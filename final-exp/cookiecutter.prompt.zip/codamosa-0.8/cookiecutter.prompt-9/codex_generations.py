

# Generated at 2022-06-22 14:43:31.033304
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test the `prompt_for_config` function.
    """
    from cookiecutter import utils
    from cookiecutter.prompt import read_user_yes_no

    sample_context = {
        'cookiecutter': {
            'project_name': "{{ cookiecutter.repo_name.title() }}",
            'repo_name': 'awesome-project',
            'pypi_username': 'audreyr',
            '_copy_without_render': ['foo.py', 'bar/'],
            'use_whitenoise': 'y',
        },
    }

    # Mock `click.prompt` with a lambda function that returns
    # whatever the function is given.
    utils.prompt = lambda *args, **kwargs: kwargs.get('default')

    #

# Generated at 2022-06-22 14:43:35.239349
# Unit test for function process_json
def test_process_json():
    user_dict = {
        "key1": "value1",
        "key2": "value2",
    }
    user_dict_json = json.dumps(user_dict)
    assert process_json(user_dict_json) == user_dict

# Generated at 2022-06-22 14:43:38.753001
# Unit test for function process_json
def test_process_json():
    # Given
    user_value = {'fake_key':'fake_value'}

    # When
    result = process_json(user_value)

    # Then
    assert isinstance(result, dict)

# Generated at 2022-06-22 14:43:40.064256
# Unit test for function prompt_for_config
def test_prompt_for_config():
    # TODO: Write unit tests
    return

# Generated at 2022-06-22 14:43:41.683478
# Unit test for function process_json
def test_process_json():
    assert process_json('foo') == 'foo'



# Generated at 2022-06-22 14:43:49.864356
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from .config_files import DEFAULT_CONFIG
    context = DEFAULT_CONFIG['cookiecutter']
    cookiecutter_dict = prompt_for_config(context)
    assert isinstance(cookiecutter_dict, dict)
    assert len(cookiecutter_dict) == 4
    assert 'full_name' in cookiecutter_dict
    assert 'email' in cookiecutter_dict
    assert 'project_name' in cookiecutter_dict
    assert 'repo_name' in cookiecutter_dict

# Generated at 2022-06-22 14:43:50.765378
# Unit test for function process_json
def test_process_json():
    pass

# Generated at 2022-06-22 14:44:00.668357
# Unit test for function render_variable
def test_render_variable():
    """ Test render_variable function """
    from cookiecutter.environment import StrictEnvironment

    context = {
        'cookiecutter': {
            'first_name': 'Test',
            'last_name': 'User',
            'email': 'test.user@example.com',
            'project_name': 'My Test Project',
            'project_slug': 'my_test_project',
            'repo_name': 'my_test_project',
            'project_short_description': 'My short description',
            'pypi_username': 'tuser',
            'project_license': 'MIT',
            'year': '2018',
            'version': '0.1.0',
            'project_version': '0.1.0',
        }
    }

# Generated at 2022-06-22 14:44:08.091492
# Unit test for function read_user_dict
def test_read_user_dict():
    user_input = """{
        "cookiecutter": {
            "full_name": "Felix Project",
            "alphabet": {"a": 1, "b": 2, "c": 3}
        }
    }"""
    expected_output = {
        "full_name": "Felix Project",
        "alphabet": {"a": 1, "b": 2, "c": 3}
    }
    assert read_user_dict("cookiecutter", {"full_name": "Felix Project"}, user_input) == expected_output

# Generated at 2022-06-22 14:44:21.032657
# Unit test for function read_user_dict
def test_read_user_dict():
    # Make variables available to the test function
    global click, process_json
    import click
    from cookiecutter.prompt import process_json

    # Parse the user-supplied value as a JSON dict
    actual = process_json('{"foo": "bar"}')
    assert isinstance(actual, dict)
    assert str(actual) == '{"foo": "bar"}'
    assert "bar" == actual["foo"]

    # Parse the user-supplied value as a JSON dict
    actual = process_json('{"foo": "bar", "no": "yes"}')
    assert isinstance(actual, dict)
    assert str(actual) == '{"foo": "bar", "no": "yes"}'
    assert "yes" == actual["no"]

    # Parse the user-supplied value as a JSON dict

# Generated at 2022-06-22 14:44:32.105077
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {'first_key':'first_value', 'second_key':'second_value'}}
    result = prompt_for_config(context, True)
    print(result)
    # excepted = {'first_key':'first_value', 'second_key':'second_value'}
    # assert result == excepted

test_prompt_for_config()

# Generated at 2022-06-22 14:44:38.944516
# Unit test for function render_variable
def test_render_variable():
    """
    It should return a rendered jinja string
    """
    env = StrictEnvironment()
    rendered_string = render_variable(env, '{{ cookiecutter.test_var }}', {'test_var': 'test value'})
    assert rendered_string == 'test value'
    rendered_string = render_variable(env, '{{ cookiecutter.test_var | replace(" value","") }}', {'test_var': 'test value'})
    assert rendered_string == 'test'

# Generated at 2022-06-22 14:44:50.782533
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit tests for the prompt_for_config function."""


# Generated at 2022-06-22 14:45:02.246581
# Unit test for function prompt_for_config
def test_prompt_for_config():
    test_context = {}

# Generated at 2022-06-22 14:45:14.912813
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Testing prompt_for_config function with different cases
    """
    from os.path import isdir, isfile
    from os import remove, rmdir

    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree

    # case with no_input
    cookiecutter('tests/test-output/fake-repo-pre/', no_input=True, overwrite_if_exists=True)

    cookiecutter_dict = prompt_for_config({
        'cookiecutter': {
            'project_name': 'Command-line copied',
            'command_line': 'copied',
        }
    }, no_input=True)
    assert cookiecutter_dict['project_name'] == 'Command-line copied'

# Generated at 2022-06-22 14:45:25.813944
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Ensure that we will get the same dictionary that we set as default"""
    context = {
        'cookiecutter': {
            'full_name': 'Bruno Oliveira',
            'email': '[hidden]',
            'github_username': 'nicoddemus',
            'project_name': 'My project',
            'project_slug': 'my_project',
            'project_short_description': 'A short description.',
            'pypi_username': 'nicoddemus',
            'release_date': 'YYYY-MM-DD',
            'version': '1.0.0',
        }
    }

    options = ['one', 'two', 'three']
    choice_default = '2'
    no_input_default = 'one'

# Generated at 2022-06-22 14:45:36.949814
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter

    # Dict is ordered for testing purposes

# Generated at 2022-06-22 14:45:48.778431
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test the prompt_for_config function."""
    from cookiecutter.environment import Environment
    import pytest
    from click.testing import CliRunner

    context = {
        'cookiecutter': {
            'project_name': 'Dummy Project',
            'repo_name': '{{ cookiecutter.project_name.lower() }}',
            'version': '0.1.0',
            'author_name': 'Your name',
        }
    }

    expected_context = {
        'cookiecutter': {
            'project_name': 'Dummy Project',
            'repo_name': 'dummy project',
            'version': '0.1.0',
            'author_name': 'Your name',
        }
    }

    env = Environment(context=context)
    cookiecutter_dict

# Generated at 2022-06-22 14:45:59.317487
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter

    context = cookiecutter("tests/fake-repo-pre/", no_input=True, output_dir="fake-repo-build/")
    print("\nContext: {} \n".format(context))
    assert context["cookiecutter"]["repo_name"] == "Yak Shaving"

    context = cookiecutter("tests/fake-repo-pre/", no_input=False, output_dir="fake-repo-build/")
    print("\nContext: {} \n".format(context))
    assert context["cookiecutter"]["repo_name"] == "New Yak Shaving"

if __name__ == "__main__":
    test_prompt_for_config()

# Generated at 2022-06-22 14:46:06.469777
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Return a config file in JSON format, according to the user's input."""
    context = {
        "cookiecutter": {
            "project_name": "Cookiecutter",
            "project_slug": "{{ cookiecutter.project_name.lower().replace(' ', '-') }}",
            "author_name": "Audreyr",
            "description": "A command-line utility that creates projects from "
                           "cookiecutters (project templates). E.g. Python package projects, "
                           "VueJS projects, etc.",
            "open_source_license": "MIT license",
            "repo_name": "cookiecutter",
            "release_date": "2014-10-09",
            "year": "2014",
            "debug": "false"
        }
    }

    # Process this with

# Generated at 2022-06-22 14:46:34.778386
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    context = utils.get_project_templates()[0]
    cookiecutter_dict = prompt_for_config(context, True)

    assert 'full_name' in cookiecutter_dict
    assert 'email' in cookiecutter_dict
    assert 'repo_name' in cookiecutter_dict

    cookiecutter('.', no_input=True, extra_context=cookiecutter_dict)

# Generated at 2022-06-22 14:46:39.395885
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""

# Generated at 2022-06-22 14:46:50.543228
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test function prompt_for_config"""

    # Test list variable
    raw_context_list = {
        "cookiecutter": {
            "key": ["option_1", "option_2"],
            "__key": "cookiecutter[\"key\"]",
        }
    }
    env_list = StrictEnvironment(context=raw_context_list)
    rend_list = render_variable(env_list, raw_context_list["cookiecutter"]["__key"],
                                raw_context_list)
    val_list = prompt_choice_for_config(raw_context_list, env_list, "key", 
                                        raw_context_list["cookiecutter"]["key"],
                                        False)
    assert val_list == "option_1"

    # Test dict variable
    raw_context

# Generated at 2022-06-22 14:47:02.676507
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test function prompt_for_config."""
    import contextlib

    # Monkeypatching stdin to read user input.
    @contextlib.contextmanager
    def _mock_stdin(mock):
        """Context manager for mocking sys.stdin."""
        import sys
        from io import StringIO
        old = sys.stdin
        sys.stdin = StringIO(mock)
        yield
        sys.stdin = old

    # Tests for prompt_for_config function.
    # Test for case of dictionary with one key.
    assert prompt_for_config({'cookiecutter': {'name': 'Test', 'version': '1.0'}},
                             no_input=True) == \
           {'name': 'Test', 'version': '1.0'}

    # Test for case of dictionary with

# Generated at 2022-06-22 14:47:09.538491
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter
    from os.path import abspath
    from pprint import pprint
    from sys import version_info

    if version_info[0] < 3:
        print('This unit test is only for Python 3')
        return

    test_path = abspath('./tests/test-output/')

# Generated at 2022-06-22 14:47:14.556475
# Unit test for function read_user_dict
def test_read_user_dict():
    # Test the valid input of a json string
    def test_valid_input():
        # The context and the default_value for the read_user_dict function
        context = "key1: value1"
        default_value = {'key1': 'value1'}
        assert read_user_dict(context, default_value) == {'key1': 'value1'}

    # Test the default return value
    def test_default_input():
        # The context and the default_value for the read_user_dict function
        context = "key1: value1"
        default_value = {'key1': 'value1'}
        assert read_user_dict(context, default_value) == {'key1': 'value1'}

    # Test the invalid input of a json string

# Generated at 2022-06-22 14:47:20.657838
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    >>> import click
    >>> click.prompt = read_user_variable
    >>> context = {'cookiecutter': {'project_name': '{{ cookiecutter.source_name }}'}}
    >>> cookiecutter_dict = prompt_for_config(context)
    """
# End of Unit test for function prompt_for_config

# Generated at 2022-06-22 14:47:29.659017
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:47:40.010851
# Unit test for function prompt_for_config
def test_prompt_for_config():
    cookiecutter_dict = {
        'full_name': 'Uri Simchoni',
        'email': 'uri@example.com',
        'project_name': 'My Project',
        'project_slug': 'my_project',
        'project_short_description': 'A short description of the project.',
        'pypi_username': 'uris',
        'release_date': '2015-04-27',
        'use_pycharm': True,
        'use_docker': False,
        'use_pypi_deployment_with_travis': False,
        'open_source_license': 'MIT license',
    }
    env = StrictEnvironment(context=cookiecutter_dict)

# Generated at 2022-06-22 14:47:49.318032
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config function.

    Config variable is replaced by the rendered variable.
    """
    from cookiecutter.main import cookiecutter

    # Create a temporary test folder.
    cookiecutters_dir = 'tests/test-generate-folder/'
    context = cookiecutter(
        cookiecutters_dir,
        no_input=True,
        extra_context={
            'full_name': 'Test Test',
            'email': 'test@example.com',
            'github_username': 'test-user',
        },
    )

    assert context['cookiecutter']['project_name'] == 'Test Project'
    assert context['cookiecutter']['repo_name'] == 'test-project'

# Generated at 2022-06-22 14:48:25.360257
# Unit test for function read_user_dict
def test_read_user_dict():
    print(read_user_dict('Enter dict', dict(a=1, b='3')))
    print(read_user_dict('Enter dict', dict(c='4', d='5')))


# Generated at 2022-06-22 14:48:26.814668
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""

test_prompt_for_config()

# Generated at 2022-06-22 14:48:39.410364
# Unit test for function read_user_dict
def test_read_user_dict():
    # Can be added:
    # Tests with invalid input
    # Exception tests
    # Tests for the default value
    test_dict = {
        'project_name': 'Peanut Butter Cookie',
        'project_slug': 'peanut-butter-cookie',
        'repo_name': 'Peanut Butter Cookie',
        'repo_slug': 'peanut-butter-cookie'
    }
    # correct: {"key": "value"}
    correct_string = '{"key": "value"}'
    # wrong: {"key": "value"
    wrong_string = '{"key": "value"'
    # wrong: test
    wrong_string2 = 'test'
    # wrong: {"key": "value",}
    wrong_string3 = '{"key": "value",}'
    # input value is not a

# Generated at 2022-06-22 14:48:45.804579
# Unit test for function process_json
def test_process_json():
    """
    process_json(user_value)
    """
    # Wrong values
    # empty string
    assert process_json('') == ""
    # wrong json
    assert process_json('{"key": "value}') == ""
    # string instead of dict
    assert process_json('"string"') == ""
    # correct json
    assert process_json('{"key": "value"}') == {"key": "value"}

# Generated at 2022-06-22 14:48:57.097676
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:49:07.236650
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:49:13.691359
# Unit test for function prompt_for_config
def test_prompt_for_config():
    import os
    import tempfile

    from cookiecutter.main import cookiecutter


# Generated at 2022-06-22 14:49:25.115437
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': OrderedDict([
            ('full_name', 'Your Name'),
            ('email', 'Your Email'),
            ('github_username', 'Your Github username'),
            ('project_name', 'Project Name'),
            ('project_slug', 'project-name'),
            ('repo_name', '{{ cookiecutter.project_name.replace(" ", "-").lower() }}'),
            ('project_short_description', 'A short description of the project.'),
        ]),
    }

# Generated at 2022-06-22 14:49:33.607197
# Unit test for function read_user_dict
def test_read_user_dict():
    env = StrictEnvironment()
    def my_dict():
        return OrderedDict([
            ('a', 1),
            ('b', 2),
            ('c', 3)
        ])

    # Test default dict
    user_dict = read_user_dict('test', my_dict())
    assert user_dict == my_dict()
    user_dict = read_user_dict('test', {'a': 1, 'b': 2, 'c': 3})
    assert user_dict == my_dict()

    # Test dicts with trailing new lines
    user_dict = read_user_dict('test', "{'a': 1, 'b': 2, 'c': 3}\n\n")
    assert user_dict == my_dict()

    # Test invalid dicts

# Generated at 2022-06-22 14:49:38.477816
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'What is your name?'
    default_value = {'name': 'Johannes', 'age': 39}
    result = read_user_dict(var_name, default_value)
    assert result['name'] == 'Johannes'
    assert result['age'] == 39

# Generated at 2022-06-22 14:50:08.545356
# Unit test for function read_user_dict
def test_read_user_dict():
    example_dict = {'A': 'b'}
    read_user_dict('test', example_dict)

# Generated at 2022-06-22 14:50:19.643830
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:50:30.239084
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Tests for function prompt_for_config"""
    context = {'cookiecutter': {'project_name': 'Test_Project',
                                'project_slug': '{{ cookiecutter.project_name.lower.replace(" ", "_") }}'}}
    cookiecutter_dict = prompt_for_config(context, True)
    cookiecutter_dict.should.contain('project_name')
    cookiecutter_dict.get('project_name').should.equal('Test_Project')
    cookiecutter_dict.should.contain('project_slug')
    cookiecutter_dict.get('project_slug').should.equal('test_project')

# Generated at 2022-06-22 14:50:36.651180
# Unit test for function render_variable
def test_render_variable():
    """Test to make sure render_variable function works."""
    cookiecutter_dict = {'full_name': 'Audrey Roy Greenfeld'}
    env = StrictEnvironment(context=cookiecutter_dict)
    raw = "{{ cookiecutter.full_name }}"
    rendered_template = render_variable(env, raw, cookiecutter_dict)
    assert rendered_template == cookiecutter_dict['full_name']

# Generated at 2022-06-22 14:50:49.373329
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test for function prompt_for_config."""

# Generated at 2022-06-22 14:50:53.286007
# Unit test for function process_json
def test_process_json():
    """Test that process_json actually accepts and returns a dict."""
    example_dict = {'a': 1, 'b': 2, 'c': 3}
    user_value = json.dumps(example_dict)
    user_response = process_json(user_value)
    assert isinstance(user_response, dict)
    assert user_response == example_dict

# Generated at 2022-06-22 14:51:04.299839
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'Cookiecutter-Puppet',
            'project_slug': 'cookiecutter-puppet',
            'project_short_description': 'A short description of the project.',
            '_template': {'license': 'MIT'},
            'year': '2014',
            'full_name': 'Your name goes here',
            'email': 'your@email.com',
            'repo_name': '',
            'repo_url': '',
            'select': [
                'a',
                'b',
                'c',
                'd',
                'e',
                'f',
                'g',
                'h',
                'i',
                'j'
            ]
        }
    }

    no_input

# Generated at 2022-06-22 14:51:07.926045
# Unit test for function read_user_dict
def test_read_user_dict():
    keys = ["key1","key2"]
    values = ["value1","value2"]
    dictionary= OrderedDict(zip(keys,values))
    assert read_user_dict("var_name", dictionary) == dictionary

# Generated at 2022-06-22 14:51:17.133111
# Unit test for function read_user_choice
def test_read_user_choice():
    """Test that read_user_choice works."""
    var_name = "test"
    options = ['a', 'b', 'c']

    # Test for valid input
    user_choice = read_user_choice(var_name, options)

    assert user_choice in options, "The user choice is not in the options"

    # Test for wrong input
    user_choice = read_user_choice(var_name, options)
    if user_choice == 'a':
        assert click.confirm('Did you choose "a"?'), "The user choice is not 'a'"
    elif user_choice == 'b':
        assert click.confirm('Did you choose "b"?'), "The user choice is not 'b'"

# Generated at 2022-06-22 14:51:28.449545
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'My Project',
            'project_slug': 'cookiecutter-my-project',
            'author_name': 'Firstname Lastname',
            'description': 'A short description of the project.',
            'domain_name': 'example.com',
            'version': '0.1.0',
            'select_license': 'MIT license',
            'open_source_license': 'MIT license',
            'pypi_username': 'my_pypi_username',
            'github_username': 'my_github_username',
            'email': 'my_name@example.com',
            'timezone': 'UTC',
        }
    }

    cookiecutter_dict = prompt_for_config(context, no_input=True)



# Generated at 2022-06-22 14:52:08.588305
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter
    from pathlib import Path
    from pathlib import PurePath
    from types import MappingProxyType
    import pytest
    from types import SimpleNamespace

    def test_prompt_for_context_string(dir_name):
        cookiecutter(dir_name)
        return True
    def test_prompt_for_context_path(dir_path):
        cookiecutter(dir_path)
        return True
    def test_prompt_for_context_pathlib(dir_pathlib):
        cookiecutter(dir_pathlib)
        return True
    def test_prompt_for_context_fit_single_char(dir_pathlib):
        cookiecutter(dir_pathlib)
        return True

# Generated at 2022-06-22 14:52:20.238034
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'Text added to render text',
            '_internal': {
                'internal_variable': 'Text added to render text',
            },
            'variable': 'Text added to render text',
            '__private': {
                'private_variable': 'Text added to render text',
            }
        }
    }

    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert 'project_name' in cookiecutter_dict
    assert '_internal' in cookiecutter_dict
    assert '__private' in cookiecutter_dict
    assert 'variable' in cookiecutter_dict

    assert 'internal_variable' in cookiecutter_dict['_internal']

# Generated at 2022-06-22 14:52:32.191681
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter import utils
    from cookiecutter import exceptions

    context = utils.make_context({'cookiecutter': {'abc': 'xyz'}})
    cookiecutter_dict = prompt_for_config(context, no_input=False)
    config_dict = utils.make_context({'cookiecutter': cookiecutter_dict})
    assert config_dict == {'cookiecutter': {'abc': u'xyz'}}

    context = utils.make_context({'cookiecutter': {'abc': ['xyz', 'uvw']}})
    cookiecutter_dict = prompt_for_config(context, no_input=False)
    config_dict = utils.make_context({'cookiecutter': cookiecutter_dict})

# Generated at 2022-06-22 14:52:44.076335
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Unit test for function prompt_for_config
    """
    class Namespace(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)


# Generated at 2022-06-22 14:52:51.976947
# Unit test for function prompt_for_config
def test_prompt_for_config():
    test_dict = {
        'cookiecutter': {
            'project_name': 'foo',
            'description': 'Cool project!',
            'author': 'First Last',
            'open_source_license': 'MIT license'
        }
    }


# Generated at 2022-06-22 14:52:57.166943
# Unit test for function read_user_dict
def test_read_user_dict():
    context = {
        'cookiecutter': {'my_dict': {'foo': 'bar'}, 'my_list': ['1', '2']}
    }

    cookiecutter_dict = prompt_for_config(context, no_input=True)

    assert cookiecutter_dict['my_dict'] == {'foo': 'bar'}
    assert cookiecutter_dict['my_list'] == ['1', '2']

# Generated at 2022-06-22 14:53:03.965228
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = "one"
    default_value = {
        "joe": "nothing",
        "mama": "joe",
        "chair": "joe",
        "2": "crazy",
    }
    expected_result = {
        "joe": "nothing",
        "mama": "joe",
        "chair": "joe",
        "2": "crazy",
    }
    user_value = read_user_dict(var_name, default_value)
    assert user_value == expected_result

# Generated at 2022-06-22 14:53:12.738116
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'test_dict'
    default_value = {'foo': 'bar', 'baz': ['biz', 'boz']}

    # test with `default`
    user_value = 'default'
    assert default_value == read_user_dict(var_name, default_value)

    # test with simple dict
    user_value = '{"foo": "baz"}'
    assert {'foo': 'baz'} == read_user_dict(var_name, default_value)

    # test with complex dict
    user_value = '{"foo": "baz", "biz": {"baz": ["biz", "boz"]}}'