

# Generated at 2022-06-22 14:43:33.979118
# Unit test for function read_user_dict
def test_read_user_dict():
    """Unit test for function read_user_dict"""
    env = StrictEnvironment(context = {})
    key = "test"
    default_value = {}

    # Test with empty string. Should return the default value.
    result = read_user_dict(key, default_value)
    assert result == default_value

    # Test with string 'default'. Should return the default value.
    result = read_user_dict(key, default_value)
    assert result == default_value

    # Test with string json. Should return the json.
    user_dict = {
        "hello": "world!",
        "foo": "bar"
    }
    result = read_user_dict(key, default_value)
    assert result == user_dict

    # Test with string json. Should raise click.UsageError

# Generated at 2022-06-22 14:43:46.494880
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Prompts the user for all the configuration information to generate the requested project

    """

# Generated at 2022-06-22 14:43:56.144372
# Unit test for function process_json
def test_process_json():
    """Test load user-supplied value as a JSON dict."""
    # test when user_value is not a dictionary
    user_value = '["elem"]'
    try:
        process_json(user_value)
    except click.UsageError:
        pass
    else:
        assert False, "Duplicated key of JSON not found."

    # test when user_value is a dictionary
    user_value = '{"elem": "elem"}'
    assert process_json(user_value) == json.loads(user_value, object_pairs_hook=OrderedDict)

# Generated at 2022-06-22 14:43:58.014312
# Unit test for function process_json
def test_process_json():
    assert {"a": "b"} == process_json('{"a": "b"}')
    assert {"a": "b"} == process_json('{   "a": "b"  }')


# Generated at 2022-06-22 14:44:05.345238
# Unit test for function prompt_for_config
def test_prompt_for_config():
    import os
    import pytest
    from cookiecutter.config import CONFIG_FILE
    from cookiecutter.prompt import read_user_variable, read_user_yes_no

    def _mock_user_variable(var_name, default_value):
        if var_name=='project_name':
            return 'project_name'
        elif var_name=='author_name':
            return 'author_name'
        elif var_name=='author_email':
            return 'author_email'
        elif var_name=='pypi_username':
            return 'pypi_username'
        else:
            return default_value

    def _mock_user_yes_no(question, default_value):
        if question == 'Shall we start?':
            return True

# Generated at 2022-06-22 14:44:16.130300
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:44:19.212006
# Unit test for function read_user_dict
def test_read_user_dict():
    user_dict = read_user_dict('test_dict', {'a': 1, 'b': 2})
    assert user_dict == {'a': 1, 'b': 2}



# Generated at 2022-06-22 14:44:30.182077
# Unit test for function prompt_for_config
def test_prompt_for_config():
    no_input = False
    context = {
        'cookiecutter': {
            'project_name': 'Peanut Butter Cookie',
            'project_slug': 'peanut-butter-cookie',
            'pylint_rcfile': '.pylintrc',
            'repo_name': "{{ cookiecutter.project_name.replace(' ', '_') }}",
            'repo_short_description': 'An example project that'
            ' shows some of cookiecutter-pypackage'
            ' capabilities',
        }
    }
    output = prompt_for_config(context, no_input)

# Generated at 2022-06-22 14:44:36.054024
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'names'
    default_value = {'a': 1, 'b':2}
    user_value = OrderedDict([('a', 1), ('b', 2)])
    assert(read_user_dict(var_name, default_value) == user_value)
    return True

# Generated at 2022-06-22 14:44:49.149897
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        "cookiecutter": {
            # simple variable
            "project_name": "Default project _name",

            # raw variable
            "project_short_description": "UNICODE SNOWMAN: ☃",

            # choice variable
            "open_source_license": [
                "MIT license",
                "BSD license",
                "ISC license",
                "Apache Software License 2.0",
                "GNU General Public License v3",
            ],

            # list variable
            "bootstrap": ["off", "XHTML", "Simple"],

            # dictionary variable
            "post_processors": {
                "compress_static": "yes",
                "compress_assets": "yes",
            },
        }
    }

    no_input = False

# Generated at 2022-06-22 14:45:05.664888
# Unit test for function render_variable
def test_render_variable():
    """Unit test for function render_variable."""
    env = StrictEnvironment()
    cookiecutter_dict = OrderedDict([("test_test", "test")])
    # test normal str
    raw = "{{ cookiecutter.test_test }}"
    assert render_variable(env, raw, cookiecutter_dict) == "test"
    # test raw str
    raw = "'{{ cookiecutter.test_test }}'"
    assert render_variable(env, raw, cookiecutter_dict) == "'{{ cookiecutter.test_test }}'"
    # test bool
    raw = True
    assert render_variable(env, raw, cookiecutter_dict) == "True"
    # test dict
    raw = {"test": "{{ cookiecutter.test_test }}"}

# Generated at 2022-06-22 14:45:12.303957
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {"cookiecutter": {"full_name": "Your Name"}}
    cookiecutter_dict = prompt_for_config(context)
    assert cookiecutter_dict == {"full_name": "Your Name"}

    cookiecutter_dict = prompt_for_config(context, True)
    assert cookiecutter_dict == {"full_name": "Your Name"}

test_prompt_for_config()

# Generated at 2022-06-22 14:45:24.017757
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'Awesome Project',
            'package_name': '{{ cookiecutter.project_name.lower().replace(" ", "_") }}',
        }
    }
    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert (cookiecutter_dict == {'project_name': 'Awesome Project', 'package_name': 'awesome_project'})


# Generated at 2022-06-22 14:45:31.478720
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = "test"
    default_value = {'testKey': 'testValue'}

    # Case 1: Provide valid JSON
    with click.testing.CliRunner() as runner:
        result = runner.invoke(read_user_dict, [var_name, default_value], input='{"hello": "world"}')
        assert result.exception == None
        assert result.exit_code == 0

    # Case 2: Provide invalid JSON
    with click.testing.CliRunner() as runner:
        result = runner.invoke(read_user_dict, [var_name, default_value], input='{"hello": "world"')
        assert result.exception != None
        assert isinstance(result.exception, click.UsageError)
        assert result.exit_code == -1

    # Case 3: Provide default
   

# Generated at 2022-06-22 14:45:40.637097
# Unit test for function render_variable
def test_render_variable():
    """Test ability to render a variable."""
    env = StrictEnvironment()
    cookie_context = {
        'cookiecutter': {
            'project_name': 'Peanut Butter Cookie',
            'repo_name': '{{ cookiecutter.project_name.lower().replace(" ", "_") }}',
        }
    }
    expected = 'peanut_butter_cookie'
    rendered_template = render_variable(
        env, cookie_context['cookiecutter']['repo_name'], cookie_context
    )
    assert rendered_template == expected, rendered_template

# Generated at 2022-06-22 14:45:52.087256
# Unit test for function render_variable
def test_render_variable():
    env = StrictEnvironment()
    dict = dict(cookiecutter_repo = 'tests', project_name = 'test project')
    key = 'project_name'
    render_variable(env, key, dict)

    key = 'cookiecutter_repo'
    render_variable(env, key, dict)

    key = '{{ cookiecutter_repo }}'
    render_variable(env, key, dict)

    key = '{{ cookiecutter_repo.upper() }}'
    render_variable(env, key, dict)

    key = '{{ cookiecutter.project_name.replace(" ", "_") }}'
    render_variable(env, key, dict)

    key = '{{ cookiecutter.project_name().replace(" ", "_") }}'
    render_variable(env, key, dict)

   

# Generated at 2022-06-22 14:46:00.910515
# Unit test for function process_json
def test_process_json():

    #Test the process_json() function is defined
    assert process_json

    #Test the process_json() function returns the right type
    #Test the process_json() function can process a valid json
    assert isinstance(process_json('{"a": 1, "b": 2, "c": 3}'), dict)

    #Test the process_json() function raises an exception on invalid json
    with pytest.raises(click.UsageError):
        process_json('{"a": 1 "b": 2 "c": 3}')

    #Test the process_json() function raises an exception on non-json object
    with pytest.raises(click.UsageError):
        process_json('["a", 1, "b", 2, "c", 3]')

# Generated at 2022-06-22 14:46:10.248131
# Unit test for function prompt_for_config
def test_prompt_for_config():
    def mock_input(raw):
        return raw

    # Test correct values

# Generated at 2022-06-22 14:46:15.295744
# Unit test for function render_variable
def test_render_variable():
    env = StrictEnvironment()

    cookiecutter_dict = {'project_slug': 'peanut-butter-cookie'}

    assert render_variable(env, '{{ cookiecutter.project_slug.replace("-", "_") }}', cookiecutter_dict) == 'peanut_butter_cookie'

# Generated at 2022-06-22 14:46:23.454214
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    prompt_for_config can handle a variety of data types passed in, from
    string to boolean to list and dict types. This is to ensure backward
    compatibility checks for older cookiecutter.json.
    """
    # Tests for backward compatibility for older cookiecutter.json

# Generated at 2022-06-22 14:46:41.231410
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for prompt_for_config function."""
    import pytest
    from unittest.mock import patch, mock_open
    from collections import OrderedDict
    from cookiecutter import environment
    import json

    # Mock the file open function
    def mock_return_value(*argv, **kwargs):
        return mock_open(read_data=json.dumps(
            OrderedDict({
                'project_name': 'Cookiecutter',
                'project_template_name': '{{ cookiecutter.project_name }}',
                '_template': 'My template'
            })
        ))


# Generated at 2022-06-22 14:46:46.006815
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:46:50.258993
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {'cookiecutter': {'project_name': 'My Project', 'repo_name': 'my_project'}}
    cookiecutter_dict = {'project_name': 'My Project'}
    env = StrictEnvironment(context=context)

    assert prompt_for_config(context, no_input=True) == cookiecutter_dict
    render_variable(env, '{{cookiecutter.project_name}}', cookiecutter_dict) == 'My Project'

    cookiecutter_dict['project_name'] = 'My new Project'
    render_variable(env, '{{cookiecutter.project_name}}', cookiecutter_dict) == 'My new Project'

# Generated at 2022-06-22 14:47:02.639834
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Unit test for function prompt_for_config
    
    """

# Generated at 2022-06-22 14:47:09.517514
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """ Test Unit for prompt_for_config """


# Generated at 2022-06-22 14:47:15.453276
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """ Unit test for function prompt_for_config."""
    context = {
        'cookiecutter': {
            'project_name': {'_input_message': 'Project name: ', 'default': 'My Project'},
            'repo_name': "{{ cookiecutter.project_name }}",
        }
    }

    config = prompt_for_config(context)
    assert config['project_name'] == 'My Project'
    assert config['repo_name'] == 'My Project'

# Generated at 2022-06-22 14:47:23.917478
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'test_value1': 'test_value'
        }
    }

    cookiecutter_dict = prompt_for_config(context, no_input=True)
    assert cookiecutter_dict['test_value1'] == 'test_value'

    cookiecutter_dict = prompt_for_config(context, no_input=False)
    assert cookiecutter_dict['test_value1'] == 'test_value'



# Generated at 2022-06-22 14:47:26.832267
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test function prompt_for_config"""
    # TODO: Make this test work
    project = prompt_for_config({
        'key': 'value',
    })
    print(project)

# Generated at 2022-06-22 14:47:27.400189
# Unit test for function read_user_dict
def test_read_user_dict():
    pass

# Generated at 2022-06-22 14:47:38.327718
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Verify the prompt_for_config function."""
    context = {
        "cookiecutter": {
            "project_name": "Cookie one",
            "repo_name": "{{ cookiecutter.project_name.replace(' ', '_') }}",
            "open_source_license": "MIT license",
            "author_name": "Your Name",
            "email": "you@example.com",
            "description": "A short description of the project.",
            "domain_name": "example.com",
            "version": "0.1.0",
        },
    }
    #no_input = False
    result = prompt_for_config(context, no_input=False)
    print(result)
    #assert result["project_name"] == "Cookie one"
    #assert result["repo

# Generated at 2022-06-22 14:48:03.205803
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for prompt for config."""

# Generated at 2022-06-22 14:48:15.993081
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:48:26.795165
# Unit test for function read_user_dict
def test_read_user_dict():
    """ Unit test for function read_user_dict """
    # Test a normal condition
    var_name = 'test_name'
    default_dict = {'test_key': 'test_value'}
    result_dict = read_user_dict(var_name, default_dict)
    assert result_dict == {'test_key': 'test_value'}
    # Test when default_value is not a dict
    default_dict = 'test_value'
    try:
        result_dict = read_user_dict(var_name, default_dict)
        assert False
    except TypeError:
        assert True
    # Test when user enters invalid JSON dict
    try:
        result_dict = read_user_dict(var_name, default_dict)
        assert False
    except click.UsageError:
        assert True


# Generated at 2022-06-22 14:48:29.471903
# Unit test for function process_json
def test_process_json():
    test_str = "{\"type\": \"bool\"}"
    assert isinstance(process_json(test_str), dict)



# Generated at 2022-06-22 14:48:41.473836
# Unit test for function read_user_dict
def test_read_user_dict():
    # test 1, different types of variables including nested objects and list variable
    default_value = {
        'company': 'test',
        'contact': {
            'name': 'test',
            'email': ['test1@test.com', 'test2@test.com'],
        },
    }
    user_value = '{"company":"test", "contact": {"name":"test", "email":["test1@test.com", "test2@test.com"]}}'
    var_name = 'test'
    assert read_user_dict(var_name, default_value) == default_value
    assert read_user_dict(var_name, user_value) == user_value

    # test 2, invalid data type
    default_value = 'test'
    user_value = ['test']
    var_name = 'test'

# Generated at 2022-06-22 14:48:49.551313
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'project_name': 'Awesome Project',
            '_template': {
                'repo_name': '{{ cookiecutter.project_name.lower() }}',
                'project_slug': '{{ cookiecutter.project_name.lower().replace(" ", "-") }}',
                'project_short_description': 'A short description of the project.',
                'pypi_username': 'audreyr',
                'open_source_license': 'MIT',
                'year': '{{ cookiecutter.release_date.year }}',
                'version': '0.1.0',
                'release_date': '{{ cookiecutter.now|datetimeformat("%b. %d, %Y") }}',
            },
        }
    }

    rendered_context = prompt

# Generated at 2022-06-22 14:48:54.847663
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter import template

    context = template.parse_cookiecutter_json(
        'tests/test-output/fake-repo-pre/'
    )
    cookiecutter_dict = prompt_for_config(context)
    assert isinstance(cookiecutter_dict, dict)
    assert cookiecutter_dict["project_name"] == "Cookiecutter Awesome Project"

# Generated at 2022-06-22 14:49:05.449381
# Unit test for function prompt_for_config
def test_prompt_for_config():

    context = {
    "cookiecutter": {
        "project_name": "Awesome Project",
        "project_slug": "awesome_project",
        "pypi_username": "audreyr",
        "github_username": "audreyr",
        "author_name": "Audrey Roy",
        "email": "audreyr@example.com",
        "description": "The best Python package ever!",
        "domain_name": "example.com",
        "version": "0.1.0",
        "license": "BSD",
        "readme": "README.rst",
        "year": "2014",
        "use_pycharm": "y",
        "console_scripts": [
            "audrey = awesome_project.__main__:main"
        ],
    }
    }

# Generated at 2022-06-22 14:49:17.324445
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit testing for function prompt_for_config."""
    context = dict(
        cookiecutter={
            'a': 1,
            'b': 2,
            'c': [1, 2, 3],
            'd': {1: 2, 3: 4},
            'e': '{{ cookiecutter.a }}',
            'f': [1, '{{ cookiecutter.c }}'],
            'g': {'a': '{{ cookiecutter.d }}'},
            '_internal': {'a': 1, 'b': 2, 'c': '{{ cookiecutter.a }}'},
            '__secret': '{{ cookiecutter.d }}',
        }
    )
    result = prompt_for_config(context)
    assert result['a'] == 1
    assert result['b'] == 2
   

# Generated at 2022-06-22 14:49:27.666958
# Unit test for function prompt_for_config
def test_prompt_for_config():
    context = {
        'cookiecutter': {
            'repo_name': "Open Event Frontend",
            'project_name': 'Open Event Organizer Frontend',
            'select_framework': ['react', 'angular'],
            'features': ['mailing', 'comment', 'analytics'],
            'use_mailchimp': 'no',
            'open_source_license': ['MIT', 'BSD', 'GPLv3'],
            'emails': {
                'support': {
                    'enabled': 'yes',
                    'email': 'info@yourdomain.com'
                }
            }
        }
    }
    cookiecutter_dict = prompt_for_config(context=context, no_input=True)

# Generated at 2022-06-22 14:50:06.542180
# Unit test for function read_user_dict
def test_read_user_dict():
    # Test with no input, should return a dict
    mock_value = {'a': 'b', 'c': 'd'}
    assert read_user_dict('test', mock_value) == mock_value

    # Test with valid and invalid input
    mock_valid = '''{"a": "b", "c": "d"}'''
    mock_invalid = '''{"a": "b", c": "d"}'''

    assert read_user_dict('test', mock_value, mock_valid) == {'a': 'b', 'c': 'd'}
    try:
        read_user_dict('test', mock_value, mock_invalid)
    except click.exceptions.UsageError:
        pass
    else:
        assert False

# Generated at 2022-06-22 14:50:10.798075
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from .test_generate_files import cookiecutter_json_dict
    context = cookiecutter_json_dict(no_input=False)
    result = prompt_for_config(context,no_input=True)
    
    assert result is not None

# Generated at 2022-06-22 14:50:13.929515
# Unit test for function read_user_choice
def test_read_user_choice():
    my_list = ["option1", "option2", "option3"]
    assert read_user_choice("MyQuestion", my_list) in my_list

# Generated at 2022-06-22 14:50:20.106476
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:50:28.068711
# Unit test for function prompt_for_config
def test_prompt_for_config():
    test_context = {"cookiecutter":
        {"project_name": "{{ cookiecutter.repo_name.replace(' ', '-') }}",
         "repo_name": "{{ cookiecutter.project_name.replace('-', ' ') }}"}
    }
    cookiecutter_dict = prompt_for_config(test_context)
    assert cookiecutter_dict['repo_name'] == cookiecutter_dict['project_name']

# Generated at 2022-06-22 14:50:38.170097
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from .prompt import prompt_choice_for_config
    from .compat import mock
    from .prompt import read_user_dict
    from .prompt import read_user_variable
    from .prompt import read_user_choice
    from .context_dictionary import load_context_file
    from .exceptions import FailedHookException
    context = load_context_file("test.json")
    no_input = True
    cookiecutter_dict = OrderedDict([])
    env = StrictEnvironment(context=context)

    key = "test"
    raw = '{"test": {"a": "{% if b is defined %}yes{% else %}no{% endif %}"}}'
    raw = json.loads(raw)
    val = render_variable(env, raw, cookiecutter_dict)
   

# Generated at 2022-06-22 14:50:50.827569
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Test prompt_for_config"""

    from cookiecutter.main import cookiecutter

    config_file = './tests/test-prompt-config-file.json'

    # The output of this function needs to be a dictionary.
    output = cookiecutter(config_file, no_input=False)
    assert(isinstance(output, dict))

    # If no input is given then the function should return defaults.
    output = cookiecutter(config_file, no_input=True)
    assert(isinstance(output, dict))
    assert(len(output.keys()) == 7)
    assert(output['project_name'] == 'Cookiecutter')
    assert(output['email'] == 'no-one@example.com')
    assert(output['project_slug'] == 'cookiecutter')

# Generated at 2022-06-22 14:50:54.997687
# Unit test for function read_user_dict
def test_read_user_dict():
    assert read_user_dict(
        "Which variables would you like to add to your public ssh key?",
        {'foo': {}, 'bar': []}
    ) == {'foo': {}, 'bar': []}

# Generated at 2022-06-22 14:51:01.326922
# Unit test for function read_user_dict
def test_read_user_dict():
    """ Test read_dict function. """
    given_user_dict = read_user_dict("user_dict_prompt", {})
    assert given_user_dict == {}

    given_user_dict = read_user_dict("user_dict_prompt", {'key': 'value'})
    assert given_user_dict == {'key': 'value'}

# Generated at 2022-06-22 14:51:13.736992
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    This function unit tests the function prompt_for_config
    """

# Generated at 2022-06-22 14:52:14.813285
# Unit test for function read_user_choice
def test_read_user_choice():
    var_name = "test_variable"
    options = ["foo", "bar", "baz"]
    result = read_user_choice(var_name, options)
    assert result in options, "result should be in options"


# Generated at 2022-06-22 14:52:22.841192
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test to validate the function prompt_for_config."""

    # Input data
    context = {
        'cookiecutter': {
            'project_name': 'Cookiecutter is a cool project!',
            '_template': {
                'repo_name': 'cookiecutter',
                'repo_url': 'https://github.com/audreyr/cookiecutter',
            },
            'repo_name': '{{ cookiecutter._template.repo_name }}',
            'repo_url': '{{ cookiecutter._template.repo_url }}',
        },
    }
    no_input = True

    # Expected output

# Generated at 2022-06-22 14:52:33.217954
# Unit test for function prompt_for_config

# Generated at 2022-06-22 14:52:38.927954
# Unit test for function read_user_dict
def test_read_user_dict():
    var_name = 'asdf'
    default_value = {'a' : 'b', 'c' : {'d': 'e'}}
    result = read_user_dict(var_name, default_value)
    assert isinstance(result, dict)



# Generated at 2022-06-22 14:52:44.868502
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config"""
    context = {
        'cookiecutter': {
            'name': 'user',
            'handle': 'user'
        }
    }
    cookiecutter_config = prompt_for_config(context, False)
    assert cookiecutter_config['name'] == 'user'
    assert cookiecutter_config['handle'] == 'user'

# Generated at 2022-06-22 14:52:50.524812
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """get configuration file path and read configurations"""
    # config_file = os.path.abspath(os.path.join(os.getcwd(), 'cfg/config.json'))
    # with open(config_file, "r") as read_file:
    #     config = json.load(read_file)
    # read_file.close()
    # context = config
    # no_input = True
    # cookiecutter_dict = prompt_for_config(context, no_input)
    # assert type(cookiecutter_dict) == OrderedDict
    pass

# Generated at 2022-06-22 14:52:52.831753
# Unit test for function prompt_for_config
def test_prompt_for_config():
    from cookiecutter.main import cookiecutter
    cookiecutter('tests/test-driven-project/', no_input=True)

# Generated at 2022-06-22 14:52:59.773939
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """Unit test for function prompt_for_config."""
    # Scenario:
    # User is prompted to enter a value for a simple variable
    # and the rendered value is returned
    context = {
        'cookiecutter': {
            'name': '{{cookiecutter.first_name}}-{{cookiecutter.last_name}}'
        },
        'cookiecutter_dict': {'first_name': 'John', 'last_name': 'Doe'},
    }
    cookiecutter_dict = prompt_for_config(context)

    assert cookiecutter_dict['name'] == 'John-Doe'


# Generated at 2022-06-22 14:53:06.882340
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Tests the prompt_for_config function.

    :param dict context: Source for field names and sample values.
    :param no_input: Prompt the user at command line for manual configuration?
    """
    context={'cookiecutter': {'project_name': 'Awesome Project',
                        'repo_name': '{{ cookiecutter.project_name.replace(" ", "_") }}',
                        'company_name': 'Big Corp',
                        'email': '{{ cookiecutter.company_name|lower }}.com'}}
    result = prompt_for_config(context)
    print(result)

test_prompt_for_config()

# Generated at 2022-06-22 14:53:13.318599
# Unit test for function prompt_for_config
def test_prompt_for_config():
    """
    Test prompt_for_config function.
    """
    try:
        from cookiecutter.main import cookiecutter
        # Inputs
        context = {'author_name': 'Your name goes here'}
        # Outputs
        cookiecutter_dict = cookiecutter(
            template='test.git', context=context, no_input=True
        )
        # Assert:
        assert cookiecutter_dict == {'author_name': 'Audrey Roy Greenfeld'}
    except ImportError:
        print("Cookiecutter must be installed to run this test.")