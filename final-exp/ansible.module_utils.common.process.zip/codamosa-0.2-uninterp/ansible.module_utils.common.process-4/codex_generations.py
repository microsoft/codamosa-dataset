

# Generated at 2022-06-16 22:48:37.801355
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/bin'], ['/sbin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/bin', '/usr/bin'], ['/sbin']) == '/bin/sh'

# Generated at 2022-06-16 22:48:44.894199
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin'], required=True) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin'], required=False) == '/usr/bin/ls'

# Generated at 2022-06-16 22:48:56.393753
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin'], required=True) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin'], required=False) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin'], required=None) == '/usr/bin/ls'

# Generated at 2022-06-16 22:49:06.921666
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    test_file = os.path.join(tmpdir, 'test_file')
    open(test_file, 'a').close()

    # Create a subdirectory in the temporary directory
    subdir = os.path.join(tmpdir, 'subdir')
    os.mkdir(subdir)

    # Create a file in the subdirectory
    test_file_subdir = os.path.join(subdir, 'test_file_subdir')
    open(test_file_subdir, 'a').close()

    # Test that get_bin_path raises an exception if the file is not found

# Generated at 2022-06-16 22:49:15.788276
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    test_file = os.path.join(tmpdir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')

    # Create a temporary PATH
    old_path = os.environ['PATH']
    os.environ['PATH'] = tmpdir

    # Test that get_bin_path raises an exception if the file is not executable
    try:
        get_bin_path('test_file')
        assert False
    except ValueError:
        pass

    # Make the file executable
    os.chmod(test_file, stat.S_IRWXU)

    #

# Generated at 2022-06-16 22:49:26.564986
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    test_file = os.path.join(tmpdir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('#!/bin/sh\nexit 0')
    # Make the file executable
    os.chmod(test_file, stat.S_IRWXU)

    # Test get_bin_path

# Generated at 2022-06-16 22:49:33.138425
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/usr/sbin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/sbin', '/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/sbin', '/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/usr/sbin']) == '/usr/bin/sh'

# Generated at 2022-06-16 22:49:45.819604
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/sbin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/sbin', '/usr/sbin']) == '/bin/ls'

# Generated at 2022-06-16 22:49:57.692272
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    test_file = os.path.join(tmpdir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('#!/bin/sh\nexit 0')
    # Make the file executable
    os.chmod(test_file, stat.S_IRWXU)

    # Test that get_bin_path finds the file
    assert get_bin_path('test_file', opt_dirs=[tmpdir]) == test_file

    # Test that get_bin_path raises an exception if the file is not found

# Generated at 2022-06-16 22:50:05.465191
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin']) == '/bin/sh'

# Generated at 2022-06-16 22:50:13.007823
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a temporary file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # make the temporary file executable
    os.chmod(tmpfile, stat.S_IRWXU)

    # test that the temporary file is found
    assert get_bin_path(os.path.basename(tmpfile), opt_dirs=[tmpdir]) == tmpfile

    # test that the temporary file is not found if not executable
    os.chmod(tmpfile, stat.S_IRUSR)

# Generated at 2022-06-16 22:50:22.550929
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/bin'], ['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/bin', '/usr/bin'], ['/bin']) == '/bin/sh'

# Generated at 2022-06-16 22:50:34.569720
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/bin'], required=True) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/bin', '/usr/bin'], required=True) == '/bin/sh'

# Generated at 2022-06-16 22:50:42.634872
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin'], required=True) == '/bin/ls'
    try:
        get_bin_path('ls', opt_dirs=['/usr/bin'], required=True)
        assert False, 'get_bin_path did not raise exception'
    except ValueError:
        pass

# Generated at 2022-06-16 22:50:51.462367
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    test_file = os.path.join(tmpdir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('#!/bin/sh\necho "Hello World"\n')
    os.chmod(test_file, stat.S_IRWXU)

    # Test that the file is found
    assert get_bin_path('test_file', opt_dirs=[tmpdir]) == test_file

    # Test that the file is not found

# Generated at 2022-06-16 22:51:01.637079
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)

    # Make the temporary file executable
    os.chmod(tmpfile, stat.S_IRWXU)

    # Test get_bin_path
    assert get_bin_path(os.path.basename(tmpfile), opt_dirs=[tmpdir]) == tmpfile

    # Clean up
    os.close(fd)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 22:51:09.967548
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/bin'], ['/sbin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/bin', '/usr/bin'], ['/sbin']) == '/bin/sh'

# Generated at 2022-06-16 22:51:22.680129
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a temporary executable file
    tmpexec = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    os.chmod(tmpexec.name, stat.S_IRWXU)
    tmpexec.close()

    # Test that get_bin_path raises an exception if the executable is not found
    try:
        get_bin_path('not_an_executable')
        assert False, 'get_bin_path did not raise an exception'
    except ValueError:
        pass

    # Test that get_bin_path raises an exception

# Generated at 2022-06-16 22:51:32.980277
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin', '/usr/local/bin']) == '/usr/bin/sh'

# Generated at 2022-06-16 22:51:45.025147
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/local/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/local/bin', '/usr/local/sbin']) == '/usr/bin/ls'

# Generated at 2022-06-16 22:51:59.616989
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin', '/usr/bin', '/usr/local/bin']) == '/bin/sh'

# Generated at 2022-06-16 22:52:06.536911
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/sbin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/sbin', '/sbin']) == '/usr/bin/ls'

# Generated at 2022-06-16 22:52:17.057176
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/bin'], ['/sbin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/bin'], ['/sbin', '/usr/sbin']) == '/usr/bin/sh'

# Generated at 2022-06-16 22:52:23.941549
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/local/bin']) == '/usr/bin/ls'

# Generated at 2022-06-16 22:52:36.266482
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin', '/usr/local/bin']) == '/bin/sh'

# Generated at 2022-06-16 22:52:45.093338
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    test_file = os.path.join(tmpdir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('#!/bin/sh\necho "test_file"\n')
    # Make the file executable
    os.chmod(test_file, stat.S_IRWXU)

    # Create a subdirectory in the temporary directory
    subdir = os.path.join(tmpdir, 'subdir')
    os.mkdir(subdir)

    # Create a file in the subdirectory

# Generated at 2022-06-16 22:52:53.878116
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/local/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/local/bin']) == '/usr/bin/ls'
    assert get

# Generated at 2022-06-16 22:53:04.022640
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    test_file = os.path.join(tmpdir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('#!/bin/sh\necho "Hello world"\n')

    # Make the file executable
    os.chmod(test_file, stat.S_IRWXU)

    # Test get_bin_path
    assert get_bin_path('test_file', opt_dirs=[tmpdir]) == test_file

    # Clean up
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 22:53:12.259897
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin'], required=True) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin'], required=False) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin'], required=None) == '/bin/sh'

# Generated at 2022-06-16 22:53:24.525283
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    test_file = os.path.join(tmpdir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('#!/bin/sh\necho "Hello World"\n')
    os.chmod(test_file, 0o755)

    # Test get_bin_path
    assert get_bin_path('test_file', opt_dirs=[tmpdir]) == test_file

    # Test get_bin_path with a non-existent file

# Generated at 2022-06-16 22:53:42.927090
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'

# Generated at 2022-06-16 22:53:52.200991
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    testfile = os.path.join(tmpdir, 'testfile')
    with open(testfile, 'w') as f:
        f.write('#!/bin/sh\nexit 0')
    os.chmod(testfile, 0o755)

    # Test get_bin_path

# Generated at 2022-06-16 22:54:04.602611
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin'], required=True) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin'], required=False) == '/usr/bin/ls'

# Generated at 2022-06-16 22:54:16.194104
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # create a temporary file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    # make the file executable
    os.chmod(tmpfile, 0o755)
    # get the file name
    tmpfile = os.path.basename(tmpfile)

    # test that the file is found
    assert get_bin_path(tmpfile, opt_dirs=[tmpdir]) == os.path.join(tmpdir, tmpfile)

    # test that the file is not found
    try:
        get_bin_path(tmpfile, opt_dirs=['/tmp'])
    except ValueError:
        pass

# Generated at 2022-06-16 22:54:26.525289
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/local/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/local/bin', '/usr/local/sbin']) == '/usr/bin/ls'

# Generated at 2022-06-16 22:54:38.453899
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)

    # Make the temporary file executable
    os.chmod(tmpfile, stat.S_IRWXU)

    # Test that get_bin_path() finds the temporary file
    assert get_bin_path(os.path.basename(tmpfile), opt_dirs=[tmpdir]) == tmpfile

    # Test that get_bin_path() raises an exception if the file is not found
    try:
        get_bin_path(os.path.basename(tmpfile) + 'foo', opt_dirs=[tmpdir])
        assert False
    except ValueError:
        pass

# Generated at 2022-06-16 22:54:50.088205
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function
    '''
    # Test for valid executable
    assert get_bin_path('ls') == '/bin/ls'
    # Test for invalid executable
    try:
        get_bin_path('invalid_executable')
    except ValueError as e:
        assert 'Failed to find required executable "invalid_executable"' in str(e)
    # Test for valid executable with optional dirs
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/bin/ls'
    # Test for invalid executable with optional dirs

# Generated at 2022-06-16 22:55:00.281856
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/local/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/local/bin', '/usr/local/sbin']) == '/usr/bin/ls'

# Generated at 2022-06-16 22:55:12.425050
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with required=True
    try:
        get_bin_path('/bin/ls', required=True)
    except ValueError:
        assert False, 'get_bin_path failed to find /bin/ls'

    # Test with required=False
    try:
        get_bin_path('/bin/ls', required=False)
    except ValueError:
        assert False, 'get_bin_path failed to find /bin/ls'

    # Test with required=None
    try:
        get_bin_path('/bin/ls')
    except ValueError:
        assert False, 'get_bin_path failed to find /bin/ls'

    # Test with required=True and opt_dirs

# Generated at 2022-06-16 22:55:24.041628
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/local/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/local/bin', '/usr/local/sbin']) == '/bin/ls'

# Generated at 2022-06-16 22:55:44.848195
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/usr/bin']) == '/usr/bin/ls'

# Generated at 2022-06-16 22:55:54.901865
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    test_file = os.path.join(tmpdir, 'test_file')
    open(test_file, 'a').close()

    # Create a directory in the temporary directory
    test_dir = os.path.join(tmpdir, 'test_dir')
    os.mkdir(test_dir)

    # Create a file in the temporary directory that is executable
    test_exec = os.path.join(tmpdir, 'test_exec')
    open(test_exec, 'a').close()
    os.chmod(test_exec, 0o755)

    # Create a file in the temporary directory that is not executable
    test_noexec = os

# Generated at 2022-06-16 22:56:00.562151
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with a valid executable
    assert get_bin_path('python') == '/usr/bin/python'

    # Test with a non-existent executable
    try:
        get_bin_path('not_an_executable')
    except ValueError as e:
        assert 'Failed to find required executable "not_an_executable"' in str(e)
    else:
        assert False, 'get_bin_path did not raise an exception for a non-existent executable'

# Generated at 2022-06-16 22:56:07.451677
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_get_bin_path'), 'w')
    f.close()
    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()
    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir2, 'test_get_bin_path'), 'w')
    f.close()

    # Test that get_bin_path raises an exception if the file is not found
    try:
        get_bin_path('test_get_bin_path', [tmpdir])
        assert False
    except ValueError:
        pass

    # Test

# Generated at 2022-06-16 22:56:15.780542
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for existing executable
    assert get_bin_path('ls') == '/bin/ls'
    # Test for non-existing executable
    try:
        get_bin_path('non-existing-executable')
    except ValueError as e:
        assert 'Failed to find required executable "non-existing-executable"' in str(e)
    else:
        assert False, 'Expected ValueError'
    # Test for existing executable in optional directory
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    # Test for existing executable in optional directory with non-existing executable in PATH
    assert get_bin_path('ls', opt_dirs=['/usr/bin'], required=True) == '/usr/bin/ls'
    # Test for non-existing executable

# Generated at 2022-06-16 22:56:26.910824
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/bin']) == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/bin', '/usr/local/bin']) == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/local/bin']) == '/usr/local/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/local/bin', '/usr/bin']) == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/local/bin', '/usr/bin']) == '/usr/bin/python'


# Generated at 2022-06-16 22:56:39.335379
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with a valid executable
    try:
        get_bin_path('ls')
    except ValueError:
        assert False, 'get_bin_path failed to find valid executable'

    # Test with an invalid executable
    try:
        get_bin_path('invalid_executable')
        assert False, 'get_bin_path did not raise ValueError for invalid executable'
    except ValueError:
        pass

    # Test with a valid executable in optional directory
    try:
        get_bin_path('ls', opt_dirs=['/bin'])
    except ValueError:
        assert False, 'get_bin_path failed to find valid executable in optional directory'

    # Test with an invalid executable in optional directory

# Generated at 2022-06-16 22:56:48.986901
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    (fd, path) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Make the file executable
    os.chmod(path, stat.S_IRWXU)

    # Test get_bin_path()
    assert get_bin_path(os.path.basename(path), opt_dirs=[tmpdir]) == path

    # Clean up
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 22:56:56.369154
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin', '/usr/local/bin']) == '/usr/bin/sh'

# Generated at 2022-06-16 22:57:06.466073
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temporary executable
    (fd, tmpexec) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    os.chmod(tmpexec, stat.S_IRWXU)

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)

    # Create a temporary file
    (fd, tmpfile2) = tempfile.mkstemp(dir=tmpdir2)
    os.close(fd)

    # Create a temporary executable

# Generated at 2022-06-16 22:57:47.485146
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/usr/local/bin']) == '/bin/sh'

# Generated at 2022-06-16 22:57:58.402623
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/bin', '/bin']) == '/usr/bin/ls'

# Generated at 2022-06-16 22:58:08.500393
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)

    # Make the file executable
    os.chmod(tmpfile, stat.S_IRWXU)

    # Test get_bin_path with the temporary file
    assert get_bin_path(os.path.basename(tmpfile), opt_dirs=[tmpdir]) == tmpfile

    # Clean up
    os.close(fd)
    os.unlink(tmpfile)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 22:58:16.729130
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin'], required=True) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin'], required=False) == '/usr/bin/ls'

# Generated at 2022-06-16 22:58:28.065442
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/usr/bin', '/bin']) == '/bin/ls'