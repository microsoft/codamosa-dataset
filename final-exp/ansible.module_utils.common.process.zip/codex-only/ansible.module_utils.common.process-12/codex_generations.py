

# Generated at 2022-06-22 21:51:22.343814
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function
    '''
    output = get_bin_path('sh')
    assert output == 'sh'

    output = get_bin_path('sh', ['/etc'])
    assert output == 'sh'

    try:
        output = get_bin_path('sh', ['/etc'], True)
    except ValueError:
        assert False, 'This should have passed, but it did not'
    else:
        assert True

    try:
        output = get_bin_path('shhhhhhhh')
    except ValueError as e:
        assert "Failed to find" in str(e)
    else:
        assert False, 'This should have failed, but it did not'


# Generated at 2022-06-22 21:51:25.969072
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    try:
        os.environ['PATH'] = '/bin:/usr/bin'
        mybinpath = get_bin_path('sh')
        assert mybinpath == '/bin/sh' or to_bytes(mybinpath) == b'/bin/sh'
        assert mybinpath != '/bin/tsh'
    except Exception as e:
        assert False, e

# Generated at 2022-06-22 21:51:33.463785
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test #1: pass valid optional argument
    bin_path = '/usr/bin/'
    expected_path = '/usr/bin/ls'
    assert get_bin_path('ls', [bin_path]) == expected_path

    # Test #2: pass invalid optional argument
    try:
        bin_path = '/fake/bin'
        get_bin_path('ls', [bin_path])
    except ValueError as e:
        assert e.args[0] == 'Failed to find required executable "ls" in paths: /fake/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games'

    # Test #3: pass nothing

# Generated at 2022-06-22 21:51:36.080682
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('which') == '/usr/bin/which'

# Generated at 2022-06-22 21:51:40.651831
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path()
    '''
    from ansible.module_utils.common._text import to_text

    bin_path = get_bin_path('sh')
    assert bin_path == to_text('/bin/sh')

    with pytest.raises(ValueError):
        get_bin_path('this_binary_is_missing')

# Generated at 2022-06-22 21:51:50.112069
# Unit test for function get_bin_path
def test_get_bin_path():
    path_orig = os.environ['PATH']

    # Create test path with a few executables
    test_path = '/tmp/test/'
    test_bin_paths = ['/tmp/test/ls', '/tmp/test/ls1', '/tmp/test/ls2', '/tmp/test/cat']
    test_bin_names = ['ls', 'ls1', 'ls2', 'cat']
    os.makedirs(test_path)
    for p in test_bin_paths:
        open(p, 'a').close()
        os.chmod(p, 0o755)

    # Test 1:  Should find an executable in a new path without any directories added to PATH
    os.environ["PATH"] = ""

# Generated at 2022-06-22 21:51:59.843402
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("/bin/false") == "/bin/false"
    assert get_bin_path("false") == "/bin/false"
    assert get_bin_path("false", opt_dirs=["/bin"]) == "/bin/false"
    assert get_bin_path("false", opt_dirs=["/foo"]) == "/bin/false"
    try:
        get_bin_path("false", opt_dirs=["/foo"], required=True)
        assert False, "should have raised ValueError"
    except ValueError:
        pass
    try:
        get_bin_path("false", opt_dirs=["/foo"], required=False)
        assert False, "should have raised ValueError"
    except ValueError:
        pass

# Generated at 2022-06-22 21:52:08.292944
# Unit test for function get_bin_path
def test_get_bin_path():
    # set PATH
    orig_path = os.environ.get('PATH', '')
    os.environ['PATH'] = '/bin:/usr/bin'
    # try valid path
    assert get_bin_path('cat') == '/bin/cat'
    # try invalid path
    try:
        get_bin_path('/usr/bin/nosuchfile')
        assert False, 'get_bin_path did not raise exception on invalid path'
    except ValueError:
        pass
    # try valid path with extra dirs
    assert get_bin_path('cat', opt_dirs=['/usr/bin']) == '/bin/cat'
    # try valid path with extra dirs (second dir)

# Generated at 2022-06-22 21:52:19.130884
# Unit test for function get_bin_path
def test_get_bin_path():
    import platform

    # test where executable is found
    try:
        path = get_bin_path('python')
    except ValueError:
        assert False, 'unit test for get_bin_path failed'

    # test where executable is not found

# Generated at 2022-06-22 21:52:28.634583
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test os.environ['PATH'] is not set if the following works
    del os.environ['PATH']
    orig_path = os.environ.get('PATH', None)
    paths = ['/bin', '/sbin']

# Generated at 2022-06-22 21:52:31.654987
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-22 21:52:39.981878
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    validate function get_bin_path
    '''
    # get_bin_path should find system commands.
    command_path = None
    # full path for test case
    full_path = "/usr/bin/ls"
    if os.path.exists(full_path):
        command_path = get_bin_path("ls", opt_dirs=['/usr/bin', '/bin'])
    assert command_path == full_path

    # Verify error handling when command is not found in PATH
    import pytest
    with pytest.raises(ValueError):
        get_bin_path("not_a_command")

# Generated at 2022-06-22 21:52:50.134357
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.six import PY3
    if PY3:
        import unittest
        import unittest.mock as mock

        class TestGetBinPath(unittest.TestCase):

            def setUp(self):
                self.old_env_path = os.environ['PATH']
                os.environ['PATH'] = '/bin'
                self.test_dir = '/tmp'
                self.file_mgr_mock = mock.Mock()
                self.file_mgr_mock.exists.return_value = True
                self.file_mgr_mock.isdir.return_value = False
                self.file_mgr_mock.isfile.return_value = True
                self.file_mgr_mock.is_executable.return_

# Generated at 2022-06-22 21:52:54.283436
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.utils.path import unfrackpath

    with unfrackpath():
        assert get_bin_path('ls') == '/bin/ls'
        try:
            get_bin_path('does-not-exist')
            assert False
        except ValueError:
            pass

# Generated at 2022-06-22 21:52:58.138033
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    get_bin_path is a simple wrapper around os.path, we just want to verify
    that it doesn't explode. This should not be in the main dotkit, it should
    be in a "tests" dotkit.
    '''
    assert get_bin_path('ssh') == '/usr/bin/ssh'

# Generated at 2022-06-22 21:53:10.016040
# Unit test for function get_bin_path
def test_get_bin_path():
    # negative test
    try:
        get_bin_path('invalid-path')
    except ValueError as e:
        assert e.message == 'Failed to find required executable "invalid-path" in paths: /sbin:/usr/sbin:/usr/local/sbin:/bin:/usr/bin:/usr/local/bin'
    else:
        assert False, "Expected ValueError not raised"

    # negative test

# Generated at 2022-06-22 21:53:21.152481
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Return path to system binaries'''

    # Setup:
    # We need to provide a path so the function knows where to look for the executable.
    # Since the OS's PATH environment variable change depending on
    # which OS the test is running on, we will not use the PATH environment variable.
    test_dir = [os.path.dirname(os.path.realpath(__file__))]
    test_name = "get_bin_path.py"

    # Execute:
    # Use a file in the same dir as this script as the executable to test with.
    test_file_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), test_name)

    # Assert:
    # The return value should be the full path of our test_file
    # Not using the

# Generated at 2022-06-22 21:53:30.493747
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    def create_executable(filename):
        open(filename, 'w').close()
        os.chmod(filename, 0o755)

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-22 21:53:32.834111
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('true') == '/bin/true'

# Generated at 2022-06-22 21:53:47.245220
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import shutil
    import tempfile
    import filecmp

    # Define temporary directory
    tmpdir = tempfile.mkdtemp()
    os.environ['PATH'] = tmpdir

    # Create and copy our test script get_bin_path.sh
    testscript = os.path.join(tmpdir, "get_bin_path.sh")
    shutil.copyfile("test/units/module_utils/common/get_bin_path.sh", testscript)
    os.chmod(testscript, 0o755)

    rc, stdout, stderr = get_bin_path("get_bin_path.sh", None, None)
    # Compare output of get_bin_path.sh
    testdata = "test/units/module_utils/common/get_bin_path.stdout"


# Generated at 2022-06-22 21:53:56.953499
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import tempfile

# Generated at 2022-06-22 21:54:00.224153
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('bash') is not None
    assert get_bin_path('/usr/bin/bash') is not None
    assert get_bin_path('no_such_cmd') is None
    assert get_bin_path('no_such_cmd', required=False) is None

# Generated at 2022-06-22 21:54:08.579332
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    if sys.version_info < (2, 5):
        print("SKIP: get_bin_path() is not available on Python < 2.5")
        return

    assert get_bin_path("sh") == "/bin/sh"
    try:
        get_bin_path("qwerty")
    except ValueError as e:
        assert str(e) == "Failed to find required executable \"qwerty\" in paths: /usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games:/sbin:/usr/sbin:/usr/local/sbin"

# Generated at 2022-06-22 21:54:11.655760
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('fake')



# Generated at 2022-06-22 21:54:20.759558
# Unit test for function get_bin_path
def test_get_bin_path():
    dir_path = os.path.dirname(__file__)
    stat_path = os.path.join(dir_path, 'stat')

# Generated at 2022-06-22 21:54:31.743029
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path("I_DO_NOT_EXIST")
        assert False, "Exception is expected"
    except ValueError as e:
        assert 'Failed to find required executable "I_DO_NOT_EXIST"' in str(e), "Unexpected exception %s" % str(e)

    assert get_bin_path("/bin/sh") == "/bin/sh"
    assert get_bin_path(os.path.basename("/bin/sh".replace("/bin/", "bin/"))) == "/bin/sh"
    assert get_bin_path("/usr/bin/python") == "/usr/bin/python"
    assert get_bin_path("python") == "/usr/bin/python"

# Generated at 2022-06-22 21:54:39.941658
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('ansible-playbook')
    assert bin_path.endswith('ansible-playbook')

    try:
        get_bin_path('pipeline')
        assert False, 'exception not thrown'
    except ValueError as e:
        assert 'Failed to find' in str(e)


# -*- -*- -*- End included fragment: ../../lib_utils/src/lib/ansible/module_utils/basic.py -*- -*- -*-

# -*- -*- -*- Begin included fragment: class/ansible/module_utils/facts/system/distribution.py -*- -*- -*-

# -*- coding: utf-8 -*-
#
# (c) 2017 Red Hat, Inc.

# Generated at 2022-06-22 21:54:42.349081
# Unit test for function get_bin_path
def test_get_bin_path():
    # Success case
    assert get_bin_path('python') == '/usr/bin/python'
    # Failure case
    try:
        get_bin_path('no_such_executable_foo')
    except:
        return
    assert False, 'No exception raised'

# Generated at 2022-06-22 21:54:47.868430
# Unit test for function get_bin_path
def test_get_bin_path():
    path_to_exes = [
        "/bin/foo",
        "/usr/bin/foo",
        "/sbin/foo",
        "/usr/sbin/foo",
        "/usr/local/bin/foo",
        "/usr/local/sbin/foo",
        "/opt/bin/foo",
        "foo",
    ]

    for exe_path in path_to_exes:
        assert exe_path == get_bin_path(os.path.basename(exe_path))

# Generated at 2022-06-22 21:54:49.631809
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('cat')
    assert bin_path == '/bin/cat'

# Generated at 2022-06-22 21:55:00.171017
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1: Look for file ssh in diretory /usr/bin
    try:
        path = get_bin_path('ssh', ['/usr/bin'])
    except ValueError as e:
        raise AssertionError('Test1 Failed: ' + str(e))
    assert path == '/usr/bin/ssh', 'Test 1 Failed: Path not /usr/bin/ssh but %s' % path

    # Test 2: Look for file ssh in diretory /bin, it should raise an exception

# Generated at 2022-06-22 21:55:12.720718
# Unit test for function get_bin_path
def test_get_bin_path():
    # since these tests are invoked from source tree,
    # there won't be any executables in bin directories
    # unless they are there explicitly
    # so we create test executables in /tmp

    # "ls"
    # no paths, required
    os.system('/bin/ls -al /tmp/ > /tmp/ls');
    bin_path = get_bin_path('ls')
    assert bin_path == '/bin/ls'

    # "ls"
    # no paths, not required
    bin_path = get_bin_path('ls', required=False)
    assert bin_path == '/bin/ls'

    # "/bin/ls"
    # no paths, required
    os.system('/bin/ls -al /tmp/ > /tmp/ls');

# Generated at 2022-06-22 21:55:13.836336
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('curl') is not None

# Generated at 2022-06-22 21:55:25.962120
# Unit test for function get_bin_path
def test_get_bin_path():
    # Verify get_bin_path returns string
    assert isinstance(get_bin_path("ls"), str)
    # Verify that get_bin_path raises exception when executable is not found
    import pytest  # python2.7 doesn't support with pytest.raises(...):
    try:
        get_bin_path("this_is_a_bad_executable_name")
        assert False
    except ValueError:
        assert True
    # Verify that get_bin_path raises exception when executable is a directory
    try:
        get_bin_path("acct")
        assert False
    except ValueError:
        assert True
    # Verify that get_bin_path raises exception when executable is not executable
    testfile = "/tmp/test_file_for_unit_test_ansible_common_file_get_bin_path"

# Generated at 2022-06-22 21:55:29.953328
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    This test method uses stub methods to simulate:

    - os.environ.get('PATH', '').split(os.pathsep)
    - os.path.exists("file_path")
    - os.path.isdir("file_path")
    - os.path.join("dir_path", "file_path")
    - is_executable("file_path")
    '''
    class FakeOs(object):
        def __init__(self):
            self.path_exists_stubs = {}
            self.path_isdir_stubs = {}
            self.path_join_stubs = {}
            self.path_exists_calls = []
            self.path_isdir_calls = []
            self.path_join_calls = []

# Generated at 2022-06-22 21:55:31.336310
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common._collections_compat import Sequence

# Generated at 2022-06-22 21:55:39.213312
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for a required missing executable
    try:
        bin_path = get_bin_path('no-such-executable', required=True)
    except Exception:
        # We still got an exception, so the test passes
        assert True
    else:
        assert False, 'test_get_bin_path(): Unexpected success'

    # Test for an optional missing executable
    try:
        bin_path = get_bin_path('no-such-executable', required=False)
    except Exception:
        assert False, 'test_get_bin_path(): Unexpected exception'
    else:
        # The function returned None, so the test passes
        assert bin_path is None

    # Test for an executable that exists in the PATH

# Generated at 2022-06-22 21:55:42.585303
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path(arg='ls')
    assert path == '/bin/ls' or path == '/usr/bin/ls'
    path = get_bin_path(arg='lssss')
    assert path == ''

# Generated at 2022-06-22 21:55:51.757932
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) is not None
    try:
        get_bin_path('no_such_binary', ['no_such_dir'])
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) is not None
    # test with sbin directories already in PATH, no exception
    assert get_bin_path('facter', opt_dirs=['/usr/bin']) is not None

# Generated at 2022-06-22 21:56:01.179585
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ['PATH'] = '/bin:/usr/bin:/usr/local/bin'

    # Test all existing files in PATH, expect location to be returned
    for path in os.environ['PATH'].split(os.pathsep):
        for file in os.listdir(path):
            try:
                assert get_bin_path(file, opt_dirs=None, required=None) == os.path.join(path, file)
            except (ValueError, AssertionError):
                if os.path.islink(file):
                    print('Unittest skipped file "%s" because it is a symbolic link' % file)
                else:
                    raise ValueError('Unittest failed to find required executable "%s" in paths: %s' % (file, os.environ['PATH']))

    # Test non-existing

# Generated at 2022-06-22 21:56:13.173638
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check for invalid input
    invalid_executables = [
        "", " ", "cmd1 cmd2", "::", "../bin/file",
        "/invalid/path/file", "/sbin/file with spaces", "shell\n"]
    for exe in invalid_executables:
        try:
            get_bin_path(exe)
            assert False, "Expected ValueError for: %s" % exe
        except ValueError:
            pass

    # Check if existing file under /sbin is found
    bin_path = get_bin_path('true')
    assert bin_path == '/bin/true' or bin_path == '/usr/bin/true'

    # Check if non-existing file under /sbin is not found

# Generated at 2022-06-22 21:56:23.827082
# Unit test for function get_bin_path
def test_get_bin_path():
    # test /bin/sh
    sh = get_bin_path('sh')
    assert sh == '/bin/sh'

    # test with opt_dirs
    cat = get_bin_path('cat', opt_dirs=['/bin', '/usr/bin'])
    assert cat == '/bin/cat'

    # test opt_dirs is None
    sbin_paths = ['/sbin', '/usr/sbin', '/usr/local/sbin']
    for sbin in sbin_paths:
        if os.path.exists(sbin) and is_executable(sbin):
            brctl = get_bin_path('brctl')
            assert brctl == os.path.join(sbin, 'brctl')

    # test that passing a non-existent directory in opt_dirs raises an error


# Generated at 2022-06-22 21:56:28.226911
# Unit test for function get_bin_path
def test_get_bin_path():
    mypath = os.getenv('PATH')
    os.environ['PATH'] = '/bin'
    assert get_bin_path('python') == '/bin/python'
    os.environ['PATH'] = mypath
    assert get_bin_path('python') != '/bin/python'



# Generated at 2022-06-22 21:56:39.907367
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    # invalid path
    try:
        assert get_bin_path('invalid_path')
    except ValueError:
        assert True
    # invalid path - with optional search path
    try:
        assert get_bin_path('invalid_path', opt_dirs=['/usr/bin'])
    except ValueError:
        assert True
    # invalid path - with optional search path (but in a wrong directory)
    try:
        assert get_bin_path('ls', opt_dirs=['/data/user/path'])
    except ValueError:
        assert True
    # valid path
    assert get_bin_path('ls', opt_dirs=['/data/user/path']) == '/data/user/path/ls'

# Generated at 2022-06-22 21:56:51.760730
# Unit test for function get_bin_path
def test_get_bin_path():
    required = None
    opt_dirs = None
    arg = 'ls'
    # Test 1: should return /bin/ls
    assert get_bin_path(arg, required, opt_dirs) == '/bin/ls'
    # Test 2: should return /bin/ls
    opt_dirs = ['/opt/bin']
    assert get_bin_path(arg, opt_dirs) == '/bin/ls'
    # Test 3: should return /opt/bin/ls
    opt_dirs = ['/opt/bin', '/opt/bin/linux']
    assert get_bin_path(arg, opt_dirs) == '/opt/bin/ls'
    # Test 4: should return '/bin/ls'
    arg = 'ls'

# Generated at 2022-06-22 21:57:01.737565
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    import pytest


# Generated at 2022-06-22 21:57:10.103521
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Test a command that is expected to be in the PATH
    # This should return the full path of the command.
    test_cmd = 'apt-get'
    expected_cmd = get_bin_path(test_cmd)
    test_cmd_path = basic._find_executable(to_bytes(test_cmd))
    if test_cmd_path is None:
        raise Exception('Failed to find required executable "%s" in paths: %s' % (test_cmd, os.pathsep.join(os.environ.get('PATH', ''))))

# Generated at 2022-06-22 21:57:14.238919
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert get_bin_path('echo') == '/bin/echo'
        assert get_bin_path('doesnotexist') == None
    except ValueError:
        pass
    try:
        get_bin_path('doesnotexist', required=True)
    except:
        pass

# Generated at 2022-06-22 21:57:26.228397
# Unit test for function get_bin_path
def test_get_bin_path():
    # known and unknown program names
    programs = ['ls', '_this_prog_does_not_exist_']

    # get os.environ
    env = dict(os.environ)

    # mangle PATH to include /sbin dirs
    sbin_paths = ['/sbin', '/usr/sbin', '/usr/local/sbin']
    paths = env.get('PATH', '').split(os.pathsep)
    for p in sbin_paths:
        if p not in paths and os.path.exists(p):
            paths.append(p)
    env['PATH'] = os.pathsep.join(paths)

    # test known and unknown programs

# Generated at 2022-06-22 21:57:31.783086
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        check_output = get_bin_path("check_output.is_a_file")
        assert False, "Should have thrown exception"
    except ValueError as e:
        assert "Failed to find required executable" in str(e), "Should have thrown ValueError"

# Generated at 2022-06-22 21:57:43.664827
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/bin/ls' == get_bin_path('ls')
    assert '/bin/cp' == get_bin_path('cp')
    assert '/bin/chmod' == get_bin_path('chmod')
    assert '/bin/echo' == get_bin_path('echo')
    assert '/bin/egrep' == get_bin_path('egrep')
    assert '/bin/fgrep' == get_bin_path('fgrep')
    assert '/bin/grep' == get_bin_path('grep')
    assert '/bin/mkdir' == get_bin_path('mkdir')
    assert '/bin/mv' == get_bin_path('mv')
    assert '/bin/rm' == get_bin_path('rm')

# Generated at 2022-06-22 21:57:51.068239
# Unit test for function get_bin_path
def test_get_bin_path():
    cur_path = os.path.dirname(os.path.abspath(__file__))
    test_echo = os.path.join(cur_path, "test_echo.sh")
    os.chmod(test_echo, 0o755)
    try:
        echo_path = get_bin_path("test_echo.sh", [cur_path])
        assert echo_path == test_echo
    finally:
        os.chmod(test_echo, 0o644)

# Generated at 2022-06-22 21:58:02.187888
# Unit test for function get_bin_path

# Generated at 2022-06-22 21:58:09.142946
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh')
    assert get_bin_path('SH', ['/home'])  # case insensitive
    assert get_bin_path('SH', ['/home'])  # case insensitive
    assert get_bin_path('SH', ['/home'])  # case insensitive
    try:
        get_bin_path('unknown_cmd')
        assert False
    except ValueError as e:
        assert 'Failed to find' in str(e)

# Generated at 2022-06-22 21:58:20.205983
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile

    # Create a test directory to work with
    d = tempfile.mkdtemp()
    cwd = os.getcwd()
    os.chdir(tempfile.mkdtemp())

    # Create a test file:
    test_file1 = os.path.join(d, 'test_file1')
    open(test_file1, 'w').close()

    # Create an executable test file:
    test_file2 = os.path.join(d, 'test_file2')
    open(test_file2, 'w').close()
    os.chmod(test_file2, 0o755)

    # Create a directory:
    test_dir = os.path.join(d, 'test_dir')
    os.mkdir(test_dir)

    # Create

# Generated at 2022-06-22 21:58:28.561778
# Unit test for function get_bin_path
def test_get_bin_path():
    import ansible.module_utils.common.file

    old_find_executable = ansible.module_utils.common.file.get_bin_path
    def mock_find_executable(arg, *args, **kwargs):
        if arg == 'foo':
            raise ValueError('Foo is not found')

        if arg == 'version':
            return '/usr/bin/version'

    ansible.module_utils.common.file.get_bin_path = mock_find_executable
    try:
        assert get_bin_path('version') == '/usr/bin/version'

        try:
            get_bin_path('foo')
            assert False, 'Should have raised exception'
        except ValueError:
            assert True

    finally:
        ansible.module_utils.common.file.get_bin_path

# Generated at 2022-06-22 21:58:38.018322
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import tempfile
    bin_path = get_bin_path(os.path.basename(__file__))
    assert bin_path == os.path.realpath(__file__)
    fd, path = tempfile.mkstemp(prefix='ansible_test_file_')
    try:
        os.write(fd, b"#!/bin/sh\nexit 0")
        os.close(fd)
        os.chmod(path, 0o755)
        bin_path = get_bin_path(os.path.basename(path))
        assert bin_path == path
    finally:
        os.remove(path)

# Generated at 2022-06-22 21:58:48.358534
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Test cases:
        1. Executable exists in PATH,
        2. Executable exists in one of optional dirs,
        3. Executable exists in PATH and in one of optional dirs,
        4. Executable exists in PATH and in one of optional dirs, but we specify different optional dir,
        5. Executable exists in PATH and in one of optional dirs, but specify optional dir without executable,
        6. Executable does not exist at all
    '''

    # case 1. Executable exists in PATH
    test_path = get_bin_path('cp')
    assert test_path == '/bin/cp'

    # case 2. Executable exists in one of optional dirs
    test_path = get_bin_path('cp', ['/usr/bin'])
    assert test_path == '/usr/bin/cp'

   

# Generated at 2022-06-22 21:58:49.569363
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-22 21:58:58.220660
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('python')
    except ValueError:
        assert False, 'Failed to find system `python` for unit test'
    # here python is found in the system PATH, so no exception should be raised
    assert True, 'Successfully found system `python` for unit test'

    try:
        get_bin_path('thisexecutableisnothere')
    except ValueError:
        assert True, 'Successfully raised exception for an executable that is not in the system PATH'
    else:
        assert False, 'Should not acceept an executable that is not in the system PATH'

    try:
        get_bin_path('thisexecutableisnothere', required=False)
    except ValueError:
        assert True, 'Successfully raised exception for an executable that is not in the system PATH and optional is True'
   

# Generated at 2022-06-22 21:59:06.363258
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test: Find 'ls' and 'non-exist-exe' in the path
    # Expected: Full path to 'ls' and ValueError for 'non-exist-exe'
    try:
        bin_path = get_bin_path('ls')
    except Exception as err:
        print("Test 1: Unexpected exception for 'ls': %s" % err)
        assert False
    try:
        bin_path = get_bin_path('non-exist-exe')
    except ValueError:
        pass
    else:
        print("Test 1: Expected ValueError for 'non-exist-exe'")
        assert False
    # Test: Find 'ls' in the path and include '/usr/local/bin'
    # Expected: Full path to 'ls' in '/usr/local/bin'

# Generated at 2022-06-22 21:59:16.633343
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    get_bin_path return the full path of the executable
    in the PATH.
    If the executable is not found, it raises a ValueError.

    Usage:
    python -c "from ansible.module_utils.common.file import get_bin_path; print get_bin_path('python2.7')"

    '''

    import sys
    import os

    if os.name == 'posix':
        assert get_bin_path('python') == sys.executable
    elif os.name == 'nt':
        import random
        import string
        random_string = ''.join(random.choice(string.ascii_lowercase) for i in range(10))
        assert get_bin_path(random_string)

# Generated at 2022-06-22 21:59:27.380396
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Test module: ansible.module_utils.yaml_utils'''

    # Test 1
    # set PATH to /bin
    os.environ['PATH'] = '/bin'
    # test executable arguments
    test_args = ['vim', 'bash', 'python', 'which', 'ls', 'rm', 'rmdir', 'wget', 'sed', 'grep']
    # test optional non existing directories
    test_dirs = ['/sbin', '/usr/sbin', '/usr/local/sbin', '/opt/bin', '/tmp', '/usr/bin', '/usr/local/bin', '/bin']
    for arg in test_args:
        try:
            bin_path = get_bin_path(arg)
            assert bin_path == '/bin/'+arg
        except AssertionError:
            print

# Generated at 2022-06-22 21:59:37.118074
# Unit test for function get_bin_path
def test_get_bin_path():
    for required in [True, False]:
        for opt_dirs in [[], ['/bin'], ['/bin/']]:
            for arg in ['echo', './echo']:
                try:
                    if os.path.isabs(arg):
                        test_bin_path = get_bin_path(arg=arg, opt_dirs=opt_dirs, required=required)
                        assert test_bin_path == arg
                    else:
                        test_bin_path = get_bin_path('echo', opt_dirs=opt_dirs, required=required)
                        assert test_bin_path not in [None, '']
                        assert test_bin_path == get_bin_path(arg=arg, opt_dirs=opt_dirs, required=required)
                except ValueError:
                    assert not required

# Generated at 2022-06-22 21:59:44.650672
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh', required=False) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/usr/bin/sh'
    try:
        get_bin_path('sh', opt_dirs=['/bin'], required=True)
    except:
        pass

# Generated at 2022-06-22 21:59:55.174599
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test on system that has /sbin in path
    try:
        get_bin_path('ip')
    except Exception as e:
        print(e)
        assert False

    try:
        get_bin_path('__file_that_does_not_exist__', ['/usr/sbin', '/sbin'])
        assert False
    except Exception:
        pass

    try:
        get_bin_path('__file_that_does_not_exist__', ['/usr/sbin', '/bin'])
        assert False
    except Exception:
        pass

    try:
        get_bin_path('__file_that_does_not_exist__', ['/usr/sbin', '/usr/bin'])
        assert False
    except Exception:
        pass

# Generated at 2022-06-22 21:59:57.673954
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.name == 'nt':
        assert get_bin_path('start.exe') is not None
    else:
        assert get_bin_path('ifconfig') is not None

# Generated at 2022-06-22 22:00:04.665268
# Unit test for function get_bin_path
def test_get_bin_path():
    # test the 'required' parameter to be removed in 2.14
    try:
        get_bin_path('nonsense_command', required=True)
        assert False, "expected exception did not occur"
    except ValueError:
        pass
    try:
        get_bin_path('nonsense_command', required=False)
        assert False, "expected exception did not occur"
    except ValueError:
        pass

    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/bin']) == '/usr/bin/python'
    try:
        get_bin_path('nonsense_command')
        assert False, "expected exception did not occur"
    except ValueError:
        pass



# Generated at 2022-06-22 22:00:08.985032
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test required param
    try:
        get_bin_path('expected_not_to_find_this')
        assert False, "Should have raised ValueError"
    except ValueError:
        pass

    # Test deprecated param
    try:
        get_bin_path('expected_not_to_find_this', required=True)
        assert False, "Should have raised ValueError"
    except ValueError:
        pass

    # Test function returns path
    path = get_bin_path('python')
    assert path and os.path.exists(path) and not os.path.isdir(path) and is_executable(path)

# Generated at 2022-06-22 22:00:12.165229
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('mkfs.ext4')
    assert path == '/sbin/mkfs.ext4'

# Generated at 2022-06-22 22:00:23.882720
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile


# Generated at 2022-06-22 22:00:32.573802
# Unit test for function get_bin_path
def test_get_bin_path():

    # We use the path to the python interpreter to test get_bin_path.

    # This test should not fail
    try:
        get_bin_path(os.path.basename(sys.executable))
    except Exception as e:
        assert False, 'Unexpected exception: %s' % str(e)

    # This test should fail
    try:
        get_bin_path('does-not-exist')
    except Exception as e:
        assert True
    else:
        assert False, 'Expected exception, but did not get one'

if __name__ == '__main__':
    import sys
    test_get_bin_path()

# Generated at 2022-06-22 22:00:39.507128
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path("find")
    except ValueError as e:
        assert False, "Failed to find executable. Error " + str(e)

    try:
        get_bin_path("this_does_not_exist")
        assert False, "Expected ValueError for non-existing executable"
    except ValueError as e:
        assert True

# Generated at 2022-06-22 22:00:43.618718
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python2.7', ['tests/unit/modules/utils']) == 'tests/unit/modules/utils/python2.7'
    assert get_bin_path('python2.7') == '/usr/bin/python2.7'

# Generated at 2022-06-22 22:00:52.399423
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('cat', ['/bin', '/sbin']) == '/bin/cat'
    assert get_bin_path('cat', ['/sbin']) == '/bin/cat'

    # Executable found in opt_dirs
    assert get_bin_path('cat', ['/sbin']) == '/bin/cat'

    try:
        get_bin_path('cmd_not_found')
    except ValueError:
        pass
    else:
        assert False, 'get_bin_path() did not fail when on cmd_not_found'

# Generated at 2022-06-22 22:00:54.844143
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible', required=True) == get_bin_path('ansible', True)

# Generated at 2022-06-22 22:01:04.587602
# Unit test for function get_bin_path
def test_get_bin_path():
    def test(arg, opt_dirs, expected):
        actual = get_bin_path(arg, opt_dirs=opt_dirs)
        assert actual == expected, 'Expected: %s, Actual: %s' % (expected, actual)

    test('/bin/ls', [], '/bin/ls')
    test('ls', [], '/bin/ls')
    test('ls', ['/usr/local/bin'], '/usr/local/bin/ls')
    test('ls', ['/bin'], '/bin/ls')
    test('ls', ['/usr/bin'], '/usr/bin/ls')
    test('ls', ['/usr/local/bin', '/bin'], '/usr/local/bin/ls')

# Generated at 2022-06-22 22:01:11.879294
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    basic._ANSIBLE_ARGS = None
    args = [
        '/usr/bin',
        '/bin',
        '/usr/sbin',
        '/sbin',
        '/usr/local/bin',
        '/usr/local/sbin']

    for executable in ['echo', 'ls', 'awk']:
        module = AnsibleModule(
            argument_spec={
                'executable': dict(required=True),
                'paths': dict(type='list', elements='path', default=args),
                'required': dict(type='bool', default=True)
            }
        )

        module.params['executable'] = executable