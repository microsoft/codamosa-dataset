

# Generated at 2022-06-22 21:51:24.401643
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path(arg='some_bogus_executable_name')
        assert 0, 'get_bin_path did not find "some_bogus_executable_name" in PATH'
    except ValueError:
        pass
    # If the following test fails, you need to install the GNU version of date:
    #
    #     On Debian/Ubuntu: sudo apt-get install coreutils
    #     On RedHat/CentOS: yum install coreutils
    #
    # Otherwise GNU date will be in /usr/local/bin, which is probably not in
    # your PATH.
    assert (get_bin_path(arg='date', opt_dirs=[]) == '/bin/date')

# Generated at 2022-06-22 21:51:28.934198
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.facts.system.distribution import DistributionFactory

    try:
        get_bin_path(DistributionFactory()._detect_sys_init())
    except ValueError:
        # If we get exception it means that system init system is not found which is normal
        pass

# Generated at 2022-06-22 21:51:37.956715
# Unit test for function get_bin_path
def test_get_bin_path():
    tempdir = 'test/unittests/utils/ansible_test_get_bin_path'

# Generated at 2022-06-22 21:51:46.177076
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('')
    os.chmod(test_file, 0o777)

    bin_path = get_bin_path('test_file', [test_dir])
    shutil.rmtree(test_dir)

    # If the bin_path is not set to the expected value, an exception will be raised by the assert.
    assert bin_path == test_file, 'get_bin_path() did not return the expected value: %s != %s' % (bin_path, test_file)

# Generated at 2022-06-22 21:51:51.007026
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test for function get_bin_path.
    '''

    # Test for a known valid path.
    try:
        get_bin_path('cat')
    except ValueError:
        assert False

    # Test for an invalid path.
    try:
        get_bin_path('cat01234567')
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-22 21:51:55.287400
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        os.stat('/bin/false')
        assert get_bin_path('false', opt_dirs=['/bin']) == '/bin/false'
    except:
        # This test depends on the existence of /bin/false, which is not guaranteed on all systems.
        pass

# Generated at 2022-06-22 21:52:02.011927
# Unit test for function get_bin_path
def test_get_bin_path():
    import platform

    if platform.system() == 'OpenBSD':
        assert get_bin_path('openssl') == '/usr/bin/openssl'
        assert get_bin_path('su') == '/usr/bin/su'
        assert get_bin_path('syslogd') == '/sbin/syslogd'
        assert get_bin_path('/usr/bin/top') == '/usr/bin/top'
        assert get_bin_path('/usr/local/bin/python3') == '/usr/local/bin/python3'
        assert get_bin_path('/foo/bar/baz/echo') == '/foo/bar/baz/echo'

# Generated at 2022-06-22 21:52:07.724994
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes

    # On some OS, ls is not executable by default
    ls_path = get_bin_path(to_bytes("ls"))

    assert os.path.exists(ls_path)
    assert os.path.isfile(ls_path) and not os.path.isdir(ls_path)
    assert is_executable(ls_path)
    assert ls_path in os.path.join('/', 'bin', 'ls') or ls_path in os.path.join('/', 'usr', 'bin', 'ls')

# Generated at 2022-06-22 21:52:16.021490
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # should work
        p = get_bin_path('sh')

    except Exception as err:
        assert False, "should not get exception: %s" % err

    try:
        # should throw exception - required arg is deprecated
        p = get_bin_path('does_not_exist', required=True)
        assert False, "should get exception"
    except Exception as err:
        pass

    try:
        # should throw exception
        p = get_bin_path('does_not_exist')
        assert False, "should get exception"
    except Exception as err:
        pass

# Generated at 2022-06-22 21:52:22.934102
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test the get_bin_path function.

    :return: ``True`` if all tests are successful, ``False`` otherwise
    '''
    assert get_bin_path('ls') == '/bin/ls'

    import shutil
    import tempfile

    fake_exe = os.path.join(tempfile.gettempdir(), 'fake_exe')
    shutil.copy(os.path.join(os.path.dirname(__file__), 'utils.py'), fake_exe)
    assert get_bin_path(fake_exe) == fake_exe
    os.remove(fake_exe)

    return True

# Generated at 2022-06-22 21:52:30.577706
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    This function is used to check the get_bin_path function
    '''
    expected = '/bin/ls'
    result = get_bin_path('ls')
    assert result == expected, 'get_bin_path should return %s' % expected

    expected = '/bin/ls'
    result = get_bin_path('ls', None, None)
    assert result == expected, 'get_bin_path should return %s' % expected

    expected = '/bin/ls'
    result = get_bin_path('ls', ['/bin'], None)
    assert result == expected, 'get_bin_path should return %s' % expected


# Generated at 2022-06-22 21:52:35.996609
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('env')

    def test_invalid():
        get_bin_path('invalid_executable')

    import pytest
    # get_bin_path() raises ValueError, an unchecked exception
    pytest.raises(ValueError, test_invalid)


# Generated at 2022-06-22 21:52:44.447767
# Unit test for function get_bin_path
def test_get_bin_path():
    import os

    # Test required = None, opt_dirs = None
    os.environ['PATH'] = '/bin:/usr/bin:/usr/local/bin'
    assert get_bin_path('cp') == '/bin/cp'
    try:
        get_bin_path('_doesnotexist')
    except ValueError:
        # ValueError is raised
        pass
    else:
        # ValueError is not raised
        assert 0

    # Test required = True, opt_dirs = None
    try:
        get_bin_path('_doesnotexist', required=True)
    except ValueError:
        # ValueError is raised
        pass
    else:
        # ValueError is not raised
        assert 0

    # Test required = False, opt_dirs = None
    os.environ['PATH'] = ''


# Generated at 2022-06-22 21:52:55.910824
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('fsck') == '/sbin/fsck'
    assert get_bin_path('ls', ['/bin']) == '/bin/ls'
    assert get_bin_path('cat', opt_dirs=['/bin', '/usr/bin']) == '/bin/cat'
    try:
        get_bin_path('does_not_exist')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    try:
        get_bin_path('does_not_exist_either', ['/bin', '/usr/bin'])
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

# Generated at 2022-06-22 21:53:01.730747
# Unit test for function get_bin_path
def test_get_bin_path():
    # test success means no exception
    get_bin_path("python")
    get_bin_path("python", ["/usr/bin"])
    # test failure means exception is raised
    try:
        get_bin_path("bogus")
        assert False
    except ValueError:
        pass
    try:
        get_bin_path("bogus", ["/usr/bin"])
        assert False
    except ValueError:
        pass

# Generated at 2022-06-22 21:53:03.241802
# Unit test for function get_bin_path
def test_get_bin_path():
    p = get_bin_path('ls')
    assert p == '/bin/ls'

# Generated at 2022-06-22 21:53:15.069968
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    import shutil
    import subprocess

    # create a directory for our 'executables'
    tmpdir = tempfile.mkdtemp()
    is_posix = 'posix' in sys.builtin_module_names


# Generated at 2022-06-22 21:53:18.366166
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    # Get the path to the current python
    py_path = get_bin_path(sys.executable)
    # Test we can get it back
    assert py_path == sys.executable

# Generated at 2022-06-22 21:53:26.591462
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('yum')
    if not os.path.exists(bin_path):
        raise AssertionError("Expected %s to exist" % bin_path)
    bin_path = get_bin_path('yum', ['/sbin'])
    if not os.path.exists(bin_path):
        raise AssertionError("Expected %s to exist" % bin_path)
    try:
        get_bin_path('bigfootisreal')
    except ValueError as e:
        if 'Failed to find required executable' not in str(e):
            raise AssertionError("Expected ValueError exception that contains 'Failed to find required executable'")

# Generated at 2022-06-22 21:53:37.524453
# Unit test for function get_bin_path
def test_get_bin_path():
    # Use a known binary in the default path -- Df on Linux and Windows
    if os.name == "nt":
        known_bin = 'df.exe'
    else:
        known_bin = 'df'

    # The current PATH
    original_path_list = os.environ["PATH"].split(os.pathsep)

    # Make a fake binary
    module_dir = os.path.dirname(__file__) or '.'
    unit_test_dir = os.path.join(module_dir, 'unit/utils/')
    fake_bin = os.path.join(unit_test_dir, "fake")
    with open(fake_bin, 'w') as f:
        f.write('#!/bin/sh\n')
        f.write('echo $0')

# Generated at 2022-06-22 21:53:49.494821
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # Test that it correctly finds a command in the system path.
    ret = get_bin_path('sh')
    assert ret.endswith('/sh')
    assert os.path.exists(ret)

    # Test that it correctly finds a command in a custom path.
    tmp = tempfile.mkdtemp()
    open(os.path.join(tmp, 'custom'), 'a').close()
    ret = get_bin_path('custom', opt_dirs=[tmp])
    assert ret.endswith('/custom')
    assert os.path.exists(ret)

    # Test that it fails to find a non-existent command.
    failed = False
    try:
        get_bin_path('nothing')
    except ValueError:
        failed = True
    assert failed

    # Test that it

# Generated at 2022-06-22 21:54:00.500537
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path()
    '''
    import tempfile
    import shutil
    import stat

    test_file_path = None
    test_dir_path = None


# Generated at 2022-06-22 21:54:05.217852
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.utils.path import get_bin_path
    try:
        get_bin_path('foo')
        assert False, "We should have gotten an exception"
    except ValueError as e:
        pass


# Generated at 2022-06-22 21:54:13.106847
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # Get path for the 'true' executable
        true_path = get_bin_path('true')
        # Check that it exists
        assert os.path.exists(true_path)
        # Check that it is executable
        assert os.access(true_path, os.X_OK)
    except ValueError:
        print('Failed to find true executable')
        assert False

# Generated at 2022-06-22 21:54:21.479605
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('date') == '/bin/date'
    assert get_bin_path('/bin/date') == '/bin/date'
    assert get_bin_path('/bin/bash') == '/bin/bash'
    assert get_bin_path('/usr/bin/ping') == '/usr/bin/ping'
    assert get_bin_path('/usr/sbin/lsof') == '/usr/sbin/lsof'
    assert get_bin_path('/sbin/ip') == '/sbin/ip'
    assert get_bin_path('/sbin/route') == '/sbin/route'

# Generated at 2022-06-22 21:54:32.395303
# Unit test for function get_bin_path
def test_get_bin_path():
    # On some systems, PATH does not include /sbin, which is required for this test to work
    os.environ['PATH'] = '/sbin:' + os.environ['PATH']
    test_paths = ['/sbin', '/usr/sbin', '/usr/local/sbin']
    for path in test_paths:
        get_bin_path('true', [path])
    # Get additional path from simulated environment
    test_path = os.environ['PATH']
    get_bin_path('true', [test_path])
    # Make sure required=False works
    get_bin_path('pymysqldb', [], False)
    try:
        get_bin_path('pymysqldb')
    except ValueError:
        pass

    # Make sure we get an exception if required=True

# Generated at 2022-06-22 21:54:40.418230
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/sbin', '/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/sbin', '/usr/sbin', '/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/sbin', '/usr/sbin', '/usr/local/sbin', '/bin', '/usr/bin']) == '/bin/ls'

# Generated at 2022-06-22 21:54:50.865607
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import signal

    # Test that it finds required command and returns a valid path
    temp_dir = tempfile.mkdtemp()
    try:
        get_ping_path = get_bin_path("ping", opt_dirs=[temp_dir])  # Required should be True by default
        assert os.path.exists(get_ping_path) and os.path.isfile(get_ping_path) and os.access(get_ping_path, os.X_OK)
    finally:
        shutil.rmtree(temp_dir)

    # Test that it raises an error if command not found

# Generated at 2022-06-22 21:55:01.865272
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Run unit test for get_bin_path
    '''
    paths = ['/tmp', '/usr/sbin']
    assert get_bin_path('pwd', opt_dirs=paths) == '/bin/pwd'
    assert get_bin_path('pwd', opt_dirs=[]) == '/bin/pwd'
    assert get_bin_path('pwd', opt_dirs=[None]) == '/bin/pwd'
    assert get_bin_path('pwd', opt_dirs=None) == '/bin/pwd'
    try:
        get_bin_path('notexists', opt_dirs=paths)
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-22 21:55:03.771541
# Unit test for function get_bin_path
def test_get_bin_path():
  assert(get_bin_path('cat') == '/bin/cat')
  assert(get_bin_path('cat', ['/usr/bin']) == '/usr/bin/cat')

# Generated at 2022-06-22 21:55:06.832696
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    path = get_bin_path('python')
    assert os.path.exists(path) and os.access(path, os.X_OK)

# Generated at 2022-06-22 21:55:17.426649
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    d = tempfile.mkdtemp()

# Generated at 2022-06-22 21:55:28.199577
# Unit test for function get_bin_path
def test_get_bin_path():

    bin = 'ls'
    bp = get_bin_path(bin)
    print("Binary path for %s is [%s]" % (bin, bp))
    if bp:
        bin_name = os.path.basename(bp)
    else:
        bin_name = '<not found>'
    assert bin_name == bin

    bin = 'nohup'
    bp = get_bin_path(bin)
    print("Binary path for %s is [%s]" % (bin, bp))
    if bp:
        bin_name = os.path.basename(bp)
    else:
        bin_name = '<not found>'
    assert bin_name == bin

    bin = 'nohup'

# Generated at 2022-06-22 21:55:34.440614
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import sys

    test_path = []
    bin_paths = []

# Generated at 2022-06-22 21:55:41.011180
# Unit test for function get_bin_path
def test_get_bin_path():
    # test case
    class GetBinPathTestCase(object):
        def __init__(self, binName, additionalPaths, isExceptionExpected, exceptionMessage):
            self._binName = binName
            self._additionalPaths = additionalPaths
            self._isExceptionExpected = isExceptionExpected
            self._exceptionMessage = exceptionMessage

    # test cases

# Generated at 2022-06-22 21:55:45.369571
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' test_get_bin_path asserts expected behaviors for get_bin_path '''
    assert get_bin_path("/true") == "/true"
    try:
        assert get_bin_path("/missing") == "/missing"
    except ValueError:
        pass

# Generated at 2022-06-22 21:55:56.807331
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic
    import pytest
    from tempfile import NamedTemporaryFile, mkdtemp

    # Create a temporary file containing `#!/bin/sh\nexit 0`
    fp = NamedTemporaryFile(mode='w')
    fp.write('#!/bin/sh\nexit 0')
    fp.flush()

    # Should fail
    with pytest.raises(ValueError):
        get_bin_path('/nonexistent_file_12345')

    # Should fail
    with pytest.raises(ValueError):
        get_bin_path('/tmp')

    # Should return full path
    assert get_bin_path(os.path.basename(fp.name)) == fp.name

    # Should return full path even if file is not executable

# Generated at 2022-06-22 21:56:04.533927
# Unit test for function get_bin_path
def test_get_bin_path():
    for arg in ['cat', 'ls', 'pwd']:
        get_bin_path(arg)

    opt_dirs = ['/bin']
    get_bin_path('cat', opt_dirs)

    try:
        get_bin_path('thisdoesnotexist')
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

    try:
        get_bin_path('thisdoesnotexist', ['/bin'])
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

# Generated at 2022-06-22 21:56:15.432252
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    from ansible.module_utils.common.file import atomic_move

    # Default path
    arg = 'sh'
    path = get_bin_path(arg)
    assert path == "/bin/sh" or path == "/usr/bin/sh"

    # Default path with opt_dirs
    opt_dirs = ['/usr/bin', '/bin', '/sbin']
    path = get_bin_path(arg, opt_dirs)
    assert path == "/bin/sh" or path == "/usr/bin/sh"

    # Specify executable name and path
    arg = 'cat'
    opt_dirs = ['/bin']
    path = get_bin_path(arg, opt_dirs)
    assert path == "/bin/cat"

    # Specify executable name and

# Generated at 2022-06-22 21:56:25.737521
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    # create fake executable
    test_file = tempfile.NamedTemporaryFile()
    test_file.write(str.encode("#!/bin/sh\necho hello"))
    test_file.flush()

    test_bin_path = get_bin_path("cat")
    assert(test_bin_path is not None)
    assert(is_executable(test_bin_path))

    try:
        get_bin_path("this_will_not_exist_for_sure")
    except ValueError:
        pass
    else:
        assert("this_will_not_exist_for_sure should not exist")

    test_bin_path = get_bin_path(test_file.name)
    assert(test_bin_path == test_file.name)

# Generated at 2022-06-22 21:56:36.640290
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = 'ls'
    # Executable should be found
    found_path = get_bin_path(arg)

    # Verify the path returned is executable
    p = os.path.split(found_path)
    assert os.path.isdir(p[0])
    assert is_executable(found_path)

    # Verify that executable not found raises error
    arg = 'xxxx'
    try:
        get_bin_path(arg)
        assert False
    except ValueError:
        assert True

    # Verify that optional directory list is searched before PATH
    arg = 'ls'
    opt_dirs = ['/bin', '/usr/bin']
    found_path = get_bin_path(arg, opt_dirs)
    assert os.path.split(found_path)[0] == '/bin'

# Generated at 2022-06-22 21:56:42.847210
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    sys.path.insert(0, '..')

# Generated at 2022-06-22 21:56:52.480799
# Unit test for function get_bin_path
def test_get_bin_path():
    bin = "ansible"
    with open("/bin/ansible", "w+") as f:
        f.write("#!/bin/bash\necho 'This is %s'" % bin)
    assert get_bin_path(bin) == "/bin/ansible"
    os.remove("/bin/ansible")

    bin = "sudo"
    with open("/usr/bin/sudo", "w+") as f:
        f.write("#!/bin/bash\necho 'This is %s'" % bin)
    assert get_bin_path(bin) == "/usr/bin/sudo"
    os.remove("/usr/bin/sudo")

# Generated at 2022-06-22 21:57:02.253906
# Unit test for function get_bin_path
def test_get_bin_path():
    # Assume Python executable is always present.
    python_path = get_bin_path('python')
    assert python_path.endswith('python')
    assert os.path.exists(python_path)
    assert not os.path.isdir(python_path)
    assert is_executable(python_path)

    # Assume Python executable is always present in opt dirs.
    python_path = get_bin_path('python', ['/opt/bin'])
    assert python_path.endswith('python')
    assert python_path.startswith('/opt/bin')
    assert os.path.exists(python_path)
    assert not os.path.isdir(python_path)
    assert is_executable(python_path)

    # Make sure that a file that is not executable is not found

# Generated at 2022-06-22 21:57:13.685750
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    # os.path.join doesn't use '/' on Windows, but PATH does
    if sys.platform == 'win32':
        path_separator = ';'
    else:
        path_separator = ':'

    # Test with a good executable
    new_path = os.path.dirname(sys.executable)
    orig_environ = dict(PATH=os.environ['PATH'])
    os.environ['PATH'] = path_separator.join((new_path, os.environ['PATH']))
    assert get_bin_path(os.path.basename(sys.executable)) == sys.executable
    os.environ.clear()
    os.environ.update(orig_environ)

    # Test with a missing executable

# Generated at 2022-06-22 21:57:20.088474
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    assert get_bin_path('python') == '/usr/bin/python'

    with pytest.raises(ValueError):
        assert get_bin_path('this_file_does_not_exist')

    with pytest.raises(ValueError):
        assert get_bin_path('python', opt_dirs='/tmp/this_dir_does_not_exist')

# Generated at 2022-06-22 21:57:23.160648
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('cat')
    assert os.path.exists(bin_path)
    assert is_executable(bin_path)

# Generated at 2022-06-22 21:57:26.683540
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('ansible-test')
        assert False, 'get_bin_path() did not raise Exception'
    except ValueError:
        pass
    assert get_bin_path('python')

# Generated at 2022-06-22 21:57:37.322148
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test executable found in PATH
    assert get_bin_path('ls') == '/bin/ls'

    # Test executable found in opt_dirs
    paths = os.environ.get('PATH', '').split(os.pathsep)
    p = [os.path.dirname(__file__)]
    assert get_bin_path('ls', opt_dirs=p) == os.path.join(os.path.dirname(__file__), 'ls')
    assert os.environ.get('PATH', '') == os.pathsep.join(paths)

    # Test executable not found in opt_dirs or PATH

# Generated at 2022-06-22 21:57:45.681255
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('/usr/bin/sh') == '/usr/bin/sh'
    assert get_bin_path('non_existing_binary', opt_dirs=['/usr/bin']) == None
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh') == '/bin/sh' or get_bin_path('sh') == '/usr/bin/sh'
    assert get_bin_path('chage') == '/usr/bin/chage'

# Generated at 2022-06-22 21:57:52.732704
# Unit test for function get_bin_path
def test_get_bin_path():
    testpaths = ['/bin', '/usr/bin', '/usr/local/bin']
    for arg in ('sh', 'true'):
        get_bin_path(arg, testpaths)
    try:
        get_bin_path('invalid-arg', testpaths)
    except ValueError:
        pass
    else:
        raise AssertionError('Failed to raise ValueError')

# Generated at 2022-06-22 21:57:59.080986
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert bin_path == '/bin/sh'
    bin_path = get_bin_path('sh', opt_dirs=['/usr/local/bin'])
    assert bin_path == '/bin/sh'
    bin_path = get_bin_path('sh', opt_dirs=['/usr/local/bin', '/usr/local/sbin'])
    assert bin_path == '/usr/local/sbin/sh'

# Generated at 2022-06-22 21:58:07.539080
# Unit test for function get_bin_path
def test_get_bin_path():

    test_paths = [
        # expected_path, arg, opt_dirs, required
        ('/foo/bar/baz', 'baz', ['/foo/bar'], None),
        ('/bin/bash', 'bash', None, True),
        ('/bin/bash', 'bash', None, None),
        (Exception, 'invalid_path', [], None),
        (Exception, 'invalid_path', [], True),
    ]

    for test_path in test_paths:
        try:
            path = get_bin_path(test_path[1], test_path[2], test_path[3])
            assert(path == test_path[0])
        except test_path[0]:
            pass

# Generated at 2022-06-22 21:58:18.334361
# Unit test for function get_bin_path
def test_get_bin_path():
    import __builtin__
    import tempfile
    import shutil

    class TempException(Exception):
        pass


# Generated at 2022-06-22 21:58:23.446252
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Unit test for function get_bin_path.'''
    from ansible.module_utils.basic import AnsibleModule

    bin_path = get_bin_path('bash')
    module = AnsibleModule(
        argument_spec=dict(),
    )
    module.exit_json(ansible_facts={'ansible_test_get_bin_path': bin_path})

# Generated at 2022-06-22 21:58:27.880698
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('this_executable_is_not_on_your_system', required=True)
        assert False
    except ValueError as e:
        assert isinstance(e, ValueError)

    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-22 21:58:39.230370
# Unit test for function get_bin_path
def test_get_bin_path():

    import shutil
    import tempfile
    import contextlib

    with contextlib.closing(tempfile.NamedTemporaryFile()) as testfile:
        testfile.write(b'#!/bin/sh\necho hello world\n')
        testfile.flush()
        os.chmod(testfile.name, 0o755)
        assert get_bin_path(testfile.name) == testfile.name
        shutil.copy(testfile.name, '/bin/' + testfile.name)
        assert get_bin_path(testfile.name, opt_dirs=['/bin']) == '/bin/' + testfile.name

# Generated at 2022-06-22 21:58:43.000011
# Unit test for function get_bin_path
def test_get_bin_path():
    # simple test for get_bin_path
    if os.name != 'nt':
        try:
            get_bin_path('sh')
        except ValueError as e:
            assert False, 'unexpected exception: %s' % e

# Generated at 2022-06-22 21:58:52.749761
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('which') == get_bin_path('which', ['/usr/bin', '/usr/sbin'])
    assert get_bin_path('which') == get_bin_path('which', ['/bin', '/usr/bin'])
    assert get_bin_path('which', ['/usr/bin', '/usr/sbin']) == get_bin_path('which', ['/usr/bin', '/usr/sbin'])
    assert get_bin_path('which', ['/usr/bin/which', '/usr/sbin/which']) == \
        get_bin_path('which', ['/usr/bin/which', '/usr/sbin/which'])

# Generated at 2022-06-22 21:59:00.441194
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes

    def do_test(path, expected):
        try:
            p = get_bin_path(path)
        except SystemExit as e:
            p = e.code

        assert p == expected, "%s: got %s, expected %s" % (path, p, expected)

    do_test(b'/bin/echo', b'/bin/echo')
    do_test(to_bytes('/bin/echo', errors='surrogate_or_strict'), b'/bin/echo')
    do_test(to_bytes(u'/bin/echo', errors='surrogate_or_strict'), b'/bin/echo')
    do_test(to_bytes(u'\xe9', errors='surrogate_or_strict'), 1)
    do_test

# Generated at 2022-06-22 21:59:02.890742
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh', ['/usr/bin', '/usr/local/bin/']) == '/usr/bin/sh'
    assert get_bin_path('sh', required=True)

# Generated at 2022-06-22 21:59:12.086799
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    returns False if get_bin_path(arg, opt_dirs) returns an error, else returns True
    '''
    assert not get_bin_path('does not exist')
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('which') == '/usr/bin/which'
    assert get_bin_path('which', opt_dirs=['/usr/bin']) == '/usr/bin/which'
    assert get_bin_path('python', opt_dirs=['/usr/bin']) == '/usr/bin/python'

# Generated at 2022-06-22 21:59:14.193269
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls', ['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'

    try:
        get_bin_path('invalid_command_name', ['/bin', '/usr/bin'])
    except ValueError:
        # pass
        assert True
    else:
        assert False, "Expected exception"

# Generated at 2022-06-22 21:59:15.857206
# Unit test for function get_bin_path
def test_get_bin_path():
    bp = get_bin_path('python')
    print(bp)

# Generated at 2022-06-22 21:59:26.745118
# Unit test for function get_bin_path
def test_get_bin_path():

    import tempfile
    import shutil
    from os.path import isfile, join, abspath

    class AnsibleModuleFake:
        def __init__(self, **kwargs):
            self.params = kwargs

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    touch(join(tmpdir, 'a_file'))

    # Test - Required file

# Generated at 2022-06-22 21:59:34.499075
# Unit test for function get_bin_path
def test_get_bin_path():
    test_arg = 'ansible'
    test_path = '/foo/bar:/bin'
    test_optdirs = ['/foo/bar']
    os.environ['PATH'] = test_path
    result = get_bin_path(test_arg, test_optdirs)
    assert result == '/foo/bar/ansible'

    test_optdirs2 = ['/bogus']
    try:
        result = get_bin_path(test_arg, test_optdirs2)
        assert False, 'Expected ValueError'
    except ValueError:
        pass

# Generated at 2022-06-22 21:59:37.179927
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/usr/bin/awk' == get_bin_path('awk', opt_dirs=['/bin', '/usr/bin', '/usr/local/bin'])

# Generated at 2022-06-22 21:59:46.186037
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    from ansible.utils.path import makedirs_safe

    test_file = 'this_is_not_a_real_file'
    (unused, temp_file_path) = tempfile.mkstemp(dir=tempfile.gettempdir(), prefix=test_file)
    temp_dir = os.path.dirname(temp_file_path)
    nonexistent_dir = os.path.join(temp_dir, 'nonexistent_dir')
    os.chmod(temp_file_path, 0o755)

    # Assumptions about this test system
    assert os.path.exists(temp_dir) and os.path.exists(temp_file_path) and os.path.exists(os.path.dirname(sys.executable))

    # Test that

# Generated at 2022-06-22 21:59:46.656445
# Unit test for function get_bin_path
def test_get_bin_path():
    return

# Generated at 2022-06-22 21:59:52.842632
# Unit test for function get_bin_path
def test_get_bin_path():

    try:
        get_bin_path('/usr/bin/foo')
    except ValueError:
        pass
    else:
        raise Exception('Failed to detect invalid path')

    try:
        get_bin_path('/bin/ls')
    except ValueError:
        raise Exception('Failed to find existing path')

    try:
        get_bin_path('ls')
    except ValueError:
        raise Exception('Failed to find existing path')

    try:
        get_bin_path('ls', ['/bin'])
    except ValueError:
        raise Exception('Failed to find existing path')

    try:
        get_bin_path('ls', ['/foo'])
    except ValueError:
        pass
  

# Generated at 2022-06-22 22:00:05.038594
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary test file
    test_file = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False, mode="w+b")
    # Write some data to it
    tfile_path = test_file.name
    test_file.write(b"#! /usr/bin/env python\n\nprint \"test_file\"\n")
    test_file.close()
    os.chmod(tfile_path, 0o700)

    # Create another temporary test file
    test_file2 = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False, mode="w+b")
    # Write some data to it
    tfile_path2 = test_file2.name


# Generated at 2022-06-22 22:00:14.651542
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    import tempfile
    import shutil


# Generated at 2022-06-22 22:00:25.370175
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert get_bin_path('ls') == '/bin/ls'
        assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
        assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'
        assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/bin/ls'
    except ValueError:
        assert False, 'expected to find ls'
    try:
        get_bin_path('ls', opt_dirs=['/usr/bin'])
        assert False, 'expected ValueError'
    except ValueError:
        assert True

# Generated at 2022-06-22 22:00:30.164377
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test generic
    get_bin_path('python')
    get_bin_path('python', ['/usr/bin', '/usr/local/bin'])

    # Test failure
    try:
        get_bin_path('python_notfound')
        assert False
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "python_notfound" in paths: /bin:/usr/bin:/sbin:/usr/sbin'

    try:
        get_bin_path('python_notfound', ['/usr/bin'])
        assert False
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "python_notfound" in paths: /usr/bin'

# Generated at 2022-06-22 22:00:42.637186
# Unit test for function get_bin_path
def test_get_bin_path():

    import sys
    import shutil
    import tempfile

    # Prepare test environment
    tdir = tempfile.mkdtemp()
    foo = os.path.join(tdir, 'foo')
    bar = os.path.join(tdir, 'bar')

    # Test if found in PATH
    os.environ['PATH'] = '/bin'
    shutil.copy(os.path.join(os.sep, 'bin', 'sh'), foo)
    assert get_bin_path('sh') == foo

    # Test if not found in PATH
    shutil.copy(os.path.join(os.sep, 'bin', 'sh'), foo)

# Generated at 2022-06-22 22:00:43.645115
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-22 22:00:54.192975
# Unit test for function get_bin_path
def test_get_bin_path():
    # should return the first executable found in given paths
    assert get_bin_path('./openssl') == os.path.join(os.getcwd(), 'openssl')
    assert get_bin_path('/bin/openssl') == '/bin/openssl'
    assert get_bin_path('/usr/bin/openssl') == '/usr/bin/openssl'
    assert get_bin_path('/usr/local/bin/openssl') == '/usr/local/bin/openssl'
    assert get_bin_path('/foo/openssl') == '/foo/openssl'
    assert get_bin_path('/foo/openssl', []) == '/foo/openssl'
    assert get_bin_path('/foo/openssl', ['/foo']) == '/foo/openssl'
    assert get_bin

# Generated at 2022-06-22 22:01:04.756604
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', None, None) == '/bin/sh'
    assert get_bin_path('sh', ['/bin'], None) == '/bin/sh'
    assert get_bin_path('sh', ['/bin'], True) == '/bin/sh'
    assert get_bin_path('sh', ['/bin'], False) == '/bin/sh'

    try:
        get_bin_path('/bin/sh', ['/non/existent'])
        assert False
    except ValueError as e:
        assert True

    try:
        get_bin_path('/bin/sh', ['/non/existent'], False)
        assert False
    except ValueError as e:
        assert True


# Generated at 2022-06-22 22:01:11.962325
# Unit test for function get_bin_path
def test_get_bin_path():
    # Create a file to use in tests
    import tempfile
    fd, temp_path = tempfile.mkstemp()
    # close the file immediately
    os.close(fd)

# Generated at 2022-06-22 22:01:23.530596
# Unit test for function get_bin_path
def test_get_bin_path():
    # Gather facts with different test cases
    #######################################
    cwd = os.getcwd()