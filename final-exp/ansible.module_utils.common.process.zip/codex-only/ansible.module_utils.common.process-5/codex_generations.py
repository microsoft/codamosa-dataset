

# Generated at 2022-06-22 21:51:27.168624
# Unit test for function get_bin_path
def test_get_bin_path():
    '''This is the unit test for function get_bin_path'''
    # Create a temporary empty directory to use as the shell PATH
    import errno
    import tempfile
    temp_dir = tempfile.mkdtemp()
    os.environ['PATH'] = temp_dir

    # Create an executable file to use in the tests. Answer 'yes' to
    # echo.
    import subprocess
    create_echo_file = tempfile.NamedTemporaryFile(dir=temp_dir, prefix='echo_', delete=False)
    create_echo_file.write(b'''#!/bin/sh
if [ "$1" = "--help" ]; then
  exit 1
fi
if [ "$1" = "--version" ]; then
  exit 1
fi
echo "yes"
''')

# Generated at 2022-06-22 21:51:32.478723
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.name == 'posix':
        assert get_bin_path('sh') == '/bin/sh'
        assert get_bin_path('sh', ['/bin']) == '/bin/sh'
        assert get_bin_path('sh', ['/xbin'], required=True) == '/xbin/sh'
        try:
            get_bin_path('sh', ['/xbin'])
            assert False
        except ValueError:
            assert True

# Generated at 2022-06-22 21:51:36.966627
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        bin_path = get_bin_path('=The quick brown fox jumps over the lazy dog')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
        bin_path = get_bin_path('echo')

    assert isinstance(bin_path, str)
    assert 'echo' in bin_path

# Generated at 2022-06-22 21:51:44.742116
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test that get_bin_path returns what we expect
    '''
    # test existing path
    try:
        os.environ['PATH'] = '/bin:/usr/bin'
        assert get_bin_path("sh") == "/bin/sh"
    except ValueError:
        assert False
    try:
        os.environ['PATH'] = '/bin:/usr/bin'
        assert get_bin_path("foo") == "/bin/foo"
    except ValueError:
        assert False
    try:
        os.environ['PATH'] = '/bin:/usr/bin'
        assert get_bin_path("foo", ['/usr/bin']) == "/usr/bin/foo"
    except ValueError:
        assert False
    # test non existing path

# Generated at 2022-06-22 21:51:53.690891
# Unit test for function get_bin_path
def test_get_bin_path():
    #
    # Setup / Teardown
    #
    def setUp():
        '''Function called before each test_* function'''
        os.environ['PATH'] = '/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin'

    def tearDown():
        '''Function called after each test_* function'''
        os.environ.pop('PATH', None)

    #
    # Tests
    #
    def test_get_bin_path_1():
        '''Test get_bin_path with no additional directories to search'''
        try:
            get_bin_path('sh')
        except ValueError:
            assert False, 'sh not found in default search paths (should have raised)'


# Generated at 2022-06-22 21:52:00.814242
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common._collections_compat import Mapping
    import sys

    # Create a list of existing directories and one nonexistent
    d = os.path.dirname(sys.executable)
    dirs = [os.path.join(d, s) for s in ['bin', 'lib', 'lib/python3.5', './']]
    dirs.append(os.path.join(os.path.sep, dirs[0], '../', dirs[0]))  # copy of first element
    dirs.append(os.path.join(dirs[3], 'nonexistent'))  # final element should not exist

    # Create a list of files and a 'nonexistent' file
    files = [sys.executable]

# Generated at 2022-06-22 21:52:08.493980
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    def test_get_bin_path_inner(tmpdir, filename, opt_paths, expected):
        path = tmpdir.dirname

        if not os.path.exists(os.path.join(path, filename)):
            open(os.path.join(path, filename), 'a').close()

        if filename not in os.listdir(path):
            raise ValueError('test_get_bin_path_inner: file "%s" not created in path "%s"' % (filename, path))

        if (opt_paths is not None) and (len(opt_paths) > 0):
            if isinstance(opt_paths, str):
                opt_paths = [opt_paths]

# Generated at 2022-06-22 21:52:14.770071
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import nose

    try:
        # Try to find ping
        path = get_bin_path('ping')
    except ValueError:
        raise nose.SkipTest('Failed to find ping. Skipping')

    assert os.path.exists(path) and os.path.isfile(path), 'Failed to find ping'
    assert is_executable(path), 'ping is not executable'

    # Now let's make sure we can't find a non-existent executable
    if sys.platform.startswith('win'):
        bogus_exe = 'this_exe_does-not-exist.exe'
    else:
        bogus_exe = 'this_exe_does-not-exist'


# Generated at 2022-06-22 21:52:22.485612
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path function
    '''
    test_bin_path = get_bin_path('python3')
    assert test_bin_path == '/usr/bin/python3'

    test_bin_path = get_bin_path('python3',
                                 opt_dirs=['/usr/bin', '/bin', '/usr/local/bin'])
    assert test_bin_path == '/usr/bin/python3'

    try:
        test_bin_path = get_bin_path('non_existant_bin')
    except ValueError:
        assert 1 == 1
    else:
        assert 1 == 2

# Generated at 2022-06-22 21:52:26.574137
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cowsay') == '/usr/bin/cowsay'
    try:
        get_bin_path('cowsay-invalid')
    except ValueError:
        pass
    else:
        raise AssertionError('get_bin_path failed to raise a ValueError when unable to find executable in PATH!')

# Generated at 2022-06-22 21:52:38.571275
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Test Python function get_bin_path'''

    # Test for an existing executable in PATH
    bin_path = get_bin_path('ls')
    assert bin_path.endswith('ls')
    assert os.path.exists(bin_path) and os.path.isfile(bin_path) and is_executable(bin_path)

    # Test for a non-existing executable
    try:
        bin_path = get_bin_path('not-existing-file')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    else:
        assert False, 'Expected ValueError'

    # Test for a subdirectory

# Generated at 2022-06-22 21:52:49.176016
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/bin/ls' == get_bin_path('ls')
    assert '/bin/ls' == get_bin_path('ls', ['/bin', '/usr/bin'])
    assert '/bin/ls' == get_bin_path('ls', ['/usr/bin', '/bin'])
    assert '/bin/ls' == get_bin_path('ls', ['/bin/', '/usr/bin/'])

    assert '/sbin/ls' == get_bin_path('ls', ['/sbin/', '/usr/sbin/'])

    assert '/bin/ls' == get_bin_path('ls', ['/bin/', '/sbin/', '/usr/bin/', '/usr/sbin/'])

# Generated at 2022-06-22 21:52:59.198884
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('/bin/cat')
    get_bin_path('cat')

    # test that path is found if it's an absolute path
    assert get_bin_path('/bin/cat') == '/bin/cat'

    # test that path is found if it's only in sbin
    assert get_bin_path('/sbin/ifconfig') == '/sbin/ifconfig'

    # test that bin is found if it's in the sbin dir
    assert get_bin_path('ifconfig') == '/sbin/ifconfig'

    try:
        get_bin_path("/bin/foobar")
    except ValueError:
        pass
    else:
        raise ValueError("/bin/foobar was supposed to raise ValueError")

# Generated at 2022-06-22 21:53:08.512352
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        bin_path = get_bin_path('cat')
    except ValueError:
        assert False, 'Unable to find the cat executable'
    assert bin_path == '/bin/cat', 'Did not find /bin/cat as expected'

    # test opt_dirs
    d = '/usr/bin'
    try:
        bin_path = get_bin_path('cat', opt_dirs=[d])
    except ValueError:
        assert False, 'Unable to find the cat executable in %s' % d
    assert bin_path == '/usr/bin/cat', 'Did not find /usr/bin/cat as expected'

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-22 21:53:19.918262
# Unit test for function get_bin_path
def test_get_bin_path():

    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils._text import to_bytes

    # Ensure that the function correctly returns the path on a system
    # where the executable is installed.
    module_args = dict(
        required=False,
        fail_on_missing=False,
        opt_dirs=[],
    )
    binary = basic.AnsibleModule(argument_spec=module_args)
    bin_path = get_bin_path(binary, '/bin/ls')
    assert bin_path == '/bin/ls'

    # Ensure that the function correctly returns the path on a system
    # when opt_dirs is not empty and the executable is installed in one
    # of the custom directories in opt_dirs
    module

# Generated at 2022-06-22 21:53:30.398037
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh', ['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('/bin/sh', ['/usr/bin']) == '/bin/sh'
    assert get_bin_path('/usr/bin/sh') == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/usr/sbin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/bin', '/usr/sbin']) == '/bin/sh'
    import pytest
    with pytest.raises(ValueError):
        get_bin_path('nonexistent_program')

# Generated at 2022-06-22 21:53:34.207775
# Unit test for function get_bin_path
def test_get_bin_path():
    print('Running tests for function get_bin_path')
    test_passed = True
    try:
        get_bin_path('')
    except ValueError:
        test_passed = False

    assert(test_passed)

# Generated at 2022-06-22 21:53:47.384949
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.six.moves import builtins
    path_sep = os.pathsep

    def mock_exists(path):
        return True

    def mock_is_executable(path):
        return True

    def mock_join(*args):
        return '/'.join(args)

    def mock_getenv(var, default):
        return '/usr/bin:/bin'

    class MockedOs(object):
        @staticmethod
        def pathsep():
            return path_sep

        @staticmethod
        def path():
            class MockPath(object):
                @staticmethod
                def exists(path):
                    return mock_exists(path)

                @staticmethod
                def isdir(path):
                    return False

            return MockPath


# Generated at 2022-06-22 21:53:48.639210
# Unit test for function get_bin_path
def test_get_bin_path():

    assert get_bin_path('bash') == '/bin/bash'

# Generated at 2022-06-22 21:53:58.113666
# Unit test for function get_bin_path
def test_get_bin_path():
    test_cases = [
        # test_case = ( arg, expected_path, opt_dirs, required)
        # True case
        ("/bin/ls", "/bin/ls", [], True),
        ("ls", "/bin/ls", [], True),
        ("ls", "/bin/ls", ['/bin'], True),
        # False case
        ("xx", None, [], True),
        ("ls", None, [], False),
    ]

    for arg, expected_path, opt_dirs, required in test_cases:
        real_path = get_bin_path(arg, opt_dirs, required)
        if expected_path is None:
            assert real_path is not None
        else:
            assert real_path == expected_path

# Generated at 2022-06-22 21:54:05.362403
# Unit test for function get_bin_path
def test_get_bin_path():
    # check for a system binary
    assert get_bin_path('/bin/ls')
    assert get_bin_path('ls')
    # check for a system binary in /sbin
    assert get_bin_path('ifconfig')
    assert get_bin_path('ifconfig', opt_dirs=['/sbin', '/usr/sbin'])
    assert get_bin_path('/sbin/ifconfig')
    # check a failure condition
    try:
        get_bin_path('unit_test_does_not_exist')
    except Exception:
        pass
    else:
        raise Exception('get_bin_path excepted exception was not raised')

# Generated at 2022-06-22 21:54:17.911661
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text

    # test with valid file in PATH directories
    arg = 'ls'
    bin_path = get_bin_path(arg)
    assert os.path.exists(bin_path)
    assert os.path.isfile(bin_path)
    assert is_executable(bin_path)

    # test with something that's not in the PATH
    arg = 'foobar'
    try:
        bin_path = get_bin_path(arg)
    except ValueError as e:
        bin_path = None
    assert bin_path is None

    # test with something that is in PATH
    arg = 'ls'

# Generated at 2022-06-22 21:54:28.942248
# Unit test for function get_bin_path
def test_get_bin_path():
    # test that we can find python
    assert get_bin_path('python')
    # test that we don't find a non-existent file
    try:
        get_bin_path('XXXXXXXXXXXXXXXXXX')
        assert False, 'should have failed to find random command'
    except ValueError:
        assert True, 'failed as expected'

    # test that we can find a file that might be in an alternate directory
    assert get_bin_path('python', opt_dirs=['/usr/local/bin'])
    # test that we can find a file that is in the standard path
    assert get_bin_path('sh')

    # test that we don't get tricked by a file in the alternate dir that's not executable

# Generated at 2022-06-22 21:54:38.436733
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('grep')
    except ValueError:
        assert False, "Failed to find command 'grep' in default PATH"

    try:
        get_bin_path('grep', opt_dirs=['/bin'])
    except ValueError:
        assert False, "Failed to find command 'grep' in default PATH"

    try:
        get_bin_path('not-a-command')
        assert False, "Failed to raise ValueError on missing command"
    except ValueError:
        pass

    try:
        get_bin_path('not-a-command', opt_dirs=['/bin'])
        assert False, "Failed to raise ValueError on missing command"
    except ValueError:
        pass


# Generated at 2022-06-22 21:54:49.190175
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import itertools

    # setup
    fake_bins = ['fake_bin1', 'fake_bin2']
    fake_sbinds = ['fake_sbin1', 'fake_sbin2']
    fake_bin_dir = tempfile.mkdtemp()
    fake_sbin_dir = tempfile.mkdtemp()
    paths = ['/usr/bin', '/usr/sbin']
    fake_paths = [fake_bin_dir, fake_sbin_dir]

    env = dict(os.environ)
    env['PATH'] = ':'.join(paths)

    for b in itertools.chain(fake_bins, fake_sbinds):
        open(os.path.join(fake_bin_dir, b), 'a').close()

# Generated at 2022-06-22 21:54:57.059513
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    # test search in /sbin
    assert get_bin_path('init') == '/sbin/init'
    # test with optional arguments - search in /usr/sbin
    assert get_bin_path('ifconfig', opt_dirs=['/usr/bin', '/usr/sbin']) == '/usr/sbin/ifconfig'

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-22 21:55:01.480848
# Unit test for function get_bin_path
def test_get_bin_path():
    # This will fail with a message including "command not found"
    result = get_bin_path("thiscouldnotpossiblyexist")
    # This is a 2.4+ idiom for assertFalse without the need for unittest
    assert False, "Should not have found an executable at %s" % result

# Generated at 2022-06-22 21:55:12.950973
# Unit test for function get_bin_path
def test_get_bin_path():
    # There are only two hard things in Computer Science: cache invalidation, naming things, and off-by-one errors.
    test_programs = ['bash', '/bin/bash', '/usr/bin/bash', 'sh', '/bin/sh', '/usr/bin/sh']
    test_dirs = ['/bin', '/usr/bin', '/usr/local/bin', '/usr']
    # Test 1.
    # Verify that the program is found.
    for tst in test_programs:
        path = get_bin_path(tst, test_dirs, required=True)

# Generated at 2022-06-22 21:55:16.045361
# Unit test for function get_bin_path
def test_get_bin_path():
    bp = get_bin_path('sh')
    assert bp is not None, 'Failed to find binary in $PATH: sh'

# Generated at 2022-06-22 21:55:24.475603
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    bin = 'foo'
    tmpdir = tempfile.mkdtemp()
    binpath = os.path.join(tmpdir, bin)

    # Create a fake executable named 'foo' in a temp dir
    with open(binpath, "w") as f:
        f.write("#!/bin/bash\necho Hello")
    os.chmod(binpath, 0o755)

    try:
        path = get_bin_path(bin)
        assert path == binpath
    finally:
        os.remove(binpath)
        os.rmdir(tmpdir)



# Generated at 2022-06-22 21:55:29.118828
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    try:
        get_bin_path('This_file_should_never_exist')
    except Exception as e:
        assert 'Failed to find required executable' in str(e)
        sys.exit(0)
    raise Exception('test_get_bin_path: expected exception was not thrown')

# Generated at 2022-06-22 21:55:35.765799
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test that get_bin_path finds existing binary
    found_path = get_bin_path('sh')
    assert os.path.exists(found_path)
    # Test that get_bin_path fails on non-existing binary
    try:
        found_path = get_bin_path('this_is_not_a_command')
        assert False, "get_bin_path didn't fail as expected"
    except ValueError:
        pass



# Generated at 2022-06-22 21:55:44.859698
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('/bin/bash', None, True)
    assert bin_path == '/bin/bash'
    bin_path = get_bin_path('/bin/bash', '/bin', True)
    assert bin_path == '/bin/bash'
    bin_path = get_bin_path('/bin/bash', ['/bin'], True)
    assert bin_path == '/bin/bash'
    try:
        bin_path = get_bin_path('/bin/bash', None, False)
    except ValueError as e:
        assert "Failed to find" in str(e)

    try:
        bin_path = get_bin_path('/bin/bash', None, True)
    except ValueError as e:
        assert "Failed to find" in str(e)

# Generated at 2022-06-22 21:55:56.395186
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    from shutil import rmtree

    def assertRaises(expected_fn, expected_msg, fn, *args, **kwargs):
        try:
            fn(*args, **kwargs)
        except Exception as e:
            assert isinstance(e, expected_fn)
            assert str(e) == expected_msg
        else:
            assert False  # exception not raised

    def assertPaths(expected_fn, expected_msg, path_arg, fn, *args):
        expected_path = os.path.join(*args)
        result = fn(path_arg)
        assert result == expected_path

    assert get_bin_path('ls') == '/bin/ls'

    # doesn't exist

# Generated at 2022-06-22 21:56:04.643563
# Unit test for function get_bin_path
def test_get_bin_path():
    # create temporary file as executable
    import tempfile
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w+b')
    f.close()

    os.chmod(fname, int('0755', 8))
    assert get_bin_path(os.path.basename(fname)) == fname
    try:
        get_bin_path('fnit_non_existing')
        assert False
    except ValueError as err:
        assert 'Failed to find required executable "fnit_non_existing"' in str(err)
    finally:
        os.unlink(fname)

# Generated at 2022-06-22 21:56:15.256183
# Unit test for function get_bin_path
def test_get_bin_path():
    # execute_bin_path will execute the binary found
    execute_bin_path = get_bin_path("echo")
    assert execute_bin_path != None

    # Nope, we don't expect find a binary that is not there
    try:
        get_bin_path("foobar")
        assert False
    except:
        assert True

    # Nope, we don't expect find a binary that is not there
    try:
        get_bin_path("foobar", opt_dirs=["/usr/bin"])
        assert False
    except:
        assert True

    # But we expect to find one if we specify the path
    execute_bin_path = get_bin_path("echo", opt_dirs=["/bin"])
    assert execute_bin_path != None

# Generated at 2022-06-22 21:56:25.616926
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat
    temp_path = tempfile.mkdtemp()

# Generated at 2022-06-22 21:56:32.074720
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('which') == '/usr/bin/which'
    assert get_bin_path('which', ['test']) == '/usr/bin/which'
    assert get_bin_path('which', ['test', '/usr/bin']) == '/usr/bin/which'
    try:
        get_bin_path('which', ['test'], required=True)
    except ValueError as e:
        assert 'Failed to find required executable "which" in paths' in str(e)

# Generated at 2022-06-22 21:56:35.482620
# Unit test for function get_bin_path
def test_get_bin_path():
    # just test with PATH
    for binary in ['python', 'bash', 'sh', 'ls']:
        get_bin_path(binary)


# ===  Deprecated  ===


# Generated at 2022-06-22 21:56:43.948250
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import shutil
    import tempfile

    def get_bin_path_for_test(arg, opt_dir=None, exc=False):
        try:
            return get_bin_path(arg, opt_dirs=opt_dir)
        except ValueError as e:
            if exc:
                err_msg = str(e)
                if arg not in err_msg:
                    raise AssertionError('Bad error message for %s: %s' % (arg, err_msg))
                return None
            raise

    def is_executable_for_test(path):
        return hasattr(os, 'access') and os.access(path, os.X_OK)

    # test with arg = /usr/bin/python
    arg = sys.executable
    # test with opt_dir = /tmp


# Generated at 2022-06-22 21:56:54.222559
# Unit test for function get_bin_path
def test_get_bin_path():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    import sys
    import unittest

    dummy_executable = sys.executable

    class TestGetBinPath(unittest.TestCase):

        @unittest.skipIf(not os.path.exists(dummy_executable), 'Skipping as %s does not exist' % dummy_executable)
        def test_default_path(self):
            ret = get_bin_path(os.path.basename(dummy_executable), required=False)
            self.assertEqual(ret, to_bytes(dummy_executable))


# Generated at 2022-06-22 21:57:02.566881
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        os_path_exists = os.path.exists

        # tests for function get_bin_path
        def os_path_exists_sideeffect(path):
            if path == '/usr/bin/ansible':
                return True
            return os_path_exists(path)
        os.path.exists = os_path_exists_sideeffect
        # check if exec is found in standard path
        assert get_bin_path('ansible') == '/usr/bin/ansible'
    finally:
        os.path.exists = os_path_exists

# Generated at 2022-06-22 21:57:07.791892
# Unit test for function get_bin_path
def test_get_bin_path():
    test_paths = ['/foo/bar', '/bar/foo', '/bin', '/usr/bin', '/usr/local/bin']
    res = get_bin_path('python', test_paths)
    assert res == '/usr/bin/python'  # expected path in a test machine

# Generated at 2022-06-22 21:57:16.003128
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('cat')
    assert bin_path == '/bin/cat'

    # try a command that doesn't exist in PATH
    try:
        get_bin_path('false')
        assert False
    except ValueError:
        pass

    # use a path that exists but the command doesn't exist
    try:
        get_bin_path('false', opt_dirs=['/bin'])
        assert False
    except ValueError:
        pass

    # verify that /sbin paths are searched
    bin_path = get_bin_path('cp')
    assert bin_path == '/bin/cp'

    bin_path = get_bin_path('poweroff')
    assert bin_path == '/sbin/poweroff'

    # if the command exists in two places, the "first" one wins


# Generated at 2022-06-22 21:57:27.929314
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('bash') == '/bin/bash'
    import sys
    assert get_bin_path(sys.executable) == sys.executable
    import tempfile
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-22 21:57:37.478323
# Unit test for function get_bin_path
def test_get_bin_path():
    home = os.path.expanduser('~')
    opt_dirs = ['/d1', '/d2', '/d3']
    paths = os.environ.get('PATH', '').split(os.pathsep)
    new_paths = opt_dirs + paths
    os.environ['PATH'] = os.pathsep.join(new_paths)
    for d in opt_dirs + paths:
        if not d:
            continue
        arg = os.path.join(d, 'get_bin_path')
        bp = get_bin_path(arg, opt_dirs=opt_dirs+paths)
        assert(bp == arg)

    paths = os.environ.get('PATH', '').split(os.pathsep)

# Generated at 2022-06-22 21:57:46.570043
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python')
    assert get_bin_path('python', ['/usr/bin'])
    assert get_bin_path('which', ['/usr/bin'])
    assert get_bin_path('which', ['/usr/bin'], False)
    try:
        get_bin_path('doesnotexist')
        assert False
    except ValueError:
        assert True
    try:
        get_bin_path('doesnotexist', ['/usr/bin'])
        assert False
    except ValueError:
        assert True
    try:
        get_bin_path('doesnotexist', ['/usr/bin'], True)
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-22 21:57:51.935606
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    try:
        get_bin_path('/bin/nope')
    except ValueError:
        pass
    else:
        assert False # didn't raise expected exception
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-22 21:57:58.103739
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = None
    try:
        bin_path = get_bin_path('sh')
        assert bin_path

        bin_path = get_bin_path('nothisfile')
        assert False
    except Exception:
        assert True

    assert bin_path and os.path.isabs(bin_path) and os.path.exists(bin_path) and os.access(bin_path, os.X_OK)


# Generated at 2022-06-22 21:57:59.763222
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')



# Generated at 2022-06-22 21:58:11.304848
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # Create a temporary directory and set PATH to it
    tmpdir = tempfile.mkdtemp()
    saved_path = os.environ.get('PATH', '')
    os.environ['PATH'] = tmpdir

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Check if calling get_bin_path with existing executable returns right path
    res = get_bin_path(os.path.basename(tmpfile))
    assert res == tmpfile

    # Cleanup: remove temporary directory and restore original PATH
    os.remove(tmpfile)
    os.rmdir(tmpdir)
    os.environ['PATH'] = saved_path

    # Check if calling get_bin_path with non-existing executable raises

# Generated at 2022-06-22 21:58:17.012470
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Test for function get_bin_path'''
    try:
        get_bin_path('this_does_not_exist')
        raise Exception("We should not get here")
    except ValueError:
        pass

    import platform
    exec_name = 'pwd'
    if platform.system() == 'Windows':
        exec_name = 'where.exe'

    get_bin_path(exec_name)

# Generated at 2022-06-22 21:58:26.503447
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Tests for get_bin_path'''
    from ansible.module_utils import basic
    import os, sys

    # 1) Test that the function throws an Exception if required is True
    try:
        get_bin_path('a_binary_that_does_not_exist', required=True, opt_dirs=['/usr/local/bin'])
        assert False, 'This statement should never be reached'
    except:
        pass

    # 2) Test that the function returns None if required is False and the executable is not found
    assert get_bin_path('a_binary_that_does_not_exist', required=False, opt_dirs=['/usr/local/bin']) is None

    # 3) Test that the function returns the path to the executable if it is found.
    #    This test is platform specific

# Generated at 2022-06-22 21:58:37.890520
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=[]).endswith('/bin/ls')
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == get_bin_path('ls', opt_dirs=['/bin'])
    try:
        get_bin_path('ls', opt_dirs=['/bin', '/usr/bin'])
        assert False, "Expected exception did not happen"
    except SystemExit:
        pass
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin', '/bin']) == '/bin/ls'

# Generated at 2022-06-22 21:58:38.896435
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python')

# Generated at 2022-06-22 21:58:49.126098
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    fd, bin_file = tempfile.mkstemp()
    os.close(fd)


# Generated at 2022-06-22 21:59:01.471891
# Unit test for function get_bin_path
def test_get_bin_path():
    def _test_get_bin_path():
        try:
            # Required should be replaced with a value in _test_get_bin_path(), but we're only testing deprecation here.
            get_bin_path('cat', required=None)
        except ValueError as e:
            assert e.args[0].startswith('Failed to find required executable "cat" in paths: ')
        else:
            assert False, 'ValueError not raised'

    def test_deprecated_get_bin_path_required_kwd():
        orig_warnings_showwarning = None

# Generated at 2022-06-22 21:59:13.411474
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import platform
    import tempfile

    # Test for pytest to confirm if python process is 64 or 32 bit
    def is_py64bit():
        return sys.maxsize > 2147483647

    # Test for pytest to confirm if python process is running on Linux or Mac
    def is_linux():
        if platform.system() == 'Linux':
            return True
        else:
            return False

    # Test for pytest to confirm if python process is running on Linux or Mac
    def is_mac():
        if platform.system() == 'Darwin':
            return True
        else:
            return False

    # Test for pytest to confirm if the system running the tests has /sbin in the PATH
    def get_path():
        path = os.environ.get('PATH')

# Generated at 2022-06-22 21:59:25.391005
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    BIN_PATH = '/bin'
    TEST_BINARY = 'printf'
    TEST_DIR = tempfile.mkdtemp()
    TEST_FILE = os.path.join(TEST_DIR, 'testfile')

    # Sanity check
    assert get_bin_path(TEST_BINARY) == os.path.join(BIN_PATH, TEST_BINARY)

    # File found in current dir
    os.chdir(TEST_DIR)
    open(TEST_FILE, 'a').close()
    assert get_bin_path(TEST_FILE) == os.path.join(TEST_DIR, TEST_FILE)

    # File found in opt_dir

# Generated at 2022-06-22 21:59:32.839428
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('some_script_that_does_not_exist')
        assert False, "expected exception"
    except ValueError as e:
        assert "Failed to find required" in str(e)

    # use a NON-existent directory due to the fact that there is
    # a /bin/ls on OSX which is not the same as /usr/bin/ls
    # and this was confused the test
    bin_path = get_bin_path('ls', opt_dirs=[os.path.expanduser('~/this_dir_does_not_exist')])
    assert os.path.basename(bin_path) == 'ls', "failed to get correct path for ls"

# Generated at 2022-06-22 21:59:43.037140
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import os
    import shutil
    path = '/tmp/ansible_test_get_bin_path'


# Generated at 2022-06-22 21:59:53.086692
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        try:
            get_bin_path(f.name)
        except ValueError:
            pass
        else:
            raise AssertionError('get_bin_path() did not raise ValueError when looking for file that does not exist')

        get_bin_path('bash')
        get_bin_path('bash', [f.name])
        try:
            get_bin_path('bash', [f.name], True)
        except ValueError:
            pass
        else:
            raise AssertionError('get_bin_path() did not raise ValueError when required=True and file does not exist')

# Generated at 2022-06-22 22:00:02.425383
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for function get_bin_path.
    '''
    import tempfile
    import shutil
    import sys

    # find system executable
    try:
        shutil.rmtree('/tmp/ansible_test/bin')
    except OSError:
        # probably doesn't exist
        pass

    # create a dummy executable
    filep = tempfile.NamedTemporaryFile(prefix='ansible_bin_path_test')
    filep.write(b'#!/bin/sh\necho hello world\n')
    filep.close()
    assert os.path.exists(filep.name)

    bin_path = get_bin_path(filep.name, opt_dirs=[os.path.dirname(filep.name)])
    assert bin_path == file

# Generated at 2022-06-22 22:00:12.919599
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/python') == '/usr/bin/python'
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('./python') == './python'
    assert get_bin_path('python', opt_dirs=['/usr/bin']) == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/bin', '/usr/local/bin']) == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/local/bin', '/usr/bin']) == '/usr/bin/python'

# Generated at 2022-06-22 22:00:22.791341
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test case with no optional directories
    expected = os.path.join(os.environ['PATH'].split(os.pathsep)[0], 'grep')
    assert get_bin_path('grep') == expected

    # Test case with optional directories
    expected = '/bin/grep'
    assert get_bin_path('grep', opt_dirs=['/bin']) == expected

    # Test for ValueError
    try:
        get_bin_path('blah', required=True)
    except ValueError:
        pass
    else:
        assert False, "ValueError should have been raised"

# Generated at 2022-06-22 22:00:30.139985
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for a valid path
    test_path1 = get_bin_path('ls')
    assert test_path1.endswith('ls')
    assert os.path.exists(test_path1)

    # Test for an invalid path when there is no executable in the path
    try:
        get_bin_path('not-a_valid_command')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    else:
        assert False


# check if two dicts intersect

# Generated at 2022-06-22 22:00:42.635866
# Unit test for function get_bin_path
def test_get_bin_path():
    # Existing file
    path = get_bin_path('/bin/true')
    assert path == '/bin/true'

    # Non existing file
    try:
        get_bin_path('/foo/bar')
        assert True is False  # Exception should be raised
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

    # Existing directory
    try:
        get_bin_path('/etc/ssh')
        assert True is False  # Exception should be raised
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

    # Existing file in search path
    if os.path.exists('/usr/bin/env'):
        path = get_bin_path('env')
        assert path == '/usr/bin/env'

# Generated at 2022-06-22 22:00:50.411680
# Unit test for function get_bin_path
def test_get_bin_path():

    path_string = ':/usr/bin:/usr/sbin'
    path_list = path_string.split(os.pathsep)
    arg_list = ['/usr/bin/cat', '/usr/bin/ping', '/usr/bin/pip', '/usr/bin/pip3', '/usr/bin/python']

    assert os.path.exists(get_bin_path(arg_list[0], path_list)) == True
    assert os.path.exists(get_bin_path(arg_list[1], path_list)) == True
    assert os.path.exists(get_bin_path(arg_list[2], path_list)) == True
    assert os.path.exists(get_bin_path(arg_list[3], path_list)) == True
    assert os.path.ex

# Generated at 2022-06-22 22:01:02.261746
# Unit test for function get_bin_path
def test_get_bin_path():

    import tempfile

    test_bin = 'test_bin'
    tmp_dir = tempfile.gettempdir()
    paths = [tmp_dir]

    #
    # POSIX
    #
    try:
        bin_path = get_bin_path(test_bin, opt_dirs=paths)
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

    bin_file = os.path.join(tmp_dir, test_bin)
    with open(bin_file, 'w') as f:
        f.write('')

# Generated at 2022-06-22 22:01:10.854756
# Unit test for function get_bin_path
def test_get_bin_path():

    # need to set a bogus PATH here since most systems have /bin:/usr/bin, so will
    # pass a test and we need to test that this really works.
    oldpath = os.environ.get('PATH', None)
    os.environ['PATH'] = '/bin'

# Generated at 2022-06-22 22:01:20.364795
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('echo') == '/bin/echo' or get_bin_path('echo') == '/usr/bin/echo'
    assert get_bin_path('/bin/echo') == '/bin/echo'
    assert get_bin_path('/bin/echo', ['/usr/local']) == '/bin/echo'
    try:
        get_bin_path('no_command')
    except ValueError:
        pass
    except Exception as err:
        assert False, 'unexpected exception: %s' % str(err)
    else:
        assert False, 'expected ValueError exception'