

# Generated at 2022-06-22 21:51:26.200956
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test execution of get_bin_path.
    '''
    try:
        get_bin_path('not_exists')
    except ValueError as e:
        assert 'Failed to find required executable "not_exists"' in str(e)
    assert get_bin_path('sh', opt_dirs='/bin') == '/bin/sh'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('chmod') == '/bin/chmod'
    assert get_bin_path('chmod', opt_dirs='/bin:') == '/bin/chmod'
    assert get_bin_path('chmod', opt_dirs=':/bin') == '/bin/chmod'

# Generated at 2022-06-22 21:51:35.747872
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Unit test for function get_bin_path'''
    from ansible.module_utils.basic import get_exception
    from sys import platform

    # Should fail with ValueError because there is no executable 'does-not-exist' on the PATH.
    try:
        get_bin_path('does-not-exist')
    except ValueError:
        pass
    else:
        assert False, 'Expected get_bin_path to raise ValueError for nonexistent executable.'

    # Pass in a list of paths.
    from tempfile import mkdtemp
    bin_name = 'ansible-test-get-bin-path'
    bin_path = os.path.join(mkdtemp(), bin_name)

# Generated at 2022-06-22 21:51:40.326402
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import os
    my_python_executable = os.path.abspath(sys.executable)
    assert get_bin_path('doesnotexist') is None
    assert get_bin_path('doesnotexist', required=True) == '/usr/bin/doesnotexist'
    assert get_bin_path(my_python_executable) == my_python_executable

# Generated at 2022-06-22 21:51:49.750972
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import random
    import string

    tdir = tempfile.mkdtemp(dir='/tmp')
    bindir = tempfile.mkdtemp(dir=tdir)
    binname = ''.join(random.choice(string.ascii_lowercase) for _ in range(7))
    bindir_abs = os.path.abspath(bindir)

    binpath = '%s/%s' % (bindir, binname)
    assert not os.path.exists(binpath)
    with open(binpath, 'w') as f:
        f.write('a' * 2**12)
    os.chmod(binpath, 0o777)
    assert os.path.exists(binpath)


# Generated at 2022-06-22 21:51:58.752247
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh', ['/tmp']) == '/tmp/sh'
    assert get_bin_path(['sh', 'bash'], ['/tmp', '/usr']) == '/tmp/sh'
    assert get_bin_path(['sh', 'bash'], ['/tmp', '/bin', '/usr']) == '/bin/bash'
    import pytest
    with pytest.raises(ValueError) as excinfo:
        get_bin_path('sh', ['/tmp'], required=True)
    assert excinfo.value.args[0] == "Failed to find required executable 'sh' in paths: /tmp:/sbin:/usr/sbin:/usr/local/sbin"

# Generated at 2022-06-22 21:52:06.470684
# Unit test for function get_bin_path
def test_get_bin_path():
    # get_bin_path() not working on Windows, yet
    if os.name == 'nt':
        return

    assert get_bin_path('grep') == '/bin/grep'
    assert get_bin_path('egrep') == '/bin/egrep'
    assert get_bin_path('fgrep') == '/bin/fgrep'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'

    try:
        get_bin_path('foobar')
        assert False, "Don't expect to get here, this should fail"
    except ValueError:
        pass

    return

# Generated at 2022-06-22 21:52:12.224611
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.compat.tests import unittest

    class TestGetBinPath(unittest.TestCase):
        def setUp(self):
            self.old_environ = os.environ.copy()

        def tearDown(self):
            os.environ.clear()
            os.environ.update(self.old_environ)

        def test_get_bin_path(self):
            path = os.path.join(os.path.dirname(__file__), '..', '..', 'lib')
            msg = "get_bin_path(%r) did not return the correct path."

# Generated at 2022-06-22 21:52:21.977108
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'bin_test')
    with open(test_file, 'w') as f:
        f.write("")
    os.chmod(test_file, 0o700)

    test_dir2 = tempfile.mkdtemp()
    test_file2 = os.path.join(test_dir2, 'bin_test')
    with open(test_file2, 'w') as f:
        f.write("")
    os.chmod(test_file2, 0o700)


# Generated at 2022-06-22 21:52:27.081100
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert(bin_path == '/usr/bin/sh')

    bin_path = get_bin_path('dummy_sh', required=True)
    assert(bin_path == '')

    # None is a valid path and should be expanded
    bin_path = get_bin_path('sh', opt_dirs=[None])
    assert(bin_path == '/usr/bin/sh')

# Generated at 2022-06-22 21:52:39.273728
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic

    test_path = '/usr/bin:/usr/local/bin:/bin'
    test_dirs = ['/usr/bin', '/usr/local/bin', '/bin']
    test_arg = 'cat'

    mock_os_environ = {'PATH': test_path}

    # mock os.environ and os.pathsep
    backup = {'os_environ': os.environ,
              'os_pathsep': os.pathsep,
              'os_path_exists': os.path.exists}


# Generated at 2022-06-22 21:52:49.773849
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Return success/failure test results'''

    import platform
    import sys

    res = {'changed': False, 'failed': False, 'rc': 0, 'warnings': []}
    my_env = dict(os.environ)
    my_env['PATH'] = '/bin:/usr/bin'
    my_env['VIRTUAL_ENV'] = '/path/to/venv'
    # Setup our test by replacing a system executable
    test_bin = os.path.abspath('./unit/ansible_test')
    if os.path.exists(test_bin):
        os.remove(test_bin)
    with open(test_bin, 'w') as f:
        f.write('#!/bin/sh\necho TEST\n')
        f.close()
    os.ch

# Generated at 2022-06-22 21:53:00.876542
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')
    try:
        get_bin_path('f8d49gf4g4')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError should have been raised')

    dirs = ['/bin', '/usr/bin', '/usr/local/bin']
    assert get_bin_path('ls', dirs) == '/bin/ls'
    assert get_bin_path('ls', ['/usr/bin', '/usr/local/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', ['/usr/local/bin', '/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', ['/usr/local/bin']) == '/usr/local/bin/ls'
   

# Generated at 2022-06-22 21:53:07.875050
# Unit test for function get_bin_path
def test_get_bin_path():

    # Test with no arguments
    test_path = get_bin_path(None)
    assert test_path is None

    # Test with nonexistent binary and opt_dirs included
    test_path = get_bin_path('bar', [])
    assert test_path is None

    # Test with nonexistent binary and opt_dirs excluded
    test_path = get_bin_path('bar')
    assert test_path is None

    # Test with existing binary and opt_dirs excluded
    test_path = get_bin_path('bash')
    assert test_path is not None

# Generated at 2022-06-22 21:53:19.475572
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test when provided executable is found in PATH
    assert get_bin_path('true') == '/bin/true'

    # Test when provided executable is not found in PATH
    failed = False
    try:
        get_bin_path('non-existent-bin')
    except ValueError:
        failed = True
    assert failed

    # Test when provided executable is found in provided opt_dirs
    assert get_bin_path('true', opt_dirs=['/bin']) == '/bin/true'

    # Test when provided executable is not found in provided opt_dirs
    failed = False
    try:
        get_bin_path('true', opt_dirs=['/non-existent-dir'])
    except ValueError:
        failed = True
    assert failed

    # Test when provided executable is found in sbin
    assert get

# Generated at 2022-06-22 21:53:26.065452
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    opt_dirs = []
    opt_dirs.append('/usr/bin')
    assert get_bin_path('sh', opt_dirs) == '/bin/sh'
    opt_dirs.append('/bin')
    assert get_bin_path('sh', opt_dirs) == '/bin/sh'

# Generated at 2022-06-22 21:53:37.169322
# Unit test for function get_bin_path
def test_get_bin_path():

    test_data = [{'arg': 'ls', 'opt_dirs': None, 'path': '/bin/ls'},
                 {'arg': 'test_not_in_path', 'opt_dirs': ['/bin', '/sbin'], 'path': '/sbin/test_not_in_path'},
                 {'arg': 'test_not_in_path', 'opt_dirs': None, 'exception': 'Failed to find required executable "test_not_in_path" in paths:'},
                 ]

    # Test get_bin_path

# Generated at 2022-06-22 21:53:49.254110
# Unit test for function get_bin_path
def test_get_bin_path():
    import platform

    # TODO: The regex in this test should be further constrained based on the
    # executable we're attempting to find.
    def assert_bin_path(executable):
        get_bin_path(executable)

    try:
        assert_bin_path('ansible')
    except ValueError as err:
        if platform.system() == 'Windows':
            assert 'Failed to find required executable "ansible"' in err
        else:
            assert 'Failed to find required executable "ansible" in paths:{0}'.format(os.pathsep) in err
    else:
        assert False


# Generated at 2022-06-22 21:53:53.871686
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with command that doesn't exist
    try:
        get_bin_path('xxxxxyyyyyzzzzz')
        assert False, 'Did not raise exception'
    except ValueError:
        pass

    # Test with command that exists
    get_bin_path('ls')

# Generated at 2022-06-22 21:54:00.061693
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with single arg
    assert get_bin_path('sh') == '/bin/sh'

    # Test with executable not in PATH
    try:
        get_bin_path('sh', opt_dirs=['/foo/bar'])
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError not raised'

    # Test with wrong arg_name
    try:
        get_bin_path('foo')
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError not raised'

# Generated at 2022-06-22 21:54:05.301178
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/true') == '/bin/true'
    assert get_bin_path('./utils.py') == os.getcwd() + '/utils.py'

    with open('/etc/passwd', 'wt') as f:
        f.write('')
    os.chmod('/etc/passwd', 0)

    # No exception when file is found but not executable
    get_bin_path('/etc/passwd', required=False)

    try:
        get_bin_path('/not/exist')
        raise RuntimeError('get_bin_path did not raise ValueError')
    except ValueError:
        pass

# Generated at 2022-06-22 21:54:13.497295
# Unit test for function get_bin_path
def test_get_bin_path():
    import os

    os.environ['PATH'] = '/usr/bin:/bin'
    os.environ['HOME'] = '/home/foo'
    path = get_bin_path('ls')
    assert path == '/bin/ls'
    try:
        get_bin_path('this-is-not-an-executable')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

# Generated at 2022-06-22 21:54:21.684712
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    import stat

    test_exec = b'#!/bin/sh\nexit 0\n'
    test_path = None
    test_exists = None
    test_executable = None


# Generated at 2022-06-22 21:54:26.792528
# Unit test for function get_bin_path
def test_get_bin_path():
    required = False
    opt_dirs = ['/opt/myapp/bin']
    # Find system executable in PATH
    get_bin_path('cat', opt_dirs, required)
    # Find app executable in opt_dirs
    get_bin_path('test_app', opt_dirs, required)

# Generated at 2022-06-22 21:54:36.083270
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    td = tempfile.mkdtemp()
    # setup the test
    touch(os.path.join(td, 'foo'))
    touch(os.path.join(td, 'bar'))
    os.chmod(os.path.join(td, 'foo'), 0o755)  # make it executable

    # test
    assert get_bin_path('foo', opt_dirs=[td]) == os.path.join(td, 'foo')
    assert get_bin_path('bar', opt_dirs=[td]) == os.path.join(td, 'bar')

    # cleanup
    shutil.rmtree(td)



# Generated at 2022-06-22 21:54:37.130774
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat')



# Generated at 2022-06-22 21:54:42.182385
# Unit test for function get_bin_path
def test_get_bin_path():
    existing_file = '/etc'
    missing_file = '/xxx/yyy/zzz'
    existing_exec = '/bin/ls'
    missing_exec = missing_file
    existing_bin_path = get_bin_path('ls')
    assert existing_bin_path == existing_exec
    try:
        get_bin_path(missing_file)
        assert False
    except ValueError:
        pass
    try:
        get_bin_path(missing_exec)
        assert False
    except ValueError:
        pass

# Generated at 2022-06-22 21:54:51.322008
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic


    if basic.HAS_PYTHON26:
        import sys


        def test_get_bin_path_fakewrite(arg, opt_dirs=None, required=None):
            return '/fakewrite'


        sys.modules['ansible.module_utils.common.file'] = type('', (), {'is_executable': lambda x: True})
        try:
            get_bin_path = test_get_bin_path_fakewrite
            assert get_bin_path('prog_not_found') == '/fakewrite'
        finally:
            get_bin_path = get_bin_path_real
            reload(basic)



# Generated at 2022-06-22 21:55:02.307540
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check for required executable in paths
    bin_path = get_bin_path('git')
    assert is_executable(bin_path)

    # Check that executable is not found in paths
    try:
        bin_path = get_bin_path('git_missing')
    except ValueError:
        pass
    else:
        assert False, "ValueError not raised"

    # Check that executable is not found
    try:
        bin_path = get_bin_path('git_missing', opt_dirs=['/usr/bin'])
    except ValueError:
        pass
    else:
        assert False, "ValueError not raised"

    # Check that executable is found
    bin_path = get_bin_path('git', opt_dirs=['/usr/bin'])

# Generated at 2022-06-22 21:55:02.725616
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-22 21:55:13.549313
# Unit test for function get_bin_path
def test_get_bin_path():
    binpath = get_bin_path('python3')
    assert binpath is not None
    assert os.path.exists(binpath)
    assert binpath == '/usr/bin/python3'
    binpath = get_bin_path('python3', opt_dirs=['/bin', '/usr/local/bin'])
    assert os.path.exists(binpath)
    assert binpath == '/usr/bin/python3'
    binpath = get_bin_path('python3', opt_dirs=['/usr/local/bin', '/usr/bin'])
    assert os.path.exists(binpath)
    assert binpath == '/usr/bin/python3'
    binpath = get_bin_path('python3', opt_dirs=['/usr/local/bin', '/bin'])
   

# Generated at 2022-06-22 21:55:24.940521
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    # Skip on win32 as we don't have bash
    if sys.platform == 'win32':
        return
    # Test different locations
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('nc') == '/usr/bin/nc'
    assert get_bin_path('ifconfig') == '/sbin/ifconfig'
    assert get_bin_path('non-existing-binary') == None

    # Test with PATH and opt_dirs
    os.environ['PATH'] += ':/bin:/opt/bin:/opt/local/bin'
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('nc') == '/usr/bin/nc'

# Generated at 2022-06-22 21:55:35.280925
# Unit test for function get_bin_path
def test_get_bin_path():

    # Test that find system executable in PATH
    assert get_bin_path('sh')
    assert get_bin_path('ls')
    assert get_bin_path('cat')

    # Test that find system executable in PATH with '/usr/local/sbin'
    assert get_bin_path('sh', opt_dirs=['/usr/local/sbin'])
    assert get_bin_path('ls', opt_dirs=['/usr/local/sbin'])
    assert get_bin_path('cat', opt_dirs=['/usr/local/sbin'])

    # Test that find system executable in PATH with '/usr/local/sbin', '/sbin'
    assert get_bin_path('sh', opt_dirs=['/usr/local/sbin', '/sbin'])
    assert get_bin_

# Generated at 2022-06-22 21:55:40.755443
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('sh') == '/bin/sh')
    assert(get_bin_path('invalid-command', ['/usr/local/bin']) == '/usr/local/bin/invalid-command')
    assert(get_bin_path('sh', ['/invalid/path']) == '/bin/sh')

# Generated at 2022-06-22 21:55:48.553635
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('bash') == '/bin/bash' or '/bin/bash'
    assert get_bin_path('bash', ['/usr/local/bin']) == '/usr/local/bin/bash' or '/usr/local/bin/bash'
    try:
        assert get_bin_path('bash', ['/bin']) == '/bin/bash' or '/bin/bash'
    except ValueError:
        assert True, "Failed to use first result as in default path order"

# Validate that the required parameter behaves as documented

# Generated at 2022-06-22 21:55:59.051405
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    # simulate PATH not existing to force failure
    saved_path = None
    if 'PATH' in os.environ:
        saved_path = os.environ['PATH']
        del os.environ['PATH']

    try:
        # failure to find python2
        if sys.version_info < (3,):
            with pytest.raises(ValueError):
                python2 = get_bin_path('python2', required=True)
    finally:
        if saved_path is not None:
            os.environ['PATH'] = saved_path

    # successful find
    python2 = get_bin_path('python2', required=True)
    assert python2 == sys.executable
    os.access(python2, os.X_OK) == True

# Generated at 2022-06-22 21:56:11.326358
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test in a virtualenv
    assert get_bin_path('python') == os.path.join(os.path.dirname(__file__), 'python')
    assert get_bin_path('python').endswith('python')

    assert get_bin_path('python', None, True).endswith('python')
    assert get_bin_path('python', ['/usr/bin'], True).endswith('python')
    assert get_bin_path('python', ['/usr/bin'], True).endswith('python')
    assert get_bin_path('python', ['/usr/bin', '/usr/sbin'], True).endswith('python')
    assert get_bin_path('bash', None, True).endswith('bash')


# Generated at 2022-06-22 21:56:22.552260
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/sbin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin', '/sbin']) == '/bin/ls'
    assert get_bin_path('/bin/ls', opt_dirs=['/usr/bin', '/sbin', '/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/sbin', '/bin']) == '/bin/ls'

# Generated at 2022-06-22 21:56:24.317271
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-22 21:56:32.847803
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no-such-executable')
    except ValueError as e2:
        assert 'Failed to find required executable' in str(e2)
    assert get_bin_path('python') == '/usr/bin/python'
    assert os.path.isfile(get_bin_path('python'))
    assert os.path.isfile(get_bin_path('python', opt_dirs=[os.path.dirname(__file__)]))
    assert get_bin_path('echo', opt_dirs=[os.path.dirname(__file__)]) == '/bin/echo'

# Generated at 2022-06-22 21:56:42.437148
# Unit test for function get_bin_path
def test_get_bin_path():
    # Call get_bin_path and check it raises exception
    try:
        get_bin_path('notaexecutable')  # Missing executable
        assert False
    except ValueError as e:
        msg = str(e)
        assert 'Failed to find required executable "notaexecutable"' in msg
        assert len(msg) > 0

    # Call get_bin_path with list of directories
    assert get_bin_path('notaexecutable', opt_dirs=['/a/b', '/c/d']) is None
    try:
        get_bin_path('notaexecutable', opt_dirs=['/a/b', '/c/d'], required=True)
        assert False
    except ValueError as e:
        msg = str(e)

# Generated at 2022-06-22 21:56:53.683685
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    from ansible.module_utils.common.file import is_executable
    from tempfile import mkdtemp
    from shutil import copy, rmtree
    import stat
    import os

    tests_dir = os.path.dirname(os.path.abspath(__file__))
    resources_dir = os.path.join(tests_dir, 'resources')

    @pytest.fixture(scope='module', autouse=True)
    def testcase(request):
        # create a temporary directory and set $PATH to include it
        test_temp_dir = mkdtemp(prefix='tmp.get_bin_path.')

        # copy the shell scripts to the temporary directory
        copy(os.path.join(resources_dir, 'foo.sh'), test_temp_dir)

# Generated at 2022-06-22 21:56:57.901733
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("true")
    assert get_bin_path("paths", opt_dirs=["/bin", "/sbin", "/usr/bin", "/usr/sbin"])


# Generated at 2022-06-22 21:57:06.908886
# Unit test for function get_bin_path
def test_get_bin_path():
    # This test only works from the test directory or from the directory above
    if not os.path.exists('lib/ansible/module_utils/basic.py'):
        os.chdir('ansible')
    if not os.path.exists('lib/ansible/module_utils/basic.py'):
        raise Exception('Unable to find basic module directory')
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_bin_path

    module = AnsibleModule(
        argument_spec=dict(),
    )

    try:
        get_bin_path('no_such_command')
    except ValueError as ve:
        pass
    else:
        raise Exception('Expected ValueError')

    # Verify we can find a command which is in the path and not in

# Generated at 2022-06-22 21:57:12.741076
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', required=False) == '/usr/bin/python'
    assert get_bin_path('python', required=True) == '/usr/bin/python'
    try:
        get_bin_path('idonotexist')
        assert False, 'Expected get_bin_path to throw exception'
    except:
        pass

# Generated at 2022-06-22 21:57:25.345410
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.file import missing_file, missing_directory
    import tempfile
    import shutil
    import signal

    # do not use tempfile.mkdtemp(), since it can fail on some systems.
    # Instead, create a directory in a known path.
    dpath = tempfile.gettempdir()
    dpath = os.path.join(dpath, 'ansible_test_dir')


# Generated at 2022-06-22 21:57:31.827966
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest, tempfile
    with tempfile.NamedTemporaryFile() as f:
        os.chmod(f.name, 0o755)
        assert f.name == get_bin_path(os.path.basename(f.name), opt_dirs=[os.path.dirname(f.name)])
        os.chmod(f.name, 0o000)
        with pytest.raises(ValueError):
            get_bin_path(os.path.basename(f.name), opt_dirs=[os.path.dirname(f.name)])

# Generated at 2022-06-22 21:57:36.715805
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') is not None
    try:
        get_bin_path('this-path-is-not-possible-at-all')
        assert False, "Exception should have been raised"
    except ValueError:
        pass

# Generated at 2022-06-22 21:57:45.934092
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    from ansible.module_utils.common._text import to_native
    from ansible.module_utils.common.file import actual_user

    # Test executable in $PATH
    assert get_bin_path('sh') == '/bin/sh'

    # Test executable NOT in $PATH
    with pytest.raises(ValueError) as ex:
        get_bin_path('not_sh')

    assert 'Failed to find required executable "not_sh" in paths:' in to_native(ex.value)

    # Test executable in $PATH and opt_dirs
    assert get_bin_path('sh', opt_dirs=['/bin', '/usr/bin']) == '/bin/sh'

    # Test executable NOT in $PATH but in opt_dirs

# Generated at 2022-06-22 21:57:50.788493
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('which') == '/usr/bin/which'
    assert get_bin_path('python3') == '/usr/bin/python3'

# Generated at 2022-06-22 21:57:51.428703
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-22 21:57:56.367018
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # test existence of executable
        get_bin_path('sh')

        # test non-existence of executable
        get_bin_path('nonexistent_command')
    except ValueError as e:
        assert "Failed to find required executable nonexistent_command in paths:" in str(e)
    except Exception:
        assert False

# Generated at 2022-06-22 21:58:06.308738
# Unit test for function get_bin_path
def test_get_bin_path():
    test_bin = 'test_ansible_shell.py'

    test_dir = 'test_dir'
    test_path = os.path.join(test_dir, test_bin)
    test_dir_paths = [os.path.abspath(os.path.join('..', test_dir))]
    test_env = 'TEST_PATH'
    test_env_path = os.path.abspath(os.path.join('..', test_dir))
    # Write a test executable to test directory
    open(test_path, 'a').close()

    # Test: should raise ValueError for non-existent file
    test_exists = False

# Generated at 2022-06-22 21:58:12.212719
# Unit test for function get_bin_path
def test_get_bin_path():

    from os import pathsep
    from tempfile import mkdtemp
    from shutil import rmtree

    from ansible.module_utils.basic import AnsibleModule

    def exec_path(m, pathnames):
        m.exit_json(changed=False, stdout=pathsep.join(pathnames), stderr='')

    module = AnsibleModule(
        argument_spec={
            'arg': dict(default='curl'),
            'opt_dirs': dict(default=None, type='list'),
            'required': dict(default=None, type='bool'),
        },
        supports_check_mode=False,
    )

    exec_path(module, os.environ.get('PATH', '').split(os.pathsep))

    tmpdirname = None
    pathnames = []
   

# Generated at 2022-06-22 21:58:16.281825
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('cat')
    assert bin_path == '/bin/cat'

    bin_path = get_bin_path('cat', opt_dirs=['/opt/bin/'])
    assert bin_path == '/opt/bin/cat'

# Generated at 2022-06-22 21:58:26.050513
# Unit test for function get_bin_path
def test_get_bin_path():
    for i in ['python', 'python2', 'python2.7']:
        print('Find python executable in PATH')
        print('Found: %s' % get_bin_path(i))
    print('Try to find executable with non existing name')
    try:
        get_bin_path('does_not_exist')
        raise Exception('test should have failed')
    except ValueError as e:
        print('As expected: %s' % str(e))
    print('Try to find executable with non existing name and non existing directories')

# Generated at 2022-06-22 21:58:37.493913
# Unit test for function get_bin_path
def test_get_bin_path():
    # sanity check default
    test_exec = 'ls'
    assert get_bin_path(test_exec) == '/bin/ls'

    # check that we find test_exec in /bin
    test_exec = 'touch'
    assert get_bin_path(test_exec) == '/bin/touch'

    # check that we find test_exec in /usr/bin
    test_exec = 'python'
    assert get_bin_path(test_exec) == '/usr/bin/python'

    # check that we find test_exec in /usr/local/bin
    test_exec = 'git'
    assert get_bin_path(test_exec) == '/usr/local/bin/git'

    # check that we find test_exec in /sbin
    test_exec = 'lvm'
    assert get_bin_

# Generated at 2022-06-22 21:58:44.005990
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check that non existing executable raises properly
    try:
        get_bin_path(None)
        assert False, "get_bin_path(None) should raise ValueError"
    except ValueError as e:
        assert "required executable" in str(e), "get_bin_path(None) raised an unexpected exception: %s" % str(e)
    except Exception as e:
        assert False, "get_bin_path(None) raised an unexpected exception: %s" % str(e)

# Generated at 2022-06-22 21:58:52.629108
# Unit test for function get_bin_path
def test_get_bin_path():
    # Testing existence
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/ls', ['/usr/bin']) == '/bin/ls'

    # Testing non-existence
    try:
        get_bin_path('asdfasdfasdf')
        assert False, 'Expected ValueError'
    except ValueError:
        pass

    # Testing non-existence with opt_dirs
    try:
        get_bin_path('asdfasdfasdf', ['/bin'])
        assert False, 'Expected ValueError'
    except ValueError:
        pass

# Generated at 2022-06-22 21:59:00.349892
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test get_bin_path()
    try:
        get_bin_path('false')
    except ValueError as e:
        assert False
    try:
        get_bin_path('false', required=True)
    except ValueError as e:
        assert False
    try:
        get_bin_path('false', required=False)
    except ValueError as e:
        assert False
    try:
        get_bin_path('false', ['.'])
    except ValueError as e:
        assert False
    try:
        get_bin_path('false', ['.'], True)
    except ValueError as e:
        assert False
    try:
        get_bin_path('nonsense', ['.'], False)
    except ValueError as e:
        assert True

# Generated at 2022-06-22 21:59:11.847808
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import subprocess

    # Create a test directory in temp with some bogus executables
    temp_dir = tempfile.mkdtemp(prefix='get_bin_path_test')
    bin_dir = os.path.join(temp_dir, 'bin')
    os.mkdir(bin_dir)
    with open(os.path.join(bin_dir, 'ansible'), 'w') as f:
        f.write('#!/bin/sh\necho "ansible"\n')
    os.chmod(os.path.join(bin_dir, 'ansible'), 0o777)

# Generated at 2022-06-22 21:59:20.902544
# Unit test for function get_bin_path
def test_get_bin_path():
    # Success
    if os.path.exists('/bin/ls'):
        assert get_bin_path('ls') == '/bin/ls'
    else:
        assert get_bin_path('dir') == '/bin/dir'

    # No required arg
    assert get_bin_path(required=False, arg='dir') == '/bin/dir'

    # Required arg and found
    assert get_bin_path(required=True, arg='dir') == '/bin/dir'

    # Required arg and not found
    try:
        get_bin_path('FAKE', ['.'])
    except ValueError as e:
        assert "Failed to find required executable 'FAKE'" in str(e)
    else:
        assert False, "Expected Exception"

    # Optional directory (does not exist)
    assert get_bin

# Generated at 2022-06-22 21:59:32.157928
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('/bin/ls', opt_dirs=['/usr/bin']) == '/bin/ls'
    for path in ['/bin', '/usr/bin', '/usr/local/bin']:
        assert get_bin_path('ls', opt_dirs=[path]) == path + '/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/local/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/usr/local/bin']) == '/usr/bin/ls'

# Generated at 2022-06-22 21:59:42.662254
# Unit test for function get_bin_path
def test_get_bin_path():
    #
    # Test 1. Modify PATH environment variable in test to simulate finding
    #         command in /sbin directory.
    #
    old_path = os.environ.get('PATH')
    program = 'ip'
    os.environ['PATH'] = '/sbin:' + os.environ.get('PATH', '')
    path = get_bin_path(program)
    assert path == '/sbin/ip'
    # Restore PATH environment variable
    if old_path is None:
        del os.environ['PATH']
    else:
        os.environ['PATH'] = old_path

    #
    # Test 2. Find command in specified location.
    #
    path = get_bin_path('ls', ['/bin'])
    assert path == '/bin/ls'

    #
    # Test 3

# Generated at 2022-06-22 21:59:52.151314
# Unit test for function get_bin_path
def test_get_bin_path():
    bp = get_bin_path('/bin/cat')
    assert '/bin/cat' == bp
    bp = get_bin_path('cat', opt_dirs=None)
    assert '/bin/cat' == bp
    bp = get_bin_path('cat', opt_dirs=['/bin'])
    assert '/bin/cat' == bp
    try:
        bp = get_bin_path('cat', ['/no_bin'], required=True)
        assert False
    except ValueError as e:
        assert 'Failed to find required executable "cat"' in str(e)

# Generated at 2022-06-22 22:00:00.800738
# Unit test for function get_bin_path
def test_get_bin_path():

    # Test1: Test get_bin_path without arguments
    assert get_bin_path('python') == '/usr/bin/python'

    # Test2: Test get_bin_path with opt_dirs argument
    assert get_bin_path('python', opt_dirs=[]) == '/usr/bin/python'

    # Test3: Assert get_bin_path raises ValueError if executable is not found
    try:
        get_bin_path('some_non_existing_executable')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

# Generated at 2022-06-22 22:00:06.240451
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/local/bin']) == '/usr/local/bin/python'
    assert get_bin_path('does_not_exist', opt_dirs=['/usr/local/bin']) == ValueError

# Generated at 2022-06-22 22:00:15.400102
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile

    d = tempfile.mkdtemp()

# Generated at 2022-06-22 22:00:25.639043
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import sys

    if sys.platform.startswith('freebsd'):
        # In FreeBSD 12 /sbin/route is not executable-only
        # https://bugs.freebsd.org/bugzilla/show_bug.cgi?id=237164
        exc_route = get_bin_path('route')
        assert exc_route.endswith('route')
        return

    exc_route = get_bin_path('route')
    assert exc_route.endswith('route')

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-22 22:00:30.623957
# Unit test for function get_bin_path
def test_get_bin_path():
    foo = 'foo'
    expected_pass_paths = [
        '/bin/foo',
        '/usr/bin/foo',
        '/usr/local/bin/foo',
        '/sbin/foo',
        '/usr/sbin/foo',
        '/usr/local/sbin/foo']

    bin_path = get_bin_path(foo)
    assert bin_path in expected_pass_paths
    assert os.path.exists(bin_path)
    assert not os.path.isdir(bin_path)
    assert is_executable(bin_path)

    try:
        get_bin_path('foo_not_exists')
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "foo_not_exists" in paths: ' + os.path

# Generated at 2022-06-22 22:00:41.972280
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('ls')
    assert bin_path is not None

    try:
        get_bin_path('non-existent-program-foo')
        assert False
    except ValueError:
        # Expected to fail
        pass

    bin_path = get_bin_path('ls', opt_dirs=['/bin', '/usr/bin'])
    assert bin_path is not None

    bin_path = get_bin_path('ls', opt_dirs=['/usr/bin'])
    assert bin_path is not None

    bin_path = get_bin_path('ls', opt_dirs=['', '/usr/bin'])
    assert bin_path is not None

# Generated at 2022-06-22 22:00:49.898109
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function
    '''
    paths_test = [
        ('/bin/ls', None, '/bin/ls'),
        ('/no_bin/ls', None, None),
        ('/bin/ls', '/sbin', '/sbin/ls'),
        ('/no_bin/ls', '/sbin', None),
    ]

# Generated at 2022-06-22 22:01:00.243932
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    if sys.platform.startswith('sunos'):
        # On SmartOS, /usr/bin/python is something that requires a
        # userland build, but 'python' is v2.6 from base.  For the
        # purposes of this test, use v2.6
        python = 'python2.6'
    elif os.path.exists('/usr/bin/python2'):
        python = 'python2'
    else:
        python = 'python'
    bin_path = get_bin_path(python, ['/usr/bin'])
    assert bin_path == '/usr/bin/python'

test_get_bin_path()

# Generated at 2022-06-22 22:01:09.171503
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    cur_dir = os.path.dirname(os.path.realpath(__file__))

    # Create temp directory for testing
    tmp_dir = tempfile.mkdtemp()

    # Create test script
    bin_name = '/test_bin'
    bin_path = tmp_dir + bin_name
    bin_content = '#!/bin/sh\n'

    with open(bin_path, 'w') as f:
        f.write(bin_content)
    os.chmod(bin_path, 0o755)

    # Test common cases
    assert get_bin_path(bin_name, []) == tmp_dir + bin_name
    assert get_bin_path(bin_name) == tmp_dir + bin_name

    # Test with /sbin in the list of directories
   

# Generated at 2022-06-22 22:01:12.640909
# Unit test for function get_bin_path
def test_get_bin_path():
    # The tar executable should always be available on any Linux or OSX system
    tar = get_bin_path("tar")
    assert tar == "/usr/bin/tar"

# Generated at 2022-06-22 22:01:21.755304
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/bin/sh'
    try:
        get_bin_path('sh', ['/usr/bin'], required=False)
    except ValueError:
        pass
    try:
        get_bin_path('sh', opt_dirs=['/usr/bin'], required=False)
    except ValueError:
        pass