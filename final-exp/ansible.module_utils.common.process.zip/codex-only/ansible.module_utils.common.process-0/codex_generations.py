

# Generated at 2022-06-22 21:51:22.548323
# Unit test for function get_bin_path
def test_get_bin_path():
    expected = '/bin/ls'
    assert get_bin_path('ls') == expected
    assert get_bin_path('ls', ['/bin', '/usr/bin']) == expected
    assert get_bin_path('ls', ['/usr/bin']) == expected
    assert get_bin_path('ls', ['/bin']) == expected
    assert get_bin_path('ls', ['/usr/bin', '/bin']) == expected
    assert get_bin_path('ls', ['/bin', '/usr/bin']) == expected
    assert get_bin_path('ls', ['/not-bin', '/usr/bin']) == expected
    assert get_bin_path('ls', ['/bin', '/not-bin']) == expected
    assert get_bin_path('ls', ['/bin', '/usr/bin']) == expected

# Generated at 2022-06-22 21:51:29.003066
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('true') == '/bin/true'
    assert get_bin_path('false') == '/bin/false'
    assert get_bin_path('false', opt_dirs=['/usr/bin']) == '/usr/bin/false'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) != '/usr/bin/ls'
    assert get

# Generated at 2022-06-22 21:51:31.328898
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('hostname')
    assert os.path.exists(path) and os.path.isfile(path) and is_executable(path)

# Generated at 2022-06-22 21:51:40.326208
# Unit test for function get_bin_path
def test_get_bin_path():
    cur_path = os.path.dirname(os.path.realpath(__file__))
    test_path = os.path.normpath(os.path.join(cur_path, '..', '..', 'bin', 'ansible-2.13.0'))
    test_bin = 'ansible-playbook'
    test_file = os.path.join(test_path, test_bin)
    if os.path.exists(test_file):
        os.environ['PATH'] = test_path + os.pathsep + os.environ['PATH']
        bin = get_bin_path(test_bin)
        if os.path.exists(bin):
            assert os.path.isfile(bin)
            assert os.access(bin, os.X_OK)

# Generated at 2022-06-22 21:51:49.752883
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for existing executable in PATH
    assert get_bin_path('true', ['/usr/bin']) == '/usr/bin/true'

    # Test for executable not in PATH
    try:
        get_bin_path('/usr/bin/should_not_exist')
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "/usr/bin/should_not_exist" in paths: /sbin:/usr/sbin:/usr/local/sbin'
    else:
        raise Exception('ValueError expected but not raised')

    # Test for executable when PATH is empty
    os.environ['PATH'] = ''

# Generated at 2022-06-22 21:51:57.727976
# Unit test for function get_bin_path
def test_get_bin_path():
    path = ''
    for p in os.environ['PATH'].split(os.pathsep):
        if os.path.exists(os.path.join(p, 'whoami')) and is_executable(os.path.join(p, 'whoami')):
            path = p
            break

    assert get_bin_path('whoami', ['/usr/bin/X11']) == os.path.join(path, 'whoami')
    assert get_bin_path('whoami', ['/usr/bin/X11', path]) == os.path.join(path, 'whoami')

# Generated at 2022-06-22 21:52:07.591033
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    # Create temporary directory and files
    tmpdir = tempfile.mkdtemp()
    test_dir = os.path.join(tmpdir, "test1")
    test_dir2 = os.path.join(tmpdir, "test2")
    test_dir3 = os.path.join(tmpdir, "test3")
    test_file = os.path.join(test_dir, "testfile")
    test_file2 = os.path.join(test_dir, "testfile2")
    test_file3 = os.path.join(test_dir, "testfile3")
    os.makedirs(os.path.dirname(test_file), 0o777)
    os.makedirs(os.path.dirname(test_file2), 0o777)

# Generated at 2022-06-22 21:52:14.479578
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('this_command_does_not_exist')
        assert False, 'Expected ValueError'
    except ValueError:
        pass

    assert get_bin_path('sh')

    dirs = ['/bin', '/usr/bin', '/usr/local/bin']

    def mock_exists(path):
        return path in dirs

    import __main__
    __main__.os.path.exists = mock_exists

    assert get_bin_path('sh') == '/bin/sh'



# Generated at 2022-06-22 21:52:23.604347
# Unit test for function get_bin_path

# Generated at 2022-06-22 21:52:35.761941
# Unit test for function get_bin_path
def test_get_bin_path():
    test_paths = ['/opt/path_one', '/opt/path_two']
    res = get_bin_path('subdir/test', test_paths)
    assert res == '/opt/path_one/subdir/test'

    test_paths = ['', '/opt/path_one', '', '/opt/path_two', '']
    res = get_bin_path('subdir/test', test_paths)
    assert res == '/opt/path_one/subdir/test'

    test_paths = ['', '/usr/sbin', '/usr/local/sbin']
    res = get_bin_path('subdir/test', test_paths)
    assert res == '/usr/sbin/subdir/test'


# Generated at 2022-06-22 21:52:44.307067
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    import ansible.module_utils.basic
    orig_paths = os.environ.get('PATH', '').split(os.pathsep)
    temp_dir = tempfile.mkdtemp()
    temp_path = os.path.join(temp_dir, 'test_path')
    os.mkdir(temp_path)
    shutil.copy(ansible.module_utils.basic.__file__, temp_path)

    # test when path is None
    bin_path = get_bin_path('python', opt_dirs=None, required=False)
    assert bin_path.endswith(os.path.join('bin', 'python'))

    # test when path is a directory

# Generated at 2022-06-22 21:52:52.948907
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile

    def test_bin_path(expected_return, path, executable):
        env = os.environ.copy()
        env['PATH'] = path
        return_value = get_bin_path(executable, required=False, paths=paths)
        assert expected_return == return_value

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()
    # Create a bin directory
    bindir = os.path.join(tmpdir, "bin")
    os.mkdir(bindir)

    paths = []
    sys_executable = os.path.join(bindir, "sh")
    paths.append(bindir)

    # Create an executable in bin dir
    open(sys_executable, "w").close()
    # Set permission for executable

# Generated at 2022-06-22 21:53:01.963617
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Unit test for function get_bin_path'''
    # only run this test on a posix system
    import platform
    if platform.system() != 'Linux':
        return

    cmd = 'cp'
    bin_path = get_bin_path(cmd)
    assert bin_path == '/bin/cp'

    # not found on this system
    cmd = 'foobar_baz_command_not_found'
    try:
        get_bin_path(cmd)
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    else:
        assert False, 'Expected ValueError, command not found'

# Generated at 2022-06-22 21:53:10.876857
# Unit test for function get_bin_path
def test_get_bin_path():
    test_required = ['test_required', 'test']
    test_optional = ['test_optional', 'test']
    for test in [test_required, test_optional]:
        for path in ['/bin', '/sbin', '/usr/sbin']:
            test.append('%s/%s' % (path, test[1]))

    old_environ = dict(os.environ)
    test_environ = dict(os.environ)
    test_environ['PATH'] = '/usr/bin'
    os.environ = test_environ


# Generated at 2022-06-22 21:53:17.460123
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    tempdir = tempfile.mkdtemp()

    # Create dummy executable
    dummy_cmd = 'echo'
    dummy_path = os.path.join(tempdir, dummy_cmd)
    with open(dummy_path, 'w') as f:
        f.write('#!/bin/sh\necho $@')
    os.chmod(dummy_path, 0o755)


# Generated at 2022-06-22 21:53:27.893976
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('marker.py') == '/path/to/marker.py'
    assert get_bin_path('marker.sh') == '/path/to/marker.sh'
    assert get_bin_path('../marker.py') == '/path/to/marker.py'
    assert get_bin_path('../marker.sh') == '/path/to/marker.sh'
    assert get_bin_path('../marker.sh', opt_dirs=['/extra/path']) == '/extra/path/marker.sh'
    assert get_bin_path('../marker.sh', opt_dirs=['/extra/path', '/another/path']) == '/extra/path/marker.sh'

# Generated at 2022-06-22 21:53:38.068492
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    # Test for a required executable that does not exist
    try:
        get_bin_path('does_not_exist', required=True)
        assert False
    except ValueError:
        pass

    # Test for a required executable that exists
    result = get_bin_path(sys.executable, required=True)
    assert result == sys.executable

    # Test for a required executable that does not exist but can be found in opt_dirs
    result = get_bin_path('cat', opt_dirs=['/bin', '/usr/bin'], required=True)
    assert result == '/bin/cat'

    # Test for a required executable that does not exist but can be found in opt_dirs

# Generated at 2022-06-22 21:53:47.098286
# Unit test for function get_bin_path
def test_get_bin_path():
    def fake_find_executable(name):
        return name

    import __builtin__

    __builtin__.__dict__['find_executable'] = fake_find_executable
    __builtin__.__dict__['is_executable'] = lambda x: x
    try:
        result = get_bin_path('echo')
        assert result.endswith('echo'), 'Failed to find echo'
    finally:
        del __builtin__.__dict__['find_executable']
        del __builtin__.__dict__['is_executable']

# Generated at 2022-06-22 21:53:53.058243
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == get_bin_path('python', [])
    from ansible.module_utils.six import PY3
    if PY3:
        assert get_bin_path('python') == 'python'
    else:
        assert get_bin_path('python') == 'python'
    assert get_bin_path('python', ['/usr', '/usr/bin/local']) == get_bin_path('python', [])

# Generated at 2022-06-22 21:53:58.376564
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('date')
    assert bin_path == '/bin/date'

    with pytest.raises(ValueError):
        get_bin_path('foo')

    bin_path = get_bin_path('ps', ['/bin'])
    assert bin_path == '/bin/ps'

    with pytest.raises(ValueError):
        get_bin_path('ps', ['/sbin'])

# Generated at 2022-06-22 21:54:01.393053
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('/bin/sh') == '/bin/sh'

# Generated at 2022-06-22 21:54:11.065346
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_bin = os.path.join(test_dir, 'bin')
    os.mkdir(test_bin)
    test_exe = os.path.join(test_bin, 'exe')
    with open(test_exe, 'w') as f:
        f.write('#!/bin/bash')

# Generated at 2022-06-22 21:54:16.656243
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for success
    assert get_bin_path('env')

    # Test for success when opt_dirs is provided
    opt_dirs = ['/bin', '/usr/bin']
    assert get_bin_path('env', opt_dirs)

    # Test for failure when opt_dirs is provided but executable is not found
    opt_dirs = ['/bin', '/usr/bin']
    try:
        assert get_bin_path('foo', opt_dirs)
        assert False
    except Exception as e:
        assert 'Failed to find required executable "foo" in paths: /bin:/usr/bin' == str(e)

    # Test for failure when required is provided

# Generated at 2022-06-22 21:54:27.757051
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat
    import os

    old_env = os.environ.copy()

    # Remove temporary binary directory
    def remove_bin_dir(bin_dir):
        shutil.rmtree(bin_dir)

    # Create a temporary binary directory, add it to PATH and create a tmp test binary
    tmp = tempfile.mkdtemp()

# Generated at 2022-06-22 21:54:37.058525
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import sys
    my_path = tempfile.mkdtemp()


# Generated at 2022-06-22 21:54:39.568729
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('ls')
    assert os.path.exists(bin_path)

# Generated at 2022-06-22 21:54:40.510115
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-22 21:54:50.933108
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

# Generated at 2022-06-22 21:55:01.938911
# Unit test for function get_bin_path
def test_get_bin_path():
    from shutil import rmtree
    from tempfile import mkdtemp

    new_path = mkdtemp()


# Generated at 2022-06-22 21:55:05.554984
# Unit test for function get_bin_path
def test_get_bin_path():
    test_bin_path = get_bin_path('python')
    test_bin_path = get_bin_path('python', required=True)
    assert test_bin_path == '/usr/bin/python'

# Generated at 2022-06-22 21:55:10.699415
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['/bin', '/usr/bin', '/usr/local/bin']
    # test valid path
    assert get_bin_path('ls', paths) == '/bin/ls'
    # test invalid path
    try:
        get_bin_path('fake_bin', paths)
    except ValueError:
        pass


# Generated at 2022-06-22 21:55:21.980750
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Function to test get_bin_path function
    '''

    # tests
    assert get_bin_path('cat', opt_dirs=['/usr/bin', '/bin']) == '/bin/cat'
    assert get_bin_path('ip', opt_dirs=['/usr/bin', '/sbin', '/usr/sbin']) == '/sbin/ip'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ip', opt_dirs=['/usr/bin', '/usr/sbin']) == '/usr/sbin/ip'
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-22 21:55:33.235919
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ['PATH'] = 'test_PATH'
    assert get_bin_path('python', opt_dirs=['/usr/bin']) == '/usr/bin/python'
    os.environ['PATH'] = None
    assert get_bin_path('python', opt_dirs=['/usr/bin']) == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/bin', '/usr/local/bin']) == '/usr/local/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/bin'], required=True) == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=[], required=True) == '/usr/bin/python'
    assert get_bin_path

# Generated at 2022-06-22 21:55:40.317897
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    tempdir = tempfile.mkdtemp()

    path = get_bin_path('date', opt_dirs=[tempdir])
    assert path == '/bin/date'
    path = get_bin_path('date', opt_dirs=['/foo/bar'])
    assert path == '/bin/date'

    os.symlink('/bin/date', os.path.join(tempdir, 'date'))
    path = get_bin_path('date', opt_dirs=[tempdir])
    assert path == os.path.join(tempdir, 'date')

    os.symlink('/foo/bar', os.path.join(tempdir, 'date'))

# Generated at 2022-06-22 21:55:52.175219
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import tempfile

    # test for failure cases & required not set
    fake_executable = 'iamnothere'
    try:
        get_bin_path(fake_executable)
    except ValueError as e:
        assert fake_executable in str(e)

    # create fake executable in temp directory


# Generated at 2022-06-22 21:55:55.641601
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("ls") == "/bin/ls"
    assert get_bin_path("ls", opt_dirs=['/usr/bin', '/bin']) == "/bin/ls"
    assert get_bin_path("ls", opt_dirs=['/usr/bin', '/bin', '/usr/sbin']) == "/bin/ls"
    assert get_bin_path("ls", opt_dirs=['/bin', '/usr/bin', '/usr/sbin']) == "/bin/ls"
    assert get_bin_path("ls", opt_dirs=['/usr/sbin', '/usr/bin', '/bin']) == "/bin/ls"
    assert get_bin_path("ls", opt_dirs=['/usr/sbin', '/bin', '/usr']) == "/bin/ls"


# Generated at 2022-06-22 21:55:56.985859
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'



# Generated at 2022-06-22 21:56:08.078601
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('fancy-does-not-exist-executable-sir')
    except ValueError:
        pass
    else:
        assert False, "there should've been an exception"

    assert get_bin_path('sh') is not None, "we should be able to find sh in the path"

    try:
        get_bin_path('ansible', ['/usr/bin'])
    except ValueError:
        pass
    else:
        assert False, "there should've been an exception"

    assert get_bin_path('ansible', [os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))]) is not None, "we should find ansible if it's in the given path"

# Generated at 2022-06-22 21:56:16.750662
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('python', opt_dirs=None, required=True)
    assert bin_path is not None

    # No arg raises exception
    try:
        get_bin_path(None, required=True)
        assert False
    except ValueError:
        pass

    # Not found raises exception
    try:
        get_bin_path('notfoundexecutable', required=True)
        assert False
    except ValueError:
        pass

    # Empty path
    bin_path = get_bin_path('python', opt_dirs=[''], required=True)
    assert bin_path is not None

    # Deprecated required parameter
    bin_path = get_bin_path('python', opt_dirs=[''], required=False)

# Generated at 2022-06-22 21:56:17.651840
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-22 21:56:23.294316
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('nohup') == '/usr/bin/nohup'
    try:
        get_bin_path('adefnohupthatdoesntexist')
    except ValueError as e:
        assert 'Failed to find' in str(e)
    assert get_bin_path('sh', ['/usr/bin']) == '/usr/bin/sh'

# Generated at 2022-06-22 21:56:34.283536
# Unit test for function get_bin_path
def test_get_bin_path():
    # should return /bin/bash
    path = get_bin_path('bash')
    assert path.endswith('/bin/bash')
    assert os.path.exists(path)
    assert not os.path.isdir(path)
    assert is_executable(path)

    # should return /sbin/service
    path = get_bin_path('service', opt_dirs=['/usr/bin', '/usr/sbin'])
    assert path.endswith('/sbin/service')
    assert os.path.exists(path)
    assert not os.path.isdir(path)
    assert is_executable(path)

    # should throw an Exception if not found
    try:
        get_bin_path('this command does not exists')
    except ValueError as e:
        assert re

# Generated at 2022-06-22 21:56:43.294595
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/ls', []) == '/bin/ls'
    assert get_bin_path('/bin/ls', ['/bin']) == '/bin/ls'
    assert get_bin_path('/bin/ls', ['/tmp']) == '/bin/ls'
    assert get_bin_path('../bin/ls', ['/tmp']) == '/bin/ls'
    assert get_bin_path('ls', ['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', ['.', '/bin', '/usr/bin']) == '/bin/ls'

# Generated at 2022-06-22 21:56:51.232352
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert(get_bin_path('echo') == '/bin/echo')
        assert(get_bin_path('echo', opt_dirs=['/bin']) == '/bin/echo')
        assert(get_bin_path('echo', opt_dirs=['/foo/bar']) == '/bin/echo')
        from pathlib import Path
        assert(get_bin_path('echo', opt_dirs=[Path('/bin/echo')]) == '/bin/echo')
    except ValueError:
        assert(False)

# Generated at 2022-06-22 21:56:57.412713
# Unit test for function get_bin_path
def test_get_bin_path():
    valid_path = get_bin_path('/bin/ls')
    valid_path2 = get_bin_path('ls')
    assert valid_path == valid_path2

    import pytest
    with pytest.raises(ValueError):
        get_bin_path('/some/bogus/path/ls')
    with pytest.raises(ValueError):
        get_bin_path('bogusCommand')

# Generated at 2022-06-22 21:56:59.884319
# Unit test for function get_bin_path
def test_get_bin_path():
    if is_executable('/bin/ls'):
        assert (get_bin_path('ls') == '/bin/ls')



# Generated at 2022-06-22 21:57:00.980230
# Unit test for function get_bin_path
def test_get_bin_path():
    result = get_bin_path('python')
    return result

# Generated at 2022-06-22 21:57:12.656146
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    if sys.platform == 'win32':
        assert get_bin_path(arg='ipconfig', opt_dirs=None) == 'C:\\Windows\\system32\\ipconfig.exe'
        assert get_bin_path(arg='ipconfig', opt_dirs=[r'C:\Windows\System32']) == 'C:\\Windows\\system32\\ipconfig.exe'
        assert get_bin_path(arg='ipconfig', opt_dirs=['/bin']) == 'C:\\Windows\\system32\\ipconfig.exe'
        assert get_bin_path(arg='ipconfig', opt_dirs=[r'C:\Program Files']) == 'C:\\Windows\\system32\\ipconfig.exe'

# Generated at 2022-06-22 21:57:25.195073
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('python')
    assert path
    assert os.path.exists(path)
    assert not os.path.isdir(path)
    assert is_executable(path)

    opt_dirs = ['/usr/bin', '/usr/sbin/']
    path = get_bin_path('python', opt_dirs)
    assert path
    assert os.path.exists(path)
    assert not os.path.isdir(path)
    assert is_executable(path)

    try:
        get_bin_path('this_should_not_exist')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    else:
        assert False, 'ValueError should have been raised'


# Generated at 2022-06-22 21:57:33.431987
# Unit test for function get_bin_path
def test_get_bin_path():
    # returns full path to command, expected has to be full path
    expected = '/bin/ls'
    # optional add_dir not present in PATH
    result = get_bin_path('ls', opt_dirs=['/bin'])
    assert expected == result

    expected = '/bin/ls'
    # optional add_dir not present in PATH
    result = get_bin_path('ls', opt_dirs=['/bin'])
    assert expected == result

    expected = '/usr/bin/firefox'
    # optional add_dir already in PATH
    result = get_bin_path('firefox', opt_dirs=['/usr/bin'])
    assert expected == result

    # no optional directories
    expected = '/bin/ls'
    # optional add_dir not present in PATH

# Generated at 2022-06-22 21:57:37.935047
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    # Create a fake executable file in temporary directory
    testexec = tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False)
    testexec.write('#!/usr/bin/python\nprint "testexec"')
    testexec.close()
    assert get_bin_path(testexec.name) == testexec.name
    os.remove(testexec.name)

# Generated at 2022-06-22 21:57:48.312808
# Unit test for function get_bin_path
def test_get_bin_path():
    def test_bin_path(arg, opt_dirs, required=None, expected=None):
        if expected is None:
            expected = get_bin_path(arg, opt_dirs=opt_dirs, required=required)

# Generated at 2022-06-22 21:57:55.211318
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('true')

    # search PATH
    try:
        get_bin_path('not-there')
    except ValueError:
        pass
    else:
        assert False, 'expected ValueError'

    # search opt_dirs
    try:
        get_bin_path('true', opt_dirs=[os.getcwd()])
    except ValueError:
        pass
    else:
        assert False, 'expected ValueError'

# Generated at 2022-06-22 21:58:05.595252
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('not-a-valid-binary')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
        assert 'not-a-valid-binary' in str(e)

    try:
        get_bin_path('whatis')
        assert True
    except ValueError as e:
        assert False

    try:
        get_bin_path('whatis', opt_dirs=['/bin'])
        assert True
    except ValueError as e:
        assert False

    try:
        get_bin_path('whatis', opt_dirs=['/bin', '/usr/bin'])
        assert True
    except ValueError as e:
        assert False


# Generated at 2022-06-22 21:58:16.227563
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        import __builtin__ as builtins  # pylint: disable=import-error
    except ImportError:
        import builtins  # pylint: disable=import-error

    bin_path = get_bin_path('sh', ['/bin', '/usr/bin'])
    assert bin_path == '/bin/sh'

    class MockFileException(Exception):
        pass

    class MockFile(object):
        def __init__(self, name):
            self.name = name
            self.count = 0

        def __enter__(self):
            if self.count > 0:
                raise MockFileException(self.name)
            self.count += 1
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass


# Generated at 2022-06-22 21:58:19.213389
# Unit test for function get_bin_path
def test_get_bin_path():
    # Placeholder for future unittest
    assert get_bin_path('cat') == '/bin/cat'
    assert is_executable(get_bin_path('cat'))

# Generated at 2022-06-22 21:58:23.404542
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'

# Generated at 2022-06-22 21:58:30.547357
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert bin_path and os.path.exists(bin_path)
    # Returned bin_path should be absolute, not relative
    assert bin_path.startswith(os.path.sep)
    # Bad executable name
    try:
        cmd_path = get_bin_path('bashabcdefg')
        assert False, 'Bin path for non-existent executable should throw an exception'
    except ValueError:
        pass

# Generated at 2022-06-22 21:58:41.416835
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/bin/sh'
    try:
        get_bin_path('lkajsdflksajdfl')
    except ValueError:
        pass
    else:
        assert False, "get_bin_path() did not raise ValueError"

    try:
        get_bin_path('lkajsdflksajdfl', required=True)
    except ValueError:
        pass
    else:
        assert False, "get_bin_path() did not raise ValueError"


# Generated at 2022-06-22 21:58:51.029221
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # Test succeed
    temp_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_dir, "test_get_bin_path"))
    path = get_bin_path("test_get_bin_path", [temp_dir])
    assert path == os.path.join(temp_dir, "test_get_bin_path")

    # Test fail
    os.remove(os.path.join(temp_dir, "test_get_bin_path"))
    try:
        get_bin_path("test_get_bin_path", [temp_dir])
    except ValueError:
        assert True
    else:
        assert False

    os.rmdir(os.path.join(temp_dir, "test_get_bin_path"))

# Generated at 2022-06-22 21:58:59.493560
# Unit test for function get_bin_path
def test_get_bin_path():
    class BaseTest:

        def test_get_bin_path(self):
            self.assertEqual(get_bin_path('sh'), '/bin/sh')

    # Skip test_get_bin_path's unit test on Windows
    if os.name == 'nt':
        return

    # Other tests for function get_bin_path
    class OptDirsTest(BaseTest):

        def test_get_bin_path(self):
            self.assertEqual(get_bin_path('sh', opt_dirs=['/bin']), '/bin/sh')


# Generated at 2022-06-22 21:59:05.184663
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import py

    # Test for mac or linux
    if sys.platform not in ('darwin', 'linux2', 'linux'):
        pytest.skip('test_get_bin_path is currently only supported on OSX and linux')

    pytest.importorskip('pytest')

    # test_1: use 'python' as executable, PATH should contain python
    try:
        path = get_bin_path('python')
    except ValueError:
        py.test.skip('test_1: python is not in PATH')
    path_split = path.split('/')
    # check that first 10 chars match python. The rest of the path can differ depending on test system.
    assert(path_split[-1][0:10] == 'python2.7')

    # test_2: use unknown executable, should

# Generated at 2022-06-22 21:59:16.561503
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Execute with unittest
    python -m ansible.module_utils.common.get_bin_path
    '''
    import unittest
    import tempfile

    # Prepare
    class TestGetBinPath(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.gettempdir()

        def test_find_ansible_executable(self):
            try:
                self.assertTrue('ansible' in os.environ['PATH'])
            except KeyError:
                self.skipTest('Unable to locate executable "ansible" in PATH')
            ansible = get_bin_path('ansible')
            self.assertTrue('/ansible' in ansible)

        def test_find_python_executable(self):
            python = get_

# Generated at 2022-06-22 21:59:26.072873
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('which') == '/usr/bin/which'
    assert get_bin_path('/usr/bin/which') == '/usr/bin/which'
    assert get_bin_path('which', opt_dirs=['/usr/bin']) == '/usr/bin/which'
    try:
        get_bin_path('nonexistent')
    except ValueError as e:
        assert "Failed to find required executable" in str(e)
    try:
        get_bin_path('nonexistent', opt_dirs=['/usr/bin'])
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

# Generated at 2022-06-22 21:59:34.536497
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['/path/to/path', '/path/to/bin', '/path/to/sbin']
    try:
        get_bin_path('non-existant', paths)
    except ValueError as ex:
        assert 'non-existant' in ex.args[0]

    try:
        get_bin_path('sh')
    except ValueError:
        assert False, 'should not raise value error for built-in /bin/sh'

    # control test for 'sh'
    # expected /bin/sh path
    assert '/bin/sh' == get_bin_path('sh', ['/bin'])

# Generated at 2022-06-22 21:59:39.669417
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('fubar') == '/bin/fubar'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    assert get_bin_path('fubar', opt_dirs=['/bin']) == '/bin/fubar'
    assert get_bin_path('fubar', opt_dirs=['/sbin']) == '/sbin/fubar'

# unit test for module

# Generated at 2022-06-22 21:59:51.853156
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Test 1: Search for existing executable in ${PATH}
    """
    # Create a temporary file
    tmpfile_name = "tmp_file.txt"
    tmpfile = open(tmpfile_name, "w")
    tmpfile.close()

    # Make it executable
    os.chmod(tmpfile_name, 0o777)

    # Check if the above file exists in paths
    try:
        bin_path = get_bin_path(tmpfile_name)
    except ValueError:
        assert False

    # Check if the real path is returned
    assert os.path.realpath(bin_path) == os.path.realpath(tmpfile_name)

    # Remove the temporary file
    os.remove(tmpfile_name)



# Generated at 2022-06-22 22:00:03.863472
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python2') == '/usr/bin/python2'
    assert get_bin_path('python3') == '/usr/bin/python3'
    assert get_bin_path('ansible-vault') == '/usr/bin/ansible-vault'
    import sys

    assert get_bin_path(sys.executable) == sys.executable

    import tempfile

    temp_dir = tempfile.mkdtemp()
    with open(os.path.join(temp_dir, 'test_get_bin_path'), 'w') as fp:
        fp.write('#!/bin/bash\n')
    assert get_bin_path('test_get_bin_path', opt_dirs=[temp_dir, os.path.join(temp_dir, 'not-exist')]) == os

# Generated at 2022-06-22 22:00:11.984299
# Unit test for function get_bin_path

# Generated at 2022-06-22 22:00:23.765717
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import tempfile
    import shutil

    def touch(path):
        with open(path, 'a'):
            os.utime(path, None)

    # create a temporary directory
    tmpdir = tempfile.mkdtemp(prefix='ansible-tmp-test_get_bin_path')

    # create a file named 'test'
    test_file = os.path.join(tmpdir, 'test')
    touch(test_file)
    os.chmod(test_file, 0o755)

    # create a directory named 'test'
    test_directory = os.path.join(tmpdir, 'test')
    os.mkdir(test_directory)

    # create a file named 'test' in test_directory

# Generated at 2022-06-22 22:00:34.701504
# Unit test for function get_bin_path
def test_get_bin_path():
    # This function raises a ValueError under certain conditions and we have to have a try/except around the unit test.
    # Refer to: https://docs.python.org/3/library/unittest.html#skipping-tests-and-expected-failures
    # pylint: disable=protected-access
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule as _AnsibleModule
    from ansible.module_utils.common.parameters import _get_bin_path

    # The following is a set of tests for the get_bin_path() method.
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements


# Generated at 2022-06-22 22:00:46.216286
# Unit test for function get_bin_path
def test_get_bin_path():
    test_arg = 'ls'
    # Test: find the executable in PATH
    test_result = get_bin_path(test_arg)
    test_expected = '/bin/ls'
    assert test_result == test_expected
    # Test: find the executable in PATH with a custom search path
    test_result = get_bin_path(test_arg, opt_dirs=['/usr/bin', '/bin', '/usr/local/bin'])
    test_expected = '/bin/ls'
    assert test_result == test_expected
    # Test: find the executable in PATH with a custom search path and a directory not exists
    test_result = get_bin_path(test_arg, opt_dirs=['/usr/bin', '/bin', '/usr/local/bin', '/not_exist'])

# Generated at 2022-06-22 22:00:57.921305
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import sys

    # create basic file structure
    test_dir = tempfile.mkdtemp()
    test_bin_dir = os.path.join(test_dir, 'bin')
    test_sbin_dir = os.path.join(test_dir, 'sbin')
    os.makedirs(test_bin_dir)
    os.makedirs(test_sbin_dir)

    # create a few dummy files
    for exe in ['foo', 'foo.exe', 'bar', 'baz']:
        open(os.path.join(test_bin_dir, exe), 'w').close()
        open(os.path.join(test_sbin_dir, exe), 'w').close()

    # test with no PATH set
    os.environ

# Generated at 2022-06-22 22:01:08.618732
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin/']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin/', '/usr/local/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bad/dir', '/usr/bin/']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bad/dir', '/usr/bin/', '/usr/local/bin']) == '/bin/ls'

# Generated at 2022-06-22 22:01:21.139369
# Unit test for function get_bin_path
def test_get_bin_path():
    def do_test(arg, expected, opt_dirs, expected_error=False):
        try:
            ret = get_bin_path(arg, opt_dirs)
            assert ret == expected
        except ValueError as e:
            assert expected_error
            assert str(e) == 'Failed to find required executable "%s" in paths: %s' % (arg, os.pathsep.join(opt_dirs))

    do_test('ls', '/bin/ls', [])
    do_test('ls', '/bin/ls', ['/usr/bin'])
    do_test('ls', '/usr/bin/ls', ['/usr/bin'])
    do_test('ls', '/bin/ls', ['/usr/bin', '/bin'])