

# Generated at 2022-06-22 21:51:24.329928
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('python')
    assert bin_path == '/usr/bin/python'
    bin_path = get_bin_path('python', ['/usr/local/bin'])
    assert bin_path == '/usr/local/bin/python'
    bin_path = get_bin_path('python', ['/usr/local/bin', '/usr/bin'])
    assert bin_path == '/usr/bin/python'

# Generated at 2022-06-22 21:51:34.285810
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test passing an executable
    try:
        get_bin_path('python')
    except ValueError:
        assert False, 'Could not find python executable'

    # Test passing a nonexecutable
    try:
        # ??? What's a better way to do this
        get_bin_path('python%d.%d' % (sys.version_info[0], sys.version_info[1]))
    except ValueError:
        assert True, 'Bad test: python executable has a version number'
    except:
        pass

    # Test passing a nonexistant executable
    try:
        get_bin_path('doesnotexist')
        assert False, 'Found nonexistent executable'
    except ValueError:
        assert True, 'Correctly did not find nonexistent executable'

    # Test passing a directory

# Generated at 2022-06-22 21:51:42.851691
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import sys
    import ansible.module_utils.basic

    try:
        tempdir = tempfile.mkdtemp()
        tfile = tempfile.NamedTemporaryFile('w', dir=tempdir)
        tfile.write("#!/usr/bin/python\nprint('Hello world!')")
        tfile.flush()
        os.chmod(tfile.name, 0o755)
        path = get_bin_path(tfile.name, opt_dirs=[tempdir])

        if str(path).find(tempdir) == -1:
            raise Exception("File not found")
    except ValueError:
        raise Exception("File not found")
    finally:
        shutil.rmtree(tempdir)

# Generated at 2022-06-22 21:51:48.945416
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('thiscommanddoesnotexist')
        assert False
    except ValueError:
        assert True
    try:
        get_bin_path('thiscommanddoesnotexist', required=False)
        assert False
    except ValueError:
        assert True
    try:
        get_bin_path('thiscommanddoesnotexist', required=True)
        assert False
    except ValueError:
        assert True
    assert get_bin_path('ls')

# Generated at 2022-06-22 21:51:50.779217
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' test_get_bin_path '''
    assert get_bin_path('cat') == '/bin/cat'


# Generated at 2022-06-22 21:52:00.135126
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test default search path : should find python2
    bin_path = get_bin_path('python2')
    assert os.path.isfile(bin_path)
    # Test search path with additional directory provided
    # Should find python2 in /usr/bin and /usr/sbin
    bin_path = get_bin_path('python2', opt_dirs=[ '/usr/sbin', '/usr/bin'])
    assert os.path.isfile(bin_path)
    # Test search path with two additional directories provided
    # Should find python2 in /usr/sbin
    bin_path = get_bin_path('python2', opt_dirs=[ '/usr/sbin', '/usr/bin', '/bin'])
    assert os.path.isfile(bin_path)
    # Test search path with additional directories provided, but

# Generated at 2022-06-22 21:52:03.739496
# Unit test for function get_bin_path
def test_get_bin_path():
    python_bin_location = get_bin_path('python')
    assert python_bin_location

    try:
        get_bin_path('A_NONEXISTENT_BINARY')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-22 21:52:11.089372
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('sh')
    get_bin_path('sh', opt_dirs=['/bin'])
    get_bin_path('sh', opt_dirs=['/usr/bin'])
    get_bin_path('sh', opt_dirs=['/usr/local/bin'])
    get_bin_path('sh', opt_dirs=['/notexist'])  # Will raise exception


# Generated at 2022-06-22 21:52:20.999598
# Unit test for function get_bin_path
def test_get_bin_path():

    # test for existing executable in the PATH
    path = os.environ.get('PATH', '')
    os.environ['PATH'] = '/usr/bin'
    assert get_bin_path('python') == '/usr/bin/python'

    # test for existing executable in the PATH
    os.environ['PATH'] = '/usr/bin'
    assert get_bin_path('pyt[hon') is None

    # test for existing executable in the optional argument
    assert get_bin_path('python', ['/usr/sbin']) == '/usr/sbin/python'

    # test for existing executable in the optional argument
    assert get_bin_path('pyt[hon', ['/usr/sbin']) is None


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-22 21:52:24.955535
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/bash') == '/bin/bash'
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('bash') != '/bin/bash2'
    assert '/bin' == os.path.dirname(get_bin_path('bash'))

# Generated at 2022-06-22 21:52:36.437789
# Unit test for function get_bin_path
def test_get_bin_path():
    import collections

    TestCase = collections.namedtuple('TestCase', ['arg', 'opt_dirs', 'expected_result'])


# Generated at 2022-06-22 21:52:44.775937
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import sys
    import tempfile
    from shutil import rmtree
    from ansible.module_utils._text import to_bytes

    # Make a temp dir to check if a path is searched correctly
    tmp_path = tempfile.mkdtemp()
    os.chmod(tmp_path, 0o700)
    global python_path
    python_path = sys.executable
    tmp_binary = tempfile.mkstemp(dir=tmp_path)
    os.chmod(tmp_binary[1], 0o700)
    orig_path = os.environ['PATH']
    os.environ['PATH'] = orig_path + os.pathsep + tmp_path


# Generated at 2022-06-22 21:52:47.111097
# Unit test for function get_bin_path
def test_get_bin_path():

    try:
        get_bin_path('/bin/ls')
    except Exception as e:
        assert 'Failed to find required executable' in str(e)

# Generated at 2022-06-22 21:52:58.101600
# Unit test for function get_bin_path
def test_get_bin_path():
    '''test get_bin_path'''
    test_dir = os.path.dirname(os.path.dirname(__file__))
    mask = os.umask(0o077)
    os.umask(mask)
    tt = get_bin_path('python2.7')
    if tt is None or not os.path.exists(tt):
        raise AssertionError('Failed to find python to test with')
    os.mkdir(os.path.join(test_dir, 'test_data'))
    os.mkdir(os.path.join(test_dir, 'test_data', 'bin'))
    os.mkdir(os.path.join(test_dir, 'test_data', 'sbin'))

# Generated at 2022-06-22 21:53:02.101929
# Unit test for function get_bin_path
def test_get_bin_path():
    curr_path = os.getcwd() + os.sep + 'test'
    os.environ['PATH'] = curr_path
    assert get_bin_path('pwd') == curr_path + os.sep + 'pwd'

# Generated at 2022-06-22 21:53:03.538971
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("yes") == "/bin/yes"

# Generated at 2022-06-22 21:53:15.492891
# Unit test for function get_bin_path
def test_get_bin_path():
    import ansible.module_utils.basic

    test_path = os.path.join(os.path.dirname(__file__), 'utils_paths_data')
    arg1 = 'test_module_utils_basic_paths_binary'
    arg2 = 'test_module_utils_basic_paths_module.sh'
    arg3 = 'test_module_utils_basic_paths_notafile'
    arg4 = 'test_module_utils_basic_paths_notexecutable'

    # Check basic functionality, it should find the binary
    binary = ansible.module_utils.basic._get_bin_path(arg1, paths=[test_path])
    assert os.path.realpath(binary) == os.path.realpath(os.path.join(test_path, arg1))
    #

# Generated at 2022-06-22 21:53:25.358522
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('sh'))
    assert(get_bin_path('/bin/sh'))
    assert(get_bin_path('/usr/bin/ansible', ['/usr/bin']))
    opt_dirs = ['/bin', '/usr/bin']
    assert(get_bin_path('sh', opt_dirs=opt_dirs) == '/bin/sh')
    assert(get_bin_path('/bin/sh', opt_dirs=opt_dirs) == '/bin/sh')
    assert(get_bin_path('/usr/bin/ansible', opt_dirs=opt_dirs) == '/usr/bin/ansible')
    # Test with /sbin in opt_dirs
    opt_dirs = ['/sbin', '/usr/sbin']

# Generated at 2022-06-22 21:53:36.529467
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest

    # test with nonexistent executable in nonexistent path
    nonexistent_bin = '/path/to/nonexistent/bin'
    nonexistent_path = '/path/to/nonexistent/path'
    with pytest.raises(ValueError) as err:
        get_bin_path(nonexistent_bin, opt_dirs=[nonexistent_path])
    assert 'Failed to find' in str(err.value)
    assert nonexistent_bin in str(err.value)
    assert nonexistent_path in str(err.value)

    # test getting executable from sbin
    # note that test env may not have some of these dirs
    sbin_paths = ['/sbin', '/usr/sbin', '/usr/local/sbin']

# Generated at 2022-06-22 21:53:48.704385
# Unit test for function get_bin_path
def test_get_bin_path():
    from tempfile import mkdtemp
    from shutil import rmtree
    import warnings

    class TestExceptions(Exception):
        pass

    tmpdir = mkdtemp()
    test_bin = os.path.join(tmpdir, 'ansible-test-bin')
    open(test_bin, 'a').close()
    os.chmod(test_bin, 0o755)

    assert get_bin_path('ansible-test-bin', opt_dirs=[tmpdir], required=True) == test_bin

    rmtree(tmpdir)
    try:
        get_bin_path('ansible-test-bin', opt_dirs=[tmpdir], required=True)
    except TestExceptions:
        pass
    else:
        assert False, "get_bin_path() did not raise TestExceptions"


# Generated at 2022-06-22 21:53:49.909629
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'

# Generated at 2022-06-22 21:53:52.645781
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('ls')
    assert os.path.exists(bin_path)

# Generated at 2022-06-22 21:53:57.689615
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('true') == '/bin/true'
    assert get_bin_path('true', opt_dirs=['/usr/sbin']) == '/bin/true'
    try:
        get_bin_path('nonexistent-executable')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-22 21:54:05.546960
# Unit test for function get_bin_path
def test_get_bin_path():
    # Make sure the function raises an error if the executable is not found
    try:
        get_bin_path('nonexistent_executable')
    except ValueError:
        pass
    else:
        raise AssertionError('value error not raised')

    # Validate optional parameter required is now ignored
    try:
        get_bin_path('nonexistent_executable', required=True)
    except ValueError:
        pass
    else:
        raise AssertionError('value error not raised')

    # Make sure the function returns the full path when it is found
    path = get_bin_path('sh')
    assert os.path.exists(path)
    assert not os.path.isdir(path)
    assert is_executable(path)

# Generated at 2022-06-22 21:54:18.172665
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('cat')
    get_bin_path('ls', ['/bin', '/usr/bin'])
    get_bin_path('awk', required=True)
    try:
        get_bin_path('blah')
        assert False, 'get_bin_path did not raise error'
    except ValueError:
        pass
    try:
        get_bin_path('blah', required=True)
        assert False, 'get_bin_path did not raise error'
    except ValueError:
        pass
    get_bin_path('ls', ['/bin', '/usr/bin'])
    get_bin_path('cp', ['/bin', '/usr/bin'])
    get_bin_path('uname')
    get_bin_path('chmod')

# Generated at 2022-06-22 21:54:21.180297
# Unit test for function get_bin_path
def test_get_bin_path():
    p = get_bin_path('sh')
    assert is_executable(p)
    assert os.path.exists(p)
    assert 'sh' in p
    print(p)

# Generated at 2022-06-22 21:54:32.119462
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    import textwrap
    import unittest

    script_template = textwrap.dedent(u"""\
        #!/usr/bin/env python
        import sys
        print(sys.argv)
        """)

    class TestGetBinPath(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.bin_name = 'test_bin.py'
            self.path_dirs = [os.path.join(self.test_dir, 'opt_dir1'),
                              os.path.join(self.test_dir, 'opt_dir2')]
            self.script_path = os.path.join(self.test_dir, self.bin_name)

# Generated at 2022-06-22 21:54:40.156783
# Unit test for function get_bin_path
def test_get_bin_path():
    test_path = os.path.join(os.path.dirname(__file__), 'test-utils', 'bin')
    os.environ['PATH'] = test_path + os.pathsep + os.environ.get('PATH', '')
    test_bin_path = os.path.join(test_path, 'ansible-test-executable')

    assert get_bin_path('ansible-test-executable') == test_bin_path
    # for backwards compatibility optional arguments still work
    assert get_bin_path('ansible-test-executable', required=False) == test_bin_path
    assert get_bin_path('ansible-test-executable', opt_dirs=[test_path]) == test_bin_path


# Generated at 2022-06-22 21:54:47.833330
# Unit test for function get_bin_path
def test_get_bin_path():
    def mock_exists(path):
        if path == '/path/to/nonexisting':
            return False
        else:
            return True

    def mock_isdir(path):
        if path == '/path/to/nonexisting':
            return False
        elif path == '/bin/date':
            return False
        else:
            return True

    def mock_is_executable(path):
        if path == '/bin/date':
            return True
        else:
            return False

    import sys
    import __builtin__
    if sys.version_info >= (3, 0):
        import builtins as __builtin__  # pylint: disable=redefined-builtin

    # Test with 'date' existing as executable
    __builtin__.__dict__['os'].path.exists = mock

# Generated at 2022-06-22 21:54:58.652613
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    td = tempfile.mkdtemp()
    d = os.path.join(td, 'bin')
    os.makedirs(d)
    p = os.path.join(d, 'test_get_bin_path')
    with open(p, 'wt') as f:
        pass
    os.chmod(p, 0o755)
    cwd = os.getcwd()
    try:
        os.chdir(d)
        bp = get_bin_path('test_get_bin_path', [])
    finally:
        os.chdir(cwd)
        shutil.rmtree(td)
    assert os.path.join(d, 'test_get_bin_path') == bp

# Generated at 2022-06-22 21:55:01.937865
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Return path of binary and test it is executable'''
    testpath = '/bin/%s' % 'ls'
    testpath = get_bin_path('ls')
    assert(os.access(testpath, os.X_OK) is True)

# Generated at 2022-06-22 21:55:13.145438
# Unit test for function get_bin_path
def test_get_bin_path():
    # This isn't really a unit test, but it's close.  It's run as part of sanitize_module_tests.py

    assert get_bin_path('ls', ['/bin']) == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls' or get_bin_path('ls') == '/usr/bin/ls'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('/bin/ls', opt_dirs=['/home']) == '/bin/ls'

# Generated at 2022-06-22 21:55:21.656110
# Unit test for function get_bin_path
def test_get_bin_path():
    import os

    # Define paths that should be searched
    paths = ['/tmp', '/usr/bin', '/usr/sbin']
    # Define files that should be found
    files = ['foo', 'bar']
    # Define files that should not be found
    missing_files = ['baz']
    # Create the test files
    cwd = os.getcwd()
    for p in paths:
        if os.path.exists(p):
            continue
        os.mkdir(p)
    for f in files:
        with open(os.path.join('/tmp', f), 'a'):
            os.utime(os.path.join('/tmp', f), None)
    # Create a file that is not an executable

# Generated at 2022-06-22 21:55:25.906472
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no-such-executable')
        assert False
    except ValueError:
        pass
    assert get_bin_path('python')
    assert get_bin_path('python', opt_dirs=['/usr/bin'])

# Generated at 2022-06-22 21:55:36.056959
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/usr/bin/cat')
    except ValueError:
        assert False
    assert get_bin_path('cat') == '/usr/bin/cat'
    try:
        get_bin_path('no-such-file-exists')
    except ValueError:
        assert True
    try:
        get_bin_path('cat', required=True)
    except ValueError:
        assert True
    assert get_bin_path('cat', opt_dirs=['/usr/bin', '/usr/sbin']) == '/usr/bin/cat'
    assert get_bin_path('cat', opt_dirs=['/usr/sbin']) == '/usr/sbin/cat'

# Generated at 2022-06-22 21:55:43.608471
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('vi') == '/usr/bin/vi'
    assert get_bin_path('vi', opt_dirs=['/usr/bin', '/']) == '/usr/bin/vi'
    assert get_bin_path('vi', opt_dirs=['/usr/bin', '/'], required=True) == '/usr/bin/vi'
    import pytest
    with pytest.raises(ValueError):
        get_bin_path('non-existing binary')
    with pytest.raises(ValueError):
        get_bin_path('non-existing binary', required=True)

# Generated at 2022-06-22 21:55:50.635564
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' get_bin_path unit test'''
    bin_path = get_bin_path('ls')
    assert bin_path
    bin_path = get_bin_path('ls', opt_dirs=['/bin', '/usr/bin'])
    assert bin_path
    try:
        bin_path = get_bin_path('null_path')
    except:
        assert True

# Generated at 2022-06-22 21:56:00.465964
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat
    import os

    def touch(fname):
        open(fname, 'a').close()
        os.chmod(fname, stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)

    # Create empty/unreadable passes
    td = tempfile.mkdtemp(suffix='-test-get_bin_path')
    tdd = os.path.join(td, 'test1')
    tddd = os.path.join(td, 'test2')
    os.mkdir(tdd)
    os.mkdir(tddd)
    touch(os.path.join(td, 'test'))
    touch(os.path.join(tdd, 'test'))

# Generated at 2022-06-22 21:56:01.377952
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible') is not None

# Generated at 2022-06-22 21:56:13.422632
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1
    import sys
    if sys.version_info >= (3, 0):
        # Python 3
        try:
            get_bin_path('nonexistent_binary', required=False)
            raise Exception("Unexpected pass")
        except ValueError as e:
            if str(e) != 'Failed to find required executable "nonexistent_binary" in paths: %s' % (os.pathsep.join(os.environ.get('PATH', '').split(os.pathsep))):
                raise Exception("Unexpected exception text: " + str(e))

# Generated at 2022-06-22 21:56:17.378641
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test error condition
    try:
        get_bin_path("/bin/ddddddddddddddddddddddddd")
    except ValueError as e:
        assert("Failed to find required executable" in str(e), "Expected exception not raised")
    # Test success condition
    assert("/bin/chmod" == get_bin_path("chmod", ["/bin"]), "Expected path not returned")

# Generated at 2022-06-22 21:56:18.102642
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')

# Generated at 2022-06-22 21:56:26.622039
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path
    '''
    import tempfile
    import shutil
    from subprocess import check_output
    from ansible.module_utils.common.file import atomic_replace
    # Create temp directory for testing functions
    tmpdir = tempfile.mkdtemp()
    temp_module_path = os.path.join(tmpdir, 'foo.py')
    temp_module_path_with_shebang = os.path.join(tmpdir, 'foo_shebang.py')
    executable_module_path = os.path.join(tmpdir, 'foo_exec.py')
    env = {'PATH': ':'.join([tmpdir, os.environ['PATH']])}

# Generated at 2022-06-22 21:56:37.403875
# Unit test for function get_bin_path

# Generated at 2022-06-22 21:56:39.048031
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh', opt_dirs=['/']) == '/bin/sh'

# Generated at 2022-06-22 21:56:46.145498
# Unit test for function get_bin_path
def test_get_bin_path():
    import subprocess
    import tempfile

    my_env = os.environ.copy()

    # Creates a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary directory and add it to PATH
    tmpdir_in_path = tempfile.mkdtemp()
    if 'PATH' in my_env:
        my_env['PATH'] = tmpdir_in_path + os.pathsep + my_env['PATH']
    else:
        my_env['PATH'] = tmpdir_in_path

    # defines the executable
    prog1 = 'prog1'
    prog1_fullpath = os.path.join(tmpdir, prog1)

    # creates an executable file in the temporary directory
    open(prog1_fullpath, 'a').close()

# Generated at 2022-06-22 21:56:49.921087
# Unit test for function get_bin_path
def test_get_bin_path():
    # Find a command that exists (we assume we can always find 'get_bin_path')
    path = get_bin_path('get_bin_path')
    assert os.path.exists(path)
    assert os.path.isabs(path)

    # Look for a command that doesn't exist
    try:
        path = get_bin_path('bad_command')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-22 21:56:55.367053
# Unit test for function get_bin_path
def test_get_bin_path():
    expected_bin = '/bin/echo'
    assert expected_bin == get_bin_path('echo')

    expected_bin = '/usr/bin/sed'
    assert expected_bin == get_bin_path('sed')

    try:
        get_bin_path('this-does-not-exist')
    except ValueError:
        pass
    else:
        assert False, "get_bin_path() failed to raise ValueError for missing executable"

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-22 21:57:02.709298
# Unit test for function get_bin_path
def test_get_bin_path():
    # Create temporary file and set variable to point to it
    import tempfile
    f = tempfile.NamedTemporaryFile()
    os.environ["TEMP_BIN_PATH"] = f.name

    # Test using the environment variable and it should return the path to the file
    assert get_bin_path("$TEMP_BIN_PATH") == f.name
    # This should return the path to 'cat'
    assert get_bin_path("cat")
    # This should throw an error
    try:
        get_bin_path("not_a_real_program")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-22 21:57:07.261188
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('pip') == get_bin_path('pip')
    assert get_bin_path('pip', opt_dirs=['/usr/bin', '/usr/local/bin']) == get_bin_path('pip')

# Generated at 2022-06-22 21:57:15.849110
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    tempdir = tempfile.mkdtemp()

    bin = tempfile.NamedTemporaryFile(mode='w+', suffix='.bin', dir=tempdir, delete=False)
    bin.write('#!/bin/sh\nexit 0')
    bin.close()
    bin_name = bin.name
    os.chmod(bin_name, 0o755)

    subtempdir = tempfile.mkdtemp(dir=tempdir)

    bin_path = get_bin_path(os.path.basename(bin_name), opt_dirs=[os.path.dirname(bin_name)])
    assert bin_path == bin_name

    bin_path = get_bin_path(os.path.basename(bin_name), opt_dirs=[subtempdir])

# Generated at 2022-06-22 21:57:27.799986
# Unit test for function get_bin_path
def test_get_bin_path():

    # Test 1. Successful execution
    assert get_bin_path('facter') == '/home/ansible/test-playbook-1/venv/bin/facter'
    assert get_bin_path('facter', '/home/ansible/test-playbook-1/venv/bin/') == '/home/ansible/test-playbook-1/venv/bin/facter'
    assert get_bin_path('facter', opt_dirs=['/home/ansible/test-playbook-1/venv/bin/']) == '/home/ansible/test-playbook-1/venv/bin/facter'

    # Test 2. Failed execution of get_bin_path
    try:
        assert get_bin_path('fakebinary')
    except ValueError as e:
        assert e.args

# Generated at 2022-06-22 21:57:35.172241
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    assert get_bin_path('nosuchbinary', opt_dirs=['/bin']) == '/bin/nosuchbinary'
    from ansible.module_utils.six import PY3
    try:
        if PY3:
            get_bin_path('nosuchbinary')
        assert False
    except FileNotFoundError:
        assert True
    except Exception:
        assert False

# Generated at 2022-06-22 21:57:45.073907
# Unit test for function get_bin_path
def test_get_bin_path():
    test_good = 'date'
    test_bad = 'not_a_valid_date'
    test_path = '/usr/bin'
    test_opt_path = '/bin'
    test_additional_path = ['/sbin', '/usr/sbin', '/usr/local/sbin']

    # Test valid executable in standard path
    assert get_bin_path(test_good)

    # Test valid executable in a provided path
    assert get_bin_path(test_good, [test_path])

    # Test valid executable in standard path and provided path
    assert get_bin_path(test_good, [test_path, test_opt_path])

    # Test invalid executable in standard path and provided path

# Generated at 2022-06-22 21:57:51.832436
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    from ansible.module_utils import basic

    bin_path = get_bin_path(arg='/bin/cat')
    assert bin_path == '/bin/cat'

    with pytest.raises(ValueError) as exc:
        get_bin_path(arg='missing-executable')
    assert 'Failed to find required executable "missing-executable"' in str(exc)

# Generated at 2022-06-22 21:58:02.914915
# Unit test for function get_bin_path
def test_get_bin_path():
    testpaths = [
        '/tmp',
        '/usr/share/ansible']

    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('/bin/sh', opt_dirs=testpaths) == '/bin/sh'

    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('bash', opt_dirs=testpaths) == '/bin/bash'

    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=testpaths) == '/usr/bin/python'


# Generated at 2022-06-22 21:58:13.829253
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile

    tempdir = None
    orig_path = None
    try:
        with tempfile.NamedTemporaryFile() as tf:
            tempdir = tempfile.mkdtemp(prefix='ansible-tmp-get_bin_path-')
            test_exe = os.path.join(tempdir, 'test_exe')
            shutil.copy(tf.name, test_exe)
            os.chmod(test_exe, 0o755)
            orig_path = os.environ.get('PATH')
            os.environ['PATH'] = tempdir
            assert get_bin_path('test_exe') == test_exe
    finally:
        if tempdir is not None:
            shutil.rmtree(tempdir)
        if orig_path is not None:
            os

# Generated at 2022-06-22 21:58:24.434048
# Unit test for function get_bin_path
def test_get_bin_path():

    # test first get_bin_path must fail (required == True and no sudo in path)
    with pytest.raises(ValueError) as execinfo:
        get_bin_path("sudo", required=True)

    assert "Failed to find required executable" in str(execinfo.value)

    # test get_bin_path must succeed (required == False and no sudo in path)
    assert get_bin_path("sudo", required=False) == None

    # test get_bin_path must succeed (required == True and sudo in path)
    # $PATH will be already modified (see setup.py test_path())
    assert get_bin_path("sudo", required=True) == "/usr/bin/sudo"

    # test get_bin_path must succeed (required == True, sudo in path and opt_dirs)
    opt_dir

# Generated at 2022-06-22 21:58:34.715771
# Unit test for function get_bin_path
def test_get_bin_path():

    bin_path = get_bin_path('/bin/sh')
    assert bin_path == '/bin/sh'

    bin_path = get_bin_path('sh')
    assert bin_path == '/bin/sh'

    bin_path = get_bin_path('sh', ['/tmp'])
    assert bin_path == '/bin/sh'

    bin_path = get_bin_path('nonsense', ['/tmp'])
    assert bin_path == '/tmp/nonsense'

    # test failure mode
    try:
        bin_path = get_bin_path('nosuchthing_at_all')
        # This should never be reached
        assert False
    except ValueError:
        pass

# Generated at 2022-06-22 21:58:44.327827
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # Test get_bin_path
        get_bin_path("ls")
        assert True
    except ValueError:
        assert False
    try:
        # Test get_bin_path with missing argument
        get_bin_path("")
        assert False
    except ValueError:
        assert True
    try:
        # Test get_bin_path with missing path
        get_bin_path('/usr/bin/missing', ['/usr/bin'])
        assert False
    except ValueError:
        assert True
    try:
        # Test get_bin_path with optional path
        assert get_bin_path('/usr/bin/ls', ['/usr/bin']) == '/usr/bin/ls'
        assert True
    except ValueError:
        assert False

# Generated at 2022-06-22 21:58:56.125914
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("sh") == '/bin/sh'
    assert get_bin_path("python") == '/usr/bin/python'

# Import test_get_bin_path only if this file was directly called from command line
if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    # Create a dummy AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            test_param=dict(required=False)
        )
    )
    # Performs the unit test
    test_get_bin_path()
    # Check if any unexpected argument is present
    if module.params['test_param']:
        module.fail_json(msg='Unexpected argument present.')
    # All OK, return success

# Generated at 2022-06-22 21:59:05.202247
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.file import get_bin_path
    from ansible.module_utils._text import to_bytes

    # Tests to see if function will find executable in PATH
    try:
        find_bin = get_bin_path("find")
        found = True
    except ValueError:
        found = False
    assert found

    # Tests to see if function will raise Exception if executable is not found in PATH
    try:
        fake_bin = get_bin_path("fake")
    except ValueError:
        pass
    else:
        raise AssertionError("Function did not raise exception")

    # Tests to see if function will find executable in PATH and in optional directory
    # This test is tricky because it must perform the same logic as the function to determine if
    # the directory for the optional argument is valid.
    #

# Generated at 2022-06-22 21:59:06.537929
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible-doc')

# Generated at 2022-06-22 21:59:17.348557
# Unit test for function get_bin_path
def test_get_bin_path():
    # Should work
    assert get_bin_path('/bin/ls', opt_dirs=['/usr/local/sbin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/local/sbin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/local/sbin', '/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/local/sbin', '/bin', '/usr/bin', '/usr/local/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin', '/usr/local/bin', '/usr/local/sbin'])

# Generated at 2022-06-22 21:59:28.885087
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    # Check that get_bin_path raises an exception
    # if the executable was not found.
    try:
        get_bin_path('no_such_exec')
        assert False, 'An exception was not thrown'
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

    # Check that get_bin_path does not raise an exception
    # if the executable was found.
    temp_dir = tempfile.mkdtemp()
    with open(os.path.join(temp_dir, 'exec-file'), 'w') as f:
        f.write('#!/usr/bin/env bash\n')
        f.write('echo "Test"\n')

# Generated at 2022-06-22 21:59:37.993301
# Unit test for function get_bin_path
def test_get_bin_path():
    test_execs = [
        'ansible-doc',
        'ansible',
        'ip',
        'iptables'
        ]

    for e in test_execs:
        try:
            print(get_bin_path(e))
        except ValueError as e:
            print("%s: %s" % (e, e.args))
            raise


if __name__ == '__main__':
    """
    Execute module as a test case.

    python -m ansible.module_utils.common.file get_bin_path
    """
    test_get_bin_path()

# Generated at 2022-06-22 21:59:46.691166
# Unit test for function get_bin_path
def test_get_bin_path():

    import tempfile
    import shutil

    def _create_and_chmod(path, mode):
        from os import makedirs
        from os import chmod

        makedirs(os.path.dirname(path))

        fd = open(path, "w")
        fd.close()

        chmod(path, mode)

    def _create_executable(filename):
        path = os.path.join(test_path, filename)

        if os.path.exists(path):
            raise Exception("Cannot create the test executable %s: file already exists!" % path)


# Generated at 2022-06-22 21:59:54.967281
# Unit test for function get_bin_path
def test_get_bin_path():

    def get_bin_path_raises_error(arg, opt_dirs=None, required=False):
        raises = False
        try:
            get_bin_path(arg, opt_dirs, required)
        except ValueError:
            raises = True
        return raises
    test_path = '/usr/local/bin'
    assert get_bin_path('sh', [test_path], False) == '/usr/local/bin/sh'
    assert get_bin_path_raises_error('does_not_exist')
    assert get_bin_path('sh') == '/bin/sh'



# Generated at 2022-06-22 21:59:57.804004
# Unit test for function get_bin_path
def test_get_bin_path():
    print(get_bin_path('ls'))
    print(get_bin_path('/bin/ls'))
    print(get_bin_path('ls', ['/bin']))


# Generated at 2022-06-22 22:00:04.912533
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    from ansible.module_utils.common.file import is_executable

    test_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'fixtures', 'module_utils', 'test_get_bin_path')
    opt_dirs = [test_path]
    arg = 'executable'
    result = os.path.join(test_path, arg)
    assert not is_executable(result)

    for mode in range(0, 0o777, 64):
        os.chmod(result, mode)
        if is_executable(result):
            assert get_bin_path(arg, opt_dirs=opt_dirs) == result
        else:
            with pytest.raises(ValueError):
                get_bin_path

# Generated at 2022-06-22 22:00:05.984164
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible-playbook')

# Generated at 2022-06-22 22:00:11.287345
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import sys
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 22:00:23.446834
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test default path
    assert get_bin_path('ls') == '/bin/ls'

    # Test non-standard path
    assert get_bin_path('ls', ['/usr/bin']) == '/usr/bin/ls'

    # Test first of multiple matches
    assert get_bin_path('python2.6') == '/usr/bin/python2.6'

    # Test that missing executable raises ValueError
    try:
        get_bin_path('this-executable-not-exist')
    except ValueError as e:
        # ValueError: Failed to find required executable "this-executable-not-exist" in paths: /bin:/usr/bin:/usr/local/bin:/usr/sbin:/usr/local/sbin:/sbin
        assert True
    else:
        assert False  # Should not reach here

   

# Generated at 2022-06-22 22:00:34.375373
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common._collections_compat import MutableMapping

    if not isinstance(dict(), MutableMapping):
        assert True, "Deprecated 'ansible.module_utils.common._collections_compat.MutableMapping' is missing"
        return

    # Create a test directory and touch some files
    test_dir = '/tmp/ansible_test_dir_get_bin_path'
    test_file1 = test_dir + '/test_file1'
    test_file2 = test_dir + '/test_file2'
    test_file3 = test_dir + '/test_file3'
    test_file4 = test_dir + '/test_file4'
    test_file5 = test_dir + '/test_file5'

    # Define original environment for restoring it later

# Generated at 2022-06-22 22:00:45.954643
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Tests for function get_bin_path'''
    # Test that get_bin_path raises an exception when it can't find the executable.
    # We expect this to fail because ping is not in a directory in the PATH for
    # this test, and the sbin directories are not included
    try:
        get_bin_path('ping')
        assert False, "get_bin_path expected to fail"
    except ValueError:
        pass

    # With the sbin directories included, get_bin_path should now succeed
    try:
        get_bin_path('ping', [])
    except ValueError:
        assert False, "get_bin_path expected to succeed"

    # Test that the optional dir list argument works

# Generated at 2022-06-22 22:00:57.681483
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', ['/debian/ls']) == '/debian/ls'
    assert get_bin_path('ls', ['/debian/ls', '/bin/ls']) == '/debian/ls'
    assert get_bin_path('ls', opt_dirs=['/debian/ls', '/bin/ls']) == '/debian/ls'
    assert get_bin_path('ls', ['/debian/ls', '/bin/ls'], None) == '/debian/ls'
    assert get_bin_path('ls', ['/debian/ls', '/bin/ls'], False) == '/debian/ls'
    assert get_bin_path('ls', ['/debian/ls', '/bin/ls'], True) == '/debian/ls'


# Generated at 2022-06-22 22:01:08.442868
# Unit test for function get_bin_path
def test_get_bin_path():
    assert os.path.basename(get_bin_path('ls')) == 'ls'
    assert os.path.basename(get_bin_path('vim')) == 'vim'
    assert os.path.basename(get_bin_path('vim', required=True)) == 'vim'

    try:
        r = get_bin_path('dne')
    except ValueError:
        r = None

    assert r is None

    try:
        r = get_bin_path('dne', required=True)
    except ValueError:
        r = None

    assert r is None

    try:
        r = get_bin_path('dne', opt_dirs=['/dne'])
    except ValueError:
        r = None

    assert r is None

# Generated at 2022-06-22 22:01:13.771714
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ping') == '/bin/ping'
    assert get_bin_path('ping', ['/bin']) == '/bin/ping'
    assert get_bin_path('ping', ['/foo/bar']) == '/bin/ping'
    assert get_bin_path('ping', ['/sbin']) == '/sbin/ping'

# Generated at 2022-06-22 22:01:23.376779
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for Mac OS
    try:
        if 'Darwin' in get_bin_path('uname'):
            tr = get_bin_path('tr')
            assert tr
            assert os.path.basename(tr) == 'tr'
            assert os.path.exists(tr) and os.access(tr, os.X_OK)
            try:
                get_bin_path('zzz')
            except ValueError as e:
                assert 'Failed to find required executable "zzz" in paths: ' in str(e)
    except ValueError as e:
        print('Failed to find executable "tr" or "uname"')