

# Generated at 2022-06-22 21:51:22.841803
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("sh") == "/bin/sh"
    assert get_bin_path("/bin/sh") == "/bin/sh"
    assert get_bin_path("/bin/bash") == "/bin/bash"
    assert get_bin_path("cat") == "/bin/cat"
    assert get_bin_path("sort") == "/bin/sort"
    assert get_bin_path("tr") == "/bin/tr"
    assert get_bin_path("expr") == "/usr/bin/expr"
    assert get_bin_path("expr") == "/usr/bin/expr"
    assert get_bin_path("md5sum") == "/usr/bin/md5sum"
    assert get_bin_path("mktemp") == "/usr/bin/mktemp"

# Generated at 2022-06-22 21:51:25.370765
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['/usr/bin', '/usr/sbin', '/tmp']
    bp = get_bin_path('ls', path)
    assert bp in ['/usr/bin/ls', '/usr/sbin/ls', '/tmp/ls']

# Generated at 2022-06-22 21:51:35.578267
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    import stat

    # create tempfile and mark it executable
    fd, tmp_file = tempfile.mkstemp()
    os.close(fd)
    os.chmod(tmp_file, stat.S_IRWXU)
    tmp_file_name = os.path.basename(tmp_file)

    # Test case: when the file is not found in existing PATH
    try:
        get_bin_path(tmp_file_name)
    except ValueError:
        pass
    else:
        raise Exception('get_bin_path did not raise exception when file is not in PATH')

    # Test case: file is found in current PATH

# Generated at 2022-06-22 21:51:42.155272
# Unit test for function get_bin_path
def test_get_bin_path():
    orig_path = os.environ['PATH']
    os.environ['PATH'] = '/bin'
    assert get_bin_path('ls') == '/bin/ls'
    os.environ['PATH'] = '/bin:/usr/bin'
    assert get_bin_path('ls') == '/bin/ls'
    os.environ['PATH'] = '/bin:/usr/bin'
    assert get_bin_path('ls', ['/usr/local/bin']) == '/usr/local/bin/ls'
    os.environ['PATH'] = orig_path


# Generated at 2022-06-22 21:51:47.431566
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('ansible-playbook')
    assert bin_path == os.path.realpath(os.path.join(os.path.dirname(__file__), '..', '..', 'bin', 'ansible-playbook'))

    try:
        bin_path = get_bin_path('not-a-binary')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-22 21:51:51.471463
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("/bin/ls") == "/bin/ls"



# Generated at 2022-06-22 21:52:00.602340
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test cases:
    1) Test if absolute path is returned back, when there is a valid executable path.
    2) Test when executable is not present.
    3) Test when executable is present, but not an executable file(ex. a directory).
    4) Test when executable is present and executable, but not an absolute path.
    5) Test when executable is present, executable and an absolute path.
    '''
    # Test case 1
    try:
        assert get_bin_path('/bin/ls') == '/bin/ls'
    except ValueError:
        assert False, 'Failed to validate the return value for a valid absolute path'

    # Test case 2

# Generated at 2022-06-22 21:52:08.857618
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Test function get_bin_path '''
    import datetime
    import time
    import tempfile
    import shutil
    import string
    import random

    try:
        import pytest
    except ImportError:
        pytest = None

    test_data = [
        '/bin/sh',
        '/sbin/sh',
        '/usr/bin/true',
        '/usr/sbin/false',
        '/usr/local/bin/python3',
        '/usr/local/sbin/python3',
    ]
    random_bin = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
    arg = 'arg'
    opt_dirs = ['opt1', 'opt2']


# Generated at 2022-06-22 21:52:10.775330
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/true') == '/bin/true'
    assert get_bin_path('python') in ['/usr/bin/python', '/usr/local/bin/python']

# Generated at 2022-06-22 21:52:12.404044
# Unit test for function get_bin_path
def test_get_bin_path():
    result = get_bin_path('/bin/sh')
    assert result == '/bin/sh'


# Generated at 2022-06-22 21:52:22.118043
# Unit test for function get_bin_path
def test_get_bin_path():
    path_to_find_1 = '/usr/bin/env'
    path_to_find_2 = '/bin/sh'
    path_to_find_3 = '/usr/sbin/sshd'
    path_to_find_4 = '/usr/bin/openssl'
    path_to_find_5 = '/usr/bin/python'

    # Test with PATH defined
    os.environ['PATH'] = '/bin:/usr/bin:/usr/local/bin'
    assert get_bin_path(path_to_find_1) == path_to_find_1
    assert get_bin_path(path_to_find_2) == path_to_find_2
    assert get_bin_path(path_to_find_4) == path_to_find_4

# Generated at 2022-06-22 21:52:29.234257
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls', opt_dirs=['/opt/bin']) == '/opt/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/opt/bin', '/opt/sbin', '/opt/sbin']) == '/opt/bin/ls'

    assert get_bin_path('ls', opt_dirs=['/opt/bin', '/opt/sbin', '/opt/sbin']) == '/opt/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/opt/bin', '/opt/sbin', '/opt/sbin', '/bin']) == '/bin/ls'

# Generated at 2022-06-22 21:52:40.699318
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    import sys

    if PY3:
        executable = 'python3'
    else:
        executable = 'python'

    # Test with valid executable but without any path information
    bin_path = get_bin_path(executable)
    assert os.path.normpath(bin_path) == os.path.normpath(sys.executable)

    # Test with valid executable in path list
    bin_path = get_bin_path(executable, opt_dirs=['/usr/bin'])
    assert os.path.normpath(bin_path) == os.path.normpath(sys.executable).split('/usr/bin/')[-1]

    # Test with invalid executable in path list

# Generated at 2022-06-22 21:52:44.092253
# Unit test for function get_bin_path
def test_get_bin_path():
    ansible_module = DummyModule()
    bin_path = get_bin_path("/bin/echo", ansible_module)
    assert bin_path == '/bin/echo'


# Unit test method for AnsibleModule.

# Generated at 2022-06-22 21:52:52.787926
# Unit test for function get_bin_path
def test_get_bin_path():
    # run in a subshell so we don't screw up the display environment
    import tempfile
    tmp = tempfile.NamedTemporaryFile(delete=False)
    tmp.write('#!/bin/sh\necho success')
    tmp.close()

# Generated at 2022-06-22 21:52:56.980918
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('foo')
        assert False, 'Expected ValueError'
    except ValueError as e:
        assert 'Failed to find required executable "foo" in paths' in str(e)

    assert get_bin_path('python') is not None

# Generated at 2022-06-22 21:53:06.353545
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Test get_bin_path() '''

    current_dir = os.path.dirname(os.path.realpath(__file__))
    os.environ['PATH'] = os.pathsep.join([current_dir, os.environ['PATH']])
    executable = 'date'
    assert get_bin_path(executable) == os.path.join(current_dir, 'date')
    os.environ['PATH'] = os.pathsep.join(['/path/does/not/exist', os.environ['PATH']])
    try:
        get_bin_path(executable)
    except Exception as e:
        assert 'Failed to find required executable "%s" in paths:' % executable in str(e)

# Generated at 2022-06-22 21:53:17.831994
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    get_bin_path unit test
    '''
    import tempfile
    import shutil

    bin_dir = tempfile.mkdtemp()
    executable = os.path.join(bin_dir, 'test_get_bin_path')

    # no executable
    with open(executable, 'a'):
        os.utime(executable, None)
    result = get_bin_path(executable)
    assert result == executable

    # executable
    with open(executable, 'a'):
        os.utime(executable, None)
    os.chmod(executable, 0o755)
    result = get_bin_path(executable)
    assert result == executable

    # executable in path

# Generated at 2022-06-22 21:53:28.139834
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh')
    assert get_bin_path('sh', ['/bin','/usr/bin'])
    assert get_bin_path('sh', ['/bin','/fake/bin'])
    assert get_bin_path('sh', ['/foo/bin','/fake/bin'])
    assert get_bin_path('sh', ['/bin','/fake/bin'], True)

# Generated at 2022-06-22 21:53:37.666288
# Unit test for function get_bin_path
def test_get_bin_path():
    path = '/usr/bin'
    os.environ['PATH'] = path
    assert get_bin_path('echo') == os.path.join(path, 'echo')

    os.environ['PATH'] = path + os.pathsep + '/usr/local/bin'
    assert get_bin_path('echo') == os.path.join(path, 'echo')

    opt_paths = ['/opt/bin', '/usr/local/bin']
    assert get_bin_path('wc', opt_paths) == os.path.join(opt_paths[0], 'wc')
    assert get_bin_path('echo', opt_paths) == os.path.join(opt_paths[1], 'echo')

# Generated at 2022-06-22 21:53:40.225714
# Unit test for function get_bin_path
def test_get_bin_path():
    output = get_bin_path('ls')
    assert output == '/bin/ls'



# Generated at 2022-06-22 21:53:50.716431
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    import shutil
    from ansible.module_utils.common.file import is_executable
    from ansible.module_utils._text import to_bytes

    # create tmp dir to store files
    tmpdir = tempfile.mkdtemp()
    # create file in tmp dir and make sure it is executable
    testfile = os.path.join(tmpdir, 'test_file')
    with open(testfile, 'w') as f:
        f.write('#!/bin/sh\necho hello')
    os.chmod(testfile, 0o755)
    assert os.path.isfile(testfile)
    assert is_executable(testfile)


# Generated at 2022-06-22 21:53:52.345363
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-22 21:54:01.366084
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/ls', opt_dirs=['/bin']) == '/bin/ls'
    try:
        get_bin_path('ls_exec')
    except ValueError:
        pass
    else:
        raise AssertionError('get_bin_path did not raise ValueError')
    try:
        get_bin_path('/bin/ls_exec')
    except ValueError:
        pass
    else:
        raise AssertionError('get_bin_path did not raise ValueError')
    try:
        get_bin_path('/bin/ls_exec', required=True)
    except ValueError:
        pass

# Generated at 2022-06-22 21:54:11.065520
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import errno
    import stat

    test_dir = tempfile.mkdtemp()
    test_path = os.path.join(test_dir, 'test')
    test_file = open(test_path, 'w')
    test_file.write('#!/bin/sh\necho "test"')
    test_file.close()
    os.chmod(test_path, stat.S_IRWXU)
    shutil.rmtree(test_dir)
    try:
        shutil.rmtree(test_dir)
    except OSError as exc:
        if exc.errno != errno.ENOENT:
            raise
    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 21:54:13.127006
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('cat')
    except ValueError:
        print('failed to find cat')

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-22 21:54:19.268682
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    for required in [None, False, True]:
        with pytest.raises(ValueError) as exc_info:
            get_bin_path('/some/path/that/does/not/exist', opt_dirs='/some/optional/path', required=required)
        assert '/some/path/that/does/not/exist' in exc_info.value.args[0]
        assert 'paths: /some/optional/path' in exc_info.value.args[0]

# Generated at 2022-06-22 21:54:30.232181
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/bin/ls')
    except ValueError:
        assert False
    try:
        get_bin_path('/bin/ls', required=False)
    except ValueError:
        assert False
    try:
        get_bin_path('/bin/ls', ['/bin'], required=False)
    except ValueError:
        assert False
    try:
        get_bin_path('/bin/ls', ['/usr'], required=False)
    except ValueError:
        assert False
    try:
        get_bin_path('/bin/ls', ['/usr/local'], required=False)
    except ValueError:
        assert False

    try:
        get_bin_path('/bin/undefined')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-22 21:54:34.846523
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    get_bin_path('python')
    if sys.platform == 'win32':
        try:
            get_bin_path('cmd.exe')
            assert False
        except ValueError:
            pass
    else:
        try:
            get_bin_path('sh')
            assert False
        except ValueError:
            pass

# Generated at 2022-06-22 21:54:41.617378
# Unit test for function get_bin_path
def test_get_bin_path():
    env = os.environ.copy()
    try:
        os.environ['PATH'] = '/bin:/usr/bin:/usr/local/bin'
        for arg in ['sh', 'bash', 'grep', 'cat']:
            assert get_bin_path(arg) == os.path.join('/bin', arg) or get_bin_path(arg) == os.path.join('/usr/bin', arg)
    finally:
        os.environ = env

# Generated at 2022-06-22 21:54:51.855678
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-22 21:54:57.234357
# Unit test for function get_bin_path
def test_get_bin_path():
    # Absent from fake PATH
    got_exception = False
    try:
        get_bin_path('expect_it_to_not_exist')
    except ValueError as e:
        got_exception = True
    if not got_exception:
        raise SystemError('Expected ValueError exception but it did not happen.')

    # Found in real PATH
    assert(get_bin_path('ls'))

# Generated at 2022-06-22 21:55:05.104839
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test a system command
    assert get_bin_path('sh') == '/bin/sh'

    # Test a command that does not exist
    try:
        get_bin_path('does_not_exist')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')

    # Test a command that exists in the supplied directory
    # but is not on the path
    assert get_bin_path('id', ['/usr/bin']) == '/usr/bin/id'
    
    # Test a command that exists on the path but is not executable
    try:
        get_bin_path('/etc/passwd')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')

# Generated at 2022-06-22 21:55:16.011331
# Unit test for function get_bin_path
def test_get_bin_path():
    # no paths specified. /bin/grep exists and is executable
    assert get_bin_path('grep') == '/bin/grep'

    # no paths specified, /bin/grep does not exist
    try:
        get_bin_path('grep')
        assert False
    except ValueError:
        assert True

    # paths specified, /bin/grep does not exist
    try:
        get_bin_path('grep', ['/bin', '/sbin'])
        assert False
    except ValueError:
        assert True

    # paths specified, /bin/grep exists but is not executable

# Generated at 2022-06-22 21:55:27.470726
# Unit test for function get_bin_path
def test_get_bin_path():
    test_paths = ['/usr/bin', '/usr/local/bin']
    result_path = get_bin_path('ls', test_paths)
    assert result_path == '/bin/ls'

    result_path = get_bin_path('/bin/bash', test_paths)
    assert result_path == '/bin/bash'

    try:
        get_bin_path('nonexistent_executable', test_paths)
    except ValueError as err:
        assert 'Failed to find required executable "nonexistent_executable"' in str(err)
        return
    assert False, 'Expecting to raise ValueError exception'

#
# Detect if Python is running in a POSIX shell
#
if os.path.isfile("/etc/redhat-release"):
    in_posix_shell

# Generated at 2022-06-22 21:55:37.219592
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes

    test_path = to_bytes('/foo/bar/baz')
    os.environ['PATH'] = to_bytes('')

    try:
        assert get_bin_path('true') == '/bin/true'
    except ValueError:
        assert False, "Failed to find required executable 'true' in PATH"

    os.environ['PATH'] = test_path

    # Add a directory to the path
    try:
        assert get_bin_path('true') == '/bin/true'
    except ValueError:
        assert False, "Failed to find required executable 'true' in PATH"

    # Remove executable from PATH
    os.environ['PATH'] = to_bytes('')

    # Test failure

# Generated at 2022-06-22 21:55:45.658342
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Incorrect "arg" values will raise exception.
    '''
    from ansible.module_utils.common.file import get_bin_path
    from ansible.module_utils.six import PY3

    # Test for proper exception when specifying nonexistant binary.
    try:
        get_bin_path('commanddoesnotexist')
    except Exception as e:
        if isinstance(e, ValueError) and "commanddoesnotexist" not in str(e):
            assert False
    else:
        assert False, "Failed to raise Exception when specifying nonexistant binary."

    # Test that 'python' is found
    try:
        get_bin_path('python')
    except Exception as e:
        assert False, "Raised exception when no exception should have been raised: %s" % str(e)

    # Test

# Generated at 2022-06-22 21:55:57.085935
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls', ['/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'
    try:
        get_bin_path('does-not-exist', ['/usr/local/bin'], False)
        assert False
    except ValueError:
        pass
    assert get_bin_path('gcc', ['/usr/bin']) == '/usr/bin/gcc'
    assert get_bin_path('gcc', ['/usr/bin'], False) == '/usr/bin/gcc'
    assert get_bin_path('gcc', ['/usr/bin'], True) == '/usr/bin/gcc'

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-22 21:56:04.001056
# Unit test for function get_bin_path
def test_get_bin_path():
    assert (get_bin_path('sh'))
    assert (get_bin_path('sh', ['/sbin', '/usr/sbin']))
    assert (get_bin_path('sh', ['/sbin', '/usr/sbin'], True))
    assert (get_bin_path('sh', ['/sbin', '/usr/sbin'], False))
    assert (get_bin_path('sh', required=True))
    assert (get_bin_path('sh', required=False))

# Generated at 2022-06-22 21:56:13.904169
# Unit test for function get_bin_path
def test_get_bin_path():
    bindir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bin')
    notbindir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'notbin')
    pathvar = os.environ.get('PATH', '')

    # PATH not extended at all
    os.environ['PATH'] = pathvar
    assert get_bin_path('ansible-test-executable-file', ['notexisting']) == os.path.join(bindir, 'ansible-test-executable-file')

    # PATH extended by extra directory
    os.environ['PATH'] = pathvar

# Generated at 2022-06-22 21:56:18.648375
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.basic import AnsibleModule

    def test(args, result, exception=None, opt_dirs=None):
        if exception is False:
            exception = None
        elif exception is True:
            exception = ValueError
        module = AnsibleModule({'arg': args['arg']})

        if exception is None:
            assert get_bin_path(**args) == result
        else:
            with pytest.raises(exception):
                get_bin_path(**args)

    test({'arg': 'echo'}, '/bin/echo')
    test({'arg': 'not-found'}, None, True)
    test({'arg': 'not-found', 'required': False}, None, False)

# Generated at 2022-06-22 21:56:29.944290
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls', ['/bin']) == '/bin/ls'
    assert get_bin_path('ls', ['/does/not/exist']) == '/bin/ls'
    assert get_bin_path('ls', ['/bin'], False) == '/bin/ls'
    try:
        assert get_bin_path('/bin/grep', ['/bin']) == '/bin/grep'
    except ValueError:
        pass
    assert get_bin_path('/bin/grep', ['/bin'], False) == '/bin/grep'
    try:
        assert get_bin_path('/does/not/exist') == '/does/not/exist'
    except ValueError:
        pass

# Generated at 2022-06-22 21:56:39.829507
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    bin_path = get_bin_path(sys.executable)
    assert bin_path == sys.executable

    # Create a temporary directory containing a script that returns True
    tmp_dir = tempfile.mkdtemp()
    script_name = os.path.join(tmp_dir, 'true.py')
    with open(script_name, 'w') as f:
        f.write('#!/usr/bin/env python\nexit(0)\n')

    os.chmod(script_name, 0o755)
    os.environ['PATH'] = tmp_dir
    bin_path = get_bin_path('true.py')
    assert bin_path == script_name

# Generated at 2022-06-22 21:56:51.714260
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary executable file
    temp_exec = tempfile.NamedTemporaryFile(suffix='.sh', dir=temp_dir, delete=False)
    temp_exec.write('#!/bin/sh\necho executable\n')
    temp_exec.close()
    os.chmod(temp_exec.name, 0o700)

    # Add temporary directory to PATH

# Generated at 2022-06-22 21:57:01.702429
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    # Test with 'python'
    assert get_bin_path('python', opt_dirs=None, required=True) == sys.executable

    # Test with 'ansible'
    import ansible
    ansible_bin_path = sys.executable.replace("python", "ansible")
    assert get_bin_path('ansible', opt_dirs=None, required=True) == ansible_bin_path

    # Test with 'aws'
    assert get_bin_path('aws', opt_dirs=None, required=True) != ""
    try:
        get_bin_path('aws', opt_dirs=None, required=True) == None
    except ValueError:
        assert True

    # Test with 'nonexistent'

# Generated at 2022-06-22 21:57:05.590075
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == os.path.realpath('/usr/bin/python')
    assert get_bin_path('nosuchbinary') == None

# Generated at 2022-06-22 21:57:08.644833
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/usr/bin/sh') == '/usr/bin/sh'

# Generated at 2022-06-22 21:57:16.344091
# Unit test for function get_bin_path
def test_get_bin_path():
    # We need to define a new function here, to avoid errors due to the ORDERING of functions in the file
    # Otherwise our tests will try to find a __main__ first
    def get_bin_path_new(arg, opt_dirs=None, required=None):
        '''
        Find system executable in PATH. Raises ValueError if executable is not found.
        Optional arguments:
           - required:  [Deprecated] Prior to 2.10, if executable is not found and required is true it raises an Exception.
                        In 2.10 and later, an Exception is always raised. This parameter will be removed in 2.14.
           - opt_dirs:  optional list of directories to search in addition to PATH
        If found return full path, otherwise raise ValueError.
        '''

# Generated at 2022-06-22 21:57:28.175972
# Unit test for function get_bin_path
def test_get_bin_path():
    path_before_test = os.getenv('PATH', '')
    os.environ['PATH'] = '/bin:/usr/bin'

    assert get_bin_path('python') == '/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/local/bin']) == '/usr/local/bin/python'
    try:
        get_bin_path('python', opt_dirs=['/usr/local/bin'], required=True)
    except ValueError:
        pass
    else:
        raise Exception("Failed to raise ValueError")

    del os.environ['PATH']
    try:
        get_bin_path('python')
    except ValueError:
        pass
    else:
        raise Exception("Failed to raise ValueError")


# Generated at 2022-06-22 21:57:37.625924
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    mydir = tempfile.mkdtemp()
    myexec = 'myexec'
    mypath = os.path.join(mydir, myexec)
    with open(mypath, 'wt') as f:
        f.write('')
    os.chmod(mypath, 0o777)

    fn = get_bin_path(myexec, [mydir])
    assert fn == mypath

    bad_dir = os.path.join(mydir, 'noexec')
    os.mkdir(bad_dir)
    try:
        fn = get_bin_path(myexec, [bad_dir])
        assert False, 'Expected exception'
    except ValueError:
        pass

    fn = get_bin_path(myexec, [mydir], required=False)

# Generated at 2022-06-22 21:57:46.039270
# Unit test for function get_bin_path
def test_get_bin_path():
    import getpass
    import shutil
    import tempfile
    import sys

    # Make a temporary directory to store our fake executables in
    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-22 21:57:58.052980
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    get_bin_path unit test.
    '''
    assert get_bin_path('ansible-playbook', opt_dirs=['/usr/bin']) == '/usr/bin/ansible-playbook'
    assert get_bin_path('ansible-playbook', opt_dirs=['/usr/local/bin', '/usr/bin']) == '/usr/bin/ansible-playbook'
    assert get_bin_path('ansible-playbook', opt_dirs=['/usr/bin', '/usr/local/bin']) == '/usr/bin/ansible-playbook'
    assert get_bin_path('ansible-playbook', opt_dirs=['/usr/bin', '/usr/local/bin', '/bin']) == '/usr/bin/ansible-playbook'
   

# Generated at 2022-06-22 21:58:08.771906
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh')
    assert '/bin/sh' == get_bin_path('sh')
    # test the optional args
    assert '/bin/sh' == get_bin_path('sh', ['/bin'])
    assert '/bin/sh' == get_bin_path('sh', ['/bin', '/usr/bin'])
    assert '/sbin/ip' == get_bin_path('ip', ['/sbin', '/usr/sbin'])
    # test failure - it should raise ValueError
    try:
        get_bin_path('bogus')
    except ValueError:
        pass
    else:
        raise AssertionError('Test for get_bin_path failed to raise ValueError')

# Generated at 2022-06-22 21:58:11.611986
# Unit test for function get_bin_path
def test_get_bin_path():
    expected = os.path.realpath(get_bin_path('ls'))
    actual = os.path.realpath('/bin/ls')
    assert expected == actual


# Generated at 2022-06-22 21:58:13.387480
# Unit test for function get_bin_path
def test_get_bin_path():
    for arg in ['ls', 'cat']:
        assert get_bin_path(arg)



# Generated at 2022-06-22 21:58:16.227367
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python')
    assert get_bin_path('python', opt_dirs=[os.path.dirname(__file__)])


# Generated at 2022-06-22 21:58:24.510471
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.geteuid() == 0:
        assert '/bin/python' == get_bin_path('python')
    else:
        assert '/usr/bin/python' == get_bin_path('python')

    pwd = os.path.dirname(__file__)
    path = get_bin_path('get_bin_path.py', [pwd])
    assert path.endswith('get_bin_path.py')

    try:
        # the path must be a directory
        get_bin_path('/dev')
    except ValueError as e:
        assert 'not an executable' in str(e)

# Generated at 2022-06-22 21:58:36.103684
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    import shutil

    # Set up temp dir with fake binaries
    tmpdir = tempfile.mkdtemp()
    shutil.copy(sys.executable, tmpdir)
    shutil.copy(__file__, tmpdir)

    # Find executable via get_bin_path
    python_path = get_bin_path('python', opt_dirs=[tmpdir])
    test_path = get_bin_path('test_utils.py', opt_dirs=[tmpdir])

    # Check that the path is indeed in the test dir
    python_base = os.path.basename(python_path)
    test_base = os.path.basename(test_path)
    assert python_base == 'python'
    assert test_base == 'test_utils.py'

    # Clean up

# Generated at 2022-06-22 21:58:45.565110
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('ls', ['/usr/bin', '/bin']) == '/bin/ls'
    assert get_bin_path('ls', ['/usr/bin', '/non/existant/path']) == '/bin/ls'
    assert get_bin_path('ls', ['/usr/bin', '/bin', '/bin']) == '/bin/ls'
    assert get_bin_path('ls', ['/usr/bin', None, '/bin']) == '/bin/ls'
    try:
        get_bin_path('non_existant_command')
        raise AssertionError('Failed to detect missing executable')
    except ValueError:
        pass

# Generated at 2022-06-22 21:58:53.846570
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with an executable which can be find in the given paths
    assert "/bin/sh" == get_bin_path("sh", ["/bin"])

    # Try with an executable in a path not in the list
    try:
        get_bin_path("sh", ["/usr/bin"])
    except ValueError as e:
        assert "Failed to find required executable \"sh\" in paths: /usr/bin" == str(e)

    # Test if paths is empty
    try:
        get_bin_path("sh", [])
    except ValueError as e:
        assert "Failed to find required executable \"sh\" in paths: " == str(e)

# Generated at 2022-06-22 21:59:03.503750
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no_such_binary_on_system')
        assert False, 'get_bin_path() should fail when no binary is found'
    except ValueError:
        pass
    return
    bin_path = get_bin_path('python')
    assert os.path.exists(bin_path)
    assert os.path.isfile(bin_path)
    assert is_executable(bin_path)
    bin_path = get_bin_path('python', opt_dirs=['/usr/local/bin'])
    assert os.path.exists(bin_path)
    assert os.path.isfile(bin_path)
    assert is_executable(bin_path)

# Generated at 2022-06-22 21:59:12.252640
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_name = 'printf'

    sbin_path = '/sbin'
    os.environ['PATH'] = os.environ['PATH'] + os.pathsep + sbin_path

    bin_path = get_bin_path(bin_name)
    assert os.environ['PATH'].find(sbin_path) != -1
    assert bin_name in bin_path
    assert os.path.exists(bin_path)
    assert not os.path.isdir(bin_path)
    assert is_executable(bin_path)

# Generated at 2022-06-22 21:59:24.497878
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common import get_platform
    import shutil
    import tempfile

    # create temporary directory to use for testing
    tmpdir = tempfile.mkdtemp()
    test_paths = []
    test_paths.append(tmpdir)
    test_paths.append(os.path.join(tmpdir, 'bin'))
    test_paths.append(os.path.join(tmpdir, 'usr', 'bin'))
    test_paths.append(os.path.join(tmpdir, 'usr', 'local', 'bin'))
    test_paths.append(os.path.join(tmpdir, 'sbin'))
    test_paths.append(os.path.join(tmpdir, 'usr', 'sbin'))

# Generated at 2022-06-22 21:59:35.218754
# Unit test for function get_bin_path
def test_get_bin_path():
    # test standard use case
    try:
        get_bin_path('getent')
    except ValueError:
        assert False, 'Failed to find getent in standard PATH'

    # test opt_dirs includes
    try:
        get_bin_path('getent', opt_dirs=['/bin'])
    except ValueError:
        assert False, 'Failed to find getent in standard PATH'

    try:
        get_bin_path('getent', opt_dirs=['/sbin'])
    except ValueError:
        assert False, 'Failed to find getent in opt_dirs /sbin'

    # test PATH includes sbin directories

# Generated at 2022-06-22 21:59:44.759755
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    get_bin_path: test case
    """
    # No PATH env variable
    os.environ.pop("PATH")
    try:
        get_bin_path("ls")
    except ValueError:
        pass
    else:
        pytest.fail("ValueError not raised")

    # Command not in PATH
    os.environ["PATH"] = "/usr/bin:/bin"
    try:
        get_bin_path("ls")
    except ValueError:
        pass
    else:
        pytest.fail("ValueError not raised")

    # Command in PATH
    os.environ["PATH"] = "/bin:/usr/bin"
    assert get_bin_path("ls") == "/bin/ls"

    # Command in PATH with additional custom paths

# Generated at 2022-06-22 21:59:50.751512
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('sh')
    get_bin_path('sh', opt_dirs=['/bin'])
    get_bin_path('/bin/sh')
    get_bin_path('/bin/sh', opt_dirs=['/bin'])
    try:
        get_bin_path('sh2')
        raise Exception("Did not raise exception!!")
    except ValueError:
        pass

# Generated at 2022-06-22 22:00:02.723103
# Unit test for function get_bin_path
def test_get_bin_path():

    if 'PATH' in os.environ:
        del os.environ['PATH']

    # Test1: Exe is in PATH and one of the optional paths
    os.environ['PATH'] = "/usr/bin:/bin:/usr/sbin:/sbin"
    assert get_bin_path('ls', opt_dirs=['/opt/test']) == "/bin/ls"

    # Test2: Exe is in PATH
    os.environ['PATH'] = "/usr/bin:/bin:/usr/sbin:/sbin"
    assert get_bin_path('ls') == "/bin/ls"

    # Test3: Exe is not in PATH
    os.environ['PATH'] = "/usr/bin:/bin:/usr/sbin:/sbin"

# Generated at 2022-06-22 22:00:05.146496
# Unit test for function get_bin_path
def test_get_bin_path():
    bindir = os.path.dirname(__file__)
    os.environ['PATH'] = bindir
    try:
        get_bin_path('nosuchcommand')
        assert False
    except ValueError:
        pass

    assert get_bin_path('test_utils_plugin.py')

# Generated at 2022-06-22 22:00:09.256609
# Unit test for function get_bin_path
def test_get_bin_path():
    test_paths = ['/bin', '/usr/bin', '/sbin', '/usr/sbin']
    test_bin_name = 'ls'
    test_bin_path = None
    for path in test_paths:
        test_bin_path = os.path.join(path, test_bin_name)
        if os.path.isfile(test_bin_path) and os.access(test_bin_path, os.X_OK):
            break

    assert(test_bin_path == get_bin_path(test_bin_name, test_paths))

# Generated at 2022-06-22 22:00:20.067568
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('nonexistent_binary')
    except ValueError as e:
        if 'Failed to find required executable' not in str(e):
            raise
    try:
        get_bin_path('python', opt_dirs=['/bin', '/usr/bin'])
    except ValueError as e:
        if 'Failed to find required executable' not in str(e):
            raise
    assert get_bin_path('python', opt_dirs=['./test/unit/utils/module_utils/common/testdata/bin']) == './test/unit/utils/module_utils/common/testdata/bin/python'

# Generated at 2022-06-22 22:00:30.230138
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('ls')
        get_bin_path('ls', required=True)
    except ValueError:
        assert False, 'Failed to find executable "ls"'

    try:
        get_bin_path('fake_exe')
        assert False, 'Found non-existant executable "fake_exe"'
    except ValueError:
        pass
    pass

    expected_paths = ['/sbin', '/usr/sbin', '/usr/local/sbin']
    for path in expected_paths:
        try:
            p = get_bin_path('fake_exe', opt_dirs=[path])
        except ValueError:
            assert False, 'Failed to find executable "fake_exe" in %s' % path


# Generated at 2022-06-22 22:00:37.886646
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('cat')
    except:
        raise ValueError('Failed to find the \'cat\' executable')

    try:
        get_bin_path('this_is_not_the_executable_you_are_looking_for')
    except ValueError as e:
        if 'Failed to find required executable' in str(e):
            # Expected result.
            pass
        else:
            raise ValueError(str(e))

# Generated at 2022-06-22 22:00:47.599896
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/nonexistdir/shouldntexists/python')
    except ValueError:
        pass
    else:
        raise AssertionError('get_bin_path should have failed to find a nonexistent file but did not.')

    try:
        get_bin_path('python')
    except ValueError:
        raise AssertionError('get_bin_path should have found the python executable but did not.')

    for required in (True, False):
        try:
            get_bin_path('/nonexistdir/shouldntexists/python', required=required)
        except ValueError:
            pass
        else:
            raise AssertionError('get_bin_path should have failed to find a nonexistent file but did not.')


# Generated at 2022-06-22 22:00:50.902335
# Unit test for function get_bin_path
def test_get_bin_path():
    # should return the path to ls
    assert get_bin_path('ls') == '/bin/ls'
    # should return the path to touch
    assert get_bin_path('touch') == '/bin/touch'

# Generated at 2022-06-22 22:01:01.954717
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('sh')
    except ValueError as e:
        raise AssertionError('%s: get_bin_path failed for "sh"' % e.args[0])

    if 'PATH' in os.environ:
        old_path = os.environ['PATH']
        os.environ['PATH'] = '/bin:/usr/bin'
    try:
        try:
            get_bin_path('sh')
        except ValueError as e:
            raise AssertionError('%s: get_bin_path failed for "sh" in /bin:/usr/bin' % e.args[0])
    finally:
        if 'PATH' in os.environ:
            os.environ['PATH'] = old_path

# Generated at 2022-06-22 22:01:10.330229
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible import constants
    import tempfile
    import shutil

    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-22 22:01:22.529657
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert get_bin_path('pwd')
    except ValueError as e:
        raise AssertionError("Failed to find path for 'pwd'")
    try:
        assert get_bin_path('asdfasdfasdf')
    except ValueError:
        pass
    else:
        raise AssertionError("Found non-existent executable")

    assert get_bin_path('pwd', opt_dirs=['/bin'])
    try:
        assert get_bin_path('pwd', opt_dirs=[])
    except ValueError as e:
        raise AssertionError("Failed to find path for 'pwd'")
    try:
        assert get_bin_path('pwd', opt_dirs=['/bin', '/'])
    except ValueError as e:
        raise