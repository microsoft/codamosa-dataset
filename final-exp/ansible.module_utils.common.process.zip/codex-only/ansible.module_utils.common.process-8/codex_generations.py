

# Generated at 2022-06-22 21:51:24.609749
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    # Create a mock directory
    tmpdir = tempfile.mkdtemp(prefix='ansible')
    a_path = os.path.join(tmpdir, "a.sh")
    b_path = os.path.join(tmpdir, "b.sh")
    with open(a_path, "w") as f:
        f.write("#!/bin/bash\n")
    with open(b_path, "w") as f:
        f.write("#!/bin/bash\n")
    os.chmod(a_path, 0o777)
    os.chmod(b_path, 0o777)
    # a.sh should be found
    assert get_bin_path("a.sh", opt_dirs=[tmpdir]) == a_path
    # b

# Generated at 2022-06-22 21:51:34.617553
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import om_shared as sharedmodule
    import platform

    """
    On windows, /sbin does not exist and get_bin_path returns None for
    any binary in /sbin.

    """
    if platform.system() == 'Windows':
        return
    sys.path.insert(0, os.path.dirname(__file__).encode('ascii', 'ignore'))

    # Check that we can get the path to any binary in PATH
    for path in os.environ['PATH'].split(os.path.pathsep):
        for name in os.listdir(path):
            full_path = os.path.join(path, name)

# Generated at 2022-06-22 21:51:40.895262
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.six import PY3

    # when python3 is running
    if PY3:
        # test for the path exist or not
        try:
            bin_path = get_bin_path('python3')
            assert os.path.exists(bin_path)
        except ValueError:
            assert False

        # test for the path does not exist
        try:
            bin_path = get_bin_path('abcd')
            assert False
        except ValueError:
            assert True

# Generated at 2022-06-22 21:51:50.312611
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    from tempfile import NamedTemporaryFile

    try:
        bin_path = get_bin_path('doesnotexist')
    except ValueError:
        pass
    else:
        raise AssertionError('get_bin_path() did not raise call get_bin_path("doesnotexist")')

    try:
        bin_path = get_bin_path('bash', opt_dirs=['/usr/bin'])
    except ValueError:
        raise AssertionError('get_bin_path() raised exception with valid path and executable')

    def make_tmp_executable(contents):
        tmpfile = NamedTemporaryFile(delete=False)
        tmpfile.write(contents.encode())
        tmpfile.close()

# Generated at 2022-06-22 21:51:59.916291
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path.
    '''
    # test success
    try:
        get_bin_path('ls')
    except ValueError:
        assert False, "get_bin_path failed to find executable ls"
    # test not found
    try:
        get_bin_path('nosuchfile')
        assert False, "get_bin_path found a non existant file nosuchfile"
    except ValueError:
        pass
    # test opt_dirs with non existant directory
    try:
        get_bin_path('ls', ['/doesntexists'])
        assert False, "get_bin_path found ls in non existant directory"
    except ValueError:
        pass
    # test opt_dirs with existant directory but file not found

# Generated at 2022-06-22 21:52:08.354861
# Unit test for function get_bin_path
def test_get_bin_path():
    path_exists_calls = []

    def mocked_exists(path):
        path_exists_calls.append(path)
        return False

    def mocked_is_executable(path):
        return True

    def mocked_environ(path):
        val = {
            "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games"
        }
        return val[path]

    def mocked_isdir(path):
        return False

    import __builtin__
    original_exists = __builtin__.__dict__["__import__"]("os.path").exists

# Generated at 2022-06-22 21:52:10.575573
# Unit test for function get_bin_path
def test_get_bin_path():
    result = get_bin_path('sh')
    assert result.endswith('/sh')

# Generated at 2022-06-22 21:52:19.034815
# Unit test for function get_bin_path
def test_get_bin_path():
    # ansible-test units --python -v test/utils/functions/get_bin_path.py
    assert get_bin_path('ls').endswith('/ls')

    try:
        get_bin_path('no_such_binary')
    except ValueError as e:
        assert 'Failed to find required executable "no_such_binary"' in str(e)

    path1 = os.path.abspath(__file__)
    path2 = os.path.abspath(__name__)
    assert get_bin_path('ls', opt_dirs=[path1, path2]).endswith('/ls')

# Generated at 2022-06-22 21:52:25.492954
# Unit test for function get_bin_path
def test_get_bin_path():
    # Positive test
    assert get_bin_path('bash', required=True) is not None
    # Negative test
    try:
        get_bin_path('badpath', required=True)
        assert False
    except Exception:
        assert True
    # Another positive test, but this time with opt_dirs
    if os.path.exists('/bin/true'):
        assert get_bin_path('true', opt_dirs=['/bin'], required=True) is not None

# Generated at 2022-06-22 21:52:37.148172
# Unit test for function get_bin_path
def test_get_bin_path():

    # simple negative test, try to find a program which is not in the path.
    try:
        get_bin_path('nosuchprogram')
    except ValueError:
        pass
    else:
        raise Exception('get_bin_path should not have found nosuchprogram')

    # simple positive test
    bin_path = get_bin_path('true')
    assert bin_path is not None

    # find it in a different location
    bin_path = get_bin_path('true', opt_dirs=['/usr/bin', '/bin', '/usr/sbin'])
    assert bin_path is not None

    # find it with a relative path
    bin_path = get_bin_path('bin/true', opt_dirs=['/usr'])
    assert bin_path is not None

# Generated at 2022-06-22 21:52:44.147755
# Unit test for function get_bin_path
def test_get_bin_path():
    # check for invalid paths
    invalid_path = '/bin/doesnotexist'
    try:
        get_bin_path(invalid_path)
        assert False
    except ValueError as e:
        if not 'Failed to find required executable "doesnotexist" in paths' in str(e):
            assert False

    # check for valid path
    valid_path = '/bin/ls'
    try:
        get_bin_path(valid_path)
    except ValueError as e:
        assert False

# Generated at 2022-06-22 21:52:52.821544
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1. If a binary is callable, return it.
    result = get_bin_path('touch')
    assert result == '/bin/touch'

    # Test 2. If a binary is not callable, raise ValueError
    try:
        get_bin_path('ls')
    except ValueError:
        pass

    # Test 3. Test optional parameters opt_dirs.
    # opt_dirs is a list of directories to search in addition to PATH
    result = get_bin_path('touch', opt_dirs=['/etc', '/bin', '/usr/'])
    assert result == '/bin/touch'

    # Test 4. If a binary is not in PATH, opt_dirs is not callable, and required is true,
    # raise ValueError

# Generated at 2022-06-22 21:53:03.490355
# Unit test for function get_bin_path
def test_get_bin_path():
    assert bin_path('foo') is None
    os.environ['PATH'] = '/usr/bin:/bin:%s' % os.path.abspath('./bin')
    assert get_bin_path('foo') is None
    assert get_bin_path('cp') == '/bin/cp'
    assert get_bin_path('/bin/cp') == '/bin/cp'
    assert get_bin_path('/usr/bin/cp') == '/usr/bin/cp'
    assert get_bin_path('./bin/cp') == './bin/cp'
    assert get_bin_path('bar') is None
    assert get_bin_path('bar', opt_dirs=['/usr/bin', './bin']) == './bin/bar'

# Generated at 2022-06-22 21:53:05.081686
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/bin/sleep' == get_bin_path('sleep')



# Generated at 2022-06-22 21:53:15.119583
# Unit test for function get_bin_path
def test_get_bin_path():
    # Missing executable
    import pytest
    with pytest.raises(ValueError):
        get_bin_path('this_should_not_exist')
    # Existing executable
    assert get_bin_path('ping') == '/usr/bin/ping'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    # Existing executable with optional directories
    assert get_bin_path('/bin/ls', opt_dirs=['/bin', '/sbin']) == '/bin/ls'
    # Existing executable with optional directories and additional path
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'

# Generated at 2022-06-22 21:53:23.491689
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Ansible module_utils.common.file.get_bin_path() test cases
    '''
    # test __file__ variable. There should be file named test_get_bin_path.py
    assert os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)),
                                       'test_get_bin_path.py')) is True
    for executable in ['sh', 'python', 'python3']:
        if executable == 'python':
            if not os.path.exists('/usr/bin/python'):
                continue
        elif executable == 'python3':
            if not os.path.exists('/usr/bin/python3'):
                continue
        get_bin_path(executable)
    # test for invalid executable

# Generated at 2022-06-22 21:53:31.603578
# Unit test for function get_bin_path
def test_get_bin_path():
    # Create temporary directories and files for testing
    temp_dirs = []
    for i in range(4):
        d = os.path.join(os.environ['HOME'], 'ansible-test-get_bin_path-{}'.format(i))
        os.mkdir(d)
        temp_dirs.append(d)
    temp_files = []
    for i in range(6):
        f = os.path.join(temp_dirs[i // 2], 'ansible-test-get_bin_path-{}'.format(i))
        with open(f, 'w'):
            os.chmod(f, 0o755)
        temp_files.append(f)
    # Test get_bin_path

# Generated at 2022-06-22 21:53:41.284327
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check that it raises an exception if the executable doesn't exist (and isn't found)
    try:
        get_bin_path('this_is_not_a_valid_executable')
    except ValueError:
        pass
    else:
        raise AssertionError('get_bin_path did not raise ValueError on non-existent executable')

    # Check that it raises an exception if the executable is not executable
    try:
        get_bin_path('/etc/hosts')
    except ValueError:
        pass
    else:
        raise AssertionError('get_bin_path did not raise ValueError on non-executable file')

    # Check that it finds a valid executable
    get_bin_path('cat')

    # Check that it can find a valid executable in an alternative location

# Generated at 2022-06-22 21:53:50.459376
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file in the temporary directory
    foo = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    foo.write(b'#!/bin/sh\necho hello world\n')
    foo.close()
    # Store the path of the temporary file
    foo_path = foo.name


# Generated at 2022-06-22 21:53:59.486729
# Unit test for function get_bin_path
def test_get_bin_path():

    # Path for executable
    r = get_bin_path('ls')
    assert r is not None
    assert 'ls' in r

    # Path for non existing executable
    try:
        get_bin_path('ls_foobar')
    except ValueError:
        pass
    else:
        assert False

    # Path for an existing file that is not an executable
    try:
        get_bin_path('ls_foobar', opt_dirs=['/etc'])
    except ValueError:
        pass

    # Path for an executable that is not in standard PATH
    r = get_bin_path('docker', opt_dirs=['/usr/local/bin'])
    assert r is not None
    assert 'docker' in r

# Generated at 2022-06-22 21:54:05.689927
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    # Create two files to test getting the full path
    tempdir = tempfile.mkdtemp()
    tfile1 = '%s/testfile1' % tempdir
    with open(tfile1, 'w') as f:
        f.write('test')
    os.chmod(tfile1, stat.S_IRWXU)
    tfile2 = '%s/testfile2' % tempdir

    # Test that we get the full path
    assert get_bin_path('testfile1', [tempdir]) == os.path.abspath(tfile1)
    assert get_bin_path('testfile1', opt_dirs=[]) == os.path.abspath(tfile1)

# Generated at 2022-06-22 21:54:18.301914
# Unit test for function get_bin_path
def test_get_bin_path():
    def my_is_executable(path):
        return path == '/usr/bin/ansible' or path == '/usr/sbin/fdisk'

    #
    # Unit test for function get_bin_path
    #
    test_path = '/foo:/bar'

# Generated at 2022-06-22 21:54:29.384086
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    import unittest

    def touch(fname, times=None):
        with open(fname, 'a'):
            os.utime(fname, times)


# Generated at 2022-06-22 21:54:35.395002
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path("test_bin_path", ["/test_ansible_path"])
    except ValueError as e:
        assert e.message == 'Failed to find required executable "test_bin_path" in paths: /test_ansible_path:/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin'
    else:
        assert False, 'get_bin_path did not raise a ValueError'

# Generated at 2022-06-22 21:54:45.772762
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == get_bin_path('ls', opt_dirs=['/bin'])
    assert get_bin_path('ls', opt_dirs=[]) == get_bin_path('ls', opt_dirs=[''])
    assert get_bin_path('ls', opt_dirs=None) == get_bin_path('ls', opt_dirs=[])
    assert get_bin_path('ls', opt_dirs=None) == get_bin_path('ls', opt_dirs=None)
    try:
        get_bin_path('nada')
        assert 0, "Failed to raise exception because path is invalid"
    except ValueError:
        pass

# Generated at 2022-06-22 21:54:55.751774
# Unit test for function get_bin_path
def test_get_bin_path():
    if not is_executable('/bin/bash'):
        raise Exception('This test requires that /bin/bash be executable')

    assert get_bin_path('bash') == '/bin/bash'

    assert get_bin_path('bash', ['/bin']) == '/bin/bash'
    assert get_bin_path('bash', ['/tmp']) == '/bin/bash'

    try:
        get_bin_path('bash', ['/tmp'], required=True)
        assert False, 'test_get_bin_path: missing exception'
    except ValueError:
        pass
    except Exception as e:
        assert False, 'test_get_bin_path: wrong exception raised: expected ValueError, got %s' % e

    # Don't expect to find bash in /tmp

# Generated at 2022-06-22 21:55:04.705171
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' run unit tests for get_bin_path '''

    # no executable
    try:
        get_bin_path('non-existent-file')
        assert False, 'get_bin_path failed to raise exception'
    except ValueError:
        pass

    # test required=False
    path = get_bin_path('non-existent-file', required=False)
    assert not path, 'get_bin_path failed to return None'

    # get_bin_path for itself
    path = get_bin_path('ansible-galaxy', required=False)
    assert path and os.path.basename(path) == 'ansible-galaxy', 'get_bin_path failed to return expected path'

    # test with partial path
    path = get_bin_path('./ansible-galaxy', required=False)

# Generated at 2022-06-22 21:55:13.488363
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', required=True) == '/bin/sh'
    assert get_bin_path('sh', required=False) == '/bin/sh'
    # assert get_bin_path('foo') == '/bin/sh'  # This should fail
    # assert get_bin_path('foo', required=True) == '/bin/sh'  # This should fail
    assert get_bin_path('foo', required=False) == '/bin/sh'  # This should fail
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'

# Generated at 2022-06-22 21:55:22.182467
# Unit test for function get_bin_path
def test_get_bin_path():

    # The test will fail with a ValueError if get_bin_path does not find ping or
    # if it does not find it in the PATH.
    bin_name = 'ping'
    try:
        bin_path = get_bin_path(bin_name)
    except ValueError as err:
        print("Failed to find executable %s in PATH. Error: %s" % (bin_name, str(err)))
        # Test failed...
    else:
        print("Path for %s is %s" % (bin_name, bin_path))
        # Test passed...

# Generated at 2022-06-22 21:55:33.412392
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    assert sys.executable == get_bin_path('python')

    #
    # Test opt_dirs parameter
    #
    assert '/opt/bin/python' == get_bin_path('python', opt_dirs=['/opt/bin'])

    #
    # Test required parameter
    #
    assert sys.executable == get_bin_path('python', required=True)
    assert '/opt/bin/python' == get_bin_path('python', opt_dirs=['/opt/bin'], required=True)
    try:
        get_bin_path('nonexistent_executable')
        assert False, get_bin_path.__name__ + 'has failed to raise exception on nonexistent executable'
    except ValueError:
        pass

# Generated at 2022-06-22 21:55:40.571456
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1: should return the correct path to ls when called from PATH
    assert get_bin_path('ls') == os.path.join(os.sep, 'bin', 'ls')

    # Test 2: should return the correct path to /bin/sleep when called
    # from /bin
    assert get_bin_path('sleep', ['/bin']) == os.path.join(os.sep, 'bin', 'sleep')

    # Test 3: should return the correct path to /bin/sleep when called
    # from PATH with /bin as a single path
    assert get_bin_path('sleep', [os.environ['PATH']]) == os.path.join(os.sep, 'bin', 'sleep')

    # Test 4: should return the correct path to /sbin/sleep when called
    # from /bin with /

# Generated at 2022-06-22 21:55:45.322878
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("whoami") == '/usr/bin/whoami'
    assert get_bin_path("whoami", ['/bin']) == '/usr/bin/whoami'
    assert get_bin_path("whoami", ['/bin', '/sbin']) == '/bin/whoami'

# Generated at 2022-06-22 21:55:56.762422
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        import pytest
        check_import = True
    except:
        check_import = False

    # Check that path is found on $PATH
    assert(get_bin_path('python'))

    # Check that path not found on $PATH raises ValueError
    try:
        # Make sure $PATH does not contain anything mockable
        path = os.environ.pop('PATH', None)
        get_bin_path('doesnotexit')
        # if we failed to raise ValueError, we pass an incorrect value
        assert False
    except ValueError:
        # if we successfully raised ValueError, we pass a correct value
        assert True
    os.environ['PATH'] = path

    # Check that path not found in opt_dirs parameter raises ValueError

# Generated at 2022-06-22 21:56:00.750125
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for function get_bin_path.
    '''
    try:
        get_bin_path('nonexisting_bin')
        assert False, 'Expected ValueError'
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

    assert get_bin_path('ls')

# Generated at 2022-06-22 21:56:12.588875
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    # Make sure that a nonexistant file raises an error
    try:
        get_bin_path('/nonexistant/blah')
        assert False, 'get_bin_path did not raise IOError!'
    except ValueError:
        pass

    # Make sure that the binary output is correct
    fd, fname = tempfile.mkstemp(dir='/tmp')
    os.close(fd)
    with open(fname, 'w'):
        pass
    os.chmod(fname, 0o755)
    assert get_bin_path(fname) == fname

    os.unlink(fname)

# The content below is imported from the legacy version of Ansible, and
# will be removed in Ansible 2.14.
#
# - start of content imported from lib/ansible

# Generated at 2022-06-22 21:56:20.850593
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('ls')
    get_bin_path('ls', ['/bin'])
    get_bin_path('ls', ['/usr/local/bin'])
    try:
        get_bin_path('not_found')
    except Exception:
        pass
    else:
        raise Exception("Does not raise exception if executable is not found.")
    if get_bin_path('ls', ['does/not/exist']) is not None:
        raise Exception("Should return None if opt_dirs is invalid.")

# Generated at 2022-06-22 21:56:26.574203
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls', ['/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', ['/bin']) == '/bin/ls'
    try:
        get_bin_path('ls', ['usr/bin'])
    except ValueError:
        pass
    else:
        assert False, 'get_bin_path should have failed'

# Generated at 2022-06-22 21:56:37.415473
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ['PATH'] = '/bin'
    e = '/bin/executable'
    assert get_bin_path('executable') == e
    assert get_bin_path('executable', required=True) == e
    assert get_bin_path('executable', required=False) == e

    try:
        os.environ['PATH'] = ''
        get_bin_path('executable')
        assert False
    except ValueError:
        assert True

    try:
        os.environ['PATH'] = ''
        get_bin_path('executable', required=True)
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-22 21:56:39.450588
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-22 21:56:51.189829
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('ansible-test-file')
    except ValueError:
        pass
    else:
        raise Exception('Test Failed: Missing required arg does not raise ValueError')

    # Create a test file in the PATH
    for p in os.environ['PATH'].split(os.pathsep):
        if p:
            test_file = os.path.join(p, 'ansible-test-file')
            # Try to create the test file in the PATH, but ignore error in case it exists
            try:
                open(test_file, 'w').close()
            except Exception:
                pass
            else:
                break
    else:
        raise Exception('Test Failed: Cannot find a directory in PATH to create test file')


# Generated at 2022-06-22 21:57:01.483591
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin', '/sbin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/sbin', '/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin', '/sbin'], required=True) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/sbin', '/bin'], required=True) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'

# Generated at 2022-06-22 21:57:05.853855
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path("ls")
    assert bin_path.endswith("ls")

if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-22 21:57:14.783215
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile

    test_executable_name = 'ansible_test_executable'
    test_executable_path = get_bin_path(test_executable_name)

    # check that existing executable is found
    assert os.path.exists(test_executable_path)

    # create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # create fake search directories and populate it
    fake_search_directories = []
    for i in range(3):
        fake_search_directories.append(os.path.join(tmp_dir, 'fake_directory_' + str(i)))
    for directory in fake_search_directories:
        os.mkdir(directory)

# Generated at 2022-06-22 21:57:26.797203
# Unit test for function get_bin_path
def test_get_bin_path():

    tests = (
        {'arg': 'ansible', 'dirs': None, 'expect': '/usr/bin/ansible'},
        {'arg': 'ansible', 'dirs': ['/tmp'], 'expect': '/tmp/ansible'},
        {'arg': 'nosuchbin', 'dirs': None, 'expect': None},
    )

    for test in tests:
        if test['expect'] is not None:
            try:
                ret = get_bin_path(test['arg'], test['dirs'])
                assert ret == test['expect'], '{0} != {1}'.format(test['expect'], ret)
            except ValueError:
                assert False, 'get_bin_path raised ValueError for {0}'.format(test['arg'])

# Generated at 2022-06-22 21:57:37.318783
# Unit test for function get_bin_path
def test_get_bin_path():
    import unittest
    import shutil
    import tempfile

    class TestPath(unittest.TestCase):

        def _touch(self, path):
            with open(path, 'a'):
                os.utime(path, None)
            return path

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.testpath = self._touch(os.path.join(self.tmpdir, 'testpath'))
            self.required_path = self._touch(os.path.join(self.tmpdir, 'required_path'))
            if not os.path.exists('/usr/bin/testpath'):
                self._touch('/usr/bin/testpath')

# Generated at 2022-06-22 21:57:45.985648
# Unit test for function get_bin_path
def test_get_bin_path():
    # ensure that get_bin_path does not attempt to search for executables
    # in non-existent directories
    def opt_dirs_with_non_existent_dir(arg, opt_dirs=None, required=None):
        new_opt_dirs = opt_dirs + ["/fake/path"]
        return get_bin_path(arg, new_opt_dirs, required)

    # existing executable on PATH
    assert get_bin_path('sh') == '/bin/sh'
    # existing executable on PATH, but non-existent directory included in opt_dirs
    try:
        opt_dirs_with_non_existent_dir('sh')
    except ValueError as e:
        assert "Failed to find required executable \"sh\" in paths: /fake/path:/bin:/usr/bin:/usr/local/bin"

# Generated at 2022-06-22 21:57:52.447998
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('true', ['/bin', '/usr/bin']) == '/bin/true'
    assert get_bin_path('sh', required=False) == '/bin/sh'
    try:
        get_bin_path('command_that_does_not_exist')
        assert False, 'Exception should be thrown'
    except:
        pass

# Generated at 2022-06-22 21:58:00.410990
# Unit test for function get_bin_path
def test_get_bin_path():
    # Find existing executable
    try:
        bin_path = get_bin_path('/bin/ls')
    except ValueError:
        assert False, 'TEST FAILURE: Unable to find required system executable for /bin/ls'
    assert os.path.exists(bin_path), 'TEST FAILURE: bin_path=%s does not exist' % bin_path
    assert is_executable(bin_path), 'TEST FAILURE: bin_path=%s exists but is not executable' % bin_path
    assert bin_path == '/bin/ls', 'TEST FAILURE: bin_path=%s is not equal to /bin/ls' % bin_path

    # Find existing executable

# Generated at 2022-06-22 21:58:11.845290
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == get_bin_path('ls', [], True)
    assert get_bin_path('ls', []) == get_bin_path('ls', [], True)

    paths = ['/usr/bin', '/usr/local/bin', '/bin', '/usr/sbin']
    assert get_bin_path('ls', paths) == get_bin_path('ls', paths, True)

    paths = ['/usr/bin', '/usr/local/bin', '/bin', '/usr/sbin/']
    assert get_bin_path('ls', paths) == get_bin_path('ls', paths, True)

    assert get_bin_path('ls', ['/usr/bin']) == get_bin_path('ls', ['/usr/bin'], True)

    paths = []

# Generated at 2022-06-22 21:58:18.609036
# Unit test for function get_bin_path
def test_get_bin_path():
    # PATH is set
    assert is_executable(get_bin_path('sh'))

    # PATH is not set
    path = os.environ.get('PATH')
    del os.environ['PATH']
    try:
        assert is_executable(get_bin_path('sh'))
    finally:
        os.environ['PATH'] = path

    # PATH is set but no command found
    assert(get_bin_path('no_command_found') == None)

# Generated at 2022-06-22 21:58:28.657998
# Unit test for function get_bin_path
def test_get_bin_path():
    # Create test directory with one executable file
    test_dir = '/tmp/test_get_bin_path'
    test_exec = 'exec_file'
    os.mkdir(test_dir)
    path = test_dir + "/" + test_exec
    file(path, 'a').close()

# Generated at 2022-06-22 21:58:32.413832
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('foo_bar_bin')
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "foo_bar_bin" in paths: /bin:/usr/bin'

# Generated at 2022-06-22 21:58:36.919249
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    assert get_bin_path('sh', ['/bin', '/usr/bin']) == '/bin/sh'

    with pytest.raises(ValueError):
        get_bin_path("not_exist")

# Generated at 2022-06-22 21:58:38.659130
# Unit test for function get_bin_path
def test_get_bin_path():
    result = get_bin_path('python')
    assert '/usr/bin/python' == result

# Generated at 2022-06-22 21:58:48.920229
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('cp') == '/bin/cp'
    assert get_bin_path('/bin/cp') == '/bin/cp'
    assert get_bin_path('/bin/sh', ['/opt/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/opt/bin']) == '/bin/sh'
    assert get_bin_path('/bin/ls', ['/opt/bin']) == '/bin/ls'

# Generated at 2022-06-22 21:58:57.632104
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import shutil

    # create temporary directory
    tmpdir = '%s/test/test_get_bin_path' % os.path.dirname(os.path.realpath(__file__))
    if os.path.exists(tmpdir):
        shutil.rmtree(tmpdir)
    os.makedirs(tmpdir)

    # create executable scripts
    script1 = '%s/script1' % tmpdir
    with open(script1, 'w') as f:
        f.write('#!/bin/sh\n')
    os.chmod(script1, int('755', 8))
    script2 = '%s/script2' % tmpdir
    with open(script2, 'w') as f:
        f.write('#!/bin/sh\n')
    os

# Generated at 2022-06-22 21:59:04.217370
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os

    test_dir = None


# Generated at 2022-06-22 21:59:15.834757
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Run from test directory (with ls /usr/bin/ls and ls /usr/bin/ls1 present)
    python -m ansible.module_utils.common.file get_bin_path
    """
    print('_' * 79)
    try:
        print('get_bin_path("ls")=%s' % get_bin_path("ls"))
    except ValueError as e:
        print('get_bin_path("ls")=Exception: %s' % str(e))

    try:
        print('get_bin_path("/usr/bin/ls")=%s' % get_bin_path("/usr/bin/ls"))
    except ValueError as e:
        print('get_bin_path("/usr/bin/ls")=Exception: %s' % str(e))


# Generated at 2022-06-22 21:59:17.332373
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-22 21:59:28.884172
# Unit test for function get_bin_path
def test_get_bin_path():

    try:
        get_bin_path('nonexisting_binary')
    except (ValueError, Exception) as e:
        assert str(e) == 'Failed to find required executable "nonexisting_binary" in paths: ' \
                         '/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games'

    try:
        get_bin_path('/usr/bin/pwd')
    except (ValueError, Exception) as e:
        assert str(e) == 'Failed to find required executable "/usr/bin/pwd" in paths: ' \
                         '/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games'

    assert get_bin_path('pwd') == '/bin/pwd'


# Generated at 2022-06-22 21:59:32.100742
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')

    if not os.path.isfile(bin_path):
        raise ValueError('Failed to find executable at path')

# Generated at 2022-06-22 21:59:34.424688
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('python2')
    assert os.path.basename(path) == 'python2'

# Generated at 2022-06-22 21:59:40.314604
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['/tmp/does_not_exist', '/bin', '/sbin', '/usr/sbin']
    bin_path = get_bin_path("true", opt_dirs=paths)
    assert bin_path == '/bin/true'

    paths.append('/does/not/exist')
    bin_path = get_bin_path("true", opt_dirs=paths)
    assert bin_path == '/bin/true'

# Generated at 2022-06-22 21:59:52.730199
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    from distutils.spawn import find_executable

    if sys.platform == 'darwin':
        # test with a mac file that has no extension
        assert get_bin_path('ruby') == find_executable('ruby')
        assert get_bin_path('arch') == find_executable('arch')
        # test with a mac file that has an extension
        assert get_bin_path('ruby.bin') == find_executable('ruby.bin')
        assert get_bin_path('arch.bin') == find_executable('arch.bin')
    elif sys.platform.startswith('linux'):
        # test with a unix file that has no extension
        assert get_bin_path('ruby') == find_executable('ruby')

# Generated at 2022-06-22 22:00:04.939209
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check that if executable exists in PATH, function returns its full path
    assert get_bin_path("/bin/ls") == "/bin/ls"
    # Check that if optional argument opt_dirs is set, its paths are searched in addition to PATH
    assert get_bin_path("ls", opt_dirs=["/bin"]) == "/bin/ls"
    # Check that if directory is not empty, it is not accepted as an executable
    try:
        get_bin_path("/etc", required=True)
        assert False
    except ValueError:
        assert True
    # Check that if none of the paths contain the executable, function raises an Exception
    try:
        get_bin_path("nonexistent")
        assert False
    except ValueError:
        assert True
    # Check that if required is set to True, function raises an

# Generated at 2022-06-22 22:00:09.256937
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', ['/bin']) == '/bin/ls'
    assert get_bin_path('ls', ['/bin', '/usr/bin']) == '/bin/ls'

    try:
        get_bin_path('notexists')
    except ValueError as e:
        assert 'Failed to find required executable "notexists"' in str(e)

# Generated at 2022-06-22 22:00:22.361202
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.file import is_safe_file
    path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    test_bin_path = os.path.join(path, 'lib/ansible/module_utils/basic.py')
    try:
        _bin_path = get_bin_path(test_bin_path)
    except ValueError:
        pass
    else:
        raise AssertionError("get_bin_path() should raise a ValueError if arg is not an executable")
    try:
        _bin_path = get_bin_path(__file__)
    except ValueError:
        pass

# Generated at 2022-06-22 22:00:32.763866
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    def _test_get_bin_path(paths, arg, expected_results):
        # create a fake path with binaries
        temp_dir = tempfile.mkdtemp()
        for path in paths:
            open(os.path.join(temp_dir, path), 'a')

        # test get_bin_path
        try:
            assert get_bin_path(arg, [temp_dir]) == os.path.join(temp_dir, expected_results)
        except AssertionError:
            print('get_bin_path: arg=%s error' % arg)

        shutil.rmtree(temp_dir)

    _test_get_bin_path(['ls', 'ls.exe', 'ls.bat'], 'ls', 'ls')
    _test_get

# Generated at 2022-06-22 22:00:42.170888
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for success
    for cmd in ['which', 'hostname', 'lsb_release']:
        try:
            get_bin_path(cmd)
        except ValueError as e:
            assert False, "Exception running get_bin_path({}): {}".format(cmd, e)

    # Test for failure
    try:
        get_bin_path('does_not_exist')
        assert False, "Function get_bin_path did not throw exception for non-existent executable"
    except ValueError:
        # Expected
        pass

# Generated at 2022-06-22 22:00:50.453940
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    # create a temporary directory to use for testing
    tmpdir = tempfile.mkdtemp()

    # create a file for testing
    file = os.path.join(tmpdir, "test")
    with open(file, "w") as f:
        f.write("#!/bin/sh\necho test")

    # make file executable
    os.chmod(file, 0o777)

    # run the function
    path = get_bin_path("test", opt_dirs=[tmpdir])

    # clean up
    shutil.rmtree(tmpdir)

    assert path == file

# Generated at 2022-06-22 22:01:02.257543
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    temp_dir = tempfile.mkdtemp()
    temp_file = tempfile.mkstemp(prefix=temp_dir+os.sep)[1]
    shutil.rmtree(temp_file)
    os.mkdir(temp_file)
    try:
        assert temp_file.endswith(os.sep+'foo')
        get_bin_path('foo')
        assert False
    except ValueError as e:
        assert 'Failed to find required executable "foo"' in str(e)

# Generated at 2022-06-22 22:01:10.553067
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path
    '''
    # test for files that should not be executable
    try:
        get_bin_path("/etc/shadow")
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError not raised")

    # test for normal file
    testfile = os.path.dirname(__file__) + '/test_file_for_ansible.txt'
    try:
        get_bin_path(testfile)
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError not raised")

    # test for executable file
    testfile = os.path.dirname(__file__) + '/test_file_for_ansible_executable.txt'

# Generated at 2022-06-22 22:01:19.624004
# Unit test for function get_bin_path
def test_get_bin_path():
     try:
         b = get_bin_path('doesnotexist')
     except ValueError as e:
         assert 'doesnotexist' in str(e)
     b = get_bin_path('/bin/ls')
     assert b == '/bin/ls'
     try:
         b = get_bin_path('ls', opt_dirs=['.'])
     except ValueError as e:
         assert 'ls' in str(e)
     b = get_bin_path('ls', opt_dirs=['/bin'])
     assert b == '/bin/ls'