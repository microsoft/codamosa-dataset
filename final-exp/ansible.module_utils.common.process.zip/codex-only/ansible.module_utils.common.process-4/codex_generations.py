

# Generated at 2022-06-22 21:51:18.020897
# Unit test for function get_bin_path
def test_get_bin_path():

    paths = get_bin_path('ls')
    assert 'ls' in paths and os.path.exists(paths)


# Generated at 2022-06-22 21:51:22.508823
# Unit test for function get_bin_path
def test_get_bin_path():
    failed = False
    try:
        get_bin_path('cat')
    except Exception as e:
        print(e)
        failed = True

    if not failed:
        print('test_get_bin_path passed')

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-22 21:51:28.976833
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile

    # Create a "no-exec" file
    fd, path = tempfile.mkstemp()
    os.close(fd)
    os.chmod(path, 0o644)

    # Test for exception handling
    try:
        get_bin_path('cat')
    except ValueError as e:
        assert 'not found' in str(e)

    assert get_bin_path('cat') == '/bin/cat'  # Test with full path
    assert get_bin_path('/bin/cat') == '/bin/cat'  # Full path to executable
    assert get_bin_path('/bin/cat', None) == '/bin/cat'  # Full path to executable
    assert get_bin_path('/bin/cat', []) == '/bin/cat'  # Full path to

# Generated at 2022-06-22 21:51:35.005331
# Unit test for function get_bin_path
def test_get_bin_path():

    if os.path.exists('/bin/true'):
        assert get_bin_path('true', ['/bin']) == '/bin/true'
    elif os.path.exists('/usr/bin/true'):
        assert get_bin_path('true', ['/bin']) == '/usr/bin/true'
    else:
        # maybe another OS?  can't test
        pass

# Generated at 2022-06-22 21:51:43.577996
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.six import PY3

    if PY3:
        assert get_bin_path('python3') == '/usr/bin/python3'

    assert get_bin_path('python2') == '/usr/bin/python2'
    assert get_bin_path('python2.7') == '/usr/bin/python2.7'
    assert get_bin_path('python', opt_dirs='/usr/local/bin') == '/usr/local/bin/python'

    try:
        get_bin_path('Spongebob')
    except ValueError as e:
        assert 'Failed to find required' in str(e)

    assert get_bin_path('python2', opt_dirs='/usr/local/bin') == '/usr/local/bin/python2'


# Generated at 2022-06-22 21:51:51.192839
# Unit test for function get_bin_path
def test_get_bin_path():
    # Create an executable file for the test
    test_exec = '/tmp/ansible_test_exec'
    test_file = open(test_exec, "w")
    test_file.write("#!/usr/bin/python")
    test_file.close()
    os.chmod(test_exec, 0o755)

    assert get_bin_path(test_exec) == test_exec
    new_paths = ['/bin', '/usr/bin', '/usr/local/bin']
    assert get_bin_path("sh", new_paths) == '/bin/sh'
    os.remove(test_exec)

# Generated at 2022-06-22 21:52:00.425442
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    tmpdir = tempfile.mkdtemp()

    # create a fake cat executable in the tmpdir
    fake_path = os.path.join(tmpdir, 'cat')
    with open(fake_path, 'wb') as fake_cat:
        fake_cat.write(b'#!/usr/bin/python\n')

    # make tmpdir first in the search path so that the fake_path
    # will be found first
    old_path = os.environ.get('PATH', '')
    fake_paths = [tmpdir, '/bin', '/usr/bin'] + old_path.split(os.pathsep)
    os.environ['PATH'] = os.pathsep.join(fake_paths)

    # good path
    assert get_bin_path('cat')

# Generated at 2022-06-22 21:52:06.644905
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('nonexistingcommand')
        raise Exception('Should have raised exception')
    except ValueError:
        pass

    try:
        get_bin_path('bash', opt_dirs=('/bin',))
        raise Exception('Should have raised exception')
    except ValueError:
        pass

    assert get_bin_path('sh', opt_dirs=('/bin',)) == '/bin/sh'
    assert get_bin_path('bash', opt_dirs=('/sbin',)) == '/sbin/bash'

# Generated at 2022-06-22 21:52:13.213293
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('/usr/sbin/useradd') == '/usr/sbin/useradd'
    assert get_bin_path('/invalid/path/for/sh') == '/invalid/path/for/sh'
    assert get_bin_path('nonesuch') is None

# Generated at 2022-06-22 21:52:20.961598
# Unit test for function get_bin_path
def test_get_bin_path():
    ansible_module_path = os.path.realpath(
        os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'module_utils', 'basic.py'))
    assert ansible_module_path == get_bin_path('ansible-module-utils', required=False)

    try:
        get_bin_path('this_command_does_not_exist')
        assert False, 'get_bin_path did not raise a ValueError for a command that does not exist'
    except ValueError:
        pass

# Generated at 2022-06-22 21:52:26.534752
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') in os.environ.get('PATH', '').split(os.pathsep)
    assert get_bin_path('sh', ['/bin', '/sbin']) in ['/bin/sh', '/sbin/sh']
    try:
        get_bin_path('shljurrg')
    except ValueError:
        pass
    else:
        assert False, "Expected a ValueError exception on an invalid binary"

# Generated at 2022-06-22 21:52:29.410056
# Unit test for function get_bin_path
def test_get_bin_path():
    expected = "/usr/bin/ls"
    actual = get_bin_path("ls")
    assert expected == actual, "expected %s, got %s" % (expected, actual)

# Generated at 2022-06-22 21:52:40.814714
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible import context
    from ansible.module_utils.six.moves.shutil_which import which
    from distutils.spawn import find_executable

    required_exes = {
        '/usr/bin/python': which('python'),
        '/bin/ls': find_executable('ls'),
        '/bin/sh': context.CLIARGS['module_path'],
    }

    for exe in required_exes:
        assert get_bin_path(os.path.basename(exe)) == required_exes[exe]
        # The Python 2 version of shutil.which returns either a full path or None,
        # but the Python 3 version raises a FileNotFoundError exception in that case.
        # The behavior of this function is based on that of shutil.which, and in
        # particular it should raise

# Generated at 2022-06-22 21:52:50.485119
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    options = {'opt_dirs': None, 'required': None}
    search_path = os.environ.get('PATH', '').split(os.pathsep)
    # Test get_bin_path on required binaries.
    options['opt_dirs'] = search_path
    try:
        get_bin_path('cat', **options)
    except Exception:
        del sys.modules['ansible.module_utils.common.file']
        del sys.modules['ansible.module_utils.common.file']  # why does pytest need this to unload the module?
        raise RuntimeError('Failed to find required executable "cat" in paths: %s' % os.pathsep.join(search_path))
    options['opt_dirs'] = []
    # Test get_bin_path on

# Generated at 2022-06-22 21:53:01.063758
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    # On some distros, /sbin/reboot is a symlink to consolehelper
    assert get_bin_path('reboot', required=True) in ['/sbin/reboot', '/usr/lib/consolehelper/reboot']
    assert get_bin_path('/bin/cat') == '/bin/cat'
    assert get_bin_path('/bin/cat', ['/foo']) == '/bin/cat'
    assert get_bin_path('/bin/cat', required=True) == '/bin/cat'

    import pytest
    with pytest.raises(ValueError):
        get_bin_path('/bin/not_there')

# Generated at 2022-06-22 21:53:10.205818
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves import builtins

    # We don't have the required program, but with a PATH containing a fake bin dir we can make it look like we do
    fake_path = os.pathsep.join(['/fake/bin', '/fake/sbin', os.environ.get('PATH', '')])
    os.environ['PATH'] = fake_path

    fake_bin = '/fake/bin/ansible-test-get-bin-path'
    with open(fake_bin, 'wb') as f:
        f.write(b'#!/bin/sh\necho -n "$@"\n')
        os.chmod

# Generated at 2022-06-22 21:53:16.794322
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('cat')
    assert os.path.exists(bin_path)
    paths = os.environ.get('PATH', '').split(os.pathsep)
    path_ok = False
    for d in paths:
        if bin_path == os.path.join(d, "cat"):
            path_ok = True
            break
    assert path_ok

# Generated at 2022-06-22 21:53:24.044025
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Tests for ansible.utils.get_bin_path
    '''

    # Get the path of an existing executable in PATH
    path = get_bin_path('vim')
    assert path.endswith('vim')

    # Get the path of a non-existing executable in PATH
    try:
        get_bin_path('non_existing_executable')
        assert False, 'This should have thrown a ValueError exception'
    except ValueError:
        pass

    # Get the path of an existing executable not in PATH
    # The argument 'sbin_paths' is used to extend the PATH
    path = get_bin_path('ping', opt_dirs=['/sbin'])
    assert path.endswith('ping')

# Generated at 2022-06-22 21:53:25.393809
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == "/bin/cat"

# Generated at 2022-06-22 21:53:35.591807
# Unit test for function get_bin_path
def test_get_bin_path():
    print('Testing get_bin_path')
    print(('Testing get_bin_path with good path "%s"' % get_bin_path('/bin/sh')))
    try:
        print(('Testing get_bin_path with bad path "%s"' % get_bin_path('/bin/ba')))
    except ValueError:
        print('Test case with bad path passed')
    try:
        print(('Testing get_bin_path with nonexistent path "%s"' % get_bin_path('/bin/ba')))
    except ValueError:
        print('Test case with nonexistent path passed')


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-22 21:53:48.219334
# Unit test for function get_bin_path
def test_get_bin_path():
    # test that it raises exception when command is not found
    try:
        get_bin_path('nonexistent_command')
        assert False
    except ValueError as e:
        assert "Failed to find required executable \"nonexistent_command\"" in str(e)

    # test that it finds a command
    assert get_bin_path('pwd')

    # test that it finds a command in an optional search directory
    assert get_bin_path('echo', opt_dirs=[os.path.dirname(get_bin_path('echo'))])

    # test that it finds a command in an optional search directory in path
    paths = os.environ.get('PATH').split(os.pathsep)
    assert get_bin_path('echo', opt_dirs=[paths[0]])

# Generated at 2022-06-22 21:53:58.072183
# Unit test for function get_bin_path
def test_get_bin_path():
    expected = '/usr/bin/python'
    actual = get_bin_path('python')
    assert actual == expected

    expected = '/usr/bin/python'
    actual = get_bin_path('python', ['/usr/bin'])
    assert actual == expected

    expected = '/tmp/doesnotexist/python'
    actual = get_bin_path('python', ['/tmp/doesnotexist'])
    assert actual == expected

    try:
        get_bin_path('thisdoesnotexist')
        assert 'unreachable' == 'fail: should raise ValueError'
    except ValueError:
        pass

    try:
        get_bin_path('thisdoesnotexist', ['/tmp/doesnotexist'])
        assert 'unreachable' == 'fail: should raise ValueError'
    except ValueError:
        pass

# Generated at 2022-06-22 21:54:03.394994
# Unit test for function get_bin_path
def test_get_bin_path():
    # get_bin_path should raise an Exception for arg `false`
    try:
        bin_path = get_bin_path('false', required=True)
    except ValueError:
        pass
    else:
        raise AssertionError('get_bin_path should have raised an Exception for arg `false`')

# Generated at 2022-06-22 21:54:11.653040
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Test the get_bin_path function with different inputs'''
    import subprocess

    def run(cmd, input=None):
        return subprocess.check_output(cmd, shell=True, input=input)

    # Create test executable
    run('touch /tmp/test.sh')
    run('chmod +x /tmp/test.sh')


# Generated at 2022-06-22 21:54:20.760326
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    import tempfile
    import shutil
    import sys

    if sys.version_info[0] == 2:
        bin_path = tempfile.mktemp()
    else:
        bin_path = tempfile.mktemp(dir=tempfile.gettempdir())


# Generated at 2022-06-22 21:54:31.742713
# Unit test for function get_bin_path
def test_get_bin_path():

    import tempfile, shutil
    import ansible.module_utils.common.file

    def mock_exists(s):
        return s == '/sbin'

    get_bin_path('/bin/false')  # Test system command found

    tmp = tempfile.mkdtemp()

# Generated at 2022-06-22 21:54:39.941523
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.six import PY3

    if not PY3:
        raise Exception("Test only valid for Python 3")

    for opt_dirs in [[], ["/bin", "/usr/bin"], None]:
        for required in [False, True]:
            # Test success
            assert get_bin_path("bash", opt_dirs=opt_dirs, required=required) == "/bin/bash"
            assert get_bin_path("cat", opt_dirs=opt_dirs, required=required) == "/bin/cat"

            # Test failure
            try:
                get_bin_path("fakedir", opt_dirs=opt_dirs, required=required)
                assert False
            except ValueError:
                assert True


# Generated at 2022-06-22 21:54:47.652477
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python' or get_bin_path('python') == '/usr/bin/python2.7'
    assert get_bin_path('python') == '/usr/bin/python' or get_bin_path('python') == '/usr/bin/python2.7'
    assert get_bin_path('python') == '/usr/bin/python' or get_bin_path('python') == '/usr/bin/python2.7'
    assert get_bin_path('python', ['/bin']) == '/usr/bin/python' or get_bin_path('python') == '/usr/bin/python2.7'
    assert get_bin_path('python', ['/usr/bin/python2.7']) == '/usr/bin/python2.7'
    assert get_

# Generated at 2022-06-22 21:54:53.096374
# Unit test for function get_bin_path
def test_get_bin_path():
    #Find the system true binary
    true_bin = get_bin_path('true')
    assert true_bin == '/bin/true'
    #Find the system curl binary
    curl_bin = get_bin_path('curl')
    assert curl_bin == '/usr/bin/curl'
    #Find the system python binary
    python_bin = get_bin_path('python')
    assert python_bin == '/usr/bin/python'

# Generated at 2022-06-22 21:55:02.118088
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # Create a temporary file and set it to be executable
    file_handle, file_path = tempfile.mkstemp()
    os.close(file_handle)
    os.chmod(file_path, 0o755)

    # Find the file in the PATH (which should not contain the directory where the temp file was created)
    file_name = os.path.basename(file_path)
    path_to_file = get_bin_path(file_name)

    # Ensure that the file was found in the path
    assert path_to_file == file_path

    # Clean up
    os.remove(file_path)

# Generated at 2022-06-22 21:55:12.999003
# Unit test for function get_bin_path
def test_get_bin_path():
    # Raise an exception if executable not found,
    # passing optional parameter required=True to
    # test backward compatibility
    try:
        get_bin_path("not_an_executable", required=True)
        assert False
    except ValueError:
        assert True

    # Finds executable in standard paths
    assert get_bin_path("cat")

    # Finds executable in specified empty directory
    assert get_bin_path("cat", ["/dev/null"])

    # Finds executable in specified directory
    assert get_bin_path("cat", ["/bin"])

    # Raises an exception if executable not found in specified directory
    try:
        get_bin_path("cat", ["/dev/null"])
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-22 21:55:21.611818
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path.
    '''
    path_foo = get_bin_path("foo")
    assert path_foo == "/usr/bin/foo"
    path_foo_opt_dirs = get_bin_path("foo", opt_dirs=['/usr/local/bin', '/sbin'])
    assert path_foo_opt_dirs == "/usr/bin/foo"
    path_foo_opt_dirs = get_bin_path("foo", opt_dirs=['/usr/local/bin', '/sbin'])
    assert path_foo_opt_dirs == "/usr/bin/foo"

# Generated at 2022-06-22 21:55:32.883794
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Returns:
        exit status
    '''

# Generated at 2022-06-22 21:55:35.123842
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-22 21:55:40.452182
# Unit test for function get_bin_path
def test_get_bin_path():
    # Directory containing this script.
    root = os.path.join(os.path.dirname(__file__), '..', '..')
    assert os.path.isfile(os.path.join(root, 'README.md'))
    bin_path = os.path.join(root, 'examples', 'scripts')
    assert os.path.isfile(os.path.join(bin_path, 'get_url'))
    assert get_bin_path('get_url', opt_dirs=[bin_path]) == os.path.join(bin_path, 'get_url')
    assert get_bin_path('xdg-open')

# Generated at 2022-06-22 21:55:48.553551
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = os.environ['PATH'].split(os.pathsep)
    for p in paths:
        assert get_bin_path(os.path.basename(p)) == p
    assert get_bin_path('missing_bin_name') == None
    try:
        get_bin_path('missing_bin_name', required=True)
        assert False
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-22 21:55:53.965221
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/bin/sh')
        get_bin_path('sh', required=True)
        get_bin_path('sh', opt_dirs=['/bin'])
    except ValueError as e:
        assert False, "Failed to get shell interpreter: %s" % e

# Generated at 2022-06-22 21:56:01.810808
# Unit test for function get_bin_path
def test_get_bin_path():
    # Python 2.6, 2.7, and 3.2 don't have unittest.TestCase
    try:
        # Try importing TestCase from unittest
        from unittest import TestCase
    except ImportError:
        # Try importing TestCase from unittest2
        from unittest2 import TestCase

    # Create a testcase object
    class MyTestCase(TestCase):
        def runTest(self):
            pass
    my_test_case = MyTestCase()

    # Find git binary in PATH
    try:
        my_test_case.assertIsNotNone(get_bin_path("git"))
    except ValueError as e:
        my_test_case.fail(e)

# Generated at 2022-06-22 21:56:13.960951
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    # copy sys.path so the test doesn't add junk to the real python path
    my_path = list(sys.path)
    my_path.append('/tmp')

    assert get_bin_path('cat') == '/bin/cat', 'Failed to find system executable "cat"'
    assert get_bin_path('no_such_program') == '/bin/cat', 'Failed to find system executable "cat"'
    assert get_bin_path('no_such_program', required=True) == '/bin/cat', 'Failed to find system executable "cat"'
    bin_path = '/path/to/no_such_program'

# Generated at 2022-06-22 21:56:24.608703
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    if not os.path.isfile('/bin/sh'):
        raise Exception('Not a linux system, not continuing with get_bin_path unit test')

    out = StringIO()
    with redirect_stdout(out):
        get_bin_path('sh')
    assert "/bin/sh" == out.getvalue().strip()

    out = StringIO()
    with redirect_stdout(out):
        get_bin_path('nonesuch', required=False)
    assert not out.getvalue()

    out = StringIO()
    with redirect_stdout(out):
        get_bin_path('nonesuch', required=True)
    assert "ValueError"

# Generated at 2022-06-22 21:56:27.781240
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # get a known executable path
        p1 = get_bin_path('sh')
    except Exception:
        p1 = None
    assert p1 is not None

    try:
        # try to get an executable path that doesn't exist
        p2 = get_bin_path('not_in_path')
    except Exception:
        p2 = None
    assert p2 is None

# Generated at 2022-06-22 21:56:39.531465
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    def make_executable_file(name):
        '''
        Make a temporary file with executable permissions
        '''
        fd, tmp = tempfile.mkstemp(prefix=name)
        os.close(fd)
        shutil.chmod(tmp, stat.S_IREAD | stat.S_IEXEC)
        return tmp

    # Create directories for testing
    tmpdir = tempfile.mkdtemp(prefix="tmpdir_ansible_test_")
    path_dirs = [os.path.join(tmpdir, "path1"), os.path.join(tmpdir, "path2")]
    for d in path_dirs:
        os.makedirs(d)

    # Create the executables
    # - one found in PATH
   

# Generated at 2022-06-22 21:56:51.275321
# Unit test for function get_bin_path
def test_get_bin_path():
    # Set up some test data
    required = ['/bin/bar']
    not_required = ['/bin/file-not-there']
    misc_paths = ['/tmp/foo']

    # Test without optional directories
    assert get_bin_path(required[0]) == required[0]
    try:
        get_bin_path(not_required[0])
    except ValueError:
        pass
    else:
        raise AssertionError('get_bin_path failed to raise ValueError for file "%s"' % (not_required[0]))

    # Test with optional directories
    assert get_bin_path(required[0], [misc_paths[0]]) == required[0]

# Generated at 2022-06-22 21:56:54.516354
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('mkfs') == '/sbin/mkfs'



# Generated at 2022-06-22 21:57:03.524958
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os
    import stat


# Generated at 2022-06-22 21:57:13.608180
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    try:
        d = tempfile.mkdtemp()
        with open(os.path.join(d, 'foo'), 'wb') as f:
            f.write(b'#!/bin/sh\nexit 0')
        os.chmod(os.path.join(d, 'foo'), 0o755)
        os.environ['PATH'] = d
        path = get_bin_path('foo')
        assert path == os.path.join(d, 'foo')
    finally:
        if os.environ.get('PATH') == d:
            del os.environ['PATH']
        if os.path.exists(d):
            shutil.rmtree(d)

# Generated at 2022-06-22 21:57:25.942470
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic

    # Test 1: simple scenario
    module = basic.AnsibleModule(argument_spec={})
    module.run_command = lambda *a, **kw: 'git_dir' in a[1] and 0 or 1
    git_dir = module.get_bin_path('git')
    assert git_dir is not None
    assert git_dir == 'git'

    # Test 2: required is True, raise PrintableError
    # Test 3: required is False, return None
    with module.assert_prints('Failed to find required executable "hello" in paths: ',
                              '%s' % os.pathsep.join(os.environ.get('PATH', '').split(os.pathsep))):
        module.get_bin_path('hello', required=True)


# Generated at 2022-06-22 21:57:33.705147
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import sys
    import tempfile
    import shutil

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # This directory will be searched first
    bindir = os.path.join(tmpdir, 'bin')
    os.mkdir(bindir)
    # Create a dummy file
    (fd, name) = tempfile.mkstemp(prefix="ansible_test_", dir=bindir)
    os.close(fd)
    # Remove file, we just want the name
    os.remove(name)


# Generated at 2022-06-22 21:57:40.698070
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # /bin/sh should exist on all unix systems
        assert get_bin_path('sh', ['/bin']) == '/bin/sh'
        assert get_bin_path('sh') == '/bin/sh'
        assert get_bin_path('sh', ['/bin'], False) == '/bin/sh'
    except ValueError as e:
        raise Exception('get_bin_path("sh") failed: %s' % e)

# Generated at 2022-06-22 21:57:50.616398
# Unit test for function get_bin_path
def test_get_bin_path():

    assert(get_bin_path('python'))
    assert(get_bin_path('python', opt_dirs=[]))
    assert(get_bin_path('python', opt_dirs=['/bin']))
    assert(get_bin_path('python', opt_dirs=['/bin', '/sbin']))
    assert(get_bin_path('python', opt_dirs=['/does/not/exist']))
    assert(get_bin_path('python', opt_dirs=['/usr/bin/python']))

    assert(get_bin_path('python', opt_dirs=['/bin']) == '/bin/python')
    assert(get_bin_path('python', opt_dirs=['/bin', '/sbin']) == '/bin/python')

# Generated at 2022-06-22 21:58:01.596943
# Unit test for function get_bin_path
def test_get_bin_path():
    # only test when in Ansible
    try:
        import ansible
    except ImportError:
        return
    # Test if this is a path on PATH
    def test_valid_command(command):
        test_path = get_bin_path(command)
        assert os.path.exists(test_path)
        assert is_executable(test_path)
    test_valid_command('python')
    # Test if this is not a path on PATH
    def test_command_not_found(command):
        try:
            get_bin_path(command)
            assert False
        except ValueError:
            pass
    test_command_not_found('doesnotexist')
    # Test that given a list of directories, the command will be found

# Generated at 2022-06-22 21:58:07.808957
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh').endswith('sh')
    assert get_bin_path('sh', opt_dirs=['./']).endswith('sh')
    try:
        get_bin_path('no-such-binary')
    except ValueError:
        pass
    else:
        assert False, "get_bin_path should have thrown a ValueError on unknown binary"

# Generated at 2022-06-22 21:58:11.753476
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    tf = tempfile.NamedTemporaryFile()
    os.chmod(tf.name, 0o775)
    bin_path = get_bin_path(os.path.basename(tf.name))
    assert bin_path == tf.name

# Generated at 2022-06-22 21:58:21.408979
# Unit test for function get_bin_path
def test_get_bin_path():
    test_executable = 'ls'
    result = get_bin_path(test_executable)
    assert is_executable(result), \
        "Failed to return full path of %s executable (%s)" % (test_executable, result)
    try:
        result = get_bin_path('missing_executable')
    except ValueError as e:
        assert e.args[0] == "Failed to find required executable \"missing_executable\" in paths: %s" % os.environ.get('PATH', ''), \
            "Failed to raise ValueError on non-existent executable."
    else:
        raise AssertionError("Failed to raise ValueError on non-existent executable")

# Generated at 2022-06-22 21:58:32.768981
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import platform

    print('Python version')
    print(sys.version_info)
    print('Platform')
    print(platform.platform())
    print('Platform distribution')
    print(platform.linux_distribution())

    # Cross-platform method to find an executable in PATH
    print('which cat')
    print(get_bin_path('cat'))

    # Should always raise an exception
    try:
        print('which foo')
        print(get_bin_path('foo'))
    except ValueError as e:
        print(e)

    # Method to find an executable in PATH, with optional directories
    print('which ldd')
    print(get_bin_path('ldd', opt_dirs=['/usr/bin']))

# Generated at 2022-06-22 21:58:41.400953
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('curl')
    assert isinstance(path, str)
    assert len(path) > 0

    try:
        path = get_bin_path('no_such_program')
        assert False
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "no_such_program" in paths: /sbin:/usr/sbin:/usr/local/sbin'

    path = get_bin_path('awk', ['/'])
    assert isinstance(path, str)
    assert path == '/awk'

# Generated at 2022-06-22 21:58:50.979879
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = [
        # expected_executable_name, expected_return_value, path_dir_list
        ('/bin/ls', '/bin/ls', ['/bin', '/usr/bin']),
        ('/bin/ls', '/bin/ls', ['/usr/bin', '/bin']),
        ('/usr/bin/python2.7', '/usr/bin/python2.7', ['/usr/bin', '/bin', '/usr/sbin']),
        ('/usr/bin/python', None, ['/usr/bin', '/bin', '/usr/sbin']),
    ]
    saved_path = os.environ['PATH']
    for path in paths:
        os.environ['PATH'] = os.pathsep.join(path[2])

# Generated at 2022-06-22 21:58:51.833182
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh')

# Generated at 2022-06-22 21:59:00.157984
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check that get_bin_path works as expected in all cases
    required_not_found = ['/bin/sh', '/bin/sh2', '/bin/sh3']
    required_found = ['/bin', '/usr/bin', '/bin/sh']
    not_required_not_found = ['/bin/sh', '/bin/sh2', '/bin/sh3']
    not_required_found = ['/bin', '/usr/bin', '/bin/sh']

    # Check that an exception is raised when required and not found
    for p in required_not_found:
        try:
            get_bin_path(p, required=True)
        except:
            pass
        else:
            raise AssertionError('Passed test which should have failed: "%s".' % p)

    # Check that a path is returned when required

# Generated at 2022-06-22 21:59:11.431823
# Unit test for function get_bin_path
def test_get_bin_path():
    import mock
    import sys
    import tempfile

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestGetBinPath(unittest.TestCase):

        def test_get_bin_path(self):
            with mock.patch('ansible.module_utils.common.file.is_executable') as mock_exec:
                mock_exec.return_value = True
                with tempfile.NamedTemporaryFile() as tf:
                    cmd = tf.name
                    self.assertEqual(get_bin_path(cmd), cmd)
                    mock_exec.assert_called_once_with(cmd)


# Generated at 2022-06-22 21:59:20.657200
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import shutil
    from tempfile import NamedTemporaryFile
    import os

    if sys.version_info[0] == 2:
        import tempfile
        tempfile.TemporaryDirectory = NamedTemporaryFile


# Generated at 2022-06-22 21:59:30.505613
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile

    # test - no directories given
    bin = 'bin'
    exec_ = 'exec'
    try:
        tmpdir = tempfile.mkdtemp()
        tmp = os.path.join(tmpdir, bin)
        os.makedirs(tmp)
        exec_path = os.path.join(tmp, exec_)
        with open(exec_path, 'w') as tmp_file:
            tmp_file.write('#!/bin/bash\nexit 0')
        os.chmod(exec_path, 0o700)

        assert get_bin_path(exec_) == exec_path
    finally:
        shutil.rmtree(tmpdir)

    # test - one directory given

# Generated at 2022-06-22 21:59:36.777179
# Unit test for function get_bin_path
def test_get_bin_path():
    # Get executable path for program in standard location
    mount_path = get_bin_path('mount')
    assert mount_path == '/bin/mount'
    # Get executable path for program in distro specific location
    yum_path = get_bin_path('yum')
    assert yum_path == '/usr/bin/yum'

# Generated at 2022-06-22 21:59:38.027195
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("a-nonexistent-command", [], required=True) == 1

# Generated at 2022-06-22 21:59:42.426845
# Unit test for function get_bin_path
def test_get_bin_path():
    if 'ANSIBLE_TEST_GET_BIN_PATH' in os.environ:
        arg = os.environ.get('ANSIBLE_TEST_GET_BIN_PATH')
        bin_path = get_bin_path(arg)
        print(bin_path)

        return 0
    else:
        return 255


# Generated at 2022-06-22 21:59:54.537142
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1
    try:
        from ansible.module_utils.common.file import get_bin_path
        get_bin_path(arg='ls', required=False)
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError to be raised as path for 'ls' is not set in PATH")
    # Test 2
    try:
        get_bin_path(arg='ls', opt_dirs='/bin')
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError to be raised as path for 'ls' is not set in /bin")

    # Test 3
    path = get_bin_path(arg='ls', opt_dirs='/bin', required=False)
    if path != '/bin/ls':
        raise Assert

# Generated at 2022-06-22 22:00:06.845543
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # Create a temp dir
    td = tempfile.mkdtemp()
    # Create a file in the temp dir: it will be searched path
    fp = os.path.join(td, 'foo')
    with open(fp, 'w') as f:
        f.write('#!/bin/sh\nexit 0')
    os.chmod(fp, 0o755)
    # Create a file in the temp dir: it will NOT be searched path
    fp = os.path.join(td, 'bar')
    with open(fp, 'w') as f:
        f.write('#!/bin/sh\nexit 0')
    os.chmod(fp, 0o600)
    # Create a directory in the temp dir: it will NOT be searched path

# Generated at 2022-06-22 22:00:11.853530
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('true') == '/bin/true')
    assert(get_bin_path('false') == '/bin/false')
    try:
        assert(get_bin_path('foobar_is_not_exists') == '/bin/foobar_is_not_exists')
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-22 22:00:17.416371
# Unit test for function get_bin_path
def test_get_bin_path():
    """Basic module execution test
    """
    args = {'arg': 'python', 'opt_dirs': None, 'required': True}
    expected_results = 'python'
    results = get_bin_path(**args)
    assert results == expected_results, \
        'Results returned are not equal to the expected results'

# Generated at 2022-06-22 22:00:28.225446
# Unit test for function get_bin_path
def test_get_bin_path():
    test_dict = {
        'find_find': {
            'arg': 'find',
            'expected': '/usr/bin/find',
        },
        'tac_find': {
            'arg': 'tac',
            'expected': '/usr/bin/tac',
        },
        'mkfs_find': {
            'arg': 'mkfs',
            'expected': '/sbin/mkfs',
        },
        'fail_find': {
            'arg': 'doesnotexist',
            'expected': None,
        }
    }
    for path, test_desc in test_dict.items():
        arg = test_desc.pop('arg')
        if test_desc['expected']:
            result = get_bin_path(arg)

# Generated at 2022-06-22 22:00:34.235027
# Unit test for function get_bin_path
def test_get_bin_path():
    with open('mytest.py', 'w') as f:
        f.write('#!/usr/bin/python\n')
    os.system('chmod +x mytest.py')

    test_dirs = ['/tmp']
    test_path = get_bin_path('mytest.py', test_dirs)

    assert test_path == os.path.join(os.path.abspath('.'), 'mytest.py')

# Generated at 2022-06-22 22:00:45.841112
# Unit test for function get_bin_path
def test_get_bin_path():
    # locate a system binary
    print('Testing get_bin_path function.')
    bin_path = get_bin_path(arg='pwd')
    assert bin_path is not None
    print('get_bin_path result: %s' % bin_path)

    # test exception with bad argument
    try:
        print('Testing get_bin_path with exception.')
        bad_path = get_bin_path('bad_pwd')
        assert False, "Expected exception."
    except ValueError:
        assert True, "Expected exception"

    # test behavior with empty path argument
    assert get_bin_path(arg='') is None

    # test behavior with optional dir argument
    assert get_bin_path(arg='pwd', opt_dirs=['/bin', '/usr/bin']) is not None



# Generated at 2022-06-22 22:00:49.901120
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/sbin']) == '/bin/ls'
    try:
        get_bin_path('unlikelyname')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-22 22:01:01.867989
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    assert get_bin_path('bash') == '/bin/bash'

    with pytest.raises(ValueError, match='Failed to find required executable "missing_binary" in paths: '):
        get_bin_path('missing_binary')

    # Test the optional argument opt_dirs.
    assert get_bin_path('bash', opt_dirs=['/usr/sbin', '/sbin']) == '/bin/bash'

    # Test the optional argument required.
    with pytest.raises(ValueError, match='Failed to find required executable "missing_binary2" in paths: '):
        get_bin_path('missing_binary2', required=True)


# -*- -*- -*- End included fragment: lib/ansible/module_utils/basic.py -*- -*

# Generated at 2022-06-22 22:01:09.461885
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.facts import get_file_content
    from ansible.module_utils._text import to_bytes

    rc, out, err = get_file_content('/proc/sys/kernel/osrelease')
    assert rc == 0

    paths = ['.']
    arg = to_bytes('python')
    try:
        print(get_bin_path(arg, opt_dirs=paths, required=False))
        print(get_bin_path(arg, opt_dirs=paths, required=True))
    except ValueError:
        print("Failed to find required executable \"%s\" in paths: %s" % (arg, os.pathsep.join(paths)))

# Generated at 2022-06-22 22:01:21.797001
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test find an executable in PATH
    path = get_bin_path("ls")
    assert os.path.exists(path)
    assert os.path.basename(path) == "ls"

    # Test not find an executable
    try:
        get_bin_path("test-command-not-exists-1234")
    except Exception as e:
        assert "Failed to find required executable" in str(e)
    else:
        assert False, "Should be raised"

    # Test with opt_dirs
    path = get_bin_path("pwd", opt_dirs=["/usr/bin", "/bin", "/usr/sbin"])
    assert os.path.exists(path)
    assert os.path.basename(path) == "pwd"