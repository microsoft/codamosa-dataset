

# Generated at 2022-06-22 21:51:24.003931
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os

    # setup directories
    tempdir = tempfile.mkdtemp()
    dir1 = os.path.join(tempdir, 'dir1')
    dir2 = os.path.join(tempdir, 'dir2')
    os.makedirs(dir1)
    os.makedirs(dir2)

    # setup executable
    pycmd = 'python -c "import sys; sys.exit(0)"'
    execfile = os.path.join(dir1, 'execfile')
    with open(execfile, 'w') as f:
        f.write(pycmd)

    # test executable in opt_dirs
    assert get_bin_path(execfile, opt_dirs=[dir1]) == execfile

    # test executable not in opt_dirs


# Generated at 2022-06-22 21:51:34.010893
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.process import get_bin_path as get_bin_path_ansible
    import platform

    required_bin_for_systems = {
        'Linux': 'ls',
        'Darwin': 'ls',
        'FreeBSD': 'ls',
        'SunOS': 'ls',
        'AIX': 'ls',
        'HP-UX': 'bdf',
    }

    os_name = platform.system()
    required_bin = required_bin_for_systems.get(os_name, None)
    if required_bin is None:
        print('Skipping get_bin_path() tests for system %s' % os_name)
        return

    # Test fail

# Generated at 2022-06-22 21:51:42.604686
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = [None, '/usr/bin', '/usr/local/bin', '/bin']
    for p in paths:
        try:
            assert(get_bin_path('ls', opt_dirs=p) == '/bin/ls')
            assert(get_bin_path('ls', opt_dirs=p, required=True) == '/bin/ls')
        except ValueError:
            assert(p == None)
        try:
            assert(get_bin_path('non-existent-bin-file', opt_dirs=p) == None)
        except ValueError:
            assert True
        try:
            get_bin_path('non-existent-bin-file', opt_dirs=p, required=True)
            assert False
        except ValueError:
            assert True

# Generated at 2022-06-22 21:51:49.694731
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/usr/bin']) == '/usr/bin/sh'
    try:
        get_bin_path('sh', opt_dirs=['/non/existing/path'])
    except ValueError:
        pass
    else:
        assert False, 'Invalid path should raise ValueError'

# Generated at 2022-06-22 21:51:59.657659
# Unit test for function get_bin_path
def test_get_bin_path():

    def test1(arg, paths=None, required=True):
        bin_path = get_bin_path(arg, paths, required)
        assert bin_path is not None
        return bin_path

    def test2(arg, paths=None, required=True):
        try:
            bin_path = get_bin_path(arg, paths, required)
        except ValueError:
            return
        assert False, 'should have failed'

    my_path = '/usr/bin:/usr/local/bin'
    assert test1('sh', ['/bin']) == '/bin/sh'
    assert test1('ls') == '/bin/ls'
    assert test1('ls') == '/bin/ls'
    assert test1('ls', ['/bin']) == '/bin/ls'

# Generated at 2022-06-22 21:52:08.167960
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat


# Generated at 2022-06-22 21:52:13.342310
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.path.exists('/usr/bin/python'):
        assert get_bin_path('python') == '/usr/bin/python'
    else:
        # No garantee that /bin/python exists, so find python using PATH
        assert get_bin_path('python')

    assert get_bin_path('somewhere the sun does not shine')

# Generated at 2022-06-22 21:52:19.527186
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = []

    path_echo = get_bin_path('echo', paths)
    assert path_echo

    paths = ['/bin', '/usr/bin', '/sbin', '/usr/sbin', '/usr/local/sbin']

    path_echo = get_bin_path('echo', paths)
    assert path_echo

    try:
        get_bin_path('badexecutable', paths)
    except ValueError:
        pass

# Generated at 2022-06-22 21:52:28.561314
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/bash') == '/bin/bash'
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('bash', opt_dirs=['/bin', '/usr/bin', '/usr/local/bin']) == '/bin/bash'
    assert get_bin_path('bash', opt_dirs=['/usr/bin', '/bin', '/usr/local/bin']) == '/bin/bash'
    assert get_bin_path('bash', opt_dirs=['/usr/bin', '/usr/local/bin', '/bin']) == '/bin/bash'
    assert get_bin_path('bash', opt_dirs=['/not/exist', '/bin']) == '/bin/bash'

# Generated at 2022-06-22 21:52:36.093825
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('foo')
        assert False, 'Expected ValueError due to foo not found in path'
    except ValueError as e:
        assert 'foo' in str(e)
    try:
        get_bin_path('passwd')
        assert True, 'passwd found in path'
    except Exception as e:
        assert False, 'Expected to find passwd in path'

# Generated at 2022-06-22 21:52:46.881537
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function that verifies get_bin_path()
    '''

    try:
        resume_path = get_bin_path('resume', ['/usr/bin', '/usr/sbin'])
        if resume_path != '/usr/bin/resume':
            raise Exception('get_bin_path("resume", ["/usr/bin", "/usr/sbin"]) returned %s' % resume_path)
    except ValueError as e:
        raise Exception('Exception of type ValueError raised for get_bin_path("resume", ["/usr/bin", "/usr/sbin"]): %s' % e)


# Generated at 2022-06-22 21:52:51.639745
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('foobar')
        assert False, "Expected ValueError"
    except ValueError:
        pass

    assert get_bin_path('sh', ['/bin']) == "/bin/sh"

    get_bin_path('true', required=True)

# Generated at 2022-06-22 21:52:57.608403
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('ip') == '/sbin/ip'
    assert get_bin_path('ip', opt_dirs=['/usr/bin']) == '/usr/bin/ip'
    assert get_bin_path('inexistant_binary') == 'find executable inexistant_binary in path /sbin:/usr/sbin:/usr/local/sbin'

# Generated at 2022-06-22 21:53:07.643119
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    if PY3:
        import sysconfig
    else:
        from distutils import sysconfig

    is_executable_mock_side_effects = (False, True, True)
    is_executable_mock_call_args = []

    def is_executable_mock(path):
        is_executable_mock_call_args.append(path)

        return is_executable_mock_side_effects.pop(0)

    def py3_get_config_var_mock(arg):
        if arg == 'BINDIR':
            return b"/usr/bin"
        elif arg == 'BINLIBDIR':
            return b"/usr/lib"



# Generated at 2022-06-22 21:53:11.878716
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test that get_bin_path() raises ValueError if executable is not found.
    try:
        get_bin_path('foo')
    except ValueError as e:
        assert 'Failed to find required executable "foo"' in str(e)

# Generated at 2022-06-22 21:53:18.758219
# Unit test for function get_bin_path
def test_get_bin_path():
    # Runs only if invoked from source root dir
    if os.path.isfile('test/sanity/code-smell/test_get_bin_path.py'):
        import sys
        import subprocess
        code = subprocess.call([sys.executable, '-m', 'unittest', 'discover', '-s', 'test/sanity/code-smell/', '-p', 'test_get_bin_path.py'])
        sys.exit(code)

# Generated at 2022-06-22 21:53:30.065305
# Unit test for function get_bin_path
def test_get_bin_path():
    valid_exes = ["cat", "python", "python3"]
    invalid_exes = ["cato", "pythono", "python3o"]
    test_paths = [None, "/bin", "/usr/bin", "/usr/local/bin"]
    for exe in valid_exes:
        try:
            get_bin_path(exe)
        except ValueError as e:
            assert False, "Did not find %s in PATH: %s" % (exe, e)

    for exe in invalid_exes:
        try:
            get_bin_path(exe)
            assert False, "Found invalid exe %s in PATH" % exe
        except ValueError:
            pass

    # find executables with optional paths

# Generated at 2022-06-22 21:53:35.098775
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    from ansible.module_utils.common.process import get_bin_path

    def test_bin_path(arg, opt_dirs, expected, side_effect=None):
        def mocked_is_executable(path):
            return True

        return_value = expected

        if side_effect is not None:
            return_value = side_effect

        with pytest.raises(Exception) if expected is None else no_raise():
            with mock.patch('ansible.module_utils.common.file.is_executable', side_effect=mocked_is_executable):
                assert get_bin_path(arg, opt_dirs=opt_dirs) == return_value

    test_bin_path('echo', [], '/bin/echo', side_effect=ValueError)
    test_bin_

# Generated at 2022-06-22 21:53:48.082492
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test the get_bin_path function.  This function is NOT part of the public
    API.  The function and tests may disappear in future versions of
    Ansible.
    '''
    import os

    # Create a temporary directory

# Generated at 2022-06-22 21:53:57.929891
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import shutil
    import tempfile
    from ansible.module_utils.common.file import get_bin_path

    module_name = __name__
    if module_name.startswith('ansible.module_utils.'):
        module_name = module_name[len('ansible.module_utils.'):]


# Generated at 2022-06-22 21:54:03.203805
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test without required parameter
    path = get_bin_path('sh')
    assert path == '/bin/sh' or path == '/sbin/sh'
    # Test with opt_dirs
    path = get_bin_path('sh', ['/usr/bin'])
    assert path == '/usr/bin/sh'
    # Test with empty opt_dirs
    path = get_bin_path('sh', [])
    assert path == '/bin/sh' or path == '/sbin/sh'

# Generated at 2022-06-22 21:54:09.119560
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible-module-invalidmodule') == '/usr/bin/ansible-module-invalidmodule'
    assert get_bin_path('ansible-module-package') == '/usr/bin/ansible-module-package'
    assert get_bin_path('invalidmodule', opt_dirs=['/usr/bin']) == '/usr/bin/invalidmodule'
    try:
        assert get_bin_path('invalidmodule') == ''
    except ValueError:
        pass

# Generated at 2022-06-22 21:54:19.712517
# Unit test for function get_bin_path
def test_get_bin_path():
    # We can't guarantee /bin/sh actually exists, but it should on all systems
    assert(get_bin_path('sh') == '/bin/sh')
    assert(get_bin_path('sh', opt_dirs=['/sbin']) == '/sbin/sh')
    assert(get_bin_path('sh', opt_dirs=['/sbin', '/bin']) == '/bin/sh')
    # Assert that correct exception is raised.
    # get_bin_path will raise ValueError, but we want to make sure that it's the correct ValueError

# Generated at 2022-06-22 21:54:25.763483
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible-test') == get_bin_path('ansible-test', ['/bin'])
    assert get_bin_path('ansible-test') == get_bin_path('ansible-test', ['/usr/bin'])
    assert get_bin_path('ansible-test') == get_bin_path('ansible-test', ['/usr/local/bin'])
    assert get_bin_path('ansible-test') == get_bin_path('ansible-test', ['/usr/local/bin', '/bin'])
    assert get_bin_path('ansible-test') != get_bin_path('ansible-test', ['/usr/bin', '/etc'])

# Generated at 2022-06-22 21:54:36.569133
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('/bin/bash') == '/bin/bash'
    assert get_bin_path('/bin/cat') == '/bin/cat'
    assert get_bin_path('/bin/sh', ['/usr/bin', '/bin']) == '/bin/sh'
    assert get_bin_path('/bin/bash', ['/usr/bin', '/bin']) == '/bin/bash'
    assert get_bin_path('/bin/cat', ['/usr/bin', '/bin']) == '/bin/cat'
    assert get_bin_path('/bin/sh', ['/nonexistent/dir']) == '/bin/sh'

# Generated at 2022-06-22 21:54:47.940979
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    from ansible.module_utils.six import PY2, b

    d = tempfile.gettempdir()
    tmp_path = d + '/ansible_test_get_bin_path'
    open(tmp_path, 'a').close()

# Generated at 2022-06-22 21:54:50.727509
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/usr/bin/ls' == get_bin_path('ls')
    assert '/bin/ls' == get_bin_path('ls', opt_dirs={'/bin', '/sbin'})

# Generated at 2022-06-22 21:55:01.753006
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import os

    # Get values for PATH, PATHEXT and extensions for the current OS.
    pathsep = os.pathsep
    paths = os.path.expandvars(os.environ['PATH']).split(pathsep)
    if os.name == 'nt':
        extensions = os.path.expandvars(os.environ['PATHEXT']).split(os.pathsep)
    else:
        extensions = ['']

    # Test 1 - Ensure expected path separator is available in the test environment.
    assert pathsep == ':'

    # Test 2 - Test the module itself for successful discovery of its own executable.
    mybin = get_bin_path(os.path.basename(sys.executable), paths)
    assert mybin == sys.executable


# Generated at 2022-06-22 21:55:12.818074
# Unit test for function get_bin_path
def test_get_bin_path():
    # test default path
    try:
        get_bin_path('sh')
    except ValueError:
        assert False, "Executable 'sh' is not found but it should be in default system PATH"

    # test custom path
    try:
        get_bin_path('sh', opt_dirs=['/bin'])
    except ValueError:
        assert False, "Executable 'sh' is not found but it should be in '/bin'"

    # test executable is not found
    try:
        get_bin_path('no_such_command')
        assert False, "We expect that executable 'no_such_command' is not found."
    except ValueError:
        pass

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-22 21:55:18.211353
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("ls") == "/bin/ls"
    assert get_bin_path("ls", []) == "/bin/ls"
    try:
        get_bin_path("bogus", [])
        assert False
    except:
        pass

    assert get_bin_path("netstat", ["/usr/bin"]) == "/usr/bin/netstat"

# Generated at 2022-06-22 21:55:21.978748
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Test get_bin_path function '''

    result_bin_path = get_bin_path('sh')
    Test.assertTrue(result_bin_path, 'Failed to find required executable "sh" in paths.')

# Generated at 2022-06-22 21:55:33.236325
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test that get_bin_path raises error when given path to binary that does not exist
    try:
        get_bin_path("does_not_exist")
        # Execution should never get here.
        assert False
    except ValueError:
        assert True

    # Test that get_bin_path raises error when given path to binary that exists but is not executable
    try:
        get_bin_path("/dev/null")
        # Execution should never get here.
        assert False
    except ValueError:
        assert True

    # Test that get_bin_path finds unix 'find' binary in all the places it should

# Generated at 2022-06-22 21:55:36.733562
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    try:
        get_bin_path('not_a_binary')
        assert False
    except ValueError:
        assert True

    try:
        get_bin_path('cat', ['/no/such/path'])
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-22 21:55:42.504128
# Unit test for function get_bin_path
def test_get_bin_path():
    test_cases = (
        ('bash', '/bin/bash'),
        ('/bin/bash', '/bin/bash'),
        ('nanosleep', '/usr/bin/nanosleep'),
    )
    for (cmd, expected) in test_cases:
        result = get_bin_path(cmd)
        assert result == expected, \
            'expected: %s, actual: %s' % (expected, result)

# Generated at 2022-06-22 21:55:54.619117
# Unit test for function get_bin_path
def test_get_bin_path():
    import ansible.module_utils.common.file

    orig_stat_func = os.stat

    # Force a failure in os.stat
    def fake_stat(path):
        raise OSError

    fixture_paths = [
        'bad_path',
        '/usr/bin/foo',
        '/usr/bin/bar',
        '/usr/bin/baz',
        '/usr/bin/qux',
        '/usr/local/bin/qux',
    ]

    # Set up our fake path and files
    def fake_glob(path):
        return fixture_paths

    def fake_exists(path):
        return path in fixture_paths

    def fake_isfile(path):
        return path in fixture_paths

    # We need to keep the original function around so we can restore it


# Generated at 2022-06-22 21:56:02.994669
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('foo') == '/bin/foo'
    assert get_bin_path('./foo') == './foo'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/foo') == '/bin/foo'

    assert get_bin_path('ls', opt_dirs=[]) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/sbin']) == '/sbin/ls'

# Generated at 2022-06-22 21:56:14.581535
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('not_an_executable')
        assert False, 'Path for not_an_executable should not be found'
    except ValueError:
        pass

    try:
        get_bin_path('echo')
        assert True
    except ValueError:
        assert False, 'Path for echo should have been found'

    try:
        get_bin_path('bash', opt_dirs=['/'])
        assert True
    except ValueError:
        assert False, 'Path for bash should have been found'

    try:
        get_bin_path('bash', opt_dirs=['/not_a_dir'])
        assert False, 'Path for bash should not have been found'
    except ValueError:
        pass

# Generated at 2022-06-22 21:56:25.100615
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no_such_executable')
        assert False
    except ValueError:
        pass
    assert 'python' in get_bin_path('python')
    assert 'ps' in get_bin_path('ps')
    assert 'sh' in get_bin_path('sh')
    # Test opt_dirs argument
    assert 'ps' in get_bin_path('ps', ['/bin', '/usr/bin'])
    opt_dirs = ['/bin', '/foo/bar']
    items = get_bin_path('sh', opt_dirs)
    if os.path.exists('/foo/bar') and '/foo/bar' not in items:
        assert False
    # Test required argument (deprecated)

# Generated at 2022-06-22 21:56:30.243298
# Unit test for function get_bin_path
def test_get_bin_path():
    # /usr/bin exists and is reachable, so /usr/bin/python is found
    assert get_bin_path("python") == "/usr/bin/python"
    # /usr/bin exists, but is not reachable (unlikely, but possible)
    with mock.patch("os.environ", new={"PATH": ""}):
        with pytest.raises(ValueError):
            get_bin_path("python")
    # /usr/bin does not exist (unlikely, but possible)
    with mock.patch("os.environ", new={"PATH": ""}):
        with mock.patch("os.path.exists") as os_path_exists:
            os_path_exists.return_value = False
            with pytest.raises(ValueError):
                get_bin_path("python")


# Generated at 2022-06-22 21:56:40.705114
# Unit test for function get_bin_path

# Generated at 2022-06-22 21:56:52.565604
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function
    '''
    assert get_bin_path("python") == "python"
    assert get_bin_path("python", opt_dirs=["/bin"]) == "python"
    assert get_bin_path("/bin/python", opt_dirs=["/bin"]) == "/bin/python"
    assert get_bin_path("/bin/python", opt_dirs=["/usr/bin"]) == "/bin/python"

    try:
        assert get_bin_path("python", opt_dirs=["/doesnot_exist"])
        assert False, "Expected ValueError exception"
    except ValueError:
        assert True


# Generated at 2022-06-22 21:57:02.325740
# Unit test for function get_bin_path
def test_get_bin_path():

    def run_test(path=None, required=None, expected_error=None):
        try:
            if path is None and required is None:
                get_bin_path('cat')
            elif path is None:
                get_bin_path('cat', required=required)
            elif required is None:
                get_bin_path('cat', opt_dirs=[path])
            else:
                get_bin_path('cat', opt_dirs=[path], required=required)
            if expected_error is not None:
                raise AssertionError('Expected an Exception to be raised but none was raised')
        except Exception as ex:
            if expected_error is None:
                raise AssertionError('Unexpected Exception raised while testing get_bin_path: %s' % ex)

# Generated at 2022-06-22 21:57:13.758555
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') is not None
    assert get_bin_path('ls', opt_dirs=['/bin']) is not None
    try:
        get_bin_path('does_notexist_ls')
        assert False, 'Expected exception to be thrown'
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "does_notexist_ls" in paths: /sbin:/usr/sbin:/usr/local/sbin:/usr/bin:/bin:/usr/local/bin:/usr/bin'
    except Exception as e:
        assert False, 'Unexpected exception thrown: %s' % str(e)

# Generated at 2022-06-22 21:57:18.848647
# Unit test for function get_bin_path
def test_get_bin_path():
    if not os.path.exists('/usr/bin/which'):
        raise Exception('This test needs the /usr/bin/which command')
    path = get_bin_path('which')
    if path != '/usr/bin/which':
        raise Exception('This test needs the /usr/bin/which command')

# Generated at 2022-06-22 21:57:25.669506
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('yes', required=True)
    assert bin_path == '/usr/bin/yes'
    bin_path = get_bin_path('yes', opt_dirs=['/usr/bin'])
    assert bin_path == '/usr/bin/yes'
    try:
        bin_path = get_bin_path('no-way-this-should-exist')
    except ValueError:
        pass

# Generated at 2022-06-22 21:57:32.804286
# Unit test for function get_bin_path
def test_get_bin_path():
    # test for invalid path
    try:
        get_bin_path('/usr/bin/test_bin')
    except ValueError:
        pass
    else:
        assert False

    # test for valid path
    path = get_bin_path('ls')
    assert os.path.exists(path)

    # test for path with opt_dirs
    path = get_bin_path('ls', opt_dirs='/bin')
    assert os.path.exists(path)

# Generated at 2022-06-22 21:57:37.740512
# Unit test for function get_bin_path
def test_get_bin_path():
    # test that it can find the unrar binary
    get_bin_path('unrar')

    # test that it can find the unrar binary in the specified directories
    get_bin_path('unrar', opt_dirs=['/tmp'])

# Generated at 2022-06-22 21:57:44.209080
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' get_bin_path should return an executable file on path or raise error
    '''
    for p in [None, '/usr/bin/', '/usr/local/bin']:
        assert get_bin_path('sh', p) is not None
    # there is no /usr/bin/false, this should raise exception
    raised = False
    try:
        get_bin_path('false')
    except ValueError:
        raised = True
    assert raised is True

# Generated at 2022-06-22 21:57:53.314792
# Unit test for function get_bin_path
def test_get_bin_path():
    result = get_bin_path('/bin/ls')
    assert result == '/bin/ls'
    result = get_bin_path('ls')
    assert result == '/bin/ls'
    result = get_bin_path('ls', opt_dirs=['/bin', '/usr/bin'])
    assert result == '/bin/ls'
    import pytest
    with pytest.raises(ValueError):
        get_bin_path('thisdoesntexist', opt_dirs=['/bin', '/usr/bin'])

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-22 21:57:56.470082
# Unit test for function get_bin_path
def test_get_bin_path():
    test_dirs = ['/bin', '/usr/bin']
    test_arg = 'ls'
    assert get_bin_path(test_arg, test_dirs) == '/bin/ls'

# Generated at 2022-06-22 21:57:58.669627
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('chmod')
    assert path == '/bin/chmod'

# Generated at 2022-06-22 21:58:02.451698
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('which') is not None
    try:
        get_bin_path('nonexistingcommand')
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-22 21:58:10.254829
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('id') is not None
    try:
        get_bin_path('id-123')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    assert get_bin_path('id-123', opt_dirs=[]) is None
    assert get_bin_path('id-123', opt_dirs=['/usr/bin']) is None
    assert get_bin_path('id-123', opt_dirs=['/usr/bin/id']) is not None

# Generated at 2022-06-22 21:58:16.776117
# Unit test for function get_bin_path
def test_get_bin_path():
    """ Test for function get_bin_path """
    paths = os.environ['PATH'].split(os.pathsep)
    binary_path = get_bin_path('ls')
    assert binary_path in paths
    try:
        binary_path = get_bin_path('this_binary_does_not_exist')
    except ValueError as ve:
        assert 'Failed to find required executable "this_binary_does_not_exist"' in str(ve)

# Generated at 2022-06-22 21:58:21.314927
# Unit test for function get_bin_path
def test_get_bin_path():

    binary_found = get_bin_path("syslog-ng")
    assert binary_found != None

    # binary not found, expect ValueError
    try:
        binary_not_found = get_bin_path("not-exists")
        assert False
    except Exception as e:
        assert True

# Generated at 2022-06-22 21:58:33.502682
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    validate get_bin_path function
    '''
    import os
    from ansible.module_utils.common._collections_compat import Mapping

    exp_dirs = os.environ.get('PATH', '').split(os.pathsep)
    exp_dirs += ['/sbin', '/usr/sbin', '/usr/local/sbin']

    # get_bin_path should return the first occurrence of an executable found within a directory
    # in the PATH environment variable that also exists in the file system.
    exp_paths = []
    for d in exp_dirs:
        if d is not None and os.path.exists(d):
            exp_paths.append(d)

    for d in exp_paths:
        for f in os.listdir(d):
            f

# Generated at 2022-06-22 21:58:38.733100
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # Assert that 'pwd' can be found
        ret = get_bin_path('pwd')
        # Assert that 'fakebin' cannot be found
        ret = get_bin_path('fakebin')
    except ValueError:
        # An Exception was correctly raised
        pass
    else:
        # An Exception should have been raised
        assert False

# Generated at 2022-06-22 21:58:48.961047
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test the get_bin_path function.
    '''
    from ansible.module_utils import basic

    def _test(arg, opt_dirs, expected):
        try:
            bin_path = get_bin_path(arg, opt_dirs)
        except ValueError as err:
            assert err.args == (expected,)
        else:
            assert bin_path == expected, bin_path


# Generated at 2022-06-22 21:58:54.278081
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Function get_bin_path tests'''
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', ['/usr/local/bin', '/usr/bin', '/bin']) == '/usr/bin/python'
    try:
        get_bin_path('invalid_executable', required=False)
    except ValueError:
        pass  # Expected result

# Generated at 2022-06-22 21:58:56.943093
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Return a string containing the full path to the 'true' command
    that is found in the default path.
    '''
    true_path = '/bin/true'
    assert get_bin_path('true') == true_path

# Generated at 2022-06-22 21:59:00.503748
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('pwd')
    assert os.path.exists(path)
    assert not os.path.isdir(path)
    assert is_executable(path)

# Generated at 2022-06-22 21:59:12.209907
# Unit test for function get_bin_path
def test_get_bin_path():

    import tempfile

    # Test finding the current python executable
    my_python = get_bin_path('python')
    assert os.path.basename(my_python) == 'python'
    assert os.path.isfile(my_python)
    assert is_executable(my_python)

    # On some systems (notably MacOS) the sh link to bash is not
    # present so we can't check for a specific path when looking for
    # /bin/sh
    assert os.path.basename(get_bin_path('sh')) == 'sh'

    assert os.path.basename(get_bin_path('dash', opt_dirs=[tempfile.gettempdir()])) == 'dash'

    # Test missing file

# Generated at 2022-06-22 21:59:15.632983
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        bin_path = get_bin_path('cat')
        assert(bin_path == '/bin/cat')
    except ValueError:
        print('test_get_bin_path: cat missing?')
        assert(False)

# Generated at 2022-06-22 21:59:23.657759
# Unit test for function get_bin_path
def test_get_bin_path():

    # Check utility functions in module utils.path
    assert get_bin_path("python3") == "/usr/bin/python3"
    assert get_bin_path("python3", ['/home/user/bin']) == "/home/user/bin/python3"
    assert get_bin_path("python3", ["/usr/local/bin"]) == "/usr/local/bin/python3"
    assert get_bin_path("python3", ["/usr/bin"]) == "/usr/bin/python3"

# Generated at 2022-06-22 21:59:34.719057
# Unit test for function get_bin_path
def test_get_bin_path():
    # get the path of the id command
    path_to_id = get_bin_path('id')

    # check if it is a valid path
    assert os.path.isfile(path_to_id)
    assert is_executable(path_to_id)

    # check if it returns the correct path
    assert path_to_id == '/usr/bin/id'

    # check it raises an exception when the command is not found
    try:
        get_bin_path('this_command_should_never_exist')
        assert False
    except ValueError:
        assert True

    # check it raises an exception when the path points to a directory
    try:
        get_bin_path('/dev')
        assert False
    except ValueError:
        assert True

    # check it raises an exception when the path points to something

# Generated at 2022-06-22 21:59:36.976462
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Return a absolute path of a file in PATH'''
    assert get_bin_path('getent') == '/usr/bin/getent'


# Generated at 2022-06-22 21:59:45.998120
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('whoami', ['/bin']) == '/bin/whoami'
    assert get_bin_path('whoami', ['/bin', '/usr/bin']) == '/bin/whoami'
    assert get_bin_path('whoami', ['/usr/bin', '/bin']) == '/usr/bin/whoami'
    assert get_bin_path('whoami', ['/usr/bin', None]) == '/usr/bin/whoami'
    assert get_bin_path('whoami', [None, '/usr/bin']) == '/usr/bin/whoami'
    assert get_bin_path('whoami', ['/nodir']) == '/usr/bin/whoami'

# Generated at 2022-06-22 21:59:52.383720
# Unit test for function get_bin_path
def test_get_bin_path():
    exe = get_bin_path('sh')
    assert os.path.exists(exe) and os.path.isfile(exe) and os.access(exe, os.X_OK)

    try:
        get_bin_path('frobble_fran_flun_fron')
        raise AssertionError('get_bin_path did not raise ValueError for bogus path')
    except ValueError:
        pass

# Generated at 2022-06-22 22:00:04.342574
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('false') == '/bin/false'
    assert get_bin_path('/bin/true') == '/bin/true'
    assert get_bin_path('/bin/true', ['/bin']) == '/bin/true'
    assert get_bin_path('true', ['/bin']) == '/bin/true'
    try:
        get_bin_path('/bin/true', ['/sbin'])
        assert False
    except ValueError as e:
        assert 'Failed to find required executable "/bin/true" in paths' in str(e)
    try:
        get_bin_path('false', ['/sbin', '/bin'])
        assert False
    except ValueError as e:
        assert 'Failed to find required executable "false" in paths' in str(e)
   

# Generated at 2022-06-22 22:00:14.287959
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import os
    import shutil
    import sys
    import pytest

    if not isinstance(__loader__, pytest.File):  # if we are running as a pytest module, this is redundant
        pytest_plugins = 'pytester'

    class TestBase():
        # Taken from module_utils.common.test_base
        def get_test_data(self, name):
            if not self.testdata_path:
                self.testdata_path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
                self.testdata_path = os.path.join(self.testdata_path, 'test', 'unit', 'test_data')
            return os.path.join(self.testdata_path, name)


# Generated at 2022-06-22 22:00:25.147131
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import errno
    good_path = '/bin/ls'
    bad_path = '/foo/bar/some_exec'
    dir_path = '/etc/'
    people = ["Peter", "Paul", "Mary"]
    tmpdir = tempfile.mkdtemp()
    tmpdir_bad = os.path.join(tmpdir, 'foo')
    tmpdir_empty = os.path.join(tmpdir, 'empty')
    os.makedirs(tmpdir_bad)
    os.makedirs(tmpdir_empty)

    (tmphandle, tmppath) = tempfile.mkstemp(prefix='ansible_test_file_')


# Generated at 2022-06-22 22:00:36.606510
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os

    orig_environ_path = os.environ['PATH']
    orig_path = os.path
    orig_os_access = os.access

    tmp_dir = tempfile.mkdtemp(prefix='ansible-tmp')
    bin_dir = tempfile.mkdtemp(prefix='ansible-tmp', dir=tmp_dir)
    fake_bin = os.path.join(bin_dir, 'my-fake-bin')

    def cleanup():
        shutil.rmtree(tmp_dir)
        os.environ['PATH'] = orig_environ_path
        os.path = orig_path
        os.access = orig_os_access


# Generated at 2022-06-22 22:00:42.074220
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.process import get_bin_path as test_get_bin_path
    p = test_get_bin_path('foo')
    assert p is None
    p = test_get_bin_path('sh')
    assert p is not None

# Generated at 2022-06-22 22:00:53.029536
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert bin_path == '/bin/sh'
    bin_path = get_bin_path('sh', opt_dirs=['/sbin'])
    assert bin_path == '/sbin/sh'
    bin_path = get_bin_path('sh', opt_dirs=['/sbin', '/bin'])
    assert bin_path == '/bin/sh'

# Generated at 2022-06-22 22:01:01.194500
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Test get_bin_path function, verify that it always raises a ValueError when the executable isn't found.
    """

    # Get executable from PATH, it should be found
    get_bin_path('ls')

    # Add a non existing directory to PATH and the executable should not be found
    try:
        get_bin_path('ls', ['/non/existing/path'])
        raise AssertionError('get_bin_path should have raised a ValueError with a non existing directory in PATH')
    except ValueError:
        pass

# Generated at 2022-06-22 22:01:10.017374
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.system import platform_defaults

    try:
        import pytest
        has_pytest = True
    except Exception:
        has_pytest = False

    try:
        import selinux
        has_selinux = True
    except ImportError:
        has_selinux = False


# Generated at 2022-06-22 22:01:19.486226
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    # Test failure
    try:
        get_bin_path('nonexistent_prog_test', required=True)
        sys.exit(1)  # This should not be reached
    except:
        pass

    # Test success
    if get_bin_path('python') is None:
        sys.exit(1)  # This should not be reached

    sys.exit(0)  # If we reach this point everything went well


if __name__ == '__main__':
    # Simple test for get_bin_path
    test_get_bin_path()