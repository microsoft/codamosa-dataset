

# Generated at 2022-06-22 21:51:26.076444
# Unit test for function get_bin_path
def test_get_bin_path():
    import random  # noqa
    import string  # noqa
    import tempfile  # noqa

    # Create a random filename
    path_len = random.randint(10, 20)
    path = tempfile.mkdtemp()
    filename = ''.join(
        random.choice(string.ascii_uppercase + string.digits) for _ in range(path_len)
    )

    # Validate the easy cases
    assert get_bin_path(filename) == filename
    assert get_bin_path(os.path.join(path, filename)) == os.path.join(path, filename)

    # Make sure it does not exist
    assert not os.path.exists(os.path.join(path, filename))

    # Make sure it can not be found

# Generated at 2022-06-22 21:51:29.460382
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest

    args = ['cat', 'not_there', 'ls']
    paths = ['/usr/bin', '/bin', '/usr/local/bin']

    for a in args:
        try:
            assert get_bin_path(a, paths)
        except ValueError:
            if a == 'not_there':
                pass
            else:
                raise


# Generated at 2022-06-22 21:51:37.805116
# Unit test for function get_bin_path
def test_get_bin_path():
    def mock_exists(path):
        return path.endswith('/cat') or path.endswith('/echo')

    try:
        original_exists = os.path.exists
        os.path.exists = mock_exists
        assert get_bin_path('echo', opt_dirs=['/bin', '/usr/bin']) == '/bin/echo'
        assert get_bin_path('cat', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/cat'
        assert get_bin_path('cat') == '/bin/cat'
        assert get_bin_path('cat', required=True) == '/bin/cat'
    finally:
        os.path.exists = original_exists

# Generated at 2022-06-22 21:51:46.838047
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Run the unit test for function get_bin_path
    '''

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    import io
    import sys

    try:
        to_native = to_bytes
    except NameError:
        to_native = lambda x: x

    # Capture the result of get_bin_path so it can be tested on all Python versions.
    _get_bin_path = get_bin_path

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    # Make sure we are using AnsibleModule
    assert isinstance(module, AnsibleModule)

    # test path with PATH=/usr/bin
    # test path with PATH=/usr/bin:/bin
    # test path with PATH

# Generated at 2022-06-22 21:51:52.152535
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Make sure get_bin_path returns the correct value
    '''
    assert get_bin_path('python') == '/usr/bin/python'


# Generated at 2022-06-22 21:51:53.619224
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'

# Generated at 2022-06-22 21:51:57.126971
# Unit test for function get_bin_path
def test_get_bin_path():
    import unittest

    class TestGetBinPath(unittest.TestCase):
        def test_get_bin_path(self):
            from ansible.module_utils.common._text import to_bytes
            ls = to_bytes(get_bin_path('ls'))
            self.assertIn(b'ls', ls)

# Generated at 2022-06-22 21:52:06.972192
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test passing incorrect required argument.
    try:
        get_bin_path('/bin/ls', require=True)
    except TypeError:
        pass
    else:
        assert False, 'Expected exception for passing incorrect argument to get_bin_path'

    # Test passing incorrect optional argument.
    try:
        get_bin_path('/bin/ls', opt_dir=None)
    except TypeError:
        pass
    else:
        assert False, 'Expected exception for passing incorrect argument to get_bin_path'

    # Test passing non-string argument.
    try:
        get_bin_path(5)
    except TypeError:
        pass
    else:
        assert False, 'Expected exception for passing non-string argument to get_bin_path'

    # Test a bad path.

# Generated at 2022-06-22 21:52:17.851946
# Unit test for function get_bin_path
def test_get_bin_path():
    goodpaths = []
    goodpaths.append(get_bin_path('lsb_release'))
    goodpaths.append(get_bin_path('lsb_release', ['/usr/bin', '/bin']))
    goodpaths.append(get_bin_path('lsb_release', ['/bin', '/usr/bin']))
    # This combination should work on every OS that runs Ansible
    goodpaths.append(get_bin_path('ps', ['/bin', '/usr/bin'], required=True))
    # Check the negative cases
    try:
        get_bin_path('nonexistent_app')
    except:
        pass
    else:
        assert False

# Generated at 2022-06-22 21:52:28.372778
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'

    # Test with opt_dirs
    assert get_bin_path('ls', opt_dirs=[]) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/bin/ls'
    # Note for the following test case, /tmp is added to the PATH, so the function
    # returns the first path, which is /tmp/ls


# Generated at 2022-06-22 21:52:40.502564
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/bin']) == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/bin', '/usr/bin/']) == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/bin', '/usr/bin/', '/usr/bin']) == '/usr/bin/python'


# Generated at 2022-06-22 21:52:44.238397
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh', opt_dirs=['/bin', '/usr/bin']) == '/bin/sh'

    try:
        get_bin_path('nonexist')
    except Exception as e:
        assert 'Failed to find required executable' in str(e)

# Generated at 2022-06-22 21:52:50.709543
# Unit test for function get_bin_path
def test_get_bin_path():
    # No optional arguments
    assert get_bin_path('python') == '/usr/bin/python'
    # No optional arguments with a required executable
    try:
        get_bin_path('python3')
        assert False, "Unexpected success finding python3"
    except ValueError as e:
        assert "Failed to find required executable" in str(e)
    # With optional arguments
    assert get_bin_path('python', opt_dirs=['/usr/local/bin']) == '/usr/local/bin/python'

# Generated at 2022-06-22 21:52:56.818517
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/bin'], required=False) == '/usr/bin/sh'
    try:
        get_bin_path('sh', ['.'])
    except (ValueError):
        pass
    else:
        assert False

# Generated at 2022-06-22 21:53:06.842218
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat


# Generated at 2022-06-22 21:53:14.584891
# Unit test for function get_bin_path
def test_get_bin_path():
    import platform
    import sys
    import tempfile
    test_dir = tempfile.mkdtemp()  # Create a temp dir
    test_bin = 'test_bin'
    test_bin_path = os.path.join(test_dir, test_bin)
    with open(test_bin_path, 'wb') as f:
        f.write(b'#!/bin/sh\necho')
    os.chmod(test_bin_path, 0o755)  # ensure it's executable
    os.environ['PATH'] = test_dir

    actual_bin_path = get_bin_path(test_bin)
    assert actual_bin_path.endswith('/' + test_bin)

# Generated at 2022-06-22 21:53:24.495868
# Unit test for function get_bin_path
def test_get_bin_path():
    import ansible.module_utils.basic

    # Test get_bin_path with required executable in PATH
    test_bin_path = ansible.module_utils.basic.get_bin_path('ansible')
    assert test_bin_path == os.path.abspath('ansible')

    # Test get_bin_path with required executable not in PATH
    try:
        ansible.module_utils.basic.get_bin_path('qwertyuiopasdfghjklzxcvbnm')
    except ValueError as e:
        assert 'Failed to find required executable "qwertyuiopasdfghjklzxcvbnm"' in e.args[0]

# Generated at 2022-06-22 21:53:27.783889
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cp') is not None
    assert get_bin_path('does_not_exist') is None
    # shell builtin 'seq'
    assert get_bin_path('seq', opt_dirs=['/bin']) is not None

# Generated at 2022-06-22 21:53:29.719387
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = get_bin_path('cat')
    assert paths == '/bin/cat'



# Generated at 2022-06-22 21:53:33.984768
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    import tempfile

    # create a temporary script file and set it to chmod 755
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)
    open(temp_path, 'w').close()
    os.chmod(temp_path, 0o755)
    # ensure that the script can be found in the command path
    bin_path = get_bin_path(to_bytes(os.path.basename(temp_path)))
    assert bin_path == to_bytes(temp_path)
    # ensure that a non-executable, non-directory file generates an exception
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)
    open(temp_path, 'w').close()


# Generated at 2022-06-22 21:53:47.384014
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check paths with and without /sbin directories
    real_path = os.environ.get('PATH', None)
    os.environ['PATH'] = '/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('ifconfig') == '/sbin/ifconfig'
    assert get_bin_path('vsftpd') == '/usr/local/sbin/vsftpd'

    os.environ['PATH'] = '/usr/local/bin:/usr/bin:/bin'
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('ifconfig') == '/sbin/ifconfig'

# Generated at 2022-06-22 21:53:58.140753
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'test_bin': {'type': 'str', 'default': 'sh'},
                                          'path': {'type': 'list', 'default': []}})

    # Test if non-existing binary result in exception
    try:
        get_bin_path('non-existing')
    except ValueError as e:
        assert "Failed to find required executable" in str(e)
    else:
        assert False, "get_bin_path did not result in exception"

    # Test if existing binary works
    test_bin = get_bin_path(module.params['test_bin'], module.params['path'])
    assert test_bin == '/bin/sh' or test_bin == '/usr/bin/sh'

# Generated at 2022-06-22 21:54:02.509596
# Unit test for function get_bin_path
def test_get_bin_path():

    bp = get_bin_path('cat')
    assert bp == '/bin/cat'

    bp = get_bin_path('cat', ['/bin'])
    assert bp == '/bin/cat'

    try:
        bp = get_bin_path('does_not_exist')
        assert False, 'get_bin_path did not fail'
    except ValueError:
        assert True


# Generated at 2022-06-22 21:54:11.439561
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    bin_path = '/bin/ls'
    arg = os.path.basename(bin_path)
    paths = [os.path.dirname(bin_path)]
    assert get_bin_path(arg, paths) == bin_path

# Generated at 2022-06-22 21:54:16.227572
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('ls')
    except:
        raise AssertionError("get_bin_path('ls') failed")
    try:
        get_bin_path('does-not-exist')
        raise AssertionError("get_bin_path('does-not-exist') failed to raise an exception")
    except:
        pass

# Generated at 2022-06-22 21:54:27.453928
# Unit test for function get_bin_path
def test_get_bin_path():
    # Case 1: ls binary is found in PATH
    bin_path = get_bin_path('ls')
    assert bin_path
    # Case 2: ls binary is not found in PATH
    # In Ansible 2.10 and later, get_bin_path always raises an Exception
    # if the executable cannot be found in PATH.
    try:
        get_bin_path('not_a_program')
        assert False
    except ValueError:
        # Expected Exception
        pass
    # Case 3: ls binary is found in a custom directory
    opt_path = os.path.dirname(bin_path)
    bin_path = get_bin_path('ls', opt_dirs=[opt_path])
    assert bin_path
    # Case 4: ls binary is not found in a custom directory

# Generated at 2022-06-22 21:54:36.970898
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.file import __file__ as _file

    # Test1: /bin/ls should be found in default path
    bin_path = get_bin_path('ls')
    assert bin_path == '/bin/ls'

    # Test2: 'ls' should be found in custom path
    bin_path = get_bin_path('ls', opt_dirs=['/sbin'])
    assert bin_path == '/sbin/ls'

    # Test3: 'ls' should be found in multiple custom paths
    bin_path = get_bin_path('ls', opt_dirs=['/', '/sbin'])
    assert bin_path == '/ls'

    # Test3: 'does_not_exist' should not be found

# Generated at 2022-06-22 21:54:42.203676
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' ut_utils.py: Unit test for function get_bin_path '''

    for path in ("/bin/sh", "/usr/bin/awk", "/usr/bin/perl", "/bin/sed", "/bin/gawk"):
        assert get_bin_path(os.path.split(path)[1]) == path

# Generated at 2022-06-22 21:54:52.392185
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function
    '''
    test_paths = ['/usr/bin', '/usr/local/bin', '/opt/bin']
    try:
        get_bin_path('this-cmd-does-not-exi-st', required=True)
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    except Exception:
        assert False
    try:
        get_bin_path('uname', required=True)
    except ValueError:
        assert False
    
    # Test file not in path
    try:
        get_bin_path('not_in_path', test_paths, required=True)
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

# Generated at 2022-06-22 21:55:03.105926
# Unit test for function get_bin_path
def test_get_bin_path():
    import filecmp

    test_path_dir = './test/get_bin_path'
    bin_file1 = os.path.join(test_path_dir, 'bin1')
    bin_file2 = os.path.join(test_path_dir, 'bin2')

    # Create two executable files and put them in a directory not in PATH
    f = open(bin_file1, 'w')
    f.write('test')
    f.close()
    os.chmod(bin_file1, 0o0777)

    f = open(bin_file2, 'w')
    f.write('test')
    f.close()
    os.chmod(bin_file2, 0o0777)

    # Find an executable file that is not in PATH

# Generated at 2022-06-22 21:55:09.501210
# Unit test for function get_bin_path
def test_get_bin_path():

    path = get_bin_path('sh')
    assert path == '/bin/sh', 'get_bin_path returned unexpected result'

    try:
        get_bin_path('sh', opt_dirs=['/foo'])
    except:
        pass
    else:
        raise AssertionError('get_bin_path should raise an exception when sh is not found')

# Generated at 2022-06-22 21:55:19.285815
# Unit test for function get_bin_path
def test_get_bin_path():
    # Require binary
    get_bin_path('openssl')
    get_bin_path('openssl')
    # Require binary with optional search directories
    get_bin_path('openssl', opt_dirs=['/bin', '/sbin'])
    get_bin_path('openssl', opt_dirs=['/sbin', '/bin'])
    # Require binary with optional search directories
    try:
        get_bin_path('foo-bar')
        assert False, 'Binary foo-bar should not be found'
    except:
        pass
    # Require binary with optional search directories
    try:
        get_bin_path('foo-bar', opt_dirs=['/bin', '/sbin'])
        assert False, 'Binary foo-bar should not be found'
    except:
        pass

# Generated at 2022-06-22 21:55:21.022690
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-22 21:55:25.672444
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('not a real t00l')
        assert False, 'Expected ValueError'
    except ValueError as e:
        assert 'required executable' in str(e)

    path = get_bin_path('ls')
    assert is_executable(path)

# Generated at 2022-06-22 21:55:35.876789
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test default path
    assert get_bin_path('grep') == '/bin/grep'

    # Test dirs with None
    assert get_bin_path('grep', ['/bin', '/sbin', None, '/tmp']) == '/bin/grep'
    assert get_bin_path('grep', opt_dirs=None) == '/bin/grep'
    assert get_bin_path('grep', opt_dirs=[]) == '/bin/grep'

    # Test dirs with custome paths
    assert get_bin_path('grep', ['.', '/bin', '/sbin', '/tmp']) == '/bin/grep'

    # Test missing required executable

# Generated at 2022-06-22 21:55:44.917965
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    temp_path = tempfile.mkdtemp()
    with open(temp_path + '/foo.bin', 'w') as f:
        f.write("")

    os.chmod(temp_path + '/foo.bin', 0o777)

    # Existing file
    assert get_bin_path('foo.bin', [temp_path]) == temp_path + '/foo.bin'

    # Existing file with absolute path
    assert get_bin_path(temp_path + '/foo.bin') == temp_path + '/foo.bin'

    # Not existing file
    try:
        get_bin_path('foo2.bin', [temp_path])
    except ValueError:
        pass

# Generated at 2022-06-22 21:55:56.393789
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    try:
        get_bin_path('/bin/ls')       # Fully Qualified Path should match
    except:
        raise AssertionError('Fully Qualified Path should match')

    try:
        get_bin_path('ls_not_exist')  # Non-existant should raise an exception
    except ValueError:
        pass
    else:
        raise AssertionError('Should raise an exception for non-existant file')

    try:
        get_bin_path('.')  # Is a directory should raise an exception
    except ValueError:
        pass
    else:
        raise AssertionError('Should raise an exception for directory')


# Generated at 2022-06-22 21:56:04.059779
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import __builtin__
    # save some builtins
    __builtin__.__dict__['old_os_environ'] = os.environ
    __builtin__.__dict__['old_sys_path'] = sys.path
    def teardown():
        __builtin__.__dict__['os'] = __builtin__.__dict__['old_os']
        __builtin__.__dict__['sys'] = __builtin__.__dict__['old_sys']
        __builtin__.__dict__['os.path'] = __builtin__.__dict__['old_os_path']
        os.environ = __builtin__.__dict__['old_os_environ']
        sys.path = __builtin__.__dict__['old_sys_path']
   

# Generated at 2022-06-22 21:56:15.200759
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import tempfile
    import shutil

    def _touch_executable_in_dir(dirname, filename):
        path = os.path.join(dirname, filename)
        open(path, 'w').close()
        os.chmod(path, 0o755)
        return path


# Generated at 2022-06-22 21:56:17.686109
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-22 21:56:28.723194
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    test_path = os.path.curdir
    test_file = 'test_file'
    test_full_path = os.path.join(test_path, test_file)

    os.mkdir(test_path)
    fd, tmpfile = tempfile.mkstemp(dir=test_path, text=True)
    os.close(fd)
    os.chmod(tmpfile, 0o700)
    assert get_bin_path('coreutils')
    assert get_bin_path('coreutils')
    assert get_bin_path(test_file, [test_path]) == test_full_path
    assert get_bin_path(test_file, [test_path]) == test_full_path

# Generated at 2022-06-22 21:56:40.234166
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("true") in [
        "/usr/bin/true",
        "/bin/true",
        "/usr/local/bin/true",
        "/Library/Frameworks/Python.framework/Versions/Current/bin/true",
        "/usr/local/sbin/true",
        "/usr/sbin/true",
    ]

    assert get_bin_path("false") in [
        "/usr/bin/false",
        "/bin/false",
        "/usr/local/bin/false",
        "/Library/Frameworks/Python.framework/Versions/Current/bin/false",
        "/usr/local/sbin/false",
        "/usr/sbin/false",
    ]

# Generated at 2022-06-22 21:56:46.688607
# Unit test for function get_bin_path
def test_get_bin_path():
    for x in ('/bin'):
        assert get_bin_path('sh') == os.path.join(x, 'sh')
    for x in ('/sbin', '/usr/sbin', '/usr/local/sbin'):
        assert get_bin_path('ip') == os.path.join(x, 'ip')

# Generated at 2022-06-22 21:56:57.465809
# Unit test for function get_bin_path
def test_get_bin_path():

    # Test to check if function raises exception when required is set to True.
    try:
        get_bin_path('not_a_executable', None, True)
    except ValueError as e:
        ex = e
    assert str(ex) == 'Failed to find required executable "not_a_executable" in paths: /usr/bin:/bin:/usr/sbin:/sbin'

    # Test to check if function raises exception when required is set to False.
    try:
        get_bin_path('not_a_executable', None, False)
    except ValueError as e:
        ex = e
    assert str(ex) == 'Failed to find required executable "not_a_executable" in paths: /usr/bin:/bin:/usr/sbin:/sbin'

    # Test to check if function returns the path of

# Generated at 2022-06-22 21:57:05.484997
# Unit test for function get_bin_path
def test_get_bin_path():

    def test_result(expected, arg, opt_dirs=None, required=None):
        result = get_bin_path(arg, opt_dirs, required)
        assert expected == result

    test_result('/sbin/foo', 'foo', ['/sbin'])
    # Test that the opt_dirs argument has precedence over the PATH environment variable
    test_result('/sbin/foo', 'foo', ['/sbin'], True)
    test_result('/bar/foo', 'foo', ['/bar'], True)
    test_result('/usr/local/sbin/foo', 'foo', [], True)
    test_result('/usr/local/sbin/foo', 'foo', [], None)
    # Test that the sbin directories are appended to the PATH environment variable

# Generated at 2022-06-22 21:57:10.485666
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python')
    assert get_bin_path('python', ['/opt/bin'])
    assert get_bin_path('python', ['/opt/bin']) == '/opt/bin/python'
    import sys
    assert get_bin_path('python', ['/opt/bin']) != sys.executable

# Generated at 2022-06-22 21:57:17.258137
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    with patch.dict('os.environ', {'PATH': ''}, clear=True):
        with tempfile.NamedTemporaryFile() as tf:
            os.chmod(tf.name, 0o777)

            # Test added directories
            assert get_bin_path(os.path.basename(tf.name), [os.path.dirname(tf.name)]) == tf.name

            # Test PATH directories
            with patch.dict('os.environ', {'PATH': os.path.dirname(tf.name)}):
                assert get_bin_path(os.path.basename(tf.name)) == tf.name

            # Test non-existent executable

# Generated at 2022-06-22 21:57:24.227673
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python2') == '/usr/bin/python2'
    assert get_bin_path('python3') == '/usr/bin/python3'
    assert get_bin_path('python2.7') == '/usr/bin/python2.7'
    assert get_bin_path('python3.6') == '/usr/bin/python3.6'

# Generated at 2022-06-22 21:57:32.925742
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.six import PY3

    def fail(arg, opt_dirs):
        try:
            get_bin_path(arg, opt_dirs)
        except ValueError:
            pass
        else:
            raise AssertionError('Failed to find required executable "%s" in paths: %s' % (arg, os.pathsep.join(paths)))

    if PY3:
        # Test that we're looking in the right places
        paths = os.environ.get('PATH', '').split(os.pathsep)
        if '/sbin' not in paths:
            get_bin_path('sh')
            fail('bash', ['/sbin'])

# Generated at 2022-06-22 21:57:44.039500
# Unit test for function get_bin_path
def test_get_bin_path():
    import ansible.module_utils.common.file as ans_file
    import platform
    import os

    # Mock out is_executable() so we can check some error cases
    def test_is_executable(file):
        if file.endswith("fail"):
            return False
        else:
            return True

    ans_file.is_executable = test_is_executable
    old_PATH = os.environ['PATH']
    old_PWD = os.environ['PWD']
    old_HOME = os.environ['HOME']

# Generated at 2022-06-22 21:57:45.129845
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/bin/sh' == get_bin_path('sh')



# Generated at 2022-06-22 21:57:57.077991
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    import tempfile
    from ansible.module_utils.common.process import get_bin_path as gpb

    # create a temporary executable file
    fh, test_exe = tempfile.mkstemp()
    os.close(fh)
    os.chmod(test_exe, 0o755)

    test_bin = "/bin/test_bin_path"
    if os.path.isfile(test_bin):
        test_bin = os.path.join('/usr/', test_bin[1:])

    # check that we can find test_exe
    assert gpb(os.path.basename(test_exe)) == test_exe

    # check that we get an exception on unfound binary

# Generated at 2022-06-22 21:58:08.364185
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.environ.get('PATH') is None:
        os.environ['PATH'] = '/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin'

    assert get_bin_path('ping') == '/usr/bin/ping'
    assert get_bin_path('ping', opt_dirs=[], required=False) == '/usr/bin/ping'
    assert get_bin_path('ping', opt_dirs=['/usr/bin'], required=False) == '/usr/bin/ping'
    assert get_bin_path('ping', opt_dirs=[os.path.dirname(__file__)], required=False) == '/usr/bin/ping'


# Generated at 2022-06-22 21:58:17.975442
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/sbin', '/usr/sbin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/sbin', '/usr/sbin']) == '/bin/sh'
    try:
        get_bin_path('foobar', opt_dirs=['/sbin', '/usr/sbin'])
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "foobar" in paths: /bin:/usr/bin:/sbin:/usr/sbin:/usr/local/bin:/usr/local/sbin'

# Generated at 2022-06-22 21:58:28.178805
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.six import PY3
    from ansible.module_utils import basic

    m = basic.AnsibleModule(argument_spec={})

    # search for ls in PATH
    path = get_bin_path('ls')
    # verify that returned path is executable
    m.assertTrue(os.path.exists(path) and os.access(path, os.X_OK), 'get_bin_path failed to find executable in PATH')

    # search for python in PATH
    path = get_bin_path('python')
    # verify that returned path is exeutable
    m.assertTrue(os.path.exists(path) and os.access(path, os.X_OK), 'get_bin_path failed to find executable in PATH')

    # search for python in a specific path
    # Note

# Generated at 2022-06-22 21:58:33.196339
# Unit test for function get_bin_path
def test_get_bin_path():
    """ Test that get_bin_path() finds executables in the standard places """
    assert('/usr/bin/ls' == get_bin_path('ls'))
    assert('/usr/bin/python' == get_bin_path('python'))
    assert('/sbin/service' == get_bin_path('service'))

# Generated at 2022-06-22 21:58:35.527184
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert bin_path == '/bin/sh'

# Generated at 2022-06-22 21:58:45.885410
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import subprocess
    import tempfile

    python_bin = sys.executable
    # Execute python binary without arguments
    process = subprocess.Popen(python_bin, stdout=subprocess.PIPE)
    python_version, _ = process.communicate()
    assert process.returncode == 0

    # See if it is "python"
    test_bin = get_bin_path('python')
    assert test_bin
    assert test_bin == python_bin

    # Make a fake python and place it in tmp directory
    tmp_path = tempfile.mkdtemp()
    test_python = os.path.join(tmp_path, 'python')
    with open(test_python, 'w') as f:
        print("#!/bin/sh", file=f)

# Generated at 2022-06-22 21:58:52.292303
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Unit test for function get_bin_path'''

    # 'python' should always be found in a PATH
    assert get_bin_path('python')
    # 'python' cannot be found in the current directory
    assert get_bin_path('python', [os.getcwd()])

    # Check for required executable (will raise ValueError)
    try:
        assert get_bin_path('this_is_an_impossible_executable_to_find')
    except ValueError:
        pass

# Generated at 2022-06-22 21:58:57.631059
# Unit test for function get_bin_path
def test_get_bin_path():
    (rc, out, err) = module.run_command('which sleep', use_unsafe_shell=True)
    sleep_path = out.strip()
    assert get_bin_path('sleep') == sleep_path

    try:
        get_bin_path('sleep', ['/non_existent_dir'])
        assert False
    except ValueError:
        pass

    try:
        get_bin_path('non_existent_bin')
        assert False
    except ValueError:
        pass



# Generated at 2022-06-22 21:59:06.003081
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path.
    '''
    def check_get_bin_path(expected_value, arg, required=None, opt_dirs=None):
        '''
        Call get_bin_path() with given parameters and check the results.
        '''
        try:
            result = get_bin_path(arg, required, opt_dirs)
        except ValueError as exc:
            result = str(exc)
        assert result == expected_value, 'get_bin_path returned "%s" but expected "%s" for arg="%s", required=%s, opt_dirs="%s"' \
            % (result, expected_value, arg, required, opt_dirs)

    check_get_bin_path('/sbin/test1', 'test1')
    check_get_

# Generated at 2022-06-22 21:59:16.986079
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test setup
    test_paths = ['$PATH', '/bin', '/usr/bin', '/usr/local/bin']
    for test_path in test_paths:
        assert os.path.exists(os.path.expandvars(test_path))
        assert is_executable(os.path.expandvars(test_path))

    # Verify that get_bin_path throws ValueError when the binary is not found
    # in the paths
    try:
        get_bin_path('nevershallexist', opt_dirs=test_paths)
        assert False
    except ValueError:
        pass

    # Verify that get_bin_path returns the correct path when the binary is found
    # in one of the paths

# Generated at 2022-06-22 21:59:26.637784
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/bin/echo' == get_bin_path('echo')
    assert '/bin/echo' == get_bin_path('echo', [])
    assert '/bin/echo' == get_bin_path('echo', required=False)
    assert '/bin/echo' == get_bin_path('echo', [], False)
    assert '/bin/echo' == get_bin_path('echo', required=True)
    assert '/bin/echo' == get_bin_path('echo', [], True)
    assert '/bin' == get_bin_path('fake_path', ['/bin'])
    assert '/usr/bin/yes' == get_bin_path('yes', ['/usr/bin'])

# Generated at 2022-06-22 21:59:36.706116
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import pytest

    #
    # run without specifying optional arguments
    #
    # valid executable, full path
    assert get_bin_path('/bin/echo') == '/bin/echo'

    # valid executable, in path
    for dir in os.environ.get('PATH', '').split(os.pathsep):
        if os.path.exists(os.path.join(dir, 'python')):
            assert get_bin_path('python') == os.path.join(dir, 'python')
            break

    # invalid executable
    with pytest.raises(ValueError):
        get_bin_path('invalid_executable')

    #
    # run with specifying optional arguments
    #
    # valid executable, full path

# Generated at 2022-06-22 21:59:42.382174
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('getent', ['/bin', '/usr/bin'])
    assert bin_path == '/usr/bin/getent'

    try:
        get_bin_path('getent', ['/bin', '/usr/bin'], required=True)
        assert False, "Should have raised an Exception"
    except Exception as e:
        assert "Failed to find required executable" in str(e)

    try:
        get_bin_path('getent', ['/bin', '/usr/bin'])
        assert False, "Should have raised an Exception"
    except Exception as e:
        assert "Failed to find required executable" in str(e)


# Generated at 2022-06-22 21:59:49.897925
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for get_bin_path()
    '''

    # This test is designed to run with python -m pytest
    # When not run with pytest, catch import error and return 0
    # This allows test to be used from ansible-test
    try:
        import pytest
    except ImportError as e:
        print('unable to import pytest: %s' % e)
        print('skipping test')
        return 0

    # 'cp' executable is typically standard, so test that case
    assert get_bin_path('cp') == '/bin/cp'

    # /bin/true and /bin/false are expected to exist, but different depending
    # on platform
    assert get_bin_path('true') == '/bin/true' or get_bin_path('true') == '/bin/true'



# Generated at 2022-06-22 22:00:01.729859
# Unit test for function get_bin_path
def test_get_bin_path():
    assert os.path.exists(os.path.dirname(get_bin_path('ls')))
    assert get_bin_path('ls').endswith('ls')
    assert get_bin_path('ls', ['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', ['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', ['/usr/bin', '/usr/sbin']) == '/usr/bin/ls'
    assert get_bin_path('ls', ['/bin', '/usr/bin', '/usr/sbin']) == '/bin/ls'
    try:
        get_bin_path('iamnotfound')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-22 22:00:06.092184
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('this_executable_does_not_exist')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-22 22:00:15.344848
# Unit test for function get_bin_path
def test_get_bin_path():
    # Add ./bin to PATH
    bin_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'bin'))
    with os.environ.item_context({'PATH': bin_path}):
        assert get_bin_path('does-not-exist') is None
        assert get_bin_path('does-not-exist', required=False) is None
        try:
            get_bin_path('does-not-exist', required=True)
            assert False, 'exception was not raised'
        except ValueError as e:
            assert 'Failed to find required executable "does-not-exist"' in str(e)
        assert get_bin_path('foo-bar') == os.path.join(bin_path, 'foo-bar')

# Generated at 2022-06-22 22:00:25.638345
# Unit test for function get_bin_path
def test_get_bin_path():

    os_path = os.path
    os_path_exists = os_path.exists
    os_path_isdir = os_path.isdir
    os_pathsep = os.pathsep
    os_environ_get = os.environ.get
    is_executable = is_executable

    def test_get_bin_path(command, expected, opt_dirs=None, required=None, exists=(), isdir=(), executable=()):
        exists = set(exists)
        isdir = set(isdir)
        executable = set(executable)

        def os_path_exists(path):
            return path in exists or os_path_exists(path)

        def os_path_isdir(path):
            return path in isdir or os_path_isdir(path)

# Generated at 2022-06-22 22:00:36.661181
# Unit test for function get_bin_path
def test_get_bin_path():
    # This function has been deprecated in Ansible 2.10 and will be removed in Ansible 2.14.
    # Tests that it raises an Exception when the executable is not in PATH.
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    try:
        get_bin_path('test_exec_not_exist', required=True)
    except Exception as e:
        module.exit_json(changed=False, msg="test_exec_not_exist is not in PATH")
    module.exit_json(changed=False, msg="test_exec_not_exist is in PATH")

    # Tests that 'get_bin_path' returns the full path of the executable when it is in PATH.

# Generated at 2022-06-22 22:00:43.618257
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') != ''
    assert get_bin_path('/bin/sh') != ''
    assert get_bin_path('sh', opt_dirs=['/bin']) != ''
    try:
        get_bin_path('/usr/bin/nosuchfile')
        assert False, 'Expected ValueError to be raised.'
    except ValueError:
        pass

# Generated at 2022-06-22 22:00:51.144496
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import os
    import shutil
    import stat

    tmpdir = tempfile.mkdtemp()
    old_environ = os.environ['PATH']

# Generated at 2022-06-22 22:00:53.985124
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python')    # Just make sure that we have a valid Python in the path



# Generated at 2022-06-22 22:01:00.900414
# Unit test for function get_bin_path
def test_get_bin_path():
    executable = 'ls'
    opt_dirs = []
    try:
        get_bin_path(executable, opt_dirs, False)
    except ValueError:
        assert False, "Test failed: '%s' not found in expected locations" % executable
    except:
        assert False, "Test failed: unexpected exception"


# If you don't want to use yaml.safe_load, then this can be used to load
# yaml without allowing the construction of arbitrary Python classes.

# Generated at 2022-06-22 22:01:09.537981
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    import sys
    import tempfile
    import shutil

    DummyExec = '''#!%s
import sys
sys.exit(0)
'''

    # This prefix should match the expected value of sys.prefix
    sys_prefix = sys.prefix if PY3 else sys.prefix.decode('utf-8')


# Generated at 2022-06-22 22:01:22.234326
# Unit test for function get_bin_path
def test_get_bin_path():
    expected_paths = ['/bin/ping', '/sbin/ping', '/usr/bin/ping', '/usr/sbin/ping', '/usr/local/bin/ping']
    try:
        res = get_bin_path('ping')
    except Exception as e:
        assert False, 'Unexpected exception raised %s ' % str(e)

    assert res in expected_paths, 'Expected paths: %s, return path: %s' % (','.join(expected_paths), res)
    try:
        res = get_bin_path('ping', ['/bin', '/sbin'])
    except Exception as e:
        assert False, 'Unexpected exception raised %s ' % str(e)
