

# Generated at 2022-06-22 21:51:21.512031
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no-such-command', opt_dirs=['/bin', '/usr/bin'])
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "no-such-command" in paths: /bin:/usr/bin:/usr/local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/sbin:/usr/bin:/sbin:/bin'
    else:
        assert False, 'failed to raise required ValueError exception'

# Generated at 2022-06-22 21:51:28.501624
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest

    # Setup module arg spec
    arg_spec = {}
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=arg_spec)
    # test for existing binary
    bp = get_bin_path("/bin/echo")
    assert bp == "/bin/echo"
    # test for non-existing binary, prior to 2.10 calling get_bin_path() with required=True would raise an exception
    # 2.10 and later by default always raise an exception for non-existing binaries so module exec will fail.
    with pytest.raises(ValueError) as excinfo:
        get_bin_path("/bin/does-not-exist")
    exception_msg = str(excinfo.value)

# Generated at 2022-06-22 21:51:31.836731
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('less')
    assert get_bin_path('less', opt_dirs=['/usr/bin'])
    assert get_bin_path('less', opt_dirs=['/usr/bin', '/bin'])
    assert get_bin_path('less', opt_dirs=['/usr/bin'], required=True)
    assert get_bin_path('less', required=True)
    assert get_bin_path('less', opt_dirs=['/usr/bin'], required=False)
    assert get_bin_path('less', opt_dirs=['/usr/bin'], required=None)

# Generated at 2022-06-22 21:51:40.733696
# Unit test for function get_bin_path
def test_get_bin_path():
    # The following tests expect the executable to be in the path (or in one of the opt_dirs)
    executable_list = ['/bin/sh', 'sh', '/sbin/dhclient', 'dhclient', '/bin/ls', 'ls', '/usr/bin/ssh', 'ssh']
    opt_dirs_list = [ ['/bin', None], ['/usr/bin', None], ['/usr/sbin', None], ['/other/dir', None],
                      [None, '/usr/bin'], [None, '/usr/sbin']]
    print ('\nTesting get_bin_path() with valid input')
    for executable in executable_list:
        for opt_dirs in opt_dirs_list:
            fullpath = get_bin_path(executable, opt_dirs, True)

# Generated at 2022-06-22 21:51:46.539499
# Unit test for function get_bin_path
def test_get_bin_path():

    # This is necessary because the unit test runs in a different environment
    # and therefore needs a different PATH.
    os.environ['PATH'] = os.path.dirname(os.path.realpath(__file__))

    assert get_bin_path('not_exist') is None
    assert get_bin_path('not_exist', required=True) is None
    assert get_bin_path('test_utils_test_get_bin_path', required=True) is not None

# Generated at 2022-06-22 21:51:52.062656
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python2') == '/usr/bin/python2'
    assert get_bin_path('python3') == '/usr/bin/python3'
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('/usr/bin/python') == '/usr/bin/python'
    assert get_bin_path('/usr/bin/python2') == '/usr/bin/python2'
    assert get_bin_path('/notexisting') == None

# Generated at 2022-06-22 21:52:01.589112
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    fd, tfile = tempfile.mkstemp(mode=0o775)
    os.close(fd)

# Generated at 2022-06-22 21:52:08.655330
# Unit test for function get_bin_path
def test_get_bin_path():
    # set up mock environment
    os.environ['PATH'] = '/bin:/usr/bin:/usr/local/bin'
    bin_dirs = ['/bin', '/usr/bin', '/usr/local/bin']
    # try to find an existing executable
    ansible_bin_path = get_bin_path('ansible', opt_dirs=None, required=False)
    assert os.path.exists(os.path.join(ansible_bin_path, 'ansible'))
    # try to find an executable that doesn't exist
    try:
        get_bin_path('not_ansible', opt_dirs=None, required=False)
    except ValueError:
        pass
    # try to find an executable that doesn't exist and is required

# Generated at 2022-06-22 21:52:19.367869
# Unit test for function get_bin_path
def test_get_bin_path():
    # Setup test to check for ls command.
    # This works for most systems but for some systems like Ubuntu, /sbin/ls is
    # a directory.
    if os.path.isdir('/sbin/ls'):
        return

    # Basic test to see if it works with path independent of the current
    # working directory.
    lsBinPath = get_bin_path('ls')
    assert lsBinPath == '/bin/ls' or lsBinPath == '/usr/bin/ls' or lsBinPath == '/usr/bin/lsb_release'

    # Test to see if it works when the current working directory is in the
    # path.
    currentDir = os.getcwd()
    os.environ['PATH'] = currentDir + ':' + os.environ['PATH']

# Generated at 2022-06-22 21:52:28.773442
# Unit test for function get_bin_path
def test_get_bin_path():
    # unit tests are only valid if used with python
    if 'python' not in os.path.basename(os.path.abspath(__file__)):
        return

    # test for `python`
    bin_path = get_bin_path('python')
    assert os.path.exists(bin_path)
    assert is_executable(bin_path)
    # test for `python` with extra dirs
    bin_path = get_bin_path('python', opt_dirs=['/usr/bin', '/bin'])
    assert os.path.exists(bin_path)
    assert is_executable(bin_path)
    # test for `python` with required=True (Deprecated)

# Generated at 2022-06-22 21:52:35.761322
# Unit test for function get_bin_path
def test_get_bin_path():
  paths = ['/usr/bin', '/usr/sbin', '/usr/local/bin', '/bin']
  req = ['ls', 'echo', 'cat', 'false']
  for t in req:
    try:
      get_bin_path(t, paths)
    except ValueError:
      raise Exception('test_get_bin_path failed for %s' % t)

# Generated at 2022-06-22 21:52:44.272467
# Unit test for function get_bin_path
def test_get_bin_path():
    # A non existing path
    not_existing_path = 'not_existing_path'
    # A non executable file
    # /dev/null is not executable on mac os
    non_exec_file = '/dev/null'
    # A non existing executable file
    not_existing_exec = '/not_existing_exec'
    # A existing executable file
    existing_exec = '/bin/ls'

    # Test with a not existing path
    try:
        get_bin_path(not_existing_path)
        assert False
    except ValueError:
        pass

    # Test with a not executable file
    try:
        get_bin_path(non_exec_file)
        assert False
    except ValueError:
        pass

    # Test with not existing executable file

# Generated at 2022-06-22 21:52:52.918320
# Unit test for function get_bin_path
def test_get_bin_path():
    # Create temporary directory
    path = "/tmp/ansible_test_directory"
    os.mkdir(path)
    os.chmod(path, 0o777)

    # Create executable in temporary directory for testing
    file_path = path + "/ansible_test_executable"
    with open(file_path, "w") as file:
        file.write("test")

    os.chmod(file_path, 0o777)

    if get_bin_path("ansible_test_executable", [path]) != file_path:
        raise ValueError("Expected: " + file_path + "\nFound: " + get_bin_path("ansible_test_executable", [path]))

    # Cleanup
    os.remove(file_path)
    os.rmdir(path)

# Generated at 2022-06-22 21:53:00.961553
# Unit test for function get_bin_path
def test_get_bin_path():
    # set PATH to a temp directory (e.g. /tmp)
    original_path = os.environ['PATH']
    os.environ['PATH'] = '/tmp'
    # try to find 'ls'
    assert get_bin_path('ls') == '/bin/ls'
    # try to find 'ls', pass PATH as optional directory
    assert get_bin_path('ls', ['/bin']) == '/bin/ls'
    # try to find 'ls', pass PATH as optional directory
    assert get_bin_path('ls', ['wrong_path']) == '/bin/ls'
    # try to find 'ls', force PATH to be /bin only
    assert get_bin_path('ls', ['/bin']) == '/bin/ls'
    # try to find 'ls', force PATH to be /sbin only

# Generated at 2022-06-22 21:53:08.865077
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('awk') == '/usr/bin/awk'
    assert get_bin_path('grep') == '/bin/grep'
    assert get_bin_path('sed') == '/bin/sed'
    assert get_bin_path('id') == '/usr/bin/id'

    from ansible.module_utils import basic
    import unittest
    import ansible


# Generated at 2022-06-22 21:53:10.183566
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'



# Generated at 2022-06-22 21:53:21.288511
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.environ.get('PATH'):
        orig_path = os.environ['PATH']

    bin_path = '/bin:/usr/bin'
    os.environ['PATH'] = bin_path

# Generated at 2022-06-22 21:53:25.193547
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat')
    assert get_bin_path('pwd')
    assert get_bin_path('python')
    assert get_bin_path('which')
    assert get_bin_path('id')
    assert get_bin_path('ls')
    assert get_bin_path('pip')
    assert get_bin_path('tar')
    assert get_bin_path('unzip')
    assert get_bin_path('xz')

# Generated at 2022-06-22 21:53:36.414142
# Unit test for function get_bin_path
def test_get_bin_path():
    assert os.path.exists(get_bin_path('date'))
    try:
        get_bin_path('this command does not exist')
        assert False, 'expected module to fail'
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "this command does not exist" in paths: /sbin:/usr/sbin:/usr/local/sbin:/usr/local/bin:/usr/bin:/bin'

    bindir = os.path.abspath('fake_bin_dir')
    os.makedirs(bindir)
    fname = os.path.join(bindir, 'fake_cmd')
    open(fname, 'w').close()
    os.chmod(fname, 0o755)

# Generated at 2022-06-22 21:53:48.660310
# Unit test for function get_bin_path
def test_get_bin_path():
    import mock

    import ansible.module_utils.common.file as cu_file

    # a bunch of fake binaries
    fake_binaries = [
        '/foo/bar/1',
        '/usr/bin/true',
        '/usr/bin/false',
        '/usr/bin/bar',
    ]

    # add the fakes to PATH for the tests
    os.environ['PATH'] = '/foo/bar:/usr/bin'

    # fake file.is_executable
    # all files in fake_binaries are executable,
    # any file not in fake_binaries is not executeabale
    def fake_is_executable(filename):
        return filename in fake_binaries

    # mock file.is_executable

# Generated at 2022-06-22 21:53:52.860175
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    assert get_bin_path('fake_exe') == None

# Generated at 2022-06-22 21:54:01.471892
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import textwrap
    import shutil

    script_content = textwrap.dedent(u'''\
    #!/bin/sh
    echo "this is a fake echo"
    ''')

    script_name = 'fake-echo'

    fake_path = tempfile.mkdtemp()
    script_path = os.path.join(fake_path, script_name) 
    with open(script_path, 'w') as f:
        f.write(script_content)
    os.chmod(script_path, 0o755)

    assert (get_bin_path(script_name, opt_dirs=[fake_path]) == script_path)

# vim: sts=4 sw=4 ts=4 et ft=python

# Generated at 2022-06-22 21:54:11.095574
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    if sys.version_info[0] == 2:
        import mock
    else:
        from unittest import mock
    import ansible.module_utils.common.file

    def mock_is_executable(path):
        return True

    def mock_os_path_exists(path):
        if path.endswith('.py'):
            return False
        return True

    def mock_os_path_isdir(path):
        if path.endswith('.py'):
            return False
        return True

    # Test executable in PATH
    exe = 'python'

# Generated at 2022-06-22 21:54:16.047265
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import nose

    try:
        get_bin_path("paper")
        assert("Expected ValueError")
    except ValueError:
        pass

    try:
        get_bin_path("true")
        assert("Expected ValueError")
    except ValueError:
        pass

    try:
        get_bin_path("true", opt_dirs=["/bin"])
    except ValueError:
        assert("Expected no ValueError")
    else:
        assert("Expected ValueError")


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-22 21:54:27.147215
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import glob

    # Set up a temporary directory
    tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(tmpdir, "testget_bin_path")

    # Create a temporary file as a test executable
    tmpfd = open(tmpfile, "wa");
    tmpfd.write("#!/bin/sh\necho testget_bin_path\n");
    tmpfd.close();

# Generated at 2022-06-22 21:54:36.916892
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    import subprocess
    import stat
    import os

    test_script = '''#!/usr/bin/python
import sys
sys.exit(0)
'''

    p = os.path.join(tempfile.gettempdir(), 'ansible_test_script.py')
    with open(p, 'w') as fp:
        fp.write(test_script)
    os.chmod(p, stat.S_IREAD | stat.S_IWRITE | stat.S_IEXEC)

    p = os.path.join(tempfile.gettempdir(), 'ansible_test_script')
    with open(p, 'w') as fp:
        fp.write(test_script)

# Generated at 2022-06-22 21:54:48.308269
# Unit test for function get_bin_path
def test_get_bin_path():

    # Test with directories
    directories = ['/bin', '/usr/bin', '/etc']
    assert get_bin_path('ls', opt_dirs=directories) == '/bin/ls'

    # Test with an empty list of directories
    directories = []
    assert get_bin_path('ls', opt_dirs=directories) == '/bin/ls'

    # Test with directories, invalid binary
    directories = ['/bin', '/usr/bin', '/etc']
    try:
        get_bin_path('jhgkjhkgjh', opt_dirs=directories)
    except Exception as e:
        assert e.message == 'Failed to find required executable "jhgkjhkgjh" in paths: /bin:/usr/bin:/etc'

    # Test with directories, invalid directory

# Generated at 2022-06-22 21:54:59.260954
# Unit test for function get_bin_path
def test_get_bin_path():
    current_path = os.getcwd()
    test_paths = ['/bin', '/usr/bin', '/usr/local/bin', '/usr/libexec', '/usr/local/libexec']
    # Create dummy executables in test_paths
    for test_path in test_paths:
        open(os.path.join(test_path, 'test_get_bin_path.bin'), 'a').close()

    # Test with default path
    try:
        bin_path = get_bin_path('test_get_bin_path.bin', opt_dirs=[])
        assert bin_path is not None and os.path.exists(bin_path) and os.path.isfile(bin_path)
    except ValueError:
        assert False

    # Test with optional path

# Generated at 2022-06-22 21:55:00.077420
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('noexists') is None

# Generated at 2022-06-22 21:55:12.719852
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for function get_bin_path
    '''
    assert get_bin_path('tec') == '/bin/tec'
    assert get_bin_path('tec', opt_dirs=['.']) == './tec'
    assert get_bin_path('false') == '/usr/bin/false'
    assert get_bin_path('/bin/tec', opt_dirs=['.']) == '/bin/tec'
    assert get_bin_path('/bin/tec') == '/bin/tec'
    assert get_bin_path('/usr/bin/false') == '/usr/bin/false'
    assert get_bin_path('/usr/bin/false', opt_dirs=['.']) == '/usr/bin/false'

# Generated at 2022-06-22 21:55:24.140501
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.facts.system.distribution import DistributionFiles
    from ansible.module_utils.facts.system.distribution import Distribution, RedHatFamily, DebianFamily, SuseFamily

    paths = ['/bin', '/usr/local/bin']
    assert get_bin_path('id', paths, None) == '/bin/id'

    def get_bin_path_mock(arg, opt_dirs=None, required=None):
        if arg == 'id':
            return '/bin/id'
        else:
            return None

    __builtins__.get_bin_path = get_bin_path_mock
    distro_files = DistributionFiles()
    distro_files.set_command(['id'])

    distro = Distribution()

    distro.files = distro_files

# Generated at 2022-06-22 21:55:34.727874
# Unit test for function get_bin_path

# Generated at 2022-06-22 21:55:36.455382
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat')

# Generated at 2022-06-22 21:55:41.329606
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls', opt_dirs=['/tmp']) == get_bin_path('ls', opt_dirs=['/tmp'])
    try:
        get_bin_path('notthere', opt_dirs=['/tmp'])
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-22 21:55:47.332879
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('cat')
    assert isinstance(bin_path, str)
    assert len(bin_path) > 0
    assert os.path.exists(bin_path)
    assert os.access(bin_path, os.X_OK)
    assert not os.path.isdir(bin_path)
    assert os.path.basename(bin_path) == 'cat'

# Generated at 2022-06-22 21:55:49.232124
# Unit test for function get_bin_path
def test_get_bin_path():
    # Call function directly to test.
    assert get_bin_path("ls") == "/bin/ls"

# Generated at 2022-06-22 21:55:59.931067
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check bin_path with existing executable in PATH
    try:
        bin_path = get_bin_path('sh')
        assert bin_path == '/bin/sh'
    except ValueError as err:
        assert False, 'Failed to find existing executable sh in PATH'

    # Check bin_path with non-existing executable in PATH
    try:
        bin_path = get_bin_path('not_present_in_path')
        assert False, 'get_bin_path did not raise ValueError for non-existing executable'
    except ValueError as err:
        assert True

    # Check bin_path with optional directories
    test_dir = '/tmp'
    sh_path = os.path.join(test_dir, 'sh')

# Generated at 2022-06-22 21:56:11.472603
# Unit test for function get_bin_path
def test_get_bin_path():
    import ansible.module_utils.basic
    # test when arg to search for is found
    assert get_bin_path('ls') == '/bin/ls'
    # test when arg is not found
    try:
        get_bin_path('this_does_not_exist') # This should raise ValueError
    except ValueError:
        pass
    else:
        assert False, 'ValueError not raised'

    # test when arg is in opt_dir
    opt_dirs = ['/bin']
    assert get_bin_path('ls', opt_dirs) == '/bin/ls'

    # test when arg is not in opt_dir
    try:
        get_bin_path('ls', opt_dirs=['/usr/bin']) # This should raise ValueError
    except ValueError:
        pass

# Generated at 2022-06-22 21:56:22.335550
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # Create a temporary directory to work in
    tmpdir = tempfile.mkdtemp()
    # Create a file called 'test_file' in the temporary directory
    test_file = os.path.join(tmpdir, 'test_file')
    test_file_handle = open(test_file, 'w')
    test_file_handle.close()

    # Test that get_bin_path raises an Exception
    try:
        get_bin_path('test_file')
    except ValueError:
        pass

    # Test that get_bin_path finds the file in the temporary directory
    assert get_bin_path('test_file', [tmpdir]) == test_file
    os.remove(test_file)
    os.rmdir(tmpdir)

# Generated at 2022-06-22 21:56:27.520649
# Unit test for function get_bin_path
def test_get_bin_path():
    # os.path.exists will always return false as this does not mock the filesystem
    assert get_bin_path('/dev/null/foo') is None

    # Note: we may want to mock os.path.exists in the future to make this more robust / reliable
    #assert get_bin_path('/dev/null') == '/dev/null'

# Generated at 2022-06-22 21:56:32.734324
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('foo_bar_executable_that_does_not_exists_foo_bar_haha') == '/bin/foo_bar_executable_that_does_not_exists_foo_bar_haha'

# Generated at 2022-06-22 21:56:42.394063
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    if os.path.exists(os.path.join('/', 'usr', 'bin', 'ansible')) and os.path.exists(os.path.join('/', 'usr', 'bin', 'ansible-config')):
        assert to_bytes(get_bin_path('ansible')) == to_bytes(os.path.join('/', 'usr', 'bin', 'ansible'))
        assert to_bytes(get_bin_path('ansible-config')) == to_bytes(os.path.join('/', 'usr', 'bin', 'ansible-config'))


# Generated at 2022-06-22 21:56:53.610447
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Test get_bin_path API '''
    # pylint: disable=unused-variable

# Generated at 2022-06-22 21:56:55.112684
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('python')

# Generated at 2022-06-22 21:56:59.664975
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1, should pass
    try:
        get_bin_path('ls')
    except ValueError:
        assert False

    # Test 2, should fail
    try:
        get_bin_path('not_there')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-22 21:57:07.898706
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no-such-binary')
    except ValueError as err:
        assert 'no-such-binary' in str(err)

    path = get_bin_path('ls')
    assert os.path.isfile(path)
    assert '/bin/ls' in path or '/usr/bin/ls' in path

    path = get_bin_path('ls', opt_dirs=['/bin'])
    assert os.path.isfile(path)
    assert '/bin/ls' in path

# Generated at 2022-06-22 21:57:16.045526
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', ['/bin']) == '/bin/ls'
    assert get_bin_path('ls', ['/usr/bin']) == '/usr/bin/ls'
    try:
        get_bin_path('ls', ['/non-existent-dir'])
        assert False, 'Expected an exception'
    except ValueError:
        pass

    # Test for function get_bin_path with required flag
    # NOTE: This test doesn't actually check the required flag in get_bin_path itself. This is because the required
    # parameter has been deprecated and marked as removed by Ansible 2.14.
    #
    # This test is intended to catch any

# Generated at 2022-06-22 21:57:23.689169
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = os.environ.get('PATH').split(os.pathsep)
    full_path = get_bin_path('python', paths)
    assert os.path.exists(full_path)
    assert is_executable(full_path)
    try:
        get_bin_path('invalid_decoy', paths)
    except ValueError as e:
        pass
    else:
        raise AssertionError('Did not see expected ValueError when checking for invalid executable')

# Generated at 2022-06-22 21:57:27.433121
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    if sys.platform == 'win32':
        assert get_bin_path('cmd') == 'C:\\Windows\\System32\\cmd.exe'
    else:
        assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-22 21:57:31.225727
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test invalid binary and test that the exception is actually raised
    from ansible.module_utils.common.file import get_bin_path

    try:
        get_bin_path('invalid')
    except ValueError:
        # expected Exception, this just catches the Exception to avoid further
        # pytest processing of the Exception, otherwise it will fail the test
        pass

# Generated at 2022-06-22 21:57:35.855163
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    try:
        get_bin_path('unknown_binary')
        assert False, 'Should have raised ValueError'
    except ValueError:
        pass

# Generated at 2022-06-22 21:57:38.055864
# Unit test for function get_bin_path
def test_get_bin_path():
    mybin = get_bin_path('tclsh')
    assert mybin and is_executable(mybin) and os.path.split(mybin)[1] == 'tclsh'

# Generated at 2022-06-22 21:57:48.437959
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os

    executable = 'foo_executable'
    dirs = []

    tmpdir = tempfile.mkdtemp()
    dirs.append(tmpdir)
    os.environ['PATH'] = tmpdir


# Generated at 2022-06-22 21:57:54.885393
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path
    '''
    get_bin_path('chmod')
    assert os.path.exists(get_bin_path('chmod'))
    assert os.path.exists(get_bin_path('chmod', ['/usr/bin', '/bin']))
    try:
        get_bin_path('foobar')
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-22 21:58:05.270463
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import shutil

    python_bin = sys.executable
    if not os.path.isabs(python_bin):
        python_bin = get_bin_path(os.path.basename(python_bin))

    # Create a temporary directory and temporarily modify PATH to include it
    tmp_dir = os.path.join(os.path.dirname(python_bin), 'ansible_test_bin_path')
    old_path = os.environ['PATH']
    os.mkdir(tmp_dir)
    os.environ['PATH'] = tmp_dir

    # Should fail on non-existent executable
    try:
        get_bin_path('nonexistent_executable')
    except ValueError:
        pass

# Generated at 2022-06-22 21:58:15.853689
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    from tempfile import TemporaryDirectory

    tmpdir = TemporaryDirectory()

    # Create test executable
    test_executable = os.path.join(tmpdir.name, "test_executable")
    with open(test_executable, mode='w') as f:
        f.write('#!/bin/sh\necho "Hello World"')
    os.chmod(test_executable, 0o700)

    # Create test directory and add it to PATH
    test_directory = os.path.join(tmpdir.name, 'test_directory')
    os.mkdir(test_directory)
    test_paths = os.environ['PATH'].split(':')
    test_paths.append(test_directory)


# Generated at 2022-06-22 21:58:18.394423
# Unit test for function get_bin_path
def test_get_bin_path():
    import ansible.module_utils.basic

    assert ansible.module_utils.basic.get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-22 21:58:27.226750
# Unit test for function get_bin_path
def test_get_bin_path():
    # save PATH
    orig_path = os.environ['PATH']

    # Test 1: search executable in PATH
    try:
        # setup
        os.environ['PATH'] = os.pathsep.join(['/usr/bin', '/bin', '/usr/sbin', '/sbin', '/usr/local/bin', '/usr/local/sbin'])

        # test
        assert not get_bin_path('sshd') == ''
    finally:
        os.environ['PATH'] = orig_path

    # Test 2: search executable in additional dirs.
    try:
        os.environ['PATH'] = '/bin:/sbin'
        # test
        assert not get_bin_path('sshd', ['/usr/sbin', '/usr/bin']) == ''
    finally:
        os.environ

# Generated at 2022-06-22 21:58:34.664303
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check that function can find a binary in PATH
    get_bin_path('ansible-playbook')

    # Check that function can find a binary not in PATH
    get_bin_path('ansible-playbook', opt_dirs=['/usr/bin'])

    # Check that ValueError is raised if binary not found
    try:
        get_bin_path('no-such-binary')
    except ValueError as e:
        assert 'no-such-binary' in str(e)

# Generated at 2022-06-22 21:58:45.237313
# Unit test for function get_bin_path
def test_get_bin_path():
    # make sure $PATH exists and it is empty
    try:
        os.environ['PATH'] = ''
    except Exception:
        raise AssertionError('Cannot set $PATH')

    # create a temp dir and a fake /bin dir
    import tempfile
    dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(dir, 'bin'))

    # create a fake 'sh' executable in the created /bin dir
    f = open(os.path.join(dir, 'bin/sh'), 'wb')
    f.close()
    os.chmod(os.path.join(dir, 'bin/sh'), 0o755)

    # add the created dir in to $PATH

# Generated at 2022-06-22 21:58:54.786869
# Unit test for function get_bin_path
def test_get_bin_path():
    from shutil import which
    from tempfile import mkdtemp
    from os import environ

    # test normal use-case
    bin_path = get_bin_path('ls')
    assert bin_path == which('ls')

    # test multiple appearances in path
    os.makedirs('/tmp/bin_test_1/bin')
    open('/tmp/bin_test_1/bin/ls_test', 'a').close()
    os.makedirs('/tmp/bin_test_2/bin')
    open('/tmp/bin_test_2/bin/ls_test', 'a').close()
    os.makedirs('/tmp/bin_test_3/bin')
    open('/tmp/bin_test_3/bin/ls_test', 'a').close()

    old_PATH = en

# Generated at 2022-06-22 21:59:01.795993
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', ['/usr/bin']) == '/usr/bin/python'
    assert get_bin_path('python', ['/usr/bin', '/bin']) == '/usr/bin/python'
    assert get_bin_path('python', ['/usr/bin', '/bin'], ['/bin']) == '/bin/python'
    assert get_bin_path('profile.d') != '/etc/profile.d'

# Generated at 2022-06-22 21:59:10.394957
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test #1 - Test that valid executable path is found
    assert get_bin_path('cat') == '/bin/cat'

    # Test #2 - Test that the function throws an error for a non-existant executable
    should_fail = False
    try:
        get_bin_path('fake-utility')
    except ValueError:
        should_fail = True
    assert should_fail

    # Test #3 - Test that the function works with an optional dir
    assert get_bin_path('cat', opt_dirs=['/usr/bin']) == '/usr/bin/cat'

# Generated at 2022-06-22 21:59:19.702160
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path.

    Tests a number of normal cases including testing the optional arguments
    and their defaults.
    '''
    opt_dirs = ['/tmp', '/var/tmp']

    assert get_bin_path('/bin/dd') == '/bin/dd'
    assert get_bin_path('/bin/dd', opt_dirs) == '/bin/dd'
    assert get_bin_path('dd', opt_dirs) == get_bin_path('dd', opt_dirs, True)
    assert get_bin_path('l', []) == get_bin_path('l', None, True)
    assert get_bin_path('/bin/ls', []) == '/bin/ls'

    import pytest

# Generated at 2022-06-22 21:59:23.252333
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = os.environ.get('PATH', '').split(os.pathsep)
    for arg in ['python3', 'sh', 'false', 'true']:
        get_bin_path(arg)

# Generated at 2022-06-22 21:59:34.382843
# Unit test for function get_bin_path
def test_get_bin_path():
    def mock_is_executable(path):
        if path.endswith(".executable_file"):
            return True
        return False
    mock_module = type('mock_module', (object,), {})
    mock_module.fail_json = lambda *args, **kwargs: None
    orig_is_executable = is_executable
    is_executable = mock_is_executable

# Generated at 2022-06-22 21:59:44.089230
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('python')
    assert bin_path is not None
    assert bin_path == '/usr/bin/python' or bin_path == '/usr/bin/python3'

    bin_path = get_bin_path('python2')
    assert bin_path is not None
    assert bin_path == '/usr/bin/python2'

    bin_path = get_bin_path('python3')
    assert bin_path is not None
    assert bin_path == '/usr/bin/python3'

    bin_path = get_bin_path('python', ['/bin', '/usr/bin', '/usr/local/bin'])
    assert bin_path is not None
    assert bin_path == '/usr/bin/python' or bin_path == '/usr/bin/python3'

    bin_path

# Generated at 2022-06-22 21:59:47.399175
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Unit test for function get_bin_path '''
    import shutil
    from tempfile import mkdtemp
    tmp = mkdtemp()
    path = os.environ['PATH']
    os.environ['PATH'] = tmp

    try:
        with open(os.path.join(tmp, 'test'), 'w') as f:
            f.write('#!/bin/sh\necho')
        os.chmod(os.path.join(tmp, 'test'), 0o755)
        assert get_bin_path("test") == os.path.join(tmp, 'test')

    finally:
        os.environ['PATH'] = path
        shutil.rmtree(tmp)



# Generated at 2022-06-22 21:59:53.669451
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import tempfile
    import shutil

    test_tmp_dir = tempfile.mkdtemp()
    test_bin = os.path.join(test_tmp_dir, 'test_bin')
    with open(test_bin, 'w') as f:
        f.write('#!/bin/sh\nexit 0')
    os.chmod(test_bin, 0o777)

    # Test with test_bin in the temporary directory
    assert get_bin_path('test_bin', opt_dirs=[test_tmp_dir]) == test_bin
    # Test with test_bin not in the temporary directory

# Generated at 2022-06-22 22:00:00.630596
# Unit test for function get_bin_path
def test_get_bin_path():
    exectuable = "echo"
    echo_path = get_bin_path(exectuable)
    assert os.path.exists(echo_path) and is_executable(echo_path)
    bad_exectuable = "not_an_echo"
    try:
        get_bin_path(bad_exectuable)
    except ValueError as e:
        assert bad_exectuable in str(e)



# Generated at 2022-06-22 22:00:07.274518
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with command that is found in PATH
    try:
        result = get_bin_path('ls')
    except ValueError:
        assert False, 'ls failed to find the command in PATH'

    # Test with a command that is not found in PATH
    try:
        result = get_bin_path('not-a-command')
        assert False, 'not-a-command found the command in PATH'
    except ValueError:
        pass

# Generated at 2022-06-22 22:00:15.279902
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import tempfile
    # find executable in PATH
    get_bin_path('ls')
    # search in additional directories
    (tempfd, tempname) = tempfile.mkstemp()
    os.close(tempfd)
    try:
        os.chmod(tempname, 0o755)
        get_bin_path('ls', [os.path.dirname(tempname)])
    finally:
        os.remove(tempname)
    # executable with not found in PATH, search in additional directories only
    try:
        get_bin_path('ls', [])
    except ValueError:
        pass
    else:
        assert False, "Executable 'ls' must not be found in []"

# Generated at 2022-06-22 22:00:25.640190
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert bin_path == '/bin/sh'

    try:
        get_bin_path('qwertyuiopasdfghjklzxcvbnmqwerty')
    except ValueError as e:
        assert 'Failed to find required executable "qwertyuiopasdfghjklzxcvbnmqwerty"' in str(e)
    else:
        raise

    #defines a custom list of directories to search
    custom_path = []
    custom_path.append("/bin")
    custom_path.append("/usr/bin")
    custom_path.append("/sbin")
    custom_path.append("/usr/sbin")
    bin_path = get_bin_path('sh', custom_path)
    assert bin_path

# Generated at 2022-06-22 22:00:30.639841
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    # test with all expected /sbin paths missing
    sys.path.pop(0)
    assert get_bin_path('python') == sys.executable

    # test with option dirs
    assert get_bin_path('python', opt_dirs=['/usr/bin', '/usr/local/bin']) == sys.executable

    # test with /sbin paths missing, but opt_dirs
    sys.path.pop(0)
    assert get_bin_path('python', opt_dirs=['/usr/bin', '/usr/local/bin']) == sys.executable

    # test with not found
    sys.path.pop(0)
    try:
        get_bin_path('not_found')
    except ValueError:
        pass

# Generated at 2022-06-22 22:00:43.086584
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('cat', opt_dirs=['/bin', '/usr/bin', '/nonexistent']) == '/bin/cat'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/usr/bin/cat', opt_dirs=['/bin', '/usr/bin', '/nonexistent']) == '/usr/bin/cat'
    try:
        get_bin_path('nonexistent', [])
    except ValueError as exc:
        assert 'Failed to find required executable "nonexistent" in paths: ' in str(exc)

# Generated at 2022-06-22 22:00:53.280423
# Unit test for function get_bin_path
def test_get_bin_path():
    import os

    # test if we can find the bash
    if os.path.exists("/bin/bash") and not os.path.isdir("/bin/bash"):
        assert get_bin_path("bash") == "/bin/bash"

    # test if we can find the python
    if os.path.exists("/bin/python") and not os.path.isdir("/bin/python"):
        assert get_bin_path("python") == "/bin/python"

    # test if we can find the python3
    if os.path.exists("/usr/bin/python3") and not os.path.isdir("/usr/bin/python3"):
        assert get_bin_path("python3") == "/usr/bin/python3"

    # test if we can find the python in the path specified

# Generated at 2022-06-22 22:00:57.278832
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('foo')
    except ValueError:
        pass
    else:
        assert False, 'get_bin_path("foo") did not raise ValueError'

    try:
        get_bin_path('foo', required=False)
    except ValueError:
        pass
    else:
        assert False, 'get_bin_path("foo", required=False) did not raise ValueError'

    try:
        get_bin_path('python', ['/usr/bin'])
    except ValueError:
        pass
    else:
        assert False, 'get_bin_path("python", ["/usr/bin"]) did not raise ValueError'

    assert get_bin_path('python2.7', ['/usr/bin']) == '/usr/bin/python2.7'


# Generated at 2022-06-22 22:01:08.012467
# Unit test for function get_bin_path
def test_get_bin_path():
    current_path = os.environ['PATH']

# Generated at 2022-06-22 22:01:15.335087
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('ls', required=True)
    assert path == '/bin/ls'
    path = get_bin_path('ls', opt_dirs=['/usr/bin'], required=True)
    assert path == '/usr/bin/ls'
    try:
        get_bin_path('ls-no-such-program', required=True)
    except ValueError:
        pass
    else:
        assert False, 'An expected exception did not happen'