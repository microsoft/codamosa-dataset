

# Generated at 2022-06-11 01:19:24.384325
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/bin/bash') == '/bin/bash'
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('/bin/lssssssssssssss') is None
    assert get_bin_path('lssssssssssssss') is None
    assert get_bin_path('/bin/ls', opt_dirs=['/usr/local/bin']) == '/bin/ls'

# Generated at 2022-06-11 01:19:32.979943
# Unit test for function get_bin_path
def test_get_bin_path():
    fake_bin = 'does_not_exist'
    fake_dir = 'does_not_exist/'
    real_bin = 'sh'

    # Test real dir
    real_dir = ''
    try:
        assert get_bin_path(real_bin, real_dir)
    except ValueError:
        raise AssertionError('get_bin_path should return full path to an executable')

    # Test fake dir
    try:
        get_bin_path(fake_bin, fake_dir)
        raise AssertionError('get_bin_path should raise ValueError exception on a fake directory')
    except ValueError:
        pass

    # Test invalid bin name

# Generated at 2022-06-11 01:19:38.147231
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ssh') == get_bin_path('ssh', ['/usr/bin'])
    try:
        get_bin_path('ssh', ['/usr/bin'], True)
    except ValueError:
        assert False, "Did not find ssh"
    try:
        get_bin_path('NON_EXISTENT_BINARY')
    except ValueError:
        assert True
    else:
        assert False, "Unexpected true"

# Generated at 2022-06-11 01:19:43.606559
# Unit test for function get_bin_path
def test_get_bin_path():
    import ansible.module_utils.basic
    # Test default required
    assert ansible.module_utils.basic.get_bin_path('/bin/ls')
    # Test required False
    assert ansible.module_utils.basic.get_bin_path('/bin/ls', required=False)
    try:
        # Test required True
        ansible.module_utils.basic.get_bin_path('a_bad_path')
    except ValueError:
        pass
    else:
        # Required is True, value error did not fire
        assert False
    # Test None
    assert ansible.module_utils.basic.get_bin_path(None) is None

# Generated at 2022-06-11 01:19:56.195764
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("/usr/bin/cat") == "/usr/bin/cat"
    assert get_bin_path("cat") == "/bin/cat"
    try:
        get_bin_path("notexistingbinary")
        assert False, "The previous command should have failed, but it didn't"
    except ValueError:
        pass
    try:
        get_bin_path("/usr/bin/cat", ["/usr/sbin"])
        assert False, "The previous command should have failed, but it didn't"
    except ValueError:
        pass
    assert get_bin_path("bash", ["/usr/sbin"]) == "/usr/sbin/bash"
    assert get_bin_path("ntpd", ["/usr/sbin"]) == "/usr/sbin/ntpd"

# Generated at 2022-06-11 01:19:59.594826
# Unit test for function get_bin_path
def test_get_bin_path():
    executable_path = get_bin_path("ls", ['/bin', '/sbin'])
    assert executable_path.endswith("ls") or executable_path.endswith("ls.exe")



# Generated at 2022-06-11 01:20:06.298288
# Unit test for function get_bin_path
def test_get_bin_path():
    # find existing ansible executable
    try:
        ansible = get_bin_path("ansible")
    except ValueError:
        return "FAIL"
    else:
        if os.path.isfile(ansible):
            return "OK"
        else:
            return "FAIL"


# ==============================================================
# This is a temporary shim until all plugins/modules use get_bin_path
# ==============================================================


# Generated at 2022-06-11 01:20:12.501314
# Unit test for function get_bin_path
def test_get_bin_path():
    for cmd in ['ls', 'fuser']:
        path = get_bin_path(cmd, required=True)
        assert os.path.exists(path), 'Command %s expected to exist' % path
    try:
        get_bin_path('not_a_command', required=True)
    except ValueError as e:
        assert 'Failed to find required executable "not_a_command"' in str(e)
    else:
        assert 1 == 0, 'Command not_a_command expected to fail'

# Generated at 2022-06-11 01:20:18.794869
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1: path is found in $PATH
    bin_path = get_bin_path('echo')
    assert os.path.exists(bin_path) and is_executable(bin_path)

    # Test 2: path is not found in $PATH
    fail = False
    try:
        get_bin_path('some_invalid_echo_like_file')
    except ValueError:
        fail = True

    assert fail

# Generated at 2022-06-11 01:20:20.256949
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('echo') == '/bin/echo')

# Generated at 2022-06-11 01:20:26.017726
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('cat', ['/usr/bin']) == '/usr/bin/cat'
    assert get_bin_path('/usr/bin/cat') == '/usr/bin/cat'

# Generated at 2022-06-11 01:20:28.365526
# Unit test for function get_bin_path
def test_get_bin_path():
    # if test fails, it's possible the system is broken
    assert get_bin_path('sh', required=True)

# Generated at 2022-06-11 01:20:40.286350
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic

    test_paths = ['/bin', '/usr/bin', '/usr/local/bin']
    old_path = os.environ['PATH']

# Generated at 2022-06-11 01:20:48.543119
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("ls", opt_dirs=['/bin', '/usr/bin']) == "/bin/ls"
    assert get_bin_path("ls", opt_dirs=['/bin', '/usr/bin']) == "/bin/ls"
    assert get_bin_path("ls", opt_dirs=['/bin', '/usr/bin']) == "/bin/ls"
    assert get_bin_path("ls", opt_dirs=['/bin', '/usr/bin']) == "/bin/ls"

    try:
        get_bin_path("ls1", opt_dirs=['/bin', '/usr/bin'])
        assert False
    except ValueError:
        pass



# Generated at 2022-06-11 01:20:49.303392
# Unit test for function get_bin_path
def test_get_bin_path():
    #Return type: bool
    return bool(get_bin_path('hostname'))

# Generated at 2022-06-11 01:20:56.608951
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert get_bin_path('/bin/ls') == '/bin/ls'
    except Exception as e:
        raise AssertionError("Test 1: get_bin_path raises Exception: %s" % str(e))
    try:
        assert get_bin_path('/bin/ls', opt_dirs=['/bin']) == '/bin/ls'
    except Exception as e:
        raise AssertionError("Test 2: get_bin_path raises Exception: %s" % str(e))
    try:
        get_bin_path('/bin/ls', opt_dirs=['/usr'])
        raise AssertionError("Test 3: get_bin_path did not raise Exception")
    except ValueError:
        pass

# Generated at 2022-06-11 01:21:06.299171
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    from stat import S_IXUSR
    from ansible.module_utils.six import PY3

    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    if PY3:
        f.write('#!/bin/sh\ntouch /tmp/foo\n')
    else:
        f.write('#!/bin/sh\ntouch /tmp/foo\n')
    os.fchmod(fd, S_IXUSR)
    f.close()

    bin_path = get_bin_path(fname)
    assert(bin_path)

    os.unlink(fname)

# Generated at 2022-06-11 01:21:07.617554
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-11 01:21:18.293585
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    tempdir = tempfile.mkdtemp()
    bin = os.path.join(tempdir, 'bash')

    # case 1: bin is not in PATH
    os.environ['PATH'] = '/sbin:/usr/bin'
    try:
        get_bin_path('bash')
        assert False, 'File bash was not found in %s' % os.environ['PATH']
    except ValueError:
        pass

    # case 2: bin is in PATH, but not an executable
    if os.path.exists(os.path.join('/tmp', 'bash')):
        os.unlink(os.path.join('/tmp', 'bash'))
    open(os.path.join('/tmp', 'bash'), 'w').write('')

# Generated at 2022-06-11 01:21:27.103904
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test to make sure get_bin_path raises an error if no binary path is found
    try:
        get_bin_path('ansible-test-bin')
        assert False, 'Should have thrown an error'
    except ValueError as e:
        assert True

    # Test to make sure that get_bin_path successfully finds the specified binary
    new_path = get_bin_path('ls')
    assert new_path == '/bin/ls'

    # Test to make sure that get_bin_path successfully finds the specified binary in the /sbin path
    new_path = get_bin_path('fdisk')
    if new_path == '/bin/fdisk':
        new_path = get_bin_path('fdisk', ['/bin', '/sbin', '/usr/sbin'])

# Generated at 2022-06-11 01:21:36.039419
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('python')
    assert os.path.exists(bin_path)
    assert is_executable(bin_path)
    assert os.path.basename(bin_path) == 'python'

    try:
        # this should fail
        get_bin_path('junk_file')
        assert False, "Failed to raise exception when looking for junk_file"
    except ValueError:
        assert True

# Test the find_executable wrapper

# Generated at 2022-06-11 01:21:46.832304
# Unit test for function get_bin_path
def test_get_bin_path():
    path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=[path, None, '/dev/null']) == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/dev/null']) == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/dev/null', path]) == path + '/test/units/module_utils/basic.py'

# Generated at 2022-06-11 01:21:50.886123
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    import filecmp
    import copy

    def touch(fname, mode=0o666, dir_fd=None, **kwargs):
        flags = os.O_CREAT | os.O_APPEND
        with os.fdopen(os.open(fname, flags=flags, mode=mode, dir_fd=dir_fd)) as f:
            os.utime(f.fileno() if os.utime in os.supports_fd else fname, dir_fd=None if os.supports_fd else dir_fd, **kwargs)

    # create temporary directory to store test files
    tmp_dir = tempfile.mkdtemp()
    # create test data

# Generated at 2022-06-11 01:21:59.722887
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path by running one command over and over with different args and different
    options, with different PATH settings.
    '''
    # executable exists in normal PATH directory
    assert get_bin_path('ls') == '/bin/ls'
    # executable exists in alternate PATH directory
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'

    # appends /sbin to PATH and tests for executable
    assert get_bin_path('mkfs') == '/sbin/mkfs'

    # does not append /sbin to PATH, executable does not exist
    try:
        get_bin_path('mkfs')
        assert False  # should not get here
    except ValueError:
        pass

    # appends /sbin to PATH, executable exists

# Generated at 2022-06-11 01:22:11.425875
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.file import MissingFileError

    """Unit test for module_utils.common.file.get_bin_path."""
    (fd, bin_path) = tempfile.mkstemp()
    os.chmod(to_bytes(bin_path), int('0777', 8))
    os.close(fd)
    with pytest.raises(ValueError) as exc:
        get_bin_path('not_found_binary')

    args = ['PATH/bin/sh', '-c', 'echo -n hello', '|', 'PATH/bin/grep', 'world']
    expected_rc, expected_stdout, expected_

# Generated at 2022-06-11 01:22:15.675557
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no_such_bin')
        assert False, 'An exception should have been thrown'
    except ValueError:
        pass

    path = get_bin_path('sh')
    assert path.endswith('/bin/sh') or path.endswith('/usr/bin/sh')

# Generated at 2022-06-11 01:22:26.096815
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = None
    try:
        bin_path = get_bin_path('true')
        assert (bin_path is not None)
    except ValueError:
        # should not happen
        assert (False)
    assert (is_executable(bin_path))
    assert (os.path.exists(bin_path))
    assert (bin_path.endswith('/true'))

    try:
        get_bin_path('what_is_this_command_anyway?')
        # should not happen
        assert (False)
    except ValueError:
        assert (True)

    try:
        get_bin_path('what_is_this_command_anyway?', required=True)
        # should not happen
        assert (False)
    except ValueError:
        assert (True)




# Generated at 2022-06-11 01:22:31.025275
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' unit test for function get_bin_path '''
    bin_path = get_bin_path('ls')
    assert bin_path == '/bin/ls'
    # this should fail
    try:
        get_bin_path('ls_asdf_command')
    except ValueError:
        pass
    else:
        raise AssertionError("should have failed with ValueError")



# Generated at 2022-06-11 01:22:41.646173
# Unit test for function get_bin_path
def test_get_bin_path():
    test_path = '/usr/bin:/usr/sbin'
    testpath_env = dict(os.environ)
    testpath_env['PATH'] = test_path
    try:
        # with os.environ['PATH']=test_path
        test_path = []
        assert get_bin_path('ls', test_path) == '/bin/ls'
        assert get_bin_path('true', test_path) == '/bin/true'
        assert get_bin_path('/usr/bin/false', test_path) == '/usr/bin/false'
    finally:
        os.environ = testpath_env


# Generated at 2022-06-11 01:22:50.901871
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import shutil
    import stat
    import tempfile

    def test_bin_path(arg, opt_dirs, expected):
        bin_path = get_bin_path(arg, opt_dirs)
        assert expected == bin_path

    # test the function with a command that's found in one of the default paths
    test_bin_path("ls", None, shutil.which("ls"))

    # test the function with a command that's not found in any of the default paths
    test_bin_path("fakedir/faketestcommand", ["/tmp/doesntexist", ".."], None)

    # test the function with a command that's found in one of the opt_dirs
    tempdir = tempfile.mkdtemp()

    def create_temp_file(filename, permission):
        full_path

# Generated at 2022-06-11 01:22:57.285931
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
# End unit test

# Generated at 2022-06-11 01:23:06.496367
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.facts.system.base import get_file_content, base_executable_exists
    get_bin_path('sh')
    try:
        get_bin_path('wtf', required=True)
        assert False, "Expected exception"
    except ValueError:
        pass
    get_bin_path('sh', opt_dirs=[])
    get_bin_path('sh', opt_dirs=[os.getcwd()])
    get_bin_path('sh', opt_dirs=['/bin','/usr/bin',os.getcwd()])

    data = get_file_content('/etc/issue')
    assert isinstance(data, str)
    assert base_executable_exists('sh')
    assert not base_executable_exists('shylock')

# Generated at 2022-06-11 01:23:15.337418
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os
    import sys

    bin_path = None
    # create temp dir
    tmpdir = tempfile.mkdtemp()
    filepath = os.path.join(tmpdir, "test_executable")

    # create temp file
    try:
        with open(filepath, 'w') as f:
            f.write('#!/bin/bash')
        os.chmod(filepath, 0o755)
        bin_path = get_bin_path("test_executable", [tmpdir])
        assert bin_path == os.path.join(tmpdir, "test_executable")
    except:
        shutil.rmtree(tmpdir)
        raise
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-11 01:23:22.313117
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Standalone unit test for function get_bin_path.
    '''

    # Define unit test data used by test cases.
    test_cases = [
        {'arg': 'python', 'path': '/usr/bin/python', 'description': 'found in system PATH'},
        {'arg': 'nonexistent', 'path': '', 'description': 'failed to find nonexistent file'},
        {'arg': 'pwd', 'path': '/bin/pwd', 'description': 'found using opt_dirs'},
        {'arg': 'nonexistent', 'path': '', 'description': 'failed to find nonexistent file using opt_dirs'},
    ]

    # Execute test case

# Generated at 2022-06-11 01:23:26.538153
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
    module = __import__('ansible.module_utils.basic', fromlist=['ansible', 'module_utils', 'basic'])
    assert module

# Generated at 2022-06-11 01:23:33.165761
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ping') == '/bin/ping'
    assert get_bin_path('ping', ['/usr/share/ansible/test/units/module_utils/netcommons2/test/bin']) == '/usr/share/ansible/test/units/module_utils/netcommons2/test/bin/ping'
    assert get_bin_path('ping', ['/usr/share/ansible/test/units/module_utils/netcommons2/test/bin', None]) == '/usr/share/ansible/test/units/module_utils/netcommons2/test/bin/ping'

# Generated at 2022-06-11 01:23:36.287909
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('vim')
    assert type(path) is str
    try:
        path = get_bin_path('_this_path_should_not_exist')
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError not raised!'


# Generated at 2022-06-11 01:23:46.419085
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    try:
        tmpdir = tempfile.mkdtemp()
        # Create an executable file
        with open(tmpdir + "/myprog", "wb") as fd:
            fd.write("#!/usr/bin/python\n")
        # Add myprog to executable search path
        paths = [tmpdir]
        # Execute function get_bin_path
        bin_path = get_bin_path('myprog', paths)
        # Check if the function return the correct path of the executable
        assert bin_path == tmpdir + "/myprog"
    finally:
        try:
            # Cleanup
            shutil.rmtree(tmpdir)
        except OSError:
            pass

# Generated at 2022-06-11 01:23:57.238333
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import platform
    from ansible.module_utils.basic import AnsibleModule

    if sys.version_info[:2] >= (2, 8):
        # Python 2.8 and later
        from unittest import TestCase
    else:
        # Python 2.7 and earlier
        from unittest2 import TestCase

    class TestGetBinPath(TestCase):
        ''' Test get_bin_path function '''
        def testNonexistent(self):
            ''' Test nonexistent executable '''
            module = AnsibleModule(argument_spec=dict())
            arg = 'nonexistent_executable'
            with self.assertRaises(ValueError):
                get_bin_path(arg, opt_dirs=None, required=True)


# Generated at 2022-06-11 01:24:04.841838
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check that get_bin_path finds commands in the normal path
    assert get_bin_path('ls') == '/bin/ls'

    # Check that get_bin_path finds commands specified in opt_dirs
    opt_dirs = ['/bin']
    assert get_bin_path('ls', opt_dirs) == '/bin/ls'

    # Check that get_bin_path raises error if command is not found
    opt_dirs = ['/invalid_dir']
    try:
        get_bin_path('invalid_command', opt_dirs)
        assert False, 'get_bin_path did not raise an Error'
    except ValueError:
        pass

# Generated at 2022-06-11 01:24:10.910536
# Unit test for function get_bin_path
def test_get_bin_path():
    # See gh-4809
    assert get_bin_path('cat') in ['/bin/cat', '/usr/bin/cat']

# Generated at 2022-06-11 01:24:22.740748
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.text.converters import to_text
    # Some tests use the function get_bin_path.
    # Create a fake PATH environment variable for abbreviated tests
    fake_path = "./test/module_utils/test_common_utils"
    os.environ["PATH"] = fake_path

    test_args = ['sysctl', 'not_installed']
    for test_arg in test_args:
        try:
            get_bin_path(test_arg)
        except Exception as error:
            if test_arg == 'sysctl':
                raise Exception("test_get_bin_path failed. "
                                "It looks like the file 'sysctl' is missing from the test data.")

# Generated at 2022-06-11 01:24:31.912632
# Unit test for function get_bin_path
def test_get_bin_path():
    directories = ['/sbin', '/usr/sbin', '/usr/local/sbin']
    execs = {'/sbin': 'ip', '/sbin/': 'ip', '/sbin/ip': 'ip', '/usr/sbin': 'ip', '/usr/sbin/': 'ip', '/usr/sbin/ip': 'ip', '/usr/local/sbin': 'ip', '/usr/local/sbin/': 'ip', '/usr/local/sbin/ip': 'ip'}
    for k in execs.keys():
        assert get_bin_path(execs[k], directories) == k


# Generated at 2022-06-11 01:24:37.050446
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.path.exists('/bin/ls'):
        assert get_bin_path('ls') == '/bin/ls'
    if os.path.exists('/usr/bin/python'):
        assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('foobar')


# Generated at 2022-06-11 01:24:41.132934
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import pytest
    import mock
    import shutil

    # Test that it calls os.path.exists
    with mock.patch('os.path.exists') as mock_exists:
        get_bin_path('my_command')
        assert mock_exists.call_count == 1

    # Test that it calls is_executable
    with mock.patch('ansible.module_utils.common.file.is_executable') as mock_is_executable:
        get_bin_path('my_command')
        assert mock_is_executable.call_count == 1

    # Test with a required=True
    # Prior to 2.10, this would throw an exception
    # In 2.10 and later, this always throws an exception
    # TODO: remove this code in 2.14

# Generated at 2022-06-11 01:24:41.562246
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') is not None

# Generated at 2022-06-11 01:24:52.262666
# Unit test for function get_bin_path
def test_get_bin_path():
    import os

    def save_paths(saved_paths):
        def _get_bin_path(*args, **kwargs):
            saved_paths['called'] = True
            saved_paths['args'] = args
            saved_paths['kwargs'] = kwargs
            return 'findme'
        return _get_bin_path

    # If arg is found in PATH, return it.
    saved_paths = {'called': False}  # use dict so we can modify in nested function
    get_bin_path_orig = get_bin_path

# Generated at 2022-06-11 01:25:03.581814
# Unit test for function get_bin_path
def test_get_bin_path():
    test_subset = set(['/sbin', '/usr/sbin', '/usr/local/sbin'])
    opt_dirs = ['/opt/bin', '/usr/local/go/bin', '/usr/bin']

    # Test 1
    # Check if get_bin_path returns appropriate path for 'ping' binary
    # Since 'ping' binary is present in '/bin ' and '/sbin', check if get_bin_path
    # found either of these paths
    bin_path = get_bin_path('ping', opt_dirs)
    assert(bin_path == '/bin/ping' or bin_path == '/sbin/ping')

    # Test 2
    # Check if get_bin_path raises exception when it couldn't find 'ping123'
    # in paths

# Generated at 2022-06-11 01:25:13.042283
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # Verify that 'cat' exists
        cat_path = get_bin_path('cat', required=True)
        assert cat_path == '/bin/cat' or cat_path == '/usr/bin/cat' or cat_path == '/usr/local/bin/cat'
        cat_path = get_bin_path('cat')
        assert cat_path == '/bin/cat' or cat_path == '/usr/bin/cat' or cat_path == '/usr/local/bin/cat'

        # Verify that a file that doesn't exist fails
        get_bin_path('cat.file.that.doesnt.exist', required=True)
    except ValueError:
        # Expected behavior
        pass
    else:
        assert False, 'Expected a ValueError from get_bin_path()'

    # Verify that a

# Generated at 2022-06-11 01:25:25.350542
# Unit test for function get_bin_path
def test_get_bin_path():
    # pick an executable that exists in all default search paths
    test_string = 'ifconfig'
    assert isinstance(get_bin_path(test_string), str)
    # verify that a ValueError is raised if the file is not found
    try:
        get_bin_path('nowaythisexists')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    else:
        raise ValueError('Expected a ValueError since file does not exist')
    # if the required file is actually a directory, act as if it's not found
    try:
        get_bin_path('/etc')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    else:
        raise ValueError('Expected a ValueError since directory does not exist')

# Generated at 2022-06-11 01:25:36.031789
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check if function can find 'true'. It should.
    assert get_bin_path('true')
    # Check if a ValueError is raised if executable isn't found
    try:
        get_bin_path('foo_bar_baz')
    except ValueError as e:
        pass
    else:
        assert False



# Generated at 2022-06-11 01:25:38.557121
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test for get_bin_path()
    '''
    bin_path = get_bin_path('/bin/sh')
    assert bin_path == '/bin/sh'

# Generated at 2022-06-11 01:25:46.739865
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('/usr/bin/python', ['/tmp/dummy'])
    assert bin_path == '/usr/bin/python'

    try:
        bin_path = get_bin_path('/usr/bin/python', ['/tmp/dummy'], True)
    except ValueError as exc:
        msg = 'Failed to find required executable "/usr/bin/python" in paths: /tmp/dummy:/bin:/usr/bin'
        assert str(exc) == msg

    try:
        bin_path = get_bin_path('/usr/bin/python', ['/tmp/dummy'], False)
    except ValueError as exc:
        msg = 'Failed to find required executable "/usr/bin/python" in paths: /tmp/dummy:/bin:/usr/bin'
       

# Generated at 2022-06-11 01:25:57.417790
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Unit test for function get_bin_path'''
    from ansible.module_utils import basic

    def testexec(tmpdir, name, code, result=None):
        '''Write a shell script to tmpdir named name, execute it and return output.'''
        path = os.path.join(tmpdir, name)
        with open(path, "wb") as f:
            f.write(b"#!/bin/sh\n")
            f.write(code)
            f.write(b"\n")
        os.chmod(path, 0o755)
        (rc, out, err) = basic.run_command(path)
        if result is not None:
            assert out == result
        return out

    import tempfile
    tmpfd, tmpdir = tempfile.mkstemp()

# Generated at 2022-06-11 01:26:01.969634
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')
    assert get_bin_path('ls', opt_dirs=['/tmp'])
    try:
        get_bin_path('foo')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
        assert 'foo' in str(e)

# Generated at 2022-06-11 01:26:12.664203
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import sys
    import os

    def restore_path(new_path):
        if "PATH" in os.environ:
            os.environ["PATH"] = new_path
        else:
            del os.environ["PATH"]

    def create_file(path):
        fd, fp = tempfile.mkstemp(prefix=path, dir=tmppath)
        os.close(fd)
        return fp

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestBinPath(unittest.TestCase):

        def setUp(self):
            self._old_path = os.environ["PATH"]
            # Create a temp directory
            global tm

# Generated at 2022-06-11 01:26:18.055913
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')
    try:
        get_bin_path('does-not-exist')
        assert False
    except ValueError:
        pass
    assert get_bin_path('ls', opt_dirs=['/bin', ], required=True)
    try:
        get_bin_path('ls', opt_dirs=['/bin', ], required=False)
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 01:26:20.767221
# Unit test for function get_bin_path
def test_get_bin_path():
    """This test passes in a string to search for in PATH and the rest of the arguments"""
    # 'get_bin_path' is tested in the test_ansible_module_common.py file
    pass

# Generated at 2022-06-11 01:26:22.330997
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('ls', ['/bin'])
    except ValueError:
        assert False



# Generated at 2022-06-11 01:26:32.397352
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test module for get_bin_path
    '''
    import shutil
    import tempfile

    cur_path = os.path.dirname(os.path.realpath(__file__))
    dir_fds = []
    bb = 'busybox'
    bb_path = '/bin/' + bb
    bb_path_local = cur_path + bb_path

    if os.path.exists(bb_path_local):
        # Create fake /bin
        tmp_dir_local = tempfile.mkdtemp(prefix='bin_')
        tmp_path_local = os.path.join(tmp_dir_local, bb)
        shutil.copy(bb_path_local, tmp_path_local)

# Generated at 2022-06-11 01:26:47.631465
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.text import to_bytes
    from ansible.module_utils.common.file import HAS_CONS3RT_REDACT

    def _test_get_bin_path(bin_name, expected_path, expected_required=True, expected_exception=None):
        try:
            path = get_bin_path(bin_name, opt_dirs=[], required=expected_required)
            assert path.endswith(expected_path)
        except Exception as e:
            if expected_exception is None:
                raise AssertionError
            elif not isinstance(e, expected_exception):
                raise AssertionError


# Generated at 2022-06-11 01:26:51.909715
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('false') == '/bin/false'

    try:
        get_bin_path('false', required=True)
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

# Generated at 2022-06-11 01:26:54.791042
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/local/bin']) == '/usr/local/bin/sh'
    import pytest
    with pytest.raises(ValueError):
        get_bin_path('no_such_binary')

# Generated at 2022-06-11 01:26:59.277687
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest


# Generated at 2022-06-11 01:27:05.486316
# Unit test for function get_bin_path
def test_get_bin_path():
    import platform
    path = get_bin_path('python')
    assert os.access(path, os.X_OK)
    if platform.system() == 'Linux':
        path = get_bin_path('ip')
        assert os.access(path, os.X_OK)
        path = get_bin_path('ip', opt_dirs=['/sbin'])
        assert os.access(path, os.X_OK)

# Generated at 2022-06-11 01:27:09.291337
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('ansible-connection', ['.'])
        raise AssertionError('Path . found in PATH')
    except ValueError:
        pass

    assert get_bin_path(__file__, ['.']) == __file__

# Generated at 2022-06-11 01:27:16.785092
# Unit test for function get_bin_path
def test_get_bin_path():
    example = '/bin/echo'
    paths = ['/bin', '/usr/bin', '/usr/local/bin']
    assert get_bin_path(example, paths) == example
    assert get_bin_path(example, paths, required=True) == example
    assert get_bin_path('echo', paths) == example
    assert get_bin_path('echo', paths, required=True) == example
    assert get_bin_path('example', paths, required=True) == example
    assert get_bin_path('example', paths) == example

# Generated at 2022-06-11 01:27:25.283457
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    [Unit test for function get_bin_path]
    '''
    # Test get_bin_path
    arg = 'bad'
    opt_dirs = None
    required = None
    try:
        print(get_bin_path(arg, opt_dirs, required))
    except ValueError as exc:
        print('Test get_bin_path Exception: %s' % exc)

    # Test get_bin_path
    arg = 'ls'
    opt_dirs = None
    required = None
    try:
        print(get_bin_path(arg, opt_dirs, required))
    except ValueError as exc:
        print('Test get_bin_path Exception: %s' % exc)


if __name__ == '__main__':
    test_get_bin_path()


# Generated at 2022-06-11 01:27:31.758683
# Unit test for function get_bin_path
def test_get_bin_path():
    # make sure get_bin_path returns full path to the arg
    assert get_bin_path('cp', required=False) == '/usr/bin/cp'
    assert get_bin_path('cp', required=True) == '/usr/bin/cp'
    assert get_bin_path('ls', ['/bin'], required=False) == '/bin/ls'
    assert get_bin_path('ls', ['/bin'], required=True) == '/bin/ls'

# Generated at 2022-06-11 01:27:41.096597
# Unit test for function get_bin_path
def test_get_bin_path():
    # mock module's exit_json function
    def exit_json(*args, **kwargs):
        return {'changed': False, 'rc': 0, 'invocation': {'module_name': 'test'}}

    # change ansible module's exit_json function to our mocked one
    import ansible.modules.system.setup
    ansible.modules.system.setup.exit_json = exit_json

    # mock module's fail_json function
    def fail_json(*args, **kwargs):
        return {'changed': False, 'msg': 'a message', 'invocation': {'module_name': 'test'}}

    # change ansible module's fail_json function to our mocked one
    ansible.modules.system.setup.fail_json = fail_json

    # run tests
    import sys
    import pytest

# Generated at 2022-06-11 01:27:51.364900
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/bin/sh' == get_bin_path('sh')
    assert '/bin/sh' == get_bin_path('sh', None, False)
    opt_dirs = ['/opt/dir', '/opt/dir2']
    assert '/opt/dir2/sh' == get_bin_path('sh', opt_dirs)
    assert '/opt/dir2/sh' == get_bin_path('sh', opt_dirs, False)

# Generated at 2022-06-11 01:28:02.480714
# Unit test for function get_bin_path
def test_get_bin_path():
    # Case where executable is in PATH directory
    get_bin_path('/bin/true')

    # Case where executable is not in PATH directory
    try:
        get_bin_path('/bin/true', opt_dirs=['/usr/bin'])
    except ValueError as e:
        assert e.message.startswith("Failed to find required executable")

    # Case where binary doesn't exist
    try:
        get_bin_path('/bin/foo')
    except ValueError as e:
        assert e.message.startswith("Failed to find required executable")

    # Case where opt_dirs item is the same as PATH
    get_bin_path('/bin/true', opt_dirs=['/usr/bin', '/bin'])

# Generated at 2022-06-11 01:28:06.186776
# Unit test for function get_bin_path
def test_get_bin_path():
    test_arg = 'sh'
    test_paths = ['/bin', '/usr/bin', '/usr/local/bin']

    assert get_bin_path(test_arg, test_paths) == '/bin/sh'

# Generated at 2022-06-11 01:28:13.984602
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os.path

    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/bin/sh') == '/bin/sh'

    d = tempfile.mkdtemp()
    path = os.path.join(d, 'sh')
    with open(path, 'w') as f:
        f.write('#!/bin/sh\necho test\n')
    os.chmod(path, 0o755)

    try:
        assert get_bin_path('sh', opt_dirs=[d]) == path
    finally:
        shutil.rmtree(d)


# Generated at 2022-06-11 01:28:25.317748
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path(None)
    except ValueError:
        pass
    else:
        raise AssertionError("get_bin_path(None) should raise exception")

    try:
        get_bin_path("")
    except ValueError:
        pass
    else:
        raise AssertionError("get_bin_path('') should raise exception")

    try:
        get_bin_path("somefilethatdoesnotexist")
    except ValueError:
        pass
    else:
        raise AssertionError("get_bin_path(arg) and somefilethatdoesnotexist should raise exception")

    if not is_executable(get_bin_path("python")):
        raise AssertionError("get_bin_path(python) should be executable")


# Generated at 2022-06-11 01:28:32.335928
# Unit test for function get_bin_path
def test_get_bin_path():

    # Dummy class for testing
    class DummyModule():
        def __init__(self):
            self.params = {}

    # test if find_executable finds a valid executable
    d = DummyModule()
    assert get_bin_path('echo') == 'echo'

    # test if find_executable raises exception if executable is not found
    d = DummyModule()
    try:
        get_bin_path('thisexecutablewillneverexist')
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-11 01:28:36.121305
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ['PATH'] = "/usr/bin:/bin"
    try:
        path = get_bin_path("sh")
    except ValueError:
        assert False
    assert path == "/bin/sh"

    try:
        get_bin_path("foobar")
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 01:28:47.412777
# Unit test for function get_bin_path
def test_get_bin_path():
    def new_get_bin_path(arg, opt_dirs=None, required=True):
        paths = None
        if opt_dirs:
            paths = os.environ.get('PATH', '')
            os.environ['PATH'] = '%s%s%s' % (os.pathsep.join(opt_dirs), os.pathsep, paths)

        ret = get_bin_path(arg)

        if paths:
            os.environ['PATH'] = paths

        return ret

    assert new_get_bin_path('ls') == '/bin/ls'
    try:
        new_get_bin_path('asdf')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 01:28:51.498420
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        bin_path = get_bin_path('true', [])
    except ValueError:
        bin_path = None
    assert bin_path is not None, 'get_bin_path(true, []) failed'

    try:
        bin_path = get_bin_path('false', [])
    except ValueError:
        bin_path = None
    assert bin_path is not None, 'get_bin_path(false, []) failed'

    try:
        bin_path = get_bin_path('not_an_executable_that_should_exist_on_a_system', [])
    except ValueError:
        bin_path = None

# Generated at 2022-06-11 01:29:01.079346
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    test_dir = tempfile.mkdtemp()

    # Create empty file
    path = os.path.join(test_dir, 'test')
    with open(path, 'w+') as f:
        pass

    # Check if the empty file is executable
    assert is_executable(path) == False

    # Create exectuable file
    path = os.path.join(test_dir, 'test')
    with open(path, 'w+') as f:
        pass
    os.chmod(path, 0o755)

    # Check if the executable file is executable
    assert is_executable(path) == True

    # Check if we can find the executable file
    assert get_bin_path('test', opt_dirs=[test_dir]) == path

    # Check if we can find the executable