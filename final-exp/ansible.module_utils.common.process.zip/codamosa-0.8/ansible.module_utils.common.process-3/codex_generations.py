

# Generated at 2022-06-11 01:19:18.476052
# Unit test for function get_bin_path
def test_get_bin_path():
    # found 'pwd' in PATH
    result = get_bin_path('pwd')
    assert os.path.exists(result)
    assert is_executable(result)

    # not found '/bogus/path' in PATH
    def call_get_bin_path(arg):
        return get_bin_path(arg)
    try:
        call_get_bin_path('/bogus/path')
        assert False
    except ValueError:
        pass

    # found '/sbin/ip' in PATH
    result = get_bin_path('ip')
    assert os.path.exists(result)
    assert is_executable(result)

    # not found '/bogus/path/ip' in PATH
    def call_get_bin_path(arg, opt_dirs):
        opt

# Generated at 2022-06-11 01:19:27.723396
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import sys

    # Set the PATH so we can find the expected command
    os.environ['PATH'] = ':'.join([tempfile.gettempdir(), os.environ['PATH']])

    # Create a fake command executable in a temp directory
    command_path = os.path.join(tempfile.gettempdir(), 'subdir/subsubdir/command')
    if sys.platform == 'win32':
        command_path += '.bat'
    os.makedirs(os.path.dirname(command_path))
    open(command_path, 'wb').close()

    # Make sure the command can be found
    assert get_bin_path('subdir/subsubdir/command') == command_path

    # Make sure we fail when the command doesn't exist

# Generated at 2022-06-11 01:19:36.504714
# Unit test for function get_bin_path
def test_get_bin_path():
    existing_executable = '/usr/bin/echo'
    nonexistent_executable = '/usr/bin/notthere'
    nonexistent_subdir = nonexistent_executable + '.d'

    # Verify we can find a real executable that's on the path in the default case
    assert get_bin_path('echo') == existing_executable

    # Verify we raise an exception if the executable is not on the path
    try:
        get_bin_path(nonexistent_executable)
        # We should not get here
        raise AssertionError
    except ValueError:
        pass

    # Verify we raise an exception of the executable is on the path but
    # the file does not have the executable bit set

# Generated at 2022-06-11 01:19:43.294792
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python2', ['/usr/bin', '/bin']) == '/usr/bin/python2'
    assert get_bin_path('python3', ['/usr/bin', '/bin']) == '/usr/bin/python3'
    assert get_bin_path('python2.7', ['/usr/bin', '/bin']) == '/usr/bin/python2.7'
    assert get_bin_path('python2', ['/usr/bin', '/bin']) == '/usr/bin/python2'
    assert get_bin_path('ping4', ['/usr/bin', '/bin']) == '/usr/bin/ping'
    assert get_bin_path('ping6', ['/usr/bin', '/bin']) == '/usr/bin/ping'

# Generated at 2022-06-11 01:19:55.912982
# Unit test for function get_bin_path
def test_get_bin_path():
    mock_paths = [
        '',
        '/sbin',
        '/usr/sbin',
        '/usr/local/sbin',
        '/fake/path',
        '/another/fake/path',
    ]

    # Test 1: PATH variable set
    os.environ['PATH'] = ':'.join(mock_paths)
    assert get_bin_path('true') == '/usr/bin/true'
    assert get_bin_path('false') == '/usr/bin/false'

    # Test 2: PATH variable not set, missing opt_dirs
    del os.environ['PATH']
    assert get_bin_path('true') == '/usr/bin/true'
    assert get_bin_path('false') == '/usr/bin/false'

    # Test 3: PATH variable not set, opt_

# Generated at 2022-06-11 01:20:03.249210
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    bin_dir = tempfile.mkdtemp()
    # Two executables in bin_dir
    bin_exe1 = os.path.join(bin_dir, 'bin_file1')
    open(bin_exe1, 'w').close()
    os.chmod(bin_exe1, 0o755)
    bin_exe2 = os.path.join(bin_dir, 'bin_file2')
    open(bin_exe2, 'w').close()
    os.chmod(bin_exe2, 0o755)
    # One executable in bin_dir that is not executable
    not_exe = 'not_executable'
    os.path.join(bin_dir, not_exe)
    open(bin_exe2, 'w').close()

# Generated at 2022-06-11 01:20:12.599808
# Unit test for function get_bin_path
def test_get_bin_path():

    try:
        import pytest
        assert 'pytest'
        pytest_mark = pytest.mark.skipif(True, reason="Requires pytest to be installed")
    except ImportError:
        pytest_mark = None

    # setup
    def mock_path(path):
        class mock_path_obj(object):
            def exists(self):
                return path in ['path-exists', 'path-executable']
            def isdir(self):
                return False

        mock = mock_path_obj()
        return mock

    def mock_is_executable(path):
        if path == 'path-executable':
            return True
        else:
            return False

    import __builtin__

# Generated at 2022-06-11 01:20:15.375272
# Unit test for function get_bin_path
def test_get_bin_path():
    opt_dirs = None
    required = None
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('does-not-exist')

# Generated at 2022-06-11 01:20:24.453268
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    # Test for an existing executable in the path.
    assert get_bin_path('python') == sys.executable

    # Test for an executable in the path with an alternate name.
    assert get_bin_path('python2') == sys.executable

    # Test for a missing executable in the path.
    got_exception = False
    try:
        get_bin_path('program_that_does_not_exist')
    except ValueError as e:
        got_exception = True
        expected_message = 'Failed to find required executable "program_that_does_not_exist" in paths: %s' % (os.pathsep.join(os.environ.get('PATH', '').split(os.pathsep)))
        assert str(e) == expected_message

# Generated at 2022-06-11 01:20:36.590691
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    # Make a dirs for testing
    dir1 = tempfile.mkdtemp()
    dir2 = tempfile.mkdtemp()
    dir3 = tempfile.mkdtemp()
    file1 = os.path.join(dir1, 'test1')
    file2 = os.path.join(dir2, 'test2')
    os.mknod(file1)
    os.mknod(file2)

# Generated at 2022-06-11 01:20:47.795192
# Unit test for function get_bin_path

# Generated at 2022-06-11 01:20:55.491538
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    tempdir = tempfile.mkdtemp()
    (script_dir, _) = os.path.split(os.path.realpath(__file__))
    shutil.copyfile(os.path.join(script_dir, '..', '..', '..', 'hacking', 'tests', 'test-executable'),
                    os.path.join(tempdir, 'executable'))
    os.chmod(os.path.join(tempdir, 'executable'), 0o755)

    # Verify test executable can be found in tempdir
    os.environ['PATH'] = ':'.join([tempdir, os.environ['PATH']])
    bin_path = get_bin_path('executable')

# Generated at 2022-06-11 01:20:58.220006
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('ansible')
    assert os.path.exists(path)
    assert is_executable(path)

# Generated at 2022-06-11 01:21:08.057277
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

    try:
        my_script = os.path.join(tmpdir, 'my_script')
        with open(my_script, 'w') as f:
            f.write('#!/bin/sh\necho "hello"')
        os.chmod(my_script, 0o755)

        bash_path = get_bin_path('bash')
        my_script_path = get_bin_path('my_script', [tmpdir])
        assert my_script_path == my_script
        assert bash_path == get_bin_path('bash', [tmpdir])
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-11 01:21:18.771918
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest

    ######################################################################
    # Check against one binary that's always there.
    # Note that this depends on the user having access to run ls.
    ######################################################################
    expected_ls_path = get_bin_path('ls', None, False)

    # Attempting to find ls in an empty dir should not cause an exception.
    empty_dir = '/tmp/not_a_really_directory_that_exists'
    assert expected_ls_path == get_bin_path('ls', [empty_dir], False)

    # Attempting to find ls in an empty dir, when ls is required, should always cause an exception
    with pytest.raises(ValueError):
        get_bin_path('ls', [empty_dir], True)

    # Attempting to find ls in an empty dir, when ls is required

# Generated at 2022-06-11 01:21:25.484876
# Unit test for function get_bin_path
def test_get_bin_path():
    mock_paths = ['', '/bin', os.path.abspath('./bin_path')]

    with open(os.path.join(mock_paths[2], 'ls'), 'w') as f:
        f.write('fake executable')
    os.chmod(os.path.join(mock_paths[2], 'ls'), 0o755)

    assert get_bin_path('ls', opt_dirs=mock_paths, required=True) == os.path.join(mock_paths[2], 'ls')

# Generated at 2022-06-11 01:21:33.803115
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('foo')
        assert False, "Failed to raise ValueError when get_bin_path could not find executable."
    except ValueError:
        pass

    bin_path = get_bin_path('ls')
    assert os.path.exists(bin_path) and is_executable(bin_path), "get_bin_path failed to find executable."
    bin_path = get_bin_path('ls', opt_dirs=[os.path.dirname(bin_path)])
    assert os.path.exists(bin_path) and is_executable(bin_path), "get_bin_path failed to find executable."

# Generated at 2022-06-11 01:21:44.321975
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/bin']) == '/bin/sh'
    try:
        get_bin_path('sh', ['/usr/bin'])
        assert False, 'Expected ValueError'
    except ValueError:
        pass
    try:
        get_bin_path('sh', ['/usr/bin'], True)
        assert False, 'Expected ValueError'
    except ValueError:
        pass
    assert get_bin_path('fio', ['/usr/bin']) == '/usr/bin/fio'

# Generated at 2022-06-11 01:21:47.474762
# Unit test for function get_bin_path
def test_get_bin_path():
    import doctest
    print('Running tests for get_bin_path ...')
    doctest.testmod()

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-11 01:21:55.136967
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    tempdir = tempfile.mkdtemp()
    try:
        # create fake executable
        path = os.path.join(tempdir, 'foo')
        with open(path, 'w') as f:
            f.write('#!/bin/sh')
        os.chmod(path, 0o755)
        # ensure path is in $PATH
        path_to_add = tempdir
        old_path = os.environ['PATH']
        os.environ['PATH'] = path_to_add+os.path.pathsep+old_path
        try:
            bin_path = get_bin_path('foo')
            assert bin_path == path
        finally:
            os.environ['PATH'] = old_path
    finally:
        os.unlink(path)

# Generated at 2022-06-11 01:22:01.612066
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat')

# Generated at 2022-06-11 01:22:12.744913
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile

    def subtest_get_bin_path(expected, arg, opt_dirs=None, required=None):
        try:
            res = get_bin_path(arg, opt_dirs, required)
            assert res == expected
        except ValueError as e:
            assert expected is None and str(e) == expected

    subtest_get_bin_path(None, 'nosuchcommand')
    subtest_get_bin_path(sys.executable, sys.executable.split('/')[-1])
    subtest_get_bin_path(sys.executable, sys.executable.split('/')[-1], ['/bin'])

# Generated at 2022-06-11 01:22:22.466881
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat', ['/bin']) == '/bin/cat'
    assert get_bin_path('cat', ['/bin', '/usr/bin']) == '/bin/cat'
    assert get_bin_path('cat', ['/usr/bin', '/bin']) == '/bin/cat'
    assert get_bin_path('cat', ['/usr/bin', '/bin']) == '/bin/cat'

    # if PATH includes directories that don't exist, they should be ignored
    assert get_bin_path('cat', ['/NONEXISTENT/bin', '/bin']) == '/bin/cat'
    assert get_bin_path('cat', ['/bin', '/NONEXISTENT/bin']) == '/bin/cat'

    # test for #27353
    # If a directory in PATH does not exist

# Generated at 2022-06-11 01:22:31.111798
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', ['/usr/local/bin']) == '/usr/local/bin/ls'
    try:
        get_bin_path('/bin', ['/usr/local/bin'])
        assert False, 'Expected exception'
    except ValueError as e:
        assert 'absolute path' in str(e)
    try:
        get_bin_path('/a/non-existent-bin', ['/usr/local/bin'])
        assert False, 'Expected exception'
    except ValueError as e:
        assert 'Failed to find' in str(e)

# Generated at 2022-06-11 01:22:41.783115
# Unit test for function get_bin_path
def test_get_bin_path():

    # 1. Binary exists in optional directories
    opt_dirs = ['/sbin', '/usr/sbin', '/usr/local/sbin', '/tmp/fake_bin_dir']
    bin_path = get_bin_path('foo', opt_dirs)
    assert bin_path == '/tmp/fake_bin_dir/foo'

    # 2. Binary exists in optional directories, but it's not executable
    opt_dirs = ['/sbin', '/usr/sbin', '/usr/local/sbin', '/tmp/fake_bin_dir']
    error_msg = ''
    try:
        bin_path = get_bin_path('foo1', opt_dirs)
    except ValueError as e:
        error_msg = str(e)

# Generated at 2022-06-11 01:22:46.219943
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # No exception should occur
        get_bin_path('ls')
    except Exception:
        assert False

    try:
        # Exception should occur when executable is not found
        get_bin_path('bad_executable_no_such_file')
        assert False
    except Exception:
        pass

# Generated at 2022-06-11 01:22:53.730292
# Unit test for function get_bin_path
def test_get_bin_path():
    # Python3 workaround
    # pylint: disable=import-error
    import __builtin__
    if hasattr(__builtin__, '__import__'):
        builtin_import = __builtin__.__import__
    else:
        builtin_import = __builtin__.import_
    # pylint: enable=import-error

    # mocking exists to not depend on anything outside '.' and have some code coverage on the if/else branch
    def exists_mock(path):
        if path.endswith('unittest'):
            return True
        return False
    old_exists = os.path.exists
    os.path.exists = exists_mock

# Generated at 2022-06-11 01:23:04.019556
# Unit test for function get_bin_path
def test_get_bin_path():
    bindir = '/bin'
    get_bin_path('ls')
    get_bin_path('ls', opt_dirs=[bindir])
    get_bin_path('ls', required=True)
    get_bin_path('ls', opt_dirs=[bindir], required=True)
    try:
        get_bin_path('ls1')
    except ValueError:
        pass
    try:
        get_bin_path('ls1', required=True)
    except ValueError:
        pass
    try:
        get_bin_path('ls', opt_dirs=['/bin1'])
    except ValueError:
        pass
    try:
        get_bin_path('ls', opt_dirs=['/bin1'], required=True)
    except ValueError:
        pass

# Generated at 2022-06-11 01:23:11.621072
# Unit test for function get_bin_path
def test_get_bin_path():
    # first argument is the executable we are looking for
    # second argument is optional to pass additional directories to search for bin_path
    # third argument is optional boolean to raise an exception if bin_path was not found
    # this argument has been deprecated in 2.10 and will be removed in 2.14
    assert get_bin_path('ls', opt_dirs=[os.path.dirname(get_bin_path('ls'))]) == os.path.realpath(get_bin_path('ls'))
    assert get_bin_path('ls', opt_dirs=[os.path.dirname(get_bin_path('ls')), '/bin']) == os.path.realpath(get_bin_path('ls'))

# Generated at 2022-06-11 01:23:16.884720
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Return OK if get_bin_path works correctly.
    Return FAIL if get_bin_path raises an exception
    '''
    try:
        get_bin_path('python')
    except Exception as err:
        print('FAILED: get_bin_path failed with %s' % err)
    else:
        print('OK')


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-11 01:23:29.731465
# Unit test for function get_bin_path
def test_get_bin_path():
    import unittest

    class TestGetBinPath(unittest.TestCase):
        # Test get_bin_path()
        def test_get_bin_path(self):
            # find an executable that exists
            bin_path = get_bin_path('ls')
            self.assertTrue(os.path.isfile(bin_path))

            # find an executable using the optional list of directories
            bin_path = get_bin_path('ls', opt_dirs=['/bin'])
            self.assertTrue(os.path.isfile(bin_path))

            # try to find an executable that does not exist
            with self.assertRaises(ValueError):
                get_bin_path('non_existent_executable')

    def main():
        unittest.main()


# Generated at 2022-06-11 01:23:37.432428
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    get_bin_path test harness
    '''
    from units.module_utils._text import to_bytes

    # Binary in PATH
    os.environ['PATH'] = '/usr/bin'
    os.symlink('/bin/echo', '/usr/bin/echo')
    assert to_bytes(get_bin_path('echo'), errors='surrogate_or_strict') == to_bytes('/usr/bin/echo')

    # Binary not in PATH
    os.environ['PATH'] = '/usr/bin'
    os.unlink('/usr/bin/echo')

# Generated at 2022-06-11 01:23:48.948433
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    TESTS = [
        # (cmd, expect_found, error_if_not_found=True, search_dir=None)
        ('/bin/ls', True),
        ('/bin/no-such-command', False),
        ('no-such-command', False),
        ('ls', True),
        ('true', True),
        ('false', True),
        ('/bin/bash', True),
        ('bash', True),
        ('/bin/sh', True),
        ('sh', True),
    ]

    # Create a temporary binary file
    f = tempfile.NamedTemporaryFile(delete=False)
    f.close()
    os.chmod(f.name, 0o755)
    TESTS.append((f.name, True))


# Generated at 2022-06-11 01:23:58.894489
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import tempfile
    import shutil

    path_dirs = []
    tmpdir = ''

# Generated at 2022-06-11 01:24:07.496282
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test that get_bin_path performs the basic check we expect
    assert get_bin_path('sleep') == '/bin/sleep'

    # Test that get_bin_path recognizes an executable file in the provided
    # directory.
    assert get_bin_path('sleep', ['/bin']) == '/bin/sleep'

    # Test that get_bin_path provides the full path if the provided path is
    # a directory that contains the executable.
    assert get_bin_path('sleep', ['/bin/']) == '/bin/sleep'

    # Test that get_bin_path recognizes an executable file in /sbin by
    # default
    assert get_bin_path('ip') == '/sbin/ip'
    # Test that get_bin_path finds an executable in /sbin if /sbin is in the
    # provided directories


# Generated at 2022-06-11 01:24:10.671036
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('env') == os.path.join(os.sep, 'usr', 'bin', 'env')
    assert get_bin_path('foobarbaz') == os.path.join(os.sep, 'usr', 'bin', 'foobarbaz')



# Generated at 2022-06-11 01:24:20.020296
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    test_get_bin_path: test function gets path for any valid binary
    '''
    from tempfile import mkdtemp
    from shutil import move, rmtree

    try:
        # create mock /sbin dir
        sbin_dir = mkdtemp(prefix='ansible')
        move('/sbin/ping', os.path.join(sbin_dir, 'ping'))
        assert get_bin_path('ping', [sbin_dir]) == os.path.join(sbin_dir, 'ping')
    finally:
        # cleanup
        rmtree(sbin_dir)

# Generated at 2022-06-11 01:24:27.843881
# Unit test for function get_bin_path
def test_get_bin_path():
    testpaths = ['/tmp', '/usr']
    result = get_bin_path('ls', opt_dirs=testpaths)
    assert result is not None

    try:
        missing = get_bin_path('thismissing' + os.urandom(4).encode('hex'), opt_dirs=testpaths)
        assert False, 'Expected ValueError, got %s' % missing
    except ValueError:
        pass

    # test /sbin dirs
    result = get_bin_path('mount')
    assert result is not None

# Generated at 2022-06-11 01:24:39.517949
# Unit test for function get_bin_path
def test_get_bin_path():
    # python 2.6 doesn't have assertRaisesRegexp, implement it
    # pylint: disable=undefined-variable
    try:
        assertRaisesRegexp  # pylint: disable=pointless-statement
    except NameError:
        import re
        import sys

        def assertRaisesRegexp(expected_exception, expected_regexp, *args, **kwargs):
            '''assertRaisesRegexp(expected_exception, expected_regexp,
                    callable obj, *args, **kwargs)'''
            # pylint: disable=missing-docstring
            def callable_obj(*args, **kwargs):
                '''callable_obj(*args, **kwargs)'''
                # pylint: disable=missing-docstring
                return None


# Generated at 2022-06-11 01:24:43.032763
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = 'ansible-doc'
    bin_path = get_bin_path(arg)
    assert os.path.isabs(bin_path)
    assert os.path.exists(bin_path)

# Generated at 2022-06-11 01:24:52.419666
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('fake_bin')
        assert False
    except ValueError as e:
        assert "Failed to find required executable" in '%s' % e

    try:
        get_bin_path('ls', required=True)
        assert False
    except ValueError as e:
        assert "Failed to find required executable" in '%s' % e

# Generated at 2022-06-11 01:25:03.859850
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    tempdir = tempfile.mkdtemp()

    # noop binary exists
    noop_path = get_bin_path('noop')
    assert os.path.exists(noop_path)
    assert os.path.isfile(noop_path)

    # available on PATH
    PATH = os.environ.get('PATH')

# Generated at 2022-06-11 01:25:07.934019
# Unit test for function get_bin_path
def test_get_bin_path():
    base_dir = '/usr/bin'
    file_name = 'compress'
    file_path = os.path.join(base_dir, file_name)
    assert(get_bin_path(file_name, opt_dirs=[base_dir]) == file_path)

# Generated at 2022-06-11 01:25:08.878307
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python')

# Generated at 2022-06-11 01:25:16.281854
# Unit test for function get_bin_path
def test_get_bin_path():
    import random
    import string

    random_string = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(5))
    bin_path = get_bin_path("ping")
    assert is_executable(bin_path)

    with open(os.devnull, 'w') as devnull:
        assert os.path.exists(get_bin_path("ping", [os.path.dirname(bin_path)]))
        assert os.path.exists(get_bin_path("ping", [os.path.dirname(bin_path), os.path.dirname(bin_path)]))
        assert os.path.exists(get_bin_path("ping", [os.path.dirname(bin_path), "/bin"]))
        assert os.path

# Generated at 2022-06-11 01:25:18.085578
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'

# Generated at 2022-06-11 01:25:23.221884
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    try:
        get_bin_path("command_that_does_not_exist")
        pytest.fail("Expected an exception")
    except ValueError:
        pass

    p = get_bin_path("ls", [])
    assert p is not None
    assert os.path.basename(p) == "ls"

# Generated at 2022-06-11 01:25:28.801517
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible') is not None
    try:
        get_bin_path('sdkfjhjksdaj')
        assert False
    except ValueError:
        pass
    assert get_bin_path('ansible', opt_dirs=[os.path.dirname(get_bin_path('ansible'))]) is not None

# Generated at 2022-06-11 01:25:40.354683
# Unit test for function get_bin_path
def test_get_bin_path():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    test_file = os.path.join(current_dir, 'test_file')
    # Test 1: Valid path
    try:
        os.makedirs('/tmp/bin')
        os.symlink(test_file, '/tmp/bin/test_file')
        os.environ['PATH'] = '/tmp/bin:/usr/bin'
        assert get_bin_path('test_file') == test_file
    finally:
        os.remove('/tmp/bin/test_file')
        os.rmdir('/tmp/bin')
    # Test 2: Valid path with forced directories

# Generated at 2022-06-11 01:25:44.123034
# Unit test for function get_bin_path
def test_get_bin_path():
    module = None
    try:
        get_bin_path('asdf') # executable asdf should not be found
    except ValueError as e:
        assert 'Failed to find required executable "asdf" in paths' in str(e)
    assert get_bin_path('/bin/sh') == '/bin/sh' # returns full path to executable



# Generated at 2022-06-11 01:25:59.481965
# Unit test for function get_bin_path
def test_get_bin_path():
    mypath = '/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'

    # found
    rc, result = get_bin_path('ls', opt_dirs=['/bin'], required=True)
    assert rc == 0
    assert result == '/bin/ls'

    # found (opt_dirs and required are ignored)
    rc, result = get_bin_path('ls')
    assert rc == 0
    assert result == '/bin/ls'

    # not found
    rc, result = get_bin_path('foo', opt_dirs=['/bin'], required=True)
    assert rc == 1
    assert result == 'Failed to find required executable "foo" in paths: /usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'

    # not

# Generated at 2022-06-11 01:26:03.189003
# Unit test for function get_bin_path
def test_get_bin_path():
    # This only tests the executable search path logic. Testing that the executable actually exists is trivial,
    # and testing that it runs is pointless.
    import shutil
    import tempfile
    import unittest

    class GetBinPathTestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.test_name = 'some_executable'
            self.test_path = os.path.join(self.tmpdir, self.test_name)
            with open(self.test_path, 'w+') as fd:
                fd.write('')
            os.chmod(self.test_path, 0o777)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)


# Generated at 2022-06-11 01:26:08.862032
# Unit test for function get_bin_path
def test_get_bin_path():
    program = 'dirname'
    if is_executable(get_bin_path(program)):
        pass
    else:
        raise ValueError('Function get_bin_path failed to find required program "%s"' % program)

    try:
        get_bin_path('__non_existent_program__')
    except ValueError:
        pass
    else:
        raise ValueError('Function get_bin_path did not raise ValueError on non-existent program')

# Generated at 2022-06-11 01:26:18.895595
# Unit test for function get_bin_path
def test_get_bin_path():
    # make a temp dir
    import tempfile
    tmpdir = tempfile.mkdtemp()
    # make a fake executable
    fakeexec = os.path.join(tmpdir, 'fakeexec')
    with open(fakeexec, 'w') as f:
        f.write("#!/bin/sh\nexit 42")
    os.chmod(fakeexec, 0o755)

# Generated at 2022-06-11 01:26:28.213326
# Unit test for function get_bin_path
def test_get_bin_path():
    test_paths = ['/usr/bin', '/bin', '/usr/local/bin', '/usr/sbin', '/usr/local/sbin', '/sbin']
    test_data = dict(
        none=dict(arg='nothinghere', path=None),
        bash_env=dict(arg='bash', path=get_bin_path('bash')),
        sed_default=dict(arg='sed', path=get_bin_path('sed', None)),
        sed_path_list=dict(arg='sed', path=get_bin_path('sed', test_paths)),
        sed_fail=dict(arg='sed', path=None, exc_type=ValueError),
    )

# Generated at 2022-06-11 01:26:36.977730
# Unit test for function get_bin_path
def test_get_bin_path():

    # Test 1: Verify that get_bin_path returns valid path for a program
    # that exists in the default PATH
    rv = get_bin_path('bash')
    assert os.path.exists(rv)
    assert rv.endswith('/bash')

    # Test 2: Verify that get_bin_path raises a ValueError if the
    # specified program does not exist in the default PATH
    import pytest
    with pytest.raises(ValueError):
        rv = get_bin_path('bash-no-such-program')

    # Test 3: Verify that get_bin_path returns a valid path in
    # non-default PATH when provided a different path
    rv = get_bin_path('date', opt_dirs=[os.path.join('/bin')])
    assert os.path.ex

# Generated at 2022-06-11 01:26:46.494690
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('sh', ['/bin']) == '/bin/sh'
    assert get_bin_path('sh') == '/bin/sh'

    try:
        get_bin_path('sh', ['/'])
        assert False
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "sh" in paths: /'

    try:
        get_bin_path('sh', [None])
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "sh" in paths: /sbin:/usr/sbin:/usr/local/sbin'

# Generated at 2022-06-11 01:26:55.424379
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function
    '''
    import platform
    from ansible.module_utils.common.file import is_executable

    # Leave PATH undefined and just test if python process is executable
    if platform.system() == 'Windows':
        abs_python_exe = os.path.abspath(os.path.join(os.path.dirname(sys.executable), '..', 'python.exe'))
    else:
        abs_python_exe = sys.executable

    paths = [os.path.dirname(abs_python_exe)]
    exe_path = get_bin_path(os.path.basename(sys.executable), paths)

    assert os.path.exists(exe_path)
    assert is_executable(exe_path)

    # If PATH is

# Generated at 2022-06-11 01:27:06.798443
# Unit test for function get_bin_path
def test_get_bin_path():
    test_failed = False
    try:
        assert get_bin_path('cat')
    except ValueError:
        test_failed = True
        print('Unexpected value cat does not exist')
    try:
        assert get_bin_path('cat', opt_dirs=['/bin'])
    except ValueError:
        test_failed = True
        print('Unexpected value cat does not exist')
    try:
        assert get_bin_path('cat', opt_dirs=['/bin'])
    except ValueError:
        test_failed = True
        print('Unexpected value cat does not exist')
    try:
        assert get_bin_path('/bin/cat')
    except ValueError:
        test_failed = True
        print('Unexpected value /bin/cat does not exist')

# Generated at 2022-06-11 01:27:17.124710
# Unit test for function get_bin_path
def test_get_bin_path():
    # First test that we can find the required executables
    valid_paths = []
    for exe in ['python', 'python3', 'python2', 'python2.7']:
        valid_paths.append(get_bin_path(exe))
    assert(len(valid_paths) == len(set(valid_paths)))

    # TODO: add a test to ensure that the path contains an executable
    # Likely will work on 2.14 when Python 2.6 is no longer supported

    # Test that ValueError is raised when an executable cannot be found
    raises_value_error = [get_bin_path('not-a-valid-executable') for x in range(1, 6)]
    assert(all([isinstance(x, ValueError) for x in raises_value_error]))

# Generated at 2022-06-11 01:27:27.317724
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('cat')
    assert path
    # FIXME: what about windows?
    assert os.path.isabs(path)
    assert os.path.isfile(path)
    assert os.access(path, os.X_OK)

    path = get_bin_path('cat', opt_dirs=['/bin'])
    assert path
    # FIXME: what about windows?
    assert os.path.isabs(path)
    assert os.path.isfile(path)
    assert os.access(path, os.X_OK)

    try:
        get_bin_path('nonexistent')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 01:27:33.869973
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('python')
    assert get_bin_path('/usr/bin/python') == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/bin']) == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/bin', '/usr/sbin']) == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/sbin', '/usr/bin']) == '/usr/bin/python'

# Generated at 2022-06-11 01:27:40.781778
# Unit test for function get_bin_path
def test_get_bin_path():
    # locate existing executable
    for executable in ['bash',  # existing executable in PATH
                       'ls',    # existing executable in PATH
                       'cut']:  # existing executable in PATH
        result = get_bin_path(executable)
        assert os.path.exists(result)
        assert os.path.isfile(result)
        assert os.access(result, os.X_OK)

    # fail if executable doesn't exist
    from ansible.module_utils.common.exceptions import AnsibleError
    try:
        get_bin_path('junk')
        assert False
    except AnsibleError:
        pass

# Generated at 2022-06-11 01:27:48.734467
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import os

    d = tempfile.gettempdir()
    # create a file
    f = open(os.path.join(d, 'test_get_bin_path_file'), 'w')
    f.close()

    # create executable (empty file)
    f = open(os.path.join(d, 'test_get_bin_path'), 'w')
    f.close()
    os.chmod(os.path.join(d, 'test_get_bin_path'), 0o755)


# Generated at 2022-06-11 01:27:59.661647
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import os

    # Test zero length PATH
    os.environ['PATH'] = ''
    try:
        get_bin_path('foobar')
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

    # Test path ends in :
    os.environ['PATH'] = '/bin:/usr/bin:'
    try:
        get_bin_path('foobar')
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

    # Test path ends in :/
    os.environ['PATH'] = '/bin:/usr/bin:/'
    try:
        get_bin_path('foobar')
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

    # Test path

# Generated at 2022-06-11 01:28:10.860519
# Unit test for function get_bin_path
def test_get_bin_path():
    def mock_is_executable(path):
        return os.path.exists(path) and os.access(path, os.X_OK)

    test_args = ['does-not-exist', 'cat', 'ls', 'sed', 'bogus-dir']
    test_dirs = ['/bin', '', os.path.dirname(__file__)]
    # make sure not using cygwin path by mistake
    is_cygwin = 'CYGWIN' in os.environ and 'PATH' in os.environ and 'cygdrive' in os.environ['PATH']
    if is_cygwin:
        # skip test since cygwin path names don't work with real os.path API
        pass
    else:
        is_executable_orig = os.path.isfile

# Generated at 2022-06-11 01:28:21.746279
# Unit test for function get_bin_path
def test_get_bin_path():
    # Success Cases
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/ls', ['/bin']) == '/bin/ls'
    assert get_bin_path('ls') == "/bin/ls"
    assert get_bin_path('ls', ['/bin']) == "/bin/ls"

    # Failure Cases
    try:
        assert get_bin_path('/bin/dummy')
    except ValueError as exc:
        assert 'Failed to find required executable' in str(exc)
    try:
        assert get_bin_path('dummy', ['/bin'])
    except ValueError as exc:
        assert 'Failed to find required executable' in str(exc)

# Generated at 2022-06-11 01:28:32.579322
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    def create_temp_executable(content=None):
        f, path = tempfile.mkstemp()
        f = os.fdopen(f, 'w')
        if content:
            f.write(content)
        f.close()
        os.chmod(path, 0o755)
        return path

    temp_executable = create_temp_executable()
    temp_executable2 = create_temp_executable('#!/bin/bash\nexit 0\n')
    temp_python_executable = create_temp_executable('#!/usr/bin/env python\n')
    temp_non_executable = create_temp_executable('#!/bin/bash')
    fake_executable = '/fake/path/%s' % os.path.basename(temp_executable)

# Generated at 2022-06-11 01:28:43.211736
# Unit test for function get_bin_path
def test_get_bin_path():
    file1 = '/tmp/test_get_bin_path'
    file2 = '/root/test_get_bin_path'
    file3 = '/test_get_bin_path'
    # Create three files to test various cases
    open(file1, 'a').close()
    open(file2, 'a').close()
    open(file3, 'a').close()
    # Case 1: User provides a directory in opt_dirs
    # Make sure we use the one the user provided
    f = get_bin_path('test_get_bin_path', ['/root'])
    assert f == '/root/test_get_bin_path'
    # Case 2: User does not provide a directory in opt_dirs and does not have permission
    #        to access file2. Make sure we raise an exception

# Generated at 2022-06-11 01:28:49.965096
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Returns:
        True if test succeeds, raises exception otherwise.
    '''

    executable = "cat"

    if not isinstance(get_bin_path(executable), str):
        raise AssertionError("Did not find executable " + executable)

    # Verify exception is raised if executable is not found
    try:
        get_bin_path("ThisIsAnUnknownExecutableWhichShouldNotExist")
    except ValueError:
        pass
    except:
        raise AssertionError("ValueError not raised for un-existing executable")

# Generated at 2022-06-11 01:29:02.979718
# Unit test for function get_bin_path
def test_get_bin_path():
    # test path of python
    assert get_bin_path('python') == '/usr/bin/python'
    # test path of non-existent file
    try:
        get_bin_path('thisfiledoesntexist')
    except ValueError as e:
        assert e.message == 'Failed to find required executable "thisfiledoesntexist" in paths: /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games'
    # test path of non-executable file

# Generated at 2022-06-11 01:29:10.561472
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Test get_bin_path function'''
    tmp_dir = os.path.dirname(__file__)
    if not tmp_dir:
        tmp_dir = '.'
    tmp_file0 = os.path.join(tmp_dir, 'file0')
    with open(tmp_file0, 'w') as handle:
        handle.write("#!/bin/sh\nexit 0\n")
    os.chmod(tmp_file0, 0o755)
    assert get_bin_path('file0') == tmp_file0
    os.remove(tmp_file0)