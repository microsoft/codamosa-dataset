

# Generated at 2022-06-11 01:19:22.188068
# Unit test for function get_bin_path
def test_get_bin_path():
    # Workaround to avoid system PATH
    os.environ['PATH'] = ''
    # Test with empty opt_dirs
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('less') == '/usr/bin/less'
    # Test with '/usr/bin' in opt_dirs
    assert get_bin_path('cat', opt_dirs=['/usr/bin']) == '/bin/cat'
    assert get_bin_path('less', opt_dirs=['/usr/bin']) == '/usr/bin/less'
    # Test with '/usr/bin' and '/bin' in opt_dirs
    assert get_bin_path('cat', opt_dirs=['/usr/bin', '/bin']) == '/bin/cat'
    assert get_bin_path

# Generated at 2022-06-11 01:19:30.430999
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = [os.path.expanduser('~/.local/bin')]

    assert get_bin_path('tee') == '/usr/bin/tee'
    assert get_bin_path('tee', opt_dirs=paths) == '/usr/bin/tee'

    # On a Debian-like system, ping is in /bin but iputils-ping is in /usr/lib/iputils
    iputils_path = '/usr/lib/iputils'
    if os.path.exists(iputils_path):
        assert get_bin_path('ping', opt_dirs=paths) == os.path.join(iputils_path, 'ping')

    # On a Debian-like system, ip is in /sbin
    assert get_bin_path('ip') == '/sbin/ip'

    #

# Generated at 2022-06-11 01:19:34.045207
# Unit test for function get_bin_path
def test_get_bin_path():
    # execute module function
    # use different path list when running unit tests as we don't have normal ansible environment
    try:
        bin_path = get_bin_path('ansible')
    except ValueError:
        bin_path = None
    assert bin_path is not None

# Generated at 2022-06-11 01:19:37.610836
# Unit test for function get_bin_path
def test_get_bin_path():
    my_path = get_bin_path('echo')
    assert my_path == '/bin/echo'

    '''
    # Unit tests
    def test_get_bin_path():
    my_path = get_bin_path('echo')
    assert my_path == '/bin/echo'
    '''

# Generated at 2022-06-11 01:19:47.183441
# Unit test for function get_bin_path
def test_get_bin_path():
    # just fail without a valid path
    try:
        ansible_path = get_bin_path("ansible")
    except ValueError:
        pass  # this is what we want
    else:
        raise AssertionError("Failed to raise ValueError when ansible is not in the PATH")

    # this will fail as /bin is not in the path
    try:
        bin_path = get_bin_path("ls")
    except ValueError:
        pass  # this is what we want
    else:
        raise AssertionError("Failed to raise ValueError when /bin is not in the PATH")

    # because the function is mocked, we can pass an absolute path
    test_path = "/bin/ls"
    bin_path = get_bin_path("/bin/ls", opt_dirs=["/bin"])

# Generated at 2022-06-11 01:19:57.431384
# Unit test for function get_bin_path
def test_get_bin_path():
    # test call with arg=None
    try:
        get_bin_path(None)
        assert False
    except ValueError:
        pass
    # test call with bad arg
    try:
        get_bin_path('pifpafpouf')
        assert False
    except ValueError:
        pass
    # test call with good arg
    assert get_bin_path('sh')
    # test call with good arg and opt_dirs
    assert get_bin_path('sh', ['/sbin', "/bin"])
    # test call with good arg and opt_dirs
    try:
        get_bin_path('pifpafpouf', ['/sbin', "/bin"])
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 01:20:06.870296
# Unit test for function get_bin_path
def test_get_bin_path():
    if get_bin_path('foo') == get_bin_path('foo', ['/bin']):
        raise Exception("No /bin/foo executable")
    if get_bin_path('ls') != "/bin/ls":
        raise Exception("Expected /bin/ls")
    if get_bin_path('ls', ['/bin', '/usr/bin']) != "/bin/ls":
        raise Exception("Expected /bin/ls")
    if get_bin_path('ls', ['/usr/bin', '/bin']) != "/bin/ls":
        raise Exception("Expected /bin/ls")

# Generated at 2022-06-11 01:20:16.681829
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    if os.geteuid() == 0:
        # test as root
        assert get_bin_path('which') is not None
    else:
        # test as non-root
        paths = [tempfile.mkdtemp()]
        f = os.path.join(paths[0], 'simple-test-file')
        open(f, 'w').close()
        try:
            assert get_bin_path('simple-test-file', paths) == f
            assert get_bin_path('simple-test-file', required=True) == f
        finally:
            os.unlink(f)
            os.rmdir(paths[0])

# Generated at 2022-06-11 01:20:24.482878
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'

    assert get_bin_path('ls', opt_dirs=['/opt/bin']) == '/opt/bin/ls'

    assert get_bin_path('cat', opt_dirs=['/opt/bin']) == '/bin/cat'

    try:
        get_bin_path('notfound', required=True)
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "notfound" in paths: /sbin:/bin:/usr/sbin:/usr/bin:/opt/bin'

    assert get_bin_path('cat', opt_dirs=['/opt/bin']) == '/bin/cat'

# Generated at 2022-06-11 01:20:36.647914
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import sys

    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.file import is_executable

    def _test_bin_path(expected, arg, env, optional_dirs):
        module = type('MockModule', (object,), {
            'get_bin_path': get_bin_path
        })
        module.fail_json = lambda *args, **kwargs: sys.exit(2)

        try:
            if not isinstance(env, MutableMapping):
                env = {}
            with mock.patch.dict(os.environ, env):
                bin_path = module.get_bin_path(arg, optional_dirs)
        except SystemExit as e:
            assert e.code == 2


# Generated at 2022-06-11 01:20:43.266190
# Unit test for function get_bin_path
def test_get_bin_path():
    # setup
    bin_path = '/bin/sh'
    old_path = os.environ['PATH']
    os.environ['PATH'] = '/bin'
    # test
    path = get_bin_path('sh')
    assert path == bin_path
    # teardown
    os.environ['PATH'] = old_path

# Generated at 2022-06-11 01:20:53.225299
# Unit test for function get_bin_path
def test_get_bin_path():
    import ansible.module_utils.common.file as file_module
    from ansible.module_utils.facts import get_file_module

    # Change this to the path of your real find binary which should be in your PATH
    find_bin = '/usr/bin/find'
    with open(find_bin, 'w') as f:
        f.write("#!/bin/sh\n")
    os.chmod(find_bin, 0o755)

    # Change this to the path of your real find which should be in your PATH
    find_path = '/usr/bin/find'
    os.symlink(find_bin, find_path)
    # Make sure chmod doesn't follow the symlink
    os.chmod(find_path, 0o777)

    # Check that file is in PATH
    find_bin

# Generated at 2022-06-11 01:21:04.944650
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    path = tempfile.mkdtemp(prefix='tmp-')

    # create executable file in temporary path
    fname = 'exec01'
    with open(os.path.join(path, fname), 'w') as f:
        f.write('#!/bin/csh\n')
    os.chmod(os.path.join(path, fname), 0o755)

    # get_bin_path() should return full path for this executable name
    assert get_bin_path(fname) == os.path.join(path, fname)

    # get_bin_path() should return full path for this executable name even if opt_dirs is specified

# Generated at 2022-06-11 01:21:10.159277
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.file import get_bin_path
    path = get_bin_path('dd')
    assert path
    try:
        # In Ansible 2.10, this is supposed to raise an exception.
        get_bin_path('does_not_exist', required=True)
        assert False
    except ValueError as e:
        assert e.message == 'Failed to find required executable "does_not_exist" in paths: /usr/bin:/bin'

# Generated at 2022-06-11 01:21:20.720672
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin/sh']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin/sh/bin']) == '/bin/sh'

    try:
        get_bin_path('sh', opt_dirs=['/usr/bin/sh'])
        assert False, 'get_bin_path did not fail when it should have'
    except ValueError:
        pass

# Generated at 2022-06-11 01:21:28.379041
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    arg = 'true'

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)

    # Close opened file
    os.close(fd)

    # Remove the file (we are interested just in its path)
    # If we do not need the file anymore, it actually gets removed
    os.unlink(path)

    # Get original PATH
    original_path = os.environ.get('PATH', '')

    # Change PATH to temporary directory
    os.environ['PATH'] = tmpdir

    # Test 1: test get_bin_path with required=False

# Generated at 2022-06-11 01:21:37.954860
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import sys


# Generated at 2022-06-11 01:21:45.732966
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('ansible-doc') == '/bin/ansible-doc'
    assert get_bin_path('ls', opt_dirs=['/opt/ansible/bin']) == '/opt/ansible/bin/ls'
    assert get_bin_path('ip', opt_dirs=['/opt/ansible/bin']) == '/sbin/ip'
    assert get_bin_path('hostname', opt_dirs=[]) == '/bin/hostname'

# Generated at 2022-06-11 01:21:48.023371
# Unit test for function get_bin_path
def test_get_bin_path():
    valid_bin = get_bin_path('ls')
    assert os.path.exists(valid_bin)
    assert os.path.isfile(valid_bin)
    assert is_executable(valid_bin)
    try:
        get_bin_path('this_is_a_bogus_executable')
    except ValueError:
        pass
    else:
        raise AssertionError('get_bin_path failed to raise ValueError')

# Generated at 2022-06-11 01:21:54.516308
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('kubectl', ['/']) == '/kubectl'
    assert get_bin_path('kubectl', ['/usr/local/bin']) == '/usr/local/bin/kubectl'
    assert get_bin_path('kubectl', ['/usr/local/bin'], required=True) == '/usr/local/bin/kubectl'
    try:
        get_bin_path('not_installed_executable')
    except Exception as e:
        assert "Failed to find required executable" in str(e)

# Generated at 2022-06-11 01:21:59.773988
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['./', '/usr/sbin/', '/usr/bin/']
    assert get_bin_path("ls", paths) == "/usr/bin/ls"
    assert get_bin_path("not_existing_bin", paths) is None

# Generated at 2022-06-11 01:22:11.466815
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' test_get_bin_path(arg, opt_dirs=None, required=None): unittest for get_bin_path '''
    import tempfile
    import shutil

    good_bin = '/bin/ls'
    bad_bin = '/bin/foobar'
    tmpdir = tempfile.mkdtemp()
    tmpbin = os.path.join(tmpdir, 'ls')
    shutil.copy(good_bin, tmpbin)

    # find a good binary in tmpdir and /bin
    assert get_bin_path('ls', opt_dirs=[tmpdir, '/bin']) == tmpbin
    # find a good binary in tmpdir
    assert get_bin_path('ls', opt_dirs=[tmpdir]) == tmpbin
    # fail to find a bad binary anywhere

# Generated at 2022-06-11 01:22:16.194193
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python')
    assert get_bin_path('python', required=True)
    # Try to get an executable program that does not exist
    # and expect a ValueError exception
    try:
        get_bin_path('does-not-exist')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)


# Generated at 2022-06-11 01:22:26.588388
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('__foobar__')
        raise SystemExit(1)
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

    try:
        get_bin_path('__foobar__', ['/tmp'])
        raise SystemExit(1)
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

    assert os.path.basename(get_bin_path('chmod')) == 'chmod'
    assert os.path.basename(get_bin_path('chmod', ['/tmp'])) == 'chmod'
    assert os.path.basename(get_bin_path('cat', ['/bin'])) == 'cat'

# Generated at 2022-06-11 01:22:34.736484
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test python function get_bin_path()
    '''

    # test_no_dirs_error
    try:
        bin_path = get_bin_path('foo')
    except ValueError:
        pass

    # test no dirs, no error
    bin_path = get_bin_path('foo', [])
    assert bin_path is None

    # test with dirs, found in dir
    bin_path = get_bin_path('foo', ['/usr/bin'])
    assert bin_path == '/usr/bin/foo'

    # test with dirs, not found in any dir
    bin_path = get_bin_path('foo', ['/usr/bin', '/usr/sbin'])
    assert bin_path is None

# Generated at 2022-06-11 01:22:39.341696
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path(arg='test_obviously_not_found_binary')
    except ValueError:
        return
    raise AssertionError('Expected get_bin_path(arg=test_obviously_not_found_binary) to raise ValueError')


# Generated at 2022-06-11 01:22:46.127301
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    from ansible.module_utils.facts import get_file_content
    from ansible.module_utils.basic import AnsibleModule

    # Run the function
    result = get_bin_path('sh')

    # Verify result
    assert os.path.exists(result) and os.path.isfile(result) and os.access(result, os.X_OK), \
           "get_bin_path('sh') should return a file with execute permissions"

# Generated at 2022-06-11 01:22:56.148358
# Unit test for function get_bin_path
def test_get_bin_path():
    def assert_bin_path(expected_val, arg, opt_dirs=None, required=None):
        if expected_val is None:
            returned_val = None
            ex_caught = False
            try:
                returned_val = get_bin_path(arg, opt_dirs=opt_dirs, required=required)
            except ValueError:
                ex_caught = True

            assert ex_caught

        else:
            assert expected_val == get_bin_path(arg, opt_dirs=opt_dirs, required=required)

    assert_bin_path(None, 'invalid_name', opt_dirs=['/dev'])
    assert_bin_path(None, '/invalid/path', opt_dirs=['/dev'])

# Generated at 2022-06-11 01:23:05.781998
# Unit test for function get_bin_path
def test_get_bin_path():
    SUCCESSFUL_TESTS = (
        'get_bin_path returns the first instance of an executable in PATH',
        {'test_input': {'arg': 'python'}, 'expected_output': get_bin_path('python')},
        'get_bin_path returns the first instance of an executable in the optional search directories',
        {'test_input': {'arg': 'ansible', 'opt_dirs': ['~/ansible']}, 'expected_output': os.path.join(os.path.expanduser('~/ansible/ansible'))},
        'get_bin_path raises ValueError if executable is not found',
        {'test_input': {'arg': 'this_is_not_an_executable'}, 'raises': ValueError},
    )

# Generated at 2022-06-11 01:23:12.131353
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Tests for function get_bin_path
    """
    # None for executable arg
    try:
        get_bin_path(None)
        assert False, "ValueError should be raised"
    except ValueError:
        pass

    # Executable arg not in path
    try:
        get_bin_path("i_am_not_in_path")
        assert False, "ValueError should be raised"
    except ValueError:
        pass

    # Executable arg in path
    assert os.path.exists(get_bin_path("sh"))

# Generated at 2022-06-11 01:23:21.894686
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function
    '''
    from ansible.module_utils import basic
    import sys
    import shutil
    import tempfile


# Generated at 2022-06-11 01:23:29.400795
# Unit test for function get_bin_path
def test_get_bin_path():

    # test for existing binaries
    existing_bins = ['python', 'iptables', 'sudo']
    for bin in existing_bins:
        bin_path = get_bin_path(bin)
        assert os.path.exists(bin_path)
        assert not os.path.isdir(bin_path)
        assert is_executable(bin_path)
        assert bin_path.endswith(bin)

    # test for non-existing binary
    bin = 'this_binary_definitely_does_not_exist'
    try:
        get_bin_path(bin)
        assert False, "ValueError was not raised"
    except ValueError:
        assert True, "ValueError was raised"

# Generated at 2022-06-11 01:23:35.092874
# Unit test for function get_bin_path
def test_get_bin_path():
    # Unix-like os (Linux)
    path = get_bin_path('awk')
    assert path == '/usr/bin/awk'

    # Mac OS X
    path = get_bin_path('sed')
    assert path == '/usr/bin/sed'

    # Windows
    path = get_bin_path('dir')
    assert path == 'C:\\Windows\\system32\\dir.EXE'

    # Fail to find executable
    try:
        path = get_bin_path('invalid cmd')
    except:
        pass

# Generated at 2022-06-11 01:23:46.494026
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    import os

    # Create a temporary directory, place a dummy binary with permissions and delete it on exit
    tdir = tempfile.mkdtemp()
    h = os.path.join(tdir, 'hello')
    open(h, 'w').write('#!/bin/sh\necho hello')

# Generated at 2022-06-11 01:23:53.118374
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')
    assert get_bin_path('ls', opt_dirs=['/bin'])
    assert 'fping' == os.path.basename(get_bin_path('fping', opt_dirs=['/sbin']))

    try:
        get_bin_path('nonexistent')
        assert False, "Should have failed"
    except ValueError as e:
        pass

# Generated at 2022-06-11 01:23:54.874976
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for system calls
    try:
        get_bin_path('cp')
        get_bin_path('no_such_executable')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 01:24:00.909657
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat
    try:
        bin_path = tempfile.mkdtemp()
        exe_path = os.path.join(bin_path, 'exe')
        with open(exe_path, 'w') as f:
            f.write('#!/bin/sh\nexit 0')
        os.chmod(exe_path, stat.S_IRWXU)
        assert get_bin_path('exe', opt_dirs=[bin_path]) == exe_path
    finally:
        shutil.rmtree(bin_path)

# Generated at 2022-06-11 01:24:08.240625
# Unit test for function get_bin_path
def test_get_bin_path():
    valid_executable = '/usr/bin/python'
    invalid_executable = 'ls'

    assert get_bin_path('python') == valid_executable
    assert get_bin_path(valid_executable) == valid_executable
    assert get_bin_path(invalid_executable) is None

    try:
        get_bin_path('python', required=False)
    except ValueError:
        raise AssertionError('Should not raise an error if required=False')

    try:
        get_bin_path(invalid_executable)
    except ValueError:
        pass
    else:
        raise AssertionError('Should raise an error if required=True')

# Generated at 2022-06-11 01:24:19.697135
# Unit test for function get_bin_path
def test_get_bin_path():
    # First create a couple of files to use
    import tempfile
    fd, fn = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write("This is the test file")
    f.close()

    fd, fn2 = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write("This is the test file")
    f.close()

    fd, fn3 = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write("This is the test file")
    f.close()
    os.chmod(fn3, 0)

    fd, fn4 = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f

# Generated at 2022-06-11 01:24:25.260947
# Unit test for function get_bin_path
def test_get_bin_path():
    # Arrange
    arg = 'python'
    opt_dirs = None
    # Act
    try:
        bin_path = get_bin_path(arg, opt_dirs)
    # Assert
    except ValueError as e:
        assert False, "Failed to find required executable '%s' in paths: %s" %(arg, os.pathsep.join(opt_dirs))

# Generated at 2022-06-11 01:24:40.654674
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import random
    import string

    random_file_name = ''.join(random.choice(string.ascii_lowercase) for _ in range(8))
    try:
        assert False, 'unexpected'
    except AssertionError as e:
        assert 'ValueError' in repr(e)

    assert get_bin_path('python') == get_bin_path('python')
    assert get_bin_path('python', '/usr/bin') == get_bin_path('python', '/usr/bin')
    assert get_bin_path('python', ['/usr/bin']) == get_bin_path('python', ['/usr/bin'])

# Generated at 2022-06-11 01:24:47.860828
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/bin/ls')
    except Exception as e:
        assert False, 'Failed to find /bin/ls with error %s' % str(e)

    try:
        get_bin_path('/nonexistent-path/bin/nonexistent-exec')
    except Exception as e:
        assert True
    else:
        assert False, 'Unexpected success when finding /nonexistent-path/bin/nonexistent-exec'

# Generated at 2022-06-11 01:24:51.678291
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert bin_path is not None
    assert os.path.exists(bin_path)
    assert is_executable(bin_path)
    assert get_bin_path('nonexistentexe') is None

# Generated at 2022-06-11 01:25:02.726372
# Unit test for function get_bin_path
def test_get_bin_path():
    # directory that does not exist
    path = None
    try:
        path = get_bin_path('tcpdump')
    except ValueError:
        assert True
    else:
        assert False, "get_bin_path('tcpdump') raised no exception"

    # directory that does exist
    path = None
    try:
        path = get_bin_path('tcpdump', ['/usr/bin'])
    except ValueError:
        assert False, "get_bin_path('tcpdump', ['/usr/bin']) raised an exception"
    else:
        assert '/usr/bin/tcpdump' == path, "get_bin_path('tcpdump', ['/usr/bin']) returned wrong path"

    # directory that exists in the PATH
    path = None

# Generated at 2022-06-11 01:25:05.856396
# Unit test for function get_bin_path
def test_get_bin_path():
    my_bin = get_bin_path('my_bin_path')
    assert my_bin == '/usr/bin/my_bin_path'



# Generated at 2022-06-11 01:25:07.943666
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('bash', ['/usr/local/bin'])
    assert os.path.exists(bin_path)

# Generated at 2022-06-11 01:25:09.834093
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')
    assert get_bin_path('ls') != get_bin_path('ls', opt_dirs=['/bin'])

# Generated at 2022-06-11 01:25:19.865722
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # create temporary executable
    fpath = os.path.join(tempfile.mkdtemp(), "bin_path")
    open(fpath, 'w').close()
    os.chmod(fpath, 0o755)
    assert os.access(fpath, os.X_OK)

    assert fpath == get_bin_path("bin_path")

    # check that valid executable can be found by get_bin_path
    assert fpath == get_bin_path("bin_path", opt_dirs=[tempfile.mkdtemp()])

    # check that ValueError exception is raised in case when executable doesn't exist
    try:
        get_bin_path("bin_path123", opt_dirs=[tempfile.mkdtemp()])
    except ValueError:
        pass

# Generated at 2022-06-11 01:25:30.473528
# Unit test for function get_bin_path
def test_get_bin_path():
    # If a file path is given, get_bin_path just returns the input.
    assert get_bin_path('/usr/bin/env') == '/usr/bin/env'

    # If a file path is given, get_bin_path just returns the input.
    # On Windows, the backslashes are normalized.
    assert get_bin_path('C:/Python27/python.exe') == 'C:/Python27/python.exe'

    # If a file path contains a directory that's not in PATH,
    # get_bin_path will complain.
    try:
        get_bin_path('/usr/bin/coverage')
        assert False, 'Absolute path with non-existent directory should have thrown an exception'
    except ValueError:
        pass

    # If a binary is specified that's not in PATH, get_bin_

# Generated at 2022-06-11 01:25:39.524076
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/bin/sh' == get_bin_path('sh')
    assert '/bin/sh' == get_bin_path('sh', [])
    assert '/sbin/init' == get_bin_path('init', [], required=False)
    assert '/sbin/init' == get_bin_path('init', [], required=True)
    try:
        get_bin_path('not_a_real_binary', required=True)
    except ValueError as e:
        assert 'Failed to find required executable "not_a_real_binary"' in '%s' % e
        pass

# Generated at 2022-06-11 01:25:45.403260
# Unit test for function get_bin_path
def test_get_bin_path():
    # Act
    result = get_bin_path('/bin/python')

    # Assert
    assert result == '/bin/python'

# Generated at 2022-06-11 01:25:55.950212
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    import shutil
    import tempfile
    import os

    arg = 'test_executable'


# Generated at 2022-06-11 01:26:06.446136
# Unit test for function get_bin_path
def test_get_bin_path():
    # Unit test for function get_bin_path

    # When executable is not found in any paths, an exception should be raised
    exception_raised = False
    try:
        get_bin_path('no_command_like_this12345')
    except ValueError:
        exception_raised = True
    assert exception_raised

    # When executable is found, full path should be returned
    try:
        expected_path = get_bin_path('which')
    except ValueError:
        assert False, 'which command does not exist in any path'
    assert expected_path == '/usr/bin/which'

    # When executable is not found in optional paths, an exception should be raised
    exception_raised = False
    try:
        get_bin_path('which', ['/usr/sbin'])
    except ValueError:
        exception_raised

# Generated at 2022-06-11 01:26:10.438322
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ['PATH'] = os.pathsep.join(['/bin', '/usr/bin'])
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('no_such_file') == '/bin/sh'

# Generated at 2022-06-11 01:26:19.940337
# Unit test for function get_bin_path
def test_get_bin_path():

    import tempfile

    def create_executable(path):
        f = open(path, "w")
        f.write("#!/bin/sh\n")
        f.write("echo 'TEST OK'\n")
        os.chmod(path, 0o755)
        f.close()

    def create_non_executable(path):
        f = open(path, "w")
        f.write("#!/bin/sh\n")
        f.write("echo 'ERROR'\n")
        os.chmod(path, 0o644)
        f.close()

    workdir = tempfile.mkdtemp()

# Generated at 2022-06-11 01:26:26.768228
# Unit test for function get_bin_path
def test_get_bin_path():
    import platform
    import tempfile
    import shutil

    def make_executable(path):
        open(path, 'w').close()
        os.chmod(path, 0o755)

    # On Windows, PATHEXT is a list of file extensions used to search PATH
    # when the specified name does not have an extension.  On other platforms,
    # there is no need to search PATH if the specified name has no extension
    # (just append an empty string to the PATHEXT list).
    if platform.system() == 'Windows':
        pathext = os.environ.get('PATHEXT', '').lower().split(os.pathsep)
    else:
        pathext = ['']

    # We will create an executable file in this temporary directory,
    # then place various combinations of '.EXE' and '.exe' in the

# Generated at 2022-06-11 01:26:31.338498
# Unit test for function get_bin_path
def test_get_bin_path():
    # Invalid path
    try:
        get_bin_path('/invalid-directory/invalid-filename')
        assert False
    except ValueError:
        pass

    # Create simple test script
    fd, fp = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('#!/bin/sh\necho "Hello World!"')
    f.close()
    # Fix mode
    os.chmod(fp, 0o755)

    # Test

# Generated at 2022-06-11 01:26:36.742344
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/bin/ls'

    try:
        assert get_bin_path('does_not_exist') == '/bin/ls'
    except ValueError:
        pass

    try:
        assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/bin/ls'
    except ValueError:
        pass

# Generated at 2022-06-11 01:26:47.556145
# Unit test for function get_bin_path
def test_get_bin_path():
    # ensure get_bin_path returns an expected path for some common programs
    expected_bin_paths = {
        'openssl': '/usr/bin/openssl',
        'facter': '/opt/puppetlabs/puppet/bin/facter',
        'puppet': '/opt/puppetlabs/puppet/bin/puppet',
    }

    for (p, e) in expected_bin_paths.items():
        assert get_bin_path(p) == e

    # ensure get_bin_path raises an exception if the requested program is not found
    try:
        get_bin_path('not-a-real-program')
    except ValueError as e:
        assert 'not-a-real-program' in str(e)

# Generated at 2022-06-11 01:26:55.935534
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    import platform

    def make_test_executable(path):
        with open(path, 'w') as f:
            if platform.system().lower() == 'windows':
                f.write('@echo off\nexit /b 0')
            else:
                f.write('#!/bin/sh\nexit 0')
        os.chmod(path, 0o755)

    temp_dir = tempfile.mkdtemp()
    try:
        test_exec = 'test_exec'
        path = os.path.join(temp_dir, test_exec)
        make_test_executable(path)
        assert get_bin_path(test_exec) == path
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-11 01:27:05.485985
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('doesnotexist') == '/sbin/doesnotexist'
    try:
        get_bin_path('doesnotexist', required=True)
    except:
        pass

if __name__ == "__main__":
    test_get_bin_path()
    print("success")

# Generated at 2022-06-11 01:27:16.548325
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('python')
    assert(bin_path == '/usr/bin/python')

    bin_path = get_bin_path(os.path.basename('/usr/bin/python'))
    assert(bin_path == '/usr/bin/python')

    bin_path = get_bin_path(os.path.basename('/usr/bin/python'), ['/usr/bin'])
    assert(bin_path == '/usr/bin/python')

    bin_path = get_bin_path(os.path.basename('/usr/bin/python'), ['/usr/share'])
    assert(bin_path == '/usr/bin/python')


# Generated at 2022-06-11 01:27:25.112770
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('cat', ['/usr/bin']) == '/usr/bin/cat'
    assert get_bin_path('cat', ['/usr/bin', '/bin']) == '/usr/bin/cat'
    assert get_bin_path('cat', ['/usr/bin', '/bin']) == '/usr/bin/cat'
    assert get_bin_path('cat', ['/usr/bin', '/bin', '/bin']) == '/usr/bin/cat'
    assert get_bin_path('cat', ['/usr/bin', '/bin', '/bin', '']) == '/usr/bin/cat'
    assert get_bin_path('cat', ['/usr/bin', '/bin', '/bin', None]) == '/usr/bin/cat'


# Generated at 2022-06-11 01:27:34.461197
# Unit test for function get_bin_path
def test_get_bin_path():
    # The test get_bin_path should be run in an environment where PATH can include /sbin.
    # Hence the /usr in the paths so that /sbin is expected to be found.
    res = get_bin_path('sh', ['/usr/sbin', '/usr/local/sbin'])
    assert os.path.exists(res)
    assert is_executable(res)
    res = get_bin_path('sh', ['/usr/sbin', '/usr/local/sbin'])
    assert os.path.exists(res)
    assert is_executable(res)
    try:
        res = get_bin_path('_file_that_does_not_exist')
    except ValueError:
        pass
    except Exception as err:
        assert False, 'Unexpected Exception raised: %s'

# Generated at 2022-06-11 01:27:37.848967
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert get_bin_path('/bin/less') is not None
        assert get_bin_path('less') is not None
        assert get_bin_path('XXXX') is None
    except ValueError:
        assert True
    except:
        assert False

# Generated at 2022-06-11 01:27:44.100571
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.compat.tests import unittest
    class TestGetBinPath(unittest.TestCase):
        def test_get_bin_path_found(self):
            # get_bin_path() should return a path that exists
            path = get_bin_path('python')
            self.assertTrue(os.path.exists(path))

        def test_get_bin_path_notfound(self):
            # get_bin_path() should raise an error if the path cannot be found
            with self.assertRaises(ValueError):
                get_bin_path('not-a-real-program')

    unittest.main()

# Generated at 2022-06-11 01:27:52.838285
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('grep') == '/bin/grep'

    # We do not have /usr/libexec/ directory on travis
    if os.path.isdir("/usr/libexec"):
        assert get_bin_path('openshift-sdn', ['/usr/libexec']) == '/usr/libexec/openshift-sdn'

    try:
        get_bin_path('ipmitool')
        assert False
    except ValueError:
        assert True

    try:
        get_bin_path('ipmitool', ['/tmp'])
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-11 01:28:04.342912
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('/bin/sleep')
    get_bin_path('sleep')
    get_bin_path('/bin/sleep', opt_dirs=['/bin'])
    get_bin_path('sleep', opt_dirs=['/bin'])
    get_bin_path('sleep', opt_dirs=['/usr/bin', '/bin', '/usr/local/bin'])

    try:
        get_bin_path('/bin/sleep', opt_dirs=[])
    except ValueError:
        pass
    else:
        assert False

    try:
        get_bin_path('/some/invalid/path/sleep')
    except ValueError:
        pass
    else:
        assert False

    # should not raise exception due to the optional argument 'required'

# Generated at 2022-06-11 01:28:13.952693
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/usr/bin/python') == '/usr/bin/python'
    assert get_bin_path('python') == '/usr/bin/python'

    # Test opt_dirs
    assert get_bin_path('/usr/bin/python', opt_dirs=['/']) == '/usr/bin/python'
    try:
        get_bin_path('fake_executable', opt_dirs=['/'])
    except ValueError as err:
        assert "Failed to find required executable" in str(err)

    # Test required: Deprecated in 2.10. Remove in 2.14

# Generated at 2022-06-11 01:28:18.568468
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        mytest = get_bin_path('testme')
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError from get_bin_path()"
    mytest = get_bin_path('sh')
    assert mytest == '/bin/sh', "Failed to find /bin/sh in path"

# Generated at 2022-06-11 01:28:33.189802
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test missing executable
    try:
        get_bin_path('missing')
        assert False, 'Expected ValueError'
    except ValueError:
        pass

    # Test existing executable in /bin
    path = get_bin_path('ls')
    assert os.path.exists(path)
    assert is_executable(path)

    # Test existing executable in /sbin
    path = get_bin_path('iptables')
    assert os.path.exists(path)
    assert is_executable(path)

    # Test existing executable in /usr/sbin
    path = get_bin_path('systemctl')
    assert os.path.exists(path)
    assert is_executable(path)

    # Test existing executable in /usr/local/sbin

# Generated at 2022-06-11 01:28:44.379183
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp()
    bindir = os.path.join(tmp_dir, 'bin')

    # create a dummy binary
    os.mkdir(bindir)
    open(os.path.join(bindir, 'foo'), 'w').close()

    # test whether we find the newly created foo binary
    foo_path = get_bin_path('foo', opt_dirs=[bindir])
    assert foo_path == os.path.join(bindir, 'foo')

    # test whether we find the newly created foo binary with absolute path
    foo_path = get_bin_path(os.path.join(bindir, 'foo'), opt_dirs=[])
    assert foo_path == os.path.join(bindir, 'foo')

    # test

# Generated at 2022-06-11 01:28:53.237736
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # First test if cat exists at all (it should)
        get_bin_path('cat')
        # Then test if true exists, should pass
        get_bin_path('true')
        # Then test if false exists, should pass
        get_bin_path('false')
        # Then test if we can find a script in a specific folder, should pass
        get_bin_path('script.py', opt_dirs=['/some/path'])
        # Will fail to find this script
        get_bin_path('script.py', opt_dirs=['/some/other/path'])
    except Exception as e:
        assert False, 'Failed to find existing executable(s). %s' % e

# Generated at 2022-06-11 01:29:02.304808
# Unit test for function get_bin_path
def test_get_bin_path():
    test_path = get_bin_path('sh')
    assert test_path == '/bin/sh'
    test_path = get_bin_path('sh', opt_dirs=['/usr/bin', '/bin'])
    assert test_path == '/bin/sh'
    bad_path = '/bin/foo_bar_baz_file_does_not_exist'
    try:
        test_path = get_bin_path('foo_bar_baz', opt_dirs=['/usr/bin', '/bin'])
    except ValueError:
        assert True, 'test_get_bin_path(): Failed to raise error for missing file'
    else:
        assert False, 'test_get_bin_path(): Passed on a missing file'

# Generated at 2022-06-11 01:29:03.476895
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-11 01:29:06.716392
# Unit test for function get_bin_path
def test_get_bin_path():
    # Verify that arg is not in PATH, if PATH doesn't exist
    os.environ['PATH'] = ''
    assert get_bin_path(arg='/bin/echo') == '/bin/echo'

