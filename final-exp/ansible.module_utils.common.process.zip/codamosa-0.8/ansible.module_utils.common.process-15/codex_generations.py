

# Generated at 2022-06-11 01:19:20.695396
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test some normal cases
    assert get_bin_path('/bin/echo') == '/bin/echo'
    assert get_bin_path('echo', required=False) == '/bin/echo'
    assert get_bin_path('echo', required=True) == '/bin/echo'
    assert get_bin_path('echo', opt_dirs=['/']) == '/bin/echo'
    assert get_bin_path('echo', opt_dirs=['']) == '/bin/echo'
    assert get_bin_path('/bin/echo', opt_dirs=['/']) == '/bin/echo'
    assert get_bin_path('/bin/echo', opt_dirs=['']) == '/bin/echo'

    # Test failure via bad arg

# Generated at 2022-06-11 01:19:25.989132
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        os.chmod('/bin/false', 0o777)
    except OSError:
        pass
    try:
        os.chmod('/bin/true', 0o777)
    except OSError:
        pass
    path = get_bin_path('false')
    assert '/bin/false' == path
    path = get_bin_path('true')
    assert '/bin/true' == path

# Generated at 2022-06-11 01:19:34.542602
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.process import get_bin_path as test_get_bin_path

    assert get_bin_path('/bin/sh') == to_text('/bin/sh')  # absolute
    assert test_get_bin_path('sh') == to_text('/bin/sh')  # relative
    assert get_bin_path('sh', required=True) == to_text('/bin/sh')  # optional arg

    # Not found
    from ansible.module_utils.common.exceptions import AnsibleError

# Generated at 2022-06-11 01:19:42.002485
# Unit test for function get_bin_path
def test_get_bin_path():
    # check simple case
    assert get_bin_path('date') == '/bin/date'

    # check simple alternative case
    try:
        get_bin_path('date', ['/usr/bin'])
    except ValueError:
        assert False, "date was found in /bin but not in /usr/bin"

    # check alternative case
    assert get_bin_path('date', ['/usr/bin', '/bin']) == '/bin/date'

    # check case which raises exception
    try:
        get_bin_path('date', ['/usr/bin', '/usr/sbin'])
    except ValueError:
        assert True

    # check case which raises exception
    try:
        get_bin_path('random_non_existent_command')
    except ValueError:
        assert True

# Generated at 2022-06-11 01:19:43.387870
# Unit test for function get_bin_path
def test_get_bin_path():
    pybin = get_bin_path('python')
    assert pybin != None



# Generated at 2022-06-11 01:19:56.012842
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('echo', opt_dirs=['/usr/bin/local']) == '/usr/bin/local/echo'
    assert get_bin_path('echo', opt_dirs=['/usr/bin/local'], required=False) == '/usr/bin/local/echo'
    assert get_bin_path('echo', opt_dirs=['/usr/bin/local']) == '/usr/bin/local/echo'
    assert get_bin_path('echo', opt_dirs=['/usr/bin/local']) == '/usr/bin/local/echo'
    assert get_bin_path('echo', opt_dirs=['/usr/bin/local']) == '/usr/bin/local/echo'
    assert get

# Generated at 2022-06-11 01:20:02.081177
# Unit test for function get_bin_path
def test_get_bin_path():
    # 1. Valid path in PATH
    assert get_bin_path("sh") == "/bin/sh"

    # 2. Extra directory in path
    assert get_bin_path("sh", opt_dirs=["/bin/"]) == "/bin/sh"

    # 3. Missing executable
    try:
        get_bin_path("some-bad-executable")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-11 01:20:11.829777
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path(None)
        raise AssertionError('get_bin_path() did not raise exception when arg is None')
    except ValueError as e:
        assert 'arg must be a string' in str(e)

    for arg in ['', '']:
        try:
            get_bin_path(arg)
            raise AssertionError('get_bin_path() did not raise exception when arg is invalid')
        except ValueError as e:
            assert 'arg must be a string' in str(e)


# Generated at 2022-06-11 01:20:22.108010
# Unit test for function get_bin_path
def test_get_bin_path():
    # Given an executable existing in PATH
    paths = [x for x in os.environ['PATH'].split(':') if x]
    for path in paths:
        for file in os.listdir(path):
            if not os.path.isfile(os.path.join(path, file)):
                continue
            if os.access(os.path.join(path, file), os.X_OK):
                # When I call get_bin_path with the name of that executable
                bin_path = get_bin_path(file)
                # Then that executable should be returned as a full path
                assert os.path.exists(bin_path)
                assert os.path.isfile(bin_path)
                assert bin_path == os.path.join(path, file)

    # Given an executable existing in PATH but not

# Generated at 2022-06-11 01:20:33.438820
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1 - Success case
    get_bin_path('sh')

    # Test 2 - Failure case where the executable is not available
    try:
        get_bin_path('foobarbazmoohaha')
    except ValueError as e:
        assert str(e).startswith('Failed to find required executable')
    else:
        fail('Expected ValueError')

    # Test 3 - Failure case where the executable is available but is not executable
    touch_path = get_bin_path('touch')
    os.chmod(touch_path, 0o0640)
    try:
        get_bin_path('touch')
    except ValueError as e:
        assert str(e).startswith('Failed to find required executable')
    else:
        fail('Expected ValueError')
    finally:
        os.ch

# Generated at 2022-06-11 01:20:45.530385
# Unit test for function get_bin_path
def test_get_bin_path():
    # get_bin_path should accept a full path with no errors
    assert get_bin_path('/bin/echo') == '/bin/echo'

    # get_bin_path should return the path to a command in PATH
    assert get_bin_path('echo') == '/bin/echo'

    # get_bin_path should accept additional directories
    assert get_bin_path('echo', ['/bin']) == '/bin/echo'

    # get_bin_path should search /sbin paths
    assert get_bin_path('mkfs') == '/sbin/mkfs'

    # get_bin_path should raise a ValueError if no executable is found
    try:
        get_bin_path('not_a_valid_command')
        assert False
    except ValueError:
        assert True

    # get_bin_path should raise

# Generated at 2022-06-11 01:20:51.846097
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    tmpdir = tempfile.mkdtemp()
    try:
        test_file = os.path.join(tmpdir, 'test_file')
        open(test_file, 'w').close()
        os.chmod(test_file, 0o755)
        assert(get_bin_path('test_file', opt_dirs=[tmpdir]) == test_file)
    finally:
        os.unlink(test_file)
        os.rmdir(tmpdir)

# Generated at 2022-06-11 01:20:59.874674
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('less')
    assert os.path.exists(bin_path)

    try:
        get_bin_path('nonexistent_executable')
    except ValueError as e:
        pass
    else:
        assert False, 'Expected ValueError'

    try:
        get_bin_path('nonexistent_executable', opt_dirs=['/usr/bin'])
    except ValueError as e:
        pass
    else:
        assert False, 'Expected ValueError'

# Generated at 2022-06-11 01:21:09.540938
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    with tempfile.NamedTemporaryFile() as tmp:
        assert tmp.name == get_bin_path(tmp.name)

    assert '/bin/sh' == get_bin_path('sh')
    # get_bin_path() should ignore the dir '/does-not-exist'
    assert '/bin/sh' == get_bin_path('sh', opt_dirs=['/does-not-exist'])

    # get_bin_path() should work with absolute paths
    with tempfile.NamedTemporaryFile() as tmp:
        assert tmp.name == get_bin_path('/bin/sh', opt_dirs=[tmp.name])

    import errno

# Generated at 2022-06-11 01:21:20.008892
# Unit test for function get_bin_path

# Generated at 2022-06-11 01:21:24.055470
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('true') == '/bin/true'
    assert get_bin_path('false') == '/bin/false'
    try:
        get_bin_path('does-not-exist')
        assert False, 'test should throw exception'
    except ValueError:
        pass

# Generated at 2022-06-11 01:21:30.003761
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.get_bin_path import get_bin_path
    from ansible_collections.community.general.tests.unit.compat import unittest
    import sys

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, msg):
            raise Exception(msg)

    class TestGetBinPath(unittest.TestCase):
        def setUp(self):
            self.module = FakeModule()

        def test_get_bin_path(self):
            python_exec = sys.executable
            bin_path = get_bin_path(python_exec)
            self.assertEqual(bin_path, python_exec)


# Generated at 2022-06-11 01:21:31.538595
# Unit test for function get_bin_path
def test_get_bin_path():
    assert is_executable(get_bin_path('sh'))

# Generated at 2022-06-11 01:21:36.137047
# Unit test for function get_bin_path
def test_get_bin_path():

    binary = 'bash'

    # Check that an exception is raised on a missing binary
    try:
        get_bin_path('nonexistentbinary')
        assert False
    except ValueError:
        assert True

    # Check the return value of a valid binary
    bin_path = get_bin_path(binary)
    assert bin_path == '/bin/bash'

# Generated at 2022-06-11 01:21:42.018731
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('date') == '/bin/date'
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('grep') == '/bin/grep'
    assert get_bin_path('/bin/dirname') == '/bin/dirname'
    assert get_bin_path('/bin/dirname', ['/usr/bin']) == '/bin/dirname'

# Generated at 2022-06-11 01:21:50.329458
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('sh')
    assert path == '/bin/sh'
    path = get_bin_path('sh', opt_dirs=['/usr/bin'])
    assert path == '/usr/bin/sh'
    path = get_bin_path('sh', opt_dirs=['/usr/bin', '/usr/local/bin'])
    assert path == '/usr/bin/sh'

# Generated at 2022-06-11 01:21:57.015941
# Unit test for function get_bin_path
def test_get_bin_path():
    # Create a temporary directory
    tempdir = tempfile.mkdtemp()
    # Create a test file in the temporary directory
    test_file = tempdir + '/test_file'
    with open(test_file, 'w') as f:
        f.write('this is a test file')
    # Make the test file executable
    os.chmod(test_file, 0o755)

    # Check that get_bin_path finds an executable in a folder added to the PATH
    assert test_file == get_bin_path('test_file', opt_dirs=[tempdir])
    # Check that get_bin_path raises an error if the executable is not found
    try:
        get_bin_path('test_file')
        assert False, "Expected exception not raised"
    except ValueError:
        pass
    # Clean up

# Generated at 2022-06-11 01:22:08.228579
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for get_bin_path
    '''
    import sys

    # Test1: Check if get_bin_path returns full path of python
    python_path = get_bin_path('python', required=True)
    assert os.path.exists(python_path) and is_executable(python_path)
    assert os.path.realpath(python_path) == sys.executable

    # Test2: path of non-existent binary
    try:
        get_bin_path('foo', required=True)
        assert False
    except ValueError:
        assert True

    # Test3: path of existing, non-executable file
    try:
        get_bin_path('/etc/hosts', required=True)
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-11 01:22:16.382546
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        path = get_bin_path('doesnotexist')
        raise AssertionError('get_bin_path should fail when binary does not exist')
    except ValueError:
        pass
    try:
        path = get_bin_path('ls')
        if not path == '/bin/ls':
            raise AssertionError('get_bin_path failed to find ls at /bin/ls')
    except ValueError:
        raise AssertionError('get_bin_path failed to find ls at /bin/ls')


# Generated at 2022-06-11 01:22:17.988979
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-11 01:22:28.103044
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    def touch(path):
        with open(path, 'a'):
            os.utime(path, None)

    test_dir = tempfile.mkdtemp()
    test_paths = [test_dir]
    touch(os.path.join(test_dir, 'foo'))
    assert get_bin_path('foo', required=False) is None
    assert get_bin_path('foo', opt_dirs=test_paths) == os.path.join(test_dir, 'foo')
    with open(os.path.join(test_dir, 'foo'), 'w') as f:
        f.write('#!/bin/bash')
    assert get_bin_path('foo', opt_dirs=test_paths) == os.path.join(test_dir, 'foo')

# Generated at 2022-06-11 01:22:37.524697
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    import tempfile
    import shutil
    import os
    import stat

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create and make executable the following files:
    #   executable_one
    #   executable_two
    #   executable_three
    #   executable_four (not executable)

    # Create file executable_one
    fh, executable_one = tempfile.mkstemp(dir=tmpdir)
    os.close(fh)

    # Create file executable_two
    fh, executable_two = tempfile.mkstemp(dir=tmpdir)
    os.close(fh)

    # Create file executable_three

# Generated at 2022-06-11 01:22:42.704910
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', ['/usr/local/bin', '/usr/bin']) == '/bin/ls'
    try:
        get_bin_path('command_not_found')
        assert False, 'ValueError not raised'
    except ValueError:
        assert True

# Generated at 2022-06-11 01:22:46.963392
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        print("get_bin_path(python) = " + get_bin_path("python"))
    except ValueError as e:
        print("Expected exception raised: " + str(e))

# Execute test
if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-11 01:22:57.535610
# Unit test for function get_bin_path
def test_get_bin_path():
    assert os.path.join(get_bin_path('ls')) == '/bin/ls'
    assert os.path.join(get_bin_path('chmod')) == '/bin/chmod'
    assert os.path.join(get_bin_path('fake_binary')) == '/bin/fake_binary'
    assert os.path.join(get_bin_path('ls', required=False)) == '/bin/ls'
    assert os.path.join(get_bin_path('chmod', required=False)) == '/bin/chmod'
    assert os.path.join(get_bin_path('fake_binary', required=False)) == '/bin/fake_binary'

# Generated at 2022-06-11 01:23:10.129504
# Unit test for function get_bin_path
def test_get_bin_path():
    def check_bin(arg, opt_dirs):
        assert get_bin_path(arg, opt_dirs) is not None

    def check_failing_bin(arg, opt_dirs):
        try:
            get_bin_path(arg, opt_dirs)
        except ValueError:
            return
        assert False, 'get_bin_path should have failed.'

    check_bin('getent', [])
    check_bin('getent', ['/usr/bin'])
    check_bin('getent', ['/usr/bin', '/bin'])
    check_failing_bin('no-such-executable', ['/usr/bin/does-not-exists'])
    check_failing_bin('getent', ['/usr/bin/does-not-exists'])

# Generated at 2022-06-11 01:23:19.222579
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import mock_open
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import Mock

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught by the test case"""
        pass


# Generated at 2022-06-11 01:23:20.539184
# Unit test for function get_bin_path
def test_get_bin_path():
    assert "ps" == os.path.basename(get_bin_path("ps"))

# Generated at 2022-06-11 01:23:25.921186
# Unit test for function get_bin_path
def test_get_bin_path():
    dirs = []
    # test with a required existing executable
    foo = get_bin_path('foo', dirs, True)
    assert foo.endswith('foo')

    # test with a required non existing executable
    try:
        get_bin_path('bar', dirs, True)
        assert False, 'ValueError expected'
    except ValueError:
        pass

    # test with an optional non existing executable
    bar = get_bin_path('bar', dirs, False)
    assert bar is None

# Generated at 2022-06-11 01:23:34.361668
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    test_bin = os.path.join(tempfile.mkdtemp(), 'bin')
    os.mkdir(test_bin)
    bin_name = 'abc'
    test_bin_path = os.path.join(test_bin, bin_name)
    with open(test_bin_path, 'w') as f:
        f.write('#!/bin/bash\n')
    os.chmod(test_bin_path, 0o755)

    path = os.environ.get('PATH', '')
    orig_path = path

# Generated at 2022-06-11 01:23:44.740385
# Unit test for function get_bin_path
def test_get_bin_path():
    # Simple bin path
    assert get_bin_path('echo') == '/bin/echo'

    # Reject nonexistent path
    try:
        get_bin_path('fake_prog')
        assert False, "This should not succeed"
    except ValueError:
        pass

    # Reject directory
    try:
        get_bin_path('fake_prog', opt_dirs=['/sbin'])
        assert False, "This should not succeed"
    except ValueError:
        pass

    # Accept optional directories
    assert get_bin_path('ip', opt_dirs=['/sbin']) == '/sbin/ip'

    # Test expected behavior in older versions

# Generated at 2022-06-11 01:23:55.767351
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import stat
    import tempfile

    # Create some temporary directories with symlinks
    tmpdir_real = tempfile.mkdtemp()
    tmpdir_ln = tempfile.mkdtemp()
    tmpdir_ln2 = tempfile.mkdtemp()

    existing_file = os.path.join(tmpdir_real, 'existing_file')

# Generated at 2022-06-11 01:24:04.623460
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python')
    assert get_bin_path('python', required=True)
    assert get_bin_path('python', opt_dirs=['/usr/local/bin', '/usr/bin', '/bin'])
    assert get_bin_path('python', required=True, opt_dirs=['/usr/local/bin', '/usr/bin', '/bin'])

    try:
        get_bin_path('not_found')
        assert False, 'Should not return'
    except Exception:
        pass

    try:
        get_bin_path('not_found', required=True)
        assert False, 'Should not return'
    except Exception:
        pass


# Generated at 2022-06-11 01:24:12.278536
# Unit test for function get_bin_path
def test_get_bin_path():
    # A specific executable is expected to be found in the default path
    # Take note that PATH is not modified in order to limit the testing scope
    # to the get_bin_path function.
    os.environ['PATH'] = '/usr/bin:/usr/local/bin'
    bin_path = get_bin_path('ls')
    assert bin_path == '/usr/bin/ls'

    # A specific executable is expected to be found in the optional path
    bin_path = get_bin_path('git', opt_dirs=['/usr/local/bin', '/usr/bin'])
    assert bin_path == '/usr/local/bin/git'

    # An optional path is not supposed to be a directory

# Generated at 2022-06-11 01:24:17.775138
# Unit test for function get_bin_path
def test_get_bin_path():
    import os

    assert os.system('which ls > /dev/null') == 0
    ls_path = get_bin_path('ls')
    assert os.path.exists(ls_path)
    assert is_executable(ls_path)



# Generated at 2022-06-11 01:24:33.125547
# Unit test for function get_bin_path
def test_get_bin_path():
    test_bin = 'python'

    def test_bin_path(expected_path, opt_dirs):
        assert get_bin_path(test_bin, opt_dirs=opt_dirs) == expected_path

    expected_paths = [os.path.join(d, test_bin) for d in filter(os.path.exists, os.environ.get('PATH', '').split(os.pathsep))]

    if not expected_paths:
        expected_paths = [os.path.join(d, test_bin) for d in ['/usr/bin', '/bin']]

    assert get_bin_path(test_bin) == expected_paths[0]
    test_bin_path(expected_paths[0], opt_dirs=[])

# Generated at 2022-06-11 01:24:34.572704
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'

# Generated at 2022-06-11 01:24:45.249294
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Unit test for get_bin_path function
    """

    from ansible.module_utils.six import PY3
    from tempfile import mkdtemp

    # Disable 'no-member' pylint warning for mocked os module
    # pylint: disable=no-member

    sbin_paths = ["/sbin", "/usr/sbin", "/usr/local/sbin"]
    paths = ["/usr/bin"]

    # Create an empty temporary directory
    tmpdir = os.path.realpath(mkdtemp())
    os.rmdir(tmpdir)

    # Create a fake executable under tmpdir
    bin_name = 'fake_script'
    if PY3:
        bin_name += '3'

    # Create a file with the same name as the executable

# Generated at 2022-06-11 01:24:55.137294
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/bin/sh')
        assert False
    except ValueError:
        pass
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/usr/local/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/usr/local/bin'], required=True) == '/bin/sh'
    try:
        get_bin_path('sh', required=True)
        assert False
    except ValueError:
        pass
    try:
        get_bin_path('bogus', required=True)
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 01:25:06.807998
# Unit test for function get_bin_path
def test_get_bin_path():
    # Verify ValueError raised if binary not found in default PATH
    try:
        get_bin_path('not_a_binary')
    except ValueError as e:
        print(e)
    else:
        assert False

    assert os.path.exists(str(get_bin_path('ls')))
    assert os.path.exists(str(get_bin_path('ls', opt_dirs=['/bin', '/usr/bin'])))
    try:
        get_bin_path('ls', opt_dirs=['/var/log', '/bin', '/usr/bin'])
    except ValueError as e:
        print(e)
    else:
        assert False


# Unit test code

# Generated at 2022-06-11 01:25:14.989274
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes

    # Test case (executable, path, expected result)
    tests = [
        ('true', [], '/bin/true'),
        ('true', ['/usr/bin'], '/usr/bin/true'),
        # Call 'true' from a different directory to ensure it's not the one in local path
        ('/bin/true', ['/usr/bin'], '/bin/true'),
        ('false', ['/usr/bin', '/usr/local/bin'], '/usr/bin/false'),
        ('false', ['/usr/bin'], '/usr/bin/false'),
        # The following test will fail if no file named 'false' exists
        ('false', [], '/bin/false'),
    ]


# Generated at 2022-06-11 01:25:16.386742
# Unit test for function get_bin_path
def test_get_bin_path():

    assert get_bin_path('bash') == '/bin/bash'


# Generated at 2022-06-11 01:25:28.234601
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    # create directories for testing
    tmpdirs = []
    for x in range(0, 2):
        tmpdirs.append(tempfile.mkdtemp())
    # create shell script in each directory
    for d in tmpdirs:
        with open(d + '/the_script', 'w') as f:
            f.write('#!/bin/sh\n')
            f.write('echo "Hello, world!"')
        os.chmod(d + '/the_script', 0o777)
    # test that get_bin_path returns absolute path with trailing slash removed
    assert get_bin_path('the_script', opt_dirs=tmpdirs) == os.path.join(tmpdirs[0], 'the_script')
    # test that get_bin_path raises error if executable not found


# Generated at 2022-06-11 01:25:35.359535
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' check get_bin_path function '''
    from ansible.module_utils.common.file import get_bin_path

    try:
        get_bin_path('suchfile')
        assert False
    except Exception as e:
        assert isinstance(e, ValueError)

    # Define test for every OS

    bin_path = get_bin_path('echo')
    assert bin_path == '/bin/echo'  # or similar

# Generated at 2022-06-11 01:25:43.214833
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/bash') == '/bin/bash'
    assert get_bin_path('bash') == '/usr/bin/bash'
    import tempfile
    d = tempfile.mkdtemp()
    assert get_bin_path('bash', opt_dirs=[d]) == '/usr/bin/bash'
    assert get_bin_path('bash', opt_dirs=['/bin']) == '/bin/bash'
    assert get_bin_path('bash', opt_dirs=['/bin', d]) == '/bin/bash'
    import pytest
    with pytest.raises(ValueError):
        get_bin_path('nonexist')

# Generated at 2022-06-11 01:25:56.990401
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    # Test 1
    test_dir = tempfile.mkdtemp()
    test_name = 'test_file'
    test_path = os.path.join(test_dir, test_name)
    with open(test_path, 'w') as f:
        f.write('#!/usr/bin/python')
        f.close()
    os.chmod(test_path, 0o755)

    assert test_path == get_bin_path(test_name, required=False, opt_dirs=[test_dir])
    shutil.rmtree(test_dir)

    # Test 2
    assert get_bin_path('bash', required=False, opt_dirs=[]) == '/bin/bash'

# Generated at 2022-06-11 01:26:07.416958
# Unit test for function get_bin_path
def test_get_bin_path():

    import shutil
    from ansible.module_utils._text import to_bytes

    # Assume the unit test is running from the main source tree, so make
    # sure we can find the test executable by adding the source tree root
    # to PATH.
    os.environ['PATH'] = to_bytes(
        ':'.join([os.environ.get('PATH', ''), os.path.join(os.path.dirname(os.path.dirname(__file__)), '..', '..')])
    )


# Generated at 2022-06-11 01:26:08.862307
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-11 01:26:18.894029
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat')
    assert get_bin_path('/bin/cat')
    assert get_bin_path('/bin/cat') == get_bin_path('cat')
    assert get_bin_path('cat', opt_dirs=['/bin', '/sbin']) == get_bin_path('cat')
    assert get_bin_path('cat', opt_dirs=['/nopath']) == get_bin_path('cat')
    try:
        get_bin_path('cat', opt_dirs=['/nopath'], required=True)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError exception'


# Generated at 2022-06-11 01:26:21.205356
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    try:
        get_bin_path('notexists')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 01:26:27.542152
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/test']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/test1', '/test2']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/test1', None, '/test2']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/test1', '', '/test2']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/test1', '', '/test2', None]) == '/bin/sh'


# Generated at 2022-06-11 01:26:36.499133
# Unit test for function get_bin_path
def test_get_bin_path():
    path = None
    try:
        path = get_bin_path('python', ['/bin'])
    except ValueError:
        raise AssertionError("Failed to get the path of python executable")

    if not path.endswith('/python'):
        raise AssertionError("Got incorrect path of python executable")

    try:
        path = get_bin_path('python', ['/bin'], required=True)
    except:
        raise AssertionError("Failed to get the path of python executable")

    if not path.endswith('/python'):
        raise AssertionError("Got incorrect path of python executable")


# Generated at 2022-06-11 01:26:47.205392
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert os.path.exists(bin_path)
    assert is_executable(bin_path)

    try:
        get_bin_path('sh', ['/bin'])
    except Exception as e:
        assert False
    else:
        assert True

    try:
        get_bin_path('sh', ['/usr/bin'])
    except Exception as e:
        assert False
    else:
        assert True

    try:
        get_bin_path('sh', ['/bin:/usr/bin'])
    except Exception as e:
        assert False
    else:
        assert True

    try:
        get_bin_path('sh', ['/notexists'])
    except Exception as e:
        assert True
    else:
        assert False

# Generated at 2022-06-11 01:26:55.147471
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('bad_tool')
        assert False, 'Should have thrown an exception'
    except ValueError:
        pass

    import stat
    import tempfile
    (dummy_fd, fname) = tempfile.mkstemp()
    os.chmod(fname, stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)
    os.unlink(fname)

    assert get_bin_path(fname) == fname

    # Testopt_dirs
    assert get_bin_path(fname, opt_dirs=[os.path.dirname(fname)]) == fname

    os.unlink(fname)

# Generated at 2022-06-11 01:27:02.410316
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import win_path

    # Test on Windows platforms
    if win_path._windows_version() > 0:
        assert '/bin' not in get_bin_path('cmd.exe')

    # Test on POSIX platforms
    else:
        for p in os.environ.get('PATH', '').split(os.pathsep):
            assert p in get_bin_path('python')
        assert '/sbin' not in get_bin_path('python')  # should not include system paths

# Generated at 2022-06-11 01:27:08.034392
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python')
    assert get_bin_path('foobar') == ValueError

# Generated at 2022-06-11 01:27:15.255556
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('cat', ['/bin1', '/bin2'], False)
    assert bin_path in ['/bin1/cat', '/bin2/cat']
    bin_path = get_bin_path('/bin/cat', False)
    assert bin_path == '/bin/cat'
    try:
        bin_path = get_bin_path('not_a_bin', False)
    except ValueError as e:
        assert 'not_a_bin' in str(e)

# Generated at 2022-06-11 01:27:24.196010
# Unit test for function get_bin_path
def test_get_bin_path():

    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/ls', []) == '/bin/ls'
    assert get_bin_path('/bin/ls', ['/tmp']) == '/bin/ls'
    assert get_bin_path('/bin/ls', ['/tmp']) == '/bin/ls'

    # Not found because it is a directory
    try:
        get_bin_path('/bin', [])
        assert False
    except ValueError as e:
        assert e.args[0] == 'Failed to find required executable "/bin" in paths: /bin:/usr/bin'

    # Found in opt_dirs

# Generated at 2022-06-11 01:27:31.037849
# Unit test for function get_bin_path
def test_get_bin_path():
    test_paths = ["/bin", "/usr/bin", "/usr/local/bin"]
    test_exe = "sh"
    bin_path = get_bin_path(test_exe, opt_dirs=test_paths)
    assert bin_path
    assert os.path.exists(bin_path)
    assert os.path.isfile(bin_path)
    assert os.access(bin_path, os.X_OK)
    assert os.path.basename(bin_path) == test_exe

# Generated at 2022-06-11 01:27:40.097386
# Unit test for function get_bin_path
def test_get_bin_path():
    # Create a temp dir with test scripts
    import tempfile
    script_dir = tempfile.mkdtemp()
    script1 = u'test_executable_script'
    script2 = u'test_executable_script2'
    script1_path = u'%s/%s' % (script_dir, script1)
    script2_path = u'%s/%s' % (script_dir, script2)

    # Create executable scripts
    with open(script1_path, u'w') as f:
        f.write(u'#!/bin/sh\n')
    with open(script2_path, u'w') as f:
        f.write(u'#!/bin/sh\n')
    os.chmod(script1_path, 755)

# Generated at 2022-06-11 01:27:46.460506
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import subprocess
    import os

    print('Testing function get_bin_path')
    mk_test = '''#!/bin/sh
    echo "Hello World"
    '''
    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-11 01:27:57.332865
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os
    import sys

    # TODO: test with custom executable PATH
    # TODO: test on non-linux

    paths = []
    for path in os.environ.get('PATH', '').split(os.pathsep):
        if path not in paths:
            paths.append(path)


# Generated at 2022-06-11 01:27:59.059332
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-11 01:28:10.381612
# Unit test for function get_bin_path
def test_get_bin_path():
    cases = (
        # arg opt_dirs required
        # string or None -> executable or None
        (True, None, True),
        (False, None, False),
        (True, None, False),
        (False, ['/usr/bin'], False),
    )

    _tests = (
        'echo',
        '/bin/echo',
        'true',
        '/bin/true',
        'false',
        '/bin/false',
        'ls',
        '/bin/ls',
        'false',
        '/bin/false',
        'binfmt_misc',
        '/proc/sys/fs/binfmt_misc/status',
    )


# Generated at 2022-06-11 01:28:15.868130
# Unit test for function get_bin_path
def test_get_bin_path():

    # Find the executable
    found_path = get_bin_path('head')
    assert found_path.endswith('head')

    # Try to find a non existing executable
    try:
        get_bin_path('not_an_executable')
        assert False
    except ValueError:
        assert True

    # Test extra PATHs
    found_path = get_bin_path('head', ['/bin', '/usr/bin'])
    assert found_path.endswith('head')

    # Test sbin
    found_path = get_bin_path('halt')
    assert found_path.endswith('halt')

# Generated at 2022-06-11 01:28:30.890523
# Unit test for function get_bin_path
def test_get_bin_path():
    def mock_join(a, b):
        return os.path.join(a, b)

    def mock_listdir(path):
        if path == '/tmp':
            return ['/tmp/foo', '/tmp/bar']
        elif path == '/path1':
            return ['/path1/foo']
        elif path == '/path2':
            return ['/path2/bar']
        else:
            return []

    def mock_exists(path):
        if path == '/tmp/foo':
            return True
        elif path == '/path1/foo':
            return True
        elif path == '/path2/bar':
            return True
        else:
            return False

    def mock_isfile(path):
        if path == '/tmp/foo':
            return True

# Generated at 2022-06-11 01:28:34.729783
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert bin_path is not None
    assert os.path.exists(bin_path)
    assert not os.path.isdir(bin_path)
    assert is_executable(bin_path)
    print('It works')

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-11 01:28:41.388544
# Unit test for function get_bin_path
def test_get_bin_path():

    paths = os.environ['PATH'].split(os.pathsep)
    for path in paths:
        if os.path.exists(path):
            for command in os.listdir(path):
                if not command:
                    continue
                try:
                    bin_path = get_bin_path(command)
                    assert os.path.exists(bin_path)
                except ValueError:
                    pass

# Generated at 2022-06-11 01:28:49.756338
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no_such_file')
    except ValueError as e:
        assert 'no_such_file' in str(e)
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    try:
        get_bin_path('ls', opt_dirs=['/no/such/dir'])
    except ValueError as e:
        assert '/no/such/dir' in str(e)

# Generated at 2022-06-11 01:28:59.700742
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-11 01:29:00.802957
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('find') == '/usr/bin/find'

# Generated at 2022-06-11 01:29:10.298234
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Function get_bin_path() returns full path to existing executable, otherwise raises ValueError'''
    from sys import executable
    from tempfile import mkstemp
    from shutil import rmtree
    from os import chmod, mkdir, write, listdir, unlink

    # test for existing executable
    assert get_bin_path(executable) == executable

    # test for not existing executable
    try:
        get_bin_path('/not/existing/executable')
    except ValueError as e:
        assert 'Failed to find required executable "/not/existing/executable"' in str(e)
    else:
        assert False, 'Not existing executable should raise ValueError'

    # test for executable in additional directory
    fd, f = mkstemp(prefix='ansible-test-')