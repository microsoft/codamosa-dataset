

# Generated at 2022-06-11 01:19:09.611150
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Validate get_bin_path() function.
    '''
    import platform

    # Unit test function on "false" command
    cmd = get_bin_path('false')
    assert cmd.endswith('bin/false' if platform.system() == 'Darwin' else 'false'), 'get_bin_path() did not find false'

    # Unit test function on "true" command
    cmd = get_bin_path('true')
    assert cmd.endswith('bin/true' if platform.system() == 'Darwin' else 'true'), 'get_bin_path() did not find true'

# Generated at 2022-06-11 01:19:17.967880
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('true') == '/bin/true'
    assert get_bin_path('/bin/true') == '/bin/true'
    assert get_bin_path('true', opt_dirs=['/bin']) == '/bin/true'
    assert get_bin_path('true', opt_dirs=['/not/a/bin']) == '/bin/true'
    assert get_bin_path('true', opt_dirs=['/sbin']) == '/sbin/true'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/usr/sbin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/sbin', '/usr/bin']) == '/usr/bin/ls'
   

# Generated at 2022-06-11 01:19:21.757557
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('nonexistent')
        assert False
    except ValueError as e:
        assert "Failed to find required executable" in str(e)
    get_bin_path('python')
    get_bin_path('python', opt_dirs='.')

# Generated at 2022-06-11 01:19:23.385865
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path("bash")
    assert bin_path == '/bin/bash'

# Generated at 2022-06-11 01:19:31.452617
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # stubs
    old_path = os.environ['PATH']
    old_os_sep = os.pathsep

    # create a PATH without /sbin/ paths
    os.environ['PATH'] = ':'.join([p for p in os.environ['PATH'].split(':')
                                   if not p.startswith('/sbin')])

    # create fake paths
    paths = []
    for i in range(3):
        paths.append(tempfile.mkdtemp(prefix='ansible_unittests'))
    for i in range(2):
        paths.append(tempfile.mkdtemp(prefix='ansible_unittests'))

    # first add a bin_path to the PATH, before the /sbin paths
    bin_path = tempfile.mk

# Generated at 2022-06-11 01:19:40.089705
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test conditions:
    # - arg is not found, required=True
    # - arg is not found, required=False
    # - arg is found in /sbin, required=False
    # - arg is found in /usr/sbin, required=False
    # - arg is found and does not have executable bits, required=True
    # - arg is found and does not have executable bits, required=False
    import pytest

    required = False

    # Test case: arg does not exist in /usr/bin or /usr/sbin
    with pytest.raises(ValueError):
        get_bin_path('missing_file', required=required)
    # Test case: arg is found in /sbin and is executable
    get_bin_path('lsmod', opt_dirs=['/sbin'], required=required)
    #

# Generated at 2022-06-11 01:19:52.114265
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' test utility for get_bin_path '''

    def assert_equal(a, b, msg):
        assert a == b, '{expected} != {actual}: {msg}'.format(expected=a, actual=b, msg=msg)

    assert_equal(get_bin_path('ls'), '/bin/ls', 'ls in /bin/ should be found')
    assert_equal(get_bin_path('ls', ['/usr/bin/']), '/usr/bin/ls', 'ls in /usr/bin/ should be found')
    assert_equal(get_bin_path('ansible'), '/usr/bin/ansible', 'ansible in /usr/bin/ should be found')

# Generated at 2022-06-11 01:19:57.130503
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Return true if function get_bin_path works as expected
    '''
    assert get_bin_path('ssh')
    try:
        get_bin_path('this_program_is_not_installed')
        assert False, 'Program was not installed but get_bin_path did not raise'
    except ValueError:
        assert True

# Generated at 2022-06-11 01:20:05.457453
# Unit test for function get_bin_path
def test_get_bin_path():
    if 'SHELL' not in os.environ:
        os.environ['SHELL'] = '/bin/sh'
    ansible_path = get_bin_path('ansible')
    ansible_path = ansible_path + "\n"
    # Check if we get /bin/sh in PATH
    assert '/bin' in ansible_path
    # Check if we get /sbin in PATH (see 'mangle PATH to include /sbin dirs' above)
    assert '/sbin' in ansible_path



# Generated at 2022-06-11 01:20:13.517611
# Unit test for function get_bin_path
def test_get_bin_path():
    import __builtin__
    import tempfile
    import shutil
    import stat

    orig_exists = os.path.exists
    orig_isfile = os.path.isfile
    orig_access = os.access
    orig_path = os.environ.get('PATH')
    orig_isdir = os.path.isdir
    tempdir = tempfile.mkdtemp()

    def fake_exists(path):
        if path == tempdir:
            return True
        return orig_exists(path)

    def fake_isfile(path):
        if path == '/fake/bin/prog':
            return True
        return orig_isfile(path)

    def fake_access(path, mode):
        if path == '/fake/bin/prog':
            return True

# Generated at 2022-06-11 01:20:24.705462
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    # Run unit test on python 2.6 and 2.7
    if sys.version_info < (2, 7):
        import unittest
        import sys

        class GetBinPathTestCase(unittest.TestCase):

            def test_get_bin_path(self):
                self.assertTrue(get_bin_path('cat'))

            def test_get_bin_path_error(self):
                with self.assertRaises(ValueError):
                    get_bin_path('some_invalid_command')

        test_case = GetBinPathTestCase()
        results = unittest.TextTestRunner(stream=sys.stdout, verbosity=2).run(test_case)
        if results.errors or results.failures:
            sys.exit(1)

# Generated at 2022-06-11 01:20:26.069217
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-11 01:20:33.094798
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no.such.executable')
        raise AssertionError('expected exception')
    except ValueError as e:
        assert e.args[0] == 'Failed to find required executable "no.such.executable" in paths: /usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin:/usr/local/sbin'

    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-11 01:20:38.627675
# Unit test for function get_bin_path
def test_get_bin_path():
    # pylint: disable=import-error,redefined-outer-name,unused-variable
    import pytest
    from ansible.module_utils import basic

    def verify_arg(arg, msg, opt_dirs=None, required=True):
        try:
            basic.get_bin_path(arg, opt_dirs=opt_dirs, required=required)
        except ValueError:
            return True
        return False

    # get_bin_path() should fail without a specified required binary
    assert verify_arg(None, msg='required cannot be None', required=None)
    assert verify_arg(None, msg='required cannot be None', required=True)
    assert verify_arg(None, msg='required cannot be None', required=False)

    # get_bin_path() should fail for a non-existing binary


# Generated at 2022-06-11 01:20:44.377516
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no-way-this-exists')
        raise Exception('get_bin_path did not fail when it was supposed to')
    except ValueError as e:
        if 'Failed to find required executable' not in str(e):
            raise Exception('get_bin_path threw a different exception than expected: %s' % e)

    if get_bin_path('test-bin/test-bin-2') != os.path.abspath('test-bin/test-bin-2'):
        raise Exception('get_bin_path could not find test executable')

# Generated at 2022-06-11 01:20:48.951102
# Unit test for function get_bin_path
def test_get_bin_path():
    # We're just going to check to make sure it doesn't blow up with a couple
    # of different expected paths.  Trying to run which in a unit test
    # environment is bound to fail.
    get_bin_path('python')
    get_bin_path('python', ['/usr/bin', '/usr/sbin'])

# Generated at 2022-06-11 01:20:53.225277
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.sys_info import get_distribution
    dist = get_distribution()
    if dist.name.lower() == 'alpine':
        # Alpine does not include ping on the default path, handle it separately
        assert get_bin_path('ping') == '/bin/ping'
    else:
        assert get_bin_path('ping')  # should not raise



# Generated at 2022-06-11 01:21:01.360900
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check that get_bin_path works normally
    get_bin_path('pwd')

    # Check that get_bin_path fails with a bad argument
    try:
        get_bin_path('foo_bar_baz')
    except ValueError:
        pass
    else:
        assert False, 'get_bin_path failed to raise exception with bad argument'

    # Check that get_bin_path works with optional directories
    get_bin_path('pwd', ['/bin', '/usr/bin'])

# Generated at 2022-06-11 01:21:10.432513
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('cat', opt_dirs=['/usr/bin']) == '/bin/cat'
    assert get_bin_path('cat', opt_dirs=['/usr/bin', '/bin']) == '/bin/cat'
    assert get_bin_path('cat', opt_dirs=[]) == '/bin/cat'
    assert get_bin_path('systemd-detect-virt') == '/usr/bin/systemd-detect-virt'
    assert get_bin_path('systemd-detect-virt', opt_dirs=['/bin']) == '/usr/bin/systemd-detect-virt'

# Generated at 2022-06-11 01:21:20.974225
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import os
    from ansible.module_utils.common.file import is_executable

    # These tests are currently failing on Python 2.6
    if sys.version_info[0] == 2 and sys.version_info[1] < 7:
        return

    # The path is moved to this for test purposes.
    # The path is located in the OS, but an additional one
    # is being added for the tests.
    os.environ['PATH'] = "/usr/local/bin:" + os.environ['PATH']
    os.environ['PATH'] = "./test/runner/common/test_data/test_bin_path:" + os.environ['PATH']


# Generated at 2022-06-11 01:21:26.996939
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('bash') == "/bin/bash"
    assert get_bin_path('bash', ['/usr/local/bin', '/usr/bin']) == "/bin/bash"
    opts = ['/no/such/place', '/no/such/place/either']
    assert get_bin_path('bash', opts) == "/bin/bash"
    assert get_bin_path('does_not_exist') == None

# Generated at 2022-06-11 01:21:36.667666
# Unit test for function get_bin_path
def test_get_bin_path():
    # mocking os.path.exists, os.path.isdir, os.path.isfile, os.access
    mock_funcs = {'isfile': lambda x: True,
                  'isdir': lambda x: False,
                  'exists': lambda x: True,
                  'is_executable': lambda x: True}
    os_path_isfile = os.path.isfile
    os_path_isdir = os.path.isdir
    os_path_exists = os.path.exists
    os_access = os.access
    os.path.isfile = lambda x: mock_funcs['isfile'](x)
    os.path.isdir = lambda x: mock_funcs['isdir'](x)

# Generated at 2022-06-11 01:21:38.304885
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('cowsay')
    except ValueError as e:
        assert False, e

# Generated at 2022-06-11 01:21:48.442037
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import mock

    # Mock os.environ
    old_environ = dict(os.environ)
    os.environ.clear()
    os.environ['PATH'] = '/usr/bin:/usr/sbin:/bin:/sbin'
    assert get_bin_path('false') == '/usr/bin/false'
    assert get_bin_path(sys.executable) == sys.executable
    assert get_bin_path('no-such-executable')
    os.environ.clear()
    os.environ['PATH'] = '/usr/bin:/usr/sbin:/bin:/sbin'

    # Restore os.environ
    os.environ.clear()
    os.environ.update(old_environ)

# Generated at 2022-06-11 01:21:52.084178
# Unit test for function get_bin_path
def test_get_bin_path():
    # linux standard locations
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ping') == '/bin/ping'
    assert get_bin_path('sysctl') == '/sbin/sysctl'
    assert get_bin_path('keyctl') == '/usr/bin/keyctl'

# Generated at 2022-06-11 01:21:56.682974
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        result = get_bin_path('foobaz')
    except ValueError as e:
        result = e.args[0]

    assert result == 'Failed to find required executable "foobaz" in paths: {}:{}'.format(os.environ['PATH'], os.pathsep.join(['/sbin', '/usr/sbin', '/usr/local/sbin']))

# Generated at 2022-06-11 01:22:07.880218
# Unit test for function get_bin_path
def test_get_bin_path():
    # NOTE: These are not the filenames of real executables on your system
    # TODO: Maybe we can do something like "touch" test executables in /tmp/
    #       and remove them later in the same test?
    # TODO: Maybe this can be rewritten as a pytest fixture instead?

    # Set up
    test_paths = ['/bin', '/usr/bin', '/usr/local/bin']
    test_data = [('foo', '/bin/foo'),
                 ('bar', '/usr/bin/bar'),
                 ('baz', '/usr/local/bin/baz'),
                 ('qux', None),
                 ('quux', None)]


# Generated at 2022-06-11 01:22:16.245838
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    try:
        res = get_bin_path('python')
        try:
            res = get_bin_path('python', required=True)
        except ValueError as e:
            # This happens if PATH is set to an empty string.
            # Note that this isn't the same as not having a PATH at all.
            if sys.platform != 'win32':
                print(str(e))
                print('Not calling get_bin_path with required=True is deprecated,')
                print('and removed in Ansible 2.14.')

        if sys.platform != 'win32':
            res = get_bin_path('make')
        else:
            try:
                res = get_bin_path('make')
                assert False
            except:
                pass
    except ImportError:
        pass

# Generated at 2022-06-11 01:22:18.983319
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/sbin']) == '/bin/sh'

# Generated at 2022-06-11 01:22:29.043091
# Unit test for function get_bin_path
def test_get_bin_path():
    real_paths = ['/usr/bin', '/bin']
    fake_paths = ['/usr/bin_no_exists', '/bin_no_exists']
    fake_dirs = ['/usr', '/bin']

    assert get_bin_path('python', fake_paths) == '/usr/bin/python'
    try:
        get_bin_path('python_no_exists', fake_paths)
        assert False
    except:
        assert True
    try:
        get_bin_path('python', fake_dirs)
        assert False
    except:
        assert True
    try:
        get_bin_path('python_no_exists', fake_dirs)
        assert False
    except:
        assert True

# Generated at 2022-06-11 01:22:42.006652
# Unit test for function get_bin_path
def test_get_bin_path():
    # Verify find_bin handles normal path correctly
    assert os.path.join('/usr/local/bin', 'echo') == get_bin_path('echo', [])

    # Verify find_bin handles path with . correctly
    assert os.path.join(os.path.expanduser('~/bin'), 'echo') == get_bin_path('echo', ['.'])

    # Verify find_bin handles path with ./ correctly
    assert os.path.join(os.path.expanduser('~/bin'), 'echo') == get_bin_path('echo', ['./'])

    # Verify find_bin handles path with ../ correctly
    assert os.path.join(os.path.expanduser('~/bin'), 'echo') == get_bin_path('echo', ['../'])

test_get_bin_path()

# Generated at 2022-06-11 01:22:51.156103
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile

    # Create a script in a temporary directory which will be added to $PATH
    dirpath = tempfile.mkdtemp()
    scriptpath = os.path.join(dirpath, "script")
    fd, tmpfilename = tempfile.mkstemp(dir=dirpath)
    with os.fdopen(fd, "w") as f:
        f.write("#!/bin/sh\necho $*\n")
    os.rename(tmpfilename, scriptpath)

    # Verify that we can find the script
    try:
        assert(get_bin_path("script", opt_dirs=[dirpath]) == scriptpath)
    except Exception as e:
        assert(False)

    # Verify that we can find python

# Generated at 2022-06-11 01:22:51.788205
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-11 01:23:02.716969
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test for function get_bin_path.
    '''
    try:
        path = get_bin_path('/usr/bin/curl')
    except Exception as e:
        assert False, f'Failed to find curl in path: {e}'
    else:
        assert path == '/usr/bin/curl', 'Failed to find curl'

    try:
        path = get_bin_path('/usr/bin/curl', ['/usr/bin'])
    except Exception as e:
        assert False, f'Failed to find curl in path with opt_dirs: {e}'
    else:
        assert path == '/usr/bin/curl', 'Failed to find curl'


# Generated at 2022-06-11 01:23:10.355041
# Unit test for function get_bin_path
def test_get_bin_path():
    # as long as get_bin_path() works and is consistent with everything else in ansible
    # there is not much to test here
    #
    # see module_utils/facts/system/__init__.py:get_file_module_args_path() for another
    # example of how get_bin_path() is used
    path_dirs = ['/bin', '/usr/bin']
    assert get_bin_path('sh', path_dirs) == '/bin/sh'

    path_dirs = ['/sbin', '/usr/sbin']
    assert get_bin_path('ip', path_dirs) == '/sbin/ip'
    assert get_bin_path('ip', path_dirs) != '/bin/ip'

# Generated at 2022-06-11 01:23:19.404494
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    import shutil
    import stat

    # Create temp dir
    tmpdir = tempfile.mkdtemp()

    # Name of an executable in tmpdir
    test_exec_name = 'ansible_test_exec'
    test_exec_path = os.path.join(tmpdir, test_exec_name)

    # Create executable in tmpdir
    open(test_exec_path, 'w+').close()
    os.chmod(test_exec_path, stat.S_IRWXU)


# Generated at 2022-06-11 01:23:22.754329
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('ls'))
    try:
        get_bin_path('THISISNOTAREALFILE', required=True)
        assert(False)
    except (Exception):
        pass
    assert(get_bin_path('THISISNOTAREALFILE', required=False) is None)

# Generated at 2022-06-11 01:23:31.358730
# Unit test for function get_bin_path
def test_get_bin_path():
    # create temp dir
    import tempfile
    from shutil import copy
    from ansible.module_utils._text import to_bytes

    tmpdir = tempfile.mkdtemp()

    # add to path
    os.environ['PATH'] = tmpdir
    os.environ['PATH'] += ':' + os.path.expandvars('$PATH')

    required_files = [('test_script', ['/sbin/']), ('test_script2', None)]

    for script, dirs in required_files:
        copy(to_bytes(os.path.join('lib/ansible/module_utils/basic.py')), to_bytes(os.path.join(tmpdir, script)))
        os.chmod(os.path.join(tmpdir, script), 0o755)

# Generated at 2022-06-11 01:23:35.678171
# Unit test for function get_bin_path
def test_get_bin_path():
    # NOTE: tests assume that there is no HOME directory
    paths = ['/bin', '/usr/bin', '/usr/local/bin']

    # example of a binary that always exist on Linux/UNIX
    get_bin_path('/bin/ls')
    get_bin_path('ls')

    # example of a binary that is not in the path

# Generated at 2022-06-11 01:23:42.029154
# Unit test for function get_bin_path
def test_get_bin_path():
    # Get dir for ssh binary
    d = get_bin_path('ssh')

    # Get path for ssh binary, test error
    try:
        get_bin_path('ssh-not-found')
        assert False
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "ssh-not-found" in paths: ' + os.pathsep.join(os.environ.get('PATH', '').split(os.pathsep))

# Generated at 2022-06-11 01:23:50.539171
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("find") is not None
    import pytest

    with pytest.raises(ValueError) as excinfo:
        get_bin_path("/bin/xyz")
    excinfo.match("Failed to find required executable \"/bin/xyz\"")

# Generated at 2022-06-11 01:23:59.800682
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1: typical case, should return the correct path
    try:
        path = get_bin_path('/bin/echo')
    except Exception as e:
        # This test should not fail because /bin/echo exists on almost any system
        print('This test should not fail because /bin/echo exists on almost any system')
        print(e)
        exit(1)

    if path == '/bin/echo':
        print('Test 1: ' + '\033[92m' + 'SUCCESS' + '\033[0m')
    else:
        print('Test 1: ' + '\033[93m' + 'FAILED' + '\033[0m')
        exit(1)

    # Test 2: file not found in given paths

# Generated at 2022-06-11 01:24:03.356183
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('ls')
    assert bin_path == '/bin/ls'
    opt_dirs = ['/usr/bin', '/usr/sbin/']
    bin_path = get_bin_path('ls', opt_dirs)
    assert bin_path == '/usr/bin/ls'

# Generated at 2022-06-11 01:24:05.905577
# Unit test for function get_bin_path
def test_get_bin_path():

    # ...without optional arguments
    # expected: path to cat
    try:
        assert get_bin_path('cat') == '/bin/cat'
    except ValueError:
        pass

# Generated at 2022-06-11 01:24:13.299070
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import platform

    # test find existing bin in system paths
    bin_path = get_bin_path('python')
    assert os.path.exists(bin_path)
    assert os.path.join(sys.prefix, 'bin', 'python') == bin_path or os.path.join(sys.base_prefix, 'bin', 'python') == bin_path

    # test for required bin in local path
    try:
        bin_path = get_bin_path('python', [os.path.dirname(os.path.realpath(__file__))])
    except ValueError:
        assert False, 'Failed to find python in local directory'

    # test for non-existing bin in system paths

# Generated at 2022-06-11 01:24:25.169781
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check that we can find which
    assert get_bin_path('which') == '/usr/bin/which'
    # Check that we can find which using opt_dirs
    assert get_bin_path('which', ['/usr/bin', '/bin']) == '/usr/bin/which'
    # Check that we get a ValueError if the binary can't be found
    try:
        get_bin_path('which_does_not_exist', expected=False)
    except ValueError as e:
        pass
    else:
        assert False
    # Check that we can't find which_does_not_exist even if it is executable

# Generated at 2022-06-11 01:24:37.210320
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    import tempfile
    import shutil
    import os

    test_exec = 'test_executable_file'

    @pytest.fixture
    def executable_file(directory, request):
        f = open(os.path.join(directory, test_exec), 'w')
        f.write('#!/bin/sh')
        f.close()
        os.chmod(os.path.join(directory, test_exec), 0o755)

    @pytest.fixture
    def directory(request):
        d = tempfile.mkdtemp()

        def fin():
            shutil.rmtree(d)
        request.addfinalizer(fin)
        return d


# Generated at 2022-06-11 01:24:48.505052
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # make a temporary directory
    tmpdir = tempfile.mkdtemp()

    # make a temporary file
    tf = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tf.close()

    # make a temporary file executable
    os.chmod(tf.name, 0o755)

    # verify if the function fails to find the file in two different paths
    # without the tmpdir in the search path
    assert get_bin_path(tf.name) == tf.name
    assert get_bin_path(tf.name, opt_dirs=[tmpdir]) == tf.name

    # verify the function finds the file in two different paths with or without
    # the tmpdir in the search path

# Generated at 2022-06-11 01:24:51.377071
# Unit test for function get_bin_path
def test_get_bin_path():
    # check for known paths
    for p in ('/bin/ls', '/usr/bin/python2.7'):
        assert get_bin_path(os.path.basename(p)) == p
    # check for a real path but one that does not exist
    from pytest import raises
    with raises(ValueError):
        get_bin_path('__DNE__')

# Generated at 2022-06-11 01:24:58.414095
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cc') == '/usr/bin/cc'
    assert get_bin_path('cc', ['/usr/local/bin']) == '/usr/local/bin/cc'
    try:
        get_bin_path('not_exists')
        assert False
    except Exception as e:
        assert str(e) == 'Failed to find required executable "not_exists" in paths: /sbin:/usr/sbin:/usr/local/sbin:/bin:/usr/bin'

# Generated at 2022-06-11 01:25:12.409567
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest

    def test_case(executable, opt_dirs, required, expected_success, expected_path):
        try:
            path = get_bin_path(executable, opt_dirs, required)
            assert expected_success, 'Successfully found executable "%s", path "%s", should have failed' % (executable, path)
            assert path == expected_path, 'Successfully found executable "%s", path "%s", expected "%s"' % (executable, path, expected_path)
        except ValueError as e:
            assert not expected_success, 'Failed to find executable "%s", should have succeeded: %s' % (executable, e)

    test_case('/usr/bin/test_exec', [], False, True, '/usr/bin/test_exec')

# Generated at 2022-06-11 01:25:16.436649
# Unit test for function get_bin_path
def test_get_bin_path():
    # Tests that get_bin_path generates the expected exception if not found
    # Returns a bool indicating pass/failure
    if get_bin_path('nonexistent_executable', [os.getcwd()], True):
        return True
    else:
        return False

# Generated at 2022-06-11 01:25:28.234291
# Unit test for function get_bin_path
def test_get_bin_path():
    # test the case of existing executable with absolute path
    cmd = "/bin/ls"
    assert get_bin_path(cmd) == cmd

    # test the case of existing executable with relative path
    assert (get_bin_path("ls") == os.path.join(os.path.sep, "bin", "ls") or get_bin_path("ls") == os.path.join(os.path.sep, "usr", "bin", "ls"))

    # test the case of missing executable
    try:
        get_bin_path("not-existing-command")
    except ValueError as e:
        assert "Failed to find required executable \"not-existing-command\"" in str(e)
    else:
        assert False # Expecting exception, but none thrown

    # test the case of existing executable, with optional directories
    cmd

# Generated at 2022-06-11 01:25:37.842585
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("/bin/sh") == "/bin/sh"
    assert get_bin_path("sh") in ["/bin/sh", "/usr/bin/sh"]
    assert get_bin_path("/bin/sh", opt_dirs=["some non existent directory"]) == "/bin/sh"
    try:
        get_bin_path("/bin/does-not-exist")
        assert False, "expected an exception"
    except ValueError:
        pass
    try:
        get_bin_path("does-not-exist")
        assert False, "expected an exception"
    except ValueError:
        pass

# Generated at 2022-06-11 01:25:45.536218
# Unit test for function get_bin_path
def test_get_bin_path():
    # Define utility directories where executables are placed
    user_bin_path = "/home/user/bin"
    bin_path = "/bin"

    # Set PATH and check whether utility directories are included
    os.environ['PATH'] = "%s" % os.pathsep.join([user_bin_path, bin_path])

    # Verify that get_bin_path function works with no optional arguments
    assert (get_bin_path('ls') == os.path.join(bin_path, 'ls'))

    # Verify that get_bin_path function works with optional arguments
    assert (get_bin_path('ls', opt_dirs=[user_bin_path, bin_path]) == os.path.join(user_bin_path, 'ls'))

# Generated at 2022-06-11 01:25:56.102201
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    mytestdir = tempfile.mkdtemp(prefix="test_get_bin_path_")

    mytestfile = os.path.join(mytestdir, "test_is_executable")

    f = open(mytestfile, 'w')
    f.write('#!/bin/sh\n')
    f.close()

    os.chmod(mytestfile, 0o755)


# Generated at 2022-06-11 01:26:06.631985
# Unit test for function get_bin_path
def test_get_bin_path():

    bin = 'ls'
    path_sep = os.pathsep

    # Test get_bin_path without optional arguments
    try:
        get_bin_path(bin)
    except ValueError:
        err = 'bin: %s is not in the PATH' % bin
        assert True, err

    # Test get_bin_path with empty opt_dirs
    try:
        get_bin_path(bin, opt_dirs=[])
    except ValueError:
        err = 'bin: %s is not in the PATH' % bin
        assert True, err

    # Test get_bin_path with opt_dirs containing invalid path

# Generated at 2022-06-11 01:26:08.863429
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    return path to python executable
    '''
    # returns path to python executable
    assert get_bin_path('python') is not None

# Generated at 2022-06-11 01:26:15.872575
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        mybin = get_bin_path("awk")
        assert mybin == "/usr/bin/awk"
    except ValueError as e:
        assert False
    try:
        mybin = get_bin_path("awk", ['/usr/bin'])
        assert mybin == "/usr/bin/awk"
    except ValueError as e:
        assert False
    # Test failure
    mybin = get_bin_path("awk", ['/usr/bin', '/usr/sbin'])
    assert False

# Generated at 2022-06-11 01:26:18.418565
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("sh") == "/bin/sh"
    assert get_bin_path("ifconfig", opt_dirs=["/sbin"]) == "/sbin/ifconfig"

# Generated at 2022-06-11 01:26:28.507957
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/bin/sh' == get_bin_path('sh')
    assert '/sbin/service' == get_bin_path('service', ['/sbin'])
    assert '/sbin/service' == get_bin_path('service', ['/sbin', '/bin'])
    try:
        get_bin_path('sh', ['/bin'])
        assert False
    except ValueError:
        assert True
        pass

# Generated at 2022-06-11 01:26:37.138080
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    import unittest

    class TestGetBinPath(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_binary(self):
            f = tempfile.NamedTemporaryFile('w', delete=False, dir=self.tempdir)
            f.write('#!/bin/sh\n')
            f.write('\nexit 0\n')
            f.flush()
            os.chmod(f.name, 0o755)
            self.assertEqual(get_bin_path(os.path.basename(f.name), [self.tempdir]), f.name)


# Generated at 2022-06-11 01:26:47.673574
# Unit test for function get_bin_path
def test_get_bin_path():
    import ansible.module_utils.basic
    from ansible.compat.six.moves import builtins

    try:
        get_bin_path('false')
    except Exception as e:
        assert 'Failed to find required executable "false"' in str(e), 'Found %s' % str(e)
    else:
        assert False, 'Exception not raised'
    try:
        get_bin_path('false', required=True)
    except Exception as e:
        assert 'Failed to find required executable "false"' in str(e), 'Found %s' % str(e)
    else:
        assert False, 'Exception not raised'

    if not hasattr(builtins, '__test_bin_path'):
        setattr(builtins, '__test_bin_path', None)


# Generated at 2022-06-11 01:26:56.259602
# Unit test for function get_bin_path
def test_get_bin_path():

    import sys
    import tempfile
    import shutil
    from ansible.module_utils.common._collections_compat import Mapping

    TEMP = None
    CMD = 'test'
    CMD_FILE = {
        'path': 'testpath',
        'mode': '0700'
    }

# Generated at 2022-06-11 01:27:02.957434
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('vi')
    except ValueError:
        assert False

    try:
        get_bin_path('vi', ['/bin', '/sbin'])
    except ValueError:
        assert False

    try:
        get_bin_path('vi', ['/bin', '/sbin', '/nonexistent-dir'], required=True)
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 01:27:07.961279
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('parted', opt_dirs=['/bin']) == '/bin/parted'
    assert get_bin_path('parted', opt_dirs=['/bin', '/usr/bin']) == '/usr/bin/parted'

# Generated at 2022-06-11 01:27:18.736175
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    The unit test covers get_bin_path()'s functionality.
    @return: None
    '''
    import os
    import tempfile

    # Try to locate ls command
    try:
        ls_loc = get_bin_path('ls')
        assert os.path.exists(ls_loc)
    except ValueError as e:
        print("test_get_bin_path: test failed to run ls command. Error: %s" % e)

    # Create a non-existent command to test that get_bin_path raises ValueError properly
    # Use a temporary file so we don't pollute the directory environment
    tmp_file = tempfile.NamedTemporaryFile()
    tmp_file.close()

# Generated at 2022-06-11 01:27:26.355354
# Unit test for function get_bin_path
def test_get_bin_path():
    import __builtin__ as builtins
    if hasattr(builtins, '__NOSE_TESTING__'):
        import tempfile
        import shutil
        import stat

        tmp = tempfile.mkdtemp()
        test_bin_file = tempfile.NamedTemporaryFile(mode='wt', delete=False, dir=tmp)
        test_bin_file.write('#!/bin/sh')
        test_bin_file.flush()
        os.fchmod(test_bin_file.fileno(), 0o755)

# Generated at 2022-06-11 01:27:35.109516
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.file import get_bin_path

    if os.name != 'posix' or 'bsd' in os.uname()[0].lower():
        print('Skipping because os.name != posix or uname is BSD')
        return

    assert get_bin_path('bash', required=False) == '/bin/bash'

    # ensure it's getting from $PATH first
    old_path = os.environ['PATH']
    os.environ['PATH'] = '/bin'
    assert get_bin_path('bash') == '/bin/bash'

    # reset path
    os.environ['PATH'] = old_path

    # ensure it finds /sbin executables
    assert get_bin_path('ip') == '/sbin/ip'
    assert get_bin_path

# Generated at 2022-06-11 01:27:36.329021
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('curl') == 'curl'

# Generated at 2022-06-11 01:27:48.602648
# Unit test for function get_bin_path
def test_get_bin_path():

    import datetime
    import tempfile

    # helper function to create an arbitrary executable file inside a temporary directory
    def _make_dir_and_exec(dir_name, exec_name, content=None):
        '''
        Creates a temporary directory and an arbitrary executable file inside it.
        Returns:
            The directory path, and the executable file path.
        '''
        dir_path = tempfile.mkdtemp(suffix=dir_name)
        exec_path = os.path.join(dir_path, exec_name)
        with open(exec_path, 'w') as f:
            content = "echo " + exec_name if content is None else content
            f.write(content)
        os.chmod(exec_path, 0o755)
        return dir_path, exec_path

    # test basic cases


# Generated at 2022-06-11 01:27:55.258094
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('cp')
    print(path)
    path = get_bin_path('cp', ['/bin'])
    print(path)
    path = get_bin_path('nosuchbinary', ['/bin'])
    print(path)
    path = get_bin_path('nosuchbinary', opt_dirs=['/bin'], required=True)
    print(path)

# Test the function
if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-11 01:27:58.304793
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('sh')  # Will raise ValueError if '/bin/sh' not found in PATH

# Generated at 2022-06-11 01:28:09.840859
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('python2')
    assert bin_path.endswith('python2')
    assert os.path.exists(bin_path)
    assert os.path.isfile(bin_path)

    bin_path = get_bin_path('python2', ['/usr/bin'])
    assert bin_path.endswith('python2')
    assert os.path.exists(bin_path)
    assert os.path.isfile(bin_path)

    bin_path = get_bin_path('python2', ['/usr/bin/'])
    assert bin_path.endswith('python2')
    assert os.path.exists(bin_path)
    assert os.path.isfile(bin_path)


# Generated at 2022-06-11 01:28:20.305603
# Unit test for function get_bin_path
def test_get_bin_path():

    # Test expected cases
    try:
        assert get_bin_path('ls') == '/bin/ls'
    except ValueError as e:
        assert False, 'Expected get_bin_path to find /bin/ls, instead got exception: %s' % e

    try:
        assert get_bin_path('ls',opt_dirs=['/bin','/usr/bin']) == '/bin/ls'
    except ValueError as e:
        assert False, 'Expected get_bin_path to find /bin/ls, instead got exception: %s' % e

    # Test exceptions

# Generated at 2022-06-11 01:28:31.609628
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import platform    #used to determine platform being tested on
    import tempfile    #used to create tempfile paths
    import atexit      #used to register clean up of temporary files

    linux_python = '/usr/bin/python'
    windows_python = r'c:\python27\python.exe'

    # Python is used for testing since it exists in default path for all platforms
    arch_dependent_exes = [
        'python'
    ]
    temp_files = []
    @atexit.register
    def clean_temp_files():
        """Executes when the test ends. Used to clean up temp files created during testing"""
        for temp_file in temp_files:
            os.remove(temp_file)


# Generated at 2022-06-11 01:28:35.620030
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' test for function get_bin_path()'''
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('nosuchthing') == None
    assert get_bin_path('nosuchthing', opt_dirs=['/usr/bin']) == None
    assert get_bin_path('nosuchthing', opt_dirs=['/usr/bin'], required=False) == None



# Generated at 2022-06-11 01:28:37.178326
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python2.7')

# Generated at 2022-06-11 01:28:47.832104
# Unit test for function get_bin_path
def test_get_bin_path():
    PATH = os.environ["PATH"]

    # this should succeed
    os.environ["PATH"] = "/usr/bin:/bin"
    bin_path = get_bin_path("ls")
    assert bin_path == "/bin/ls"

    # this should fail
    try:
        os.environ["PATH"] = "/usr/bin"
        bin_path = get_bin_path("ls")
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

    # set PATH to be the original and test 'required' parameter (deprecated)
    os.environ["PATH"] = PATH
    try:
        bin_path = get_bin_path("ls")
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

    os.en

# Generated at 2022-06-11 01:28:57.292195
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for PATH override
    assert get_bin_path('ls') is not None

    # Test for non-existent file
    try:
        get_bin_path('fakecommand')
        assert False, "Failed to find required executable fakecommand in PATH"
    except ValueError:
        pass

    # Test for executable in PATH
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin', '/usr/local/bin']) is not None

    # Test for executable not in PATH
    try:
        get_bin_path('ls', opt_dirs=['/usr/bin', '/usr/local/bin'])
        assert False, "Failed to find required executable ls in PATH"
    except ValueError:
        pass