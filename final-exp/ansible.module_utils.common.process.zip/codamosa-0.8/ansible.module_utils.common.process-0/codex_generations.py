

# Generated at 2022-06-11 01:19:21.121480
# Unit test for function get_bin_path
def test_get_bin_path():
    from mock import patch

    mocked_get_bin_path_exists = ['', '/bin', '/sbin', '/usr/sbin']
    mocked_get_bin_path_isdir = ['/usr/local/bin']

    with patch('os.path.isdir') as mock_isdir, \
        patch('os.path.exists') as mock_exists, \
        patch('os.environ.get') as mock_env, \
        patch('ansible.module_utils.common.file.is_executable') as mock_is_exec:

        mock_exists.side_effect = lambda path: path in mocked_get_bin_path_exists
        mock_isdir.side_effect = lambda path: path in mocked_get_bin_path_isdir

# Generated at 2022-06-11 01:19:28.761654
# Unit test for function get_bin_path
def test_get_bin_path():
    #setup
    arg = '/usr/bin/python'
    opt_dirs = ['/usr/bin']
    try:
        os.environ['PATH'] = '/usr/bin:/bin'
        assert get_bin_path(arg, opt_dirs) == arg
        # Assert that opt_dirs argument was used
        assert get_bin_path('/bin/ls', ['/usr/bin', '/usr/local/bin']) == '/usr/local/bin/ls'
        assert get_bin_path('/bin/ls', ['/usr/bin', '/bin']) == '/bin/ls'
    except ValueError as e:
        print("Failed to run %s" % arg)
        raise e

# Generated at 2022-06-11 01:19:37.565493
# Unit test for function get_bin_path
def test_get_bin_path():
    print("=== Test get_bin_path ===")
    import sys
    import tempfile

    # Create a temporary file to test with
    tf = tempfile.NamedTemporaryFile()
    bin_name = os.path.basename(tf.name)

    # We expect this to succeed since the temporary file is "executable" and in the current directory
    test_bin_path = get_bin_path(bin_name, ['./'])
    print("Found path: " + test_bin_path)

    # We expect this to raise a value error since the directory doesn't exist
    try:
        get_bin_path(bin_name, ['/this/path/doesnt/exist'])
    except ValueError as e:
        print("Raised expected ValueError: %s" % e)

    tf.close()


# Generated at 2022-06-11 01:19:42.128995
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    d = tempfile.mkdtemp()

    f = open(os.path.join(d, 'ls'), 'w')
    f.close()

    try:
        result = get_bin_path('ls', [os.path.join(d)])
        assert result == os.path.join(d, 'ls')

    finally:
        os.unlink(os.path.join(d, 'ls'))
        os.rmdir(d)



# Generated at 2022-06-11 01:19:54.678492
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    ansible.module_utils.common.file.get_bin_path
    '''
    import ansible.module_utils.common.file as file_utils

    # PATH is set to common paths in usual Unix-like systems.
    os.environ['PATH'] = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'

    # Testing with a required executable.
    bash_path = file_utils.get_bin_path('bash')
    assert bash_path == '/bin/bash'

    # Testing with a non-required executable
    python_path = file_utils.get_bin_path('python', required=False)
    assert python_path == '/usr/bin/python'

    # Testing with an nonexistent executable, which results in a ValueError exception.


# Generated at 2022-06-11 01:20:02.625486
# Unit test for function get_bin_path
def test_get_bin_path():
    import ansible.module_utils.common.file
    import shutil
    import tempfile
    import sys

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    def restore_path(path):
        if os.path.exists(path):
            os.remove(path)

    def mock_is_executable(path):
        return os.path.exists(path)

    opt_dirs = ['/bin', '/usr/bin']
    required = None
    arg = 'ls'

    temp_dir = tempfile.mkdtemp()
    path = os.path.join(temp_dir, arg)


# Generated at 2022-06-11 01:20:09.629484
# Unit test for function get_bin_path
def test_get_bin_path():
    import subprocess
    import tempfile

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 01:20:14.609664
# Unit test for function get_bin_path
def test_get_bin_path():
    # If ansible is installed using 'pip', ansible-doc and ansible-console
    # will not be available. The unit test will pass on Fedora and RHEL.
    try:
        assert get_bin_path('ansible-doc')
        assert get_bin_path('ansible-console')
    except ValueError:
        pass

# Generated at 2022-06-11 01:20:23.987983
# Unit test for function get_bin_path
def test_get_bin_path():
    def assert_bin_path(arg, opt_dirs=None, required=False):
        return get_bin_path(arg, opt_dirs, required)

    paths = ['/bin', '/usr/bin', '/usr/local/bin']

    # file found in path dir
    assert_bin_path('awk')

    # file found in additional path dir
    assert_bin_path('awk', opt_dirs=paths)

    # file found in first additional path dir
    assert_bin_path('awk', opt_dirs=paths[:1])

    # file found in last additional path dir
    assert_bin_path('awk', opt_dirs=paths[-1:])

    # file not found

# Generated at 2022-06-11 01:20:34.809094
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('ansible-config')
    print(bin_path)
    bin_path = get_bin_path('bash', opt_dirs=['/usr/bin', '/bin'])
    print(bin_path)
    bin_path = get_bin_path('python', opt_dirs=['/usr/bin', '/bin'])
    print(bin_path)

    bin_path = get_bin_path('/bin/bash')
    print(bin_path)
    bin_path = get_bin_path('/usr/bin/python')
    print(bin_path)


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-11 01:20:42.938150
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ['PATH'] = '/usr/bin'
    assert get_bin_path('sh') == '/usr/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    try:
        get_bin_path('this_should_fail', required=True)
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-11 01:20:51.090624
# Unit test for function get_bin_path
def test_get_bin_path():

    # success with an executable name
    assert get_bin_path("touch") is not None

    # failure
    got_exception = False
    try:
        get_bin_path("does-not-exist")
    except ValueError:
        got_exception = True
    assert got_exception

    # success with executable name in optional search path
    cur_dir = os.path.dirname(os.path.realpath(__file__))
    assert get_bin_path("touch", opt_dirs=[cur_dir]) is not None

    # failure with executable name not in optional search path
    got_exception = False
    try:
        get_bin_path("does-not-exist", opt_dirs=[cur_dir])
    except ValueError:
        got_exception = True
    assert got_exception



# Generated at 2022-06-11 01:20:57.735301
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check path when file exists in first path in PATH
    with open('/tmp/test_in_first', 'w') as f:
        f.write('#!/bin/sh\necho $@\n')

    os.chmod('/tmp/test_in_first', 0o755)
    old_path = os.environ['PATH']

    try:
        os.environ['PATH'] = '/tmp:' + old_path
        bin_path = get_bin_path('test_in_first', [])
    finally:
        os.environ['PATH'] = old_path

    os.remove('/tmp/test_in_first')

    assert bin_path == '/tmp/test_in_first'

    # Check path when file exists in second path in PATH

# Generated at 2022-06-11 01:21:05.468276
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/usr/bin/python2.7')
    except ValueError:
        assert False, "Python 2.7 should be found"

    try:
        get_bin_path('/usr/bin/python3.7')
    except ValueError:
        assert False, "Python 3.7 should be found"

    try:
        get_bin_path('/usr/bin/foo')
        assert False, 'This executable does not exists, should raise ValueError'
    except ValueError:
        pass

# Generated at 2022-06-11 01:21:12.837429
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('missing_tool')
        assert False, "Failed to raise ValueError when command is not found"
    except ValueError as e:
        assert 'Failed to find required executable "missing_tool"' in str(e)

    assert 'ls' in get_bin_path('ls')
    assert 'ps' in get_bin_path('ps')
    assert 'ps' in get_bin_path('ps', required=True)
    assert 'ps' in get_bin_path('ps', ['/bin'])
    assert 'ps' in get_bin_path('ps', ['/bin'], required=True)
    assert 'ps' in get_bin_path('ps', opt_dirs=['/bin'])

# Generated at 2022-06-11 01:21:22.958228
# Unit test for function get_bin_path
def test_get_bin_path():
    # setup OS environment for unit test
    test_env = dict(PATH='/bin:/usr/bin:/usr/local/bin')
    saved_env = {}
    for key in test_env:
        saved_env[key] = os.environ.get(key)
        os.environ[key] = test_env[key]

    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('cat', opt_dirs=['/usr/bin']) == '/usr/bin/cat'

    # restore OS environment
    for key in saved_env:
        if saved_env[key] is None:
            del os.environ[key]
        else:
            os.environ[key] = saved_env[key]

# Generated at 2022-06-11 01:21:30.627394
# Unit test for function get_bin_path
def test_get_bin_path():
    for bin in ('/bin/sh', '/usr/bin/sh'):
        # Test that get_bin_path with no arguments returns same path we pass in
        assert get_bin_path(bin) == bin
        # Test that get_bin_path with a path of our choosing returns same path we pass in
        assert get_bin_path(bin, opt_dirs=['/']) == bin
        # Test that get_bin_path with a path of our choosing returns same path we pass in
        assert get_bin_path(bin, opt_dirs=['/usr', '/']) == bin
        # Test that a non-existant bin file raises ValueError

# Generated at 2022-06-11 01:21:40.610526
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test the get_bin_path function used by many unit tests
    '''
    import platform
    import stat
    import shutil
    import tempfile
    import sys

    # Test with the python executable
    curr_python = get_bin_path('python')

    # Test that the executable exists
    assert os.path.isfile(curr_python)

    # Test that the executable is executable (octal 550)
    assert stat.S_IMODE(os.stat(curr_python).st_mode) == 0o550 or os.stat(curr_python).st_mode & stat.S_IEXEC

    # Test with an executable that should be in the path (sh)
    sh = get_bin_path('sh')

    # Test that the executable exists

# Generated at 2022-06-11 01:21:43.571382
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.file import find_executable

    bin_path = get_bin_path('bash')
    assert find_executable('bash') == bin_path

# Generated at 2022-06-11 01:21:48.565480
# Unit test for function get_bin_path
def test_get_bin_path():
    import os

    old_path = os.environ['PATH']
    del os.environ['PATH']
    try:
        os.environ['PATH'] = '/bin'
        assert get_bin_path('sh', opt_dirs=['/sbin']) == '/bin/sh'
    finally:
        os.environ['PATH'] = old_path

# Generated at 2022-06-11 01:21:56.155467
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python', opt_dirs=['/test/path']) == '/test/path/python'
    assert get_bin_path('python', opt_dirs=['/test/path']) != '/test/path/python2'

# Generated at 2022-06-11 01:22:06.329866
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/bash') == '/bin/bash'

    bin_path = get_bin_path('bash')
    assert bin_path == '/bin/bash' or bin_path == '/usr/bin/bash'

    bin_path = get_bin_path('true')
    assert bin_path == '/bin/true' or bin_path == '/usr/bin/true'

    bin_path = get_bin_path('true', opt_dirs=['/usr/bin'], required=False)
    assert bin_path == '/usr/bin/true'

    try:
        get_bin_path('this-will-never-exist')
        assert False, 'Invalid executable should raise ValueError'
    except ValueError:
        pass

# Generated at 2022-06-11 01:22:08.376735
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('curl')
    get_bin_path('curl', ['.'], True)

# Generated at 2022-06-11 01:22:16.076464
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        my_bin_path = get_bin_path('/bin/dir', ['/bin', '/usr/bin'])
        if my_bin_path != '/bin/dir':
            raise AssertionError('path returned is wrong')
        # Negative test
        try:
            my_bin_path = get_bin_path('/bin/dir', ['/sbin', '/usr/bin'])
        except ValueError as e:
            if str(e) != 'Failed to find required executable "/bin/dir" in paths: /sbin:/usr/bin':
                raise AssertionError('path returned is wrong')
            else:
                return
    except ValueError as e:
        raise AssertionError('path returned is wrong')

# Generated at 2022-06-11 01:22:26.498811
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['/bin', '/usr/bin']

    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=paths) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=paths + ['/tmp']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=[]) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=None) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=[None]) == '/bin/ls'

# Generated at 2022-06-11 01:22:28.193603
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert bin_path == '/bin/sh'

# Generated at 2022-06-11 01:22:34.976213
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile

    arg = sys.executable
    opt_dirs = [tempfile.gettempdir()]
    opt_dirs_result = get_bin_path(arg, opt_dirs)
    assert os.path.exists(opt_dirs_result)

    bin_path = get_bin_path(arg, required=False)
    assert os.path.exists(bin_path)

    # test not found
    try:
        get_bin_path('this_executable_does_not_exist')
    except ValueError as exc:
        assert isinstance(exc, ValueError)



# Generated at 2022-06-11 01:22:39.603344
# Unit test for function get_bin_path
def test_get_bin_path():
    test_paths = ['', '/bin', '/usr/bin', '/usr/local/bin', '/sbin', '/usr/sbin', '/usr/local/sbin']
    assert get_bin_path('ls', test_paths) == '/bin/ls'

# Generated at 2022-06-11 01:22:49.611194
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    path = os.path.join(tmpdir, 'get_bin_path')
    with open(path, 'w') as f:
        f.write('#!/bin/sh\necho hello')

    # Mark the file mode as executable
    mode = os.stat(path).st_mode
    mode |= 0o111
    os.chmod(path, mode)

    # Assert that the file is executable now
    assert os.access(path, os.X_OK)

    # add the file to PATH
    os.environ['PATH'] = tmpdir

    # Test with 'get_bin_path'

# Generated at 2022-06-11 01:22:51.548814
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path("ping")
    assert os.access(path, os.X_OK)

# Generated at 2022-06-11 01:23:04.305838
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('cat', ['/bin']) == '/bin/cat'
    assert get_bin_path('cat', ['/bin', '/usr/bin']) == '/bin/cat'
    assert get_bin_path('cat', ['/usr/bin']) == '/usr/bin/cat'
    assert get_bin_path('cat', ['/bin', '/usr/bin'], True) == '/bin/cat'
    try:
        get_bin_path('does_not_exist')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-11 01:23:12.882205
# Unit test for function get_bin_path
def test_get_bin_path():

    from tempfile import mkdtemp
    from shutil import rmtree

    test_paths = []
    test_paths.append(None)
    test_paths.append(os.path.abspath(os.path.curdir))
    test_paths.append(os.path.abspath(os.path.pardir))
    test_paths.append(os.path.abspath(os.path.join(os.path.pardir, os.path.pardir)))
    test_paths.append(os.sep)
    test_paths.append(os.path.join('/', 'sbin'))
    test_paths.append(os.path.join('/', 'bin'))

# Generated at 2022-06-11 01:23:21.028777
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Error case tests
    '''
    # test command not in PATH
    try:
        get_bin_path('not_in_path_command')
    except ValueError as e:
        assert e.args[0].startswith('Failed to find required executable "not_in_path_command"')
    else:
        assert False, 'Expected ValueError to be raised'

    # test command in PATH with wrong permissions
    f = open('/var/tmp/test_get_bin_path_file', 'w')
    f.write('''#!/bin/sh
    ''')
    f.close()
    os.chmod('/var/tmp/test_get_bin_path_file', 0o444)

# Generated at 2022-06-11 01:23:29.437327
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/echo') == '/bin/echo'
    assert get_bin_path('/bin/echo') != '/usr/bin/echo'
    assert get_bin_path('/bin/echodoesnotexist') == None
    try:
        get_bin_path('/bin/echodoesnotexist', required=True)
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "/bin/echodoesnotexist" in paths: /bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin'
    assert get_bin_path('echo') == '/bin/echo'
    # assert get_bin_path('echodoesnotexist', opt_dirs=['/bin']) == None
    # assert get

# Generated at 2022-06-11 01:23:37.211979
# Unit test for function get_bin_path
def test_get_bin_path():
    test_path = '/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin'
    os.environ['PATH'] = test_path
    bin_path = get_bin_path('sh')
    assert bin_path == '/bin/sh'

    os.environ['PATH'] = test_path
    bin_path = get_bin_path('sh', required=True)
    assert bin_path == '/bin/sh'

    os.environ['PATH'] = '/bin:/usr/bin:/usr/local/bin'
    try:
        bin_path = get_bin_path('csh')
    except ValueError:
        assert True, 'ValueError expected'
    else:
        assert False, 'ValueError not raised'

    os.environ['PATH'] = test_path
    bin_path

# Generated at 2022-06-11 01:23:48.686767
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('bash')) == '/bin/bash'
    assert(get_bin_path('/bin/bash')) == '/bin/bash'
    try:
        get_bin_path('badbinary_notfound') == '/bin/bash'
    except ValueError:
        pass
    try:
        get_bin_path('/dev/null/badbinary_notfound') == '/bin/bash'
    except ValueError:
        pass
    assert(get_bin_path('bash', opt_dirs=['/bin'])) == '/bin/bash'
    assert(get_bin_path('/bin/bash', opt_dirs=['/bin'])) == '/bin/bash'

# Generated at 2022-06-11 01:23:57.790724
# Unit test for function get_bin_path
def test_get_bin_path():
    # success cases
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('dos2unix', ['/usr/bin', '/usr/sbin']) == '/usr/bin/dos2unix'
    assert get_bin_path('/bin/ls') == '/bin/ls'

    # failure cases
    try:
        get_bin_path('abcdefg')
        assert False, 'Expected to fail'
    except ValueError:
        pass

    try:
        get_bin_path('abcdefg', ['/usr/bin', '/usr/sbin'])
        assert False, 'Expected to fail'
    except ValueError:
        pass

# Generated at 2022-06-11 01:24:06.416948
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    This is a unit test for function get_bin_path from this module.
    '''
    from itertools import permutations
    from distutils.spawn import find_executable
    from tempfile import mkdtemp
    import shutil
    import random
    # This is a fixed set of commands
    commands = [
        'ls',
        'nginx',
        'python',
        'ssh',
        'git',
        'cat',
        'grep',
        'awk'
        'arista-archiver',
    ]

    # These are random paths
    # We use a set to make sure there are no duplicates, then convert to list
    # This is to make sure we don't get any exceptions when we create this
    # directory. Also, these directories will be randomly added to the PATH
    # and tested

# Generated at 2022-06-11 01:24:10.294052
# Unit test for function get_bin_path
def test_get_bin_path():
    # when in path
    assert get_bin_path('true')

    # not in path
    try:
        get_bin_path('true', opt_dirs=[])
        assert False
    except ValueError:
        assert True

    # in path from opt_dirs
    assert get_bin_path('true', opt_dirs=['/bin'])

# Generated at 2022-06-11 01:24:14.360997
# Unit test for function get_bin_path
def test_get_bin_path():
    # test is_executable()
    assert is_executable(get_bin_path('true')) is True
    assert is_executable(get_bin_path('false')) is True

    # test exceptions
    import pytest
    with pytest.raises(ValueError):
        get_bin_path('nonexistent_executable')
    with pytest.raises(ValueError):
        get_bin_path('nonexistent_executable', required=True)

# Generated at 2022-06-11 01:24:41.868095
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', [tmpdir]) == '/bin/sh'
    assert get_bin_path('false', [tmpdir]) == '/bin/false'
    assert get_bin_path(os.path.join(tmpdir, 'sh')) == '/bin/sh'
    assert get_bin_path('bash', ['/bin']) == '/bin/bash'
    assert get_bin_path('/bin/bash') == '/bin/bash'

    # Create a shell script to test
    print('#!/bin/sh', file=open(os.path.join(tmpdir, 'test1.sh'), 'w'))

# Generated at 2022-06-11 01:24:45.784475
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.six.moves import builtins

    # test for non-existence of bin
    try:
        get_bin_path('nonsense', required=True)
        raise Exception('get_bin_path should have failed to find nonsense')
    except ValueError:
        pass

    # test for existence of bin
    python_bin = 'python'
    if hasattr(builtins, '__xonsh__'):
        python_bin = os.path.join(os.path.dirname(builtins.__xonsh__.env['XONSH_INTERPRETER']), python_bin)
    try:
        get_bin_path(python_bin, required=True)
    except ValueError:
        raise Exception('get_bin_path should found %s' % python_bin)

# Generated at 2022-06-11 01:24:50.801569
# Unit test for function get_bin_path
def test_get_bin_path():
    # simple test to just run function on known executable
    #  - should find it, and return a string ending in arg
    assert get_bin_path("python").endswith("python")
    # check that passing required=True is deprecated
    assert get_bin_path("python", required=True).endswith("python")

# Generated at 2022-06-11 01:25:01.490976
# Unit test for function get_bin_path
def test_get_bin_path():
    # Tests on Linux
    if os.name == 'posix':
        # Default case
        assert get_bin_path('which') == '/usr/bin/which'

        # Existing but non-executable case
        open(os.path.join('/tmp', 'non-executable'), 'a').close()
        os.chmod(os.path.join('/tmp', 'non-executable'), 0o400)
        try:
            get_bin_path('non-executable')
        except ValueError:
            os.remove(os.path.join('/tmp', 'non-executable'))
        else:
            raise AssertionError("get_bin_path() did find non-executable file")

        # Non-existing case

# Generated at 2022-06-11 01:25:06.002168
# Unit test for function get_bin_path
def test_get_bin_path():
    path1 = get_bin_path('sh')
    assert path1 == '/bin/sh' or path1 == '/usr/bin/sh'

    path2 = get_bin_path('no_executable_by_this_name')
    assert path2 is None

# Generated at 2022-06-11 01:25:07.711809
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert bin_path == '/bin/sh'

# Generated at 2022-06-11 01:25:15.570479
# Unit test for function get_bin_path
def test_get_bin_path():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import Sequence

    from ansible.module_utils.common.file import is_executable

    from ansible.module_utils.common.file import get_bin_path

    from ansible.module_utils.basic import AnsibleModule

    def my_exit_json(self, **kwargs):
        kwargs['invoked'] = True
        return super(MyModule, self).exit_json(**kwargs)

    def my_fail_json(self, **kwargs):
        kwargs['invoked'] = True
        return super(MyModule, self).fail_json(**kwargs)


# Generated at 2022-06-11 01:25:25.211049
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('ip') == '/sbin/ip'
    assert get_bin_path('ip', opt_dirs=['/usr/bin']) == '/usr/bin/ip'
    assert get_bin_path('ip', opt_dirs=['/usr/bin'], required=True) == '/usr/bin/ip'
    try:
        get_bin_path('nonexistent', opt_dirs=['/usr/bin'])
        assert False, "Expected ValueError"
    except ValueError:
        pass

# Generated at 2022-06-11 01:25:27.025639
# Unit test for function get_bin_path
def test_get_bin_path():

    assert 'sh' == os.path.basename(get_bin_path('sh', []))

# Generated at 2022-06-11 01:25:38.811456
# Unit test for function get_bin_path
def test_get_bin_path():
    # the 'sed' binary should exist on all platforms
    assert get_bin_path('sed')
    # a spin loop is as close as we can get to a blocking
    # assert that raises an exception
    while True:
        try:
            get_bin_path('nonexistent-executable')
        except ValueError:
            break

    # test for optional argument opt_dirs
    # the 'ls' binary should exist on all platforms
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/local/bin'])
    # a spin loop is as close as we can get to a blocking
    # assert that raises an exception
    while True:
        try:
            get_bin_path('ls', opt_dirs=['nonexistent-path'])
        except ValueError:
            break

# Generated at 2022-06-11 01:25:58.580785
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/bin'], False) == '/usr/bin/sh'
    # get_bin_path raises ValueError if exec not found, so this line raises an exception:
    # get_bin_path('bogus')
    # the next two lines are the same, but the first one is to test deprecated required parameter:
    assert get_bin_path('bogus', [], False) == '/bin/bogus'
    assert get_bin_path('bogus', []) == '/bin/bogus'

# Generated at 2022-06-11 01:26:08.810304
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        bin_path = get_bin_path('foo', required=False)
        assert False, 'Expected ValueError'
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    bin_path = get_bin_path('ls')
    assert bin_path == '/bin/ls'
    bin_path = get_bin_path('ls', opt_dirs=[ '/bin' ])
    assert bin_path == '/bin/ls'
    bin_path = get_bin_path('ls', opt_dirs=[ '/bin', '/usr/bin' ])
    assert bin_path == '/bin/ls'
    bin_path = get_bin_path('ls', opt_dirs=[ '/usr/bin' ])
    assert bin_path == '/usr/bin/ls'
    bin

# Generated at 2022-06-11 01:26:10.436849
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-11 01:26:19.939136
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.file import is_executable

    # Temporary binary file
    tmp_bin = '/tmp/binpath_' + to_bytes(os.getpid())

    # Simple tests
    try:
        # No binary
        get_bin_path(tmp_bin)
        assert False, "Expected ValueError"
    except ValueError:
        pass

    # Create simple binary file as executable
    open(tmp_bin, 'w').write('#!/bin/sh\nexit 0')
    os.chmod(tmp_bin, 0o755)
    assert is_executable(tmp_bin)

    # Test with the binary

# Generated at 2022-06-11 01:26:23.337105
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('ls')
    assert os.path.isfile(bin_path)
    assert os.path.isabs(bin_path)
    assert os.access(bin_path, os.X_OK)


# this is required if this module is being run by itself
if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-11 01:26:24.457196
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'

# Generated at 2022-06-11 01:26:25.681102
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/bin/sh' == get_bin_path('sh', ['/bin'])

# Generated at 2022-06-11 01:26:35.690272
# Unit test for function get_bin_path
def test_get_bin_path():
    import platform
    import subprocess

    if platform.system() != "Linux":
        raise ValueError("test_get_bin_path: Test only supported on Linux.")

    # Test specific cases
    assert get_bin_path("/usr/bin/python") == "/usr/bin/python"

    assert get_bin_path("python") == "/usr/bin/python"

    try:
        get_bin_path("__MISSING_BINARY__")
        raise AssertionError("Failed to raise ValueError")
    except ValueError:
        pass

    # Test behavior when optional parameters are set
    #
    # get_bin_path(arg, opt_dirs, required=None)
    #
    # required is deprecated in favor of the generic raise ValueError for missing binaries. It will no longer behave
    # as previous versions

# Generated at 2022-06-11 01:26:43.880074
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Function get_bin_path is tested'''

    # Test for the case executable is found
    try:
        get_bin_path('sh')
    except Exception as e:
        raise AssertionError('Unexpected exception: %s' % str(e))

    # Test for the case executable is not found
    try:
        get_bin_path('nonexisting_executable')
    except ValueError as e:
        if 'Failed to find required executable' not in str(e):
            raise AssertionError('Unexpected exception: %s' % str(e))
    except Exception as e:
        raise AssertionError('Unexpected exception: %s' % str(e))

# Generated at 2022-06-11 01:26:51.386535
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    # test with optional path and empty PATH
    assert get_bin_path('ls', opt_dirs=['/usr/bin'], required=False) == '/usr/bin/ls'
    try:
        get_bin_path('ls', opt_dirs=[], required=False)
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-11 01:27:04.365234
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path("ansible-doc")
    assert(bin_path is not None)
    # assume path to ansible-doc is absolute
    assert(len(bin_path) > 0 and bin_path[0] == "/")

# Generated at 2022-06-11 01:27:15.475105
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Returns true if get_bin_path() returns expected path
    '''
    from ansible.module_utils.common._text import to_bytes
    # find in PATH
    res = get_bin_path('cp')
    assert os.path.exists(res)
    assert os.path.exists(res) and not os.path.isdir(res)
    assert res == to_bytes(res)
    assert is_executable(res)
    # find in PATH (and also in /sbin)
    res = get_bin_path('kpartx')
    assert os.path.exists(res)
    assert os.path.exists(res) and not os.path.isdir(res)
    assert res == to_bytes(res)
    assert is_executable(res)
    #

# Generated at 2022-06-11 01:27:24.378177
# Unit test for function get_bin_path

# Generated at 2022-06-11 01:27:33.973805
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # create a fake command to test
    (handle, test_bin) = tempfile.mkstemp(prefix='ansible_test_cmd_')
    os.close(handle)
    with open(test_bin, 'wb') as f:
        f.write(b'#!/bin/sh')
        f.close()
    os.chmod(test_bin, 0o755)


# Generated at 2022-06-11 01:27:37.027518
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        result = get_bin_path('cat')
    except ValueError as e:
        assert False, 'Test failed with exception: %s' % e


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-11 01:27:44.711381
# Unit test for function get_bin_path
def test_get_bin_path():
    for executable, path in [('ls', '/bin/ls'), ('/bin/ls', '/bin/ls'), ('cat', '/bin/cat')]:
        assert get_bin_path(executable) == path
        assert get_bin_path(path) == path

    # Test the option directories
    assert get_bin_path('ls', ['/bin']) == '/bin/ls'
    assert get_bin_path('ls', ['/tmp']) == '/bin/ls'
    assert get_bin_path('ls', ['/tmp', '/bin']) == '/bin/ls'

    # Test searching directories in PATH
    os.environ['PATH'] = '/tmp'
    assert get_bin_path('ls', ['/bin']) == '/tmp/ls'

    # Test not finding executable

# Generated at 2022-06-11 01:27:55.050971
# Unit test for function get_bin_path
def test_get_bin_path():
    """ get_bin_path -- unit test routine
    Note that unit tests are much easier to understand if they use constants
    instead of the mocks (as the mocks do). As the mocks are quite complex and
    use many different formats of output (in order to be useful as mocks).

    :return: True if all tests pass, False if any test fails
    """
    try:
        import __builtin__
        builtins = __builtin__
    except ImportError:
        import builtins
    builtins.__dict__['os'] = {}
    result = get_bin_path('pwd')
    assert result == '/bin/pwd'
    result = get_bin_path('foo')
    assert result == '/bin/foo'
    result = get_bin_path('/bin/pwd')

# Generated at 2022-06-11 01:28:07.101413
# Unit test for function get_bin_path
def test_get_bin_path():

    # Test with invalid executable
    try:
        get_bin_path('foobar')
    except ValueError:
        pass

    # Test with valid executable from PATH
    test_bin = get_bin_path('sh')
    assert test_bin.endswith('/sh')
    assert os.path.exists(test_bin)
    assert os.path.isdir(test_bin) == False
    assert is_executable(test_bin) == True

    # Test with valid executable from PATH and optional list of directories
    test_bin = get_bin_path('sh', opt_dirs=['/bin', '/usr/bin'])
    assert test_bin.endswith('/sh')
    assert os.path.exists(test_bin)
    assert os.path.isdir(test_bin) == False


# Generated at 2022-06-11 01:28:15.156552
# Unit test for function get_bin_path
def test_get_bin_path():

    assert get_bin_path("python") == "/usr/bin/python"

    opt_dirs = ['/opt/bin/', '/tmp']
    bin_path = get_bin_path("python", opt_dirs)
    assert "/opt/bin/python" == bin_path
    bin_path = get_bin_path("python", opt_dirs, required=True)
    assert "/opt/bin/python" == bin_path
    try:
        bin_path = get_bin_path("not-python", opt_dirs, required=True)
    except ValueError:
        assert True == True
    else:
        assert False == True

    try:
        bin_path = get_bin_path("not-python", opt_dirs)
    except ValueError:
        assert True == True

# Generated at 2022-06-11 01:28:26.803931
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test case 1: arg = 'python'
    # Expected result: The path for the 'python' command
    print('========= Running test_get_bin_path 1 =========')
    result = get_bin_path('python')
    print(result)
    assert result.endswith('/python')

    # Test case 2: arg = 'random_program'
    # Expected result: ValueError exception
    print('========= Running test_get_bin_path 2 =========')
    try:
        result = get_bin_path('random_program')
        print(result)
    except ValueError as e:
        print('Exception: %s' %e)
    else:
        raise Exception('get_bin_path() did not raise expected ValueError exception')

    # Test case 3: arg = 'python', opt_dirs

# Generated at 2022-06-11 01:28:46.733088
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/echo') == '/bin/echo'
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('echo', opt_dirs=['/usr/bin']) == '/usr/bin/echo'
    assert get_bin_path('echo', opt_dirs=['/bin', '/usr/bin']) == '/bin/echo'
    assert get_bin_path('echo', opt_dirs=['/usr/bin', '/bin']) == '/bin/echo'
    assert get_bin_path('echo', opt_dirs=['/usr/bin', '/bin', '/sbin']) == '/bin/echo'

# Generated at 2022-06-11 01:28:56.944286
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for get_bin_path
    '''
    assert get_bin_path('/usr/bin/true', ['/usr/bin']) == '/usr/bin/true'
    assert get_bin_path('/bin/false', ['/usr/bin']) is None
    assert get_bin_path('true', ['/usr/bin']) == '/usr/bin/true'
    assert get_bin_path('/bin/true', ['/usr/bin']) == '/bin/true'
    try:
        get_bin_path('/bin/false', ['/usr/bin'])
        assert False, 'Expected ValueError'
    except ValueError:
        pass  # Expected ValueError


# Generated at 2022-06-11 01:29:01.467215
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path("abcdefg", required=True)
        assert False
    except ValueError as e:
        assert e.args[0] == "Failed to find required executable \"abcdefg\" in paths: /usr/bin:/bin"
    assert get_bin_path("sh") == "/bin/sh"

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-11 01:29:11.103277
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    with tempfile.NamedTemporaryFile() as test_file:
        test_file_path = test_file.name
        test_bin = os.path.basename(test_file_path)
        test_dir = os.path.dirname(test_file_path)

        os.chmod(test_file.name, 0o755)
        # assert that we can find our test_bin in a path we can control
        assert get_bin_path(test_bin, [test_dir]) == test_file_path

        os.chmod(test_file.name, 0o0)
        # assert that the test_bin isn't found because it isn't executable