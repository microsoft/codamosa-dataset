

# Generated at 2022-06-11 01:19:13.866474
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') is not None

# Generated at 2022-06-11 01:19:21.978645
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes

    assert get_bin_path('python') == get_bin_path(to_bytes('python')) == get_bin_path('python2') == get_bin_path(to_bytes('python2'))

    assert get_bin_path('python3') == get_bin_path(to_bytes('python3'))

    # Test that get_bin_path raises exception if it can't find the executable
    got_expected = False
    try:
        get_bin_path('invoke_not_installed')
    except ValueError:
        got_expected = True
    assert got_expected is True

# Generated at 2022-06-11 01:19:30.249361
# Unit test for function get_bin_path
def test_get_bin_path():
    for cmd in ['sh', 'bash', 'echo']:
        path = get_bin_path(cmd)
        assert path.endswith(cmd)

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    with patch.object(os.path, 'exists', return_value=True):
        with patch.object(os, 'access', return_value=True):
            try:
                get_bin_path('not_here')
                assert False
            except ValueError:
                assert True

            try:
                get_bin_path('not_here_either', opt_dirs=['/usr/local/bin'])
                assert False
            except ValueError:
                assert True


# Generated at 2022-06-11 01:19:39.002159
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat
    import sys

    # create a temp directory
    tmpdir = tempfile.mkdtemp()

    # add a test file to this directory
    test_file = os.path.join(tmpdir, 'test')
    f = open(test_file, 'w')
    f.write('test')
    f.close()

    # make it executable
    os.chmod(test_file, stat.S_IRWXU)

    if sys.platform == 'win32':
        # Test case for windows
        import ntsecuritycon
        test_dir = tmpdir.lower()
        test_file = test_file.lower()
        paths = [test_dir]

        # Remove execute permissions from test directory
        # on Windows. It should still return the path
        # to

# Generated at 2022-06-11 01:19:50.261032
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.file import is_executable
    from ansible.module_utils.common.file import get_bin_path
    import os

    # make sure is_executable works
    assert is_executable('/bin/echo') is True
    assert is_executable('/bin/non-existing-file') is False

    # make sure get_bin_path raises expected errors
    try:
        get_bin_path('non-existing-file', opt_dirs=['/'], required=False)
        assert False, 'Expected ValueError'
    except ValueError:
        pass

    # make sure get_bin_path returns correct path
    assert get_bin_path('echo') == '/bin/echo'

# Generated at 2022-06-11 01:19:52.201844
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('$$') is None

# Generated at 2022-06-11 01:20:00.305321
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Test different call patterns of get_bin_path
    """

    # Test get_bin_path with valid argument
    assert get_bin_path('cowsay')

    # Test get_bin_path with valid argument and optional path
    assert get_bin_path('cowsay', opt_dirs=['/usr/games'])

    # Test get_bin_path with None argument
    try:
        get_bin_path(None)
    except Exception as e:
        assert type(e) == ValueError

    # Test get_bin_path with invalid argument
    try:
        get_bin_path('bogus_executable')
    except Exception as e:
        assert type(e) == ValueError

# Generated at 2022-06-11 01:20:10.576482
# Unit test for function get_bin_path
def test_get_bin_path():
    """Test get_bin_path function."""
    # Any executable could be used here, we use /bin/true as a fallback if not present
    # There are two cases:
    #   1. Executable exists in "/bin" (or "/usr/bin") => should be found
    #   2. Executable doesn't exist in "/bin" => should not be found
    #   3. Executable exists in path but not in any directory in PATH => should be found
    #   4. Executable doesn't exist in PATH => should not be found

    # Case 1 - get_bin_path should return full path to the executable
    true_bin_path = get_bin_path('true')
    print('true_bin_path:', true_bin_path)
    assert os.path.exists(true_bin_path)

    # Case 2 -

# Generated at 2022-06-11 01:20:21.166036
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/sbin/ip' == get_bin_path('ip')
    assert '/sbin/ip' == get_bin_path('ip', ['/sbin', '/usr/sbin'])
    assert '/sbin/grep' == get_bin_path('grep', ['/sbin', '/usr/sbin'])
    assert '/usr/bin/grep' == get_bin_path('grep', ['/usr/bin'])
    assert '/usr/bin/grep' == get_bin_path('grep', ['/usr/bin', '/usr/sbin'])
    assert '/usr/bin/grep' == get_bin_path('grep', ['/usr/bin', '/usr/sbin', '/sbin'])

# Generated at 2022-06-11 01:20:24.555937
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'



# Generated at 2022-06-11 01:20:38.983818
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test retrieving common executable from /sbin
    assert get_bin_path('ip') == '/sbin/ip'

    # Test retrieving executable from provided dir
    opt_dirs = ['.']
    assert get_bin_path('test_get_bin_path', opt_dirs) == os.path.abspath(__file__)

    # Test retrieving executable from provided dir
    opt_dirs = ['/usr/bin']
    assert get_bin_path('ls', opt_dirs) == '/usr/bin/ls'

    # Test retrieving executable from provided dir
    opt_dirs = ['/does/not/exist']
    assert get_bin_path('ls', opt_dirs) == '/usr/bin/ls'

    # Test retrieving executable in PATH

# Generated at 2022-06-11 01:20:45.647128
# Unit test for function get_bin_path
def test_get_bin_path():
    # Assert that non-existent path raises ValueError
    try:
        get_bin_path('nonexistent')
        assert False
    except ValueError:
        assert True

    # Assert that path to ls command is found
    bin_path = get_bin_path('ls')
    assert '/bin/ls' in bin_path

    # Assert that path to fdisk command is found
    bin_path = get_bin_path('fdisk', opt_dirs=['/sbin'])
    assert '/sbin/fdisk' in bin_path

# Generated at 2022-06-11 01:20:50.381889
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest

    if os.name == 'nt':
        cmd = 'cmd'
    else:
        cmd = '/bin/true'
    assert get_bin_path(cmd)

    with pytest.raises(ValueError):
        get_bin_path('not_a_command')

    test_bin = 'test_bin'
    test_dirs = ['/tmp']
    with open(test_bin, 'w') as f:
        f.write('#!/bin/sh\necho "$@"\n')
    os.chmod(test_bin, 0o755)
    my_path = get_bin_path(test_bin, opt_dirs=test_dirs)
    assert my_path == test_bin
    os.remove(test_bin)

# Generated at 2022-06-11 01:20:54.129998
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('dd') == get_bin_path('dd')
    assert get_bin_path('dd') != get_bin_path('ls')
    assert get_bin_path('dd') != get_bin_path('cat')

    assert 'dd' in get_bin_path('dd')
    assert 'dd' not in get_bin_path('ls')
    assert 'dd' not in get_bin_path('cat')

    assert 'ls' in get_bin_path('ls')
    assert 'ls' not in get_bin_path('dd')
    assert 'ls' not in get_bin_path('cat')

    assert 'cat' in get_bin_path('cat')
    assert 'cat' not in get_bin_path('dd')

# Generated at 2022-06-11 01:21:01.815992
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('missing_executable')
        assert False
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "missing_executable" in paths: /usr/bin:/bin'

    # Test that we find the executable in opt_dirs first
    assert get_bin_path('false', opt_dirs=['/bin', '/usr/bin']) == '/bin/false'

# Generated at 2022-06-11 01:21:03.297021
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-11 01:21:03.935598
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-11 01:21:12.026666
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        bin_path = get_bin_path('/usr/bin/python')
        assert bin_path == '/usr/bin/python'
    except ValueError:
        assert False, 'Unexpected ValueError exception'

    # test for the default opt_dirs value (empty list)
    try:
        bin_path = get_bin_path('/usr/bin/python', opt_dirs=None)
        assert bin_path == '/usr/bin/python'
    except ValueError:
        assert False, 'Unexpected ValueError exception'

    # test for an invalid opt_dirs value (non-empty string)

# Generated at 2022-06-11 01:21:20.592462
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.network import get_bin_path
    from ansible.module_utils._text import to_bytes

    assert get_bin_path('sh') == to_bytes(get_bin_path('sh'))
    assert get_bin_path('sh') == get_bin_path('sh', ['/bin', '/usr/local/bin'])
    assert get_bin_path('sh', ['/bin', '/usr/bin']) == get_bin_path('sh')
    assert get_bin_path('sh', ['/bin/']) == get_bin_path('sh', ['/bin'])

# Generated at 2022-06-11 01:21:21.487750
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh')

# Generated at 2022-06-11 01:21:32.981928
# Unit test for function get_bin_path
def test_get_bin_path():
    import mock
    from ansible.module_utils.six import PY3

    if PY3:
        import builtins  # pylint: disable=import-error
        open_mock = mock.Mock(return_value=io.BytesIO(b'#!/usr/bin/python3'))
        builtins.open = open_mock
    else:
        import __builtin__
        open_mock = mock.Mock(return_value=io.BytesIO(b'#!/usr/bin/python'))
        __builtin__.open = open_mock

    assert '/bin/ls' == get_bin_path('ls')
    assert '/bin/ls' == get_bin_path('ls', [])
    assert '/bin/ls' == get_bin_path('ls', ['/bin'])

# Generated at 2022-06-11 01:21:43.359054
# Unit test for function get_bin_path
def test_get_bin_path():
    # Verify environment is expected
    os.environ['PATH'] = '/bin:/usr/bin:/usr/local/bin'

    # Verify executable is found in PATH
    assert get_bin_path('awk') == '/usr/bin/awk'

    # Verify executable is found in optional PATH
    assert get_bin_path('date', ['/bin']) == '/bin/date'

    # Verify executable is not found in PATH
    try:
        get_bin_path('awk_notfound')
        assert False, 'get_bin_path should have failed'
    except ValueError:
        pass

    # Verify executable is not found in optional PATH
    try:
        get_bin_path('date', ['/bin', '/usr/bin'])
        assert False, 'get_bin_path should have failed'
    except ValueError:
        pass

# Generated at 2022-06-11 01:21:45.275814
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('tar')
    get_bin_path('tar', ['/bin', '/usr/bin'])

# Generated at 2022-06-11 01:21:51.445198
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('ip', opt_dirs=['/sbin']) == '/sbin/ip'
    try:
        get_bin_path('notthere')
        assert False, 'Should raise ValueError when path not found'
    except ValueError:
        pass
    try:
        get_bin_path('notthere', required=False)
        assert False, 'Should raise ValueError when path not found'
    except ValueError:
        pass

# Generated at 2022-06-11 01:22:00.690382
# Unit test for function get_bin_path
def test_get_bin_path():

    from ansible.module_utils.six import PY3

    try:
        # os.chmod fails on some NFS shares so this test is not reliable in all environments
        os.chmod('/bin/sh', 0o777)
        # test finding an executable that should be there
        get_bin_path('sh')
    except OSError:
        print("WARNING: Skipping get_bin_path unit test due to inability to change permissions on /bin/sh")
        return

    # test finding an executable that should not be there
    try:
        get_bin_path('/bin/this_file_should_not_exist')
        assert False, "Expected ValueError not raised"
    except ValueError:
        pass

    # test finding an executable that exists but the permissions do not allow execution

# Generated at 2022-06-11 01:22:02.250554
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-11 01:22:13.238460
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    import ansible.module_utils.common.file

    # call a function with only options
    assert get_bin_path('sh')

    # call a function with no options
    assert get_bin_path('sh')

    # call a function with a file not found
    try:
        assert get_bin_path('/bin/notexists')
    except ValueError:
        pass

    # call a function with a file and a dir in the same path
    path = get_bin_path('sh')
    assert path

    # call a function with required = True

# Generated at 2022-06-11 01:22:23.913770
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    # Create temporary paths
    tmp_dir = tempfile.mkdtemp()
    tmp_dir1 = os.path.join(tmp_dir, 'tmp_dir1')
    tmp_dir2 = os.path.join(tmp_dir, 'tmp_dir2')
    tmp_dir3 = os.path.join(tmp_dir, 'tmp_dir3')
    os.makedirs(tmp_dir1)
    os.makedirs(tmp_dir2)
    os.makedirs(tmp_dir3)


# Generated at 2022-06-11 01:22:28.584479
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('python')
    except Exception as e:
        assert False, e.message

    try:
        get_bin_path('python_not_available')
    except Exception as e:
        assert e.message == 'Failed to find required executable "python_not_available" in paths: /usr/bin:/bin:/usr/sbin:/sbin'

# Generated at 2022-06-11 01:22:29.493855
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')

# Generated at 2022-06-11 01:22:39.532262
# Unit test for function get_bin_path
def test_get_bin_path():

    import ansible.module_utils.common.file as utils_file
    utils_file.__file__ = 'ansible/module_utils/common/file.py'

    my_bin_path = os.path.join('/opt', 'bin')
    os.environ['PATH'] = my_bin_path
    bin_path = get_bin_path('ls')
    assert bin_path == os.path.join(my_bin_path, 'ls')

    # Test optional arguments
    my_env_path = os.path.join('/usr', 'bin')
    os.environ['PATH'] = my_env_path
    opt_dirs = [my_bin_path]
    bin_path = get_bin_path('ls', opt_dirs)
    assert bin_path == os.path.join

# Generated at 2022-06-11 01:22:44.680308
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('true')
    try:
        get_bin_path('this_will_never_exist_and_hopefully_not_be_created')
    except ValueError:
        pass
    else:
        raise Exception("Expected ValueError not raised")
    assert is_executable(get_bin_path('true'))

# Generated at 2022-06-11 01:22:47.848839
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('does_not_exist') == None
    assert get_bin_path('cat', ['/bin', '/usr/bin']) == '/bin/cat'

# Generated at 2022-06-11 01:22:58.884307
# Unit test for function get_bin_path
def test_get_bin_path():

    import tempfile
    import shutil
    import stat

    tempdir = tempfile.mkdtemp()
    orig_path = os.environ['PATH']
    os.environ['PATH'] = tempdir

    fname = os.path.join(tempdir, 'test_exec')
    with open(fname, 'w') as f:
        f.write('test_exec')
    os.chmod(fname, stat.S_IRWXU)

    # Regular case
    assert get_bin_path('test_exec') == fname

    # Non-existing executable
    try:
        get_bin_path('not_exec')
    except ValueError as e:
        pass
    else:
        assert False, 'Exception not raised'

    # Non-executable file

# Generated at 2022-06-11 01:23:05.589567
# Unit test for function get_bin_path
def test_get_bin_path():
    # test failure
    try:
        get_bin_path('nonexistent_executable_file')
        assert False
    except ValueError:
        pass

    # test success
    from subprocess import Popen, PIPE
    proc = Popen(['which', 'which'], stdout=PIPE)
    bin_path = proc.communicate()[0].rstrip()
    assert get_bin_path('which') == bin_path

# Generated at 2022-06-11 01:23:06.334057
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python')



# Generated at 2022-06-11 01:23:13.070041
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import tempfile
    import shutil

    # create a fake ssh executable
    temp_dir = tempfile.mkdtemp()
    fake_ssh = '''#!/bin/sh
    echo "Fake ssh program"
    '''
    with open(os.path.join(temp_dir, 'ssh'), 'w') as f:
        f.write(fake_ssh)
    os.chmod(os.path.join(temp_dir, 'ssh'), 0o755)


# Generated at 2022-06-11 01:23:21.147230
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('get_bin_path_test_bin')
        assert False, 'cmd not found, ValueError should have been raised'
    except ValueError:
        pass

    try:
        get_bin_path('get_bin_path_test_bin', opt_dirs='/path_does_not_exist')
        assert False, 'cmd not found, ValueError should have been raised'
    except ValueError:
        pass

    test_cmd = 'tests/utils/module_utils/test_bin'
    assert get_bin_path(test_cmd, opt_dirs=None) == os.path.join(os.getcwd(), test_cmd)

# Generated at 2022-06-11 01:23:29.586132
# Unit test for function get_bin_path
def test_get_bin_path():
    def check_get_bin_path(arg, expected_path=None, opt_dirs=None):
        path = get_bin_path(arg, opt_dirs=opt_dirs)
        assert path == expected_path

    my_env = os.environ.copy()
    my_env['PATH'] = '/usr/bin:/bin:/usr/local/bin'

    check_get_bin_path('cat', '/usr/bin/cat')
    check_get_bin_path('cat', '/bin/cat', opt_dirs=['/bin'])
    with pytest.raises(ValueError):
        get_bin_path('cat', opt_dirs=['/bin/bogus'])

    # test with default arguments
    check_get_bin_path('cat', '/bin/cat')
    #

# Generated at 2022-06-11 01:23:32.882618
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Make sure we can find various utils used by the module.
    '''
    def check(executable):
        assert get_bin_path(executable) is not None

    check('which')
    check('gcc')
    check('python')

# Generated at 2022-06-11 01:23:53.516080
# Unit test for function get_bin_path
def test_get_bin_path():
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.join(test_dir, 'test_utils_get_bin_path_dir')
    test_executable = os.path.join(test_dir, 'test_executable')
    os.environ['PATH'] = test_dir
    assert get_bin_path('test_executable') == test_executable
    assert get_bin_path('test_executable', opt_dirs=['/tmp']) == test_executable
    assert get_bin_path('test_executable', opt_dirs=['/tmp', test_dir + '/tmp']) == test_executable

# Generated at 2022-06-11 01:23:55.512349
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Unit test for function get_bin_path()'''

    # Test if get_bin_path can find python
    path = get_bin_path('python', ['/usr/local/bin'])

    if path:
        return True

    return False

# Generated at 2022-06-11 01:24:03.891782
# Unit test for function get_bin_path
def test_get_bin_path():
    import subprocess
    bin_path = None

    # test get_bin_path raises ValueError
    try:
        get_bin_path('absent_bin_path')
    except ValueError:
        assert True
    else:
        assert False

    # test get_bin_path returns properly
    try:
        bin_path = get_bin_path('python')
    except ValueError:
        assert False
    if not bin_path:
        assert False

# Generated at 2022-06-11 01:24:11.920054
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with PATH and custom opt_dirs
    path = get_bin_path('cat', opt_dirs=['/bin', '/usr/bin'])
    assert path == '/bin/cat'

    # Test with PATH not having /usr/sbin
    path = get_bin_path('ifconfig')
    assert path == '/sbin/ifconfig'

    # Test with PATH having /usr/sbin
    path = get_bin_path('mount')
    assert path == '/bin/mount'

    # Test without PATH
    path = get_bin_path('mount', opt_dirs=['/bin'])
    assert path == '/bin/mount'

    # Test without PATH or opt_dirs
    try:
        get_bin_path('mount')
    except Exception:
        pass
    else:
        raise Ass

# Generated at 2022-06-11 01:24:24.340452
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == get_bin_path('sh')
    assert get_bin_path('sh').endswith(os.path.join('bin', 'sh'))

    expected = get_bin_path('sh')
    result = get_bin_path('sh', opt_dirs=['/bin'])
    assert expected == result

    from ansible.module_utils.common.collections import ImmutableDict
    expected = get_bin_path('sh')
    expected_paths = os.environ.get('PATH', '').split(os.pathsep) + ['/sbin', '/usr/sbin', '/usr/local/sbin']
    result = get_bin_path('sh', opt_dirs=['/bin'], required=True)
    result_paths = os.en

# Generated at 2022-06-11 01:24:32.817605
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import tempfile
    bin_dir = tempfile.mkdtemp()
    test_path = os.path.join(bin_dir, 'bin_path_test')
    with open(test_path, 'w') as f:
        f.write("#!/bin/sh\necho")
    os.chmod(test_path, 0o755)
    assert get_bin_path('bin_path_test', [bin_dir]) == test_path

    from shutil import rmtree
    rmtree(bin_dir)

# Generated at 2022-06-11 01:24:34.190606
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('example_exe', required=True)
        assert False
    except ValueError:
        pass

    try:
        get_bin_path('example_exe')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 01:24:44.985203
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check that the supplied argument exists in PATH (use the utility "id" to do the test)
    id_path = get_bin_path("id")
    assert os.path.isabs(id_path)
    assert os.path.isfile(id_path)

    # Check that the supplied argument exists in opt_dirs (/usr/bin)
    bin_path = get_bin_path("id", opt_dirs=["/usr/bin"])
    assert os.path.isabs(bin_path)
    assert os.path.isfile(bin_path)

    # Check that the supplied argument exists in opt_dirs (should be /bin/id)
    bin_path = get_bin_path("id", opt_dirs=["/bin"])
    assert os.path.isabs(bin_path)


# Generated at 2022-06-11 01:24:48.868492
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('/bin/echo')
    if not bin_path == '/bin/echo':
        raise Exception("test_get_bin_path failed, /bin/echo was not found")

# Generated at 2022-06-11 01:24:52.887575
# Unit test for function get_bin_path
def test_get_bin_path():

    # test with simple binary on PATH
    testbin_path = get_bin_path('which')
    assert testbin_path != None

    # test with fake binary on PATH
    try:
        get_bin_path('thisbinarydoesnotexist')
        assert False
    except:
        pass


# Generated at 2022-06-11 01:25:11.835891
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path
    '''
    # Create temporary directory
    import tempfile
    tmpdir = tempfile.mkdtemp()

    # Create directory structure
    #
    #  /
    #  ├── bin
    #  │   └── ping
    #  ├── sbin
    #  │   └── ping
    #  └── etc
    #      ├── ansible
    #      │   └── ansible.cfg
    #      └── ansible.cfg
    #
    for d in ['/bin', '/sbin', '/etc', '/etc/ansible']:
        os.mkdir(tmpdir + d)


# Generated at 2022-06-11 01:25:19.964371
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat', ['/usr/local/bin/']) == '/usr/local/bin/cat'
    assert get_bin_path('cat', ['/usr/local/bin/', '/usr/bin/']) == '/usr/bin/cat'
    # PATH: /bin and /usr/bin
    assert get_bin_path('cat', ['/usr/local/bin/']) == '/bin/cat'
    assert get_bin_path('cat', ['/usr/local/bin/', '/usr/bin/']) == '/usr/bin/cat'

# Generated at 2022-06-11 01:25:29.038600
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    # Test with required = None (used to be default, will be default in 2.14)
    try:
        get_bin_path(sys.executable)
    except ValueError:
        assert False, 'Failed to find required executable on PATH'

    try:
        get_bin_path('doesntexist')
        assert False, 'Should have raised error. Binary "doesntexist" not found on PATH'
    except ValueError:
        pass

    # Test with required = False
    assert get_bin_path(sys.executable, required=False)

    assert get_bin_path('doesntexist', required=False) is None

# Generated at 2022-06-11 01:25:40.559194
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import filecmp

    # Test1: try to find an executable that doesn't exist in expected places
    got_exception = False
    path = 'no_hope'
    try:
        bp = get_bin_path(path)
    except ValueError:
        got_exception = True
    assert got_exception

    # Test2: try to find an executable that does exist in expected places
    for path in ['cat', 'curl']:
        bp = get_bin_path(path)
        assert os.path.exists(bp)

    # Test3: try to find an executable that does exist in a specified location
    # create a temporary directory with a script in it
    # check that we can find it
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-11 01:25:48.105373
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Get path of executable using arg as executable name to search.
    '''
    paths = os.environ.get('PATH', '').split(os.pathsep)
    exe = 'ssh'
    bin_path = get_bin_path(exe)

    assert bin_path == '/usr/bin/ssh'
    assert is_executable(bin_path) is True
    # Test with optional dirs
    bin_path = get_bin_path(exe, ['/usr/bin'])
    assert bin_path == '/usr/bin/ssh'
    assert is_executable(bin_path) is True
    # Test with optional dirs where command is not found in one of the dirs
    bin_path = get_bin_path(exe, ['/usr/bin', '/usr/bin2'])
   

# Generated at 2022-06-11 01:25:56.786329
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('ansible') == '/usr/local/bin/ansible'
    assert get_bin_path('ansible', opt_dirs=['/usr/local/bin']) == '/usr/local/bin/ansible'
    assert get_bin_path('ansible', opt_dirs=['/usr/sbin']) == '/usr/sbin/ansible'
    assert get_bin_path('ansible', opt_dirs=['/usr/sbin', '/usr/local/bin']) == '/usr/local/bin/ansible'

# Generated at 2022-06-11 01:25:59.312209
# Unit test for function get_bin_path
def test_get_bin_path():
    def get_bin_path_run():
        return get_bin_path('getent')

    assert get_bin_path_run() is not None

    try:
        get_bin_path('getent123')
    except ValueError:
        pass
    else:
        assert False

    try:
        get_bin_path('/bin/getent')
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-11 01:26:09.574123
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('ls')
    assert path == '/bin/ls' or path == '/usr/bin/ls'
    path = get_bin_path('gsed')
    assert path == '/bin/sed' or path == '/usr/bin/sed'
    path = get_bin_path('true')
    assert path == '/bin/true' or path == '/usr/bin/true'
    path = get_bin_path('/bin/true')
    assert path == '/bin/true'
    path = get_bin_path('/bin/true', opt_dirs=['/bin', '/usr/bin'])
    assert path == '/bin/true'

# Generated at 2022-06-11 01:26:16.525936
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('printf', ['/bin', '/usr/bin']) == '/bin/printf'
    # if in path, use first instance
    assert get_bin_path('printf', ['/bin', '/sbin', '/usr/sbin', '/usr/local/sbin']) == '/sbin/printf'
    # if not in path, raise ValueError
    try:
        get_bin_path('no_such_binary', ['/bin'])
        assert(False)
    except ValueError:
        pass

# Generated at 2022-06-11 01:26:25.047394
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test search path function
    try:
        assert get_bin_path('/usr/bin/sh') == '/usr/bin/sh'
        assert get_bin_path('sh') == '/usr/bin/sh'
        # On Windows we can't do this really
        if not os.name == 'nt':
            assert get_bin_path('cat') == '/bin/cat'
            assert get_bin_path('/bin/cat') == '/bin/cat'
    except ValueError:
        raise AssertionError("Failed to find required executable")
    try:
        get_bin_path('doesnotexist')
        raise AssertionError("Did not raise ValueError when required executable was not found")
    except ValueError:
        pass

# Generated at 2022-06-11 01:26:52.849073
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    if sys.platform == 'win32':
        import ctypes
        from ctypes import c_long, c_int, c_char_p, WINFUNCTYPE
        from ctypes.wintypes import BOOL, HANDLE, DWORD, LPCWSTR, LPWSTR

        CloseHandle = WINFUNCTYPE(BOOL, HANDLE)(('CloseHandle', ctypes.windll.kernel32))
        CreateFileW = WINFUNCTYPE(HANDLE, LPCWSTR, DWORD, DWORD, c_long, DWORD, DWORD, HANDLE)(('CreateFileW', ctypes.windll.kernel32))

# Generated at 2022-06-11 01:26:58.768162
# Unit test for function get_bin_path
def test_get_bin_path():
    # Assumes that this program, src/lib/ansible/module_utils/basic.py, is installed in /bin, /sbin, or /usr/bin.
    #
    # Test that we can find the path to basic by just specifying the name, with extensions, and with extensions
    # that aren't executable
    path = get_bin_path('basic.py')
    assert path.endswith('/basic.py')
    assert is_executable(path)
    assert not os.path.exists(path + '.notexecutable')
    path1 = get_bin_path('basic.py.notexecutable')
    assert path1.endswith('/basic.py.notexecutable')
    assert not is_executable(path1)
    path2 = get_bin_path('basic.pyc')
    assert path

# Generated at 2022-06-11 01:27:05.395974
# Unit test for function get_bin_path
def test_get_bin_path():
    from distutils.spawn import find_executable
    assert get_bin_path('env') == find_executable('env')
    assert get_bin_path('env', opt_dirs=[]) == find_executable('env')
    assert get_bin_path('env', opt_dirs=['/bin']) == find_executable('env')
    assert get_bin_path('env', opt_dirs=['/foo']) == find_executable('env')



# Generated at 2022-06-11 01:27:16.497810
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import sys
    import traceback
    import threading

    tmpdir = tempfile.mkdtemp()
    def _is_executable(path):
        return True

    def _mock_module_utils_common_file_is_executable(path):
        return _is_executable(path)

    orig_is_executable = __import__('ansible.module_utils.common.file', fromlist=['is_executable']).is_executable

# Generated at 2022-06-11 01:27:25.049535
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-11 01:27:34.405217
# Unit test for function get_bin_path
def test_get_bin_path():
    def mock_is_executable(path):
        return True


# Generated at 2022-06-11 01:27:42.944803
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat
    import os
    import stat


# Generated at 2022-06-11 01:27:53.023909
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ['PATH'] = '/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin:/usr/local/sbin'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', ['/usr/bin', '/usr/local/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', ['/usr/bin', '/usr/local/bin'], required=False) == '/usr/bin/ls'

    try:
        assert get_bin_path('false') == '/bin/false'
    except ValueError:
        assert True


# Generated at 2022-06-11 01:27:56.266195
# Unit test for function get_bin_path
def test_get_bin_path():
    path, err, rc = module.run_command("which xargs")
    assert rc == 0
    xargs = get_bin_path("xargs")
    assert xargs == path.rstrip()

# Generated at 2022-06-11 01:28:00.792136
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Return True if all tests pass, otherwise return False.
    '''
    try:
        get_bin_path(arg='ls')
    except ValueError as e:
        print('ValueError: %s' % str(e))
        return False
    return True



# Generated at 2022-06-11 01:28:26.908998
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['/usr/libexec', '/bin', '/usr/bin', '/sbin', '/usr/sbin', '/usr/local/bin', '/usr/local/sbin']
    assert get_bin_path('sh', paths) == '/bin/sh'
    assert get_bin_path('touch', paths) == '/bin/touch'
    assert get_bin_path('ls', paths) == '/bin/ls'
    assert get_bin_path('pwd', paths) == '/bin/pwd'
    assert get_bin_path('ifconfig', paths) == '/sbin/ifconfig'

# Generated at 2022-06-11 01:28:33.114076
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls', ['/bin']) == '/bin/ls'
    try:
        get_bin_path('ls', ['/sbin']) == '/sbin/ls'  # Expected to not find executable
        assert False  # expected to raise exception
    except:
        pass
    assert get_bin_path('ls', ['/sbin'], True) == '/sbin/ls'

# Generated at 2022-06-11 01:28:44.292367
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check that the function raises the appropriate exceptions for arg, opt_dirs and required
    try:
        get_bin_path(None)
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')
    try:
        get_bin_path('/opt/bin', None)
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')
    try:
        get_bin_path('/opt/bin', '', required=True)
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')
    # Check that the function returns the path of the executable when it is found in PATH
    abs_path = get_bin_path('ls')

# Generated at 2022-06-11 01:28:54.254749
# Unit test for function get_bin_path

# Generated at 2022-06-11 01:29:01.841949
# Unit test for function get_bin_path
def test_get_bin_path():
    path = os.environ.get('PATH', '')
    os.environ['PATH'] = '/usr/sbin:/sbin'
    if os.path.exists('/usr/sbin/nologin') and is_executable('/usr/sbin/nologin'):
        assert get_bin_path('nologin') == '/usr/sbin/nologin'
    if os.path.exists('/sbin/nologin') and is_executable('/sbin/nologin'):
        assert get_bin_path('nologin') == '/sbin/nologin'
    os.environ['PATH'] = path

# Generated at 2022-06-11 01:29:11.472940
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Create a temporary directory.
        Create a temporary file.
        Set file permissions to executable.
        Run get_bin_path against the temporary file to ensure it is found.
        Remove the temporary file.
        Remove the temporary directory.
    '''
    from tempfile import mkdtemp
    from tempfile import mkstemp
    from shutil import rmtree
    from ansible.module_utils.basic import AnsibleModule

    test_dir = mkdtemp()
    test_file_fd, test_file_path = mkstemp(dir=test_dir)
    os.chmod(test_file_path, 0o755)
    args = {'_ansible_tmpdir': test_dir, '_ansible_no_log': True}