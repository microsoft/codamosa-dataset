

# Generated at 2022-06-11 01:19:22.033754
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('false')
        assert False, "Did not fail to find false"
    except ValueError:
        pass
    assert get_bin_path('sh')
    assert get_bin_path('sh', ['/sbin', '/bin'])
    assert get_bin_path('sh', ['/sbin', '/bin'])

    try:
        get_bin_path('sh', ['/sbin', '/bin'], True)
        assert False, "Did not fail to find sh with required set"
    except ValueError:
        pass

    try:
        get_bin_path('sh', ['/not-a-direcory-123123123'])
        assert False, "Did not fail to find sh with bad additional paths"
    except ValueError:
        pass

# Generated at 2022-06-11 01:19:28.223256
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    basic test of get_bin_path function
    '''

    try:
        get_bin_path('nonexistent', required=False)
    except Exception as e:
        raise AssertionError("Function get_bin_path should not raise an exception when the executable is not found.")
    else:
        assert True

    try:
        get_bin_path('nonexistent')
    except Exception as e:
        assert True
    else:
        raise AssertionError("Function get_bin_path should raise an exception when the executable is not found.")

# Generated at 2022-06-11 01:19:31.417110
# Unit test for function get_bin_path
def test_get_bin_path():
    for executable in ['true', 'false']:
        assert get_bin_path(executable)
    try:
        get_bin_path('_this_executable_should_not_exist_')
    except ValueError:
        pass
    else:
        assert False, 'This executable should not exist'

# Generated at 2022-06-11 01:19:39.130054
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test the get_bin_path function
    '''
    # check that it finds 
    try:
        assert get_bin_path("echo") == "/bin/echo"
    except ValueError:
        assert False, "get_bin_path didn't find /bin/echo in PATH"

    try:
        assert get_bin_path("ansible-doc")
    except ValueError:
        assert False, "get_bin_path didn't find ansible-doc in PATH"

    # check that it fails
    try:
        get_bin_path("/tmp/does-not-exist")
        assert False, "get_bin_path didn't fail on nonexistent executable"
    except ValueError:
        assert True

    # check that it fails

# Generated at 2022-06-11 01:19:49.190843
# Unit test for function get_bin_path
def test_get_bin_path():
    res = get_bin_path('ls')
    assert res.endswith('ls')
    assert os.path.exists(res)
    assert os.access(res, os.X_OK)

    # Test for finding in an optional search directory
    res = get_bin_path('ls', ['/usr/bin'])
    assert res.endswith('ls')
    assert os.path.exists(res)
    assert os.access(res, os.X_OK)
    assert res.startswith('/usr/bin')

    # Test for not finding file
    try:
        res = get_bin_path('notfound')
        assert False
    except:
        assert True

# Generated at 2022-06-11 01:19:49.810086
# Unit test for function get_bin_path
def test_get_bin_path():
    result = get_b

# Generated at 2022-06-11 01:19:59.623877
# Unit test for function get_bin_path
def test_get_bin_path():
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.file import touch

    # Create a temp directory to test command search.
    tmp_path = mkdtemp()
    # Create a dummy executable.
    touch(os.path.join(tmp_path, 'foo'))
    os.chmod(os.path.join(tmp_path, 'foo'), 0o755)
    # Try to find the dummy executable.
    if os.path.isfile(get_bin_path('foo', [tmp_path])):
        rmtree(tmp_path)
    else:
        assert False, 'Failed to find foo executable with get_bin_path: %s' % to_bytes(tmp_path)

# Generated at 2022-06-11 01:20:10.126703
# Unit test for function get_bin_path
def test_get_bin_path():
    import runpy

    # set PATH so it only has . in it
    os.environ['PATH'] = '.'
    # create a python file in cwd which we can execute
    path = os.path.join(os.getcwd(), 'has_no_deps.py')
    with open(path, 'wt') as f:
        # Can't use textwrap.dedent on Python 2.6
        f.write('#!/usr/bin/python\n')
        f.write('#\n')
        f.write('# Ansible is distributed in the hope that it will be useful,\n')
        f.write('# but WITHOUT ANY WARRANTY; without even the implied warranty of\n')
        f.write('# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n')
       

# Generated at 2022-06-11 01:20:21.038951
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/bin/ls' == get_bin_path('ls')
    assert '/bin/ls' == get_bin_path('ls', ['/usr/bin', '/bin'])
    assert '/bin/ls' == get_bin_path('ls', ['/usr/bin', '/bin'], True)
    assert '/usr/bin/awk' == get_bin_path('awk', ['/bin', '/usr/bin'], True)
    assert '/bin/ls' == get_bin_path('ls', None, True)

    try:
        get_bin_path('jadfjadfkak')
    except ValueError:
        assert True
    else:
        assert False

    try:
        get_bin_path('ls', [])
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-11 01:20:30.652732
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('sh')
    assert path is not None
    assert os.path.exists(path)
    assert os.path.isfile(path)
    assert os.access(path, os.X_OK)

    # Test get_bin_path with a directory
    test_path = os.path.join(os.path.dirname(__file__), "utils_data")
    try:
        get_bin_path('sh', opt_dirs=[test_path])
        assert False
    except ValueError as e:
        assert "not found" in str(e)
    except Exception:
        assert False

# Generated at 2022-06-11 01:20:44.398034
# Unit test for function get_bin_path
def test_get_bin_path():
    PATH = os.path.expandvars(os.path.expanduser('$PATH'))
    OLD_PATH = os.path.expandvars(os.path.expanduser('$PATH'))
    HOME = os.path.expandvars(os.path.expanduser('~'))
    OLD_HOME = os.path.expandvars(os.path.expanduser('~'))
    os.environ['PATH'] = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
    os.environ['HOME'] = HOME
    scp_path = get_bin_path('scp')
    assert scp_path == '/usr/bin/scp'
    os.environ['PATH'] = OLD_PATH


# Generated at 2022-06-11 01:20:50.473389
# Unit test for function get_bin_path
def test_get_bin_path():
    path1 = get_bin_path("date")
    assert "lib64/ld-linux-x86-64.so.2" in path1
    path2 = get_bin_path("date", opt_dirs="/bin")
    assert "bin/date" in path2
    try:
        path3 = get_bin_path("date", opt_dirs="/usr/")
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-11 01:20:51.802593
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('true') == '/bin/true'
    assert get_bin_path('false') == '/bin/false'
    get_bin_path('not_exist')

# Generated at 2022-06-11 01:20:58.567199
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import platform

    if sys.platform.startswith('win'):
        assert get_bin_path("powershell.exe") is not None
        assert get_bin_path("powershell.exe", opt_dirs=["C:\\Windows\\System32"]) is not None
        assert get_bin_path("powershell.exe", opt_dirs=["C:\\Windows\\System32\\Garbage"]) is not None
        try:
            get_bin_path("powershell1.exe")
            assert False
        except ValueError:
            pass
        try:
            get_bin_path("powershell1.exe", required=True)
            assert False
        except ValueError:
            pass
    else:
        assert get_bin_path("sh") is not None

# Generated at 2022-06-11 01:21:01.211866
# Unit test for function get_bin_path
def test_get_bin_path():
    exec_path = get_bin_path("date")
    assert exec_path == "/bin/date"

# Generated at 2022-06-11 01:21:10.335249
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/usr/local/bin']) == '/usr/bin/ls'
    assert get_bin_path('echo', opt_dirs=['/usr/bin', '/usr/local/bin']) == '/usr/bin/echo'
    import shutil
    tmpdir = '/tmp/ansible-test-get_bin_path'
    if os.path.exists(tmpdir):
        shutil.rmtree(tmpdir)
    os.mkdir(tmpdir)


# Generated at 2022-06-11 01:21:17.011498
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/cat') == '/bin/cat'
    assert get_bin_path('/bin/wget') == '/usr/bin/wget'
    # assert get_bin_path('/bin/wget', required=True) == '/usr/bin/wget'  # @Deprecated: 2.10
    # assert get_bin_path('/bin/wget', required=False) == '/usr/bin/wget'  # @Deprecated: 2.10



# Generated at 2022-06-11 01:21:26.456864
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Test function get_bin_path'''

    try:
        get_bin_path('invalidpath')
        raise AssertionError('Executable not found')
    except ValueError:
        pass

    try:
        get_bin_path('invalidpath', required=True)
        raise AssertionError('Executable not found')
    except ValueError:
        pass

    try:
        get_bin_path('invalidpath', opt_dirs=[''])
        raise AssertionError('Executable not found')
    except ValueError:
        pass

    valid_path = get_bin_path('ls')
    assert valid_path.endswith('ls')

    valid_path = get_bin_path('ls', ['.'])
    assert valid_path.endswith('ls')

# Generated at 2022-06-11 01:21:28.664156
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('no_such_executable') == ''



# Generated at 2022-06-11 01:21:35.641479
# Unit test for function get_bin_path
def test_get_bin_path():
    # Bad path locations
    path_locations = ["", "/not/exists", "/usr/bin/ls" ]

    # Good path locations
    good_locations = get_bin_path('ls')

    for test in path_locations:
        try:
            get_bin_path('ls', test)
        except ValueError as e:
            assert "Failed to find required executable" in str(e)
        else:
            raise ValueError("{0} should not be a valid path".format(test))

    assert get_bin_path('ls') == good_locations

# Generated at 2022-06-11 01:21:40.841959
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('echo') == '/bin/echo'
    # Test path has been modified to include /sbin dirs
    assert get_bin_path('mkfs') == '/sbin/mkfs'

# Generated at 2022-06-11 01:21:49.894924
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('tar', opt_dirs=[]) == '/bin/tar'
    assert get_bin_path('tar', opt_dirs=['/usr/bin']) == '/usr/bin/tar'
    assert get_bin_path('bash', opt_dirs=['/home/foo']) == '/bin/bash'
    assert get_bin_path('ls', opt_dirs=['/home/foo', '/home/bar']) == '/bin/ls'
    try:
        get_bin_path('nonexistant')
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-11 01:21:56.726887
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.get_os_distribution import get_os_distribution

    (os_distro, os_version, os_major_version) = get_os_distribution()

    if os_distro == 'RedHat' or os_distro == 'CentOS':
        bin_path = get_bin_path("firewall-cmd")
        assert bin_path, "Firewall-cmd not present on the system"
    elif os_distro == 'Debian':
        bin_path = get_bin_path("ufw")
        assert bin_path, "Ufw not present on the system"
    elif os_distro == 'Ubuntu':
        bin_path = get_bin_path("ufw")
        assert bin_path, "Ufw not present on the system"

# Generated at 2022-06-11 01:21:59.276332
# Unit test for function get_bin_path
def test_get_bin_path():
    path_list = ['/test/bin', '/bin']
    bin_path = get_bin_path('ls', path_list)
    assert bin_path == '/bin/ls'

# Generated at 2022-06-11 01:22:11.084377
# Unit test for function get_bin_path
def test_get_bin_path():
    # get_bin_path expects first arg to be executable, others are optional and empty
    assert get_bin_path('/bin/true') == '/bin/true'
    assert get_bin_path('/bin/true', [], False) == '/bin/true'

    # With no optional second arg, get_bin_path will search in paths defined in
    # environment variable 'PATH'
    os.environ['PATH'] = '/bin:/usr/bin:/usr/local/bin'
    assert get_bin_path('true') == '/bin/true'
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('env') == '/usr/bin/env'

# Generated at 2022-06-11 01:22:20.759466
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import tempfile
    import shutil

    path = os.path.join(tempfile.mkdtemp(), 'testModule.py')
    open(path, 'w').close()
    os.chmod(path, 0o700)
    sys.argv = [path, '-c', 'import ansible.module_utils.basic; ansible.module_utils.basic.AnsibleModule().fail_json(msg="OK", rc=1)']

    with open(os.devnull, 'w') as null:
        m = AnsibleModule(stdin=null, stdout=null, stderr=null)

# Generated at 2022-06-11 01:22:23.197540
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-11 01:22:29.137209
# Unit test for function get_bin_path
def test_get_bin_path():
    # test with input out of PATH
    bin_path = get_bin_path('python')
    assert(bin_path)
    # test with input not in PATH
    expected_bin_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'unit')
    bin_path = get_bin_path('faux', opt_dirs=expected_bin_path)

# Generated at 2022-06-11 01:22:34.694508
# Unit test for function get_bin_path
def test_get_bin_path():
    # This test is for macOS support only.
    # If a supported OS does not have a python binary in the paths, then it will fail.
    if get_bin_path('python', ['/bin']) is not None:
        assert get_bin_path('python', ['/bin']) == '/bin/python'
    # macOS doesn't have python in path.
    # So we test to see if essential python binaries are in paths
    assert get_bin_path('python') is not None
    assert get_bin_path('python3') is not None

# Generated at 2022-06-11 01:22:46.311504
# Unit test for function get_bin_path
def test_get_bin_path():
    # Negative test case
    # Testcase 1: Check exception is raised when executable is not found
    try:
        get_bin_path('unknown_exec')
        assert False, 'Expecting to throw exception when executable is not found'
    except ValueError as e:
        assert e == 'Failed to find required executable "unknown_exec" in paths: /bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin', 'Expecting different exception'

    # Positive test case
    # Testcase 2: Check exception is not raised when executable is found
    try:
        get_bin_path('ls')
    except ValueError as e:
        assert False, 'Not expecting to throw exception when executable is found'
    # Testcase 3: Check exception is not raised when optional directories list is passed and executable is found


# Generated at 2022-06-11 01:22:54.890190
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('bash')
    except ValueError:
        assert False
    try:
        get_bin_path('sh')
    except ValueError:
        assert False
    try:
        get_bin_path('unlikely-to-exist')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-11 01:22:56.421800
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('cat')
    assert path == 'cat'

# Generated at 2022-06-11 01:23:00.115090
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('ls', opt_dirs=[]) == '/bin/ls'

# Generated at 2022-06-11 01:23:08.237942
# Unit test for function get_bin_path
def test_get_bin_path():
    with pytest.raises(ValueError):
        get_bin_path('fake_bin')

    if sys.platform == 'darwin':
        bin_path = get_bin_path('launchctl')
    elif sys.platform.startswith('linux'):
        bin_path = get_bin_path('ip')
    elif sys.platform.startswith('freebsd'):
        bin_path = get_bin_path('pkg')
    else:
        bin_path = get_bin_path('echo')

    assert bin_path


if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-11 01:23:17.552473
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    import ansible.module_utils.basic as basic

    # Create example module directory tree
    tmpdir = tempfile.mkdtemp()
    os.makedirs("%s/ansible/module_utils" % tmpdir)

    # Write our test file (ansible.module_utils.basic) to temp directory
    f = open("%s/ansible/module_utils/basic.py" % tmpdir, "w")
    f.write(basic.__file__.read())
    f.close()

    # Add temp directory to module_utils path
    sys.path.insert(0, tmpdir)

    # Delete temp directory when we're done
    shutil.rmtree(tmpdir)

    # Call the get_bin_path function with a valid executable
    p = get_bin

# Generated at 2022-06-11 01:23:19.160064
# Unit test for function get_bin_path
def test_get_bin_path():
    # NOTE: The tests for this function are in the module_utils/shell.py tests.
    assert True

# Generated at 2022-06-11 01:23:27.490469
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path
    '''
    import tempfile
    import shutil
    import stat
    import sys

    # Test finding commands in PATH
    fh, path = tempfile.mkstemp(dir='/usr/bin', prefix='ansible-test-')
    tmpfile = path
    os.close(fh)
    os.chmod(tmpfile, stat.S_IREAD | stat.S_IEXEC | stat.S_IRUSR)
    r = get_bin_path('ansible-test-*')
    if sys.version_info[0] == 2:
        assert r == tmpfile  # Python 2 returns unicode from get_bin_path
    if sys.version_info[0] == 3:
        assert r == tmpfile.encode('utf-8')

# Generated at 2022-06-11 01:23:29.137917
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python', "Failed to find python in PATH"

# Generated at 2022-06-11 01:23:30.221354
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == "/bin/ls"

# Generated at 2022-06-11 01:23:36.652647
# Unit test for function get_bin_path
def test_get_bin_path():

    # Test that it can find an executable in our path
    assert get_bin_path('python') != None

    # Test that it fails to find a non-executable
    try:
        get_bin_path('__init__.py')
    except ValueError:
        assert True
    else:
        assert False, 'get_bin_path did not fail to find a non-executable file'

    # Test that it fails to find a missing executable
    try:
        get_bin_path('frobnicate')
    except ValueError:
        assert True
    else:
        assert False, 'get_bin_path did not fail to find a missing executable'

# Generated at 2022-06-11 01:23:52.171578
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ip') == '/sbin/ip'
    assert get_bin_path('getent') == '/usr/bin/getent'
    try:
        assert get_bin_path('noexist') == None
        assert False, 'Should not be here, exception expected'
    except ValueError as e:
        assert 'Failed to find required executable "noexist"' in str(e)
    try:
        assert get_bin_path('noexist', opt_dirs=['/usr/bin']) == None
        assert False, 'Should not be here, exception expected'
    except ValueError as e:
        assert 'Failed to find required executable "noexist" in paths: /usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin:/usr/local/sbin' in str(e)

# Generated at 2022-06-11 01:24:00.815193
# Unit test for function get_bin_path
def test_get_bin_path():
    import random
    import tempfile
    import shutil

    def maketest(name, error, paths=None, required=None):
        if error is not None:
            if isinstance(error, Exception):
                expected = error
            else:
                expected = ValueError
        else:
            expected = str
        paths = [] if paths is None else paths
        required = [True] if required is None else required
        for req in required:
            for p in paths:
                if req:
                    # ensure required=True (default in 2.8 and prior) raises an Exception when not found
                    yield (name, expected, p, req)
                elif error is not None:
                    # ensure required=False does not raise an Exception
                    yield (name, None, p, req)

    test_count = 0
    failures = list()


# Generated at 2022-06-11 01:24:03.157861
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('echo') == '/bin/echo'

# Generated at 2022-06-11 01:24:11.351167
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic

    # Create a list of arguments to test.
    # arg[0] should be the name of the executable we are testing for
    # arg[1] should be the results we expect
    # arg[2] should be an optional list of additional dirs to search
    # arg[3] should be an optional list of dirs that should fail
    # arg[4] should be the expected result if the optional path fails

# Generated at 2022-06-11 01:24:20.237868
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Calls get_bin_path for each executable in PATH and then for some nonexisting executables
    '''
    for bin_path in os.environ.get('PATH', '').split(os.pathsep):
        for executable in os.listdir(bin_path):
            try:
                assert get_bin_path(executable) == os.path.join(bin_path, executable)
            except ValueError:
                pass
    try:
        get_bin_path('non_existing_executable')
    except ValueError:
        pass

# Generated at 2022-06-11 01:24:31.912327
# Unit test for function get_bin_path
def test_get_bin_path():
    # No optional directories
    assert get_bin_path('true') == '/bin/true'

    # Optional directory
    assert get_bin_path('true', ['/usr/bin']) == '/bin/true'

    # Required arg deprecated
    assert get_bin_path('true', required=False) == '/bin/true'

    # Binary not found
    try:
        get_bin_path('thisbinarydoesnotexist')
        assert False
    except ValueError as e:
        assert 'Failed to find required executable "thisbinarydoesnotexist"' in str(e)

    # Directory not found

# Generated at 2022-06-11 01:24:43.120781
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    ansible.module_utils.basic.get_bin_path test harness
    '''
    import pytest
    pytestmark = pytest.mark.skipif(os.geteuid() != 0, reason='must be run as root')

    def test_get_bin_path(module_name):
        bin_path = get_bin_path(module_name)
        assert bin_path is not None
        assert os.path.exists(bin_path)
        assert not os.path.isdir(bin_path)
        assert is_executable(bin_path)

    # find root executable
    test_get_bin_path('/sbin/iptables')
    # find executable under root
    test_get_bin_path('iptables')
    # find executable directly
    test_get_bin_

# Generated at 2022-06-11 01:24:47.114509
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('hostname') == '/bin/hostname'
    assert get_bin_path('test') != '/bin/test'



# Generated at 2022-06-11 01:24:55.014197
# Unit test for function get_bin_path
def test_get_bin_path():

    try:
        # Test that get_bin_path raises ValueError for a non-existing executable
        get_bin_path('fake_executable')
        raise AssertionError('Test should have thrown a ValueError')
    except ValueError as e:
        pass

    # Test that get_bin_path returns the full path to the executable using its PATH
    assert get_bin_path('ls') == '/bin/ls'

    # Test that get_bin_path returns the full path to the executable using a list of optional directories
    opt_dirs = ['/usr/local/sbin']
    assert get_bin_path('iptables', opt_dirs=opt_dirs) == '/usr/local/sbin/iptables'

# Generated at 2022-06-11 01:25:06.720897
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat
    import sys

    tmpdir = tempfile.gettempdir()
    tmpdir = os.path.realpath(tmpdir)
    if sys.platform.startswith('win'):
        bin1 = os.path.join(tmpdir, 'bin1')
        shutil.copyfile(os.path.join(os.environ.get('SystemRoot', 'C:\\Windows'), 'system32', 'ipconfig.exe'), bin1)
    else:
        bin1 = os.path.join(tmpdir, 'bin1')
        shutil.copyfile('/bin/ls', bin1)

    bin1 = os.path.realpath(bin1)

    assert get_bin_path('bin1') == bin1


# Generated at 2022-06-11 01:25:21.420956
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test utilization of function get_bin_path
    '''
    assert get_bin_path('ansible') == get_bin_path('ansible')
    try:
        get_bin_path('this-ansible-does-not-exist')
        assert False, "get_bin_path should have raised an exception"
    except ValueError:
        pass

    opt_dirs = ['.']
    assert get_bin_path('ansible', opt_dirs=opt_dirs) == get_bin_path('ansible', opt_dirs=opt_dirs)

# Generated at 2022-06-11 01:25:31.442412
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    bn1 = 'bin1'
    bn2 = 'bin2'
    bn3 = 'bin3'
    bn4 = 'bin4'
    d1 = tempfile.mkdtemp()
    fn1 = os.path.join(d1, bn1)
    fn2 = os.path.join(d1, bn2)
    fn3 = os.path.join(d1, bn3)
    fn4 = os.path.join(d1, bn4)
    open(fn1, 'wb').close()
    open(fn2, 'wb').close()
    open(fn3, 'wb').close()
    open(fn4, 'wb').close()
    os.chmod(fn1, 0o777)

# Generated at 2022-06-11 01:25:34.892480
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test fixture to verify the module will raise ValueError if required executable is not found
    '''
    import pytest

    path = '/usr/bin/python'
    path_expected = get_bin_path('python')
    assert path == path_expected

    with pytest.raises(ValueError) as exc:
        get_bin_path('/wibblewibble')
    assert 'Failed to find required executable' in str(exc)

# Generated at 2022-06-11 01:25:44.061287
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile

    # Test simple use case
    args = ['sh', '-c', 'echo $PATH']
    env = dict(os.environ, PATH='/foo:/bar')
    path = get_bin_path('echo', ['/foo', '/bar'])
    assert path == '/bin/echo'
    exit_code = os.spawnve(os.P_WAIT, path, args, env)
    assert exit_code == 0

    # Test if required is True, raise exception
    try:
        path = get_bin_path('invalid', ['/foo', '/bar'])
    except ValueError:
        pass

    # Test if opt_dirs is None, empty list
    path = get_bin_path('echo', None)
    assert path == '/bin/echo'
    exit_code

# Generated at 2022-06-11 01:25:53.377377
# Unit test for function get_bin_path
def test_get_bin_path():
    # Normal cases
    assert get_bin_path('pwd') != '' and 'pwd' in get_bin_path('pwd')
    assert get_bin_path('nc') != '' and 'nc' in get_bin_path('nc')

    # Non-existed binary in PATH
    try:
        get_bin_path('non-exist-binary')
    except ValueError as exception:
        assert 'Failed to find required executable' in str(exception)

    # Non-existed binary in optional dir
    try:
        get_bin_path('non-exist-binary', opt_dirs=['/'])
    except ValueError as exception:
        assert 'Failed to find required executable' in str(exception)

# Generated at 2022-06-11 01:26:04.112082
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()
    temp_leaseweb_test_tmpl = temp_dir + '/leaseweb_test_tmpl'
    temp_leaseweb_test_tmpl_sh = temp_leaseweb_test_tmpl + '.sh'
    temp_leaseweb_test = temp_dir + '/leaseweb_test'
    with open(temp_leaseweb_test_tmpl_sh, 'w') as f:
        f.write('\n')
    shutil.copy2(temp_leaseweb_test_tmpl_sh, temp_leaseweb_test)
    os.chmod(temp_leaseweb_test, 0o700)

    assert get

# Generated at 2022-06-11 01:26:13.022379
# Unit test for function get_bin_path
def test_get_bin_path():
    current_dir = os.path.dirname(os.path.realpath(__file__))
    assert(get_bin_path('/bin/cat') == '/bin/cat')
    try:
        # Fails if no program like this is found, which is correct
        get_bin_path('/usr/bin/no-such-program-exists')
        assert False, "should not have gotten this far"
    except ValueError as e:
        pass
    assert(get_bin_path('ansible-doc', [os.path.join(current_dir, '..')]) ==
           os.path.join(current_dir, '..', 'ansible-doc'))

# Generated at 2022-06-11 01:26:21.635665
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    This unit test needs to be run as root.
    '''
    import tempfile
    import pytest

    # Function to be tested
    from ansible.module_utils.basic import get_bin_path

    # create a temporary executable file
    t_file = tempfile.NamedTemporaryFile(mode='w+')
    t_file.write('#!/bin/sh\n/bin/true\n')
    t_file.flush()

    # call the tested function on the temporary executable
    result = get_bin_path(t_file.name)

    # confirm that the returned path is correct
    assert result == t_file.name

    # test an executable that does not exist

# Generated at 2022-06-11 01:26:31.748596
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test default search path
    assert get_bin_path('ls') == '/bin/ls'
    # Test additional search paths
    assert get_bin_path('ls', ['/usr/bin', '/usr/local/bin']) == '/usr/bin/ls'
    # Test additional search paths with relative path
    assert get_bin_path('ls', ['bin']) == 'bin/ls'
    # Test order additional search paths
    assert get_bin_path('ls', ['/usr/bin', '/bin']) == '/bin/ls'
    # Test search returns first executable path from additional search paths
    assert get_bin_path('ls', ['/lib', '/bin']) == '/bin/ls'
    # Test ValueError is raised
    import pytest
    with pytest.raises(ValueError):
        get_bin_path

# Generated at 2022-06-11 01:26:39.274674
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Create temp dir
    tmp_dir = tempfile.mkdtemp()
    # Create some file/directory for testing
    dummy_content = 'Hello world'
    test_files = {'foo': dummy_content, 'bar': dummy_content}
    std_files = {'etc': {'hosts': dummy_content}, 'bin': {'ls': dummy_content},
                 'usr': {'lib': {'lib1': dummy_content}, 'bin': {'ls': dummy_content}, 'local': {'lib': {'lib2': dummy_content}}}}

    def make_file(path, content):
        with open(path, 'w') as f:
            f.write(content)

# Generated at 2022-06-11 01:26:52.502117
# Unit test for function get_bin_path
def test_get_bin_path():
    assert is_executable(get_bin_path('ssh', ['/usr/bin', '/usr/local/bin']))
    assert is_executable(get_bin_path('echo', ['/bin']))
    assert get_bin_path('echo', ['/bin']) == '/bin/echo'
    assert is_executable(get_bin_path('/bin/echo'))

# Generated at 2022-06-11 01:26:55.038269
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh')
    assert get_bin_path('/bin/sh')
    try:
        get_bin_path('nonexistent')
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-11 01:27:05.939741
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    class TestGetBinPath(unittest.TestCase):
        @patch.dict(os.environ, {'PATH': '/bin:/sbin'})
        def test_get_bin_path_should_find_executable_in_default_path(self):
            result = get_bin_path('bash')
            self.assertEqual(result, '/bin/bash')


# Generated at 2022-06-11 01:27:17.031681
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python', opt_dirs=["/usr/bin"]) == "/usr/bin/python"
    assert get_bin_path('python', opt_dirs=["/usr/bin", "/usr/local/bin"]) == "/usr/bin/python"
    assert get_bin_path('python', opt_dirs=["/usr/local/bin", "/usr/bin"]) == "/usr/bin/python"
    assert get_bin_path('python', opt_dirs=["/usr/local/bin", "/usr/bin", "/usr/sbin"]) == "/usr/bin/python"
    assert get_bin_path('python', opt_dirs=["/usr/local/bin", "/usr/sbin", "/usr/bin"]) == "/usr/bin/python"
    assert get_

# Generated at 2022-06-11 01:27:22.782675
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_name = 'sh'
    bin_path = get_bin_path(bin_name)
    assert os.path.isfile(bin_path)
    assert is_executable(bin_path) is True
    assert os.path.basename(bin_path) == bin_name

    bin_name = 'unexisting-bin'
    try:
        get_bin_path(bin_name)
        assert False
    except ValueError as e:
        assert bin_name in str(e)

# Generated at 2022-06-11 01:27:29.676642
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    from ansible.module_utils.common.file import is_executable

    bin_path = get_bin_path('/usr/bin/ls')

    with pytest.raises(ValueError):
        get_bin_path('fake_command')

    # assert that a binary that is not in path fails as required
    with pytest.raises(ValueError):
        get_bin_path('/usr/sbin/netstat', required=True)

# Generated at 2022-06-11 01:27:36.726190
# Unit test for function get_bin_path
def test_get_bin_path():

    try:
        get_bin_path('nonexistent_executable')
        assert False
    except ValueError:
        pass

    try:
        get_bin_path('')
        assert False
    except ValueError:
        pass

    path = get_bin_path('sh')
    assert os.path.exists(path)

    path = get_bin_path('sh', opt_dirs=[])
    assert os.path.exists(path)

    # verify sh was found in the requested directory
    path = get_bin_path('sh', opt_dirs=['/'])
    assert os.path.exists(path)
    assert path.startswith('/')

    # verify nonexistent_executable not found in directory

# Generated at 2022-06-11 01:27:38.768760
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/path/does/not/exist')
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-11 01:27:43.289248
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')
    try:
        get_bin_path('plop')
        assert False
    except ValueError:
        pass
    try:
        get_bin_path('plop', required=True)
        assert False
    except ValueError:
        pass
    try:
        get_bin_path('plop', opt_dirs=['/bin'])
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 01:27:46.355501
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/env') == '/usr/bin/env'
    try:
        get_bin_path('spongebob')
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError to be raised"

# Generated at 2022-06-11 01:28:05.681612
# Unit test for function get_bin_path
def test_get_bin_path():
    """Verify module function get_bin_path works for the following.
    - returns the binary path if it is on the path.
    - Raises ValueError if the binary is not on the path.
    - Searches /sbin, /usr/sbin and /usr/local/sbin in addition to the PATH env var.

    :return: None
    """
    # Test 1. Verify that get_bin_path returns the absolute path of the requested binary if it's on the path.
    bin_path = get_bin_path('bash')
    assert(os.path.exists(bin_path))

    # Test 2. Verify that get_bin_path returns the absolute path of the requested binary in /sbin if it's on the path.
    bin_path = get_bin_path('poweroff')

# Generated at 2022-06-11 01:28:14.648914
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Test function get_bin_path '''

    # Non existing executable
    try:
        get_bin_path('nothingbetter')
        assert 0, 'Failed to find executable nothingbetter'
    except ValueError as exp:
        exp_str = 'Failed to find required executable "nothingbetter" in paths'
        assert str(exp).startswith(exp_str)

    # Existing executable
    exp = get_bin_path('ls')
    assert os.path.exists(exp), 'Executable ls not found'
    assert os.path.isfile(exp), 'Executable ls is not a file'
    assert is_executable(exp), 'Executable ls is not executable'

    # Existing executable in a provided dir
    bindir = os.path.dirname(exp)
    assert bindir

# Generated at 2022-06-11 01:28:19.441931
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('ansible-doc')
    except Exception:
        assert False, 'Failed to find ansible-doc in path.'
    try:
        get_bin_path('does-not-exist')
        assert False, 'did not raise exception on non-existant file'
    except ValueError:
        pass

# Generated at 2022-06-11 01:28:30.891051
# Unit test for function get_bin_path
def test_get_bin_path():

    # Create a file stub for testing
    from tempfile import mkstemp
    fd, fpath = mkstemp()
    os.close(fd)

    # Ensure that file stub was created

# Generated at 2022-06-11 01:28:35.201337
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    try:
        get_bin_path('foobar')
        assert False, "Expected exception"
    except ValueError:
        pass

    new_paths = ['/bin/', '/usr/local/bin', '/usr/local/sbin']
    assert get_bin_path('python', new_paths) == '/usr/local/bin/python'

# Generated at 2022-06-11 01:28:46.459441
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/']) == '/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/opt/bin', '/']) == '/opt/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/']) == '/usr/bin/ls'


# Generated at 2022-06-11 01:28:56.684695
# Unit test for function get_bin_path
def test_get_bin_path():
    import platform
    import shutil
    import tempfile
    import sys

    if sys.platform == 'darwin':
        bin_path = '/usr/bin/python'
    else:
        bin_path = '/bin/python'

    # make a fake python executable in a temp dir, as a test that we
    # can find our fake /bin/python
    temp_python = tempfile.NamedTemporaryFile(mode='w', delete=False).name
    shutil.copy(bin_path, temp_python)

    # should find the system python
    assert bin_path == get_bin_path('python')

    # should use temp_python, because we pass it as a directory to search
    assert(temp_python == get_bin_path('python', opt_dirs=[os.path.dirname(temp_python)]))



# Generated at 2022-06-11 01:29:04.444688
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.six import PY3

    import os
    import tempfile


# Generated at 2022-06-11 01:29:10.386123
# Unit test for function get_bin_path
def test_get_bin_path():
    test_arg = 'program'
    test_dirs = ['/bin', '/usr/bin']
    test_paths = ['/usr/bin', '/bin']

    assert get_bin_path(test_arg, test_dirs) == test_paths[0] + os.sep + test_arg
    assert get_bin_path('program', ['/bin', '/usr/bin']) == '/usr/bin/program'