

# Generated at 2022-06-11 01:19:20.695133
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    from ansible_collections.ansible.community.tests.unit.compat import unittest

    class TestGetBinPath(unittest.TestCase):
        def setUp(self):
            self._old_path = os.environ['PATH']
            self._tmp_dir = tempfile.mkdtemp()
            os.environ['PATH'] = self._tmp_dir

        def tearDown(self):
            os.environ['PATH'] = self._old_path

        def test_return_value(self):
            executable = 'test_exe'
            path = os.path.join(self._tmp_dir, executable)
            with open(path, 'w') as f:
                f.write('#!/bin/sh')
            os.chmod(path, 0o700)
            self

# Generated at 2022-06-11 01:19:27.571523
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        os.environ['PATH'] = '/usr/bin:/usr/local/bin'
        os.environ['_ANSIBLE_TEST_GET_BIN_PATH'] = '1'
        assert get_bin_path('ls') == '/usr/bin/ls'
        assert get_bin_path('doesnotexist')
        assert False, 'get_bin_path should have raised'
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    finally:
        del os.environ['_ANSIBLE_TEST_GET_BIN_PATH']

# Generated at 2022-06-11 01:19:36.359035
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')
    assert get_bin_path('cat', required=False)
    assert get_bin_path('cat', required=True)
    assert get_bin_path('cat', required=True)
    assert get_bin_path('ls', opt_dirs=['/bin'])
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin'])
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin', '/not/here'])
    assert get_bin_path('ls', opt_dirs=['/sbin'])
    assert get_bin_path('ls', opt_dirs=['/sbin', '/usr/sbin'])

# Generated at 2022-06-11 01:19:43.179148
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('python')
    assert path == '/usr/bin/python'
    path = get_bin_path('python', opt_dirs=['/usr/local/bin', '/usr/bin', '/usr/sbin'])
    assert path == '/usr/bin/python'
    path = get_bin_path('python', opt_dirs=['/usr/sbin', '/usr/sbin/panos'])
    assert path == '/usr/bin/python'
    try:
        get_bin_path('python', opt_dirs=['/usr/sbin/panos'])
        assert False
    except:
        assert True
    path = get_bin_path('python', opt_dirs=[None, '/usr/bin/panos', '/usr/bin'])

# Generated at 2022-06-11 01:19:49.085674
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['/bin', '/usr/bin', '/usr/local/bin']
    required = True

    assert get_bin_path('ls') == get_bin_path('ls', paths, required)

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-11 01:19:51.613228
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('this_program_does_not_exist')
    except ValueError as e:
        assert 'this_program_does_not_exist' in str(e)
    else:
        assert False

    import sys
    assert get_bin_path(sys.executable) == os.path.realpath(sys.executable)

# Generated at 2022-06-11 01:19:54.359264
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    bin_dir = os.path.dirname(sys.executable)
    bin_path = get_bin_path("python")
    assert bin_path == sys.executable

# Generated at 2022-06-11 01:20:01.480468
# Unit test for function get_bin_path
def test_get_bin_path():
    my_dir = os.path.dirname(__file__)
    my_file = os.path.join(my_dir, 'get_bin_path.py')
    # We make sure we don't find it because we don't want executing this file from the filesystem.
    # we want to find the real one from the module_utils directory.
    assert not os.path.exists(my_file)
    assert get_bin_path('ping') == '/bin/ping'
    assert get_bin_path('get_bin_path.py', opt_dirs=[os.path.join(os.path.dirname(my_dir), 'module_utils')]) == my_file

# Generated at 2022-06-11 01:20:08.982782
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    fd, fname = tempfile.mkstemp(prefix='ansible_test_get_bin_path')
    with open(fname, 'wt') as fh:
        fh.write('''#!/bin/sh
echo "success!"
''')
    os.chmod(fname, 0o700)

    try:
        assert get_bin_path(fname, ['/bin']) == fname
    finally:
        os.close(fd)
        os.unlink(fname)

# Generated at 2022-06-11 01:20:19.666778
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test results of get_bin_path function
    '''
    ansible_path = os.getcwd()
    test_found = False
    try:
        ansible_path = get_bin_path('ansible')
        test_found = True
    except Exception:
        pass
    assert test_found, "ansible not found in path {}".format(ansible_path)

    # Test custom path
    custom_path = os.getcwd() + "/lib/ansible/module_utils/"
    test_found = False
    try:
        custom_path = get_bin_path('ansible', custom_path)
        test_found = True
    except Exception:
        pass
    assert test_found, "ansible not found in path {}".format(custom_path)

    # Test custom path with

# Generated at 2022-06-11 01:20:32.925558
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('echo') == '/bin/echo'
    try:
        get_bin_path('missing_exec')
        assert False
    except ValueError:
        pass
    assert get_bin_path('missing_exec', ['/bin']) == '/bin/missing_exec'
    assert get_bin_path('missing_exec', ['/bin'], required=False) == '/bin/missing_exec'
    try:
        get_bin_path('missing_exec', ['/bin'], required=True)
        assert False
    except ValueError:
        pass
    try:
        get_bin_path('missing_exec', required=True)
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 01:20:40.552152
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/bin/ls')
    except:
        raise AssertionError("Binary path '/bin/ls' not found! This test suite requires this to be installed and available in $PATH")
    # Test that an exception is raised
    try:
        get_bin_path('not_there')
        raise AssertionError('get_bin_path should have failed but did not')
    except ValueError:
        pass


# TODO: consider using distutils.spawn.find_executable

# Generated at 2022-06-11 01:20:49.995478
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for get_bin_path()
    '''
    import tempfile

    arg = 'test_file'
    # Create a temp dir and then remove it.  This is done to make sure that
    # the tempfile.tempdir doesn't contain any test_file* files
    tempfile.tempdir = None
    temp_dir = tempfile.mkdtemp()
    os.rmdir(temp_dir)

    # Create test_file in tempfile.tempdir
    tmp_fname = os.path.join(os.path.dirname(tempfile.tempdir), arg)
    with open(tmp_fname, 'w') as tmp_file:
        tmp_file.write('')

    opt_dirs = ['/sbin']

    # Make sure that get_bin_path() works as

# Generated at 2022-06-11 01:20:50.781380
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('pwd') == '/bin/pwd'

# Generated at 2022-06-11 01:20:56.832627
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for system executable
    assert get_bin_path('ls')
    # Test for executable in /sbin
    assert get_bin_path('fipscheck')
    # Test for executable in /usr/sbin
    assert get_bin_path('systemctl')
    # Test for executable in /usr/local/sbin
    assert get_bin_path('pip')
    # Test for executable in paths
    assert get_bin_path('ls', ['/bin'])
    # Test for executable in opt_dirs
    assert get_bin_path('ls', ['/bin', '/usr/bin'])


# Generated at 2022-06-11 01:21:00.602069
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin', '/usr/bin']) == '/bin/sh'



# Generated at 2022-06-11 01:21:09.909786
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' test get_bin_path() '''
    import tempfile
    import shutil
    import sys

    def create_executables(tmpdir):
        ''' Create temp executables '''
        bin_path = os.path.join(tmpdir, 'bin')
        os.mkdir(bin_path)
        open(os.path.join(bin_path, 'foo'), 'a').close()
        os.chmod(os.path.join(bin_path, 'foo'), 0o755)
        os.symlink(os.path.join(bin_path, 'foo'), os.path.join(tmpdir, 'foo'))
        return bin_path

    # create temp directory
    tmpdir = tempfile.mkdtemp(dir=os.environ['HOME'])
    bin_path = create_

# Generated at 2022-06-11 01:21:20.322734
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('/bin/bash') == '/bin/bash'
    assert get_bin_path('/bin/echo') == '/bin/echo'
    assert (get_bin_path('echo', opt_dirs=['']) == '/bin/echo') or (get_bin_path('echo', opt_dirs=['']) == '/usr/bin/echo')
    assert (get_bin_path('/bin/echo', opt_dirs=['']) == '/bin/echo') or (get_bin_path('/bin/echo', opt_dirs=['']) == '/usr/bin/echo')

# Generated at 2022-06-11 01:21:22.094257
# Unit test for function get_bin_path
def test_get_bin_path():
    assert is_executable(get_bin_path('cat'))

# Module-level tests

# Generated at 2022-06-11 01:21:26.456257
# Unit test for function get_bin_path
def test_get_bin_path():
    path_foo = get_bin_path('foo')
    assert path_foo == os.path.join(os.environ.get('PATH', '').split(os.pathsep)[0], 'foo')
    try:
        get_bin_path('imaginary')
        assert False, 'get_bin_path did not throw exception for missing command'
    except ValueError:
        pass  # E

# Generated at 2022-06-11 01:21:39.111491
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    # create a fake binary and ensure that is found
    (fake_bin_fd, fake_bin_file) = tempfile.mkstemp()
    fake_bin = os.fdopen(fake_bin_fd, "w+b")
    fake_bin.write(b"#!/bin/sh\necho fake_bin\n")
    fake_bin.close()
    os.chmod(fake_bin_file, stat.S_IXUSR)

    # create a fake directory containing fake_bin
    fake_dir = tempfile.mkdtemp()
    fake_dir_bin = os.path.join(fake_dir, os.path.basename(fake_bin_file))
    shutil.copy(fake_bin_file, fake_dir)

    # mock

# Generated at 2022-06-11 01:21:49.573936
# Unit test for function get_bin_path
def test_get_bin_path():
    assert os.path.isfile(get_bin_path('sh'))
    assert os.path.isfile(get_bin_path('sh', opt_dirs=['/bin']))


if __name__ == '__main__':
    import sys
    import pytest
    from subprocess import Popen, PIPE

    if len(sys.argv) > 1 and sys.argv[1] == '--validate':
        pytest.main(['-v'])
    elif len(sys.argv) > 1 and sys.argv[1] == '--validate-fast':
        pytest.main(['-v', '-x', '--durations=0'])

# Generated at 2022-06-11 01:21:57.313211
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test OK case
    assert get_bin_path('chmod') == '/bin/chmod'
    get_bin_path('chmod', opt_dirs=['/usr/bin', '/bin']) == '/bin/chmod'
    get_bin_path('chmod', opt_dirs=['/usr/bin', '/bin'], required=True) == '/bin/chmod'

    # Test Not Found case
    try:
        get_bin_path('chmod1')
        assert False
    except ValueError:
        pass
    try:
        get_bin_path('chmod1', opt_dirs=['/usr/bin', '/bin'])
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 01:22:02.577087
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        bin_path = get_bin_path('/bin/cat')
        assert bin_path == '/bin/cat'
        bin_path = get_bin_path('cat')
        assert bin_path == '/bin/cat' or bin_path == '/usr/bin/cat'
    except Exception as e:
        print('Exception: {}'.format(e))

# Generated at 2022-06-11 01:22:10.148637
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/sbin']) == '/bin/ls'
    assert get_bin_path('busybox') == '/bin/busybox'
    assert get_bin_path('/bin/busybox') == '/bin/busybox'
    assert get_bin_path('/bin/ls') == '/bin/ls'



# Generated at 2022-06-11 01:22:13.411395
# Unit test for function get_bin_path
def test_get_bin_path():
    # test if function return expected value
    assert get_bin_path('/usr/bin/python') == '/usr/bin/python'

    # test if function raise right exception
    try:
        get_bin_path('/usr/bin/python', required=False)
    except ValueError:
        pass

# Generated at 2022-06-11 01:22:18.648858
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Function get_bin_path should return the path of a command that can be found in the path.'''

    # Get the path to Python, which should be installed somewhere in the path
    path = get_bin_path('python')

    assert path is not None

    # Check that the path returned points to an executable file
    assert os.access(path, os.X_OK)

# Generated at 2022-06-11 01:22:25.338718
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    def check_bin_path(expected, arg, opt_dirs=None, required=None):
        '''
        This function calls get_bin_path() with the specified arguments,
        and asserts that it returns the expected result.
        '''
        bin_path = get_bin_path(arg, opt_dirs=opt_dirs, required=required)
        assert bin_path == expected, "Expected %s, got %s" % (expected, bin_path)

    # on Windows, PATHEXT contains a list of extensions other than .exe,
    # such as .com and .bat, which may precede .exe if the user has
    # an older version of the executable on the PATH;
    # we split them out and check for each of them
    exe_extensions = ['']

# Generated at 2022-06-11 01:22:33.202543
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('getent') == '/usr/bin/getent'
    assert get_bin_path('getent', opt_dirs=['/bin', '/usr/bin']) == '/usr/bin/getent'
    try:
        assert get_bin_path('getent', opt_dirs=['/bin', '/usr/bin'], required=False)
        assert get_bin_path('getent', opt_dirs=['/bin', '/usr/bin'])
    except ValueError:
        assert False
    try:
        assert get_bin_path('getent', opt_dirs=['/bin', '/usr/bin'], required=True)
    except ValueError:
        assert False

# Generated at 2022-06-11 01:22:44.535342
# Unit test for function get_bin_path
def test_get_bin_path():
    # Search PATH for path of 'true'
    try:
        true_path = get_bin_path('true')
    except (OSError, ValueError):
        # We couldn't find the path for true,
        # so mark this test as unsuccessful
        true_path = None
    assert true_path is not None

    # Ensure that searching for a nonexistent executable fails
    nonexistent_executable = '__this_binary_does_not_exist__'
    try:
        get_bin_path(nonexistent_executable)
        # We didn't receive the expected ValueError,
        # so mark this test as unsuccessful
        nonexistent_executable_path = None
    except ValueError:
        nonexistent_executable_path = None
    assert nonexistent_executable_path is None

    # Ensure that the optional directory argument works
    test_executable

# Generated at 2022-06-11 01:22:54.181937
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.environ.get("NOSE") is None:
        # No test on host where nosetests is not installed.
        return
    from nose.tools import assert_raises

    # Executable is not found
    with assert_raises(ValueError) as err:
        get_bin_path("does-not-exists")
    assert 'Failed to find required executable "does-not-exists" in paths' in str(err.exception)

    # Executable is a directory
    with assert_raises(ValueError) as err:
        get_bin_path("/usr/bin/")
    assert 'Failed to find required executable "/usr/bin/" in paths' in str(err.exception)

    # Executable is not executable
    with assert_raises(ValueError) as err:
        get_bin

# Generated at 2022-06-11 01:22:55.122313
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh')

# Generated at 2022-06-11 01:23:05.154975
# Unit test for function get_bin_path
def test_get_bin_path():
    my_path = os.pathsep.join([
        os.path.join(os.path.dirname(__file__), '..', '..', 'test_data'),
        os.path.join(os.path.dirname(__file__), '..', '..', 'test_data', 'gather_facts'),
        '/usr/bin'
    ])
    old_path = os.environ.get('PATH')
    os.environ['PATH'] = my_path

# Generated at 2022-06-11 01:23:12.366548
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    from ansible.utils.path import unfrackpath


# Generated at 2022-06-11 01:23:20.788455
# Unit test for function get_bin_path
def test_get_bin_path():
    import itertools

    test_paths = ('/bin', '/usr/bin', '/usr/local/bin', '/usr/share/bin')
    test_bin_name = 'test' + os.path.extsep + 'sh'
    test_bin_path = os.path.join(test_paths[1], test_bin_name)
    test_not_existing_bin_path = '/foo/bar/test.sh'

    # generate test cases
    test_cases = []

    # default case
    test_cases.append((test_bin_name, None, None, test_bin_path))
    test_cases.append((test_bin_name, [], None, test_bin_path))
    test_cases.append((test_bin_name, None, [], test_bin_path))

    #

# Generated at 2022-06-11 01:23:29.184047
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', ['/usr/bin', '/bin', '/usr/sbin']) == '/bin/ls'
    assert get_bin_path('ls', ['/usr/bin', '/usr/sbin']) == '/usr/bin/ls'
    assert get_bin_path('ls', ['/usr/sbin']) == '/usr/sbin/ls'
    assert get_bin_path('ls', ['/sbin']) == '/sbin/ls'
    assert get_bin_path('ls', ['/usr/bin', '/bin']) == '/bin/ls'
    assert get_bin_path('sh', ['/bin']) == '/bin/sh'

# Generated at 2022-06-11 01:23:32.806366
# Unit test for function get_bin_path
def test_get_bin_path():
    executable = 'python'
    bin_path = get_bin_path(executable)
    assert os.path.exists(bin_path) and not os.path.isdir(bin_path) and is_executable(bin_path)
    assert bin_path.endswith(executable)



# Generated at 2022-06-11 01:23:36.198655
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/bin']) == '/bin/sh'
    try:
        get_bin_path('invalid')
        raise AssertionError("Expected 'invalid' to raise an exception")
    except ValueError:
        pass

# Generated at 2022-06-11 01:23:38.800495
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('thisdoesntexist')
        assert False, 'expected get_bin_path to fail'
    except ValueError:
        pass

# Generated at 2022-06-11 01:23:44.594311
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('python')
    assert bin_path is not None, "Failed to find python executable"
    assert os.path.exists(bin_path), "Failed to find python executable"
    assert is_executable(bin_path), "Failed to find python executable"
    assert os.path.basename(bin_path) == 'python'

# Generated at 2022-06-11 01:23:54.067800
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('false', opt_dirs=['/'])
    except ValueError as e:
        assert e.args[0] == 'Failed to find required executable "false" in paths: /:/bin:/usr/bin:/usr/local/bin:/usr/sbin:/sbin:/usr/local/sbin'
    assert get_bin_path('false', opt_dirs=['/bin', '/usr/bin']) == '/bin/false'

# Generated at 2022-06-11 01:23:57.002122
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert get_bin_path('ls')
    except ValueError as e:
        assert False, 'get_bin_path("ls") should return path to ls exec'
    try:
        assert not get_bin_path('foobar')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

# Generated at 2022-06-11 01:24:05.943856
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test normal return
    item = 'sh'
    try:
        bin_path = get_bin_path(item)
    except ValueError:
        print('Failed to find required executable "%s" in paths' % (item))
        return 1
    # Test that probem takes optional directory as input
    item = 'uname'
    opt_dirs = ['', '/bin', '/sbin', '/usr/bin', '/usr/local/bin', '/usr/sbin']
    try:
        bin_path = get_bin_path(item, opt_dirs)
    except ValueError:
        print('Failed to find required executable "%s" in paths' % (item))
        return 1
    item = 'doesnotexist'

# Generated at 2022-06-11 01:24:10.106216
# Unit test for function get_bin_path
def test_get_bin_path():
    import os

    def test_bin_path(arg, expected_bin_path):
        assert get_bin_path(arg, opt_dirs=[]) == expected_bin_path

    test_bin_path("ls", "/bin/ls")
    test_bin_path("/bin/ls", "/bin/ls")
    test_bin_path("../bin/ls", os.path.normpath("../bin/ls"))

# Generated at 2022-06-11 01:24:21.798101
# Unit test for function get_bin_path
def test_get_bin_path():

    initial_path = os.environ.get('PATH', '')
    os.environ['PATH'] = '/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin'

    # Test1: Test if the file is found in the PATH
    try:
        assert get_bin_path('ls') == '/bin/ls'
    except ValueError:
        assert False, 'Failed to find executable'

    # Test2: Test if the file is found in the PATH even if extra
    #        arguments are specified
    try:
        assert get_bin_path('ls', ['/']) == '/bin/ls'
    except ValueError:
        assert False, 'Failed to find executable'

    # Test3: Test if exception is raised when required is set to True
    #        and file

# Generated at 2022-06-11 01:24:24.572682
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible') == os.path.join(os.path.dirname(__file__), '..', '..', 'bin', 'ansible')

# Generated at 2022-06-11 01:24:28.850954
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.six import PY3
    import mock
    import tempfile
    import shutil
    import stat

    if PY3:
        def exec_perms_down(directory):
            pass
    else:
        def exec_perms_down(directory):
            # Python 2.x provides no direct support for setting a directory's permissions.
            # This is a workaround for Python 2.x based upon a method at the following link:
            #     https://stackoverflow.com/questions/2697039/python-equivalent-of-chmod-x
            new_permissions = stat.S_IMODE(os.stat(directory)[stat.ST_MODE])  # Get current permissions.

# Generated at 2022-06-11 01:24:32.712188
# Unit test for function get_bin_path
def test_get_bin_path():
    test_cmd = 'ansible-config'
    result = get_bin_path(test_cmd)
    assert(result == os.path.join(os.getcwd(), test_cmd))

# Generated at 2022-06-11 01:24:43.793428
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    # Testing with non-existing executable
    try:
        get_bin_path('this_does_not_exist')
    except ValueError:
        assert True
    else:
        assert False
    # Testing with opt_dirs argument
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin']) == '/bin/sh'
    # Testing with opt_dirs and non-existing executable
    try:
        get_bin_path('this_does_not_exist', opt_dirs=['/usr/bin', '/bin'])
    except ValueError:
        assert True
    else:
        assert False
    # Testing with opt_dirs argument and existing executable

# Generated at 2022-06-11 01:24:54.021641
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/test/test')
    except ValueError as ve:
        assert 'not found' in str(ve)

    with open('/test1', 'w') as f:
        f.write('')
    try:
        get_bin_path('/test1')
    except ValueError as ve:
        assert 'not executable' in str(ve)

    with open('/test2', 'w') as f:
        f.write('#! /bin/sh\necho')
    os.chmod('/test2', 0o755)
    assert '/test2' == get_bin_path('/test2')

    with open('/test3', 'w') as f:
        f.write('#! /bin/sh\necho')

# Generated at 2022-06-11 01:25:00.821811
# Unit test for function get_bin_path
def test_get_bin_path():
    path_name = get_bin_path('ansible')
    assert isinstance(path_name, str)
    assert os.path.isfile(path_name)
    assert os.access(path_name, os.X_OK)

# Generated at 2022-06-11 01:25:11.026831
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import random
    import string
    import unittest

    class TestGetBinPath(unittest.TestCase):
        def setUp(self):
            self.add_dir = None
            self.temp_dir = tempfile.mkdtemp()
            self.temp_subdir = None

            # PATH
            self.paths = os.environ.get('PATH', '').split(os.pathsep)

            # create some random executable file in temp dir
            # add temp dir to the PATH
            rand_exec_file = ''.join(random.choice(string.ascii_lowercase) for _ in range(8))
            rand_exec_file_path = os.path.join(self.temp_dir, rand_exec_file)

# Generated at 2022-06-11 01:25:21.922938
# Unit test for function get_bin_path
def test_get_bin_path():
    good_binary = 'date'
    assert get_bin_path(good_binary) is not None

    # Test different places in the PATH
    good_binary = 'pwd'
    assert get_bin_path(good_binary, opt_dirs=['/bin', '/usr/bin']) is not None
    assert get_bin_path(good_binary, opt_dirs=['/usr/bin', '/bin']) is not None

    # Test different places in the PATH where we know it's not
    bad_binary = 'nonexistentbinarythatwillneverbefound'
    th = None
    try:
        get_bin_path(bad_binary, opt_dirs=['/sbin', '/usr/sbin'])
    except ValueError as e:
        th = e
    assert th is not None

    #

# Generated at 2022-06-11 01:25:29.654150
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/python') == '/usr/bin/python'
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('python')
    assert get_bin_path('sh')
    try:
        get_bin_path('/bin/no_such_binary')
        assert False, "Expecting an error"
    except:
        assert True
    try:
        get_bin_path('no_such_binary')
        assert False, "Expecting an error"
    except:
        assert True

# Generated at 2022-06-11 01:25:36.396005
# Unit test for function get_bin_path
def test_get_bin_path():
    # simplest possible case - find an executable
    assert get_bin_path('true')
    # test that sbin dirs are correctly added to the path
    assert get_bin_path('udevadm')
    # case where executable is not found
    try:
        get_bin_path('nonexistent_executable')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-11 01:25:38.155587
# Unit test for function get_bin_path
def test_get_bin_path():
    # It is a test failure if the exception is raised
    get_bin_path('env')



# Generated at 2022-06-11 01:25:46.461981
# Unit test for function get_bin_path
def test_get_bin_path():

    assert get_bin_path('sh')
    assert '/usr/bin/sh' in get_bin_path('sh')
    assert get_bin_path('ansible-playbook')
    assert '/usr/bin/ansible-playbook' in get_bin_path('ansible-playbook')
    assert get_bin_path('ansible-playbook', required=True)
    assert '/usr/bin/ansible-playbook' in get_bin_path('ansible-playbook', required=True)
    assert '/usr/bin/sh' in get_bin_path('sh', opt_dirs=['/usr/bin', '/usr/local/bin'])
    assert '/usr/bin/sh' in get_bin_path('sh', opt_dirs=['/usr/local/bin', '/usr/bin'])
   

# Generated at 2022-06-11 01:25:57.417576
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    test_dir = tempfile.mkdtemp()

    bin_path = get_bin_path('ls')
    # Check that a system binary is found
    assert bin_path == shutil.which('ls')

    # Create a test binary in the temporary directory
    test_bin_name = 'test-bin'
    test_bin_path = os.path.join(test_dir, test_bin_name)
    with open(test_bin_path, 'w') as f:
        f.write('#!/bin/sh\necho "test\n"')
    os.chmod(test_bin_path, stat.S_IRWXU)

    # Check that get_bin_path can find the test binary
    test_bin_path_from_get_bin

# Generated at 2022-06-11 01:26:04.619285
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check that non-existing executable raises exception
    try:
        get_bin_path('nonexisting-utility')
        assert(False)
    except ValueError:
        pass

    # Check that existing executable is found
    try:
        assert(get_bin_path('ls') == 'ls')
    except ValueError:
        assert(False)

    # Check that executable in path is found
    try:
        assert(get_bin_path('cat') == 'cat')
    except ValueError:
        assert(False)

# Generated at 2022-06-11 01:26:06.353896
# Unit test for function get_bin_path
def test_get_bin_path():

    assert 'get_bin_path' == get_bin_path('get_bin_path').split('/')[-1]

# Generated at 2022-06-11 01:26:18.337814
# Unit test for function get_bin_path
def test_get_bin_path():
    # find system executable in PATH
    try:
        bin_path = get_bin_path('sh')
        assert os.path.exists(bin_path)
        assert not os.path.isdir(bin_path)
    except ValueError as e:
        assert False

    # find system executable in PATH
    try:
        bin_path = get_bin_path('sh', ['/foo/bar', '/usr/bin'])
        assert os.path.exists(bin_path)
        assert not os.path.isdir(bin_path)
    except ValueError as e:
        assert False

    # raise error if executable is not found
    try:
        get_bin_path('sh_not_exist')
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-11 01:26:25.644737
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file in that directory =
    tmpfname = os.path.join(tmpdir, "test.sh")
    with open(tmpfname, "w") as f:
        f.write("#!/bin/sh\n")
    # Make it executable
    os.chmod(tmpfname, 0o755)
    # Add the temp directory to PATH
    os.environ['PATH'] = tmpdir
    # When we run get_bin_path() it should return the path to the file
    assert get_bin_path("test.sh") == tmpfname

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-11 01:26:29.474040
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test if an exception is triggered if the argument is not found
    try:
        get_bin_path("foo")
        assert False
    except ValueError:
        assert True

    # TODO: more case

# Generated at 2022-06-11 01:26:37.776999
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os

    saved_environ = os.environ

    try:
        dir_path = tempfile.mkdtemp()
        file_path = os.path.join(dir_path, 'foo')
        with open(file_path, 'w') as f:
            f.write('#!/bin/sh')
        # Make file executable
        os.chmod(file_path, 0o755)
        os.environ = {'PATH': dir_path}
        foo = get_bin_path('foo')
        assert os.path.exists(foo)
    except:
        os.environ = saved_environ
        raise
    finally:
        shutil.rmtree(dir_path)
        os.environ = saved_environ

# Generated at 2022-06-11 01:26:48.275446
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    import shutil

    # Make a temp dir to use as a fake PATH
    test_dir = tempfile.mkdtemp()

    # Make some executables to find
    for test_bin in ['python', 'python.exe', 'pip', 'pip.exe']:
        with open(os.path.join(test_dir, test_bin), 'w') as f:
            f.write('#!/bin/python\n'
                    'import sys\n'
                    'if __name__ == "__main__":\n'
                    '    sys.exit(0)\n')
        os.chmod(os.path.join(test_dir, test_bin), 0o755)

    # find python, and make sure we found the one in this temp dir
    results = get_bin_

# Generated at 2022-06-11 01:26:56.680486
# Unit test for function get_bin_path
def test_get_bin_path():

    import ansible.module_utils.facts.system.distribution as distro
    import ansible.module_utils.facts.system.platform as platform
    from ansible.module_utils.facts.system.distribution import LinuxDistribution

    if distro.distribution.lower() == 'ubuntu':

        # regular command
        path = get_bin_path('apt')
        assert path.endswith('/apt')

        # script file with no extension
        path = get_bin_path('vmware-uninstall-tools')
        assert path.endswith('/vmware-uninstall-tools')

    elif distro.distribution.lower() == 'oracle':

        # regular command
        path = get_bin_path('yum')
        assert path.endswith('/yum')


# Generated at 2022-06-11 01:27:08.180933
# Unit test for function get_bin_path
def test_get_bin_path():
    # pylint: disable=redefined-outer-name
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.file import tmp_executable
    from ansible.module_utils.common._collections_compat import Sequence
    import pytest

    # Get path to Python executable since this is expected to exist on all systems
    python_bin_path = sys.executable

    # This should be in the same directory as this file
    test_path = os.path.dirname(os.path.abspath(__file__))

    # Allow PATH environment variable to be overridden by test runner
    # This is needed in Windows to point to the WINDOWS\system32 directory or tests will fail
    test_env = os.environ.copy()

# Generated at 2022-06-11 01:27:19.017467
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 01:27:24.377892
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('grep') == '/bin/grep'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('dummy-non-existent-executable') == None
    try:
        get_bin_path('dummy-non-existent-executable', required=True)
    except ValueError:
        pass
    else:
        assert "Should have raised ValueError"

# Generated at 2022-06-11 01:27:33.972828
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os
    import sys

    if sys.version_info[0] > 2:
        from unittest.mock import Mock
    else:
        from mock import Mock

    # Note that test_paths is used in the test_paths directory since all the directories
    # are relative to the test directory (which is test_paths) and upon creation of this mock
    # module, the current working directory is the test directory.
    test_paths = tempfile.mkdtemp()
    exec_a = os.path.join(test_paths, 'a')
    exec_b = os.path.join(test_paths, 'b')
    dir_a = os.path.join(test_paths, 'a_dir')

# Generated at 2022-06-11 01:27:43.100343
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('test_file_not_found', required=False)
    except ValueError:
        pass
    else:
        raise ValueError

    assert get_bin_path('bash', required=False) == '/bin/bash'
    try:
        get_bin_path('bash', opt_dirs=['/bin'], required=False)
    except ValueError:
        raise ValueError('Should not throw exception')
    try:
        get_bin_path('bash', opt_dirs=['/binn'], required=False)
    except ValueError:
        raise ValueError('Should not throw exception')

# Generated at 2022-06-11 01:27:49.409576
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' unit test for get_bin_path'''
    assert get_bin_path('openssl')
    assert get_bin_path('openssl', ['/usr/local/bin'])
    try:
        get_bin_path('foo')
        assert False, 'Failed to raise ValueError.'
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    assert get_bin_path('openssl', ['/usr/local/bin', '/usr/local/sbin'])

# Generated at 2022-06-11 01:28:00.585248
# Unit test for function get_bin_path
def test_get_bin_path():
    path_name='/bin:/sbin:/usr/bin'
    try:
        get_bin_path('invalidapp', opt_dirs=path_name, required=True)
    except ValueError as e:
        assert 'Failed to find required executable "invalidapp" in paths: /bin:/sbin:/usr/bin' in str(e)
    path_name='/bin:/sbin:/usr/bin'
    try:
        get_bin_path('invalidapp', opt_dirs=path_name, required=False)
    except ValueError as e:
        assert 'Failed to find required executable "invalidapp" in paths: /bin:/sbin:/usr/bin' in str(e)

    path_name='/bin:/sbin:/usr/bin'

# Generated at 2022-06-11 01:28:09.746388
# Unit test for function get_bin_path
def test_get_bin_path():
    import mock
    from ansible.module_utils.six import StringIO

    f = StringIO()
    with mock.patch('ansible.module_utils.basic.get_bin_path') as mo:
        mo.return_value = '/usr/bin/ansible-galaxy'
        test_path = get_bin_path(arg='ansible-galaxy')
        mo.assert_called_with(arg='ansible-galaxy')
        print('ansible-galaxy path', test_path, file=f)
        assert test_path == '/usr/bin/ansible-galaxy'
        assert mo.call_count == 1

# Generated at 2022-06-11 01:28:12.854089
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Make sure executable is found on standard paths.
    '''
    bin_path = get_bin_path('ls')
    assert bin_path.endswith('/ls'), 'bin_path =="%s" should end with "/ls"' % bin_path

# Generated at 2022-06-11 01:28:23.782635
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    from ansible.module_utils._text import to_bytes, to_native

    # Check required executable is returned in PATH
    try:
        path = get_bin_path('cat')
        assert path == to_native(to_bytes(os.path.realpath(path)))
    except ValueError:
        raise AssertionError('Failed to find "cat" in PATH')

    # Check executable is returned in PATH when looking for directory name
    try:
        path = get_bin_path('/bin/cat')
        assert os.path.isdir(path) == False
        assert path == to_native(to_bytes(os.path.realpath(path)))
    except ValueError:
        raise AssertionError('Failed to find "/bin/cat" in PATH')

    # Check that ValueError is raised

# Generated at 2022-06-11 01:28:33.725737
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/python2')
    try:
        get_bin_path('/usr/bin/doesnt_exist')
        assert False
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

    # Check all optional parameters
    assert get_bin_path(arg='/usr/bin/python2', opt_dirs=['/usr/bin'], required=False)
    try:
        get_bin_path('/usr/bin/doesnt_exist', ['/usr/bin'], False)
        assert False
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

    # Check invalid types for optional parameters

# Generated at 2022-06-11 01:28:45.101115
# Unit test for function get_bin_path
def test_get_bin_path():
    print("Testing get_bin_path function")
    testexec = 'ansible-test-exec'
    default_path = '/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:/bin:/sbin'
    orig_path = os.environ['PATH']
    for p in os.environ['PATH'].split(':'):
        os.environ['PATH'] = ':'.join([p, default_path])
        try:
            assert get_bin_path(testexec) == p + '/' + testexec
        except ValueError:
            print('testexec %s is not in path %s' % (testexec, os.environ['PATH']))
            os.environ['PATH'] = orig_path
        # Test optional parameters

# Generated at 2022-06-11 01:28:50.661685
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no_exist_bin', ['/fake/path/'])
    except ValueError as e:
        assert 'Failed to find required executable "no_exist_bin" in paths' in to_text(e)

    try:
        get_bin_path('ls')
    except ValueError as e:
        assert 'Failed to find required executable "ls" in paths' not in to_text(e)

# Generated at 2022-06-11 01:29:00.496558
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import stat
    import tempfile

    # A simple binary file
    (dummy_fd, dummy) = tempfile.mkstemp()
    os.close(dummy_fd)
    os.chmod(dummy, stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)
