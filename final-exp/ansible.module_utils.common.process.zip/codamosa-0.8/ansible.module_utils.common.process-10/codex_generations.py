

# Generated at 2022-06-11 01:19:16.436384
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for function get_bin_path
    '''
    opt_dirs = ['/opt/sbin']
    assert get_bin_path('ping', opt_dirs) == '/usr/sbin/ping'
    assert get_bin_path('foo') == '/sbin/foo'

# Generated at 2022-06-11 01:19:23.669477
# Unit test for function get_bin_path
def test_get_bin_path():
    # Empty bin path
    try:
        get_bin_path(arg=None)
    except ValueError as e:
        assert "Failed to find required executable" in e.args[0]
    # Bin not found
    try:
        get_bin_path(arg="invalid_bin")
    except ValueError as e:
        assert "Failed to find required executable" in e.args[0]
    # Valid bin
    bin_path = get_bin_path(arg="ls")
    assert bin_path and is_executable(bin_path)

# Generated at 2022-06-11 01:19:31.699786
# Unit test for function get_bin_path
def test_get_bin_path():
    # Get the path for system executable sh. Returns full path.
    exe_path = get_bin_path('sh')
    assert exe_path is not None

    # Get the path for system executable false. Returns full path.
    exe_path = get_bin_path('false')
    assert exe_path is not None

    # Get the path for system executable true. Returns full path.
    exe_path = get_bin_path('true')
    assert exe_path is not None

    # Get the path for system executable cowsay. Returns full path.
    exe_path = get_bin_path('cowsay')
    assert exe_path is not None

    # Get the path for system executable fortune. Returns full path.
    exe_path = get_bin_path('fortune')
    assert exe_path

# Generated at 2022-06-11 01:19:38.327398
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    test_dir = tempfile.mkdtemp()
    f = open(os.path.join(test_dir, 'test_get_bin_path_ansible'), 'w')
    f.close()
    os.chmod(f.name, 0o777)

    assert get_bin_path('test_get_bin_path_ansible', [test_dir]) == os.path.join(test_dir, 'test_get_bin_path_ansible')
    os.unlink(f.name)
    os.rmdir(test_dir)

# Generated at 2022-06-11 01:19:44.491368
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    try:
        get_bin_path('pythona', required=False)
        assert False
    except ValueError as e:
        assert 'Failed to find required executable "pythona"' in str(e)
    assert get_bin_path('pythona', required=True) == '/usr/bin/pythona'
    assert get_bin_path('python', opt_dirs=['/usr/bin/pythona']) == '/usr/bin/pythona'
    assert get_bin_path('pythona', opt_dirs=['/usr/bin/']) == '/usr/bin/pythona'

# Generated at 2022-06-11 01:19:56.828082
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils import basic
    import os

    # Arrange
    module = basic.AnsibleModule(argument_spec=dict(
        args=dict(type='str', required=True),
        opt_dirs=dict(type='list'),
        required=dict(type='bool', default=False),
    ))

    # Act/Assert
    module.run_command_environ_update = dict()
    module.run_command_environ_update['PATH'] = os.getenv('PATH')
    module.run_command_environ_update['PATH'] = to_bytes(module.run_command_environ_update['PATH'])

# Generated at 2022-06-11 01:20:07.520280
# Unit test for function get_bin_path
def test_get_bin_path():
    fix_paths = [os.path.join('/', 'tmp', 'test'), os.path.join('/', 'usr', 'bin')]

    try:
        get_bin_path("not_exists_file")
    except ValueError as e:
        assert e.args[0] == 'Failed to find required executable "not_exists_file" in paths: /usr/bin:/opt/ansible'

    try:
        get_bin_path("not_exists_file", fix_paths)
    except ValueError as e:
        assert e.args[0] == 'Failed to find required executable "not_exists_file" in paths: /tmp/test:/usr/bin'

# Generated at 2022-06-11 01:20:09.427995
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(arg='sh') == '/bin/sh'

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 01:20:20.214730
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    test_path = os.path.join(tempfile.mkdtemp(), 'test_file')
    test_path_contents = "test_file_contents"

    # Create test file
    fh = open(test_path, 'w')
    fh.write(test_path_contents)
    fh.write("\n")
    fh.close()

    # Make test file executable
    cmd = "chmod +x %s" % test_path
    rc, out, err = module.run_command(cmd)

    # test_path is executable and is found in temp directory
    assert(rc == 0)
    assert(os.path.exists(test_path))
    assert(is_executable(test_path))

    # get_bin_path() should be able to find

# Generated at 2022-06-11 01:20:28.472955
# Unit test for function get_bin_path
def test_get_bin_path():
    assert is_executable('/usr/bin/python')
    assert is_executable('/usr/bin/python')
    assert is_executable('/bin/ls')
    assert is_executable('/bin/ls')
    assert not is_executable('/bin/ls', enforce_interpreter=True)
    assert not is_executable('/usr/bin/python', enforce_interpreter=True)
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('python') == '/usr/bin/python'

# Generated at 2022-06-11 01:20:31.885458
# Unit test for function get_bin_path
def test_get_bin_path():
    my_dir = os.path.dirname(__file__)
  

# Generated at 2022-06-11 01:20:43.266433
# Unit test for function get_bin_path
def test_get_bin_path():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    # Directory layout for unit test
    # tmpdir/a -> /usr/bin/ansible
    # tmpdir/b/c -> /usr/bin/ansible
    # tmpdir/d/e -> /usr/bin/ansible

    with TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        os.symlink('/usr/bin/ansible', 'a')
        os.makedirs('b/c')
        os.symlink('/usr/bin/ansible', 'b/c/ansible')
        os.symlink(os.path.abspath('b/c/ansible'), 'd/e/ansible')

        # POSIX 'which' command

# Generated at 2022-06-11 01:20:51.358623
# Unit test for function get_bin_path
def test_get_bin_path():

    paths = os.environ.get('PATH', '').split(os.pathsep)

    # test with valid executable
    try:
        assert get_bin_path('ansible-playbook')
    except:
        assert False

    # test with invalid executable
    try:
        get_bin_path('bad-exec')
    except ValueError:
        assert True

    # test on not found executable
    try:
        get_bin_path('bad-exec', opt_dirs=['/tmp/'])
    except ValueError:
        assert True

    # test with extra dir in PATH
    tmp_dir = '/tmp/test_get_bin_path'
    os.makedirs(tmp_dir)
    f = '/tmp/test_get_bin_path/testfile'

# Generated at 2022-06-11 01:20:57.907241
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic
    import sys

    def mock_module_params(bin_name, opt_dirs=None, required=None):
        basic._ANSIBLE_ARGS = {'_ansible_': {
                                   'forks': 10,
                                   'become': True,
                                   'become_method': 'sudo',
                                   'become_user': 'root',
                                   'check': False,
                                   'diff': False,
                                   'module_name': 'ping',
                                   'no_log': False
                                   },
                               'bin_name': bin_name,
                               'opt_dirs': opt_dirs,
                               'required': required}


# Generated at 2022-06-11 01:21:02.534002
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Validate proper retrieval of the full path to executables that exist in the path.
    '''
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('iptables') == '/usr/sbin/iptables'



# Generated at 2022-06-11 01:21:11.181744
# Unit test for function get_bin_path
def test_get_bin_path():
    my_path = os.path.dirname(os.path.realpath(__file__))
    assert get_bin_path('cat', [os.path.join(my_path, '../files'), os.path.join(my_path, '../files/bin')]) == os.path.join(my_path, '../files/bin/cat')
    assert get_bin_path('cat', [os.path.join(my_path, '../files'), os.path.join(my_path, '../files/bin')]) == os.path.join(my_path, '../files/bin/cat')

# Generated at 2022-06-11 01:21:21.530868
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    test for module_utils.common.get_bin_path
    '''
    # in case there is no file in path
    try:
        get_bin_path('xxx', ['/bin', '/sbin'])
    except ValueError:
        pass
    else:
        assert False, "Failed to get ValueError when no path is found."

    # in case there is a file in path
    try:
        get_bin_path('sh')
    except ValueError:
        assert False, "Failed to find sh in PATH."

    # in case there is a file in path even though its not executable
    # should not raise

# Generated at 2022-06-11 01:21:26.701353
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/yes') == '/usr/bin/yes'
    # On my system, /sbin/ip is a symlink to /bin/ip
    assert get_bin_path('ip', required=True, opt_dirs=['/sbin', '/bin']) == '/sbin/ip'
    assert get_bin_path('ip', required=True, opt_dirs=['/bin']) == '/bin/ip'

# Generated at 2022-06-11 01:21:29.937826
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        binary = get_bin_path('ansible')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    else:
        assert os.path.exists(binary)

# Generated at 2022-06-11 01:21:39.834306
# Unit test for function get_bin_path
def test_get_bin_path():
    # test 'which' as a command.
    which_path = get_bin_path('which')
    assert which_path == '/usr/bin/which'
    # test 'which' with optional search directory
    which_path = get_bin_path('which', opt_dirs=[os.path.dirname(which_path)])
    assert which_path == '/usr/bin/which'
    # test a command that would normally exist, but doesn't
    try:
        get_bin_path('not_a_command', required=True)
    except ValueError:
        assert True
    else:
        assert False

    # test a command that would normally exist, but doesn't, but we pass in a cwd to search

# Generated at 2022-06-11 01:21:51.626650
# Unit test for function get_bin_path
def test_get_bin_path():
    # Paths to search. 3rd value contains /sbin dirs.
    paths = [
        '/usr/bin:/bin',
        '/usr/bin:/bin:/opt/bin',
        '/usr/bin:/bin:/sbin:/usr/sbin:/usr/local/sbin',
    ]

    # Test cases [arg, opt_dirs, expected_path]

# Generated at 2022-06-11 01:22:01.053058
# Unit test for function get_bin_path
def test_get_bin_path():
    def test_exception(arg, opt_dirs=None):
        try:
            bin_path = get_bin_path(arg, opt_dirs)
        except ValueError as e:
            if 'Failed to find required executable' not in str(e):
                raise
        else:
            raise AssertionError("get_bin_path() should raise ValueError")

    bin_path = get_bin_path("true")
    if bin_path != "/bin/true":
        raise AssertionError("get_bin_path() should return /bin/true")

    test_exception("not_exists_file")

    bin_path = get_bin_path("true", ['/bin/not_exists_dir'])

# Generated at 2022-06-11 01:22:11.632524
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test should not throw an exception
    assert get_bin_path("/usr/bin/python")
    # Test should not throw an exception
    assert get_bin_path("/usr/bin/python", opt_dirs=[])
    # Test should not throw an exception
    assert get_bin_path("/usr/bin/python", opt_dirs=["/tmp", "/usr/bin/"])
    # Test should throw an exception
    try:
        get_bin_path("/usr/bin/python", required=False)
    except ValueError:
        assert False
    # Test should throw an exception
    try:
        get_bin_path("/tests/test_file", required=True)
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-11 01:22:21.430701
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    paths = []

# Generated at 2022-06-11 01:22:28.923430
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path("/usr/bin/python2.7")
    except ValueError:
        raise AssertionError("Executable should be found in standard path.")

    # Verify that function raises an exception for invalid executable
    try:
        get_bin_path("invalid_executable")
    except ValueError:
        pass
    else:
        raise AssertionError("ValueError exception should be raised")

    # Verify that the function searches in optional directories
    try:
        get_bin_path("/bin/ls", ["/usr/bin"])
    except ValueError:
        raise AssertionError("Executable should be found in optional path.")

    # Verify that function raises an error for executable in optional directory

# Generated at 2022-06-11 01:22:38.415366
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import errno
    from ansible.module_utils.common.file import missing_libs

    cmd = 'cmd' if missing_libs.get_libc_version()[0] > 2 else b'cmd'
    try:
        tmp_dir = tempfile.gettempdir()
        tmp_file = os.path.join(tmp_dir, 'ansible')
        with open(tmp_file, 'wb') as f:
            f.write(cmd)
        os.chmod(tmp_file, 0o755)
        assert get_bin_path('ansible', [tmp_dir]) == tmp_file
    except OSError as e:
        if e.errno != errno.EPERM:
            raise

# Generated at 2022-06-11 01:22:47.452836
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1 - find an executable that is in the default PATH
    if 'PATH' not in os.environ:
        os.environ['PATH'] = ''
    try:
        get_bin_path('ls')
    except ValueError:
        assert False, 'Expected successful call to get_bin_path(), but it failed'

    # Test 2 - find an executable in a directory that is not in the default path
    tdir = os.path.dirname(__file__)
    try:
        get_bin_path('ls', opt_dirs=[tdir])
    except ValueError:
        assert False, 'Expected successful call to get_bin_path(), but it failed'

# Generated at 2022-06-11 01:22:54.880552
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == "/bin/ls"
    assert get_bin_path('pwd', ['/bin', '/usr/bin']) == "/bin/pwd"
    got_error = False
    try:
        get_bin_path('nonexistent_command')
    except ValueError:
        got_error = True
    assert got_error
    got_error = False
    try:
        get_bin_path('ls', ['/nonexistent/path'])
    except ValueError:
        got_error = True
    assert got_error

# Generated at 2022-06-11 01:23:01.649940
# Unit test for function get_bin_path
def test_get_bin_path():
    '''get_bin_path should return the path to grep from the system 'PATH' variable'''
    try:
        bin_path = get_bin_path('grep')
    except Exception as e:
        raise Exception("Failed to find required executable 'grep' in paths: %s" % e)

    if (bin_path.find('grep') == -1):
        raise Exception("Failed to find required executable 'grep'")

# Generated at 2022-06-11 01:23:10.440100
# Unit test for function get_bin_path
def test_get_bin_path():
    from tempfile import mkdtemp
    from shutil import rmtree

    # Create a temporary directory
    tmpdir = mkdtemp()

    # Create a temporary "fake" executable
    fn = os.path.join(tmpdir, "get_bin_path.unit.test")
    f = open(fn, "w")
    f.write("#!/bin/bash")
    f.close()
    os.chmod(fn, 0o755)

    # Create a temporary sub directory
    tmpdir_sub = os.path.join(tmpdir, "subdir")
    os.mkdir(tmpdir_sub)

    # Check to see if get_bin_path finds the "fake" executable
    assert get_bin_path('get_bin_path.unit.test', [tmpdir, tmpdir_sub]) == fn

   

# Generated at 2022-06-11 01:23:20.759211
# Unit test for function get_bin_path
def test_get_bin_path():

    def fake_executable(path):
        return True if os.path.splitext(path)[1] == '.exe' else False

    is_executable_save = is_executable

# Generated at 2022-06-11 01:23:25.175854
# Unit test for function get_bin_path
def test_get_bin_path():
    test_paths = ['/bin', '/usr/bin', '/usr/local/bin']
    assert get_bin_path('echo', test_paths) == '/bin/echo'
    assert get_bin_path('/bin/echo', test_paths) == '/bin/echo'
    assert get_bin_path('/usr/bin/echo', test_paths) == '/usr/bin/echo'

# Generated at 2022-06-11 01:23:31.997960
# Unit test for function get_bin_path
def test_get_bin_path():
    #Test that get_bin_path() raises an exception if the executable is not found
    try:
        get_bin_path("not_a_binary")
    except ValueError as e:
        assert "Failed to find required executable" in str(e)
    else:
        assert False, "get_bin_path() did not raise an exception for an executable that was not found"

    # Test that get_bin_path() returns the path to the executable if it is found
    find = get_bin_path("find")
    assert find.endswith("/find"), "get_bin_path() did not return the path of the executable"

# Generated at 2022-06-11 01:23:38.709864
# Unit test for function get_bin_path
def test_get_bin_path():

    assert get_bin_path("python") == "/usr/bin/python"
    assert get_bin_path("python", ["/bin/", "/sbin/"]) == "/usr/bin/python"
    assert get_bin_path("python", ["/bin/", "/sbin/", "/usr/bin/"]) == "/usr/bin/python"
    assert get_bin_path("python", ["/usr/bin/", "/bin/", "/sbin/"]) == "/usr/bin/python"
    assert get_bin_path("python", ["/doesnotexist/", "/tmp/"]) == "/usr/bin/python"
    assert get_bin_path("python", []) == "/usr/bin/python"

# Generated at 2022-06-11 01:23:44.128030
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert get_bin_path('false') == '/bin/false'
    except ValueError:
        print('Failed to find false in PATH')
    try:
        assert get_bin_path('/bin/false') == '/bin/false'
    except ValueError:
        print('Failed to find false in PATH')

# Generated at 2022-06-11 01:23:47.712549
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/foo', '/bar']) == '/bin/ls'
    assert get_bin_path('not_there') == None

# Generated at 2022-06-11 01:23:58.064652
# Unit test for function get_bin_path

# Generated at 2022-06-11 01:24:06.665155
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('__this_path_does_not_exist')
    except ValueError as err:
        assert "Failed to find required executable" in str(err)
    else:
        raise AssertionError("Failed to raise exception for nonexistent path")

    # Fake PATH to ensure that a command that doesn't exist still fails
    fake_path = '/__this_path_does_not_exist__'
    os.environ["PATH"] = fake_path
    try:
        get_bin_path('__this_path_does_not_exist')
    except ValueError as err:
        assert fake_path in str(err)
    else:
        raise AssertionError("Failed to raise exception for nonexistent path")

    # Don't fail when PATH is empty
    os.environ["PATH"] = ''

# Generated at 2022-06-11 01:24:07.816405
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'


# Generated at 2022-06-11 01:24:10.926075
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('echo') == '/bin/echo'

    try:
        get_bin_path('cowsay')
        assert False, "Did not fail to find cowsay"
    except ValueError:
        pass

# Generated at 2022-06-11 01:24:24.860730
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import sys
    import tempfile

    tempdir = tempfile.gettempdir()
    tempdir = os.path.realpath(tempdir)

    def create_executable(dirname, name, content=b''):
        basename = os.path.join(dirname, name)
        with open(basename, 'wb') as f:
            f.write(content)
        from stat import S_IEXEC, S_IRUSR, S_IXUSR, S_IRGRP, S_IXGRP
        if sys.platform == 'win32':
            from stat import S_IREAD, S_IWRITE
            os.chmod(basename, S_IWRITE | S_IREAD | S_IXUSR | S_IEXEC)

# Generated at 2022-06-11 01:24:31.578488
# Unit test for function get_bin_path
def test_get_bin_path():
    # Get a known executable
    bash = get_bin_path('bash')
    assert bash == '/bin/bash' or bash == '/usr/bin/bash'

    # Test validation
    try:
        get_bin_path('fake_command')
    except ValueError as e:
        assert "Failed to find" in str(e)
    else:
        assert False, "A ValueError should have been raised"

# Generated at 2022-06-11 01:24:36.171588
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Basic unit test for function get_bin_path
    '''

    res = False
    try:
        bp = get_bin_path('test_foo_bar')
    except ValueError:
        res = True

    assert res, "Expect ValueError for test_foo_bar"

# Generated at 2022-06-11 01:24:39.737044
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/bin/python')
    except ValueError:
        assert False, 'Python not found in paths'
    try:
        get_bin_path('/bin/python-not-found')
        assert False, 'Expected error if python not found'
    except ValueError:
        pass
    try:
        get_bin_path('/bin/python', ['/bin'])
    except ValueError:
        assert False, 'Python not found in /bin'
    try:
        get_bin_path('/bin/python', ['/sbin'])
    except ValueError:
        assert False, 'Python not found in /sbin'


# Generated at 2022-06-11 01:24:42.139782
# Unit test for function get_bin_path
def test_get_bin_path():
    service_path = get_bin_path('service')
    assert is_executable(service_path)

# Generated at 2022-06-11 01:24:52.656680
# Unit test for function get_bin_path
def test_get_bin_path():
    # test search a few existing binaries
    assert get_bin_path('ssh')
    assert get_bin_path('reboot')
    assert get_bin_path('ping')

    # test that raising the error is required
    try:
        get_bin_path('foo')
        # if it doesn't raise an error
        raise AssertionError
    except ValueError:
        pass

    # test that raising the error is required with extra dirs
    try:
        get_bin_path('foo', opt_dirs=['/bin'])
        # if it doesn't raise an error
        raise AssertionError
    except ValueError:
        pass

    # test that invalid required value raises an error

# Generated at 2022-06-11 01:25:03.915906
# Unit test for function get_bin_path
def test_get_bin_path():
    def os_path_exists(path):
        '''This is a mock os.path.exists()'''
        if path == '/bin/ls':
            return True
        else:
            return False

    # Patch os.path.exists so we don't actually have to install every binary in order to test.
    # Patching /bin/ls to return True since that should always exist.
    if not os.path.exists("/bin/ls"):
        os.path.exists = os_path_exists

    # Test valid path
    try:
        path = get_bin_path("ls")
        assert path == "/bin/ls"
    except Exception:
        assert False

    # Test missing path

# Generated at 2022-06-11 01:25:13.263595
# Unit test for function get_bin_path
def test_get_bin_path():

    # Test with a valid executable for the current system
    executable = 'ls' if os.name != 'nt' else 'ipconfig'
    assert get_bin_path(executable) is not None

    # Test with an invalid executable
    try:
        get_bin_path('this_is_an_invalid_executable')
    except ValueError:
        assert True
    else:
        assert False, 'Expected exception on invalid executable'

#
# This code is simply for debugging / unit testing of this module
#
if __name__ == '__main__':

    import sys
    for executable in sys.argv[1:]:
        print('get_bin_path(%s) = %s' % (executable, get_bin_path(executable)))

    test_get_bin_path()

# Generated at 2022-06-11 01:25:23.187530
# Unit test for function get_bin_path
def test_get_bin_path():
    test_paths = [
        '/usr/bin:/usr/sbin',
        '/usr/sbin:/usr/bin',
        '/usr/sbin',
        '/usr/bin:/usr/sbin',
    ]
    bad_test_path = '/does/not/exist:/usr/bin:/usr/sbin'
    for p in test_paths:
        assert get_bin_path('cat', opt_dirs=p.split(':')) == '/bin/cat'
    try:
        get_bin_path('cat', opt_dirs=bad_test_path.split(':'))
    except ValueError as e:
        return
    raise Exception('Test failed')

# Generated at 2022-06-11 01:25:26.029885
# Unit test for function get_bin_path
def test_get_bin_path():
    executable = 'ansible-playbook'
    assert get_bin_path(executable) is not None



# Generated at 2022-06-11 01:25:37.743104
# Unit test for function get_bin_path
def test_get_bin_path():
    # None of these files exist, therefore get_bin_path should fail
    try:
        get_bin_path('/usr/bin/ansible-none')
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError exception')

    # These files exist, therefore get_bin_path should succeed
    try:
        get_bin_path('/bin/bash')
    except ValueError:
        raise AssertionError('Expected no ValueError exception')

    try:
        get_bin_path('/bin/awk')
    except ValueError:
        raise AssertionError('Expected no ValueError exception')

# Generated at 2022-06-11 01:25:40.766958
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('/usr/bin/sh') == '/usr/bin/sh'

# Generated at 2022-06-11 01:25:48.224885
# Unit test for function get_bin_path
def test_get_bin_path():
    # All of these should raise
    args = [
        (None,),
        ('/does/not/exist',),
        ('/etc/passwd',),
    ]

    for arg in args:
        try:
            get_bin_path(*arg)
        except ValueError:
            pass
        else:
            raise AssertionError('get_bin_path(%s) should have raised an exception' % (arg,))

    # All of these should return successfully
    args = [
        ([], 'ls'),
        (None, '/bin/ls'),
        (None, '/usr/bin/ls'),
        (None, 'ls'),
        (['/usr/bin'], 'ls'),
        (['/usr/bin', '/usr/sbin'], 'ls'),
    ]

    expected = '/bin/ls'

# Generated at 2022-06-11 01:25:50.448528
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('echo') == 'echo'
    assert get_bin_path('ansible') == 'ansible'

# Generated at 2022-06-11 01:25:54.548706
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path("foo")
    assert bin_path is not None
    prefer_opt_dir = get_bin_path("foo", opt_dirs=["/usr/bin"])
    assert prefer_opt_dir == "/usr/bin/foo"

# Generated at 2022-06-11 01:26:03.688675
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('nope')
    except ValueError:
        pass
    else:
        assert False, 'Failed to raise exception for non-existant command'

    try:
        import sys
        get_bin_path(sys.executable)
    except ValueError:
        assert False, 'Failed to find existing command %s' % sys.executable

    bin_path = get_bin_path('python')
    assert bin_path.endswith('/python')
    bin_path = get_bin_path('python', opt_dirs=['/usr/bin'])
    assert bin_path.endswith('/usr/bin/python')

# Generated at 2022-06-11 01:26:14.175517
# Unit test for function get_bin_path
def test_get_bin_path():

    def mock_is_executable(arg):
        return True if arg == os.path.join(test_paths[0], 'cmd') else False

    with mock.patch('ansible.module_utils.common.file.is_executable', mock_is_executable):
        try:
            # no command path
            get_bin_path('cmd')
            assert True == False, "Should have raised ValueError"
        except ValueError:
            pass

        # command path with additional dirs
        test_paths = ['/dir1', '/dir2']
        os.environ['PATH'] = os.pathsep.join(test_paths[1:])

# Generated at 2022-06-11 01:26:15.521328
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-11 01:26:23.838652
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['/bin', '/usr/bin', '/usr/local/bin', '/sbin', '/usr/sbin', '/usr/local/sbin']

    # Test to find which 'sh' from non-root.
    assert get_bin_path('sh') in ['/bin/sh', '/usr/bin/sh', '/usr/local/bin/sh']

    # Test to find 'sh' from list of directories.
    for path in paths:
        assert get_bin_path('sh', [path]) == '/bin/sh'

    # Test to fail to find 'sh' when not in PATH.
    try:
        get_bin_path('sh', ['/usr/sbin'])
        assert False
    except ValueError:
        pass

    # Test to find 'sh' from current directory.
    assert get_bin_path

# Generated at 2022-06-11 01:26:33.913386
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1: test if get_bin_path() raises an exception if required executable is missing
    find_missing_executable = ['this_program_does_not_exist']
    for exe in find_missing_executable:
        try:
            get_bin_path(exe)
        except ValueError:
            continue
        # The following line will never be executed
        raise AssertionError('get_bin_path() failed to raise an exception for missing executable %s' % exe)

    # Test 2: test if get_bin_path() returns a path for valid executables
    find_valid_executables = ['wc', 'grep', 'id']
    for exe in find_valid_executables:
        try:
            path = get_bin_path(exe)
        except ValueError:
            raise Assert

# Generated at 2022-06-11 01:26:47.940194
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test normal scenario
    bin_path = get_bin_path('ansible-playbook', opt_dirs=['/usr/local/bin', '/usr/bin'])
    assert bin_path == '/usr/bin/ansible-playbook'

    # Test on non-existent executable
    try:
        get_bin_path('ansible-playbook', opt_dirs=['/usr/local/bin'])
    except ValueError as exc:
        assert str(exc) == 'Failed to find required executable "ansible-playbook" in paths: /usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin'
    else:
        assert False, "test for exc ValueError not raised"


# Generated at 2022-06-11 01:26:56.434800
# Unit test for function get_bin_path
def test_get_bin_path():
    # Exists in path
    assert get_bin_path("ls") == "/bin/ls"

    # Does not exist
    try:
        get_bin_path("nonexistant_executable")
    except ValueError:
        pass

    # Exists in a directory given in opt_dirs
    assert get_bin_path("ifconfig", ["/sbin"]) == "/sbin/ifconfig"

    # Exists in a directory given in opt_dirs, even if it is a symlink
    assert get_bin_path("ifconfig", ["/sbin/../sbin"]) == "/sbin/ifconfig"

    # Exists in a directory given in opt_dirs and in PATH
    assert get_bin_path("ifconfig", ["/sbin"]) == "/sbin/ifconfig"

# Generated at 2022-06-11 01:27:07.905712
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path("pwd")
    assert path == "/bin/pwd"
    path = get_bin_path("pwd", ['/usr/bin'])
    assert path == "/usr/bin/pwd"
    path = get_bin_path("pwd", ['/usr/bin'], ['/usr/bin'])
    assert path == "/usr/bin/pwd"
    try:
        get_bin_path("pwd", ['/usr/bin'], ['/usr/sbin'])
    except ValueError as e:
        assert "/usr/sbin" in str(e)

# Generated at 2022-06-11 01:27:11.397391
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('__thisfileshouldnotexistandmaybedoesnot')
    except (ValueError):
        pass

# Generated at 2022-06-11 01:27:20.018767
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('non-existent-command')
    except Exception as e:
        assert isinstance(e, ValueError)

    required_exception_msg = 'Required executable "not_found" not found in paths: /bin:/usr/bin'
    try:
        get_bin_path('not_found')
    except Exception as e:
        assert isinstance(e, ValueError)
        assert str(e) == required_exception_msg

    try:
        get_bin_path('not_found', [])
    except Exception as e:
        assert isinstance(e, ValueError)
        assert str(e) == required_exception_msg

# Generated at 2022-06-11 01:27:21.534305
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("python2") == os.path.normpath("/usr/bin/python2")

# Generated at 2022-06-11 01:27:32.275211
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('python3')
    assert os.path.exists(bin_path)
    bin_path = get_bin_path('python3', opt_dirs=['/usr/local/bin'])
    assert os.path.exists(bin_path)
    try:
        get_bin_path('python3', opt_dirs=['/no/such/path'])
        raise AssertionError("get_bin_path didn't fail")
    except ValueError:
        pass
    try:
        get_bin_path('python3', opt_dirs=['/dev'])
        raise AssertionError("get_bin_path didn't fail")
    except ValueError:
        pass

# Generated at 2022-06-11 01:27:35.607399
# Unit test for function get_bin_path
def test_get_bin_path():
    for b in ['ls', 'grep', 'python']:
        assert get_bin_path(b) is not None


__all__ = ['get_bin_path', 'test_get_bin_path']

# Generated at 2022-06-11 01:27:36.854189
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('sh')
    assert path == '/bin/sh'

# Generated at 2022-06-11 01:27:39.260331
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' returns full path for `tar` executable in PATH '''
    bin_path = get_bin_path('tar')
    assert(bin_path == '/usr/bin/tar')

# Generated at 2022-06-11 01:27:53.069856
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function and some of the logic.
    '''

    # Test 1: Check that an existing executable in PATH is found
    try:
        f = get_bin_path('/usr/bin/id')
    except ValueError:
        f = None
    assert f == '/usr/bin/id'

    # Test 1: Check that an existing executable not in PATH is not found
    try:
        f = get_bin_path('/usr/bin/id', opt_dirs=['/usr/bin/'])
    except ValueError:
        f = None
    assert f == '/usr/bin/id'

    # Test 2: Check that a non-executable is not found

# Generated at 2022-06-11 01:28:03.771087
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for bad executable
    try:
        get_bin_path('bad-executable')
        assert False, 'Exception should have been thrown'
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "bad-executable" in paths: '

    # Test for existing executable
    assert get_bin_path('ls')

    # Test for existing executable in specific path
    assert get_bin_path('ls', ['/bin'])

    # Test for existing executable in specific path that is not in PATH
    assert get_bin_path('ls', ['/tmp'])

    # Test for existing executable in optional path that is not in PATH
    assert get_bin_path('ls', opt_dirs=['/tmp'])

# Generated at 2022-06-11 01:28:13.598528
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    from ansible.module_utils._text import to_bytes

    path = tempfile.mkdtemp()
    file_path = os.path.join(path, 'ansible-test-file')
    with open(file_path, 'w') as f:
        f.write('#!/bin/sh')
    os.chmod(file_path, 0o755)

    assert get_bin_path(to_bytes('ansible-test-file'), opt_dirs=[path]) == file_path

    # If ansible-test-file is not found in opt_dirs, then it should look in path.
    # If opt_dirs is not set, then it should look in path.
    assert get_bin_path(to_bytes('ansible-test-file'))
    assert get_bin_path

# Generated at 2022-06-11 01:28:24.854572
# Unit test for function get_bin_path
def test_get_bin_path():
    # Can find which
    # which should always be in PATH
    bin_path = get_bin_path('which')

    # Can't find sdfjhjsdf2342342
    try:
        get_bin_path('sdfjhjsdf2342342')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

    # Can't find sdfjhjsdf2342342 with fake path
    try:
        get_bin_path('sdfjhjsdf2342342', opt_dirs=['/fake/bin'])
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

    # Can find echo
    # echo exists in PATH, but it is not executable

# Generated at 2022-06-11 01:28:29.711809
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh')
    assert get_bin_path('sh', required=True)
    assert get_bin_path('awk')
    assert get_bin_path('awk', required=True)
    assert get_bin_path('/bin/sh')
    assert get_bin_path('/bin/sh', required=True)

# Generated at 2022-06-11 01:28:36.579224
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import os.path
    import __main__ as main
    import ansible.module_utils.common.file as file_utils

    # Set PATH to known value and ensure that a known utility exists in the path
    which_path = os.path.dirname(file_utils.which(main.__file__))
    PATH = os.path.dirname(which_path)
    os.environ['PATH'] = PATH

    # Verify that get_bin_path works when the path to the utility is in PATH
    the_path = get_bin_path('echo')
    assert the_path.endswith('/bin/echo')

    # Verify that get_bin_path raises a ValueError when the path to the utility is not in PATH

# Generated at 2022-06-11 01:28:47.473222
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('python')
    get_bin_path('python', required=True)
    get_bin_path('python', ['/usr/local/bin', '/usr/bin'])
    get_bin_path('python', ['/usr/local/bin', '/usr/bin'], required=True)

    try:
        get_bin_path('python', ['/usr/local/bin'])
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    try:
        get_bin_path('python', ['/usr/local/bin'], required=True)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    try:
        get_bin_path('xyzzy')
    except ValueError:
        pass
   

# Generated at 2022-06-11 01:28:49.524570
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('python')
    assert path is not None
    assert path.endswith('python')

# Compatibility for Ansible 2.9
if not hasattr(__builtins__, 'FileNotFoundError'):
    FileNotFoundError = IOError

# Generated at 2022-06-11 01:28:54.920950
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Make sure get_bin_path returns the correct path of 'wc' utility.
    '''
    try:
        get_bin_path('wc')
    except ValueError:
        # there is no wc in non-interactive mode in travis-ci
        return

    assert os.path.exists(get_bin_path('wc'))

# Generated at 2022-06-11 01:28:59.373121
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('cat') == '/bin/cat'
    try:
        get_bin_path('_$&*#')
    except ValueError:
        pass
    else:
        raise AssertionError('should have failed')

# Generated at 2022-06-11 01:29:12.660841
# Unit test for function get_bin_path
def test_get_bin_path():
    test_args = (
        '/bin/env',
        '/bin/sleep',
        '/bin/no-such-exe',
        '/bin/sleep-foo',
    )

    for test_arg in test_args:
        try:
            assert get_bin_path(test_arg) == test_arg
        except ValueError:
            assert test_arg.endswith('-foo')

    try:
        assert get_bin_path('/bin/sleep', required=True) == '/bin/sleep'
    except ValueError:
        pass

    try:
        assert get_bin_path('/bin/sleep-foo', required=True)
    except ValueError:
        pass

    # make sure additional directories are searched