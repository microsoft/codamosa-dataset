

# Generated at 2022-06-20 16:04:57.837996
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    # test with a command that is available in path
    command = 'ls'
    bin_path = get_bin_path(command)
    assert bin_path.endswith(command)
    # test with a command that is not available in path
    command = 'not_a_command'
    with pytest.raises(ValueError):
        bin_path = get_bin_path(command)

# Generated at 2022-06-20 16:05:08.363876
# Unit test for function get_bin_path
def test_get_bin_path():
    # Get the script bin dir
    CURRENT_DIR = os.path.dirname(os.path.realpath(__file__))
    BIN_DIR = os.path.join(CURRENT_DIR, "../../../bin")
    BIN_DIR = os.path.abspath(BIN_DIR)

    assert get_bin_path('ansible-doc') == os.path.join(BIN_DIR, 'ansible-doc')
    assert get_bin_path('ansible-galaxy') == os.path.join(BIN_DIR, 'ansible-galaxy')
    assert get_bin_path('ansible-test') == os.path.join(BIN_DIR, 'ansible-test')

# Generated at 2022-06-20 16:05:10.801453
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test is compatible only with Linux
    if os.name == 'posix':
        assert get_bin_path('which') == '/usr/bin/which'

# Generated at 2022-06-20 16:05:18.306062
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Error conditions are tested by function run_isolated_module
    in test module test_integration_isolated_module.py.
    Here only test the expected behavior.
    '''

    tmp_base = '/tmp'
    if not os.path.exists(tmp_base):
        tmp_base = '/var/tmp'

    # Create a temporary directory
    tmp_dir = '%s/test_get_bin_path.XXXXXX' % tmp_base
    from tempfile import mkdtemp
    tmp_dir = mkdtemp(dir=tmp_base, prefix='test_get_bin_path.')

    # Create an executable file
    bin_path = os.path.join(tmp_dir, "which.sh")

# Generated at 2022-06-20 16:05:26.148713
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import shutil
    import tempfile

    # Attempt to find a program
    try:
        which_exe = get_bin_path('which', opt_dirs=[])
    except ValueError:
        # If which is missing, skip the test
        return

    # Folder paths
    tmpdir = tempfile.mkdtemp(prefix='ansible_test_get_bin_path')

# Generated at 2022-06-20 16:05:31.019244
# Unit test for function get_bin_path
def test_get_bin_path():
    expected_path_to_sed = '/bin/sed'
    actual_path_to_sed = get_bin_path('sed')
    assert actual_path_to_sed == expected_path_to_sed
    assert get_bin_path('foo') is None

# Generated at 2022-06-20 16:05:37.444229
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import platform

    # create temp directory to work in
    test_dir = tempfile.mkdtemp()
    opt_dirs = [test_dir]

    test_exec = 'ansible_test_exe'
    if platform.system() == 'Windows':
        test_exec += '.exe'

    # create temp exe file
    test_exe = os.path.join(test_dir, test_exec)
    with open(test_exe, 'w') as f:
        f.write('#!/bin/sh\n')
        f.write('exit 0')

    # make it exectable
    os.chmod(test_exe, 0o755)

    # find temp exe in test_dir (should pass) and assert that it is full path
    test_path = get

# Generated at 2022-06-20 16:05:48.592641
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import os
    import ansible.module_utils.common.file as file_utils
    # Test that we don't find a non-existant file
    try:
        get_bin_path('/some/path/that/does/not/exist')
        assert False, 'Exception was not raised'
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    # Create temp dir
    tmpdir = tempfile.mkdtemp()
    # Create a temp file, give permissions, and make sure we can find it
    tempf_name = os.path.join(tmpdir, 'justatest')
    tempf = open(tempf_name, 'w')
    tempf.write('test')
    tempf.close()
    file_utils.set_file_att

# Generated at 2022-06-20 16:05:56.295210
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path(arg='ls')
    assert path == '/bin/ls' or path == '/usr/bin/ls'
    assert '/sbin/ls' not in path
    path = get_bin_path(arg='ls', opt_dirs=['/usr/bin'])
    assert path == '/usr/bin/ls'
    path = get_bin_path(arg='ls', opt_dirs=['/sbin', '/usr/bin'])
    assert path == '/sbin/ls'

# Generated at 2022-06-20 16:06:00.822874
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('does_not_exist', opt_dirs=['/sbin'])
    except ValueError:
        pass
    else:
        raise ValueError('Failed to raise expected exception')

    get_bin_path('/usr/bin/python', opt_dirs=['/sbin'])

# Generated at 2022-06-20 16:06:14.413843
# Unit test for function get_bin_path
def test_get_bin_path():

    if os.path.exists('/etc/passwd'):
        #
        # Success cases
        #

        # Typical case: Executable found in PATH
        assert get_bin_path('cat') == '/bin/cat'

        # Executable with full path
        assert get_bin_path('/bin/cat') == '/bin/cat'

        # Executable found in additional directory
        assert get_bin_path('passwd', opt_dirs=['/usr/bin']) == '/usr/bin/passwd'

        # Executable found in additional directory before existing in PATH
        assert get_bin_path('id', opt_dirs=['/', '/usr/bin']) == '/id'

        # Executable found in PATH and in additional directory, with additional directory first

# Generated at 2022-06-20 16:06:20.927316
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        bin_path = get_bin_path('ansible-doc')
        assert os.path.exists(bin_path)
        assert not os.path.isdir(bin_path)
        assert is_executable(bin_path)
    except ValueError:
        assert False, "ansible-doc not found"

# Generated at 2022-06-20 16:06:33.682055
# Unit test for function get_bin_path
def test_get_bin_path():
    print('Test get_bin_path:')
    # Test when command is in PATH
    assert get_bin_path('grep') == '/bin/grep'

    # Test when command is not in PATH
    try:
        get_bin_path('this-command-does-not-exist')
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "this-command-does-not-exist" in paths: /bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin'

    # Test when command is not in PATH but directory is specified
    assert get_bin_path('grep', ['/bin']) == '/bin/grep'

    # Test when command is not in PATH but directory is specified but not existing

# Generated at 2022-06-20 16:06:40.971736
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') is not None
    assert get_bin_path('sh', ['/bin', '/usr/bin']) is not None
    assert get_bin_path('sh', ['/usr/bin'], True) is not None
    assert get_bin_path('sh', opt_dirs=['/usr/bin'], required=True) is not None
    try:
        get_bin_path('notfound')
    except ValueError:
        pass

# Generated at 2022-06-20 16:06:44.824588
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    try:
        get_bin_path('XXX_NOT_GOING_TO_BE_FOUND_XXX', required=False)
        assert False, 'get_bin_path should have raised an exception'
    except ValueError as e:
        pass


# Generated at 2022-06-20 16:06:52.233614
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path with mocked os and os.path (see mocks.py)
    '''
    # pylint: disable=no-self-use,redefined-outer-name,unused-argument
    # unit tests for get_bin_path
    #
    # first, test the bin path to use for the mock
    # it will be the first of the following to exist
    # /bin/false
    # /bin/true
    # /usr/bin/false
    # /usr/bin/true
    #
    # result should be one of /bin/true or /usr/bin/true
    #
    bin_path = get_bin_path('true')
    assert bin_path == '/usr/bin/true'

# Generated at 2022-06-20 16:06:58.050653
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.file import is_executable

    import tempfile
    import os

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, "testfile")
    testlist = [("bin_path_test", tmp_file)]

    for p, f in testlist:
        assert get_bin_path(p, [tmp_dir]) == f

    os.remove(tmp_file)

# Generated at 2022-06-20 16:07:01.496972
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('/bin/sh')
    assert '/bin/sh' in bin_path
    try:
        get_bin_path('/bin/file_does_not_exist')
    except Exception as e:
        print(e)
        assert 'Failed to find required executable' in e.message

# Generated at 2022-06-20 16:07:10.174277
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('/bin/sh') == '/bin/sh')
    assert(get_bin_path('/bin/bash'))
    assert(get_bin_path('invalid_executable') == None)
    assert(get_bin_path('invalid_executable', opt_dirs=[]) == None)
    assert(get_bin_path('invalid_executable', opt_dirs=['/bin', '/usr/bin']) == None)
    assert(get_bin_path('invalid_executable', opt_dirs=['/bin', '/usr/bin']))
    test_get_bin_path()

# Generated at 2022-06-20 16:07:15.343834
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == get_bin_path('python')
    assert get_bin_path('python', opt_dirs=['/usr/bin']) == get_bin_path('python')
    assert get_bin_path('python', opt_dirs=['/usr/bin', '/bin']) == get_bin_path('python')

    import tempfile
    td = tempfile.mkdtemp()
    f = tempfile.NamedTemporaryFile(delete=False, dir=td)
    f.close()
    try:
        os.chmod(f.name, 0o755)
        assert get_bin_path(f.name, opt_dirs=[td]) == f.name
    finally:
        os.unlink(f.name)
        os.rmdir(td)

# Generated at 2022-06-20 16:07:28.489834
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/echo') == '/bin/echo'

    assert get_bin_path('echo') == '/bin/echo'

    # Test that sbin dirs is always added to PATH and that sbin binaries are found
    assert get_bin_path('ip') == '/sbin/ip'

    assert get_bin_path('ip', opt_dirs=['/bin']) == '/sbin/ip'

    # Test that optional dirs is added to PATH and that binaries in these dirs are found
    assert get_bin_path('echo', opt_dirs=['/bin', '/sbin']) == '/bin/echo'

    # Test that optional dirs overrides PATH
    assert get_bin_path('ip', opt_dirs=['/bin']) == '/bin/ip'

# Generated at 2022-06-20 16:07:32.564784
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('find')
    assert get_bin_path('find', required=True)

# Generated at 2022-06-20 16:07:43.326643
# Unit test for function get_bin_path
def test_get_bin_path():
    def test_path(path, expected_path, expected_exception=None):
        if expected_exception is None:
            assert get_bin_path(path) == expected_path
        else:
            try:
                import ansible.module_utils.common.file as f
                f.get_bin_path(path)
            except Exception as e:
                assert e.__class__ == expected_exception
            else:
                raise Exception("Expected exception %s not raised" % expected_exception)

    test_path('/bin/sh', '/bin/sh')
    test_path('sh', '/bin/sh')
    test_path('invalid_path', None, ValueError)
    test_path('sh', '/invalid_path', ValueError)

# Generated at 2022-06-20 16:07:52.623796
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test get_bin_path with a valid executable in path
    assert get_bin_path('sh')

    # Test get_bin_path with a non-executable in path
    try:
        get_bin_path('/etc/passwd')
    except ValueError:
        pass
    else:
        assert False, "expected an exception"

    # Test get_bin_path with a non-existing file
    try:
        get_bin_path('/not/a/valid/path')
    except ValueError:
        pass
    else:
        assert False, "expected an exception"

# Generated at 2022-06-20 16:08:00.321161
# Unit test for function get_bin_path
def test_get_bin_path():
    test_dirs = ['/bin', '/usr/bin', '/usr/local/bin']
    assert get_bin_path(arg='sh', opt_dirs=test_dirs) == '/bin/sh'
    assert get_bin_path(arg='ifconfig', opt_dirs=test_dirs) == '/sbin/ifconfig'
    assert get_bin_path(arg='foo-baz', opt_dirs=test_dirs) == '/usr/bin/foo-baz'

# Generated at 2022-06-20 16:08:10.940129
# Unit test for function get_bin_path
def test_get_bin_path():
    # Create temp directory
    test_temp_dir = None

# Generated at 2022-06-20 16:08:19.426277
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for system binary
    assert get_bin_path('/bin/cat') == '/bin/cat'
    # For POSIX, there is no system binary /bin/catfile
    try:
        get_bin_path('/bin/catfile')
        assert False, "Should have raised ValueError"
    except ValueError:
        pass
    # Test for unavailable path
    try:
        get_bin_path('/not_exist/catfile')
        assert False, "Should have raised ValueError"
    except ValueError:
        pass
    # Test using optional dirs
    try:
        get_bin_path('cat', ['/bin'])
        assert False, "Should have raised ValueError"
    except ValueError:
        pass
    # Test using optional dirs

# Generated at 2022-06-20 16:08:25.186145
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/bin/ls' == get_bin_path('ls')
    assert '/bin/ls' == get_bin_path('ls', ['/bin'])
    assert '/bin/ls' == get_bin_path('ls', ['/bin', '/usr/bin'])
    assert '/bin/ls' == get_bin_path('ls', ['/usr/bin', '/bin'])

# Generated at 2022-06-20 16:08:28.827440
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('bash')
    # Check the path contains the string 'bash'
    assert 'bash' in bin_path
    # Check the path contains the string 'bin'
    assert 'bin' in bin_path

# Generated at 2022-06-20 16:08:30.575186
# Unit test for function get_bin_path
def test_get_bin_path():
    from sys import executable
    assert get_bin_path(executable) == executable


# Generated at 2022-06-20 16:08:35.999124
# Unit test for function get_bin_path
def test_get_bin_path():
    found = get_bin_path('bash')
    assert found == '/bin/bash'

# Generated at 2022-06-20 16:08:45.285171
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fp = open(os.path.join(tmpdir, 'file'), 'w')
    fp.close()

    # Check if we find the file
    path = get_bin_path('file', opt_dirs=[tmpdir])
    assert path == os.path.join(tmpdir, 'file')

    # Check that the file is not found, when only path is used
    try:
        path = get_bin_path('file')
    except ValueError:
        pass

    # Cleanup
    os.unlink(os.path.join(tmpdir, 'file'))
    os.rmdir(tmpdir)

# Generated at 2022-06-20 16:08:55.270800
# Unit test for function get_bin_path
def test_get_bin_path():

    # setup global env
    os.environ['PATH'] = '/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'
    # get_bin_path('ls')
    assert get_bin_path('ls') == '/bin/ls'
    # get_bin_path('ls', opt_dirs=['/usr/bin',])
    assert get_bin_path('ls', opt_dirs=['/usr/bin', ]) == '/usr/bin/ls'
    # get_bin_path('ls', opt_dirs=['/usr/bin', '/usr/sbin'])
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/usr/sbin']) == '/usr/bin/ls'
    # get_bin_path('ls', opt_dirs

# Generated at 2022-06-20 16:08:59.297141
# Unit test for function get_bin_path
def test_get_bin_path():
    # executable that should be found
    assert get_bin_path('env') != None

    # executable that should not be found
    try:
        get_bin_path('no_such_exe')
        assert False, 'get_bin_path did not raise an exception for non-existent executable'
    except ValueError:
        pass

# Generated at 2022-06-20 16:09:05.036909
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/bin/echo' == get_bin_path('echo', ['/bin'])
    try:
        get_bin_path('this_should_fail')
        assert False, "get_bin_path() should have raised an exception"
    except ValueError as e:
        assert 'this_should_fail' in e.args[0]
    import sys
    if sys.platform.startswith('linux'):
        assert '/sbin/route' == get_bin_path('route')

# Generated at 2022-06-20 16:09:07.316921
# Unit test for function get_bin_path
def test_get_bin_path():
    if get_bin_path('/bin/sleep'):
        assert True
    else:
        assert False
    try:
        get_bin_path('/bin/sleep2')
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-20 16:09:17.052943
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Test for get_bin_path'''
    # Search for python
    bindir = '/usr/bin' if os.path.isdir('/usr/bin') else ''
    bindir = '/bin' if not bindir and os.path.isdir('/bin') else bindir
    binname = 'python' if not bindir or os.path.exists(os.path.join(bindir, 'python')) else ''
    if binname:
        try:
            binpath = get_bin_path(binname)
        except ValueError:
            assert 0, "Failed to find binary %s" % binname
        assert binpath == os.path.join(bindir, binname)
    else:
        assert 0, "Failed to find a binary to test with."



# Generated at 2022-06-20 16:09:22.808922
# Unit test for function get_bin_path
def test_get_bin_path():
    path_paths = []
    path_paths.append(get_bin_path('sh'))
    path_paths.append(get_bin_path('sh', ['/usr/bin', '/bin']))
    path_paths.append(get_bin_path('ansible-config'))

    assert all(path is not None for path in path_paths)

# Generated at 2022-06-20 16:09:24.046995
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-20 16:09:36.016548
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    from ansible.module_utils.common._text import to_text

    curdir = to_text(os.getcwd())
    testdir = tempfile.mkdtemp()
    testdir2 = tempfile.mkdtemp()

# Generated at 2022-06-20 16:09:47.780255
# Unit test for function get_bin_path
def test_get_bin_path():
    fake_path = os.path.join(os.getcwd(), 'test_get_bin_path')
    # Create fake executable in fake PATH at fake_path
    fake_exe = os.path.join(fake_path, 'fake_exe')
    if not os.path.exists(fake_path):
        os.makedirs(fake_path)
    open(fake_exe, 'a').close()
    os.chmod(fake_exe, 0o777)
    try:
        assert get_bin_path('fake_exe', [fake_path]) == fake_exe
    finally:
        os.remove(fake_exe)
        os.rmdir(fake_path)

# Generated at 2022-06-20 16:09:58.937817
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert isinstance(bin_path, str)
    assert bin_path.endswith('/sh')
    assert os.path.exists(bin_path)

    tb_path = '/tmp/bin'

# Generated at 2022-06-20 16:10:07.206603
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Returns True if test passes, False if test fails. '''

# Generated at 2022-06-20 16:10:18.889983
# Unit test for function get_bin_path
def test_get_bin_path():
    # required argument deprecated
    try:
        get_bin_path('ls', required=True)
        assert False, "get_bin_path('ls', required=True) should raise an exception"
    except ValueError:
        pass
    try:
        get_bin_path('ls', required=False) == '/bin/ls'
        assert False, "get_bin_path('ls', required=False) should raise an exception"
    except ValueError:
        pass

    # return value
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/tmp']) == '/bin/ls'

    # non-existing command

# Generated at 2022-06-20 16:10:28.618466
# Unit test for function get_bin_path
def test_get_bin_path():

    import tempfile

    # Create a script in temporary file.
    _, path = tempfile.mkstemp()
    text = '#!/bin/sh\npython -c "import sys; sys.exit(12)"'
    with open(path, 'w') as f:
        f.write(text)
    # Make it executable
    os.chmod(path, 0o755)
    # Define function to be used as a fixture in a unit test
    def reset_get_bin_path():
        get_bin_path.cache_clear()

    # Unit test get_bin_path
    # See https://docs.pytest.org/en/latest/xunit_setup.html for teardown
    reset_get_bin_path()
    assert get_bin_path(os.path.basename(path)) == path

# Generated at 2022-06-20 16:10:41.085474
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('cat', ['/usr/bin']) == '/usr/bin/cat'
    assert get_bin_path('cat', ['/usr/bin','/usr/bin/local']) == '/usr/bin/cat'
    assert get_bin_path('cat', ['/usr/bin/local']) == '/usr/bin/local/cat'
    assert get_bin_path('cat', ['/usr/bin','/usr/bin/local']) == '/usr/bin/cat'
    assert get_bin_path('cat', ['/usr/bin','/usr/bin/local'], '/usr/bin/local') == '/usr/bin/local/cat'

# Generated at 2022-06-20 16:10:48.619378
# Unit test for function get_bin_path
def test_get_bin_path():
    """
   Function to test get_bin_path
   """
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/ls', opt_dirs=['/sbin', '/usr/sbin', '/usr/local/sbin']) == '/bin/ls'
    assert get_bin_path('/bin/ls', opt_dirs=['/usr/sbin', '/usr/local/sbin']) == '/bin/ls'
    assert get_bin_path('/bin/ls', opt_dirs=['/bin', '/sbin', '/usr/sbin', '/usr/local/sbin']) == '/bin/ls'

# Generated at 2022-06-20 16:11:01.040875
# Unit test for function get_bin_path
def test_get_bin_path():
    # Valid program in PATH should return full path
    PATH_mock = ['/sbin', '/usr/sbin', '/usr/local/sbin', '/bin', '/usr/bin', '/usr/local/bin']
    assert get_bin_path('sh', PATH_mock) == '/bin/sh'

    # Invalid path should raise error
    PATH_mock = ['/bin', '/usr/bin', '/usr/local/bin']
    try:
        get_bin_path('invalid_program', PATH_mock)
    except (ValueError):
        pass
    else:
        assert False, 'Able to get the real path of invalid program'

    # Program in path which is not valid executable should raise error
    PATH_mock = ['/bin', '/usr/bin', '/usr/local/bin']

# Generated at 2022-06-20 16:11:09.236041
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.utils.path import unfrackpath

    env = os.environ.copy()
    env['PATH'] = ':'.join((unfrackpath(__file__), env['PATH']))
    assert get_bin_path('path_utils.py') == unfrackpath(__file__) + '/path_utils.py'
    assert get_bin_path('path_utils.py', opt_dirs=[]) == unfrackpath(__file__) + '/path_utils.py'

# Generated at 2022-06-20 16:11:19.721704
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == get_bin_path('/bin/ls')
    assert get_bin_path('ls', opt_dirs=['/bin']) == get_bin_path('/bin/ls', opt_dirs=['/bin'])
    assert get_bin_path('ls', opt_dirs=['/bin']) == get_bin_path('ls', opt_dirs=['/bin', '/bin'])

    try:
        get_bin_path('idont_exist')
        assert False
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "idont_exist" in paths: /sbin:/usr/sbin:/usr/local/sbin:/bin:/usr/bin'

# Generated at 2022-06-20 16:11:25.455136
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-20 16:11:36.951392
# Unit test for function get_bin_path
def test_get_bin_path():
    import ansible.module_utils.basic
    import ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.file

    # Save original values
    old_environ = os.environ
    old_is_executable = ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.file.is_executable


# Generated at 2022-06-20 16:11:48.611253
# Unit test for function get_bin_path
def test_get_bin_path():
    test_dir1 = '/fake/dir1'
    test_dir2 = '/fake/dir2'
    test_dir3 = '/fake/dir3'
    arg = 'fake_prog'
    executable = os.path.join(test_dir3, arg)
    test_paths = [test_dir1, test_dir2, test_dir3]
    saved_path = os.environ.get('PATH')
    os.environ['PATH'] = os.pathsep.join(test_paths)
    # Mocked function
    orig_exists = os.path.exists
    orig_isdir = os.path.isdir
    orig_is_executable = is_executable
    def mocked_exists(path):
        return path == executable

# Generated at 2022-06-20 16:11:56.410811
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('./ls') == './ls'
    try:
        get_bin_path('ls', opt_dirs=['/bin'], required=False)
    except (ValueError, KeyError):
        assert True
    else:
        assert False

# Generated at 2022-06-20 16:11:59.928437
# Unit test for function get_bin_path
def test_get_bin_path():
    # Make sure path '/usr/bin' is in the PATH
    opt_dirs = ['/usr/bin']
    bin_path = get_bin_path('cat', opt_dirs=opt_dirs)
    assert bin_path == '/usr/bin/cat'
    bin_path = get_bin_path('cat', opt_dirs=opt_dirs, required=False)
    assert bin_path == '/usr/bin/cat'

    # If opt_dir doesn't exist raise exception
    try:
        get_bin_path('cat', opt_dirs=['/doesnotexists'])
        assert False, "Should have raised exceptiion as '/doesnotexists' directory doesn't exist"
    except ValueError as e:
        assert True

# Generated at 2022-06-20 16:12:11.410923
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('/bin/cat') == '/bin/cat'
    assert get_bin_path('/bin/cat', opt_dirs=('/sbin',)) == '/bin/cat'
    assert get_bin_path('/bin/cat', opt_dirs=()) == '/bin/cat'
    assert get_bin_path('/some/bogus/path/bin/cat', opt_dirs=('/bin',)) == '/bin/cat'
    assert get_bin_path('/noopt/bogus/path/bin/cat') == '/bin/cat'
    assert get_bin_path('/sbin/bogus/path/bin/cat') == '/bin/cat'

# Generated at 2022-06-20 16:12:13.063526
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-20 16:12:19.721501
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.facts.system.paths import get_bin_path

    # look for a known executable (ls)
    path = get_bin_path('ls')
    assert is_executable(path)

    # look for a non-existent executable
    got_exception = False
    try:
        path = get_bin_path('this_executable_does_not_exist')
    except ValueError:
        got_exception = True
    finally:
        assert got_exception

# Generated at 2022-06-20 16:12:31.665337
# Unit test for function get_bin_path
def test_get_bin_path():
    # Prepare a temporary directory
    import tempfile
    tmpdir = tempfile.mkdtemp()
    test_file = os.path.join(tmpdir, 'test_execute')
    open(test_file, "w").close()
    os.chmod(test_file, 0o755)


# Generated at 2022-06-20 16:12:35.726515
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest

    # Test that a required executable in PATH is found
    required_bin_path = get_bin_path('python', required=True)
    assert os.path.isfile(required_bin_path)
    assert os.access(required_bin_path, os.X_OK)

    # Test that a required executable not in PATH raises an Exception
    with pytest.raises(ValueError):
        get_bin_path('this_is_not_a_valid_executable_filename', required=True)

    # Test that an optional executable in PATH is found
    optional_bin_path = get_bin_path('python', required=False)
    assert os.path.isfile(optional_bin_path)
    assert os.access(optional_bin_path, os.X_OK)

    # Test that an optional executable

# Generated at 2022-06-20 16:12:51.911601
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping

    class DevNull(MutableMapping):
        def __getitem__(self, key):
            return None

        def __setitem__(self, key, value):
            pass

        def __delitem__(self, key):
            pass

        def __iter__(self):
            return iter({})

        def __len__(self):
            return 0

    def fake_check_output(arg, *args, **kwargs):
        return to_bytes('/usr/bin/%s' % arg)

    old_import = __import__


# Generated at 2022-06-20 16:12:54.119411
# Unit test for function get_bin_path
def test_get_bin_path():
    # check that get_bin_path raises error in case if executable does not exist
    try:
        get_bin_path('exe_does_not_exist')
        assert False
    except:
        assert True

# Generated at 2022-06-20 16:12:58.110888
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['/bin', '/usr/bin', '/usr/local/bin', '/sbin', '/usr/sbin', '/usr/local/sbin']
    for path in paths:
        # Test that the path exists
        get_bin_path('ls', [path])

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-20 16:13:06.036981
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sudo') == '/usr/bin/sudo'
    assert get_bin_path('/usr/bin/ssh') == '/usr/bin/ssh'
    try:
        get_bin_path('sh_not_existing')
        raise AssertionError('get_bin_path did not fail')
    except:
        pass
    assert get_bin_path('nmap', opt_dirs=['/bin']) == '/bin/nmap'
    assert get_bin_path('tcpdump', opt_dirs=['/usr/sbin']) == '/usr/sbin/tcpdump'

# Generated at 2022-06-20 16:13:11.504557
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/bin/sh'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/bin/ls'
    try:
        get_bin_path('test_file', opt_dirs=['/usr/bin'])
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError not raised'

# Generated at 2022-06-20 16:13:23.808224
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/sbin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/sbin']) == '/sbin/ls'
    assert get_bin_path('ls', opt_dirs=['/mkdir']) == '/mkdir/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/mkdir']) == '/bin/ls'

# Generated at 2022-06-20 16:13:24.975095
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'

# Generated at 2022-06-20 16:13:33.277212
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import random
    import string

    # We need to do this since we cannot assume that a command like
    # /usr/bin/something exists, or will return zero.  So we create
    # a temporary directory and a simple executable that we can call.
    temp_dir = tempfile.mkdtemp()

    # Use the same directory in multiple places to make sure that the
    # function properly searches PATH and not just the given directory
    search_path = []
    search_path.append(temp_dir)
    search_path.append(temp_dir)
    search_path.append(temp_dir)

    # Create a temporary file and make it executable
    (temp_handle, temp_filename) = tempfile.mkstemp(dir=temp_dir)
    os.close(temp_handle)


# Generated at 2022-06-20 16:13:44.899820
# Unit test for function get_bin_path
def test_get_bin_path():
    # setup test environment
    if os.path.exists('/tmp/test_get_bin_path'):
        os.system('rm -rf /tmp/test_get_bin_path')
    os.mkdir('/tmp/test_get_bin_path')
    os.mkdir('/tmp/test_get_bin_path/usr')
    os.mkdir('/tmp/test_get_bin_path/usr/bin')
    os.mkdir('/tmp/test_get_bin_path/usr/sbin')
    os.mkdir('/tmp/test_get_bin_path/usr/local')
    os.mkdir('/tmp/test_get_bin_path/usr/local/bin')

# Generated at 2022-06-20 16:13:47.287600
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        result = get_bin_path('cat')
    except Exception as e:
        ok = False
    else:
        ok = True
    assert(ok)



# Generated at 2022-06-20 16:14:01.852638
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with None parameter
    try:
        get_bin_path(None)
    except ValueError:
        pass   # Nothing to be done
    # Test with empty parameter
    try:
        get_bin_path('')
    except ValueError:
        pass   # Nothing to be done
    # Test with valid parameter
    get_bin_path('ls')
    # Test with valid parameter, but does not exists in PATH
    try:
        get_bin_path('invalid_executable.sh')
    except ValueError:
        pass   # Nothing to be done

# Generated at 2022-06-20 16:14:09.119266
# Unit test for function get_bin_path
def test_get_bin_path():
    # path to use for unit test
    test_path = ['/users/test/bin']

    # path exists without test_path
    bin_path = get_bin_path('ls', test_path)
    assert os.path.exists(bin_path)

    # path doesn't exist with test_path
    empty_path = get_bin_path('test_bin', test_path)
    assert empty_path == '/users/test/bin/test_bin'

# Generated at 2022-06-20 16:14:22.083232
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/foo']) == '/bin/sh'
    try:
        get_bin_path('sh', opt_dirs=['/foo'], required=True)
    except ValueError as e:
        assert "Failed to find required executable \"sh\" in paths: /foo:/bin:/usr/bin:/usr/local/bin" == str(e)

# Generated at 2022-06-20 16:14:32.908349
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function
    '''
    import shutil
    import tempfile

    testbin = 'test_bin'
    path_list = []
    path_list.append(tempfile.mkdtemp())
    path_list.append(tempfile.mkdtemp())
    with open(os.path.join(path_list[0], testbin), 'w') as f:
        f.write('')
    os.chmod(os.path.join(path_list[0], testbin), 0o755)

    try:
        bin_path = get_bin_path(testbin, path_list)
        assert bin_path == os.path.join(path_list[0], testbin)
    finally:
        shutil.rmtree(path_list[0])
       

# Generated at 2022-06-20 16:14:38.640425
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls', opt_dirs=None) == '/bin/ls'
    try:
        get_bin_path('does_not_exist', opt_dirs=None)
    except ValueError as e:
        assert 'Failed to find required executable "does_not_exist"' in str(e)

# Generated at 2022-06-20 16:14:42.007840
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.path.exists('/bin/ls'):
        assert get_bin_path('ls') == '/bin/ls'
    else:
        assert get_bin_path('ls') == '/usr/bin/ls'

# Generated at 2022-06-20 16:14:45.603204
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Return true if get_bin_path() is functioning
    '''
    if get_bin_path('python2.7') == '/usr/bin/python2.7':
        return True
    return False