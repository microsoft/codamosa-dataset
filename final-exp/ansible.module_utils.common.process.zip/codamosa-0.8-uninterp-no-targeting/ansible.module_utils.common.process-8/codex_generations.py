

# Generated at 2022-06-20 16:04:55.193696
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'

# Generated at 2022-06-20 16:05:05.506697
# Unit test for function get_bin_path
def test_get_bin_path():
    # Create a temporary file at a specified pathname
    # and ensure that get_bin_path returns that path
    def create_temp_file(pathname):
        fp = open(pathname, 'w')
        fp.close()

    # Remove a temporary file that was created using create_temp_file
    def remove_temp_file(pathname):
        os.remove(pathname)

    # Ensure that get_bin_path fails when a required executable does not exist
    def get_bin_path_fail(pathname):
        try:
            get_bin_path(pathname)
        except ValueError:
            return None
        return pathname

    # Ensure that get_bin_path succeeds when a required executable exists

# Generated at 2022-06-20 16:05:09.803051
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('sh')
    assert path == '/bin/sh'

    path = get_bin_path('sh', opt_dirs=['/usr/bin'])
    assert path == '/bin/sh'

    # Test with prefix './'
    path = get_bin_path('./sh', opt_dirs=['/usr/bin'])
    assert path == '/bin/sh'

    try:
        path = get_bin_path('nonexistent_file')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    else:
        assert path is None, 'Path should be None'

# Generated at 2022-06-20 16:05:13.496991
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh')
    with pytest.raises(ValueError):
        # expected to raise exception
        get_bin_path('fasdfasdf')
    assert get_bin_path('false', required=False) == '/bin/false'

# Generated at 2022-06-20 16:05:25.494015
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import tempfile
    
    for binary in ['chmod', 'grep', 'python']:
        # Should work for any command available in PATH
        get_bin_path(binary)
    
    for binary in ['chmod', 'grep', 'python']:
        # Should work for any command available in PATH
        get_bin_path(binary)
    
    # Should fail if command is not in PATH
    try:
        get_bin_path('not_a_binary')
    except ValueError:
        pass
    else:
        assert False, 'Should have raised an exception'
    
    # Should work if command is in opt_dirs
    tmpfile = tempfile.NamedTemporaryFile()
    tmpfile.write(b'#!/bin/sh\n')
    tmpfile.flush()
   

# Generated at 2022-06-20 16:05:36.090622
# Unit test for function get_bin_path
def test_get_bin_path():
    # if /usr/bin is already in the PATH, remove it.
    if '/usr/bin' in os.environ['PATH']:
        pathlist = os.environ['PATH'].split(os.pathsep)
        pathlist.remove('/usr/bin')
        os.environ['PATH'] = os.pathsep.join(pathlist)

    # check that get_bin_path raises exception on missing executable
    missing = 'THIS_EXECUTABLE_SHOULD_NOT_EXIST'
    try:
        get_bin_path(missing)
    except ValueError as e:
        assert missing in str(e)
    else:
        assert False, 'get_bin_path() failed to raise exception on invalid executable'

    # check that get_bin_path returns path when executable is present
    assert get_bin

# Generated at 2022-06-20 16:05:47.002826
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # Expected failures
    try:
        # Will fail because no directory is specified.
        get_bin_path('no_such_executable')
    except ValueError:
        pass
    else:
        raise AssertionError('Expected a failure')

    try:
        # Will fail because no directory exists.
        get_bin_path('no_such_executable', ['/no/such/directory'])
    except ValueError:
        pass
    else:
        raise AssertionError('Expected a failure')

    # Expected success
    # Create a temporary executable for testing.
    test_executable = tempfile.NamedTemporaryFile(mode='w+x')
    # It must be on PATH for get_bin_path to work.

# Generated at 2022-06-20 16:05:57.835499
# Unit test for function get_bin_path
def test_get_bin_path():
    # test under known PATH
    path = '/bin:/usr/bin'
    with os.environ.context([('PATH', path)]):
        assert get_bin_path('vi') == '/bin/vi'
        assert get_bin_path('/bin/vi') == '/bin/vi'
        assert get_bin_path('/usr/bin/vi') == '/usr/bin/vi'

    # test under known PATH and with additional search paths
    with os.environ.context([('PATH', path)]):
        assert get_bin_path('vi', opt_dirs=['/usr/sbin']) == '/bin/vi'
        assert get_bin_path('/bin/vi', opt_dirs=['/usr/sbin']) == '/bin/vi'

# Generated at 2022-06-20 16:06:05.453521
# Unit test for function get_bin_path
def test_get_bin_path():
    # Create a fake PATH with a fake path
    os.environ['PATH'] = '/sbin:/bin:/usr/sbin:/usr/bin'
    assert get_bin_path('ping') == '/bin/ping'

    # Test that sbin paths are included
    assert get_bin_path('ifconfig') == '/sbin/ifconfig'
    assert get_bin_path('ifconfig', opt_dirs=['/bin']) == '/sbin/ifconfig'

    # Test to ensure that the required argument is deprecated
    os.environ.pop('PATH')
    try:
        assert get_bin_path('ping', required=True)
    except ValueError as e:
        assert ' Failed to find required executable "ping" in' in str(e)

# Generated at 2022-06-20 16:06:17.130198
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('/bin/echo') == '/bin/echo'
    assert get_bin_path(['/bin/echo', '/bin']) == '/bin/echo'
    assert get_bin_path('/bin/echo', required=False) == '/bin/echo'
    assert get_bin_path('/bin/echo', required=True) == '/bin/echo'
    assert get_bin_path('/bin/echo', '/bin') == '/bin/echo'
    assert get_bin_path('/bin/echo', opt_dirs='/bin') == '/bin/echo'
    assert get_bin_path('/bin/echo', opt_dirs=['/bin']) == '/bin/echo'

# Generated at 2022-06-20 16:06:21.679270
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == b'/bin/sh'
    assert get_bin_path('awk') == b'/usr/bin/awk'

# Generated at 2022-06-20 16:06:33.007310
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('/bin/busybox') == '/bin/busybox')
    assert(get_bin_path('/bin/busybox', ['/bin']) == '/bin/busybox')
    assert(get_bin_path('/bin/busybox', ['/usr/bin']) == '/bin/busybox')
    assert(get_bin_path('sh') == get_bin_path('/bin/sh'))
    assert(get_bin_path('tac') == get_bin_path('/bin/tac'))
    try:
        get_bin_path('nonexistingcommand')
        assert(False)
    except ValueError:
        assert(True)

# Generated at 2022-06-20 16:06:39.909369
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-20 16:06:48.537828
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=[]) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('foo') == '/bin/foo'
    assert get_bin_path('foo', opt_dirs=['/bin']) == '/bin/foo'

# Generated at 2022-06-20 16:06:49.671191
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('pwd') == '/bin/pwd'



# Generated at 2022-06-20 16:06:58.558553
# Unit test for function get_bin_path
def test_get_bin_path():

    def mock_is_executable(path):
        return True

    # Mocking is_executable function to return True for all paths
    get_bin_path.is_executable = mock_is_executable

    # Mocking PATH environment variable to find /bin/false
    os.environ['PATH'] = '/bin:/usr/bin'

    # Expected result
    false = '/bin/false'
    assert get_bin_path('false', required=True) == false
    assert get_bin_path(false, required=True) == false

    # Exception: executable is not found
    try:
        get_bin_path('no-such-executable')
    except ValueError:
        pass
    else:
        assert False, 'ValueError not raised'

    # Mocking PATH to find /bin/false
    os.en

# Generated at 2022-06-20 16:07:06.142796
# Unit test for function get_bin_path
def test_get_bin_path():

    # These tests need to be run as root in order to test paths in /sbin and /usr/sbin
    import os
    import sys
    if os.geteuid() != 0:
        sys.exit('Need root privileges to do these tests')

    # Test for one executable
    try:
        get_bin_path('true')
    except ValueError as e:
        raise AssertionError('get_bin_path raised %s instead of returning path.' % e)

    # Test for another executable
    try:
        get_bin_path('ip')
    except ValueError as e:
        raise AssertionError('get_bin_path raised %s instead of returning path.' % e)

    # Test for one nonexisting executable

# Generated at 2022-06-20 16:07:12.154642
# Unit test for function get_bin_path
def test_get_bin_path():

    # Python 2 requires a different path from Python 3 to access the same file.
    # Hence this function cannot be used directly to test get_bin_path().
    # Instead, on each OS, we create a file in $PATH, create a symlink to it in a temp directory
    # and test that get_bin_path can find it via the symlink.
    # The file we use to test with is onehundredone, which supports being called
    # with the -v option, which allows us to check the version of the program.

    test_file = 'onehundredone'
    test_version = b'101.74'

    # The onehundredone program is a fairly standard C program, compiled with the -O2 option
    # on a Mac with XCode > 10.1. On Linux and Windows it is compiled on Python 3.6.
   

# Generated at 2022-06-20 16:07:23.610550
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.six.moves import builtins

    builtin_open = builtins.open

    def open_mock(path, *args, **kwargs):
        if path.endswith('/bin/ls'):
            raise OSError
        if path.endswith('/bin/foo'):
            return builtin_open(path, *args, **kwargs)
        raise IOError('No such file: %s' % path)
    builtins.open = open_mock

    # Test with path not containing /bin/ls

# Generated at 2022-06-20 16:07:25.234874
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')

# Generated at 2022-06-20 16:07:34.690832
# Unit test for function get_bin_path
def test_get_bin_path():
    # Fake PATH with a known directory
    os.environ["PATH"] = "/bin"

    # Using an existing executable
    bin_path = get_bin_path("ls")
    assert bin_path == "/bin/ls", "get_bin_path() should return the full path of an existing executable"

    # Using a non-existing executable
    try:
        bin_path = get_bin_path("doesnotexist")
    except ValueError:
        pass
    else:
        assert False, "get_bin_path() should raise a ValueError if the file does not exist"

    # Using a non-executable
    try:
        bin_path = get_bin_path("/etc/passwd")
    except ValueError:
        pass

# Generated at 2022-06-20 16:07:44.185092
# Unit test for function get_bin_path
def test_get_bin_path():
    fake_dir = '/fake/dir'
    fake_dir_path = os.path.join(fake_dir, 'path')
    fake_path = os.path.join(fake_dir, 'path')
    fake_sbin_paths = ['/sbin', '/usr/sbin']
    fake_bin_paths = ['/bin', '/usr/bin']
    fake_sbin_paths_bin = os.path.join(fake_sbin_paths[0], 'blah')
    fake_bin_path = os.path.join(fake_bin_paths[0], 'blah')
    fake_mixed_path = os.path.join(fake_sbin_paths[1], 'blah')

# Generated at 2022-06-20 16:07:47.830427
# Unit test for function get_bin_path
def test_get_bin_path():
    # get_bin_path is not unit tested because unit tests do not have PATH set on configured PATH.
    return

# Generated at 2022-06-20 16:07:52.606896
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_dir = os.path.dirname(get_bin_path('sh'))
    assert bin_dir is not None
    assert bin_dir in os.environ['PATH'].split(os.pathsep)

# Generated at 2022-06-20 16:08:04.069341
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import sys
    import tempfile


# Generated at 2022-06-20 16:08:12.498404
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test of non existing file in non existing directory
    try:
        get_bin_path('/nonexistingdir/nonexistingfile')
    except ValueError:
        pass
    else:
        raise AssertionError('Did not get ValueError for non existing file')

    # Test of existing file in non existing directory
    try:
        get_bin_path('/nonexistingdir/existingfile', opt_dirs=[os.path.dirname(__file__)])
    except ValueError:
        pass
    else:
        raise AssertionError('Did not get ValueError for existing file in non existing directory')

    # Test of existing file in existing directory
    assert os.path.normcase(get_bin_path('ansible-playbook', opt_dirs=[os.path.dirname(__file__)])) == os

# Generated at 2022-06-20 16:08:20.672887
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import sys

    # test bin in one of the standard locations on PATH
    assert get_bin_path('ls') == '/bin/ls'

    # test missing bin
    try:
        get_bin_path('missing_bin')
        assert(False)
    except ValueError as e:
        assert(e.args[0] == 'Failed to find required executable "missing_bin" in paths: ')
        exc_info = sys.exc_info()
        assert(exc_info[0] == ValueError)

    # test bin in an optional directory
    opt_dir = tempfile.mkdtemp(prefix='test_get_bin_path')
    test_bin = opt_dir + '/test_bin'
    fh = open(test_bin, 'w')

# Generated at 2022-06-20 16:08:27.956097
# Unit test for function get_bin_path
def test_get_bin_path():

    opt_dirs = ['/usr/bin', '/usr/local/bin']

    # Executable found
    try:
        get_bin_path('ls', opt_dirs, required=True)
    except SystemExit as e:
        assert False
    # Executable not found
    try:
        get_bin_path('this_executable_does_not_exist', opt_dirs, required=True)
    except SystemExit as e:
        assert True
    else:
        assert False, "SystemExit should have been raised"

# Generated at 2022-06-20 16:08:38.147778
# Unit test for function get_bin_path
def test_get_bin_path():
    import ansible.module_utils.basic as basic

    # Test matching executable
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/sh') == '/bin/sh'

    # Test non-matching executable
    try:
        get_bin_path('/bin/no-such-executable')
    except ValueError as err:
        assert str(err) == 'Failed to find required executable "/bin/no-such-executable" in paths: /bin:/usr/bin'
    else:
        assert False, "Expected ValueError"

    # Test matching executable path option
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'

# Generated at 2022-06-20 16:08:47.209373
# Unit test for function get_bin_path
def test_get_bin_path():
    # check we can find simple executable
    bin_path = get_bin_path('/bin/true')
    assert bin_path == '/bin/true'

    # check we can find executable using PATH
    bin_path = get_bin_path('true')
    assert bin_path == '/bin/true'

    # check we can find executable on the path in opt_dirs
    bin_path = get_bin_path('true', opt_dirs=['/sbin', '/usr/sbin'])
    assert bin_path == '/sbin/true'

    # check we can find executable on the path in opt_dirs that is not in PATH
    bin_path = get_bin_path('true', opt_dirs=['/bin', '/usr/bin'])
    assert bin_path == '/bin/true'

    # check

# Generated at 2022-06-20 16:08:59.630703
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes

    if os.name == 'nt':
        import ctypes
        from ctypes.wintypes import MAX_PATH
        from ansible.module_utils.six.moves import winreg

    # On Windows, this would be an alias for 'where'
    def which(program):
        """Python clone of /usr/bin/which.
        from https://github.com/pydanny/whichcraft
        """
        def is_exe(fpath):
            return os.path.isfile(fpath) and os.access(fpath, os.X_OK)

        fpath, fname = os.path.split(program)
        if fpath:
            if is_exe(program):
                return program

# Generated at 2022-06-20 16:09:03.099021
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for function get_bin_path
    '''
    assert get_bin_path('sh') == '/bin/sh'


# If a module requires a specific system executable to be present, it can
# use this function to fail the module with an appropriate error when the
# executable isn't found.

# Generated at 2022-06-20 16:09:11.157076
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    from ansible.module_utils._text import to_native

    def is_executable(path):
        return True


# Generated at 2022-06-20 16:09:19.649548
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('/bin/sl') == '/bin/sl'
    assert get_bin_path('/bin/sl', ['/bin']) == '/bin/sl'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sl') == '/bin/sl'
    assert get_bin_path('sl', ['/bin']) == '/bin/sl'
    assert get_bin_path('sh', ['/tmp']) == '/bin/sh'
    assert get_bin_path('sl', ['/tmp']) == '/bin/sl'
    assert get_bin_path('sl', ['/tmp', '/bin']) == '/bin/sl'

# Generated at 2022-06-20 16:09:25.289636
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('python', opt_dirs=['/bin', '/usr/bin'])
    assert bin_path == '/usr/bin/python'
    try:
        bin_path = get_bin_path('this_does_not_exist')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')

# Generated at 2022-06-20 16:09:31.531417
# Unit test for function get_bin_path
def test_get_bin_path():

    assert get_bin_path('sh', ['/bin', '/sbin']) == '/bin/sh'

    # should be able to find the executable in sbin
    assert get_bin_path('ip') == '/sbin/ip'

    # test with nonexistent arg
    try:
        get_bin_path('thisfileisnothere')
    except ValueError as e:
        assert e.args[0].startswith('Failed to find required')

# Generated at 2022-06-20 16:09:38.860113
# Unit test for function get_bin_path
def test_get_bin_path():
    import re

    # Test that appropriate PATH is found
    path_re = re.compile('^(\/.*\/python[2-3]\.[0-9])$')
    assert path_re.search(get_bin_path('python', required=True))

    # Test that failure raises exception
    try:
        assert get_bin_path('xyzzy')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    else:
        assert False, 'Expected ValueError to be raised'

# Generated at 2022-06-20 16:09:47.912560
# Unit test for function get_bin_path
def test_get_bin_path():

    try:
        get_bin_path('----nonsense----', ['/usr/bin', '/usr/sbin'])
        raise AssertionError('Test failed: get_bin_path should have raised ValueError')
    except ValueError:
        pass

    try:
        get_bin_path('----nonsense----', required=True)
        raise AssertionError('Test failed: get_bin_path should have raised ValueError')
    except ValueError:
        pass

    try:
        get_bin_path('----nonsense----', ['/usr/bin', '/usr/sbin'], required=True)
        raise AssertionError('Test failed: get_bin_path should have raised ValueError')
    except ValueError:
        pass


# Generated at 2022-06-20 16:09:59.104408
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test coverage for function get_bin_path
    '''
    # Test command and path lists
    test_cmds = [
        ('pwd', ['/usr/bin']),
        ('/bin/pwd', ['/usr/bin']),
        ('python', ['/usr/bin']),
        ('/bin/python', ['/usr/bin']),
        ('invalidcmd', ['/tmp', '/usr/bin']),
    ]
    for cmd, dirs in test_cmds:
        try:
            path = get_bin_path(cmd, dirs)
            assert len(path) > 0
            assert path == os.path.realpath(cmd)
        except Exception:
            if cmd.startswith('/') or dirs:
                raise
            assert True

# Generated at 2022-06-20 16:10:07.281283
# Unit test for function get_bin_path
def test_get_bin_path():
    # test simple stuff we should be able to find
    python_bin = get_bin_path('python')
    assert python_bin == sys.executable
    with open(python_bin, 'rb') as python_bin_fd:
        python_bin_contents = python_bin_fd.read()
    assert b'Python' in python_bin_contents

    # test a search path
    python_bin = get_bin_path('python', opt_dirs=['/usr/bin/coreutils', '/usr/bin'])
    assert python_bin == sys.executable
    with open(python_bin, 'rb') as python_bin_fd:
        python_bin_contents = python_bin_fd.read()
    assert b'Python' in python_bin_contents

    # test a search path that includes a non

# Generated at 2022-06-20 16:10:11.059269
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'

# Generated at 2022-06-20 16:10:17.237483
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/usr/local/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/usr/local/bin', '/tmp/doesntexist']) == '/bin/ls'

# Generated at 2022-06-20 16:10:22.917896
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for existing executable
    c = get_bin_path('cp')
    assert os.path.exists(c)
    assert os.path.isfile(c)
    assert is_executable(c)
    # Test for existing executable in /sbin
    c = get_bin_path('fdisk')
    assert os.path.exists(c)
    assert os.path.isfile(c)
    assert is_executable(c)
    # Test for non-existing executable
    try:
        c = get_bin_path('adfadfasdfa')
    except ValueError as e:
        assert "Failed to find required executable" in str(e)
    else:
        assert False, 'Expected ValueError'
    # Test for non-existing executable with opt_dirs

# Generated at 2022-06-20 16:10:28.453266
# Unit test for function get_bin_path
def test_get_bin_path():
    import __main__

    # Check get_bin_path against existing mock module
    bp = get_bin_path(__main__.__file__)
    assert bp == __main__.__file__, bp

    # Check get_bin_path against a non-existing file
    try:
        get_bin_path("this_should_never_exist_i_hope")
    except ValueError as e:
        assert 'Failed to find required executable' in str(e), e

# Generated at 2022-06-20 16:10:32.011561
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("ls") == "/bin/ls"
    try:
        get_bin_path("invalid_path")
        assert False, "expected ValueError"
    except ValueError:
        pass

# Generated at 2022-06-20 16:10:41.753385
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # Test non-existent file
        path = get_bin_path('some/bogus/path/command')
        assert False, "Expected ValueError exception"
    except ValueError as ve:
        assert True

    # Test good return
    path = get_bin_path('/bin/grep')
    assert path == '/bin/grep'

    # Test good return with opt_dirs
    path = get_bin_path('/bin/grep', ['/bin'])
    assert path == '/bin/grep'

    # Test good return with opt_dirs and existing directory
    path = get_bin_path('/bin', ['/bin'])
    assert path == '/bin'

    # Test good return with opt_dirs and non-executable

# Generated at 2022-06-20 16:10:44.642766
# Unit test for function get_bin_path
def test_get_bin_path():
    # Assume in Unix PATH environment variable exists
    assert get_bin_path('awk')
    # Assume in Unix PATH environment variable does not exist
    assert get_bin_path('awk', opt_dirs=['/bin', '/usr/bin'])


# Generated at 2022-06-20 16:10:51.363493
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    test_dir = tempfile.mkdtemp()
    test_prog = 'test_prog'
    test_file = os.path.join(test_dir, test_prog)
    with open(test_file, 'w') as f:
        f.write('#!/bin/sh')
    os.chmod(test_file, 0o755)
    assert get_bin_path(test_prog, opt_dirs=[test_dir]) == test_file
    shutil.rmtree(test_dir)

# Generated at 2022-06-20 16:10:59.677314
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        _ = get_bin_path('cat')
    except ValueError as e:
        raise ValueError("FAILED: get_bin_path('cat'): %s" % e)
    try:
        _ = get_bin_path('no_such_executable')
    except ValueError as e:
        raise ValueError("FAILED: get_bin_path('no_such_executable'): %s" % e)

# Generated at 2022-06-20 16:11:00.907733
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Unit test for function get_bin_path.
    """
    assert get_bin_path('python')

# Generated at 2022-06-20 16:11:05.164884
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('non-existent-binary')
    except ValueError:
        pass

test_get_bin_path()

# Generated at 2022-06-20 16:11:13.450691
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') is not None
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin', '/usr/local/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/sbin', '/usr/local/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/sbin', '/usr/local/bin']) == '/bin/ls'
    assert get_bin_path('/bin/ls') == '/bin/ls'

    try:
        get_bin_path('PATH_NOT_EXIST_BIN')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-20 16:11:25.767263
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import unittest

    class TestGetBinPath(unittest.TestCase):

        def test_get_bin_path(self):
            import tarfile  # tarfile module is available only in python2.7 and higher
            import tempfile

            # create a testing temporary directory
            temp_dir = tempfile.mkdtemp()

            # get absolute path of python interpreter
            python_interpreter = sys.executable

            # add the directory containing the python interpreter to the $PATH environment variable
            os.environ['PATH'] += os.pathsep + os.path.abspath(os.path.join(sys.executable, os.pardir))

            # create a temporary executable file named 'prog'

# Generated at 2022-06-20 16:11:37.595389
# Unit test for function get_bin_path
def test_get_bin_path():
    class SubprocessMock:
        def __init__(self):
            self.cmd = []

        def call(self, cmd, *args, **kwargs):
            self.cmd = cmd

    subprocess = SubprocessMock()

    get_bin_path('ansible', subprocess=subprocess)
    assert subprocess.cmd == ['which', 'ansible']


# -*- -*- -*- End included fragment: ../../../lib_utils/src/lib/utils/__init__.py -*- -*- -*-

# -*- -*- -*- Begin included fragment: lib/base.py -*- -*- -*-
# pylint: disable=too-many-lines


# Generated at 2022-06-20 16:11:45.972685
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes

    test_bin = get_bin_path('ls')
    assert 'ls' in test_bin

    test_bin2 = get_bin_path('ls', [to_bytes('/usr/bin')])
    assert test_bin2 == to_bytes('/usr/bin/ls')

    try:
        get_bin_path('nonexistant-command')
    except ValueError as e:
        msg = str(e)
        assert 'nonexistant-command' in msg

# Generated at 2022-06-20 16:11:51.523236
# Unit test for function get_bin_path
def test_get_bin_path():
    # Reuse assert statements from other tests
    assert is_executable(get_bin_path('ls'))
    try:
        get_bin_path('missing-command')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    else:
        assert False, 'Expected ValueError to be raised'

# Generated at 2022-06-20 16:11:55.945411
# Unit test for function get_bin_path
def test_get_bin_path():
    path_found = None
    try:
        path_found = get_bin_path('ls')
    except ValueError:
        pass
    assert path_found is not None
    path_notfound = None
    try:
        path_notfound = get_bin_path('non_existent_cmd')
    except ValueError:
        pass
    assert path_notfound is None

# Generated at 2022-06-20 16:12:01.077317
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/tmp/path_that_does_not_exist']) == '/bin/ls'

# Generated at 2022-06-20 16:12:09.465435
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test that trying to find an executable in a directory that doesn't exist raises an error
    try:
        get_bin_path('/no/such/directory/executable')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    else:
        assert False, 'Should have raised an error'

    # Test that specifying an optional directory that doesn't exist does not cause an error
    assert get_bin_path('/bin/true', opt_dirs=['/no/such/directory']) == '/bin/true'

# Generated at 2022-06-20 16:12:19.189921
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import os

    # test for systems where /usr/bin/python is not an executable,
    # e.g. Mac OS
    if os.path.exists('/usr/bin/python') and not is_executable('/usr/bin/python'):
        sys.exit(0)

    try:
        get_bin_path('python')
    except ValueError:
        print('Error: /usr/bin/python not found. Please fix your system.')
        sys.exit(1)

# Generated at 2022-06-20 16:12:33.612880
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Returns True if get_bin_path works as expected, otherwise returns False.'''

    test_path = '/tmp'

    # Test get_bin_path() - should return the path to /bin/ls
    try:
        bin_path = get_bin_path('ls')
    except ValueError:
        return False

    if 'ls' not in bin_path:
        return False

    # Test get_bin_path() with opt_dirs argument - should return the path to /bin/ls
    try:
        bin_path = get_bin_path('ls', opt_dirs=[test_path])
    except ValueError:
        return False

    if 'ls' not in bin_path:
        return False

    # Test get_bin_path() with a command that doesn't exist - should raise ValueError

# Generated at 2022-06-20 16:12:43.803518
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    pybin = os.path.realpath(sys.executable)
    assert get_bin_path('python') == pybin

    # Test finding executable in opt_dirs
    tempdir = tempfile.mkdtemp()
    testbin = os.path.join(tempdir, 'testbin')
    with open(testbin, 'w') as f:
        f.write('#!/bin/sh\n')
    os.chmod(testbin, 0o700)
    assert get_bin_path('testbin', opt_dirs=[tempdir]) == testbin

    # Test not finding executable in opt_dirs, using default dirs
    tempdir = tempfile.mkdtemp()
    assert get_bin_path('python', opt_dirs=[tempdir]) == pybin

   

# Generated at 2022-06-20 16:12:53.094761
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()

    test_files = {'foo': '', 'bar': ''}

    current_path = os.environ['PATH']

    for x in test_files:
        f = open(os.path.join(test_dir, x), 'w')
        f.close()

    if not os.path.exists(os.path.join(test_dir, 'bar')):
        raise Exception('error creating files')

    # Test with extra, 'built-in' path dir
    os.environ['PATH'] = '%s:%s' % (test_dir, os.environ['PATH'])

    for x in test_files:
        path = get_bin_path(x, required=False)


# Generated at 2022-06-20 16:13:01.353537
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a fake exe
    (fd, exe_path) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    os.chmod(exe_path, stat.S_IRWXU)

    # Check that we can find it
    found_path = get_bin_path(os.path.basename(exe_path), opt_dirs=[tmpdir])
    assert found_path == exe_path

    # Check that we won't find a directory
    os.remove(exe_path)
    os.mkdir(exe_path)

# Generated at 2022-06-20 16:13:05.579081
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('which')
    assert isinstance(bin_path, str)
    bin_path = get_bin_path('which', ['/bin', '/usr/bin'])
    assert isinstance(bin_path, str)
    try:
        get_bin_path('thisdoesnotexist')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-20 16:13:13.679579
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

# Generated at 2022-06-20 16:13:25.599407
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile

    tmp_dir = tempfile.mkdtemp()
    tmp_bin = os.path.join(tmp_dir, 'foo')
    with open(tmp_bin, 'w') as f:
        f.write('#!/bin/bash\ntrue')
    os.chmod(tmp_bin, 0o755)
    tmp_bin2 = os.path.join(tmp_dir, 'foo2')

    assert get_bin_path('foo', [tmp_dir]) == tmp_bin
    shutil.rmtree(tmp_dir)

    # Test exception
    try:
        get_bin_path('foo', [tmp_dir])
    except ValueError as e:
        assert 'Failed to find required executable \"foo\"' in str(e)
    else:
        assert False

# Generated at 2022-06-20 16:13:30.903181
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.path.exists('/bin/sh'):
        assert get_bin_path('sh') == '/bin/sh'
    else:
        assert get_bin_path('sh', [os.path.dirname(__file__)]) == os.path.dirname(__file__) + '/sh'



# Generated at 2022-06-20 16:13:34.721813
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    tmp = tempfile.mkdtemp()
    assert get_bin_path('sh', opt_dirs=[tmp]) == os.path.join(tmp, 'sh')
    # cleanup temp directory
    shutil.rmtree(tmp)

# Generated at 2022-06-20 16:13:46.040120
# Unit test for function get_bin_path
def test_get_bin_path():

    import tempfile
    import shutil
    import sys

    class TmpPath(object):
        def __enter__(self):
            self.dname = tempfile.mkdtemp()
            bin_path = os.path.join(self.dname,"bin")
            os.makedirs(bin_path)
            os.chmod(bin_path, 0o755)
            os.environ['PATH'] = bin_path
            return None

        def __exit__(self, exc_type, exc_val, exc_tb):
            for f in os.listdir(self.dname):
                path=os.path.join(self.dname,f)
                if os.path.isdir(path):
                    shutil.rmtree(path)
                else:
                    os.unlink(path)


# Generated at 2022-06-20 16:13:56.299332
# Unit test for function get_bin_path
def test_get_bin_path():
    _PATH = os.environ['PATH']
    os.environ['PATH'] = '/bin:/usr/bin'
    try:
        assert get_bin_path('true') == '/bin/true'
        os.environ['PATH'] = ''
        assert get_bin_path('false') == '/bin/false'
    finally:
        os.environ['PATH'] = _PATH

# Generated at 2022-06-20 16:13:59.808516
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for failure, no such command
    try:
        get_bin_path('noSuchCommand')
        assert False
    except Exception as e:
        assert True

    try:
        result = get_bin_path('dd')
        assert result == '/bin/dd'
    except Exception as e:
        assert False

# Generated at 2022-06-20 16:14:11.031924
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Test function get_bin_path'''
    from ansible.module_utils.common.file import get_bin_path
    from ansible.module_utils._text import to_bytes
    import tempfile
    import os
    import os.path

    test_dir = tempfile.mkdtemp()
    bin_path = os.path.join(test_dir, 'test_bin_path')
    os.close(os.open(bin_path, os.O_CREAT))
    assert get_bin_path('test_bin_path', opt_dirs=[test_dir]) == bin_path
    os.chmod(bin_path, 0o556)
    assert get_bin_path('test_bin_path', opt_dirs=[test_dir]) == bin_path

# Generated at 2022-06-20 16:14:16.791580
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('nosuchfile_fhhg')
    except ValueError as e:
        assert 'Failed to find required executable "nosuchfile_fhhg" in paths: ' in str(e)
    assert get_bin_path('pwd', ['/bin']) == '/bin/pwd'
    assert get_bin_path('cp', ['/bin']) == '/bin/cp'
    assert get_bin_path('pwd', ['/no/such/path']) == '/bin/pwd'
    assert get_bin_path('pwd') == '/bin/pwd'

# Generated at 2022-06-20 16:14:22.974675
# Unit test for function get_bin_path
def test_get_bin_path():
    import doctest
    failed, tests = doctest.testmod()
    if failed == 0:
        print('SUCCESS: %s' % __file__)
    else:
        print('FAILURE: %s' % __file__)
    sys.exit(failed)

if __name__ == '__main__':
    # Run unit tests
    test_get_bin_path()

# Generated at 2022-06-20 16:14:25.184202
# Unit test for function get_bin_path

# Generated at 2022-06-20 16:14:31.495363
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert os.path.exists(get_bin_path('cat'))
    assert os.path.isfile(get_bin_path('cat'))
    try:
        get_bin_path('cat1')
        assert False
    except ValueError:
        assert True
    assert get_bin_path('cat1', opt_dirs=['/bin'], required=True) == '/bin/cat1'

# Generated at 2022-06-20 16:14:37.374895
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Unit test for function get_bin_path'''
    assert get_bin_path('ls') in ['/bin/ls', '/usr/bin/ls']
    assert get_bin_path('invalid_utility') in ['/bin/ls', '/usr/bin/ls']

# Generated at 2022-06-20 16:14:43.051519
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    In this unit test, we create a temporary virtualenv and add it to
    the PATH.  We then use get_bin_path to see if we can find "python"
    in the system PATH or our PATH.  If we can't find it, we raise
    an error to demonstrate that the function throws an error if the
    executable is not found.
    '''
    from ansible.module_utils.common.file import mkstemp_close
    from ansible.module_utils.common.process import get_bin_path as get_bin_path_helper
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves import configparser
    import os
    import platform
    import shutil
    import tempfile
    import unittest


# Generated at 2022-06-20 16:14:47.925196
# Unit test for function get_bin_path
def test_get_bin_path():
    import sysconfig

    py_exec = sysconfig.get_config_var('BINDIR') + '/' + sysconfig.get_config_var('EXE')
    bin_path = get_bin_path(sysconfig.get_config_var('EXE'), opt_dirs=[sysconfig.get_config_var('BINDIR')])
    assert bin_path == py_exec