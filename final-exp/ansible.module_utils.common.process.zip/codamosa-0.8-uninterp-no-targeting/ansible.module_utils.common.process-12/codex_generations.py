

# Generated at 2022-06-20 16:04:48.955696
# Unit test for function get_bin_path
def test_get_bin_path():
   get_bin_path('/bin/ls')
   get_bin_path('ls')

# Generated at 2022-06-20 16:04:53.842712
# Unit test for function get_bin_path
def test_get_bin_path():

    # Auxiliary function to create a fake file in the fake PATH
    def create_file(file_path):
        try:
            os.makedirs(os.path.dirname(file_path))
        except os.error:
            pass

        try:
            with open(file_path, 'w') as outfile:
                outfile.write('')
        except os.error:
            pass

    # Test fixture - a fake PATH
    fake_path = '/fake/path1:/fake/path2:/fake/path3:/fake/path4'

    # Test fixture - a fake executable name
    arg = 'fake'

    # Test fixture - a fake verbose flag
    verbose = False

    # Test fixture - a execution path for the fake executable
    expected_path = '/fake/path1/fake'

    # Test fixture

# Generated at 2022-06-20 16:05:04.510091
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1: No bins found
    try:
        bin_path = get_bin_path('non_existent_binary', ['/non_existent_dir'])
        assert False, 'Expected ValueError'
    except ValueError as err:
         assert str(err) == "Failed to find required executable 'non_existent_binary' in paths: /non_existent_dir"
    # Test 2: Bin found
    bin_path = get_bin_path('ls', ['/bin'])
    assert bin_path == '/bin/ls'
    # Test 3: Path with shell metachars
    bin_path = get_bin_path('ls', ['/bin', '/foo bar'])
    assert bin_path == '/bin/ls'
    # Test 4: Path with trailing slash

# Generated at 2022-06-20 16:05:07.934604
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'

# Generated at 2022-06-20 16:05:16.835288
# Unit test for function get_bin_path
def test_get_bin_path():
    valid_paths = [
        '/bin/sh',
        '/usr/bin/sh',
        '/usr/local/bin/sh',
        '/usr/local/sbin/sh',
        '/usr/sbin/sh',
        '/sbin/sh',
    ]
    invalid_paths = [
        '/bin/not_sh',
        '/usr/bin/not_sh',
        '/usr/local/bin/not_sh',
        '/usr/local/sbin/not_sh',
        '/usr/sbin/not_sh',
        '/sbin/not_sh',
    ]

    for path in valid_paths:
        os.environ['PATH'] = os.pathsep.join(valid_paths)

# Generated at 2022-06-20 16:05:23.000401
# Unit test for function get_bin_path
def test_get_bin_path():
    path = '/usr/bin/python'
    assert get_bin_path('python') == path, "get_bin_path() returned the wrong path"
    try:
        get_bin_path('non-existent-program')
        assert 0, "get_bin_path() failed to raise an exception"
    except ValueError:
        pass



# Generated at 2022-06-20 16:05:30.529148
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('bash', opt_dirs=['/bin']) == '/bin/bash'
    try:
        get_bin_path('nonexisting_cmd')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
        pass
    else:
        assert False


# Generated at 2022-06-20 16:05:31.097673
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-20 16:05:37.516335
# Unit test for function get_bin_path

# Generated at 2022-06-20 16:05:48.627756
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    python get_bin_path(arg, opt_dirs=None, required=None)
    '''

    from ansible.module_utils._text import to_bytes

    # Test for invalid executable 'foo'
    try:
        get_bin_path('foo')
        assert False, "get_bin_path('foo') did not raise exception"
    except ValueError:
        pass

    # Test for valid executable 'python'
    bin_path = get_bin_path('python')
    if not os.path.exists(bin_path):
        assert False, "'python' executable not found"

    # Test for valid executable 'python' in optional directory
    # For this test, the script directory is passed in.
    # This should not be present in $PATH, and so we expect to find nothing.
    bin_path

# Generated at 2022-06-20 16:06:01.037448
# Unit test for function get_bin_path
def test_get_bin_path():
    # Get executable in PATH
    assert get_bin_path('sh')
    # Get executable in optional directory
    assert "/etc" in get_bin_path('hostname', opt_dirs=['/etc'])
    # Path with spaces
    assert "/usr/local/foo bar" in get_bin_path('sh', opt_dirs=['/usr/local/foo bar'])
    # Neither PATH nor optional directory has the executable
    try:
        get_bin_path('foo', opt_dirs=['/bar'])
        assert False, 'ValueError should be raised'
    except ValueError:
        pass
    # Executable in PATH but not executable
    try:
        get_bin_path('/etc/hostname')
        assert False, 'ValueError should be raised'
    except ValueError:
        pass

# Generated at 2022-06-20 16:06:06.052739
# Unit test for function get_bin_path
def test_get_bin_path():
    good_bin_path = get_bin_path('python')
    assert os.path.isfile(good_bin_path)
    assert is_executable(good_bin_path)

    bad_bin_path = 'foo_bar_baz'
    with pytest.raises(ValueError):
        get_bin_path(bad_bin_path)

# Generated at 2022-06-20 16:06:09.392507
# Unit test for function get_bin_path
def test_get_bin_path():
    path1 = get_bin_path('python')
    assert path1.startswith('/')
    try:
        get_bin_path('this-is-not-a-real-executable')
    except ValueError:
        pass

# Generated at 2022-06-20 16:06:17.301290
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' unit test for function get_bin_path '''
    bin_path = get_bin_path('sh')
    assert bin_path is not None
    assert bin_path.endswith(os.sep + 'sh')

    # we should fail for a non-existent executable
    try:
        bin_path = get_bin_path('fantastic_binary_that_will_never_exist')
    except ValueError:
        pass
    else:
        raise AssertionError('Failed to raise exception!')

# Generated at 2022-06-20 16:06:25.098227
# Unit test for function get_bin_path
def test_get_bin_path():
    # This test relies on a valid python executable being in the PATH
    # and the test directory being in the PATH.
    # This test will fail if python is not in the PATH and will
    # skip the test if the test directory is not in the PATH.
    try:
        get_bin_path('python')
    except ValueError as e:
        raise Exception(str(e))
    try:
        get_bin_path('fictional_executable')
        raise Exception('Failed test:  Was not able to find the fictional_executable in the PATH.')
    except ValueError as e:
        if 'fictional_executable' not in str(e):
            raise Exception('Failed test:  Exception does not contain the name of the fictional_executable.')

# Generated at 2022-06-20 16:06:34.755545
# Unit test for function get_bin_path
def test_get_bin_path():
    # to enable, change to True and ensure your system has 'systemctl' command
    if False:
        from ansible.module_utils.six import PY3
        import unittest
        import sys

        class TestGetBinPath(unittest.TestCase):
            def test_get_bin_path(self):
                # Example passing test with passing test class
                self.assertEqual(os.path.normpath(get_bin_path('systemctl', required=True)), '/usr/bin/systemctl')

                # Example failing test with passing test class
                self.assertEqual(os.path.normpath(get_bin_path('systemctl', required=True)), '/usr/sbin/systemctl')


# Generated at 2022-06-20 16:06:43.619009
# Unit test for function get_bin_path
def test_get_bin_path():
    path = '/usr/bin:/bin'
    os.environ['PATH'] = path
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('curl') == '/usr/bin/curl'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin/']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin/ls']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin/ls']) == '/usr/bin/ls'

# Generated at 2022-06-20 16:06:47.318330
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('pwd', ['./lib'], True) == './lib/pwd'
    assert get_bin_path('pwd', ['./lib'], False) == './lib/pwd'
    assert get_bin_path('pwd', ['./lib']) == './lib/pwd'

# Generated at 2022-06-20 16:06:54.752948
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    from ansible.module_utils.common.file import is_executable
    test_paths = ["/bin", "/usr/bin", "/usr/local/bin"]

    for p in test_paths:
        if not os.path.exists(p):
            continue
        try:
            binary = get_bin_path(os.listdir(p)[0], test_paths)
            assert not os.path.isdir(binary)
            assert is_executable(binary)
        except:
            assert False, "Failed to find required executable in one of the following paths: %s" % os.pathsep.join(test_paths)

# Generated at 2022-06-20 16:06:59.140570
# Unit test for function get_bin_path
def test_get_bin_path():
    p = get_bin_path('python')
    assert is_executable(p)

    try:
        p = get_bin_path('thisfiledoesnotexist')
        assert False, "get_bin_path did not raise an exception"
    except ValueError:
        pass

    p = get_bin_path('sh', opt_dirs=['/bin'])
    assert is_executable(p)

# Generated at 2022-06-20 16:07:06.819679
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['.', '/usr/bin', '/bin']
    php_path = get_bin_path('php', paths, False)
    assert php_path == '/usr/bin/php'


if __name__ == '__main__':
    test_get_bin_path()
    print('All tests OK')

# Generated at 2022-06-20 16:07:11.647848
# Unit test for function get_bin_path
def test_get_bin_path():
    # First test we get the path to python2 binary
    bin_path = get_bin_path("python2")
    assert os.path.exists(bin_path)
    assert is_executable(bin_path)

    # Then we try to get the path to a not existing binary
    try:
        bin_path = get_bin_path("python3")
        assert False
    except ValueError:
        assert True

    # Then we try the same with a required parameter that is deprecated
    try:
        bin_path = get_bin_path("python3", required=True)
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-20 16:07:22.394627
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    test_vectors = [
        (['/usr/bin', '/bin'], 'sh', '/bin/sh', 'Path search failure'),
        (['/usr/bin', '/bin'], 'false', None, 'Failure to recognize non-executable'),
        (['/usr/bin', '/bin'], 'nothing', None, 'Failure to recognize non-existent file'),
        (['/usr/bin', '/bin'], 'nothing', '/bin/nothing', 'Failure to add to PATH'),
    ]

    old_path = os.environ['PATH']
    if PY3:
        old_path = to_bytes(old_path)


# Generated at 2022-06-20 16:07:32.202015
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('cat', ['/sbin', '/usr/sbin']) == '/sbin/cat'
    assert get_bin_path('cat', ['/sbin']) == '/sbin/cat'
    assert get_bin_path('cat', ['/usr/sbin']) == '/usr/sbin/cat'
    assert get_bin_path('cat', ['/usr/sbin', '/usr/sbin']) == '/usr/sbin/cat'
    assert get_bin_path('cat', ['/usr/sbin', '/sbin']) == '/usr/sbin/cat'
    assert get_bin_path('cat', opt_dirs=['/tmp/does-not-exist']) == '/bin/cat'
   

# Generated at 2022-06-20 16:07:43.249658
# Unit test for function get_bin_path
def test_get_bin_path():
    with patch.dict(os.environ, dict(PATH='/sbin:/bin:/usr/sbin:/usr/bin')):
        assert get_bin_path('ls') == '/bin/ls'
        assert get_bin_path('ping') == '/bin/ping'
        assert get_bin_path('/bin/ls') == '/bin/ls'

        assert get_bin_path('/etc/passwd', ['/']) == '/etc/passwd'
        assert get_bin_path('/etc/passwd', ['/'], True) == '/etc/passwd'

        with pytest.raises(ValueError):
            assert get_bin_path('passwd')
        with pytest.raises(ValueError):
            assert get_bin_path('xyz')

# Generated at 2022-06-20 16:07:45.371343
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-20 16:07:57.296518
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    test_get_bin_path: test get_bin_path function, for odd cases like
       - executable not found
       - executable found in one /sbin dir
       - executable is a directory
       - executable is in a directory with : as part of the name
    '''

# Generated at 2022-06-20 16:08:07.399478
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh', ['/bin', '/usr/bin'])
    assert bin_path == '/bin/sh' or bin_path == '/usr/bin/sh'

    script_path = os.path.join(os.getcwd(), 'test_get_bin_path')
    with open(script_path, 'w') as f:
        f.write('#!/bin/sh\n')
        f.close()

    bin_path = get_bin_path(script_path, [])
    assert bin_path == script_path
    os.unlink(script_path)


# Generated at 2022-06-20 16:08:15.504886
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function with system executable.
    '''
    assert get_bin_path('ls', ['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', ['/usr/bin', '/bin']) == '/usr/bin/ls' or get_bin_path('ls', ['/usr/bin', '/bin']) == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls' or get_bin_path('ls') == '/usr/bin/ls'


# Generated at 2022-06-20 16:08:27.410325
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path.
    '''
    alt_path = "/usr/bin/alternatives"
    grep_path = "/bin/grep"

    # Absolute path
    result = get_bin_path(alt_path)
    assert result == alt_path

    # Binary that can't be found
    try:
        get_bin_path("/this/should/not/exist")
    except ValueError:
        pass
    else:
        assert False

    # Binary from PATH
    result = get_bin_path("grep")
    assert result == grep_path

    # Binary from an alternate directory
    result = get_bin_path("grep", opt_dirs=("/bin",))
    assert result == grep_path

    # Binary that exists as a directory

# Generated at 2022-06-20 16:08:31.079939
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('ls')
    assert os.path.exists(bin_path)

# Generated at 2022-06-20 16:08:37.578425
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with empty path
    old_path = os.environ['PATH']
    os.environ['PATH'] = ''

    # Expected result
    required = True
    opt_dirs = ['/bin']
    expected = '/bin/sudo'

    # Test
    try:
        result = get_bin_path('sudo', opt_dirs, required)
        assert result == expected
    finally:
        os.environ['PATH'] = old_path

# Generated at 2022-06-20 16:08:46.854941
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with not required file
    assert get_bin_path('ls')

    # Test with required file
    try:
        get_bin_path('nonexistent_file', required=True)
        assert False, 'this is expected to fail'
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

    # Test with extra path
    try:
        assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    except ValueError as e:
        assert False, 'this is not expected to fail'

    # Test with wrong extra path
    try:
        get_bin_path('ls', opt_dirs=['/nonexistent_dir'])
    except ValueError as e:
        assert 'Failed to find required executable' in str

# Generated at 2022-06-20 16:08:49.330724
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no_such_file')
        assert False
    except ValueError:
        pass

    try:
        get_bin_path('ls')
    except ValueError:
        assert False

# Generated at 2022-06-20 16:08:59.417757
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    from tempfile import mkdtemp
    from ansible.module_utils.common.file import unfrackpath

    test_dir = unfrackpath(mkdtemp())
    test_bin = 'foo'
    test_path = os.path.join(test_dir, test_bin)

# Generated at 2022-06-20 16:09:08.371042
# Unit test for function get_bin_path
def test_get_bin_path():

    # Test passing a PATH that is None, or has None strings
    assert get_bin_path('/bin/ls', None) == '/bin/ls'
    assert get_bin_path('/bin/ls', [None]) == '/bin/ls'
    assert get_bin_path('/bin/ls', ['/bin', None, '/usr/bin']) == '/bin/ls'

    # Test passing a PATH that doesn't exist
    assert get_bin_path('/bin/ls', ['/this_path_doesnt_exist']) == '/bin/ls'

    # Test with the required argument set.  This test is left in place in case the deprecated
    # required argument is ever to be re-enabled.

# Generated at 2022-06-20 16:09:12.269626
# Unit test for function get_bin_path
def test_get_bin_path():
    assert os.path.join('/bin', 'grep') == get_bin_path('grep')
    assert os.path.join('/sbin', 'fipscheck') == get_bin_path('fipscheck', ['/sbin'])

# Generated at 2022-06-20 16:09:19.101169
# Unit test for function get_bin_path
def test_get_bin_path():
    current_path = os.path.dirname(os.path.abspath(__file__))
    test_path = os.path.join(current_path, 'test_get_bin_path')
    os.environ['PATH'] = test_path
    bin_path = get_bin_path('foo')
    assert bin_path == os.path.join(test_path, 'foo')
    try:
        get_bin_path('bar')
    except ValueError as err:
        assert('Failed to find required executable "bar"' in str(err))

# Generated at 2022-06-20 16:09:24.555283
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test expected failures with default arguments
    try:
        bad_path = get_bin_path('bad_path_that_is_not_executable')
    except ValueError as e:
        pass
    else:
        raise AssertionError('Expected failure for get_bin_path with bad path')

    try:
        bad_path = get_bin_path('bad_path_that_is_a_dir')
    except ValueError as e:
        pass
    else:
        raise AssertionError('Expected failure for get_bin_path with path that is a directory')

    try:
        bad_path = get_bin_path('bad_path_that_does_not_exist')
    except ValueError as e:
        pass

# Generated at 2022-06-20 16:09:36.476525
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('ls', ['/tmp']) == '/bin/ls'
    assert get_bin_path('ls', ['/bin', '/usr/bin']) == '/bin/ls'
    try:
        get_bin_path('notthere')
        assert False, 'get_bin_path must throw exception if executable is not found'
    except Exception as e:
        assert 'required executable' in str(e)

# Generated at 2022-06-20 16:09:43.207978
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('python2.7')
    except ValueError:
        pytest.fail('python2.7')

# Generated at 2022-06-20 16:09:44.907730
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' test_get_bin_path: Check get_bin_path '''
    assert get_bin_path('bash') == '/bin/bash'

# Generated at 2022-06-20 16:09:54.574267
# Unit test for function get_bin_path
def test_get_bin_path():
    # Does not work on a windows system
    import sys
    if sys.platform.startswith('win'):
        return
    # Not sure we can use assertRaisesRegex here
    import pytest
    with pytest.raises(ValueError, match='Failed to find required executable "doesnt-exist" in paths: .*'):
        get_bin_path('doesnt-exist', required=True)
    with pytest.raises(ValueError, match='Failed to find required executable "doesnt-exist" in paths: .*'):
        get_bin_path('doesnt-exist')

# Generated at 2022-06-20 16:10:04.358053
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import platform
    # Copy '/usr/bin/env' to a temporary directory and test for existance of 'env'
    temp_dir = tempfile.mkdtemp()
    shutil.copy(get_bin_path('env'), temp_dir)
    assert get_bin_path('env', opt_dirs=[temp_dir]) == os.path.join(temp_dir, 'env')
    shutil.rmtree(temp_dir)
    # Pip install 'boto3' to a temporary directory and test for existance of 'aws'
    temp_dir = tempfile.mkdtemp()
    import pip
    # boto3 >= 1.12.29 requires botocore >= 1.15.29, which is not available in the very latest AWS AMIs;
    # we use 1.12

# Generated at 2022-06-20 16:10:09.148866
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')
    assert get_bin_path('ls', ['/bin'])
    try:
        assert get_bin_path('ls', ['/bin'], required=False)
    except:
        raise Exception('test_get_bin_path failed')

    try:
        assert get_bin_path('foo')
        raise Exception('test_get_bin_path failed, should have raised exception about not finding foo')
    except:
        pass

    try:
        assert get_bin_path('foo', ['/bin'])
        raise Exception('test_get_bin_path failed, should have raised exception about not finding foo')
    except:
        pass

# Generated at 2022-06-20 16:10:16.364068
# Unit test for function get_bin_path
def test_get_bin_path():
    # Example executable path in PATH environment variable
    assert get_bin_path('sh') == '/bin/sh'

    # Example sbin paths not in PATH
    assert get_bin_path('iptables', ['/sbin']) == '/sbin/iptables'

    # Example file not found
    try:
        get_bin_path('__file_not_found')
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError() exception was not raised"

# Generated at 2022-06-20 16:10:21.489006
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("/bin/sh") == "/bin/sh"
    assert get_bin_path("sh") == "/bin/sh"
    assert get_bin_path("bash") == "/bin/bash"
    assert get_bin_path("/usr/bin/python") == "/usr/bin/python"
    assert get_bin_path("python") == "/usr/bin/python"
    assert get_bin_path("python2.7") == "/usr/bin/python2.7"
    assert get_bin_path("pwd") == "/bin/pwd"
    assert get_bin_path("fake")

if __name__ == '__main__':
    test_get_bin_path()
    print("Success")

# Generated at 2022-06-20 16:10:30.260371
# Unit test for function get_bin_path
def test_get_bin_path():
    from tempfile import NamedTemporaryFile, mkdtemp
    from shutil import rmtree

    bin1 = os.path.join(mkdtemp(), 'bin1')
    bin2 = os.path.join(mkdtemp(), 'bin2')

    with NamedTemporaryFile() as f:
        os.symlink('/bin/bash', bin1)
        os.symlink('/bin/bash', bin2)

        assert get_bin_path('bash') == '/bin/bash'
        assert get_bin_path('bash', [bin1, bin2]) == bin1
        assert get_bin_path('bash', [bin2, bin1]) == bin2

        os.unlink(bin1)
        os.unlink(bin2)

        rmtree(os.path.dirname(bin1))


# Generated at 2022-06-20 16:10:41.704614
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' test_get_bin_path: Test get_bin_path function
        Expected result:
            - without optional parameter it should fail when executable is not found
            - with optional parameter it should succeed when executable is found in one of the directories
            - with optional parameter it should fail when executable is not found in any of the directories
    '''
    import tempfile
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.file import md5, md5c

    tmpdir0 = tempfile.mkdtemp(prefix='ansible_test_get_bin_path-')
    tmpdir1 = tempfile.mkdtemp(prefix='ansible_test_get_bin_path-')

# Generated at 2022-06-20 16:10:49.157597
# Unit test for function get_bin_path
def test_get_bin_path():
    test_dir = '/tmp/foo/bar'
    assert get_bin_path('true') == '/bin/true'
    assert get_bin_path('true', [test_dir]) == '/bin/true'
    assert get_bin_path('sfdisk', [test_dir]) == '/sbin/sfdisk'
    assert get_bin_path('sfdisk', required=True) == '/sbin/sfdisk'
    try:
        get_bin_path('nosuchcmd')
        assert False, 'did not raise ValueError'
    except ValueError:
        pass
    try:
        get_bin_path('nosuchcmd', [test_dir])
        assert False, 'did not raise ValueError'
    except ValueError:
        pass

# Generated at 2022-06-20 16:11:02.335404
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    this_dir = os.path.dirname(os.path.realpath(__file__))
    temp_dir = tempfile.mkdtemp()

    def get_bin_path_test(arg, expected):
        try:
            bin_path = get_bin_path(arg)
            assert bin_path == expected
        except ValueError:
            assert expected is None

    # Test for /bin/sh (system default)
    get_bin_path_test('/bin/sh', '/bin/sh')
    get_bin_path_test('sh', '/bin/sh')
    get_bin_path_test('sh', '/bin/sh')

    # Create executable sh in temp directory

# Generated at 2022-06-20 16:11:03.486567
# Unit test for function get_bin_path
def test_get_bin_path():
    binpath = get_bin_path('cat')
    assert binpath == '/bin/cat'

# Generated at 2022-06-20 16:11:11.822400
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    if PY3:
        # Python3 raises OSError for wrong permissions
        def mock_os_access(path, mode):
            if path == '/etc/passwd' and mode == os.R_OK:
                raise OSError('Test')
            return True
    else:
        # Python2 raises IOError for wrong permissions
        def mock_os_access(path, mode):
            if path == '/etc/passwd' and mode == os.R_OK:
                raise IOError('Test')
            return True

    def mock_os_path_exists(path):
        if path == '/etc/passwd':
            return True
        return os.path.exists(path)

   

# Generated at 2022-06-20 16:11:20.866545
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.utils.path import get_bin_path
    assert get_bin_path('python') == get_bin_path('python2')
    assert get_bin_path('python3') == get_bin_path('python3.4')
    assert get_bin_path('python') != get_bin_path('python3')
    assert get_bin_path('ruby') == get_bin_path('ruby2')
    assert get_bin_path('ruby') != get_bin_path('ruby1')
    assert get_bin_path('ruby') != get_bin_path('ruby3')
    assert get_bin_path('ruby1.9') != get_bin_path('ruby2.0')

# Generated at 2022-06-20 16:11:32.234979
# Unit test for function get_bin_path
def test_get_bin_path():
    # test PATH normalization
    assert get_bin_path('curl') == '/usr/bin/curl'
    assert get_bin_path('curl', ['']) == '/usr/bin/curl'
    # test including optional directories
    assert get_bin_path('curl', ['/bin']) == '/usr/bin/curl'
    assert get_bin_path('curl', ['/bin', '/usr/bin']) == '/usr/bin/curl'
    # test including optional directories in reverse order
    assert get_bin_path('curl', ['/usr/bin', '/bin']) == '/usr/bin/curl'
    # test including optional directories with only one in PATH
    assert get_bin_path('curl', ['/bin']) == '/usr/bin/curl'
    # test non

# Generated at 2022-06-20 16:11:42.992480
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Test get_bin_path function
    """
    testpass = True
    sample_dirs = ['/usr/bin', '/usr/local/bin']
    # test case 1: success when exist directory in sample_dirs
    try:
        bin_path = get_bin_path('find', sample_dirs, False)
        if bin_path != '/usr/bin/find':
            testpass = False
            print('Test case 1: test_get_bin_path failed')
    except Exception:
        testpass = False
        print('Test case 1: test_get_bin_path failed')
    # test case 2: success when not exist directory in sample_dirs

# Generated at 2022-06-20 16:11:54.043288
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/true') == '/bin/true'
    assert get_bin_path('/bin/false') == '/bin/false'

    # Verify second parameter 'opt_dirs' works
    assert get_bin_path('/bin/true', opt_dirs=['/usr/bin']) == '/bin/true'
    assert get_bin_path('/bin/false', opt_dirs=['/usr/bin']) == '/bin/false'

    # Verify it raises an exception when executable is not found
    try:
        get_bin_path('/non/existent')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)


# Generated at 2022-06-20 16:11:55.295411
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-20 16:12:04.522335
# Unit test for function get_bin_path
def test_get_bin_path():

    # assert get_bin_path('no-exist-foo') raise ValueError
    try:
        # no-exist-foo not exist
        get_bin_path('no-exist-foo')
    except ValueError:
        pass
    else:
        assert False, 'get_bin_path should raise ValueError for non-exist executable'

    # assert get_bin_path('ls') return ls path
    ls_path = get_bin_path('ls')
    assert os.path.exists(ls_path) and os.path.isfile(ls_path) and is_executable(ls_path), 'get_bin_path return wrong path'

    # assert get_bin_path('python', ['/usr/bin/local']) return python path under /usr/bin/local

# Generated at 2022-06-20 16:12:16.819282
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test path to java
    java_cmd = 'java'
    bin_path = get_bin_path('java')
    assert bin_path
    assert java_cmd in bin_path
    assert 'java' == os.path.basename(bin_path)

    # Test path to pyhton
    python_cmd = 'python'
    bin_path = get_bin_path('python')
    assert bin_path
    assert python_cmd in bin_path
    assert 'python' == os.path.basename(bin_path)

    # Test path to ansible
    bin_path = get_bin_path('ansible')
    assert bin_path
    assert 'ansible' == os.path.basename(bin_path)

    # Test path to awk
    awk_cmd = 'awk'
    bin_

# Generated at 2022-06-20 16:12:31.053390
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for function get_bin_path
    '''
    import sys
    import shutil
    import tempfile
    import subprocess

    # Create temporary directory and temp file to use in unit testing
    tmpdir = tempfile.mkdtemp(prefix='ansible_test_get_bin_path')
    # For test: sbin and bin directories
    tmpdir_sbin = tmpdir + '/sbin'
    os.makedirs(tmpdir_sbin)
    tmpdir_bin = tmpdir + '/bin'
    os.makedirs(tmpdir_bin)
    # For test: temp file with executable name in sbin directory
    tmpfile_sbin = tmpdir_sbin + '/ansible_test_get_bin_path'

# Generated at 2022-06-20 16:12:38.908655
# Unit test for function get_bin_path
def test_get_bin_path():
    # This function is used by the integration tests in test_ansible_module_utils_common_file.py
    # So the test is primarily to keep code coverage tool happy
    test_dir = os.path.dirname(os.path.realpath(__file__))
    # get path of a fake executable
    fake_exec_path = os.path.join(test_dir, 'fake_exec')
    # since the fake_exec executable is in the test directory, it should be returned
    assert get_bin_path('fake_exec') == fake_exec_path

# Generated at 2022-06-20 16:12:51.873127
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('pwd')

# -*- -*- -*- End included fragment: ../../lib_utils/src/class/ansible/module_utils/facts/system/distribution.py -*- -*- -*-

# -*- -*- -*- Begin included fragment: ansible/module_utils/facts/system/distribution/redhat.py -*- -*- -*-

# Copyright (c) 2016 Red Hat, Inc.
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

from ansible.module_utils.facts.system.distribution import DistributionFact

# Generated at 2022-06-20 16:12:58.207425
# Unit test for function get_bin_path
def test_get_bin_path():
    test_paths = ['/bin', '/usr/bin', '/usr/local/bin']
    # test passing in optional dirs
    path = get_bin_path('bash', opt_dirs=test_paths)
    assert path == '/bin/bash'

    # test without optional dirs
    path = get_bin_path('bash')
    assert path == '/bin/bash'

    # test failure
    try:
        path = get_bin_path('not_a_binary')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError should have been raised by get_bin_path')

# Generated at 2022-06-20 16:13:06.464518
# Unit test for function get_bin_path
def test_get_bin_path():
    import mock
    import errno
    from ansible.module_utils.common.file import is_executable

    def mock_os_path_exists(path):
        if path == "/bin/sh":
            return True
        else:
            return False

    def mock_os_path_isdir(path):
        if path == "/bin/sh":
            return False
        else:
            return True

    # Test that we find /bin/sh

# Generated at 2022-06-20 16:13:13.225087
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.sys_info import get_platform
    assert get_bin_path('/bin/date') == get_bin_path('date') == '/bin/date'
    assert get_bin_path('/bin/date') != get_bin_path('ls')
    with raises(ValueError):
        get_bin_path('notfound')
    if get_platform() != 'Windows':
        assert get_bin_path('notfound', []) == get_bin_path('notfound', ['/bin'])
        assert get_bin_path('notfound', ['/bin']) == '/bin/notfound'

# Generated at 2022-06-20 16:13:14.431760
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('which')
    assert(bin_path == '/usr/bin/which')

# Generated at 2022-06-20 16:13:25.536428
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('asdf', required=True) == '/sbin/asdf'
    assert get_bin_path('asdf') == '/sbin/asdf'
    try:
        get_bin_path('asdf', opt_dirs=['/foo'], required=True)
        assert False, 'get_bin_path should have raised'
    except ValueError:
        pass
    assert get_bin_path('asdf', opt_dirs=['/foo']) == '/sbin/asdf'
    assert get_bin_path('asdf', opt_dirs=['/foo'], required=False) == '/sbin/asdf'
    assert get_bin_path('asdf', opt_dirs=['/foo']) == '/sbin/asdf'

# Generated at 2022-06-20 16:13:30.923090
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os
    test_dir = tempfile.mkdtemp()
    test_file_path = os.path.join(test_dir, "test_file")

# Generated at 2022-06-20 16:13:42.543604
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no_such_executable')
        raise AssertionError("Failed to raise exception for non-existent executable")
    except ValueError:
        pass


# Make sure the 'imp' module is used as much as possible instead of the deprecated 'importhook'.
#
# pip uses a different import strategy for modules in stdlib as for everything else. This is a
# problem for Ansible as we may monkey patch the imp module to work around problems in
# combination with certain distributions (see Debian#857641). The monkey patching is done in
# ansible.module_utils._text. In older versions of pip (versions before 9.0.0) the imp module
# was not used when importing modules from stdlib. In newer versions the imp module is used
# for all modules. This function makes sure the importhook is not used

# Generated at 2022-06-20 16:13:54.708219
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('bash')
    except Exception:
        raise AssertionError(
            'Failed to find required executable bash in paths: %s' % os.environ['PATH']
        )

    # Test optional arguments opt_dirs and required
    assert get_bin_path('bash', opt_dirs=['/bin']) == '/bin/bash'

    try:
        get_bin_path('bash_no_exist', opt_dirs=['/bin'], required=True)
    except Exception:
        pass
    else:
        raise AssertionError('Test referred to a command that does not really exist')


# Generated at 2022-06-20 16:14:02.679499
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Test get_bin_path's ability to find executables in the path '''
    try:
        get_bin_path('globally_unknown_command')
        assert 0, "get_bin_path should throw exception on unknown executable"
    except ValueError:
        pass

    try:
        # Should find ls in path
        assert get_bin_path('ls')
    except ValueError:
        assert 0, "get_bin_path should not throw exception on known executable"

    try:
        # Should find ls in path even if opt_dirs parameter is not None
        assert get_bin_path('ls', opt_dirs=[None])
    except ValueError:
        assert 0, "get_bin_path should not throw exception on known executable"

# Generated at 2022-06-20 16:14:13.114725
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['/bin', '/usr/bin', '/usr/local/bin', '/sbin', '/usr/sbin', '/usr/local/sbin']

# Generated at 2022-06-20 16:14:24.400335
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import sys

    with tempfile.TemporaryDirectory() as td:
        with open(os.path.join(td, 'test_executable'), 'w') as f:
            f.write("#!/bin/sh\nexit 0\n")
        os.chmod(os.path.join(td, 'test_executable'), 0o755)
        os.environ['PATH'] = td
        if sys.platform == 'win32':
            assert get_bin_path('test_executable')
        else:
            assert shutil.which('test_executable') == os.path.join(td, 'test_executable')

# Generated at 2022-06-20 16:14:31.777851
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    # test for valid executable in PATH
    bin_path = get_bin_path('python')
    assert bin_path == sys.executable

    # test for executable in optional dirs
    bin_path = get_bin_path('python', opt_dirs=['/usr/bin'])
    assert bin_path == sys.executable

    # test for non existing executable
    try:
        get_bin_path('this_exe_does_not_exist')
    except ValueError as e:
        assert True
    else:
        assert False



# Generated at 2022-06-20 16:14:40.076540
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('sh')
    assert path != ''
    assert path == '/bin/sh'

    path = get_bin_path('sh', ['/usr/sbin'])
    assert path != ''
    assert path == '/bin/sh'

    path = get_bin_path('echo')
    assert path != ''
    assert path == '/bin/echo'

    path = get_bin_path('echo', ['something'])
    assert path != ''
    assert path == '/bin/echo'

# Generated at 2022-06-20 16:14:46.165600
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('bash', ['/bin/bash']) == '/bin/bash'
    assert get_bin_path('bash', ['/sbin/bash']) == '/sbin/bash'