

# Generated at 2022-06-20 16:04:55.839677
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('foo') == '/usr/bin/nopath'
    assert get_bin_path('foo', opt_dirs=['/usr']) == '/usr/nopath'

# Generated at 2022-06-20 16:05:00.376049
# Unit test for function get_bin_path
def test_get_bin_path():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import path, environ, chmod
    from stat import S_IXUSR
    import sys

    # Create temporary PATH directories
    tmp1 = mkdtemp()
    tmp2 = mkdtemp()

    # Create temporary binaries
    ex1 = path.join(tmp1, 'get_bin_path_test')
    ex2 = path.join(tmp2, 'get_bin_path_test')
    with open(ex1, 'w') as f:
        f.write("#!/bin/sh\n")
        f.write("exit 0")
    with open(ex2, 'w') as f:
        f.write("#!/bin/sh\n")
        f.write("exit 0")


# Generated at 2022-06-20 16:05:02.637747
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('ansible-connection')
    assert os.path.exists(bin_path)

# Generated at 2022-06-20 16:05:12.659958
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function
    '''

    def mock_exists(path):
        return path in (
            '/usr/bin/ls',
            '/sbin/ls',
            '/usr/sbin/ls',
            '/usr/local/sbin/ls',
            '/bin/ls',
        )

    def mock_is_executable(path):
        return path in (
            '/usr/bin/ls',
            '/sbin/ls',
            '/usr/sbin/ls',
            '/usr/local/sbin/ls',
            '/bin/ls',
        )


# Generated at 2022-06-20 16:05:17.725398
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    D = tempfile.mkdtemp()
    try:
        # We create a dummy "cat" executable
        cat = os.path.join(D, 'cat')
        with open(cat, 'w') as fcat:
            fcat.write('#!/bin/sh\necho OK')
        os.chmod(cat, 0o755)
        # Now test that get_bin_path finds it
        assert get_bin_path('cat', [D]) == cat
    finally:
        os.unlink(cat)
        os.rmdir(D)

# Generated at 2022-06-20 16:05:25.151056
# Unit test for function get_bin_path
def test_get_bin_path():
    from tempfile import mkdtemp
    from shutil import copytree, rmtree, copy
    from sys import executable

    tempdir = mkdtemp(prefix='ansible_test_get_bin_path')

# Generated at 2022-06-20 16:05:26.612964
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') is not None

# Generated at 2022-06-20 16:05:28.455600
# Unit test for function get_bin_path
def test_get_bin_path():
    # get_bin_path is too intertwined with system configuration to be easily unit tested.
    assert True

# Generated at 2022-06-20 16:05:38.962896
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') in ['/bin/cat', '/usr/bin/cat']
    assert get_bin_path('cat', opt_dirs=['/bin']) == '/bin/cat'
    assert get_bin_path('cat', opt_dirs=['/bin', '/sbin']) == '/bin/cat'
    assert get_bin_path('cat', opt_dirs=['/sbin']) in ['/sbin/cat', '/usr/sbin/cat']
    try:
        get_bin_path('cat', opt_dirs=['/etc'])
    except:
        assert True
    else:
        assert False
    # if os.path.exists('/etc/python'):
    #     try:
    #         get_bin_path('python')
    #    

# Generated at 2022-06-20 16:05:45.211398
# Unit test for function get_bin_path
def test_get_bin_path():
    # If found return full path, otherwise raise ValueError.
    assert get_bin_path('/toto') == '/toto'
    assert get_bin_path('true') == '/bin/true'

    try:
        get_bin_path('trues')
        assert False
    except ValueError as e:
        assert 'Failed to find required executable "trues"' in str(e)

# Generated at 2022-06-20 16:05:53.182750
# Unit test for function get_bin_path
def test_get_bin_path():
    result = {}
    result['rc'] = 0
    try:
        test = get_bin_path('bash', ['/usr/bin'])
    except ValueError as e:
        result['msg'] = str(e)
        result['rc'] = 1
    assert result['rc'] == 0
    assert test == '/usr/bin/bash'

# Generated at 2022-06-20 16:05:58.472667
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('python')
    assert os.path.exists(bin_path)
    try:
        get_bin_path('nonexistent', required=True)
    except ValueError:
        pass
    except Exception:
        assert False, "get_bin_path('nonexistent') should raise ValueError"
    return

# Generated at 2022-06-20 16:06:05.703701
# Unit test for function get_bin_path
def test_get_bin_path():
    (rc, out, err) = module.run_command('which ls')
    path_ls = out.strip()

    # test for existing command
    assert get_bin_path('ls') == path_ls

    # test for command not found
    try:
        get_bin_path('foobar')
    except ValueError as e:
        assert 'not found' in str(e)

    # test for None as second argument
    assert get_bin_path('ls', None) == path_ls

    # test for non existing directory
    try:
        get_bin_path('ls', '/foobar')
    except ValueError as e:
        assert 'not found' in str(e)

    # test for empty string as path

# Generated at 2022-06-20 16:06:11.177543
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    PATH = os.environ.pop('PATH')
    opt_dirs = ['/usr/bin', '/usr/local/bin']


# Generated at 2022-06-20 16:06:16.403068
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check that non-executable is not returned
    try:
        get_bin_path('does-not-exist')
    except ValueError as e:
        assert 'not found' in str(e)

    # Check that executable is returned
    try:
        get_bin_path('python')
    except ValueError as e:
        assert False

# Generated at 2022-06-20 16:06:25.220848
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Check to see if function get_bin_path works correctly
    '''
    def make_function(opt_dirs, file_name, test_type, required):
        '''
        Return a function that checks to see if get_bin_path works correctly
        '''
        def function():
            temp_dir = 'test_dir'
            if test_type == 'no_dir':
                opt_dirs = None
                file_dir = None
                file_name = file_name
            elif test_type == 'no_file':
                opt_dirs = None
                file_dir = temp_dir
                file_name = file_name
            elif test_type == 'with_dir':
                opt_dirs = opt_dirs
                file_dir = temp_dir
                file_name = file

# Generated at 2022-06-20 16:06:34.779273
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Function to test get_bin_path function via unittest framework.
    '''
    # Basic test for get_bin_path
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('csh') == '/bin/csh'
    # Basic test with optionals
    assert get_bin_path('sh', ['/bin']) == '/bin/sh'
    # Test with sbin paths
    assert get_bin_path('systemctl') in ['/bin/systemctl', '/usr/bin/systemctl', '/sbin/systemctl', '/usr/sbin/systemctl']
    # Negative test

# Generated at 2022-06-20 16:06:44.901897
# Unit test for function get_bin_path
def test_get_bin_path():
    for exp_path, arg, opt_dirs, required in [
        ('/bin/true', 'true', None, None),
        ('/sbin/ip', 'ip', None, None),
        ('/sbin/ip', 'ip', ['/sbin'], None),
        ('/sbin/ip', 'ip', ['/sbin', '/bin'], None),
    ]:
        assert get_bin_path(arg, opt_dirs, required) == exp_path
    for arg, opt_dirs, required in [
        ('foo', None, None),
        ('foo', ['/sbin'], None),
    ]:
        try:
            get_bin_path(arg, opt_dirs, required)
        except ValueError:
            pass
        else:
            assert False, "should have raised"

# Generated at 2022-06-20 16:06:52.117358
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('foo') == '/usr/bin/foo'
    assert get_bin_path('foo', ['/home/foo/bin']) == '/usr/bin/foo'
    assert get_bin_path('foo', ['/home/foo/bin', '/opt/bin']) == '/usr/bin/foo'
    assert get_bin_path('foo', opt_dirs=['/home/foo/bin', '/opt/bin']) == '/usr/bin/foo'
    assert get_bin_path('python') == '/usr/bin/python'
    import os
    import shutil
    import tempfile
    foo_path = tempfile.mkstemp(prefix='foomod', dir='/tmp')[1]
    os.chmod(foo_path, 0o755)
    assert get_bin_

# Generated at 2022-06-20 16:07:00.944904
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/echo') == '/bin/echo'
    assert get_bin_path('pwd') == '/bin/pwd'
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/local/bin', '/usr/bin']) == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/local/bin', '/usr/bin']) == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/usr/bin']) == '/usr/bin/python'
    assert get_bin_path('pwd', opt_dirs=['/usr/bin']) == '/bin/pwd'
    assert get

# Generated at 2022-06-20 16:07:08.076828
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.parameters import is_executable

    assert is_executable(get_bin_path('sh'))
    assert is_executable(get_bin_path('/bin/sh'))

    try:
        get_bin_path('nonexistingcommand')
    except ValueError:
        pass

    try:
        get_bin_path('/tmp/nonexisting')
    except ValueError:
        pass

# Generated at 2022-06-20 16:07:13.652759
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Validate get_bin_path() function
    '''
    from shutil import rmtree
    import tempfile
    import getpass

    test_dirs = []
    test_dirs.append(tempfile.mkdtemp())
    test_dirs.append(tempfile.mkdtemp())
    test_dirs.append(tempfile.mkdtemp())
    test_dirs.append(tempfile.mkdtemp())
    test_dirs.append(tempfile.mkdtemp())

    tmp_dirs = []
    tmp_dirs.append(tempfile.mkdtemp(dir=test_dirs[0]))
    tmp_dirs.append(tempfile.mkdtemp(dir=test_dirs[1]))

# Generated at 2022-06-20 16:07:22.451271
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-20 16:07:25.044926
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    if sys.version_info.major == 2:
        cmd = 'python'
    else:
        cmd = 'python3'

    path = get_bin_path(arg=cmd)
    assert path
    assert is_executable(path)

# Generated at 2022-06-20 16:07:35.771342
# Unit test for function get_bin_path
def test_get_bin_path():
    # Acknowledgement: This unit test is taken from Ansible's ansible-test test_utils_command.py module,
    # the Ansible project uses the MIT License, for more details see LICENSE.MIT.
    assert get_bin_path('sh') == '/bin/sh'
    fake_paths = ['/fake/bin']
    assert get_bin_path('sh', opt_dirs=fake_paths) == '/bin/sh'
    try:
        get_bin_path('notthere')
        pytest.fail("expected failure")
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "notthere" in paths: /bin:/usr/bin'

# Generated at 2022-06-20 16:07:41.572203
# Unit test for function get_bin_path
def test_get_bin_path():
    # Function is called with required = False, it should return None
    assert get_bin_path('/bin/true', required = False) == '/bin/true'
    assert get_bin_path('/bin/false', required = False) == None
    # Function is called with required = True, it should raise ValueError
    try:
        get_bin_path('/bin/false')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

# Generated at 2022-06-20 16:07:54.180344
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Unit test to verify behaviour of get_bin_path
    """
    # default behaviour
    path = get_bin_path('echo')
    assert path == '/bin/echo'

    # search only one directory
    path = get_bin_path('echo', opt_dirs=['/usr/bin'])
    assert path == '/usr/bin/echo'

    # search several directories
    path = get_bin_path('ls', opt_dirs=['/usr/bin', '/bin'])
    assert path == '/bin/ls'

    # search binary in /sbin if not present in PATH
    path = get_bin_path('shutdown', opt_dirs=['/usr/bin', '/bin'])
    assert path == '/sbin/shutdown'

    # return exception if executable is not found in directories or PATH

# Generated at 2022-06-20 16:08:04.157584
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'

# Generated at 2022-06-20 16:08:12.498598
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Get paths for which commands exist.
    '''
    import os

    assert (get_bin_path('python'))
    assert (get_bin_path('python', ['/usr/bin']))
    assert (get_bin_path('sh'))
    assert (get_bin_path('/usr/local/bin/wget'))
    assert (get_bin_path('/usr/bin/wget'))

    # command does not exist
    try:
        get_bin_path('sentinella')
    except ValueError as e:
        assert "sentinella" in str(e)

    # command exists in a dir not in the PATH
    try:
        get_bin_path('wget')
    except ValueError as e:
        assert "wget" in str(e)

# Generated at 2022-06-20 16:08:13.824446
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-20 16:08:26.636613
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common._text import to_bytes, to_native

    # Test binary that exists and can be found
    assert get_bin_path('sh') == to_bytes(to_native(os.path.realpath(get_bin_path('sh'))))

    # Test binary that exists but can't be found
    bin_path = get_bin_path('sh', opt_dirs=[os.path.abspath(os.sep)])
    assert bin_path == to_bytes(to_native(os.path.realpath(get_bin_path('sh'))))

    # Test binary that does not exist
    try:
        get_bin_path('an-invalid-binary')
    except ValueError:
        pass

# Generated at 2022-06-20 16:08:31.094145
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls', ['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('lssssss', ['/usr/bin'], required=True)
    assert get_bin_path('lssssss', opt_dirs=['/usr/bin'], required=True)
    assert get_bin_path('lssssss', required=True)

# Generated at 2022-06-20 16:08:41.858373
# Unit test for function get_bin_path
def test_get_bin_path():
    """basic unit test for get_bin_path"""

    # Existing file in system PATH
    assert get_bin_path('bash') == '/bin/bash'

    # Existing file in defined PATH
    assert get_bin_path('bash', ['/usr/bin']) == '/usr/bin/bash'

    # Existing file in defined PATH, with double slashes
    assert get_bin_path('bash', ['/usr/bin//']) == '/usr/bin/bash'

    # Non existing file
    try:
        get_bin_path('fake')
    except ValueError as e:
        assert "Failed to find required executable \"fake\" in" in str(e)
    else:
        assert False, 'Expected ValueError'

    # Existing file in PATH, but not executable

# Generated at 2022-06-20 16:08:44.488601
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('gdate', required=True).endswith('gdate')
    assert get_bin_path('no_such_cmd', required=True) is None

test_get_bin_path()

# Generated at 2022-06-20 16:08:54.538656
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test the positive and negative behavior of get_bin_path
    '''
    # Assert that the function raises an exception if the required
    # path is not found
    try:
        get_bin_path(arg='/not/here')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised in test')

    # Assert that the function fails gracefully if we pass something
    # other than a string in as the arg
    try:
        get_bin_path(arg=10)
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised in test')

    # Assert that the function returns the correct path to ls

# Generated at 2022-06-20 16:08:57.127846
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('cat', opt_dirs=['/usr/bin']) == '/usr/bin/cat'

# Generated at 2022-06-20 16:09:03.382616
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import platform
    import stat

    # Test that function raises ValueError when required is True and executable is not found
    with tempfile.NamedTemporaryFile() as fx:
        bin_name = fx.name
        # On Windows, ensure the file is executable
        if platform.system() == 'Windows':
            os.chmod(bin_name, stat.S_IXUSR)
        with tempfile.TemporaryDirectory() as td:
            tmpdir = td
            os.chdir(tmpdir)
            expected_path = os.path.join(tmpdir, bin_name)
            with open(expected_path, 'w') as f:
                f.write('#!/bin/sh\necho hello world\n')
            os.chmod(expected_path, 0o777)

# Generated at 2022-06-20 16:09:07.766114
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile

    def get_bin_modpath(arg):
        return get_bin_path(arg, [os.path.dirname(module_utils.basic.__file__)])

    def get_bin_syspath(arg):
        return get_bin_path(arg, [sys.exec_prefix, '/usr/local/bin'])

    assert get_bin_modpath('bogus_exec') == os.path.join(os.path.dirname(module_utils.basic.__file__), 'bogus_exec')
    assert get_bin_syspath('python2.7') == sys.executable

# Generated at 2022-06-20 16:09:13.621463
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    assert get_bin_path('ls') == '/bin/ls'
    with pytest.raises(ValueError):
        get_bin_path('not_exist')
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/nonexistent']) == '/bin/ls'

# Generated at 2022-06-20 16:09:23.832575
# Unit test for function get_bin_path
def test_get_bin_path():

    # Need to set PATH to test it
    oldPath = os.environ['PATH']
    os.environ['PATH'] = '/sbin:/usr/sbin:/usr/local/sbin:' + oldPath

    # Test the executable "ls"
    expectedPath = '/bin/ls'
    actualPath = get_bin_path('ls')
    assert actualPath == expectedPath

    # Test the executable "info"
    expectedPath = '/usr/bin/info'
    actualPath = get_bin_path('info')
    assert actualPath == expectedPath

    # Test the executable "ntpq"
    expectedPath = '/usr/sbin/ntpq'
    actualPath = get_bin_path('ntpq')
    assert actualPath == expectedPath

    # Test the executable "fake-executable"

# Generated at 2022-06-20 16:09:37.499021
# Unit test for function get_bin_path
def test_get_bin_path():
    import os

    # find valid path
    get_bin_path('/bin/ls')

    # find invalid path
    try:
        get_bin_path('invalid_bin_path')
        assert False, "Expected get_bin_path to raise exception when given invalid path"
    except ValueError:
        pass

    # find valid path in optional directory
    get_bin_path('bash', opt_dirs=[os.environ.get('PATH', '').split(os.pathsep)[0]])

    # find valid path with empty optional directory
    get_bin_path('bash', opt_dirs=[''])

# Generated at 2022-06-20 16:09:44.946320
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('/bin/ls')
    get_bin_path('ls')
    get_bin_path('ifconfig', ['/sbin'])
    try:
        get_bin_path('not-exist')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    try:
        get_bin_path('not-exist', ['/bin'])
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)



# Generated at 2022-06-20 16:09:56.879097
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    import shutil
    import stat

    test_home = tempfile.mkdtemp()

# Generated at 2022-06-20 16:10:05.811675
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls', []) == '/bin/ls'
    try:
        get_bin_path('/bin/doesnotexist')
        assert False, 'Expected exception not raised'
    except ValueError as e:
        assert 'does not exist' in str(e)

    assert get_bin_path('test_file_system_utils_helper') == os.path.join(os.path.dirname(__file__), 'test_file_system_utils_helper')
    try:
        get_bin_path('test_file_system_utils_helper_not_there')
        assert False, 'Expected exception not raised'
    except ValueError as e:
        assert 'does not exist' in str(e)

# Generated at 2022-06-20 16:10:18.851532
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat', None) == '/bin/cat'
    assert get_bin_path('cat', ['/sbin']) == '/sbin/cat'
    assert get_bin_path('cat', ['/sbin', '/usr/sbin']) == '/sbin/cat'
    import shutil
    os.environ['PATH'] = '/usr/bin:/bin'
    try:
        shutil.copyfile('/bin/chmod', '/usr/bin/chmod')
        assert get_bin_path('chmod', None) == '/usr/bin/chmod'
    finally:
        os.unlink('/usr/bin/chmod')
        del os.environ['PATH']

# Generated at 2022-06-20 16:10:28.578083
# Unit test for function get_bin_path
def test_get_bin_path():
    path_elements = os.environ['PATH'].split(os.pathsep)
    paths = path_elements[:]
    paths.append(os.path.join(os.path.sep, 'sbin'))
    paths.append(os.path.join(os.path.sep, 'usr', 'sbin'))
    paths.append(os.path.join(os.path.sep, 'usr', 'local', 'sbin'))

    # /sbin directories should be included
    get_bin_path('test-module')

    # PATH directories should not be modified
    get_bin_path('test-module')
    assert os.environ['PATH'].split(os.pathsep) == path_elements

    # opt_dirs should be optional

# Generated at 2022-06-20 16:10:41.650090
# Unit test for function get_bin_path
def test_get_bin_path():
    from ..module_utils.common.file import get_bin_path

    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/bin/sh', opt_dirs=['/tmp']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/tmp']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/tmp'], required=True) == '/bin/sh'


# Generated at 2022-06-20 16:10:49.097105
# Unit test for function get_bin_path

# Generated at 2022-06-20 16:11:01.210951
# Unit test for function get_bin_path
def test_get_bin_path():
    '''unit test for get_bin_path'''
    # pylint: disable=invalid-name
    assert get_bin_path('bash') == '/usr/bin/bash'
    assert get_bin_path('bash', opt_dirs=['/bin', '/usr/bin']) == '/usr/bin/bash'
    assert get_bin_path('bash', opt_dirs=['/bin', '/usr/bin'], required=False) == '/usr/bin/bash'
    assert get_bin_path('bash', opt_dirs=['/bin', '/usr/bin'], required=False) == '/usr/bin/bash'
    try:
        get_bin_path('does_not_exist')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
   

# Generated at 2022-06-20 16:11:02.290808
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible') == '/usr/bin/ansible'

# Generated at 2022-06-20 16:11:07.577498
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') is not None

# Generated at 2022-06-20 16:11:10.908117
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sed') == '/bin/sed'
    assert get_bin_path('/bin/sed') == '/bin/sed'
    try:
        get_bin_path('notafile')
    except ValueError:
        pass
    else:
        assert False, 'get_bin_path failed to raise error'


# Generated at 2022-06-20 16:11:17.815635
# Unit test for function get_bin_path
def test_get_bin_path():
    # Executable exists in PATH:
    assert get_bin_path('sh') == '/bin/sh'
    # Executable exists in /sbin
    assert get_bin_path('ip') == '/sbin/ip'
    # Executable found in opt_dirs
    assert get_bin_path('ssh', ['/usr/libexec']) == '/usr/libexec/ssh'
    # No executable found, ValueError raised
    try:
        get_bin_path('non_existent_executable')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-20 16:11:20.244901
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('sh')
    assert path == '/bin/sh'
    with pytest.raises(ValueError):
        get_bin_path('notfound')

# Generated at 2022-06-20 16:11:31.499096
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls').endswith(os.sep + 'ls')
    assert get_bin_path('bash')
    assert get_bin_path('my_programm_that_does_not_exist') is None
    try:
        get_bin_path('ls', required=True)
        raise Exception('Failed to raise exception')
    except ValueError:
        pass
    # test opt_dirs
    assert get_bin_path('ls', opt_dirs=['/bin'], required=True).endswith(os.sep + 'ls')
    try:
        get_bin_path('ls', opt_dirs=['/unknown_dir'])
        raise Exception('Failed to raise exception')
    except ValueError:
        pass

# Generated at 2022-06-20 16:11:32.409786
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh', required=False)
    assert bin_path == '/bin/sh'

# Generated at 2022-06-20 16:11:37.595607
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('/bin/ls', opt_dirs=['/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('foo', opt_dirs=['/bin', '/usr/bin']) == '/bin/foo'

# Generated at 2022-06-20 16:11:43.823451
# Unit test for function get_bin_path
def test_get_bin_path():
    """The function should return an executable in the given path that exists."""

    assert get_bin_path("ping") == "/bin/ping"

    # Test opt_dirs, ensure it can find another executable in the system
    opt_dirs = ['/bin', '/usr/bin', '/usr/local/bin']
    assert get_bin_path("ip", opt_dirs) == "/bin/ip"

# Generated at 2022-06-20 16:11:54.628809
# Unit test for function get_bin_path
def test_get_bin_path():

    # Test that get_bin_path does what it is supposed to do
    assert 'tar' == os.path.basename(get_bin_path('tar'))

    # Test that get_bin_path error is formatted as a ValueError
    try:
        get_bin_path('some-nonexistent-program')
        assert False
    except ValueError:
        pass

    # Test that get_bin_path works with optional parameters
    assert 'tar' == os.path.basename(get_bin_path('tar', ['/bin', '/usr/bin']))

    # Test that get_bin_path works with sbin directories
    assert 'ip' == os.path.basename(get_bin_path('ip', opt_dirs=None))

# Generated at 2022-06-20 16:12:04.022149
# Unit test for function get_bin_path

# Generated at 2022-06-20 16:12:12.378792
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('tar')
    expected = '/bin/tar'
    assert bin_path == expected, 'get_bin_path result "%s" does not match expected value "%s"' % (bin_path, expected)

# Generated at 2022-06-20 16:12:19.545744
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/cat') == '/bin/cat'
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('cat', ['/sbin']) == '/sbin/cat'
    assert get_bin_path('cat', ['/sbin/bin']) == '/sbin/bin/cat'
    assert get_bin_path('cat', ['/sbin', '/bin']) == '/bin/cat'
    try:
        get_bin_path('etag') != None
    except ValueError as e:
        pass
    else:
        assert False

# Generated at 2022-06-20 16:12:23.327598
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path(arg='bash', opt_dirs=['/bin', '/usr/local/bin', '/usr/local/sbin']) == '/bin/bash'

# Generated at 2022-06-20 16:12:29.766767
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("ls")
    assert get_bin_path("ls", opt_dirs=["/bin", "/usr/bin"])
    try:
        get_bin_path("ls", opt_dirs=["/idontexist", "/noidea"])
        assert False, 'bin_path was not supposed to be found'
    except ValueError:
        pass

# Generated at 2022-06-20 16:12:40.286552
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, Mock

    with patch('ansible_collections.notstdlib.moveitallout.tests.unit.compat.builtins.open', create=True) as mock_open:
        mock_open.side_effect = OSError()
        with patch.object(os.path, "exists") as mock_exists:
            mock_exists.return_value = False
            try:
                get_bin_path('sh', ['/foo'], required=True)
            except ValueError as e:
                assert 'Failed to find required executable' in str(e)
            else:
                assert False, "Failed to raise expected ValueError"

# Generated at 2022-06-20 16:12:46.133249
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == get_bin_path('python', ['/usr/bin'])
    assert get_bin_path('python', ['/usr/bin']) == '/usr/bin/python'
    assert get_bin_path('python', ['/usr/bin']) != '/usr/bin/python3'

    # Verify a directory is not returned as a valid path
    assert get_bin_path('/usr/bin') != '/usr/bin'

    try:
        get_bin_path('thisdoesnotexist')
        assert False, "Expected exception to be thrown"
    except ValueError:
        pass

# Generated at 2022-06-20 16:12:49.044409
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('true')
    assert get_bin_path('true', required=False)
    assert get_bin_path('true', required=True)

# Generated at 2022-06-20 16:12:52.545550
# Unit test for function get_bin_path
def test_get_bin_path():
    path = os.environ['PATH']
    os.environ['PATH'] = '/bin'
    assert get_bin_path('sh', required=True) == '/bin/sh'
    os.environ['PATH'] = path

# Generated at 2022-06-20 16:13:00.884400
# Unit test for function get_bin_path
def test_get_bin_path():
    import ansible.module_utils.basic
    test_paths = ['/bin', '/usr/bin', '/usr/local/bin']
    for path in test_paths:
        # file exists
        ansible.module_utils.basic.get_bin_path('ls', opt_dirs=path)
        # file does not exist
        try:
            ansible.module_utils.basic.get_bin_path('xxxxxxx', opt_dirs=path)
        except Exception as e:
            pass
        else:
            raise Exception("get_bin_path should have failed")
    # file exists, path does not
    try:
        ansible.module_utils.basic.get_bin_path('ls', opt_dirs="/xxxxx")
    except Exception as e:
        pass

# Generated at 2022-06-20 16:13:09.405982
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for function get_bin_path
    '''

    # Test when the executable is found in the paths
    try:
        path = get_bin_path('/bin/cat')
        assert path == '/bin/cat'
    except ValueError:
        # Invalid executable should raise exception
        assert False

    # Test when the executable is not found in the paths
    paths = []
    try:
        path = get_bin_path('invalid_executable', paths)
        # Invalid executable should raise exception
        assert False
    except ValueError:
        assert True

    # Test when the executable is not found in the paths and required
    paths = []

# Generated at 2022-06-20 16:13:22.951164
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test invalid executable
    try:
        get_bin_path('/nonexistent/test-test')
    except ValueError:
        pass
    else:
        assert False
    # Test valid executable
    assert get_bin_path('touch') == '/bin/touch'
    # Test valid executable in optional paths
    assert get_bin_path('touch', opt_dirs=['/bin']) == '/bin/touch'

# Generated at 2022-06-20 16:13:30.922678
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    tempdir = tempfile.mkdtemp()

    # Test an executable that exists in the user's standard path
    try:
        get_bin_path('id')
    except ValueError:
        assert False, 'get_bin_path failed to find "id" utility'

    # Test an executable that doesn't exist
    try:
        get_bin_path('idontexist')
        assert False, 'get_bin_path did not raise exception for "idontexist"'
    except ValueError:
        pass

    # Create an executable in the temporary directory
    test_executable = os.path.join(tempdir, 'testexecutable')
    with open(test_executable, 'w') as f:
        f.write('#!/bin/sh\necho "testexecutable ran"\n')

# Generated at 2022-06-20 16:13:42.544470
# Unit test for function get_bin_path
def test_get_bin_path():
    # Executable not in PATH but in current directory
    bin_path = get_bin_path('grep', [os.getcwd()])
    assert bin_path == os.path.join(os.getcwd(), 'grep')

    # Executable in PATH
    bin_path = get_bin_path('grep')
    assert bin_path == '/bin/grep'

    # Executable in PATH and in current directory
    bin_path = get_bin_path('grep', [os.getcwd()])
    assert bin_path == '/bin/grep'

    # Executable not found in either PATH or current directory

# Generated at 2022-06-20 16:13:52.055762
# Unit test for function get_bin_path
def test_get_bin_path():
    success_cases = (
        (['/usr/bin'], '/bin/ls', '/usr/bin/ls'),
        (['/usr/bin'], 'ls', '/usr/bin/ls'),
        ([None], '/bin/ls', '/bin/ls'),
        ([None], 'ls', '/bin/ls'),
    )

    for opt_dirs, arg, expected in success_cases:
        try:
            assert get_bin_path(arg, opt_dirs=opt_dirs) == expected
        except Exception as e:
            raise AssertionError("Failed on input (opt_dirs=%s, arg=%s)" % (opt_dirs, arg)) from e


# Generated at 2022-06-20 16:13:58.226714
# Unit test for function get_bin_path
def test_get_bin_path():
    import mock
    import sys

    if sys.version_info < (2, 7):
        print('Test of function get_bin_path requires Python 2.7 or greater')
        sys.exit(0)

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    old_open = None

# Generated at 2022-06-20 16:14:03.482081
# Unit test for function get_bin_path
def test_get_bin_path():
    """ test get_bin_path function """
    from ansible.module_utils.common.process import get_bin_path
    from random import randrange

    bn = "nonexistent_command_%s" % randrange(1000000)
    try:
        get_bin_path(bn)
    except ValueError:
        pass
    else:
        assert False, "Should have raised exception"

# Generated at 2022-06-20 16:14:04.109308
# Unit test for function get_bin_path
def test_get_bin_path():
    # TODO: implement tests
    pass

# Generated at 2022-06-20 16:14:08.002404
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('vi') == '/usr/bin/vi'
    assert get_bin_path('vi', ['/usr/bin', '/bin']) == '/usr/bin/vi'
    assert get_bin_path('vi', ['/usr/bin', '/bin', '/usr/local/bin']) == '/usr/bin/vi'
    assert get_bin_path('vi', ['/usr/bin', '/bin', '/usr/local/bin'], None) == '/usr/bin/vi'
    assert get_bin_path('vi', ['/usr/bin', '/bin', '/usr/local/bin'], True) == '/usr/bin/vi'


# Generated at 2022-06-20 16:14:15.424706
# Unit test for function get_bin_path
def test_get_bin_path():
    test_bin_path = '/bin/test_bin_path'
    assert get_bin_path('/bin/test_bin_path') == test_bin_path
    assert get_bin_path('/usr/bin/test_bin_path') == '/usr/bin/test_bin_path'

    # use optional argument opt_dirs
    test_dir = '/tmp/test_dir'
    assert get_bin_path('/bin/test_bin_path', opt_dirs=[test_dir]) == test_bin_path
    assert get_bin_path('/usr/bin/test_bin_path', opt_dirs=[test_dir]) == '/usr/bin/test_bin_path'

# Generated at 2022-06-20 16:14:26.023784
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('find', opt_dirs=['/usr/bin', '/usr/sbin']) == '/usr/bin/find'
    assert get_bin_path('ls', ['/bin', '/sbin', '/usr/sbin']) == '/bin/ls'
    assert get_bin_path('ls', ['/bin', '/sbin', '/usr/sbin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=None) == '/bin/ls'
    assert get_bin_path('ping', opt_dirs=['/bin', '/sbin', '/usr/bin', '/usr/sbin']) == '/bin/ping'

# Generated at 2022-06-20 16:14:43.824418
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('not_an_executable', required=False)
        assert False, 'expected error due to not finding executable'
    except Exception as e:
        assert 'Failed to find required executable' in str(e)

    # Try to find a real executable using paths with both executable and
    # non-readable bits set.
    orig_path = os.environ['PATH']
    try:
        # Note: This assumes that the file /tmp exists.
        os.environ['PATH'] = '/tmp'
        assert get_bin_path('/bin/sh') == '/bin/sh', 'Failed to find /bin/sh'
    finally:
        os.environ['PATH'] = orig_path

# Generated at 2022-06-20 16:14:50.350409
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr']) == '/bin/sh'

    try:
        get_bin_path('this_program_does_not_exist')
        raise AssertionError("We should not get here, get_bin_path should raise a ValueError")
    except ValueError as e:
        # ok
        pass