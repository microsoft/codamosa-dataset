

# Generated at 2022-06-20 16:05:05.787558
# Unit test for function get_bin_path
def test_get_bin_path():
    """Verify the get_bin_path function returns the expected binary path
    based on the given PATH.

    This function is not intended to be run automatically as part of
    the unit test suite. Instead it is expected that this would be run
    manually, such as:

    source hacking/env-setup
    python -m testtools.run ansible.module_utils.basic.get_bin_path
    """
    from testtools import TestCase
    import ansible.module_utils.basic
    from io import StringIO

    class TestGetBinPath(TestCase):
        def test_get_bin_path_raises_value_error_on_missing_binary(self):
            """Verify that get_bin_path raises a ValueError when an
            executable cannot be found on the given PATH.
            """

# Generated at 2022-06-20 16:05:08.126749
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('find', required=True)
    try:
        get_bin_path('find_no_such_cmd_by_this_name', required=True)
    except ValueError:
        pass
    else:
        assert False, "Expected to raise ValueError"

# Generated at 2022-06-20 16:05:15.378030
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/usr/bin/bad_path')
        assert False, "Should have thrown ValueError"
    except ValueError:
        pass

    # Assert that the last directory in PATH is used when multiple matches.
    os.environ['PATH'] = '/dummy1:/usr/bin:/usr/local/bin:/dummy2'
    assert get_bin_path('python') == '/dummy2/python'

    os.environ['PATH'] = '/usr/bin:/dummy1:/dummy2'
    assert get_bin_path('python') == '/usr/bin/python'

# Generated at 2022-06-20 16:05:20.388881
# Unit test for function get_bin_path
def test_get_bin_path():
    import os

    # get_bin_path should raise an exception if path doesn't contain the executable
    try:
        get_bin_path("no_such_file")
    except ValueError:
        pass
    else:
        raise Exception("Failed to execute get_bin_path with no_such_file")

    # get_bin_path should return the path of the executable given to it
    found = get_bin_path("/bin/true")
    if found != "/bin/true":
        raise Exception("get_bin_path does not return the path of the given executable")

    # get_bin_path should return the path of the executable given to it
    found = get_bin_path("true")
    if found != "/bin/true":
        raise Exception("get_bin_path does not return the path of the given executable")

# Generated at 2022-06-20 16:05:27.187436
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat
    import os.path


# Generated at 2022-06-20 16:05:29.163758
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('tee') == '/usr/bin/tee'

# Generated at 2022-06-20 16:05:39.091579
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    from os.path import join, basename

    path = get_bin_path('sh')

    assert basename(path) == 'sh'

    tmpdir = tempfile.mkdtemp()
    open(join(tmpdir, 'test_file'), 'w').close()
    open(join(tmpdir, 'test_file_2'), 'w').close()

    assert get_bin_path(join(tmpdir, 'test_file'), required=True) == join(tmpdir, 'test_file')
    try:
        get_bin_path(join(tmpdir, 'test_file_3'), required=True)
        assert False
    except ValueError:
        pass


# Generated at 2022-06-20 16:05:39.645720
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-20 16:05:50.115632
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    This unit test checks that get_bin_path() returns correct path
    and that function raises an exception if executable is not found.
    '''
    import tempfile
    import shutil
    from ansible.module_utils.common.file import HASHES_FILES_TO_REMOVE


# Generated at 2022-06-20 16:06:00.479473
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    bin_dir = tempfile.mkdtemp()
    bin_path = os.path.join(bin_dir, 'test_bin')
    open(bin_path, 'w').write("#!/bin/sh\n")

# Generated at 2022-06-20 16:06:13.537515
# Unit test for function get_bin_path
def test_get_bin_path():
    import os, sys

    if sys.platform == "darwin" or sys.platform.startswith("freebsd"):
        test_bin = "/usr/bin/which"
    else:
        test_bin = "/bin/uname"

    os.environ["PATH"] = "/bin:/usr/bin"
    assert get_bin_path("uname") == test_bin

    os.environ["PATH"] = "/usr/bin"
    try:
        # The bin name is changed because on FreeBSD, /bin/uname is a shell script
        get_bin_path("uname")
        assert False
    except ValueError as e:
        assert "Failed to find required executable" in str(e)



# Generated at 2022-06-20 16:06:24.269837
# Unit test for function get_bin_path
def test_get_bin_path():
    test_path = os.path.join('test','file','path')
    if 'PATH' in os.environ:
        old_path = os.environ['PATH']
        os.environ['PATH'] += os.pathsep + test_path
    else:
        old_path = None
        os.environ['PATH'] = test_path

    # test that function returns path if the executable is found
    assert get_bin_path('echo') == os.path.join(test_path, 'echo')

    # test that function raises exception if the executable is not found
    try:
        get_bin_path('nonexistent')
        assert False
    except ValueError:
        pass

    # test that opt_dirs are searched before PATH
    # if the executable is found

# Generated at 2022-06-20 16:06:31.798522
# Unit test for function get_bin_path
def test_get_bin_path():
    for f in ('/bin/sh', 'ansible', 'true'):
        assert get_bin_path(f)
    for f in ('nonsense', 'something-that-does-not-exist'):
        try:
            get_bin_path(f)
        except ValueError:
            pass
        else:
            asse

# Generated at 2022-06-20 16:06:39.746395
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        bin_path = get_bin_path('cat', ['/usr/bin', '/bin'])
        assert bin_path == '/bin/cat'
    except ValueError:
        assert False
    try:
        bin_path = get_bin_path('cat')
        assert bin_path == '/bin/cat'
    except ValueError:
        assert False
    try:
        bin_path = get_bin_path('cat', ['/usr/bin', '/bin'])
        assert bin_path == '/bin/cat'
    except ValueError:
        assert False
    try:
        bin_path = get_bin_path('cat', ['/usr/bin', '/bin'], required=True)
        assert bin_path == '/bin/cat'
    except ValueError:
        assert False

# Generated at 2022-06-20 16:06:48.428401
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    import unittest

    def create_executable(path, mode=0o755):
        with open(path, 'w') as f:
            pass
        os.chmod(path, mode)

    class TestGetBinPath(unittest.TestCase):
        """Unit tests for get_bin_path()."""

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.executable = os.path.join(self.test_dir, "executable")
            create_executable(self.executable)

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_executable_in_path(self):
            path = get_bin_path("executable")
            self

# Generated at 2022-06-20 16:06:57.243966
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('bash', list('/usr/bin'), required=False)
    except:
        assert False
    try:
        get_bin_path('bash', list('/usr/bin'), required=True)
    except:
        assert False
    try:
        get_bin_path('bash', list('/usr/bin'), required=None)
    except:
        assert False
    try:
        get_bin_path('bash', ['invalid1', 'invalid2'])
    except:
        assert False
    try:
        get_bin_path('bash', [None, None])
    except:
        assert False
    try:
        get_bin_path('bash', [''])
    except:
        assert False

# Generated at 2022-06-20 16:07:05.152685
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['/bin', '/usr/bin', '/usr/local/bin']
    for path in paths:
        try:
            bin_path = get_bin_path('ansible-config', opt_dirs=[path])
        except ValueError:
            assert False, 'ansible-config found in: %s' % path

    try:
        bin_path = get_bin_path('ansible-lint', opt_dirs=[])
    except ValueError:
        assert False, 'ansible-lint found in /usr/bin'

    try:
        bin_path = get_bin_path('ansible-playbook', opt_dirs=[])
    except ValueError:
        assert False, 'ansible-playbook found in /usr/bin'


# Generated at 2022-06-20 16:07:07.820650
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Note: This unit test will fail, if default path to 'which' command is changed.
    '''
    from ansible.module_utils.basic import AnsibleModule
    bin_path = get_bin_path('which', opt_dirs=None, required=True)
    assert bin_path == '/usr/bin/which'

# Generated at 2022-06-20 16:07:13.214489
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test that get_bin_path returns the first executable file it finds in the search path.
    #
    # We create a temporary directory with two files, one of which is executable. We create
    # a link in that directory to another executable file which is not in the search path.
    # The files are named by the following variables.
    bin_filename = 'bin_file'
    link_filename = 'link_file'
    realbin_filename = 'realbin_file'


# Generated at 2022-06-20 16:07:19.027160
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/bin/sh')
        assert 1 == 0, "should not be able to solve absolute path"
    except ValueError:
        pass

    sh = get_bin_path('sh')
    assert sh.endswith('/sh') or sh.endswith('\\sh')
    assert is_executable(sh)

# Generated at 2022-06-20 16:07:22.464931
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-20 16:07:28.712000
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    # bin path of getent
    BIN_PATH = "/usr/bin/getent"
    # Optional PATH diretories to search
    OPT_DIRS = ['/usr/bin', '/usr/local/bin']
    # Expected bin path of getent
    EXPECTED = "/usr/bin/getent"
    # Actual bin path of getent
    ACTUAL = get_bin_path("getent", OPT_DIRS)

    assert EXPECTED == ACTUAL

    # Expected exception
    with pytest.raises(ValueError) as err:
        get_bin_path("invalid_binary", OPT_DIRS)
    assert "Failed to find required executable" in str(err.value)



# Generated at 2022-06-20 16:07:35.770951
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('cat')
    assert bin_path == '/bin/cat'

    import tempfile
    with tempfile.NamedTemporaryFile() as f:
        os.chmod(f.name, 0o700)
        bin_path = get_bin_path(f.name)
        assert bin_path == f.name

# Generated at 2022-06-20 16:07:44.716779
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1:
    bin_path = get_bin_path('ansible')
    assert bin_path.endswith('/ansible')

    # Test 2:
    bin_path = get_bin_path('ansible', opt_dirs=['/usr/bin'])
    assert bin_path.endswith('/ansible')

    # Test 3:
    opt_dirs = ['/usr/bin', '/bin', '/usr/sbin']
    bin_path = get_bin_path('echo', opt_dirs=opt_dirs)
    assert bin_path.endswith('/echo')

    # Test 3:
    opt_dirs = ['/usr/bin', '/usr/sbin']

# Generated at 2022-06-20 16:07:48.028437
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('ls')
    assert path and os.path.isfile(path)



# Generated at 2022-06-20 16:07:57.305462
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat
    import subprocess

    def _test_executable(cmd):
        # test that the command `cmd' can be executed
        rc = subprocess.call(cmd, stdout=open(os.devnull, 'w'), stderr=subprocess.STDOUT)
        if rc != 0:
            raise Exception("command '%s' failed with rc=%d" % (cmd, rc))

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a test executable
    test_app = 'testapp'
    test_app_path = os.path.join(tmpdir, test_app)
    test_app_symlink = os.path.join(tmpdir, 'testapp_symlink')
    test_app_symlink_

# Generated at 2022-06-20 16:08:02.255868
# Unit test for function get_bin_path
def test_get_bin_path():
    assert isinstance(get_bin_path("sh"), str)
    assert isinstance(get_bin_path("sh", opt_dirs=["/bin"]), str)
    assert isinstance(get_bin_path("sh", opt_dirs=["/bin", "/usr/bin"]), str)

# Generated at 2022-06-20 16:08:09.243911
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    # Setup needed environment variables
    old_env_path = os.getenv("PATH", None)
    old_env_sbin_paths = os.getenv("SBIN_PATH", None)
    old_env_sbin_paths = os.getenv("SBIN_PATHS", None)
    os.environ["PATH"] = "/usr/bin:/bin"
    os.environ["SBIN_PATH"] = "/sbin"
    os.environ["SBIN_PATHS"] = "/usr/sbin:/usr/local/sbin"

# Generated at 2022-06-20 16:08:17.816659
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python2', required=False) is not None
    assert get_bin_path('python2.7', required=False) is not None
    assert get_bin_path('python3', required=False) is not None
    assert get_bin_path('python3.5', required=False) is not None
    assert get_bin_path('ansible', required=False) is not None
    assert get_bin_path('ansible-playbook', required=False) is not None

    # Validate exception is thrown if command is not found
    try:
        get_bin_path('invalid-path')
    except ValueError:
        pass
    else:
        assert False, "Failed to throw exception"

# Generated at 2022-06-20 16:08:29.527424
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' ansible.module_utils.common.get_bin_path tests '''

    # PATH is not set
    os.environ['PATH'] = ''

    # get_bin_path raises ValueError if binary does not exist
    got_error = False
    try:
        get_bin_path('/bin/noprogram', required=True)
    except ValueError:
        got_error = True
    assert got_error

    # get_bin_path returns correct path for system binary
    assert get_bin_path('/bin/ls') == '/bin/ls'

    # get_bin_path can handle system binary with args
    assert get_bin_path('/bin/ls -l') == '/bin/ls'

    # get_bin_path returns first bin found in path

# Generated at 2022-06-20 16:08:34.991804
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    if bin_path is None or not os.path.exists(bin_path):
        raise Exception('Failed to find required executable')

# Generated at 2022-06-20 16:08:44.648376
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # confirm get_bin_path() raises an exception when it fails
        get_bin_path('wibble', required=True)
        assert 'exception expected'
    except ValueError:
        # expected
        pass
    # confirm get_bin_path() raises an exception when it fails
    get_bin_path('wibble')
    assert 'exception expected'

    # confirm get_bin_path() returns the expected value when runnable
    assert get_bin_path('python') == '/usr/bin/python', \
        'Expected get_bin_path to return the full path to a runnable executable'

    # confirm get_bin_path() raises an exception when it fails
    get_bin_path('/usr/lib/python2.7/plat-linux2/python')

# Generated at 2022-06-20 16:08:46.897557
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('which', []) == get_bin_path('which')

# Generated at 2022-06-20 16:08:56.312044
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = 'echo'
    paths = ['/bin', '/usr/bin']
    bin_path = get_bin_path(arg, paths)
    assert bin_path == '/bin/echo'

    arg = '/bin/echo'
    paths = ['/usr/bin']
    bin_path = get_bin_path(arg, paths)
    assert bin_path == '/bin/echo'

    arg = '/usr/bin/echo'
    paths = ['/bin']
    bin_path = get_bin_path(arg, paths)
    assert bin_path == '/usr/bin/echo'

    arg = '/usr/local/bin/echo'
    paths = ['/bin']
    bin_path = get_bin_path(arg, paths)
    assert bin_path == '/usr/local/bin/echo'

    #

# Generated at 2022-06-20 16:09:02.748834
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test found
    assert '/bin/ls' == get_bin_path('ls')
    assert '/bin/ls' == get_bin_path('ls', ['/bin'])

    # Test not found
    try:
        get_bin_path('ls', ['/invalid_dir'])
    except Exception as e:
        assert 'Failed to find required executable "ls"' in str(e)
    else:
        assert False, 'Expected Exception'

# Test for function get_bin_path with optional arg 'required'

# Generated at 2022-06-20 16:09:07.872615
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=["/bin"]) == '/bin/ls'
    def _exec_fail():
        get_bin_path('ls', opt_dirs=["/dev"])
    import pytest
    with pytest.raises(ValueError):
        _exec_fail()

# Generated at 2022-06-20 16:09:15.636523
# Unit test for function get_bin_path
def test_get_bin_path():
    #  Given:
    #    - arg is a valid executable
    #  When:
    #    - get_bin_path is called
    #  Then:
    #    - get_bin_path returns successfully
    try:
        get_bin_path("echo")
    except:
        assert False
    #  Given:
    #    - arg is NOT a valid executable
    #  When:
    #    - get_bin_path is called
    #  Then:
    #    - get_bin_path raises an exception
    try:
        get_bin_path("__bad_executable__")
        assert False
    except:
        assert True

# Generated at 2022-06-20 16:09:26.596646
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_native


# Generated at 2022-06-20 16:09:37.775932
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    test_exe_name = 'ansible-test-command'
    test_exe_cmd = '#!/bin/bash\necho hello\n'

    test_exe_cmd = test_exe_cmd.encode()
    current_paths = os.environ.get('PATH', '').split(os.pathsep)


# Generated at 2022-06-20 16:09:41.657628
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = basic.AnsibleArgs({})
    assert(get_bin_path('sh'))



# Generated at 2022-06-20 16:09:50.167367
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic
    from ansible.module_utils.six import PY2
    import sys

    try:
        sys.stdout.write('')
    except IOError:
        # python may be in a mode where stdout is not writable, e.g. frozen Windows exe or Console app
        sys.exit(0)

    # emulate an empty PATH
    basic._ANSIBLE_ARGS = None
    basic._ANSIBLE_ARGS = basic.AnsibleModuleArgs(
        argument_spec=dict()
    )
    os.environ.pop('PATH', None)

# Generated at 2022-06-20 16:10:00.548772
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Test for ansible.module_utils.basic.get_bin_path function.
    """
    import tempfile
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-20 16:10:08.928489
# Unit test for function get_bin_path
def test_get_bin_path():
    import platform
    import tempfile
    import subprocess
    import shutil

    # Test an executable that should always be on the system
    sh_path = get_bin_path('sh', required=True)
    assert sh_path == '/bin/sh' or sh_path == '/usr/bin/sh' or sh_path == '/usr/sbin/sh'

    # Test an executable that should be in the same directory
    my_path = os.path.abspath(__file__)
    parent_dir = os.path.dirname(my_path)
    temp_script = os.path.join(parent_dir, 'test_get_bin.sh')
    with open(temp_script, 'w') as f:
        f.write('#!/bin/sh\n')

# Generated at 2022-06-20 16:10:12.492187
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('foo', ['.']) == './foo'
    assert get_bin_path('false', None) == '/bin/false'


# Generated at 2022-06-20 16:10:22.617705
# Unit test for function get_bin_path
def test_get_bin_path():
    def get_bin_path_func(arg, opt_dirs=None, required=None):
        if opt_dirs is None:
            opt_dirs = []
        return get_bin_path(arg, opt_dirs, required)

    # Test 1: Success with various arguments
    assert get_bin_path_func('/bin/ls') == '/bin/ls'
    assert get_bin_path_func('echo') == '/bin/echo'
    assert get_bin_path_func('echo', ['/bin', '/sbin']) == '/bin/echo'
    assert get_bin_path_func('echo', ['/sbin', '/bin']) == '/bin/echo'
    assert get_bin_path_func('echo', opt_dirs=['/sbin', '/bin']) == '/bin/echo'

# Generated at 2022-06-20 16:10:28.854293
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.utils.path import unfrackpath

    # good path
    #
    # note: if /usr/bin/python is not present on the system running the tests,
    # this will fail
    p = get_bin_path("python")
    assert unfrackpath("/usr/bin/python") == unfrackpath(p)

    # bad path
    try:
        p = get_bin_path("foo_bar_baz")
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError")

# Generated at 2022-06-20 16:10:33.809176
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-20 16:10:40.062028
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    import shutil

    # Test the following scenarios:
    # 1. Normal execution
    # 2. With required=True which should be ignored and exception raised
    # 3. File with required arg not found and exception raised
    # 4. file with opt_dirs not found and exception raised
    exe_name = 'ansible-test-exe%s' % sys.version_info[0]
    # 1. Normal execution
    try:
        bin_path = get_bin_path(exe_name)
        assert bin_path is None
    except ValueError as e:
        pass

    # 2. With required=True
    try:
        get_bin_path(exe_name, required=True)
    except ValueError as e:
        assert 'Failed to find required executable "%s"' % exe

# Generated at 2022-06-20 16:10:42.903313
# Unit test for function get_bin_path
def test_get_bin_path():
    __import__('ansible.utils.path')
    import ansible.utils.path
    ansible.utils.path.get_bin_path = get_bin_path
    from ansible.module_utils.common.os import get_bin_path
    get_bin_path('env')

# Generated at 2022-06-20 16:10:47.343206
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.path.exists("/usr/bin/python"):
        r, s = get_bin_path("python"), os.path.realpath("/usr/bin/python")
        assert r == s, "test_get_bin_path() failed - expected %s, got %s" % (r, s)


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-20 16:10:58.588836
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for a bogus executable to be sure we raise ValueError
    try:
        get_bin_path('bogus_executable_that_does_not_exist')
    except ValueError:
        pass
    else:
        raise AssertionError('get_bin_path did not raise ValueError')

    # Test with a valid executable
    path = get_bin_path('mountpoint')
    if not os.path.exists(path):
        raise AssertionError('get_bin_path failed to find mountpoint executable')

# Generated at 2022-06-20 16:11:02.689435
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('ntpd') == '/usr/sbin/ntpd'
    try:
        get_bin_path('/foo')
    except ValueError:
        pass
    else:
        assert False, 'Expected exception with arg /foo'
    try:
        get_bin_path('nosuchbinary')
    except ValueError:
        pass

# Generated at 2022-06-20 16:11:04.426086
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Test by function get_bin_path
    """
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-20 16:11:09.736928
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', ['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('cp') == '/bin/cp'
    assert get_bin_path('chmod') == '/bin/chmod'
    assert get_bin_path('man') == '/usr/bin/man'
    assert get_bin_path('systemctl') == '/bin/systemctl'

# Generated at 2022-06-20 16:11:21.123922
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    if sys.version_info[0] == 2:
        # python 2.7 patch to fake is_executable func
        import stat
        def is_executable(path):
            mode = os.stat(path).st_mode
            return bool(stat.S_IXUSR & mode)
    else:
        from ansible.module_utils.common.file import is_executable

    assert get_bin_path('python2.7') == '/usr/bin/python2.7'
    assert get_bin_path('ansible-test', opt_dirs=['/usr/local/bin']) == '/usr/local/bin/ansible-test'
    assert is_executable(get_bin_path('ansible-test')) is True

# Generated at 2022-06-20 16:11:32.416181
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    from ansible.module_utils._text import to_bytes

    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)


# Generated at 2022-06-20 16:11:33.175365
# Unit test for function get_bin_path
def test_get_bin_path():
    # TODO: Implement the unit test on the get_bin_path function.
    pass

# Generated at 2022-06-20 16:11:38.258252
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with a non existing file
    non_existing_file = 'non-existing-file'
    expected_error_message = 'Failed to find required executable "%s" in paths: %s' % (non_existing_file, os.pathsep.join(os.environ.get('PATH', '').split(os.pathsep)))
    try:
        get_bin_path(non_existing_file)
    except ValueError as e:
        assert str(e) == expected_error_message
    else:
        assert False, "Expected ValueError to be raised"

    # Test with a file that exists in more than 1 dir in PATH
    existing_file = 'ls'
    expected_result = get_bin_path(existing_file)
    result = get_bin_path(existing_file)

# Generated at 2022-06-20 16:11:39.984126
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'

# Generated at 2022-06-20 16:11:47.510202
# Unit test for function get_bin_path
def test_get_bin_path():
    # test for a fake executable
    try:
        get_bin_path('bin_not_in_path')
    except ValueError as e:
        assert e.args[0] == 'Failed to find required executable "bin_not_in_path" in paths: /sbin:/bin:/usr/sbin:/usr/bin'
    else:
        raise Exception('test failed: expected ValueError')

    import sys
    assert get_bin_path(sys.executable) == sys.executable # test for sys.executable

# Generated at 2022-06-20 16:12:02.358603
# Unit test for function get_bin_path
def test_get_bin_path():
    import errno
    import tempfile
    from ansible.module_utils import basic

    # create directory containing one file which is executable
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-20 16:12:08.808237
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("true")
    assert get_bin_path("/usr/bin/true")
    assert get_bin_path("/bin/bash", opt_dirs=['/bin'])
    assert get_bin_path("/bin/bash", opt_dirs=['/does_not_exist'])
    assert get_bin_path("/bin/bash", opt_dirs=['/does_not_exist', '/bin'])
    assert get_bin_path("/bin/bash", opt_dirs=[None, '/does_not_exist', None, '/bin'])
    assert get_bin_path("/bin/bash", opt_dirs=['/does_not_exist', None, '/bin'])
    import pytest
    with pytest.raises(ValueError):
        assert get_bin

# Generated at 2022-06-20 16:12:14.650361
# Unit test for function get_bin_path
def test_get_bin_path():
    res = get_bin_path('python')
    assert res == '/usr/bin/python'
    res = get_bin_path('/usr/bin/python')
    assert res == '/usr/bin/python'
    res = get_bin_path('/bin/toto')
    assert res == '/bin/toto'
    res = get_bin_path('toto', required=False)
    assert res is None



# Generated at 2022-06-20 16:12:19.458361
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.six.moves import builtins

    assert get_bin_path('sh') == os.path.join(os.sep, 'bin', 'sh')
    assert get_bin_path('ls') == os.path.join(os.sep, 'bin', 'ls')
    assert get_bin_path('wrong_cmd') is None



# Generated at 2022-06-20 16:12:21.099995
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('sh')
    assert len(path) > 0

# Generated at 2022-06-20 16:12:24.726704
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible') is not None
    assert get_bin_path('this-is-really-unlikely-to-be-a-valid-executable-name-at-all') is None

# Generated at 2022-06-20 16:12:35.572554
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Tests for function get_bin_path'''
    # 1. Test - no optional arguments
    try:
        get_bin_path('/bin/ls')
    except Exception as e:
        assert(False)

    # 2. Test - with optional arguments
    # 2.a - /bin/ls executable must be in the paths
    try:
        get_bin_path('/bin/ls', ['/bin', '/usr/bin'])
    except Exception as e:
        assert(False)

    # 2.b - /bin/ls executable must not be in the paths
    try:
        get_bin_path('/bin/ls', ['/tmp'])
        assert(False)
    except Exception as e:
        assert(True)

# Generated at 2022-06-20 16:12:43.624550
# Unit test for function get_bin_path
def test_get_bin_path():
    cwd = os.path.abspath(os.path.dirname(__file__))

    assert get_bin_path('test/test_get_bin_path.sh') == os.path.join(cwd, 'test/test_get_bin_path.sh')

    os.environ['PATH'] = ''
    try:
        get_bin_path('test/test_get_bin_path.sh')
        assert False, 'Expected ValueError'
    except ValueError as ve:
        assert str(ve) == 'Failed to find required executable "test/test_get_bin_path.sh" in paths: '

# Generated at 2022-06-20 16:12:44.837153
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == 'python', 'Failed to get python path'

# Generated at 2022-06-20 16:12:51.672365
# Unit test for function get_bin_path
def test_get_bin_path():
    """This tests the get_bin_path function"""

    paths = ["/bin", "/usr/bin", "/usr/local/bin"]
    binary = "python"

    # Test with python
    python_path = get_bin_path(binary, paths)
    assert python_path

    # Test with non existent binary
    binary = "not_a_real_binary"
    try:
        get_bin_path(binary, paths)
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

# Generated at 2022-06-20 16:13:06.913576
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # create a temp directory
    tmpdir = tempfile.mkdtemp()

    # create two files in temp directory: /tmp/t1 and /tmp/t2
    # chmod /tmp/t1 to be executable
    # chmod /tmp/t2 to be not executable
    tmpfile1 = os.path.join(tmpdir, 't1')
    tmpfile2 = os.path.join(tmpdir, 't2')
    open(tmpfile1, 'w').close()
    open(tmpfile2, 'w').close()
    os.chmod(tmpfile1, 0o755)
    os.chmod(tmpfile2, 0o644)

    # get_bin_path should return /tmp/t1 for 't1'

# Generated at 2022-06-20 16:13:12.838650
# Unit test for function get_bin_path
def test_get_bin_path():
    # Get the name of the shell and assume it is the shell installed on the system
    shell = os.environ.get('SHELL')
    if not shell:
        raise ValueError("Could not determine user's login shell, set SHELL environment variable to test.")
    # Get the name of the shell (i.e. the basename, last component of the path)
    shell_bin = os.path.basename(shell)
    # Verify that get_bin_path returns the full path to the shell
    assert get_bin_path(shell_bin) == shell

# Generated at 2022-06-20 16:13:23.849825
# Unit test for function get_bin_path
def test_get_bin_path():

    def run_test(test):
        global get_bin_path
        if 'required' in test:  # required is deprecated and ignored
            test.pop('required')
        if 'warn' in test:  # warn is deprecated and ignored
            test.pop('warn')
        if 'exception' in test and test['exception']:
            get_bin_path_orig = get_bin_path

            def get_bin_path(a, o, r):
                raise Exception("Test Exception")
            test['exception'] = False
        else:
            get_bin_path_orig = get_bin_path
            def get_bin_path(a, o, r):
                return a
        from ansible.module_utils.common.file import get_bin_path

# Generated at 2022-06-20 16:13:32.217174
# Unit test for function get_bin_path
def test_get_bin_path():
    import mock
    import sys
    import unittest

    class mytest(unittest.TestCase):
        def test_get_bin_path_exception_python2(self):
            with mock.patch('sys.version_info', (2, 7)):
                with self.assertRaises(ValueError):
                    get_bin_path('does_not_exist')
                with self.assertRaises(ValueError):
                    get_bin_path('does_not_exist', required=True)

        def test_get_bin_path_exception_python3(self):
            with mock.patch('sys.version_info', (3, 7)):
                with self.assertRaises(ValueError):
                    get_bin_path('does_not_exist')
                with self.assertRaises(ValueError):
                    get

# Generated at 2022-06-20 16:13:33.009853
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('ls')

# Generated at 2022-06-20 16:13:44.579206
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    import shutil
    import tempfile
    import os
    import stat

    # create temporary directory to test in
    tmpdir = tempfile.mkdtemp()

    # create file in temporary directory
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    os.chmod(tmpfile.name, 0o755)

    # check that get_bin_path throws an exception if it fails to find the file
    with pytest.raises(ValueError):
        get_bin_path('this-does-not-exist')

    # check that get_bin_path can find the file if we provide the directory
    foundfilepath = get_bin_path(os.path.basename(tmpfile.name), opt_dirs=[tmpdir])

# Generated at 2022-06-20 16:13:46.074911
# Unit test for function get_bin_path
def test_get_bin_path():
    assert isinstance(get_bin_path('/bin/sh'), str)



# Generated at 2022-06-20 16:13:57.881321
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.getenv('TRAVIS') == 'true':
        # Skip this test on travis-ci
        return
    assert get_bin_path('bash')
    assert get_bin_path('/bin/bash')
    assert get_bin_path('/bin/bash', opt_dirs=['/bin'])
    assert get_bin_path('/bin/bash', opt_dirs=['/usr/bin'])
    assert get_bin_path('/bin/bash', opt_dirs=['/usr/bin', '/bin'])

    try:
        get_bin_path('command_that_will_never_exist')
    except ValueError:
        pass
    else:
        # This should never happen
        assert False


# Generated at 2022-06-20 16:14:04.828066
# Unit test for function get_bin_path
def test_get_bin_path():
    test_dir = '/tmp/test_get_bin_path'
    os.makedirs(test_dir)
    os.makedirs('%s/bin' % test_dir)
    os.makedirs('%s/sbin' % test_dir)
    os.makedirs('%s/usr/sbin' % test_dir)
    os.makedirs('%s/usr/local/sbin' % test_dir)
    os.makedirs('%s/usr/local/bin' % test_dir)

    test1_bin = '%s/bin/test1' % test_dir
    test2_bin = '%s/sbin/test2' % test_dir
    test3_bin = '%s/usr/sbin/test3' % test_dir
    test4

# Generated at 2022-06-20 16:14:14.386722
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    d1 = tempfile.mkdtemp()
    d2 = tempfile.mkdtemp()

# Generated at 2022-06-20 16:14:30.208923
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    # create temporary directory
    tmp_dir = tempfile.mkdtemp()
    tmp_path = os.path.join(tmp_dir, 'get_bin_path_test')
    open(tmp_path, 'w').close()

# Generated at 2022-06-20 16:14:31.420763
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-20 16:14:43.145048
# Unit test for function get_bin_path
def test_get_bin_path():
    # Assume /bin/bash is on all system
    path = get_bin_path('bash')
    assert path == '/bin/bash'

    # Assume /bin/bash exists, but is not executable
    path = '/bin/bash'
    os.chmod(path, 0o444)
    try:
        get_bin_path(path)
        assert False
    except ValueError as e:
        assert 'Failed to find required executable \"' in str(e)
    finally:
        os.chmod(path, 0o755)

    # Assume /bin/bash is not there
    path = '/bin/bash'
    os.remove(path)

# Generated at 2022-06-20 16:14:53.599090
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    backup_path = os.environ['PATH'] if 'PATH' in os.environ else None

    # Ansible uses common.file.is_executable to prevent command
    # injection, and tests that here.
    with tempfile.NamedTemporaryFile('wb', prefix='ansible-test_get_bin_path-injection', suffix='.sh') as script:
        script.write(b"#!/bin/sh\n")
        script.write(b"echo injected\n")
        script.flush()
        os.chmod(script.name, 0o700)
        os.environ['PATH'] = os.path.dirname(script.name)
