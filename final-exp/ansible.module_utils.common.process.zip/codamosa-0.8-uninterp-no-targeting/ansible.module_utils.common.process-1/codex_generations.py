

# Generated at 2022-06-20 16:04:55.052737
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Test get_bin_path function'''

    # Test PATH
    assert get_bin_path('echo') == '/bin/echo'

    # Test opt_dirs
    assert get_bin_path('echo', ['/bin']) == '/bin/echo'
    assert get_bin_path('echo', ['/usr/bin']) == '/usr/bin/echo'
    assert get_bin_path('echo', ['/sbin']) == '/sbin/echo'
    assert get_bin_path('echo', ['/usr/sbin']) == '/usr/sbin/echo'

    # Test opt_dirs and PATH
    assert get_bin_path('echo', ['/bin', '/usr/bin']) == '/bin/echo'

    # Test PATH and opt_dirs

# Generated at 2022-06-20 16:05:05.399029
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test the get_bin_path function
    '''
    PATH = '/usr/bin:/usr/sbin:/bin:/sbin'

    #
    # Verify that the function returns the first executable it finds in the
    # path.
    #
    os.environ['PATH'] = '/usr/bin/:/bin'
    bin_path = get_bin_path('python')
    assert(bin_path == '/usr/bin/python')

    #
    # Verify that the function raises a ValueError if the executable is not
    # in the path and no optional directories are specified.
    #
    os.environ['PATH'] = '/usr/bin/:/bin'
    try:
        get_bin_path('perl')
        raise Exception('Expected ValueError')
    except ValueError:
        pass

    #

# Generated at 2022-06-20 16:05:10.746714
# Unit test for function get_bin_path
def test_get_bin_path():
    # Valid case: executable exists in PATH
    assert get_bin_path('cat') == '/bin/cat'
    # Valid case: executable exists in PATH
    assert get_bin_path('gzip') == '/bin/gzip'
    # Valid case: executable exists in PATH
    assert get_bin_path('/bin/bash') == '/bin/bash'
    # InValid case: executable does not exists in PATH
    try:
        get_bin_path('caty')
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "caty" in paths: /sbin:/usr/sbin:/usr/local/sbin:/bin:/usr/bin:/usr/local/bin:/root/bin'
    # InValid case: executable does not exists in PATH

# Generated at 2022-06-20 16:05:16.526725
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile

    with tempfile.NamedTemporaryFile() as fd:
        fd.write("#!/bin/sh\nexit 0\n")
        fd.flush()
        os.chmod(fd.name, 0o755)

        paths = [
            fd.name,
        ]

        sys.path.insert(0, fd.name)
        try:
            assert get_bin_path("command_not_found") in paths
        finally:
            sys.path.remove(fd.name)

# Generated at 2022-06-20 16:05:25.117684
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('awk') == '/usr/bin/awk'
    assert get_bin_path('false') == '/usr/bin/false'
    assert get_bin_path('false', opt_dirs=['/usr/bin']) == '/usr/bin/false'
    assert get_bin_path('true') == '/usr/bin/true'
    assert get_bin_path('true', opt_dirs=['/usr/bin']) == '/usr/bin/true'
    assert get_bin_path('true', opt_dirs=['/usr/bin', '/usr/bin']) == '/usr/bin/true'

    try:
        get_bin_path('nonexist')
        assert False
    except ValueError:
        pass


# Generated at 2022-06-20 16:05:32.962358
# Unit test for function get_bin_path
def test_get_bin_path():
    testargs = ['ls', 'ansible-playbook']

    # test with no additional dirs
    for arg in testargs:
        bin_path = get_bin_path(arg)
        assert os.path.exists(bin_path)

    # test with additional dirs
    for arg in testargs:
        bin_path = get_bin_path(arg, opt_dirs=[os.path.dirname(bin_path)])
        assert os.path.exists(bin_path)

# Generated at 2022-06-20 16:05:43.884627
# Unit test for function get_bin_path

# Generated at 2022-06-20 16:05:52.129333
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    bin_path = '/usr/bin/sh'
    arg = os.path.basename(bin_path)

    # 1. Verify path is found when it exists in PATH
    assert get_bin_path(arg) == bin_path

    # 2. Verify additional directories to search are handled
    tmp_dir = tempfile.gettempdir()
    assert get_bin_path(arg, opt_dirs=tmp_dir) == bin_path

    # 3. Verify that ValueError is raised if path does not exist
    try:
        get_bin_path(arg + '.xyz')
        assert False, 'ValueError expected'
    except ValueError:
        pass

    # 4. Verify that ValueError is raised if directory is passed instead of a file

# Generated at 2022-06-20 16:06:02.070876
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('nonexistent_file')
        assert False, "get_bin_path should raise an exception if the executable cannot be found"
    except ValueError as e:
        assert 'Failed to find required executable' in str(e), \
            "Exception message should contain the string 'Failed to find required executable'"

    expected_path = '/bin/ls'
    found_path = get_bin_path('ls')
    assert expected_path in found_path, "get_bin_path should find ls in the search path"

    found_path = get_bin_path('ls', opt_dirs=['/bin'])
    assert expected_path in found_path, "get_bin_path should find ls in the optional search path"


# Generated at 2022-06-20 16:06:08.998573
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('ls')
    assert '/bin/ls' == bin_path
    try:
        get_bin_path('foo')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    bin_path = get_bin_path('ls', opt_dirs=['/usr/bin'])
    assert '/usr/bin/ls' == bin_path

# Generated at 2022-06-20 16:06:21.904901
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()
    orig_path = os.environ.get('PATH')
    os.environ['PATH'] = tmpdir

    # create an executable file in the temporary directory
    tmpexe = os.path.join(tmpdir, 'tmpexe') 
    with open(tmpexe, 'wt') as fd:
        fd.write('#!/bin/sh\necho $@\n')
    os.chmod(tmpexe, 0o755)

    # test 1: find our executable
    path = get_bin_path('tmpexe')
    assert path == tmpexe

    # test 2: failure due to missing executable

# Generated at 2022-06-20 16:06:23.632386
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'



# Generated at 2022-06-20 16:06:27.624299
# Unit test for function get_bin_path
def test_get_bin_path():
    binpath = get_bin_path('no_such_exe_in_path')
    assert False, 'should not reach here'


# Generated at 2022-06-20 16:06:32.155224
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert get_bin_path('ls') == '/bin/ls'
    except ValueError:
        assert get_bin_path('ls') == '/usr/bin/ls'
    try:
        assert get_bin_path('awk') == '/usr/bin/awk'
    except ValueError:
        assert get_bin_path('awk') == '/usr/bin/awk'

# Generated at 2022-06-20 16:06:39.773414
# Unit test for function get_bin_path
def test_get_bin_path():
    sbin_path = '/sbin'
    bin_path = '/bin'
    paths = [sbin_path, '/usr/sbin', '/usr/local/sbin']

    root_bin_path = get_bin_path('ls')
    assert root_bin_path

    # test for root in PATH
    for p in paths:
        if p not in os.environ['PATH'].split(os.pathsep):
            assert os.path.exists(p)
            assert not os.path.isdir(p)
            assert not is_executable(p)
            assert os.path.exists(os.path.join(p, 'ls'))
            assert not os.path.isdir(os.path.join(p, 'ls'))

# Generated at 2022-06-20 16:06:48.428989
# Unit test for function get_bin_path
def test_get_bin_path():
    # first test if the function raises an exception if binary is not found
    try:
        get_bin_path("nonexistent-binary", required=True)
    except ValueError as e:
        assert "Failed to find required executable" in str(e)
    else:
        raise Exception("Test failed")

    # then test if the function finds executables in the standard paths
    for bin in ["ls", "python", "grep", "ssh", "env", "which", "uname", "file"]:
        assert get_bin_path(bin) is not None

    # test if the function raises when passed an empty argument
    try:
        get_bin_path("")
    except ValueError as e:
        assert "Failed to find required executable" in str(e)
    else:
        raise Exception("Test failed")

    #

# Generated at 2022-06-20 16:06:51.392171
# Unit test for function get_bin_path
def test_get_bin_path():
    from io import StringIO
    required_exe = 'ls'
    exe_path = get_bin_path(required_exe)
    assert os.path.normpath(exe_path) == os.path.normpath('/bin/ls')


# Generated at 2022-06-20 16:06:56.182639
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function
    '''
    # This call should succeed
    try:
        assert get_bin_path("echo")
    except ValueError:
        assert False

    # This call should fail
    try:
        assert get_bin_path("not_a_good_path")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-20 16:07:02.081521
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    try:
        os.environ['PATH'] = test_dir
        with open(os.path.join(test_dir, 'foo'), 'w') as foo:
            foo.write('#!/bin/sh\nexit 0')
        os.chmod(os.path.join(test_dir, 'foo'), 0o755)
        assert get_bin_path('foo') == os.path.join(test_dir, 'foo')
    finally:
        shutil.rmtree(test_dir)

# Generated at 2022-06-20 16:07:08.682756
# Unit test for function get_bin_path
def test_get_bin_path():
    with open("test_get_bin_path.py", "w") as fd:
        fd.write("#!/usr/bin/env python\nprint('Hello world')")
    os.chmod("test_get_bin_path.py", 0o755)
    os.chdir(os.path.dirname(__file__))
    path = get_bin_path("test_get_bin_path.py", None, None)
    assert path == os.path.join(os.path.dirname(__file__), "test_get_bin_path.py")
    assert path == os.path.join(os.path.dirname(__file__), "test_get_bin_path.py")
    os.unlink("test_get_bin_path.py")

# Generated at 2022-06-20 16:07:13.131399
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('ls')
    assert os.path.exists(path)
    assert not os.path.isdir(path)
    assert is_executable(path)

    path = get_bin_path('cat', required=False)
    assert os.path.exists(path)
    assert not os.path.isdir(path)
    assert is_executable(path)

# Generated at 2022-06-20 16:07:23.651027
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('command_non_exists_in_os', required=True)
        assert(False)  # non-existing command should not success
    except ValueError:
        pass

    try:
        get_bin_path('command_non_exists_in_os')
        assert(False)  # non-existing command should not success
    except ValueError:
        pass

    try:
        bin_path = get_bin_path('python', ['/usr/local/bin'])
        assert(bin_path == '/usr/local/bin/python')
    except ValueError:
        pass

    try:
        bin_path = get_bin_path('python')
        assert(bin_path == 'python')
    except ValueError:
        pass

    import sys

# Generated at 2022-06-20 16:07:25.385296
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('sh')

# Generated at 2022-06-20 16:07:29.051413
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('cat', ['/usr/bin', '/usr/sbin']) == '/usr/bin/cat'
    assert get_bin_path('fake-command') == '/bin/fake-command'

# Generated at 2022-06-20 16:07:35.726682
# Unit test for function get_bin_path
def test_get_bin_path():
    existing_binary = 'ls'  # this exists on all supported platforms
    non_existing_binary = 'this_binary_does_not_exist'
    existing_dir = '/'     # this exists on all supported platforms
    opt_dirs = ['/bin', '/sbin', existing_dir]
    # Set this to true when we want to see the ouput of the command executed
    do_print = False
    import subprocess

    # Check when the binary exists

# Generated at 2022-06-20 16:07:42.719747
# Unit test for function get_bin_path
def test_get_bin_path():
    abs_path = get_bin_path('ansible')
    with open("/proc/self/cmdline", "r") as cmdline:
        raw_value = cmdline.read()
    read_value = raw_value.replace("\x00", " ")
    assert abs_path in read_value, "Failed to find ansible in /proc/self/cmdline"
    assert os.access(abs_path, os.X_OK), "Executable is not executable"
    assert not os.path.isdir(abs_path), "Executable should not be a directory"

# Generated at 2022-06-20 16:07:53.056871
# Unit test for function get_bin_path
def test_get_bin_path():
    # Create temp file
    import tempfile
    tmp_fd, tmp_file = tempfile.mkstemp()
    tmp_file = os.path.abspath(tmp_file)
    os.write(tmp_fd, "#!/bin/bash\necho ok\n")
    os.close(tmp_fd)

    # Make it executable
    import stat
    os.chmod(tmp_file, stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)

    # Test it and delete it
    assert get_bin_path(tmp_file)
    os.unlink(tmp_file)

# Generated at 2022-06-20 16:07:56.811507
# Unit test for function get_bin_path
def test_get_bin_path():
    bin = get_bin_path("sh")
    try:
        get_bin_path("invalid")
        raise Exception("Unexpected success")
    except ValueError:
        pass
    assert is_executable(bin)

# Generated at 2022-06-20 16:08:06.816320
# Unit test for function get_bin_path
def test_get_bin_path():
    import doctest
    from ansible.module_utils.common.file import is_executable

    my_exe_name = 'ansible-test-non-existent-executable-for-test'

    try:
        get_bin_path(my_exe_name)
        assert False, 'should have raised an exception'
    except ValueError as e:
        assert my_exe_name in str(e)

    import tempfile
    python = get_bin_path('python')
    my_exe = os.path.join(tempfile.gettempdir(), my_exe_name)

    with open(my_exe, 'w') as f:
        f.write('#!/bin/sh\n')
        f.write('echo hello\n')

    os.chmod(my_exe, 0o700)

    assert get

# Generated at 2022-06-20 16:08:12.761527
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test that the function can find an executable in the path
    found = False
    try:
        get_bin_path('awk')
        found = True
    except ValueError:
        pass
    assert found

    # Test that the function can find an executable in an opt_dirs
    found = False
    opt_dirs = ['/usr/bin']
    try:
        get_bin_path('grep', opt_dirs=opt_dirs)
        found = True
    except ValueError:
        pass
    assert found

    # Test that the function raises a ValueError when executable is not found
    caught = False
    try:
        get_bin_path('foo')
    except ValueError:
        caught = True
    assert caught

    # Test that the function can find an executable in a provided list of directories

# Generated at 2022-06-20 16:08:24.017400
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    ansible.module_utils.basic.get_bin_path
    '''

    # Test for not found
    try:
        get_bin_path("/bin/false")
    except ValueError:
        pass
    except Exception as e:
        assert False, 'Unexpected exception raised: {0}'.format(e)
    else:
        assert False, 'ExpectedException not raised'

    # Check the first one found
    path = get_bin_path("/bin/true", opt_dirs=['/bin', '/usr/bin'])
    assert path == "/bin/true", 'Incorrect path returned: {0}'.format(path)

# Generated at 2022-06-20 16:08:31.151814
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('doesnotexist')
    except ValueError as err:
        assert 'doesnotexist' in str(err)
    else:
        assert False, 'expected exception'
    try:
        get_bin_path('bash', opt_dirs=['/bin'])
    except ValueError as err:
        assert 'bash' in str(err)
    else:
        assert False, 'expected exception'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'

# Generated at 2022-06-20 16:08:41.937204
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    kwargs = {
        'arg': 'test_get_bin_path_executable',
        'opt_dirs': None
    }

# Generated at 2022-06-20 16:08:49.293409
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('this-should-not-exist')
    except ValueError:
        pass
    else:
        raise Exception("Failed to throw ValueError for a bad executable name")

    try:
        get_bin_path('sh')
    except ValueError:
        raise Exception("Failed to find sh executable")

    try:
        get_bin_path('python')
    except ValueError:
        raise Exception("Failed to find python executable")

    try:
        get_bin_path('make')
    except ValueError:
        raise Exception("Failed to find make executable")

    try:
        get_bin_path('ls')
    except ValueError:
        raise Exception("Failed to find ls executable")


# Generated at 2022-06-20 16:08:56.748082
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python3', ['/bin']) == '/bin/python3'
    assert get_bin_path('python3', ['/bin', '/usr/bin', '/usr/local/bin']) == '/usr/bin/python3'
    assert get_bin_path('python3', required=True) == '/usr/bin/python3'
    try:
        get_bin_path('python3', required=False)
    except ValueError:
        assert False
    try:
        get_bin_path('python4')
    except ValueError:
        assert True



# Generated at 2022-06-20 16:09:03.298119
# Unit test for function get_bin_path
def test_get_bin_path():
    # test an existing bin in the path
    assert get_bin_path('/bin/ls') == '/bin/ls'

    # test an existing bin not in the path
    assert get_bin_path('/bin/ls', opt_dirs=['/bin']) == '/bin/ls'

    # test a fake bin not in the path
    try:
        get_bin_path('/bin/NotHere')
        assert False
    except ValueError:
        assert True

    # test a fake bin not in the path but with a fake path
    try:
        get_bin_path('/bin/NotHere', opt_dirs=['/bin'])
        assert False
    except ValueError:
        assert True

    # test a directory not in the path

# Generated at 2022-06-20 16:09:07.809642
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    # Test searching additional directories
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'
    try:
        get_bin_path('this-executable-does-not-exist')
        assert False
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    try:
        get_bin_path('this-executable-does-not-exist', required=False)
        assert False
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

# Generated at 2022-06-20 16:09:15.285407
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('/usr/bin/python') == '/usr/bin/python'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('sh', ['/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/no/such/dir'], required=False) is None
    assert get_bin_path('/no/such/dir') is None

# Generated at 2022-06-20 16:09:19.869124
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls', ['/bin']) == '/bin/ls'
    assert get_bin_path('ls', ['/bin'], ['/bin']) == '/bin/ls'

# Generated at 2022-06-20 16:09:24.006530
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    This test only runs when run as a unit test.
    """
    import sys

    if not hasattr(sys, 'ps1'):
        # Run only when called as a unit test (not in CLI)
        assert get_bin_path('false') == '/bin/false'

# Generated at 2022-06-20 16:09:32.365947
# Unit test for function get_bin_path
def test_get_bin_path():
    '/usr/bin' == get_bin_path('python')

# Generated at 2022-06-20 16:09:33.813467
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('does-not-exist')
    except ValueError as e:
        assert 'Failed to find required executable "does-not-exist" in paths' in str(e)

# Generated at 2022-06-20 16:09:42.978801
# Unit test for function get_bin_path
def test_get_bin_path():
    # assert that it fails with a ValueError if /bin/sh is not in PATH
    # a little tricky since it could fail at the os.path.exists() call
    try:
        get_bin_path('sh', ['/bin'])
    except ValueError as e:
        assert 'Failed to find required executable "sh"' in str(e)
    else:
        assert False, 'get_bin_path should have failed looking for /bin/sh'
    # assert that it returns /bin/sh if /bin is in PATH
    assert get_bin_path('sh', ['/bin']) == '/bin/sh'

# Generated at 2022-06-20 16:09:49.687947
# Unit test for function get_bin_path
def test_get_bin_path():
    import nose
    import tempfile

    temp_dir = tempfile.mkdtemp()
    test_file = os.path.join(temp_dir, 'test_file')
    with open(test_file, 'w') as fp:
        fp.write("#!/bin/bash")
    os.chmod(test_file, 0o755)

    assert get_bin_path("bash")
    assert get_bin_path("bash", [temp_dir]) == test_file
    assert get_bin_path("test_file", [temp_dir]) == test_file


# Generated at 2022-06-20 16:09:52.949825
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    # Test searching on additional dirs
    assert get_bin_path('sh', ['/sbin']) == '/sbin/sh'
    # Test that additional dirs are searched first
    assert get_bin_path('sh', ['/sbin', '/bin']) == '/sbin/sh'

# Generated at 2022-06-20 16:10:03.195059
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('exists', opt_dirs=['/usr/bin']) == '/usr/bin/exists'
    assert get_bin_path('/usr/bin/exists') == '/usr/bin/exists'
    assert get_bin_path('/bin/exists', opt_dirs=['/usr/bin']) == '/bin/exists'
    assert get_bin_path('exists', opt_dirs=['/usr/bin'], required=True) == '/usr/bin/exists'
    assert get_bin_path('/usr/bin/exists', required=True) == '/usr/bin/exists'
    assert get_bin_path('/bin/exists', opt_dirs=['/usr/bin'], required=True) == '/bin/exists'
   

# Generated at 2022-06-20 16:10:12.598382
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.path.exists('/bin/ls'):
        assert get_bin_path('ls') == '/bin/ls'
    if os.path.exists('/usr/bin/python'):
        assert get_bin_path('python') == '/usr/bin/python'
    if os.path.exists('/usr/bin/python'):
        assert get_bin_path('python', opt_dirs=['/usr/bin/']) == '/usr/bin/python'
    if os.path.exists('/usr/local/bin/python'):
        assert get_bin_path('python', opt_dirs=['/usr/local/bin/']) == '/usr/local/bin/python'
    if os.path.exists('/usr/bin/python'):
        assert get_bin

# Generated at 2022-06-20 16:10:22.665837
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile

    # Make temporary directory and add it to the PATH.
    tmpdir = tempfile.mkdtemp()
    os.environ['PATH'] += os.pathsep + tmpdir

    # On macOS, python is usually a symlink to the actual binary.  Get the actual binary name.
    python_binary = sys.executable.split('/')[-1]

    # Create and place a small executable into the temporary directory.
    executable_filename = 'test_executable'
    executable_path = '%s/%s' % (tmpdir, executable_filename)
    with open(executable_path, 'w') as f:
        f.write('#!/bin/sh\necho Hello from %s' % executable_filename)
    os.chmod(executable_path, 0o755)

# Generated at 2022-06-20 16:10:23.938069
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-20 16:10:33.530239
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import platform
    import stat

    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-20 16:10:44.513431
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        dirs = ['/bin', '/usr/bin']
        get_bin_path('ls', dirs)
    except ValueError:
        assert False, 'Failed to find executable: ls'

# Generated at 2022-06-20 16:10:46.768501
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('ls')
    assert path == '/bin/ls' or path == '/usr/bin/ls', 'path = %s does not match expected /bin/ls or /usr/bin/ls' % path

# Generated at 2022-06-20 16:10:52.662709
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    import shutil
    import filecmp


# Generated at 2022-06-20 16:10:58.335158
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('ls')
    except ValueError as exp:
        assert False, 'Failed to found executable'
    assert get_bin_path('ls') == '/bin/ls'

__all__ = [
    'get_bin_path',
]

# Generated at 2022-06-20 16:11:04.043223
# Unit test for function get_bin_path
def test_get_bin_path():
    import random
    import string
    import tempfile

    def random_string(length):
        return ''.join(random.choice(string.ascii_letters) for i in range(length))

    # Create a temporary directory.
    tempdir = tempfile.mkdtemp()

    # Create a random filename in the temporary directory.
    filename = random_string(10)

    # Create an empty file in the temporary directory with the random name.
    open(os.path.join(tempdir, filename), 'a').close()

    # The file we just created should be found.
    assert get_bin_path(filename, [tempdir]) == os.path.join(tempdir, filename)

    # An arbitrary filename should not be found.

# Generated at 2022-06-20 16:11:12.254517
# Unit test for function get_bin_path

# Generated at 2022-06-20 16:11:19.675100
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('bogus', ['/bin']) == '/bin/bogus'
    assert get_bin_path('bogus', ['/bin', '/sbin']) == '/sbin/bogus'

    try:
        get_bin_path('bogus', ['/bin', '/sbin'], required=True) == '/sbin/bogus'
        assert(False)
    except ValueError:
        assert(True)

# Generated at 2022-06-20 16:11:31.417674
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import shutil
    import tempfile

    def mktmpfile(content, mode="r+"):
        f, filename = tempfile.mkstemp()
        f = open(filename, mode)
        f.write(content)
        f.close()
        return filename

    def rmtempfile(filename):
        try:
            os.remove(filename)
        except OSError as e:
            raise Exception("Failed to remove temp file %s: %s" % (filename, e))

    def mktmpdir():
        d = tempfile.mkdtemp()
        return d


# Generated at 2022-06-20 16:11:42.200517
# Unit test for function get_bin_path
def test_get_bin_path():
    import nose
    import tempfile
    import shutil
    from ansible.module_utils.common.file import remove_tmp_from_args, tmp_path_join

    currdir = os.getcwd()
    tempdir = tempfile.mkdtemp()
    os.chdir(tempdir)

    def check_found(path):
        if not os.path.isdir(path):
            nose.tools.assert_true(os.path.exists(path))
            nose.tools.assert_true(os.path.isfile(path))
            nose.tools.assert_true(os.access(path, os.X_OK))
        else:
            nose.tools.assert_false(os.path.exists(path))

    def check_not_found(path):
        nose.tools.assert_false

# Generated at 2022-06-20 16:11:54.117714
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Unit test for function get_bin_path in module_utils. '''
    # test for required argument
    try:
        get_bin_path(None)
        raise Exception('get_bin_path does not handle None arg')
    except ValueError:
        pass

    # test for unknown cmd
    try:
        get_bin_path('unknown_cmd')
        raise Exception('get_bin_path does not handle unknown cmd')
    except ValueError:
        pass

    # test for cmd in $PATH
    if get_bin_path('ls') != '/bin/ls':
        raise Exception('get_bin_path does not handle cmd in $PATH')

    # test for /sbin

# Generated at 2022-06-20 16:12:14.086895
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/ls', opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('/bin/ls', opt_dirs=['/usr/bin', '/bin']) == '/bin/ls'
    assert get_bin_path('/bin/ls', opt_dirs=[]) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=[]) == '/bin/ls'


# Generated at 2022-06-20 16:12:18.091139
# Unit test for function get_bin_path
def test_get_bin_path():
  import sys
  try:
    get_bin_path("invalid_executable")
  except ValueError as exc:
    assert("Failed to find required executable 'invalid_executable' in paths" in exc.args[0])

# Generated at 2022-06-20 16:12:29.711972
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == get_bin_path('python', [])
    assert get_bin_path('python2') == get_bin_path('python2', [])
    assert get_bin_path('python3') == get_bin_path('python3', [])

    # Test using function inside of module as opposed to importing
    import os.path
    import __main__
    bin_path = os.path.join(os.path.split(__main__.__file__)[0], 'bin')
    assert get_bin_path('notepad') == os.path.join(bin_path, 'notepad')

    assert get_bin_path('does_not_exist', required=False) != get_bin_path('does_not_exist', [], None)

# Generated at 2022-06-20 16:12:35.229680
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import StringIO

    from ansible.compat.tests import unittest

    import sys
    import tempfile

    class UnitTestGetBin(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = tempfile.NamedTemporaryFile(mode='r+', dir=self.temp_dir, prefix="binary_")

        def tearDown(self):
            if os.path.isdir(self.temp_dir):
                os.rmdir(self.temp_dir)
            if os.path.isfile(self.temp_file.name):
                os.remove(self.temp_file.name)


# Generated at 2022-06-20 16:12:44.696753
# Unit test for function get_bin_path
def test_get_bin_path():

    import tempfile

    # Create a temp dir
    tmpdir = tempfile.mkdtemp()
    tmpdir_bin = os.path.join(tmpdir, 'bin')

    # Make sure get_bin_path fails when no executable
    try:
        get_bin_path('no_such_exe')
        assert(False)
    except ValueError as e:
        assert('Failed to find required executable' in str(e))

    # Create a directory and add it to PATH
    os.mkdir(tmpdir_bin)
    os.environ['PATH'] = '%s:%s' % (os.environ['PATH'], tmpdir_bin)

    # Create a temp file and make it executable
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir_bin)
    os.chmod

# Generated at 2022-06-20 16:12:51.506769
# Unit test for function get_bin_path
def test_get_bin_path():
    # Make sure that a ValueError exception is raised when the cmd is not found
    try:
        get_bin_path('i-do-not-exist')
    except ValueError:
        pass

    # Check that /sbin is searched if the cmd is found in /sbin
    assert '/sbin/ip' == get_bin_path('ip')

    # Check if the third optional argument is working as expected
    assert '/sbin/iptables' == get_bin_path('iptables', ['/sbin', '/usr/sbin'])

# Generated at 2022-06-20 16:12:57.044208
# Unit test for function get_bin_path
def test_get_bin_path():
    # Some values come from a 'tox -e venv -- notest' environment
    if os.path.exists('/bin/sh'):
        assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', ['.', '..']) == '/usr/bin/python'
    try:
        get_bin_path('does-not-exist')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-20 16:13:06.947672
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    def do_test(path, result):
        orig_path = os.environ.get('PATH')
        try:
            os.environ['PATH'] = path
            assert result == get_bin_path('ls', opt_dirs=['/bin', '/usr/bin'])
        finally:
            if orig_path:
                os.environ['PATH'] = orig_path
            else:
                del os.environ['PATH']

    if sys.platform == 'win32':
        do_test(path='c:\\windows\\system32', result='c:\\windows\\system32\\ls')
    else:
        do_test(path='/bin:/usr/bin', result='/bin/ls')
        do_test(path='/bin:/usr/bin', result='/bin/ls')
       

# Generated at 2022-06-20 16:13:15.005429
# Unit test for function get_bin_path
def test_get_bin_path():
    # mock os.path.exists(path)
    orig_exists = os.path.exists
    os.path.exists = lambda path: True

    # mock is_executable()
    orig_executable = is_executable
    is_executable = lambda path: True

    # mock os.environ.get('PATH')
    orig_path = os.environ.get('PATH')
    os.environ['PATH'] = '/usr/bin/'

    # Test that sbin directories are in path
    sbin_paths = ['/sbin', '/usr/sbin', '/usr/local/sbin']
    bin_path = get_bin_path('foo')
    sbin_found = False
    sbin_msg = "Expected one of %s to be in PATH" % sbin_paths


# Generated at 2022-06-20 16:13:24.698288
# Unit test for function get_bin_path
def test_get_bin_path():
    # try to find a nonexistent binary
    nonexistent_bin = "/__non_existent_bin__"
    try:
        bin_path = get_bin_path(nonexistent_bin)
        raise AssertionError("get_bin_path did not fail trying to locate non existent executable " + nonexistent_bin)
    except ValueError:
        pass

    # try to find a binary in non existent directory
    try:
        bin_path = get_bin_path("/bin/ls", opt_dirs=["/__non_existent_dir__"])
        raise AssertionError("get_bin_path did not fail trying to locate executable ls in non existent directory /__non_existent_dir__")
    except ValueError:
        pass

    # test bin_path

# Generated at 2022-06-20 16:13:36.992219
# Unit test for function get_bin_path
def test_get_bin_path():
    # call get_bin_path with minimal args
    try:
        get_bin_path('true')
    except ValueError:
        # test failed
        return False
    # test passed
    return True

# Generated at 2022-06-20 16:13:41.024834
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert bin_path.startswith('/')

if __name__ == '__main__':
    test_get_bin_path()
    print('ok')

# Generated at 2022-06-20 16:13:52.133887
# Unit test for function get_bin_path
def test_get_bin_path():
    from shutil import which

    my_which = '/tmp/my_which'
    which_path = which('which')
    my_fake_bin = '/tmp/my-fake-bin'

    if which_path is None:
        raise AssertionError("'which' command not found")

    if not os.path.exists(which_path):
        raise AssertionError("'which' command not found at path %s" % which_path)

    with open(my_which, 'w') as f:
        f.write("#!/bin/sh\n%s \"$1\"\n" % which_path)

    os.chmod(my_which, 0o755)
    os.environ['PATH'] = os.pathsep.join(['/tmp', '/usr/bin'])


# Generated at 2022-06-20 16:14:00.885139
# Unit test for function get_bin_path
def test_get_bin_path():
    def test_paths_arg(argname, argvalue):
        path = get_bin_path('ls', argvalue)
        assert os.path.exists(path)
        assert os.path.isfile(path)
        assert is_executable(path)

    test_paths_arg('None', None)
    test_paths_arg('[]', [])
    test_paths_arg('[None]', [None])
    test_paths_arg('[""]', [''])
    test_paths_arg('["/bin"]', ['/bin'])
    test_paths_arg('["/tmp"]', ['/tmp'])
    test_paths_arg('["/tmp", ""]', ['/tmp', ''])

# Generated at 2022-06-20 16:14:07.196139
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python')
    try:
        get_bin_path('spurious_executable')
        assert False
    except ValueError:
        pass
    try:
        get_bin_path('spurious_executable', required=False)
        assert False
    except ValueError:
        pass
    assert get_bin_path('spurious_executable', opt_dirs=['/']) == '/spurious_executable'

# Generated at 2022-06-20 16:14:12.880074
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        bin_path = get_bin_path('some-bogus-executable')
        assert E
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
        assert 'in paths' in str(e)
    try:
        bin_path = get_bin_path('python')
        assert bin_path
        if bin_path and os.pathsep in bin_path:
            assert False
    except:
        assert False

# Generated at 2022-06-20 16:14:17.495280
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Test get_bin_path() with PATH set to a custom dir
    """
    try:
        os.environ['PATH'] = '/sbin'
        assert get_bin_path('ip') == '/sbin/ip'
    finally:
        del os.environ['PATH']

# Generated at 2022-06-20 16:14:18.720386
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-20 16:14:21.339524
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path("cat")
    except ValueError as e:
        if "No such file or directory" in str(e):
            raise AssertionError("Executable 'cat' not found in paths.")

# Generated at 2022-06-20 16:14:32.500336
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert os.path.exists(bin_path)
    assert os.path.isfile(bin_path)
    assert is_executable(bin_path)

    # Add optional directories to the search list
    fake_dir = '/not/exist/dir'
    fake_bin = 'not_exist_bin'
    bin_path = get_bin_path(fake_bin, opt_dirs=[fake_dir])
    assert bin_path != fake_dir
    assert bin_path is not None

    # Raise ValueError for not exist exeutable
    try:
        get_bin_path(fake_bin)
    except ValueError as e:
        assert 'Failed to find required executable "%s"' % fake_bin in str(e)

    # (Deprecated) Use

# Generated at 2022-06-20 16:14:52.914973
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python')
    assert get_bin_path('python', ['/usr/local/bin'])
    assert get_bin_path('python', ['/usr/local/bin', '/usr/local/sbin'])
    assert get_bin_path('python', opt_dirs=['/usr/local/bin', '/usr/local/sbin'])
    assert get_bin_path('/usr/bin/python')
    try:
        get_bin_path('no_such_python_interpreter')
        assert False, 'expected ValueError above'
    except ValueError:
        pass