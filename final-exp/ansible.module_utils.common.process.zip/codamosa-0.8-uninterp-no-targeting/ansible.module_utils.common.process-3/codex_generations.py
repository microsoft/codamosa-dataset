

# Generated at 2022-06-20 16:04:55.813018
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    try:
        get_bin_path('foobar')
        assert 0, 'get_bin_path: did not error out trying to find foobar'
    except ValueError:
        pass

# Generated at 2022-06-20 16:05:05.541213
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/nonexistentpath')
        assert False
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "/nonexistentpath" in paths: '
    try:
        get_bin_path('/bin')
        assert False
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "/bin" in paths: '
    try:
        get_bin_path('/bin/ls')
        assert False
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "/bin/ls" in paths: '
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-20 16:05:10.877555
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path with different inputs
    '''
    import sys

    # No tests on windows
    if sys.platform.startswith('win'):
        return

    # Check ValueError is raised if no command is given
    from py.test import raises
    raises(ValueError, get_bin_path, '', required=False)
    raises(ValueError, get_bin_path, None, required=False)

    # Check ValueError is raised if command not in path
    raises(ValueError, get_bin_path, 'some-bogus', required=False)

    # Check command in path is returned if executable
    assert get_bin_path('cat', required=False) == '/bin/cat'
    # Check command in path is returned if executable

# Generated at 2022-06-20 16:05:14.952741
# Unit test for function get_bin_path
def test_get_bin_path():
    # Success
    assert get_bin_path('git') is not None
    # Failure
    try:
        get_bin_path('some_unknown_executable')
        assert False, "Expected exception for unknown executable"
    except ValueError as e:
        assert e.args[0].startswith("Failed to find required executable")

# Generated at 2022-06-20 16:05:23.460680
# Unit test for function get_bin_path
def test_get_bin_path():
    # When searching for a command in path, find it and return full path
    assert get_bin_path('ls') == '/bin/ls'

    with pytest.raises(ValueError):
        get_bin_path('no_such_cmd')
    with pytest.raises(ValueError):
        get_bin_path('no_such_cmd', required=True)
    with pytest.raises(ValueError):
        get_bin_path('ls', opt_dirs=['/non_existent_path'])

# Generated at 2022-06-20 16:05:35.091628
# Unit test for function get_bin_path
def test_get_bin_path():
    test_path = os.path.realpath(__file__)
    test_dir = os.path.dirname(test_path)
    test_file = os.path.basename(test_path)
    test_name = os.path.splitext(test_file)[0]

    # function should return path at which it finds executable
    assert get_bin_path(test_name, [test_dir]) == test_path
    # function should raise ValueError if executable is not found

# Generated at 2022-06-20 16:05:44.465078
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Test function get_bin_path in module_utils.basic. '''

    if os.path.exists('/bin/sh'):
        assert get_bin_path('sh') == '/bin/sh'

    if os.path.exists('/bin/sh'):
        assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'

    if os.path.exists('/bin/sh') and os.path.exists('/usr/share'):
        assert get_bin_path('sh', opt_dirs=['/usr/share']) == '/bin/sh'

# Generated at 2022-06-20 16:05:46.394726
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sed') == '/bin/sed'
    assert get_bin_path('mount') == '/bin/mount'

# Generated at 2022-06-20 16:05:51.777209
# Unit test for function get_bin_path
def test_get_bin_path():
    # pylint: disable=redefined-outer-name
    try:
        get_bin_path('no_such_executable')
        assert False, "Exception not raised"
    except ValueError as e:
        assert 'no_such_executable' in str(e)
        assert 'some_dir' in str(e)
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/some_dir']) == '/bin/sh'

# Generated at 2022-06-20 16:06:02.553371
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    # setup temp dirs for test
    ansible_base = tempfile.mkdtemp()
    opt_base = tempfile.mkdtemp()

    # create a fake executable for the test
    ansible_test_exec = os.path.join(ansible_base, 'ansible-get-bin-path-test')
    open(ansible_test_exec, 'w').close()
    os.chmod(ansible_test_exec, stat.S_IRWXU)

    # create a fake executable outside the added paths
    other_test_exec = os.path.join(os.path.sep, 'ansible-get-bin-path-test')
    open(other_test_exec, 'w').close()

# Generated at 2022-06-20 16:06:14.055004
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', ['/usr/sbin']) == '/usr/bin/python'
    assert get_bin_path('python', ['/nonexisting']) == '/usr/bin/python'
    assert get_bin_path('python', ['/usr/sbin', '/nonexisting']) == '/usr/bin/python'
    try:
        get_bin_path('not-existing-cmd')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-20 16:06:19.537933
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test to make sure get_bin_path will return the correct path or raise the correct exception
    '''
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('not_a_command') == ValueError

# Generated at 2022-06-20 16:06:26.859688
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    paths = []
    dirs = ["/bin", "/usr/bin", "/sbin", "/usr/sbin"]
    tmpdir = tempfile.mkdtemp()
    test_execs = ["ls", "awk", "grep", "ssh"]


# Generated at 2022-06-20 16:06:31.228551
# Unit test for function get_bin_path
def test_get_bin_path():
    # We can't test this 100% on all platforms but we can get close
    path = get_bin_path('python')
    assert path is not None
    assert os.path.exists(path)
    assert is_executable(path)

# Generated at 2022-06-20 16:06:42.318857
# Unit test for function get_bin_path
def test_get_bin_path():
    # Set up PATH environment variable
    os.environ['PATH'] = '/usr/bin:/usr/sbin:/bin:/sbin'
    # Executable is found in default path
    assert get_bin_path('ls') == '/bin/ls'
    # Executable is found in opt_dirs
    assert get_bin_path('sudo', opt_dirs=['/usr/local/bin']) == '/usr/local/bin/sudo'
    # Executable is not found anywhere
    try:
        get_bin_path('do-not-exist')
        assert False
    except ValueError as e:
        expected_msg = 'Failed to find required executable "do-not-exist" in paths: /usr/bin:/usr/sbin:/bin:/sbin'
        assert str(e) == expected_msg

# Generated at 2022-06-20 16:06:50.306652
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('non-executable-path', required=False)
    except:
        pass
    else:
        assert False, 'get_bin_path() did not raise exception for non-executable-path'
    try:
        get_bin_path('non-executable-path')
    except:
        pass
    else:
        assert False, 'get_bin_path() did not raise exception for non-executable-path'
    try:
        get_bin_path('non-existent-path', required=False)
    except:
        pass
    else:
        assert False, 'get_bin_path() did not raise exception for non-existent-path'
    try:
        get_bin_path('non-existent-path')
    except:
        pass

# Generated at 2022-06-20 16:06:59.217549
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['', '/bin', '/usr/bin', '/sbin', '/usr/sbin', '/usr/local/sbin']
    # Insert a few valid paths into the environment to test
    new_environ = {'PATH': os.pathsep.join(paths)}
    for e in ('SHELL', 'PYTHONPATH', 'LD_LIBRARY_PATH'):
        if e in os.environ:
            new_environ[e] = os.environ[e]
    os.environ.clear()
    os.environ.update(new_environ)
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('nonsense') == '/bin/nonsense'

# Generated at 2022-06-20 16:07:06.275155
# Unit test for function get_bin_path
def test_get_bin_path():
    for path in [None, '', '/bin', '/usr/bin:/bin:/sbin', '/', '/bin:/usr/bin:/sbin']:
        try:
            get_bin_path('this-file-does-not-exist', opt_dirs=path.split(os.pathsep) if path else None, required=False)
        except ValueError:
            pass
        except Exception as e:
            assert False, 'Unexpected exception %s' % e

    # should raise ValueError
    try:
        get_bin_path('tar')
    except ValueError:
        pass
    except Exception as e:
        assert False, 'Unexpected exception %s' % e

    # should return path to file

# Generated at 2022-06-20 16:07:12.248268
# Unit test for function get_bin_path
def test_get_bin_path():
    def set_env(tmp_env_name, new_env, use_mod_utils=True):
        import six

        if not use_mod_utils:
            os.environ[tmp_env_name] = new_env
        else:
            # Use AnsibleModule to set environment variable.
            from ansible.modules.system import set_fact
            module = set_fact.AnsibleModule({})
            module.set_environment(tmp_env_name, new_env)
            module.cleanup()
        # Reload os.environ because AnsibleModule modified os.environ
        if six.PY2:
            # Python 2
            reload(os)
        else:
            # Python 3
            import importlib
            importlib.reload(os)

    import tempfile
    import shutil
    tmp_env

# Generated at 2022-06-20 16:07:23.612019
# Unit test for function get_bin_path
def test_get_bin_path():
    # These tests are complex because we need to isolate the test
    # from external ifluences on PATH

    def test_positive(arg, opt_dirs, expected_path):
        try:
            old_path = os.environ.get('PATH')
            os.environ['PATH'] = ''
            bin_path = get_bin_path(arg, opt_dirs)
            assert bin_path == expected_path
        finally:
            if old_path is None:
                del os.environ['PATH']
            else:
                os.environ['PATH'] = old_path


# Generated at 2022-06-20 16:07:34.555230
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')
    assert get_bin_path('ls', ['/bin', '/usr/bin'])
    assert get_bin_path('ls', ['/bin', '/fake'])
    assert get_bin_path('ls', ['/fake', '/bin'])
    assert get_bin_path('cat', ['/bin', '/fake', '/fake2'])
    assert get_bin_path('cat', ['/fake', '/bin', '/fake2'])
    assert get_bin_path('cat', ['/fake', '/fake2', '/bin'])
    assert get_bin_path('cat', ['/fake2', '/bin', '/fake'])
    assert get_bin_path('cat', ['/fake2', '/fake', '/bin'])

# Generated at 2022-06-20 16:07:44.119967
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('/bin/echo') == '/bin/echo'
    assert get_bin_path('/bin/bash') == '/bin/bash'
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('/usr/bin/find') == '/usr/bin/find'
    assert get_bin_path('/usr/bin/rpm') == '/usr/bin/rpm'
    assert get_bin_path('/sbin/ip') == '/sbin/ip'
    assert get_bin_path('/sbin/fuser') == '/sbin/fuser'
    assert get_bin_path('ip') == '/sbin/ip'

# Generated at 2022-06-20 16:07:51.483264
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat', ['/bin']) == '/bin/cat'
    assert get_bin_path('cat', ['/usr/bin', '/bin', '/usr/sbin']) == '/bin/cat'
    try:
        bad = get_bin_path('not_there', ['/usr/bin', '/bin'])
    except Exception:
        # This is the expected result
        pass

# Generated at 2022-06-20 16:07:56.765608
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('echo', required=False)
    except Exception as e:
        assert False, 'should not throw an exception: %s' % e
    try:
        get_bin_path('nonexistent_executable')
        assert False, 'should throw a ValueError exception'
    except ValueError:
        pass

# Generated at 2022-06-20 16:08:06.781028
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    from tempfile import mkdtemp

    tempdir = mkdtemp()
    OPENSSL_BIN = get_bin_path('openssl')

    assert OPENSSL_BIN

    # test with opt_dirs
    test_bin = get_bin_path('openssl', opt_dirs=[tempdir])
    assert OPENSSL_BIN == test_bin
    test_bin = get_bin_path('openssl', opt_dirs=[tempdir, '/usr/bin'])
    assert OPENSSL_BIN == test_bin

    non_existing_bin = os.path.join(tempdir, 'not_existing')
    with pytest.raises(ValueError):
        get_bin_path(non_existing_bin)

    # test for required = False
    test_bin = get_bin_path

# Generated at 2022-06-20 16:08:08.062348
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-20 16:08:15.864846
# Unit test for function get_bin_path
def test_get_bin_path():
    import ansible.module_utils.common.file
    globals()['os'] = ansible.module_utils.common.file
    globals()['is_executable'] = ansible.module_utils.common.file.is_executable

    paths = ['/test1', '/test2/']
    v_test = ['/test1/pwd1', '/test2/pwd1']
    assert get_bin_path('pwd1', opt_dirs=paths) in v_test
    assert get_bin_path('pwd2', opt_dirs=paths) == '/bin/pwd2'

# Generated at 2022-06-20 16:08:22.547680
# Unit test for function get_bin_path
def test_get_bin_path():
    # dir list is only needed for this unit test
    test_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_data')
    for command_list in [
            # Passed list of directories with 'ls'
            [os.path.join(test_dir, 'fake_bin'), 'ls'],
            # Passed empty list with 'ls'
            [os.path.join(test_dir, 'fake_bin'), 'ls'],
            # Passed no list with 'ls'
            ['ls'],
            # Passed no list with 'false' (negative test)
            ['false']]:
        bin_path = get_bin_path(*command_list)
        print(bin_path)
        assert os.path.exists(bin_path)
        assert get_bin

# Generated at 2022-06-20 16:08:27.498545
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test if get_bin_path returns expected path
    import sys
    if sys.version_info[0] == 2:
        python = 'python'
    else:
        python = 'python3'
    try:
        get_bin_path(python)
    except Exception:
        assert False, "Unexpected error in get_bin_path"

# Generated at 2022-06-20 16:08:32.090634
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh')
    assert get_bin_path('sh', ['/bin', '/usr/bin'])
    assert get_bin_path('sh', ['/usr/bin', '/bin'])
    try:
        get_bin_path('no_such_binary')
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

# Generated at 2022-06-20 16:08:43.052965
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test that get_bin_path() raises ValueError when it does not find
    # the command in the path or any optional directories.
    # Test for normal case where path to command is in $PATH
    # Test for successful lookup of command in an optional directory.
    # Test for unsuccessful lookup of command in optional directory.
    # Test that get_bin_path() raises ValueError when it finds the command,
    # but the command is not executable.
    # Test that get_bin_path() raises ValueError when it finds the command
    # in an optional directory that is not executable.
    pass

# Generated at 2022-06-20 16:08:50.014983
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("/usr/bin/sh") == "/bin/sh"
    assert get_bin_path("echo") == "/bin/echo"
    assert get_bin_path("echo", required=True) == "/bin/echo"
    assert get_bin_path("echo", ["/bin"]) == "/bin/echo"

    try:
        get_bin_path("echo", ["/x"])
        raise Exception("Should have failed to find echo in /x")
    except ValueError:
        pass

    assert get_bin_path("/usr/bin/sh", ["/bin"]) == "/usr/bin/sh"
    assert get_bin_path("echo", ["/x"]) == "/bin/echo"

# Generated at 2022-06-20 16:08:56.702116
# Unit test for function get_bin_path
def test_get_bin_path():
    test_path = get_bin_path('cat')
    assert os.path.exists(test_path) and not os.path.isdir(test_path) and is_executable(test_path)

# Generated at 2022-06-20 16:09:02.793166
# Unit test for function get_bin_path
def test_get_bin_path():
    import subprocess
    from ansible.module_utils.six.moves import shlex_quote

    if subprocess.call(shlex_quote(get_bin_path('/bin/false'))) == 0:
        raise Exception('/bin/false should return false')
    if subprocess.call(shlex_quote(get_bin_path('bin/sh', opt_dirs=['/']))) != 0:
        raise Exception('bin/sh should return true')

    # Make sure we raise an error if the executable not found
    try:
        get_bin_path('foo/bar')
        raise Exception('get_bin_path(foo/bar) should raise an Exception')
    except ValueError:
        pass



# Generated at 2022-06-20 16:09:10.329260
# Unit test for function get_bin_path
def test_get_bin_path():
    import subprocess

    shell = get_bin_path('sh')
    arg = 'printf "This is a test"'
    try:
        p = subprocess.Popen([shell, '-c', arg], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = p.communicate('')
    except OSError:
        raise AssertionError('Failed to execute command: %s' % (arg, ))

    assert out.strip() == 'This is a test'

    if os.path.exists('/bin'):
        bp = get_bin_path('sh', opt_dirs='/bin')
        assert shell == bp

# Generated at 2022-06-20 16:09:20.863450
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    from shutil import copy

    rand_prefix = 'py_test_'
    rand_suffix = '.tmp'
    rand_exec_name = 'py_test_exec_file.tmp'

    # test with a bad file name and dirs
    try:
        get_bin_path('bad_test_file')
        assert(False)
    except ValueError:
        pass

    # test with a good file name and dirs
    temp_dir = tempfile.mkdtemp(prefix=rand_prefix, suffix=rand_suffix)
    my_exec = os.path.join(temp_dir, rand_exec_name)
    copy(os.path.join(os.path.dirname(__file__), 'get_bin_path.py'), my_exec)

# Generated at 2022-06-20 16:09:31.978813
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path
    '''
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=["/bin/", None]) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=["/bin/", None]) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=["/bin/", None], required=True) == '/bin/ls'

    fake_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'fixtures/fake')
    assert get_bin_path('ls', opt_dirs=[fake_file, "/bin/", None], required=True) == '/bin/ls'

# Generated at 2022-06-20 16:09:42.169972
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    (fd, fname) = tempfile.mkstemp()
    os.write(fd, b'#!/bin/sh\n')
    os.close(fd)
    os.chmod(fname, 0o755)

    assert get_bin_path(fname, []) == fname
    os.unlink(fname)

    # if we do not have /usr/sbin & /usr/local/sbin in PATH, we should get a ValueError
    (fd, fname) = tempfile.mkstemp()
    os.write(fd, b'#!/bin/sh\n')
    os.close(fd)
    os.chmod(fname, 0o755)

    os.environ['PATH'] = '/bin:/usr/bin'

    err = False

# Generated at 2022-06-20 16:09:49.253041
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    validate get_bin_path function
    '''
    import tempfile
    import shutil

    (tmpdir_handle, tmpdir_path) = tempfile.mkstemp()
    os.close(tmpdir_handle)
    os.mkdir(tmpdir_path)
    os.mkdir(os.path.join(tmpdir_path, 'bin'))
    os.mkdir(os.path.join(tmpdir_path, 'sbin'))

    # create script
    script_path = os.path.join(tmpdir_path, 'sbin', 'shell')
    with open(script_path, 'w') as script_fd:
        script_fd.write('#!/bin/sh\n')
        script_fd.write('exit 0\n')

# Generated at 2022-06-20 16:09:56.378867
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Validate that get_bin_path raises a ValueError when the executable is not found.
    '''
    import pytest
    with pytest.raises(ValueError):
        get_bin_path('ansible-non-existent-executable')
    try:
        get_bin_path('ansible-non-existent-executable', required=False)
    except ValueError:
        pytest.fail('AnsibleModule.get_bin_path raises a ValueError with required=False')

# Generated at 2022-06-20 16:10:08.652357
# Unit test for function get_bin_path
def test_get_bin_path():
    import platform
    if platform.system() == 'Windows':
        assert get_bin_path('cmd.exe', opt_dirs=[])
        # Make sure that PATH is searched
        os.environ['ansible_does_not_exist_on_windows'] = 'does_not_exist_on_windows'
        # On Windows PATHEXT recognizes both .exe and .com files (https://docs.microsoft.com/en-us/windows/desktop/fileio/file-name-extensions)
        assert get_bin_path('ansible_does_not_exist_on_windows', opt_dirs=[]) == os.path.abspath('ansible_does_not_exist_on_windows')

# Generated at 2022-06-20 16:10:19.636695
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.facts.virtual.sysctl import _sysctl_cmd
    import tempfile
    import os
    import shutil
    import stat

    path = None

# Generated at 2022-06-20 16:10:29.186223
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('touch') == '/usr/bin/touch'
    assert get_bin_path('/usr/bin/touch') == '/usr/bin/touch'
    assert get_bin_path('/bin/touch') == '/bin/touch'
    assert get_bin_path('touch', opt_dirs=['/usr/bin', '/usr/local/bin']) == '/usr/bin/touch'
    assert get_bin_path('touch', required=True) == '/usr/bin/touch'


# Generated at 2022-06-20 16:10:40.249081
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_list = ['mkdir', 'ls', 'rm', 'find', 'grep', 'egrep', 'fgrep', 'bash', 'ssh', 'scp', 'rsync', 'dd', 'tar', 'chmod', 'chown', 'ln', 'cp', 'id', 'file', 'which']
    my_module = get_bin_path(bin_list[0])
    for arg in bin_list[1:]:
        try:
            assert get_bin_path(arg) != None
        except Exception as e:
            raise ValueError("get_bin_path('%s') failed: %s" % (arg, e))

# Generated at 2022-06-20 16:10:41.575516
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert bin_path.endswith('sh')

# Generated at 2022-06-20 16:10:49.035432
# Unit test for function get_bin_path
def test_get_bin_path():
    test_paths = ['/usr/bin', '/bin']
    test_paths_reverse = ['/bin', '/usr/bin']


# Generated at 2022-06-20 16:10:59.407141
# Unit test for function get_bin_path
def test_get_bin_path():
    # test without a required value
    assert 'bash' == os.path.basename(get_bin_path('bash', ['/bin', '/usr/bin']))
    # test with a required value
    assert 'bash' == os.path.basename(get_bin_path('bash', ['/bin', '/usr/bin'], True))
    # test with a required value and a missing file
    try:
        get_bin_path('bash', ['/bin_a', '/usr/bin_a'], True)
        raise AssertionError('Expected ValueError')
    except ValueError as e:
        assert 'Failed to find required executable "bash" in paths:' in str(e)

# Generated at 2022-06-20 16:11:05.005845
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('/usr/bin/ls') == '/usr/bin/ls'
    assert get_bin_path('/bin/ls', ['/usr/bin']) == '/bin/ls'
    assert get_bin_path('/bin/ls', ['.']) == './ls'
    assert get_bin_path('/bin/ls', ['/nonexistent']) == '/bin/ls'
    try:
        get_bin_path('nonexistent')
        raise Exception("Failed to raise an exception")
    except:
        pass
    try:
        get_bin_path('nonexistent', ['/bin', '/usr/bin'])
        raise Exception("Failed to raise an exception")
    except:
        pass



# Generated at 2022-06-20 16:11:13.255367
# Unit test for function get_bin_path
def test_get_bin_path():

    import tempfile
    import random

    sbin_paths = ('/sbin', '/usr/sbin', '/usr/local/sbin')
    paths = os.environ.get('PATH', '').split(os.pathsep)

    # Create a temporary directory
    tmp = tempfile.mkdtemp()
    os.chmod(tmp, 0o777)

    # Create executable file in the temporary directory
    (handle, path) = tempfile.mkstemp(dir=tmp)

    # Create executable file with the same name in os.getcwd() and in /sbin
    (handle, path) = tempfile.mkstemp(dir=tmp)
    (handle, path2) = tempfile.mkstemp(dir=os.getcwd())

# Generated at 2022-06-20 16:11:22.740423
# Unit test for function get_bin_path
def test_get_bin_path():
    # test for python executable
    try:
        assert get_bin_path('python')
        assert get_bin_path('python', required=True)
    except ValueError as e:
        assert False, 'Failed while searching for python executable in PATH. Exception: "%s"'% e

    # test for nonexistent executable
    try:
        get_bin_path('fooobarbaz', required=True)
    except ValueError as e:
        assert True, 'ValueError thrown correctly for nonexistent executable. Exception: "%s"'% e

    # test for directory in path
    try:
        get_bin_path(os.getcwd(), required=True)
    except ValueError as e:
        assert True, 'ValueError thrown correctly for a directory in PATH. Exception: "%s"'% e



# Generated at 2022-06-20 16:11:38.117277
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('bash')
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('bash', ['/sbin', '/usr/sbin', '/usr/local/sbin']) == '/bin/bash'
    assert get_bin_path('bash', ['/sbin', '/usr/sbin', '/usr/local/sbin']) == '/bin/bash'
    try:
        get_bin_path('this_exe_is_not_found')
    except ValueError:
        pass
    else:
        raise AssertionError('get_bin_path did not raise exception')
    try:
        get_bin_path('bash', ['/etc'])
    except ValueError:
        pass

# Generated at 2022-06-20 16:11:50.283316
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    # Check which Python interpreter is used
    if '/usr/bin/python2' in sys.executable:
        # The system Python is used on RHEL/CentOS 6
        python2_exec_path = '/usr/bin/python2'
        python3_exec_path = '/usr/bin/python3'
    else:
        # The system Python is used on RHEL/CentOS 7 and Debian
        python2_exec_path = '/usr/bin/python'
        python3_exec_path = '/usr/bin/python3'

    # Check where is the awk executable
    if os.path.exists('/usr/bin/awk'):
        awk_exec_path = '/usr/bin/awk'
    elif os.path.exists('/usr/bin/gawk'):
        aw

# Generated at 2022-06-20 16:11:56.215836
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no-such-executable-in-path')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    assert get_bin_path('python2') == '/usr/bin/python2'  # this exists on CI
    assert get_bin_path('python2', required=False) == '/usr/bin/python2'  # this exists on CI

# Generated at 2022-06-20 16:12:01.875043
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', '/bin') == '/bin/sh'
    try:
        get_bin_path('nosuchfoobarbaz')
        assert False, "Expected get_bin_path() to raise an exception"
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

# Generated at 2022-06-20 16:12:07.906243
# Unit test for function get_bin_path
def test_get_bin_path():
    # test if existing executables are found
    if is_executable('/bin/sh'):
        get_bin_path('sh')
    if is_executable('/bin/ls'):
        get_bin_path('ls')

    # test if existing directories are not accepted
    try:
        get_bin_path('/')
    except ValueError as e:
        pass
    else:
        assert False, 'Directory should raise ValueError'

    # test for non existing executables
    try:
        get_bin_path('this_is_not_an_executable')
    except ValueError as e:
        pass
    else:
        assert False, 'Non existing executable should raise ValueError'

# Generated at 2022-06-20 16:12:18.635039
# Unit test for function get_bin_path
def test_get_bin_path():
    """Return get_bin_path value"""
    assert get_bin_path("/bin/ls") == "/bin/ls"
    assert get_bin_path("ls") == "/bin/ls"
    assert get_bin_path("ls", required=False) == "/bin/ls"
    assert get_bin_path("ls", opt_dirs=['/sbin']) == "/sbin/ls"
    assert get_bin_path("ls", opt_dirs=['/usr/local/bin']) == "/usr/local/bin/ls"
    assert get_bin_path("ls", opt_dirs=['/usr/bin']) == "/usr/bin/ls"

# Generated at 2022-06-20 16:12:30.584728
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function
    '''
    if os.path.exists('/usr/bin/ls'):
        assert get_bin_path('ls') == '/usr/bin/ls'
    else:
        assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['']) == '/bin/ls'
    # Test that /sbin paths are searched

# Generated at 2022-06-20 16:12:41.337252
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    import tempfile
    import shutil

    class TestGetBinPathTestCase(unittest.TestCase):

        def setUp(self):
            self.paths = []
            self.tempdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tempdir)

        def _make_exec(self, filename, temproot=False):
            if temproot:
                fpath = os.path.join(self.tempdir, filename)
            else:
                fpath = os.path.join(self.tempdir, 'ansible', filename)
            dirpath = os.path.dirname(fpath)

# Generated at 2022-06-20 16:12:46.229826
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no_such_program')
        assert False, 'Should have raised ValueError'
    except ValueError:
        pass

    # the 'env' command should be in the default paths
    path = get_bin_path('env')
    assert path is not None and os.path.exists(path)
    assert is_executable(path)

    # the 'env' command should be in the passed in paths
    path = get_bin_path('env', opt_dirs='/tmp')
    assert path is not None and os.path.exists(path)
    assert is_executable(path)

    # If the passed in path does not exist it should not be returned
    path = get_bin_path('env', opt_dirs='/tmp/no_such_dir')
    assert path

# Generated at 2022-06-20 16:12:54.507463
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    python_path = get_bin_path('python')
    if 'python' in python_path:
        raise ValueError('Test get_bin_path for python failed: %s' % python_path)
    # ANSIBLE_TEST_GET_BIN_PATH_DIRS contains comma-separated paths to test
    test_dirs = os.environ.get('ANSIBLE_TEST_GET_BIN_PATH_DIRS', '').split(',')
    if test_dirs:
        # the test fails, if 'python' is not found in the test dirs
        python_path = get_bin_path('python', test_dirs)

# Generated at 2022-06-20 16:13:05.748030
# Unit test for function get_bin_path
def test_get_bin_path():
    # If get_bin_path is called with an argument which exists in a provided directory it should return it
    bin_path = get_bin_path('touch', ['/bin', '/usr/bin'])
    assert bin_path == '/bin/touch'

    # If get_bin_path is called with an argument which exists in PATH it should return it
    bin_path = get_bin_path('touch')
    assert bin_path == '/bin/touch'

    # If the argument is not found in PATH or the provided directories, it should raise an exception
    import pytest
    pytest.raises(ValueError, get_bin_path, 'touch', ['/non/existent/dir'])

# Generated at 2022-06-20 16:13:07.194614
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ['PATH'] = '/sbin:/usr/sbin:/usr/local/sbin:/usr/bin'
    assert get_bin_path('bash') == '/bin/bash'

# Generated at 2022-06-20 16:13:15.248489
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import filecmp

    class TestArgs(object):
        def __init__(self, opt_dirs=None, required=None):
            self.opt_dirs = opt_dirs
            self.required = required

    # Test creating a temporary directory
    td = tempfile.mkdtemp()

    # Get full path of a program that we know will be in the PATH
    cat_path = get_bin_path('cat')

    # Create a symlink to cat
    cat_symlink = os.path.join(td, 'cat_symlink')
    os.symlink('cat', cat_symlink)

    # Test finding cat from our temporary directory
    test_args = TestArgs(opt_dirs=[td])
    assert cat_path == get_bin_path

# Generated at 2022-06-20 16:13:24.935395
# Unit test for function get_bin_path
def test_get_bin_path():
    test_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    test_path_python = os.path.join(test_path, 'python')
    test_path_invalid = os.path.join(test_path, 'invalid')
    assert get_bin_path('python', [test_path_python]) == os.path.join(test_path_python, 'python')
    assert get_bin_path('python', [test_path_invalid]) == get_bin_path('python')
    assert get_bin_path('python', [test_path_python], [test_path_invalid]) == os.path.join(test_path_python, 'python')
    assert get_bin_path('invalid', [test_path_python]) is None
    assert get

# Generated at 2022-06-20 16:13:30.974826
# Unit test for function get_bin_path
def test_get_bin_path():
    from tempfile import mkdtemp
    from shutil import rmtree

    opt_dirs = [mkdtemp()]
    for arg in ('python', 'python3.8', 'invalid'):
        try:
            path = get_bin_path(arg, opt_dirs)
            assert path == os.path.join(opt_dirs[0], arg), 'expected %s != %s' % (path, os.path.join(opt_dirs[0], arg))
        except ValueError:
            if arg != 'invalid':
                raise

    rmtree(opt_dirs[0])

# Generated at 2022-06-20 16:13:42.632397
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import platform

    bin_name = 'foo'
    bin_path = get_bin_path(bin_name)

    # Create tmp dir to put executable in
    tmp_dir = tempfile.mkdtemp()

    # Create tmp dir to add to exec path
    tmp_dir2 = tempfile.mkdtemp()

    # Create executable in tmp dir
    with open(os.path.join(tmp_dir, bin_name), 'w') as f:
        f.write('#!%s\n' % (bin_path))
        f.write('import sys\n')
        f.write('print("Hello World!")\n')

    # Make executable executable
    os.chmod(os.path.join(tmp_dir, bin_name), 0o755)

    # Create executable

# Generated at 2022-06-20 16:13:50.284179
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function. Test the following cases
    - Found in PATH
    - Found in opt_dirs
    - Not Found
    '''
    fake_bin = 'fake_bin'
    fake_bin_path = '/tmp/fake_bin'

    import tempfile
    tmp_dirs = []

    # Create a fake_bin in tmp (PATH) and opt_dirs
    for tmp_dir in [tempfile.gettempdir(), tempfile.mkdtemp()]:
        open(os.path.join(tmp_dir, fake_bin), 'w').close()
        tmp_dirs.append(tmp_dir)

    # Create a fake_bin outside of PATH and opt_dirs
    open(fake_bin_path, 'w').close()

    # Test found bin in PATH

# Generated at 2022-06-20 16:14:00.655682
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('cat')
    except ValueError:
        assert False, 'cat was not found in path'

    try:
        get_bin_path('cat', required=True)
    except ValueError:
        assert False, 'cat was not found in path'

    try:
        get_bin_path('cat', ['/usr/local/bin', '/usr/bin/local'])
    except ValueError:
        assert False, 'cat was not found in path'

    try:
        get_bin_path('fake_file')
        assert False, 'fake_file was found in path'
    except ValueError:
        pass


# Generated at 2022-06-20 16:14:11.555053
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for binary existing in PATH
    assert get_bin_path('sh') == which('sh')

    # Test for binary not existing in PATH
    try:
        get_bin_path('does_not_exist')
    except ValueError:
        assert True
    else:
        assert False

    # Test for binary existing in PATH with alternative directories
    assert get_bin_path('sh', opt_dirs=['/bin', '/usr/bin']) == which('sh')
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin']) == which('sh')

    # Test for binary not existing in PATH and alternative directories
    try:
        get_bin_path('sh', opt_dirs=['/usr/bin'])
    except ValueError:
        assert True

# Generated at 2022-06-20 16:14:19.009161
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.path.exists('/usr/bin/python'):
        assert get_bin_path('python') == '/usr/bin/python'
    else:
        assert get_bin_path('python') == '/usr/bin/python2'
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('notfound', opt_dirs=[os.path.dirname(__file__)]) == os.path.join(os.path.dirname(__file__), 'notfound')

# Generated at 2022-06-20 16:14:33.610125
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import tempfile
    import pytest
    import getpass
    from distutils.spawn import find_executable

    TEST_SCRIPT = """#!/bin/sh
    echo "I am test_bin_path"
    """
    # /usr/bin is the first directory in PATH for most users:
    # create a temporary file in /usr/bin so that we can reliably
    # find it using find_executable.
    #
    # Use Distutils' find_executable because we don't want the test
    # to fail if PATH isn't setup as expected.
    (fd, fp) = tempfile.mkstemp(prefix='', suffix='test_bin_path', dir='/usr/bin')
    os.write(fd, TEST_SCRIPT)
    os.close(fd)

# Generated at 2022-06-20 16:14:44.282427
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path
    '''
    import tempfile
    from ansible.module_utils.six import PY3

    tmp_file = tempfile.NamedTemporaryFile()
    test_exec = tmp_file.name
    test_exec_name = os.path.basename(test_exec)
    # on Windows, when creating a temp file via NamedTemporaryFile, it
    # will not have the executable bit set; on Unix, it will
    if not PY3:
        import stat
        os.chmod(test_exec, (os.stat(test_exec).st_mode | stat.S_IEXEC))


# Generated at 2022-06-20 16:14:53.385725
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('echo') == get_bin_path('echo', ['/bin']) == get_bin_path('echo', opt_dirs=['/bin'])
    assert get_bin_path('echo', opt_dirs=['/bin', '/sbin']) == '/bin/echo'
    try:
        get_bin_path('pylint', ['/bin', '/sbin'])
    except ValueError:
        pass
    else:
        raise Exception('get_bin_path should have raised a ValueError')
    assert get_bin_path('touch', ['/bin', '/sbin']) is not None