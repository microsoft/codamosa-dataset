

# Generated at 2022-06-20 16:05:04.755093
# Unit test for function get_bin_path
def test_get_bin_path():
    if not hasattr(os, 'symlink'):
        return
    import tempfile
    import shutil
    import stat

    # Create a non-executable file in a temp dir
    temp_dir = tempfile.mkdtemp()
    non_executable_file_name = os.path.join(temp_dir, 'non_executable_file')
    with open(non_executable_file_name, "w") as f:
        f.write("I am a file")
    os.chmod(non_executable_file_name, stat.S_IWRITE)

    # Create a symlink to the non-executable file in the temp dir
    symlink_file_name = os.path.join(temp_dir, 'symlink_file')

# Generated at 2022-06-20 16:05:05.960194
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-20 16:05:06.994746
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('sh')
    assert path == '/bin/sh'

# Generated at 2022-06-20 16:05:08.748363
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('cat'))

# Generated at 2022-06-20 16:05:10.469299
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_b

# Generated at 2022-06-20 16:05:18.109988
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # For all of these tests, we are simply seeing if the code finds all
    # the correct paths and does not find the incorrect paths.
    # We don't want to test the validity of the paths found.

    # test_1
    assert get_bin_path('whoami') == basic.get_platform_binary('whoami')

    # test_2
    # whoami should exist in sbin
    assert get_bin_path('whoami', opt_dirs=['/sbin']) == to_bytes('/sbin/whoami')

    # test_3
    # whoami should exist in /sbin

# Generated at 2022-06-20 16:05:25.629616
# Unit test for function get_bin_path
def test_get_bin_path():
    # a non-existing binary
    try:
        get_bin_path('file-not-existing')
        assert False, 'We should not reach this line'
    except ValueError:
        pass

    # a binary in /bin and /usr/bin
    assert get_bin_path('ls') == '/bin/ls'

    # a binary in a given path
    assert get_bin_path('ls', opt_dirs=[ '/usr/bin' ]) == '/usr/bin/ls'

    # a binary in /sbin paths
    assert get_bin_path('halt') == '/sbin/halt'
    assert get_bin_path('halt', opt_dirs=[ '/bin', '/usr/bin' ]) == '/sbin/halt'

# Generated at 2022-06-20 16:05:28.018539
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('tar')
    assert bin_path is not None
    assert len(bin_path) > 4



# Generated at 2022-06-20 16:05:38.206614
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1: Locate /bin/ls
    #
    # Test succeeds if ls exists in current PATH, otherwise fails.
    #
    # Test is skipped if ls does not exist in current PATH. In that case, function
    # get_bin_path should return 'None'
    #
    try:
        bin_path = get_bin_path('ls')
    except ValueError:
        bin_path = None
    assert bin_path == os.system('/bin/which ls')  # returns 0 on success, 1 if not

    # Test 2: Locate /bin/ls using optional argument opt_dirs
    #
    # Test succeeds if ls exists in /bin and /bin is the only directory specified in opt_dirs
    #
    # Test fails if ls exists in /bin and /bin is not the only directory specified in opt_dir

# Generated at 2022-06-20 16:05:49.202978
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat
    import platform

    # Create a temporary directory to hold the test files
    tmpdir = tempfile.mkdtemp(prefix="test-get_bin_path-")

    # Create the executable file in the temporary directory
    file_name = "executable_file"
    file_path = tmpdir + os.sep + file_name
    with open(file_path, "w") as tmp_file:
        tmp_file.write("#!/bin/sh\necho Hello\n")

    # Make the file executable
    mode = os.stat(file_path).st_mode
    mode |= (mode & 0o444) >> 2    # copy R bits to X
    os.chmod(file_path, mode & 0o777)


# Generated at 2022-06-20 16:06:01.658623
# Unit test for function get_bin_path
def test_get_bin_path():
    assert isinstance(get_bin_path('ansible-connection'), str)
    try:
        get_bin_path('false')
        assert False, 'ansible.module_utils.basic.get_bin_path should have raised a ValueError.'
    except ValueError:
        assert True
    try:
        get_bin_path('false', opt_dirs=['/bin'])
        assert False, 'ansible.module_utils.basic.get_bin_path should have raised a ValueError.'
    except ValueError:
        assert True
    try:
        get_bin_path('false', opt_dirs=['/usr/bin'])
        assert False, 'ansible.module_utils.basic.get_bin_path should have raised a ValueError.'
    except ValueError:
        assert True

# Generated at 2022-06-20 16:06:12.842195
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    assert get_bin_path('ls') == os.path.join(os.path.sep, 'bin', 'ls')

    assert get_bin_path('ping') == os.path.join(os.path.sep, 'bin', 'ping')

    assert get_bin_path('/bin/ls') == os.path.join(os.path.sep, 'bin', 'ls')

    assert get_bin_path('/usr/sbin/ping') == os.path.join(os.path.sep, 'usr', 'sbin', 'ping')

    assert get_bin_path('/does/not/exist') == None

    assert get_bin_path('/usr/bin/python2.7') == os.path.realpath(sys.executable)

# Generated at 2022-06-20 16:06:23.171539
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.file import is_executable
    import os
    import tempfile
    import shutil
    import os.path

    try:
        TEST_DIR = tempfile.mkdtemp()
        BIN_PATH = os.path.join(TEST_DIR, 'my_cmd')
        open(BIN_PATH, 'w').close()
        os.chmod(BIN_PATH, 0o755)

        assert(get_bin_path('my_cmd', [TEST_DIR]) == BIN_PATH)
    finally:
        shutil.rmtree(TEST_DIR, ignore_errors=True)

# Generated at 2022-06-20 16:06:35.859787
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('sh') in ('/bin/sh', '/usr/bin/sh', '/usr/sbin/sh', '/sbin/sh', '/usr/local/sbin/sh')
    assert get_bin_path('sh', required=True) in ('/bin/sh', '/usr/bin/sh', '/usr/sbin/sh', '/sbin/sh', '/usr/local/sbin/sh')
    assert get_bin_path('sh', opt_dirs=['/opt/bin']) in ('/opt/bin/sh')
    assert get_bin_path('sh', opt_dirs=['/opt/bin'], required=True) in ('/opt/bin/sh')

    # now test required functionality

# Generated at 2022-06-20 16:06:44.598547
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.sys_info import get_distribution

    if get_distribution() in ('FreeBSD', 'OpenBSD'):
        assert get_bin_path('/sbin/ping') == '/sbin/ping'
        assert get_bin_path('ping') == '/sbin/ping'
        assert get_bin_path('/bin/ping') == '/bin/ping'
    else:
        assert get_bin_path('/sbin/ping') == '/sbin/ping'
        assert get_bin_path('ping') == '/bin/ping'
        assert get_bin_path('/bin/ping') == '/bin/ping'

# Generated at 2022-06-20 16:06:51.930742
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test module for get_bin_path.
    '''
    from ansible.module_utils.common.process import get_bin_path
    BIN_NAME = 'test_bin_module'

    # Environment variables needed for the test
    if 'PATH' in os.environ:
        orig_path = os.environ['PATH']
    else:
        orig_path = None

    # Set PATH to a single dir containing the test bin
    bin_path = os.path.abspath(BIN_NAME)
    bin_parent_dir = os.path.dirname(bin_path)
    assert(bin_path != bin_parent_dir)
    os.environ['PATH'] = bin_parent_dir

    # Check that we can find the test bin

# Generated at 2022-06-20 16:06:59.889934
# Unit test for function get_bin_path
def test_get_bin_path():
    test_dir = '/usr/bin'
    test_paths = ['sshpass']

    for p in test_paths:
        get_bin_path(p)
        get_bin_path(p, opt_dirs=[test_dir])
        get_bin_path(p, opt_dirs=[test_dir, test_dir])

    # Test exception
    error_msg = ''
    try:
        get_bin_path(p + '.2')
    except ValueError as e:
        error_msg = str(e)
    assert error_msg == 'Failed to find required executable "%s" in paths: %s' % (p + '.2', test_dir), error_msg

# Generated at 2022-06-20 16:07:11.665106
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile, shutil

    fd, fname = tempfile.mkstemp()
    os.close(fd)
    try:
        os.chmod(fname, 0o700)
        get_bin_path(fname)
        assert False, "get_bin_path should have raised exception"
    except ValueError:
        pass

    fd, fname = tempfile.mkstemp()
    os.close(fd)
    os.chmod(fname, 0o700)
    get_bin_path(fname, opt_dirs=[os.path.dirname(fname)])
    assert os.path.exists(fname), "temporary file was removed"
    os.unlink(fname)

    # with empty PATH expect ValueError

# Generated at 2022-06-20 16:07:23.569490
# Unit test for function get_bin_path
def test_get_bin_path():
    import mock

    arg = 'test'
    required = True
    expected = 'foo'

    with mock.patch('os.environ', {'PATH': 'foo'}):
        with mock.patch('ansible.module_utils.common.file.is_executable', return_value=True):
            bin_path = get_bin_path(arg, opt_dirs=[], required=required)
            assert bin_path == expected

    with mock.patch('os.environ', {'PATH': 'foo'}):
        with mock.patch('ansible.module_utils.common.file.is_executable', return_value=True):
            opt_dirs = ['bar']
            bin_path = get_bin_path(arg, opt_dirs=opt_dirs, required=required)

# Generated at 2022-06-20 16:07:32.058402
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('date')
    assert is_executable(bin_path)
    assert os.path.basename(bin_path) == 'date'
    assert os.path.dirname(bin_path) in os.environ.get('PATH', '').split(os.pathsep)

    bin_path = get_bin_path('FOO', opt_dirs=['/bin', '/usr/bin'])
    assert is_executable(bin_path)
    assert os.path.basename(bin_path) == 'FOO'
    assert os.path.dirname(bin_path) in ['/bin', '/usr/bin']

# Generated at 2022-06-20 16:07:44.050460
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('cat', ['/usr/local/bin', '/usr/local/sbin']) == '/usr/local/bin/cat'
    assert get_bin_path('cat', ['/usr/local/bin', '/usr/local/sbin'], True) == '/usr/local/bin/cat'
    assert get_bin_path('cat', ['/usr/local/bin', '/usr/local/sbin'], False) == '/usr/local/bin/cat'
    try:
        get_bin_path('cats')
    except ValueError as e:
        assert 'cats' in str(e)
    try:
        get_bin_path('cats', required=False)
    except ValueError as e:
        assert 'cats'

# Generated at 2022-06-20 16:07:56.901397
# Unit test for function get_bin_path
def test_get_bin_path():
    def _is_bin_in_paths(binname, pathlist, expected_result=True):
        # Using a ValueError as a sentinel value here, that way a falsey
        # value (like False or '') is not mistaken for a valid path.
        try:
            bin_path = get_bin_path(binname, opt_dirs=pathlist)
            assert expected_result, 'Expected to not find {0}, but found it at {1}'.format(binname, bin_path)
        except ValueError:
            assert not expected_result, 'Did not expect to find {0}, but did anyway'.format(binname)

    _is_bin_in_paths('true', [])
    _is_bin_in_paths('false', [])

# Generated at 2022-06-20 16:08:06.924803
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for function get_bin_path
    '''
    from ansible.module_utils.common.file import is_executable
    import os

    # fake a command that uses python3
    def unit_test_path_join(arg, opt_dirs = None):
        return os.path.join('/bin', arg)

    # Ensure that get_bin_path returns the correct value that is executable
    os.path.join = unit_test_path_join
    os.path.exists = lambda x: True
    os.path.isdir = lambda x: False
    assert get_bin_path('python3', None) == '/bin/python3'
    is_executable = lambda x: True
    assert get_bin_path('python3', None) == '/bin/python3'
    is_

# Generated at 2022-06-20 16:08:12.216776
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('has_highstate') == '/usr/bin/has_highstate'
    assert get_bin_path('/usr/bin/has_highstate') == '/usr/bin/has_highstate'
    assert get_bin_path('/usr/bin/has_highstate', ['/usr/bin']) == '/usr/bin/has_highstate'
    try:
        get_bin_path('non_existant')
    except ValueError:
        assert True
    else:
        assert False
    assert get_bin_path('has_highstate', ['/non/existant'], True) == '/usr/bin/has_highstate'

# Generated at 2022-06-20 16:08:20.426219
# Unit test for function get_bin_path
def test_get_bin_path():
    import errno
    import pytest
    from ansible.module_utils.common.file import is_executable

    def is_executable_wrapper(path):
        if path == '/fake/path/fail_me':
            return False
        return is_executable(path)

    fake_path_value = '/fake/path'
    paths = os.environ.get('PATH', '').split(os.pathsep)
    paths.insert(0, fake_path_value)

    orig_os_path_exists = os.path.exists
    orig_os_path_isdir = os.path.isdir
    orig_is_executable = is_executable

    def os_path_exists_wrapper(path):
        if path == '/fake/path/fail_me':
            return False
        return

# Generated at 2022-06-20 16:08:25.879978
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('hostname') == '/bin/hostname'
    # assert get_bin_path('does-not-exist') == None  # ValueError: Failed to find required executable "does-not-exist" in paths: /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
    # assert get_bin_path('does-not-exist', required='fal

# Generated at 2022-06-20 16:08:36.436846
# Unit test for function get_bin_path
def test_get_bin_path():
    # Basic call with no extra options
    try:
        get_bin_path('python')
    except:
        assert False, 'Failed to find python in PATH'
    try:
        get_bin_path('__foo_bar_baz__')
        assert False, 'Found a non-existent executable'
    except ValueError:
        pass
    # Call with optional arguments
    opt_dirs = ['/bin', '/usr/bin']
    try:
        get_bin_path('python', opt_dirs=opt_dirs)
    except:
        assert False, 'Failed to find python in PATH and additional directories %s' % opt_dirs

# Generated at 2022-06-20 16:08:45.943901
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    # Test with an executable already in PATH - /bin/sh
    try:
        my_bin_path = get_bin_path('sh')
    except ValueError:
        assert False, "Failed to find executable in PATH !"
    assert os.access(my_bin_path, os.F_OK), "Executable found does not exist !"
    assert os.access(my_bin_path, os.X_OK), "Executable found is not executable !"

    # Test with an executable not in PATH - touch
    # create a temporary directory to hold the executable
    my_dir = tempfile.mkdtemp()
    my_bin = 'mybin'
    # concatenate the directory and the binary name to get the executable's full path

# Generated at 2022-06-20 16:08:48.305614
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' get_bin_path(): Basic test of get_bin_path(). '''
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-20 16:08:49.710507
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('some_not_existing_binary') == '/usr/bin/some_not_existing_binary'

# Generated at 2022-06-20 16:09:00.208467
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = 'ansible'
    bin_path = get_bin_path(arg)
    assert bin_path == '/usr/bin/ansible'

    # User specified PATH
    arg = 'ansible-playbook'
    get_bin_path(arg, opt_dirs=['/usr/bin'])
    assert bin_path == '/usr/bin/ansible-playbook'

    # User specified PATH, which doesn't have required executable
    arg = 'foo-bar'
    with pytest.raises(ValueError):
        get_bin_path(arg, opt_dirs=['/usr/bin'])

    # User specified PATH with required executable, but arg is not executable
    arg = 'ansible-playbook'

# Generated at 2022-06-20 16:09:09.092329
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    import errno

    # create fake executable in temp_dir
    temp_dir = tempfile.mkdtemp()
    fake_executable_name = 'fake_executable'
    fake_executable_path = os.path.join(temp_dir, fake_executable_name)
    fake_executable = open(fake_executable_path, 'w')
    fake_executable.write("#!/bin/bash")
    fake_executable.close()
    os.chmod(fake_executable_path, 0o711)

    # test 1: should find executable in our temp directory 'temp_dir'
    assert get_bin_path(fake_executable_name, [temp_dir]) == os.path.join(temp_dir, fake_executable_name)

   

# Generated at 2022-06-20 16:09:19.535494
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    options = tempfile.mkdtemp()
    path = os.environ.get('PATH')
    os.environ['PATH'] = '%s%s%s' % (options, os.path.pathsep, path)
    exe = 'ansible-test-executable'

    # Installed
    shutil.copy('/bin/ls', exe)
    shutil.copy('/bin/ls', os.path.join(options, exe))
    os.chmod(exe, stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)

# Generated at 2022-06-20 16:09:26.815997
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    test_path = tempfile.mkdtemp()
    path_file = os.path.join(test_path, 'test')
    open(path_file, 'a').close()
    os.chmod(path_file, 0o777)
    old_path = os.environ.get('PATH', '')
    os.environ['PATH'] = test_path
    assert get_bin_path('test') == path_file
    os.environ['PATH'] = old_path

# Generated at 2022-06-20 16:09:34.397980
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('cat')
    assert bin_path and '/bin/cat' in bin_path

    # with optional dirs
    bin_path = get_bin_path('cat', opt_dirs=['/bin', '/usr/bin'])
    assert bin_path and '/bin/cat' in bin_path

    # required executable not found
    try:
        bin_path = get_bin_path('not-found-executable')
        raise Exception('Expected ValueError exception')
    except ValueError:
        pass

# Generated at 2022-06-20 16:09:44.231423
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with no optional arguments
    get_bin_path('ls', None, None)
    # Test with optional arguments
    opt_dirs = ["/usr/bin", "/usr/sbin", "/bin", None, ""]
    get_bin_path('ls', opt_dirs, None)
    # Test with empty arg
    opt_dirs = []
    with pytest.raises(ValueError):
        get_bin_path('', opt_dirs, True)
    # Test with unknown executable
    # On some systems python does not have a versioned name (ex: /usr/bin/python)
    # so test with python that must have a versioned name (ex: /usr/bin/python2.7)
    opt_dirs = ["/usr/bin", "/usr/sbin", "/bin", None, ""]


# Generated at 2022-06-20 16:09:56.468549
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/bin', '/bin']) == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/bin', '/bin', '/usr/bin']) == '/usr/bin/python'
    try:
        get_bin_path('foobar_non_existant_binary')
        assert False
    except ValueError:
        pass
    try:
        get_bin_path('foobar_non_existant_binary', opt_dirs=['/bin', '/bin', '/usr/bin'])
        assert False
    except ValueError:
        pass

# Generated at 2022-06-20 16:10:05.776295
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import sys


# Generated at 2022-06-20 16:10:11.088763
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path.  Try to find dummy executable 'dummy'
    that should exist in current directory.
    '''
    fake_path = os.getcwd()
    my_path = os.environ['PATH']
    try:
        os.environ['PATH'] = fake_path
        bin_path = get_bin_path('dummy')
        assert bin_path == os.path.join(fake_path, 'dummy')
    finally:
        os.environ['PATH'] = my_path

# Generated at 2022-06-20 16:10:15.169269
# Unit test for function get_bin_path
def test_get_bin_path():
    test_bin_path = get_bin_path('ansible')
    if 'ansible' not in test_bin_path.lower():
        raise Exception("Expected test binary path to contain the string 'ansible'.")

# Generated at 2022-06-20 16:10:22.825774
# Unit test for function get_bin_path

# Generated at 2022-06-20 16:10:29.303712
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    from ansible.module_utils.common.file import is_executable

    # If the function raises a valueError, it means that the path doesn't exist.
    # This means that the ASCII art in the welcome message will not be printed.
    # By failing this test, we make sure that the ASCII art is printed properly.
    with pytest.raises(ValueError):
        get_bin_path('echo')

    # Check if the path to the echo executable is correct.
    assert is_executable(get_bin_path('echo'))



# Generated at 2022-06-20 16:10:41.650859
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no_existo')
    except Exception as err:
        assert err.args[0] == 'Failed to find required executable "no_existo" in paths: %s' % os.pathsep.join(os.environ.get('PATH', '').split(os.pathsep))
    else:
        assert False, 'expected ValueError'

    try:
        get_bin_path('no_existo', opt_dirs=['/does/not/exist', None])
    except Exception as err:
        assert err.args[0] == 'Failed to find required executable "no_existo" in paths: /does/not/exist:/'
    else:
        assert False, 'expected ValueError'


# Generated at 2022-06-20 16:10:46.089154
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path as gbp

    assert gbp('/bin/ls') == '/bin/ls'
    assert gbp('ls') == '/bin/ls'
    assert gbp(to_bytes('ls')) == '/bin/ls'
    assert gbp('ls', ['/bin']) == '/bin/ls'

# Generated at 2022-06-20 16:10:51.463098
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/bin/sh') == '/bin/sh'
    try:
        assert get_bin_path('_nonexisting_path')
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "_nonexisting_path" in paths: /sbin:/bin:/usr/sbin:/usr/bin:/usr/local/sbin'

# Generated at 2022-06-20 16:11:00.194140
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == 'python'
    assert get_bin_path('ansible-playbook', opt_dirs=['/usr/bin']) == '/usr/bin/ansible-playbook'
    try:
        get_bin_path('some-nonexistent-command')
    except:
        pass
    else:
        assert False
    try:
        get_bin_path('some-nonexistent-command', required=False)
    except Exception:
        assert True

# Generated at 2022-06-20 16:11:12.447359
# Unit test for function get_bin_path
def test_get_bin_path():
    # Standard executable in path
    assert get_bin_path('ls') == '/bin/ls' or get_bin_path('ls') == '/usr/bin/ls'

    # Relative path ("./")
    relative_path = os.path.dirname(os.path.realpath(__file__)) + './get_bin_path_test'
    assert get_bin_path('./get_bin_path_test') == relative_path

    # Nonexistent executable

# Generated at 2022-06-20 16:11:18.469363
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test OS path is not found
    try:
        get_bin_path("blahblah")
    except Exception as e:
        assert "Failed to find required executable" in str(e)

    # Test OS path is found
    path = get_bin_path("ls")
    assert path
    assert not os.path.isdir(path)
    assert is_executable(path)

# Generated at 2022-06-20 16:11:30.222861
# Unit test for function get_bin_path
def test_get_bin_path():
    # mock the function os.path.exists
    os.path.exists = lambda x: True
    # mock the function is_executable
    is_executable = lambda x: True
    # check the function get_bin_path
    assert get_bin_path('/home/ansible/ansible') == '/home/ansible/ansible'
    os.path.exists = lambda x: False
    # check that exception is raised
    try:
        get_bin_path('/home/ansible/ansible')
        assert False
    except:
        assert True
    # restore functions
    os.path.exists = lambda x: True
    is_executable = lambda x: True
    # check that exception is raised

# Generated at 2022-06-20 16:11:41.109968
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Run unit test for function get_bin_path
    '''
    # get_bin_path for which binary is present in PATH
    try:
        get_bin_path("python")
    except Exception:
        assert False, "get_bin_path failed when binary is present in PATH"

    # get_bin_path for which binary is not present in PATH
    try:
        get_bin_path("ping")
    except Exception:
        assert True, "get_bin_path failed when binary is not present in PATH"

    # get_bin_path with optional argument opt_dirs

# Generated at 2022-06-20 16:11:55.985846
# Unit test for function get_bin_path
def test_get_bin_path():

    import tempfile
    import shutil

    # Setup the temporary directory and add it to the module search path
    tmpdir = tempfile.mkdtemp(prefix='ansible_test_bin_lookup_')
    os.environ['PATH'] = tmpdir + os.pathsep + os.environ['PATH']

    # Create a temporary executable file to test with
    exe_name = 'ansible_test_bin_lookup_exe'
    exe_path = os.path.join(tmpdir, exe_name)

    # Create the test executable
    # NOTE: Change the shebang to the output of `which python` or `python -c "import sys; print(sys.executable)"`
    f = open(exe_path, 'w')
    f.write('#!/usr/bin/python\n')
   

# Generated at 2022-06-20 16:12:05.031620
# Unit test for function get_bin_path
def test_get_bin_path():
    for p in ['/bin/ls', '/usr/bin/ls', '/usr/local/bin/ls', '/sbin/ls', '/usr/sbin/ls', '/usr/local/sbin/ls']:
        if os.path.exists(p) and is_executable(p):
            with open(p, 'r') as f:
                if f.read(2) == '#!':
                    break
    else:
        raise AssertionError('Unable to find suitable executable in /bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin')

    assert get_bin_path('ls') == p


# The following line is for testing only. If python-apt is not installed then
# the rest of this module does not need to be tested.

# Generated at 2022-06-20 16:12:17.201253
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common._collections_compat import Mapping
    import sys

    # choose a shell
    if 'bsd' in sys.platform:
        shell = '/bin/sh'
    else:
        shell = '/bin/bash'

    # check function returns something
    assert get_bin_path(shell) is not None

    # check opt_dirs and extra path
    assert get_bin_path(shell, ['/bin']) == shell
    assert get_bin_path(shell, ['/usr/lib']) is not None

    # check raises exception when not found and required
    try:
        assert get_bin_path(os.path.join('bin', 'huey'), ['/bin']) is None
    except ValueError as e:
        assert 'Failed to find required executable' in str

# Generated at 2022-06-20 16:12:20.390325
# Unit test for function get_bin_path
def test_get_bin_path():
    # test found
    try:
        bin_path = get_bin_path('ls')
        assert bin_path.endswith('/ls')
    except ValueError:
        assert False
    # test not found
    try:
        bin_path = get_bin_path('foo')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-20 16:12:30.770659
# Unit test for function get_bin_path
def test_get_bin_path():
    from tempfile import mkdtemp
    from shutil import rmtree

    test_dir = mkdtemp()
    bin_name = 'test_bin'
    bin_path = os.path.join(test_dir, bin_name)
    if not os.path.exists(bin_path):
        with open(bin_path, 'w') as f:
            f.write('#!/bin/sh\necho foo\n')
        os.chmod(bin_path, 0o777)

    try:
        assert get_bin_path(bin_name, opt_dirs=[test_dir]) == bin_path
    finally:
        rmtree(test_dir)

# Generated at 2022-06-20 16:12:38.964222
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test input values
    try:
        assert get_bin_path(None)
    except ValueError as e:
        assert "Failed to find required executable" in str(e)
    assert get_bin_path("ls") != "ls"
    assert get_bin_path("ls") == "/bin/ls"
    assert get_bin_path("ls", opt_dirs=["/bin", "/sbin"]) == "/bin/ls"
    assert get_bin_path("ls", opt_dirs=["/sbin", "/bin"]) == "/bin/ls"



# Generated at 2022-06-20 16:12:47.790609
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('ls', opt_dirs=[os.path.curdir])
    assert bin_path == os.path.join(os.path.curdir, 'ls'), 'Failed to find executable in "."'

    bin_path = get_bin_path('ls')
    assert bin_path == '/bin/ls', 'Failed to find executable in PATH'

# Generated at 2022-06-20 16:12:54.840265
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic

    # Find /bin/sh using function get_bin_path
    try:
        sh_path = get_bin_path('sh')
    except:
        assert False

    # Change PATH
    os.environ['PATH'] = '/bin'

    # Try to find /bin/sh using function get_bin_path
    try:
        sh_path = get_bin_path('sh')
        assert sh_path == '/bin/sh'
    except:
        assert False

    # Try to find /bin/sh using function basic.get_ex_command
    try:
        sh_path = basic.get_ex_command('sh')
        assert sh_path == '/bin/sh'
    except:
        assert False

# Generated at 2022-06-20 16:12:57.653184
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('thereisnosuchthinganywhere')
        assert False, "thereisnosuchthinganywhere missing, should raise exception"
    except ValueError as e:
        assert "Failed to find required executable" in str(e)



# Generated at 2022-06-20 16:13:00.085054
# Unit test for function get_bin_path
def test_get_bin_path():
    ret = get_bin_path("sh")
    assert ret.endswith("sh")

# Generated at 2022-06-20 16:13:12.921624
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    if PY3:
        # Not currently supported
        return

    module = AnsibleModule({})

# Generated at 2022-06-20 16:13:23.880381
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile

    def test(expected, *args, **kwargs):
        try:
            result = get_bin_path(*args, **kwargs)
            assert result == expected
        except ValueError:
            assert expected is ValueError

    test('/sbin/ping', '/sbin/ping')
    test('/bin/ping', '/bin/ping')
    test('/bin/ping', '/bin/ping', opt_dirs=['/sbin'])

    test(ValueError, 'this-file-does-not-exist')
    test(ValueError, 'this-file-does-not-exist', opt_dirs=['/etc'])

    test('/bin/ping', 'ping')
    test('/bin/ping', 'ping', opt_dirs=['/sbin'])



# Generated at 2022-06-20 16:13:32.256258
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Unit test for function get_bin_path'''
    import subprocess

    def shell_command(cmd):
        '''
        Run given command in shell, return stdout and stderr
        '''
        try:
            p_obj = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
            stdout, stderr = p_obj.communicate()
        except subprocess.CalledProcessError:
            stdout = stderr = None
        return stdout, stderr

    # set PATH
    os.environ['PATH'] = '/tmp'

    # 'which' should return empty if cmd is not in PATH
    cmd = 'which non-existing-cmd'
    shell_stdout, shell_stderr = shell

# Generated at 2022-06-20 16:13:43.505473
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    class PATH_contains(object):
        def __init__(self, path):
            self.path = path

        def __enter__(self):
            self.origin_path = os.environ['PATH']
            os.environ['PATH'] += os.pathsep + self.path

        def __exit__(self, *args):
            os.environ['PATH'] = self.origin_path

    def test_check_output(command):
        return os.path.join(command[0], command[1])

    from ansible.module_utils.common.process import get_bin_path

    with tempfile.TemporaryDirectory() as temporary_directory:
        get_bin_path('doesnotexists')

        # Test negative case

# Generated at 2022-06-20 16:13:44.900301
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sort') == '/usr/bin/sort'

# Generated at 2022-06-20 16:13:48.611477
# Unit test for function get_bin_path
def test_get_bin_path():
    # These are some default path locations that should work for all Unix systems and Windows.
    # This test will fail for Windows if the Windows version of Python is not installed using
    # the setup defaults.
    bin_path = get_bin_path('python')
    assert os.path.exists(bin_path)


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-20 16:13:59.493045
# Unit test for function get_bin_path
def test_get_bin_path():
    test_success_1 = os.path.exists('/bin/ls')
    test_success_2 = os.path.exists('/usr/bin/hostname')
    test_failure_1 = os.path.exists('/bin/fake_file_not_existing')
    test_failure_2 = os.path.exists('/usr/bin/fake_file_not_existing')
    def _paths_equal(p1, p2):
        return os.path.normpath(p1) == os.path.normpath(p2)
    # Test for success cases
    assert(_paths_equal(get_bin_path('ls'), '/bin/ls'))
    assert(_paths_equal(get_bin_path('hostname'), '/usr/bin/hostname'))

# Generated at 2022-06-20 16:14:03.356836
# Unit test for function get_bin_path
def test_get_bin_path():
    # Success
    assert os.path.basename(get_bin_path('python')) == 'python'

    # Failure - was causing exit failure to be logged
    try:
        get_bin_path('this_is_not_a_real_executable_ansible_should_never_find_me')
        # if we get here, exception should have been raised
        assert False
    except ValueError:
        pass

# Generated at 2022-06-20 16:14:11.318138
# Unit test for function get_bin_path
def test_get_bin_path():
    from tempfile import mkdtemp
    cur_dir = os.path.abspath(os.path.curdir)
    bin_path = os.path.join(mkdtemp(), 'foo.sh')
    with open(bin_path, 'w') as f:
        f.write('#!/bin/sh\n')
    os.chmod(bin_path, 0o755)
    try:
        assert get_bin_path('foo.sh', [cur_dir]) == bin_path
    finally:
        os.remove(bin_path)

# Generated at 2022-06-20 16:14:18.203449
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    test_get_bin_path:
          Test functionality of get_bin_path function

          Test assertions:
              Test case 1:
                  Since the PATH environment variable is set to '/bin' by default, get_bin_path returns
                  the path to the test executable which is executed only if found in the path.

              Test case 2:
                  Since the PATH environment variable to is reset to '/sbin' in this test case, the test executable
                  is not found in the path. Hence, the assertion fails with ValueError.

              Test case 3:
                  Since the PATH environment variable is set to '/usr/sbin', the test executable is found in the path.
                  Hence, the assertion succeeds.
    '''
    bin_path = '/bin/true'
    os.environ['PATH'] = '/bin'

# Generated at 2022-06-20 16:14:28.261987
# Unit test for function get_bin_path
def test_get_bin_path():
    cases = [
        ('ls', None, None, '/bin/ls'),
        ('ls', ['/bin'], None, '/bin/ls'),
        ('ls', ['/bin'], True, '/bin/ls'),
    ]
    for arg, opt_dirs, required, expected in cases:
        result = get_bin_path(arg, opt_dirs, required)
        assert result == expected



# Generated at 2022-06-20 16:14:37.617317
# Unit test for function get_bin_path
def test_get_bin_path():

    # -----------------------------------------------------------------------------
    # Test all parameters as expected

    # Test: Executable found in /usr/bin
    try:
        get_bin_path('ls')
    except ValueError:
        raise AssertionError('test_get_bin_path: Unexpectedly failed to find "ls" in "/usr/bin"')

    # Test: Executable found in first optional directory
    try:
        get_bin_path('ls', ['/usr/bin'])
    except ValueError:
        raise AssertionError('test_get_bin_path: Unexpectedly failed to find "ls" in "/usr/bin"')

    # Test: Executable found in second optional directory

# Generated at 2022-06-20 16:14:46.200039
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'

    # Assert that an exception is raised if the arg is not in PATH
    try:
        get_bin_path('arg_not_in_path')
    except ValueError as e:
        # Assert error message is valid
        assert 'Failed to find required executable "arg_not_in_path"' in str(e)
    else:
        # Assert that an Exception was raised if the arg is not in PATH
        assert False

    # assert normal behavior when opt_dirs is specified and arg is in PATH
    assert get_bin_path('ls', opt_dirs=['/']) == '/bin/ls'

    # assert normal behavior when opt_dirs is specified and arg is in opt_dirs

# Generated at 2022-06-20 16:14:55.549990
# Unit test for function get_bin_path
def test_get_bin_path():
    real_path = get_bin_path('python')
    assert os.path.exists(real_path) and not os.path.isdir(real_path) and is_executable(real_path)

    # Test supplemental paths
    fake_path = os.path.join(os.path.dirname(__file__), 'fake_bin')
    fake_path = os.path.abspath(fake_path)
    assert fake_path not in os.environ['PATH'].split(os.pathsep)
    real_path = get_bin_path('python', [fake_path])
    assert real_path == os.path.join(fake_path, 'python')

    # Test for invalid path