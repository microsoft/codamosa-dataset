

# Generated at 2022-06-20 16:05:04.987036
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile

    def touch(path):
        with open(path, 'a'):
            os.utime(path, None)

    # Test that the function raises ValueError if the executable is not found
    try:
        get_bin_path('not-existing-command')
    except ValueError as exc:
        pass
    else:
        assert False, 'ValueError not raised'

    # Test that the function returns the full path of a command if found
    temp_dir = tempfile.mkdtemp(dir='/tmp')
    test_command = 'test_command'

# Generated at 2022-06-20 16:05:08.015994
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ['PATH'] = "/bin:/usr/bin"
    try:
        get_bin_path('ansible-galaxy', required=False)
    except Exception as e:
        assert "Failed to find required executable \"ansible-galaxy\" in paths: /bin:/usr/bin" == str(e)
    else:
        assert 1 == 0

# Generated at 2022-06-20 16:05:15.292863
# Unit test for function get_bin_path
def test_get_bin_path():
    # In the unit test we force PATH to a single location that contains the
    # required files. We then assert that we find this file. Then we also
    # assert that we do not find another file that is not there.
    os.environ['PATH'] = '/bin'
    assert os.environ.get('PATH') == '/bin'
    assert get_bin_path('ls') == '/bin/ls'
    try:
        get_bin_path('blah')
    except ValueError as e:
        assert 'Failed to find required executable "blah" in paths: /bin' in str(e)

# Generated at 2022-06-20 16:05:18.306079
# Unit test for function get_bin_path
def test_get_bin_path():
    cc = get_bin_path('cc')
    assert 'cc' in cc
    assert is_executable(cc)

    try:
        get_bin_path('bogus-command-that-does-not-exist')
    except ValueError:
        pass
    else:
        assert False, 'get_bin_path should have raised an exception when the command does not exist'

# Generated at 2022-06-20 16:05:23.900722
# Unit test for function get_bin_path
def test_get_bin_path():
    assert (is_executable(get_bin_path('ls')) == True)
    assert (is_executable(get_bin_path('ls', ["/bin"])) == True)
    try:
        get_bin_path('ls_dne', ["/bin"])
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-20 16:05:32.035129
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        os.remove('/tmp/bin_path.test')
    except OSError:
        pass
    os.symlink('/bin/ls', '/tmp/bin_path.test')
    assert get_bin_path('bin_path.test', opt_dirs=['/tmp']) == '/tmp/bin_path.test'
    os.remove('/tmp/bin_path.test')



# Generated at 2022-06-20 16:05:34.383085
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python') != '/usr/bin'
    assert get_bin_path('does_not_exist')

# Generated at 2022-06-20 16:05:45.439826
# Unit test for function get_bin_path
def test_get_bin_path():
    script_dir = os.path.dirname(os.path.realpath(__file__))
    sample_bin_dir = os.path.join(script_dir, 'sample_bin')
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=[sample_bin_dir]) == os.path.join(sample_bin_dir, 'sh')
    assert get_bin_path('sh', opt_dirs=['/not/existing/dir', sample_bin_dir]) == os.path.join(sample_bin_dir, 'sh')
    try:
        get_bin_path('not_existing_command')
        assert False, 'get_bin_path() should raise ValueError if command not found'
    except ValueError:
        pass

# Generated at 2022-06-20 16:05:46.697295
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path("python")
    assert path.endswith("python")

# Generated at 2022-06-20 16:05:54.355697
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test module get_bin_path
    '''
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    import sys
    import unittest

    # Create a test class object
    class AnsibleModuleTest(unittest.TestCase):

        # Create a setUp function
        def setUp(self):
            '''
            Function to run before each test case
            '''
            pass

        # Create a tearDown function
        def tearDown(self):
            '''
            Function to run after each test case
            '''
            pass

        # Create a test case function
        def test_get_bin_path(self):
            '''
            Function to test the get_bin_path function
            '''
            # Mock stdout
            stdout = sys

# Generated at 2022-06-20 16:05:57.745645
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-20 16:06:03.783514
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/usr/local/bin']) == '/usr/local/bin/sh'
    import pytest
    with pytest.raises(ValueError):
        get_bin_path('sh', ['/usr/local/bin'], required=True)
    with pytest.raises(ValueError):
        get_bin_path('/usr/local/bin/sh')

# Generated at 2022-06-20 16:06:05.484022
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('ls')

# Generated at 2022-06-20 16:06:10.921516
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert get_bin_path('python2') == '/usr/bin/python2'
    except ValueError:
        assert get_bin_path('python2', ['/usr/bin']) == '/usr/bin/python2'
    finally:
        assert get_bin_path('python2', ['/usr/bin']) == '/usr/bin/python2'

    try:
        assert get_bin_path('sh') == '/bin/sh'
    except ValueError:
        assert get_bin_path('sh', ['/bin']) == '/bin/sh'
    finally:
        assert get_bin_path('sh', ['/bin']) == '/bin/sh'

    try:
        assert get_bin_path('__non_existant_command__') == None
    except ValueError:
        assert get

# Generated at 2022-06-20 16:06:13.604998
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Return paths of executables in /bin, /usr/bin, /usr/local/bin.
    '''
    bin_paths = []
    for d in ['/bin', '/usr/bin', '/usr/local/bin']:
        for f in os.listdir(d):
            bin_paths.append(os.path.join(d, f))
    return bin_paths


# Generated at 2022-06-20 16:06:23.044462
# Unit test for function get_bin_path
def test_get_bin_path():
    import platform

    # get_bin_path should work for Linux and BSD systems
    if platform.system() == 'Linux' or platform.system() == 'Darwin':
        # Test basics of get_bin_path
        try:
            # get_bin_path should raise an exception for a non-existent argument
            get_bin_path('nonexistent-executable')
            assert False
        except ValueError:
            pass
    else:
        # Do not test non-Unix systems
        pass

# Generated at 2022-06-20 16:06:35.868995
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestGetBinPath(unittest.TestCase):
        '''
        unittest class to test the get_bin_path function
        '''
        def setUp(self):
            # Make sure PATH contains at least one path.
            self.mock_path = os.path.join(os.path.dirname(__file__), '.mock_path')
            self.old_path = os.environ['PATH']
            os.environ['PATH'] = self.mock_path

        def tearDown(self):
            # Restore PATH.
            os.environ['PATH'] = self.old_path


# Generated at 2022-06-20 16:06:37.846536
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('false')
    except ValueError:
        pass

# Generated at 2022-06-20 16:06:47.890234
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_paths = []
    bin_paths.append(get_bin_path('ansible'))
    bin_paths.append(get_bin_path('ansible', opt_dirs=[]))
    bin_paths.append(get_bin_path('tar', opt_dirs=['/usr/bin']))

    # Ensure all elements in the returned array are equal to each other.
    assert bin_paths.count(bin_paths[0]) == len(bin_paths)

    # Ensure the file exists and is executable
    assert os.path.exists(bin_paths[0]) and os.access(bin_paths[0], os.X_OK)

    # If the file does not exist, it should raise a ValueError

# Generated at 2022-06-20 16:06:56.658737
# Unit test for function get_bin_path
def test_get_bin_path():
    from distutils.spawn import find_executable
    import tempfile
    import os
    import shutil


# Generated at 2022-06-20 16:07:01.798306
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('which') == get_bin_path('which', [])
    assert get_bin_path('which', ['/bin']) == '/bin/which'
    try:
        get_bin_path('i-should-not-exist')
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-20 16:07:12.151373
# Unit test for function get_bin_path
def test_get_bin_path():

    test_dir = "/tmp/test"

    try:
        os.makedirs(os.path.join(test_dir,"bin"))
        with open(os.path.join(test_dir,"bin","foo"), "w") as fp:
            fp.write("#!/bin/sh\necho foo")
        os.chmod(os.path.join(test_dir,"bin","foo"), 0o755)

        os.environ["PATH"] = test_dir + os.pathsep + os.environ["PATH"]
        path = get_bin_path("foo")
        assert os.path.exists(path)
        assert path == os.path.join(test_dir,"bin","foo")
    finally:
        os.unlink(os.path.join(test_dir,"bin","foo"))
       

# Generated at 2022-06-20 16:07:18.598026
# Unit test for function get_bin_path
def test_get_bin_path():
    if not is_executable('/bin/bash'):
        raise Exception('Bash does not exist')

    bash_bin = get_bin_path('bash')

    if bash_bin != '/bin/bash':
        raise Exception('get_bin_path did not retrieve bash binary: %s' % bash_bin)

# Generated at 2022-06-20 16:07:28.650272
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import os
    import tempfile

    test_path = tempfile.mkdtemp(prefix='ansible-test')
    sys_path = [test_path, os.path.join(test_path, 'bin'), os.path.join(test_path, 'sbin')]
    os.makedirs(sys_path[1])
    os.makedirs(sys_path[2])
    sys.path += sys_path
    f = tempfile.NamedTemporaryFile(dir=sys_path[0], delete=False)


# Generated at 2022-06-20 16:07:35.108540
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function
    '''
    dir_name = 'test_file_exists_directory'
    file_name = 'test_file_exists_file'
    try:
        os.mkdir(dir_name)
        open(os.path.join(dir_name, file_name), 'a').close()
        os.environ['PATH'] = os.pathsep.join((os.getcwd(), dir_name))
        assert get_bin_path(file_name) == os.path.join(dir_name, file_name)
    finally:
        os.remove(os.path.join(dir_name, file_name))
        os.rmdir(dir_name)

# Generated at 2022-06-20 16:07:40.307911
# Unit test for function get_bin_path

# Generated at 2022-06-20 16:07:43.400653
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = ['/usr/bin/python', '/bin/python']
    x = get_bin_path('python', opt_dirs=bin_path)
    assert x == bin_path[0]

# Generated at 2022-06-20 16:07:48.553152
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 'ls' == os.path.basename(get_bin_path('ls'))
    try:
        get_bin_path('this-file-does-not-exist')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-20 16:07:53.050159
# Unit test for function get_bin_path
def test_get_bin_path():
    executable = 'python'
    try:
        get_bin_path(executable)
    except ValueError:
        assert False, 'Found executable which is not in the path'
    else:
        assert True

# Generated at 2022-06-20 16:08:04.510845
# Unit test for function get_bin_path
def test_get_bin_path():
    # Success with required executable (non-absolute path) in PATH
    path = get_bin_path('sh')
    assert is_executable(path)
    assert any(os.access(os.path.join(path, os.path.basename(path)), os.X_OK) for path in os.environ["PATH"].split(os.pathsep))

    # Success with required executable (non-absolute path) in opt_dirs
    path = get_bin_path('sh', opt_dirs=['/bin/'])
    assert is_executable(path)
    assert os.access(os.path.join(path, os.path.basename(path)), os.X_OK)

    # Success with required executable (absolute path) in opt_dirs

# Generated at 2022-06-20 16:08:11.520216
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('no_such_file', required=False) is None
    try:
        get_bin_path('no_such_file')
        assert False, 'no Exception'
    except ValueError:
        pass



# Generated at 2022-06-20 16:08:16.601016
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test standard executables that should be found
    for exe in ['ls', 'cat', 'pwd']:
        p = get_bin_path(exe)
        assert p is not None and is_executable(p)

    # Test executable that may not be found
    if os.path.exists('/bin/foobar'):
        p = get_bin_path('foobar')
        assert p is None

# Generated at 2022-06-20 16:08:25.338325
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path("this_does_not_exist")
        assert False, '"this_does_not_exist" should not exist'
    except ValueError:
        pass

    try:
        get_bin_path("ansible-module-runner")
        assert False, '"ansible-module-runner" should not exist'
    except ValueError:
        pass

    get_bin_path("ls")

    current_dir = os.path.dirname(os.path.abspath(__file__))
    get_bin_path("ls", opt_dirs=[current_dir])

# Generated at 2022-06-20 16:08:36.089750
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    @return: True if test passes, otherwise False
    """
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.module_utils._text import to_bytes

    base_dir = mkdtemp()
    base_dir = to_bytes(base_dir, errors='surrogate_or_strict')
    bin_dir = os.path.join(base_dir, "bin")
    os.mkdir(bin_dir)
    bin_file = os.path.join(bin_dir, "test")
    with open(bin_file, 'wb') as f:
        f.write(to_bytes('#!/bin/sh'))
    os.chmod(bin_file, 0o755)

    test_pass = True

# Generated at 2022-06-20 16:08:40.633061
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check executable in path
    get_bin_path('ansible', ['/usr/bin'])

    # Check executable in opt_dir
    get_bin_path('ansible', ['/some/path'])

    # Check executable in sbin
    get_bin_path('route', ['/usr/bin'])

# Generated at 2022-06-20 16:08:52.641530
# Unit test for function get_bin_path

# Generated at 2022-06-20 16:08:56.223147
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('hostname') == get_bin_path('hostname', required=True))

# Generated at 2022-06-20 16:08:58.070864
# Unit test for function get_bin_path
def test_get_bin_path():
    expected = '/bin/ls'
    assert get_bin_path('ls') == expected



# Generated at 2022-06-20 16:09:07.885379
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.file import which

    # Find a valid path to the ping binary on the system
    ping_bin = which('ping')

    # Ensure that we found a binary
    assert ping_bin is not None

    # Ensure that the binary is executable
    assert os.access(ping_bin, os.X_OK)

    # Ensure that we can find ping in the path if it exists
    assert get_bin_path('ping') == ping_bin

    # Ensure that we find ping even if we add an option
    assert get_bin_path('ping', opt_dirs=['/bin']) == ping_bin

    # Ensure that we can find ping even if we tell get_bin_path not to look
    # in a folder that contains it

# Generated at 2022-06-20 16:09:17.954169
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/bin/ls', required=True)
    except:
        assert False, 'test failed for /bin/ls'

    try:
        get_bin_path('/bin/not_exist', required=True)
        assert False, 'test for non-existing binary failed'
    except:
        pass

    try:
        get_bin_path('/bin/ls', required=True, opt_dirs=['/etc', '/bin'])
    except:
        assert False, 'test failed for /bin/ls with opt_dirs set to /etc, /bin'


# Generated at 2022-06-20 16:09:30.538221
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # empty path, python
    os.environ['PATH'] = ''
    try:
        path = get_bin_path('python')  # Should raise ValueError
        assert False
    except ValueError:
        pass

    # non-existing path, python
    os.environ['PATH'] = '/a/b/c/d'
    try:
        path = get_bin_path('python')  # Should raise ValueError
        assert False
    except ValueError:
        pass

    # existing, valid path, python
    os.environ['PATH'] = '/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin'
    path = get_bin_path('python')
    assert path == '/usr/bin/python'

    # existing, invalid path,

# Generated at 2022-06-20 16:09:36.099579
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('yum') is not None
    assert get_bin_path('foobar') is None

    # Test optional arguments
    assert get_bin_path('yum', ['/not/a/path']) is not None

# Generated at 2022-06-20 16:09:46.373267
# Unit test for function get_bin_path
def test_get_bin_path():
    import mock
    import sys
    if sys.version_info[0] < 3:
        builtin_module_name = '__builtin__'
    else:
        builtin_module_name = 'builtins'

    def fake_os_path_exists(path):
        return path == "test_path"

    def fake_os_path_isdir(path):
        return path == "test_path"

    def fake_is_executable(path):
        return path == "test_path"


# Generated at 2022-06-20 16:09:51.524868
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.path.exists('/bin/sh'):
        assert get_bin_path('sh') == '/bin/sh'
    if os.path.exists('/usr/bin/python'):
        assert get_bin_path('python') == '/usr/bin/python'



# Generated at 2022-06-20 16:10:01.876565
# Unit test for function get_bin_path
def test_get_bin_path():
    # Paths should be split
    paths = os.environ.get('PATH', '').split(os.pathsep)
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin']) in ['/bin/ls', '/usr/bin/ls']
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin', '/nonexistent']) in ['/bin/ls', '/usr/bin/ls']
    assert get_bin_path('ls', opt_dirs=['/nonexistent', '/usr/bin', '/bin']) in ['/bin/ls', '/usr/bin/ls']

# Generated at 2022-06-20 16:10:08.352000
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('expect', required=False)
    except ValueError:
        pass
    else:
        assert False
    try:
        get_bin_path('expect_not_found')
    except ValueError:
        pass
    else:
        assert False
    assert get_bin_path('expect', opt_dirs='/usr/bin') == '/usr/bin/expect'
    assert get_bin_path('expect', opt_dirs='/usr/bin', required=True) == '/usr/bin/expect'
    assert get_bin_path('expect', opt_dirs=['/usr/bin'], required=True) == '/usr/bin/expect'

# Generated at 2022-06-20 16:10:19.464756
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test first without any optional paths
    test_path = get_bin_path('sort')
    assert os.path.exists(test_path)

    # Test with optional paths
    test_path = get_bin_path('sort', ['/bin', '/usr/bin'])
    assert os.path.exists(test_path)

    # Test with optional path that does not exist
    test_path = get_bin_path('sort', ['/does_not_exist'])
    assert not os.path.exists(test_path)

    # Test with optional directory that is not on PATH
    test_path = get_bin_path('sort', ['/tmp', '/var/tmp'])
    assert not os.path.exists(test_path)

    # Test with optional path that exists, but has no sort executable
    test

# Generated at 2022-06-20 16:10:29.040246
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with None
    try:
        get_bin_path(None)
        assert False, 'This statement should not be reached'
    except ValueError:
        pass

    # Test with non-existing executable
    try:
        get_bin_path('non-existing_executable')
        assert False, 'This statement should not be reached'
    except ValueError:
        pass

    # Test with existing executable
    ret = get_bin_path('ls')
    assert ret.endswith('ls'), 'ls executable should be found'

    # Test with existing executable, given in extra directories
    ret = get_bin_path('ls', opt_dirs=['/bin', '/usr/bin'])
    assert ret.endswith('ls'), 'ls executable should be found'

    # Test with /sbin directory in PATH, check that

# Generated at 2022-06-20 16:10:41.649804
# Unit test for function get_bin_path
def test_get_bin_path():
    import os

    if os.name != "posix":
        return

    sys_bin_dirs = [
        '/bin',
        '/usr/bin',
        '/usr/local/bin',
    ]
    sys_bin_dirs.append('/'.join(get_bin_path('sh').split(os.sep)[:-1]))
    assert get_bin_path('sh', sys_bin_dirs) == get_bin_path('sh', sys_bin_dirs)
    assert get_bin_path('sh', sys_bin_dirs) == '/bin/sh'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=[]) == '/bin/sh'

# Generated at 2022-06-20 16:10:50.440376
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.file import md5

    md5_bin = '/sbin/md5'
    md5sum_bin = '/usr/bin/md5sum'

    if is_executable(md5_bin):
        bin_path = get_bin_path('md5')
        assert bin_path is not None
        assert os.path.exists(bin_path)
        assert not os.path.isdir(bin_path)
        assert is_executable(bin_path)
        assert bin_path == md5_bin
        assert md5(bin_path) == md5(md5_bin)
        assert to_bytes(md5(bin_path)) == to_bytes(md5(md5_bin))


# Generated at 2022-06-20 16:11:02.843471
# Unit test for function get_bin_path
def test_get_bin_path():
    # expected binary in system path
    bin_path = get_bin_path('ls')
    assert bin_path == '/bin/ls'

    # expected binary in system path, tested with deprectated parmeter
    bin_path = get_bin_path('ls', required=True)
    assert bin_path == '/bin/ls'

    # expected binary in /sbin, tested with deprectated parmeter
    bin_path = get_bin_path('ifconfig', required=True)
    assert bin_path == '/sbin/ifconfig'

    # expected binary in custom path
    bin_path = get_bin_path('test', opt_dirs=['/usr/bin'])
    assert bin_path == '/usr/bin/test'

    # expected binary in multiple custom paths

# Generated at 2022-06-20 16:11:11.170346
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for function get_bin_path
    '''
    import tempfile
    import shutil
    import os

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = tempfile.NamedTemporaryFile(delete=False, dir=tmp_dir)
        tmp_file.close()
        os.chmod(tmp_file.name, 0o755)
        new_PATH = tmp_dir + os.pathsep + os.environ.get('PATH', '')
        os.environ['PATH'] = new_PATH

        try:
            assert get_bin_path(os.path.basename(tmp_file.name)) == tmp_file.name
        finally:
            del os.environ['PATH']
            shutil.rmtree(tmp_dir)

# Generated at 2022-06-20 16:11:21.093312
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Function get_bin_path unit test.
    '''
    import os
    import random
    import string
    import tempfile
    import unittest

    class TestGetBinPath(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.test_exec = os.path.join(self.tempdir, 'test_exec')

        def _test(self, path):
            bin_path = get_bin_path(self.test_exec, opt_dirs=[path])
            self.assertEqual(os.path.join(path, self.test_exec), bin_path)

        def test_in_temp(self):
            self._test(self.tempdir)


# Generated at 2022-06-20 16:11:23.290146
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('whoami') == '/usr/bin/whoami' or get_bin_path('whoami') == '/bin/whoami'

# Generated at 2022-06-20 16:11:34.863081
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('true') == '/bin/true'
    assert get_bin_path('false') == '/bin/false'
    assert get_bin_path('ls', ['/bin']) == '/bin/ls'

    try:
        assert get_bin_path('false', ['/bin']) == '/bin/false'
    except ValueError as e:
        pass
    else:
        assert False, 'ValueError not raised'

    try:
        assert get_bin_path('true', ['/no/such/path']) == '/bin/true'
    except ValueError as e:
        pass
    else:
        assert False, 'ValueError not raised'


# Generated at 2022-06-20 16:11:41.364994
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/bin/ls' == get_bin_path('ls')
    assert '/bin/ls' == get_bin_path('ls', [])
    assert '/bin/ls' == get_bin_path('ls', ['/bin'])
    try:
        get_bin_path('foo_bar')
        assert False, 'Expected ValueError'
    except ValueError as e:
        assert 'Failed to find required executable "foo_bar" in paths: ' in str(e)

# Generated at 2022-06-20 16:11:53.330125
# Unit test for function get_bin_path
def test_get_bin_path():
    path_orig = os.environ.get('PATH', '')
    cur_dir = os.path.abspath(os.path.dirname(__file__))
    sbin_dir = os.path.join(cur_dir, 'fixtures/sbin')

# Generated at 2022-06-20 16:12:01.164170
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', ['/bin', '/sbin']) == '/bin/ls'
    try:
        get_bin_path('boguscommand')
    except ValueError:
        pass
    else:
        assert False, 'should have raised a ValueError exception'



# Generated at 2022-06-20 16:12:09.922269
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat')
    assert get_bin_path('bash')
    try:
        get_bin_path('no_such_binary')
    except ValueError:
        assert True
    else:
        assert False
    assert get_bin_path('pwd', opt_dirs='/bin')
    assert get_bin_path('ssh', opt_dirs='/usr/bin')

    try:
        get_bin_path('no_such_binary', opt_dirs='/bin')
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-20 16:12:21.403028
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test existing executable in PATH.
    # PATH contains /bin, /sbin, /usr/bin, /usr/sbin
    assert get_bin_path('sh') == '/bin/sh'
    # Test existing executable in PATH.
    assert get_bin_path('boh') == '/sbin/boh'
    # Test executable with relative path.
    assert get_bin_path('./boh2') == './boh2'
    # Test executable with absolute path
    assert get_bin_path('/bin/boh2') == '/bin/boh2'
    # Test executable with optional directory
    assert get_bin_path('boh3', opt_dirs=['/usr/local/bin']) == '/usr/local/bin/boh3'
    # Test executable with optional directories where one path contains the

# Generated at 2022-06-20 16:12:30.047565
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-20 16:12:37.757587
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for successful match
    try:
        r = get_bin_path('ls')
        assert r is not None
    except ValueError:
        assert False

    # Test for unsuccessful match
    try:
        r = get_bin_path('no_such_command')
        assert False
    except ValueError:
        assert True

    # Test additional user provided paths
    try:
        r = get_bin_path('echo', opt_dirs=['/bin', '/usr/bin'])
        assert r is not None
    except ValueError:
        assert False



# Generated at 2022-06-20 16:12:39.642115
# Unit test for function get_bin_path
def test_get_bin_path():
    # Make sure we can find the python executable
    get_bin_path('python')

# Generated at 2022-06-20 16:12:51.873323
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()

    assert os.path.exists(get_bin_path('sh', []))
    assert os.path.exists(get_bin_path('sh'))

    non_existing_path = os.path.join(test_dir, 'non_existing_path')
    with open(os.path.join(test_dir, 'non_existing'), 'w') as f:
        assert f.write('echo "This is not execuetable"')
    os.chmod(os.path.join(test_dir, 'non_existing'), 0)


# Generated at 2022-06-20 16:12:55.369415
# Unit test for function get_bin_path
def test_get_bin_path():
    # get_bin_path should always raise an exception if an executable is not found
    bin_path = get_bin_path('foo', opt_dirs=[os.path.abspath('./bin')])
    assert bin_path == os.path.join(os.path.abspath('./bin'), 'foo')

# Generated at 2022-06-20 16:13:06.878414
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import platform

    # For binary names in PATH
    assert get_bin_path('python') == sys.executable
    if platform.system() != 'Windows':
        assert get_bin_path('ls') == '/bin/ls'

    # For binary paths in PATH
    assert get_bin_path(sys.executable) == sys.executable
    if platform.system() != 'Windows':
        assert get_bin_path('/bin/ls') == '/bin/ls'

    # For binary names not in PATH
    try:
        get_bin_path('this_bin_does_not_exist')
    except ValueError:
        pass
    else:
        assert False

    # For binary paths not in PATH

# Generated at 2022-06-20 16:13:14.910716
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Test for get_bin_path'''

    # Check that it raises when not found
    try:
        get_bin_path("NotExistingExecutable")
    except ValueError as e:
        assert "not found" in str(e)
    else:
        assert False

    # Check that it raises when not executable
    try:
        get_bin_path("README.md")
    except ValueError as e:
        assert "executable" in str(e)
    else:
        assert False

    # Check that it raise when existing but directory
    try:
        get_bin_path("test")
    except ValueError as e:
        assert "executable" in str(e)
    else:
        assert False

    # Check that it can find one of the many executables
    bin_path = get_bin

# Generated at 2022-06-20 16:13:24.660880
# Unit test for function get_bin_path
def test_get_bin_path():
    def mock_is_executable(file):
        return file in ['/bin/python', '/bin/python2', '/bin/python2.7', '/bin/python2.7.5']

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.file import is_executable

    # if no path exists, file not found
    assert get_bin_path('python') == '/bin/python'
    assert get_bin_path('python2.7') == '/bin/python2.7'
    # can't find python3

# Generated at 2022-06-20 16:13:31.334726
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test assert with expected success
    assert get_bin_path('/bin/echo') == '/bin/echo'
    assert get_bin_path('/bin/echo', opt_dirs=[]) == '/bin/echo'
    # Test assert with expected error
    try:
        get_bin_path('/bin/echo', opt_dirs=['/dir_doesnt_exist'])
    except ValueError as e:
        assert e.args[0] == 'Failed to find required executable "/bin/echo" in paths: /bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:/dir_doesnt_exist'

# Generated at 2022-06-20 16:13:34.378546
# Unit test for function get_bin_path
def test_get_bin_path():

    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-20 16:13:52.517038
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import pytest
    if sys.platform == 'win32':
        pytest.skip('Skipping test for windows')
    assert get_bin_path('ls')

# Generated at 2022-06-20 16:14:01.715616
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = os.environ.get('PATH', '').split(os.pathsep)
    # Test that a required path that exists succeeds
    get_bin_path('echo', required=True)
    # Test that a required path that does not exist fails
    try:
        get_bin_path('/this/path/does/not/exist', required=True)
    except ValueError:
        pass
    else:
        assert False, 'Expected exception'
    # Test that a non required path that does not exist returns None
    assert get_bin_path('/this/path/does/not/exist', required=False) is None
    # Test with an absolute path
    assert get_bin_path('/bin/echo') == '/bin/echo'
    # Test with a relative path

# Generated at 2022-06-20 16:14:06.290449
# Unit test for function get_bin_path
def test_get_bin_path():
    # Execute the function
    bin_path = get_bin_path('python')
    # Validate
    assert os.path.exists(bin_path)
    assert os.path.isfile(bin_path)
    assert is_executable(bin_path)

# Generated at 2022-06-20 16:14:14.777661
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('/bin/echo')
    assert path == '/bin/echo'

    path = get_bin_path('echo', opt_dirs=['/bin'])
    assert path == '/bin/echo'

    path = get_bin_path('/sbin/fstyp')
    assert path == '/sbin/fstyp'

    path = get_bin_path('fstyp', opt_dirs=['/sbin'])
    assert path == '/sbin/fstyp'

    path = get_bin_path('fstyp', opt_dirs=['/sbin', '/bin'])
    assert path == '/sbin/fstyp'

    try:
        get_bin_path('not-found')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-20 16:14:25.615053
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import platform

    bin_names = ('foo', 'bar', 'baz')
    path = tempfile.mkdtemp()
    for b in bin_names:
        # Create executable file
        f = open(os.path.join(path, b), 'w')
        f.write('#!/bin/sh')
        f.close()
        os.chmod(os.path.join(path, b), 0o755)

    # Get original PATH
    orig_paths = os.environ.get('PATH', '').split(os.pathsep)
    # Add temp dir to PATH
    os.environ['PATH'] = os.pathsep.join([path] + orig_paths)

    # Test valid names

# Generated at 2022-06-20 16:14:31.026360
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test finds ls in PATH
    bin_path = get_bin_path("ls")
    assert(os.path.exists(bin_path))
    assert(is_executable(bin_path))

    # Test no_log is False
    bin_path = get_bin_path("ls")
    assert(os.path.exists(bin_path))
    assert(is_executable(bin_path))

    # Test with option /sbin in PATH
    bin_path = get_bin_path("ip")
    assert(os.path.exists(bin_path))
    assert(is_executable(bin_path))

    # Test with opt_dirs set
    bin_path = get_bin_path("ifconfig", opt_dirs="/sbin")

# Generated at 2022-06-20 16:14:38.189436
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    import textwrap

    python = shutil.which('python')

    # create dummy executable
    f, tmp = tempfile.mkstemp()
    os.write(f, textwrap.dedent('''#!/bin/sh
    echo "Hello World"
    ''').encode('utf-8'))
    os.close(f)
    os.chmod(tmp, 0o700)
    assert os.path.exists(tmp)

    # create fake PATH that does not contain python
    tmp_path = tempfile.mkdtemp()
    os.environ['PATH'] = tmp_path
    # remove PATH from os.environ before exiting

# Generated at 2022-06-20 16:14:46.502904
# Unit test for function get_bin_path
def test_get_bin_path():
    # test where it should find a valid executable in the path
    my_bin_path = get_bin_path('ls', opt_dirs=['/bin'])
    assert my_bin_path == '/bin/ls'

    # test where the executable should be found in the path
    my_bin_path = get_bin_path('ls', opt_dirs=['/usr/bin'])
    assert my_bin_path in ['/bin/ls', '/usr/bin/ls']

    # test when opt_dirs is not passed it and the executable should be found in the path
    my_bin_path = get_bin_path('ls')
    assert my_bin_path in ['/bin/ls', '/usr/bin/ls']

    # test when opt_dirs is passed and the executable is not found

# Generated at 2022-06-20 16:14:55.784560
# Unit test for function get_bin_path
def test_get_bin_path():
    # Setup
    test_paths = ['/tmp', '/var', '/usr/local/bin']
    test_path = None
    # Test os.pathsep to be defined
    assert(os.pathsep is not None)
    for tp in test_paths:
        if os.path.exists(tp) and 'PATH' in os.environ:
            os.environ['PATH'] = os.pathsep.join(test_paths)
            break
        else:
            test_path = '/home'
            os.environ['PATH'] = '/home'
    assert(test_path is not None)
    # Test get_bin_path
    assert(get_bin_path('/usr/bin/id', opt_dirs=[]) is not None)