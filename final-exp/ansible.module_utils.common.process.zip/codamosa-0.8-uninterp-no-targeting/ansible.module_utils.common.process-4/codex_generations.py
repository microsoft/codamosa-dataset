

# Generated at 2022-06-20 16:04:59.916015
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('cp')
    assert(bin_path is not None)
    assert('/bin/cp' == bin_path)

    try:
        get_bin_path('this_does_not_exist')
        assert(1 == 0)
    except ValueError:
        pass  # Expected

    bin_path = get_bin_path('cp', opt_dirs=['/usr/bin'])
    assert(bin_path is not None)
    assert('/usr/bin/cp' == bin_path)

# Generated at 2022-06-20 16:05:10.217697
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test of function get_bin_path
    '''
    import platform

    if platform.system() == 'Windows':
        assert get_bin_path('cmd.exe', [os.environ.get('SYSTEMROOT', 'C:\\Windows'), 'C:\\Windows\\System32']) == 'C:\\Windows\\System32\\cmd.exe'
    elif platform.system() == 'FreeBSD':
        assert get_bin_path('sh') == '/bin/sh'
        assert get_bin_path('/bin/sh') == '/bin/sh'
        assert get_bin_path('/usr/sbin/mount', ['/usr/local/sbin']) == '/usr/local/sbin/mount'

# Generated at 2022-06-20 16:05:13.216194
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    get_bin_path return full path to system executable.
    '''
    bin_path = get_bin_path('python')

    assert bin_path == get_bin_path('python')

# Generated at 2022-06-20 16:05:18.915204
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path("ls", required=True)
    assert bin_path.endswith("ls")

# Generated at 2022-06-20 16:05:25.328629
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('some_unlikely_file_name_that_will_not_exist')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    ret = get_bin_path('env', opt_dirs=['/usr/bin'])
    assert ret == '/usr/bin/env'
    os.environ['PATH'] = '/bin:/usr/bin'
    ret = get_bin_path('env', required=True)
    assert ret == '/usr/bin/env'

# Generated at 2022-06-20 16:05:32.962582
# Unit test for function get_bin_path
def test_get_bin_path():
    # paths that should be present in PATH
    bin_path = get_bin_path('sh')
    assert os.path.exists(bin_path)
    assert is_executable(bin_path)

    # path that will not be found in PATH
    try:
        get_bin_path('/usr/bin/no-such-path')
    except ValueError as e:
        assert 'Failed to find' in str(e)
    else:
        assert False, 'Expected a ValueError Exception.'

# Generated at 2022-06-20 16:05:34.419128
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    basic usage test
    '''

    assert get_bin_path('true') == '/bin/true'

# Generated at 2022-06-20 16:05:40.757877
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('ls')
    try:
        get_bin_path('spongebob')
    except ValueError:
        pass
    else:
        raise AssertionError('expected ValueError')
    get_bin_path('ls', opt_dirs=['/usr/bin'])
    try:
        get_bin_path('ls', opt_dirs=['/usr/bin'], required=True)
    except ValueError:
        raise AssertionError('expected no ValueError')

# Generated at 2022-06-20 16:05:42.689383
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh')

# Generated at 2022-06-20 16:05:46.228438
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('ansible-doc')
    except Exception:
        assert False, "ansible-doc not found on current path."

    try:
        get_bin_path('ansible-doc',['/usr/bin'])
    except Exception:
        assert False, "ansible-doc not found on current path and /usr/bin."

    try:
        get_bin_path('ansible-doc',['/invalid/path'])
        assert False, "Exception not raised."
    except Exception:
        pass

# Generated at 2022-06-20 16:05:56.713386
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('sh', required=False) == '/bin/sh')
    assert(get_bin_path('sh', opt_dirs=['/bin', '/sbin'], required=False) == '/bin/sh')
    assert(get_bin_path('sh', opt_dirs=['/sbin', '/bin'], required=False) == '/sbin/sh')
    try:
        get_bin_path('nonexistent', required=True)
        assert(False)
    except ValueError:
        pass

# Generated at 2022-06-20 16:06:04.836602
# Unit test for function get_bin_path
def test_get_bin_path():
    dir = os.path.dirname(os.path.realpath(__file__))
    c = 'test_ansible_module_utils_get_bin_path.py'
    p = os.path.join(dir, c)
    assert is_executable(p)
    assert get_bin_path(c, [dir]) == p
    assert get_bin_path('/bin/sh', [dir]) == '/bin/sh'  # path already absolute
    ## Only absolute paths
    assert get_bin_path('.', [dir]) == '/'  # path already absolute

# Generated at 2022-06-20 16:06:16.991207
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common._text import to_native
    from ansible.module_utils.six import PY3
    import sys

    assert to_native(get_bin_path(sys.executable)) == to_native(sys.executable)

    if not PY3:
        try:
            get_bin_path('this_does_not_exist')
        except ValueError as e:
            print(e)
            assert 'Failed to find' in to_native(e)
        else:
            raise AssertionError('get_bin_path did not raise Exception')

    try:
        get_bin_path('this_does_not_exist', ['/dev/null'])
    except ValueError as e:
        print(e)

# Generated at 2022-06-20 16:06:25.477420
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.file import md5, md5s

    # Setup temporary files
    from tempfile import mkstemp
    (tf, tf_path) = mkstemp(text=False)
    os.close(tf)
    (tf2, tf2_path) = mkstemp(text=False)
    os.close(tf2)

    # Setup temporary diretories
    from tempfile import mkdtemp
    td = mkdtemp()
    td2 = mkdtemp()
    td3 = mkdtemp()

    # Test locating an executable on first path
    os.environ['PATH'] = '%s:%s:%s' % (td, td2, td3)
    tf_bin_path = get_bin_path('foo')

# Generated at 2022-06-20 16:06:37.036495
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Verify get_bin_path can find the given path on this system
    '''
    import tempfile


# Generated at 2022-06-20 16:06:40.023810
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("python3") == "/usr/bin/python3"



# Generated at 2022-06-20 16:06:43.702339
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    from ansible.module_utils.common.file import is_executable
    from ansible.module_utils.common import get_bin_path

    wrapper = get_bin_path('ls')

    assert os.path.exists(wrapper)
    assert is_executable(wrapper)

# Generated at 2022-06-20 16:06:53.245187
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    from tempfile import mkdtemp
    from shutil import rmtree, copy2
    from distutils.spawn import find_executable
    # Create temporary directory to copy files to
    tmp_path = mkdtemp()

    # Create and copy executable to temp directory
    test_exec = 'test_exec'
    exec_path = find_executable(test_exec)
    copy2(exec_path, tmp_path)

    # Create and copy non-executable to temp directory
    test_non_exec = 'test_non_exec'
    non_exec_path = find_executable(test_non_exec)
    copy2(non_exec_path, tmp_path)

    # Test for required executable in optional directories

# Generated at 2022-06-20 16:06:54.993619
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('oe') == '/bin/oe'
    print("pass")

# Generated at 2022-06-20 16:06:59.063688
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' test if the get_bin_path function raises ValueError when required is True and executable is not found
    '''
    import pytest
    for arg in ["not_exists_sys_bin", "not_exists_sys_bin", ""]:
        with pytest.raises(ValueError):
            get_bin_path(arg, required=True)


# Generated at 2022-06-20 16:07:07.965114
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Basic unit test for get_bin_path
    '''
    test_paths = [['/usr/bin', '/bin'], ['/usr/bin']]

    for paths in test_paths:
        for cmd in ['ls', 'false', 'true']:
            path = get_bin_path(cmd, paths)
            assert os.path.exists(path)
            assert path.endswith(cmd)

# Generated at 2022-06-20 16:07:09.813041
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('notexists') == None

# Generated at 2022-06-20 16:07:13.826467
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os
    mydir = tempfile.mkdtemp()
    print(mydir)
    bin_path = os.path.join(mydir, 'ls')
    with open(bin_path, 'wb'):
        pass
    os.chmod(bin_path, 0o755)
    assert get_bin_path('ls', [mydir]) == bin_path
    assert get_bin_path('ls', [os.path.join(mydir, 'unknown')]) == bin_path
    shutil.rmtree(mydir)

# Generated at 2022-06-20 16:07:23.765819
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("ls") == '/bin/ls'
    assert get_bin_path("ls", opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path("/bin/ls", opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path("/bin/ls", opt_dirs=['/bin', '/usr/bin', '/bin']) == '/bin/ls'
    assert get_bin_path("/bin/ls", opt_dirs=['/usr/bin', '/bin']) == '/bin/ls'
    assert get_bin_path("/bin/ls", opt_dirs=['/usr/bin']) == '/bin/ls'

# Generated at 2022-06-20 16:07:33.358073
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test = get_bin_path('/bin/ls')
        assert test == '/bin/ls'
    except ValueError as e:
        assert 'Failed to find required executable "/bin/ls"' in str(e)

    try:
        test = get_bin_path('/usr/bin/id')
        assert test == '/usr/bin/id'
    except ValueError as e:
        assert 'Failed to find required executable "/usr/bin/id"' in str(e)


# Generated at 2022-06-20 16:07:39.543613
# Unit test for function get_bin_path
def test_get_bin_path():
    # CentOS 7 /usr/bin/openssl is a symlink to /usr/bin/openssl.old -> This is normal
    # For example, if /usr/sbin/sssd is not installed, get_bin_path returns None
    bin_path = get_bin_path("openssl")
    assert bin_path == "/usr/bin/openssl"
    bin_path = get_bin_path("sssd")
    assert bin_path is None

# Generated at 2022-06-20 16:07:42.671297
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('ansible-does-not-exist')
    except ValueError as e:
        # Ansible 2.10 and later
        assert 'ansible-does-not-exist' in str(e)
        assert 'PATH' in str(e)
    else:
        raise Exception('Expected ValueError not raised.')

    # get_bin_path('ansible-does-not-exist', required=True) # deprecated in Ansible 2.10
    # with pytest.raises(ValueError) as err:

# Generated at 2022-06-20 16:07:55.422861
# Unit test for function get_bin_path
def test_get_bin_path():
    def fake_is_executable(path):
        return True

    import sys
    path = list(sys.path)
    try:
        sys.path.append(os.path.abspath('utils/module_docs_fragments'))
        from get_bin_path_data import testcases
    except:
        raise
    finally:
        sys.path = path
    for case in testcases:
        os.environ['PATH'] = case['environ']
        if case['expected'] == "ValueError":
            try:
                get_bin_path(case['binary'], case['directories'], fake_is_executable)
            except ValueError:
                pass
            else:
                raise Exception('did not get expected exception')

# Generated at 2022-06-20 16:08:05.971760
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test success cases
    # Test normal case
    assert get_bin_path('ls') == '/bin/ls'
    # Test with optional dirs
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/bin/ls'
    # Test with optional dirs which contains executable
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/usr/local/bin']) == '/usr/local/bin/ls'
    # Test sbin is in PATH
    assert get_bin_path('df') == '/bin/df'
    # Test with sbin in optional dirs
    assert get_bin_path('df', opt_dirs=['/sbin', '/usr/sbin']) == '/sbin/df'

    # Test failure cases
    # Test non

# Generated at 2022-06-20 16:08:15.422497
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test without opt_dirs and required parameters
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('perl') == '/usr/bin/perl'
    # Test with opt_dirs and required parameters
    opt_dirs = ['/usr/bin', '/bin', '/usr/local/bin']
    assert get_bin_path('sh', opt_dirs, False) == '/bin/sh'
    assert get_bin_path('python3', opt_dirs, False) == '/usr/bin/python3'

# Generated at 2022-06-20 16:08:18.341850
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-20 16:08:30.019730
# Unit test for function get_bin_path
def test_get_bin_path():
    # Testing with a required executable and with not required executable
    assert get_bin_path('grep') == '/bin/grep'
    assert get_bin_path('jfnsdfje', required=False) is None

    # Testing with a required executable but with not found binary
    test_executable_not_found_error = False
    try:
        get_bin_path('jfnsdfje')
    except ValueError:
        test_executable_not_found_error = True
    assert test_executable_not_found_error is True

    # Testing with additional path
    dir_path = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-20 16:08:30.940565
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('nosuchfile') is None

# Generated at 2022-06-20 16:08:33.668268
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ping') is not None
    try:
        get_bin_path('__DOES_NOT_EXIST__')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-20 16:08:42.577773
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', required=False) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/sbin']) == '/sbin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/local/bin']) == '/usr/local/bin/ls'
    assert get_bin_path('ls', ['/bogus']) == '/bin/ls'
    try:
        assert get_bin_path('bogus')
    except ValueError:
        pass

# Generated at 2022-06-20 16:08:43.903551
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('bash') == '/bin/bash'

# Generated at 2022-06-20 16:08:52.888424
# Unit test for function get_bin_path
def test_get_bin_path():
    global __file__
    import os

    # when the requested path is not present, raise an exception
    not_present = os.path.join(os.path.dirname(__file__), 'no_such_executable')
    try:
        get_bin_path(not_present)
    except ValueError:
        pass
    else:
        assert False, "should've raised exception"

    # when the requested path is present, return it
    present = os.path.join(os.path.dirname(__file__), 'get_bin_path.py')
    result = get_bin_path(present)
    assert result == present, "failed to return %s: got %s" % (present, result)

# Generated at 2022-06-20 16:09:02.434059
# Unit test for function get_bin_path
def test_get_bin_path():
    mypath = '/usr/bin:/usr/local/bin:/bin'
    newpaths = ['/sbin', '/usr/sbin']
    my_env = os.environ
    my_env['PATH'] = mypath
    saved_environ = os.environ
    os.environ = my_env
    try:
        assert get_bin_path('cat') == '/bin/cat'
        assert get_bin_path('ntpdate', required=False) == '/usr/sbin/ntpdate'
        assert get_bin_path('ntpdate', opt_dirs=newpaths) == '/usr/sbin/ntpdate'
    except AssertionError:
        pass
    finally:
        os.environ = saved_environ

# Generated at 2022-06-20 16:09:10.297996
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('../bin/sh') == '../bin/sh'
    assert get_bin_path('/bin/foo') == '/bin/foo'
    assert get_bin_path('invalidpath', ['/bin']) == '/bin/invalidpath'
    assert get_bin_path('foobar') == '/bin/foobar'
    assert get_bin_path('foobar', ['/sbin', '/usr/sbin']) == '/sbin/foobar'
    assert get_bin_path('env') == '/usr/bin/env'

# Generated at 2022-06-20 16:09:20.862705
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    valid_bin = '/bin/true'
    invalid_bin = '/bin/false'

    test_dir = tempfile.mkdtemp()
    bin_dir = os.path.join(test_dir, 'bin')
    py_dir = os.path.join(test_dir, 'python')
    sub_dir = os.path.join(py_dir, 'subdir')

    os.makedirs(bin_dir)
    os.makedirs(py_dir)
    os.makedirs(sub_dir)

    open(os.path.join(bin_dir, 'true'), 'a').close()
    os.chmod(os.path.join(bin_dir, 'true'), 0o755)

# Generated at 2022-06-20 16:09:31.168351
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('getent')

    try:
        get_bin_path('asdfasdfasdf')
        assert False, 'Did not catch missing required getent'
    except ValueError as e:
        assert 'Failed to find required executable "asdfasdfasdf"' in str(e)

    try:
        get_bin_path('getent', opt_dirs=['/usr/bin'])
        assert False, 'Did not catch missing required getent'
    except ValueError as e:
        assert 'Failed to find required executable "getent" in paths: /usr/bin' in str(e)

# Generated at 2022-06-20 16:09:41.687412
# Unit test for function get_bin_path
def test_get_bin_path():
    start_path = os.environ.get('PATH', '')
    os.environ['PATH'] = '/bin:/usr/bin'

    # Successful lookup in current path
    assert get_bin_path('true') == '/bin/true'
    assert get_bin_path('false') == '/bin/false'
    assert get_bin_path('ls') == '/bin/ls'

    # Unsuccessful lookup in current path
    try:
        get_bin_path('well_i_guess_you_cant_find_me_sir')
        assert False, 'should have raised exception'
    except:
        pass

    # Successful lookup in added path
    assert get_bin_path('df', opt_dirs=['/bin']) == '/bin/df'

    # Successful lookup in added path with multiple directories

# Generated at 2022-06-20 16:09:48.973009
# Unit test for function get_bin_path
def test_get_bin_path():
    #
    # SETUP
    #
    # Create a temporary directory to run unit tests
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    import shutil
    import stat

    # Create a fake executable
    fake_bin_dir = os.path.join(tmp_dir, 'bin')
    os.mkdir(fake_bin_dir)
    fake_bin_path = os.path.join(fake_bin_dir, 'fake_bin')
    with open(fake_bin_path, 'w') as fake_bin:
        fake_bin.write('#!/bin/bash\n')
    os.chmod(fake_bin_path, stat.S_IREAD | stat.S_IEXEC)

    #
    # TESTS
    #

# Generated at 2022-06-20 16:09:59.729154
# Unit test for function get_bin_path
def test_get_bin_path():
    def mock_path_exists(path):
        return True if path == '/usr/bin/git' else False

    def mock_is_executable(path):
        return True if path == '/usr/bin/git' else False

    def mock_makedirs(path):
        raise OSError(13, 'Permission denied')

    orig_path_exists = os.path.exists
    orig_is_executable = is_executable
    orig_makedirs = os.makedirs
    os.path.exists = mock_path_exists
    is_executable = mock_is_executable
    os.makedirs = mock_makedirs

# Generated at 2022-06-20 16:10:08.426110
# Unit test for function get_bin_path
def test_get_bin_path():
    import getpass

    user = getpass.getuser()
    bin = '/bin/id'
    opt_dirs = ['/sbin', '/usr/sbin', '/usr/local/sbin']
    # optional dirs are searched first
    path = get_bin_path(bin, opt_dirs)
    assert path == '/sbin/id'
    # optional dirs are searched first and in order
    path = get_bin_path(bin, ['/usr/sbin', '/usr/local/sbin'])
    assert path == '/usr/sbin/id'
    # optional dirs are kept in path only if they exist
    path = get_bin_path(bin, ['/foo/bar'])
    assert path == '/bin/id'
    # optional dirs are kept in path only if they exist
    path

# Generated at 2022-06-20 16:10:12.398390
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path
    '''
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import patch

    def side_effect(arg, opt_dirs):
        return arg

    def side_effect_exception(*unused_args, **unused_kwargs):
        raise Exception("Exception")

    with patch('os.path.exists', side_effect=side_effect) as mock_exists:
        # test with no optional directory
        test_results = get_bin_path('arg1')
        assert test_results == 'arg1', test_results

        # test with optional directory provided
        test_results = get_bin_path('arg1', opt_dirs=['opt_dir'])

# Generated at 2022-06-20 16:10:22.569758
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import os
    import tempfile

    # Create a temporary path
    tmppath = tempfile.mkdtemp()
    os.chmod(tmppath, 0o755)

    # Create a temporary file and set it to be executable
    dummy, tmpfile = tempfile.mkstemp()
    os.chmod(tmpfile, 0o755)

    # Create a temporary file and don't set it to be executable
    f = open(os.path.join(tmppath, "not_executable"), "w")
    f.close()

    # Check that tmpfile is in PATH
    assert get_bin_path(os.path.basename(tmpfile)) == tmpfile

    # Check that we can find tmpfile in tmppath

# Generated at 2022-06-20 16:10:30.880427
# Unit test for function get_bin_path
def test_get_bin_path():
    # testing 'paths' argument
    pwd = os.path.dirname(os.path.abspath(__file__))
    not_found_in_pwd = get_bin_path('file_doesnt_exists', opt_dirs=[pwd])
    assert not_found_in_pwd is None

    found_in_pwd = get_bin_path('get_bin_path.py', opt_dirs=[pwd])
    assert found_in_pwd == os.path.join(pwd, 'get_bin_path.py')

    # testing 'required' argument
    not_found_required_false = get_bin_path('file_doesnt_exists', required=False)
    assert not_found_required_false is None


# Generated at 2022-06-20 16:10:38.034588
# Unit test for function get_bin_path
def test_get_bin_path():
    def fake_is_exec(path):
        return True

    def fake_exists(path):
        return path in ['/my/bin/dd2', '/my/bin/dd2.txt']

    def fake_join(a, b):
        return os.path.join(a, b)

    def fake_get(var, default):
        return default

    def mock_module(function):
        fake_module = {}
        fake_module['ANSIBLE_DEBUG'] = False
        fake_module['is_executable'] = function
        fake_module['getenv'] = fake_get
        fake_module['join'] = fake_join
        fake_module['exists'] = fake_exists
        return fake_module

    def fake_import_module(module):
        return mock_module(fake_is_exec)



# Generated at 2022-06-20 16:10:45.395480
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test to make sure the script doesn't break if the executable doesn't exist
    # Tests user-specified directories
    try:
        module_utils_common_file_get_bin_path('/bin/doesnotexist')
    except ValueError:
        pass
    else:
        print('Failed to detect missing executable in /bin')

    try:
        module_utils_common_file_get_bin_path('/usr/bin/doesnotexist')
    except ValueError:
        pass
    else:
        print('Failed to detect missing executable in /usr/bin')

    try:
        module_utils_common_file_get_bin_path('/usr/local/bin/doesnotexist')
    except ValueError:
        pass
    else:
        print('Failed to detect missing executable in /usr/local/bin')

# Generated at 2022-06-20 16:11:01.039974
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path("ls")
    assert os.path.exists(path) and not os.path.isdir(path) and is_executable(path)
    path = get_bin_path("ls")
    assert os.path.exists(path) and not os.path.isdir(path) and is_executable(path)
    # using opt_dirs in the call
    path = get_bin_path("ls", opt_dirs=['/bin'])
    assert os.path.exists(path) and not os.path.isdir(path) and is_executable(path)
    # None value in opt_dirs
    path = get_bin_path("ls", opt_dirs=['/bin', None])
    assert os.path.exists(path) and not os.path

# Generated at 2022-06-20 16:11:12.223818
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible') == '/usr/bin/ansible'
    assert get_bin_path('nc') == '/bin/nc'
    assert get_bin_path('true') == '/bin/true'
    assert get_bin_path('false') == '/bin/false'
    assert get_bin_path('grep') == '/bin/grep'
    assert get_bin_path('cut') == '/usr/bin/cut'
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('awk') == '/usr/bin/awk'
    assert get_bin_path('wc') == '/usr/bin/wc'
    assert get_bin_path('something_nonexistent') is None

# Generated at 2022-06-20 16:11:22.153195
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    # Set up some temporary directories
    bin = tempfile.TemporaryDirectory()
    bin_path = tempfile.TemporaryDirectory()
    sbin = tempfile.TemporaryDirectory()
    sbin_path = tempfile.TemporaryDirectory()

    # Create some fake binaries
    os.mknod(os.path.join(bin.name, 'a.bin'))
    os.mknod(os.path.join(bin_path.name, 'a.bin'))
    os.mknod(os.path.join(sbin.name, 'b.bin'))
    os.mknod(os.path.join(sbin_path.name, 'b.bin'))

    # Set up PATH environment variable

# Generated at 2022-06-20 16:11:33.459674
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile

    tmp = None
    if sys.platform.startswith('linux'):
        tmp = tempfile.mktemp()
        with open(tmp, 'w') as f:
            f.write('#!/bin/sh\n')
            f.flush()
        os.chmod(tmp, 0o755)

        assert get_bin_path('sh') == '/bin/sh'
        assert get_bin_path('sh', opt_dirs=['/bin', '/usr/bin']) == '/bin/sh'
        assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/usr/bin/sh'
        assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/sh'
       

# Generated at 2022-06-20 16:11:38.429468
# Unit test for function get_bin_path
def test_get_bin_path():
    test_path = '/bin:/usr/bin'
    test_required = False
    test_opt_dirs = []

    # Test 1: verify expected behaviour for existing executable
    test_arg = 'which'
    path = get_bin_path(test_arg, test_opt_dirs, test_required)
    assert path == '/usr/bin/which'

    # Test 2: verify expected behaviour for non-existing executable
    test_arg = 'foobar'
    try:
        path = get_bin_path(test_arg, test_opt_dirs, test_required)
    except ValueError as e:
        assert 'Failed to find required executable "%s"' % test_arg in str(e)

    # Test 3: verify expected behaviour for executable in alternative dir
    test_arg = 'foo'
    test_opt_

# Generated at 2022-06-20 16:11:50.637087
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest

    def _test_get_bin_path(arg, expected, opt_dirs):
        assert get_bin_path(arg, opt_dirs=opt_dirs) == expected

    def _test_get_bin_path_exception(arg, opt_dirs):
        with pytest.raises(ValueError):
            get_bin_path(arg, opt_dirs=opt_dirs)

    _test_get_bin_path('ansible-test-get-bin-path-cmd', os.path.realpath('ansible-test-get-bin-path-cmd'), [])

# Generated at 2022-06-20 16:11:57.849579
# Unit test for function get_bin_path
def test_get_bin_path():

    import tempfile

    # Create nonexistent executable
    nonexistent_executable = os.path.join(tempfile.gettempdir(), 'nonexistent_executable')
    assert not os.path.isfile(nonexistent_executable)

    # Create executable in temp dir
    test_executable = os.path.join(tempfile.gettempdir(), 'test_executable')
    with open(test_executable, 'w') as f:
        f.write("#!/bin/sh\necho 'test output'")
    os.chmod(test_executable, 0o755)
    assert os.path.isfile(test_executable)

    # Create executable in subdir
    subdir = os.path.join(tempfile.gettempdir(), 'subdir')
    os.mkdir(subdir)
    test

# Generated at 2022-06-20 16:12:00.013582
# Unit test for function get_bin_path
def test_get_bin_path():
    ret = get_bin_path('python')
    print(ret)



if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-20 16:12:06.904452
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import subprocess
    import shutil

    with tempfile.TemporaryDirectory() as temp_dir:
        path = os.path.join(temp_dir, 'front-end')
        path2 = os.path.join(temp_dir, 'back-end')
        f = open(path, "w")
        f.close()
        os.chmod(path, 0o755)
        os.environ['PATH'] = temp_dir + os.pathsep + os.environ['PATH']

        # test if any of the executable files are in the path
        assert get_bin_path('front-end') == path
        assert get_bin_path('front-end', [temp_dir]) == path

        # test if file isn't in path and path is empty
        paths = ['']

# Generated at 2022-06-20 16:12:13.484519
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('id')
    except ValueError:
        assert False, 'get_bin_path failed to find "id" command'

    try:
        get_bin_path('frobbleblats')
        assert False, 'get_bin_path found missing command "frobbleblats"'
    except ValueError:
        pass

    # @todo:  Add tests for optional arguments, which will require mocking

# Generated at 2022-06-20 16:12:20.777170
# Unit test for function get_bin_path
def test_get_bin_path():
    # fn exists and is executable and should be found
    assert is_executable(get_bin_path('true'))
    # fn exists but is not executable and should not be found
    try:
        get_bin_path('/etc/hosts')
    except ValueError:
        pass
    # fn does not exist and should not be found
    try:
        get_bin_path('does_not_exist')
    except ValueError:
        pass

# Generated at 2022-06-20 16:12:32.835696
# Unit test for function get_bin_path
def test_get_bin_path():
    binary = 'test_binary'

    with open(binary, 'w') as f:
        f.write("#!/usr/bin/env python\nimport sys\nprint(sys.version)")
    os.chmod(binary, 0o755)

    path = get_bin_path('asdf', required=True)
    assert path == 'asdf'

    path = get_bin_path('doesnotexist', required=True)
    assert path == 'doesnotexist'

    try:
        path = get_bin_path(binary, required=False)
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "%s" in paths: %s' % (binary, os.environ['PATH'])


# Generated at 2022-06-20 16:12:34.866833
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('cat'))
    assert(get_bin_path('ls'))
    assert(get_bin_path('python'))

# Generated at 2022-06-20 16:12:40.422864
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('i_do_not_exist')
        assert False
    except Exception:
        pass

    try:
        get_bin_path('i_do_not_exist', required=True)
        assert False
    except Exception:
        pass

    assert get_bin_path('which') is not None

# Generated at 2022-06-20 16:12:45.296312
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('thisdoesnotexist')
        raise Exception('get_bin_path did not raise exception for a non-existent executable')
    except ValueError:
        pass
    try:
        get_bin_path('bash')
        get_bin_path('bash', required=False)
        get_bin_path('bash', required=True)
        get_bin_path('bash', required=True)
    except:
        raise Exception('get_bin_path raised exception for an existing executable')

# Generated at 2022-06-20 16:12:54.161345
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import filecmp
    import pprint
    import random
    import string

    random_string = lambda n: ''.join([random.choice(string.lowercase) for i in range(n)])
    tmpdir = tempfile.mkdtemp()
    tmpdir_subdir = os.path.join(tmpdir, 'subdir')
    os.mkdir(tmpdir_subdir)


# Generated at 2022-06-20 16:13:01.984965
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    opt_dirs = ['/usr/local/bin', '/usr/bin', '/bin', '/usr/sbin', '/sbin']
    required = True
    # Test for a valid executable
    result = get_bin_path('ls', required=required)
    assert(result.endswith('/ls'))
    # Test for a valid executable in an opt_dir
    result = get_bin_path('ls', opt_dirs, required=required)
    assert(result.endswith('/ls'))
    # Test for a valid executable in an opt_dir that is not in the path
    result = get_bin_path('ls', ['/usr/local/bin'], required=required)
    assert(result.endswith('/ls'))
    # Test for a valid executable in an opt_dir

# Generated at 2022-06-20 16:13:04.541484
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/usr/bin/false')
    except ValueError:
        pass
    else:
        raise AssertionError('get_bin_path() did not raise ValueError on non-existent exec')

    result = get_bin_path('/bin/cat')
    assert result == '/bin/cat'

# Generated at 2022-06-20 16:13:11.175969
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert 'sh' in get_bin_path('sh')
    assert 'bash' in get_bin_path('bash')
    assert 'ls' in get_bin_path('ls')
    assert 'chmod' in get_bin_path('chmod')
    assert 'python' in get_bin_path('python')
    assert 'ansible-config' in get_bin_path('ansible-config')
    assert 'nosuchfileordirectory' not in get_bin_path('nosuchfileordirectory')

# Generated at 2022-06-20 16:13:22.713794
# Unit test for function get_bin_path
def test_get_bin_path():
    # Positive tests
    assert get_bin_path('ls')
    assert '/bin/ls' == get_bin_path('ls')
    assert '/usr/bin/ls' == get_bin_path('ls', opt_dirs=['/usr/bin'])

    # Negative tests:
    bin_path_raises = (
        ('ls', ValueError),
        ('no_exist_binary', ValueError),
    )
    for arg, exc_type in bin_path_raises:
        try:
            get_bin_path(arg)
        except exc_type:
            pass
        else:
            assert False, 'Expected %s to raise %s' % (arg, exc_type)

# Generated at 2022-06-20 16:13:34.687508
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('foo')
        fail('Should fail and throw an exception')
    except ValueError as e:
        eq_(e.message, 'Failed to find required executable "foo" in paths: /bin:/usr/bin:/usr/local/bin')

    x = get_bin_path('cat')
    ok_(x, '/bin/cat')
    x = get_bin_path('cat', ['/usr/bin'])
    ok_(x, '/bin/cat')
    x = get_bin_path('cat', ['/bin'])
    ok_(x, '/bin/cat')
    x = get_bin_path('cat', ['/bin/cat'])
    ok_(x, '/bin/cat')
    x = get_bin_path('cat', ['/foo'], False)
    ok

# Generated at 2022-06-20 16:13:43.813673
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('true')
    assert path == '/bin/true'
    path = get_bin_path('cat')
    assert path == '/bin/cat' or path == '/usr/bin/cat'
    try:
        get_bin_path('invalid_path_to_executable')
    except ValueError as err:
        assert 'Failed to find required executable' in str(err)
    else:
        assert False
    path = get_bin_path('bash', ['/usr/bin', '/usr/local/bin'])
    assert path == '/usr/local/bin/bash'

# Generated at 2022-06-20 16:13:52.653734
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    dirs = []

# Generated at 2022-06-20 16:13:55.229958
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('ls', opt_dirs=('/bin', '/usr/bin'))
    assert path == '/bin/ls'


# Generated at 2022-06-20 16:14:03.445190
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text

    # Test normal path
    assert get_bin_path(to_bytes('ls')) == to_text(os.path.realpath(to_bytes('/bin/ls')))
    assert get_bin_path(to_bytes('python')) == to_text(os.path.realpath('/usr/bin/python'))
    assert get_bin_path(to_bytes('pip')) == to_text(os.path.realpath(to_bytes('/usr/bin/pip')))

    # Test extra path

# Generated at 2022-06-20 16:14:12.564846
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Unit test for function get_bin_path '''
    assert get_bin_path('sh')
    # sh should not be in tmpdir
    assert not get_bin_path('sh', opt_dirs=[os.path.join(os.path.dirname(__file__), 'tmpdir')])
    # touch a file in tmpdir and get_bin_path should find it
    open(os.path.join(os.path.dirname(__file__), 'tmpdir', 'test_file'), 'a').close()
    assert get_bin_path('test_file', opt_dirs=[os.path.join(os.path.dirname(__file__), 'tmpdir')])

# Generated at 2022-06-20 16:14:23.054207
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    base_dir = tempfile.mkdtemp()
    bin_dir1 = os.path.join(base_dir, 'bin1')
    bin_dir2 = os.path.join(base_dir, 'bin2')
    os.mkdir(bin_dir1)
    os.mkdir(bin_dir2)
    test_file = 'test_file'
    test_path1 = os.path.join(bin_dir1, test_file)
    test_path2 = os.path.join(bin_dir2, test_file)
    with open(test_path1, 'w') as f:
        f.write('some content')
    with open(test_path2, 'w') as f:
        f.write('some content')
    os.chmod

# Generated at 2022-06-20 16:14:26.614379
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Verify get_bin_path function
    '''

# Generated at 2022-06-20 16:14:35.664103
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    try:
        get_bin_path('asdf-not-exists')
        assert False
    except ValueError as e:
        assert "Failed to find" in str(e)
    assert get_bin_path('ssh', opt_dirs=['/bin']) == '/bin/ssh'
    assert get_bin_path('ssh', opt_dirs=['/usr/bin']) == '/usr/bin/ssh'
    assert get_bin_path('ip', opt_dirs=['/sbin', '/usr/bin']) == '/sbin/ip'
    assert get_bin_path('ip', opt_dirs=['/bin', '/usr/bin']) == '/usr/bin/ip'

# Generated at 2022-06-20 16:14:39.804729
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('__not_found__', required=False)
    except ValueError as e:
        assert 'Failed to find required executable "__not_found__"' in to_text(e)



# Generated at 2022-06-20 16:14:54.369898
# Unit test for function get_bin_path
def test_get_bin_path():
    assert (isinstance(get_bin_path('ls'), str))
    try:
        get_bin_path('some_random_cmd_that_does_not_exist')
    except ValueError as e:
        assert(str(e) == 'Failed to find required executable "some_random_cmd_that_does_not_exist" in paths: /usr/lib64/qt-3.3/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/jenkins/.local/bin:/home/jenkins/bin:/sbin')
    assert (get_bin_path('ls', ['/tmp/dir1', '/tmp/dir2']) == '/tmp/dir1/ls')