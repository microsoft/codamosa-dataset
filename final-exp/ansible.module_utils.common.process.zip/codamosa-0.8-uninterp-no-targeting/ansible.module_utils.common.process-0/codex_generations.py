

# Generated at 2022-06-20 16:05:05.793658
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('perl') == '/usr/bin/perl'
    assert get_bin_path('foo') is None
    assert get_bin_path('foo', []) is None
    assert get_bin_path('echo', ['/bin', '/usr/bin']) == '/bin/echo'
    assert get_bin_path('echo', ['/sbin', '/usr/sbin']) == '/bin/echo'
    assert get_bin_path('echo', ['/sbin', '/usr/bin']) == '/bin/echo'
    assert get_bin_path('echo', opt_dirs=['/usr/bin', '/bin']) == '/bin/echo'
    assert get_bin_path('echo', opt_dirs=['/usr/bin', '/sbin']) == '/bin/echo'
   

# Generated at 2022-06-20 16:05:06.607638
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('hostname')

# Generated at 2022-06-20 16:05:16.459731
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1: Check for simple command 'ls' in PATH
    try:
        bin_path = get_bin_path('ls')
        assert bin_path and os.path.exists(bin_path), "Couldn't find ls in PATH"
    except:
        assert False, "Failed when searching for simple command in PATH"

    # Test 2: Check for simple command 'ansible-playbook' in PATH and specified directory
    try:
        bin_path = get_bin_path('ansible-playbook', [os.getcwd()])
        assert bin_path and os.path.exists(bin_path), "Couldn't find ansible-playbook in PATH"
    except:
        assert False, "Failed when searching for simple command in PATH and specified directory"

    # Test 3: Check for simple command 'ansible-

# Generated at 2022-06-20 16:05:25.118399
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('somesomewhere_over_the_rainbowdir')
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "somesomewhere_over_the_rainbowdir" in paths: /bin:/usr/bin:/usr/local/bin'

    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/local/bin']) == '/usr/local/bin/ls'

# Generated at 2022-06-20 16:05:34.238033
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Check that known executables can be found in the path'''
    # These tests fail without having /sbin, /usr/sbin, and /usr/local/sbin
    # in the PATH env variable.  This is a hack to make them pass.
    #  Also note this will fail for people who have these directories
    #  under /usr/local, or in other non-standard locations.
    for exec_name in ['sh', 'ls', 'grep']:
        try:
            get_bin_path(exec_name)
        except ValueError:
            assert False, 'executable "%s" not found' % exec_name

# Generated at 2022-06-20 16:05:42.265126
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path.
    '''

    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('vim') == '/usr/bin/vim'
    assert get_bin_path('sudo') == '/usr/bin/sudo'
    assert get_bin_path('rsync') == '/usr/bin/rsync'
    try:
        get_bin_path('sdfsdfsdfsdfsdfsdfsdf')
    except ValueError:
        pass
    else:
        assert False, "Failed to raise exception"

# Generated at 2022-06-20 16:05:47.854351
# Unit test for function get_bin_path
def test_get_bin_path():
    test_path_1 = get_bin_path('python')
    #test success
    assert 'python' in test_path_1
    #test exception
    try:
        test_path_2 = get_bin_path('thisisnotanexecutable')
    except ValueError:
        assert 'ValueError'
    else:
        assert False, "Failed to raise ValueError!"

# Generated at 2022-06-20 16:06:00.354587
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import shlex
    from ansible.module_utils.common.file import mkstemp_file

    test_dir = tempfile.mkdtemp()
    shutil.rmtree(test_dir)
    os.mkdir(test_dir)
    fd, test_file = mkstemp_file(dir=test_dir)
    with open(test_file, 'w') as f:
        f.write('echo')
    os.chmod(test_file, 0o755)
    initial_path = os.environ.get('PATH', '')

# Generated at 2022-06-20 16:06:11.655000
# Unit test for function get_bin_path

# Generated at 2022-06-20 16:06:21.421568
# Unit test for function get_bin_path
def test_get_bin_path():
    def check_bin_path(name, bin_path, opt_dirs=None, required=None):
        assert name == get_bin_path(name, opt_dirs, required)

    check_bin_path('ls', '/bin/ls')
    check_bin_path('/bin/ls', '/bin/ls')

    if 'PIP_BIN_DIR' in os.environ:
        check_bin_path('pip', os.environ['PIP_BIN_DIR'] + '/pip', opt_dirs=[os.environ['PIP_BIN_DIR']])

    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 16:06:28.972844
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('/usr/bin/echo')
    if not bin_path == '/usr/bin/echo':
        raise AssertionError('Failed to find /usr/bin/echo.')

# Generated at 2022-06-20 16:06:35.294635
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1: Test which appears in the default paths.
    path = get_bin_path('chmod')
    assert path == '/bin/chmod'

    # Test 2: Test which appears in /usr/local/sbin.
    path = get_bin_path('samba-tool')
    assert path == '/usr/local/sbin/samba-tool'

    # Test 3: Test that calling with /usr/local/sbin in opt_dirs will return the same path.
    path = get_bin_path('samba-tool', opt_dirs=['/usr/local/sbin'])
    assert path == '/usr/local/sbin/samba-tool'

    # Test 4: Test a path which does not exist.

# Generated at 2022-06-20 16:06:45.550454
# Unit test for function get_bin_path

# Generated at 2022-06-20 16:06:54.593010
# Unit test for function get_bin_path
def test_get_bin_path():

    try:
        get_bin_path('foobarbaz')
        assert False, 'An exception was expected'
    except ValueError as e:
        assert 'Failed to find required executable "foobarbaz"' in str(e)

    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('python') == '/usr/bin/python'

    assert get_bin_path('cat', ['/bin', '/usr/bin']) == '/bin/cat'
    assert get_bin_path('python', ['/bin', '/usr/bin']) == '/usr/bin/python'

    assert get_bin_path('cat', ['/usr/bin', '/bin']) == '/usr/bin/cat'

# Generated at 2022-06-20 16:07:02.326895
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    try:
        get_bin_path('this_does_not_exist')
    except ValueError as e:
        assert '/bin/this_does_not_exist' not in str(e)
        assert 'this_does_not_exist' in str(e)
    try:
        get_bin_path('sh', ['/tmp'])
    except ValueError as e:
        assert '/tmp/sh' not in str(e)
        assert '/bin/sh' not in str(e)
        assert 'sh' in str(e)
    try:
        get_bin_path('sh', ['/bin'])
    except ValueError as e:
        assert '/bin/sh' in str(e)

# Generated at 2022-06-20 16:07:09.142109
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        import pytest
    except ImportError:
        print('Unable to import the "pytest" module. Please install it to run the unit test.')
        return

    # Test 1: Use get_bin_path to find path to 'python'
    expected_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../test/runner/python')
    assert get_bin_path('python') == expected_path

    # Test 2: Use get_bin_path to find a path that does not exist
    expected_error_msg = 'Failed to find required executable "this_path_does_not_exist" in paths: .*'

# Generated at 2022-06-20 16:07:14.584219
# Unit test for function get_bin_path
def test_get_bin_path():

    from ansible.module_utils.common.file import is_executable

    v, r = None, None
    try:
        # assert that we can't find an executable that doesn't exist
        test_bin = os.path.join(os.path.sep, 'tmp', 'not_a_bin')
        v = get_bin_path(test_bin, required=True)
        assert False, 'Found non-existing executable: %s' % test_bin
    except ValueError as e:
        r = "Failed to find required executable \"%s\"" % test_bin
        assert r in str(e)

    # find a chosen system executable
    test_bin = 'tar'
    v = get_bin_path(test_bin, required=True)
    assert os.path.isfile(v) and is_exec

# Generated at 2022-06-20 16:07:23.852358
# Unit test for function get_bin_path
def test_get_bin_path():
    real_path = '/bin/sh'
    fake_path = '/bin/fake_path'
    fake_sbin_path = '/sbin/fake_path'

    assert get_bin_path('sh') == real_path
    try:
        get_bin_path(fake_path)
        assert False
    except ValueError as ve:
        assert str(ve) == 'Failed to find required executable "%s" in paths: %s' % (fake_path, os.environ.get('PATH', ''))

    assert get_bin_path('sh', opt_dirs=['/sbin']) == real_path
    assert get_bin_path('sh', opt_dirs=['/sbin']) == real_path

# Generated at 2022-06-20 16:07:28.201843
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('ls')
        assert True
    except ValueError:
        assert False

    try:
        get_bin_path('not-exists')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-20 16:07:32.709529
# Unit test for function get_bin_path
def test_get_bin_path():
    argv0 = get_bin_path('argv0')
    assert os.path.basename(argv0) == 'argv0'

    if os.path.exists('/bin/argv0'):
        argv0_alt = get_bin_path('argv0', ['/bin'])
        assert argv0_alt != argv0
        assert os.path.basename(argv0_alt) == 'argv0'

# Generated at 2022-06-20 16:07:40.843520
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/env') == '/usr/bin/env'
    assert get_bin_path('env', ['/usr/bin']) == '/usr/bin/env'
    assert get_bin_path('env', ['/usr/bin'], False) == '/usr/bin/env'
    try:
        get_bin_path('env', ['/usr/bin'], True)
        raise AssertionError('Expected get_bin_path to return ValueError')
    except ValueError:
        pass

# Generated at 2022-06-20 16:07:49.568448
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Unit test to validate get_bin_path'''
    # Test existing file
    bin_path = get_bin_path('sh')
    assert bin_path == '/bin/sh'
    # Test existing file with opt_dirs
    bin_path = get_bin_path('sh', opt_dirs=['/bin'])
    assert bin_path == '/bin/sh'
    # Test non existing file with opt_dirs
    try:
        bin_path = get_bin_path('sh2', opt_dirs=['/bin'])
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-20 16:07:57.675208
# Unit test for function get_bin_path
def test_get_bin_path():
    # confirm function raises exception if required executable is not found
    try:
        get_bin_path('__nonexistent_executable__')
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')

    # find system executable in PATH
    try:
        exec_path = get_bin_path('sh')
    except:
        raise AssertionError('Expected to find "sh" in paths: %s' % os.pathsep.join(os.environ.get('PATH', '').split(os.pathsep)))

    # find system executable in dir not in PATH
    sbin_path = '/sbin'

# Generated at 2022-06-20 16:08:04.510081
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin']) == '/usr/bin/sh'
    try:
        get_bin_path('bad')
    except Exception as e:
        assert isinstance(e, ValueError)


# Generated at 2022-06-20 16:08:11.051103
# Unit test for function get_bin_path
def test_get_bin_path():
    # test success
    path = get_bin_path('python')
    assert path is not None

    # test failure
    path = get_bin_path('bad_python_exec')
    assert path is None

# Generated at 2022-06-20 16:08:16.756461
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        cmd = 'test'
        test_path = os.path.join(tmpdirname, cmd)
        with open(test_path, 'w') as f:
            f.write('#!/bin/sh')
        os.chmod(test_path, os.stat(test_path).st_mode | 0o111)

    assert get_bin_path(cmd) == test_path



# Generated at 2022-06-20 16:08:28.225040
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test passing fully qualified executable path
    try:
        get_bin_path('/bin/sh')
    except ValueError:
        assert 0, 'Unexpected ValueError exception raised'

    # Test passing non-existent executable
    try:
        get_bin_path('/bin/not_an_executable', required=True)
    except ValueError:
        pass
    except Exception:
        assert 0, 'Unexpected exception raised'
    else:
        assert 0, 'Expected ValueError exception not raised'

    # Test passing non-existent executable with 'required' parameter
    try:
        get_bin_path('/bin/not_an_executable', required=False)
    except ValueError:
        pass
    except Exception:
        assert 0, 'Unexpected exception raised'

# Generated at 2022-06-20 16:08:32.890482
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("sh") == "/bin/sh"
    assert get_bin_path("/bin/sh") == "/bin/sh"
    assert get_bin_path("/usr/bin/sh") == "/usr/bin/sh"
    try:
        get_bin_path("false")
        assert False
    except ValueError:
        pass

# Generated at 2022-06-20 16:08:35.127181
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('/bin/sh')
    get_bin_path('sh')

# Generated at 2022-06-20 16:08:44.806722
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest

    env_paths = os.environ.get('PATH').split(os.pathsep)
    env_paths.extend(['/usr/local/bin', '/opt/bin'])

    # simple test for find_executable
    assert get_bin_path("python") == get_bin_path("python")
    assert "/usr/bin/python" == get_bin_path("python")

    # test with additional search dirs
    assert "/usr/bin/python" == get_bin_path("python", opt_dirs=['/usr/bin', '/usr/sbin'])
    assert "/usr/local/bin/python" == get_bin_path("python", opt_dirs=['/usr/local/bin', '/usr/sbin'])

# Generated at 2022-06-20 16:08:51.796673
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('env')
    assert get_bin_path('env', required=False)
    assert get_bin_path('env', required=True)

# Generated at 2022-06-20 16:08:58.595550
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', ['/usr/local/bin']) == '/usr/local/bin/ls'
    try:
        get_bin_path('ls', ['/non/existent'])
        assert 0 == 1, 'Did not get expected exception'
    except ValueError:
        pass



# Generated at 2022-06-20 16:09:08.158654
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Functional test for get_bin_path.
    This should work on any system that has /bin/true and /bin/false.
    '''
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-20 16:09:15.636732
# Unit test for function get_bin_path
def test_get_bin_path():
    # test with no optional directories specified
    try:
        get_bin_path('nonsense')
        assert False, 'expected ValueError'
    except ValueError:
        pass
    # test with optional directory specified
    assert get_bin_path('get_bin_path.py', opt_dirs=['test/utils/argparsing'])
    # test with optional directory specified but wrong
    try:
        get_bin_path('get_bin_path.py', opt_dirs=['test/utils/argparsing/wrong'])
        assert False, 'expected ValueError'
    except ValueError:
        pass

# Generated at 2022-06-20 16:09:26.596651
# Unit test for function get_bin_path
def test_get_bin_path():
    def _mock_exists(foo):
        return foo in ('/bin/sh', '/sbin/ping', '/bin/false')
    def _mock_is_executable(foo):
        return foo in ('/bin/sh', '/sbin/ping')
    import __builtin__ as builtins
    builtins.__dict__['open'] = None
    builtins.__dict__['file'] = None
    builtins.__dict__['xrange'] = None
    os.path.exists = _mock_exists
    is_executable = _mock_is_executable
    # test with something that exists in PATH
    assert get_bin_path('sh') == '/bin/sh'
    # test with something that does not exist in PATH

# Generated at 2022-06-20 16:09:32.019911
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # get_bin_path should find a real executable
        assert get_bin_path('ls')
        # get_bin_path should not find a non-existent executable
        get_bin_path('/bin/foobarbaz')
    except ValueError:
        pass
    else:
        assert False, 'get_bin_path did not raise a ValueError for missing executable'

# Generated at 2022-06-20 16:09:42.157831
# Unit test for function get_bin_path
def test_get_bin_path():
    tests = [('/bin/ls', False, '/bin/ls'),
             ('ls', False, '/bin/ls'),
             ('/bin/ls', True, '/bin/ls'),
             ('ls', True, '/bin/ls'),
             ('/nonexisting/ls', True, '/nonexisting/ls'),
             ('/bin/ls', True, '/bin/ls', ['/nonexisting/ls', '/nonexisting/ls']),
             ('ls', True, '/bin/ls', ['/nonexisting/ls', '/nonexisting/ls'])]

    for test in tests:
        (arg, required, path, dirs) = test
        if dirs is None:
            dirs = []


# Generated at 2022-06-20 16:09:49.254031
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import shlex
    import subprocess
    import mock

    (fd, path) = tempfile.mkstemp()
    os.close(fd)

    # test retrieval of existing executable
    bin_path = get_bin_path('ls')
    assert os.path.exists(bin_path)
    assert is_executable(bin_path)

    # test retrieval of existing executable not in PATH
    arg = 'python'
    if os.path.exists('/usr/bin/python'):
        # This works on MacOS
        existing_path = '/usr/bin/python'
    else:
        # This works on linux
        existing_path = '/usr/bin/python2.7'
    assert os.path.exists(existing_path)
    assert is_executable

# Generated at 2022-06-20 16:09:54.805281
# Unit test for function get_bin_path
def test_get_bin_path():
    def test(args, expected_path, opt_dirs=None, required=None):
        bin_path = get_bin_path(args, opt_dirs=opt_dirs, required=required)
        assert bin_path == expected_path
    test('/bin/ls', '/bin/ls')
    test('ls', '/bin/ls')
    test('ls', '/bin/ls')
    test('ls', '/bin/ls', ['', '/bin/ls'])
    test('ls', '/ls', ['', '/ls'])
    test('ls', '/ls', ['', '/bin/ls', '/ls'])
    test('ls', '/bin/ls', ['/ls', '/bin/ls'])
    test('ls', '/bin/ls', ['/bin/ls', '/ls'])

# Generated at 2022-06-20 16:09:58.171088
# Unit test for function get_bin_path
def test_get_bin_path():
    test_executable = 'ansible-test-get_bin_path'
    bin_path = get_bin_path(test_executable, None, None)

    assert bin_path == '/usr/bin/ansible-test-get_bin_path'

# Generated at 2022-06-20 16:10:08.457142
# Unit test for function get_bin_path
def test_get_bin_path():
    # run function
    bin_path = get_bin_path('python')
    # test results
    assert bin_path.endswith('python')



# Generated at 2022-06-20 16:10:13.459446
# Unit test for function get_bin_path
def test_get_bin_path():
    import unittest

    import ansible.module_utils.common.file as file_utils
    from ansible.module_utils.common.file import is_executable

    import tempfile

    # File created below will only be executable by current user
    def add_only_user_exec(file_name):
        current_mode = os.stat(file_name).st_mode
        new_mode = current_mode | (current_mode & 0o444) >> 2
        os.chmod(file_name, new_mode)

    # File created below will only be readable by current user
    def add_only_user_read(file_name):
        current_mode = os.stat(file_name).st_mode
        new_mode = current_mode & ~(current_mode & 0o444)

# Generated at 2022-06-20 16:10:23.212376
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('ruby')
    except ValueError:
        assert False, 'test_get_bin_path failed: path to ruby expected to be set in PATH'
    # test optional dirs
    test_dirs = ['/tmp', '/nonexistent']
    try:
        get_bin_path('ruby', test_dirs)
    except ValueError:
        assert False, 'test_get_bin_path failed: path to ruby expected to be found in %s' % (test_dirs)
    try:
        get_bin_path('nonexistent', ['/tmp'])
    except ValueError:
        assert True, 'test_get_bin_path failed: path to nonexistent executable should not be found'
        # test required

# Generated at 2022-06-20 16:10:28.066448
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', ['/tmp']) == '/bin/ls'
    assert get_bin_path('awesome_app') == '/usr/bin/awesome_app'
    assert 'facter' in get_bin_path('facter')

# Generated at 2022-06-20 16:10:36.834482
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == 'python'
    assert get_bin_path('python2.7') == 'python2.7'
    assert get_bin_path('python', required=True) == 'python'
    import tempfile
    temp_dir = tempfile.mkdtemp()
    test_exe_path = os.path.join(temp_dir, 'test_executable')
    with open(test_exe_path, 'wb') as f:
        f.write(b"\x7fELF" + os.urandom(100))
    os.chmod(test_exe_path, 0o777)
    assert get_bin_path(os.path.basename(test_exe_path),
                         opt_dirs=[os.path.dirname(test_exe_path)]) == test_exe

# Generated at 2022-06-20 16:10:44.993946
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.file import is_executable

    assert get_bin_path('env') == get_bin_path('env', [])
    assert get_bin_path('env') == get_bin_path('env', ['/usr/local/bin', '/usr/local/sbin'])
    assert get_bin_path('env', ['/usr/local/bin', '/usr/local/sbin']) != get_bin_path('env', ['/usr/local/bin'])

    test_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'get_bin_path_test_path')

# Generated at 2022-06-20 16:10:54.475999
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh', ['/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/bin'], True) == '/bin/sh'
    assert get_bin_path('sh', ['/not_exists_dir'], True) == '/bin/sh'
    assert get_bin_path('sh', ['/bin', '/sbin']) == '/bin/sh'
    assert get_bin_path('sh', ['/bin', '/sbin', '/not_exists_dir']) == '/bin/sh'
    assert get_bin_path('sh', ['/bin', '/sbin', '/not_exists_dir'], True) == '/bin/sh'

# Generated at 2022-06-20 16:11:03.116435
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    import shutil
    import uuid

    # create a safe temporary (non-existent) directory
    tmpdir = tempfile.mkdtemp()

    # make uuid
    uid = uuid.uuid4()
    exec_name = str(uid)

    # create executable in temporary directory
    path_to_exec = os.path.join(tmpdir, exec_name)
    with open(path_to_exec, "w") as f:
        f.write("#!/bin/sh\nexit 0\n")
    os.chmod(path_to_exec, 0o755)

    # put temporary dir in PATH
    saved_path = os.environ["PATH"]
    os.environ["PATH"] = tmpdir + os.pathsep + os.environ["PATH"]

# Generated at 2022-06-20 16:11:11.496672
# Unit test for function get_bin_path
def test_get_bin_path():

    try:
        get_bin_path('not_there')
        assert False
    except ValueError:
        assert True

    # if required was True, an exception was raised. If required was False, not.
    try:
        get_bin_path('not_there', required=False)
        assert True
    except Exception:
        assert False

    try:
        get_bin_path('not_there', required=True)
        assert False
    except ValueError:
        assert True

    # We expect to find this binary (which is actually a shell script. But that's OK.)
    assert get_bin_path('which')

    # We expect to find this binary in our own test directory not on the PATH
    assert os.path.exists('/not_on_path')

# Generated at 2022-06-20 16:11:12.543290
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat')


# Generated at 2022-06-20 16:11:24.968432
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    import ansible.module_utils.common.file as file_utils

    path = None
    tempdir = None
    exename = 'example'

# Generated at 2022-06-20 16:11:36.449529
# Unit test for function get_bin_path
def test_get_bin_path():
    # make sure a found executable returns the correct path
    assert get_bin_path('cat', ['/bin']) == '/bin/cat'
    assert get_bin_path('cat', ['/bin']) != '/sbin/cat'
    # make sure a not found executable raises an exception
    try:
        get_bin_path('notthere')
        assert False
    except ValueError:
        pass
    # make sure an optional directory is searched
    assert get_bin_path('cat', ['/sbin']) == '/sbin/cat'
    # make sure optional directories are searched in order
    assert get_bin_path('cat', ['/bin', '/sbin']) == '/bin/cat'
    # make sure non-executables are ignored

# Generated at 2022-06-20 16:11:48.046879
# Unit test for function get_bin_path
def test_get_bin_path():
    # Mocking and patching os.environ and os.path functions to perform unit test
    import mock
    from ansible.module_utils._text import to_bytes
    real_environ = os.environ
    real_exists = os.path.exists
    real_isdir = os.path.isdir
    real_is_executable = is_executable

    class Environ(dict):
        def __init__(self, data):
            self.data = data

        def __getitem__(self, key):
            return self.data[key]

        def get(self, key, default=None):
            if key in self.data:
                return self.data[key]
            return default


# Generated at 2022-06-20 16:11:59.463692
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('/bin/bash') == '/bin/bash'
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python3') == '/usr/bin/python3'
    try:
        get_bin_path('non_existing_command')
        assert False, "Exception should have been raised"
    except ValueError as e:
        assert e.args[0].startswith('Failed to find required executable "non_existing_command" in paths')

   

# Generated at 2022-06-20 16:12:00.534020
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-20 16:12:12.482899
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    with patch('ansible.module_utils.common.file.is_executable') as mock_is_executable:
        mock_is_executable.return_value = True

        # Test with paths
        with patch.dict(os.environ, {'PATH': '/bin:/usr/bin'}):
            path = get_bin_path('foo')
            assert path == '/bin/foo'

        # Test with opt_dirs and paths
        with patch.dict(os.environ, {'PATH': '/bin:/usr/bin'}):
            path = get_bin_path('foo', ['/sbin', '/usr/sbin'])
            assert path == '/sbin/foo'

        # Test

# Generated at 2022-06-20 16:12:17.447514
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('cat')
    assert os.path.exists(path)

    def assert_bad(arg):
        try:
            get_bin_path(arg)
            assert False, 'Should have raised ValueError for "%s"' % arg
        except ValueError:
            pass
    assert_bad('does-not-exist')

# Generated at 2022-06-20 16:12:29.712103
# Unit test for function get_bin_path
def test_get_bin_path():
    # Verify that exception for non-existent file is raised
    try:
        get_bin_path('Xnotexist')
    except ValueError as e:
        exception_text = str(e)
    assert 'Failed to find required executable' in exception_text
    # Verify that exception for existing, but not executable, file is raised
    try:
        get_bin_path('/etc/fstab')
    except ValueError as e:
        exception_text = str(e)
    assert 'Failed to find required executable' in exception_text
    # Verify that file found in search path works
    assert get_bin_path('python') == '/usr/bin/python'
    # Verify that full path to file works
    assert get_bin_path('/usr/bin/python') == '/usr/bin/python'

# Generated at 2022-06-20 16:12:35.207677
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('cat', opt_dirs=['/sbin']) == '/bin/cat'
    assert get_bin_path('cat', opt_dirs=['/sbin', '/bin']) == '/bin/cat'
    try:
        get_bin_path('no_such_file')
        assert False
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    try:
        get_bin_path('no_such_file', required=True)
        assert False
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

# Generated at 2022-06-20 16:12:40.104460
# Unit test for function get_bin_path
def test_get_bin_path():
    # unix
    assert get_bin_path('sh') == '/bin/sh'
    # windows
    assert get_bin_path('cmd.exe') == 'cmd.exe'
    assert get_bin_path('cmd.exe', opt_dirs=['c:\\']) == 'c:\\cmd.exe'

# Generated at 2022-06-20 16:12:53.611073
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('find') == '/usr/bin/find'
    assert get_bin_path('find', ['/usr/bin']) == '/usr/bin/find'
    assert get_bin_path('find', ['/usr/bin', '/bin']) == '/usr/bin/find'

    try:
        get_bin_path('nosuchbinary')
        assert False
    except ValueError as e:
        assert 'Failed to find required executable "nosuchbinary"' in str(e)

    try:
        get_bin_path('nosuchbinary', required=False)
        assert False
    except ValueError as e:
        assert 'Failed to find required executable "nosuchbinary"' in str(e)


# Generated at 2022-06-20 16:13:01.670840
# Unit test for function get_bin_path
def test_get_bin_path():
    test_bin = 'python'
    test_paths = ['/usr/bin', '/usr/local/bin', '/opt/bin']

    # Execute function with no optional arguments
    bin_path = get_bin_path(arg=test_bin)
    assert os.path.exists(bin_path) and is_executable(bin_path), "Failed to find '%s' in default PATH" % test_bin

    # Execute function with optional argument
    bin_path = get_bin_path(arg=test_bin, opt_dirs=None)
    assert os.path.exists(bin_path) and is_executable(bin_path), "Failed to find '%s' in default PATH" % test_bin

    # Execute function with optional argument

# Generated at 2022-06-20 16:13:10.190645
# Unit test for function get_bin_path
def test_get_bin_path():
    import nose
    import tempfile
    import shutil
    import textwrap
    import os
    import stat

    TEST_SCRIPT = textwrap.dedent('''
        #!/bin/sh
        echo this is a test script
        exit 0
    ''')

    def test_get_bin_path_throws_exception_if_required_is_true_and_not_found():
        try:
            get_bin_path('foo', required=True)
            raise Exception('Expected an exception')
        except ValueError:
            pass

    def test_get_bin_path_throws_exception_if_not_found():
        try:
            get_bin_path('foo')
            raise Exception('Expected an exception')
        except ValueError:
            pass


# Generated at 2022-06-20 16:13:22.636980
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest

    assert(get_bin_path('ls'))
    assert(get_bin_path('/bin/ls'))
    assert(get_bin_path('/bin/ls', ['/bin']))
    assert(get_bin_path('/bin/ls', ['/bin'], True))

    with pytest.raises(ValueError):
        get_bin_path('some_bad_path')
    with pytest.raises(ValueError):
        get_bin_path('some_bad_path', ['good_path'])
    with pytest.raises(ValueError):
        get_bin_path('some_bad_path', ['good_path'], True)

# Generated at 2022-06-20 16:13:31.609447
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import shutil
    import tempfile

    def make_executable(path):
        old_mode = os.stat(path).st_mode

# Generated at 2022-06-20 16:13:40.430094
# Unit test for function get_bin_path
def test_get_bin_path():
    # If no directory is given then PATH is looked up
    assert get_bin_path('ls')
    assert get_bin_path('ls', opt_dirs=None)

    # If directory is given then the path is tested against that directory
    assert get_bin_path('ls', opt_dirs=['/bin'])

    # If directory is invalid then it cannot be found
    try:
        get_bin_path('ls', opt_dirs=['/invalid'])
        assert False, 'path was found in invalid path'
    except ValueError:
        pass

# Generated at 2022-06-20 16:13:52.000952
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile

    # create a temp dir
    tmpdir = tempfile.mkdtemp()
    py = os.path.join(tmpdir, 'python')
    with open(py, 'w') as f:
        f.write('')

    # create a temp file in that dir
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)
    py2 = os.path.join(tmpdir2, 'python2')
    with open(py2, 'w') as f:
        f.write('')

    # add the temp dir to PATH
    old_path = os.environ['PATH']
    os.environ['PATH'] = tmpdir2 + os.pathsep + tmpdir + os.pathsep + old_path

# Generated at 2022-06-20 16:14:04.720708
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.file import which

    # Test for a valid executable in PATH
    cat = get_bin_path('cat')
    assert cat == which('cat')
    # Test for an invalid executable in PATH
    try:
        get_bin_path('invalid_executable')
        assert False
    except ValueError:
        pass
    # Test for an invalid executable in PATH and no check_rc on failure
    try:
        get_bin_path('invalid_executable', required=False)
        assert False
    except ValueError:
        pass
    # Test for an optional valid executable in PATH
    ls = get_bin_path('ls', required=False)
    assert ls == which('ls')
    # Test for an optional valid executable in PATH

# Generated at 2022-06-20 16:14:13.306403
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/usr/local/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/usr/local/bin'], required=False) == '/bin/sh'

    try:
        get_bin_path('non-existent-binary-should-never-exist', required=False)
        assert False
    except ValueError:
        assert True

    try:
        get_bin_path('non-existent-binary-should-never-exist')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-20 16:14:20.111199
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test the get_bin_path function without optional arguments
    '''
    # Test case 1 - Executable exists in paths.
    try:
        bin_path = get_bin_path('cat')
        assert bin_path is not None
    except ValueError:
        assert False, 'Failed to find cat executable in paths.'

    # Test case 2 - Executable doe not exists in paths.
    try:
        get_bin_path('exec_not_found')
        assert False, 'exec_not_found executable should not be found in paths.'
    except ValueError:
        assert True

    # Test case 3 - Test executable found in opt_dirs.

# Generated at 2022-06-20 16:14:30.381552
# Unit test for function get_bin_path
def test_get_bin_path():
    # first use case: a custom PATH
    path_list = ['.', '/usr/bin', '/bin']
    test_path = get_bin_path('ls', path_list)
    assert(test_path == '/bin/ls')

    # second use case: default PATH
    test_path = get_bin_path('ls')
    assert(test_path == '/bin/ls')



# Generated at 2022-06-20 16:14:37.783222
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil

    TMPD = '/tmp/ansible_test_get_bin_path'
    BINP = os.path.join(TMPD, 'bin/sh')
    SPTP = os.path.join(TMPD, 'sbin/sh')
    EXTP = os.path.join(TMPD, 'extra/sh')

    os.makedirs(TMPD)
    open(BINP, 'w').write('#!/bin/sh')
    open(SPTP, 'w').write('#!/bin/sh')
    os.chmod(BINP, 0o755)
    os.chmod(SPTP, 0o755)

    # Test default get_bin_path
    assert get_bin_path('sh') == BINP

    # Test get_bin_path when /sbin is not

# Generated at 2022-06-20 16:14:46.305040
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path returns the correct path
    '''
    # Test 1: Valid path returned
    import shutil
    import tempfile
    # Make a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Make a script file in the temporary directory
    fh, script_path = tempfile.mkstemp(dir=tmpdir)
    # Make sure the script file is executable
    os.chmod(script_path, 0o755)

    # Test function get_bin_path
    result = get_bin_path(os.path.basename(script_path), opt_dirs=[os.path.dirname(script_path)])
    assert result == script_path

    # Clean up - delete the temporary directory
    shutil.rmtree(tmpdir)

    # Test 2:

# Generated at 2022-06-20 16:14:48.328673
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Basic sanity test for the get_bin_path function
    '''
    assert get_bin_path('sh') == '/bin/sh'

