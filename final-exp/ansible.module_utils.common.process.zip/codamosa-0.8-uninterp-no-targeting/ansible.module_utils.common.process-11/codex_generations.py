

# Generated at 2022-06-20 16:05:04.069377
# Unit test for function get_bin_path
def test_get_bin_path():
    def run_test(arg, opt_dirs, expected, expected_result):
        try:
            result = get_bin_path(arg, opt_dirs)
        except ValueError:
            result = None
        assert result == expected_result, 'Expected: %s, got: %s' % (expected_result, result)
        if result:
            assert result.endswith(expected), 'Expected: %s, got: %s' % (expected, result)

    # Invoke get_bin_path and make sure that it always returns an absolute path
    arg = '/bin/python'
    expected = '/bin/python'
    opt_dirs = ['/bin']
    run_test(arg, opt_dirs, expected, arg)

    arg = 'python'
    expected = 'python'
    opt_dir

# Generated at 2022-06-20 16:05:13.611586
# Unit test for function get_bin_path
def test_get_bin_path():
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_file = os.path.join(test_dir, 'test_get_bin_path')
    # Create file and make executable
    with open(test_file, 'w') as tf:
        tf.write('#!/bin/bash')
    os.chmod(test_file, 0o755)

    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path(test_file) == test_file
    try:
        get_bin_path('non_existing_cmd')
        raise Exception('get_bin_path did not raise expected ValueError')
    except ValueError:
        pass

    os.unlink(test_file)

# Generated at 2022-06-20 16:05:25.493145
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.validation import get_bin_path
    import mock

    with mock.patch('os.path.exists') as mock_exists, \
            mock.patch('os.path.isdir') as mock_isdir, \
            mock.patch('ansible.module_utils.common.file.is_executable'):

        mock_exists.side_effect = lambda p: p in ('/usr/bin/ansible', '/sbin/ansible', '/usr/bin/ansible-doc')
        mock_isdir.return_value = False

        assert get_bin_path('ansible') == '/usr/bin/ansible'
        assert get_bin_path('ansible-doc') == '/usr/bin/ansible-doc'

# Generated at 2022-06-20 16:05:36.090184
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls', opt_dirs=[]) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=[]) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/bin/ls'

# Generated at 2022-06-20 16:05:47.003333
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/tmp']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/tmp/sbin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/tmp/sbin']) == '/bin/sh'
    assert get_bin_path('bash', opt_dirs=['/tmp']) == '/bin/bash'
    assert get_bin_path('bash', opt_dirs=['/tmp/sbin']) == '/bin/bash'
    assert get_bin_path('bash', opt_dirs=['/tmp/sbin']) == '/bin/bash'

# Generated at 2022-06-20 16:05:57.835950
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test case 1: No required args
    try:
        get_bin_path('bash')
    except ValueError as err:
        assert False, "Unexpected failure: %s" % str(err)
    # Test case 2: Optional directory
    try:
        get_bin_path('eggs', opt_dirs='/bin')
    except ValueError as err:
        assert False, "Unexpected failure: %s" % str(err)

    # Test case 3: No such executable
    try:
        get_bin_path('eggs')
        assert False, "Managed to find non-existent executable"
    except ValueError as err:
        assert True

    # Test case 4: No such directory

# Generated at 2022-06-20 16:06:05.464958
# Unit test for function get_bin_path
def test_get_bin_path():
    # find existing executable in PATH
    path = get_bin_path('ls')
    assert os.path.exists(path) and is_executable(path)
    # find existing executable in opt_dirs
    path = get_bin_path('ls', opt_dirs = ['/bin'])
    assert os.path.exists(path) and is_executable(path)
    # find executable in /sbin including /sbin in PATH
    path = get_bin_path('ss')
    assert os.path.exists(path) and is_executable(path)
    # find executable in /sbin including /sbin in opt_dirs
    path = get_bin_path('ss', opt_dirs = ['/sbin'])

# Generated at 2022-06-20 16:06:13.826120
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test for proper get_bin_path fuctions.
    '''
    assert get_bin_path('true')  == '/bin/true'
    assert get_bin_path('grep')  == '/bin/grep'
    assert get_bin_path('sleep') == '/bin/sleep'

    try:
        get_bin_path('pip')
    except ValueError as e:
        assert "Failed to find" in str(e)
    except Exception as e:
        assert "raise ValueError" in str(e)

# Generated at 2022-06-20 16:06:23.864815
# Unit test for function get_bin_path
def test_get_bin_path():
    def test_bin_path(arg, opt_dirs=None, required=None, expected_path=None):
        bin_path = get_bin_path(arg, opt_dirs=opt_dirs, required=required)
        assert bin_path == expected_path

    test_bin_path('/bin/sh', expected_path='/bin/sh')
    test_bin_path('sh', expected_path='/bin/sh')
    test_bin_path('/bin/bogus', required=True)
    with open('/bin/sh', 'w') as f:
        f.write('#!/bin/bash\necho "Hello"')
    test_bin_path('sh', expected_path='/bin/sh')

# Generated at 2022-06-20 16:06:36.206237
# Unit test for function get_bin_path
def test_get_bin_path():
    PATH = os.environ['PATH']

    def _test(arg, required=None, opt_dirs=None, error_pattern=None, paths=None):
        os.environ['PATH'] = paths or PATH
        try:
            bin_path = get_bin_path(arg, required=required, opt_dirs=opt_dirs)
            assert bin_path
        except ValueError as e:
            if not error_pattern:
                raise
            assert error_pattern in str(e)

    # Test that PATH is searched
    try:
        get_bin_path('true')
    except Exception:
        raise AssertionError('get_bin_path failed to search PATH')

    # Test opt_dirs
    _test('true', opt_dirs=['/bin'])

# Generated at 2022-06-20 16:06:47.927664
# Unit test for function get_bin_path
def test_get_bin_path():

    # This function requires a fair amount of mock and patch.  Using the
    # AnsibleModule object from the ansible.module_utils.basic module would
    # reduce the cost of this function, but the function needs to be
    # stand-alone, because it is used by the unit tests for the basic module.
    import mock
    import os
    import stat
    import sys

    class MockModule:

        class MockAnsibleModule:

            class MockFailJson:

                def __call__(self, msg):
                    raise Exception('Exception: %s' % msg)

            def __init__(self, *args, **kwargs):
                self.fail_json = self.MockFailJson()

        def __init__(self, *args, **kwargs):
            self.ansible_module = self.MockAnsibleModule

# Generated at 2022-06-20 16:06:56.694698
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test that we correctly find executables
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('python') == '/usr/bin/python'

    # Test that we correctly not find executables
    try:
        get_bin_path('foo')
    except ValueError as err:
        assert 'Failed to find required executable "foo"' in str(err)
    else:
        assert False, "did not raise expected ValueError"

    # Test that we correctly find executables in optional directories
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/bin/ls'

    # Test that we correctly not find executables in optional directories

# Generated at 2022-06-20 16:07:02.218821
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('true')
    assert get_bin_path('bash')
    try:
        get_bin_path('non_existing_cmd')
        raise Exception("Failed to raise exception on missing command")
    except ValueError as err:
        assert err.args[0] == "Failed to find required executable 'non_existing_cmd' in paths: /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

# Test if get_bin_path returns the executable if it already is an absolute path

# Generated at 2022-06-20 16:07:09.040857
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile

    if sys.platform.startswith('freebsd'):
        prefix = '/usr/local'
    else:
        prefix = '/usr'
    sbin_dir = prefix + '/sbin'
    usr_local_bin_dir = prefix + '/local/bin'
    usr_local_sbin_dir = prefix + '/local/sbin'
    test_path = tempfile.mkdtemp()
    # Make sure we test get_bin_path's search for /sbin
    paths = '/bin:/usr/bin:' + test_path
    os.environ['PATH'] = paths
    # On some platforms, /sbin and /usr/sbin may not be in PATH, so add them

# Generated at 2022-06-20 16:07:14.497845
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import sys
    import stat

    # Test normal usage
    temp_path = tempfile.mkdtemp()

    # test finding sbin files
    if sys.platform.startswith('freebsd') or sys.platform.startswith('openbsd') or sys.platform.startswith('gnu'):
        bin_path = get_bin_path('date')
        assert bin_path == '/bin/date'

        bin_path = get_bin_path('df')
        assert bin_path == '/bin/df'

    # Test that ValueError is raised when the command is not found.
    try:
        bin_path = get_bin_path('missing_command')
    except ValueError:
        pass

# Generated at 2022-06-20 16:07:23.850742
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Test for function get_bin_path '''
    import tempfile
    import shutil

    # Test finding existing executable in paths
    test_path = '/usr/bin/'
    assert get_bin_path('ls', opt_dirs=[test_path]) == os.path.join(test_path, 'ls')
    assert get_bin_path('ls', opt_dirs=[test_path]) == os.path.join(test_path, 'ls')
    assert get_bin_path('ls') == os.path.join('/bin', 'ls')

    # Test not finding executable in paths
    try:
        get_bin_path('no_such_exe')
    except ValueError:
        pass

# Generated at 2022-06-20 16:07:30.767063
# Unit test for function get_bin_path
def test_get_bin_path():
    # path to 'ls' command
    assert get_bin_path('ls')
    # path to 'cat' command
    assert get_bin_path('cat')
    # path to 'grep' command
    assert get_bin_path('grep')
    # path to 'python' command
    assert get_bin_path('python')
    # path to 'tar' command
    assert get_bin_path('tar')
    # path to 'awk' command
    assert get_bin_path('awk')



# Generated at 2022-06-20 16:07:43.172355
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # Create a temp dir, and dummy files with different permissions
    # We should be able to find the ones with executable bit set
    tmp_dir = tempfile.mkdtemp()
    print('Temporary directory: %s' % (tmp_dir))
    print('Setting up test executables to test get_bin_path')
    path_prefix = os.path.join(tmp_dir, 'test_get_bin_path_')
    os.mkdir(path_prefix + 'dummy')
    exec_list = ['12345', '70123', '100701']
    for perm in exec_list:
        os.mknod(path_prefix + perm)
        os.chmod(path_prefix + perm, int(perm, 8))
    print('Searching for test executables that have executable bit set')
   

# Generated at 2022-06-20 16:07:55.748677
# Unit test for function get_bin_path
def test_get_bin_path():
    import subprocess
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils._text import to_bytes

    # Create a script for testing
    test_script = '/tmp/get_bin_path_test.sh'
    test_script_content = \
        '#!/bin/sh\n' \
        'echo "Hello from $0"\n'
    # Ensure script is not there to begin with
    if os.path.exists(test_script):
        os.remove(test_script)

    # Create a directory to search
    test_dir = '/tmp/get_bin_path_test_dir'
    if not os.path.exists(test_dir):
        os.makedirs(test_dir)

    # Find nothing

# Generated at 2022-06-20 16:08:03.198959
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/bin/python' == get_bin_path('python')
    assert '/bin/python' == get_bin_path('python', opt_dirs=[''])
    assert '/bin/python' == get_bin_path('python', opt_dirs=[None])

    assert '/sbin/fusermount' == get_bin_path('fusermount', opt_dirs=[])
    assert '/sbin/fusermount' == get_bin_path('fusermount', opt_dirs=['/usr/bin'])

# Generated at 2022-06-20 16:08:13.100039
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for function get_bin_path
    '''
    try:
        get_bin_path('foobar')
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError from get_bin_path'
    try:
        get_bin_path('true')
    except ValueError:
        assert False, 'Unexpected ValueError from get_bin_path'

# Generated at 2022-06-20 16:08:21.104402
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.six.moves import builtins

    old_PATH = os.environ.get('PATH')
    os.environ['PATH'] = '/usr/bin'

    assert get_bin_path('false') == '/usr/bin/false'
    try:
        assert get_bin_path('asdf')
        assert False
    except (OSError, ValueError):
        pass

    os.environ['PATH'] = old_PATH

    old_open = builtins.open
    def open(path, mode='r', buffering=0, encoding=None, errors=None):
        if path == '/etc/passwd':
            class FauxPasswd:
                def readlines(self):
                    return ['root']

                def close(self):
                    pass

            return FauxPasswd()
        return

# Generated at 2022-06-20 16:08:27.221790
# Unit test for function get_bin_path
def test_get_bin_path():
    # query for an executable that exists
    try:
        get_bin_path("ls", ['/bin'])
    except ValueError:
        assert False, "test_get_bin_path for an existing executable failed"

    # query for an executable that does not exist
    try:
        get_bin_path("dne")
        assert False, "test_get_bin_path for a non-existing executable failed"
    except ValueError:
        pass

# Generated at 2022-06-20 16:08:37.405584
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['/bin', '/sbin', '/usr/bin', '/usr/sbin']

    # Test fail on path with no dirs
    paths = []
    try:
        get_bin_path('ls', paths)
    except ValueError:
        pass
    else:
        assert False, "Failed to raise exception"

    # Test fail on valid args
    try:
        get_bin_path('ls', paths)
    except ValueError:
        assert False, "Raised exception on valid args"

    # Test fail on invalid executable name
    try:
        get_bin_path('de242d86-b912-4b4d-87bc-1e5caf0c7abefoobar', paths)
    except ValueError:
        pass

# Generated at 2022-06-20 16:08:46.723346
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Unit test for get_bin_path'''
    PATH = os.environ.get('PATH')

# Generated at 2022-06-20 16:08:56.107382
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Validate that we can find executables in:
       /sbin, /usr/sbin, /usr/local/sbin
    '''
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('/bin/bash') == '/bin/bash'
    assert get_bin_path('bad') == '/bin/bad'
    assert get_bin_path('bad', opt_dirs=['/bin']) == '/bin/bad'
    try:
        get_bin_path('bad')
        assert False
    except ValueError:
        assert True
    assert get_bin_path('bad', opt_dirs=['/bin']) == '/bin/bad'
    assert get_bin_path('netstat') == '/bin/netstat'
    assert get_bin

# Generated at 2022-06-20 16:09:03.157661
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import sys
    import shutil
    import tempfile

    # Setup temp dirs
    tmpdir = os.path.realpath(tempfile.mkdtemp())
    bindir = os.path.join(tmpdir, 'bin')
    etcdir = os.path.join(tmpdir, 'etc')
    oldpath = os.environ['PATH']
    os.mkdir(bindir)
    os.mkdir(etcdir)
    os.environ['PATH'] = "%s%s%s" % (bindir, os.pathsep, etcdir)

    # Setup some commands
    os.symlink('/bin/true', os.path.join(bindir, 't1'))

# Generated at 2022-06-20 16:09:09.031282
# Unit test for function get_bin_path
def test_get_bin_path():
    # test get_bin_path returns itself if called with absolute path, absolute path is executable
    assert get_bin_path('/bin') == '/bin'
    # test get_bin_path returns itself if called with absolute path, absolute path is executable and optional paths are specified
    assert get_bin_path('/bin', opt_dirs=['/usr/bin']) == '/bin'
    # test get_bin_path throws ValueError with message if called with absolute path, absolute path is not executable
    try:
        get_bin_path('/bin/true')
    except ValueError as e:
        assert 'Failed to find required executable "/bin/true" in paths: /bin' in str(e)
    else:
        raise Exception('ValueError not raised')
    # test get_bin_path in default paths, default path is executable
   

# Generated at 2022-06-20 16:09:12.760447
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('/bin/ls')
    assert bin_path == '/bin/ls'


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-20 16:09:22.932370
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path
    '''
    # delete PATH env variable and save old value
    saved_path = os.environ.get('PATH')
    del os.environ['PATH']

    # test without PATH env variable
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('noexecutable') is None

    # test with PATH env variable
    os.environ['PATH'] = 'noexecutable:noexecutable2'
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('noexecutable') is None

    # restore old PATH env variable value
    if saved_path:
        os.environ['PATH'] = saved_path
    else:
        del os.environ['PATH']

# Generated at 2022-06-20 16:09:27.255893
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'

# Backward compatibility for function get_bin_path

# Generated at 2022-06-20 16:09:39.002174
# Unit test for function get_bin_path
def test_get_bin_path():
    # if executable is not found and required is False, return None
    assert get_bin_path('this_is_not_an_executable', required=False) is None
    # if executable is not found and required is None (the default)
    # return None
    assert get_bin_path('this_is_not_an_executable') is None
    # if executable is not found and required is True, raise exception
    try:
        get_bin_path('this_is_not_an_executable', required=True)
        assert False, "get_bin_path() should have raised an exception"
    except ValueError:
        pass
    # if executable is found in opt_dirs return full path

# Generated at 2022-06-20 16:09:47.272480
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.test.test_plugins.test_util.testable_get_bin_path import __ansible_arg__ as arg
    import sys

    bin_path = get_bin_path(arg)
    assert is_executable(bin_path)
    assert os.path.split(bin_path)[1] == arg

    # Test that opt_dirs gets searched first
    lib_path = os.path.dirname(sys.modules[__name__].__file__)
    bin_path = get_bin_path(arg, [lib_path])
    assert os.path.normpath(bin_path) == os.path.join(lib_path, arg)
    assert is_executable(bin_path)

# Generated at 2022-06-20 16:09:58.424419
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test finding an executable on the PATH
    assert get_bin_path('grep')
    assert '/bin/grep' == get_bin_path('grep')
    # Test finding with additional directories
    assert '/sbin/grep' == get_bin_path('grep', opt_dirs=['/sbin'])

    # Test not finding a required executable with default opt_dirs
    try:
        get_bin_path('bogus')
        assert 0, "get_bin_path should return a ValueError on failure"
    except ValueError:
        pass

    # Test not finding an executable with opt_dirs

# Generated at 2022-06-20 16:09:59.462923
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh')

# Generated at 2022-06-20 16:10:08.385634
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Test get_bin_path() - Test cases for get_bin_path(arg, opt_dirs=None, required=None) '''

    try:
        # test with a real executable, should return its absolute path
        real_exec = get_bin_path('ls')
        assert os.path.exists(real_exec)

        # test with an executable that is not in PATH, but should be found in opt_dirs, should return its absolute path
        real_exec = get_bin_path('false', ['/bin'])
        assert os.path.exists(real_exec)

        # test with an executable that is not in PATH nor in opt_dirs, should raise an error
        real_exec = get_bin_path('false', ['/dev/null'])

    except ValueError:
        pass

# Generated at 2022-06-20 16:10:19.467225
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python2') == get_bin_path('python2', opt_dirs=['/usr/bin'])
    assert get_bin_path('python2', opt_dirs=['/usr/bin']) == '/usr/bin/python2'
    assert get_bin_path('/usr/bin/python2', opt_dirs=['/usr/bin']) == '/usr/bin/python2'
    try:
        get_bin_path('python2', opt_dirs=['/usr/bin'], required=False)
        assert True
    except ValueError as e:
        assert False
    try:
        get_bin_path('python2', opt_dirs=['/usr/bin'], required=True)
        assert True
    except ValueError as e:
        assert False


# Generated at 2022-06-20 16:10:22.320765
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') is not None
    try:
        get_bin_path('WeWillNeverHaveThisName')
    except ValueError:
        pass

# Generated at 2022-06-20 16:10:27.548167
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Make sure it does not explode '''
    # Check if a known command, ls, can be found
    app = get_bin_path('ls')
    # check that a command that does not exist fails
    try:
        get_bin_path('frobnicate')
    except ValueError:
        pass
    # check if optional dirs are handled properly
    app = get_bin_path('ls', ['/bin', '/usr/bin'])

# Generated at 2022-06-20 16:10:31.625124
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path ansible module helper get_bin_path function
    '''

    arg = 'grep'
    bin_path = get_bin_path(arg)
    assert bin_path == '/bin/grep'



# Generated at 2022-06-20 16:10:42.145552
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = []
    assert get_bin_path('sh', paths) == '/bin/sh'
    paths = ['/bin']
    assert get_bin_path('sh', paths) == '/bin/sh'
    paths = ['/usr/bin']
    assert get_bin_path('sh', paths) == '/usr/bin/sh'
    paths = ['/usr/bin', '/bin']
    assert get_bin_path('sh', paths) == '/usr/bin/sh'
    paths = ['/fake/nonexistent/path', '/bin']
    assert get_bin_path('sh', paths) == '/bin/sh'

    paths = ['/fake/nonexistent/path', '/bin']

# Generated at 2022-06-20 16:10:43.867155
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Unit test for function get_bin_path'''
    path = get_bin_path('cat')
    assert os.path.exists(path)

# Generated at 2022-06-20 16:10:50.698612
# Unit test for function get_bin_path
def test_get_bin_path():
    test_cases = (
        # input, result
        ('/bin/sh', '/bin/sh'),
        ('bogus', None),
        ('bogus', None, []),
        ('bogus', None, ['/bin']),
        ('bogus', None, ['/bogus']),
        ('sh', '/bin/sh'),
        ('sh', '/bin/sh', []),
        ('sh', '/bin/sh', ['/bin']),
        ('sh', '/bogus/sh', ['/bogus']),
        ('sh', None, ['/bogus1', '/bogus2']),
    )

    fails = 0

# Generated at 2022-06-20 16:11:02.298618
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test non existing file
    try:
        get_bin_path("/bin/this/file/does/not/exist")
        assert False, "Expected get_bin_path to raise ValueError"
    except ValueError:
        pass

    # Test existing file, managed by Ansible
    try:
        path = get_bin_path("/bin/cat")
        assert path == "/bin/cat", "Expected get_bin_path to return /bin/cat: %s" % path
    except ValueError:
        assert False, "Expected get_bin_path to not raise ValueError"

    # Test existing file, not managed by Ansible

# Generated at 2022-06-20 16:11:05.806886
# Unit test for function get_bin_path
def test_get_bin_path():
    assert os.path.exists(get_bin_path('python'))
    assert os.path.exists(get_bin_path('python', opt_dirs=['/usr/bin']))
    assert os.path.exists(get_bin_path('python', opt_dirs=[os.getcwd()]))
    # Require should always be true
    assert os.path.exists(get_bin_path('python', required=False))
    assert os.path.exists(get_bin_path('python', required=True))

# Generated at 2022-06-20 16:11:12.664961
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Unit test for function get_bin_path '''

    get_bin_path('/usr/bin/python', None, None)
    get_bin_path('/usr/bin/python', ['/usr/bin'], None)
    get_bin_path('/usr/bin/python', ['/usr/bin', '/usr/local/bin'], None)
    get_bin_path('/usr/bin/python', ['/usr/bin', '/usr/local/bin', '/usr/sbin'], None)
    get_bin_path('/usr/bin/python', ['/usr/bin', '/usr/local/bin', '/usr/sbin', '/sbin'], None)



# Generated at 2022-06-20 16:11:13.340678
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('python')

# Generated at 2022-06-20 16:11:23.098097
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' basic test for get_bin_path'''
    import tempfile
    from ansible.module_utils._text import to_bytes

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a number of files in that directory
    filenames = [
        'foo',
        'bar',
        'baz',
        'foobar',
        'foobaz',
        'barbaz',
        'barbazfoo',
        'foobarbaz'
    ]

    # make each file executable
    for filename in filenames:
        filepath = os.path.join(tmpdir, filename)
        open(filepath, 'w').close()
        os.chmod(filepath, 0o755)

    # create a binary file

# Generated at 2022-06-20 16:11:31.045659
# Unit test for function get_bin_path
def test_get_bin_path():
    real_path = '/usr/bin/ansible-config'
    fake_path = '/usr/bin/answer'
    path_list = ['/usr/bin']

    assert get_bin_path('ansible-config') == real_path
    assert get_bin_path('ansible-config', path_list) == real_path

    try:
        get_bin_path('ansible-config', [fake_path])
    except ValueError:
        pass
    else:
        raise AssertionError('Bad path did not throw exception!')

# Generated at 2022-06-20 16:11:32.924163
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/sbin/init' == get_bin_path('init', ['/sbin', '/usr/sbin'])

# Generated at 2022-06-20 16:11:39.880683
# Unit test for function get_bin_path
def test_get_bin_path():
    bp = '/bin/sh'
    assert get_bin_path('sh') == bp, 'expected: %s, not %s' % (bp, get_bin_path('sh'))

# Generated at 2022-06-20 16:11:42.992344
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no_such_file_or_path')
    except ValueError as e:
        pass
    else:
        assert False, 'Expected ValueError'

# Generated at 2022-06-20 16:11:54.715034
# Unit test for function get_bin_path
def test_get_bin_path():
    # test valid pipe executable
    _, rc, _, _ = module.run_command('touch /tmp/pipe_test')
    _, rc, _, _ = module.run_command('chmod +x /tmp/pipe_test')
    try:
        assert get_bin_path('/tmp/pipe_test') == '/tmp/pipe_test'
    finally:
        os.unlink('/tmp/pipe_test')
    # test invalid path
    try:
        get_bin_path('/tmp/pipe_test')
        assert False
    except ValueError:
        assert True
    # test file with no execute permission
    _, rc, _, _ = module.run_command('touch /tmp/pipe_test')

# Generated at 2022-06-20 16:12:04.093177
# Unit test for function get_bin_path
def test_get_bin_path():
    # Must be run from a directory under the top of the module utils
    # directory structure.  An exception will be raised if there
    # is a problem finding os.path.
    # /usr/bin/env is a portable version of env to verify with
    path1 = get_bin_path('env')
    path2 = get_bin_path('env', required=True)
    assert path1 == '/usr/bin/env'
    assert path1 == path2
    try:
        get_bin_path('foo_bar_baz')
        assert False, "get_bin_path should have raised ValueError"
    except ValueError:
        pass


# Generated at 2022-06-20 16:12:16.359180
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path
    '''
    # Get current PATH environment variable
    current_path = os.environ['PATH']

    # Define a non-existing path
    non_existing_path = '/non_existing_path'

    # Define a new path with non-existing directory
    new_path = '{0}:{1}'.format(current_path, non_existing_path)

    # Define a new path with existing directory
    new_path_2 = '/bin:/sbin'

    # Define a new path with existing directory
    new_path_3 = '/bin:/sbin:/tmp'

    # Define a non-existing executable
    non_existing_exec = 'non_existing_exec'

    # Define an existing executable in $PATH
    existing_exec = 'ls'



# Generated at 2022-06-20 16:12:21.291001
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('ifconfig')
    assert bin_path == '/sbin/ifconfig'

    bin_path = get_bin_path('/sbin/ifconfig')
    assert bin_path == '/sbin/ifconfig'

    bin_path = get_bin_path('sbin/ifconfig')
    assert bin_path == '/sbin/ifconfig'

    bin_path = get_bin_path('python', ['/usr/local/bin'])
    assert bin_path == '/usr/local/bin/python'

# Generated at 2022-06-20 16:12:33.084231
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    mydir = tempfile.mkdtemp()
    mybin = os.path.join(mydir, 'get_bin_path_test')
    open(mybin, 'w').close()
    os.chmod(mybin, stat.S_IRWXU)
    try:
        assert mybin == get_bin_path('get_bin_path_test', [mydir])
        try:
            get_bin_path('get_bin_path_test', [])
        except ValueError as e:
            assert "Failed to find required executable" in str(e)
        else:
            assert False, "Expected ValueError"
    finally:
        shutil.rmtree(mydir)

# Generated at 2022-06-20 16:12:36.614821
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('cat', required=True)
    except ValueError as e:
        assert 'Failed to find required executable "cat"' in str(e)
    else:
        assert False, 'Failed to catch missing binary'

# Generated at 2022-06-20 16:12:45.500107
# Unit test for function get_bin_path
def test_get_bin_path():
    # Run this test in a subprocess as os.environ gets modified
    import subprocess

    test_script = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'module_utils', 'basic', 'test', '__init__.py')
    test_file_path = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'module_utils', 'basic', 'test', 'test_basic.py')
    cmd = [sys.executable, test_script, test_file_path]
    cmd.extend(['test_get_bin_path'])

    # Shorten the test case run time by limiting the number of iterations
    cmd.extend(['--count', '10'])

# Generated at 2022-06-20 16:12:54.262325
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' test get_bin_path'''
    import tempfile
    import shutil
    # Create temporary folder on current directory
    tempdir = tempfile.mkdtemp(dir='.')
    # Create executable file in the folder
    test_executable = tempdir + os.sep + 'executable'
    with open(test_executable, "wb") as f:
        f.write(b"0\n")
    os.chmod(test_executable, 0o755)
    # Add directory to path
    original_path = os.getenv('PATH')
    os.environ['PATH'] = tempdir + os.pathsep + os.getenv('PATH')
    # Get binary path
    bin_path = get_bin_path('executable')
    assert bin_path == test_executable
    #

# Generated at 2022-06-20 16:13:06.983775
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Test to verify get_bin_path function.
    """
    # Test python/python2
    # Issue  #43182: test python2 if python is not available, skip if neither is available
    bin_path = None
    python = '/usr/bin/python'
    python2 = '/usr/bin/python2'
    # For the purpose of unit tests, remove python2 if it exists, so we can test the code path in get_bin_path that
    # checks for python2 when python does not exist.
    if os.path.exists(python) and not os.path.exists(python2):
        bin_path = get_bin_path('python')

# Generated at 2022-06-20 16:13:11.662043
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('bash')
    assert get_bin_path('gcc') == '/usr/bin/gcc'
    assert get_bin_path('gcc', opt_dirs=['/usr/bin/gcc']) == '/usr/bin/gcc'
    assert get_bin_path('gcc', ['test']) == "/usr/bin/gcc"

# Generated at 2022-06-20 16:13:23.808003
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('gzip') == '/bin/gzip'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('chmod') == '/bin/chmod'
    assert get_bin_path('gzip', opt_dirs=['/bin']) == '/bin/gzip'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('chmod', opt_dirs=['/bin']) == '/bin/chmod'
    # test path out of order
    assert get_bin_path

# Generated at 2022-06-20 16:13:27.309578
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible-doc') == '/usr/bin/ansible-doc'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'

# Generated at 2022-06-20 16:13:33.273114
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin'] ) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/sbin'] ) == '/usr/sbin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin'] ) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/sbin'] ) == '/sbin/ls'

# Generated at 2022-06-20 16:13:44.901828
# Unit test for function get_bin_path
def test_get_bin_path():
    test_env_path = os.path.normcase(os.path.abspath(os.path.dirname(__file__) + '/../../..'))
    os.environ['PATH'] = '%s%s%s/test/integration/targets/module_utils/shell/' % (os.environ['PATH'], os.pathsep, test_env_path)
    test_path = get_bin_path('spam')
    assert test_path == os.path.normcase(os.path.abspath(test_env_path + '/test/integration/targets/module_utils/shell/spam'))

    try:
        get_bin_path('inexistent')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-20 16:13:47.856135
# Unit test for function get_bin_path
def test_get_bin_path():
    module = MockAnsibleModule()
    path = get_bin_path('find', module=module, required=True)
    module.assert_called_with(failed_when_required=True)
    module.assert_called_with(msg=None)


# Generated at 2022-06-20 16:13:53.240562
# Unit test for function get_bin_path
def test_get_bin_path():
    extra_dir = os.path.dirname(os.path.abspath(__file__))
    p = get_bin_path('true', opt_dirs=[extra_dir])
    assert p == os.path.join(extra_dir, 'true')

# Generated at 2022-06-20 16:14:02.239110
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    try:
        get_bin_path('fake-exe', opt_dirs=['/bin'])
        assert False, "get_bin_path('fake-exe') should have raised an exception"
    except ValueError as e:
        assert 'Failed to find required executable "fake-exe" in paths: /bin:/sbin:/usr/sbin' in str(e)

    assert get_bin_path('ls', opt_dirs=['/bin', '/sbin', '/usr']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=[]) == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-20 16:14:08.784394
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('ansible-playbook')
    assert path is not None
    assert os.path.exists(path)
    assert os.path.isfile(path)
    assert is_executable(path)

    try:
        path = get_bin_path('bad-name')
        assert False, 'Expected an error'
    except ValueError:
        # expected exception
        pass

# Generated at 2022-06-20 16:14:30.552723
# Unit test for function get_bin_path
def test_get_bin_path():
    # Typical use case
    path = get_bin_path('cat')
    assert path.endswith('/cat')

    # Verify that opt_dirs search path is honored
    # Note: We don't expect 'cat' in '/dev'
    path = get_bin_path('cat', opt_dirs=['/dev'])
    assert path.endswith('/cat')

    # Verify that required executable is not found and exception is raised
    try:
        get_bin_path('doesnotexist')
        assert False, "Exception not raised for missing executable"
    except ValueError:
        pass

# Generated at 2022-06-20 16:14:37.885427
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1: Should fail on required=True without optional paths and without PATH set
    try:
        get_bin_path("ls", None, True)
        assert False
    except ValueError:
        pass

    # Test 2: Should fail on required=True without optional paths and with empty path
    try:
        os.environ["PATH"] = ""
        get_bin_path("ls", None, True)
        assert False
    except ValueError:
        pass

    # Test 3: Should succeed with required=True without optional paths and with current directory included in path
    os.environ["PATH"] = os.getcwd()
    ls_path = get_bin_path("ls", None, True)
    assert ls_path == os.path.join(os.getcwd(), "ls")

    # Test 4: Should succeed with required=

# Generated at 2022-06-20 16:14:45.927602
# Unit test for function get_bin_path
def test_get_bin_path():

    bin_path = get_bin_path('ls')
    assert bin_path == '/bin/ls' or bin_path == '/usr/bin/ls'

    paths = ['/usr/bin', '/bin', '/usr/sbin']
    bin_path = get_bin_path('ls', paths)
    assert bin_path == '/usr/bin/ls'

    try:
        bin_path = get_bin_path('.')
    except ValueError as e:
        assert e.args[0] == 'Failed to find required executable "." in paths: /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/snap/bin'
    else:
        assert False, 'ValueError not raised'

# Generated at 2022-06-20 16:14:54.413738
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import shutil
    import tempfile
    tf_dir = tempfile.mkdtemp()
    tf_exec = os.path.join(tf_dir, 'test_exec')

    try:
        # create test executable
        with open(tf_exec, "w") as f:
            f.write("#!/bin/sh\n")
        os.chmod(tf_exec, 0o700)

        # test get_bin_path
        assert os.path.join(tf_dir, 'test_exec') == get_bin_path('test_exec', opt_dirs=[tf_dir])
    finally:
        shutil.rmtree(tf_dir)