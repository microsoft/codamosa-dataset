

# Generated at 2022-06-20 16:04:54.376838
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') in ['/bin/sh', '/usr/bin/sh']

# Generated at 2022-06-20 16:04:57.073985
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_path = get_bin_path('true')
        assert os.path.isfile(test_path)
    except ValueError as exc:
        assert 0, exc

# Generated at 2022-06-20 16:05:01.481288
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.common.file
    # Exception raised if executable does not exist
    def _get_bin_path_no_exist(arg):
        return get_bin_path(arg)
    # Check that the exception is the correct one
    def _get_bin_path_no_exist_check():
        get_bin_path('nonexistent_executable')
    module = AnsibleModule(argument_spec={})
    module.fail_json(msg=_get_bin_path_no_exist_check.__name__,
                     exception=str(module.get_exception()))
    # Exception raised if executable exists but is not executable
    def _get_bin_path_no_exec(arg):
        return get_bin_path(arg)

# Generated at 2022-06-20 16:05:11.288227
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test module-utils ansible-test sanity-checks
    assert not is_executable(__file__)
    assert not is_executable(os.path.join(os.path.dirname(__file__), os.pardir, 'module_utils'))

    # Test valid bin paths
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls') == get_bin_path('ls')
    assert get_bin_path('ls', required=True) == get_bin_path('ls', required=False)

    # Test invalid bin paths
    try:
        get_bin_path('file_not_exists')
    except ValueError:
        # ValueError is required for (required=False) since 2.10
        pass

# Generated at 2022-06-20 16:05:16.656049
# Unit test for function get_bin_path
def test_get_bin_path():

    assert get_bin_path('true', opt_dirs=['/bin']) == '/bin/true'
    assert get_bin_path('true', opt_dirs=['/i-dont-exist']) == '/bin/true'

    # this is a little unfortunate since it's not unitary, but python on a system without /sbin/reboot is hard to come by
    assert get_bin_path('reboot', opt_dirs=['/sbin']) == '/sbin/reboot'

# Generated at 2022-06-20 16:05:25.135843
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import os
    import shutil
    import nose
    tmp_dir = tempfile.mkdtemp()
    sub_dir = os.path.join(tmp_dir, 'sub_dir1')
    os.mkdir(sub_dir)
    test_filename = os.path.join(tmp_dir, 'test_file')
    test_exec_filename = os.path.join(tmp_dir, 'b')
    test_exec_filename2 = os.path.join(sub_dir, 'b')
    open(test_filename, 'a').close()
    open(test_exec_filename, 'a').close()
    open(test_exec_filename2, 'a').close()
    os.chmod(test_exec_filename, 700)

# Generated at 2022-06-20 16:05:36.089759
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.facts import gather_facts
    from ansible.module_utils._text import to_bytes
    from ansible.utils.path import get_bin_path

    os_path = '/bin:/usr/bin:/usr/local/bin'
    sbin_path = '/sbin:/usr/sbin:/usr/local/sbin'
    os.environ['PATH'] = os_path
    os_paths = os.environ['PATH'].split(os.pathsep)
    paths = os_paths + sbin_path.split(os.pathsep)

    host_info = gather_facts(module=None)

    # Test 1: exists
    test_cmd = 'ls'
    test_args = dict(required=False, opt_dirs=[])
    test_cmd_path

# Generated at 2022-06-20 16:05:38.117605
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path(arg='/bin/ls')
    except Exception as e:
        assert False, e

# Generated at 2022-06-20 16:05:45.808510
# Unit test for function get_bin_path
def test_get_bin_path():
    # test normal execution
    assert get_bin_path('sh') == '/bin/sh'

    # test non-existing binary in path
    try:
        get_bin_path('not_exist_binary')
        assert False, 'This statement should not be executed'
    except ValueError:
        pass

    # test existing binary in non-executable directory
    try:
        get_bin_path('sh', ['/etc'])
        assert False, 'This statement should not be executed'
    except ValueError:
        pass

# Generated at 2022-06-20 16:05:53.208046
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    import shutil
    import atexit
    import subprocess
    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    atexit.register(lambda: shutil.rmtree(tmpdir))
    # Set PATH environment variable to temporary directory
    path = os.environ.get('PATH', '')
    os.environ['PATH'] = tmpdir
    # Create executable in temporary directory
    test_file = os.path.join(tmpdir, 'test')
    if sys.platform == 'win32':
        test_file += '.exe'
    subprocess.check_call(['touch', test_file])
    subprocess.check_call(['chmod', '+x', test_file])
    # Check
    assert get_bin_path('test') == test_file

# Generated at 2022-06-20 16:06:03.998140
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic

    def _test_get_bin_path(expected, cmd, opt_dirs=None, required=None):
        m = basic.AnsibleModule(argument_spec={})
        result = get_bin_path(cmd, opt_dirs, required)
        if result != expected:
            m.fail_json(msg='expected: %s, but got: %s' % (expected, result))
        else:
            m.exit_json(changed=False)

    cases = [
        ('/bin/sh', 'sh'),
        ('/bin/bash', 'bash', ['/bin']),
        ('/foo/bar/baz', 'baz', ['/foo/bar']),
        ('/bin/sh', 'sh', ['/foo/bar']),
    ]
   

# Generated at 2022-06-20 16:06:10.232028
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('This_command_DoEsN0t_exiSts', required=True)
        assert False, 'An exception should be raised'
    except ValueError:
        assert True

    try:
        get_bin_path('ls')
        assert True
    except ValueError:
        assert False, 'Exception should not be raised'

# Generated at 2022-06-20 16:06:20.760812
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile
    from ansible.module_utils.common.file import atomic_replace
    from ansible.module_utils._text import to_bytes

    (tmpfd, tmpfile) = tempfile.mkstemp()
    os.close(tmpfd)

    # Create a fake binary in a temporary directory
    with atomic_replace(to_bytes(tmpfile, errors='surrogate_or_strict'), 'wb', backup=False) as (out_file, tmp_path):
        out_file.write(b'#!/bin/sh\nexit 0')
    os.chmod(tmpfile, 0o755)

    # We should find it
    path = get_bin_path(tmpfile)
    assert(path == tmpfile)

    # If we don't find it, we should get an exception
   

# Generated at 2022-06-20 16:06:23.043976
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ['PATH'] = '/sbin:/usr/sbin:/bin'
    assert '/sbin/ip' == get_bin_path('ip')

# Generated at 2022-06-20 16:06:35.487295
# Unit test for function get_bin_path
def test_get_bin_path():
    valid_path = '/usr/bin/ansible'
    invalid_path = '/usr/bin/ansible_foo'

    if is_executable(valid_path):
        assert get_bin_path('ansible') == valid_path
    else:
        assert get_bin_path('ansible', ['/usr/bin']) == valid_path

    try:
        get_bin_path(invalid_path)
        assert False
    except ValueError:
        assert True
    try:
        get_bin_path(invalid_path, ['/usr/bin'])
        assert False
    except ValueError:
        assert True
    try:
        get_bin_path(invalid_path, required=True)
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-20 16:06:37.846789
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Get bin path for git
    '''
    assert 'git' in get_bin_path('git')

# Generated at 2022-06-20 16:06:47.902127
# Unit test for function get_bin_path
def test_get_bin_path():

    # Unit test when EXECUTABLE is in PATH (should return full path)
    try:
        full_path = get_bin_path('echo')
    except ValueError as e:
        assert False, "Test failed to find required executable echo in paths: %s" % e
    assert full_path is not None
    assert os.path.exists(full_path), "Test failed. File (%s) does not exist" % full_path
    assert os.path.isfile(full_path), "Test failed. File (%s) is not a file" % full_path
    assert os.access(full_path, os.X_OK), "Test failed. File (%s) is not executable" % full_path

    # Unit test when EXECUTABLE is NOT in PATH (should raise ValueError exception)

# Generated at 2022-06-20 16:06:52.095401
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('ls', opt_dirs=['/bin', '/usr/bin'])
    assert bin_path == '/bin/ls'

    try:
        get_bin_path('invalid-path-to-bin', opt_dirs=['/bin', '/usr/bin'])
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

# Generated at 2022-06-20 16:07:00.946129
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    path = None
    temp_dir = None

# Generated at 2022-06-20 16:07:09.107894
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    tmp = tempfile.gettempdir()
    os.environ['PATH'] = tmp

    # create a file and make it executable
    (fd, path) = tempfile.mkstemp()
    os.chmod(path, 0o700)

    # Test whether we can find the executable
    try:
        assert os.path.join(tmp, os.path.basename(path)) == get_bin_path(os.path.basename(path))
    finally:
        os.close(fd)
        os.unlink(path)

# Generated at 2022-06-20 16:07:18.695760
# Unit test for function get_bin_path
def test_get_bin_path():
    path = os.environ.get('PATH')
    os.environ['PATH'] = '/bin:/usr/bin'
    bin_path = get_bin_path('sh')
    assert bin_path == '/bin/sh'
    os.environ['PATH'] = '/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/sbin'
    bin_path = get_bin_path('sh')
    assert bin_path == '/bin/sh'
    print(bin_path)
    os.environ['PATH'] = path

# Generated at 2022-06-20 16:07:28.730943
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh', ['/tmp']) == '/bin/sh'
    assert get_bin_path('sh', ['/tmp']) == '/bin/sh'
    try:
        assert get_bin_path('sh', ['/tmp'], True) == '/bin/sh'
    except:
        pass
    assert get_bin_path('fake-prog', ['/tmp']) == '/tmp/fake-prog'
    try:
        assert get_bin_path('fake-prog', ['/tmp'], True) == '/tmp/fake-prog'
        raise Exception
    except ValueError:
        pass
    try:
        assert get_bin_path('fake-prog', ['/tmp']) == '/tmp/fake-prog'
        raise Exception
    except ValueError:
        pass

# Generated at 2022-06-20 16:07:39.088484
# Unit test for function get_bin_path
def test_get_bin_path():
    import sysconfig
    # NOTE(mhayden): This logic is NOT the same logic used in get_bin_path().
    # It is only used here to get executable path for testing.
    python_dir = sysconfig.get_config_var('BINDIR')
    python_name = 'python' + sysconfig.get_config_var('VERSION')
    python_path = os.path.join(python_dir, python_name)
    if not os.path.exists(python_path):
        python_path = os.path.join(python_dir, 'python')

    assert get_bin_path(python_name) == python_path
    assert get_bin_path('foobar') == None

# Generated at 2022-06-20 16:07:50.236166
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python')
    assert get_bin_path('python', None, True)
    try:
        get_bin_path('python2')
    except Exception as e:
        assert str(e) == 'Failed to find required executable "python2" in paths: /bin:/usr/bin:/usr/local/bin'
    try:
        get_bin_path('python2', None, True)
    except Exception as e:
        assert str(e) == 'Failed to find required executable "python2" in paths: /bin:/usr/bin:/usr/local/bin'
    assert get_bin_path('python2', ['/usr/bin']) == '/usr/bin/python2'

# Generated at 2022-06-20 16:07:57.529654
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        bin_path = get_bin_path('chmod')
    except ValueError:
        assert False, "chmod in path but get_bin_path could not locate it"

    assert bin_path == '/bin/chmod'
    assert get_bin_path('/bin/chmod') == '/bin/chmod'
    try:
        get_bin_path('chmod', ['/nothing'])
        assert False, "chmod in path but get_bin_path could not locate it in additional directories"
    except ValueError:
        pass

    try:
        get_bin_path('not_a_real_program')
        assert False, "get_bin_path found a non-existent executable"
    except ValueError:
        pass

# Generated at 2022-06-20 16:08:07.326921
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    import tempfile
    import shutil

    opt_dir = tempfile.mkdtemp()
    executable = os.path.join(opt_dir, 'executable')
    open(executable, 'w').close()
    os.chmod(executable, 0o755)

    # try to find executable with additional directories
    found_path = get_bin_path(os.path.basename(to_bytes(executable)), [opt_dir])
    assert os.path.isfile(found_path)

    # check exception when executable is not found
    try:
        get_bin_path('executable-not-found', [opt_dir])
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)


# Generated at 2022-06-20 16:08:10.577006
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')
    assert get_bin_path('ls', [], True)
    assert get_bin_path('ls', required=True)

    try:
        get_bin_path('does_not_exist')
    except Exception as e:
        assert "Failed to find required" in str(e)

# Generated at 2022-06-20 16:08:12.087130
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('python')
    assert os.path.exists(bin_path)



# Generated at 2022-06-20 16:08:17.099438
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/bin/sh') == '/bin/sh'

    # Deprecated
    try:
        get_bin_path('missing_binary', required=True)
    except ValueError:
        pass

    try:
        get_bin_path('missing_binary')
    except ValueError:
        pass

# Generated at 2022-06-20 16:08:18.347541
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-20 16:08:22.922540
# Unit test for function get_bin_path
def test_get_bin_path():
    # Return None if not found
    assert get_bin_path('not-a-prog') is None
    # TODO: add tests for get_bin_path()


# Generated at 2022-06-20 16:08:25.135479
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for function get_bin_path()
    '''
    assert get_bin_path('cat') == 'cat'

# Generated at 2022-06-20 16:08:27.314192
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh', ['/bin', '/usr/bin']) == '/bin/sh'



# Generated at 2022-06-20 16:08:37.546617
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path
    '''
    if not os.path.exists('/bin/ls'):
        raise ValueError('Test skipped because /bin/ls is not found')
    ls_path = get_bin_path('ls')
    if ls_path != '/bin/ls':
        raise ValueError('Test failed for ls_path')

    if not os.path.exists('/bin/rm'):
        raise ValueError('Test skipped because /bin/rm is not found')
    rm_path = get_bin_path('/bin/rm', opt_dirs=None, required=None)
    if rm_path != '/bin/rm':
        raise ValueError('Test failed for rm_path')

    invalid_path = '/bin/invalid'

# Generated at 2022-06-20 16:08:43.504180
# Unit test for function get_bin_path
def test_get_bin_path():
    # test path is found in expected locations
    found_path = get_bin_path('python')
    assert os.sep in found_path
    assert found_path.endswith('python')

    # test path is not found in optional extra dirs
    try:
        get_bin_path('python', opt_dirs=['/dev/null'])
        assert 'expected ValueError'
    except ValueError:
        pass

# Generated at 2022-06-20 16:08:50.212907
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    test_dir1 = tempfile.mkdtemp()
    test_dir2 = tempfile.mkdtemp()
    test_dir3 = tempfile.mkdtemp()
    test_bin1 = tempfile.NamedTemporaryFile()
    test_bin2 = tempfile.NamedTemporaryFile()

    os.chmod(test_bin1.name, 0o755)
    os.chmod(test_bin2.name, 0o755)

    shutil.copy(test_bin1.name, test_dir1)
    shutil.copy(test_bin1.name, test_dir2)
    shutil.copy(test_bin2.name, test_dir3)

    test_path = os.path.basename(test_bin1.name)


# Generated at 2022-06-20 16:09:00.027069
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test PATH: /usr/bin;/usr/sbin
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('ssh') == '/usr/bin/ssh'
    assert get_bin_path('iptables') == '/usr/sbin/iptables'
    # TODO: make this test look for /usr/local/bin/ssh
    #assert get_bin_path('iptables', opt_dirs=['/usr/local/bin']) == '/usr/local/bin/iptables'

    # TODO: this test does not work on travis-ci (where PATH does not include /sbin)
    #assert get_bin_path('iptables', opt_dirs=['/sbin']) == '/sbin/iptables'

# Generated at 2022-06-20 16:09:05.109153
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('ansible-doc')
    except ValueError as e:
        assert False, 'Module failed to find ansible-doc'

    try:
        get_bin_path('not_existing')
    except ValueError as e:
        if 'Failed to find required executable "not_existing"' not in str(e):
            assert False, 'Module failed to raise error for non existing'

# Generated at 2022-06-20 16:09:07.569489
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('pwd')
    assert bin_path == '/bin/pwd'
    try:
        get_bin_path('__no_such_file__')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-20 16:09:17.910588
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path("/bin/ls")
    except ValueError:
        assert True
    else:
        assert False

    try:
        # non-existent directory
        get_bin_path("/bin/ls", ['/opt/bin'])
    except ValueError:
        assert True
    else:
        assert False

    bin_path = get_bin_path("ls", ['/opt/bin'])
    assert bin_path == get_bin_path("ls", ['/opt/bin'])
    assert bin_path == '/bin/ls'
    bin_path = get_bin_path("ls", ['/opt/bin', '/sbin', '/usr/sbin'])

# Generated at 2022-06-20 16:09:24.037244
# Unit test for function get_bin_path
def test_get_bin_path():
    for bin_name in ('echo', 'sleep'):
        bin_path = get_bin_path(bin_name)
        assert os.path.dirname(bin_path) in os.environ.get('PATH', '').split(os.pathsep)

# Generated at 2022-06-20 16:09:27.852548
# Unit test for function get_bin_path
def test_get_bin_path():
    assert os.path.isabs(get_bin_path('sh'))
    try:
        get_bin_path('bogus-program-name')
        assert False, "expected exception"
    except ValueError:
        pass

# Generated at 2022-06-20 16:09:31.259596
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == get_bin_path('python')
    assert get_bin_path('python') == get_bin_path('python', required=True)  # required is now ignored to maintain compat

# Generated at 2022-06-20 16:09:38.643962
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.path.isdir('/usr/local/bin'):  # only perform test where /usr/local/bin exists
        try:
            os.environ['PATH'] = '/usr/local/bin'
            get_bin_path('modinfo')
        except ValueError:  # 'modinfo' should be in /usr/local/bin
            raise AssertionError('modinfo was not found in the PATH')
    else:
        print("Not performing get_bin_path test since /usr/local/bin does not exist")

# Generated at 2022-06-20 16:09:47.541657
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    try:
        bin_name = 'some_fake_bin'
        tmp_path = tempfile.mkdtemp()
        bin_path = os.path.join(tmp_path, bin_name)
        with open(bin_path, 'w') as f_bin:
            f_bin.write('#!/usr/bin/env python\nprint("Hello, I am %s")\n' % bin_name)
        os.chmod(bin_path, 0o755)
        # test get_bin_path
        path = get_bin_path(bin_name)
        assert bin_path == path
    finally:
        if os.path.exists(tmp_path):
            import shutil
            shutil.rmtree(tmp_path)

# Generated at 2022-06-20 16:09:50.443725
# Unit test for function get_bin_path
def test_get_bin_path():
    my_executable = get_bin_path("bash")
    # We should have a valid path
    assert (my_executable[0] == '/')

# Generated at 2022-06-20 16:09:57.634877
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', ['/bin', '/usr/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/usr/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/bin']) == '/usr/bin/sh'
    assert get_bin_path('sh', ['/usr/bin', '/bin'], ['/sbin']) == '/usr/bin/sh'

# Generated at 2022-06-20 16:10:04.036638
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('ping') is not None)
    assert(get_bin_path('ping', ['/bin', '/sbin']) is not None)
    try:
        get_bin_path('bad_executable')
        # should not be reached
        assert False
    except ValueError:
        assert True
    try:
        get_bin_path('bad_executable', ['/bin', '/sbin'])
        # should not be reached
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-20 16:10:11.247104
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    opt_dirs = ['/usr/lib/debug', '/usr/local/sbin']
    assert get_bin_path('cat', opt_dirs) == '/bin/cat'
    assert get_bin_path('is_executable_test', opt_dirs) == '/usr/local/sbin/is_executable_test'
    assert get_bin_path('is_executable_test', opt_dirs + ['/bin']) == '/bin/is_executable_test'

# Generated at 2022-06-20 16:10:16.975843
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['/usr/bin']
    assert(get_bin_path('cat', paths) == '/usr/bin/cat')
    try:
        get_bin_path('bad_command', paths)
    except ValueError as e:
        assert 'Failed to find required executable "bad_command"' in str(e)
    else:
        assert False, 'did not catch expected exception'

# Generated at 2022-06-20 16:10:28.659070
# Unit test for function get_bin_path
def test_get_bin_path():
    # test with both args and kwargs
    def _get_bin_path(arg, **kwargs):
        r = get_bin_path(arg, **kwargs)
        # return a tuple of (path, arg) so as to keep arg for error reporting
        return (r, arg)
    # test for no such file
    try:
        _get_bin_path('no_such_file')
        assert 0
    except ValueError:
        pass
    except Exception:
        assert 0

    # setup some standard binaries
    binaries = ['/bin/true', '/bin/false']
    # test normal execution
    for b in binaries:
        (r, arg) = _get_bin_path(b)

# Generated at 2022-06-20 16:10:37.493512
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test case id: None
    Test get_bin_path
    Steps:
        1. Use get_bin_path to get path of executable
    Expected Results:
        1. Path of executable could be found
    '''
    bin_path = get_bin_path("echo")
    assert os.path.exists(bin_path)

# Generated at 2022-06-20 16:10:40.478702
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    try:
        get_bin_path('this-command-does-not-exist')
        sys.exit(1)
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    assert get_bin_path('sh')

# Generated at 2022-06-20 16:10:46.592076
# Unit test for function get_bin_path
def test_get_bin_path():
    # Unit test will only succeed as an executable in the PATH
    assert get_bin_path('ls') is not None
    try:
        get_bin_path('shouldnotexist')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    bad_path = '/this/path/should/not/exist'
    assert get_bin_path('ls', opt_dirs=[bad_path]) is not None
    try:
        get_bin_path('ls', opt_dirs=[bad_path], required=True)
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

# Generated at 2022-06-20 16:10:48.864151
# Unit test for function get_bin_path
def test_get_bin_path():
    binary = 'cat'
    bin_path = get_bin_path(binary)
    assert bin_path == '/bin/cat'

# Generated at 2022-06-20 16:10:51.689872
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path(arg='not_found_executable', opt_dirs=['.', '..'], required=False)
        raise AssertionError("Expecting 'Failed to find required executable' exception")
    except ValueError:
        pass

# Generated at 2022-06-20 16:11:02.191525
# Unit test for function get_bin_path
def test_get_bin_path():
    # when PATH is empty
    os.environ['PATH'] = ''
    opt_dir = ['/opt/bin']
    req = True
    ret = get_bin_path('cat', opt_dirs=opt_dir, required=True)
    assert '/opt/bin/cat' == ret

    # when PATH includes only /bin
    os.environ['PATH'] = '/bin'
    opt_dir = ['/opt/bin']
    req = True
    ret = get_bin_path('cat', opt_dirs=opt_dir, required=True)
    assert '/opt/bin/cat' == ret

    # when PATH includes only /bin and /usr/bin
    os.environ['PATH'] = '/bin:/usr/bin'
    opt_dir = ['/opt/bin']
    req = True

# Generated at 2022-06-20 16:11:08.231728
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test various existing binaries
    existing_bins = (
        '/bin/sh',
        '/sbin/iptables',
        '/usr/local/sbin/nginx',
        'ssh',
        'htpasswd',
        'docker',
    )
    for bin in existing_bins:
        get_bin_path(bin)

    # Test non-existing binary
    failed = False
    try:
        get_bin_path('test-bin-doesnotexist')
    except ValueError:
        failed = True
    assert failed


# Generated at 2022-06-20 16:11:17.512959
# Unit test for function get_bin_path
def test_get_bin_path():
    # Unit test 1: missing path
    try:
        get_bin_path('/bin/foo')
        assert False
    except ValueError:
        assert True

    # Unit test 2: missing executable within PATH
    try:
        get_bin_path('non_existent')
        assert False
    except ValueError:
        assert True

    # Unit test 3: use optional arguments opt_dirs and required
    # Prior to 2.10, if required is true, it raises an Exception when executable is not found.
    # In 2.10 and later, an Exception is always raised.
    # This parameter will be removed in 2.14.
    try:
        get_bin_path('non_existent', opt_dirs=['/bin'], required=True)
        assert False
    except ValueError:
        assert True

    # Unit test 4

# Generated at 2022-06-20 16:11:21.348823
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('cat')
    except:
        assert False, 'Failed to find cat executable in PATH'
    else:
        assert True

# Generated at 2022-06-20 16:11:36.703729
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    from contextlib import contextmanager

    @contextmanager
    def set_sys_executable(new_executable):
        old_executable = sys.executable
        sys.executable = new_executable
        try:
            yield
        finally:
            sys.executable = old_executable

    sys_executable = sys.executable
    assert sys_executable == os.path.basename(sys_executable)
    bin_path = get_bin_path(sys_executable)
    assert len(bin_path) > len(sys_executable)

    # Pretend that sys.executable is "python"
    with set_sys_executable('python'):
        bin_path = get_bin_path(sys_executable)


# Generated at 2022-06-20 16:11:48.299173
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'

# Generated at 2022-06-20 16:11:59.667346
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('cat')
    assert bin_path.endswith('cat')
    assert os.path.exists(bin_path)
    assert not os.path.isdir(bin_path)
    assert is_executable(bin_path)

    dir1 = os.path.dirname(bin_path)
    bin_path2 = get_bin_path('cat', opt_dirs=[dir1])
    assert bin_path == bin_path2

    dir2 = os.path.dirname(dir1)
    bin_path3 = get_bin_path('cat', opt_dirs=[dir1, dir2])
    assert bin_path == bin_path3

    # test that it is not found in a subdirectory

# Generated at 2022-06-20 16:12:03.207285
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert not '/usr/sbin/httpd' in get_bin_path('httpd', ['/usr/sbin', '/usr/local/sbin'])

# Generated at 2022-06-20 16:12:08.688306
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/bin/sh')
        get_bin_path('sh')
        get_bin_path('sh', ['/bin'])
        get_bin_path('sh', ['/bin'], True)
    except ValueError:
        raise AssertionError('test_get_bin_path failed')


# Generated at 2022-06-20 16:12:14.788575
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        err = get_bin_path('foo', ['/usr/bin'])
    except ValueError as e:
        assert 'Failed to find required executable "foo"' in str(e)
        assert '/usr/bin' in str(e)
    else:
        raise AssertionError('ValueError expected')

    try:
        err = get_bin_path('foo', required=False, opt_dirs=[])
    except ValueError as e:
        assert 'Failed to find required executable "foo"' in str(e)
    else:
        raise AssertionError('ValueError expected')

    try:
        err = get_bin_path('foo', opt_dirs=[])
    except ValueError as e:
        assert 'Failed to find required executable "foo" in paths' in str(e)

# Generated at 2022-06-20 16:12:19.223232
# Unit test for function get_bin_path
def test_get_bin_path():
    assert('/bin/sh' == get_bin_path('sh'))
    assert('/bin/sh' == get_bin_path('sh', opt_dirs=['/usr/bin']))
    try:
        get_bin_path('doesnotexist')
    except:
        pass
    else:
        assert(False) # Should have raised exception

# Generated at 2022-06-20 16:12:31.100200
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Test cases for function get_bin_path'''
    # case 1
    # test missing executable
    try:
        path = get_bin_path('not.exists')
    except ValueError:
        pass
    else:
        assert(False, 'Should have raised ValueError for missing executable')
    # case 2
    # test a missing directory
    try:
        path = get_bin_path('/tmp/does_not_exist/not.exists')
    except ValueError:
        pass
    else:
        assert(False, 'Should have raised ValueError for missing executable')
    # case 3
    # test a regular file (not executable)
    try:
        path = get_bin_path('/etc/hosts')
    except ValueError:
        pass

# Generated at 2022-06-20 16:12:33.613984
# Unit test for function get_bin_path
def test_get_bin_path():
    # Find an executable in the system path
    assert get_bin_path('sh') is not None


# pylint: disable=locally-disabled,redefined-builtin

# Generated at 2022-06-20 16:12:43.802326
# Unit test for function get_bin_path
def test_get_bin_path():

    from ansible.module_utils._text import to_bytes
    from tempfile import mkdtemp
    import shutil
    import stat

    # create an executable file
    test_dir = mkdtemp()
    test_path = os.path.join(test_dir, 'test_file')
    test_data = to_bytes('#!/bin/sh\necho test script\n')
    with open(test_path, 'w') as test_file:
        test_file.write(test_data)
    os.chmod(test_path, stat.S_IRWXU)

    # test get_bin_path with the file
    result = get_bin_path('test_file', opt_dirs=[test_dir])
    assert result == test_path

    # test get_bin_path with empty opt_dir

# Generated at 2022-06-20 16:12:48.570190
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('python')
    assert bin_path.endswith('python')

# Generated at 2022-06-20 16:12:53.010026
# Unit test for function get_bin_path
def test_get_bin_path():
    path = '/bin'
    arg = 'cat'
    try:
        get_bin_path(arg, ['/bin'])
    except ValueError:
        assert True
    else:
        assert False
    try:
        get_bin_path(arg, ['/bin', '/usr/bin'])
    except ValueError:
        assert False
    else:
        assert True

# Generated at 2022-06-20 16:13:01.299912
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('my_invalid_executable')
        assert False, 'expected an exception'
    except ValueError:
        pass

    assert get_bin_path('sh') == '/bin/sh'

    # Simulate a valid executable that is not in the PATH
    with open('/tmp/ansible_unit_test_executable', 'w') as f:
        f.write('#!/bin/sh')
    os.chmod('/tmp/ansible_unit_test_executable', 0o755)
    assert get_bin_path('ansible_unit_test_executable', opt_dirs=['/tmp']) == '/tmp/ansible_unit_test_executable'
    assert get_bin_path('ansible_unit_test_executable', required=False) is None
   

# Generated at 2022-06-20 16:13:04.035168
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function found in module_utils.common.file.
    :return:
    '''
    result = get_bin_path('python')
    assert result is not None

# Generated at 2022-06-20 16:13:12.922090
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.facts.misc.get_bin_path import get_bin_path
    import pytest

    def test_get_bin_path(arg, opt_dirs=None, required=False, expected=None):
        paths = get_bin_path(arg, opt_dirs, required)
        assert paths == expected

    with pytest.raises(ValueError):
        test_get_bin_path("invalid_foo")

    # When the executable exists only in PATH and not opt_dirs
    test_get_bin_path("python", opt_dirs=['/usr/bin'], expected='/usr/bin/python')

    # When the executable exists in opt_dirs and not in PATH

# Generated at 2022-06-20 16:13:19.195176
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        bin_path = get_bin_path('pwd', ['.'])
    except ValueError as e:
        assert False, 'Failed to find executable: %s' % to_text(e)
    assert bin_path == os.path.abspath('pwd')

# Generated at 2022-06-20 16:13:29.122351
# Unit test for function get_bin_path
def test_get_bin_path():
    """Main function. Optionally takes command line arguments."""
    try:
        get_bin_path('true')
    except ValueError:
        print('FAIL: module_utils.common.get_bin_path failed to find true executable in path')
    else:
        print('PASS: module_utils.common.get_bin_path found true executable in path')
    try:
        get_bin_path('cmd-does-not-exist-xuz')
    except ValueError:
        print('PASS: module_utils.common.get_bin_path correctly raised ValueError exception when command not found')
    else:
        print('FAIL: module_utils.common.get_bin_path failed to raise ValueError exception when command not found')


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-20 16:13:34.893286
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with find command
    assert get_bin_path('find') == '/usr/bin/find'

    # Test with file not found
    try:
        get_bin_path('test', required=True)
        assert False, "expected an Exception"
    except ValueError:
        pass

    # Test with optional directory
    assert get_bin_path('find', opt_dirs=['/usr/bin']) == '/usr/bin/find'

    # Test with optional directory and file not found
    try:
        get_bin_path('test', opt_dirs=['/usr/bin'], required=True)
        assert False, "expected an Exception"
    except ValueError:
        pass

test_get_bin_path()

# Generated at 2022-06-20 16:13:39.022835
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python2') == '/usr/bin/python2'
    assert get_bin_path('python3') == '/usr/bin/python3'

# Generated at 2022-06-20 16:13:51.953100
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    This function is not a test case. It provides a test harness for the
    get_bin_path function.

    Returns:
        A dictionary containing test result information.
    '''
    # Setup - nothing to do
    # Exercise - test get_bin_path()
    # Teardown - delete any files created in test
    module_results = dict(
        failed=False,
        changed=False,
        msg='',
        rc=0,
    )
    bin_paths = []
    # Some of the bins we test for are not guaranteed to be there, so
    # capture the failure messages so we can verify them.

# Generated at 2022-06-20 16:14:03.872840
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check required is passed as expected
    for required in (None, 'False', 'True', False, True):
        try:
            get_bin_path('no-such-executable-exists-anywhere', required=required)
        except ValueError as e:
            assert required not in str(e)
        else:
            assert required not in (True, 'True')

    # Check get_bin_path returns the correct path
    try:
        result = get_bin_path('bash', required=False)
    except ValueError:
        result = ''
    assert result == '/bin/bash'

# Generated at 2022-06-20 16:14:12.322657
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' Unit test for function get_bin_path '''
    bin_path = get_bin_path('sh')
    assert bin_path == '/bin/sh'
    bin_path = get_bin_path('sh', opt_dirs=['/bin', '/usr/bin'])
    assert bin_path == '/bin/sh'
    bin_path = get_bin_path('sh', opt_dirs=['/usr/bin', '/bin'])
    assert bin_path == '/bin/sh'
    bin_path = get_bin_path('sh', opt_dirs=['/this/path/does/not/exist'])
    assert bin_path == '/bin/sh'

# Generated at 2022-06-20 16:14:18.726251
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for success
    path = get_bin_path('cat')
    assert path
    assert os.path.exists(path)

    # Test for failure
    try:
        get_bin_path('this_does_not_exist')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

    # Test for success with optional path
    path = get_bin_path('cat', ['/bin'])
    assert path
    assert os.path.exists(path)
    assert path.startswith('/bin')

    # Test for failure with optional path
    try:
        get_bin_path('this_does_not_exist', ['/bin'])
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

    # Test

# Generated at 2022-06-20 16:14:30.164827
# Unit test for function get_bin_path
def test_get_bin_path():

    #
    # Test 1
    #
    # Test for failure to find executable
    #
    try:
        bp = get_bin_path('non_existent_executable')
    except Exception as e:
        pass
    else:
        assert False, "Expected to fail, but succeeded"
    #
    # Test 2
    #
    # Test for finding executable in current path
    #
    try:
        bp = get_bin_path('which')
    except Exception as e:
        assert False, "Unexpected failure to find executable: " + str(e)
    else:
        if not os.path.exists(bp):
            assert False, "Executable found but it does not exist: " + bp

# Generated at 2022-06-20 16:14:34.991813
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('python')
    assert bin_path == '/usr/bin/python'
    bin_path = get_bin_path('python', ['/usr/bin'])
    assert bin_path == '/usr/bin/python'
    try:
        get_bin_path('does_not_exist')
    except ValueError as e:
        assert "Failed to find required executable 'does_not_exist'" in str(e)

# Generated at 2022-06-20 16:14:39.030283
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('ls')
    assert path.endswith('ls')
    path = get_bin_path('awk')
    assert path.endswith('awk')


# Generated at 2022-06-20 16:14:45.754053
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    tmpdir = tempfile.mkdtemp()

    assert os.environ.get('PATH') is not None

    # clean-up
    shutil.rmtree(tmpdir)

# Generated at 2022-06-20 16:14:47.888013
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls', None, None)
    assert get_bin_path("ls", ["/bin"], None)
    assert get_bin_path("ls", [], None)