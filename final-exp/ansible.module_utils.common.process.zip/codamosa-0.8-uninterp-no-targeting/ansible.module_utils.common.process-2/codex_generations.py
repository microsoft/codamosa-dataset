

# Generated at 2022-06-20 16:04:55.498632
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh';
    assert get_bin_path('sh', opt_dirs=['/dev/null']) == '/bin/sh';

# Generated at 2022-06-20 16:05:05.787246
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import tempfile

    path_dir = tempfile.mkdtemp()
    os.chmod(path_dir, 0o755)
    os.environ['PATH'] = path_dir
    try:
        path = os.path.join(path_dir, 'ansible-test')
        path_file = open(path, 'w')
        path_file.write('#!/bin/sh\n')
        path_file.write('echo -n $0\n')
        path_file.close()
        os.chmod(path, 0o755)
        assert get_bin_path('ansible-test') == path
    except AssertionError:
        raise AssertionError('get_bin_path failed test')
    finally:
        del os.environ['PATH']

# Generated at 2022-06-20 16:05:11.369889
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.compat import TemporaryDirectory
    from ansible.module_utils.common.file import atomic_open

    with TemporaryDirectory(prefix='ansible_test_get_bin_path_') as tmpdir:
        binary_path = os.path.join(tmpdir, 'test_binary')
        with open(binary_path, 'w') as f:
            f.write('#!/bin/sh\n')
        os.chmod(binary_path, 0o755)
        assert get_bin_path('test_binary', opt_dirs=[tmpdir]) == binary_path

# Generated at 2022-06-20 16:05:18.602190
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test normal use with module_utils.common.file.is_executable mocked
    class IsExecutableMock(object):
        def __init__(self):
            self.call_args_list = []
            self.call_args_list = []

        def __call__(self, path):
            self.call_args_list.append(path)
            return True

    mock_is_executable = IsExecutableMock()

    class MockPathModule(object):
        def __init__(self):
            self.exists_call_args_list = []
            self.isdir_call_args_list = []
            self.join_call_args_list = []

        def exists(self, path):
            self.exists_call_args_list.append(path)
            return True


# Generated at 2022-06-20 16:05:27.084185
# Unit test for function get_bin_path
def test_get_bin_path():
    import mock

    def _fake_exists(filename):
        if filename == '/sbin/bad_executable':
            return False
        else:
            return True

    class MockPopen(object):
        def __init__(self, cmd, shell=False, stdin=None, stdout=None, stderr=None,
                     preexec_fn=None, close_fds=True, env=None):
            self.cmd = cmd
            self.returncode = 0
            self.stdout = b''
            self.stderr = b''

        def communicate(self):
            return self.stdout, self.stderr

    mock_exists = mock.MagicMock(side_effect=_fake_exists)

# Generated at 2022-06-20 16:05:37.366988
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import subprocess

    python3_dirs = ['',
                    os.path.dirname(sys.executable),
                    os.path.dirname(sys.executable) + os.sep + '..' + os.sep + 'bin',
                    '/usr/bin',
                    '/bin']
    python2_dirs = ['',
                    os.path.dirname(sys.executable),
                    '/usr/bin',
                    '/bin']

    for d in python3_dirs:
        try:
            python3_path = get_bin_path('python3', [d], required=True)
            subprocess.check_call([python3_path, '--version'], stderr=subprocess.STDOUT)
            break
        except:
            continue

# Generated at 2022-06-20 16:05:48.511219
# Unit test for function get_bin_path
def test_get_bin_path():
    # Run the function with a normal path
    assert get_bin_path('/bin/sh') == '/bin/sh'

    # Run with a normal path where no executable is found
    try:
        get_bin_path('/foo/bar')
    except ValueError:
        pass
    else:
        assert False, 'ValueError not raised'

    # Run with a normal path where the executable is a directory
    try:
        get_bin_path('/bin')
    except ValueError:
        pass
    else:
        assert False, 'ValueError not raised'

    # Run with a path without a dir component
    # Testing /sbin
    assert get_bin_path('ls') in ['/bin/ls', '/usr/bin/ls']
    # Testing /usr/sbin

# Generated at 2022-06-20 16:06:00.494725
# Unit test for function get_bin_path
def test_get_bin_path():

    if 'PATH' not in os.environ:
        os.environ['PATH'] = '/usr/bin:/bin'
    assert get_bin_path('sysctl') == '/usr/sbin/sysctl'
    assert get_bin_path('sysctl', opt_dirs=['/usr/bin', '/bin']) == '/usr/sbin/sysctl'
    assert get_bin_path('sysctl', opt_dirs=['/usr/bin', '/bin'], required=False) == '/usr/sbin/sysctl'
    os.environ['PATH'] = '/usr/bin:/bin'
    assert get_bin_path('sysctl') == '/usr/bin/sysctl'

# Generated at 2022-06-20 16:06:06.850524
# Unit test for function get_bin_path
def test_get_bin_path():
    # Lets find world-writable directory for unit-test
    for d in ('.', '/tmp', '/var/tmp'):
        if os.path.isdir(d) and os.stat(d).st_mode & 0o007:
            tmpdir = d
            break
    else:
        tmpdir = '/'             # Just to make checker happy

    # Create files for test
    test_file_1 = os.path.join(tmpdir, 'test_file_1')
    test_file_2 = os.path.join(tmpdir, 'test_file_2')
    test_file_3 = os.path.join(tmpdir, 'test_file_3')
    test_file_4 = os.path.join(tmpdir, 'test_file_4')

# Generated at 2022-06-20 16:06:11.495666
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert get_bin_path('cat') == '/bin/cat'
        assert get_bin_path('ntpdate') == '/usr/sbin/ntpdate'
    except ValueError:
        # we may not have all of the executables
        pass

# Generated at 2022-06-20 16:06:23.044967
# Unit test for function get_bin_path
def test_get_bin_path():
    PATH = ['/usr/bin:/bin']
    EXE = 'ls'
    EXPECTED_RETURN = '/bin/ls'

    assert get_bin_path(EXE) == EXPECTED_RETURN
    assert get_bin_path(EXE, opt_dirs=PATH) == EXPECTED_RETURN

    # test ValueError exception
    try:
        get_bin_path('bad_exe')
    except ValueError:
        pass
    else:
        raise AssertionError("ValueError was not raised for bad exe")

# Generated at 2022-06-20 16:06:31.214133
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') is not None
    assert get_bin_path('sh', ['/bin']) is not None
    assert get_bin_path('sh', []) is not None
    assert get_bin_path('sh', [None]) is not None
    try:
        get_bin_path('nonexist')
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')

# Generated at 2022-06-20 16:06:36.918564
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test existing path with path override
    bin_path = get_bin_path('sh', opt_dirs=['/usr/sbin', '/sbin'])
    assert bin_path == '/sbin/sh'
    # Test existing path without path override
    bin_path = get_bin_path('sh')
    assert bin_path == '/bin/sh'
    # Test non-existent path
    try:
        get_bin_path('foo')
    except ValueError:
        pass

# Generated at 2022-06-20 16:06:42.024268
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test for ansible package
    ansible_path = get_bin_path('ansible')
    assert os.path.exists(ansible_path)

    # Test for python executable
    python_path = get_bin_path('python')
    assert os.path.exists(python_path)

# Generated at 2022-06-20 16:06:50.093732
# Unit test for function get_bin_path
def test_get_bin_path():
    '''This function is not a real unit test, but is used
    to compare results of function get_bin_path under Python2 and Python3
    '''
    import platform
    import sys


# Generated at 2022-06-20 16:06:58.985742
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Unit test for function get_bin_path'''
    import sys
    import unittest
    import uuid

    class TestGetBinPath(unittest.TestCase):
        '''Tests class for function get_bin_path'''

        def setUp(self):
            '''Setup test environment'''
            self.required = True
            self.opt_dirs = None
            self.temp_dir = '/tmp/ansible_test_%s' % uuid.uuid4().hex
            self.temp_bin_path = '%s/test_get_bin_path' % self.temp_dir

            os.mkdir(self.temp_dir)

# Generated at 2022-06-20 16:07:06.433921
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    # Create empty directories
    test_dir = tempfile.mkdtemp(prefix='ansible_test_get_bin_path_')


# Generated at 2022-06-20 16:07:12.157127
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    d = tempfile.mkdtemp()

    try:
        # Create a temporary file executable
        fd, path = tempfile.mkstemp(prefix='ansible_test_get_bin_path_')
        os.chmod(path, 0o755)
        os.close(fd)

        # Should raise an exception if no path is provided
        try:
            get_bin_path(os.path.basename(path))
        except ValueError:
            pass
        else:
            assert False

        # Should find executable in temp dir
        assert get_bin_path(os.path.basename(path), opt_dirs=[d]) == path
    finally:
        shutil.rmtree(d, ignore_errors=True)

# Generated at 2022-06-20 16:07:23.611311
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    class MockPopen:
        def __init__(self, cmd, stdout, stderr):
            self.stdout = stdout
            self.stderr = stderr

    def mock_popen(cmd, *args):
        if cmd[0] == 'yum':
            return MockPopen(cmd, '', 'foo')
        return MockPopen(cmd, 'bar', '')

    # Create a temporary directory and add it to PATH
    temp_path = tempfile.mkdtemp()
    os.environ['PATH'] = temp_path + ":" + os.environ['PATH']

    # Create a fake binary that returns True
    fake_bin = os.path.join(temp_path, 'fake-bin')

# Generated at 2022-06-20 16:07:33.130485
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('rsync')
    try:
        get_bin_path('notreally')
    except ValueError:
        pass
    else:
        assert False, "Command notreally found but it should not exist"

    assert get_bin_path('rsync', ['/usr/local/bin'])
    try:
        get_bin_path('notreally', ['/usr/local/bin'])
    except ValueError:
        pass
    else:
        assert False, "Command notreally found but it should not exist"

    assert get_bin_path('rsync', ['/usr/local/bin', '', '.'])
    try:
        get_bin_path('notreally', ['/usr/local/bin', '', '.'])
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-20 16:07:44.718245
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import os
    tempdir = tempfile.mkdtemp()
    testdir = os.path.join(tempdir, 'bin')
    os.makedirs(testdir)
    file1 = os.path.join(testdir, 'test1')
    file2 = os.path.join(testdir, 'test2')
    with open(file1, 'w') as f:
        f.write('#!/bin/bash')
    with open(file2, 'w') as f:
        f.write('#!/bin/bash')
        f.write('exit 1')
    os.chmod(file1, 0o777)
    os.chmod(file2, 0o777)


# Generated at 2022-06-20 16:07:57.208469
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils import basic

    # Do not make this a global variable because it breaks the unit test.
    # This is a bug in the way ansible does the unit test.
    module = basic.AnsibleModule(
        argument_spec=dict(
            opt_dirs=dict(type='list'),
        ),
    )

    module.run_command = lambda *args, **kwargs: (0, "", "")
    assert get_bin_path("ifconfig") == '/sbin/ifconfig'
    assert get_bin_path("ifconfig", opt_dirs=['/bin']) == '/bin/ifconfig'
    assert get_bin_path("ifconfig", opt_dirs=['/bin', '/sbin']) == '/bin/ifconfig'

# Generated at 2022-06-20 16:08:06.598214
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest

    path = get_bin_path('/bin/sh')
    assert path == '/bin/sh'

    # test that PATH is searched if arg is not an absolute path
    path = get_bin_path('sh')
    assert path == '/bin/sh'

    with pytest.raises(ValueError):
        path = get_bin_path('doesnotexist')

    with pytest.raises(ValueError):
        path = get_bin_path('/bin/doesnotexist')

    # test that opt_dirs and PATH are both searched
    path = get_bin_path('sh', opt_dirs=['/usr/local/bin'])
    assert path == '/usr/local/bin/sh'

# Generated at 2022-06-20 16:08:17.022346
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = '/bin/date'
    assert bin_path == get_bin_path('date')

    bin_path = '/sbin/reboot'
    assert bin_path == get_bin_path('reboot', [])

    bin_path = '/bin/ls'
    assert bin_path == get_bin_path('ls', ['/bin', '/usr/bin'])
    assert bin_path == get_bin_path('ls', required=False)

    import pytest
    with pytest.raises(ValueError) as excinfo:
        get_bin_path('ls', ['/bin', '/usr/bin'], required=True)
    assert 'Failed to find required executable' in str(excinfo.value)

# Generated at 2022-06-20 16:08:23.467566
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('true')
    except ValueError as e:
        assert False, 'get_bin_path should have found /bin/true but raised a ValueError: %s' % e

    try:
        get_bin_path('no_such_thing')
        assert False, 'get_bin_path should have raised a ValueError for "no_such_thing"'
    except ValueError:
        pass

# Generated at 2022-06-20 16:08:33.545167
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/ls', required=False) == '/bin/ls'
    assert get_bin_path('./ls') == './ls'
    assert get_bin_path('test_get_bin_path', opt_dirs=['/tmp']) == '/tmp/test_get_bin_path'
    import pytest
    with pytest.raises(ValueError):
        get_bin_path('invalid_executable')
    with pytest.raises(ValueError):
        get_bin_path('invalid_executable', required=False)

    # make sure PATH is searched correctly

# Generated at 2022-06-20 16:08:44.240234
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/sbin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/sbin', '/usr/local/sbin']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/sbin', '/usr/local/sbin', '/sbin']) == '/bin/ls'

# Generated at 2022-06-20 16:08:54.294545
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.utils.path import makedirs_safe

    file_path = os.path.expanduser("~/.ansible/tmp/gbin_test/usr/local/sbin")
    makedirs_safe(file_path)

    test_bin1 = "ansible_test_bin"
    test_bin2 = "ansible_test_bin2"

    with open(os.path.join(file_path, test_bin1), 'w') as f:
        f.write("test")

    orig_path = os.environ.get('PATH', '')
    open(os.path.join(file_path, test_bin2), 'w').close()
    os.environ['PATH'] = file_path


# Generated at 2022-06-20 16:08:57.755241
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Function to unit test get_bin_path function
    '''
    import sys

    try:
        get_bin_path('ansible-config')
        assert True
    except:
        assert False

# Generated at 2022-06-20 16:09:07.572437
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' test get_bin_path function '''

    import sys
    import tempfile
    import shutil

    # 1. test with bogus executable
    try:
        get_bin_path('bogus_executable')
        assert False
    except ValueError:
        pass

    # 2. test with python executable
    python_executable = get_bin_path('python')
    if sys.version_info[0] == 2:
        assert python_executable == sys.executable
    else:
        assert python_executable.endswith('python2') or python_executable.endswith('python2.7')

    # 3. test with yum
    yum_executable = get_bin_path('yum')
    assert yum_executable.endswith('yum') or yum_executable

# Generated at 2022-06-20 16:09:20.291324
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        import __builtin__
    except ImportError:
        import builtins
        __builtin__ = builtins
    # Test case 1: No exception
    get_bin_path('python')
    # Test case 2: Raise exception (File not found)
    try:
        __builtin__.open = lambda x: None
        get_bin_path('python')
    except ValueError as e:
        assert 'Failed to find required executable "python"' in str(e)
    except OSError as e:
        assert 'Failed to find required executable "python"' in str(e)
    finally:
        __builtin__.open = open



# Generated at 2022-06-20 16:09:28.362748
# Unit test for function get_bin_path
def test_get_bin_path():
    # This test requires a Linux host
    if os.name != 'posix':
        return

    # If the system executable is not found, get_bin_path raises ValueError
    try:
        get_bin_path('this_is_not_a_real_executable')
        # Should never get here, so raise AssertionError
        raise AssertionError()
    except ValueError:
        pass

    # If the system executable is found, get_bin_path returns the full path
    assert os.path.exists(get_bin_path('ls'))

# Generated at 2022-06-20 16:09:39.141310
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Cover the following conditions
    1. Executable within PATH
    2. Executable in optional dir
    3. Non-existent executable in optional dir
    4. Non-existent executable in PATH
    '''
    # Executable within PATH
    bin_path = get_bin_path('/bin/sh')
    assert bin_path == '/bin/sh'
    # Executable in optional dir
    opt_dirs = ['/sbin']
    bin_path = get_bin_path('/sbin/init', opt_dirs)
    assert  bin_path == '/sbin/init'
    # Non-existent executable in optional dir
    opt_dirs = ['/sbin']

# Generated at 2022-06-20 16:09:47.912255
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('sh')
    assert path == '/bin/sh'
    path = get_bin_path('sh', opt_dirs=['/usr/bin'])
    assert path == '/usr/bin/sh'
    path = get_bin_path('sh', opt_dirs=['/bin'])
    assert path == '/bin/sh'
    path = get_bin_path('sh', opt_dirs=['/usr/bin'])
    assert path == '/usr/bin/sh'
    path = get_bin_path('sh', opt_dirs=['/bin'], required=True)
    assert path == '/bin/sh'
    path = get_bin_path('sh', opt_dirs=['/usr/bin'])
    assert path == '/usr/bin/sh'

# Generated at 2022-06-20 16:09:59.104250
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil


# Generated at 2022-06-20 16:10:08.000394
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    print("Testing get_bin_path with valid executable in script directory")
    bin_path = get_bin_path("test_get_bin_path")
    assert bin_path ==  os.path.realpath(__file__), "Path returned by get_bin_path is not correct"

    print("Testing get_bin_path with executable in PATH")
    bin_path = get_bin_path("echo")
    assert os.path.realpath(os.path.join(os.path.dirname(bin_path),"echo")) ==  bin_path, "Path returned by get_bin_path is not correct"

    print("Testing get_bin_path with executable not in PATH")

# Generated at 2022-06-20 16:10:19.084537
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        path = get_bin_path('cat')
    except ValueError as e:
        path = None
        assert False, 'Failed to get path for cat.'
    assert path.endswith('cat'), 'Returned path %s not valid path to cat' % path

    try:
        path = get_bin_path('doesnt_exist')
        assert False, 'Unexpected success in getting path for doesnt_exist.'
    except ValueError as e:
        path = None
    assert path is None, 'Unexpectedly got path for doesnt_exist'

    try:
        path = get_bin_path('cat', opt_dirs=['/bin'])
    except ValueError as e:
        path = None
        assert False, 'Failed to get path for cat.'

# Generated at 2022-06-20 16:10:27.070705
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('python')
    get_bin_path('python', required=True)
    get_bin_path('python', opt_dirs=['/usr/bin', '/usr/local/bin'])
    get_bin_path('python', opt_dirs=['/usr/bin', '/usr/local/bin'], required=True)
    # Should raise ValueError
    try:
        get_bin_path('this_python_is_not_available')
    except ValueError:
        pass
    try:
        get_bin_path('this_python_is_not_available', required=True)
    except ValueError:
        pass

# Generated at 2022-06-20 16:10:35.871342
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    # Create local temp directory
    tmpdir = tempfile.mkdtemp()

    # test all cases

# Generated at 2022-06-20 16:10:42.823934
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with valid executable file name
    assert get_bin_path('/bin/ls') == '/bin/ls'

    # Test with invalid executable file name
    try:
        get_bin_path('/bin/does_not_exist')
    except ValueError as e:
        assert 'Failed to find required executable "/bin/does_not_exist"' in str(e)

    # Test with valid executable file name and custom paths
    assert get_bin_path('ls', opt_dirs=['/bin', '/sbin']) == '/bin/ls'

    # Test with invalid executable file name and custom paths

# Generated at 2022-06-20 16:10:56.502808
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    import tempfile
    from ansible.module_utils.six import PY3

    test_paths = tempfile.mkdtemp()

    test_exe = os.path.join(test_paths, "test_get_bin_path_1")
    with open(test_exe, "w") as test_exe_fd:
        test_exe_fd.write("#! /bin/sh\necho -n")
    os.chmod(test_exe, int("0700", 8))
    if PY3:
        os.fsencode(test_exe)


# Generated at 2022-06-20 16:11:01.871825
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible import constants as C

    # Check that not implemented error is raised for unsupported platforms
    if not C.DEFAULT_SUDO_PATH:
        try:
            get_bin_path('sudo')
        except NotImplementedError:
            pass
    else:
        assert get_bin_path('sudo') is not None

    # Testing that if binary is not in PATH, ValueError is raised
    try:
        get_bin_path('this_binary_does_not_exist')
    except ValueError:
        pass

# Generated at 2022-06-20 16:11:06.098422
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('not_here')
        assert 0
    except:
        assert 1


# Generated at 2022-06-20 16:11:13.865944
# Unit test for function get_bin_path
def test_get_bin_path():
    # stubs
    test_paths = ['/foo/bar']
    arg = 'test_executable'

    # Test #1: Executable found in PATH
    os.environ['PATH'] = '/usr/bin'
    bin_path = get_bin_path(arg)
    assert bin_path == '/usr/bin/test_executable'

    # Test #2: Executable not found in PATH
    try:
        bin_path = get_bin_path(arg)
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "test_executable" in paths: /usr/bin'

    # Test #3: Optional directory list passed
    os.environ['PATH'] = '/foo/bar'

# Generated at 2022-06-20 16:11:23.519815
# Unit test for function get_bin_path
def test_get_bin_path():
    # test with a valid executable in path and not required
    get_bin_path('/bin/ls')
    # test with a valid executable on the outside of path and not required
    get_bin_path('ls', ['/'])
    # test with a valid executable in path, not required and extra opt_dir
    get_bin_path('ls', ['/opt/bin'])
    # test with a invalid executable in path and required
    try:
        get_bin_path('/bin/fake')
    except Exception as e:
        assert(str(e) == 'Failed to find required executable "/bin/fake" in paths: %s' % os.environ.get('PATH', ''))
    # test with a invalid executable in path and not required

# Generated at 2022-06-20 16:11:27.181879
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.utils.path import unfrackpath

    assert get_bin_path('ansible-config') == unfrackpath('~/.ansible/venv/bin/ansible-config')
    assert get_bin_path('/bin/bash') == '/bin/bash'

# Generated at 2022-06-20 16:11:38.929056
# Unit test for function get_bin_path
def test_get_bin_path():

    import random


# Generated at 2022-06-20 16:11:51.001856
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    from . import exit_json, fail_json, AnsibleModule

    def get_bin_path_runner(module, arg, opt_dirs=None):
        ''' Test runner for get_bin_path '''

        try:
            result = get_bin_path(arg, opt_dirs)
        except ValueError as e:
            module.fail_json(msg=to_bytes(e), exception=format_exc())

        return result

    module = AnsibleModule(
        argument_spec=dict(
            arg=dict(required=True),
            opt_dirs=dict(type='list', default=None),
        ),
        supports_check_mode=True
    )

    arg = module.params['arg']
    opt_dirs = module.params

# Generated at 2022-06-20 16:11:54.842143
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Should return full path to python executable'''
    assert get_bin_path('python') == '/usr/bin/python'

# Generated at 2022-06-20 16:11:59.294168
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('true') == '/bin/true'
    # make sure opt_dirs returns the first match in the list of directories
    assert get_bin_path('true', opt_dirs=['/bin', '/usr/bin']) == '/bin/true'

# Generated at 2022-06-20 16:12:15.906809
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path(None)
        assert False, 'Failed to raise ValueError when no arg is passed to get_bin_path()'
    except ValueError:
        pass

    try:
        get_bin_path('')
        assert False, 'Failed to raise ValueError when empty arg is passed to get_bin_path()'
    except ValueError:
        pass

    try:
        get_bin_path('foo')
        assert False, 'Failed to raise ValueError when non-existent executable passed to get_bin_path()'
    except ValueError:
        pass

    try:
        get_bin_path('bash')
        get_bin_path('bash', required=True)
    except ValueError:
        assert False, 'Raised ValueError when passed valid executable'


# Generated at 2022-06-20 16:12:19.638901
# Unit test for function get_bin_path
def test_get_bin_path():
    print(get_bin_path('true', ['.']))
    print(get_bin_path('true', ['.', '/sbin']))
    # If script is executed as '__main__', run unit tests
    import sys
    if sys.argv[0] == __file__:
        test_get_bin_path()

# Generated at 2022-06-20 16:12:31.572065
# Unit test for function get_bin_path
def test_get_bin_path():
    # stub PATH
    os.environ['PATH'] = "/usr/bin:/bin"
    # test found
    f = get_bin_path("ls")
    assert f == "/bin/ls"
    # test not found
    try:
        f = get_bin_path("not-there")
    except ValueError:
        pass
    else:
        assert False, "failed to raise"
    # test with opt_dirs
    f = get_bin_path("ls", opt_dirs=["/usr/bin", "/bin"])
    assert f == "/bin/ls"
    # test with opt_dirs but not in path
    try:
        f = get_bin_path("ls", opt_dirs=["/tmp"])
    except ValueError:
        pass

# Generated at 2022-06-20 16:12:40.148907
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # Create temporary file
    temp_d = tempfile.mkdtemp()
    touch_path = os.path.join(temp_d, 'touch')
    touch_cmd = "touch %s" % touch_path
    os.system(touch_cmd)

    # Make sure file exists
    assert os.path.isfile(touch_path)

    # Find the path
    bin_path = get_bin_path('touch')
    assert bin_path == touch_path

    # Clean up
    os.remove(touch_path)
    os.rmdir(temp_d)



# Generated at 2022-06-20 16:12:45.580167
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no_such_program')
    except ValueError as e:
        assert e.args[0] == 'Failed to find required executable "no_such_program" in paths: '
    else:
        assert False, "expected ValueError"



# Generated at 2022-06-20 16:12:49.436335
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    basic test for get_bin_path using command 'which'
    '''
    bin_path = get_bin_path('which', ['/usr/bin'])
    assert bin_path == '/usr/bin/which'

# Generated at 2022-06-20 16:12:55.487729
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    try:
        get_bin_path('sh', opt_dirs=['/usr/bin'])
    except ValueError as e:
        assert str(e) == 'Failed to find required executable \"sh\" in paths: /usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin'

# Generated at 2022-06-20 16:13:02.388495
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert get_bin_path('python') == os.path.realpath(sys.executable)
    except ValueError as e:
        print('ValueError:', str(e))
        return 1

if __name__ == '__main__':
    import sys
    sys.exit(test_get_bin_path())

# Generated at 2022-06-20 16:13:06.784851
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    # Find existing executable
    for executable in [sys.executable]:
        result = get_bin_path(executable)
        assert os.path.exists(result)

    # Fail on non-existing executable
    try:
        get_bin_path('this_file_should_not_exist')
        assert False, "non-existing executable should throw an exception"
    except ValueError:
        pass


# Generated at 2022-06-20 16:13:14.417150
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test case 1: Executable is in PATH
    test_cmd = 'python'
    bin_path = get_bin_path(test_cmd)
    assert bin_path == '/usr/bin/python'

    # Test case 2: Executable not in PATH
    test_cmd = 'invalid_command'
    try:
        bin_path = get_bin_path(test_cmd)
        assert False
    except ValueError as e:
        assert str(e)

    # Test case 3: Executable specified in opt_dirs
    test_cmd = 'ssh'
    opt_dirs = ['/bin']
    bin_path = get_bin_path(test_cmd, opt_dirs)
    assert bin_path == '/bin/ssh'

# Generated at 2022-06-20 16:13:24.334115
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check if get_bin_path returns path to command
    cmd = 'chmod'
    assert get_bin_path(cmd) == '/bin/chmod'

    # Check if get_bin_path raises ValueError when command is not found
    cmd = 'no-such-command'
    try:
        get_bin_path(cmd)
    except ValueError as v:
        assert cmd in str(v)
    else:
        assert False, "Expected ValueError exception"

# Generated at 2022-06-20 16:13:32.750956
# Unit test for function get_bin_path
def test_get_bin_path():

    # Some test binaries
    env_bin = "/usr/bin/env"
    false_bin = "/usr/bin/false"
    true_bin = "/usr/bin/true"

    # Fail with no env in path
    try:
        get_bin_path(env_bin, required=False)
    except Exception as e:
        assert(str(e) == 'Failed to find required executable "env" in paths:')
    else:
        assert()

    # Get env from path
    env_path = get_bin_path(env_bin, required=False)
    assert(env_path == env_bin)

    # Get false from path with alternate paths
    false_path = get_bin_path(false_bin, opt_dirs=[], required=False)
    assert(false_path == false_bin)



# Generated at 2022-06-20 16:13:44.242294
# Unit test for function get_bin_path
def test_get_bin_path():
    # root directory to be prepended to PATH, guaranteed to exist
    base_path = os.path.abspath(os.path.dirname(__file__))

    # empty PATH and opt_dirs, should raise ValueError
    try:
        get_bin_path('ansible-test-get-bin-path')
    except ValueError:
        pass
    else:
        # should have raised
        assert False

    # with non-existent PATH and opt_dirs, should raise ValueError
    try:
        get_bin_path('ansible-test-get-bin-path',
                     opt_dirs=['/does/not/exist'])
    except ValueError:
        pass
    else:
        # should have raised
        assert False

    # with non-existent PATH and existing opt_dirs, should return existing opt

# Generated at 2022-06-20 16:13:53.128543
# Unit test for function get_bin_path
def test_get_bin_path():
    # Ensure that get_bin_path raises an exception if unable to find required executable
    try:
        get_bin_path('__NOT_A_REAL_EXECUTABLE__', required=True)
    except ValueError as e:
        pass
    else:
        raise AssertionError('Expected get_bin_path to raise a ValueError exception')

    # Ensure that get_bin_path raises an exception if unable to find optional executable
    try:
        get_bin_path('__NOT_A_REAL_EXECUTABLE__', required=False)
    except ValueError as e:
        pass
    else:
        raise AssertionError('Expected get_bin_path to raise a ValueError exception')

    # Ensure that get_bin_path returns the full path to the requested executable, if found
    assert get_bin_

# Generated at 2022-06-20 16:14:02.175474
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    # check OS dependant files
    try:
        get_bin_path('sh')
        get_bin_path('python')
    except ValueError:
        assert False, 'test_get_bin_path failed'

    # check not found files
    for f in ['qwerty', 'asdfgh', 'ymessag', 'log']:
        try:
            get_bin_path(f)
            assert False, 'test_get_bin_path failed'
        except ValueError:
            pass

    # check warning in Python 2
    if sys.version_info[0] == 2:
        try:
            get_bin_path('/bin/sh', required=True)
            assert False, 'test_get_bin_path failed'
        except TypeError:
            pass

    # check warning in Python

# Generated at 2022-06-20 16:14:07.501421
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.basic import get_exception_msg

    arg = 'python'
    try:
        get_bin_path(arg, None)
    except Exception as e:
        assert False, get_exception_msg(e)
    assert False, "get_bin_path() did not raise an exception when arg value doesn't exist"

# Generated at 2022-06-20 16:14:19.532043
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.facts.hardware.freebsd import get_bin_path

    class DummyModule(object):
        def __init__(self, module_name='ansible.module_utils.facts.hardware.freebsd',
                     bin_name='uname', bin_path='/bin/busybox'):
            self.module_name = module_name
            self.bin_name = bin_name
            self.bin_path = bin_path

        def fail_json(self, *args, **kwargs):
            raise RuntimeError("%s: %s" % (args, kwargs))


    # We have a busybox symlink in /bin, so the test should pass
    dm = DummyModule()
    bin_path = get_bin_path(dm.bin_name)

# Generated at 2022-06-20 16:14:30.961991
# Unit test for function get_bin_path
def test_get_bin_path():
    # find existing executable in /sbin, /bin and /usr/bin (in this order)
    bin_path = get_bin_path('awk', required=True)
    assert bin_path == '/usr/bin/awk'

    # find existing executable in /usr/bin and /bin (in this order)
    bin_path = get_bin_path('iptables', opt_dirs=[], required=True)
    assert bin_path == '/usr/bin/iptables'

    # executable not found in path

# Generated at 2022-06-20 16:14:36.093923
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path("thisprogramexists!")
    except:
        pass
    assert(get_bin_path("sh") == "/bin/sh")
    assert(get_bin_path("sh", required=True) == "/bin/sh")
    try:
        get_bin_path("thisprogramdoesntexist")
    except ValueError:
        pass
    try:
        get_bin_path("thisprogramdoesntexist", required=True)
    except ValueError:
        pass

# Generated at 2022-06-20 16:14:42.618693
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Unit test for function get_bin_path'''

    # test successful get_bin_path
    expected_result = '/bin/bash'
    assert expected_result == get_bin_path('bash')

    # test failed get_bin_path
    try:
        get_bin_path('nosuchcommand')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    else:
        assert False