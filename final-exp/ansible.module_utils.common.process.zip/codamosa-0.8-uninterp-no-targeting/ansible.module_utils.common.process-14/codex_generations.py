

# Generated at 2022-06-20 16:04:53.545488
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python')

# Generated at 2022-06-20 16:05:04.213838
# Unit test for function get_bin_path
def test_get_bin_path():
    # pylint: disable=redefined-outer-name

    def _mock_exists(path):
        if path in ('/bin/foo', '/sbin/foo'):
            return True
        else:
            return False

    def _mock_is_executable(path):
        if path in ('/bin/foo', '/sbin/foo'):
            return True
        else:
            return False

    def _mock_path_sep():
        return ':'

    def _mock_environ():
        return {'PATH': '/bin'}

    m = __import__('ansible.module_utils.common.file')
    save_exists = m.os.path.exists
    m.os.path.exists = _mock_exists
    save_is_executable = m

# Generated at 2022-06-20 16:05:13.973423
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    def create_tmp_exec(name):
        with tempfile.NamedTemporaryFile(prefix=name, delete=False) as f:
            f.write(b'#!/bin/sh\nexit $1\n')
        os.chmod(f.name, 0o755)
        return f.name


# Generated at 2022-06-20 16:05:18.915389
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('date')  # This one always exists, so this is a valid test.

# Generated at 2022-06-20 16:05:22.590906
# Unit test for function get_bin_path
def test_get_bin_path():
    # This is a temporary unit test, to be refactored at the same time as
    # the function being tested.
    assert get_bin_path("bash") == "/bin/bash"

# Generated at 2022-06-20 16:05:34.594435
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for function get_bin_path

    :return: ``None``
    '''

    # Note: to test bin_path's built using local paths, we must
    # ensure that the bin file exists first.
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        f.write('#!/bin/sh\necho "hello"\n')
        f.flush()

        try:
            # test for existing bin file
            bin_path = get_bin_path(f.name)
            assert os.path.exists(bin_path)
        except ValueError:
            assert False
        finally:
            os.unlink(f.name)


# Generated at 2022-06-20 16:05:45.684630
# Unit test for function get_bin_path
def test_get_bin_path():
    print("Testing " + __file__)

    import sys
    if sys.version_info[:2] < (2, 7):
        print("SKIP: python version too old<2.7")
        return

    assert get_bin_path('sh') == os.path.abspath(get_bin_path('sh'))
    try:
        get_bin_path('not_an_exe', required=True)
        assert False
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    try:
        get_bin_path('not_an_exe', required=False)
        assert False
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

# Generated at 2022-06-20 16:05:50.683445
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/bin/sh') == '/bin/sh'
    # Test that non-executable files don't count as valid bin_path
    assert get_bin_path('/etc/hosts') == '/etc/hosts'

# Generated at 2022-06-20 16:05:53.264216
# Unit test for function get_bin_path
def test_get_bin_path():
    from shutil import which
    find_bin = which('find')
    assert find_bin
    assert find_bin == get_bin_path('find')

# Generated at 2022-06-20 16:06:00.480307
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        import coverage
        cov = coverage.coverage()
        cov.start()
    except ImportError:
        pass

    try:
        # Test the function get_bin_path
        get_bin_path('true')
        if os.environ.get('PATH', '') != '':
            get_bin_path('true', ['/bin'])
    finally:
        try:
            cov.stop()
            cov.save()
            cov.html_report()
        except NameError:
            pass

# Generated at 2022-06-20 16:06:14.547687
# Unit test for function get_bin_path
def test_get_bin_path():
    # In this case, python2 is executable
    if os.path.exists('/usr/bin/python2'):
        assert get_bin_path('python2') == '/usr/bin/python2'
    if os.path.exists('/usr/bin/python3'):
        assert get_bin_path('python3') == '/usr/bin/python3'
    if os.path.exists('/usr/bin/python'):
        assert get_bin_path('python') == '/usr/bin/python'
    # In this case, python2 is not executable
    if os.path.exists('/usr/bin/python2'):
        assert not os.access('/usr/bin/python2', os.X_OK)

# Generated at 2022-06-20 16:06:24.336579
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path
    '''

    def test_tuple(arg, opt_dirs, result, exc_type=None):
        '''
        Test a test_tuple
        '''
        try:
            res = get_bin_path(arg, opt_dirs=opt_dirs)
        except Exception as err:
            res = err
        assert isinstance(res, exc_type) if exc_type else isinstance(res, str), 'Wrong exception type returned'
        assert res == result, 'Wrong path returned'


# Generated at 2022-06-20 16:06:31.367802
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    python_bin = get_bin_path('python')
    sys.executable = python_bin
    #assert python_bin == get_bin_path('python', None, None)
    assert python_bin == get_bin_path('python', None, True)

# Generated at 2022-06-20 16:06:39.549761
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert bin_path == '/bin/sh', "Found sh as " + bin_path + " instead of /bin/sh"
    bin_path = get_bin_path('sh', opt_dirs=['/bin'])
    assert bin_path == '/bin/sh', "Found sh as " + bin_path + " instead of /bin/sh"
    bin_path = get_bin_path('sh', opt_dirs=['/usr/bin'])
    assert bin_path == '/bin/sh', "Found sh as " + bin_path + " instead of /bin/sh"
    bin_path = get_bin_path('sh', opt_dirs=['/usr/bin'], required=True)

# Generated at 2022-06-20 16:06:45.680837
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('awk') == '/usr/bin/awk'
    assert get_bin_path('/bin/sh', opt_dirs=[]) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=[]) == '/bin/sh'
    assert get_bin_path('awk', opt_dirs=[]) == '/usr/bin/awk'

# Generated at 2022-06-20 16:06:49.291840
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test for get_bin_path()
    '''
    # Test for a folder which exists in PATH
    try:
        get_bin_path('python2')
    except ValueError:
        assert False, 'Failed to locate a folder which exists in PATH'


# Generated at 2022-06-20 16:06:50.699954
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    tempfile.mkdtemp(prefix='ansible_test_')



# Generated at 2022-06-20 16:06:55.113416
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = []
    try:
        get_bin_path('expect', paths)
    except ValueError:
        pass
    else:
        assert False, "Failed to detect expected failure"

    paths.append('/bin')
    paths.append('/usr/bin')
    get_bin_path('expect', paths)

# Generated at 2022-06-20 16:07:02.685854
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function with following inputs:
       - Existing executable in PATH
       - Existing executable in optional directory
       - Executable not found
    '''
    import tempfile
    import pytest

    res = tempfile.mkdtemp()
    exe = os.path.join(res, 'executeMe')
    os.mkdir(exe)
    with open(exe, 'w') as f:
        f.write('')
    os.chmod(exe, 0o755)
    os.putenv('PATH', os.environ.get('PATH') + os.pathsep + res)

    assert get_bin_path('executeMe') == exe

    assert get_bin_path('executeMe', opt_dirs=[res]) == exe

# Generated at 2022-06-20 16:07:06.588838
# Unit test for function get_bin_path
def test_get_bin_path():
    opt_dirs = ['/bin', '/usr/bin', '/usr/local/bin']
    assert get_bin_path('sh', opt_dirs=opt_dirs) == '/bin/sh'

# vim: ai et ts=4 sts=4 sw=4 ft=python

# Generated at 2022-06-20 16:07:13.392331
# Unit test for function get_bin_path
def test_get_bin_path():
    # should check if script exists in the path, If found, it should return full path otherwise raise exception
    path = get_bin_path('python')
    if(path != None):
        if(os.path.exists(path)):
            assert True
        else:
            assert False
    else:
        assert False

# Generated at 2022-06-20 16:07:19.067669
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest  # noqa

    expected_path = '/usr/bin/python'
    try:
        path = get_bin_path('python')
    except Exception as e:
        pytest.fail('%s' % e)
    assert path == expected_path, 'python from path is not at expected location %s' % path

# Generated at 2022-06-20 16:07:29.092742
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    test_dir = tempfile.mkdtemp()

    # Create a executable file
    with open(os.path.join(test_dir, 'test_file'), 'w') as f:
        f.write('#!/bin/sh\n')
        f.write('echo Hello world')

    os.chmod(os.path.join(test_dir, 'test_file'), 0o755)

    # Test for the existance of the file
    assert get_bin_path('test_file') == os.path.join(test_dir, 'test_file')

    # Test it is able to find the file when given an alternative path

# Generated at 2022-06-20 16:07:40.100804
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Unit test for function get_bin_path
    '''
    # Unit test for function get_bin_path

# Generated at 2022-06-20 16:07:45.319681
# Unit test for function get_bin_path
def test_get_bin_path():
    PEBKAC = False
    try:
        bin_path = get_bin_path('ansible')
    except ValueError:
        PEBKAC = True
    assert not PEBKAC
    assert os.path.exists(bin_path) and os.path.isfile(bin_path) and is_executable(bin_path)


# Some of the code below was taken from Ansible 2.10's module_utils/network/common/utils.py


# Generated at 2022-06-20 16:07:48.505881
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('/bin/sh')
    assert bin_path.endswith('/bin/sh')



# Generated at 2022-06-20 16:07:57.306362
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh', ['/bin']) == '/bin/sh'
    assert get_bin_path('sh', [None, '/bin']) == '/bin/sh'
    assert get_bin_path('sh', ['/bin', None]) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=None) == '/bin/sh'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('service') == '/sbin/service'
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('/bin/sh', [None]) == '/bin/sh'
    assert get_bin_path('/bin/sh', ['doesnotexist']) == '/bin/sh'

# Generated at 2022-06-20 16:08:04.841240
# Unit test for function get_bin_path
def test_get_bin_path():
    import ansible.module_utils.basic

    # Test success
    result = ansible.module_utils.basic.AnsibleModule(argument_spec=dict(test_arg=dict(type='str'))).get_bin_path('bin/true')
    assert os.path.exists(result)

    # Test failure
    # No test is available to verify this behavior because we can't remove directory from PATH.
    # It is anyway tested implicitly by unit tests for IOSXERole.get_config() and IOSXERole.get_diff() methods.

# Generated at 2022-06-20 16:08:16.639306
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_paths = ['/sbin', '/usr/sbin', '/usr/local/sbin']
    result_paths = [get_bin_path('sfdisk', bin_paths) for path in bin_paths]
    assert all(path.startswith(path) for path in result_paths)

    result_path = get_bin_path('sfdisk', bin_paths, required=True)
    assert result_path.startswith('/sbin')

    try:
        get_bin_path('sfdisk', ['/bad/path'])
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError to be raised"

# Generated at 2022-06-20 16:08:28.090275
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    def write_file(path):
        fd = os.open(path, os.O_CREAT | os.O_WRONLY, 0o755)
        os.close(fd)

    try:
        path = tempfile.mkdtemp()
        d = os.path.join(path, 'bin')
        os.makedirs(d)
        write_file(os.path.join(d, 'mybin'))
        o = get_bin_path('mybin', opt_dirs=[d])
        assert o == os.path.join(d, 'mybin')
        try:
            get_bin_path('python')
            assert False, "should not reach this point"
        except ValueError:
            assert True
    finally:
        shutil.rmt

# Generated at 2022-06-20 16:08:43.143312
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    bindir = os.path.join(tmpdir, 'bin')
    os.mkdir(bindir)

    # First, check that it fails when it can't find the executable
    try:
        get_bin_path('some-executable', opt_dirs=[bindir])
        assert False, "Expected ValueError for some-executable not found"
    except ValueError:
        pass

    # Now create the executable and check if it is found
    test_script = os.path.join(bindir, 'some-executable')
    with open(test_script, 'w', encoding='utf-8') as f:
        f.write('''#!/bin/bash
        exit 0
        ''')
    os.chmod

# Generated at 2022-06-20 16:08:50.074333
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    import stat
    import os

    # create temporary directory
    tmpdir = tempfile.mkdtemp()
    bin_path = '/bin/sh'
    # create empty file
    t = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(t[0])
    f.close()
    os.chmod(t[1], stat.S_IWRITE)
    os.remove(t[1])

    # test for a normal executable
    assert get_bin_path('sh') == bin_path
    # test for a normal executable with opt_dirs argument
    assert get_bin_path('sh', opt_dirs=['/bin']) == bin_path
    # test for a normal executable with opt_dirs argument in a list
    assert get

# Generated at 2022-06-20 16:09:00.149857
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('/usr/bin/env') == '/usr/bin/env'
    assert get_bin_path('/usr/bin/env', ['/usr/bin']) == '/usr/bin/env'
    assert get_bin_path('/usr/bin/env', ['/usr/lib']) == '/usr/bin/env'
    assert get_bin_path('/usr/lib/env', ['/usr/bin']) == '/usr/lib/env'
    assert get_bin_path('/usr/bin/env', ['/usr/bin']) == '/usr/bin/env'
    assert get_bin_path('sh') == '/bin/sh'

# Generated at 2022-06-20 16:09:09.022807
# Unit test for function get_bin_path
def test_get_bin_path():
    import platform

    system = platform.system()

    if system == 'FreeBSD' or system == 'NetBSD' or system == 'OpenBSD' or system == 'SunOS':
        assert get_bin_path('ls', ['/bin','/usr/bin','/usr/pkg/bin','/usr/sfw/bin']) == '/bin/ls'
    elif system == 'Linux':
        assert get_bin_path('ls', ['/bin','/usr/bin','/usr/local/bin']) == '/bin/ls'
    elif system == 'Darwin':
        assert get_bin_path('ls', ['/bin','/usr/bin','/usr/local/bin']) == '/bin/ls'

# Generated at 2022-06-20 16:09:19.453713
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Sanity test for get_bin_path function
    '''
    paths = os.environ.get('PATH', '').split(os.pathsep)
    for arg in ['sh', 'python']:
        bin_path = get_bin_path(arg)
        found = False
        for d in paths:
            if bin_path == os.path.join(d, arg):
                found = True
        if not found:
            raise Exception("get_bin_path(%s) returned %s, which is not in PATH" % (arg, bin_path))

    # test opt_dirs argument
    test_paths = ['/bin', '/usr/bin']
    bin_path = get_bin_path('sh', test_paths)

# Generated at 2022-06-20 16:09:27.899400
# Unit test for function get_bin_path
def test_get_bin_path():
    from tempfile import mkdtemp
    try:
        d = mkdtemp()
        # Create a "test" file in the temporary directory and test it is found
        path = d + '/test'
        with open(path, 'w') as f:
            f.write('test')
        os.chmod(path, 0o775)
        assert get_bin_path('test', opt_dirs=['/none', '/usr/local/bin', d, '/usr/bin', '/bin']) == path
    finally:
        os.remove(path)
        os.rmdir(d)

# Generated at 2022-06-20 16:09:38.787617
# Unit test for function get_bin_path
def test_get_bin_path():
    # For tests, suppress optional argument deprecation warning
    import warnings
    warnings.filterwarnings(action='ignore', category=DeprecationWarning, module='ansible.module_utils.basic', lineno=0)

    # Check that get_bin_path() finds an existing executable
    assert os.path.isfile(get_bin_path('ls'))

    # Check that get_bin_path() returns full path
    assert get_bin_path('ls') == which('ls')

    # Check that get_bin_path() raises ValueError if executable is not found
    raised = False
    try:
        get_bin_path('lsdfjlkjasfdlkj')
    except ValueError:
        raised = True
    assert raised

    # Check that get_bin_path() raises ValueError if executable is not found, even if optional required

# Generated at 2022-06-20 16:09:43.791805
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('sh') == '/bin/sh'
    try:
        get_bin_path('notthere')
    except ValueError:
        pass
    else:
        assert False, 'did not get expected ValueError'

# Generated at 2022-06-20 16:09:50.047785
# Unit test for function get_bin_path
def test_get_bin_path():
    # test working
    get_bin_path('/bin/echo', opt_dirs=[])
    get_bin_path('echo', opt_dirs=[])
    get_bin_path('echo', opt_dirs=['/bin'])
    get_bin_path('echo', opt_dirs=['/bin'])
    # test not working
    try:
        get_bin_path('no_such_bin', opt_dirs=[])
        assert False, 'Exception should be raised when no path given'
    except ValueError:
        pass
    try:
        get_bin_path('echo', opt_dirs=['/no/such/dir'])
        assert False, 'Exception should be raised when no such dir given'
    except ValueError:
        pass

# Generated at 2022-06-20 16:09:59.004473
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/ls', opt_dirs=['/sbin']) == '/bin/ls'

    try:
        get_bin_path('ls', opt_dirs=['/sbin'])
        assert False
    except ValueError:
        assert True

    prev_env = os.environ.get('PATH', '')
    os.environ['PATH'] = ''
    try:
        get_bin_path('ls')
        assert False
    except ValueError:
        assert True
    finally:
        os.environ['PATH'] = prev_env

# Generated at 2022-06-20 16:10:18.969395
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.facts import is_executable
    def is_executable(path): return True

    PATH = os.environ.get('PATH', '').split(os.pathsep)

    # Try to find an executable that should be within the default PATH env var.
    found = get_bin_path('python')
    assert found
    assert found in PATH

    # Try to find an executable that is in optional paths.
    opt_dirs = ['/usr/local/bin']
    found = get_bin_path('python', opt_dirs=opt_dirs)
    assert found
    assert found in opt_dirs

    # Check that exception is raised if not found

# Generated at 2022-06-20 16:10:28.366787
# Unit test for function get_bin_path
def test_get_bin_path():
    # Assumes that /bin/ls exists and /bin/not_ls does not exist
    bin_ls = get_bin_path('ls')
    assert bin_ls == '/bin/ls'

    try:
        get_bin_path('not_ls')
    except ValueError:
        pass
    else:
        pytest.fail('Failed to raise exception')

    # Assumes that /sbin/ip exists and /bin/ip does not exist
    sbin_ip = get_bin_path('ip', ['/sbin'])
    assert sbin_ip == '/sbin/ip'

    try:
        get_bin_path('ip', ['/bin'])
    except ValueError:
        pass
    else:
        pytest.fail('Failed to raise exception')

# Generated at 2022-06-20 16:10:31.407701
# Unit test for function get_bin_path
def test_get_bin_path():
    assert os.path.isabs(get_bin_path("echo"))
    assert get_bin_path("/bin/echo") == "/bin/echo"

# Generated at 2022-06-20 16:10:38.395580
# Unit test for function get_bin_path
def test_get_bin_path():
    executable_name = 'bin_name'
    dummy_dir = '/some/dir'
    import tempfile
    from shutil import rmtree
    dummy_dir = tempfile.mkdtemp(prefix='ansible_test_')
    bin_path = os.path.join(dummy_dir, executable_name)
    open(bin_path, 'w').close()
    os.chmod(bin_path, 0o700)
    # test passing string for optional directories
    try:
        assert get_bin_path(executable_name, dummy_dir) == bin_path
    finally:
        rmtree(dummy_dir)
    # test passing list for optional directories

# Generated at 2022-06-20 16:10:41.540844
# Unit test for function get_bin_path
def test_get_bin_path():
    # no existing binary specified.
    try:
        get_bin_path('/fake_bins/ansible-fake')
        assert False
    except ValueError:
        assert True
    # existing binary specified.
    bin_path = get_bin_path('/bin/sleep')
    assert bin_path.endswith('sleep')

# Generated at 2022-06-20 16:10:49.004404
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file inside it
    test_file = os.path.join(tmpdir, 'get_bin_path_test')
    f = open(test_file, 'w')
    f.close()
    # Try getting the file using the function
    returned_bin_path = get_bin_path('get_bin_path_test', opt_dirs=[tmpdir])
    # Cleanup
    os.remove(test_file)
    os.rmdir(tmpdir)
    # Return the file
    return returned_bin_path

# Test get_bin_path function
bin_path = test_get_bin_path()

# Generated at 2022-06-20 16:11:01.234223
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import os
    import shutil

    oldenv = os.environ.get('PATH', None)

    # Setup a temp dir to be used as PATH
    tempdir = tempfile.mkdtemp()
    os.environ['PATH'] = tempdir
    tempfile.mkstemp(prefix='ansibletmp')[0]  # create an empty file in the tmp dir

    # Get the name of the empty file
    fake_command = os.path.basename(tempfile.mkstemp(prefix='ansibletmp')[1])

    # Make sure that file is not found

# Generated at 2022-06-20 16:11:09.584536
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.file import mkstemp

    # No PATH set
    assert 'PATH' not in os.environ

    # Optionally pass opt_dirs
    assert os.environ.get('PATH')
    test_filename = os.path.basename(mkstemp()[1])
    test_dir = os.path.dirname(mkstemp()[1])
    test_path = os.path.join(test_dir, test_filename)
    os.chmod(test_path, 0o700)
    assert is_executable(test_path)
    assert get_bin_path(test_filename, opt_dirs=[test_dir]) == test_path
    assert get_bin_path(test_filename) == test

# Generated at 2022-06-20 16:11:13.429478
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('service', opt_dirs=['/sbin']) == '/usr/sbin/service'
    try:
        get_bin_path('this_command_does_not_exist')
    except ValueError:
        pass
    else:
        assert False, 'ValueError expected'

# Generated at 2022-06-20 16:11:23.557851
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = 'ansible-playbook'

    # Ensure we can find the local executable
    bin_path = get_bin_path(arg)
    assert os.path.exists(bin_path) and is_executable(bin_path), "Didn't find local ansible-playbook executable"

    # now try to find a fake executable that can't exist
    try:
        bin_path = get_bin_path("this-should-fail")
    except ValueError:
        return
    assert False, "get_bin_path should have thrown exception but returned '%s'" % bin_path

# Generated at 2022-06-20 16:11:34.590926
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    bin_path = get_bin_path(sys.executable)
    assert bin_path == sys.executable

# Generated at 2022-06-20 16:11:41.847250
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/']) == '/sh'
    assert get_bin_path('./sh', opt_dirs=['/']) == '/sh'
    assert get_bin_path('/sh') == '/sh'
    assert get_bin_path('/bin/sh') == '/bin/sh'

# Generated at 2022-06-20 16:11:47.297944
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("/usr/bin/id") == "/usr/bin/id"
    assert get_bin_path("/bin/id") == "/bin/id"
    assert get_bin_path("../bin/id") is None
    assert get_bin_path("bin/id") == get_bin_path("id")

# Generated at 2022-06-20 16:11:58.863757
# Unit test for function get_bin_path
def test_get_bin_path():

    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'

    try:
        get_bin_path('/bin/ls', ['/bin', '/sbin'])
    except ValueError:
        assert False, 'ls is in /bin and /sbin'

    try:
        get_bin_path('ls', ['/bin', '/sbin'])
    except ValueError:
        assert False, 'ls is in /bin and /sbin'

    try:
        get_bin_path('bash', ['/bin', '/sbin'])
        assert False, 'bash is not in /bin and /sbin'
    except ValueError:
        pass


# Generated at 2022-06-20 16:12:10.132003
# Unit test for function get_bin_path

# Generated at 2022-06-20 16:12:18.090136
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_bytes

    test_path = u'/sbin/foo'
    abs_test_path = os.path.abspath(test_path)
    assert get_bin_path(test_path, opt_dirs=[u'/sbin']) == to_bytes(abs_test_path, errors='surrogate_or_strict')

# Generated at 2022-06-20 16:12:30.095609
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # We don't want to depend on /bin/echo being available in unit tests;
    # make a tempfile that is executable and includes the path to echo.
    # For example, on OSX, /bin/echo is /usr/bin/echo, so when we look for
    # echo in the temp dir, it will find this file, which will execute
    # /usr/bin/echo.
    exe = '#!/bin/sh\n/bin/echo "$@"\n'
    (fd, tmpfile) = tempfile.mkstemp()
    with os.fdopen(fd, "wb") as f:
        f.write(exe)
    os.chmod(tmpfile, 0o777)


# Generated at 2022-06-20 16:12:40.953718
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys
    import platform
    from ansible.module_utils.common._text import to_text

    def _test_executable(executable_path):
        # Define a Python executable program
        with open(executable_path, 'wt') as f:
            f.write("#!%s\nprint(42)\n" % to_text(sys.executable))
        os.chmod(executable_path, 0o755)

    # Ensure that the directory containing the Python executable is in PATH
    python_bin_folder = os.path.dirname(sys.executable)
    if python_bin_folder not in os.environ.get('PATH', '').split(os.pathsep):
        os.environ['PATH'] = python_bin_folder + os.pathsep + os.environ['PATH']

# Generated at 2022-06-20 16:12:53.006906
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # Create temporary directories
    t1 = tempfile.mkdtemp()
    t2 = tempfile.mkdtemp()
    t3 = tempfile.mkdtemp()
    t4 = tempfile.mkdtemp()

    # Create executables in these directories
    f1 = os.path.join(t1, "test1")
    f2 = os.path.join(t2, "test2")
    f3 = os.path.join(t3, "test3")
    f4 = os.path.join(t4, "test4")

    with open(f1, "w") as f:
        f.write("#!/usr/bin/python\n")
    with open(f2, "w") as f:
        f.write("#!/usr/bin/python\n")

# Generated at 2022-06-20 16:12:58.832352
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('grep') == '/bin/grep'
    assert get_bin_path('does-not-exists') == None
    try:
        get_bin_path('does-not-exists', required=True)
    except Exception as ex:
        assert str(ex) == 'Failed to find required executable "does-not-exists" in paths: /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'

# Generated at 2022-06-20 16:13:19.591895
# Unit test for function get_bin_path
def test_get_bin_path():

    try:
        get_bin_path('i-dont-exist')
        assert False
    except ValueError:
        pass

    try:
        get_bin_path('sh')
        assert True
    except ValueError:
        assert False

# Generated at 2022-06-20 16:13:21.128118
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('ls') == '/bin/ls')

# Generated at 2022-06-20 16:13:30.468822
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test case failure
    try:
        get_bin_path('unknown_executable')
    except ValueError as e:
        if 'Failed to find required executable "unknown_executable"' in str(e):
            print("PASS: Function get_bin_path() threw Expected Exception with message %s" % str(e))
        else:
            print("FAIL: Function get_bin_path() threw %s, but Expected Exception was 'Failed to find required executable \"unknown_executable\"'" % str(e))

    # Test case success for known executable in PATH

# Generated at 2022-06-20 16:13:37.319656
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()

    # Create a fake executable
    executable = 'my_executable'
    open(os.path.join(tmpdir, executable), "a").close()
    get_bin_path(executable, opt_dirs=[tmpdir])
    get_bin_path(executable, opt_dirs=[tmpdir], required=True)

    # Verify that it works when given just the executable name
    shutil.rmtree(tmpdir)

# Generated at 2022-06-20 16:13:43.159859
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    # Create a fake executable and add its directory to the PATH
    ff, fn = tempfile.mkstemp()
    os.close(ff)
    os.chmod(fn, 0o755)
    assert get_bin_path('basename', [os.path.dirname(fn)]) == fn
    os.remove(fn)

# Generated at 2022-06-20 16:13:50.650392
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check that a non-existing command is not found
    try:
        get_bin_path("non-existing-command", opt_dirs=None)
    except ValueError as e:
        assert 'Failed to find required executable "non-existing-command"' in str(e)
    else:
        raise AssertionError("Test should fail here")

    # check that existing command is found
    result = get_bin_path("ls", opt_dirs=None)
    assert result == '/bin/ls' or result == '/usr/bin/ls', 'Expected path to "ls" in /bin or /usr/bin, got %s' % result

    # check that additional search path is correctly respected
    result = get_bin_path("ls", opt_dirs=['/usr/bin'])

# Generated at 2022-06-20 16:14:00.996893
# Unit test for function get_bin_path
def test_get_bin_path():
    #
    # Create a facter command in /tmp
    #
    facter_dir = "/tmp/facter/bin"
    if not os.path.exists(facter_dir):
        os.makedirs(facter_dir)
    facter_cmd = os.path.join(facter_dir, "facter")
    with open(facter_cmd, 'w') as fh:
        fh.write("#!/bin/sh\necho bar\n")
    os.chmod(facter_cmd, 0o755)

    #
    # Normal expected case
    #
    bin_path = get_bin_path("facter")
    assert bin_path == "/usr/bin/facter"

    #
    # Test optional override
    #
    bin_path = get_bin_path

# Generated at 2022-06-20 16:14:11.702588
# Unit test for function get_bin_path
def test_get_bin_path():

    def mock_os_path_exists(path):
        return path == '/bin/true'

    def mock_is_executable(path):
        return path.endswith('true')

    import ansible.module_utils.common.file as f
    m_os_path_exists = f.os.path.exists
    m_is_executable = f.is_executable
    f.os.path.exists = mock_os_path_exists
    f.is_executable = mock_is_executable

    path = get_bin_path('true')
    assert path == '/bin/true'

    path = get_bin_path('true', ['/usr/bin'])
    assert path == '/bin/true'

    f.os.path.exists = m_os_path_exists

# Generated at 2022-06-20 16:14:17.129645
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    try:
        get_bin_path('missing', opt_dirs=['/bin'])
    except ValueError:
        pass
    else:
        assert False
    assert get_bin_path('echo', opt_dirs=[]) == '/bin/echo'

# Generated at 2022-06-20 16:14:22.569882
# Unit test for function get_bin_path
def test_get_bin_path():
    import unittest

    import tempfile
    import shutil

    class TestGetBinPath(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_valid_path(self):
            os.makedirs(os.path.join(self.temp_dir, 'bin'))
            open(os.path.join(self.temp_dir, 'bin', 'foo'), 'w').close()
            old_PATH = os.environ.get('PATH', '')
            os.environ['PATH'] = self.temp_dir

# Generated at 2022-06-20 16:14:43.054295
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("ls")

# Generated at 2022-06-20 16:14:51.570891
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/bin']) == '/bin/sh'
    try:
        get_bin_path('notthere')
        assert False, 'get_bin_path("notthere") should raise ValueError'
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

    assert get_bin_path('facter', opt_dirs=['/bin', '/usr/bin', '/usr/local/bin']) == '/usr/local/bin/facter'