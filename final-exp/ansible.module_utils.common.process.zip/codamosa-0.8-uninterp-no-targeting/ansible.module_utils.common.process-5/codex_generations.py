

# Generated at 2022-06-20 16:05:03.903322
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    def setup_path(tmpdir, name, content=''):
        with open(os.path.join(tmpdir, name), 'w') as f:
            f.write(content)
        if name not in os.listdir(tmpdir):
            raise Exception("unable to create test file %s" % name)

    # Test binary search
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-20 16:05:09.290633
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path() function.
    '''
    bin_path = get_bin_path('sed')
    assert isinstance(bin_path, str)
    assert os.path.exists(bin_path)
    assert not os.path.isdir(bin_path)
    assert is_executable(bin_path)
    bin_path = get_bin_path('invalid-executable')
    assert False

# Generated at 2022-06-20 16:05:17.755426
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile

    test_paths = ["/bin", "/usr/bin", "/usr/local/bin", "/sbin", "/usr/sbin", "/usr/local/sbin"]

    # find a current executable in PATH
    for path in test_paths:
        for exe in ["ls", "rm", "grep", "python", "make"]:
            exe = os.path.join(path, exe)
            if os.path.exists(exe) and is_executable(exe):
                try:
                    assert get_bin_path(os.path.basename(exe)) == exe
                except AssertionError:
                    raise AssertionError("test_get_bin_path: failed using %s from %s" % (exe, path))
                break

    # create a new executable and add it

# Generated at 2022-06-20 16:05:25.726366
# Unit test for function get_bin_path
def test_get_bin_path():
    test_path = os.path.dirname(__file__)

    # Test find the executable in a configurable PATH
    for path in ['/usr/bin', '/usr/local/bin']:
        bin_path = os.path.join(path, 'hostname')
        assert get_bin_path('hostname', opt_dirs=[test_path]) == bin_path

    # Test in a path without the executable
    try:
        get_bin_path('hostname', opt_dirs=[test_path, '/bad/path'])
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-20 16:05:36.250614
# Unit test for function get_bin_path
def test_get_bin_path():
    # Set up the temporary module search path
    paths = [
        '/bin',
        '/usr/bin',
        '/usr/local/bin',
        '/sbin',
        '/usr/sbin',
        '/usr/local/sbin',
    ]

    # Example tests
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('tar') == '/bin/tar'
    assert get_bin_path('chown') == '/bin/chown'
    assert get_bin_path('chmod') == '/bin/chmod'
    assert get_bin_path('cat') == '/bin/cat'
    assert get_bin_path('cut') == '/bin/cut'
    assert get_bin_path('dig') == '/usr/bin/dig'
    assert get_bin_

# Generated at 2022-06-20 16:05:47.503431
# Unit test for function get_bin_path
def test_get_bin_path():
    # Get the path to the current module from ansible.module_utils
    test_path = os.path.dirname(os.path.realpath(__file__))
    test_directories = [os.path.join(test_path, 'test_get_bin_path'), '/bin']
    test_executables = ['test_file', 'false', 'true']
    test_exists = [True, True, True]
    test_executable = [True, True, True]

    # Check that we get the expected result for each test case
    for i in range(len(test_directories)):
        test_dir = test_directories[i]
        test_exec = test_executables[i]
        test_ex = test_exists[i]
        test_exe = test_executable[i]

# Generated at 2022-06-20 16:05:53.351457
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check path for an executable that exists
    found = get_bin_path('ansible-config')
    assert(found.endswith('/ansible-config'))
    # Check path for an executable that does not exist
    try:
        found = get_bin_path('file-does-not-exist-ansible-config')
        assert(False)
    except ValueError:
        pass
    # Check path for an executable that does not exist with an optional path
    opt_path = '/'
    try:
        found = get_bin_path('file-does-not-exist-ansible-config', opt_dirs=[opt_path])
        assert(False)
    except ValueError:
        pass

# Generated at 2022-06-20 16:06:03.160654
# Unit test for function get_bin_path
def test_get_bin_path():
    my_dir = '/tmp/test_get_bin_path'
    my_script = 'test_script'
    os.makedirs(my_dir)
    with open(os.path.join(my_dir, my_script), 'w') as f:
        f.write('#!/bin/sh\n')
    os.chmod(os.path.join(my_dir, my_script), 0o777)
    assert get_bin_path(my_script) == os.path.join(my_dir, my_script)
    assert get_bin_path(my_script, opt_dirs=[]) == os.path.join(my_dir, my_script)

# Generated at 2022-06-20 16:06:08.999125
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils._text import to_text

    # Test with simple argument value
    arg = 'ls'
    try:
        bin_path = get_bin_path(arg)
        assert bin_path == to_text(os.sep).join(['', 'bin', 'ls'])
    except ValueError:
        assert False

# Generated at 2022-06-20 16:06:20.033572
# Unit test for function get_bin_path
def test_get_bin_path():
    opt_dirs = ['/tmp']
    assert get_bin_path('true', opt_dirs) == '/tmp/true'
    assert get_bin_path('test_file_not_found', opt_dirs) == '/tmp/test_file_not_found'
    assert get_bin_path('dir_not_found/true', opt_dirs) == '/tmp/dir_not_found/true'
    try:
        # Test 1st arg is executable
        get_bin_path('dir_not_found/yaml', opt_dirs)
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

# Generated at 2022-06-20 16:06:30.363040
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('foobar') == '/sbin/foobar'
    import sys
    try:
        get_bin_path('foobarbaz')
        assert False, 'Failed to raise exception when binary not found'
    except ValueError:
        e = sys.exc_info()[1]
        assert 'Failed to find required executable "foobarbaz"' in str(e)

# Generated at 2022-06-20 16:06:41.639142
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function.
    '''
    # Test 1:  Check for echo command in /sbin, /bin, and PATH.
    from ansible.module_utils.common.process import get_bin_path
    try:
        bin_path = get_bin_path('echo')
    except ValueError as e:
        fail_msg = "Exception raised.  Failed to run echo.  Exception is: %s" % (e)
        assert False, fail_msg

    # Check to see if echo exists
    if not os.path.exists(bin_path) or os.path.isdir(bin_path):
        fail_msg = "Failed to find echo command!"
        assert False, fail_msg

    # Verify that echo is executable

# Generated at 2022-06-20 16:06:49.810662
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '/bin/sh' == get_bin_path('sh')
    assert '/bin/sh' == get_bin_path('sh', required=False)
    assert '/bin/sh' == get_bin_path('sh', required=True)
    assert '/bin/sh' == get_bin_path('sh', opt_dirs=None, required=False)
    assert '/bin/sh' == get_bin_path('sh', opt_dirs=None, required=True)
    assert '/bin/sh' == get_bin_path('sh', opt_dirs=[], required=False)
    assert '/bin/sh' == get_bin_path('sh', opt_dirs=[], required=True)

    assert is_executable('/bin/bash')
    assert '/bin/bash' == get_bin_path('bash')


# Generated at 2022-06-20 16:06:55.156550
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('awk') == '/bin/awk'
    assert get_bin_path('awk', ['/']) == '/awk'
    assert get_bin_path('awk', ['/', '/bin']) == '/bin/awk'
    assert get_bin_path('awk', ['/bin', '/']) == '/bin/awk'
    assert get_bin_path('not_a_real_executable') == '/bin/awk'

# Generated at 2022-06-20 16:06:58.287364
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("echo") == "/bin/echo"
    assert get_bin_path("this_can't_possibly_be_in_path_on_any_system") == "/bin/this_can't_possibly_be_in_path_on_any_system"

# Generated at 2022-06-20 16:07:05.944707
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    unit test:
      - ensures get_bin_path returns 'ls' found in /bin
      - ensures get_bin_path raises exception for 'bad' not in PATH
    '''
    import sys
    import pytest

    # default test
    cmd = 'ls'
    if sys.platform.startswith(('freebsd', 'darwin')):
        bin_path = get_bin_path(cmd)
        assert bin_path == '/bin/ls'

    # test with directory that does not exist
    with pytest.raises(ValueError):
        cmd = 'bad'
        get_bin_path(cmd)

    # test with directory that exists
    cmd = 'ls'
    bin_path = get_bin_path(cmd, opt_dirs=['/bin/'])
    assert bin_

# Generated at 2022-06-20 16:07:09.017537
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', ['/usr/bin1']) == '/usr/bin1/python'
    # Individual test takes 1.7s to run. Run all in a single process
    # python -m pytest -s -vv -k test_get_bin_path -x test/units/module_utils/basic.py

# Generated at 2022-06-20 16:07:14.476307
# Unit test for function get_bin_path
def test_get_bin_path():
    '''Test get_bin_path function'''
    from ansible.module_utils._text import to_bytes

    # testing with normal PATHs
    expected_paths = ['/usr/bin/ls', '/bin/ls']
    for path in expected_paths:
        assert get_bin_path('ls') == path

    # testing with explicite binary directories
    assert get_bin_path('ls', opt_dirs=['/bin']) == '/bin/ls'

    # testing with a binary not in PATH
    try:
        get_bin_path('ls')
        assert False
    except ValueError:
        assert True

    # testing with a binary not in PATH and required flag
    try:
        get_bin_path('ls', required=True)
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-20 16:07:16.224435
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('/usr/bin/ansible')

# Generated at 2022-06-20 16:07:17.329712
# Unit test for function get_bin_path
def test_get_bin_path():
    print(get_bin_path('python'))

# Generated at 2022-06-20 16:07:23.182460
# Unit test for function get_bin_path
def test_get_bin_path():
    import sys

    # test with a file which is already in PATH
    test_bin = 'python'
    path_to_bin = get_bin_path(test_bin)
    if os.path.basename(path_to_bin) != test_bin:
        raise Exception('Unit test for function get_bin_path failed. Tested executable is: ' + test_bin)

    # test with a file which is not in PATH
    test_bin = 'file_not_in_path'
    path_to_bin = None
    try:
        path_to_bin = get_bin_path(test_bin)
    except ValueError:
        # As the required executable is not in path, we expect to get exception here
        pass

# Generated at 2022-06-20 16:07:28.017624
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Unit test for function get_bin_path
    """
    import platform
    if platform.system() != 'SunOS':
        try:
            get_bin_path('tree')
        except ValueError as e:
            assert "Failed to find required executable" in str(e)
        else:
            assert False

    try:
        get_bin_path('does_not_exist')
    except ValueError as e:
        assert "Failed to find required executable" in str(e)
    else:
        assert False

# Generated at 2022-06-20 16:07:31.385026
# Unit test for function get_bin_path
def test_get_bin_path():
    bp = get_bin_path('ls', ['/bin', '/usr/bin'])
    assert bp == '/bin/ls'
    try:
        bp = get_bin_path('foo')
        raise Exception("Didn't detect missing foo executable")
    except ValueError as e:
        pass

# Generated at 2022-06-20 16:07:40.714271
# Unit test for function get_bin_path

# Generated at 2022-06-20 16:07:51.984117
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("ansible-playbook") == get_bin_path("ansible-playbook", opt_dirs=None)
    assert get_bin_path("ansible-playbook") == get_bin_path("ansible-playbook", opt_dirs=[])
    assert get_bin_path("ansible-playbook") == get_bin_path("ansible-playbook", opt_dirs=["/"])
    assert get_bin_path("ansible-playbook") != get_bin_path("ansible-playbook", opt_dirs=["/some/bad/path"])
    assert get_bin_path("non-exist-bin") == get_bin_path("non-exist-bin", opt_dirs=["/some/bad/path"])

# Generated at 2022-06-20 16:07:53.513190
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("sh") == "/bin/sh"

# Generated at 2022-06-20 16:08:01.306418
# Unit test for function get_bin_path
def test_get_bin_path():
    test_paths = ['/bin', '/usr/bin', '/usr/local/bin']
    assert get_bin_path('python') == '/usr/bin/python', 'Expected /usr/bin/python, not %s' % get_bin_path('python')
    assert get_bin_path('python', opt_dirs=test_paths) == '/usr/bin/python', 'Expected /usr/bin/python, not %s' % get_bin_path('python', opt_dirs=test_paths)

# Generated at 2022-06-20 16:08:10.977934
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('ipmitool') == '/usr/bin/ipmitool'
    assert get_bin_path('ipmitool', ['/sbin', '/usr/sbin']) == '/usr/sbin/ipmitool'
    assert get_bin_path('ipmitool', ['./sbin', './usr/sbin']) == './sbin/ipmitool'
    assert get_bin_path('ipmitool', ['.', os.getcwd()]) == './ipmitool'

    import pytest
    with pytest.raises(ValueError):
        get_bin_path('not_found')
    with pytest.raises(ValueError):
        get_bin_path('not_found', required=True)

# Generated at 2022-06-20 16:08:18.132983
# Unit test for function get_bin_path
def test_get_bin_path():
    class MockOs(object):

        class path(object):
            @staticmethod
            def exists(path):
                return path in ['/bin/sh', '/usr/bin', '/usr/bin/sh']

            @staticmethod
            def isdir(path):
                return False

        @staticmethod
        def environ(val):
            return {'PATH': '/bin:/usr/bin'}[val]

        @staticmethod
        def pathsep():
            return ':'

    import builtins
    builtins.__dict__['os'] = MockOs
    assert get_bin_path('sh') == '/bin/sh'



# Generated at 2022-06-20 16:08:26.795879
# Unit test for function get_bin_path
def test_get_bin_path():
    __test_paths = ['/bin', '/usr/bin', '/usr/local/bin']
    test_path = get_bin_path('true', opt_dirs=__test_paths)
    assert test_path == '/bin/true'
    # test it fails when the executable is not found
    err_raised = False
    try:
        test_path = get_bin_path('truf', opt_dirs=__test_paths)
    except ValueError:
        err_raised = True
    assert err_raised

# Generated at 2022-06-20 16:08:30.893126
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('no_such_exe')
        raise AssertionError('expected ValueError for missing exe')
    except ValueError:
        pass

# Generated at 2022-06-20 16:08:41.708015
# Unit test for function get_bin_path
def test_get_bin_path():
    ''' test_get_bin_path is a unit test for the get_bin_path function '''
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 16:08:44.323777
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('grep') == '/bin/grep'
    assert get_bin_path('grep', opt_dirs=['/usr/bin', '/bin']) == '/bin/grep'

# Generated at 2022-06-20 16:08:54.379064
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat

    def make_executable(path):
        mode = os.stat(path).st_mode
        mode |= (mode & 0o444) >> 2  # copy R bits to X
        os.chmod(path, mode)


# Generated at 2022-06-20 16:09:02.482061
# Unit test for function get_bin_path
def test_get_bin_path():
    # get an executable that exists on every system
    assert get_bin_path('/bin/sh')
    # this should not raise
    assert get_bin_path('/bin/sh', required=False)
    # run one where we know the path
    assert get_bin_path('sh', opt_dirs=['/bin', '/sbin'])
    # run one where we know the path and don't require it
    assert get_bin_path('sh', opt_dirs=['/bin', '/sbin'], required=False)

    # run one where we don't know the path and require it
    try:
        get_bin_path('fasdfwerwetgwrtg')
    except ValueError:
        pass
    else:
        fail("should have raised")

    # run one where we don't know the path

# Generated at 2022-06-20 16:09:10.793562
# Unit test for function get_bin_path
def test_get_bin_path():
    import mock
    import sys
    import tempfile
    import textwrap

    # FIXME: refactor to use pytest temp_path/tmp_path fixture.
    # FIXME: refactor to use tmp_path_factory.mktemp()
    temp_dir = tempfile.mkdtemp()
    temp_file = tempfile.NamedTemporaryFile(mode='wt', dir=temp_dir)
    temp_file.write(textwrap.dedent("""\
      #!%s
      print("hello, world")
    """ % (sys.executable)))
    temp_file.flush()
    os.chmod(temp_file.name, 0o755)

    with mock.patch.dict(os.environ, {'PATH': temp_dir}):
        assert get_bin_path('foo', required=True)

# Generated at 2022-06-20 16:09:13.910276
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/sbin', '/bin']) == '/bin/sh'


# Generated at 2022-06-20 16:09:24.118373
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path("sh")
    assert bin_path == "/bin/sh"
    assert "non-existing-path" not in bin_path
    bin_path = get_bin_path("sh", opt_dirs=["/usr/bin"])
    assert bin_path == "/bin/sh"
    bin_path = get_bin_path("sh", opt_dirs=["/usr/bin", "/usr/sbin"])
    assert bin_path == "/bin/sh"
    bin_path = get_bin_path("sh", opt_dirs=["/usr/bin", "/usr/sbin", "/usr/bin"])
    assert bin_path == "/bin/sh"
    bin_path = get_bin_path("sh", opt_dirs=["/usr/sbin"])


# Generated at 2022-06-20 16:09:36.057129
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('cat')
    assert path is not None
    path = get_bin_path('cat', opt_dirs=['/bin'])
    assert path is not None
    path = get_bin_path('cat', opt_dirs=['/bin', '/sbin'])
    assert path is not None

    try:
        path = get_bin_path('cat', opt_dirs=['/bin', '/sbin'], required=False)
    except ValueError as e:
        assert False, e
    assert path is not None

    try:
        path = get_bin_path('nonexistcmd')
        assert False
    except ValueError as e:
        assert 'Failed to find required' in str(e)


# Generated at 2022-06-20 16:09:41.657696
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path in this module
    '''
    try:
        import sys
        import pytest
        bin_path = get_bin_path('dir')
        assert True
    except ImportError:
        # if pytest is not installed, just do nothing
        pass

# Generated at 2022-06-20 16:09:46.915045
# Unit test for function get_bin_path
def test_get_bin_path():
    test_dir = 'testdir'
    assert os.path.exists(get_bin_path('sh'))
    try:
        get_bin_path('this_should_not_exist')
        assert False
    except ValueError:
        pass
    assert get_bin_path('sh', [test_dir]) == os.path.join(test_dir, 'sh')



# Generated at 2022-06-20 16:09:58.170442
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Validate that get_bin_path returns the expected value based on the path
    '''

    # Check that an exception is raised if the executable is not found in the path
    test_arg = 'not_in_the_path'
    try:
        get_bin_path(arg=test_arg)
        assert False, 'Should not get here'
    except ValueError as e:
        assert test_arg in str(e)

    # Check that the executable is found if it is in the path
    test_arg = 'whoami'
    assert get_bin_path(arg=test_arg)

    # Check that the executable is found if it is not in the path but an alternate directory is supplied
    test_arg = 'whoami'
    test_dir = '/usr/bin'

# Generated at 2022-06-20 16:10:07.426075
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    import os


# Generated at 2022-06-20 16:10:18.890868
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') is not None
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/bin', '/usr/sbin']) == '/bin/sh'
    assert get_bin_path('sh', opt_dirs=['/usr/bin', '/usr/local/bin', '/usr/sbin']) == '/usr/bin/sh'

    try:
        get_bin_path('sh', opt_dirs=['/usr/bin', '/usr/local/bin', '/usr/sbin'], required=False)
    except ValueError:
        assert False


# Generated at 2022-06-20 16:10:28.619005
# Unit test for function get_bin_path
def test_get_bin_path():
    """Function get_bin_path needs to be tested."""
    from shutil import rmtree
    import tempfile
    import os
    import subprocess

    py_cmd = 'python'
    py_path = get_bin_path(py_cmd)
    proc = subprocess.Popen([py_path, '-c', 'print("Hello, world")'], stdout=subprocess.PIPE)
    py_out = proc.communicate()[0]
    assert py_out.strip() == b'Hello, world'

    # Test that get_bin_path raises error on not found bin
    not_found_bin = 'supercalifragilisticexpialidocious'

# Generated at 2022-06-20 16:10:41.657195
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    tmpdir = tempfile.mkdtemp()
    fname = os.path.join(tmpdir, 'executable_file')
    with open(fname, 'w') as f:
        f.write('#!/bin/sh')

    os.chmod(fname, 0o755)

    assert get_bin_path(os.path.basename(fname), opt_dirs=[tmpdir]) == fname
    try:
        get_bin_path('missing', opt_dirs=[tmpdir])
    except ValueError as e:
        assert 'missing' in str(e)
    else:
        assert False, 'Expected ValueError'

    # Check we do not get a ValueError from the dumb '<' test in the module
    assert get_bin_path('<')



# Generated at 2022-06-20 16:10:50.477518
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('echo') == '/bin/echo'

    try:
        get_bin_path('this executable does not exist')
        assert False
    except ValueError:
        assert True

    try:
        get_bin_path('this executable does not exist', required=True)
        assert False
    except ValueError:
        assert True

    opt_dirs = ['/bin', '/usr/bin', '/usr/local/bin']
    # Test optional directory
    try:
        bin_path = get_bin_path('echo', opt_dirs)
        assert bin_path == '/bin/echo'
    except ValueError:
        assert False

    # Test optional directory that does not contain executable

# Generated at 2022-06-20 16:11:02.126047
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("/bin/sh") == "/bin/sh"
    paths = [ "/bin" ]
    assert get_bin_path("sh", paths) == "/bin/sh"
    assert get_bin_path("sh", paths, False) == "/bin/sh"
    assert get_bin_path("bash", paths, False) == "/bin/bash"
    assert get_bin_path("bash", paths, True) == "/bin/bash"
    paths = [ "/bin", "/usr/local/bin" ]
    assert get_bin_path("sh", paths, False) == "/bin/sh"
    assert get_bin_path("bash", paths, False) == "/usr/local/bin/bash"
    assert get_bin_path("bash", paths) == "/usr/local/bin/bash"

# Generated at 2022-06-20 16:11:10.313198
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')
    assert get_bin_path('ls', ['.'])
    assert get_bin_path('ls', ['/bin'])
    assert get_bin_path('ls', ['/usr/bin'])
    assert get_bin_path('ls', ['/bin', '/bin'])
    assert get_bin_path('ls', ['/bin', '/usr/bin', '/bin'])
    try:
        get_bin_path('false')
    except ValueError as e:
        assert 'Failed to find' in e.message
    try:
        get_bin_path('false', ['.'])
    except ValueError as e:
        assert 'Failed to find' in e.message

if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-20 16:11:18.696996
# Unit test for function get_bin_path
def test_get_bin_path():
    test_bin_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_utils_executable')
    assert get_bin_path('ls') is not None
    assert get_bin_path(test_bin_path, opt_dirs=['/bin']) == test_bin_path
    import pytest
    with pytest.raises(ValueError) as e:
        get_bin_path(test_bin_path)
    assert str(e.value) == 'Failed to find required executable "%s" in paths: /sbin:/usr/sbin:/usr/local/sbin' % test_bin_path

# Generated at 2022-06-20 16:11:21.352370
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-20 16:11:26.121940
# Unit test for function get_bin_path
def test_get_bin_path():
    required = True
    test_paths = ['/usr/bin', '/bin', '/usr/sbin', 'usr/local/bin']
    test_arg = 'ping'
    try:
        get_bin_path(arg=test_arg, opt_dirs=test_paths, required=required)
    except ValueError as e:
        print(e)
        assert False

# Generated at 2022-06-20 16:11:37.595262
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test for getting the path of a specified executable.
    '''

    from ansible.module_utils.common.os import get_bin_path as gbp
    from ansible.module_utils.six import PY3
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    test_executable = 'test_executable'
    test_executable_path = os.path.join(temp_dir, test_executable)
    open(test_executable_path, 'w').close()
    os.chmod(test_executable_path, 0o755)
    gbp('test_executable', opt_dirs=[temp_dir])
    os.unlink(test_executable_path)
    shutil.rmtree(temp_dir)

    #

# Generated at 2022-06-20 16:11:50.074395
# Unit test for function get_bin_path
def test_get_bin_path():
    '''unit test for get_bin_path'''
    import tempfile
    import shutil
    import stat

    # setup in temporary directory
    tmp_dir = tempfile.mkdtemp()

    # make a fake file in tmp_dir and make it executable
    fake_file = tempfile.NamedTemporaryFile(prefix='fake', dir=tmp_dir, delete=False)
    fake_file.close()
    os.chmod(fake_file.name, stat.S_IRWXU)

    # make a fake subdirectory in tmp_dir
    sub_dir = tempfile.mkdtemp(prefix='sub', dir=tmp_dir)

    # make a fake file in sub_dir
    fake_file2 = tempfile.NamedTemporaryFile(prefix='fake', dir=sub_dir, delete=False)
   

# Generated at 2022-06-20 16:11:57.848706
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    import tempfile
    import textwrap
    import unittest

    class GetBinPathTestCase(unittest.TestCase):

        def test_find_system_executable_in_path(self):
            tempdir = tempfile.mkdtemp()
            # create a mock script in the tempdir
            script_text = textwrap.dedent("""
            #!%s
            print('I am executable')
            """ % sys.executable)
            script_path = os.path.join(tempdir, 'test_script')
            with open(script_path, 'w') as script_file:
                script_file.write(script_text)
            os.chmod(script_path, 0o755)
            # test that the mock script can be found
            test_executable = os.path

# Generated at 2022-06-20 16:12:05.578788
# Unit test for function get_bin_path
def test_get_bin_path():
    import tempfile
    import shutil
    import stat
    import errno
    import os
    import sys

    saved_env = os.environ.copy()
    saved_path = os.path.abspath(os.curdir)
    bin_test_dir = None
    bin_test_file = None


# Generated at 2022-06-20 16:12:08.739893
# Unit test for function get_bin_path
def test_get_bin_path():
    res = get_bin_path('sh')
    print(res)

# Sample command line to execute script directly
# python get_bin_path.py

# Generated at 2022-06-20 16:12:19.101991
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('missing')
        assert False
    except ValueError:
        pass
    get_bin_path('ls')
    get_bin_path('ls', ['/bin'])
    get_bin_path('ls', ['/bin'], True)
    try:
        get_bin_path('ls', ['/missing'])
        assert False
    except ValueError:
        pass
    get_bin_path('ls', ['/missing'], True)
    try:
        get_bin_path('missing', ['/bin'])
        assert False
    except ValueError:
        pass
    get_bin_path('missing', ['/bin'], True)
    try:
        get_bin_path('missing', ['/missing'])
        assert False
    except ValueError:
        pass


# Generated at 2022-06-20 16:12:30.142493
# Unit test for function get_bin_path
def test_get_bin_path():
    # Pass a list of directories to search
    path_list = ["/usr/bin/", "/bin/"]
    try:
        assert get_bin_path('ls', path_list) == "/bin/ls"
    except ValueError:
        # No ls in /bin or /usr/bin
        pass
    try:
        assert get_bin_path('xyz', path_list) == None
    except ValueError:
        # This fails, but it's the expected behaviour
        pass

    # Without a list of directories, check it finds the executable in PATH
    assert get_bin_path('ls')
    try:
        assert get_bin_path('xyz') == None
    except ValueError:
        # This fails, but it's the expected behaviour
        pass

# Generated at 2022-06-20 16:12:40.997266
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # Call get_bin_path with an arg which is not in the PATH. Expected result: ValueError
        get_bin_path("noexecutable")
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError"

    try:
        # Call get_bin_path with an arg which is in the PATH (ls). Expected result: return path to ls
        assert get_bin_path("ls") == "/bin/ls"
    except ValueError:
        assert False, "Unexpected ValueError"


# Generated at 2022-06-20 16:12:46.970408
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('doesnotexist', required=False)
    except ValueError:
        pass
    else:
        print("Failed to raise exception on non-existent executable")

    try:
        get_bin_path('doesnotexist', required=True)
    except ValueError:
        pass
    else:
        print("Failed to raise exception on non-existent executable")

    try:
        get_bin_path('doesnotexist', required=True, opt_dirs=['/'])
    except ValueError:
        pass
    else:
        print("Failed to raise exception on non-existent executable")

    try:
        get_bin_path('doesnotexist', required=False, opt_dirs=['/'])
    except ValueError:
        pass

# Generated at 2022-06-20 16:12:48.434374
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("cat") == "/bin/cat"

# Generated at 2022-06-20 16:12:52.041604
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ['PATH'] = '/usr/bin:/bin'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('bash') == '/usr/bin/bash'
    assert get_bin_path('nonexistent') == '/usr/bin/nonexistent'

# Generated at 2022-06-20 16:12:53.339726
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh')
    assert bin_path == '/bin/sh'

# Generated at 2022-06-20 16:13:01.539789
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Basic unit test for get_bin_path()
    '''

    bin_path = get_bin_path("cat")
    assert bin_path == "/bin/cat"

    try:
        get_bin_path("cat", ["/no_bin"])
    except ValueError:
        pass
    else:
        pass # assert False, "Expected ValueError for non-existent path"

    try:
        get_bin_path("cat", ["/bin"])
    except ValueError:
        pass
    else:
        pass # assert False, "Expected ValueError for non-executable path"

    try:
        get_bin_path("cat", ["/etc"])
    except ValueError:
        pass
    else:
        pass # assert False, "Expected ValueError for directory path"

# Generated at 2022-06-20 16:13:04.308304
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest

    with pytest.raises(ValueError, match=r'Failed to find required executable "blahblah" in paths'):
        get_bin_path("blahblah")

# Generated at 2022-06-20 16:13:08.902812
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('sh', ['/bin'])
    assert bin_path == '/bin/sh'

    try:
        get_bin_path('nonexistent_binary_with_this_name')
        raise Exception('get_bin_path did not raise an exception')
    except ValueError as e:
        assert 'Failed to find required executable "nonexistent_binary_with_this_name"' in str(e)

# Generated at 2022-06-20 16:13:12.136138
# Unit test for function get_bin_path
def test_get_bin_path():

    # test successful run
    assert get_bin_path("mkdir") is not None

    # test failed run
    try:
        get_bin_path("my_command_does_not_exist")
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

# Generated at 2022-06-20 16:13:23.846148
# Unit test for function get_bin_path
def test_get_bin_path():
    import shutil
    from tempfile import mkdtemp
    from ansible.module_utils.common.file import atomic_move
    import os.path

    # Create a temporary directory
    tmpdir = mkdtemp()

    # Create directory for optional dir testing
    optdir = os.path.join(tmpdir, "optional")

    # Create file within temporary directory
    (fd, test_file) = tempfile.mkstemp(dir=tmpdir)

    # close the file
    os.close(fd)

    # make the file executable
    os.chmod(test_file, 0o755)

    # rename the file to named in test
    shutil.move(test_file, os.path.join(tmpdir, "test_exec"))

    # create the optional directory
    os.mkdir(optdir)

   

# Generated at 2022-06-20 16:13:27.093436
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('ls')
    assert 'bin/ls' in bin_path
    try:
        bin_path = get_bin_path('no_such_executable')
        assert False, 'Expected ValueError exception not raised'
    except ValueError:
        pass

# Generated at 2022-06-20 16:13:35.060683
# Unit test for function get_bin_path
def test_get_bin_path():
    # captureable mock of this function, used in the unittest below
    import sys
    import platform
    from ansible.module_utils.basic import AnsibleModule

    def mock_fail_json(*args, **kwargs):
        module.fail_json(*args, **kwargs)

    def mock_get_bin_path(arg, required=None):
        if arg == 'false':
            raise ValueError('Failed to find required executable')
        bin_path = None
        if arg == 'ls':
            if platform.system() == 'SunOS':
                bin_path = '/bin/ls'
            else:
                bin_path = '/usr/bin/ls'
        if arg == 'does_not_exist':
            bin_path = '/usr/bin/does_not_exist'
        return bin_path


# Generated at 2022-06-20 16:13:46.351130
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test to see if it finds standard executables
    assert get_bin_path('awk')
    assert get_bin_path('true')

    # Test to see if it finds executables in optional dir list
    assert get_bin_path('true', opt_dirs = ['/bin'])
    assert get_bin_path('true', ['/bin'])

    # Test to see if it finds executables in $PATH
    assert get_bin_path('true')

    # Test to see if it finds executables in $PATH and optional dirs
    assert get_bin_path('true', ['/bin'])

    # Test to see if it raises exception when an executable is not found
    try:
        get_bin_path('blah')
        raise AssertionError('Should have raised exception')
    except ValueError:
        pass
   

# Generated at 2022-06-20 16:13:58.075607
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sed').endswith('/sed')
    assert get_bin_path('sed', opt_dirs=['/opt/test']) == '/opt/test/sed'
    assert get_bin_path('sed', opt_dirs=['/opt/test'], required=True) == '/opt/test/sed'
    assert get_bin_path('sed', opt_dirs=['/opt/test'], required=False) == '/opt/test/sed'

    try:
        get_bin_path('seddd')
    except ValueError as e:
        assert 'not found' in str(e)

    try:
        get_bin_path('seddd', required=True)
    except ValueError as e:
        assert 'not found' in str(e)

    assert get_bin_

# Generated at 2022-06-20 16:14:04.927543
# Unit test for function get_bin_path
def test_get_bin_path():
    # returns the full path of a given binary existing in /bin
    path = get_bin_path('sh')
    assert path
    assert is_executable(path)

    # negative testing
    from ansible.module_utils.common.exceptions import AnsibleFileNotFound
    try:
        get_bin_path('xyzzy')
        assert False, "AnsibleFileNotFound should have been raised"
    except AnsibleFileNotFound:
        assert True

    # negative testing
    try:
        get_bin_path('xyzzy', ['/does/not/exist'])
        assert False, "AnsibleFileNotFound should have been raised"
    except AnsibleFileNotFound:
        assert True

    # positive testing
    # this may fail on TravisCI, but should be fine on most systems

# Generated at 2022-06-20 16:14:14.442320
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.text.converters import to_str
    import pytest

    try:
        get_bin_path('ansible-galaxy')
    except ValueError as e:
        assert 'Failed to find required executable' in to_native(e)

    assert get_bin_path('ansible-galaxy', required=False) is None

    try:
        get_bin_path('ansible-galaxy', required=True)
    except ValueError as e:
        assert 'Failed to find required executable' in to_native(e)

    assert get_bin_path('ansible-galaxy', [], required=False) is None

   

# Generated at 2022-06-20 16:14:25.514563
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1: get_bin_path('chown') confirms that 'chown' in /bin is returned.
    # No opt_dirs used so return will be the path to 'chown' in /bin
    # This test assumes that /bin/chown exists.
    path_chown = get_bin_path('chown')
    assert path_chown == '/bin/chown'

    # Test 2: get_bin_path('chown', ['/sbin']) confirms that 'chown' in /sbin
    # is returned. In this case, opt_dirs is used so return will be the path
    # to 'chown' in /sbin
    # This test assumes that /sbin/chown exists.
    path_chown = get_bin_path('chown', ['/sbin'])
    assert path

# Generated at 2022-06-20 16:14:33.384876
# Unit test for function get_bin_path
def test_get_bin_path():
    test_paths = [
        '/bin/foo',
        '/usr/bin/bar',
        '/usr/local/bin/other',
    ]
    for test_path in test_paths:
        try:
            assert(get_bin_path('foo') == '/bin/foo')
        except ValueError:
            assert(False)
        try:
            assert(get_bin_path('foo', ['/usr/bin']) == '/usr/bin/foo')
        except ValueError:
            assert(False)
        try:
            get_bin_path('invalid', None, True)
        except ValueError:
            assert(True)

# Generated at 2022-06-20 16:14:44.246259
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test function get_bin_path
    '''
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text

    primary_arch = basic._get_primary_arch()

    bin_path = get_bin_path('try_executable_with_opt_dirs', opt_dirs=[to_text(os.path.expanduser('~/architecture/{}/path_executables'.format(primary_arch)))])
    assert bin_path == to_text(os.path.expanduser('~/architecture/{}/path_executables/try_executable_with_opt_dirs'.format(primary_arch)))

    bin_path = get_bin_path('try_executable_with_opt_dirs')
    assert bin

# Generated at 2022-06-20 16:14:46.483849
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('nowaythiscommandexists') == '/bin/sh'