

# Generated at 2022-06-24 20:45:58.967564
# Unit test for function get_bin_path
def test_get_bin_path():
    path = os.getcwd().split('/')[-1]
    assert get_bin_path(path)


# Generated at 2022-06-24 20:46:02.006760
# Unit test for function get_bin_path
def test_get_bin_path():
    bool_0 = True
    var_0 = get_bin_path(bool_0)
    bool_0 = True
    var_0 = get_bin_path(bool_0)

# Generated at 2022-06-24 20:46:02.997108
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None

# Generated at 2022-06-24 20:46:05.905996
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path("false")
    assert bin_path == '/bin/false'



# Generated at 2022-06-24 20:46:13.988487
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ['PATH'] = '/usr/bin'
    # Path does not exist
    assert get_bin_path('/usr/bin/python') == '/usr/bin/python'
    # Path is a directory
    assert get_bin_path('/usr') == '/usr'
    # Path is not executable
    try:
        get_bin_path('/etc/password')
    except ValueError as e:
        assert 'Failed to find required executable "/etc/password" in paths:' in str(e)
    # Path is executable
    assert get_bin_path('/bin/cat') == '/bin/cat'
    # Path is not in PATH

# Generated at 2022-06-24 20:46:15.241134
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(test_case_0) == None



# Generated at 2022-06-24 20:46:23.144145
# Unit test for function get_bin_path
def test_get_bin_path():
    # Make sure that module can be imported
    from ansible.module_utils.basic import AnsibleModule

    # Call the function
    func_return = get_bin_path("test-0")
    assert func_return == "test-0"

    # make sure function accepts optional parameter opt_dirs which is a list
    func_return = get_bin_path("test-0", opt_dirs=["/test-0-path"])
    assert func_return == "/test-0-path/test-0"

    # test required parameter with value True
    func_return = get_bin_path("test-1", required=True)
    assert func_return == "test-1"

    # test required parameter with value False
    func_return = get_bin_path("test-1", required=False)
    assert func_return

# Generated at 2022-06-24 20:46:24.516160
# Unit test for function get_bin_path
def test_get_bin_path():
    print("Testing get_bin_path")

    test_case_0()

test_get_bin_path()

# Generated at 2022-06-24 20:46:26.153041
# Unit test for function get_bin_path
def test_get_bin_path():
    # test_case_0
    bool_0 = False
    # var_0 = get_bin_path(bool_0)

# Generated at 2022-06-24 20:46:35.290757
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:46:39.401941
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('arg_0', ['opt_dirs_0'],) == 'bin_path'

# Generated at 2022-06-24 20:46:50.370431
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:46:58.543358
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = False  # type: bool
    arg_1 = False  # type: bool
    arg_2 = False  # type: bool

    # Call function
    try:
        result = get_bin_path(arg_0, arg_1, arg_2)
    except (TypeError, ValueError, Exception) as e:
        result = str(e)

    # Check result
    assert result == 'get_bin_path(): required argument "arg" (pos 1) not found', \
        "get_bin_path() returned an unexpected result: %s" % result



# Generated at 2022-06-24 20:47:01.685880
# Unit test for function get_bin_path
def test_get_bin_path():
    "Test to get the executable path of tools like git."
    bool_0 = get_bin_path('git')
    assert bool_0 is not None


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:47:03.094419
# Unit test for function get_bin_path
def test_get_bin_path():
    bool_0 = False
    var_0 = get_bin_path(bool_0)
    assert var_0 == False
    assert var_0 == False

# Generated at 2022-06-24 20:47:06.104290
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 'test' in get_bin_path('test', opt_dirs=['/'])

# Generated at 2022-06-24 20:47:08.719509
# Unit test for function get_bin_path
def test_get_bin_path():
    opt_dirs = ['string', 'string', 'string']
    required = True
    assert type(get_bin_path('string', opt_dirs, required)) == str

# Generated at 2022-06-24 20:47:14.528644
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('name') == '/path/to/name'
    assert get_bin_path('name', opt_dirs=[]) == '/path/to/name'
    assert get_bin_path('name', opt_dirs=[], required=True) == '/path/to/name'
    assert get_bin_path('name', opt_dirs=['p0', 'p1']) == '/path/to/name'
    assert get_bin_path('name', opt_dirs=['p0', 'p1'], required=True) == '/path/to/name'



# Generated at 2022-06-24 20:47:20.414601
# Unit test for function get_bin_path
def test_get_bin_path():
    direc_0 = '/bin'
    direc_1 = '/usr/bin'
    direc_2 = '/usr/local/bin'
    string_0 = 'ssh'
    string_1 = 'ssh.exe'
    string_2 = 'ssh.EXE'
    string_3 = 'notssh'
    value_0 = get_bin_path(string_0, [])
    value_1 = get_bin_path(string_1, [])
    value_2 = get_bin_path(string_2, [])
    value_3 = get_bin_path(string_3, [])
    value_4 = get_bin_path(string_1, [direc_0])
    value_5 = get_bin_path(string_2, [direc_1])
    value_

# Generated at 2022-06-24 20:47:22.316547
# Unit test for function get_bin_path
def test_get_bin_path():
    var = get_bin_path(path='/test/path', opt_dirs='/test/dirs', required=False)

# Generated at 2022-06-24 20:47:31.456282
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True
    try:
        test_case_0()
        assert False
    except ValueError:
        assert True
    except Exception:
        assert False
    try:
        test_case_0()
        assert False
    except ValueError:
        assert True
    except Exception:
        assert False
    try:
        test_case_0()
        assert False
    except ValueError:
        assert True
    except Exception:
        assert False

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:47:32.171667
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:47:33.377067
# Unit test for function get_bin_path
def test_get_bin_path():
    assert isinstance(get_bin_path(arg='/bin/ls'), str)
    pass

# Generated at 2022-06-24 20:47:35.765775
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)


# Generated at 2022-06-24 20:47:44.592503
# Unit test for function get_bin_path
def test_get_bin_path():
    # Path configuration:
    exe1 = '/opt/foo/bar'
    # Path without executable
    exe2 = '/opt/foo/baz'
    # Non-existant path
    exe3 = '/opt/asdf/asdf'

    os.environ['PATH'] = '/opt/bin:/opt/sbin'

    assert get_bin_path('bar') == exe1
    assert get_bin_path('baz') is None
    assert get_bin_path('sudo') is not None
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('bar', opt_dirs=['/opt/foo']) == exe1

# Generated at 2022-06-24 20:47:45.419220
# Unit test for function get_bin_path
def test_get_bin_path():
    assert False and False


# Generated at 2022-06-24 20:47:46.217345
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh')

# Generated at 2022-06-24 20:47:54.279473
# Unit test for function get_bin_path
def test_get_bin_path():

    f = open('/tmp/ansible_get_bin_path_tests.txt', 'w')
    f.write('''### BEGIN - UNIT TEST ###

## Case 0
# Command from PATH
get_bin_path(ls)
# FIXME: /bin/ls

### END - UNIT TEST ###''')
    f.close()

    cmd = ['/bin/bash', '-c', 'source /tmp/ansible_get_bin_path_tests.txt && python /tmp/ansible_get_bin_path_tests.py']
    return (0, '', '\nCommand execution:')

# Generated at 2022-06-24 20:48:00.458633
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('echo', ['/bin']) == '/bin/echo'

    try:
        get_bin_path('nothing')
    except ValueError:
        pass
    else:
        assert False, 'ValueError not raised'

    try:
        get_bin_path('echo', ['/bin'], ['/usr/bin'])
    except ValueError:
        pass
    else:
        assert False, 'ValueError not raised'

# Generated at 2022-06-24 20:48:03.392074
# Unit test for function get_bin_path
def test_get_bin_path():
    p = get_bin_path('ansible')
    assert p.find('ansible') != -1
    try:
        p = get_bin_path('foo_bar')
    except ValueError:
        pass
    else:
        raise Exception('get_bin_path with invalid arg did not raise ValueError')



# Generated at 2022-06-24 20:48:15.822877
# Unit test for function get_bin_path
def test_get_bin_path():
    tst_lst = []
    assert get_bin_path('/bin/cat', ['/bin']) == '/bin/cat'
    tst_lst.append('/bin/cat')
    assert get_bin_path('/bin/cat', ['/usr/bin', '/bin']) == '/bin/cat'
    tst_lst.append('/bin/cat')
    assert get_bin_path('/bin/cat', ['/usr/bin']) == '/bin/cat'
    tst_lst.append('/bin/cat')
    assert get_bin_path('cat', ['/usr/bin']) == '/bin/cat'
    tst_lst.append('/bin/cat')

# Generated at 2022-06-24 20:48:17.050012
# Unit test for function get_bin_path
def test_get_bin_path():
    assert is_executable(get_bin_path("ls"))



# Generated at 2022-06-24 20:48:20.289029
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = False
    opt_dirs = None
    required = None
    # pass in invalid args to make sure they fail
    # Raises: ValueError
    get_bin_path(arg, opt_dirs, required)


if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:48:24.203041
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = 'test'
    arg_1 = None
    arg_2 = 'test'
    get_bin_path(arg_0, arg_1, arg_2)


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:48:26.880093
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = ''
    opt_dirs = []
    required = None

    # Return value is a string
    path = get_bin_path(arg, opt_dirs, required)
    assert isinstance(path, (str,))

# Generated at 2022-06-24 20:48:29.496157
# Unit test for function get_bin_path
def test_get_bin_path():
    assert not get_bin_path("ssh")



# Generated at 2022-06-24 20:48:34.875809
# Unit test for function get_bin_path
def test_get_bin_path():
    # assert callable(get_bin_path)
    try:
        get_bin_path('/usr/sbin/useradd')
    except Exception:
        assert False
    try:
        get_bin_path('/usr/sbin/NOTAVALIDUSERADD')
    except ValueError:
        assert True

# Generated at 2022-06-24 20:48:36.696804
# Unit test for function get_bin_path
def test_get_bin_path():
    bool_0 = False
    var_0 = get_bin_path(bool_0)



# Generated at 2022-06-24 20:48:38.177507
# Unit test for function get_bin_path
def test_get_bin_path():
    assert isinstance(test_case_0(), str)

# Generated at 2022-06-24 20:48:44.953795
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None, "Test case 0 failed"

# Local variables:
# eval:(setq-local company-minimum-prefix-length 1)
# eval:(setq-local company-tooltip-align-annotations t)
# eval:(setq-local company-tooltip-flip-when-above t)
# eval:(setq-local company-idle-delay 0.1)
# eval:(set-company-backend 'company-capf)
# End:

# Generated at 2022-06-24 20:48:55.011345
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible-config') == '/usr/bin/ansible-config'
    assert get_bin_path('ansible-galaxy') == '/usr/bin/ansible-galaxy'
    assert get_bin_path('ansible-playbook') == '/usr/bin/ansible-playbook'
    assert get_bin_path('ansible') == '/usr/bin/ansible'

# Generated at 2022-06-24 20:49:04.275578
# Unit test for function get_bin_path
def test_get_bin_path():
    # check that it successfully returns path
    assert os.path.isdir(get_bin_path('/bin'))

    # check that it properly raises exception if you provide invalid path
    # also check that still raises exception if you provide valid but wrong path
    bin_path = get_bin_path('/bin_this_doesnt_exist')
    try:
        bin_path = get_bin_path('/bin_this_doesnt_exist')
    except ValueError:
        pass
    except Exception as e:
        raise RuntimeError("Unexpected exception type: %s" % e)
    # check that it raises exception if you provide path and opt_dirs isn't list
    try:
        bin_path = get_bin_path('/bin', opt_dirs={})
    except ValueError:
        pass

# Generated at 2022-06-24 20:49:07.996881
# Unit test for function get_bin_path
def test_get_bin_path():
    # Generates the following test cases:
    #
    # get_bin_path(bool)
    #
    # where bool is one of {False, '0'}
    test_case_0()


# Generated at 2022-06-24 20:49:09.325723
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('arg_0') == '/usr/bin/env'

# Generated at 2022-06-24 20:49:09.840573
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:49:12.574334
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as e:
        print(e)
    else:
        raise AssertionError('Uncaught exception')

# Generated at 2022-06-24 20:49:17.739878
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = ''
    opt_dirs = ['/bin', 'foo']
    required = False
    expected = None
    result = get_bin_path(arg, opt_dirs, required)
    assert result == expected

    arg = ''
    opt_dirs = ['/bin', 'foo']
    required = False
    expected = None
    result = get_bin_path(arg, opt_dirs, required)
    assert result == expected

# Generated at 2022-06-24 20:49:21.399657
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert isinstance(test_case_0(), str)
    except (AssertionError, ValueError) as e:
        print("Failed test_get_bin_path: {}".format(e))
        raise



# Generated at 2022-06-24 20:49:23.331467
# Unit test for function get_bin_path
def test_get_bin_path():
    assert "Failed to find required executable \"False\" in paths: /sbin:/usr/sbin:/usr/local/sbin" == test_case_0()

# Generated at 2022-06-24 20:49:24.102426
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:49:37.112262
# Unit test for function get_bin_path
def test_get_bin_path():

    # Check if the function throws when required is set to True
    try:
        get_bin_path("invalid_binary", required=True)
    except ValueError as e:
        err_msg = "Failed to find required executable \"invalid_binary\" in paths: %s" % (os.pathsep.join(os.environ.get('PATH', '').split(os.pathsep)))
        assert str(e) == err_msg, "Unexpected exception message: %s" % str(e)
        return

    # required does not default to True.  ValueError should be raised.

# Generated at 2022-06-24 20:49:39.511676
# Unit test for function get_bin_path
def test_get_bin_path():
    path_0 = '/usr/bin'
    path_1 = 'python'
    ret_0 = get_bin_path(path_1, [path_0])
    assert ret_0 == path_0 + '/python', ret_0


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:49:42.384069
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = 'pip'
    arg_1 = None
    arg_2 = None
    result = get_bin_path(arg_0, arg_1, arg_2)
    assert isinstance(result, (str, unicode))


# Generated at 2022-06-24 20:49:43.633864
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls -l') == 'ls'

# Generated at 2022-06-24 20:49:46.443899
# Unit test for function get_bin_path
def test_get_bin_path():

    # Get tests from lint/test_default.yml
    test_cases = (test_case_0)

    for test in test_cases:
        try:
            test()
        except:
            pass

# Generated at 2022-06-24 20:49:52.376081
# Unit test for function get_bin_path
def test_get_bin_path():
    print('Start tests for function get_bin_path')

    # Testing for case 0
    print('Case 0: python3 does not exist')
    try:
        test_case_0()
        print('Case 0: pass')
    except ValueError as e:
        print('Case 0: fail\n Exception: %s' % e)

    print('End tests for function get_bin_path')


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:50:00.890970
# Unit test for function get_bin_path
def test_get_bin_path():

    # simple test to check the name
    assert get_bin_path("which").endswith("/which")

    # simple test to check the name for a package name
    try:
        get_bin_path("some_non_existent_package")
    except ValueError as e:
        assert "some_non_existent_package" in str(e)

    # check if we can read this executable
    assert get_bin_path("which", ['/usr/bin']).endswith("/which")

    # check that the path is returned even if we cant find the executable
    try:
        get_bin_path("which", ['/var/tmp'])
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

# Generated at 2022-06-24 20:50:01.464379
# Unit test for function get_bin_path
def test_get_bin_path():
    assert "passed" == True

# Generated at 2022-06-24 20:50:08.599443
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ["PATH"] = "/bin:/usr/bin:/usr/local/bin"
    assert get_bin_path('ls') == '/bin/ls'
    os.environ["PATH"] = "/bin:/usr/bin:/usr/local/bin"
    assert get_bin_path('ls', ['/usr/bin', '/usr/local/bin']) == '/usr/bin/ls'
    os.environ["PATH"] = "/bin:/usr/bin:/usr/local/bin"
    assert get_bin_path('ls', ['/usr/bin', '/usr/local/bin']) == '/usr/bin/ls'
    os.environ["PATH"] = "/bin:/usr/bin:/usr/local/bin"
    assert get_bin_path('ls', required=False) == '/bin/ls'

# Generated at 2022-06-24 20:50:12.621918
# Unit test for function get_bin_path
def test_get_bin_path():
    # Assign values to arg1, arg2, arg3, arg4, arg5, arg6, arg7
    arg1 = ''

    # Call the function
    func_return_value = get_bin_path(arg1)

    # Assert return code
    assert func_return_value is not None


# Generated at 2022-06-24 20:50:15.402084
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:50:24.403935
# Unit test for function get_bin_path
def test_get_bin_path():

    from ansible.module_utils import basic

    # Test case 1
    path = get_bin_path("/usr/sbin/iptables")
    actual = basic.path_dwim("/usr/sbin/iptables")
    assert actual == path

    # Test case 2
    path = get_bin_path("iptables")
    actual = basic.path_dwim("iptables")
    assert actual == path

    # Test case 3
    path = get_bin_path("iptables", [])
    actual = basic.path_dwim("iptables")
    assert actual == path

    # Test case 4
    path = get_bin_path("iptables", [], False)
    actual = basic.path_dwim("iptables")
    assert actual == path


# Generated at 2022-06-24 20:50:25.554028
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True == (get_bin_path('ls'))



# Generated at 2022-06-24 20:50:30.923173
# Unit test for function get_bin_path
def test_get_bin_path():
    var_1 = False
    var_2 = None
    try:
        res_0 = get_bin_path('ls', var_1, var_2)
        assert res_0 == '/bin/ls'
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-24 20:50:35.695914
# Unit test for function get_bin_path
def test_get_bin_path():
    print("in function get_bin_path ")
    path = os.getcwd() # get current directory
    print("path: ", path)
    path = "./../module_utils/common/file"
    get_bin_path("module_utils/common/file")


# Generated at 2022-06-24 20:50:38.702610
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/', required=False) == '/'
    assert get_bin_path('/usr/bin/sh', opt_dirs=['/']), '/usr/bin/sh'

# Generated at 2022-06-24 20:50:47.413935
# Unit test for function get_bin_path
def test_get_bin_path():
    # these tests won't pass on OSX unless we manually mock the `is_executable` test.
    # I think that's OK.
    # Current (4/3/2020) tests still pass on OSX for get_bin_path because we mock
    # the `is_executable` function.
    bool_0 = True
    var_0 = get_bin_path(bool_0)
    assert var_0 == ''

    bool_1 = True
    var_0 = get_bin_path(bool_1)
    assert var_0 == ''

    bool_2 = True
    var_0 = get_bin_path(bool_2)
    assert var_0 == ''

    bool_3 = True
    var_0 = get_bin_path(bool_3)
    assert var_0 == ''

    bool_4

# Generated at 2022-06-24 20:50:49.507267
# Unit test for function get_bin_path
def test_get_bin_path():
    # Source: Ansible Module
    assert False
    # assert get_bin_path(False) == False

# Generated at 2022-06-24 20:50:51.809835
# Unit test for function get_bin_path
def test_get_bin_path():
    opt_dirs = ['opt_dirs']
    required = True

    assert True # TODO: may be replace assertion with "Equals" in the future



# Generated at 2022-06-24 20:50:59.177383
# Unit test for function get_bin_path
def test_get_bin_path():
    # no optional args
    assert get_bin_path('ls') == '/bin/ls'

    # add /usr/bin to search path
    assert get_bin_path('ls', ['/usr/bin']) == '/usr/bin/ls'

    # arg not found
    try:
        get_bin_path('not_a_real_arg')
    except ValueError as e:
        assert e.args[0] == 'Failed to find required executable "not_a_real_arg" in paths: /bin:/usr/bin:/usr/sbin:/sbin:/usr/local/sbin'
    else:
        assert False, 'no ValueError raised'

    # arg not found, add /usr/sbin

# Generated at 2022-06-24 20:51:02.919222
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path("/usr/bin")
    assert path == "/usr/bin"


# Generated at 2022-06-24 20:51:04.289926
# Unit test for function get_bin_path
def test_get_bin_path():

    # Testing the return value of the function get_bin_path
    assert get_bin_path() == ValueError

# Generated at 2022-06-24 20:51:08.326747
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() is None

if __name__ == '__main__':
    print("Running unit test for function %s" % os.path.basename(__file__))
    print("========================================")
    test_get_bin_path()

# Generated at 2022-06-24 20:51:10.097696
# Unit test for function get_bin_path
def test_get_bin_path():
    bool_0 = False
    var_0 = get_bin_path(bool_0)
    assert var_0 == None

# Generated at 2022-06-24 20:51:19.332198
# Unit test for function get_bin_path
def test_get_bin_path():
    import random

    param_0 = 'mkdir'

    parameter_0 = [
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
        'mkdir',
    ]

    # random tests
    for i in range(100):
        param_0 = random.choice(parameter_0)
        result = get_bin_path(param_0)
        print(result)

# Generated at 2022-06-24 20:51:19.899302
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:51:27.651218
# Unit test for function get_bin_path
def test_get_bin_path():
    # Start from zero
    rc = 0
    failed = []
    import sys
    import pytest
    from ansible.module_utils.six import PY3

    try:
        test_case_0()
    except Exception as e:
        if 'ValueError' in str(e):
            rc = 0
        else:
            rc = 1
            failed.append(str(e).strip())

    if rc != 0:
        pytest.fail('\n' + '\n'.join(failed))

# Generated at 2022-06-24 20:51:32.777101
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = '' # TODO: construct a proper input value
    opt_dirs = [] # TODO: construct a proper input value
    required = None # TODO: construct a proper input value

    # Test function
    result = get_bin_path(arg, opt_dirs, required)

    assert result is None



# Generated at 2022-06-24 20:51:36.941426
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/bash') == '/bin/bash'
    assert get_bin_path('') == '/bin/bash'
    assert get_bin_path('no-such-file') == '/bin/bash'
    assert get_bin_path(None) == '/bin/bash'

# Generated at 2022-06-24 20:51:45.895062
# Unit test for function get_bin_path
def test_get_bin_path():
    #////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////
    # Expected Exception: ValueError
    try:
        test_case_0()
    except ValueError as e:
        assert type(e) == ValueError

    #////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////
    # Expected Exception: ValueError
    try:
        bool_0 = False
        get_bin_path(bool_0)
    except ValueError:
        pass
    else:
        assert False, "Should raise ValueError"

# Generated at 2022-06-24 20:51:56.493285
# Unit test for function get_bin_path
def test_get_bin_path():
    ret_1 = None
    ret_2 = None
    ret_3 = None
    ret_4 = None
    ret_5 = None

    ret_1 = get_bin_path(arg_0='uname')
    ret_2 = get_bin_path(arg_0='df')
    ret_3 = get_bin_path(arg_0='gzip')
    ret_4 = get_bin_path(arg_0='cat')
    ret_5 = get_bin_path(arg_0='uname', opt_dirs=['/sbin'])
    return (ret_1, ret_2, ret_3, ret_4, ret_5)


# Generated at 2022-06-24 20:52:01.925194
# Unit test for function get_bin_path
def test_get_bin_path():
    # Assert not found in PATH
    try:
        get_bin_path('/nonexistent', required=True)
    except ValueError:
        pass
    else:
        raise AssertionError('Expected exception not raised')
    # Assert found in PATH
    bin_path = get_bin_path('/bin/sh')


# Class to test type requirements

# Generated at 2022-06-24 20:52:09.254704
# Unit test for function get_bin_path
def test_get_bin_path():
    test_cases = []
    # Case 0:
    bool_0 = False
    var_0 = get_bin_path(bool_0)

    # Case 1:
    bool_1 = False
    var_1 = get_bin_path(bool_1)

    # Case 2:
    bool_2 = True
    var_2 = get_bin_path(bool_2)

    # Case 3:
    bool_3 = True
    var_3 = get_bin_path(bool_3)

# Test for function get_bin_path when args['paths'] is not set

# Generated at 2022-06-24 20:52:13.243934
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = b'/etc/test'
    assertion_result = True
    expected = True
    try:
        bin_path = get_bin_path(arg)
        assertion_result = os.path.exists(bin_path)
    except Exception as e:
        print(e)
        assertion_result = False
    assert assertion_result == expected

# Generated at 2022-06-24 20:52:17.571242
# Unit test for function get_bin_path
def test_get_bin_path():

    # Call get_bin_path with correct parameters
    result = get_bin_path('/usr/bin/env')

    # Check if the result is correct
    assert result == '/usr/bin/env'

# Generated at 2022-06-24 20:52:19.618112
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True
    #assert not False


if __name__ == "__main__":
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:52:27.780321
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(False) == get_bin_path(None)
    assert get_bin_path(False) == get_bin_path(True)
    assert get_bin_path(False) == get_bin_path('')
    assert get_bin_path(False) == get_bin_path(0)
    assert get_bin_path(False) == get_bin_path(1)
    assert get_bin_path(False) == get_bin_path('0')
    assert get_bin_path(False) == get_bin_path('1')
    assert get_bin_path(False) == get_bin_path('False')
    assert get_bin_path(False) == get_bin_path('True')
    assert get_bin_path(False) == get_bin_path('false')

# Generated at 2022-06-24 20:52:29.119352
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


# Main program - this runs all the test cases in the examples above

# Generated at 2022-06-24 20:52:34.427795
# Unit test for function get_bin_path
def test_get_bin_path():
    exepcted_result = '/usr/local/sbin/arg_0'
    result = get_bin_path('arg_0')

    assert exepcted_result == result

# Main program
if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:52:44.351624
# Unit test for function get_bin_path
def test_get_bin_path():
    path = os.environ["PATH"].split(':')
    assert get_bin_path('ls', path, False) == '/usr/bin/ls'
    assert get_bin_path('ls') == '/usr/bin/ls'
    assert get_bin_path('ls', path, True) == '/usr/bin/ls'
    assert get_bin_path('ls', path, None) == '/usr/bin/ls'
    assert get_bin_path('ls', path) == '/usr/bin/ls'
    assert get_bin_path('ls', [path]) == '/usr/bin/ls'
    assert get_bin_path('ls', [path[0]]) == '/usr/bin/ls'

# Generated at 2022-06-24 20:52:55.123089
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:52:56.318040
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(False) # == None


# Generated at 2022-06-24 20:52:57.680680
# Unit test for function get_bin_path
def test_get_bin_path():
    # Make sure no exception is raised
    assert not bool(get_bin_path("/sbin"))

# Generated at 2022-06-24 20:52:58.733990
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:53:06.557943
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('/bin/id')
    assert path == '/bin/id'
    # Use cases
    try:
        get_bin_path('/bin/id', ['/bin'])
    except ValueError:
        pass
    else:
        assert False, 'ValueError was not raised'
    # Do not raise error if path is missing, but executable is found in PATH
    try:
        get_bin_path('/bin/id', None, True)
    except ValueError:
        assert False, 'ValueError was raised'
    else:
        pass



# Generated at 2022-06-24 20:53:16.763871
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = ["/usr/bin", "/usr/sbin"]
    var_1 = ["/usr/bin", "/usr/sbin", "/usr/local/sbin"]
    bool_0 = False
    bool_1 = True
    arg_0 = ""
    arg_1 = "pip"
    arg_2 = "apt"
    arg_3 = "ansible"
    arg_4 = "ansible-playbook"
    arg_5 = "ansible-galaxy"
    arg_6 = "pip"
    arg_7 = "apt"
    arg_8 = "ansible"
    arg_9 = "ansible-playbook"
    arg_10 = "ansible-galaxy"

    # Test get_bin_path(arg1, [arg2, arg3])

# Generated at 2022-06-24 20:53:27.186555
# Unit test for function get_bin_path
def test_get_bin_path():
    # Path in 'PATH' environment variable
    assert get_bin_path('true') == '/bin/true'

    # Absolute path
    assert get_bin_path('/bin/true') == '/bin/true'

    # Path not in 'PATH' environment variable, but in 'opt_dirs'
    assert get_bin_path('true', opt_dirs=['/sbin']) == '/sbin/true'

    # Path does not exist
    try:
        get_bin_path('/foo/bar/true')
    except ValueError as e:
        assert e.args[0] == "Failed to find required executable \"/foo/bar/true\" in paths: /sbin:/bin:/usr/sbin:/usr/bin:/usr/local/sbin:/usr/local/bin"

    # Gather facts on FreeBSD system

# Generated at 2022-06-24 20:53:29.546923
# Unit test for function get_bin_path
def test_get_bin_path():
    var_1 = False
    var_2 = None
    var_3 = False
    var_4 = get_bin_path(var_1, var_2, var_3)

# Generated at 2022-06-24 20:53:30.992342
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('./file') == './file'

# Generated at 2022-06-24 20:53:33.365177
# Unit test for function get_bin_path
def test_get_bin_path():
    bool_1 = True
    assert True == is_executable(get_bin_path(bool_1))


# Generated at 2022-06-24 20:53:36.777176
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == 0



# Generated at 2022-06-24 20:53:46.771405
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("curl") is not None
    assert get_bin_path("curl", ["/usr/bin"]) is not None
    assert get_bin_path("curl", ["/usr/bin", "/usr/local/bin"]) is not None
    assert get_bin_path("curl", opt_dirs=["/usr/bin"]) is not None
    assert get_bin_path("curl", opt_dirs=["/usr/bin", "/usr/local/bin"]) is not None
    assert get_bin_path("curl", ["/usr/bin"], required=False) is not None
    assert get_bin_path("curl", ["/usr/bin", "/usr/local/bin"], required=False) is not None

# Generated at 2022-06-24 20:53:55.002558
# Unit test for function get_bin_path
def test_get_bin_path():
    passed = False
    try:
        test_case_0()
        passed = True
    except SystemExit:
        # exception from sys.exit()
        passed = False
    except Exception:
        # other exception
        passed = False
    assert passed, "Unit test for get_bin_path" 


if __name__ == "__main__":
    test_get_bin_path()
    for test in [test_get_bin_path]:
        test()

# Generated at 2022-06-24 20:53:59.646778
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:54:00.865353
# Unit test for function get_bin_path
def test_get_bin_path():

    # Execution of function is successful
    assert(test_case_0() is None)

# Generated at 2022-06-24 20:54:05.250350
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Unit test for function get_bin_path.
    """
    os.environ['PATH'] = '/bin:/usr/bin'
    assert get_bin_path('sh') == '/bin/sh'

    os.environ['PATH'] = '/bin:/usr/bin'
    try:
        get_bin_path('bogus')
    except ValueError:
        pass
    else:
        assert False, 'Test #1 failed'

    os.environ['PATH'] = '/bin:/usr/bin'
    assert get_bin_path('sh', ['/sbin', '/usr/sbin']) == '/sbin/sh'

    os.environ['PATH'] = '/bin:/usr/bin'

# Generated at 2022-06-24 20:54:09.420140
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test case 1
    result = get_bin_path("ls")
    assert result == "/bin/ls"

    # Test case 2
    result = get_bin_path("ansible", opt_dirs=["/usr/bin", "/usr/sbin"])
    assert result == "/usr/bin/ansible"

    # Test case 3
    result = get_bin_path("ansible", opt_dirs=["/usr/bin", "/usr/sbin"])
    assert result == "/usr/bin/ansible"

# Generated at 2022-06-24 20:54:19.539256
# Unit test for function get_bin_path
def test_get_bin_path():
    bool_0 = False
    var_0 = get_bin_path(bool_0)
    assert var_0 == False

    bool_1 = False
    var_1 = get_bin_path(bool_1, bool_1)
    assert var_1 == False

    str_0 = 'This is a test'
    var_2 = get_bin_path(str_0)
    assert var_2 == 'This is a test'

    str_1 = 'This is a test'
    var_3 = get_bin_path(str_1, str_1)
    assert var_3 == 'This is a test'

    str_2 = 'This is a test'
    var_4 = get_bin_path(str_2)
    assert var_4 == 'This is a test'


# Generated at 2022-06-24 20:54:23.853033
# Unit test for function get_bin_path
def test_get_bin_path():
    opt_dirs = ['/opt/bin']
    required = None
    try:
        var_0 = get_bin_path(opt_dirs, required)
        var_0.assertEqual(var_0, None)
    except ValueError:
        var_0.assertEqual(var_0, None)



# Generated at 2022-06-24 20:54:24.625016
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:54:33.193381
# Unit test for function get_bin_path
def test_get_bin_path():
    with pytest.raises(SystemExit):
        test_case_0()

# Generated at 2022-06-24 20:54:36.653679
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as err:
        print("[Error]{0}".format(err))

if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:54:42.445119
# Unit test for function get_bin_path
def test_get_bin_path():
    # Mock out the module parameters
    arg = 'ansible'
    opt_dirs = None
    required = None

    try:
        # Execute the function, function to be tested
        ret = get_bin_path(arg, opt_dirs, required)
    except Exception as err:
        # Print the exception message for further information
        print('Function get_bin_path() failed with exception message: {0}'.format(err))


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:54:47.765750
# Unit test for function get_bin_path
def test_get_bin_path():
    f_0 = '/etc/bogus_path'
    var_0 = get_bin_path(f_0)
    f_1 = 'asdfadsf'
    var_1 = get_bin_path(f_1)


# Generated at 2022-06-24 20:54:50.659105
# Unit test for function get_bin_path
def test_get_bin_path():
    # Call function
    test_case_0()


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:54:54.032751
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = ''

    # Call function to get result
    result = get_bin_path(arg_0)

    # Tests for value returned
    assert True



# Generated at 2022-06-24 20:54:57.894254
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('test_value_0', opt_dirs=None, required=None)
    except(NameError, UnboundLocalError):
        assert False

    try:
        get_bin_path('test_value_0', None, None)
    except(TypeError):
        assert False



# Generated at 2022-06-24 20:55:06.199688
# Unit test for function get_bin_path
def test_get_bin_path():
    path_0 = "/tmp/ansible_get_bin_path_payload_wiN6Pn"
    assert os.path.exists(path_0) is False
    path_1 = "/tmp/ansible_get_bin_path_payload_C7eB1D"
    assert os.path.exists(path_1) is False

    f = open(path_0, 'w')
    f.close()
    os.chmod(path_0, 0o777)

    f = open(path_1, 'w')
    f.close()
    os.chmod(path_1, 0o777)


# Generated at 2022-06-24 20:55:10.665481
# Unit test for function get_bin_path
def test_get_bin_path():

    # Unit test for function get_bin_path with optionals
    bool_0 = False
    bool_1 = True
    var_0 = get_bin_path(bool_0, bool_1)

    # Unit test for function get_bin_path without optionals
    bool_0 = False
    var_0 = get_bin_path(bool_0)

# Generated at 2022-06-24 20:55:12.475796
# Unit test for function get_bin_path
def test_get_bin_path():

    # If necessary, add other tests here.
    # For example, testing for different types of inputs.

    test_case_0()
    test_case_0()

# Generated at 2022-06-24 20:55:18.277973
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('tar') == '/bin/tar'



# Generated at 2022-06-24 20:55:22.523746
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(' /bin/echo') == '/bin/echo'
    assert get_bin_path('/usr/bin/echo') == '/usr/bin/echo'
    assert get_bin_path('/usr/sbin/echo') == '/usr/sbin/echo'
    assert get_bin_path('echo') == '/bin/echo'

# Generated at 2022-06-24 20:55:26.709178
# Unit test for function get_bin_path
def test_get_bin_path():
    assert (get_bin_path(None) is None), "Argument should be None"
    # assert (get_bin_path is not None), "False is not None"



# Generated at 2022-06-24 20:55:29.241947
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls', required=False) == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-24 20:55:30.826438
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = "Ansible"
    expected = True  # FIXME
    actual = get_bin_path(arg)
    assert actual == expected

# Generated at 2022-06-24 20:55:32.275255
# Unit test for function get_bin_path
def test_get_bin_path():
    # Call the function
    get_bin_path(arg, opt_dirs=opt_dirs, required=required)

# Generated at 2022-06-24 20:55:33.604925
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(False) == 'false'
    assert get_bin_path('false') == 'false'

# Generated at 2022-06-24 20:55:37.638850
# Unit test for function get_bin_path
def test_get_bin_path():
    # assert(get_bin_path(1, [], True) == 2)
    # assert(get_bin_path(2, [], True) == 2)
    test_case_0()

test_get_bin_path()

# Generated at 2022-06-24 20:55:40.225131
# Unit test for function get_bin_path
def test_get_bin_path():
    # Run function get_bin_path to do some test
    test_case_0()

if __name__ == '__main__':
    # Run a unit test
    test_get_bin_path()

# Generated at 2022-06-24 20:55:45.555721
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = False  # True/False
    assert get_bin_path(var_0) == False  # expected True
    var_1 = True  # True/False
    assert get_bin_path(var_1) == True  # expected True
    var_2 = False  # True/False
    assert get_bin_path(var_2) == False  # expected True
    var_3 = True  # True/False
    assert get_bin_path(var_3) == True  # expected True

# Generated at 2022-06-24 20:55:52.937977
# Unit test for function get_bin_path
def test_get_bin_path():

    # Set up test values
    opt_dirs = ['test_opt_dirs']
    required = False

    # Perform the test
    result = get_bin_path(opt_dirs, required)

    # Verify the results
    assert(result == None)

