

# Generated at 2022-06-24 20:46:03.040211
# Unit test for function get_bin_path
def test_get_bin_path():
    with pytest.raises(TypeError):
        get_bin_path("foo")

# Generated at 2022-06-24 20:46:08.067742
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = 1853
    var_1 = get_bin_path(var_0)
    assert var_1 == '/bin/xargs'

    var_2 = 'ping'
    var_3 = get_bin_path(var_2)
    assert var_3 == '/bin/ping'

# Generated at 2022-06-24 20:46:12.522537
# Unit test for function get_bin_path
def test_get_bin_path():
    # These assertions check that the specified arguments to
    # the function raise the appropriate exceptions
    int_0 = 'whatever'
    with pytest.raises(TypeError) as excinfo:
        get_bin_path(int_0)
    with pytest.raises(TypeError) as excinfo:
        get_bin_path(int_0)



# Generated at 2022-06-24 20:46:17.056252
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)


# Generated at 2022-06-24 20:46:24.768897
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = 1853
    opt_dirs = None
    paths = os.environ.get('PATH', '').split(os.pathsep)

    expected_exception = ValueError

    try:
        get_bin_path(arg, opt_dirs)
    except Exception:
        pass

    for path in paths:
        if not path:
            continue
        # validate path
        fullpath = os.path.join(path, arg)
        try:
            assert os.path.exists(fullpath) and not os.path.isdir(fullpath) and is_executable(fullpath)
            test_case_0()
        except Exception:
            if Exception == expected_exception:
                pass
            else:
                raise

    # validate that an exception has been raised

# Generated at 2022-06-24 20:46:27.977135
# Unit test for function get_bin_path
def test_get_bin_path():
    # Setup
    int_0 = 1853
    opt_dirs = []
    required = None

    try:
        result = get_bin_path(int_0, opt_dirs, required)
    except ValueError as e:
        print(e)

# Generated at 2022-06-24 20:46:31.331303
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

test_get_bin_path()

# Generated at 2022-06-24 20:46:32.115479
# Unit test for function get_bin_path
def test_get_bin_path():
    # Case 0 - run through all code blocks

    test_case_0()

# Generated at 2022-06-24 20:46:33.096003
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('/bin/echo')


# Entry point for the test

# Generated at 2022-06-24 20:46:36.056897
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True;

test_case_0()

# Generated at 2022-06-24 20:46:50.283837
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = 'dat3'
    arg_0 = None
    arg_0 = [arg_0]
    arg_1 = None
    var_0 = get_bin_path(arg, arg_0, arg_1)
    opt_dirs = None
    opt_dirs = [opt_dirs]
    required = '1'
    try:
        var_0 = get_bin_path(arg, opt_dirs, required)
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')
    try:
        var_1 = get_bin_path(arg, opt_dirs)
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')

# Generated at 2022-06-24 20:46:55.378950
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('<\x0c2*\rp\rp[fNdHc83 ')

# Test specific functions - usually called via lambda
import os


# Generated at 2022-06-24 20:47:04.847584
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '<\x0c2*\rp\rp[fNdHc83 '
    var_0 = get_bin_path(str_0)
    str_1 = '+rB\x17'
    var_1 = get_bin_path(str_1)
    str_2 = '\x18FsN\nN'
    var_2 = get_bin_path(str_2)
    str_3 = '\x19\x1csY\x0c\x15'
    var_3 = get_bin_path(str_3)
    str_4 = 'D5\x7f'
    var_4 = get_bin_path(str_4)

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:47:09.537742
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible-doc') == '/usr/bin/ansible-doc'
    assert get_bin_path('asdf') == '/usr/bin/asdf'
    assert get_bin_path('vagrant') == '/usr/bin/vagrant'

# Generated at 2022-06-24 20:47:10.540212
# Unit test for function get_bin_path
def test_get_bin_path():
    assert type(test_case_0()) is str

# Generated at 2022-06-24 20:47:13.922076
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '<\x0c2*\rp\rp[fNdHc83 '
    var_0 = get_bin_path(str_0)
    assert var_0 == '/usr/bin/awk'

# Generated at 2022-06-24 20:47:16.980760
# Unit test for function get_bin_path
def test_get_bin_path():
    # mock
    with patch.object(os, 'path') as mock_path:
        from ansible.module_utils.basic import get_bin_path
        mock_path.exists.return_value = False
        mock_path.is_dir.return_value = False

        # setup
        arg_0 = '<\x0c2*\rp\rp[fNdHc83 '
        opt_dirs_0 = []
        required_0 = None

        # test
        try:
            get_bin_path(arg_0, opt_dirs_0, required_0)
            self.fail('Expected ValueError')
        except ValueError:
            pass



# Generated at 2022-06-24 20:47:18.824699
# Unit test for function get_bin_path
def test_get_bin_path():

    # This is just to verify the Python code is correct
    assert True

# Test cases for module get

# Generated at 2022-06-24 20:47:22.905365
# Unit test for function get_bin_path
def test_get_bin_path():

    try:
        # Test with valid arguments
        str_0 = '<\x0c2*\rp\rp[fNdHc83 '
        var_0 = get_bin_path(str_0)

    except ValueError:
        # raise ValueError if executable is not found
        raise



# Generated at 2022-06-24 20:47:31.418812
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec = dict(
            str_0 = dict(type='str'),
        )
    )
    str_0 = module.params['str_0']

    try:
        actual_result = get_bin_path(str_0)
    except Exception as e:
        module.fail_json(msg="Exception: %s" % str(e))

    module.exit_json(changed=False, ansible_facts=dict(actual_result=actual_result))


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:47:39.530814
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = unhexlify('3C0C322A0D70720D70705B664E644863')
    # get_bin_path(arg,opt_dirs=None,required=None) -> str
    get_bin_path(arg)
    assert True

if __name__ == "__main__":
    import hashlib
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:47:41.292746
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:47:46.653819
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.file import get_bin_path

    assert get_bin_path('python')
    assert get_bin_path('python3')
    assert not get_bin_path('hopefully_does_not_exist_py34293894')
    assert get_bin_path('python3', required=False) is None
    assert get_bin_path('python3', opt_dirs=['/']) is None
    assert get_bin_path('python3', opt_dirs=['/usr/bin'])

# Generated at 2022-06-24 20:47:48.560539
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('/bin/ls')



# Generated at 2022-06-24 20:47:58.697227
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("R0s=JOYs6T1") == "/bin/nano"
    assert get_bin_path("xfc&%sR*bARd") == "/bin/mtr"
    assert get_bin_path("FoFNRYb$x+&") == "/bin/ping"
    assert get_bin_path("A5Ogy8z2a)r") == "/bin/vim"
    assert get_bin_path("'*'0l(R$''").split("/")[-1] == "nano"
    assert get_bin_path("j&pa%(+v1-").split("/")[-1] == "nc"
    assert get_bin_path("+uBF7ZzGv}").split("/")[-1] == "nmap"

# Generated at 2022-06-24 20:48:01.332168
# Unit test for function get_bin_path
def test_get_bin_path():
    print('Test: get_bin_path')
    test_case_0()
    print('Test: get_bin_path - OK')


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:48:11.236888
# Unit test for function get_bin_path
def test_get_bin_path():
    # Try to get executable with empty opt_dirs
    try:
        get_bin_path('TEST_EXECUTABLE_0')
    # Should fail
    except ValueError:
        pass
    # Try to get executable inside opt_dirs
    try:
        get_bin_path('TEST_EXECUTABLE_0', opt_dirs=['/home/test/bin'])
    # Should fail
    except ValueError:
        pass
    # Try to get executable with empty opt_dirs and required=False
    try:
        get_bin_path('TEST_EXECUTABLE_0', required=False)
    # Should fail
    except ValueError:
        pass
    # Try to get executable inside opt_dirs and required=False

# Generated at 2022-06-24 20:48:12.871598
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 1
    assert test_case_0() is not None
    assert True


# Cleanup Test Tempfiles

# Generated at 2022-06-24 20:48:14.326914
# Unit test for function get_bin_path
def test_get_bin_path():
    assert False


# Generated at 2022-06-24 20:48:21.266499
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/bash') == '/usr/bin/bash'
    assert get_bin_path('/bin/bash') == '/bin/bash'
    assert get_bin_path('/bin/bash', opt_dirs=[]) == '/bin/bash'
    assert get_bin_path('/bin/bash', opt_dirs=['/opt/bin/']) == '/opt/bin/bash'
    assert get_bin_path('/bin/bash', opt_dirs=['/opt/bin/'], required=True) == '/opt/bin/bash'
    assert get_bin_path('/bin/bash', opt_dirs=['/opt/bin']) == '/opt/bin/bash'

# Generated at 2022-06-24 20:48:26.533413
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '\x0ci\x1f\x0b\x0c\x1d\x1c5\r:\x0b\x15 '
    var_0 = get_bin_path(str_0)


test_case_0()
test_get_bin_path()

# Generated at 2022-06-24 20:48:29.666824
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = '<\x0c2*\rp\rp[fNdHc83 '
    opt_dirs_0 = None
    required_0 = None
    assert get_bin_path(arg_0, opt_dirs_0, required_0) == '/usr/sbin/ls', 'Expected for return value of get_bin_path to be "/usr/sbin/ls" is "%s"' % get_bin_path(arg_0, opt_dirs_0, required_0)

# Generated at 2022-06-24 20:48:32.002582
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path), "Function 'get_bin_path()' not defined"



# Generated at 2022-06-24 20:48:42.109930
# Unit test for function get_bin_path
def test_get_bin_path():
    assert os.path.exists(get_bin_path('ls'))
    assert os.path.exists(get_bin_path('true'))
    assert os.path.exists(get_bin_path('false'))
    assert os.path.exists(get_bin_path('sh'))
    assert os.path.exists(get_bin_path('bash'))
    assert os.path.exists(get_bin_path('cat'))
    assert os.path.exists(get_bin_path('chmod'))
    assert os.path.exists(get_bin_path('cp'))
    assert os.path.exists(get_bin_path('echo'))
    assert os.path.exists(get_bin_path('mkdir'))
    assert os.path.ex

# Generated at 2022-06-24 20:48:53.661000
# Unit test for function get_bin_path
def test_get_bin_path():
    # verify correct number of tasks in play
    assert 1 == len(test_case_0.play.tasks)
    # verify correct ids for all tasks
    assert 'set_fact' == test_case_0.play.get_task(0).action
    # verify correct number of handlers in play
    assert 0 == len(test_case_0.play.handlers)
    # test correct exception thrown for required
    exception_thrown = False
    try:
        get_bin_path('cron')
    except ValueError:
        exception_thrown = True
    assert exception_thrown
    # test correct exception NOT thrown for non required
    exception_thrown = False
    try:
        get_bin_path('cron', required=False)
    except:
        exception_thrown = True
    assert not exception_th

# Generated at 2022-06-24 20:49:03.921894
# Unit test for function get_bin_path
def test_get_bin_path():
    # Make sure that the generated path exist on the filesystem
    assert os.path.exists(get_bin_path('ls')), "get_bin_path() failed to find 'ls'"
    assert os.path.exists(get_bin_path('ls', opt_dirs=['/usr/bin'])), "get_bin_path() failed to find 'ls'"
    assert os.path.exists(get_bin_path('ls', required=False)), "get_bin_path() failed to find 'ls'"
    assert os.path.exists(get_bin_path('ls', required=False, opt_dirs=['/usr/bin'])), "get_bin_path() failed to find 'ls'"

    # Test for proper exception handling

# Generated at 2022-06-24 20:49:09.170572
# Unit test for function get_bin_path
def test_get_bin_path():
    str_1 = '<\x0c2*\rp\rp[fNdHc83 '
    var_1 = get_bin_path(str_1)
    print(var_1)


# entry point
if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:49:10.603675
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert get_bin_path(arg='ls')
    except ValueError:
        assert False

# Generated at 2022-06-24 20:49:14.430082
# Unit test for function get_bin_path
def test_get_bin_path():
    # [2.12.0] Ensure get_bin_path raises no error when provided with an existing executable path as input
    assert is_executable(
        get_bin_path("/bin/mv")
    )

    # [2.12.0] Ensure get_bin_path raises no error when provided with an existing executable as input
    assert is_executable(
        get_bin_path("mv")
    )

    # [2.12.0] Ensure get_bin_path raises an error when provided with a mandatory non-existent executable as input
    try:
        get_bin_path("asdfasdfasdf")
    except ValueError:
        pass
    else:
        assert False, "get_bin_path did not raise an error when provided with a mandatory non-existent executable"

    # [2.12.0]

# Generated at 2022-06-24 20:49:16.691768
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(b'get_bin_path') == '/Users/mikas/PycharmProjects/untitled/raw_input'


# Generated at 2022-06-24 20:49:22.546002
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        raise Exception('Failed to run test case')

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:49:32.101584
# Unit test for function get_bin_path
def test_get_bin_path():
    str_1 = '<\x0c2*\rp\rp[fNdHc83 '
    try:
        var_1 = get_bin_path(str_1)
    except ValueError:
        pass
    else:
        raise Exception('Failed to raise ValueError')

    str_2 = '<\x0c2*\rp\rp[fNdHc83 '
    str_2_list = ['\x02\r\rsp`\r', '6UZ\x02\r\rsp`\r', '6UZ\x02\r\rsp`\r', '6UZ\x02\r\rsp`\r', '6UZ\x02\r\rsp`\r']

# Generated at 2022-06-24 20:49:35.847836
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path() is None)
    assert(get_bin_path() is None)
    assert(get_bin_path() is None)
    assert(get_bin_path() is None)
    assert(get_bin_path() is None)



# Generated at 2022-06-24 20:49:44.753067
# Unit test for function get_bin_path
def test_get_bin_path():

    try:
        print("\nPYTHON VERSION: ", os.sys.version)
        print("\nSTART test_get_bin_path")
        print("\nTry to handle unicode arguments")
        test_case_0()
        print("\nTest passed: No Exceptions")
    except Exception as ex:
        print("\nException: " + str(ex))
        print("\nTest failed.")

# Start of script
if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:49:54.478212
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible-playbook') == '/usr/local/bin/ansible-playbook'
    assert get_bin_path('/usr/bin/whoami') == '/usr/bin/whoami'
    try:
        get_bin_path('not_a_program')
        assert False
    except ValueError:
        pass

    # test with known paths
    try:
        get_bin_path('/usr/bin/whoami', opt_dirs=['/usr/local/bin', '/usr/bin'])
        assert False
    except ValueError:
        pass

    assert get_bin_path('/usr/bin/whoami', opt_dirs=['/usr/bin', '/usr/local/bin']) == '/usr/bin/whoami'

# Generated at 2022-06-24 20:49:57.880513
# Unit test for function get_bin_path
def test_get_bin_path():
    print("> Executing test_get_bin_path")
    # TODO: Provide test values for the parameters in the test cases.
    test_case_0()

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:50:05.674216
# Unit test for function get_bin_path
def test_get_bin_path():

    # Return value from function get_bin_path
    ret_1 = str()

    # Return value from function get_bin_path
    ret_2 = str()

    str_1 = 'Z"\x15\x14sF:Q\x10\x06\r\r\x0b\x0f'
    # Use function get_bin_path to get value
    ret_1 = get_bin_path(str_1)
    str_2 = 'f\x1dSm@c\x1e\x1e>\x0c\x13\x16\x0f\x1a\x17\x0e\x1a'
    # Use function get_bin_path to get value
    ret_2 = get_bin_path(str_2)
    return ret_1, ret_2

# Generated at 2022-06-24 20:50:07.526893
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None


# Generated at 2022-06-24 20:50:12.703495
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(os.path.exists(get_bin_path('ls')))
    try:
        str_1 = '*\x0c2*\rp\rp[fNdHc83 '
        get_bin_path(str_1)
    except ValueError:
        pass


if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:50:15.716333
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True == True
# END OF TESTS

if __name__ == "__main__":
    test_get_bin_path()
    test_case_0()

# Generated at 2022-06-24 20:50:18.835490
# Unit test for function get_bin_path
def test_get_bin_path():
  test_case_0()

# Generated at 2022-06-24 20:50:21.626680
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '"\x1bYW\x0ej\x1b\x02\x1c\x03\x11'
    var_0 = test_case_0()
    assert var_0 is None

# Generated at 2022-06-24 20:50:28.334662
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path('python2')
    assert var_0 == '/usr/bin/python2', var_0
    var_1 = get_bin_path('/usr/bin/python2')
    assert var_1 == '/usr/bin/python2', var_1
    var_2 = get_bin_path('python2', '/bin')
    assert var_2 == '/usr/bin/python2', var_2
    var_3 = get_bin_path('python2', opt_dirs=['/usr/bin'])
    assert var_3 == '/usr/bin/python2', var_3
    var_4 = get_bin_path('python2', opt_dirs=['/usr/bin', '/usr/sbin'])

# Generated at 2022-06-24 20:50:29.989249
# Unit test for function get_bin_path
def test_get_bin_path():
    pass


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:50:31.463817
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:50:37.895940
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True == is_executable(get_bin_path('ls'))
    assert True == is_executable(get_bin_path('/usr/bin/ls'))
    assert False == is_executable(get_bin_path('ls -al'))

# Generated at 2022-06-24 20:50:44.930948
# Unit test for function get_bin_path
def test_get_bin_path():

    assert test_case_0() == '<\x0c2*\rp\rp[fNdHc83 '
    assert test_get_bin_path() == '<\x0c2*\rp\rp[fNdHc83 '

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:50:54.965922
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls', "get_bin_path test 0 failed"
    assert get_bin_path('ls') == '/bin/ls', "get_bin_path test 1 failed"
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls', "get_bin_path test 2 failed"
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls', "get_bin_path test 3 failed"


if __name__ == '__main__':
    try:
        test_case_0()
    except:
        pass
    test_get_bin_path()

# Generated at 2022-06-24 20:50:56.740633
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '<\x0c2*\rp\rp[fNdHc83 '
    test_case_0()

# Generated at 2022-06-24 20:51:00.220461
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as error:
        print('Exception: %s' % error)
    else:
        print('Test completed without errors')

if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:51:06.247984
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError:
        assert True

# Generated at 2022-06-24 20:51:07.196980
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('curl') == '/usr/bin/curl'

# Generated at 2022-06-24 20:51:08.480786
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:51:13.594012
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/foo') == '/foo'
    assert get_bin_path('foo') == '/bin/foo'
    assert get_bin_path('foo', opt_dirs=['/']) == '/foo'


if __name__ == '__main__':
    print('Test case 1')
    try:
        test_get_bin_path()
    except Exception as err:
        print(err)

# Generated at 2022-06-24 20:51:23.883051
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '2*' in get_bin_path('<\x0c2*\rp\rp[fNdHc83 ')
    assert 'rp' in get_bin_path('<\x0c2*\rp\rp[fNdHc83 ')
    assert 'dHc83' in get_bin_path('<\x0c2*\rp\rp[fNdHc83 ')
    assert '[' in get_bin_path('<\x0c2*\rp\rp[fNdHc83 ')
    assert 'fN' in get_bin_path('<\x0c2*\rp\rp[fNdHc83 ')

# Generated at 2022-06-24 20:51:25.825158
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None, "Function call failed"

# Generated at 2022-06-24 20:51:27.020149
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True



# Generated at 2022-06-24 20:51:37.542584
# Unit test for function get_bin_path
def test_get_bin_path():
    # Simple test -- function should return None
    assert get_bin_path('/bin/true') is not None
    os.environ['PATH'] = os.pathsep.join(['/usr/bin', os.path.dirname(__file__)])

    # Simple test -- with test script in path
    # Regression for bug #77364
    assert get_bin_path('example_executable_in_path') is not None

    # Test with a non-existent path
    try:
        get_bin_path('/nonexistent/foo/bar')
        assert False, 'Previous command should have thrown exception'
    except ValueError:
        pass
    try:
        get_bin_path('/etc/group')
        assert False, 'Previous command should have thrown exception'
    except ValueError:
        pass

# Generated at 2022-06-24 20:51:42.901693
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '\x0eRy_7\x1c\x1bN\x0b\x07\x1f\x1e-\x1d1\x17'
    var_0 = get_bin_path(str_0)

# Generated at 2022-06-24 20:51:47.408070
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError:
        pass


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:51:56.345634
# Unit test for function get_bin_path
def test_get_bin_path():
  try:
    test_case_0()
  except Exception as err:
    print('Caught exception: ' + str(err))
    raise err

# Generated at 2022-06-24 20:51:58.539798
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path(str)
    get_bin_path(str, [])
    get_bin_path(str, [], bool)

# Generated at 2022-06-24 20:52:04.407266
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/less') == '/usr/bin/less'
    assert get_bin_path('less') == '/usr/bin/less'
    assert get_bin_path('./less') == './less'


# Generated at 2022-06-24 20:52:06.474675
# Unit test for function get_bin_path
def test_get_bin_path():
    var_1 = get_bin_path('9r\r{T\\N^z+\\o')


# Generated at 2022-06-24 20:52:15.773206
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert 1 == 1
    except AssertionError as e:
        print("AssertionError")
        raise e
    try:
        assert 1 == 2
    except AssertionError as e:
        print("AssertionError")
        raise e
    try:
        assert 1 == 1
    except AssertionError as e:
        print("AssertionError")
        raise e
    try:
        assert 1 == 1
    except AssertionError as e:
        print("AssertionError")
        raise e
    try:
        assert 1 == 1
    except AssertionError as e:
        print("AssertionError")
        raise e
    try:
        assert 1 == 1
    except AssertionError as e:
        print("AssertionError")
        raise e
   

# Generated at 2022-06-24 20:52:17.542053
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = str()
    try:
        var_0 = get_bin_path(var_0)
        assert False
    except ValueError:
        pass


# Generated at 2022-06-24 20:52:19.580052
# Unit test for function get_bin_path
def test_get_bin_path():

    # Call the function
    result = get_bin_path('/usr/bin/python')

    # Check the result
    assert result == '/usr/bin/python'

# Generated at 2022-06-24 20:52:23.814392
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = '<\x0c2*\rp\rp[fNdHc83 '
    var_0 = get_bin_path(arg_0)
    assert var_0 in ('/usr/bin/<\x0c2*\rp\rp[fNdHc83 ', '/bin/<\x0c2*\rp\rp[fNdHc83 ')
    assert is_executable(var_0)

# Generated at 2022-06-24 20:52:25.833110
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # Test cases
        test_case_0()
        res = False
        # no exception was raised
    except:
        res = True
    assert not res, 'An exception is raised'

# Generated at 2022-06-24 20:52:32.716089
# Unit test for function get_bin_path
def test_get_bin_path():
    # get_bin_path(arg, opt_dirs=None, required=None)
    assert(get_bin_path("/bin/sh") == "/bin/sh")

    # required=False
    try:
        get_bin_path("/bin/foobar", required=False)
    except ValueError:
        assert(False)
    else:
        assert(True)

    # required=True
    try:
        get_bin_path("/bin/foobar")
    except ValueError:
        assert(True)
    else:
        assert(False)

    # opt_dirs
    try:
        get_bin_path("/bin/foobar", opt_dirs=["/bin"])
    except ValueError:
        assert(True)
    else:
        assert(False)

# Generated at 2022-06-24 20:52:46.728779
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '<\x0c2*\rp\rp[fNdHc83 '
    get_bin_path(str_0)
    str_0 = '\x188\r\r\r\r\r\r\r\r%'
    get_bin_path(str_0)
    str_0 = 'https://github.com/ansible/ansible/issues/103417'
    get_bin_path(str_0)
    str_0 = 'https://github.com/ansible/ansible/issues/103417'
    get_bin_path(str_0)
    str_0 = 'https://github.com/ansible/ansible/issues/103417'
    get_bin_path(str_0)

# Generated at 2022-06-24 20:52:49.501948
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception as e:
        assert False, "Unable to run test case: " + str(e)

test_get_bin_path()

# Generated at 2022-06-24 20:52:51.912005
# Unit test for function get_bin_path
def test_get_bin_path():
    # str_0 = '<\x0c2*\rp\rp[fNdHc83 '
    # var_0 = get_bin_path(str_0)
    assert False



# Generated at 2022-06-24 20:52:55.887975
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as e:
        if "Failed to find required executable" in str(e):
            raise AssertionError(str(e))


# This should be run from the root directory of the ansible-test package
if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:52:57.296362
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated from:
# isort:skip_file
# flake8: noqa

# Generated at 2022-06-24 20:53:00.803989
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '<\x0c2*\rp\rp[fNdHc83 '
    var_0 = get_bin_path(str_0)
    assert var_0 is not None


# Generated at 2022-06-24 20:53:03.038084
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('')



# Generated at 2022-06-24 20:53:04.912218
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '<\x0c2*\rp\rp[fNdHc83 '
    var_0 = get_bin_path(str_0)

    assert var_0 == '/bin/sh'



# Generated at 2022-06-24 20:53:08.869517
# Unit test for function get_bin_path
def test_get_bin_path():
    p = get_bin_path('sh')
    assert p.endswith('/sh'), "get_bin_path failed to find the path to the 'sh' executable"


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:53:12.757637
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'kKHM6'
    var_0 = get_bin_path(str_0, ['/my/path1', '/my/path2'], False)

# vim: sts=4 ts=4 sw=4 et ft=python

# Generated at 2022-06-24 20:53:23.655264
# Unit test for function get_bin_path
def test_get_bin_path():
    print('Unit test for function get_bin_path')
    test_case_0()

# Compiled with version: 2.6.9
# Decompiled with version: 2.7.11

# Generated at 2022-06-24 20:53:28.952326
# Unit test for function get_bin_path
def test_get_bin_path():
    assert str_0 == '<\x0c2*\rp\rp[fNdHc83 '

# Generated at 2022-06-24 20:53:29.633697
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()



# Generated at 2022-06-24 20:53:32.160054
# Unit test for function get_bin_path
def test_get_bin_path():
    #str_0 = '\x1c\xc1\x0f>\tP\n\x04\x0c\x14\x1c'
    # a = get_bin_path(str_0)
    # assert True == a
    assert True

# Generated at 2022-06-24 20:53:34.270633
# Unit test for function get_bin_path
def test_get_bin_path():
    # 17
    test_case_0()

# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-24 20:53:35.210582
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 'dirname' == get_bin_path('dirname')



# Generated at 2022-06-24 20:53:45.482134
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'o\x1f\x15\x14\n\x17\x16\x1c\x0f\x16\x1c\nF\x10\x1e\x19\x11\x12>\x06\x0f\x16\x1c\x1a\x1e\x1e\x0b\x15'
    var_0 = get_bin_path(str_0)
    str_1 = '\x16\x1c\x0fF\x10\x1e\x19\x11\x0b\x17\x1c\n\x0f\x15\x1a\x12\x0b\x15'
    var_1 = get_bin_path(str_1)

# Generated at 2022-06-24 20:53:50.128355
# Unit test for function get_bin_path
def test_get_bin_path():
    var_2 = get_bin_path('oc')
    var_3 = get_bin_path('oc', required=True)
    var_4 = get_bin_path('oc', opt_dirs=None)
    var_5 = get_bin_path('oc', opt_dirs=None, required=True)
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:53:52.389888
# Unit test for function get_bin_path
def test_get_bin_path():
    # assert get_bin_path() == ''
    # assert get_bin_path() == ''
    assert True

# test_get_bin_path()

# Generated at 2022-06-24 20:53:53.877654
# Unit test for function get_bin_path
def test_get_bin_path():
    with pytest.raises(ValueError):
        get_bin_path(arg='')


# Generated at 2022-06-24 20:54:04.601702
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path('/usr/bin/python')
    assert var_0 == 'echo python'


# Generated at 2022-06-24 20:54:06.356571
# Unit test for function get_bin_path
def test_get_bin_path():
    rc = test_case_0()
    assert rc == 0


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:54:08.343688
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '<\x0c2*\rp\rp[fNdHc83 '
    var_0 = get_bin_path(str_0)

# Generated at 2022-06-24 20:54:16.884010
# Unit test for function get_bin_path
def test_get_bin_path():
    # If a valid executable is passed in, the function should return the full path to that executable
    assert get_bin_path('echo') == '/bin/echo'

    # If the provided executable is not a file, the function should raise a ValueError
    try:
        get_bin_path('foobar')
    except ValueError:
        assert True
    else:
        assert False

    # If the provided executable is not executable, the function should raise a ValueError
    try:
        get_bin_path('/etc/hosts')
    except ValueError:
        assert True
    else:
        assert False

    # If the provided executable exists in both /usr/bin and /bin, the one in /bin should be returned
    assert get_bin_path('sh') == '/bin/sh'

    # If the executable is not in the path, the

# Generated at 2022-06-24 20:54:23.376185
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'wvm(s\x0cv*\rp\rp[fNdHc83 '
    str_1 = 'c%ywM\x0cN^1\rp\rp[fNdHc83 '
    str_2 = 'wvm(s\x0cv*\rp\rp[fNdHc83 '
    str_3 = '\x0cwvm(s\x0c+\x0cN^1\rp\rp[fNdHc83 '
    str_4 = '\x0cwvm(s\x0c+\x0cN^1\rp\rp[fNdHc83 '

# Generated at 2022-06-24 20:54:25.818996
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception as err:
        print(err)

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:54:28.448193
# Unit test for function get_bin_path
def test_get_bin_path():
    # Step #0
    test_case_0()


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:54:35.409628
# Unit test for function get_bin_path
def test_get_bin_path():
    # Verify no exception is raised with required param set to False
    try:
        str_0 = '\x12(0\x10<1\x13#\x01\x0c'
        assert get_bin_path(str_0, [], False)
    except Exception:
        # Ignore failure
        pass

    var_0 = get_bin_path('\x06\x06\x06\x06\x06\x06')



# Generated at 2022-06-24 20:54:45.103723
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:54:52.742633
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = '<\x0c2*\rp\rp[fNdHc83 '
    opt_dirs_0 = None
    required_0 = None
    var_0 = get_bin_path(arg_0, opt_dirs=opt_dirs_0, required=required_0)
    assert not var_0
    assert var_0 == '<\x0c2*\rp\rp[fNdHc83 '

# Generated at 2022-06-24 20:55:09.863637
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/tmp/ee8FFxW.tmp') == '/tmp/ee8FFxW.tmp'
    assert get_bin_path('/tmp/ee8FFxW.tmp', ['/tmp', '/usr/bin']) == '/tmp/ee8FFxW.tmp'
    assert get_bin_path('/tmp/ee8FFxW.tmp', required=True) == '/tmp/ee8FFxW.tmp'
    assert get_bin_path('/tmp/ee8FFxW.tmp', ['/tmp', '/usr/bin'], required=True) == '/tmp/ee8FFxW.tmp'

# Generated at 2022-06-24 20:55:12.053493
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '<\x0c2*\rp\rp[fNdHc83 '
    var_0 = get_bin_path(str_0)


# Generated at 2022-06-24 20:55:21.780433
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'hc_Mfv0~6?G1\u0018*h;9@J}qb+0e\u0000\u0000\u0000'
    var_0 = get_bin_path(str_0)
    str_1 = '\u0015nw\u007f\u0004(\u0012$M`#\u0012Gd\u000e\u0015\u0017e'
    var_1 = get_bin_path(str_1)
    str_2 = '\u0018w\u0018\u0003oL\u001a\u007fFu\u0007\u0005\u0014z\u001b\x0bpO\u0001'
    var_2 = get_bin_path(str_2)
   

# Generated at 2022-06-24 20:55:26.053609
# Unit test for function get_bin_path
def test_get_bin_path():
    cur_dir = os.path.dirname(os.path.realpath(__file__))
    test_case_0()
    assert get_bin_path('sh', opt_dirs=[cur_dir]) == os.path.join(cur_dir, 'sh')
    assert get_bin_path('sh', opt_dirs=['/dev/null']) == '/bin/sh'

# Generated at 2022-06-24 20:55:34.575433
# Unit test for function get_bin_path
def test_get_bin_path():
    if os.uname()[0] == 'SunOS':
        os.environ['PATH'] = '/usr/bin:/usr/sbin'
        assert get_bin_path('cat') == '/usr/bin/cat'

    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('which') == '/usr/bin/which'
    assert get_bin_path('which', opt_dirs=['/bin']) == '/bin/which'
    assert get_bin_path('which', opt_dirs=['/bin', '/usr/bin']) == '/usr/bin/which'
    assert get_bin_path('which', opt_dirs=['/bin', '/usr/bin']) == '/usr/bin/which'

# Generated at 2022-06-24 20:55:37.694532
# Unit test for function get_bin_path
def test_get_bin_path():
    func_0 = get_bin_path('', '', '')
    assert func_0 == None

# Generated at 2022-06-24 20:55:40.857244
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


# Unit tests for function get_bin_path

# Generated at 2022-06-24 20:55:45.768942
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
        print('TestCase 0 Passed!')
    except ValueError as e:
        print('TestCase 0 Failed!')
    else:
        print('TestCase 0 Error!')

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:55:50.885526
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = '/h7nHOl6'
    var_1 = str('\x7f\rA\x7f\rY')
    var_2 = [var_0, var_1]
    dirs = {var_0: 'h7nHOl6', var_1: '0rA7f0rY'}
    var_0 = get_bin_path(str('\x7f\rA\x7f\rY'), dirs)



# Generated at 2022-06-24 20:55:59.401058
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '<\x0c2*\rp\rp[fNdHc83 '
    var_0 = get_bin_path(str_0)
    str_1 = 'GF\x1c\x1f\x1e;\x05\x0f\x1f\x1bpO\x1fT\x02m\x02\x184s\x03\x1e'
    var_1 = get_bin_path(str_1)