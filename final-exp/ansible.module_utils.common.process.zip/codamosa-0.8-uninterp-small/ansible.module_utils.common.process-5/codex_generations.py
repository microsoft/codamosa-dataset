

# Generated at 2022-06-24 20:46:00.633912
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception as e:
        print('Caught exception: ', e)


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:46:05.518990
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as err:
        if err.args[0] != 'Failed to find required executable "-1720" in paths: /sbin:/usr/sbin:/usr/local/sbin':
            raise err
    else:
        raise ValueError('Failed to raise exception')



# Generated at 2022-06-24 20:46:07.432869
# Unit test for function get_bin_path
def test_get_bin_path():
    int_0 = get_bin_path('/sbin')
    print(type(int_0))
    assert type(int_0) == str


# Generated at 2022-06-24 20:46:08.375677
# Unit test for function get_bin_path
def test_get_bin_path():
    with pytest.raises(ValueError):
        test_case_0()

# Generated at 2022-06-24 20:46:09.502561
# Unit test for function get_bin_path
def test_get_bin_path():
    # test case 0
    test_case_0()

# Generated at 2022-06-24 20:46:10.411425
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True == True


# Generated at 2022-06-24 20:46:14.760657
# Unit test for function get_bin_path
def test_get_bin_path():
    test_cases = list()
    test_cases.append(test_case_0)

    for test_case in test_cases:
        try:
            test_case()
        except Exception as e:
            print("Exception caught in test case!")
            print(str(e))


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:46:19.703210
# Unit test for function get_bin_path
def test_get_bin_path():

    # test case 0
    try:
        test_case_0()
    except Exception as e:
        assert(str(e) == 'Failed to find required executable "-1720" in paths: /sbin:/usr/sbin:/usr/local/sbin:/usr/bin:/usr/local/bin:/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/sbin:/usr/bin:/opt/bin')




# Generated at 2022-06-24 20:46:22.111571
# Unit test for function get_bin_path
def test_get_bin_path():
    int_0 = -1720
    var_0 = get_bin_path(int_0)
    int_1 = 12
    int_2 = 15
    var_1 = get_bin_path(int_1, int_2)

# Generated at 2022-06-24 20:46:28.959625
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with required=False argument.
    assert get_bin_path("/bin/true", required=False) == None

    # Test with required=True argument (deprecated in 2.10, removed in 2.14).
    try:
        get_bin_path("/bin/true", required=True)
    except Exception as err:
        assert str(err) == 'Failed to find required executable "/bin/true" in paths: /sbin:/usr/sbin:/usr/local/sbin'
    else:
        assert False

    # Test with required argument absent (deprecated in 2.10, removed in 2.14).

# Generated at 2022-06-24 20:46:34.729438
# Unit test for function get_bin_path
def test_get_bin_path():
    int_0 = -1720
    var_0 = get_bin_path(int_0)
    assert var_0 == '/usr/bin/gettext.sh', 'Return value of get_bin_path is incorrect'


# Generated at 2022-06-24 20:46:38.414007
# Unit test for function get_bin_path
def test_get_bin_path():
    int_0 = -1720
    var_0 = get_bin_path(int_0)

    int_1 = var_0
    test_case_0()

test_get_bin_path()

# Generated at 2022-06-24 20:46:40.305245
# Unit test for function get_bin_path
def test_get_bin_path():
    int_0 = -1720
    var_0 = get_bin_path(int_0)
    assert var_0 == '/usr/bin/red'



# Generated at 2022-06-24 20:46:47.758823
# Unit test for function get_bin_path
def test_get_bin_path():
    # assert [ get_bin_path(int_0,opt_dirs=opt_dirs_0,required=required_0) for int_0 in int_values_0 ] == expected_0
    assert [ get_bin_path(int_0) for int_0 in int_values_0 ] == expected_0

expected_0 = [ -1720,]

# Test case for get_bin_path
int_values_0 = [
    -1720,
]


# Generated at 2022-06-24 20:46:48.544969
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None

# Generated at 2022-06-24 20:46:49.935549
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("") is None


# Generated at 2022-06-24 20:46:54.848540
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(0) == '0'

    if __name__ == "__main__":
        test_case_0()

# Generated at 2022-06-24 20:46:55.772203
# Unit test for function get_bin_path
def test_get_bin_path():
    assert False, "No test for function get_bin_path"


# Generated at 2022-06-24 20:47:03.461992
# Unit test for function get_bin_path
def test_get_bin_path():
    with pytest.raises(ValueError):
        get_bin_path(None)
    with pytest.raises(ValueError):
        get_bin_path(None)
    with pytest.raises(ValueError):
        get_bin_path(None)
    with pytest.raises(ValueError):
        get_bin_path(None)
    with pytest.raises(ValueError):
        get_bin_path(None)
    with pytest.raises(ValueError):
        get_bin_path(None)
    with pytest.raises(ValueError):
        get_bin_path(None)
    with pytest.raises(ValueError):
        get_bin_path(None)

# Generated at 2022-06-24 20:47:07.308781
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('uname')
    assert (bin_path is not None)
    try:
        # This function should raise ValueError with this non-existent command
        get_bin_path('abc123')
    except ValueError:
        # That's what we expect to see
        pass
    else:
        # Otherwise, we fail
        assert False

# Generated at 2022-06-24 20:47:11.569946
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ruby') != None

# Generated at 2022-06-24 20:47:15.112731
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:47:18.462335
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = None
    opt_dirs_0 = None
    required_0 = None
    assert get_bin_path(arg_0, opt_dirs_0, required_0)

# Test case 1
test_case_0()

# Generated at 2022-06-24 20:47:27.333531
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(get_bin_path) == get_bin_path
    assert get_bin_path(get_bin_path, opt_dirs=None) == get_bin_path
    assert get_bin_path(get_bin_path, opt_dirs=None, required=False) == get_bin_path
    assert get_bin_path(get_bin_path, opt_dirs=None, required=None) == get_bin_path
    assert get_bin_path('is_executable') == is_executable
    assert get_bin_path('is_executable', opt_dirs=None) == is_executable
    assert get_bin_path('is_executable', opt_dirs=None, required=False) == is_executable

# Generated at 2022-06-24 20:47:33.549243
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test Cases for function get_bin_path
    test_case_0()


# main function entry point
if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:47:38.502979
# Unit test for function get_bin_path
def test_get_bin_path():
    func = get_bin_path
    arg_0 = arg_1 = arg_2 = 0
    result = func(arg_0, arg_1, arg_2)
    assert result is None, "get_bin_path() == '%s', expected: %s" % (result, None)

# Generated at 2022-06-24 20:47:46.722315
# Unit test for function get_bin_path
def test_get_bin_path():
    # The module_utils/common/file.py uses the get_bin_path function, so here we test the file module.
    # Get the module_utils/common/file.py and import the file module.
    module_path = os.path.join(os.path.dirname(__file__), '../../../lib/ansible/module_utils/common/file.py')
    file_module = imp.load_source('file', module_path)
    # Assert that file is executable.
    assert file_module.is_executable(__file__)
    # Assert that file is executable.
    assert file_module.is_executable('/etc')
    # Assert that file is executable.
    assert file_module.is_executable('/etc/passwd')
    # Assert that file is not executable.

# Generated at 2022-06-24 20:47:48.606916
# Unit test for function get_bin_path
def test_get_bin_path():
    assert False, 'Test case not implemented'



# Generated at 2022-06-24 20:47:50.336987
# Unit test for function get_bin_path
def test_get_bin_path():
    assert False, "No tests for function get_bin_path"

# Generated at 2022-06-24 20:47:59.967817
# Unit test for function get_bin_path
def test_get_bin_path():
    ansible_0 = { 
        'shell_type': 'csh', 
        'password': 'NotARealPassword', 
        'host': 'localhost', 
        'executable': '/usr/bin/ssh', 
        'become_method': 'sudo', 
        'user': 'root'
    }
    ansible_1 = { 
        'password': 'NotARealPassword', 
        'host': 'localhost', 
        'executable': '/usr/bin/ssh', 
        'become_method': 'sudo', 
        'user': 'root'
    }

    # Testing with partial arguments
    test_case_0()

    # Testing with full arguments

# Generated at 2022-06-24 20:48:04.544494
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


test_get_bin_path()

# Generated at 2022-06-24 20:48:11.593045
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.file import get_bin_path

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught by the test case"""
        pass

    def exit_json(*args, **kwargs):  # pylint: disable=unused-argument
        """function to patch over exit_json; package return data into an exception"""
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise Ans

# Generated at 2022-06-24 20:48:19.248430
# Unit test for function get_bin_path
def test_get_bin_path():
    int_0 = get_bin_path("uptime", ["/bin/", "/usr/bin/"])
    assert int_0 == "/usr/bin/uptime"
    int_1 = get_bin_path("uptime")
    assert int_1 == "/usr/bin/uptime"
    int_2 = get_bin_path(None)
    assert int_2 == "/usr/bin/uptime"


# Generated at 2022-06-24 20:48:25.611570
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path_0 = get_bin_path(int(-1720), [], None)
    assert bin_path_0 == '/usr/sbin/netstat', "bin_path_0 should be '/usr/sbin/netstat' but is: %r" % bin_path_0

# Generated at 2022-06-24 20:48:37.477582
# Unit test for function get_bin_path
def test_get_bin_path():
    # Called from library in the path
    get_bin_path('false')

    # Not in the path, but in the same directory as the library
    get_bin_path('aws.py')

    # Not in the path or the library directory
    get_bin_path('/bin/true')

    # Test a relative path to the library
    get_bin_path('bin/ls')

    # Test the optional paths argument
    get_bin_path('ls', opt_dirs=['/bin'])

    # Test the optional required argument
    try:
        get_bin_path('ls', opt_dirs=['/bin'], required=False)
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "ls" in paths: /bin'
    else:
        assert False

    #

# Generated at 2022-06-24 20:48:38.680370
# Unit test for function get_bin_path
def test_get_bin_path():
    assert('None' not in str(test_case_0()))

# Generated at 2022-06-24 20:48:40.444017
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = '/usr/sbin/arp'
    executable = '/usr/sbin'
    assert get_bin_path(bin_path) == executable

# Generated at 2022-06-24 20:48:44.460487
# Unit test for function get_bin_path
def test_get_bin_path():
    # AssertionError: Failed to find required executable "뻵" in paths: ...
    pass
#     int_0 = -1720
#     var_0 = get_bin_path(int_0)



# Generated at 2022-06-24 20:48:48.620426
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:48:51.287377
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:48:57.424399
# Unit test for function get_bin_path
def test_get_bin_path():
    tests = [{
            "arg": -1720,
            "opt_dirs": None,
            "required": None,
        }, {
            "arg": -1720,
            "opt_dirs": None,
            "required": None,
        },
    ]
    for test in tests:
        get_bin_path(test["arg"], test["opt_dirs"], test["required"])



# Generated at 2022-06-24 20:48:58.930590
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:49:01.324387
# Unit test for function get_bin_path
def test_get_bin_path():
    expected_output = None
    int_0 = test_case_0()
    assert(expected_output == int_0)

test_get_bin_path()



# Generated at 2022-06-24 20:49:07.956672
# Unit test for function get_bin_path
def test_get_bin_path():
    int_0 = -2088
    int_1 = -1424
    int_2 = -1424
    bool_0 = False
    var_0 = get_bin_path(int_0, int_1, int_2, bool_0)

if __name__ == '__main__':
    print(get_bin_path('/usr/bin/'))

# Generated at 2022-06-24 20:49:12.527626
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = False
    if not var_0:
        raise Exception('Test failed')


# Generated at 2022-06-24 20:49:17.708663
# Unit test for function get_bin_path
def test_get_bin_path():
    # Execute module
    script_dir = os.path.dirname(os.path.realpath(__file__))
    common_utils_path = os.path.join(script_dir, '..', '..', '..', 'lib', 'ansible', 'module_utils', 'common')

    os.environ['PATH'] = common_utils_path + os.pathsep + os.environ['PATH']
    test_case_0()

# Generated at 2022-06-24 20:49:19.398631
# Unit test for function get_bin_path
def test_get_bin_path():
    assert not get_bin_path()



# Generated at 2022-06-24 20:49:21.310097
# Unit test for function get_bin_path
def test_get_bin_path():
    # TODO: Implement test_get_bin_path
    assert True
    test_case_0()
    pass

# Generated at 2022-06-24 20:49:27.594118
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path("sh", None, None) is not None)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 20:49:37.989243
# Unit test for function get_bin_path
def test_get_bin_path():
    path = os.getcwd()
    # With extra argument opt_dirs 
    # with path as parameter
    assert get_bin_path('ansible', [path]) == path + os.sep + 'ansible'
    # with path and shell as parameter
    assert get_bin_path('sh', [path]) == '/bin/sh'
    assert get_bin_path('sh', [path], required=True) == '/bin/sh'
    # with invalid path
    try:
        get_bin_path('asdf', [path])
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
        assert path in str(e) # Path has to be in the string
    # Without opt_dirs - should use PATH

# Generated at 2022-06-24 20:49:46.307148
# Unit test for function get_bin_path
def test_get_bin_path():
    with pytest.raises(ValueError):
        get_bin_path()



# Generated at 2022-06-24 20:49:48.335760
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('a') == 0
    assert get_bin_path('a', required=None) == 0


# Generated at 2022-06-24 20:49:50.178649
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path("/bin/cat")
    assert path == "/bin/cat"

# Generated at 2022-06-24 20:49:50.745573
# Unit test for function get_bin_path
def test_get_bin_path():
    pass



# Generated at 2022-06-24 20:49:59.226583
# Unit test for function get_bin_path
def test_get_bin_path():
    # Check that get_bin_path raises ValueError for invalid executable.
    try:
        get_bin_path('__invalid__')
    except ValueError:
        pass
    else:
        raise Exception('Failed to raise expected exception.')

    # Check that get_bin_path raises ValueError for invalid executable in optional directory.
    try:
        get_bin_path('__invalid__', opt_dirs=[os.path.dirname(__file__)])
    except ValueError:
        pass
    else:
        raise Exception('Failed to raise expected exception.')

    # Check that get_bin_path returns correct path for valid executable.
    assert get_bin_path('cat') == '/bin/cat'

    # Check that get_bin_path returns correct path for valid executable in optional directory.
    assert get_bin

# Generated at 2022-06-24 20:50:00.692079
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 'NOSUCHEXEC' in get_bin_path('NOSUCHEXEC')

# Generated at 2022-06-24 20:50:01.519591
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path


# Generated at 2022-06-24 20:50:07.813655
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = -1720
    sbin_paths = ['/sbin', '/usr/sbin', '/usr/local/sbin']
    paths = []
    for d in []:
        if d is not None and os.path.exists(d):
            paths.append(d)
    paths += os.environ.get('PATH', '').split(os.pathsep)
    bin_path = None
    # mangle PATH to include /sbin dirs
    for p in sbin_paths:
        if p not in paths and os.path.exists(p):
            paths.append(p)
    for d in paths:
        if not d:
            continue
        path = os.path.join(d, arg)

# Generated at 2022-06-24 20:50:11.915872
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = -1720
    var_1 = ['/sbin', '/usr/sbin', '/usr/local/sbin']
    var_2 = -1846
    var_3 = get_bin_path(var_0, var_1, var_2)
    return var_3

# Generated at 2022-06-24 20:50:13.121710
# Unit test for function get_bin_path
def test_get_bin_path():
    with pytest.raises(ValueError):
        test_case_0()

# Generated at 2022-06-24 20:50:22.021773
# Unit test for function get_bin_path
def test_get_bin_path():
    int_0 = -1720
    var_0 = get_bin_path(int_0)
    assert var_0 == '/bin/sleep'



# Generated at 2022-06-24 20:50:23.313436
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:50:26.109291
# Unit test for function get_bin_path
def test_get_bin_path():
    temp_0 = -3446
    temp_1 = [temp_0]
    temp_2 = None
    temp_3 = get_bin_path(temp_0, temp_1, temp_2)

# Generated at 2022-06-24 20:50:29.200073
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == 0

# Generated at 2022-06-24 20:50:32.138005
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python3', opt_dirs=['/bin', '/sbin', '/usr/sbin', '/usr/local/sbin'], required=False) == "/usr/bin/python3"

# Testing get_bin_path with valid argument

# Generated at 2022-06-24 20:50:35.883861
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/echo') == '/bin/echo'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', ['/bin', '/usr/bin']) == '/bin/ls'
    try:
        get_bin_path('foobar')
        assert False
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-24 20:50:37.125313
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = test_case_0()

# Generated at 2022-06-24 20:50:40.318364
# Unit test for function get_bin_path
def test_get_bin_path():
    test_cases = [0,]
    for case in test_cases:
        print(f"Running test for case: {case}")
        globals()[f"test_case_{case}"]()

# Generated at 2022-06-24 20:50:46.907047
# Unit test for function get_bin_path
def test_get_bin_path():
    var_1 = 'TEST_VAR_1'
    os.environ['PATH'] = var_1
    assert os.environ['PATH'] == var_1
    try:
        var_2 = get_bin_path('test')
    except ValueError:
        pass
    else:
        assert False

    try:
        var_3 = get_bin_path('/bin/test')
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-24 20:50:51.726981
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception as exception:
        if exception.args[0] != 'Failed to find required executable "-1720" in paths: /sbin:/usr/sbin:/usr/local/sbin:/usr/local/bin:/user/bin:':
            raise exception
    else:
        raise AssertionError('Unreachable statement')

# Generated at 2022-06-24 20:51:03.602350
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception as err:
        print("Test failed: {}".format(err))
        assert(False)
    else:
        print("Test passed")
        assert(True)

# Generated at 2022-06-24 20:51:13.022341
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with required set to None
    int_0 = -179
    new_arg_0 = get_bin_path(int_0)

    # Test with required set to True
    int_1 = -1740
    opt_dirs_0 = ['/usr/bin', '/usr/bin', '/bin', '/usr/bin']
    new_arg_1 = get_bin_path(int_1, opt_dirs_0, required=True)

    # Test with required set to False
    int_2 = -1597
    opt_dirs_1 = ['/usr/bin', '/bin', None, '/usr/bin']
    new_arg_2 = get_bin_path(int_2, opt_dirs_1, required=False)

    # Test with opt_dirs set to None

# Generated at 2022-06-24 20:51:19.142486
# Unit test for function get_bin_path
def test_get_bin_path():

    test_cases = [
        {
            "int_0": -1720,
        },
        {
            "int_0": 1180,
        },
        {
            "int_0": -1160,
        },
        {
            "int_0": 1580,
        },
        {
            "int_0": -1180,
        },
        {
            "int_0": 1080,
        },
        {
            "int_0": -1400,
        },
    ]

    for test_case in test_cases:
        int_0 = test_case.get('int_0')
        var_0 = get_bin_path(int_0)


# Generated at 2022-06-24 20:51:30.413304
# Unit test for function get_bin_path
def test_get_bin_path():

    # Mock for the exception ValueError
    class ValueErrorMock(object):
        @staticmethod
        def __new__(*args, **kwargs):
            return ValueError

    # Mock for the exception TypeError
    class TypeErrorMock(object):
        @staticmethod
        def __new__(*args, **kwargs):
            return TypeError

    mock_module = type('module', (), {'_stderr': mock.MagicMock()})()
    mock_module._stderr.side_effect = [ValueErrorMock, TypeErrorMock]

    # Constructing mock objects
    mock_arg = mock.MagicMock()
    mock_opt_dirs = mock.MagicMock()
    mock_required = mock.MagicMock()

# Generated at 2022-06-24 20:51:36.273866
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = -1720
    paths = []
    result = get_bin_path(arg, paths)
    assert result is None

# Test for:
#   - get_bin_path(arg, opt_dirs, required)
#   - get_bin_path(arg, required)
#   - get_bin_path(arg, opt_dirs)
#   - get_bin_path(arg)

# Generated at 2022-06-24 20:51:46.144120
# Unit test for function get_bin_path
def test_get_bin_path():
    int_0 = 434
    var_0 = get_bin_path(int_0)
    assert var_0 == '434'
    int_0 = -1720
    var_0 = get_bin_path(int_0)
    assert var_0 == '-1720'
    int_0 = 804
    var_0 = get_bin_path(int_0)
    assert var_0 == '804'
    int_0 = -1720
    var_0 = get_bin_path(int_0)
    assert var_0 == '-1720'
    int_0 = -27
    var_0 = get_bin_path(int_0)
    assert var_0 == '-27'
    int_0 = 804

# Generated at 2022-06-24 20:51:48.103678
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:51:54.933917
# Unit test for function get_bin_path
def test_get_bin_path():
    # get_bin_path() raises ValueError when there are no args
    with pytest.raises(TypeError):
        get_bin_path()

    # get_bin_path() raises ValueError when there are too many args
    with pytest.raises(TypeError):
        get_bin_path(None, None, None, None)

    # get_bin_path() raises ValueError when multiple args are provided
    with pytest.raises(TypeError):
        get_bin_path(None, None, None)

    # get_bin_path() raises ValueError when inputs are invalid
    with pytest.raises(ValueError):
        get_bin_path("/bin/sh", "/bin/bash", "/bin")

    # get_bin_path() raises ValueError when executable not found

# Generated at 2022-06-24 20:52:04.164698
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(1) == '/usr/bin/yum'
    assert get_bin_path('/usr/bin') == '/usr/bin'
    assert get_bin_path(2) == '/usr/sbin/acpi'
    assert get_bin_path(3, opt_dirs=['/bin']) == '/bin/echo'
    assert get_bin_path(4, ['usr']) == '/usr/bin/nmap'
    assert get_bin_path(5, [4]) == '/usr/bin/nmap'
    assert get_bin_path(6, opt_dirs=['/tmp']) == '/bin/busctl'
    assert get_bin_path(7) == '/bin/wget'

# Generated at 2022-06-24 20:52:08.832679
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()
    test_file_path = os.path.join(os.path.dirname(__file__), 'support/get_bin_path')
    expected = os.path.join(os.getcwd(), test_file_path)
    assert get_bin_path('get_bin_path') == expected

# Generated at 2022-06-24 20:52:32.012900
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path('builtins')
    assert 'builtins' in var_0
    var_1 = get_bin_path('builtins')
    assert 'builtins' in var_1
    var_2 = get_bin_path('builtins')
    assert 'builtins' in var_2
    var_3 = get_bin_path('builtins')
    assert 'builtins' in var_3
    var_4 = get_bin_path('builtins')
    assert 'builtins' in var_4
    var_5 = get_bin_path('builtins')
    assert 'builtins' in var_5
    var_6 = get_bin_path('builtins')
    assert 'builtins' in var_6
    var_7 = get_bin_path('builtins')

# Generated at 2022-06-24 20:52:33.188508
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


# Generated at 2022-06-24 20:52:36.400196
# Unit test for function get_bin_path
def test_get_bin_path():
    var_1 = -1245
    var_2 = -124
    var_3 = get_bin_path(var_1, var_2)

# Generated at 2022-06-24 20:52:38.125813
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = -1720
    assert get_bin_path(arg_0)


# Generated at 2022-06-24 20:52:39.845314
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True
    # TODO: add more test cases


# vim: ft=python:

# Generated at 2022-06-24 20:52:48.989008
# Unit test for function get_bin_path
def test_get_bin_path():
    # Create mock Environment Variables
    os.environ['PATH'] = '%s:/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin' % os.environ.get('PATH', '')

    (result, expected, expected_msg) = (None, None, None)
    this_dir = os.path.dirname(__file__)
    # Create tests
    tests = [
        # Each test is a 4-tuple
        # Description of test, expected return value, call, and exception message on failure.
        ('Expected Failure - Bad Arg', None,
         lambda: test_case_0(),
         "Failed to find required executable",),
    ]


# Generated at 2022-06-24 20:52:49.965993
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(test_case_0() is None)

# Generated at 2022-06-24 20:52:55.112816
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert test_case_0() == None
    except Exception as err:
        print(err)
        assert False

test_get_bin_path()

# Generated at 2022-06-24 20:52:58.239910
# Unit test for function get_bin_path
def test_get_bin_path():
    int_0 = -1720
    opt_dirs_0 = []
    required_0 = True
    var_1 = get_bin_path(int_0, opt_dirs_0, required_0)
    assert var_1 == '{0}'.format('')

# Generated at 2022-06-24 20:52:59.631896
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# vim: syntax=python

# Generated at 2022-06-24 20:53:38.814819
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/cp') == '/bin/cp'
    assert get_bin_path('cp') == '/bin/cp'

    assert get_bin_path('/bin/nocommand') == '/bin/nocommand'
    assert get_bin_path('nocommand') == '/bin/nocommand'

# Generated at 2022-06-24 20:53:39.417439
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path() == None

# Generated at 2022-06-24 20:53:40.423828
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:53:42.497050
# Unit test for function get_bin_path
def test_get_bin_path():
    assert not os.path.join(get_bin_path.__code__.co_name, get_bin_path.__code__.co_filename)

# Generated at 2022-06-24 20:53:47.374003
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = 10
    opt_dirs = "10"
    required = "empty"
    try:
        get_bin_path(arg, opt_dirs, required)
    except ValueError as e:
        print(e)
           
if __name__ == '__main__':
    test_get_bin_path()
    test_case_0()

# Generated at 2022-06-24 20:53:57.088101
# Unit test for function get_bin_path
def test_get_bin_path():
    int_0 = -407
    var_0 = get_bin_path(int_0)
    assert var_0 == '/usr/local/sbin/ping', 'Unexpected value returned'
    int_0 = -33
    var_0 = get_bin_path(int_0, ['/usr/local/sbin'])
    assert var_0 == '/usr/local/sbin/ping6', 'Unexpected value returned'
    int_0 = -1720
    var_0 = get_bin_path(int_0)
    assert var_0 == '/usr/local/sbin/ping', 'Unexpected value returned'
    int_0 = -704
    var_0 = get_bin_path(int_0)
    assert var_0 == '/bin/ping', 'Unexpected value returned'


# Generated at 2022-06-24 20:54:03.000131
# Unit test for function get_bin_path
def test_get_bin_path():
    # set up test parameters
    int_0 = -1720

    # execute the test
    try:
        var_0 = get_bin_path(int_0)
    except Exception as e:
       print("Exception thrown in unit test")
       print("Unit test failed")
       return(1)

    print("Unit test passed")
    return(0)


if __name__=="__main__":
    test_case_0()
    rc = test_get_bin_path()
    exit(rc)

# Generated at 2022-06-24 20:54:06.092710
# Unit test for function get_bin_path
def test_get_bin_path():
    # Call function get_bin_path with arguments:
    # self.get_bin_path(arg0, required=None)
    assert test_case_0() == None


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:54:09.168674
# Unit test for function get_bin_path
def test_get_bin_path():
    func = get_bin_path("arg", ["opt_dirs"], "required")
    assert func == "arg:opt_dirs:required"

    func = get_bin_path("arg")
    assert func == "arg:None:None"

    func = get_bin_path("arg", opt_dirs='p')
    assert func == "arg:p:None"

# Generated at 2022-06-24 20:54:13.603164
# Unit test for function get_bin_path
def test_get_bin_path():
    args = [
        {'arg': '',
         'opt_dirs': [],
         'required': None},
    ]
    for arg in args:
        try:
            get_bin_path(**arg)
        except Exception as exc:
            assert False, str(exc)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:55:26.642873
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True


# Generated at 2022-06-24 20:55:29.201103
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path("ansible")
    assert path == '/home/jesse/bin/ansible'

# Generated at 2022-06-24 20:55:31.655255
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', opt_dirs=['/bin']) == '/bin/python'

test_get_bin_path()

# Generated at 2022-06-24 20:55:33.399292
# Unit test for function get_bin_path
def test_get_bin_path():
    int_0 = -1720
    var_0 = get_bin_path(int_0)
    assert var_0 is not None


# Generated at 2022-06-24 20:55:34.514584
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:55:43.433564
# Unit test for function get_bin_path
def test_get_bin_path():
    module = AnsibleModule(
        argument_spec=dict(
            arg=dict(required=True, type='str'),
            opt_dirs=dict(required=False, type='list'),
        ),
        supports_check_mode=False
    )

    result = get_bin_path(module.params['arg'], module.params['opt_dirs'])
    module.exit_json(changed=False, ansible_facts=dict(get_bin_path=result))


# ansible registers the module
from ansible.module_utils.basic import AnsibleModule

if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:55:48.652515
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError:
        pass

# Standard boilerplate to call the main() function to begin
# the program.
if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:55:56.265178
# Unit test for function get_bin_path
def test_get_bin_path():
    # Paths should be case insensitive on Windows, so we'll try some variants.
    if os.name == 'nt':
        # The path should just be in PATH, no opt_dirs
        for cased in ('python.exe', 'PYTHON.exe', 'Python.exe', 'PyThOn.ExE'):
            ret = get_bin_path(cased)
            assert ret.lower() == os.path.realpath(ret).lower(), "Case for '%s' incorrect" % ret
            assert os.path.exists(ret), "Unable to find '%s' which should be in PATH" % ret
            assert os.path.basename(ret) == cased, "Case of basename (%s) doesn't match (%s)" % (os.path.basename(ret), cased)