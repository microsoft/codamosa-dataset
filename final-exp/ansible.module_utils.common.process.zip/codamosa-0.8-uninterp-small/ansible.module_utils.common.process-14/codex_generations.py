

# Generated at 2022-06-24 20:46:02.300393
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Check if the function can determine the correct path
    '''
    assert get_bin_path('ls') == '/bin/ls' or get_bin_path('ls') == '/usr/bin/ls'

# Generated at 2022-06-24 20:46:03.584126
# Unit test for function get_bin_path
def test_get_bin_path():
    result = get_bin_path('echo')
    assert result is not None

# Generated at 2022-06-24 20:46:04.079943
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:46:07.089833
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') is not None


# Generated at 2022-06-24 20:46:08.069188
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("asdf") == "/bin/asdf"

# Generated at 2022-06-24 20:46:10.845419
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'Pausing for %d seconds%s'
    str_1 = 'Pausing for %d seconds%s'
    var_0 = get_bin_path(str_0)

# Generated at 2022-06-24 20:46:11.724331
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:46:17.671870
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ.get = MagicMock(return_value = '/usr/bin:/bin:/usr/sbin:/sbin')
    get_bin_path("")


# Generated at 2022-06-24 20:46:18.837703
# Unit test for function get_bin_path
def test_get_bin_path():
    assert False # FIXME: implement your test here

# vim: ft=python

# Generated at 2022-06-24 20:46:21.544151
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()
    if (var_0 == False):
        print('Failed')
    else:
        print('Success')

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:46:26.252521
# Unit test for function get_bin_path
def test_get_bin_path():
    # run function: get_bin_path
    try:
        test_case_0()
    except ValueError:
        print('Execution failed: ValueError')


if __name__ == '__main__':
    # unit test
    test_get_bin_path()

# Generated at 2022-06-24 20:46:32.305356
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('get_bin_path') is not None)
    assert(get_bin_path('get_bin_path', required=False) is not None)
    assert(get_bin_path(None) is not None)
    assert(get_bin_path(None, required=True) is not None)
    assert(get_bin_path(None, required=False) is not None)
    assert(get_bin_path('.') is not None)
    assert(get_bin_path('./get_bin_path') is not None)
    assert(get_bin_path('./get_bin_path', required=True) is not None)
    assert(get_bin_path('./get_bin_path', required=False) is not None)

# Generated at 2022-06-24 20:46:33.061420
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')

# Generated at 2022-06-24 20:46:36.692156
# Unit test for function get_bin_path
def test_get_bin_path():
    assert func_0() == 'Hannah'
    assert func_0() == 'Samantha'


# Generated at 2022-06-24 20:46:37.066302
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:46:39.988318
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        str_0 = 'Pausing for %d seconds%s'
        var_0 = get_bin_path(str_0)
        print(var_0)
    except ValueError as e:
        print('ValueError detected:', type(e), e)
    else:
        print('test succeeded.')
        print()

test_get_bin_path()

# Unit tests for function get_bin_path with different argument values

# Generated at 2022-06-24 20:46:42.329205
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/echo') == '/bin/echo'



# Generated at 2022-06-24 20:46:51.726708
# Unit test for function get_bin_path
def test_get_bin_path():
    # function opts: {}
    # function kwargs: {}
    # function args: [Pausing for %d seconds%]
    assert get_bin_path('Pausing for %d seconds%').endswith('/pause')
    # function opts: {'opt_dirs': ['/bin']}
    # function kwargs: {}
    # function args: [Pausing for %d seconds%]
    assert get_bin_path('Pausing for %d seconds%', opt_dirs=['/bin']) == '/bin/pause'
    # function opts: {}
    # function kwargs: {}
    # function args: [True]
    assert get_bin_path('True').endswith('/true')
    # function opts: {}
    # function kwargs: {}
    # function args: [False]

# Generated at 2022-06-24 20:46:56.856671
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path("systemctl") == "/bin/systemctl")
    assert(get_bin_path("ssh-keygen") == "/usr/bin/ssh-keygen")
    try:
        test_case_0()
    except ValueError:
        pass
    else:
        raise Exception("ValueError not raised")

# Generated at 2022-06-24 20:47:03.932810
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'Pausing for %d seconds%s'
    assert get_bin_path(str_0) == '/usr/bin/printf'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/bin', '/usr/bin/']) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin/', '/bin']) == '/bin/ls'

# Generated at 2022-06-24 20:47:09.938241
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'Pausing for %d seconds%s'
    var_0 = get_bin_path(str_0)
    assert var_0 == '/bin/sleep'

str_0 = 'Pausing for %d seconds%s'
var_0 = get_bin_path(str_0)

# Generated at 2022-06-24 20:47:11.459299
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:47:13.722760
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Main block stub
if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:47:15.189301
# Unit test for function get_bin_path
def test_get_bin_path():
    var = get_bin_path('program')
    assert var == ['/usr/bin/program']

# Generated at 2022-06-24 20:47:16.663452
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('Pausing for %d seconds%s')


# Generated at 2022-06-24 20:47:24.505596
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('git') is not None
    assert get_bin_path('git', ['/usr/local/bin', '/usr/local/sbin']) is not None
    assert get_bin_path('git', ['/usr/bin', '/usr/sbin']) is not None
    try:
        get_bin_path('git1', ['/usr/bin', '/usr/sbin'])
    except Exception:
        # Test passed if exception gets raised
        pass
    try:
        get_bin_path('git', ['/usr/bin2', '/usr/sbin2'])
    except Exception:
        # Test passed if exception gets raised
        pass
    assert get_bin_path('git', ['/usr/bin', '/usr/sbin'], required=False) is None
    assert get_bin_

# Generated at 2022-06-24 20:47:33.898898
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls') in ('/bin/ls', '/usr/bin/ls', '/usr/local/bin/ls')
    assert get_bin_path('/bin/ls', required=True) == '/bin/ls'
    assert get_bin_path('ls', required=True) in ('/bin/ls', '/usr/bin/ls', '/usr/local/bin/ls')
    try:
        get_bin_path('/bin/ls', required=True, opt_dirs=['/tmp'])
    except Exception as e:
        assert type(e) == ValueError

# Generated at 2022-06-24 20:47:43.687961
# Unit test for function get_bin_path
def test_get_bin_path():
    # test get_bin_path with two args
    try:
        str_0 = 'Pausing for %d seconds%s'
        var_0 = get_bin_path(str_0)
    except ValueError:
        do_nothing()
    else:
        assert False
    # test get_bin_path with three args
    try:
        str_1 = 'Pausing for %d seconds%s'
        str_list_0 = ['test_path']
        var_1 = get_bin_path(str_1, str_list_0)
    except ValueError:
        do_nothing()
    else:
        assert False
    # test get_bin_path with four args

# Generated at 2022-06-24 20:47:47.943398
# Unit test for function get_bin_path
def test_get_bin_path():
    print('Running test_get_bin_path...')
    test_case_0()
    print('get_bin_path is OK!')

# Generated at 2022-06-24 20:47:50.152031
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(str_0) == 'Pausing for %d seconds%s'



# Generated at 2022-06-24 20:47:56.638673
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = None
    arg_1 = '/etc/hosts'
    arg_2 = True
    try:
        get_bin_path(arg_0, arg_1, arg_2)
    except ValueError as e:
        assert str(e) == "\"Failed to find required executable \"\'Pausing for %d seconds%s\'\" in paths: /etc/hosts\""



# Generated at 2022-06-24 20:48:03.286056
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        if  os.environ['TEST_GET_BIN_PATH'] == '1':
            print('Running test case: ' + 'test_case_0')
            test_case_0()
    except:
        print('Test Failed')

# Run test cases
if __name__ == '__main__':
    # test_case_0()
    print('Running test cases:')
    try:
        test_get_bin_path()
    except Exception as tce:
        print('Test Failed\n' + str(tce))
    else:
        print('Test Passed')

# Generated at 2022-06-24 20:48:04.545508
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)
    test_case_0()

# Generated at 2022-06-24 20:48:09.253781
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(None) == None


# Generated at 2022-06-24 20:48:11.627314
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('Pausing for %d seconds%s') == get_bin_path('Pausing for %d seconds%s'))

# Generated at 2022-06-24 20:48:14.164376
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python3') == '/usr/bin/python3'
    # TODO: test with different /etc/paths and custom paths

# Generated at 2022-06-24 20:48:17.637728
# Unit test for function get_bin_path
def test_get_bin_path():
    str_1 = 'Pausing for %d seconds%s'
    var_1 = get_bin_path(str_1, None)
    assert var_1 == '/usr/bin/Pausing for %d seconds%s'


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:48:25.569380
# Unit test for function get_bin_path
def test_get_bin_path():
    # check when opt_dirs is not None
    assert get_bin_path('cat', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/cat'
    # check when opt_dirs is None
    assert get_bin_path('/bin/cat') == '/bin/cat'
    # check when opt_dirs is list of directories
    assert get_bin_path('/bin/cat', opt_dirs=['/usr/bin', '/bin']) == '/bin/cat'

# Generated at 2022-06-24 20:48:30.991670
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('')

# Generated at 2022-06-24 20:48:32.425906
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path() == ""

test_case_0()

# Generated at 2022-06-24 20:48:42.394226
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(['/usr/bin', '/bin'], 'sh') == '/bin/sh'
    assert get_bin_path(['/usr/bin', '/bin'], 'sh', required=False) == '/bin/sh'
    assert get_bin_path(['/usr/bin', '/bin'], 'sh', required=True) == '/bin/sh'
    assert get_bin_path(['/usr/bin', '/bin'], 'sh', required=None) == '/bin/sh'
    assert get_bin_path(['/usr/bin', '/bin'], 'sh', required=0) == '/bin/sh'
    assert get_bin_path(['/usr/bin', '/bin'], 'sh', required=1) == '/bin/sh'

# Generated at 2022-06-24 20:48:52.075520
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = '/sbin/ip'
    arg_1 = [ '/usr/sbin', '/usr/bin', '/sbin' ]
    try:
        assert get_bin_path(arg_0, arg_1)
    except Exception as e:
        pass
    try:
        assert get_bin_path('/usr/local/sbin')
    except Exception as e:
        pass
    try:
        assert get_bin_path('/usr/bin/python')
    except Exception as e:
        pass


if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:48:56.200341
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('Pausing for %d seconds%s') == '/usr/bin/time'


# Generated at 2022-06-24 20:48:58.576898
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('where', '/sbin:/usr/sbin:/usr/local/sbin', required=None) == '/usr/bin/where'


# Generated at 2022-06-24 20:49:05.302226
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/python2.7') == '/usr/bin/python2.7', 'Path should match'
    assert get_bin_path('/usr/bin/python2.7', opt_dirs=['/bin', '/sbin']) == '/usr/bin/python2.7', 'Path should match'
    assert get_bin_path('/usr/bin/python2.7', opt_dirs=['/bin', '/sbin']) == get_bin_path('python2.7'), 'Path should match'
    try:
        get_bin_path('/bin/python2.7', required=True)
    except ValueError:
        assert False, 'Path should exist'

# Generated at 2022-06-24 20:49:07.732608
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('git')
    assert get_bin_path('git', ['test'])

# Generated at 2022-06-24 20:49:12.029910
# Unit test for function get_bin_path
def test_get_bin_path():
    args = ['arg', 'opt_dirs', 'required']
    arg_type = ['str', 'list', 'bool']
    ret_type = ['str', 'ValueError']
    test_template_0 = '''
from ansible.module_utils.common.process import get_bin_path
from ansible.module_utils._text import to_native

var_0 = 'arg'
var_1 = 'opt_dirs'
var_2 = 'required'
str_0 = 'Pausing for %d seconds%s'

try:
    var_3 = get_bin_path(var_0, var_1, var_2)
except Exception as var_4:
    ret_0 = type(var_4).__name__
else:
    ret_0 = to_native(var_3)
'''

# Generated at 2022-06-24 20:49:17.518436
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('ls')
    assert bin_path == '/bin/ls'
    # with arguments
    bin_path = get_bin_path('ls', required=False)
    assert bin_path == '/bin/ls'
    # with keyword arguments
    bin_path = get_bin_path(arg='ls', required=False)
    assert bin_path == '/bin/ls'
    # with arguments and keyword arguments
    bin_path = get_bin_path('ls', opt_dirs=['/usr/bin'], required=False)
    assert bin_path == '/usr/bin/ls'

# Generated at 2022-06-24 20:49:20.299830
# Unit test for function get_bin_path
def test_get_bin_path():
    ansible_bin_path = get_bin_path("ansible")
    assert ansible_bin_path is not None


# Generated at 2022-06-24 20:49:22.301762
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert test_case_0() == "Pausing for %d seconds%s"
    except AssertionError:
        raise


# Generated at 2022-06-24 20:49:30.278480
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('ls')
    assert path.endswith('ls')
    try:
        path = get_bin_path('thisisnotaprogram')
        assert False, 'Should not get here'
    except ValueError:
        pass
    path = get_bin_path('ls', opt_dirs=['/bin', '/usr/bin'])
    assert path.endswith('ls')
    try:
        path = get_bin_path('ls', opt_dirs=['/usr/local/bin'])
        assert False, 'Should not get here'
    except ValueError:
        pass
    path = get_bin_path('ls', opt_dirs=['/tmp'])
    assert path.endswith('ls')

# Generated at 2022-06-24 20:49:33.084530
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'Pausing for %d seconds%s'
    var_0 = get_bin_path(str_0)

# Generated at 2022-06-24 20:49:41.123827
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = '/home/user/ansible/directory/tests/unit/modules/checks/etc/asdfasdf/not/a/foo'
    arg_1 = ['/home/user/ansible/directory/tests/unit/modules/checks/etc/asdfasdf/not/a/foo', '/home/user/ansible/directory/tests/unit/modules/checks/etc/asdfasdf/not/a/bar', '/home/user/ansible/directory/tests/unit/modules/checks/etc/asdfasdf/not/a/foobar']
    with pytest.raises(ValueError) as exec_info:
        get_bin_path(arg_0, arg_1)
    assert "Failed to find required executable" in exec_info.value.args[0]

# Generated at 2022-06-24 20:49:44.753400
# Unit test for function get_bin_path
def test_get_bin_path():

    try:
        get_bin_path('python')
    except ValueError:
        raise AssertionError('Failed to retrieve the python executable in the path.  This is a test failure NOT a bug.')

# Generated at 2022-06-24 20:49:55.306859
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = 'ping'
    expected_0 = '/bin/ping'
    actual_0 = get_bin_path(arg_0)
    assert expected_0 == actual_0

    arg_1 = 'echo'
    opt_dirs_1 = ['/bin', '/usr', '/usr/local']
    expected_1 = '/bin/echo'
    actual_1 = get_bin_path(arg_1, opt_dirs_1)
    assert expected_1 == actual_1

    arg_2 = 'not-here'
    expected_2 = 'Failed to find required executable "not-here" in paths: /sbin:/bin:/usr/sbin:/usr/bin:/usr/local/sbin'

# Generated at 2022-06-24 20:50:03.924412
# Unit test for function get_bin_path
def test_get_bin_path():
    assert (get_bin_path('get_bin_path'))
    assert (get_bin_path('get_bin_path', ['../ansible_collections/joyent/triton']) == '../ansible_collections/joyent/triton/get_bin_path')
    assert (get_bin_path('get_bin_path') == 'get_bin_path')
    assert (get_bin_path('/bin/get_bin_path') == '/bin/get_bin_path')
    assert (get_bin_path('/bin') == '/bin')
    assert (get_bin_path('/bin/', ['../ansible_collections/joyent/triton']) == '/bin/')

# Generated at 2022-06-24 20:50:09.718667
# Unit test for function get_bin_path
def test_get_bin_path():
    required = None
    opt_dirs = None
    result = get_bin_path(required, opt_dirs)
    assert result == None, "Expected None"

# Generated at 2022-06-24 20:50:15.723789
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('Pausing for %d seconds%s') == '/usr/bin/Pausing for %d seconds%s'
    assert get_bin_path('Pausing for %d seconds%s', ['/usr/bin']) ==  '/usr/bin/Pausing for %d seconds%s'
    assert get_bin_path('Pausing for %d seconds%s', ['/usr/sbin']) ==  '/usr/sbin/Pausing for %d seconds%s'

# Generated at 2022-06-24 20:50:16.926747
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('pwd') == '/bin/pwd'

# Generated at 2022-06-24 20:50:25.282770
# Unit test for function get_bin_path
def test_get_bin_path():
    # AssertionError: Failed to find required executable "Pausing for %d seconds%" in paths: /usr/bin:/bin
    try:
        get_bin_path('Pausing for %d seconds%')
    except ValueError as error:
        assert error.args[0] == 'Failed to find required executable "Pausing for %d seconds%" in paths: /usr/bin:/bin'
    else:
        assert False



# Generated at 2022-06-24 20:50:28.334205
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True == isinstance(get_bin_path(str_0), str)


# Generated at 2022-06-24 20:50:29.933168
# Unit test for function get_bin_path
def test_get_bin_path():
    assert not get_bin_path('SourceTree')
    assert get_bin_path('ls')


# Generated at 2022-06-24 20:50:37.157576
# Unit test for function get_bin_path
def test_get_bin_path():

    assert get_bin_path('/usr/bin/echo', ['/usr/bin'], True) == '/usr/bin/echo'

    assert get_bin_path('/usr/bin/gem', ['/usr/bin'], True) == '/usr/bin/gem'

    assert get_bin_path('/usr/sbin/dmidecode', ['/usr/sbin'], True) == '/usr/sbin/dmidecode'

    assert get_bin_path('/usr/sbin/grub2-mkconfig', ['/usr/sbin'], True) == '/usr/sbin/grub2-mkconfig'

    assert get_bin_path('/bin/ping', ['/bin'], True) == '/bin/ping'


# Generated at 2022-06-24 20:50:38.660797
# Unit test for function get_bin_path
def test_get_bin_path():
    assert isinstance(get_bin_path("asdf"), object)  # TODO: should be type str

# Generated at 2022-06-24 20:50:42.982317
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(str_0)

# Generated at 2022-06-24 20:50:50.465852
# Unit test for function get_bin_path
def test_get_bin_path():
    """Return pathname of program or script for invocation on the command line.
    If the executable is not found, then returns None. If a path is supplied
    and is_executable() fails then ValueError will be raised.
    """
    # Case 1
    try:
        get_bin_path('/bin/false')
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "/bin/false" in paths: /bin/false'

# Generated at 2022-06-24 20:50:54.073340
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('pwd') == '/bin/pwd'
    assert get_bin_path('notaprog') == ''

# Generated at 2022-06-24 20:50:58.285672
# Unit test for function get_bin_path
def test_get_bin_path():
    str_2 = 'ps1'
    assert get_bin_path(str_2) == '/bin/ps1'

# Generated at 2022-06-24 20:51:00.379595
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/') == '/usr/bin/'

# Generated at 2022-06-24 20:51:06.320787
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'Pausing for %d seconds%s'
    v_0 = get_bin_path(str_0)
    assert  v_0 == '/sbin/pause'

# Generated at 2022-06-24 20:51:09.483464
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(str_0) == var_0

# Generated at 2022-06-24 20:51:10.344812
# Unit test for function get_bin_path
def test_get_bin_path():
    assert False


# Generated at 2022-06-24 20:51:11.588904
# Unit test for function get_bin_path
def test_get_bin_path():
    assert isinstance(get_bin_path(str_0), str)


# Generated at 2022-06-24 20:51:15.267564
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = '/sbin/ping'
    opt_dirs_0 = ['/bin', '/usr/bin', '/usr/local/bin']
    required_0 = True

    # Call the function
    get_bin_path(arg_0, opt_dirs_0, required_0)



# Generated at 2022-06-24 20:51:20.324014
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = 'Pausing for %d seconds%s'
    res_0 = get_bin_path(var_0)
    assert res_0 == 'Pausing for %d seconds%s'



# Generated at 2022-06-24 20:51:26.877903
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.common.validation import check_type_int
    from ansible.module_utils.common.validation import check_type_list
    from ansible.module_utils.common.validation import check_type_str
    check_type_str('str_0')
    test_case_0()

# Generated at 2022-06-24 20:51:30.240330
# Unit test for function get_bin_path
def test_get_bin_path():
    for test_args, expected_return in [
        ((test_case_0,), (test_case_0,)),
    ]:
        actual_return = get_bin_path(*test_args)
        assert actual_return == expected_return

# Generated at 2022-06-24 20:51:36.197718
# Unit test for function get_bin_path
def test_get_bin_path():
    cases = [
        (0, ),
    ]
    for case in cases:
        try:
            test_case_0(*case[:-1])
        except Exception as ex:
            raise AssertionError("Input: (%s). Output: %r. Expected: %r" % (case[:-1], ex, case[-1]))

# Generated at 2022-06-24 20:51:41.613126
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('shutdown') == '/sbin/shutdown'
    assert get_bin_path('foobar') == '/sbin/foobar'
    assert get_bin_path('ansible3') == 'ansible3'

# Generated at 2022-06-24 20:51:53.099810
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'Pausing for %d seconds%s'
    var_0 = get_bin_path(str_0)
    var_1 = os.path.exists(var_0)
    var_2 = is_executable(var_0)
    assert(var_1 and var_2)

    str_2 = 'Pausing for %d seconds%s'
    var_3 = get_bin_path(str_2, opt_dirs=['/bin', '/usr/bin'])
    var_4 = os.path.exists(var_3)
    var_5 = is_executable(var_3)
    assert(var_4 and var_5)

    str_3 = 'Pausing for %d seconds%s'

# Generated at 2022-06-24 20:51:58.705102
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert test_case_0() == 'Pass'
    except:
        print('Failed')

# Generated at 2022-06-24 20:52:03.511599
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 'Pausing for %d seconds%s' == get_bin_path('Pausing for %d seconds%s')



# Generated at 2022-06-24 20:52:08.463769
# Unit test for function get_bin_path
def test_get_bin_path():

    # work around for pytest#2248
    # TODO: Remove when https://github.com/ansible/ansible/issues/40570 is fixed
    test_case_0()

    from ansible.module_utils.common.file import get_bin_path

    src_path = get_bin_path('source', required=True)
    assert src_path



# Generated at 2022-06-24 20:52:10.050976
# Unit test for function get_bin_path
def test_get_bin_path():
    assert len(get_bin_path('bin_path')) > 0, 'Failed at line: 5'

# Generated at 2022-06-24 20:52:11.365671
# Unit test for function get_bin_path
def test_get_bin_path():
    assert isinstance(get_bin_path('python'), str)

# Generated at 2022-06-24 20:52:13.244510
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path(arg='Pausing for %d seconds%s', opt_dirs=[], required=None)



# Generated at 2022-06-24 20:52:16.309357
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:52:18.642097
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # Simple test case
        test_case_0()
    except ValueError as e:
        assert False, 'Failed to execute test case for function get_bin_path: ' + str(e)

# Generated at 2022-06-24 20:52:21.211059
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = '.'
    opt_dirs = '/usr/sbin'
    required = None
    expected = '/usr/sbin/./'
    actual = get_bin_path(arg, opt_dirs, required)
    assert actual == expected

# Generated at 2022-06-24 20:52:25.522024
# Unit test for function get_bin_path
def test_get_bin_path():
    assert os.path.isfile(get_bin_path('python'))

# Generated at 2022-06-24 20:52:33.453851
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'Pausing for %d seconds%s'
    var_0 = get_bin_path(str_0)
    assert var_0 == '/usr/bin/Pausing for %d seconds%s'



# Generated at 2022-06-24 20:52:36.740595
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('Pausing for %d seconds%s') == '/usr/local/sbin/Pausing for %d seconds%s'

# Generated at 2022-06-24 20:52:46.538965
# Unit test for function get_bin_path
def test_get_bin_path():
    # These tests are from Ansible's module_utils.common.file:get_bin_path
    try:
        get_bin_path('testExecute2')
        raise AssertionError('ValueError not raised')
    except ValueError:
        pass

    try:
        get_bin_path('doesNotExist', required=True)
        raise AssertionError('ValueError not raised')
    except ValueError:
        pass

    try:
        get_bin_path('doesNotExist', required=False)
        raise AssertionError('ValueError not raised')
    except ValueError:
        pass

    # set required=False and test for expected exception (in Python 2.6)

# Generated at 2022-06-24 20:52:49.581093
# Unit test for function get_bin_path
def test_get_bin_path():
    args = "Pausing for %d seconds%"
    ans = "/usr/bin/Pausing for %d seconds%/usr/bin/Pausing for %d seconds%"
    assert get_bin_path(args) == ans



# Generated at 2022-06-24 20:53:00.207511
# Unit test for function get_bin_path
def test_get_bin_path():
    # Variables
    str_obj_0 = "some_string"

    # Testing function with None parameter
    assert get_bin_path() == None

    # Testing function with None parameter and optional parameter
    assert get_bin_path(None) == None

    # Testing function with valid parameter
    assert get_bin_path(str_obj_0) != None

    # Testing function with valid parameter and optional parameter
    assert get_bin_path(str_obj_0, None) != None

    # Testing function with missing parameter
    try:
        assert get_bin_path(None, required=True) != None
    except BaseException as exception:
        assert type(exception) is ValueError

    # Testing function with missing parameter and optional parameter

# Generated at 2022-06-24 20:53:02.350948
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True == isinstance(get_bin_path(str_0), str)

# Generated at 2022-06-24 20:53:10.496559
# Unit test for function get_bin_path
def test_get_bin_path():

    assert isinstance(test_case_0(), str)
    assert len(test_case_0()) > 0
    assert isinstance(get_bin_path('/bin/true'), str)
    assert len(get_bin_path('/bin/true')) > 0
    assert isinstance(get_bin_path('/bin/false'), str)
    assert len(get_bin_path('/bin/false')) > 0
    assert isinstance(get_bin_path('/bin/cat'), str)
    assert len(get_bin_path('/bin/cat')) > 0
    assert isinstance(get_bin_path('/bin/echo'), str)
    assert len(get_bin_path('/bin/echo')) > 0
    assert isinstance(get_bin_path('/bin/head'), str)
   

# Generated at 2022-06-24 20:53:17.968623
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('/bin/ls')
    assert path == 'ls'
    #assert os.path.exists(path)
    #assert os.path.isfile(path)
    #assert os.access(path, os.X_OK)

    try:
        path = get_bin_path('NotReallyExist')
    except ValueError as e:
        assert "Failed to find required executable" in e.message
    except Exception as e:
        print(e)
        assert False, "Failed to throw exception"
    else:
        assert False, "Failed to throw exception"

# Generated at 2022-06-24 20:53:22.576932
# Unit test for function get_bin_path
def test_get_bin_path():

  # Call function with arguments:
  #   'Pausing for %d seconds%s'
  #   None
  #   None
  # Expected exception:
  #   ValueError
  test_case_0()

# Generated at 2022-06-24 20:53:24.295932
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("ansible-galaxy") is not None
    assert get_bin_path("ansible-galaxy") is not None

# Generated at 2022-06-24 20:53:39.046688
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path('/bin/true','','','','','','','','','','')
    assert var_0 == '/bin/true'
    var_1 = get_bin_path('/bin/true',['/bin','/usr/bin'])
    assert var_1 == '/bin/true'
    var_2 = get_bin_path('/bin/true',['/usr/bin'])
    assert var_2 == '/bin/true'
    var_3 = get_bin_path('/bin/true',['/bin','/usr/bin','/usr/local/bin'])
    assert var_3 == '/bin/true'
    var_4 = get_bin_path('/bin/false',['/bin','/usr/bin','/usr/local/bin'])
    assert var_

# Generated at 2022-06-24 20:53:40.079888
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("ls") is not None

# Generated at 2022-06-24 20:53:41.839053
# Unit test for function get_bin_path
def test_get_bin_path():
    assert (get_bin_path('pwd', opt_dirs=None)) is not None


# Generated at 2022-06-24 20:53:43.183170
# Unit test for function get_bin_path
def test_get_bin_path():

    assert get_bin_path('test')

test_case_0()

# Generated at 2022-06-24 20:53:44.459393
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 1: provided test case
    test_case_0()



# Generated at 2022-06-24 20:53:47.122005
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('grep') is not None
    with pytest.raises(ValueError):
        get_bin_path('grep_not_exists')

# Generated at 2022-06-24 20:53:52.308614
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('get_bin_path') is not None, "get_bin_path() test failed"


# Generated at 2022-06-24 20:54:00.249284
# Unit test for function get_bin_path
def test_get_bin_path():
    join_0 = os.path.join('1', '2', '3')
    isdir_0 = os.path.isdir(join_0)
    isdir_1 = os.path.isdir('1')
    _join = os.path.join
    os.path.join = lambda *args, **kwargs: _join(*args, **kwargs)
    if not isdir_1:
        raise AssertionError
    if not isdir_0:
        raise AssertionError
    if '1'.lower() not in join_0.lower():
        raise AssertionError
    if '2'.lower() not in join_0.lower():
        raise AssertionError
    if '3'.lower() not in join_0.lower():
        raise AssertionError

# Generated at 2022-06-24 20:54:02.545509
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'Pausing for %d seconds%s'
    var_0 = get_bin_path(str_0)
    assert var_0 == '/bin/sh'

# Generated at 2022-06-24 20:54:10.297255
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible.module_utils.common.file import get_bin_path
    from ansible.module_utils.common.file import get_bin_path

    # Invalid usage
    try:
        result = get_bin_path(None)
        assert False, "Expected exception"
    except ValueError as e:
        assert str(e) == "path argument is not a string", "Exception message does not match"

    # Does not exist, should raise exception
    try:
        result = get_bin_path('/usr/bin/python')
        assert False, "Expected exception"
    except ValueError as e:
        assert str(e) == "Failed to find required executable \"/usr/bin/python\" in paths: ", "Exception message does not match"

    # Exists, is executable, should return path
    result = get

# Generated at 2022-06-24 20:54:18.042700
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("date") == "/bin/date"



# Generated at 2022-06-24 20:54:20.899401
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = 'Pausing for %d seconds%s'
    opt_dirs = 'Pausing for %d seconds%s'
    assert get_bin_path(arg, opt_dirs) is not None

# Generated at 2022-06-24 20:54:22.309033
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:54:23.644036
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('Pause') != 'Pausing'


# Generated at 2022-06-24 20:54:27.414107
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert isinstance(get_bin_path(arg, opt_dirs=None, required=None), basestring)
    except (TypeError, AssertionError) as e:
        print(e)
        print("Incorrect return type from get_bin_path()")


# Generated at 2022-06-24 20:54:31.056731
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('Pausing for %d seconds%s') == '/usr/bin/PauPausinginsingf or %d seconds%s'
    assert get_bin_path('testing123') == '/usr/bin/testing123'

# Generated at 2022-06-24 20:54:34.410226
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = 'a'
    str_0 = 'Pausing for %d seconds%s'
    assert False, 'No input validation for str_0.'
    assert False, 'No input validation for var_0.'


# Generated at 2022-06-24 20:54:35.380934
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True == False  # FIXME


# Generated at 2022-06-24 20:54:41.077490
# Unit test for function get_bin_path
def test_get_bin_path():
    # Unit test for get_bin_path
    get_bin_path('pwd')
    path = '/usr/bin/pwd'
    get_bin_path('pwd', opt_dirs=path)

# Generated at 2022-06-24 20:54:45.825578
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'Pausing for %d seconds%s'
    var_0 = get_bin_path(str_0)

    # Test for Exception
    try:
        str_0 = 'Pausing for %d seconds%s'
        var_0 = get_bin_path(str_0)
    except Exception:
        pass

# Generated at 2022-06-24 20:54:51.459560
# Unit test for function get_bin_path
def test_get_bin_path():
    assert False


# Generated at 2022-06-24 20:54:53.037137
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:54:56.279169
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Test get_bin_path()
    """
    test_case_0()


if __name__ == '__main__':
    import pytest
    pytest.main("-s test_get_bin_path.py")

# Generated at 2022-06-24 20:55:04.536738
# Unit test for function get_bin_path
def test_get_bin_path():

    # Test with valid values
    arg = 'Pausing for %d seconds%s'
    assert get_bin_path(arg) == '/usr/bin/python'

    # Test with invalid value
    arg = 'Pausing for %d seconds'
    try:
       get_bin_path(arg)
    except ValueError:
       pass

    # Test with valid values
    arg = 'init'
    assert get_bin_path(arg) == '/usr/bin/python'

    # Test with valid values
    arg = 'python'
    assert get_bin_path(arg) == '/usr/bin/python'

    # Test with invalid value
    arg = 'initd'
    try:
       get_bin_path(arg)
    except ValueError:
       pass

    # Test with invalid value

# Generated at 2022-06-24 20:55:06.335772
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(str_0) == '/usr/bin/python'



# Generated at 2022-06-24 20:55:14.634934
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cp') == '/bin/cp'
    assert get_bin_path('/bin/cp') == '/bin/cp'
    assert get_bin_path('/unknown/path') == '/unknown/path'
    assert get_bin_path('/unknown/path', ['/bin']) == '/unknown/path'
    assert get_bin_path('/unknown/path', ['/bin', '/sbin']) == '/unknown/path'
    assert get_bin_path('/unknown/path', ['/bin'], True) == '/unknown/path'
    assert get_bin_path('/unknown/path', ['/bin', '/sbin'], True) == '/unknown/path'
    assert get_bin_path('/unknown/path', required=True) == '/unknown/path'
    assert get_bin_

# Generated at 2022-06-24 20:55:15.811857
# Unit test for function get_bin_path
def test_get_bin_path():
    # TODO: rewrite as appropriate test
    assert True

# Generated at 2022-06-24 20:55:17.080132
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('which') is not None

# Generated at 2022-06-24 20:55:18.466790
# Unit test for function get_bin_path
def test_get_bin_path():
    with pytest.raises(ValueError) as excinfo:
       test_case_0()
    assert 'Failed to find required executable' in str(excinfo.value)


# Generated at 2022-06-24 20:55:28.455828
# Unit test for function get_bin_path
def test_get_bin_path():
    # that can be run by pytest with the -s flag (i.e. pytest -s test_file.py).

    # Create a mock object to simulate the os module.
    mock_os = create_autospec(os)

    # Mock the os.path.exists function so it always returns true.
    mock_os.path.exists.return_value = True

    # Mock the os.path.isdir function so it always returns false.
    mock_os.path.isdir.return_value = False

    # Mock the os.path.join function so it always returns the second parameter.
    mock_os.path.join.return_value = 'some_executable'

    # Mock the os.environ function so it always returns a path.

# Generated at 2022-06-24 20:55:34.406789
# Unit test for function get_bin_path
def test_get_bin_path():
    var_1 = get_bin_path('python')
    assert var_1 == '/usr/bin/python', 'Test failed'



# Generated at 2022-06-24 20:55:38.910072
# Unit test for function get_bin_path
def test_get_bin_path():
    test_cases = [
        (0, None),
    ]
    for index, tc in enumerate(test_cases):
        try:
            test_case_0()
        except ValueError as e:
            raise AssertionError('Error raised in test case #{}: {}'.format(index, str(e)))

# Generated at 2022-06-24 20:55:40.069678
# Unit test for function get_bin_path
def test_get_bin_path():
  assert 'Pausing' in get_bin_path('Pausing')

# Generated at 2022-06-24 20:55:43.074015
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(str_0) == var_0
    assert get_bin_path(str_0, opt_dirs=[]) == var_0
    assert get_bin_path(str_0, opt_dirs=[]) == var_0

# Test case 1

# Generated at 2022-06-24 20:55:46.639702
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:55:48.034678
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('Pausing for %d seconds%s') == '/usr/bin/sleep'



# Generated at 2022-06-24 20:55:51.797309
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') is not None
    assert get_bin_path('i_do_not_exist', required=False) is None
    assert get_bin_path('i_do_not_exist') is None


if __name__ == '__main__':
    test_get_bin_path()