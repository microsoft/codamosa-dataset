

# Generated at 2022-06-24 20:46:01.614871
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('/etc/passwd')
    assert True


# Generated at 2022-06-24 20:46:09.597410
# Unit test for function get_bin_path
def test_get_bin_path():
    # Unit test for function get_bin_path
    #
    # Raise an exception if the executable is not found in the search paths.
    #

    # the environment variable PATH is used to determine the search paths.
    # Since we don't want to affect the environment, we make a copy and reset
    # the environment after the test.
    env = dict(os.environ)

# Generated at 2022-06-24 20:46:13.545517
# Unit test for function get_bin_path
def test_get_bin_path():
    float_0 = -1511.9776
    var_0 = get_bin_path(float_0)
    if isinstance(var_0, str):
        print("could not find required executable %s: %s" % (float_0, var_0))
    else:
        print("get_bin_path: PASS\n")


# Generated at 2022-06-24 20:46:15.147824
# Unit test for function get_bin_path
def test_get_bin_path():
    print('\n### TESTING get_bin_path ###')
    test_case_0()



# Generated at 2022-06-24 20:46:16.028088
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:46:20.525225
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with required_existing = False
    required_existing = False
    var_0 = get_bin_path(arg=required_existing, required=True)
    assert var_0 == True
    # Test with required_existing = True
    required_existing = True
    var_1 = get_bin_path(arg=required_existing, required=True)
    assert var_1 == True



# Generated at 2022-06-24 20:46:25.384530
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert test_case_0()
    except ValueError as e:
        assert "Failed to find required executable" in str(e), "Failure: %s" % str(e)
        return True

# Generated at 2022-06-24 20:46:27.180337
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError:
        pass

# Generated at 2022-06-24 20:46:29.588184
# Unit test for function get_bin_path
def test_get_bin_path():
    f = get_bin_path
    assert f(float()) == float()
    assert f(int()) == int()
    assert f(bool()) == bool()


if __name__ == '__main__':
    import sys
    get_bin_path(sys.argv[0])

# Generated at 2022-06-24 20:46:33.313313
# Unit test for function get_bin_path
def test_get_bin_path():
    float_0 = -1603.1255
    float_1 = -0.9071112
    float_2 = -6186.08
    float_3 = 0.2989668
    assert get_bin_path(float_0)
    assert get_bin_path(float_1)
    assert get_bin_path(float_2)
    assert get_bin_path(float_3)

# Generated at 2022-06-24 20:46:40.145817
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path('git')
    var_1 = get_bin_path('pwd')
    var_2 = get_bin_path('fakeroot')

# Generated at 2022-06-24 20:46:42.518199
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(0) == 0


# Generated at 2022-06-24 20:46:44.498399
# Unit test for function get_bin_path
def test_get_bin_path():
    # Assume base directory contains file 'a'
    assert get_bin_path("a") == os.path.join(os.getcwd(), "a")

# Generated at 2022-06-24 20:46:48.201236
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with dummy arguments
    float_0 = -1511.9776
    var_0 = get_bin_path(float_0)
    pass


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:46:49.651470
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test execution with correct arguments
    assert True


# Generated at 2022-06-24 20:46:54.056630
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path(test_case_0)

# Generated at 2022-06-24 20:47:01.555413
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('lsb_release') is not None
    try:
        get_bin_path('zccdddvbvbvbv')
        failed = False
    except ValueError:
        failed = True
    assert failed
    assert get_bin_path('lsb_release', required=True) is not None
    assert get_bin_path('zccdddvbvbvbv', required=True) is None

# Generated at 2022-06-24 20:47:08.408412
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert test_case_0() == -1511.9776
    except AssertionError as err:
        print("Test case assert failed: {0}".format(err))

# Unit test end
if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:47:10.675176
# Unit test for function get_bin_path
def test_get_bin_path():
    float_0 = -1511.9776
    var_0 = get_bin_path(float_0)
    assert var_0 == '-1511.9776'

# Generated at 2022-06-24 20:47:13.088143
# Unit test for function get_bin_path
def test_get_bin_path():
    # test_case_0()
    pass


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:47:19.766782
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = -1511.9776
    opt_dirs = []
    required = None
    expected = ValueError
    output = ValueError

# Generated at 2022-06-24 20:47:25.469221
# Unit test for function get_bin_path
def test_get_bin_path():
    var_5 = get_bin_path()
    assert var_5 == None


# Generated at 2022-06-24 20:47:31.093043
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(1) == "/usr/bin/1"
    obj = get_bin_path("/usr/bin/2", required=False)
    assert obj == "/usr/bin/2"
    assert get_bin_path(None) == "/bin/None"
    assert get_bin_path(1, [False, 1, "foo"], False) == "/usr/bin/1"
    assert get_bin_path(1.0, ["foo", True, 1], True) == "/bin/1.0"
    obj = get_bin_path("/usr/bin/3", required=False)
    assert obj == "/usr/bin/3"
    assert get_bin_path(0, [False, 1, "foo"], True) == "/bin/0"

# Generated at 2022-06-24 20:47:36.467046
# Unit test for function get_bin_path
def test_get_bin_path():
    # This test might need more specific assertions than just checking if an
    # exception was thrown. (In most cases, these assertions would be more
    # specific to the actual implementation of get_bin_path and would likely
    # not be useful in other cases.)

    # Passing a non-string path raises a ValueError
    bool_0 = False
    str_0 = '1'
    bool_1 = False
    bool_2 = False
    with pytest.raises(ValueError):
        get_bin_path(bool_0, bool_1, bool_2)

    # Passing a non-string required raises a ValueError
    bool_3 = False
    str_1 = '2'
    bool_4 = False
    bool_5 = False

# Generated at 2022-06-24 20:47:40.960641
# Unit test for function get_bin_path
def test_get_bin_path():
    some_args = 1511.9776
    get_bin_path(some_args)


# Generated at 2022-06-24 20:47:43.953103
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path1 = get_bin_path('/bin/ls')
    assert bin_path1 == '/bin/ls'
    bin_path2 = get_bin_path('ls', ['/bin'])
    assert bin_path2 == '/bin/ls'

# Generated at 2022-06-24 20:47:53.470304
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path(
        '--ignore-unknown-arguments',
        opt_dirs=['/usr/bin', '/usr/sbin', '/bin', '/sbin', '/usr/local/bin', '/usr/local/sbin'],
        required=False,
        )
    get_bin_path('--ignore-unknown-options', ['/usr/bin', '/usr/sbin', '/bin', '/sbin', '/usr/local/bin', '/usr/local/sbin'], False)
    get_bin_path('--yes', ['/usr/bin', '/usr/sbin', '/bin', '/sbin', '/usr/local/bin', '/usr/local/sbin'], True)

# Generated at 2022-06-24 20:47:55.001379
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)
    get_bin_path(float_0)



# Generated at 2022-06-24 20:48:03.530874
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:48:13.363090
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/pwd') == '/usr/bin/pwd'
    assert get_bin_path('/usr/bin/pwd', ['/usr/bin']) == '/usr/bin/pwd'
    assert get_bin_path('/usr/bin/pwd', ['/bin']) == '/usr/bin/pwd'
    assert get_bin_path('pwd') == '/bin/pwd'
    assert get_bin_path('pwd', ['/usr/bin']) == '/bin/pwd'
    assert get_bin_path('pwd', ['/usr/bin'], None) == '/bin/pwd'
    assert get_bin_path('pwd', ['/usr/bin'], True) == '/bin/pwd'

# Generated at 2022-06-24 20:48:16.811343
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('nothing') == None


# Generated at 2022-06-24 20:48:17.932811
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path('ls') == '/bin/ls')

# Generated at 2022-06-24 20:48:19.267043
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:48:24.331354
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)
    assert isinstance(get_bin_path(1.0), (os.PathLike, str, bytes))

# Generated at 2022-06-24 20:48:24.818934
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-24 20:48:27.361309
# Unit test for function get_bin_path
def test_get_bin_path():
    for i in range(100):
        test_case_0()
    print("Test test_get_bin_path() completed")


# Unit test execution
if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:48:29.204209
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() is None

# Generated at 2022-06-24 20:48:29.755681
# Unit test for function get_bin_path
def test_get_bin_path():
    assert False # FIXME

# Generated at 2022-06-24 20:48:32.719933
# Unit test for function get_bin_path
def test_get_bin_path():
    # Simple two-stage pipeline with just two functions under test.
    assert test_case_0() is None, "Failed to test_get_bin_path"



# Generated at 2022-06-24 20:48:38.515065
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('/bin/ls')
    except ValueError:
        pass
    else:
        # not what we expected
        raise AssertionError
    try:
        get_bin_path('ls')
    except ValueError:
        # not what we expected
        raise AssertionError
    else:
        pass



# Generated at 2022-06-24 20:48:44.009500
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None

# Generated at 2022-06-24 20:48:44.768521
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:48:54.658157
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = '/usr/bin/python'
    opt_dirs_0 = None
    required_0 = True
    assert isinstance(get_bin_path(arg_0, opt_dirs_0, required_0), str) == True
    arg_1 = 'execute_command'
    opt_dirs_1 = None
    required_1 = False
    assert isinstance(get_bin_path(arg_1, opt_dirs_1, required_1), str) == True
    arg_2 = 'python'
    opt_dirs_2 = ['/usr/bin', '/bin']
    required_2 = True
    assert isinstance(get_bin_path(arg_2, opt_dirs_2, required_2), str) == True
    arg_3 = '/usr/bin/python'
   

# Generated at 2022-06-24 20:48:58.686264
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = '-1511.9776'
    arg_1 = 'var_1'
    try:
        test_case_0()
    except ValueError as e:
        if arg_1  in str(e):
            print('Test Success')
        else:
            print('Test Failure')
    except (Exception) as e:
        print('Test Failure')


# Generated at 2022-06-24 20:49:01.107485
# Unit test for function get_bin_path
def test_get_bin_path():
    args = []
    if __name__ == '__main__':
        for arg in args:
            get_bin_path(arg)
        test_case_0()

# Generated at 2022-06-24 20:49:04.047239
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as e:
        print(e)

# Generated at 2022-06-24 20:49:07.457049
# Unit test for function get_bin_path
def test_get_bin_path():
    # get_bin_path() example
    var_0 = get_bin_path("/usr/bin/python")
    assert var_0 == "/usr/bin/python"

# Generated at 2022-06-24 20:49:12.591761
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# vim: sts=4 sw=4 et

# Generated at 2022-06-24 20:49:14.224817
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True == True


# Test for function get_bin_path with param args=

# Generated at 2022-06-24 20:49:15.217456
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python')

# Generated at 2022-06-24 20:49:24.594067
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('/usr/bin/ansible-pull')
    assert path == '/usr/bin/ansible-pull'

    path = get_bin_path('behat')
    assert path == '/usr/local/bin/behat'

    try:
        get_bin_path('nonexistant-command')
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)
    else:
        assert False


# Generated at 2022-06-24 20:49:27.188549
# Unit test for function get_bin_path
def test_get_bin_path():
    test_0 = get_bin_path('/usr/bin/test')
    test_1 = get_bin_path('test')

# Generated at 2022-06-24 20:49:28.937575
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None, "Failed to set variable to proper value"

# Generated at 2022-06-24 20:49:38.970904
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(get_bin_path('/sbin/route', required=False)) == get_bin_path('/sbin/route')
    assert get_bin_path(get_bin_path('/bin/false'), required=False) == get_bin_path('/bin/false')
    assert get_bin_path(get_bin_path('/bin/false', required=False)) == get_bin_path('/bin/false')
    assert get_bin_path(get_bin_path('/bin/false', opt_dirs=['/bin']), opt_dirs=['/bin']) == get_bin_path('/bin/false')

# Generated at 2022-06-24 20:49:40.173232
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path(42)
        assert False, "Should have thrown an exception"
    except ValueError as e:
        assert "Failed to find required executable" in str(e)

# Generated at 2022-06-24 20:49:44.253623
# Unit test for function get_bin_path
def test_get_bin_path():

    float_0 = -1511.9776
    var_0 = get_bin_path(float_0)


if __name__ == '__main__':
    test_get_bin_path()
    test_case_0()

# Generated at 2022-06-24 20:49:47.623377
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:49:57.610163
# Unit test for function get_bin_path
def test_get_bin_path():
    float_0 = -1511.9776
    var_0 = get_bin_path(float_0)
    float_1 = -1247.5155
    float_2 = -2124.1711
    var_1 = get_bin_path(float_1, float_2)
    float_3 = -1609.243
    float_4 = -2659.9294
    var_2 = get_bin_path(float_3, float_4)
    float_5 = -2366.9642
    float_6 = -2400.4176
    var_3 = get_bin_path(float_5, float_6)
    float_7 = -2679.0206
    float_8 = -1458.926
    float_9 = -1612.8586
    float_10

# Generated at 2022-06-24 20:50:01.624106
# Unit test for function get_bin_path
def test_get_bin_path():

    # These calls should pass
    test_case_0()


# Generated at 2022-06-24 20:50:04.329276
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('foo') == None
    assert get_bin_path('ansible') != None
    assert get_bin_path('ansible', opt_dirs=['/usr/local/bin']) != None
    assert get_bin_path('ansible', opt_dirs=['/usr/local/bin', '/usr/bin']) == None


# Generated at 2022-06-24 20:50:12.984891
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ['PATH'] = '/bin:/usr/bin:/usr/local/bin'
    assert get_bin_path('sh', None, None) is not None
    assert get_bin_path('sh', ['/bin'], None) is not None
    assert get_bin_path('sh', ['/usr/bin'], None) is not None
    assert get_bin_path('sh', ['/usr/local/bin'], None) is not None
    assert get_bin_path('sh', ['/nonexistent'], None) is not None
    assert get_bin_path('sh', ['/nonexistent', '/other/nonexistent'], None) is not None
    assert get_bin_path('/bin/sh', None, None) is not None

# Generated at 2022-06-24 20:50:14.180315
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError:
        pass

# Generated at 2022-06-24 20:50:23.158607
# Unit test for function get_bin_path
def test_get_bin_path():
    # Get the value of the 'temp_dir' builtin variable
    temp_dir = dir()
    # Create a new context for function 'get_bin_path'
    # Create a new context for function 'get_bin_path'
    # Assign a type to the variable 'float_0' (line 209)
    module_type_store.set_type_of(stypy.reporting.localization.Localization(__file__, 209, 4), 'float_0', float_0)
    
    # Assigning a Call to a Name (line 210):
    
    # Call to get_bin_path(...): (line 210)
    # Processing the call arguments (line 210)
    # Getting the type of 'float_0' (line 210)

# Generated at 2022-06-24 20:50:26.000465
# Unit test for function get_bin_path
def test_get_bin_path():
    result = get_bin_path(arg, opt_dirs, required)
    assert result.__class__.__name__ == 'float' or result.__class__.__name__ == 'int'

# Generated at 2022-06-24 20:50:33.890609
# Unit test for function get_bin_path
def test_get_bin_path():
    float_0 = -1511.9776
    var_0 = get_bin_path(float_0)
    float_1 = float_0
    var_1 = get_bin_path(float_1, required=float_1)
    float_2 = float_1
    float_3 = float_2
    var_2 = get_bin_path(float_3, opt_dirs=float_2)
    float_4 = float_3
    int_0 = int(float_3)
    var_3 = get_bin_path(float_4, opt_dirs=int_0)
    float_5 = float_4
    var_4 = get_bin_path(float_5, required=float_5, opt_dirs=var_3)
    float_6 = float_5
    int

# Generated at 2022-06-24 20:50:34.625324
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)


# Generated at 2022-06-24 20:50:35.162725
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:50:35.854238
# Unit test for function get_bin_path
def test_get_bin_path():
    result = None
    expected = None
    assert actual == expected, 'Test Failed'

# Generated at 2022-06-24 20:50:38.045489
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = 'test'
    ret_0 = get_bin_path(arg_0)

    assert isinstance(ret_0, str)

# Generated at 2022-06-24 20:50:43.877120
# Unit test for function get_bin_path
def test_get_bin_path():
    float_0 = -1511.9776
    var_0 = get_bin_path(float_0)


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:50:47.030873
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()



# Generated at 2022-06-24 20:50:49.416190
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path("/bin/sh") != None)
    # assert(get_bin_path("/bin/false") == None)

# Generated at 2022-06-24 20:50:50.719980
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 'ansible' in get_bin_path('ansible')

# Generated at 2022-06-24 20:50:55.162414
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("aoe-revalidate")
    assert get_bin_path("all")
    assert get_bin_path("/usr/bin/echo")



# Generated at 2022-06-24 20:50:56.374035
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = test_case_0()
    assert not var_0

# Generated at 2022-06-24 20:50:57.126142
# Unit test for function get_bin_path
def test_get_bin_path():
    # Run Module Test
    test_case_0()

# Generated at 2022-06-24 20:50:58.498631
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(test_case_0()) == 'test-result'

# Generated at 2022-06-24 20:51:01.179233
# Unit test for function get_bin_path
def test_get_bin_path():
    float_0 = 'sk9cY'
    var_0 = get_bin_path(float_0)


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:51:07.356597
# Unit test for function get_bin_path
def test_get_bin_path():
    # Input parameters
    arg = -1511.9776

    # Output parameters
    var_1 = -1511.9776

    var_0 = get_bin_path(float_0)

    # Check for correct output
    if var_0 != var_1:
        raise ValueError

    if var_0 is not None:
        pass
    else:
        raise ValueError



# Generated at 2022-06-24 20:51:13.224793
# Unit test for function get_bin_path
def test_get_bin_path():
    # Path to file of test case.
    test_case_path = os.path.join(os.path.dirname(__file__), 'test_case_0.py')
    # Compile test case.
    py_compile.compile(test_case_path, doraise=True)
    # Execute test case.
    test_case_module = imp.load_source('0', test_case_path)
    test_case_0()


# Generated at 2022-06-24 20:51:18.877052
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = -1511.9776

    # Call function get_bin_path
    get_bin_path(arg)


if __name__ == "__main__":
    test_case_0()
    # test_get_bin_path()

# Generated at 2022-06-24 20:51:22.276516
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('nodejs')
    assert bin_path


if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:51:23.260488
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None

# Generated at 2022-06-24 20:51:27.261994
# Unit test for function get_bin_path
def test_get_bin_path():
    # This unit test can be used to test function get_bin_path
    # Assert statement(s) to check the output as per the requirements
    var_0 = get_bin_path("/bin/ls")
    assert var_0 == "/bin/ls"

# Generated at 2022-06-24 20:51:28.257303
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("echo") is not None

# Generated at 2022-06-24 20:51:38.545933
# Unit test for function get_bin_path
def test_get_bin_path():
    srcdir = os.path.dirname(__file__)
    testdir = os.path.join(srcdir, 'pytest')

    float_0 = -1511.9776
    float_1 = -0.38
    float_2 = 3.2
    var_0 = get_bin_path(float_0)
    var_1 = get_bin_path(float_1)
    var_2 = get_bin_path(float_2)
    var_3 = get_bin_path(float_0, [testdir])
    var_4 = get_bin_path(float_1, [testdir])
    var_5 = get_bin_path(float_2, [testdir])



# Generated at 2022-06-24 20:51:40.332115
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

if __name__ == '__main__':
    # Additional unit tests need to be placed here
    test_get_bin_path()

# Generated at 2022-06-24 20:51:48.518579
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test case 0
    try:
        test_case_0()
    except ValueError:
        pass
    else:
        raise AssertionError('An error occurred during test case 0. (None raised when ValueError was expected).')
    # Test case 1
    float_0 = float('nan')
    try:
        var_0 = get_bin_path(float_0)
    except ValueError:
        pass
    else:
        raise AssertionError('An error occurred during test case 1. (None raised when ValueError was expected).')
    # Test case 2
    try:
        test_case_0()
    except ValueError:
        pass
    else:
        raise AssertionError('An error occurred during test case 2. (None raised when ValueError was expected).')
    # Test case 3
    float_0

# Generated at 2022-06-24 20:51:51.162229
# Unit test for function get_bin_path
def test_get_bin_path():
    print("Executing test '%s'" % __file__)
    print("Calling get_bin_path")
    test_case_0()
    print("All tests pass!")


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:51:57.113321
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('/usr/bin')
    print('The absolute path to test is: ', path)
    assert path == '/usr/bin'

if __name__ == '__main__':
    get_bin_path()
    test_case_0()

# Generated at 2022-06-24 20:52:04.044803
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception:
        print('Test case failed.')

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:52:04.578365
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:52:07.315542
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as err:
        assert err
    else:
        raise AssertionError("Unhandled error")

# Generated at 2022-06-24 20:52:11.575999
# Unit test for function get_bin_path
def test_get_bin_path():
    # Assert 0
    try:
        test_case_0()
    except ValueError:
        pass
    else:
        raise AssertionError("Unreachable due to exception")

# Generated at 2022-06-24 20:52:14.055738
# Unit test for function get_bin_path
def test_get_bin_path():
    print('Testing get_bin_path()')
    test_case_0()

# MAIN
if __name__ == '__main__':
    test_get_bin_path()
    print('Done')

# Generated at 2022-06-24 20:52:15.415090
# Unit test for function get_bin_path
def test_get_bin_path():
    float_0 = -1511.9776
    var_0 = get_bin_path(float_0)



# Generated at 2022-06-24 20:52:22.822676
# Unit test for function get_bin_path
def test_get_bin_path():
    # NB: we cannot use assertRaisesRegexp in Python 2.6 so we use
    # assertRaisesRegex instead and disable the check for regexes in the
    # doctest runner
    from nose import SkipTest
    from nose.tools import assert_raises_regex
    from ansible.module_utils.six.moves import reload_module
    reload_module(doctest)
    import doctest
    doctest.DONT_ACCEPT_TRUE_FOR_1 = True
    doctest.IGNORE_EXCEPTION_DETAIL = True
    raise SkipTest("FIXME: needs a mock PATH, and then the bin path will be wrong anyway")

# Generated at 2022-06-24 20:52:25.214483
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test get_bin_path function
    '''
    test_case_0()

# Collect all test cases in this class
test_cases = [
    test_get_bin_path,
]

# There is only one test suite for now

# Generated at 2022-06-24 20:52:26.334837
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path(arg, opt_dirs=None, required=None)


# Generated at 2022-06-24 20:52:29.453654
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
        print('Passed unit test')
    except ValueError as e:
        print(e)
        print('Failed unit test')
    else:
        print('Passed unit test')

if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:52:36.599100
# Unit test for function get_bin_path
def test_get_bin_path():
    float_0 = -1511.9776
    ret_0 = get_bin_path(float_0)

# Generated at 2022-06-24 20:52:40.173638
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('python')

    assert bin_path

    try:
        bin_path = get_bin_path('foo')
        assert False, 'Expected exception'
    except ValueError:
        pass

# Generated at 2022-06-24 20:52:41.133623
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:52:43.464418
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = 0
    opt_dirs = []
    required = None

    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-24 20:52:48.184544
# Unit test for function get_bin_path
def test_get_bin_path():
    float_0 = get_bin_path(float_0)
    assert var_0 == '-1511.9776'

# Generated at 2022-06-24 20:52:50.088361
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path(1)
    get_bin_path(1.0)
    get_bin_path('string')



# Generated at 2022-06-24 20:52:55.725309
# Unit test for function get_bin_path
def test_get_bin_path():
    # Initialize test
    assert True

    # Execute test
    test_case_0()


'''
Run test with:
python -m pytest tests/test_ansible_module_utils___init__.py
'''

# Generated at 2022-06-24 20:52:56.853697
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None


# Generated at 2022-06-24 20:52:57.609955
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:53:05.073733
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as err:
        print("\nFAILED:\nFailed to find required executable '%s' in paths: %s\n" % (str(-1511.9776), os.pathsep.join(os.environ.get('PATH', '').split(os.pathsep))))
    else:
        print("\nSUCCESS\n")

if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:53:12.965263
# Unit test for function get_bin_path
def test_get_bin_path():
    print("\n\nTESTING get_bin_path")

    test_case_0()
    print("*** END OF get_bin_path TESTS ***")



# Generated at 2022-06-24 20:53:14.429603
# Unit test for function get_bin_path
def test_get_bin_path():
    assert (test_case_0() == None)


# Generated at 2022-06-24 20:53:15.709100
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None


# Generated at 2022-06-24 20:53:23.251660
# Unit test for function get_bin_path
def test_get_bin_path():
    # Get_bin_path without options and without required
    float_0 = -1511.9776
    var_0 = get_bin_path(float_0)
    # Get_bin_path with options and without required
    int_0 = -11192
    var_1 = get_bin_path(int_0, opt_dirs=[int_0])
    # Get_bin_path without options and with required
    dict_0 = {5.5: "Kc%", '1': 2, '8': 0}
    str_0 = 'bh'
    dict_1 = {str_0: "D!j", '1': int_0, '3': dict_0}
    list_0 = [dict_1, int_0, var_1]

# Generated at 2022-06-24 20:53:30.710259
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0  = -1511.9776
    ret_0 = get_bin_path(arg_0 )
    assert ret_0 == '/sbin/fsck.ext3'

    arg_1  = ' -3.1414'
    arg_2  = 'test2'
    ret_1 = get_bin_path(arg_1 , opt_dirs=[arg_2 ] )
    assert ret_1 == '/sbin/fsck.ext3'



# Generated at 2022-06-24 20:53:36.479369
# Unit test for function get_bin_path
def test_get_bin_path():
    int_0 = -98
    int_1 = -1511
    float_0 = -1511.9776

    # Call function get_bin_path
    get_bin_path(int_0)
    get_bin_path(int_1)
    get_bin_path(float_0)


# Generated at 2022-06-24 20:53:39.978346
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '<function get_bin_path at 0x' in repr(get_bin_path)
    assert get_bin_path(-1511.9776) is not None
    #
    # TODO: Add more tests as needed.
    #

# Generated at 2022-06-24 20:53:41.745625
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception as error:
        print(str(error))
        assert False

# Generated at 2022-06-24 20:53:42.673966
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True == True



# Generated at 2022-06-24 20:53:51.434487
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test function get_bin_path with float argument
    float_0 = 0.4444444444444444
    float_1 = -1.578947368421052
    float_2 = -0.8333333333333333
    float_3 = -2.842105263157897
    float_4 = -0.08333333333333333
    float_5 = -1.2105263157894736
    float_6 = -0.4444444444444444
    float_7 = -1.0
    float_8 = -0.22222222222222222
    float_9 = -0.5789473684210526
    float_10 = -0.5263157894736842
    float_11 = -0.3333333333333333

# Generated at 2022-06-24 20:53:57.102981
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == -1511.9776

# Generated at 2022-06-24 20:53:57.957168
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:54:03.984354
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        #var_0 = get_bin_path('ls')
        var_1 = get_bin_path('ohai')
        if var_1 != None:
            print(var_1)
    except Exception:
        print("fail1")
        
    try:
        #var_0 = get_bin_path('ls')
        var_1 = get_bin_path('ohai_not_found')
        if var_1 != None:
            print(var_1)
    except Exception:
        print("fail2")



if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:54:06.234036
# Unit test for function get_bin_path
def test_get_bin_path():
    # Assert False
    try:
        get_bin_path(float_0)
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "-1511.9776" in paths: /sbin:/usr/sbin:/usr/local/sbin'



# Generated at 2022-06-24 20:54:07.687172
# Unit test for function get_bin_path
def test_get_bin_path():

    assert get_bin_path('ansible-console') == '/usr/local/bin/ansible-console'


# Generated at 2022-06-24 20:54:14.053294
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        from importlib import reload
    except ImportError:
        from imp import reload

    # Test with arguments:
    #   - arg = <float>
    #   - opt_dirs = [ <string> ]
    #   - required = <boolean>
    # Verify that function returns <string>
    #
    reload(importlib.machinery)
    importlib.machinery.SOURCE_SUFFIXES.append('')
    tmp_0 = -1511.9776
    get_bin_path(arg=tmp_0)

    # Test with arguments:
    #   - arg = <list>
    #   - opt_dirs = [ <string> ]
    #   - required = <boolean>
    # Verify that function returns ValueError
    #

# Generated at 2022-06-24 20:54:16.090443
# Unit test for function get_bin_path
def test_get_bin_path():
    # Testing for function get_bin_path
    assert test_case_0() == None



# Generated at 2022-06-24 20:54:19.926730
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = -1511.9776
    opt_dirs = []
    required = None
    bin_path = get_bin_path(arg, opt_dirs, required)
    assert bin_path == '/usr/sbin/time'



# Generated at 2022-06-24 20:54:21.504384
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except (TypeError) as e:
        assert False

test_get_bin_path()

# Generated at 2022-06-24 20:54:27.414856
# Unit test for function get_bin_path
def test_get_bin_path():
    # Replace the following values with the expected results of the unit test
    float_0 = -1511.9776
    str_0 = 'Failed to find required executable "-1511.9776" in paths: /usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin:/usr/local/sbin'

    # Perform the unit test
    try:
        get_bin_path(float_0)
    except ValueError as var_0:
        assert str(var_0) == str_0

# Generated at 2022-06-24 20:54:34.692880
# Unit test for function get_bin_path
def test_get_bin_path():
    print("Testing function get_bin_path")

    # Testing function_0
    print("Testing function_0")
    test_case_0()

# Generated at 2022-06-24 20:54:35.595399
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:54:36.521660
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:54:37.077447
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:54:40.407028
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert test_case_0() == '-1511.9776'
    except AssertionError as e:
        print('AssertionError: %s' % e)
    except Exception as e:
        print('Exception: %s' % e)


# Generated at 2022-06-24 20:54:42.003751
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as ex:
        print(ex)

# Generated at 2022-06-24 20:54:45.105582
# Unit test for function get_bin_path
def test_get_bin_path():
    float_0 = -1511.9776
    var_0 = get_bin_path(float_0)
    assert var_0 == '5WY'

# Generated at 2022-06-24 20:54:52.742779
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:54:54.640117
# Unit test for function get_bin_path
def test_get_bin_path():
    (var_0, float_0) = test_case_0()
    assert var_0 == float_0

# Generated at 2022-06-24 20:55:01.944983
# Unit test for function get_bin_path
def test_get_bin_path():
    arg0 = "test_get_bin_path"

    # Call function
    try:
        result = get_bin_path(arg0)
    except ValueError as e:
        if str(e) in 'failed to find executable':
            assert True
        else:
            assert False
    else:
        assert True


# Generated at 2022-06-24 20:55:08.965547
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path(0.0)
    get_bin_path(0)
    get_bin_path(0, [])


# Generated at 2022-06-24 20:55:12.260281
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path({}) is None
    assert get_bin_path(None) is None

# Generated at 2022-06-24 20:55:19.469430
# Unit test for function get_bin_path
def test_get_bin_path():
    function_name = "get_bin_path"
    print("\033[1m{} starting tests...\033[0m".format(function_name))
    print("\033[1m{} running test 1/1...\033[0m".format(function_name))
    assert get_bin_path(1, []) == '/bin/sh'
    assert get_bin_path(1, [], required=1) == '/bin/sh'
    print("\033[1m{} all tests passed.\033[0m".format(function_name))



# Generated at 2022-06-24 20:55:25.916884
# Unit test for function get_bin_path
def test_get_bin_path():
    ansible_module_get_bin_path = dict(
        failed=False,
        changed=True,
        rc=0,
        stderr="",
        stdout="",
        stdout_lines=[],
        stderr_lines=[]
    )
    with pytest.raises(ValueError, match="Missing required argument: required"):
        get_bin_path("name")
    with pytest.raises(ValueError, match="Missing required argument: name"):
        get_bin_path()

    test_case_0()



# Generated at 2022-06-24 20:55:27.109196
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None

# Generated at 2022-06-24 20:55:35.070338
# Unit test for function get_bin_path
def test_get_bin_path():
    float_0 = -1511.9776
    float_1 = 6.6700e-11
    float_2 = -4.9e-324
    float_3 = -1.02e+308
    int_0 = -1887759344
    int_1 = -508317020
    int_2 = -6
    int_3 = -6
    int_4 = -6
    int_5 = -6
    int_6 = -6
    int_7 = -6
    int_8 = -6
    int_9 = -6
    int_10 = -6
    int_11 = -6
    int_12 = -6
    int_13 = -6
    int_14 = -6
    int_15 = -6
    int_16 = -6

# Generated at 2022-06-24 20:55:38.614712
# Unit test for function get_bin_path
def test_get_bin_path():
    float_0 = -1511.9776
    assert('/usr/bin/pow' == get_bin_path(float_0))

# Generated at 2022-06-24 20:55:40.620306
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True == True


# Generated at 2022-06-24 20:55:41.763821
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(get_bin_path) is not None


# Generated at 2022-06-24 20:55:44.039229
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception as e:
        print("exception occured at test_case_0")
        print(e)

# Define function to import ansible module

# Generated at 2022-06-24 20:55:53.362923
# Unit test for function get_bin_path
def test_get_bin_path():
    float_0 = -1511.9776
    opt_dirs = ['/usr/bin', '/opt/bin']
    var_0 = get_bin_path(float_0, opt_dirs)
    assert var_0 == '/usr/bin/-1511.9776'
    float_1 = -1511.9776
    var_1 = get_bin_path(float_1)
    assert var_1 == '/usr/bin/-1511.9776'

# Generated at 2022-06-24 20:55:53.798324
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True


# Generated at 2022-06-24 20:55:59.274491
# Unit test for function get_bin_path
def test_get_bin_path():
    float_0 = -1511.9776
    var_0 = get_bin_path(float_0)
    float_0 = 4007.8656
    var_0 = get_bin_path(float_0)
    float_0 = 4862.3936
    var_0 = get_bin_path(float_0)
    float_0 = -3540.5888
    var_0 = get_bin_path(float_0)
    float_0 = -2742.1408
    var_0 = get_bin_path(float_0)
    float_0 = -2542.8256
    var_0 = get_bin_path(float_0)
    float_0 = -3464.4928
    var_0 = get_bin_path(float_0)
    float_0