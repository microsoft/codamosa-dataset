

# Generated at 2022-06-24 20:45:58.741402
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/mv') == '/usr/bin/mv', "The command get_bin_path returned the wrong value"



# Generated at 2022-06-24 20:46:00.537572
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:46:09.282334
# Unit test for function get_bin_path
def test_get_bin_path():

    import os
    import tempfile

    test_file = 'test_file'

    tmp_dir = tempfile.mkdtemp()

    # test passing the wrong directory
    try:
        get_bin_path(test_file, [tmp_dir])
    except ValueError as e:
        assert 'Failed to find required' in str(e)

    # test passing the right directory
    test_file_abs = os.path.join(tmp_dir, test_file)
    with open(test_file_abs, 'w') as f:
        f.write('#!/bin/sh')

# Generated at 2022-06-24 20:46:12.877743
# Unit test for function get_bin_path
def test_get_bin_path():
    result = get_bin_path('pwd')
    assert result == '/usr/bin/pwd'
    result = get_bin_path('id')
    assert result == '/usr/bin/id'
    result = get_bin_path('timeout')
    assert result == '/usr/bin/timeout'

# Generated at 2022-06-24 20:46:21.750238
# Unit test for function get_bin_path
def test_get_bin_path():
    import argparse

    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--test-coverage', action='store_true',
                        help='Enable code coverage.')

    args, argv = parser.parse_known_args()
    if args.test_coverage:
        try:
            import coverage
            # See also .coveragerc
            COV = coverage.coverage(branch=True, source=['ansible'], omit=['/usr/*', 'ansible/module_utils/*'])
            COV.start()
        except ImportError:
            print('Unable to import coverage module, disabling coverage collection')
            args.test_coverage = False

    # Begin testing
    test_case_0()

    if args.test_coverage:
        COV.stop()

# Generated at 2022-06-24 20:46:24.702002
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Test : # python -m pytest tests/unit/utils/test_module_utils_common_file.py::test_get_bin_path
    '''
    print(test_case_0.__doc__)
    test_case_0()



# Generated at 2022-06-24 20:46:26.050836
# Unit test for function get_bin_path
def test_get_bin_path():
    module_test_case_0()
    # TODO: Write unit tests


# Generated at 2022-06-24 20:46:34.895205
# Unit test for function get_bin_path
def test_get_bin_path():

    # Call get_bin_path with arguments: (arg)
    assert '/bin/ps' == get_bin_path('ps')
    assert '/bin/ps' == get_bin_path('ps')
    # Call get_bin_path with arguments: (arg, None, None)
    assert '/bin/ps' == get_bin_path('ps', None, None)
    # Call get_bin_path with arguments: (arg, None, None)
    assert '/bin/ps' == get_bin_path('ps', None, None)
    # Call get_bin_path with arguments: (arg, None, None)
    assert '/bin/ps' == get_bin_path('ps', None, None)



# Generated at 2022-06-24 20:46:37.552451
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = None
    arg_1 = []
    arg_2 = None
    try:
        get_bin_path(arg_0, opt_dirs=arg_1, required=arg_2)
    except ValueError:
        pass
    else:
        raise AssertionError("ValueError not raised")


# Generated at 2022-06-24 20:46:48.302635
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:46:54.331681
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = None
    opt_dirs_0 = [None]
    required_0 = None
    tuple_0 = (arg_0, opt_dirs_0, required_0)

    var_0 = get_bin_path(*tuple_0)

    assert var_0 == '/bin/echo'

# Generated at 2022-06-24 20:47:04.163530
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = ''
    opt_dirs_0 = None
    required_0 = None
    arg_1 = ''
    opt_dirs_1 = None
    required_1 = None
    arg_2 = ''
    opt_dirs_2 = None
    required_2 = None
    arg_3 = ''
    opt_dirs_3 = None
    required_3 = None
    arg_4 = ''
    opt_dirs_4 = None
    required_4 = None
    arg_5 = ''
    opt_dirs_5 = None
    required_5 = None
    arg_6 = ''
    opt_dirs_6 = None
    required_6 = None
    arg_7 = ''
    opt_dirs_7 = None
    required_7 = None
    arg_8 = ''


# Generated at 2022-06-24 20:47:12.572825
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path("foo"))
    assert(get_bin_path("pip") == "/usr/bin/pip")
    assert(get_bin_path("pip", ["/usr/local/bin"]) == "/usr/local/bin/pip")
    assert(get_bin_path("pip", ["/usr/local/bin", "/bin"]) == "/usr/local/bin/pip")
    assert(get_bin_path("pip", ["/usr/local/bin", "/bin", "/usr/bin"]) == "/usr/bin/pip")



# Generated at 2022-06-24 20:47:22.468229
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as err:
        assert err.args[0] == 'Failed to find required executable "None" in paths: /sbin:/usr/sbin:/usr/local/sbin:/bin:/usr/bin:/usr/local/bin:/usr/local/sbin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/sbin'
    try:
        test_case_1()
    except ValueError as err:
        assert err.args[0] == 'Failed to find required executable "None" in paths: /sbin:/usr/sbin:/usr/local/sbin:/bin:/usr/bin:/usr/local/bin:/usr/local/sbin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/sbin'

# Generated at 2022-06-24 20:47:32.776079
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_1 = None
    var_0 = get_bin_path(tuple_1)
    assert isinstance(var_0, str) == True, 'Expected return value of get_bin_path(tuple_1=None) is <type \'str\'>, got <type \'%s\'>' % type(var_0)
    tuple_2 = None
    var_1 = get_bin_path(tuple_2)
    assert isinstance(var_1, str) == True, 'Expected return value of get_bin_path(tuple_2=None) is <type \'str\'>, got <type \'%s\'>' % type(var_1)
    tuple_3 = None
    var_2 = get_bin_path(tuple_3)
    assert isinstance(var_2, str) == True

# Generated at 2022-06-24 20:47:35.954521
# Unit test for function get_bin_path
def test_get_bin_path():
    cmd = 'ansible-galaxy'
    opt_dirs = None
    required = None
    expected_result = '/usr/bin/ansible-galaxy'
    result = get_bin_path(cmd, opt_dirs, required)
    assert result == expected_result


# Generated at 2022-06-24 20:47:38.214851
# Unit test for function get_bin_path
def test_get_bin_path():
    assert isinstance(get_bin_path("/usr/bin/ansible", [], required=True), str)



# Generated at 2022-06-24 20:47:39.770598
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_0 = None
    var_0 = get_bin_path(tuple_0)

# Generated at 2022-06-24 20:47:41.474047
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception:
        assert False



# Generated at 2022-06-24 20:47:49.127038
# Unit test for function get_bin_path
def test_get_bin_path():
    import os
    import os.path as path
    import random
    import shutil
    import tempfile

# Generated at 2022-06-24 20:47:53.237838
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("wc") is not None
    # TODO add dynamic test case

# Generated at 2022-06-24 20:47:58.199684
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception as err:
        print("FAILED: " + str(err))
        return False
    else:
        print("PASSED")
        return True

if __name__ == '__main__':
    print("Running test for function get_bin_path")
    test_get_bin_path()

# Generated at 2022-06-24 20:47:59.996553
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_0 = None
    result_0 = get_bin_path(tuple_0)
    assert result_0 is None


# Generated at 2022-06-24 20:48:03.985811
# Unit test for function get_bin_path
def test_get_bin_path():
    # Path to a non existing binary
    assert get_bin_path('this_binary_does_not_exist') == 'this_binary_does_not_exist'
    # Path to a regular file
    assert get_bin_path('/etc/hosts') == '/etc/hosts'

# Generated at 2022-06-24 20:48:14.238062
# Unit test for function get_bin_path
def test_get_bin_path():

    paths = ['/bin', '/usr/bin', '/usr/local/bin']
    # pylint: disable=unexpected-keyword-arg
    bin_path = get_bin_path('pwd', opt_dirs=paths)
    assert bin_path == '/bin/pwd'

    # path does not exist
    try:
        # pylint: disable=unexpected-keyword-arg
        bin_path = get_bin_path('pwd', opt_dirs=['this_is_not_a_real_directory'])
    except ValueError as ex:
        expected_msg = "Failed to find required executable \"pwd\" in paths: this_is_not_a_real_directory"
        assert ex.args[0] == expected_msg

    # pylint: disable=unexpected-keyword

# Generated at 2022-06-24 20:48:15.484628
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('true') == '/usr/bin/true'

# Generated at 2022-06-24 20:48:17.599262
# Unit test for function get_bin_path
def test_get_bin_path():
    arg0 = None
    arg1 = None
    arg2 = None
    get_bin_path(arg0, opt_dirs=arg1, required=arg2)



# Generated at 2022-06-24 20:48:18.368001
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None

# Generated at 2022-06-24 20:48:22.684832
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh', ['/bin'], required=True) == '/bin/sh'

# Generated at 2022-06-24 20:48:24.902546
# Unit test for function get_bin_path
def test_get_bin_path():
    module_function_name = 'ansible.module_utils.basic.get_bin_path'
    python_version = '2.7'
    # (1) Test with empty argument
    tuple_0 = None
    var_0 = get_bin_path(tuple_0)

# Generated at 2022-06-24 20:48:34.977473
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_0 = "testfile"
    var_0 = get_bin_path(tuple_0)
    tuple_1 = "testfile"
    var_1 = get_bin_path(tuple_1)
    assert var_0 == "/usr/bin/testfile"
    assert var_0 != "/usr/bin/test"
    assert len(var_1) == 13
    assert len(var_0) == 16

# Generated at 2022-06-24 20:48:37.499024
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_0 = '/bin/sh'
    result = get_bin_path(tuple_0)
    assert result == '/bin/sh'



# Generated at 2022-06-24 20:48:40.849686
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_1 = None
    arg_1 = tuple_1
    tuple_2 = None
    arg_2 = tuple_2
    tuple_3 = None
    arg_3 = tuple_3

    get_bin_path(arg_1, opt_dirs=arg_2, required=arg_3)

# Generated at 2022-06-24 20:48:44.181250
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:48:54.428958
# Unit test for function get_bin_path
def test_get_bin_path():
    total_tests = 1
    failed_tests = 0
    failed_tests_list = []
    test_id = 1

    dict_0 = None
    dict_1 = {}
    dict_2 = {'1': '1'}
    dict_3 = {'2': '2'}
    dict_4 = {'1': '1', '2': '2'}
    dict_5 = {'1': '1', '2': '2', '3': '3'}
    dict_6 = {'3': '3'}
    dict_7 = {'1': '1', '3': '3'}
    dict_8 = {'2': '2', '3': '3'}

# Generated at 2022-06-24 20:48:57.160776
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path("ls")

# Generated at 2022-06-24 20:48:59.949792
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = None
    var_0 = get_bin_path(arg_0)
    assert var_0 is not None

# Generated at 2022-06-24 20:49:01.597997
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except StandardError:
        print('Assertion failed while testing get_bin_path')

# Generated at 2022-06-24 20:49:12.308698
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(None) == None
    assert get_bin_path(None, None) == None
    assert get_bin_path(None, None, None) == None
    assert get_bin_path(None, None, False) == None
    assert get_bin_path(None, None, True) == None
    assert get_bin_path(None, [], None) == None
    assert get_bin_path(None, [], False) == None
    assert get_bin_path(None, [], True) == None
    assert get_bin_path(None, [''], None) == None
    assert get_bin_path(None, [''], False) == None
    assert get_bin_path(None, [''], True) == None

# Generated at 2022-06-24 20:49:13.641140
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:49:21.311150
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Unit test for the get_bin_path function.
    """

    # If this test fails it is because the test environment is not properly
    # set up or because your local or global configuration is incorrect.
    # Ensure that you can successfully execute `which sh` and `sh --version`.

    result = get_bin_path('sh')
    assert result == '/bin/sh'



# Generated at 2022-06-24 20:49:27.981853
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = "/bin/sh"
    arg_1 = None
    arg_2 = None
    test_0 = get_bin_path(arg_0, arg_1, arg_2)
    yield test_0


# Generated at 2022-06-24 20:49:35.144069
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = ['/usr/bin']
    # Change to assertTrue to enable debug logging
    assert isinstance(get_bin_path('ls', paths), str), \
        'get_bin_path("ls", paths) should return an instance of str'
    try:
        get_bin_path('not_found_bin_here')
    except ValueError:
        pass
    else:
        assert False, 'get_bin_path("not_found_bin_here") should raise a ValueError'



# Generated at 2022-06-24 20:49:40.924683
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_0 = 'echo'
    var_0 = get_bin_path(tuple_0)
    if (var_0 == '/bin/echo' or var_0 == '/usr/bin/echo' or var_0 == '/usr/local/bin/echo'):
        print("1st test case")
        test_case_0()
    else:
        print("2nd test case")
        tuple_1 = 'chmod'
        var_1 = get_bin_path(tuple_1)
        if (var_1 == '/bin/chmod' or var_1 == '/usr/bin/chmod' or var_1 == '/usr/local/bin/chmod'):
            print("3rd test case")
            test_case_0()
        else:
            print("4th test case")

test_

# Generated at 2022-06-24 20:49:43.382362
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = None
    assert get_bin_path(arg_0) == None

# Generated at 2022-06-24 20:49:49.207522
# Unit test for function get_bin_path
def test_get_bin_path():
    test_cases = [
        (0,),
    ]
    for index, tc in test_cases:
        print('Testing case #%d' % (index,))
        globals()['test_case_%d' % index]()
        print('Case #%d passed' % (index,))

# Generated from test_101.yaml

# Generated at 2022-06-24 20:49:52.623403
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = "test"
    opt_dirs = None
    required = None
    try:
        ans = get_bin_path(arg, opt_dirs, required)
    except:
        ans = None
    assert ans is None

if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:49:53.484585
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path() == "Hello"

# Generated at 2022-06-24 20:49:59.376847
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        tuple_0 = "get_bin_path"
        var_0 = get_bin_path(tuple_0)
    except ValueError as e:
        var_0 = str(e)
    test_0 = "Failed to find required executable \"get_bin_path\" in paths: "
    test_1 = os.environ.get('PATH', '').split(os.pathsep)
#    assert(test_0 in var_0)

# Generated at 2022-06-24 20:50:00.215088
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path() == "Something bad happened"

# Generated at 2022-06-24 20:50:04.501049
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') != None
    assert get_bin_path('lslslslslslsls') == None
    assert get_bin_path('') is None
    assert get_bin_path(None) is None

# Generated at 2022-06-24 20:50:09.327511
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("/usr/bin/default") == "/usr/bin/default"

# Generated at 2022-06-24 20:50:13.121667
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_0 = None
    tuple_1 = None
    tuple_2 = None
    var_0 = get_bin_path(tuple_0)
    var_1 = get_bin_path(tuple_1, tuple_2)

# Generated at 2022-06-24 20:50:16.702811
# Unit test for function get_bin_path
def test_get_bin_path():
    required = None

    # pass in valid arguments

    ret_0 = get_bin_path('awk', None, required)
    expected_0 = '/usr/bin/awk'

    ret_1 = get_bin_path('ls', None, required)
    expected_1 = '/bin/ls'

    ret_2 = get_bin_path('iptables', None, required)
    expected_2 = '/sbin/iptables'

    assert ret_0 == expected_0, "got {}, expected {}".format(ret_0, expected_0)
    assert ret_1 == expected_1, "got {}, expected {}".format(ret_1, expected_1)
    assert ret_2 == expected_2, "got {}, expected {}".format(ret_2, expected_2)


# Generated at 2022-06-24 20:50:18.353730
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:50:20.135930
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_0 = None
    var_0 = get_bin_path(tuple_0)
    assert var_0 == None

# Generated at 2022-06-24 20:50:20.979044
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True == True
#

# Generated at 2022-06-24 20:50:23.951842
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = None
    opt_dirs = None
    required = None

    # Invoke module
    result = get_bin_path(arg, opt_dirs, required)

# The following added to ensure 100% code coverage,
#  even though it is not strictly necessary

# Generated at 2022-06-24 20:50:25.196174
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_0 = None
    var_0 = get_bin_path(tuple_0)



# Generated at 2022-06-24 20:50:29.109840
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:50:36.592874
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:50:42.627415
# Unit test for function get_bin_path
def test_get_bin_path():
    # Note that the function get_bin_path has new arguments
    # and the old tests do not include them
    # assert get_bin_path('/bin/sh') == '/bin/sh'
    # assert get_bin_path('sh') == '/bin/sh'
    # assert get_bin_path('this_does_not_exist') == ''
    # assert get_bin_path('this_does_not_exist', required=False) == ''
    # assert get_bin_path('this_does_not_exist', required=False) == ''
    pass



# Generated at 2022-06-24 20:50:49.237331
# Unit test for function get_bin_path
def test_get_bin_path():
    # Setup the call_function arguments
    arg = 'test'
    opt_dirs = None
    required = None
    try:
        get_bin_path(arg, opt_dirs, required)
    except ValueError as e:
        assert(str(e) == 'Failed to find required executable "test" in paths: /bin:/usr/bin:/usr/local/bin')



# Generated at 2022-06-24 20:50:50.882971
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_0 = None
    var_1 = get_bin_path(tuple_0)

# Generated at 2022-06-24 20:50:59.719422
# Unit test for function get_bin_path
def test_get_bin_path():
    # Path to the file to be loaded
    INPUT_FILE = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))),
        "test",
        "unit",
        "common",
        "files",
        "test_files",
        "test_file_0.txt"
    )

    # Test if path_or_buf points to a file that exists
    assert os.path.exists(INPUT_FILE)

    tuple_0 = None
    var_0 = get_bin_path(tuple_0)

    tuple_0 = None
    var_1 = get_bin_path(tuple_0, None)

    tuple_0 = None

# Generated at 2022-06-24 20:51:02.727819
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('ifconfig')
    except (OSError, ValueError) as e:
        assert False, "function get_bin_path raised " + type(e).__name__ + " for valid input" 



# Generated at 2022-06-24 20:51:06.083695
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)
    raise Exception("Test not implemented")


# Generated at 2022-06-24 20:51:07.292087
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == get_bin_path(('ls'))  # Test #0

# Generated at 2022-06-24 20:51:16.380842
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_1 = None
    var_2 = 'lspci'
    tuple_3 = None
    tuple_4 = None
    try:
        get_bin_path(tuple_1, tuple_3, tuple_4)
    except ValueError as var_5:
        if (var_5.args == ('Failed to find required executable "None" in paths: %s' % os.pathsep.join([]),)):
            tuple_6 = None
            tuple_7 = None
            tuple_8 = None

# Generated at 2022-06-24 20:51:17.520257
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)



# Generated at 2022-06-24 20:51:20.166785
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:51:25.825576
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_0 = None
    tuple_1 = None
    tuple_2 = None
    try:
        get_bin_path(tuple_0)
        get_bin_path(tuple_1, tuple_2)
    except Exception as e:
        print('Caught exception: ' + str(e))


# Generated at 2022-06-24 20:51:28.932326
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception as exc:
        assert isinstance(exc, ValueError)


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:51:37.208479
# Unit test for function get_bin_path
def test_get_bin_path():
    arg0 = None
    arg1 = None
    arg2 = None
    expected_result = None
    # Call the function
    result = get_bin_path(arg0, arg1, arg2)
    assert result == expected_result
    # More tests with different arguments
    expected_result = None
    # Call the function
    result = get_bin_path(arg0, arg1, arg2)
    assert result == expected_result
    expected_result = None
    # Call the function
    result = get_bin_path(arg0, arg1, arg2)
    assert result == expected_result



# Generated at 2022-06-24 20:51:45.611970
# Unit test for function get_bin_path
def test_get_bin_path():
    # No exception is raised
    get_bin_path('/usr/bin/python')
    # Exception is raised
    with pytest.raises(ValueError):
        get_bin_path('/usr/bin/python', required=True)
    # No exception is raised
    get_bin_path('/usr/bin/python', required=False)
    # No exception is raised
    get_bin_path('/usr/bin/python', opt_dirs=['/usr/local/bin'])
    # No exception is raised
    get_bin_path('/usr/bin/python', opt_dirs=['/usr/local/bin'], required=False)

# Generated at 2022-06-24 20:51:51.402808
# Unit test for function get_bin_path
def test_get_bin_path():
    # Make sure the expected exceptions are raised
    with pytest.raises(Exception):
        get_bin_path(None)
    with pytest.raises(Exception):
        get_bin_path(dict())
    with pytest.raises(Exception):
        get_bin_path('')

# Generated at 2022-06-24 20:52:00.962791
# Unit test for function get_bin_path
def test_get_bin_path():
    # Calling get_bin_path with argument tuple_0 that has length 1
    tuple_0 = b"ansible"
    var_0 = get_bin_path(tuple_0)
    # Calling get_bin_path with argument tuple_0 that has length 1
    tuple_0 = b"ansible"
    var_0 = get_bin_path(tuple_0)
    # Calling get_bin_path with argument tuple_0 that has length 1
    tuple_0 = b"ansible"
    var_0 = get_bin_path(tuple_0)
    # Calling get_bin_path with argument tuple_0 that has length 1
    tuple_0 = b"ansible"
    var_0 = get_bin_path(tuple_0)
    # Calling get_bin_path with argument tuple_0 that has

# Generated at 2022-06-24 20:52:02.552642
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = None
    assert get_bin_path(arg_0) == None



# Generated at 2022-06-24 20:52:04.613516
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = None
    opt_dirs_0 = None
    required_0 = None
    assert get_bin_path(arg_0, opt_dirs_0, required_0)

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-24 20:52:07.010505
# Unit test for function get_bin_path
def test_get_bin_path():
    result = get_bin_path("/usr/bin/python")
    len = result.__len__()
    assert len != 0

# Generated at 2022-06-24 20:52:14.391435
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_0 = None
    var_0 = get_bin_path(tuple_0)
    var_1 = get_bin_path(tuple_0, var_0, False)
    var_2 = get_bin_path(tuple_0, var_0, True)
    var_3 = get_bin_path(tuple_0, var_0, True)
    assert var_0 == var_1 and var_1 == var_2 and var_2 == var_3

# Generated at 2022-06-24 20:52:22.121183
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path(arg=None, opt_dirs=None, required=None)
    var_1 = get_bin_path(arg=None, opt_dirs=None, required=None)
    try:
        var_2 = get_bin_path(arg=None, opt_dirs=None, required=None)
    except ValueError:
        pass
    var_3 = get_bin_path(arg=None, opt_dirs=None, required=None)
    try:
        var_4 = get_bin_path(arg=None, opt_dirs=None, required=None)
    except ValueError:
        pass



# Generated at 2022-06-24 20:52:26.797265
# Unit test for function get_bin_path
def test_get_bin_path():
    # Establish that get_bin_path raises a TypeError for non-string args
    with pytest.raises(TypeError):
        tuple_0 = None
        get_bin_path(tuple_0)


# Run unit tests for function get_bin_path
test_case_0()

# Generated at 2022-06-24 20:52:28.245325
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_0 = None
    var_0 = get_bin_path(tuple_0)

# Generated at 2022-06-24 20:52:33.662117
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('hostname') is not None

# Generated at 2022-06-24 20:52:40.308204
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        tuple_0 = None
        # get_bin_path(self, tuple_0, opt_dirs=None, required=None)
        get_bin_path(tuple_0)
    except ValueError as var_0:
        print("ValueError")
        print(var_0)
        raise

#
# Helper function for the get_bin_path.
#

# Generated at 2022-06-24 20:52:47.794376
# Unit test for function get_bin_path
def test_get_bin_path():
    # This will detect the presence of the Bash command on the system
    tuple_0 = 'bash'
    var_0 = get_bin_path(tuple_0)
    print(var_0)
    # This will detect the presence of the Python command on the system
    tuple_0 = 'python'
    var_0 = get_bin_path(tuple_0)
    print(var_0)
    # This will raise an exception
    tuple_0 = 'command_that_does_not_exist'
    var_0 = get_bin_path(tuple_0)
    print(var_0)


# Generated at 2022-06-24 20:52:49.655543
# Unit test for function get_bin_path
def test_get_bin_path():
    expected = 'hello world'
    actual = 'goodbye cruel world'
    assert expected == actual

# Test for function get_bin_path

# Generated at 2022-06-24 20:52:54.102238
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') != None


# Generated at 2022-06-24 20:52:55.179497
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(tuple_0) == Var_0


# Generated at 2022-06-24 20:53:03.688296
# Unit test for function get_bin_path
def test_get_bin_path():
    print("(%s) Starting tests for %s" % (__file__, __name__))
    os.chdir(os.path.dirname(__file__))
    test_case_0()
    print("(%s) Completed tests for %s" % (__file__, __name__))


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:53:04.998247
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(None) != ''

# Generated at 2022-06-24 20:53:06.552895
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')


# Generated at 2022-06-24 20:53:07.078780
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:53:09.296295
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_0 = None
    opt_dirs_0 = None
    required_0 = None
    test_case_0()



# Generated at 2022-06-24 20:53:18.860795
# Unit test for function get_bin_path
def test_get_bin_path():
    # This can be used to mock the get_bin_path function
    def _mock_get_bin_path(arg, opt_dirs=None, required=None):
        return os.path.join(os.path.dirname(__file__), 'fixtures', arg)

    import sys

    saved_get_bin_path = sys.modules['ansible.module_utils.common.file.get_bin_path']
    sys.modules['ansible.module_utils.common.file.get_bin_path'] = _mock_get_bin_path


# Generated at 2022-06-24 20:53:20.498218
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as includeExc:
        assert "Failed to find required executable" in includeExc.__str__()

# Generated at 2022-06-24 20:53:25.738365
# Unit test for function get_bin_path
def test_get_bin_path():
    # Pass in an non-executable file
    file_name = 'README.md'
    bin_path = get_bin_path(file_name)
    assert is_executable(bin_path)
    assert os.path.basename(bin_path) == file_name

    # Pass in an executable file that does not exist locally
    file_name = 'ssh'
    bin_path = get_bin_path(file_name)
    assert is_executable(bin_path)
    assert os.path.basename(bin_path) == file_name


if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:53:28.247634
# Unit test for function get_bin_path
def test_get_bin_path():
    executable = 'pip'
    result = get_bin_path(executable)
    assert result is not None, "No value returned for %s" % executable



# Generated at 2022-06-24 20:53:32.884506
# Unit test for function get_bin_path
def test_get_bin_path():
    assert not get_bin_path('df', required=False), 'Failure in testmock0'
    assert not get_bin_path('df', required=True), 'Failure in testmock1'
    assert not get_bin_path('df', required=True), 'Failure in testmock2'


# Test cases for function get_bin_path

# Generated at 2022-06-24 20:53:42.452778
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)
    # List of tuples
    tuple_0 = None
    tuple_1 = ('optional_dir', tuple_0)
    tuple_2 = ('required', True)
    tuple_3 = ('required', False)
    # Create a list of tuples
    tuples = [tuple_1, tuple_2, tuple_3]
    for t in tuples:
        assert isinstance(t, tuple)
    var_0 = get_bin_path(tuple_0)

# Generated at 2022-06-24 20:53:51.328391
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = None
    opt_dirs = None
    required = None
    retval = get_bin_path(arg, opt_dirs, required)
    assert retval is None
    arg = None
    opt_dirs = None
    required = None
    retval = get_bin_path(arg, opt_dirs, required)
    assert retval is None
    arg = 'ping'
    opt_dirs = None
    required = None
    retval = get_bin_path(arg, opt_dirs, required)
    assert retval is None
    arg = 'ping'
    opt_dirs = None
    required = None
    retval = get_bin_path(arg, opt_dirs, required)
    assert retval is None
    arg = 'ping'
    opt_dirs = []


# Generated at 2022-06-24 20:53:52.695414
# Unit test for function get_bin_path
def test_get_bin_path():
    # Make sure that the function returns a value
    assert get_bin_path('sh')



# Generated at 2022-06-24 20:53:53.052896
# Unit test for function get_bin_path
def test_get_bin_path():
    pass



# Generated at 2022-06-24 20:53:56.378524
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("which") == "/usr/bin/which"
    try:
        get_bin_path("this_cmd_doesnt_exist")
    except ValueError:
        assert True
    try:
        get_bin_path("ls", ["/usr/bin/"])
    except ValueError:
        assert True

# Generated at 2022-06-24 20:53:57.223830
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sudo') is not None

# Generated at 2022-06-24 20:53:58.442995
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = None
    arg_1 = None
    with pytest.raises(ValueError):
        get_bin_path(arg_0, arg_1)

# Generated at 2022-06-24 20:54:07.877258
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/python') == '/usr/bin/python'
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', ['/usr/local/bin']) == '/usr/local/bin/python'
    assert get_bin_path('this_does_not_exist') == None
    assert get_bin_path('this_does_not_exist', ['/usr/local/bin']) == None
    assert get_bin_path('./this_does_not_exist') == None
    #assert get_bin_path('/etc') == None
    assert get_bin_path('/etc', ['/usr/local/bin']) == None

# Generated at 2022-06-24 20:54:13.131519
# Unit test for function get_bin_path
def test_get_bin_path():
    print('Function get_bin_path executed')
    assert get_bin_path(None)


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:54:17.743105
# Unit test for function get_bin_path
def test_get_bin_path():
    assertion_0 = False
    try:
        test_case_0()
    except ValueError:
        assertion_0 = True
    assert assertion_0 == True, "Failed: ValueError not raised"


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:54:29.612936
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_0 = None
    var_0 = get_bin_path(tuple_0)
    tuple_1 = None
    var_1 = get_bin_path(tuple_1)
    tuple_2 = None
    var_2 = get_bin_path(tuple_2)
    tuple_3 = None
    var_3 = get_bin_path(tuple_3)
    tuple_4 = None
    var_4 = get_bin_path(tuple_4)
    tuple_5 = None
    var_5 = get_bin_path(tuple_5)
    tuple_6 = None
    var_6 = get_bin_path(tuple_6)
    tuple_7 = None
    var_7 = get_bin_path(tuple_7)
    tuple_8 = None


# Generated at 2022-06-24 20:54:31.513669
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() is None
    assert 'crm' in get_bin_path('crm')


# Generated at 2022-06-24 20:54:35.033772
# Unit test for function get_bin_path
def test_get_bin_path():
    paths = '/usr/bin:/usr/bin'
    opt_dirs = paths.split(':')
    arg = '/bin/sed'
    var_0 = get_bin_path(arg, opt_dirs=opt_dirs)

# Generated at 2022-06-24 20:54:40.680394
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == os.path.abspath('/bin/ls')

# Generated at 2022-06-24 20:54:43.393489
# Unit test for function get_bin_path
def test_get_bin_path():
    print("Testing for expected exceptions")
    try:
        test_case_0()
    except TypeError:
        pass


# Generated at 2022-06-24 20:54:47.824406
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with tuple_0,
    test_case_0()
    # Test with tuple_1,
    # Test with tuple_2,
    # Test with tuple_3,



# Generated at 2022-06-24 20:54:55.048459
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    This function tests that function get_bin_path correctly returns the
    full path of a command, given its basename and optional directories to
    search.
    """
    # Test the command "which".
    # Test the command "which" with a list of optional directories including a directory
    # that contains the command.
    # Test the command "which" with a list of optional directories that does not include
    # a directory that contains the command.

# Generated at 2022-06-24 20:55:05.950933
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(None)

    assert get_bin_path('python')

    assert get_bin_path('python', ['/tmp/'])

    assert get_bin_path('python', ['/tmp/'], True)

    try:
        get_bin_path('python_NOT_FOUND_ON_PURPOSE')
        raise Exception('Should have raised ValueError when executable is not found')
    except:
        pass

    try:
        get_bin_path('python_NOT_FOUND_ON_PURPOSE', ['/tmp/'])
        raise Exception('Should have raised ValueError when executable is not found')
    except:
        pass


# Generated at 2022-06-24 20:55:14.367418
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as e:
        assert True
    else:
        assert False
# Test name: test_get_bin_path
# Failing on: Python 2.7.17, Python 3.5.5, Python 3.6.2
# Developer notes:
# ######################################################################################################################

# Start of of test-case test_get_bin_path #
    # Check for the existence of executable /sbin/ip
    # On success return the full path else raise ValueError
    try:
        opt_dirs = ['/sbin', '/bin', '/usr/sbin', '/usr/bin']
        assert '/sbin/ip' == get_bin_path('ip', opt_dirs)
    except ValueError as e:
        assert True

# Generated at 2022-06-24 20:55:16.602543
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_0 = None
    var_0 = get_bin_path(tuple_0)


# Generated at 2022-06-24 20:55:26.610023
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = ''
    opt_dirs = None
    required = True
    # Find system executable in PATH. Raises ValueError if executable is not found.
    # Optional arguments:
    #   - required:  [Deprecated] Prior to 2.10, if executable is not found and required is true it raises an Exception.
    #                In 2.10 and later, an Exception is always raised. This parameter will be removed in 2.14.
    #   - opt_dirs:  optional list of directories to search in addition to PATH
    # If found return full path, otherwise raise ValueError.
    assert get_bin_path(arg, opt_dirs, required)

# Generated at 2022-06-24 20:55:34.301264
# Unit test for function get_bin_path
def test_get_bin_path():
    tuple_0 = None
    tuple_1 = None
    # [Deprecated] All optional arguments must be defined, or a TypeError is raised.
    # The optional arguments will be removed in Ansible 2.14
    var_0 = get_bin_path(tuple_0, tuple_1)
    assert var_0 == '/usr/bin/hostname'

    tuple_0 = None
    tuple_1 = None
    tuple_2 = None
    # [Deprecated] All optional arguments must be defined, or a TypeError is raised.
    # The optional arguments will be removed in Ansible 2.14
    var_0 = get_bin_path(tuple_0, tuple_1, tuple_2)
    assert var_0 == '/usr/bin/hostname'

# Generated at 2022-06-24 20:55:37.674315
# Unit test for function get_bin_path
def test_get_bin_path():
    res = get_bin_path('/usr/bin/vim', ['', '/usr/bin'])
    assert res == '/usr/bin/vim'

# Generated at 2022-06-24 20:55:46.061250
# Unit test for function get_bin_path
def test_get_bin_path():
    # object
    test_object_0 = {}
    test_object_0['kwargs'] = {}
    test_object_0['kwargs']['opt_dirs'] = os.path.dirname(os.path.realpath(__file__))
    test_object_0['kwargs']['required'] = False

    test_object_0['args'] = './test_file_path'

    test_object_0['answer'] = os.path.realpath(__file__)


    # object
    test_object_1 = {}
    test_object_1['kwargs'] = {}
    test_object_1['kwargs']['opt_dirs'] = os.path.dirname(os.path.realpath(__file__))
    test_object_1['kwargs']['required']

# Generated at 2022-06-24 20:55:53.954977
# Unit test for function get_bin_path
def test_get_bin_path():
    # if not isinstance(arg, list):
    #     print('Expected argument of type list')
    #     assert(False)

    print('Test 0: expected failure')
    try:
        test_case_0()
    except ValueError as e:
        print('Exception raised as expected')
    print('Test 0: passed')

    # if not isinstance(opt_dirs, list):
    #     print('Expected argument of type list')
    #     assert(False)

    # if required is not None and not isinstance(required, bool):
    #     print('Expected argument of type bool')
    #     assert(False)

    # if not isinstance(bin_path, bool):
    #     print('Expected return value of type bool')
    #     assert(False)

    print('Test complete')