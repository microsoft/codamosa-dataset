

# Generated at 2022-06-24 20:46:01.062780
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


# Test case 2

# Generated at 2022-06-24 20:46:06.737050
# Unit test for function get_bin_path
def test_get_bin_path():
    # Replace assert with appropriate code to verify exceptions when expected
    str_0 = 'jPhi/]0)vG|SgWe%e~'
    str_1 = get_bin_path(str_0)
    assert(str_1 == 'jPhi/]0)vG|SgWe%e~')
#    str_1 = get_bin_path(str_0, str_0)
#    assert(str_1 == 'jPhi/]0)vG|SgWe%e~')
#    str_1 = get_bin_path(str_0, str_0, str_0)
#    assert(str_1 == 'jPhi/]0)vG|SgWe%e~')
#    str_1 = get_bin_path(str_0, str_0,

# Generated at 2022-06-24 20:46:10.160559
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as err:
        assert str(err) == 'Failed to find required executable "jPhi/]0)vG|SgWe%e~" in paths: jPhi/]0)vG|SgWe%e~'

# Generated at 2022-06-24 20:46:18.413662
# Unit test for function get_bin_path
def test_get_bin_path():
    # str_0 = 'jPhi/]0)vG|SgWe%e~'
    # var_0 = get_bin_path(str_0, str_0)
    str_0 = 'jPhi/]0)vG|SgWe%e~'
    str_1 = '/opt/stack/new/venvs/swift-2.19.0/bin/swift'
    str_2 = '/usr/bin/swift'
    assert get_bin_path(str_0) == str_1
    assert get_bin_path(str_0, '/opt/stack/new/venvs/swift-2.19.0/bin/') == str_2

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:46:19.460626
# Unit test for function get_bin_path
def test_get_bin_path():
    assert isinstance(get_bin_path, object)

# Generated at 2022-06-24 20:46:21.155762
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:46:21.876648
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:46:26.562153
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4*iU6wqUQ0yv!_F! '
    var_0 = get_bin_path(str_0)
    str_1 = 'Oo^?@'
    var_1 = get_bin_path(str_0, str_1)
    str_2 = 'z`tD&L1{a)X^'
    var_2 = get_bin_path(str_0, str_1, str_2)


# Generated at 2022-06-24 20:46:33.177757
# Unit test for function get_bin_path
def test_get_bin_path():
    path = '/usr/bin/something'
    path_mock = MagicMock(return_value=path)
    opt_dirs = []
    executable = 'something'
    with patch('os.path.exists', path_mock):
        assert get_bin_path(executable, opt_dirs) == path
    assert path_mock.call_count == 2
        


# Generated at 2022-06-24 20:46:35.563449
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-24 20:46:49.150300
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = 'some_directory/some_executable'

    paths = ['some_directory', 'some_other_directory']
    expected_0 = 'some_directory/some_executable'
    actual_0 = get_bin_path(bin_path, paths)
    assert expected_0 == actual_0

    paths = ['non_existent_directory', 'some_other_directory']
    try:
        actual_1 = get_bin_path(bin_path, paths)
    except ValueError:
        pass
    else:
        assert False, 'Expected to fail with ValueError'

    expected_2 = 'some_directory/some_executable'
    actual_2 = get_bin_path(bin_path)
    assert expected_2 == actual_2


# Generated at 2022-06-24 20:46:54.027447
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)

# Generated at 2022-06-24 20:46:54.909635
# Unit test for function get_bin_path
def test_get_bin_path():
    print('Test get_bin_path()')
    test_case_0()

# Generated at 2022-06-24 20:47:02.440224
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = 'mock_get_bin_path'

    paths = ['/tmp']
    expected = os.path.join(paths[0], arg)

    os.makedirs(paths[0])
    with open(expected, 'w'):
        pass

    result = get_bin_path(arg, paths)

    assert result == expected
    os.unlink(result)
    os.rmdir(paths[0])



# Generated at 2022-06-24 20:47:13.902661
# Unit test for function get_bin_path
def test_get_bin_path():
    assert ('_([1$fYG~AjP\x7f^o' == get_bin_path('_([1$fYG~AjP\x7f^o', '4b]WZK36`TbT,G'))
    assert ('W|-v>t\x7fUt,VK2N' == get_bin_path('W|-v>t\x7fUt,VK2N', 'Ns-L\x7f^aAOwG,g'))
    assert ('e%\"\x7f6U"R#U!G"c' == get_bin_path('e%\"\x7f6U"R#U!G"c', '^\x7fqTQT1E@ZaS'))

# Generated at 2022-06-24 20:47:16.311383
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path('bar', '/foo')
    assert var_0 == '/foo/bar'


# Generated at 2022-06-24 20:47:18.617235
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError:
        pass

import argparse
import sys


# Generated at 2022-06-24 20:47:20.036531
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python')


test_case_0()

# Generated at 2022-06-24 20:47:21.976093
# Unit test for function get_bin_path
def test_get_bin_path():
    # test case 0
    test_case_0()


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:47:27.474362
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(arg)
    assert get_bin_path(arg, opt_dirs)
    assert get_bin_path(arg, opt_dirs, required)
    assert get_bin_path(arg, None, required)
    assert get_bin_path(arg, None, True)

# Generated at 2022-06-24 20:47:33.648787
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('date') == '/bin/date'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    try:
        get_bin_path('this_is_not_the_path_you_are_looking_for')
        assert False, 'This command should not have succeeded'
    except ValueError:
        pass

# Generated at 2022-06-24 20:47:41.724663
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = None
    str_1 = 'r[B5x1u5?5+X7'
    get_bin_path(str_0)
    get_bin_path(str_0, True)
    get_bin_path(str_0, False)
    get_bin_path(str_1)
    get_bin_path(str_1, True)
    get_bin_path(str_1, False)



if __name__ == '__main__':
    import pytest
    pytest.main('-s -v %s' % __file__)

# Generated at 2022-06-24 20:47:49.335637
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = '/bin'
    var_1 = '/bin'
    var_2 = 'n1=Q`&V7A5X[>5D5e$'
    var_3 = 'non-existent'
    var_4 = 'test'
    var_5 = 'command'
    var_6 = 'does-not-exist'
    var_7 = 'should-not-exist'
    # Function call
    var_8 = get_bin_path(var_2)
    assert var_8 == var_4
    # Test for Exception
    try:
        var_9 = get_bin_path(var_3)
    except ValueError as e:
        var_10 = str(e)
        assert var_10 == var_5
        var_11 = True
    else:
        var_11

# Generated at 2022-06-24 20:47:56.379319
# Unit test for function get_bin_path
def test_get_bin_path():
    arg1 = None  # Stub
    arg2 = None  # Stub
    arg3 = None  # Stub
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-24 20:47:59.007010
# Unit test for function get_bin_path
def test_get_bin_path():
    # no exceptions should be raised
    try:
        test_case_0()
    except BaseException as e:
        raise e

# Generated at 2022-06-24 20:48:02.357643
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError:
        return True
    return False

# Generated at 2022-06-24 20:48:09.712236
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'XZr'
    str_1 = 'dJ-P'

# Generated at 2022-06-24 20:48:16.696934
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '0)xCddG#X'
    var_0 = get_bin_path(str_0)
    str_1 = 'vN<lN1|$Y6kD'
    str_2 = ';/8'
    str_3 = 'MpK1f'
    var_1 = get_bin_path(str_3, [str_0, str_1, str_2])

if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:48:18.651563
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('nonexistant') == None



# Generated at 2022-06-24 20:48:23.736407
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('wc', str_0)

# Generated at 2022-06-24 20:48:27.434449
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 'x' == get_bin_path('x', ['/bin'])
    assert 'bin/x' == get_bin_path('x', ['bin'])

# Generated at 2022-06-24 20:48:27.984418
# Unit test for function get_bin_path
def test_get_bin_path():
    assert False
    #get_bin_path()

# Generated at 2022-06-24 20:48:30.302670
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


if '__main__' == __name__:
    test_get_bin_path()

# Generated at 2022-06-24 20:48:34.368102
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 'RHEL_VSFTPD' == get_bin_path('RHEL_VSFTPD', ['RHEL_VSFTPD'])
    assert 'RHEL_VSFTPD' == get_bin_path('RHEL_VSFTPD', ['RHEL_VSFTPD', 'RHEL_VSFTPD'])
    assert 'RHEL_VSFTPD' == get_bin_path('RHEL_VSFTPD', ['RHEL_VSFTPD', 'RHEL_VSFTPD', 'RHEL_VSFTPD'])
    assert 'RHEL_VSFTPD' == get_bin_path('RHEL_VSFTPD', ['RHEL_VSFTPD', 'RHEL_VSFTPD', 'RHEL_VSFTPD', 'RHEL_VSFTPD'])
    assert 'RHEL_VSFTPD' == get_bin_

# Generated at 2022-06-24 20:48:37.617200
# Unit test for function get_bin_path
def test_get_bin_path():
    # Mock module input values
    opt_dirs = ['opt_dirs']
    arg_0 = 'arg_0'

    bin_path = get_bin_path(arg_0, opt_dirs)
    assert(bin_path)

# Generated at 2022-06-24 20:48:44.484953
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('python')
    assert os.path.exists(path) and is_executable(path)

    path = get_bin_path('python', ['/usr/bin'])
    assert os.path.exists(path) and is_executable(path)

    path = get_bin_path('python', ['/usr/bin', '/bin'])
    assert os.path.exists(path) and is_executable(path)

    path = get_bin_path('python', ['/usr/bin', '/bin', '/'])
    assert os.path.exists(path) and is_executable(path)

    path = get_bin_path('python', ['/usr/bin', '/bin', '/', None])

# Generated at 2022-06-24 20:48:49.310477
# Unit test for function get_bin_path
def test_get_bin_path():

    var_0 = 'X9:y3V/'
    var_1 = []
    var_2 = test_case_0(var_0, var_1, var_1)

if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:48:50.126227
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True == True


# Generated at 2022-06-24 20:48:54.333812
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '{3q$' + '`Y'
    var_0 = get_bin_path(str_0)
    assert var_0 == '/bin/{3q$`Y', "Get bin path failed on /bin/{3q$`Y"

# Generated at 2022-06-24 20:48:57.944363
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('get_bin_path') is not None

# Generated at 2022-06-24 20:49:05.115083
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/python') == '/usr/bin/python'


"""
Requires:

- pip install passlib

"""

# Generated at 2022-06-24 20:49:15.134661
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'rI=PJ9t.b)`8R`I+H'
    str_1 = '^D\x7fZS&^<5\x1b\x1b'
    str_2 = ')'
    str_3 = '6Z^c*eLP2'
    str_4 = '7*u!k>+Vdw0'
    str_5 = '6Z^c*eLP2'
    str_6 = '6Z^c*eLP2'
    str_7 = '6Z^c*eLP2'
    str_8 = '6Z^c*eLP2'
    str_9 = '6Z^c*eLP2'
    str_10 = '6Z^c*eLP2'

# Generated at 2022-06-24 20:49:25.312951
# Unit test for function get_bin_path
def test_get_bin_path():
    assert ['G', '8', 's'] == get_bin_path('G8s', ['G', '8', 's'])
    assert ['0', 'd', 'g'] == get_bin_path('0dg', ['0', 'd', 'g'])
    assert ['j', '+', 'C'] == get_bin_path('j+C', ['j', '+', 'C'])
    assert ['k', 'w', 's'] == get_bin_path('kws', ['k', 'w', 's'])
    assert ['d', '^', '}'] == get_bin_path('d^}', ['d', '^', '}'])
    assert ['N', 'w', 'j'] == get_bin_path('Nwj', ['N', 'w', 'j'])

# Generated at 2022-06-24 20:49:29.720267
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'aveI;B]-f#M!Oy!0@'
    var_0 = get_bin_path(str_0)


if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:49:34.264232
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:49:36.048168
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/python') == '/usr/bin/python'



# Generated at 2022-06-24 20:49:41.619241
# Unit test for function get_bin_path
def test_get_bin_path():
    print('start of test_get_bin_path function')

    test_case_0()

    print('end of test_get_bin_path function')

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:49:43.123247
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True
# vim:cc=80

# Generated at 2022-06-24 20:49:48.417539
# Unit test for function get_bin_path
def test_get_bin_path():
    assert os.path.exists(get_bin_path('ls'))
    assert not os.path.exists(get_bin_path('does-not-exist'))

# Generated at 2022-06-24 20:49:52.517093
# Unit test for function get_bin_path
def test_get_bin_path():

    # Var declaration
    str_0 = 'jPhi/]0)vG|SgWe%e~'
    var_1 = get_bin_path(str_0, str_0)
    var_3 = get_bin_path("foo", str_0, str_0)

    return

# Generated at 2022-06-24 20:49:56.375757
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path('tr')
    assert var_0 == '/bin/tr'


# Generated at 2022-06-24 20:50:07.186692
# Unit test for function get_bin_path
def test_get_bin_path():

    # Test for simple string
    str_1 = 'jPhi/]0)vG|SgWe%e~'
    str_2 = get_bin_path(str_1)
    assert str_2 == str_1

    # Test for str with path separators
    str_3 = 'jPhi/]0)vG|SgWe%e~'
    str_4 = 'jPhi/]0)vG|SgWe%e~'
    str_5 = get_bin_path(str_3, str_4)
    assert str_5 == os.path.join(str_3, str_4)

    # Test for simple string
    str_6 = 'jPhi/]0)vG|SgWe%e~'

# Generated at 2022-06-24 20:50:08.117822
# Unit test for function get_bin_path
def test_get_bin_path():
    with pytest.raises(SystemExit):
        test_case_0()

# Generated at 2022-06-24 20:50:14.182929
# Unit test for function get_bin_path
def test_get_bin_path():
    with pytest.raises(ValueError) as excinfo:
        test_case_0()
    the_exception = excinfo.value
    assert the_exception.args[0] == 'Failed to find required executable "jPhi/]0)vG|SgWe%e~" in paths: /bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin'


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:50:20.939078
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/pwd') == '/usr/bin/pwd'
    assert get_bin_path('/usr/bin/pwd', ['/bin']) == '/usr/bin/pwd'
    assert get_bin_path('../foo', ['/bin']) == '../foo'
    assert get_bin_path('../foo', ['/bin']) == '../foo'
    assert get_bin_path('pwd', ['/bin']) == '/bin/pwd'
    test_case_0()


# Generated at 2022-06-24 20:50:26.902114
# Unit test for function get_bin_path
def test_get_bin_path():
    # Assert argument 1 -> arg
    # Assert argument 2 -> opt_dirs
    # Assert argument 3 -> value of required
    # Return type: string
    assert isinstance(get_bin_path(arg=None, opt_dirs=None), str)
    # Raise ValueError if executable is not found -> error
    # Return type: None
    # Execute function with arguments:
    #   arg: 'jPhi/]0)vG|SgWe%e~'
    #   opt_dirs: 'jPhi/]0)vG|SgWe%e~'
    #   required: Undefined

# Generated at 2022-06-24 20:50:28.371755
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('TypeA') == 'D:/Python/Python36-32/python.exe'

# Generated at 2022-06-24 20:50:34.110888
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert get_bin_path('no good', '/usr/bin')
        assert True
    except ValueError:
        assert False

    try:
        assert get_bin_path('no good', '/usr/bin', ['/usr/bin'])
        assert True
    except ValueError:
        assert False

    try:
        assert get_bin_path('sh')
        assert True
    except ValueError:
        assert False

if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:50:37.472008
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == 'C:\\Program Files\\Anaconda3\\python.exe', "test_case_0 failed"


if __name__ == '__main__':
    a = get_bin_path('git', 'git')
    print(a)
    # test_get_bin_path()

# Generated at 2022-06-24 20:50:40.077649
# Unit test for function get_bin_path
def test_get_bin_path():
    str_bin = 'Z0mam.3ce'
    var_bin = get_bin_path(str_bin)


# Generated at 2022-06-24 20:50:52.215606
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cp') == '/bin/cp'
    assert get_bin_path('cp', ['/usr/gnu/bin']) == '/usr/gnu/bin/cp'
    assert get_bin_path('/bin/cp') == '/bin/cp'
    assert get_bin_path('/bin/cp', ['/usr/gnu/bin']) == '/bin/cp'
    assert get_bin_path('/usr/gnu/bin/cp') == '/usr/gnu/bin/cp'
    assert get_bin_path('/usr/gnu/bin/cp', ['/bin']) == '/usr/gnu/bin/cp'

# Generated at 2022-06-24 20:50:57.353559
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('') == '/bin/sh'
    assert get_bin_path('', ['/sbin']) == '/sbin/sh'
    assert get_bin_path('', ['/usr/bin', '/bin', '/usr/sbin', '/sbin', '/usr/local/bin', '/usr/local/sbin']) == '/bin/sh'

# Generated at 2022-06-24 20:50:59.947320
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('bash') is not None


if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:51:09.282264
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'U6nH(6+l)<b$+'
    str_1 = '@eY4g]s'
    str_2 = 'jPhi/]0)vG|SgWe%e~'
    str_3 = 'jPhi/]0)vG|SgWe%e~'
    str_4 = 'jPhi/]0)vG|SgWe%e~'
    assert(get_bin_path(str_0) == os.path.join(os.sep, 'tmp', 'fU6nH(6+l)<b$+f'))

# Generated at 2022-06-24 20:51:18.427941
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/bash') == '/bin/bash'
    assert get_bin_path('/bin/hash') == '/bin/hash'
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('csh') == '/bin/csh'
    assert get_bin_path('dash') == '/bin/dash'
    assert get_bin_path('dash') == '/bin/dash'
    assert get_bin_path('bash') == '/bin/bash'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('pwd') == '/bin/pwd'
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-24 20:51:23.744243
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as error:
        assert ('Failed to find required executable' in str(error))
    return True

# Test get_bin_path() from stdin
if __name__ == '__main__':
    print(test_get_bin_path())
    sys.exit(not test_get_bin_path())

# Generated at 2022-06-24 20:51:25.683281
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')



# Generated at 2022-06-24 20:51:26.877924
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:51:28.285912
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'

# Generated at 2022-06-24 20:51:38.869513
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('false') == '/bin/false'
    assert get_bin_path('/bin/false') == '/bin/false'
    assert get_bin_path('/usr/bin/false') == '/usr/bin/false'
    assert get_bin_path('/usr/bin/sh') == '/usr/bin/sh'
    assert get_bin_path('/usr/bin/env') == '/usr/bin/env'
    assert get_bin_path('/usr/bin/python2.7') == '/usr/bin/python2.7'
    assert get_bin_path('/usr/bin/python') == '/usr/bin/python'
    assert get_bin_path('sh') == '/bin/sh'
    assert get_bin_path('b0gus') == get_bin_path

# Generated at 2022-06-24 20:51:42.218351
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:51:53.730831
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = 'r/ol7/Jn'
    var_1 = get_bin_path(var_0)
    assert var_1 == 'r/ol7/Jn'
    var_0 = 's+O?$'
    var_1 = get_bin_path(var_0)
    assert var_1 == 's+O?$'
    var_0 = 'J8PcW'
    var_1 = get_bin_path(var_0)
    assert var_1 == 'J8PcW'
    var_0 = '"/>]d$L'
    var_1 = get_bin_path(var_0)
    assert var_1 == '"/>]d$L'
    var_0 = '4_..A&|.e~'
    var_1 = get

# Generated at 2022-06-24 20:51:56.111711
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('RGz{_18,R;Rz`M4N4+')


# Generated at 2022-06-24 20:51:57.092828
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)
    test_case_0()

# Generated at 2022-06-24 20:52:01.541739
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/cat') == '/bin/cat'
    assert get_bin_path('cat') == get_bin_path('cat', ['$PATH'])
    assert get_bin_path('cat', ['$PATH']) == '/bin/cat'

# Generated at 2022-06-24 20:52:07.608841
# Unit test for function get_bin_path
def test_get_bin_path():
    """Check get_bin_path has expected results for various inputs.
    """
    assert get_bin_path('cp') == '/usr/bin/cp'
    assert get_bin_path('cp', ['/usr/local/bin']) == '/usr/bin/cp'
    assert get_bin_path('cp', ['/usr/local/bin'], True) == '/usr/bin/cp'

    with pytest.raises(ValueError):
        assert get_bin_path('nonexistent')



# Generated at 2022-06-24 20:52:10.125085
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-24 20:52:18.155379
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'yb_'
    var_1 = get_bin_path(str_0, str_0)
    str_1 = ']|&/'
    var_2 = get_bin_path(str_1, str_1)
    str_2 = '<-7y'
    var_3 = get_bin_path(str_2, str_2)
    str_3 = 'v(Q'
    var_4 = get_bin_path(str_3, str_3)
    str_4 = 'v\\2'
    var_5 = get_bin_path(str_4, str_4)
    str_5 = 'Eu:7'
    var_6 = get_bin_path(str_5, str_5)

# Generated at 2022-06-24 20:52:19.617421
# Unit test for function get_bin_path
def test_get_bin_path():
    # Placeholder for (possible) unit test(s)
    assert True


# Generated at 2022-06-24 20:52:21.513802
# Unit test for function get_bin_path
def test_get_bin_path():
    """Test for function get_bin_path, will be removed in 2.14"""
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:52:24.900662
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'


# Generate expected ARP Response from ARP Request

# Generated at 2022-06-24 20:52:25.348446
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_b

# Generated at 2022-06-24 20:52:27.553710
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = "d"
    arg_1 = []
    arg_2 = None
    ret = get_bin_path(arg_0, arg_1, arg_2)



# Generated at 2022-06-24 20:52:32.692280
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:52:37.380615
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('sh')
    assert not get_bin_path('doesnotexist')
    assert not get_bin_path('ruby')
    assert get_bin_path('ruby', opt_dirs=['/usr/bin'])

# Generated at 2022-06-24 20:52:47.019746
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/opt/katalon']) == '/opt/katalon/ls'
    assert get_bin_path('ls', opt_dirs=['/opt/katalon', '/opt/katalon']) == '/opt/katalon/ls'
    assert get_bin_path('ls', opt_dirs=['/opt/katalon', '/opt/katalon', '/home/katalon']) == '/opt/katalon/ls'

# Generated at 2022-06-24 20:52:55.303334
# Unit test for function get_bin_path
def test_get_bin_path():

    # Output of failed call:
    # ValueError: Failed to find required executable "jPhi/]0)vG|SgWe%e~" in paths: /bin:/usr/bin:/sbin:/usr/sbin:/usr/local/sbin:/usr/local/bin:/opt/local/bin:/opt/local/sbin:/usr/local/serf/bin:/usr/local/bin:/opt/local/bin:/opt/local/sbin:/usr/local/serf/bin
    try:
        test_case_0()
    except ValueError as e:
        print(e)

# Generated at 2022-06-24 20:52:57.043394
# Unit test for function get_bin_path
def test_get_bin_path():
    # No exception thrown Unit Test
    try:
        test_case_0()
    except Exception:
        assert False



# Generated at 2022-06-24 20:53:03.011663
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('/bin/echo') == '/bin/echo'
    assert get_bin_path('/bin/echo', opt_dirs=['/bin']) == '/bin/echo'
    assert get_bin_path('echo', opt_dirs=['/bin']) == '/bin/echo'

    try:
        get_bin_path('asdf')
        assert False, "Expected error"
    except ValueError as err:
        assert str(err) == 'Failed to find required executable "asdf" in paths: /bin:/usr/bin'

    try:
        get_bin_path('asdf', required=True)
        assert False, "Expected error"
    except ValueError as err:
        assert str(err)

# Generated at 2022-06-24 20:53:04.798674
# Unit test for function get_bin_path
def test_get_bin_path():
    # The code to run the unit test goes here.  Return true or false
    # to indicate success or failure.
    return True

# Generated at 2022-06-24 20:53:09.571594
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'jPhi/]0)vG|SgWe%e~'
    var_0 = get_bin_path(str_0, str_0)

# Generated at 2022-06-24 20:53:11.925854
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'jdH1@.p$'
    var_0 = get_bin_path(str_0, str_0)

# Generated at 2022-06-24 20:53:14.079037
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == 0, "get_bin_path() returned non-zero"



# Generated at 2022-06-24 20:53:21.870251
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'jPhi/]0)vG|SgWe%e~'
    str_1 = 'f=_wY(R8NY}+/^'
    str_2 = ']2,B8gJl_c+$MC'
    str_3 = 'UvJpf1F6T^-LNV>'
    str_4 = '^CY=DGJnR'
    str_5 = '~zYA0aN:5R'
    str_6 = 'h,]$tEN-/q3x'
    str_7 = 'hbK%c7Vm$'
    str_8 = 'Q|K-F&C'
    str_9 = '68K)c%^7p'

# Generated at 2022-06-24 20:53:24.802388
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '"='
    var_0 = get_bin_path(str_0)
    assert var_0 is not None
    assert os.path.exists(var_0)

    str_0 = ''
    var_0 = get_bin_path(str_0)
    assert var_0 is not None
    assert os.path.exists(var_0)

# Generated at 2022-06-24 20:53:29.417319
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True
# END-OF-CASE: test_case_0

# Generated at 2022-06-24 20:53:31.504739
# Unit test for function get_bin_path
def test_get_bin_path():
    # Assert for valid declaration of get_bin_path function
    assert isinstance(get_bin_path, object)
    # Calling test case
    test_case_0()



# Generated at 2022-06-24 20:53:42.880842
# Unit test for function get_bin_path
def test_get_bin_path():
    # Testing function get_bin_path
    str_0 = 'DFoZ3qr|-z[xP`9%I^'
    str_1 = ';bDwF~1G-fY'
    str_2 = 'e9X'
    str_3 = '#{^w-wA'
    var_0 = get_bin_path(str_3, [str_3], True)
    assert var_0 == '/usr/bin/ssh-keygen', 'AssertionError: ' + var_0 + ' not equal to /usr/bin/ssh-keygen'
    var_1 = get_bin_path(str_2, [str_3], True)

# Generated at 2022-06-24 20:53:45.731704
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'jPhi/]0)vG|SgWe%e~'
    var_0 = get_bin_path(str_0, str_0)
    assert var_0 == str_0

# Generated at 2022-06-24 20:53:47.882827
# Unit test for function get_bin_path
def test_get_bin_path():
    assert not test_case_0()


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:53:55.023982
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('test') == '/bin/test'
    try:
        get_bin_path('test-notfound')
        assert False, 'exception expected'
    except ValueError:
        pass
    assert get_bin_path('test', ['/usr/bin']) == '/usr/bin/test'
    assert get_bin_path('test', ['/usr/bin', '/bin']) == '/bin/test'
    assert get_bin_path('test-notfound', ['/usr/bin', '/bin']) == '/usr/bin/test-notfound'

# Generated at 2022-06-24 20:53:55.891951
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0()

# Generated at 2022-06-24 20:54:04.358798
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'b8YM=DFC?j!}'
    str_1 = '.IkeoC(sz?_KjQP~0'
    str_2 = 'NG1L0XK?+`yH#MR'
    str_3 = 'M}8Y/J|_j/'
    str_4 = '8W*[H.N|6U5'
    str_5 = '@(2@x3~q4+4<L8W'
    var_0 = get_bin_path(str_0, str_1)
    var_1 = get_bin_path(str_2, str_3, str_4)
    var_2 = get_bin_path(str_5, str_1, str_4)


# Generated at 2022-06-24 20:54:11.715654
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.file import is_executable
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.file import get_bin_path


# Generated at 2022-06-24 20:54:13.313104
# Unit test for function get_bin_path
def test_get_bin_path():
    # Calling function get_bin_path
    test_case_0()

# Generated at 2022-06-24 20:54:17.569849
# Unit test for function get_bin_path
def test_get_bin_path():
    
    # This is a good test
    str_0 = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_get_bin_path_file0')
    test_case_0()


# Generated at 2022-06-24 20:54:22.736577
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as e:
        print(e)
        assert str(e) == 'Failed to find required executable "jPhi/]0)vG|SgWe%e~" in paths: /Users/marcin/.pyenv/versions/3.7.0/bin'

# Generated at 2022-06-24 20:54:25.174044
# Unit test for function get_bin_path
def test_get_bin_path():
    os.path.expanduser('')
    os.path.expandvars('')
    assert isinstance(get_bin_path(''), str)

# Generated at 2022-06-24 20:54:26.685944
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == 'jPhi/]0)vG|SgWe%e~'

# Generated at 2022-06-24 20:54:27.578714
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:54:38.817288
# Unit test for function get_bin_path
def test_get_bin_path():
    str_1 = 'pSopZ'
    var_1 = get_bin_path(str_1)

    str_2 = 'jPhi/]0)vG|SgWe%e~'
    str_1 = 'pSopZ'
    var_2 = get_bin_path(str_1, str_2)

    var_1 = None
    var_2 = get_bin_path(str_1, var_1)

    str_3 = 'pSopZ'
    str_4 = 'jPhi/]0)vG|SgWe%e~'
    var_2 = get_bin_path(str_1, str_4, str_3)

    var_2 = get_bin_path(str_1, str_4, var_1)

    str_5

# Generated at 2022-06-24 20:54:41.129844
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except:
        # AssertionError, TypeError, AttributeError, ValueError, DeprecationWarning
        assert False



# Generated at 2022-06-24 20:54:44.665784
# Unit test for function get_bin_path
def test_get_bin_path():
    # str_0 = 'jPhi/]0)vG|SgWe%e~'
    # var_0 = get_bin_path(str_0, str_0)
    pass


# Generated at 2022-06-24 20:54:52.477758
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert os.getcwd() not in get_bin_path(os.path.basename(__file__))
    except ValueError:
        pass
    assert os.path.basename(__file__) != get_bin_path(os.path.basename(__file__), [os.getcwd()])
    try:
        assert os.path.basename(__file__) == get_bin_path(os.path.basename(__file__), [os.getcwd()], True)
    except ValueError:
        pass
    assert os.path.basename(__file__) == get_bin_path(os.path.basename(__file__), [os.getcwd()], False)

# Generated at 2022-06-24 20:54:54.479235
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:54:58.690231
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-24 20:55:04.434438
# Unit test for function get_bin_path
def test_get_bin_path():
    assert is_executable(get_bin_path('ls'))
    assert get_bin_path('no-such-executable') is None
    assert is_executable(get_bin_path('ls', [os.path.dirname(get_bin_path('ls'))]))

# Unit test execution
if __name__ == '__main__':

    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:55:06.917731
# Unit test for function get_bin_path
def test_get_bin_path():
    if test_case_0() == 'pass':
        print("Test Case 0 Passed!")
    else:
        print("Test Case 0 Failed!")



# Generated at 2022-06-24 20:55:10.020073
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    ansible.module_utils.basic._get_bin_path
    """
    test_case_0()

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:55:12.621371
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    get_bin_path('this-file-does-not-exist')

# Generated at 2022-06-24 20:55:20.033611
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path(None, None)
    except SystemExit as e:
        assert e.code == 1
    try:
        get_bin_path('', None)
    except SystemExit as e:
        assert e.code == 1
    try:
        get_bin_path(None, '')
    except SystemExit as e:
        assert e.code == 1

# Generated at 2022-06-24 20:55:21.648165
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('/bin/sh')
    get_bin_path('../bin/bash')


# Generated at 2022-06-24 20:55:26.687408
# Unit test for function get_bin_path
def test_get_bin_path():
    str_1 = 'jPhi/]0)vG|SgWe%e~'
    var_0 = get_bin_path('xcat')
    assert var_0 == '/usr/bin/xcat'
    var_1 = get_bin_path('xcat', str_1)
    assert var_1 == '/usr/bin/xcat'
    var_2 = get_bin_path('xcat', str_1)
    assert var_2 == '/usr/bin/xcat'



# Generated at 2022-06-24 20:55:27.855561
# Unit test for function get_bin_path
def test_get_bin_path():

    test_case_0()

# Generated at 2022-06-24 20:55:33.967895
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', required=False) == '/bin/ls'
    assert get_bin_path('ls', '/usr/bin/', required=False) == '/bin/ls'
    #assert get_bin_path('ls', '/foo/bar') == '/bin/ls'
    #assert get_bin_path('ls', '/foo/bar', required=False) == '/bin/ls'

# Generated at 2022-06-24 20:55:38.454818
# Unit test for function get_bin_path
def test_get_bin_path():
    # str_0 = 'jPhi/]0)vG|SgWe%e~'
    # assert_equals(get_bin_path(arg_0, arg_1), expected_0)
    return True


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:55:42.622927
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path('openssl')
    except Exception as e:
        print('Autogenerated test for function get_bin_path failed with error: {0}'.format(e))


# Generated at 2022-06-24 20:55:47.529631
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None

# Test class for function get_bin_path

# Generated at 2022-06-24 20:55:50.519398
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('asdf')
    assert get_bin_path('python')
    assert get_bin_path('python', ['/usr/local/bin/'])
    assert get_bin_path('python', ['/usr/bin/'])


# Generated at 2022-06-24 20:55:59.373895
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'Hq?4A@y)sB'
    str_1 = '/3kD]1?I'
    str_2 = 'N'
    str_3 = '1u|>H^/9I'
    str_4 = 'm!i(@;<'
    str_5 = '/nM8>'
    str_6 = '#&zOQjtb'
    str_7 = 'w%cKjC"`g'
    str_8 = 'k-A8'
    str_9 = '@'
    str_10 = '0YaKj6Q'
    str_11 = 'nU6-1'
    str_12 = 'ol_(!D'
    str_13 = 'XN'
    str_14 = '/d'
