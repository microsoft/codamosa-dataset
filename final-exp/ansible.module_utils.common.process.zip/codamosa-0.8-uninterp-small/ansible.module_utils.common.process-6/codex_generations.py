

# Generated at 2022-06-24 20:45:55.927982
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:45:56.907412
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:45:58.322767
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)


# Generated at 2022-06-24 20:45:58.981982
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:46:00.381066
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(get_bin_path.__code__) is not None

# Generated at 2022-06-24 20:46:05.006395
# Unit test for function get_bin_path
def test_get_bin_path():
    ret = get_bin_path(
        arg='/usr/bin/python2.7',
        opt_dirs=None,
        required=None,
    )

    # check for expected results
    success = True
    if ret is not None:
        success = False
    assert success



# Generated at 2022-06-24 20:46:09.842157
# Unit test for function get_bin_path
def test_get_bin_path():

    assert test_case_0() == -3121.422

# Generated at 2022-06-24 20:46:18.453618
# Unit test for function get_bin_path
def test_get_bin_path():
    float_0 = -3121.422
    var_0 = get_bin_path(float_0)
    assert var_0 is None
    float_1 = -3121.422
    opt_dirs = [['required', ['optional', 'list', 'of', 'dirs', 'to', 'search', 'in', 'addition', 'to', 'PATH']], ['required', ['optional', 'list', 'of', 'dirs', 'to', 'search', 'in', 'addition', 'to', 'PATH']], []]
    var_1 = get_bin_path(float_1, opt_dirs=opt_dirs)
    assert var_1 is None
    float_2 = -3121.422
    opt_dirs = {}

# Generated at 2022-06-24 20:46:19.823035
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None, "Test failed."

# Generated at 2022-06-24 20:46:23.585567
# Unit test for function get_bin_path
def test_get_bin_path():
    values_0 = [
        0,
        2,
        2.5568,
        0.11028,
        1.55,
        0.023,
        1.113,
        3.01,
        1.12,
        3.01,
        0.001,
        1.1,
        0.001
    ]
    get_bin_path(values_0)


# Generated at 2022-06-24 20:46:28.350367
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)
    print(var_0)


# Generated at 2022-06-24 20:46:30.090657
# Unit test for function get_bin_path
def test_get_bin_path():

    # Tests
    assert test_case_0() == None


if __name__ == "__main__":
    test_get_bin_path()
    print('Testing completed!')

# Generated at 2022-06-24 20:46:35.762760
# Unit test for function get_bin_path
def test_get_bin_path():
    # Path => 4\\\r
    # PathEnvironmentVariable => PATH
    # Required => True
    # ExecutableDirectory => 
    # OptionalExecutableDirectories => 
    # Expected => C:\Windows\System32\4\r
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)
    assert var_0 == 'C:\\Windows\\System32\\4\\r'

    # Path => 4\\\r
    # PathEnvironmentVariable => PATH
    # Required => True
    # ExecutableDirectory => C:\Windows\System32
    # OptionalExecutableDirectories => 
    # Expected => C:\Windows\System32\4\r
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)
    assert var_

# Generated at 2022-06-24 20:46:40.921905
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = "get_bin_path"
    str_1 = "\""
    str_2 = "false"
    str_3 = "list"
    str_4 = "get-bin-path"
    str_5 = 'ps -F'
    str_6 = "list"
    str_7 = "opt_dirs_list"
    str_8 = "get_bin_path"
    str_9 = 'which python2'
    str_10 = "sys.executable"
    str_11 = "get_bin_path"
    str_12 = "Not Implemented Error"
    str_13 = 'which python3'
    str_14 = "sys.executable"
    str_15 = "get_bin_path"
    str_16 = "Not Implemented Error"
   

# Generated at 2022-06-24 20:46:46.520051
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:46:48.396525
# Unit test for function get_bin_path
def test_get_bin_path():
    with pytest.raises(ValueError):
        get_bin_path(str_0)

# Generated at 2022-06-24 20:46:51.472667
# Unit test for function get_bin_path
def test_get_bin_path():

    # Tests for method get_bin_path
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:46:53.919687
# Unit test for function get_bin_path
def test_get_bin_path():

    assert True

# Generated at 2022-06-24 20:46:55.990564
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    @brief  The unit test for function atl_crash_reporter_get_bin_path
    @task   To ensure that function requires a non-empty string.
    @return None
    """
    assert True

# Generated at 2022-06-24 20:47:00.995746
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('1\\\r')



# Generated at 2022-06-24 20:47:06.464505
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as err:
        print('ValueError detected in %s: %s' % (__file__, err))

# Generated at 2022-06-24 20:47:14.438783
# Unit test for function get_bin_path
def test_get_bin_path():
    VALID_OUTPUT_FILE = os.path.join(os.path.dirname(__file__), "valid_output_get_bin_path.txt")
    EXPECTED_OUTPUT_FILE = os.path.join(os.path.dirname(__file__), "expected_output_get_bin_path.txt")

    # Remove old output file if it exists
    if os.path.exists(VALID_OUTPUT_FILE):
        os.remove(VALID_OUTPUT_FILE)

    # Run the test and generate output
    test_case_0()

    # Verify the output is what we expected
    assert os.path.exists(VALID_OUTPUT_FILE)

    assert filecmp.cmp(VALID_OUTPUT_FILE, EXPECTED_OUTPUT_FILE)

# Generated at 2022-06-24 20:47:20.342873
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(None, None, None) is None
    assert get_bin_path('binFalse', None, None) is None
    assert get_bin_path('binTrue', None, None) is not None
    assert get_bin_path('binTrue', ['./bin'], None) is not None
    assert get_bin_path('binTrue', ['bin'], None) is not None
    assert get_bin_path(None, ['./bin'], None) is None
    assert get_bin_path(None, ['./bin'], None) is None
    assert get_bin_path(None, ['./bin'], None) is None
    assert get_bin_path(None, None, None) is None
    assert get_bin_path('binFalse', None, None) is None
    assert get

# Generated at 2022-06-24 20:47:28.798931
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('yell') == '/usr/bin/yell'
    assert get_bin_path('jargon') is None
    try:
        get_bin_path('jargon', required=True)
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "jargon" in paths: /usr/bin:/bin'
    except Exception as exc:
        assert False, 'Unhandled exception "%s"' % exc
    else:
        assert False, 'Expected exception was not raised'

# Generated at 2022-06-24 20:47:31.455766
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    try:
        get_bin_path('foobarbaz')
        assert False
    except ValueError:
        pass

test_get_bin_path()

# Generated at 2022-06-24 20:47:33.409917
# Unit test for function get_bin_path
def test_get_bin_path():
    assert type(get_bin_path(str_0)) == str

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 20:47:37.804784
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)
    test_case_0()


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:47:38.329457
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-24 20:47:43.947849
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = '5_'
    arg_1 = ['/etc/ansible']
    try:
        assert isinstance(get_bin_path(arg_0, arg_1), str)
    except ValueError:
        pass
    else:
        raise Exception('Expected ValueError')

test_get_bin_path()


# Test generated with Python 2.7.14 and mocker (https://github.com/ValeLint/mocker)
import mocker
import sys


# Generated at 2022-06-24 20:47:47.331436
# Unit test for function get_bin_path
def test_get_bin_path():

    assert var_0 == '/sbin'



# Generated at 2022-06-24 20:47:55.396741
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)


# call function get_bin_path

# Generated at 2022-06-24 20:47:59.956694
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except BaseException as ex:
        print(ex)
        return False
    else:
        return True


if __name__ == '__main__':
    if test_get_bin_path():
        print('all test ok')
    else:
        print('test error')

# Generated at 2022-06-24 20:48:05.318508
# Unit test for function get_bin_path
def test_get_bin_path():
    # Call function get_bin_path with arguments, str(4\\\r) and
    # [None] to test with expected, ValueError: Failed to find required executable "4\\\r" in paths:
    try:
        test_case_0()
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "4\\\\\\r" in paths: '



# Generated at 2022-06-24 20:48:09.565926
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception as e:
        print('\n', 'Unit test failed: ', e)
        return False
    else:
        return True


if __name__ == '__main__':
    if test_get_bin_path():
        print('Unit test passed')

# Generated at 2022-06-24 20:48:11.195795
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('10\\\n')


# Generated at 2022-06-24 20:48:17.507040
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)
    str_1 = ' mkdir '
    var_1 = get_bin_path(str_1)



# Generated at 2022-06-24 20:48:22.860275
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)
    assert var_0 == '/sbin/4\\\r'

# Generated at 2022-06-24 20:48:29.041146
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '-type'
    str_1 = 'c2'
    str_2 = 'sbin'
    str_3 = 'avg'
    try:
        result = get_bin_path(str_0)
    except ValueError:
        result = str_1
    assert result == str_2
    str_4 = 'j\x19\x7fS\x1d'
    str_5 = '%\\\x7f'
    str_6 = 'M'
    str_7 = '_\x15\x1c\x19'
    str_8 = '\x7f\x19\x7fS\x1d'
    try:
        result_1 = get_bin_path(str_4)
    except ValueError:
        result_1 = str_

# Generated at 2022-06-24 20:48:30.247920
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None

# Generated at 2022-06-24 20:48:31.964000
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True is True

# Boilerplate for main function

# Generated at 2022-06-24 20:48:42.575144
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True
    # get_bin_path(arg, opt_dirs=None, required=None)
    try:
        get_bin_path('grep')
    except ValueError:
        pass
    else:
        assert False, "Did not catch ValueError"
    try:
        get_bin_path(str_0)
    except ValueError:
        assert True
    else:
        assert False, "Did not catch ValueError"
    try:
        get_bin_path('grep ')
    except ValueError:
        assert True
    else:
        assert False, "Did not catch ValueError"
    try:
        get_bin_path('/bin/grep', ['/usr/bin'])
    except ValueError:
        assert True

# Generated at 2022-06-24 20:48:44.943930
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test case 0
    test_case_0()

# Generated at 2022-06-24 20:48:49.065656
# Unit test for function get_bin_path
def test_get_bin_path():
    func_0 = '4\\\r'
    var_0 = get_bin_path(func_0)
    assert callable(get_bin_path)
    assert var_0 != False
    assert var_0 != None

# Generated at 2022-06-24 20:48:57.360417
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)

    str_1 = '$x\x00'
    var_1 = get_bin_path(str_1)

    str_2 = '\n'
    var_2 = get_bin_path(str_2)

    str_3 = 'Y'
    var_3 = get_bin_path(str_3)

    str_4 = 'Y'
    var_4 = get_bin_path(str_4)

    str_5 = '^x\x00'
    var_5 = get_bin_path(str_5)

    str_6 = '/'
    var_6 = get_bin_path(str_6)

    str_7 = '\xd8\x00'

# Generated at 2022-06-24 20:48:59.872307
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = False
    try:
        test_case_0()
    except ValueError as v:
        var_0 = True

    assert var_0

# Generated at 2022-06-24 20:49:01.253994
# Unit test for function get_bin_path
def test_get_bin_path():
    # Testing for str_0 = '4\\\r'
    test_case_0()



# Generated at 2022-06-24 20:49:05.340100
# Unit test for function get_bin_path
def test_get_bin_path():
    # Add simple tests here
    pass


# Unit test start
if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:49:07.733111
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)

# Generated at 2022-06-24 20:49:10.351679
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        str_0 = '4\\\r'
        var_0 = get_bin_path(str_0)
    except:
        pass

# Test using pytest

# Generated at 2022-06-24 20:49:18.677753
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '  \r'
    str_1 = '   \r'
    str_2 = ' 4\r'
    str_3 = '(,\r'
    str_4 = ' \r\r'
    str_5 = '\r\r'
    str_6 = '\r!\r'
    str_7 = '\r\r'
    str_8 = '\r\r'
    str_9 = '\r!\r'
    str_10 = '\\\r'
    str_11 = '\r'
    str_12 = 'h\r'
    str_13 = '\r\r'
    str_14 = '\r\r'
    str_15 = '\r!\r'
    str_16 = '\r\r'


# Generated at 2022-06-24 20:49:32.251848
# Unit test for function get_bin_path
def test_get_bin_path():
    path = get_bin_path('ls')
    assert os.path.exists(path)
    assert path == '/bin/ls'
    # no such command
    failed = False
    try:
        get_bin_path('no-such-command')
    except ValueError:
        failed = True
    assert failed is True
    # normal operation
    path = get_bin_path('sh', required=True)
    assert os.path.exists(path)
    assert path == '/bin/sh'
    # alternative paths
    path = get_bin_path('sed', opt_dirs=['/usr/bin', '/bin'])
    assert os.path.exists(path)
    assert path == '/bin/sed'
    # not in alternative paths
    failed = False

# Generated at 2022-06-24 20:49:34.421587
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)
    assert var_0 is not None

# Generated at 2022-06-24 20:49:41.962923
# Unit test for function get_bin_path
def test_get_bin_path():
    str_1 = '0'
    var_0 = get_bin_path(str_1)
    str_2 = '1'
    var_1 = get_bin_path(str_2)
    str_3 = '2'
    var_2 = get_bin_path(str_3)
    str_4 = '3'
    var_3 = get_bin_path(str_4)
    str_5 = '4'
    var_4 = get_bin_path(str_5)
    str_6 = '5'
    var_5 = get_bin_path(str_6)
    str_7 = '6'
    var_6 = get_bin_path(str_7)
    str_8 = '7'
    var_7 = get_bin_path(str_8)

# Generated at 2022-06-24 20:49:51.608554
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)
    assert var_0 is not None, "get_bin_path(str_0) returned None"
    assert var_0 == '/bin/4\\\r', "get_bin_path(str_0) returned %s" % str(var_0)
    str_0 = 'k8e'

# Generated at 2022-06-24 20:49:55.054479
# Unit test for function get_bin_path
def test_get_bin_path():
    assert (b'\n\nUnit test for get_bin_path\n' == b'\n\nUnit test for get_bin_path\n')

# Generated at 2022-06-24 20:49:59.976458
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)
    str_1 = '8I'
    var_1 = get_bin_path(str_1, opt_dirs=None, required=None)
    var_2 = get_bin_path(str_1, opt_dirs=var_1, required=None)


# Generated at 2022-06-24 20:50:01.128641
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() is None, 'Failed to check case 0.'

# Generated at 2022-06-24 20:50:01.946962
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:50:03.338079
# Unit test for function get_bin_path
def test_get_bin_path():
    assert('/usr/bin/4\\\\r' == get_bin_path('4\\\\r'))


# Generated at 2022-06-24 20:50:10.753612
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '8>|'
    var_0 = get_bin_path(str_0)
    str_0 = '\x1b'
    var_0 = get_bin_path(str_0)
    str_0 = '\x1b'
    var_0 = get_bin_path(str_0)



# Generated at 2022-06-24 20:50:14.298004
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)


# Generated at 2022-06-24 20:50:16.431319
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as e:
        print('Failed: Expected Exception:', e)
        return False

    return True



# Generated at 2022-06-24 20:50:19.983990
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)
    str_1 = '1\\\r'
    var_1 = get_bin_path(str_1)

# Generated at 2022-06-24 20:50:20.820404
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case(0)


# Generated at 2022-06-24 20:50:23.518122
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '\\\n\\'
    str_1 = '\a\\\t'
    str_2 = '3\''
    str_3 = '\\'
    str_4 = '\''


# Generated at 2022-06-24 20:50:31.967960
# Unit test for function get_bin_path
def test_get_bin_path():
    """Test the get_bin_path function"""
    try:
        str_0 = ''
        var_0 = get_bin_path(str_0)
        assert(False)
    except ValueError:
        assert(True)

    # Check exit on empty string
    try:
        str_0 = ''
        var_0 = get_bin_path(str_0)
        assert(False)
    except ValueError:
        assert(True)

    # Check exit on non existent file
    try:
        str_0 = 'non-existent-program'
        var_0 = get_bin_path(str_0)
        assert(False)
    except ValueError:
        assert(True)


# Generated at 2022-06-24 20:50:37.443779
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/env')


if __name__ == "__main__":
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:50:40.318641
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True
    try:
        var_0 = get_bin_path(var_0)
        assert True
    except ValueError as e:
        assert False

# Generated at 2022-06-24 20:50:46.328595
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = ';'
    str_1 = '5U:z'
    opt_dirs_0 = [str_0, str_1]
    var_0 = get_bin_path('uuidgen', opt_dirs_0)
    if (len(var_0) > 0):
      assert True
    else:
      assert False


# Generated at 2022-06-24 20:50:48.976286
# Unit test for function get_bin_path
def test_get_bin_path():
    str_1 = '7\\\r'
    test_case_0()
    var_1 = get_bin_path(str_1)
    return var_1

# Generated at 2022-06-24 20:50:57.937164
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 'foo' == get_bin_path('foo')

# Generated at 2022-06-24 20:51:06.286192
# Unit test for function get_bin_path
def test_get_bin_path():
    # test get_bin_path when var_0 is False
    str_0 = '^'
    var_0 = get_bin_path(str_0)
    if var_0 is not None:
        print('Expected None, got', var_0)

    # test get_bin_path when var_0 is False
    str_0 = '%'
    var_0 = get_bin_path(str_0)
    if var_0 is not None:
        print('Expected None, got', var_0)

    # test get_bin_path when var_0 is OrderedDict
    str_0 = 'I'
    var_0 = get_bin_path(str_0)
    if var_0 is not None:
        print('Expected None, got', var_0)

    # test get

# Generated at 2022-06-24 20:51:10.235283
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)
    assert str(var_0) == '4\r'


# Generated at 2022-06-24 20:51:11.465275
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('nmcli')


# Generated at 2022-06-24 20:51:12.671555
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()
    test_case_1()

# Generated at 2022-06-24 20:51:15.303082
# Unit test for function get_bin_path
def test_get_bin_path():
  print("fibonacci_recursive")
  # print(fibonacci_recursive(35))
  print("fibonacci_iterative")
  # print(fibonacci_iterative(35))

# Generated at 2022-06-24 20:51:19.571705
# Unit test for function get_bin_path
def test_get_bin_path():
    assert isinstance(get_bin_path(''), str)


# Generated at 2022-06-24 20:51:21.343676
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)



# Generated at 2022-06-24 20:51:31.668932
# Unit test for function get_bin_path
def test_get_bin_path():
    var_1 = 'convert'
    var_2 = [None, '/usr/bin', 'pwd']
    var_3 = True
    try:
        var_4 = get_bin_path(var_1, var_2, var_3)
    except ValueError as e:
        pass
    else:
        raise AssertionError('Expected ValueError but no exception was raised.')


    var_5 = 'convert'
    var_6 = [None, '/usr/bin', 'pwd']
    var_7 = False
    try:
        var_8 = get_bin_path(var_5, var_6, var_7)
    except ValueError as e:
        pass
    else:
        raise AssertionError('Expected ValueError but no exception was raised.')

# Unit test

# Generated at 2022-06-24 20:51:41.389798
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/bash') is not None
    assert get_bin_path('/bin/bash') == '/bin/bash'
    assert get_bin_path('/bin/bash', required=True) is not None
    assert get_bin_path('/bin/bash', required=True) == '/bin/bash'
    assert get_bin_path('/bin/bash', opt_dirs=[]) is not None
    assert get_bin_path('/bin/bash', opt_dirs=[]) == '/bin/bash'
    assert get_bin_path('/bin/bash', opt_dirs=[], required=True) is not None
    assert get_bin_path('/bin/bash', opt_dirs=[], required=True) == '/bin/bash'

# Generated at 2022-06-24 20:51:49.526592
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '\\*'
    var_0 = get_bin_path(str_0)
    assert var_0 == '/Users/pescobar/.pyenv/shims/pip'

# Generated at 2022-06-24 20:51:52.400628
# Unit test for function get_bin_path
def test_get_bin_path():
    str_1 = 'h'
    # Test for ValueError
    try:
        get_bin_path(str_1)
        passed = False
    except ValueError:
        passed = True

    return passed


# Generated at 2022-06-24 20:51:56.777172
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path('4\\\r')


# Boilerplate
if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 20:52:01.671305
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)
    assert var_0 == '4\\\r'


if __name__ == "__main__":
    import pytest
    pytest.main('-v test_get_bin_path.py')

# Generated at 2022-06-24 20:52:02.822740
# Unit test for function get_bin_path
def test_get_bin_path():

    # Run test case 0
    test_case_0()



# Generated at 2022-06-24 20:52:04.362876
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = '4\\\r'

    # Call function with arguments.
    val = get_bin_path(arg)

# Generated at 2022-06-24 20:52:09.095157
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('nano')
    assert get_bin_path('nano', opt_dirs=['/bin'])
    assert get_bin_path('nano', opt_dirs=['/bin', '/usr/bin'])
    assert get_bin_path('nano', required=False)


# Generated at 2022-06-24 20:52:12.089608
# Unit test for function get_bin_path
def test_get_bin_path():
    # ensure overrides are used
    bin_file = '/bin/echo'
    test_dir = '/tmp'
    var_1 = get_bin_path(bin_file, opt_dirs=[test_dir])
    assert var_1 == bin_file

# Generated at 2022-06-24 20:52:16.558949
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('4\\\\r') == '/bin/4\\\\r'
    assert get_bin_path('Yj\\\x9b\x1d\\') == '/bin/Yj\\\\\\x9b\\x1d\\\\'
    assert get_bin_path('l\x84') == '/bin/l\\x84'
    s =  'H'
    assert get_bin_path(s) == '/bin/H'

# Generated at 2022-06-24 20:52:19.782130
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError:
        pass
    else:
        assert False, "No exception was raised"

if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:52:27.133085
# Unit test for function get_bin_path
def test_get_bin_path():
  # Expected return value
  expected = None
  
  # Return value
  actual = get_bin_path(str_0, var_1, var_2)
  
  # Unit test assertion
  try:
    assert actual == expected
  except AssertionError as e:
    print('AssertionError: expected {} to equal {}'.format(expected, actual))



# Generated at 2022-06-24 20:52:29.355264
# Unit test for function get_bin_path
def test_get_bin_path():
    assert func_0()
    assert func_1()
    assert func_2()
    assert func_3()
    assert func_4()
    assert func_5()
    assert func_6()

# Generated at 2022-06-24 20:52:34.363920
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '0\\,1X'
    get_bin_path(str_0, ['/root/dir'])
    var_0 = get_bin_path(None)
    str_1 = '\\y\\'
    get_bin_path(str_1, [])
    str_2 = '\\x\\'
    get_bin_path(str_2, [], None)


# Generated at 2022-06-24 20:52:38.170505
# Unit test for function get_bin_path
def test_get_bin_path():
    # Load the data from the example files
    try:
        test_case_0()

    # We don't need to do anything when a test passes.
    except:
        # We only need to handle unexpected errors.
        raise

# Generated at 2022-06-24 20:52:40.953107
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'yarg'
    var_0 = get_bin_path(str_0)
    assert var_0 == '/bin/yarg'


# Generated at 2022-06-24 20:52:49.749399
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'installer.cpp'
    assert(get_bin_path(str_0)) == '/tmp/ansible_get_bin_path_payload_xVg9oE/bin/installer.cpp'
    str_1 = 'installer.cpp'
    assert(get_bin_path(str_1, opt_dirs=[os.curdir])) == '/tmp/ansible_get_bin_path_payload_xVg9oE/bin/installer.cpp'
    str_2 = 'installer.cpp'

# Generated at 2022-06-24 20:52:51.813479
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'udevadm'
    var_0 = get_bin_path(str_0)
    assert var_0 == '/sbin/udevadm'



# Generated at 2022-06-24 20:52:54.812639
# Unit test for function get_bin_path
def test_get_bin_path():
    # these tests must be run in order as some cases are dependant on previous ones
    assert isinstance(test_case_0(), type(None))



# Generated at 2022-06-24 20:53:00.237180
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = 'test'
    opt_dirs_0 = ['/bin', '/sbin', '/usr/bin', '/usr/local/bin', '/usr/local/sbin']
    required_0 = [False, True]
    for required_0_0 in required_0:
        try:
            var_0 = get_bin_path(arg_0, opt_dirs=opt_dirs_0, required=required_0_0)
            print(var_0)
        except ValueError as var_1:
            print(var_1)

# Mocking os.path.exists

# Generated at 2022-06-24 20:53:03.287714
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 'etcd' in get_bin_path('etcd')
    assert 'etcdctl' in get_bin_path('etcdctl')

# Generated at 2022-06-24 20:53:06.511718
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True


# Generated at 2022-06-24 20:53:08.594700
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test case 0
    test_case_0()


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:53:09.618984
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:53:16.045927
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = 'vmware-rpctool'
    expected_result = '/usr/bin/vmware-rpctool'
    actual_result = get_bin_path(arg)
    # Test for correct results for call get_bin_path('vmware-rpctool')
    assert actual_result == expected_result

    # Test for error when argument is not present
    with pytest.raises(ValueError):
        get_bin_path('test-error')

# Generated at 2022-06-24 20:53:23.620442
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('false', ['/bin', '/usr/bin'], False) == '/bin/false'
    assert get_bin_path('false', ['/bin', '/usr/bin'], True) == '/bin/false'
    assert get_bin_path('false', ['/bin', '/usr/bin'], False) == '/bin/false'
    assert get_bin_path('false', ['/bin', '/usr/bin'], False) == '/bin/false'
    assert get_bin_path('false', ['/bin', '/usr/bin'], True) == '/bin/false'
    assert get_bin_path('false', ['/bin', '/usr/bin'], True) == '/bin/false'

# Generated at 2022-06-24 20:53:27.772540
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True == True

# Generated at 2022-06-24 20:53:38.998191
# Unit test for function get_bin_path
def test_get_bin_path():

    # Input parameters
    # str arg
    str_0 = '4\\\r'

    # list opt_dirs
    opt_dirs_0 = ['/tmp/foo', '/tmp/bar']

    # Instance of class VarsModule
    class VarsModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    # Create instance of class VarsModule
    var_0 = VarsModule(
                         required='false',
                         opt_dirs=opt_dirs_0,
    )

    # Call function get_bin_path with args '4\\\r' and a dictionary of parameters
    var_1 = get_bin_path(str_0, **var_0.params)

    # Test if var_1 has expected value

# Generated at 2022-06-24 20:53:43.797188
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4\\\r'
    try:
        var_0 = get_bin_path(str_0)
    except ValueError as ve:
        if 'Failed to find required executable' not in str(ve):
            raise

if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:53:48.566612
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = 'test_str'
    try:
        var_0 = get_bin_path(arg_0)
    except ValueError as e:
        print(e)
        print('test_get_bin_path failed')

if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:53:52.861618
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except (ValueError, IOError, OSError) as err:
        # pass
        print(err)

# Test cases for function replace_encrypted_password


# Generated at 2022-06-24 20:53:55.954134
# Unit test for function get_bin_path
def test_get_bin_path():
    pass


# Generated at 2022-06-24 20:54:04.441476
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test Exception raised for missing executable
    try:
        with pytest.raises(ValueError):
            str_0 = '9k\\'
            var_0 = get_bin_path(str_0)
    except ValueError as e:
        var_0 = e.args[0]
        assert var_0 == 'Failed to find required executable "9k\\" in paths: '
    else:
        raise Exception('ExpectedValueError')
    # Test Exception raised for missing executable
    try:
        with pytest.raises(ValueError):
            str_0 = '\\'
            var_0 = get_bin_path(str_0)
    except ValueError as e:
        var_0 = e.args[0]
        assert var_0 == 'Failed to find required executable "\\" in paths: '

# Generated at 2022-06-24 20:54:08.010750
# Unit test for function get_bin_path
def test_get_bin_path():
    tests = [
        (['get_bin_path', 'test_case_0', '<string>', 1, 'test_get_bin_path'], {}),
    ]
    for test_args, test_kwargs in tests:
        with unit.Function(**test_kwargs) as testcase:
            testcase(*test_args)

# Generated at 2022-06-24 20:54:09.061380
# Unit test for function get_bin_path
def test_get_bin_path():
    with pytest.raises(ValueError):
        test_case_0()

# Generated at 2022-06-24 20:54:19.059997
# Unit test for function get_bin_path
def test_get_bin_path():

    # Case 1
    # 'exists' is True
    # 'isdir' is True
    # 'isabs' is True
    # 'ismount' is True
    # 'islink' is True
    try:
        str_0 = None
        var_0 = get_bin_path(str_0)
        assert False
    except ValueError:
        assert True

    # Case 2
    # 'exists' is True
    # 'isdir' is True
    # 'isabs' is True
    # 'ismount' is True
    # 'islink' is False
    try:
        str_0 = None
        var_0 = get_bin_path(str_0)
        assert False
    except ValueError:
        assert True

    # Case 3
    # 'exists' is True
    # '

# Generated at 2022-06-24 20:54:21.041630
# Unit test for function get_bin_path
def test_get_bin_path():
    assert var_0 == '/bin/4'


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:54:24.535102
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path('/usr/sbin/service')
    var_1 = '/usr/sbin/service'
    if var_1 != var_0:
        raise ValueError('AssertionError')

# Test case for get_bin_path

# Generated at 2022-06-24 20:54:25.418401
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:54:35.397137
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '2\\\r'
    var_0 = get_bin_path(str_0)

    str_1 = '*'
    var_1 = get_bin_path(str_1)

    str_2 = '^'
    var_2 = get_bin_path(str_2)

    str_3 = '|'
    var_3 = get_bin_path(str_3)

    str_4 = '.'
    var_4 = get_bin_path(str_4)

    str_5 = '1\\\r'
    var_5 = get_bin_path(str_5)

    str_6 = '#'
    var_6 = get_bin_path(str_6)

    str_7 = '6\\\r'
    var_7 = get_

# Generated at 2022-06-24 20:54:36.654020
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'

# Generated at 2022-06-24 20:54:40.364066
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('4\\\r') == '4\\\\\r'

# Generated at 2022-06-24 20:54:47.717097
# Unit test for function get_bin_path
def test_get_bin_path():
    res_0 = '4'
    assert get_bin_path(res_0) == '4', 'Expected: {}, Got: {}'.format(res_0, get_bin_path(res_0))
    res_1 = '4\\\r'
    assert get_bin_path(res_1) == '4\\\r', 'Expected: {}, Got: {}'.format(res_1, get_bin_path(res_1))


if __name__ == "__main__":
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:54:51.888850
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)
    assert get_bin_path(str_0) == var_0



# Generated at 2022-06-24 20:54:54.121535
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception as e:
        assert False, str(e)

# Generated at 2022-06-24 20:54:57.965329
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '1\\\r'
    var_0 = get_bin_path(str_0)
    str_1 = '2\\\r'
    var_1 = get_bin_path(str_1)
    assert var_0 == '1\\\r' and var_1 == '2\\\r'

# Generated at 2022-06-24 20:55:00.009192
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '2\\\n'
    var_0 = get_bin_path(str_0)

    assert(var_0 == '2\\\n')

# Generated at 2022-06-24 20:55:06.211630
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('touch') is not None
    try:
        get_bin_path('this_binary_does_not_exist')
    except ValueError as e:
        assert str(e) == "Failed to find required executable \"this_binary_does_not_exist\" in paths: /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"


# Generated at 2022-06-24 20:55:09.093697
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('devnull') == '/dev/null'

if __name__ == "__main__":
    print(get_bin_path('devnull'))

# Generated at 2022-06-24 20:55:18.570736
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = ''
    opt_dirs_0 = []
    required_0 = None
    try:
        var_0 = get_bin_path(arg_0, opt_dirs_0, required_0)
        assert False
    except ValueError:
        pass
    arg_1 = '>'
    opt_dirs_1 = []
    required_1 = None
    try:
        var_1 = get_bin_path(arg_1, opt_dirs_1, required_1)
        assert False
    except ValueError:
        pass
    arg_2 = '>'
    opt_dirs_2 = ['', '/tmp']
    required_2 = None

# Generated at 2022-06-24 20:55:20.133998
# Unit test for function get_bin_path
def test_get_bin_path():
    var_1 = get_bin_path('/usr/bin/python')


# Generated at 2022-06-24 20:55:26.027316
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()
    test_case_0()

# Generated at 2022-06-24 20:55:28.856679
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path('/sbin/sysctl')
    assert var_0 == '/sbin/sysctl'



# Generated at 2022-06-24 20:55:29.653145
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:55:32.461470
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '4\\\r'
    var_0 = get_bin_path(str_0)
    assert len(var_0) == 0


# Running tests


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:55:40.738429
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('/foo/bar') is None
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('foo') is None
    assert get_bin_path('foo', ['foo']) == 'foo/foo'
    assert get_bin_path('foo', opt_dirs=['bar', 'foo']) == 'foo/foo'
    assert get_bin_path('foo', opt_dirs=['bar', 'foo', '/usr/bin']) == 'foo/foo'
    assert get_bin_path('foo', opt_dirs=['bar', '/usr/bin', 'foo']) == 'foo/foo'

# Generated at 2022-06-24 20:55:44.456072
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '/bin/4\\\r'
    var_0 = get_bin_path(str_0)
    assert var_0 == str_0

# Generated at 2022-06-24 20:55:46.259992
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '5\n'
    var_0 = get_bin_path(str_0)

# Generated at 2022-06-24 20:55:50.774676
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert str(type(get_bin_path('/usr/bin/python'))) == "<type '_sre.SRE_Match'>"
    except AssertionError as e:
        print(e)
        print('Function returned a value of type %s that does not match expected type _sre.SRE_Match' % type(get_bin_path('/usr/bin/python')))
