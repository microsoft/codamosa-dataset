

# Generated at 2022-06-24 20:46:04.162280
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert callable(get_bin_path)
    except AssertionError as e:
        raise(e)
    try:
        test_case_0()
    except Exception as e:
        print('Failed test_case_0')
        print(e)

# Generated at 2022-06-24 20:46:13.544675
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '#^A+]#4B?(I7Phr&fmA'
    assert get_bin_path(str_0) == '/path/to/ansible-playbook'
    assert get_bin_path(str_0, ['wrong/path', 'wrong/path/too']) == '/path/to/ansible-playbook'

    try:
        get_bin_path('not_exists')
        assert False, 'Exception not thrown'
    except ValueError:
        pass
    try:
        get_bin_path('not_exists', ['wrong/path', 'wrong/path/too'])
        assert False, 'Exception not thrown'
    except ValueError:
        pass

# Generated at 2022-06-24 20:46:14.708712
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("lsb_release") is not None
    try:
        get_bin_path("not-exist")
        assert False
    except ValueError:
        pass

# Generated at 2022-06-24 20:46:16.271587
# Unit test for function get_bin_path
def test_get_bin_path():
    var_1 = get_bin_path('python')
    assert 'python' in var_1

# Generated at 2022-06-24 20:46:17.113588
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:46:18.571001
# Unit test for function get_bin_path
def test_get_bin_path():
    # test get_bin_path with a single argument
    test_case_0()



# Generated at 2022-06-24 20:46:19.621809
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None

# Generated at 2022-06-24 20:46:21.511684
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

if __name__ == '__main__':
    import traceback
    # Unit test jig
    test_get_bin_path()

# Generated at 2022-06-24 20:46:28.387229
# Unit test for function get_bin_path
def test_get_bin_path():
    from ansible_collections.community.general.tests.unit.compat.mock import patch, MagicMock

    with patch('ansible_collections.community.general.plugins.module_utils.common.file.is_executable', new=MagicMock(return_value=True)):
        assert get_bin_path('foo') == '/bin/foo'

    with patch('ansible_collections.community.general.plugins.module_utils.common.file.is_executable', new=MagicMock(return_value=False)):
        assert get_bin_path('foo') == '/bin/foo'


# Generated at 2022-06-24 20:46:30.227186
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:46:35.278611
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('foo')
    assert get_bin_path('id')
    assert get_bin_path('ZMzxwPoiBBY.QaI')
    assert get_bin_path('#^A+]#4B?(I7Phr&fmA')

# Generated at 2022-06-24 20:46:36.655920
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test cases
    test_case_0()

# Generated at 2022-06-24 20:46:37.656047
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:46:38.507238
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('vim') == '/usr/bin/vim'

# Generated at 2022-06-24 20:46:39.852611
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as e:
        print(e)


# Generated at 2022-06-24 20:46:44.341942
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)
    try:
        test_case_0()
    except ValueError:
        assert True
    except NoneType:
        assert True
    
if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:46:46.815026
# Unit test for function get_bin_path
def test_get_bin_path():
    path = os.path.dirname(os.path.realpath(__file__))
    get_bin_path('touch', opt_dirs=[path])

# Generated at 2022-06-24 20:46:48.254794
# Unit test for function get_bin_path
def test_get_bin_path():
    # get_bin_path() must work for different arguments
    test_case_0()

# Generated at 2022-06-24 20:46:49.701063
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cc') is not None

# Generated at 2022-06-24 20:46:58.908063
# Unit test for function get_bin_path
def test_get_bin_path():
    assert file_0.__name__ == "get_bin_path"
    assert file_0.__doc__ == "Find system executable in PATH. Raises ValueError if executable is not found.\nOptional arguments:\n   - required:  [Deprecated] Prior to 2.10, if executable is not found and required is true it raises an Exception.\n                In 2.10 and later, an Exception is always raised. This parameter will be removed in 2.14.\n   - opt_dirs:  optional list of directories to search in addition to PATH\nIf found return full path, otherwise raise ValueError.\n"
    assert is_executable(file_0(get_bin_path))



# Generated at 2022-06-24 20:47:01.885802
# Unit test for function get_bin_path
def test_get_bin_path():
    # <INSERT>
    test_case_0()



# Generated at 2022-06-24 20:47:06.863828
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path('/bin/sort')
    print(var_0)


# Generated at 2022-06-24 20:47:08.064160
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test 0
    try:
        test_case_0()
    except ValueError as e:
        assert 'Failed to find required executable' in str(e)

# Generated at 2022-06-24 20:47:14.343583
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("/usr/bin/mkdir") == '/usr/bin/mkdir'
    assert get_bin_path("mkdir") in ['/bin/mkdir', '/usr/bin/mkdir', '/usr/local/bin/mkdir']
    assert get_bin_path("nope") is None
    assert get_bin_path("nope", required=False) is None
    assert get_bin_path("nope", required=False, opt_dirs=['/bin']) is None
    assert get_bin_path("nope", required=True, opt_dirs=['/bin']) == '/bin/nope'

# Generated at 2022-06-24 20:47:24.088151
# Unit test for function get_bin_path
def test_get_bin_path():
    var_1 = '/etc/ansible/h=Dp(~r=[f8,(L#'
    int_0 = len(var_1)
    var_2 = set(var_1)
    var_3 = len(var_1)
    int_0 = len(var_1) + int('34')
    str_0 = 'UDS0l)i2&}O$YWk9'
    var_4 = get_bin_path(str_0)
    str_1 = 'I4#4u;'
    var_5 = get_bin_path(str_1)
    str_2 = '#^A+]#4B?(I7Phr&fmA'
    var_6 = get_bin_path(str_2)
    var_7 = get_bin_

# Generated at 2022-06-24 20:47:33.616245
# Unit test for function get_bin_path
def test_get_bin_path():
    # Call function get_bin_path with arguments: test_str
    try:
        test_str = '!@#$%^&*()_+'
        ans = get_bin_path(test_str)
    except ValueError as e:
        assert e.message == 'Failed to find required executable "%s" in paths: %s' % (test_str, os.pathsep.join(os.environ.get('PATH', '').split(os.pathsep)))

    # Call function get_bin_path with arguments: test_str
    try:
        test_str = 'echo'
        ans = get_bin_path(test_str)
    except ValueError as e:
        assert False

    # Call function get_bin_path with arguments: test_str, opt_dirs

# Generated at 2022-06-24 20:47:39.849556
# Unit test for function get_bin_path
def test_get_bin_path():

    p1 = get_bin_path('sh')
    assert p1.endswith('sh')

    try:
        p1 = get_bin_path('this_is_not_exiting')
    except ValueError as e:
        pass
    except Exception as e:
        raise AssertionError("Failed with incorrect exception")


if __name__ == "__main__":
    test_get_bin_path()
    print('Test passed')

# Generated at 2022-06-24 20:47:41.323157
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)
    test_case_0()

# Generated at 2022-06-24 20:47:42.167382
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None

# Generated at 2022-06-24 20:47:49.678362
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("hostname") == "/bin/hostname"
    assert get_bin_path("hostname", opt_dirs=['/bin', '/sbin']) == "/bin/hostname"
    assert get_bin_path("hostname", opt_dirs=['/bin', '/sbin'], required=True) == "/bin/hostname"
    try:
        get_bin_path("hostname", opt_dirs=['/bin', '/sbin', '/usr/bin']) == "/bin/hostname"
    except ValueError as e:
        assert "Failed to find required executable \"hostname\" in paths: /bin:/sbin:/usr/bin" == str(e)

# Generated at 2022-06-24 20:47:55.473092
# Unit test for function get_bin_path
def test_get_bin_path():
    assert var_0 is not None
    assert var_0 == '/usr/bin/xz'

test_case_0()

# Generated at 2022-06-24 20:48:00.648308
# Unit test for function get_bin_path
def test_get_bin_path():
    assert "test_client_config" in globals(), "global variable test_client_config is not present"
    assert "test_client_config" not in locals(), "local variable test_client_config is present"

    str_0 = '#^A+]#4B?(I7Phr&fmA'
    var_0 = get_bin_path(str_0)
    assert not var_0


# Generated at 2022-06-24 20:48:01.657869
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == 'B'

# Generated at 2022-06-24 20:48:04.112746
# Unit test for function get_bin_path
def test_get_bin_path():
    # Mock argument and context
    # Function execution
    str_0 = '#^A+]#4B?(I7Phr&fmA'
    try:
        test_case_0()
    except ValueError:
        pass



# Generated at 2022-06-24 20:48:09.967293
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 'ntpd' in get_bin_path('ntpd')
    assert 'ntpd' not in get_bin_path('ntpd', opt_dirs=['/bin', '/usr/bin'])
    pass

# Generated at 2022-06-24 20:48:19.266610
# Unit test for function get_bin_path
def test_get_bin_path():
    '''
    Execute a series of tests to verify the functionality of function get_bin_path
    '''
    # Get the path to the system executable "ls"
    ls_path = get_bin_path("ls")
    assert ls_path is not None
    assert "ls" in ls_path

    # Verify that an exception is raised when the executable is not found
    try:
        get_bin_path("some_non_existent_executable")
    except ValueError:
        pass
    else:
        assert False

    # Verify that an optional list of directories to search in addition to PATH are supported
    ls_path2 = get_bin_path("ls", [os.path.dirname(ls_path)])
    assert ls_path2 == ls_path

    # Verify that an exception is still raised when the executable is not found


# Generated at 2022-06-24 20:48:29.993480
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("ansible") == "/usr/local/bin/ansible"
    assert get_bin_path("ls") == "/bin/ls"
    assert get_bin_path("/bin/ls") == "/bin/ls"
    assert get_bin_path("/usr/bin/python") == "/usr/bin/python"
    assert get_bin_path("python") == "/usr/bin/python"
    assert get_bin_path("python3") == "/usr/bin/python3"

    if os.path.exists("/usr/local/bin/python"):
        assert get_bin_path("/usr/local/bin/python") == "/usr/local/bin/python"

    if os.path.exists("/usr/local/bin/python3"):
        assert get_bin_

# Generated at 2022-06-24 20:48:32.745828
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '#^A+]#4B?(I7Phr&fmA'
    var_0 = get_bin_path(str_0)

# Generated at 2022-06-24 20:48:35.267012
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('gcc') == '/usr/bin/gcc'

# Generated at 2022-06-24 20:48:37.097745
# Unit test for function get_bin_path
def test_get_bin_path():
    "Test to get the path of a executable"
    assert True == isinstance(test_case_0(), str)

# Generated at 2022-06-24 20:48:44.895305
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 'MY_ENV_VAR' not in os.environ
    try:
        os.environ['MY_ENV_VAR'] = '/some/path'
        test_case_0()
    finally:
        del os.environ['MY_ENV_VAR']

# Generated at 2022-06-24 20:48:45.912636
# Unit test for function get_bin_path
def test_get_bin_path():
    pass


# Generated at 2022-06-24 20:48:55.443736
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '6B?(I7Phr&fmA'
    str_1 = ''
    str_2 = 'df'
    str_3 = 'ls'
    str_4 = 'df'
    str_5 = 'ls'
    str_6 = '6B?(I7Phr&fmA'
    str_7 = ''
    str_8 = 'df'
    str_9 = 'ls'
    str_10 = 'df'
    str_11 = 'ls'
    try:
        var_0 = get_bin_path(str_0)
    except:
        var_0 = None
    try:
        var_1 = get_bin_path(str_1)
    except:
        var_1 = None

# Generated at 2022-06-24 20:48:57.922335
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = str(get_bin_path('#^A+]#4B?(I7Phr&fmA'))
    print(str_0)

test_get_bin_path()

# Generated at 2022-06-24 20:49:01.826465
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = '#^A+]#4B?(I7Phr&fmA'
    opt_dirs_0 = ['/usr/bin', '/usr/sbin', '/bin']
    var_0 = get_bin_path(arg_0, opt_dirs_0)
    print(var_0)



# Generated at 2022-06-24 20:49:05.752233
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '#^A+]#4B?(I7Phr&fmA'
    var_0 = get_bin_path(str_0)
    assert var_0 == '/usr/bin/ssh-keygen'

# Generated at 2022-06-24 20:49:08.157808
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path('$PATH')
    assert var_0 == '$PATH'

# Generated at 2022-06-24 20:49:17.060386
# Unit test for function get_bin_path
def test_get_bin_path():
    assert not get_bin_path('/bin//sh') == '/bin//sh'
    assert not get_bin_path('/bin/sh') == '/bin/sh'
    assert not get_bin_path('/bin/sh') == '/bin/sh'
    assert not get_bin_path('/bin//sh') == '/bin//sh'
    assert get_bin_path('/bin//sh') == '/bin/sh'
    assert not get_bin_path('/bin//sh') == '/bin//sh'
    assert not get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert not get_bin_path('/bin//sh') == '/bin//sh'

# Generated at 2022-06-24 20:49:22.368555
# Unit test for function get_bin_path
def test_get_bin_path():
    os_env_backup = dict(os.environ)
    del os.environ['PATH']

    try:
        assert test_case_0() == None, "Function returned unexpected result"
    finally:
        os.environ.clear()
        os.environ.update(os_env_backup)

# Generated at 2022-06-24 20:49:28.400042
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = '#^A+]#4B?(I7Phr&fmA'
    opt_dirs = []
    required = None
    try:
        get_bin_path(arg, opt_dirs, required)
        assert False
    except ValueError:
        assert True


# Unit Test

# Generated at 2022-06-24 20:49:40.639626
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:49:42.421325
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:49:51.735000
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert True == True
        test_case_0()
    except (AssertionError, ValueError) as e:
        raise(e)

# Generated from test-case-0
# 81 chars long, 0x50 == 'P'
str_0 = '#^A+]#4B?(I7Phr&fmA'
# Generated from test-case-1
# 25 chars long, 0x11 == '\x11'
str_1 = '<0\x11o5u\x11PQ7O`'
# Generated from test-case-2
# 23 chars long, 0x18 == '\x18'
str_2 = '\x18d;_9>\x18Q2\x18$,'
# Generated from test-case-3
# 18 chars long,

# Generated at 2022-06-24 20:49:57.023831
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ['PATH'] += ':' + os.path.dirname(os.path.realpath(__file__))
    assert isinstance(get_bin_path('ansible-test-file'), str)
    assert isinstance(get_bin_path('ansible-test-file'), str)
    assert isinstance(get_bin_path('ansible-test-file'), str)

# Generated at 2022-06-24 20:50:02.283608
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '#^A+]#4B?(I7Phr&fmA'
    var_0 = get_bin_path(str_0)

# Generated at 2022-06-24 20:50:03.701736
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError:
        pass
    else:
        raise Exception("should throw ValueError")

# Generated at 2022-06-24 20:50:10.131156
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    # Exception Handler:
    except:
        pass

# Main function
if __name__ == "__main__":
    # Calling main function
    test_get_bin_path()

# Generated at 2022-06-24 20:50:19.550333
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path('')
    var_1 = get_bin_path('', required=True)
    var_2 = get_bin_path('', opt_dirs=['/bin'])
    var_3 = get_bin_path('', opt_dirs=['/bin'], required=True)
    var_4 = lambda str_0: get_bin_path(str_0)
    var_5 = lambda str_0: get_bin_path(str_0, required=True)
    var_6 = lambda str_0: get_bin_path(str_0, opt_dirs=['/bin'])
    var_7 = lambda str_0: get_bin_path(str_0, opt_dirs=['/bin'], required=True)

# Generated at 2022-06-24 20:50:24.404507
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert os.environ['PATH']
    except KeyError:
        os.environ['PATH'] = ''
    # Test with required = None
    try:
        get_bin_path('test_file')
    except ValueError:
        pass
    except Exception:
        assert False, 'Expected ValueError, but got %s' % (traceback.format_exc().splitlines()[-1])
    else:
        assert False, "Expected ValueError"

# Generated at 2022-06-24 20:50:29.973882
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)
    # Test with default values for arguments
    test_case_0()

# Generated at 2022-06-24 20:50:35.111186
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


# This lets us unit test the main path and the debug path.

# Generated at 2022-06-24 20:50:38.299326
# Unit test for function get_bin_path
def test_get_bin_path():
    hash_int_0 = 1455246071
    str_0 = ''
    hash_int_x_0 = 6775809
    str_1 = ' %8W"+:@vJ`<^`F'
    str_2 = '2.10'
    str_3 = ' %8W"+:@vJn9'
    str_4 = ' %8W"+:@vJn9'
    str_5 = ' %8W"+:@vJn9'
    str_6 = ' %8W"+:@vJn9'


# Generated at 2022-06-24 20:50:47.383903
# Unit test for function get_bin_path
def test_get_bin_path():
    # Full path to script will be '/ansible/test/integration/targets/generic/helpers/ansible_test/_from_command_line_test.py'
    # The following is a simple test, assuming that we are testing
    # the _from_command_line_test script
    str_0 = '_from_command_line_test.py'
    var_0 = get_bin_path(str_0)
    assert var_0, 'Script cannot be found: "_from_command_line_test.py"'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:50:48.633141
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None



# Generated at 2022-06-24 20:50:55.920679
# Unit test for function get_bin_path
def test_get_bin_path():
    assert isinstance(get_bin_path('/bin/cat'), str)
    assert isinstance(get_bin_path('/bin/cat', ['/usr/bin']), str)
    try:
        get_bin_path('this-does-not-exist-and-should-fail')
        assert False, 'get_bin_path did not error on a missing command'
    except ValueError:
        pass
    # Test that feature works on a non-standard path
    os.environ['PATH'] = '/bin'
    assert get_bin_path('cat') == '/bin/cat'

# Generated at 2022-06-24 20:50:56.989545
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert False
    except AssertionError as e:
        raise e

# Generated at 2022-06-24 20:51:05.592536
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 'F#yJhXB}jIfft8' == 'k~*x-'
    assert -14.858732712894102 == -14.858732712894102
    assert 'pkFx{' == 'pkFx{'

# Generated at 2022-06-24 20:51:15.339694
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/pwd') == '/bin/pwd'
    assert get_bin_path('/bin/bogus') == '/bin/bogus'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/ls', opt_dirs=['/usr/bin']) == '/bin/ls'
    assert get_bin_path('pwd') == '/bin/pwd'
    assert get_bin_path('/bin/bogus', opt_dirs=['/usr/bin']) == '/usr/bin/bogus'
    assert get_bin_path('/bin/bogus', opt_dirs=['/usr/bin', '/usr/sbin']) == '/usr/sbin/bogus'

# Generated at 2022-06-24 20:51:22.276110
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("nmap").lower().endswith("nmap")
    assert get_bin_path("nmap", [])
    assert get_bin_path("nmap", ["/usr/bin"])
    assert get_bin_path("nmap", ["/usr/bin"], True)
    try:
        get_bin_path("nmap", ["NON-EXISTENT-PATH"])
        assert False, "should have raised ValueError"
    except ValueError:
        pass

# Generated at 2022-06-24 20:51:27.790783
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '0{,K*6p9X!#S?6#+qqF&'
    var_0 = get_bin_path(str_0, opt_dirs=['1r7K!+', None, '7E$M+>uV7'], required=None)


# Generated at 2022-06-24 20:51:41.350570
# Unit test for function get_bin_path
def test_get_bin_path():
    # Sanity
    assert get_bin_path('ls')
    assert get_bin_path('ls', required=True)

    # Locate a file in a path
    # Note: do not run this test on a system that does not have
    # /sbin/sysctl
    # If this test fails and /sbin/sysctl exists, the test runner is
    # likely setting an empty PATH
    assert get_bin_path('sysctl', ['/sbin'])

    # Make sure we are getting the correct executable back
    assert get_bin_path('sysctl', ['/sbin']) != get_bin_path('sysctl', ['/bin'])

    # Do not find any valid executable

# Generated at 2022-06-24 20:51:42.394587
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True


# Generated at 2022-06-24 20:51:47.004977
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(len(get_bin_path('#^A+]#4B?(I7Phr&fmA')) > 0)
    assert(len(get_bin_path('#^A+]#4B?(I7Phr&fmA', [])) > 0)
    assert(len(get_bin_path('#^A+]#4B?(I7Phr&fmA', [])) > 0)


# Generated at 2022-06-24 20:51:48.148119
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:51:54.920381
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        # pylint: disable=line-too-long
        assert var_0 == 'neon/bin/neon-build', 'Expected function return is: neon/bin/neon-build'
        # pylint: enable=line-too-long
        print('test_get_bin_path: PASS')
    except AssertionError as exc:
        print(exc)
        print('test_get_bin_path: FAIL')


if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:52:04.164939
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(
        '#^A+]#4B?(I7Phr&fmA') == '/bin/%s' % ('#^A+]#4B?(I7Phr&fmA')
    assert get_bin_path('#^A+]#4B?(I7Phr&fmA',opt_dirs=['/bin']) == '/bin/%s' % ('#^A+]#4B?(I7Phr&fmA')
    assert get_bin_path('#^A+]#4B?(I7Phr&fmA',opt_dirs=['/bin'],required=True) == '/bin/%s' % ('#^A+]#4B?(I7Phr&fmA')

# Generated at 2022-06-24 20:52:06.923832
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '#^A+]#4B?(I7Phr&fmA'
    var_0 = get_bin_path(str_0)



# Generated at 2022-06-24 20:52:15.596963
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = '^'
    var_1 = '#'
    var_2 = '^'
    var_3 = '"'
    var_4 = '^'
    var_5 = 'A'
    var_6 = '^'
    var_7 = '+'
    var_8 = '^'
    var_9 = ']'
    var_10 = '^'
    var_11 = '#'
    var_12 = '^'
    var_13 = '4'
    var_14 = '^'
    var_15 = 'B'
    var_16 = '^'
    var_17 = '?'
    var_18 = '^'
    var_19 = '('
    var_20 = '^'
    var_21 = 'I'

# Generated at 2022-06-24 20:52:22.979336
# Unit test for function get_bin_path
def test_get_bin_path():
    required = None
    opt_dirs = None
    assert get_bin_path('python', []) == None
    assert get_bin_path('python', [], required) == None
    assert get_bin_path('python', opt_dirs) == None
    assert get_bin_path('python', opt_dirs, required) == None
    assert get_bin_path('python', opt_dirs, required) == None
    assert get_bin_path('python', opt_dirs, required) == None
    assert get_bin_path('python', opt_dirs, required) == None
    assert get_bin_path('python', opt_dirs, required) == None
    assert get_bin_path('python', opt_dirs, required) == None

# Generated at 2022-06-24 20:52:24.706564
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '#^A+]#4B?(I7Phr&fmA'
    var_0 = get_bin_path(str_0)



# Generated at 2022-06-24 20:52:33.011757
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 20:52:34.075042
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('echo') is not None

# Generated at 2022-06-24 20:52:45.191699
# Unit test for function get_bin_path
def test_get_bin_path():

    # noinspection PyUnusedLocal
    def sub_test_case():

        # noinspection PyUnusedLocal
        def sub_test_case_0():
            var_0 = get_bin_path(str_0, opt_dirs=None, required=None)

        # noinspection PyUnusedLocal
        def sub_test_case_1():
            var_0 = get_bin_path(str_0, opt_dirs=list_0, required=None)

    # noinspection PyUnusedLocal
    def sub_test_case_0():
        str_0 = '#^A+]#4B?(I7Phr&fmA'
        var_0 = get_bin_path(str_0)

    # noinspection PyUnusedLocal

# Generated at 2022-06-24 20:52:47.423451
# Unit test for function get_bin_path
def test_get_bin_path():

    str_0 = 'od'
    var_0 = get_bin_path(str_0)
    assert var_0 == '/bin/od'


# Generated at 2022-06-24 20:52:48.255931
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible') is not None

# Generated at 2022-06-24 20:52:50.490759
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 'false' == get_bin_path('false')

if __name__ == '__main__':
    test_get_bin_path()
    test_case_0()

# Generated at 2022-06-24 20:52:55.485926
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '#^A+]#4B?(I7Phr&fmA'
    var_0 = get_bin_path(str_0)

    assert var_0 is not None

# Generated at 2022-06-24 20:52:57.981046
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cat') == 'cat'
    assert get_bin_path('ls') == 'ls'
    assert get_bin_path('find') == 'find'
    assert get_bin_path('which') == 'which'

# Generated at 2022-06-24 20:53:04.226602
# Unit test for function get_bin_path
def test_get_bin_path():
    # method invocation
    try:
        from ansible.module_utils.basic import AnsibleModule
        ansible_module = AnsibleModule(
            argument_spec = dict(),

        )

        # function invocation
        result = get_bin_path(ansible_module)
    except Exception as e:
        result = 'Exception: %s' % (e,)

    assert result is not None and result == 'success'

# Generated at 2022-06-24 20:53:04.802006
# Unit test for function get_bin_path
def test_get_bin_path():

    assert True

# Generated at 2022-06-24 20:53:10.367709
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()
    assert True

# Generated at 2022-06-24 20:53:13.374439
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)
    try:
        get_bin_path('a|b')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-24 20:53:15.878836
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '5p,GR3<d$1v@-nL6HYEK'
    var_0 = get_bin_path(str_0)


# Generated at 2022-06-24 20:53:16.763233
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path_0()

# Generated at 2022-06-24 20:53:23.143333
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/echo') == '/bin/echo'
    assert get_bin_path('sudo') == '/usr/bin/sudo'
    try:
        get_bin_path('a-path-that-does-not-exist')
    except ValueError:
        pass


# Generated at 2022-06-24 20:53:29.653889
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = '#^A+]#4B?(I7Phr&fmA'
    var_0 = get_bin_path(arg_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 20:53:41.011054
# Unit test for function get_bin_path
def test_get_bin_path():
    # get_bin_path() without parameters
    try:
        get_bin_path()
    except TypeError as e:
        pass
    else:
        print('Failed to raise expected TypeError')

    # get_bin_path() with required parameter
    try:
        get_bin_path(str_0)
    except ValueError as e:
        pass
    else:
        print('Failed to raise expected ValueError')

    # get_bin_path() with required parameter and True value for required
    try:
        get_bin_path(str_0, required=True)
    except ValueError as e:
        pass
    else:
        print('Failed to raise expected ValueError')

    # get_bin_path() with required parameter and True value for required and empty opt_dirs list

# Generated at 2022-06-24 20:53:43.138378
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() is None

if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:53:50.668386
# Unit test for function get_bin_path
def test_get_bin_path():
    assert func_0.__name__ == "get_bin_path", "Function name is wrong"
    assert func_0.__doc__ == " Find system executable in PATH. Raises ValueError if executable is not found.\n    Optional arguments:\n       - required:  [Deprecated] Prior to 2.10, if executable is not found and required is true it raises an Exception.\n                    In 2.10 and later, an Exception is always raised. This parameter will be removed in 2.14.\n       - opt_dirs:  optional list of directories to search in addition to PATH\n    If found return full path, otherwise raise ValueError.\n    ", "Function docstring is wrong"


# Generated at 2022-06-24 20:53:52.587253
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        testcase_0()
        testcase_1()
    except:
        print('Fail')
    else:
        print('Pass')



# Generated at 2022-06-24 20:53:59.064133
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as e:
        print(e)

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:53:59.585143
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-24 20:54:05.160669
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('vi', opt_dirs=['/usr/bin', '/usr/local/bin', '/bin']) == '/usr/bin/vi'
    assert get_bin_path('rm', opt_dirs=['/usr/bin', '/usr/local/bin', '/bin']) == '/bin/rm'
    assert get_bin_path('echo', opt_dirs=['/bin', '/usr/local/bin', '/usr/bin']) == '/bin/echo'



# Generated at 2022-06-24 20:54:10.847406
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        str_1 = 'gDD%[Pxn8'
        var_1 = get_bin_path(str_1)
    except ValueError as e:
        raise AssertionError('get_bin_path will not take %s as an argument' % repr(str_1))

    try:
        str_2 = 'gDD%[Pxn8'
        var_2 = get_bin_path(str_2, required=True)
    except ValueError as e:
        raise AssertionError('get_bin_path will not take %s as an argument' % repr(str_2))


# Generated at 2022-06-24 20:54:15.459729
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '#^A+]#4B?(I7Phr&fmA'
    var_0 = get_bin_path(str_0)
    expected = '#^A+]#4B?(I7Phr&fmA'
    assert expected == var_0


# Generated at 2022-06-24 20:54:20.676910
# Unit test for function get_bin_path
def test_get_bin_path():
    bin_path = get_bin_path('true')
    assert bin_path is not None
    assert os.path.exists(bin_path)
    assert not os.path.isdir(bin_path)
    assert is_executable(bin_path)

# Generated at 2022-06-24 20:54:23.277662
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '#^A+]#4B?(I7Phr&fmA'
    var_0 = get_bin_path(str_0)
    assert var_0 == '/bin/sh'

# Generated at 2022-06-24 20:54:27.372920
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '#^A+]#4B?(I7Phr&fmA'
    str_1 = '76uxh!b8=0:rG0wH+'
    var_0 = get_bin_path(str_0)
    var_1 = get_bin_path(str_1)


# Generated at 2022-06-24 20:54:37.413759
# Unit test for function get_bin_path
def test_get_bin_path():
    str_1 = 'make'
    opt_dirs_1 = ['/usr/bin', '/usr/bin/']
    var_1 = get_bin_path(str_1, opt_dirs_1)
    assert(var_1 == '/usr/bin/make')

    str_2 = 'make'
    opt_dirs_2 = ['/usr/bin', '/usr/bin/', '/usr/bin/make']
    var_2 = get_bin_path(str_2, opt_dirs_2)
    assert(var_2 == '/usr/bin/make')

    str_3 = 'make'
    opt_dirs_3 = ['/usr/bin', '/usr/bin/', '/usr/bin/make', None]

# Generated at 2022-06-24 20:54:41.086861
# Unit test for function get_bin_path
def test_get_bin_path():
    # Reset cdb_var_t to its initial state
    cdb_var_t = {}
    cdb_var_t['cdb_var_t'] = test_case_0()
    # Evaluate test case's assertion(s)
    assert cdb_var_t['cdb_var_t'] is None

# Generated at 2022-06-24 20:54:54.836099
# Unit test for function get_bin_path
def test_get_bin_path():
    var_1 = get_bin_path('git', opt_dirs=None, required=None)
    assert var_1 == '/usr/bin/git', 'Unexpected value returned by get_bin_path'
    var_2 = get_bin_path('/sbin/savecore', opt_dirs=None, required=None)
    assert var_2 == '/sbin/savecore', 'Unexpected value returned by get_bin_path'
    var_3 = get_bin_path('/usr/sbin/savecore', opt_dirs=['/usr/bin'], required=None)
    assert var_3 == '/usr/sbin/savecore', 'Unexpected value returned by get_bin_path'

if __name__ == '__main__':
    test_case_0()
    test_get_bin_

# Generated at 2022-06-24 20:55:03.780592
# Unit test for function get_bin_path
def test_get_bin_path():
    test_0 = [('M8"MNf-@', ['/sbin', '/usr/sbin', '/usr/local/sbin', '/opt/local/sbin', '/usr/sbin', '/sbin'], True)]
    for x in test_0:
        start_time = time.time()
        var_0 = get_bin_path(x[0], x[1], x[2])
        end_time = time.time()
        assert var_0 is not None
        print('get_bin_path() took %.2f seconds on test case: %s' % (end_time - start_time, x))

# Generated at 2022-06-24 20:55:05.471887
# Unit test for function get_bin_path
def test_get_bin_path():
    assert set(get_bin_path('x')) == set(('x', 'y'))

# Generated at 2022-06-24 20:55:06.378291
# Unit test for function get_bin_path
def test_get_bin_path():
    assert  test_get_bin_path() == True

# Generated at 2022-06-24 20:55:09.264452
# Unit test for function get_bin_path
def test_get_bin_path():
    print(get_bin_path.__doc__)

    try:
        test_case_0()
    except ValueError as e:
        print (e)

# Generated at 2022-06-24 20:55:13.301792
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = get_bin_path('#^A+]#4B?(I7Phr&fmA')


if __name__ == '__main__':
    test_get_bin_path()
    test_case_0()

# Generated at 2022-06-24 20:55:17.688362
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '#^A+]#4B?(I7Phr&fmA'
    var_0 = get_bin_path(str_0)
    assert var_0 == '/bin/gcc', 'Expected: "/bin/gcc", Got: "%s"' % var_0


# Generated at 2022-06-24 20:55:25.387617
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', ['/usr/bin', '/usr/local/bin']) == '/usr/bin/python'
    assert get_bin_path('python', ['/usr/local/bin', '/usr/bin']) == '/usr/bin/python'
    try:
        get_bin_path('python2.7')
        assert False
    except ValueError:
        assert True
    # try:
    #     get_bin_path('something which does not exist', required=True)
    #     assert False
    # except ValueError:
    #     assert True

# Generated at 2022-06-24 20:55:26.619442
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:55:27.725540
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0()

# Generated at 2022-06-24 20:55:34.232044
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '$%@)7+]6B:)3Bf&F9CL'
    var_0 = get_bin_path(str_0)

# Generated at 2022-06-24 20:55:42.228004
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '#^A+]#4B?(I7Phr&fmA'
    var_0 = get_bin_path(str_0)
    assert os.path.exists(var_0) and is_executable(var_0)

    str_0 = os.path.basename(var_0)
    var_0 = get_bin_path(str_0)
    assert var_0 == os.path.join(os.path.dirname(var_0), str_0)

    var_0 = get_bin_path(str_0, [os.path.dirname(var_0)])
    assert var_0 == os.path.join(os.path.dirname(var_0), str_0)


# Generated at 2022-06-24 20:55:47.782158
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(test_case_0() == None)

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:55:49.871348
# Unit test for function get_bin_path
def test_get_bin_path():
    assert not get_bin_path('ansible-playbook', required=True)
    assert not get_bin_path('ansible-playbook', required=False)

# Generated at 2022-06-24 20:55:50.955913
# Unit test for function get_bin_path
def test_get_bin_path():
    print("Testing function get_bin_path")
    test_case_0()

# Generated at 2022-06-24 20:55:52.215143
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(None)


# Generated at 2022-06-24 20:55:57.407888
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('stack') == '/usr/bin/stack'
    assert get_bin_path('stack', required=True) == '/usr/bin/stack'
    assert get_bin_path('stack', opt_dirs=['/usr']) == '/usr/bin/stack'
    assert get_bin_path('stack', opt_dirs=['/usr', '/usr/bin']) == '/usr/bin/stack'
    assert get_bin_path('stack', opt_dirs=['/usr/local', '/usr/local/bin']) == '/usr/local/bin/stack'