

# Generated at 2022-06-24 20:46:04.281145
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test case 0
    assert test_case_0() == None, 'Failed Test case 0 failed'

# Test run
test_get_bin_path()

# Generated at 2022-06-24 20:46:05.977367
# Unit test for function get_bin_path
def test_get_bin_path():
    assert not test_case_0()

if __name__ == '__main__':
    test()

# Generated at 2022-06-24 20:46:08.720807
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
        print('test 1 [ok]')
    except Exception as e:
        print('test 1 [error]')
        print(e)


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:46:09.983478
# Unit test for function get_bin_path
def test_get_bin_path():
    # Assert that the function can handle an empty string
    get_bin_path('')

# Generated at 2022-06-24 20:46:10.540667
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-24 20:46:11.445795
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() is None

# Generated at 2022-06-24 20:46:12.640548
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('cupiditate') == 'cupiditate'

# Generated at 2022-06-24 20:46:17.327316
# Unit test for function get_bin_path
def test_get_bin_path():
    expected_0 = ''
    str_0 = ';/.;L;'
    var_0 = get_bin_path(str_0)
    assert var_0 == expected_0

# Test for check that file path exists and can be executed

# Generated at 2022-06-24 20:46:25.017291
# Unit test for function get_bin_path
def test_get_bin_path():
    # No options
    assert get_bin_path('ls') is not None
    # Simple string
    assert get_bin_path('ls', '.') is not None
    # Simple array
    assert get_bin_path('ls', ['.']) is not None
    # Complex array
    assert get_bin_path('ls', ['.', '..', '../..']) is not None
    # Path does not exist
    try:
        get_bin_path('ls', 'bad_path')
        assert False
    except ValueError:
        pass
    # File does not exist
    try:
        get_bin_path('file_does_not_exist')
        assert False
    except ValueError:
        pass
    # Test executable
    assert is_executable(get_bin_path('ls'))
    # Test not executable

# Generated at 2022-06-24 20:46:28.495852
# Unit test for function get_bin_path
def test_get_bin_path():
    # Create args
    str_0 = '/G_bJl]I+D'

    # Call function
    var_0 = get_bin_path(str_0, str_0)

    # AssertionError: Failed to find required executable "/G_bJl]I+D" in paths: /G_bJl]I+D

# Generated at 2022-06-24 20:46:33.293998
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = ';}s//;Lbp'
    var_0 = get_bin_path(str_0, str_0)
    assert var_0 == ';'


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:46:38.876053
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:46:42.748736
# Unit test for function get_bin_path
def test_get_bin_path():
    obj = None
    try:
        test_case_0()
    except (TypeError) as exc:
        obj = exc

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:46:44.381496
# Unit test for function get_bin_path
def test_get_bin_path():
    # TODO: Fix the assertion
    # assert <expected value> == <actual value>
    assert True



# Generated at 2022-06-24 20:46:53.052849
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(';' if False else '')
    assert get_bin_path(';' if False else '', '/usr/bin:/usr/local/bin')
    assert get_bin_path(';' if False else '', '' if False else '/usr/bin:/usr/local/bin')
    assert get_bin_path(';' if False else '', '' if False else '/usr/bin:/usr/local/bin', True)
    assert get_bin_path(';' if False else '', '' if False else '/usr/bin:/usr/local/bin', False)
    assert not get_bin_path(';' if False else '', '' if False else '/usr/bin:/usr/local/bin', False)

# Generated at 2022-06-24 20:46:55.301009
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except BaseException as e:
        # Display error and skip test.
        print('Exception from test: %s' % e)
        import traceback
        traceback.print_exc()
        return False

    return True


# Generated at 2022-06-24 20:47:02.392511
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with valid inputs
    str_1 = 'var_1'
    str_2 = 'var_2'
    var_3 = get_bin_path(str_1, str_2,)
    assert isinstance(var_3, str)
    # Test with invalid inputs
    try:
        get_bin_path()
    except TypeError as e:
        print(e.message)


# Generated at 2022-06-24 20:47:07.313908
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError:
        print('caught exception')

# Generated at 2022-06-24 20:47:10.189576
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ps')
    del os.environ['PATH']
    try:
        get_bin_path('ls')
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-24 20:47:20.440068
# Unit test for function get_bin_path
def test_get_bin_path():
    var_1 = get_bin_path('echo')
    assert var_1 is not None
# This test may fail in virtual environments that don't have /sbin and /usr/sbin in the PATH
    var_2 = get_bin_path('lsof', opt_dirs=['/sbin', '/usr/sbin'])
    assert var_2 is not None
    try:
        get_bin_path('does_not_exist')
        assert False
    except ValueError as e:
        assert "Failed to find required executable" in str(e)
    var_3 = get_bin_path('echo', required=False)
    assert var_3 is not None

# Generated at 2022-06-24 20:47:26.918424
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path('foo', 'bar')
    var_2 = get_bin_path('foo', 'bar')
    test_case_0()
    print('unit test for get_bin_path')


# Generated at 2022-06-24 20:47:30.633322
# Unit test for function get_bin_path
def test_get_bin_path():
    var = get_bin_path(';', ';', ';')
    var_1 = test_case_0()

    var_2 = is_executable(var)
    var_3 = is_executable(var_1)

    assert var_2 or var_3

# Generated at 2022-06-24 20:47:37.446589
# Unit test for function get_bin_path
def test_get_bin_path():
    # Run unit test and verify expected output
    assert get_bin_path('') == ''

    # Run unit test and verify exception thrown
    try:
        get_bin_path('', [])
    except ValueError:
        pass
    else:
        raise AssertionError("Unhandled exception raised!")

    # Run unit test and verify exception thrown
    str_0 = ';'
    try:
        get_bin_path(str_0)
    except ValueError:
        pass
    else:
        raise AssertionError("Unhandled exception raised!")

    # Run unit test and verify exception thrown
    str_0 = ';'
    try:
        get_bin_path(str_0, str_0)
    except ValueError:
        pass

# Generated at 2022-06-24 20:47:40.421252
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/usr/bin/env') == '/usr/bin/env'

    try:
        get_bin_path('i_am_a_bad_executable_that_will_not_be_found')
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 20:47:44.225681
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls')
    assert get_bin_path('ls', ['/bin'])
    assert get_bin_path('ls', ['not/a/dir']) # this test is irrelevant; what is the expected result?
    assert get_bin_path('grep')
    try:
        get_bin_path('not_a_real_bin')
    except ValueError:
        assert True
    try:
        get_bin_path('not_a_real_bin', ['not/a/dir'])
    except ValueError:
        assert True
    assert get_bin_path('ls', None)
    try:
        get_bin_path('not_a_real_bin', None)
    except ValueError:
        assert True

# Generated at 2022-06-24 20:47:45.630648
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:47:46.449794
# Unit test for function get_bin_path
def test_get_bin_path():
    # Not implemented
    pass

# Generated at 2022-06-24 20:47:56.480627
# Unit test for function get_bin_path
def test_get_bin_path():
    test_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'bin_path')
    with open(os.path.join(test_path, 'requirements.txt'), 'w') as f:
        print('ansible', file=f)

# Generated at 2022-06-24 20:48:00.381439
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        str_0 = '}j4{UTka2e{'
        arg_0 = get_bin_path(str_0)
    except:
        str_1 = ';_p}D'
        arg_1 = get_bin_path(str_1)

# Generated at 2022-06-24 20:48:03.294125
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception:
        assert False

# Unit test main
if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:48:11.037736
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/ls', opt_dirs=['/usr/bin']) == '/bin/ls'
    try:
        get_bin_path('/bin/ls', opt_dirs=['/usr/bin'], required=True)
    except ValueError:
        assert True
    try:
        get_bin_path('ls', opt_dirs=['/usr/bin'])
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-24 20:48:21.220253
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path('locate')
    assert var_0 == '/usr/bin/locate'

    var_0 = get_bin_path('/usr/bin/locate', ['/usr/bin'])
    assert var_0 == '/usr/bin/locate'

    var_0 = get_bin_path('gcloud')
    assert 'gcloud' in var_0

    var_0 = get_bin_path('banana', ['/bin', '/usr/bin'])
    assert var_0 == '/usr/bin/banana'

    var_0 = get_bin_path('locate', ['/sbin'])
    assert var_0 == '/usr/bin/locate'

    var_0 = get_bin_path('locate', ['/sbin'])
    assert var_

# Generated at 2022-06-24 20:48:30.116618
# Unit test for function get_bin_path
def test_get_bin_path():
    os.environ = {}

    # Test type str
    var_0 = ';'
    var_1 = [var_0, 's//;Lbp']
    var_3 = var_1[1] in var_1
    var_4 = var_1[1]

    try:
        var_5 = get_bin_path(var_0, var_1)
    except Exception as e:
        print('Exception caught: ', e)
        assert('Failed to find required executable' in str(e))

    # Test type list
    var_0 = ['\';', ';zrjr\\;\\']
    var_1 = [var_0, 's//;Lbp']
    var_3 = var_1[1] in var_1
    var_4 = var_1[1]

   

# Generated at 2022-06-24 20:48:32.132000
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:48:38.390241
# Unit test for function get_bin_path
def test_get_bin_path():
    # Paths string to test
    str_0 = ';}s//;Lbp'

    # Calling get_bin_path with argument (str_0, str_0)
    var_0 = get_bin_path(str_0, str_0)

    # Ensure that the required binary has been found in the path
    assert var_0 is not None


# Generated at 2022-06-24 20:48:39.577423
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(str_0, str_0)

# Generated at 2022-06-24 20:48:44.768570
# Unit test for function get_bin_path
def test_get_bin_path():
    func_name = sys._getframe().f_code.co_name
    try:
        test_case_0()
        print("Test " + func_name + ": OK")
    except:
        print("Test " + func_name + ": FAILED")


# Run tests on function
if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:48:45.912894
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(get_bin_path("python"))

# Generated at 2022-06-24 20:48:55.444182
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '${#}' is ''
    assert '!e' is '!e'
    assert str(2) is '2'
    assert 'I/6p' is 'I/6p'
    assert '"Y#M' is '"Y#M'
    assert '$i0)u' is '$i0)u'
    assert str([] or {}) is '[]'
    assert ')%o' is ')%o'
    assert str(2.0) is '2.0'
    assert str([]) is '[]'
    assert '4#' is '4#'
    assert 'N&"%' is 'N&"%'
    assert str(1.0) is '1.0'
    assert '[mJX' is '[mJX'

# Generated at 2022-06-24 20:48:56.195256
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path(';', [], 1)

# Generated at 2022-06-24 20:48:59.910173
# Unit test for function get_bin_path
def test_get_bin_path():
    var_1 = get_bin_path('x', 'LQ>')


# Generated at 2022-06-24 20:49:00.994848
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('', '', False)


# Generated at 2022-06-24 20:49:06.838524
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = ';}s//;Lbp'
    arg_1 = ';}s//;Lbp'
    get_bin_path(arg_0, arg_1)

if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:49:12.189477
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 'ansible' == get_bin_path('ansible')



# Generated at 2022-06-24 20:49:16.545562
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = 'sed'
    var_1 = 'uname'
    var_2 = get_bin_path(var_0)
    var_3 = get_bin_path(var_1)


if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:49:19.256391
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception:
        print('Unit test failed.')


# Generated at 2022-06-24 20:49:30.096443
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = ';'
    str_1 = ';5'
    var_0 = get_bin_path(str_0, str_1)
    str_0 = '4'
    str_1 = 'P'
    var_0 = get_bin_path(str_0, str_1)
    str_0 = '>'
    var_0 = get_bin_path(str_0)
    str_0 = 'B'
    str_1 = 'n'
    var_0 = get_bin_path(str_0, str_1)
    str_0 = ','
    str_1 = 'f'
    var_0 = get_bin_path(str_0, str_1)
    str_0 = 'X'
    str_1 = 'u'
    var_0

# Generated at 2022-06-24 20:49:33.282711
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except:
        assert(False)


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:49:34.205202
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:49:37.033311
# Unit test for function get_bin_path
def test_get_bin_path():
    import pytest
    with pytest.raises(ValueError) as excinfo:
        get_bin_path('/tmp')

    assert 'Failed to find required executable' in str(excinfo.value)



# Generated at 2022-06-24 20:49:46.645496
# Unit test for function get_bin_path
def test_get_bin_path():
    # Testing with optional var opt_dirs set to ']m$`'
    str_0 = ']=?2_U'
    str_1 = ']=?2_U'
    var_1 = get_bin_path(str_1, str_0)
    assert var_1 == '/bin/x'
    # Testing with optional var required set to '&>|;V7'
    str_3 = '&>|;V7'
    str_4 = '[OQG'
    var_2 = get_bin_path(str_4, None, str_3)
    assert var_2 == '/usr/bin/x'
    # Testing with optional var opt_dirs set to 'l&H2'
    str_5 = 'l&H2'
    str_6 = '<">1'
   

# Generated at 2022-06-24 20:49:47.227438
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-24 20:49:57.259543
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = ';f/;Lbp'
    var_0 = get_bin_path(str_0, str_0)
    str_1 = ';f/;Lbp'
    str_2 = ';f/;Lbp'
    var_1 = get_bin_path(str_1, str_2)
    str_3 = ';f/;Lbp'
    str_4 = ';f/;Lbp'
    var_2 = get_bin_path(str_3, str_4)
    str_5 = ';f/;Lbp'
    var_3 = get_bin_path(str_5, str_5)
    str_6 = ';f/;Lbp'
    var_4 = get_bin_path(str_6, str_6)
   

# Generated at 2022-06-24 20:50:02.545919
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = ')))+//{g]?]B'
    var_0 = get_bin_path(str_0)
    assert var_0 == '/usr/bin/uuidgen'

# Generated at 2022-06-24 20:50:08.284913
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'bin_path'
    str_1 = 'is_executable'
    assert str_0 in globals() and 'os.path' in globals() and str_1 in globals(), "Function 'get_bin_path' should be defined"
    assert callable(get_bin_path), "Function 'get_bin_path' should be callable"
    get_bin_path('/bin/sh')
    get_bin_path('/bin/bash')
    get_bin_path('/bin/echo')
    get_bin_path('/bin/true')
    get_bin_path('/usr/bin/which')


# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-24 20:50:10.129022
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:50:11.533749
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except (ValueError):
        pass

# Generated at 2022-06-24 20:50:18.435742
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python', ['/usr/bin']) == '/usr/bin/python'
    assert get_bin_path('python') == '/usr/bin/python'
    assert get_bin_path('python', ['/usr/bin', '/usr/local/bin']) == '/usr/bin/python'
    assert get_bin_path('python', ['/usr/local/bin', '/usr/bin']) == '/usr/bin/python'
    assert get_bin_path('python', ['/usr/local/bin']) == '/usr/local/bin/python'

# Generated at 2022-06-24 20:50:23.566939
# Unit test for function get_bin_path
def test_get_bin_path():
    test_cases = [
        ['uname', 'find_unix_tools'],
    ]
    for case in test_cases:
        assert get_bin_path(case[0], case[1])

# Generated at 2022-06-24 20:50:26.324066
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Boilerplate code to call main() function
if __name__ == '__main__':
    try:
        test_get_bin_path()
    except SystemExit:
        pass

# Generated at 2022-06-24 20:50:29.525208
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError:
        # This exception is expected.
        pass
    else:
        assert False

# Generated at 2022-06-24 20:50:31.617418
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


if __name__ == '__main__':
    print('Testing function "get_bin_path"')
    test_get_bin_path()

# Generated at 2022-06-24 20:50:33.171515
# Unit test for function get_bin_path
def test_get_bin_path():
    # Run test case with arguments: ';/;Lbp' and ';}s//;Lbp'
    test_case_0()
    pass

# Generated at 2022-06-24 20:50:37.512212
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path('sed')
    test_case_0()

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:50:44.381268
# Unit test for function get_bin_path
def test_get_bin_path():
    # Note: these tests only verify the correct path is returned, not that a
    # required executable exists.
    get_bin_path('foo')
    get_bin_path('foo', ['/tmp'])
    get_bin_path('foo', ['/tmp'], required=False)
    get_bin_path('foo', ['/tmp'], required=False)
    get_bin_path('foo', ['/tmp'], required=True)
    get_bin_path('foo', ['/tmp'], required=True)
    get_bin_path('foo', ['/tmp'], required=True)
    get_bin_path('foo', ['/tmp'], required=True)
    get_bin_path('foo', ['/tmp'], required=True)

# Generated at 2022-06-24 20:50:47.239610
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = ';}s//;Lbp'
    var_0 = get_bin_path(str_0, str_0)
    test_case_0()

# Generated at 2022-06-24 20:50:50.013446
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Test :meth:`ansible.module_utils.common.file.get_bin_path` with no specific
    arguments
    """
    pass



# Generated at 2022-06-24 20:50:51.241796
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError:
        assert False

# Generated at 2022-06-24 20:50:55.918268
# Unit test for function get_bin_path
def test_get_bin_path():
    print('Testing function get_bin_path...')

    test_case_0()

    print('Testing function get_bin_path: ok')

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:50:58.035775
# Unit test for function get_bin_path
def test_get_bin_path():
    print("Testing get_bin_path")
    test_case_0()
    print("Completed test for get_bin_path")

# Main function to test all functions

# Generated at 2022-06-24 20:51:09.241580
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '/usr/local/bin/pip'
    var_0 = get_bin_path(str_0, '/usr/local/bin')

    if var_0 == str_0:
        print('Bin path found: %s' % var_0)
    else:
        print('Bin path not found')

    str_1 = 'pip'
    var_1 = get_bin_path(str_1)

    if var_1 == str_0:
        print('Bin path found: %s' % var_0)
    else:
        print('Bin path not found')

if __name__ == "__main__":
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:51:11.165964
# Unit test for function get_bin_path
def test_get_bin_path():
    print('Test get_bin_path()')
    assert_get_bin_path()
    print('Success: test_get_bin_path')



# Generated at 2022-06-24 20:51:18.546198
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '='
    str_1 = 'N.%c'
    str_2 = 's/./&/85'
    var_0 = get_bin_path(str_0, [str_1, str_1, str_1, str_1, str_1, str_1, str_2, str_1, str_1, str_1, str_1])
    # AssertionError: Failed to find required executable "=" in paths: N.%c, N.%c, N.%c, N.%c, N.%c, N.%c, s/./&/85, N.%c, N.%c, N.%c, N.%c
    str_0 = 'R.Vu'
    str_1 = 'Z[O<1'

# Generated at 2022-06-24 20:51:20.278883
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = get_bin_path(str, None, None)

# Test class for normal call

# Generated at 2022-06-24 20:51:22.685470
# Unit test for function get_bin_path
def test_get_bin_path():
    # assert_equals()
    test_case_0()


# Boiler plate

# Generated at 2022-06-24 20:51:24.100658
# Unit test for function get_bin_path
def test_get_bin_path():
    assert {'test_case_0'}


# Generated at 2022-06-24 20:51:25.506146
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()
    assert True

# Generated at 2022-06-24 20:51:26.656078
# Unit test for function get_bin_path
def test_get_bin_path():
    # first case provided by test gen
    test_case_0()



# Generated at 2022-06-24 20:51:31.857531
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test failure of get_bin_path, passing bad arguments
    try:
        str_0 = '}d`^H=2'
        get_bin_path(str_0, str_0)
    except ValueError as err:
        print('Exception raised: {0}'.format(err))


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:51:36.024949
# Unit test for function get_bin_path
def test_get_bin_path():

    # Pass in a list of values and expect a return of the default value
    # This test passes if the function raises a ValueError
    try:
        get_bin_path('test_string', None)
    except ValueError as ve:
        pass


# Generated at 2022-06-24 20:51:39.733142
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('"}]\',') == '/usr/bin/"}]\','


# Generated at 2022-06-24 20:51:44.040569
# Unit test for function get_bin_path
def test_get_bin_path():
    test_cases = [
        # 0
        (
            ';'
            '}s/\//;Lbp'
        ),
    ]
    for test_case in test_cases:
        try:
            str_0 = test_case[0]
            var_0 = get_bin_path(str_0)
        except:
            pass


# Generated at 2022-06-24 20:51:48.977305
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("ls") == "/bin/ls"


# Generated at 2022-06-24 20:51:53.874524
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = ';'
    test_case_0()
    str_0 = ';}s//;Lbp'
    var_0 = get_bin_path(str_0, str_0)
    try:
        str_0 = ';'
        var_0 = get_bin_path(str_0, str_0)
    except ValueError as e:
        pass

# Main function

# Generated at 2022-06-24 20:51:57.475217
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("/usr/bin/env") == "/usr/bin/env"
    assert get_bin_path("/bin/sh") == "/bin/sh"
    assert get_bin_path("foo") != "foo"

# Generated at 2022-06-24 20:51:59.075392
# Unit test for function get_bin_path
def test_get_bin_path():
    arg0 = 'abcde'
    get_bin_path(arg0)


# Generated at 2022-06-24 20:52:02.807389
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test case 0
    test_case_0()

# Generated at 2022-06-24 20:52:12.349169
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'H:m8'
    var_1 = get_bin_path(str_0)
    str_2 = '2P'
    var_3 = get_bin_path(str_2, str_0, str_2)
    str_4 = 's'
    var_5 = get_bin_path(str_4, str_2, str_4)
    str_6 = 'S'
    var_7 = get_bin_path(str_4, str_2, str_4)
    str_8 = 'S!7'
    var_9 = get_bin_path(str_8, str_6, str_4)
    str_10 = '.'
    var_11 = get_bin_path(str_8, str_10, str_2)
    str_12

# Generated at 2022-06-24 20:52:22.743250
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'z0;0gab_wO!Z'
    str_1 = ';}s//;Lbp'
    str_2 = ';Bx'
    str_3 = '1'
    str_4 = 'Xo5r5J+'
    str_5 = 'u'
    str_6 = '}'
    str_7 = 'gE%'
    str_8 = '+'
    str_9 = '6l@'
    str_10 = '2y'
    str_11 = 'Tb'
    str_12 = 'D'
    str_13 = 'Y'

# Generated at 2022-06-24 20:52:28.092572
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert (get_bin_path('ls'))
        assert (get_bin_path('ls', ['/usr/bin', '/bin', '/usr/sbin', '/sbin'], False))
        assert (get_bin_path('ls', ['/usr/bin', '/bin', '/usr/sbin', '/sbin'], None))
        assert (get_bin_path('ls', ['/usr/bin', '/bin', '/usr/sbin', '/sbin']))
        assert (get_bin_path('ls', ['/usr/bin', '/bin', '/usr/sbin', '/sbin'], True))
    except ValueError:
        print('ValueError')


# Generated at 2022-06-24 20:52:33.512217
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        assert get_bin_path(str_0, str_0) == var_0, "Expected: " + var_0
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-24 20:52:38.696503
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls', None) == 'ls'
    assert get_bin_path('ls', '/bin:/usr/bin') == 'ls'
    assert get_bin_path('ls', '/bin:/usr/bin:/bin/ls') == '/bin/ls'

# Generated at 2022-06-24 20:52:40.018738
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == (None)


# Generated at 2022-06-24 20:52:49.101262
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:52:57.188815
# Unit test for function get_bin_path
def test_get_bin_path():
    proper_bin_path = '/bin/ls'
    path_no_slash = 'ls'
    dne_bin_path = 'thisisnotpath'
    dne_file = '/bin/thisisnotanfile'
    is_dir = '/etc/'
    with open('/tmp/test_get_bin_path.txt', 'w') as f:
        f.write('#!/bin/bash')
    os.chmod('/tmp/test_get_bin_path.txt', 0o755)

    assert get_bin_path(proper_bin_path) == proper_bin_path
    assert get_bin_path(path_no_slash) == proper_bin_path
    os.remove('/tmp/test_get_bin_path.txt')

# Generated at 2022-06-24 20:52:59.751933
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test case "0"
    try:
        test_case_0()
    except ValueError:
        pass
    else:
        assert False, "unhandled exception"

if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:53:00.802383
# Unit test for function get_bin_path
def test_get_bin_path():
    pass


# Generated at 2022-06-24 20:53:09.958286
# Unit test for function get_bin_path
def test_get_bin_path():
    # Unit test for function get_bin_path
    str_0 = ';}s//;Lbp'
    var_0 = get_bin_path(str_0, str_0)
    assert var_0 == '/bin/zsh'
    assert type(var_0) == str
    str_0 = ';a;;;s//;Lbp'
    var_0 = get_bin_path(str_0, str_0)
    assert var_0 == '/bin/zsh'
    assert type(var_0) == str
    str_0 = ';s/s///;Lbp'
    var_0 = get_bin_path(str_0, str_0)
    assert var_0 == '/bin/zsh'
    assert type(var_0) == str

# Generated at 2022-06-24 20:53:13.286296
# Unit test for function get_bin_path
def test_get_bin_path():
    values = (
        False,
        True,
    )

    for value in values:
        str_0 = ';}s//;Lbp'
        var_0 = get_bin_path(str_0)

# Generated at 2022-06-24 20:53:16.482402
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except:
        failed = True
        return failed

if __name__ == "__main__":
    failed = test_get_bin_path()
    exit(int(failed))

# Generated at 2022-06-24 20:53:23.230459
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 1 == 1, 'Failure of test'
    #
    # result_0 = get_bin_path(str_0, str_0)
    # assert get_bin_path('str_1', 'str_0', 'str_0') == result_0 == 'str_1', 'Failure of test'

# Generated at 2022-06-24 20:53:32.117107
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/cat') == '/bin/cat'
    assert get_bin_path('/bin/cat', ['/bin']) == '/bin/cat'
    assert get_bin_path('/bin/cat', ['/bin', '/sbin']) == '/bin/cat'

    try:
        get_bin_path('/bin/cat', ['/bin', '/sbin'], required=True)
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "/bin/cat" in paths: /bin:/sbin'
    else:
        assert False


# Generated at 2022-06-24 20:53:38.496190
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test with a non-existent path
    str_0 = 'does-not-exist'
    try:
        var_0 = get_bin_path(str_0, str_0)
        assert False
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "%s" in paths: %s' % (str_0, str_0)



# Generated at 2022-06-24 20:53:43.311561
# Unit test for function get_bin_path
def test_get_bin_path():
    test_cases = [
        # (expected, args, kwargs)
        (
            ';%s//;Lbp' % os.sep,
            (';}s//;Lbp', ';}s//;Lbp'),
        ),
    ]

    for expected, args, kwargs in test_cases:
        assert expected == get_bin_path(*args, **kwargs)

# Generated at 2022-06-24 20:53:45.827465
# Unit test for function get_bin_path
def test_get_bin_path():
    """
    Test for the function get_bin_path
    """
    test_cases = [0]
    for item in test_cases:
        test_case_0()

# Generated at 2022-06-24 20:53:47.664684
# Unit test for function get_bin_path
def test_get_bin_path():
    assert os.path.isfile(get_bin_path('python', None, None)), 'unable to find python'

# Generated at 2022-06-24 20:53:51.949922
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('foo') == '/usr/bin/test-foo'
    assert get_bin_path('}', ['/usr/bin/test-foo']) == '/usr/bin/test-foo'
    assert get_bin_path('}', []) == '/usr/bin/test-foo'

# Generated at 2022-06-24 20:53:53.155280
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ansible') is not None



# Generated at 2022-06-24 20:53:53.781171
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == True

# Generated at 2022-06-24 20:53:59.563775
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError:
        pass

# Generated at 2022-06-24 20:54:10.065423
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'CexU6FKsU6'
    str_1 = 'KkqNZgAdx4'
    str_2 = 'DgSNYUBdGw'
    str_3 = ';su9EgojK'
    str_4 = ':'
    str_5 = 'if5!e'
    var_0 = get_bin_path(str_0, [str_1], False)
    assert(var_0.decode() == str_2)

    var_1 = get_bin_path(str_3, [str_5])
    assert(var_1.decode() == str_4)


# Generated at 2022-06-24 20:54:10.990257
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:54:12.266534
# Unit test for function get_bin_path
def test_get_bin_path():
    # get_bin_path('perl')
    pass


# Generated at 2022-06-24 20:54:16.756071
# Unit test for function get_bin_path
def test_get_bin_path():
    print('')
    var_0 = test_case_0()
    print(var_0)
    assert var_0 is not None

get_bin_path('X')
#import pdb; pdb.set_trace()
test_get_bin_path()

# Generated at 2022-06-24 20:54:23.358203
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:54:24.868517
# Unit test for function get_bin_path
def test_get_bin_path():
    assert None == get_bin_path(';.//3')

# Generated at 2022-06-24 20:54:26.726397
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('echo') == '/bin/echo'
    assert get_bin_path('ls') == '/bin/ls'

# Generated at 2022-06-24 20:54:31.057910
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = ''
    opt_dirs = ''
    value = get_bin_path(arg, opt_dirs, required=None)
    assert value == '', "The function should return '%s' instead of '%s'"%('', value)

test_get_bin_path()



# Generated at 2022-06-24 20:54:40.407186
# Unit test for function get_bin_path
def test_get_bin_path():
    print('Test #1')
    print('[%s]' % get_bin_path('/etc/passwd'))
    print('Test #2')
    print('[%s]' % get_bin_path('/etc/passwdd'))
    print('Test #3')
    print('[%s]' % get_bin_path('passwd'))
    print('Test #4')
    print('[%s]' % get_bin_path('passwdd'))
    print('Test #5')
    print('[%s]' % get_bin_path('/bin/sh'))
    print('Test #6')
    print('[%s]' % get_bin_path('/bin/ssss'))
    print('Test #7')

# Generated at 2022-06-24 20:54:45.258768
# Unit test for function get_bin_path
def test_get_bin_path():
    for test_no in dir():
        if test_no.startswith('test_'):
            func = globals()[test_no]
            try:
                func()
            except ValueError:
                pass
            else:
                raise AssertionError('ValueError not risen for test %s' % test_no)



# Generated at 2022-06-24 20:54:50.360110
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(str) == get_bin_path(str)


# Generated at 2022-06-24 20:54:58.108269
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/sh') == '/bin/sh'
    assert get_bin_path('/usr/bin/sh') == '/usr/bin/sh'
    assert get_bin_path('/usr/bin/../bin/sh') == '/bin/sh'
    if os.path.exists('/sbin/apk'):
        assert get_bin_path('apk') == '/sbin/apk'
    assert get_bin_path('python') == sys.executable
    assert get_bin_path('unix2dos!') == '/usr/bin/unix2dos'

# Generated at 2022-06-24 20:54:59.499413
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError:
        print('ValueError: Failed to find required executable')

# Generated at 2022-06-24 20:55:05.914602
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '}RdCeJr+'
    str_1 = '}RdCeJr+:3^)1'
    str_2 = '}RdCeJr+:3^)1:H"'
    str_3 = '}RdCeJr+:3^)1:H""z6.g'


if __name__ == '__main__':
    test_get_bin_path()
    test_case_0()

# Generated at 2022-06-24 20:55:10.092053
# Unit test for function get_bin_path
def test_get_bin_path():
    str_1 = 'zqgZjKQQ'
    var_1 = get_bin_path(str_1)

    var_2 = get_bin_path('ls', ['/bin'])

    var_3 = get_bin_path('ls', ['/thishostdoesntexist'])



# Generated at 2022-06-24 20:55:18.613887
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(';') == '/bin/;'
    assert get_bin_path(';', []) == '/bin/;'
    assert get_bin_path(';') == '/bin/;'
    assert get_bin_path(';', []) == '/bin/;'
    assert get_bin_path(';', []) == '/bin/;'
    assert get_bin_path(';', []) == '/bin/;'
    assert get_bin_path(';', []) == '/bin/;'
    assert get_bin_path(';') == '/bin/;'
    assert get_bin_path(';') == '/bin/;'
    assert get_bin_path(';') == '/bin/;'
    assert get_bin_path(';') == '/bin/;'

# Generated at 2022-06-24 20:55:28.580835
# Unit test for function get_bin_path
def test_get_bin_path():
  res = get_bin_path('/etc/passwd', [])
  assert res == '/etc/passwd'

  res = get_bin_path(get_bin_path('/etc/passwd', []), [])
  assert res == '/etc/passwd'

  res = get_bin_path('/etc/passwd', '/home/ubuntu')
  assert res == '/etc/passwd'

  res = get_bin_path(get_bin_path('/etc/passwd', '/home/ubuntu'), '/home/ubuntu')
  assert res == '/etc/passwd'

  res = get_bin_path('/etc/passwd', test_case_0())
  assert res == '/etc/passwd'


# Generated at 2022-06-24 20:55:34.084101
# Unit test for function get_bin_path
def test_get_bin_path():
    # AssertionError: Failed to find required executable "anon" in paths:
    # assert test_case_0() == 'anon'
    assert True

# Generated at 2022-06-24 20:55:34.984827
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test case 0
    test_case_0(None)




# Generated at 2022-06-24 20:55:37.463039
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == None

# Generated at 2022-06-24 20:55:44.175014
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = 'lsl'
    arg_1 = None
    ret_1 = get_bin_path(arg_0, arg_1)
    # TODO: Fix assert statements
    # assert ret_1 == '/usr/bin/lsl'
    ret_2 = get_bin_path(arg_0, arg_1)
    # TODO: Fix assert statements
    # assert ret_2 == '/usr/bin/lsl'

# Generated at 2022-06-24 20:55:47.476474
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    var_0 = get_bin_path(str_0, str_1, str_2)
    assert var_0 is None

# Test case for function get_bin_path

# Generated at 2022-06-24 20:55:49.686491
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = ';}s//;Lbp'
    var_0 = get_bin_path(str_0)


# Generated at 2022-06-24 20:55:54.431121
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except:
        pass