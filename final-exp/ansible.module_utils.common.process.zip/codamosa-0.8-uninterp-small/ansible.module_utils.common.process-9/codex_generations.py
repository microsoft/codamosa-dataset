

# Generated at 2022-06-24 20:46:03.417359
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:46:03.945293
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:46:07.217255
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('asdf', ['/usr/bin']) == '/usr/bin/asdf'

# Generated at 2022-06-24 20:46:15.905351
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)
    str_1 = '_raw_params'
    var_1 = get_bin_path(str_1)
    str_2 = '_raw_params'
    var_2 = get_bin_path(str_2)
    str_3 = '_raw_params'
    var_3 = get_bin_path(str_3)
    str_4 = '_raw_params'
    var_4 = get_bin_path(str_4)
    str_5 = '_raw_params'
    var_5 = get_bin_path(str_5)

if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:46:18.651098
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('_raw_params') == '/usr/bin/_raw_params'
    assert get_bin_path('_raw_params', opt_dirs=['/usr/bin']) == '/usr/bin/_raw_params'

# Generated at 2022-06-24 20:46:26.187752
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        get_bin_path(None, None)
    except ValueError:
        pass
    else:
        assert False, 'ExpectedValueError'

    try:
        get_bin_path(None)
    except ValueError:
        pass
    else:
        assert False, 'ExpectedValueError'

    try:
        get_bin_path('_raw_params', [os.getcwd()])
    except ValueError:
        pass
    else:
        assert False, 'ExpectedValueError'

    try:
        get_bin_path('_raw_params', [os.getcwd()], True)
    except ValueError:
        pass
    else:
        assert False, 'ExpectedValueError'


# Generated at 2022-06-24 20:46:31.429086
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(str_0) == ('/usr/bin/id')

# Generated at 2022-06-24 20:46:32.471010
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path("_raw_params") is not None

# Test data for function get_bin_path

# Generated at 2022-06-24 20:46:34.735395
# Unit test for function get_bin_path
def test_get_bin_path():
    str_1 = 'test_file_0'
    file_0 = open(str_1, 'w+')
    test_case_0()
    file_0.close()
    f_0 = os.remove(str_1)

# Generated at 2022-06-24 20:46:36.220029
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:46:40.182424
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0() == '_raw_params'

# Generated at 2022-06-24 20:46:42.565640
# Unit test for function get_bin_path
def test_get_bin_path():
    assert (get_bin_path('_raw_params'))

# Generated at 2022-06-24 20:46:48.896516
# Unit test for function get_bin_path
def test_get_bin_path():
    args_0 = ['_raw_params']
    opt_dirs_0 = ['/sys/devices/platform/xhci_hcd.0/usb2/2-1/2-1.2/2-1.2.2']
    
    test_case_0()


if __name__ == '__main__':
    try:
        test_get_bin_path()
    except Exception as e:
        print(e)
    else:
        print('OK')

# Generated at 2022-06-24 20:46:59.648847
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/false') == '/bin/false'
    assert get_bin_path('/bin/true') == '/bin/true'
    bin_path = get_bin_path('/bin/bash')
    assert isinstance(bin_path, str)
    assert bin_path == '/bin/bash'
    try:
        bin_path = get_bin_path('/bin/this-path-does-not-exist')
        # Should not reach here.
        assert False
    except ValueError as e:
        assert isinstance(e, ValueError)
    # for this test to work, csh must be installed on system that is executing the test.

# Generated at 2022-06-24 20:47:00.239423
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:47:02.826427
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)
    var_1 = get_bin_path(str_0)
    assert var_1 == var_0, "Function 'get_bin_path' failed to return a value"

# Generated at 2022-06-24 20:47:06.105240
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/etc/passwd') == '/etc/passwd'

# Generated at 2022-06-24 20:47:08.719417
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = '_raw_params'
    result = get_bin_path(arg)
    if not result:
        raise AssertionError(result)

# Generated at 2022-06-24 20:47:14.194285
# Unit test for function get_bin_path
def test_get_bin_path():
    # System default paths to be added
    opt_dirs = ['/opt/bin', '/usr/local/bin']
    bin_path_name = 'ansible-playbook'
    bin_path = get_bin_path(bin_path_name, opt_dirs, required=False)
    # Ensure bin_path is one of the path in opt_dirs
    assert any(opt_dir in bin_path for opt_dir in opt_dirs)


# Generated at 2022-06-24 20:47:23.936431
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = 'sleep'
    arg_1 = None
    arg_2 = None
    try:
        get_bin_path(arg_0, arg_1, arg_2)
        assert 0 == 1
    except SystemExit:
        assert 1 == 1

    arg_0 = 'sleep'
    arg_1 = []
    arg_2 = None
    try:
        get_bin_path(arg_0, arg_1, arg_2)
        assert 0 == 1
    except ValueError:
        assert 1 == 1

    arg_0 = 'sleep'
    arg_1 = None
    arg_2 = None
    try:
        get_bin_path(arg_0, arg_1, arg_2)
        assert 0 == 1
    except ValueError:
        assert 1 == 1

    arg_0

# Generated at 2022-06-24 20:47:29.282585
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception:
        raise AssertionError('Test failed')


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:47:30.096980
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:47:36.953249
# Unit test for function get_bin_path
def test_get_bin_path():
    # get_bin_path(arg, opt_dirs=None, required=None)
    # Find system executable in PATH. Raises ValueError if executable is not found.
    # Optional arguments:
    # - required:  [Deprecated] Prior to 2.10, if executable is not found and required is true it raises an Exception.
    #             In 2.10 and later, an Exception is always raised. This parameter will be removed in 2.14.
    # - opt_dirs:  optional list of directories to search in addition to PATH
    # If found return full path, otherwise raise ValueError.

    paths = ['/sbin', '/usr/sbin', '/usr/local/sbin']

    executable = 'ping'


# Generated at 2022-06-24 20:47:39.324720
# Unit test for function get_bin_path
def test_get_bin_path():
    assert os.path.exists('/bin/sh')
    mypath = '/bin/sh'
    sh = get_bin_path(mypath)
    assert sh == mypath



# Generated at 2022-06-24 20:47:43.928180
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = '_raw_params'
    var_1 = False
    var_2 = None
    var_3 = get_bin_path(str_0=var_0, required=var_1, opt_dirs=var_2)
    assert var_3 is not None
    return True


# ###############
# MODULE EXECUTION
# ###############



# Generated at 2022-06-24 20:47:48.496408
# Unit test for function get_bin_path
def test_get_bin_path():
    args = [{'arg': '_raw_params', 'opt_dirs': None, 'required': None}]

    for i in range(0, len(args)):
        test_case_0()


# Generated at 2022-06-24 20:47:51.059406
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_get_bin_path'
    var_0 = get_bin_path(str_0)


# Generated at 2022-06-24 20:47:56.264726
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:48:04.679263
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)
    str_1 = var_0
    str_2 = '%s/%s' % (str_1, '_ansible_module_generated_vars.py')
    var_1 = get_bin_path(str_2)
    str_3 = var_1
    str_4 = '%s/%s' % (str_3, '_text.py')
    var_2 = get_bin_path(str_4)
    str_5 = var_2
    str_6 = '%s/%s' % (str_5, '_common_utils.py')
    var_3 = get_bin_path(str_6)
    str_7 = var_3
    str

# Generated at 2022-06-24 20:48:05.470281
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:48:09.448360
# Unit test for function get_bin_path
def test_get_bin_path():
    result = get_bin_path("/usr/bin/env")
    assert result == "/usr/bin/env"

# Generated at 2022-06-24 20:48:12.174802
# Unit test for function get_bin_path
def test_get_bin_path():
    #
    # Test with the basic parameters.
    #
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)

# Generated at 2022-06-24 20:48:16.882887
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'sdfsdfsdfsdf'
    var_0 = get_bin_path(str_0)

# Generated at 2022-06-24 20:48:20.279181
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'

    var_0 = get_bin_path(str_0)


# Generated at 2022-06-24 20:48:24.429200
# Unit test for function get_bin_path
def test_get_bin_path():
    # ensure argument str_0 is expected type
    test_case_0()



# Generated at 2022-06-24 20:48:25.425302
# Unit test for function get_bin_path
def test_get_bin_path():
    assert isinstance(test_case_0(), (six.string_types,))

# Generated at 2022-06-24 20:48:27.046023
# Unit test for function get_bin_path
def test_get_bin_path():
    str_1 = 'ls'
    assert get_bin_path(str_1) == '/bin/ls'


# Generated at 2022-06-24 20:48:35.231376
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)
    str_1 = '_check_invalid_arguments'
    var_1 = get_bin_path(str_1)
    #assert var_0 == var_1
    #assert var_0 == '/usr/local/bin/_raw_params'
    #assert var_1 == '/usr/local/bin/_check_invalid_arguments'



# Generated at 2022-06-24 20:48:36.648563
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('_raw_params') == '_raw_params'

# Generated at 2022-06-24 20:48:38.556476
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:48:48.459751
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)
    print(var_0)


# Generated from a Paramiko example (link: https://gist.github.com/kirpit/1306188)

# Generated at 2022-06-24 20:48:55.262275
# Unit test for function get_bin_path
def test_get_bin_path():
    # Tested with 1 arguments
    # get_bin_path('_raw_params')

    # Tested with 2 arguments
    # get_bin_path('cmd', [])

    # Tested with 3 arguments
    # get_bin_path('cmd', required=True)

    # Tested with 4 arguments
    # get_bin_path('cmd', required=True, opt_dirs=[])
    assert test_case_0() == 0

# Generated at 2022-06-24 20:49:04.035234
# Unit test for function get_bin_path
def test_get_bin_path():
    test_cases = [
        # TestCase 1:
        # Example for get_bin_path() used in a module
        (
            # ('_raw_params'),
            ('ansible-doc'),
            # **{}
            {
                # 'opt_dirs': None,
                'opt_dirs': ['/usr/local/bin', '/usr/bin', '/bin'],
                # 'required': None
            }
        )
    ]
    for test_case in test_cases:
        str_0 = test_case[0]
        var_0 = get_bin_path(str_0, **test_case[1])
        print("get_bin_path('%s', **%s) returned %s" % (str_0, str(test_case[1]), var_0))


# Generated at 2022-06-24 20:49:06.264564
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('_raw_params') == get_bin_path('_raw_params')

# Generated at 2022-06-24 20:49:12.881625
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = '_raw_params'
    var_1 = ['/bin']
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 20:49:14.916771
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)

# Generated at 2022-06-24 20:49:16.134674
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('_raw_params') is not None

# Generated at 2022-06-24 20:49:16.894760
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True
# END.

# Generated at 2022-06-24 20:49:20.811140
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('curl') == '/usr/bin/curl'
    assert get_bin_path('ping') == '/usr/bin/ping'
    assert get_bin_path('find') == '/usr/bin/find'

# Generated at 2022-06-24 20:49:21.725046
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True



# Generated at 2022-06-24 20:49:28.139028
# Unit test for function get_bin_path
def test_get_bin_path():

    # AssertionError: Failed to find required executable "python" in paths: /tmp/ansible/ansible/lib/ansible
    func_0 = get_bin_path(arg, opt_dirs=None, required=None)
    assert func_0 == 'python'

# Generated at 2022-06-24 20:49:34.249198
# Unit test for function get_bin_path
def test_get_bin_path():
    str_1 = '_raw_params'
    # dict_0 = dict()
    # dict_0['opt_dirs'] = None
    # dict_0['required'] = None
    var_0 = get_bin_path(str_1)
    assert not var_0


if __name__ == "__main__":
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:49:35.143488
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:49:37.567023
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    str_1 = '_ansible_modlib'
    var_0 = get_bin_path(str_0)
    assert var_0
    var_1 = get_bin_path(str_1)
    assert var_1

# Generated at 2022-06-24 20:49:38.417490
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

test_get_bin_path()

# Generated at 2022-06-24 20:49:42.991593
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)


'''
# Test steps for function get_bin_path


# Assertions for function get_bin_path
assert get_bin_path('_raw_params') == 5
assert get_bin_path('_raw_params') == 6
assert get_bin_path('_raw_params') == 7
assert get_bin_path('_raw_params') == 8
assert get_bin_path('_raw_params') == 9
assert get_bin_path('_raw_params') == 10
'''


# Generated at 2022-06-24 20:49:48.118506
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except NotImplementedError:
        print("arg_types is undefined")

# Generated at 2022-06-24 20:49:50.655527
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test if str_ret starts with a literal string.
    str_ret = get_bin_path("str_0")
    assert str_ret.startswith("str_0") is True

# Generated at 2022-06-24 20:50:00.137522
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    str_1 = '_'
    str_2 = 'raw_params'
    ret_0 = get_bin_path(str_0)
    ret_1 = get_bin_path(str_1)
    ret_2 = get_bin_path(str_2)
    str_3 = '_raw_params.py'
    str_4 = '_'
    str_5 = 'raw_params.py'
    ret_3 = get_bin_path(str_3)
    ret_4 = get_bin_path(str_4)
    ret_5 = get_bin_path(str_5)
    assert(ret_0 == ret_1 == ret_2)
    assert(ret_3 == ret_4 == ret_5)



# Generated at 2022-06-24 20:50:02.829289
# Unit test for function get_bin_path
def test_get_bin_path():
    arg = '_raw_params'
    get_bin_path(arg)


if __name__ == '__main__':
    print("Arguments:")
    print("    arg: _raw_params")
    test_case_0()

# Generated at 2022-06-24 20:50:08.092915
# Unit test for function get_bin_path
def test_get_bin_path():
    assert 0 == 0


# Generated at 2022-06-24 20:50:15.711835
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('ls') == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls', opt_dirs=[]) == '/bin/ls'
    assert get_bin_path('ls', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'
    assert get_bin_path('ls -t', opt_dirs=['/usr/bin', '/bin']) == '/usr/bin/ls'

# Generated at 2022-06-24 20:50:18.025087
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('python') == '/usr/bin/python'


# Generated at 2022-06-24 20:50:24.179371
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    opt_dirs_0 = []
    var_0 = get_bin_path(str_0, opt_dirs_0, required=None)
    assert var_0 is not None and var_0 == '/bin/_raw_params'


# Generated at 2022-06-24 20:50:26.251831
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception as e:
        print("Exception raised in test cases: " + str(e))

# Generated at 2022-06-24 20:50:29.968208
# Unit test for function get_bin_path
def test_get_bin_path():
    args = [1]
    if get_bin_path(args[0]) != '__return__':
        raise AssertionError('Expected "%s", but got "%s"' % ('__return__', get_bin_path(args[0])))

test_case_0()

# Generated at 2022-06-24 20:50:33.686242
# Unit test for function get_bin_path
def test_get_bin_path():

    # This will fail because the executable '_raw_params' doesn't exist
    try:
        test_case_0()
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "_raw_params" in paths: /bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin'

# Generated at 2022-06-24 20:50:43.406104
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    assert get_bin_path('/bin/ls', ['/sbin', '/usr/sbin']) == '/bin/ls'
    try:
        get_bin_path('/usr/bin/wtf')
    except ValueError as e:
        assert 'Failed to find required executable "/usr/bin/wtf"' in str(e)
    try:
        get_bin_path('/usr/bin/wtf', ['/sbin'])
    except ValueError as e:
        assert 'Failed to find required executable "/usr/bin/wtf"' in str(e)
    assert get_bin_path('/usr/bin/wtf', ['/sbin', '/usr/bin']) == '/usr/bin/wtf'

# Generated at 2022-06-24 20:50:47.043669
# Unit test for function get_bin_path
def test_get_bin_path():
  try:
    test_case_0()
  except:
    return False
  else:
    return True

print(test_get_bin_path())

# Generated at 2022-06-24 20:50:56.661315
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    str_1 = 'executable'
    str_2 = 'path'
    str_3 = 'str'

# Generated at 2022-06-24 20:51:03.599747
# Unit test for function get_bin_path
def test_get_bin_path():
    f_0 = get_bin_path
    str_0 = '_raw_params'
    var_0 = f_0(str_0)
    var_1 = '/usr/bin/python'

    assert var_0 == var_1


# Generated at 2022-06-24 20:51:07.292021
# Unit test for function get_bin_path
def test_get_bin_path():
    with pytest.raises(ValueError) as excinfo:
        get_bin_path(None)
    assert 'required' in str(excinfo.value)
    with pytest.raises(ValueError) as excinfo:
        get_bin_path('_raw_params')
    assert 'Failed to find required executable' in str(excinfo.value)

# Generated at 2022-06-24 20:51:13.589614
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)
    assert var_0 == '/usr/bin/_raw_params'

    str_1 = 'module_common.py'
    var_1 = get_bin_path(str_1)
    assert var_1 == '/usr/lib/python2.7/site-packages/ansible/module_utils/common/module_common.py'



# Generated at 2022-06-24 20:51:18.777784
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False


if __name__ == '__main__':
    import sys
    import pytest

    if len(sys.argv) == 1:
        pytest.main(['-v', __file__])
    else:
        pytest.main(sys.argv[1:])

# Generated at 2022-06-24 20:51:20.031276
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('foo') == '/usr/bin/foo'

# Generated at 2022-06-24 20:51:23.600336
# Unit test for function get_bin_path
def test_get_bin_path():
    # Declare variables
    str_0 = '_raw_params'

    # Setup
    var_0 = get_bin_path(str_0)

    # Verify
    assert True


# Generated at 2022-06-24 20:51:28.353399
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as e:
        assert str(e) == 'Failed to find required executable "_raw_params" in paths: /bin:/usr/bin:/sbin:/usr/sbin:/usr/local/sbin'
    except Exception as e:
        assert False

# Generated at 2022-06-24 20:51:29.807036
# Unit test for function get_bin_path
def test_get_bin_path():
    assert '_raw_params' == get_bin_path('_raw_params')

# Generated at 2022-06-24 20:51:30.513401
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-24 20:51:40.520112
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test against known string
    str_1 = '_raw_params'
    # assert str_1 == get_bin_path(str_1, None, False)

    # Test against a known path
    var_0 = get_bin_path(str_1)
    # assert var_0 == '/usr/bin/_raw_params'

    # Test against a known path with optional directories
    var_1 = get_bin_path(str_1, ['/usr/sbin/', '/bin/'])
    # assert var_1 == '/usr/bin/_raw_params'

    # Test against a known path with optional directories
    var_2 = get_bin_path(str_1, ['/usr/sbin/', '/bin/'], True)
    # assert var_2 == '/usr/bin/_raw_params'

   

# Generated at 2022-06-24 20:51:47.804071
# Unit test for function get_bin_path
def test_get_bin_path():

    try:
        test_case_0()
    except ValueError as exp_err:
        return 'Failed: ' + str(exp_err)
    else:
        return 'Success'

# Generated at 2022-06-24 20:51:48.779858
# Unit test for function get_bin_path
def test_get_bin_path():
    assert test_case_0()


# Generated at 2022-06-24 20:51:51.115725
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)
    assert var_0 is not None



# Generated at 2022-06-24 20:51:56.152651
# Unit test for function get_bin_path
def test_get_bin_path():
    str_1 = '_raw_params'
    var_0 = get_bin_path(str_1)
    assert var_0 == '_raw_params'



# Generated at 2022-06-24 20:51:57.448595
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)

# Generated at 2022-06-24 20:52:03.908082
# Unit test for function get_bin_path
def test_get_bin_path():
    # Case 0
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)
    assert var_0 is not None
    assert var_0 == '_raw_params'

    # Case 1
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)
    assert var_0 is not None
    assert var_0 == '_raw_params'



# Generated at 2022-06-24 20:52:05.511436
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)



# Generated at 2022-06-24 20:52:13.384569
# Unit test for function get_bin_path
def test_get_bin_path():
    # Test case 0
    assert get_bin_path('_raw_params') == '/usr/bin/_raw_params'
    # Test case 1
    assert get_bin_path('_raw_params') == '/usr/bin/_raw_params'
    # Test case 2
    assert get_bin_path('_raw_params') == '/usr/bin/_raw_params'

# Generated at 2022-06-24 20:52:16.827390
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:52:19.427545
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True == isinstance(get_bin_path(arg='_raw_params'), str)
    assert True == isinstance(get_bin_path(arg='_raw_params', opt_dirs=None, required=None), str)

# Generated at 2022-06-24 20:52:26.364985
# Unit test for function get_bin_path
def test_get_bin_path():
    # Testing for Standard Functionality
    test_0 = get_bin_path('ls')
    assert(test_0 == '/bin/ls')

    # Testing for Variable Type
    test_1 = get_bin_path('git')
    assert(type(test_1) == str)

    # Testing Expected Value
    test_2 = get_bin_path('cp')
    assert(test_2 == '/bin/cp')

# Generated at 2022-06-24 20:52:27.779745
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:52:28.222095
# Unit test for function get_bin_path
def test_get_bin_path():
    assert False  # Not a good test



# Generated at 2022-06-24 20:52:34.522598
# Unit test for function get_bin_path
def test_get_bin_path():
    var = [x for x in dir() if x.startswith('test_')]
    for test_name in var:
        val = globals()[test_name]
        val()
    print('All unit tests for function get_bin_path is Passed!')

if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:52:37.203427
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)
    pass

# Generated at 2022-06-24 20:52:37.776531
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:52:47.506656
# Unit test for function get_bin_path
def test_get_bin_path():

    # Tests class - FQDN:get_bin_path

    # str_0 = '_raw_params'
    # var_0 = get_bin_path(str_0)
    #
    # str_1 = '_singleton'
    # var_1 = get_bin_path(str_1)
    str_2 = 'module_utils'
    var_2 = get_bin_path(str_2)

    print("")
    print("# Unit test for function get_bin_path")

    # print("")
    # print("# Class: FQDN:get_bin_path")
    # print("# Function: get_bin_path")

    # print("")
    # print("# Test: get_bin_path - str_0 = " + str_0)
    # print("# Expected

# Generated at 2022-06-24 20:52:48.626912
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)


# Generated at 2022-06-24 20:52:54.959989
# Unit test for function get_bin_path
def test_get_bin_path():
    # Tuple: [input, output]
    test_input_output = [
        (
            '_raw_params',
            '/usr/lib/python2.7/dist-packages/openstack/_raw_params'
        )
    ]

    for test_io in test_input_output:
        try:
            assert get_bin_path(test_io[0]) == test_io[1]
        except AssertionError:
            print("Expected %s but got %s" %
                  (test_io[1], get_bin_path(test_io[0])))



# Generated at 2022-06-24 20:52:57.335471
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = '_raw_params'
    arg_1 = []
    arg_2 = None
    ret_0 = get_bin_path(arg_0, arg_1, arg_2)

# Generated at 2022-06-24 20:53:07.045499
# Unit test for function get_bin_path
def test_get_bin_path():
    var_0 = '_raw_params'
    var_1 = None
    try:
        var_1 = get_bin_path(var_0, opt_dirs=None, required='_raw_params')
    except Exception:
        pass
    print(var_1)


# END OF TEST CASES
if __name__ == "__main__":
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:53:08.873551
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('_raw_params') == get_bin_path('_raw_params')

# Generated at 2022-06-24 20:53:10.874312
# Unit test for function get_bin_path
def test_get_bin_path():
    assert isinstance(get_bin_path('/usr/bin/python'), str)



# Generated at 2022-06-24 20:53:19.967126
# Unit test for function get_bin_path

# Generated at 2022-06-24 20:53:22.895308
# Unit test for function get_bin_path
def test_get_bin_path():
    cmd = ['/bin/sh', '-c', 'git --version']
    opt_dirs = None
    required = None
    res = get_bin_path(cmd, opt_dirs, required)
    assert res is not None
    assert type(res) is str


# Generated at 2022-06-24 20:53:24.259175
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)



# Generated at 2022-06-24 20:53:25.264872
# Unit test for function get_bin_path
def test_get_bin_path():
    assert(test_case_0() == None)

test_get_bin_path()

# Generated at 2022-06-24 20:53:29.584948
# Unit test for function get_bin_path
def test_get_bin_path():
    # Setup
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)
    assert var_0 == '/usr/bin/_raw_params'

# Generated at 2022-06-24 20:53:30.640847
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(arg='_raw_params') == '/bin/ls'

# Generated at 2022-06-24 20:53:42.063092
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('_ansible_module_post') == '/usr/bin/_ansible_module_post'
    assert get_bin_path('_ansible_module_post', ['/usr/share/ansible/extra_modules']) == '/usr/bin/_ansible_module_post'
    assert get_bin_path('_ansible_module_post', ['/usr/share/ansible/extra_modules'], True) == '/usr/bin/_ansible_module_post'
    assert get_bin_path('_ansible_module_post', ['/usr/share/ansible/extra_modules'], False) == '/usr/bin/_ansible_module_post'

# Generated at 2022-06-24 20:53:56.333485
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    opt_dirs = []
    str_3 = '_ansible_module_setup'
    try:
        get_bin_path(str_0, opt_dirs)
        assert False, 'Expected ValueError'
    except ValueError:
        pass
    try:
        get_bin_path(str_0, opt_dirs, True)
        assert False, 'Expected ValueError'
    except ValueError:
        pass
    try:
        get_bin_path(str_3)
        assert False, 'Expected ValueError'
    except ValueError:
        pass


if __name__ == "__main__":
    test_get_bin_path()

# Generated at 2022-06-24 20:53:57.184967
# Unit test for function get_bin_path
def test_get_bin_path():
    assert callable(get_bin_path)

# Generated at 2022-06-24 20:53:59.024176
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError:
        pass
    else:
        raise AssertionError('ExpectedValueError')

# Generated at 2022-06-24 20:54:06.468617
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True
    try:
        var_0 = '_raw_params'
        var_1 = ['/usr/local', '/usr/local/bin']
        var_2 = get_bin_path(var_0, var_1)
        assert True
    except ValueError:
        assert False

    var_3 = 'ansible_facts'
    try:
        var_4 = get_bin_path(var_3)
        assert False
    except ValueError as e:
        assert True


if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()
    test_get_bin_path()
    test_get_bin_path()

# Generated at 2022-06-24 20:54:10.428905
# Unit test for function get_bin_path
def test_get_bin_path():
    str_1 = '_raw_params'
    var_1 = get_bin_path(str_1)
    assert var_1 == '/usr/bin/_raw_params'
    str_2 = '_raw_params'
    var_2 = get_bin_path(str_2)
    assert var_2 == '/usr/bin/_raw_params'
    str_3 = '_raw_params'
    var_3 = get_bin_path(str_3)
    assert var_3 == '/usr/bin/_raw_params'

# Generated at 2022-06-24 20:54:10.949906
# Unit test for function get_bin_path
def test_get_bin_path():
    assert False

# Generated at 2022-06-24 20:54:15.948323
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_make_contrib_dir'
    list_0 = ['_normalize_module_spec', '_binary_module_name', '_binary_module_replacement']
    var_0 = get_bin_path(str_0)
    var_1 = get_bin_path(str_0, list_0)

# Generated at 2022-06-24 20:54:21.115313
# Unit test for function get_bin_path
def test_get_bin_path():

    # Define test input parameters
    arg_0 = '_raw_params'
    opt_dirs_0 = None
    required_0 = None

    # Define expected test result
    result_0 = None  # <class 'ValueError'>

    # Run test
    test_case_0()

    # Check test results
    assert result_0 == None

# Generated at 2022-06-24 20:54:21.925832
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path(None, None)

# Generated at 2022-06-24 20:54:24.878064
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = 'ssh'
    var_0 = get_bin_path(str_0)
    str_1 = '_raw_params'
    var_1 = get_bin_path(str_1)

# Generated at 2022-06-24 20:54:31.355350
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        test_case_0()
    except ValueError as exc:
        assert False, exc

# Generated at 2022-06-24 20:54:35.853450
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = '_raw_params'
    arg_1 = None
    arg_2 = None
    try:
        ret_0 = get_bin_path(arg_0, arg_1, arg_2)
    except ValueError as e:
        pass
    else:
        raise ValueError('Uncaught ValueError exception')

# Generated at 2022-06-24 20:54:41.320230
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:54:42.264099
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:54:43.655826
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:54:46.550314
# Unit test for function get_bin_path
def test_get_bin_path():
    pass

# Generated at 2022-06-24 20:54:47.680985
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(arg) == "arg"


# Generated at 2022-06-24 20:54:49.860177
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path(str)

# Main unit test entry point

# Generated at 2022-06-24 20:54:59.497743
# Unit test for function get_bin_path
def test_get_bin_path():
    str = 'hardware.product_name'
    var = get_bin_path(str)
    str = 'hardware.product_serial'
    var = get_bin_path(str)
    str = 'hardware.product_vendor'
    var = get_bin_path(str)
    str = 'hardware.product_version'
    var = get_bin_path(str)
    str = 'hardware.system_vendor'
    var = get_bin_path(str)
    str = 'hardware.system_serial'
    var = get_bin_path(str)
    str = 'hardware.virtual'
    var = get_bin_path(str)
    str = 'hardware.cpu_cores'
    var = get_bin_path(str)

# Generated at 2022-06-24 20:55:00.253389
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Generated at 2022-06-24 20:55:05.254690
# Unit test for function get_bin_path
def test_get_bin_path():
    pass


# Generated at 2022-06-24 20:55:07.344412
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()

# Unit test execution
if __name__ == '__main__':
    test_get_bin_path()

# Generated at 2022-06-24 20:55:08.320725
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

# Generated at 2022-06-24 20:55:13.813674
# Unit test for function get_bin_path
def test_get_bin_path():
    try:
        str_0 = '_raw_params'
        var_0 = get_bin_path(str_0)
        if var_0 is None:
            return False
    except ValueError as e:
        print(e)
        return False
    return True

# Generated at 2022-06-24 20:55:14.651410
# Unit test for function get_bin_path
def test_get_bin_path():
    test_case_0()


# Generated at 2022-06-24 20:55:16.625104
# Unit test for function get_bin_path
def test_get_bin_path():
    # get_bin_path() function should pass these test cases with no error
    test_case_0()

# Generated at 2022-06-24 20:55:18.165997
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)
    assert var_0 is not None

# Generated at 2022-06-24 20:55:20.372093
# Unit test for function get_bin_path
def test_get_bin_path():
    # Verifies that the function has no outputs
    assert len(test_case_0()) == 0

test_case_0()

# Generated at 2022-06-24 20:55:23.678103
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    var_0 = get_bin_path(str_0)



# Generated at 2022-06-24 20:55:31.881402
# Unit test for function get_bin_path
def test_get_bin_path():
    assert get_bin_path('/bin/ls') == '/bin/ls'
    result = get_bin_path('ls')
    assert result == '/bin/ls' or result == '/usr/bin/ls'
    try:
        get_bin_path('sdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdf')
        assert False
    except ValueError:
        assert True
    assert get_bin_path('/bin/ls', required=False) == '/bin/ls'
    assert get_bin_path('ls', required=False) == '/bin/ls' or result == '/usr/bin/ls'

# Generated at 2022-06-24 20:55:41.109153
# Unit test for function get_bin_path
def test_get_bin_path():
    get_bin_path(arg, opt_dirs=None, required=None)
    assert True

# Generated at 2022-06-24 20:55:46.145530
# Unit test for function get_bin_path
def test_get_bin_path():
    str_0 = '_raw_params'
    opt_dirs_0 = ['/usr/local/sbin', '/usr/sbin', '/sbin']
    required_0 = True
    var_0 = get_bin_path(str_0, opt_dirs_0, required_0)

# Tests for function get_bin_path
# No parameter test

# Generated at 2022-06-24 20:55:49.719039
# Unit test for function get_bin_path
def test_get_bin_path():
    arg_0 = None
    arg_1 = []
    arg_2 = None
    try:
        get_bin_path(arg_0, arg_1, arg_2)
    except ValueError:
        pass


if __name__ == '__main__':
    test_case_0()
    test_get_bin_path()

# Generated at 2022-06-24 20:55:54.666473
# Unit test for function get_bin_path
def test_get_bin_path():
    assert True

#<<INCLUDE_ANSIBLE_MODULE_COMMON>>
main()