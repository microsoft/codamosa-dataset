

# Generated at 2022-06-26 04:06:00.246185
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = 'load_module_from_file_location'
    var_0 = load_module_from_file_location(str_0)
    var_1 = load_module_from_file_location(b'\x98\xb7\xae\xd2\x8e\x0b\x9b\xab"')
    var_2 = load_module_from_file_location(b'\x6b\x7f\x9d\x7f\x78\x0b\xa2\xb8\x87\x7b')
    var_3 = load_module_from_file_location(b'\x74\x88\xbc\x93\x9a\x0b\xa2\xab\x96\x77')
    var_4 = load_module_

# Generated at 2022-06-26 04:06:09.096082
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    name = 'test_module'
    location = '/some/path/test_module.py'
    _mod_spec = spec_from_file_location(name, location)
    module = module_from_spec(_mod_spec)
    _mod_spec.loader.exec_module(module)   # type: ignore
    assert load_module_from_file_location(location) == module, \
        "load_module_from_file_location: test_1"



# Generated at 2022-06-26 04:06:19.711343
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic.config import LOGGING, LOGGING_CONFIG, LOGO, LOG_CONFIG
    from sanic.log import LOGGING_DEFAULTS

    assert load_module_from_file_location(LOG_CONFIG) == LOGGING
    assert load_module_from_file_location(LOG_CONFIG)["LOGO"] == LOGO
    assert (
        load_module_from_file_location(LOGGING_CONFIG)["loggers"]
        == LOGGING_DEFAULTS["loggers"]
    )
    assert type(LOGGING_CONFIG) is str
    assert isinstance(load_module_from_file_location(LOG_CONFIG), dict)

# Generated at 2022-06-26 04:06:22.598938
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test if the function fail when test_data.txt doesn't exist"""
    try:
        var_0 = load_module_from_file_location('test_data.txt')
    except IOError:
        return
    assert False, 'Error: expected an IOError exception'

# Code Injection test for function load_module_from_file_location

# Generated at 2022-06-26 04:06:28.389814
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("false") == False
    with pytest.raises(ValueError):
        str_to_bool("tru")



# Generated at 2022-06-26 04:06:32.680607
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '\\^u\x0bC\\{`V%b{_2THx'
    var_0 = load_module_from_file_location(str_0)
    assert var_0


# Module-level docstring

# Generated at 2022-06-26 04:06:36.923970
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = "/etc/config.py"
    path_0 = Path("/etc/config.py")
    assert load_module_from_file_location(str_0) == load_module_from_file_location(
        path_0
    )

# Generated at 2022-06-26 04:06:48.508509
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = "/some/path/to/the/file.py"
    name = path.split("/")[-1].split(".")[0]  # get filename without path and .py
    spec_mock = MagicMock()
    module_mock = MagicMock()
    module_mock.__spec__ = spec_mock
    module_mock.__file__ = path
    with patch("importlib.util.spec_from_file_location") as spec_patcher, patch(
        "importlib.util.module_from_spec"
    ) as module_patcher:
        spec_patcher.return_value = spec_mock
        module_patcher.return_value = module_mock
        with patch("sanic.helpers.open") as open_patcher:
            mock_open = mock

# Generated at 2022-06-26 04:06:50.777702
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('False') == False
    assert str_to_bool('true') == True


# Generated at 2022-06-26 04:06:57.482187
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        test_case_0()
    except Exception:
        test_result = False
    else:
        test_result = True

    assert test_result

if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:07:02.798308
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '\\^u\x0bC\\{`V%b{_2THx'
    var_0 = load_module_from_file_location(str_0)
    assert var_0 is not None



# Generated at 2022-06-26 04:07:04.752586
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_case_0()


# Generated at 2022-06-26 04:07:08.137064
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import unittest
    try:
        test_case_0()
    except LoadFileException:
        raise unittest.SkipTest("Exception thrown.")

# Generated at 2022-06-26 04:07:12.472374
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    result = load_module_from_file_location("tests/test_utils/test_load_file_location/test_config.py")
    assert all([result.A == 1, result.B == 2, result.C == [3, 4, 5]])



# Generated at 2022-06-26 04:07:25.743428
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = (
        b'\xdd\x1c\xd0\x30S\x9e\x0c\xb4\xd4d\x18t\x18f\x91\xcc\xe7J\x9bG'
        b'\x18\xed\x1e\xb2\x8b\xe7\x15\x81\x80\xc8\x8c\x06U\xfe>\xab\x02\x1a'
        b'\x0b\x8c\xa9\xce\x0f\x1d\x04Q\x19\x94\xe2K'
    )
    var_0 = load_module_from_file_location(str_0)
    assert var_0
    str_0 = b

# Generated at 2022-06-26 04:07:33.643450
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '\\^u\x0bC\\{`V%b{_2THx'
    # Get an instance of the module
    var_0 = load_module_from_file_location(str_0)
    # Test type
    assert isinstance(var_0, types.ModuleType)
    # Test length
    assert len(var_0.__dict__) == 0


# Generated at 2022-06-26 04:07:36.534971
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/home/michal/dev/sanic/tests/fixtures/test_load_mod.py'
    var_0 = load_module_from_file_location(str_0)
    assert var_0.x == 42
    return



# Generated at 2022-06-26 04:07:38.788792
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    with pytest.raises(ValueError):
        test_case_0()

# Generated at 2022-06-26 04:07:47.766893
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Case 0
    str_0 = '\\^u\x0bC\\{`V%b{_2THx'
    var_0 = load_module_from_file_location(str_0)
    assert isinstance(var_0, types.ModuleType)

    # Case 1
    str_1 = '%c\"\\E\\s\x18\\\x14\\\x0e\x1c\\weHT\x00'
    var_1 = load_module_from_file_location(str_1)
    assert isinstance(var_1, types.ModuleType)

    # Case 2
    str_2 = 'tc\\\x1c\x14\\\x0e\x1c\\\x0ex\\\x1c\x1c\\\x0e'

# Generated at 2022-06-26 04:07:53.578308
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '\\^u\x0bC\\{`V%b{_2THx'
    try:
        var_0 = load_module_from_file_location(str_0)
    except Exception:
        var_0 = None
    assert var_0 is None

# Generated at 2022-06-26 04:08:03.400619
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        test_case_0()
    except ValueError:
        assert False
    else:
        assert True


if __name__ == "__main__":
    print("Test: load_module_from_file_location")
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:08:06.296522
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_1 = '/tmp/.$'
    var_1 = load_module_from_file_location(str_1)


# Generated at 2022-06-26 04:08:09.824159
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert callable(load_module_from_file_location)
    # TODO: Stubs
    # TODO: Asserts

# Generated at 2022-06-26 04:08:13.845169
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    result = load_module_from_file_location("random_module_name",
                                            "/some/path/to/some_file.py")
    assert result != None

# Generated at 2022-06-26 04:08:15.277049
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_case_0()

# Generated at 2022-06-26 04:08:21.243710
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from hypothesis import given
    from hypothesis.strategies import binary, characters, tuples

    @given(
        location=tuples(
            binary(), binary(), binary(), characters(min_codepoint=0)
        ),
        encoding=binary(),
    )
    def test_load_module_from_file_location__strategy(
        location, encoding
    ):  # noqa
        location_0, location_1, location_2, location_3 = location
        import io
        import contextlib
        import importlib.util

        @contextlib.contextmanager
        def _mock_spec_from_file_location(
            name, location, *args, **kwargs
        ):  # noqa
            yield None


# Generated at 2022-06-26 04:08:22.973722
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_case_0()

# Generated at 2022-06-26 04:08:31.631045
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    assert hasattr(load_module_from_file_location, "__call__")
    assert callable(load_module_from_file_location)

    str_0: str = '\\^u\x0bC\\{`V%b{_2THx'
    var_0: types.ModuleType = load_module_from_file_location(str_0)

    str_1: str = 'yep'
    str_2: str = 'yup'
    str_3: str = 'yeah'
    str_4: str = 'yes'
    str_5: str = 'y'
    str_6: str = 'yes'
    str_7: str = 'true'
    str_8: str = 't'
    str_9: str = 'on'

# Generated at 2022-06-26 04:08:32.999124
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        test_case_0()
    except Exception as exp:
        assert False, (
            "load_module_from_file_location raised Exception: "
            + str(exp)
        )



# Generated at 2022-06-26 04:08:37.167658
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_string('FwIaJ')
    load_module_from_file_location('\\^u\x0bC\\{`V%b{_2THx')

# Generated at 2022-06-26 04:08:44.249315
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-26 04:08:53.419166
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from types import FunctionType, ModuleType

    assert isinstance(load_module_from_file_location('./tests/app.py'), ModuleType)
    assert isinstance(load_module_from_file_location('tests/app.py'), ModuleType)
    assert isinstance(load_module_from_file_location('tests/app.py'), ModuleType)
    assert isinstance(load_module_from_file_location('tests/app.py'), ModuleType)
    assert isinstance(load_module_from_file_location('./tests/app.py'), ModuleType)
    assert isinstance(load_module_from_file_location('./tests/app.py'), ModuleType)
    assert isinstance(load_module_from_file_location('./tests/app.py'), ModuleType)

# Generated at 2022-06-26 04:08:55.468076
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert callable(load_module_from_file_location)


# Generated at 2022-06-26 04:09:03.342631
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        test_case_0()
    except Exception as e:
        raise Exception("test_case_0: {0}".format(e))
    try:
        assert str_to_bool(
            'g'
        )  # This should fail since one of the two cases is not being matched.
    except ValueError as e:
        pass  # This is the expected case
    else:
        raise Exception(
            "Expected a ValueError exception to be raised."
        )  # This should not occur

# Generated at 2022-06-26 04:09:07.801214
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '\\^u\x0bC\\{`V%b{_2THx'
    assert load_module_from_file_location(str_0) == None



# Generated at 2022-06-26 04:09:15.588282
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Case 0, from the comments of the function
    assert not ("some_module_name" in sys.modules)
    sys.path.append("/some/path")
    os_environ["some_env_var"] = "some_var_value"
    module_0 = load_module_from_file_location(
        "some_module_name",
        "/some/path/${some_env_var}",  # Will be resolved to os.path.join("/some/path/", "some_var_value")
        subdir="some_subdir",
        suffix="_suffix",
    )
    assert module_0 is not None
    assert module_0.__name__ == "some_module_name"
    assert "some_module_name" in sys.modules

# Generated at 2022-06-26 04:09:20.759097
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '\\^u\x0bC\\{`V%b{_2THx'
    var_0 = load_module_from_file_location(str_0)
    if str_to_bool('t'):
        str_1 = "a"
        var_1 = load_module_from_file_location(str_1)


# Generated at 2022-06-26 04:09:30.011363
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Execution of load_module_from_file_location with arguments
    #   location = '\\^u\x0bC\\{`V%b{_2THx'
    #   encoding = 'utf8'
    #   args = ()
    #   kwargs = {}
    # should not raise any exception
    try:
        test_case_0()
    except Exception:
        raise AssertionError("Failed test case 0")

# Generated at 2022-06-26 04:09:40.933521
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("tests.test_utils.test_case_0", "./tests/test_utils.py")
    assert load_module_from_file_location("./tests/test_utils.py")
    assert load_module_from_file_location("tests.test_utils.test_case_0", "./tests/test_utils.py").test_case_0()
    assert load_module_from_file_location("./tests/test_utils.py").test_case_0()


# Generated at 2022-06-26 04:09:54.384808
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def test_case_1():
        str_0 = '\\^u\x0bC\\{`V%b{_2THx'
        var_0 = '\\^u\x0bC\\{`V%b{_2THx'
        var_1 = '\\^u\x0bC\\{`V%b{_2THx'
        var_2 = load_module_from_file_location(var_0)
        var_3 = load_module_from_file_location(var_1)

    def test_case_2():
        var_0 = b'\xd2\xa0\xef\x8c\xf3\x0b\x9d\x14\xbb\x87\xe2'

# Generated at 2022-06-26 04:09:59.672278
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    return load_module_from_file_location('./testdata/config.py')


# Generated at 2022-06-26 04:10:00.900274
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert True == load_module_from_file_location("True")


# Generated at 2022-06-26 04:10:10.851484
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # bytes_0 = b'\xd2\xa0\xef\x8c\xf3\x0b\x9d\x14\xbb\x87\xe2'
    bytes_0 = b'\xd2\xa0\xef\x8c'
    string_0 = '\xd2\xa0\xef\x8c'
    print(bytes_0)
    print(string_0)


# Generated at 2022-06-26 04:10:23.369308
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    bytes_0 = b'\xd2\xa0\xef\x8c\xf3\x0b\x9d\x14\xbb\x87\xe2'

    module = load_module_from_file_location('tests/config.py')

    assert module.TEST_KEY == 'config.TEST_KEY'
    assert module.TEST_KEY2 == 'config.TEST_KEY2'
    
    module = load_module_from_file_location(bytes_0)
    module = load_module_from_file_location(bytes_0, encoding='utf8')
    
    module = load_module_from_file_location('tests/config.py', 'subpackage')
    
    
if __name__ == '__main__':
    test_case_0()
    test_load

# Generated at 2022-06-26 04:10:35.340243
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert type(load_module_from_file_location(b'\xd2\xa0\xef\x8c\xf3\x0b\x9d\x14\xbb\x87\xe2')) == types.ModuleType
    assert type(load_module_from_file_location(b'\xd2\xa0\xef\x8c\xf3\x0b\x9d\x14\xbb\x87\xe2', 'utf-32')) == types.ModuleType
    assert type(load_module_from_file_location(b'\xd2\xa0\xef\x8c\xf3\x0b\x9d\x14\xbb\x87\xe2', 'utf-32', True)) == types.ModuleType

# Generated at 2022-06-26 04:10:46.366135
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # simple case
    assert load_module_from_file_location(Path(__file__))
    assert load_module_from_file_location(__file__)

    # Path case
    assert load_module_from_file_location(Path(__file__)) == load_module_from_file_location(
        __file__
    )

    # env variable case
    some_env_var = "SOME_ENV_VAR"
    os_environ[some_env_var] = __file__
    assert load_module_from_file_location(
        "/some/path/${" + some_env_var + "}"
    ) == load_module_from_file_location(Path(__file__))

# Generated at 2022-06-26 04:10:53.762796
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    bytes_0 = b'\xd2\xa0\xef\x8c\xf3\x0b\x9d\x14\xbb\x87\xe2'
    load_module_from_file_location(bytes_0)
    load_module_from_file_location(bytes_0, encoding="utf-8")
    load_module_from_file_location(bytes_0, encoding="utf_8")
    load_module_from_file_location(bytes_0, encoding="utf8")
    load_module_from_file_location(bytes_0, encoding="utf16")
    load_module_from_file_location(bytes_0, encoding="utf32")

# Generated at 2022-06-26 04:11:06.677537
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    config_sample_str = """
        # Test configuration file
        DB_USER = "user"
        DB_PASSWORD = "password"
        DB_HOST = "127.0.0.1"

        SOME_INT = 25
        TEST_LIST = [1, 2, 3]
        TEST_DICT = {"key": "value", "1": 2}
        TEST_TUPLE = (1, 2, 3)
        TEST_SET = {1, 2, 3, 4}
        TEST_BOOL = True
    """
    with open("config_sample.py", "w") as config_file:
        config_file.write(config_sample_str)

    # A) Check if return is module_from_spec
    returned_module = load_module_from_file_location("config_sample.py")


# Generated at 2022-06-26 04:11:15.379195
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    mock_0 = Mock()

    # Call the function
    ret_val_0 = load_module_from_file_location(mock_0)

    # Assert the return type
    assert (
        isinstance(ret_val_0, ModuleType)
    ), 'Return value should be of type "ModuleType"'

    # Return the function's return value
    return ret_val_0



# Generated at 2022-06-26 04:11:28.686992
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Testing the function load_module_from_file_location"""
    # Replace
    from sanic_openapi import doc as sanic_openapi_doc
    from sanic_openapi import swagger_blueprint as sanic_openapi_swagger_blueprint
    from sanic.exceptions import FlattenException, SanicException
    from sanic.handlers import ErrorHandler
    from sanic import Sanic
    from sanic.response import json
    from sanic.log import logger
    from sanic.websocket import WebSocketProtocol
    from sanic.views import HTTPMethodView
    from sanic.server import HttpProtocol, WebSocketProtocol
    from sanic.exceptions import ServerError
    from sanic.response import HTTPResponse
    from sanic import helpers

# Generated at 2022-06-26 04:11:33.275309
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert 1 == 1

# Generated at 2022-06-26 04:11:42.588220
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # test case 0
    '''
    bytes_0 = b'\xd2\xa0\xef\x8c\xf3\x0b\x9d\x14\xbb\x87\xe2' 
    test_result_0 = load_module_from_file_location(bytes_0, encoding='utf8', *args, **kwargs)
    '''
    # test case 0
    bytes_0 = b'\xd2\xa0\xef\x8c\xf3\x0b\x9d\x14\xbb\x87\xe2' 
    test_result_0 = load_module_from_file_location(bytes_0, encoding='utf8')
    expected_result_0 = None 
    assert test_result_0 == expected_result_0
    #

# Generated at 2022-06-26 04:11:48.777718
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        "/home/ubuntu/workspace/sanic/examples/env_vars/config.py",
        "utf8",
        False,
        "/home/ubuntu/workspace/sanic/examples/env_vars/config.py",
    )
    assert module is not None


# Generated at 2022-06-26 04:11:56.900619
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # case 0: function: load_module_from_file_location
    try:
        assert b'\xd2\xa0\xef\x8c\xf3\x0b\x9d\x14\xbb\x87\xe2' == load_module_from_file_location(b'\xd2\xa0\xef\x8c\xf3\x0b\x9d\x14\xbb\x87\xe2')
    except LoadFileException:
        raise LoadFileException('Incorrect exception raised')
    except:
        raise


# Generated at 2022-06-26 04:12:07.516411
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test the case where location is a  bytestr
    print('\nRunning test test_load_module_from_file_location')

# Generated at 2022-06-26 04:12:10.138643
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location(bytes_0)


# Generated at 2022-06-26 04:12:15.040997
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    print('test_load_module_from_file_location')
    assert load_module_from_file_location(
        'tests/test_conf_files/module_from_file.py') is not None


# Generated at 2022-06-26 04:12:20.515738
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "./load_module_from_file_location.py"
    module = load_module_from_file_location(location)
    assert module.__name__ == 'load_module_from_file_location'


# Generated at 2022-06-26 04:12:24.541317
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Find any module
    bytes_0 = b'\xf9\xca\x05\x90\x84\xff\x95\x93\xe7\x8c\x95'
    assert load_module_from_file_location(
        bytes_0, 'utf8'
    ) is not None



# Generated at 2022-06-26 04:12:34.452991
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    print("Testing load module from file location \n")
    bytes_0 = b'\xd2\xa0\xef\x8c\xf3\x0b\x9d\x14\xbb\x87\xe2'
    try:
        # In case of bytes
        load_module_from_file_location(bytes_0)

    except Exception as e:
        if str(e) != "Unable to load configuration b'\\xd2 \\xa0 \\ef \\x8c \\xf3 \\x0b \\x9d \\x14 \\xbb \\x87 \\xe2'":
            print("Exception: ", str(e), "\n")
            return
    else:
        print("There was an error")
        return
    print("Passed \n")


# Generated at 2022-06-26 04:12:47.219350
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    location = "./test_data/test_config.py"
    module_name = "test_config"

    # this step is needed because we want to be able to import
    # file generated with load_module_from_file_location even if
    # it is generated in the same session
    del sys.modules[module_name]

    try:
        module = load_module_from_file_location(location)
    except Exception:
        assert False, "Should be no exception."

    var_0 = module.VAR_0
    var_1 = module.VAR_1

    assert isinstance(var_0, str), "Should be of a string type."
    assert isinstance(var_1, int), "Should be of a string type."

    assert var_0 == "1", "Should be 1"
    assert var_

# Generated at 2022-06-26 04:12:55.678874
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    a = load_module_from_file_location(
        "conf.json")  # Returns module with __example__ variable.
    assert a.__example__ == 1
    try:
        b = load_module_from_file_location(
            "tests/app/sanic_app_test.py"
        )  # Returns module with __example__ variable.
        assert b.__example__ == 1
    except LoadFileException:
        print("test_load_module_from_file_location() FAILED")
        assert 1 == 2, "test_load_module_from_file_location() FALIED"
    else:
        print("test_load_module_from_file_location() PASS")
        assert 1 == 1, "test_load_module_from_file_location() PASS"


# Generated at 2022-06-26 04:13:04.912839
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = "BBvE,Rh'2$S;1Hw\x0cZ:@J-q3(j.>xW\x19\x07\x0e\x06\x03\x0e\x13"
    str_1 = "W+Fv\x1b'Y\x1c;f+\x1b\x1a(_\x1f\x0fP"
    bool_0 = str_to_bool(str_0)
    bool_1 = str_to_bool(str_1)
    bool_2 = str_to_bool(str_1)
    bool_3 = str_to_bool(str_0)
    bool_4 = str_to_bool(str_1)
    bool_5 = str_to_bool(str_1)

# Generated at 2022-06-26 04:13:11.840466
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = '"FTZMRiYuMC6zwd\x0c,9&+'
    encoding = 'ascii'
    *args = ['--', '-', 'S']

# Generated at 2022-06-26 04:13:24.690406
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "./sanic.json"
    module = load_module_from_file_location(location)

# Generated at 2022-06-26 04:13:28.081583
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    settings = load_module_from_file_location('./sanic/examples/config_example.py')

# Generated at 2022-06-26 04:13:37.711930
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '"FTZMRiYuMC6zwd\x0c,9&+'
    bool_0 = str_to_bool(str_0)
    test_data = [{"file_name": "test_config.py"}, {"file_name": "test_config.py", "location": "/nonexist"}]
    for data in test_data:
        flag = "location" in data
        file_name = data["file_name"]
        if flag:
            location = data["location"]
            try:
                module = load_module_from_file_location(location, file_name)
            except Exception as e:
                print(e)

# Generated at 2022-06-26 04:13:47.824267
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import imp
    import sys
    import tempfile
    import shutil


# Generated at 2022-06-26 04:13:58.385986
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # This function must exist, otherwise comment
    # this unit test line.
    assert callable(load_module_from_file_location)
    # This function must not throw an exception.
    try:
        # If this line does not throw an exception,
        # all is OK.
        load_module_from_file_location(
            '"FTZMRiYuMC6zwd\x0c,9&+'
        )
    except Exception as e:
        # On exception, check if it is LoadFileException,
        # otherwise it is a other type of exception,
        # which is not allowed.
        if isinstance(e, LoadFileException):
            raise
        else:
            raise Exception(e)

# Generated at 2022-06-26 04:14:03.460097
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("/home/anuj/Desktop/")

#Unit test case to test the function load_module_from_file_location

# Generated at 2022-06-26 04:14:11.187362
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_0 = Path("h3Pn_joURb\\\x0e\\\x12^\x1d\x1f\\")

    load_module_from_file_location(path_0)
    load_module_from_file_location(path_0, "cp1250")


if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:14:13.109846
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location("my_config.py")

# Generated at 2022-06-26 04:14:16.219078
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "io_sanic.server:config"
    arr = load_module_from_file_location(location)


# Generated at 2022-06-26 04:14:18.127090
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = '${HOME}/config'
    mod = load_module_from_file_location(location)

# Generated at 2022-06-26 04:14:25.779486
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ

    location = os_environ.get("some_env_var")
    if not location:
        raise RuntimeError("Environment variable some_env_var is not set.")

    assert load_module_from_file_location(location)



# Generated at 2022-06-26 04:14:35.676432
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    importlib = __import__("importlib")
    importlib.reload(importlib.util)
    mod = load_module_from_file_location("bytes", __file__)
    assert mod
    mod = load_module_from_file_location("os.path", __file__)
    assert mod
    mod = load_module_from_file_location("pathlib", __file__)
    assert mod

    with open(__file__) as file:
        mod = load_module_from_file_location(b"bytes", file)
        assert mod
        mod = load_module_from_file_location("os.path", file)
        assert mod
        mod = load_module_from_file_location("pathlib", file)
        assert mod


# Generated at 2022-06-26 04:14:39.707555
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_0 = load_module_from_file_location(
        "os", "/Library/Frameworks/Python.framework/Versions/3.7/lib/python3.7/os.py",  # noqa
        "rb", True, True,
    )
    assert module_0 is not None

# Generated at 2022-06-26 04:14:46.198920
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_mod = load_module_from_file_location(
        "sanic.tests.config.file_config_test_1"
    )
    test_mod_2 = load_module_from_file_location(
        "sanic.tests.config.file_config_test_2"
    )
    assert test_mod.test_conf == "works"
    assert test_mod.test_conf_2 == "works"
    assert test_mod_2.test_conf == "works"

# Generated at 2022-06-26 04:14:51.237231
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location(): # checks if the module is imported properly
    module = load_module_from_file_location(
        "../test_files/test_application_config.py"
    )
    assert module.test_var == "test_string"


# Generated at 2022-06-26 04:14:56.301492
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location(
        "sanic/unittest/test_load_module_from_file_location_file.py"
    )


# Generated at 2022-06-26 04:15:02.185259
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "./tests/test_configs"
    module = load_module_from_file_location(location)
    assert module.TEST_0 is True


# Generated at 2022-06-26 04:15:14.134725
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    def create_temp_py_file(content: str, file_name: str = "temp.py"):
        fd, path = tempfile.mkstemp(suffix=file_name)
        with os.fdopen(fd, "w") as tmp:
            tmp.write(content)
        return path

    location = create_temp_py_file("a = 2", file_name="temp_0.py")
    result = load_module_from_file_location(location)
    assert result.a == 2

    location = create_temp_py_file("a = 2")
    result = load_module_from_file_location(location)
    assert result.a == 2

    os_environ["some_env_var"] = "some_path"

# Generated at 2022-06-26 04:15:25.197735
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Case 1: Case-sensitive environment variable
    # To run test case properly set environment variable with name TEST_VAR
    module_1 = load_module_from_file_location(
        "test_module_1", Path(__file__).parent / "assets" / "module_1.py"
    )
    assert module_1.TEST_VAR == os_environ.get("TEST_VAR")

    # Case 2: Case-insensitive environment variable
    # To run test case properly set environment variable with name test_var
    module_2 = load_module_from_file_location(
        "test_module_2", Path(__file__).parent / "assets" / "module_2.py"
    )
    assert module_2.TEST_VAR == os_environ.get("test_var")

# Generated at 2022-06-26 04:15:30.496924
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Loads a module from file location."""
    m = load_module_from_file_location(
        "project_directory.settings", ".env"
    )
    assert m.ERROR_MESSAGE == "Oops, something went wrong"

# Generated at 2022-06-26 04:15:34.443660
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    _path = os.path.join(os.path.dirname(__file__), '__init__.py')
    module = os.path.basename(_path)[:-3]

    assert module in load_module_from_file_location(_path)

# Generated at 2022-06-26 04:15:38.768927
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert True

if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:15:44.373087
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "./"
    ready_to_compare = "./"
    res = load_module_from_file_location(location, "utf8")
    assert ready_to_compare == res.__file__
    return

test_load_module_from_file_location()
test_case_0()


# Generated at 2022-06-26 04:15:55.927566
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    a = load_module_from_file_location("tests.app_example")
    assert a.test_setting == "yep"
    a = load_module_from_file_location("tests/app_example.py")
    assert a.test_setting == "yep"
    a = load_module_from_file_location(Path("tests/app_example.py"))
    assert a.test_setting == "yep"
    a = load_module_from_file_location(Path("tests/app_example"))
    assert a.test_setting == "yep"
    a = load_module_from_file_location("tests/app_example")
    assert a.test_setting == "yep"
    a = load_module_from_file_location("${PWD}/tests/app_example")
   