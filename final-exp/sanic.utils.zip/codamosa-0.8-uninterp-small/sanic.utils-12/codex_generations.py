

# Generated at 2022-06-26 04:06:00.146293
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("no") is False
    assert str_to_bool("false") is False
    assert str_to_bool("FALSE") is False
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("nope") is False
    assert str_to_bool("on") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("off") is False
    assert str_to_bool("OFF") is False
    assert str_to_bool("1") is True


# Generated at 2022-06-26 04:06:11.148096
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pathlib
    import sys
    import os
    import tempfile
    import shutil

    path = pathlib.Path(tempfile.mkdtemp())

# Generated at 2022-06-26 04:06:12.241388
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

# Generated at 2022-06-26 04:06:25.167500
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_0 = module_0.Path('/')
    assert load_module_from_file_location(path_0) == None
    assert load_module_from_file_location(path_0) == None
    assert load_module_from_file_location(path_0) == None
    assert load_module_from_file_location(path_0) == None
    assert load_module_from_file_location(path_0) == None
    assert load_module_from_file_location(path_0) == None
    assert load_module_from_file_location(path_0) == None
    assert load_module_from_file_location(path_0) == None
    assert load_module_from_file_location(path_0) == None

# Generated at 2022-06-26 04:06:31.397125
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic_envconfig import EnvConfig, Str, Path, Int

    class Config(EnvConfig):
        DB_HOST: str = Str("localhost")
        DB_PORT: int = Int(None)
        DB_USER: str = Str("")
        DB_PASS: str = Str("")
        DB_NAME: str = Str("")
        DB_LOG_QUERIES: bool = True
        LOG: str = Str("prod.log")

    def test_case_0():
        load_module_from_file_location(
            f"""
DB_HOST = "127.0.0.1"
DB_PASS = "my_password"
""",
            "test.py",
        )

    def test_case_1():
        load_module_from_file_location("test.py")



# Generated at 2022-06-26 04:06:35.156320
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_0 = pathlib.Path()
    var_0 = load_module_from_file_location(path_0)
import pathlib as module_0


# Generated at 2022-06-26 04:06:36.884027
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = Path()
    var = load_module_from_file_location(path)

    assert var is not None

# Generated at 2022-06-26 04:06:37.749304
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_case_0()

# Generated at 2022-06-26 04:06:49.178777
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Mocking environment variables
    env_vars_to_mock = {}
    for arg in (
        "location",
    ):
        env_vars_to_mock["{" + arg + "}"] = str(os.environ[arg])

    # Create dummy files for testing
    for i in range(1):
        with open(f"load_module_from_file_location_test_{i}.py", "w") as f:
            f.write(
                "def some_func():\n"
                f"    return {i}\n"
                "\n"
                "some_var = {i}\n"
            )
            f.flush()


# Generated at 2022-06-26 04:06:59.691697
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pathlib as module_0
    path_0 = module_0.Path()
    var_0 = load_module_from_file_location(path_0)

    import pathlib as module_1
    path_1 = module_1.Path()
    var_1 = load_module_from_file_location(path_1)

    import pathlib as module_2
    path_2 = module_2.Path()
    var_2 = load_module_from_file_location(path_2)

    for var_3 in {var_0, var_1, var_2}:
        if var_3 is not var_0:
            raise ValueError(var_3)



# Generated at 2022-06-26 04:07:06.362211
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = 'g('
    load_module_from_file_location(str_0)



# Generated at 2022-06-26 04:07:11.918746
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = '/home/lk43/leo/sanic/test/test_config_loader_case.py'
    some_module = load_module_from_file_location(location)
    assert callable(some_module.hello_world)
    assert some_module.hello_world() == "hello world"

# Generated at 2022-06-26 04:07:25.453444
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Invalid input
    try:
        # Unexpected input
        load_module_from_file_location(42, 42)
    except TypeError:
        pass
    
    try:
        # Unexpected input
        load_module_from_file_location(b'42', '42')
    except TypeError:
        pass

    try:
        # Environment variable not set
        load_module_from_file_location('${not_set}')
    except LoadFileException:
        pass

    # Correct tests
    load_module_from_file_location(Path(__file__))
    load_module_from_file_location('/no/such/folder/file.py')

    # FIXME: Does not test that environment variables are substituted
    load_module_from_file_location('${HOME}/file.py')



# Generated at 2022-06-26 04:07:27.253044
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests if function load_module_from_file_location raises"""

    # Case 0 - function raises
    try:
        test_case_0()
        assert False
    except ValueError:
        assert True
    except:
        assert False


if __name__ == "__main__":
    test_load_module_from_file_location()
    test_case_0()

# Generated at 2022-06-26 04:07:31.331309
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("test")
    if module is None:
        raise Exception("test module is None")
    else:
        print(module)



# Generated at 2022-06-26 04:07:36.714330
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = '/home/ubuntu/Projects/sanic/examples/'
    path_2 = '/home/ubuntu/Projects/sanic/examples/server_settings.py'
    str_0 = 'g('
    module_0 = load_module_from_file_location(path)
    module_1 = load_module_from_file_location(path_2)
    module_2 = load_module_from_file_location(str_0)


# Generated at 2022-06-26 04:07:40.244321
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_location = "/path/to/file.py"

    config_module = load_module_from_file_location(file_location)

# Generated at 2022-06-26 04:07:42.893692
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_0 = '/home/ubuntu/vectors/sanic_server/sanic_server/test_config_0.py'
    module_0 = load_module_from_file_location(path_0, 'utf8')
    print(module_0.INPUT_DIM)

# Generated at 2022-06-26 04:07:54.664042
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        os.environ['ENV'] = '1'
        os.environ['ENV2'] = '2'
        m = load_module_from_file_location('/etc/environment',
                                           '${ENV}/${ENV2}')
        os.environ.pop('ENV', None)
        os.environ.pop('ENV2', None)
    except Exception as e:
        raise

    assert m.__file__ == '/etc/environment'


if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:08:01.830892
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "settings.py"
    encoding = "utf8"
    module_0 = load_module_from_file_location(location, encoding)
    assert isinstance(module_0, types.ModuleType)

if __name__ == '__main__':
    test_load_module_from_file_location()
    test_case_0()

# Generated at 2022-06-26 04:08:05.929083
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = 'my_module'
    load_module_from_file_location(location)

# Generated at 2022-06-26 04:08:15.003374
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    py_filepath = "./test_load.py"
    ret_module = load_module_from_file_location(py_filepath)
    assert ret_module.__name__ == "test_load"

    py_filepath = b"./test_load.py"
    ret_module = load_module_from_file_location(py_filepath, "ascii")
    assert ret_module.__name__ == "test_load"

# Generated at 2022-06-26 04:08:18.749653
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "./tests/test_files/test_file.py"

    func_0 = load_module_from_file_location(location)


try:
    test_case_0()
except ValueError:
    print("ValueError")

try:
    test_load_module_from_file_location()
except TypeError:
    print("TypeError")

# Generated at 2022-06-26 04:08:19.610887
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass



# Generated at 2022-06-26 04:08:27.112560
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 0
    file_name = 'test_case_0'
    # file_name = 'test_case_1'
    file_path = Path(os_environ['PY_FILE']).joinpath(file_name)
    module = load_module_from_file_location(file_path)
    print(module.__dict__)


# Generated at 2022-06-26 04:08:31.642712
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    '''
    This function is used to test the load_module_from_file_location function
    '''
    location = './test_data/workspace.py'
    args = ''
    kwargs = ''
    error_msg = None
    try:
        result = load_module_from_file_location(
            location, *args, **kwargs
        )
    except Exception as e:
        error_msg = str(e)
    finally:
        assert error_msg is None, error_msg



# Generated at 2022-06-26 04:08:35.700780
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # case 1: string:
    try:
        case_1 = load_module_from_file_location(
            'a', 'tests/fixtures/exception_example.py'
        )
        assert type(case_1) == types.ModuleType
    except Exception:
        assert False, 'load_module_from_file_location failed for str'
    # case 2: bytes:
    try:
        case_2 = load_module_from_file_location(
            b'a', b'tests/fixtures/exception_example.py'
        )
        assert type(case_2) == types.ModuleType
    except Exception:
        assert False, 'load_module_from_file_location failed for bytes'
    # case 3: pathlib Path:

# Generated at 2022-06-26 04:08:39.331070
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for load_module_from_file_location"""

    str_0 = "/some/path"
    location = str_0

    module = load_module_from_file_location(location)
    assert(module.__file__ == "/some/path")

# Generated at 2022-06-26 04:08:48.063023
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # check load_module_from_file_location works as expected with valid input
    location = 'test_config.py'
    module = load_module_from_file_location(
        location=location,
        encoding='utf8',
        # args,
        # kwargs,
    )
    assert hasattr(module, 'KEY')


# Generated at 2022-06-26 04:08:54.231529
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("sanic.exceptions", "")
    assert module.__name__ == "sanic.exceptions"


module = load_module_from_file_location("sanic.exceptions", "")
print(module)

# Generated at 2022-06-26 04:09:04.057150
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location"""
    # testing for file location = "file_location"
    module = load_module_from_file_location("file_location")
    assert module is not None
    # testing for file location = "file_location", encoding = "utf8"
    module = load_module_from_file_location("file_location", "utf8")
    assert module is not None
    # testing for file location = b"file_location"
    module = load_module_from_file_location(b"file_location")
    assert module is not None
    # testing for file location = b"file_location", encoding = "utf8"
    module = load_module_from_file_location(b"file_location", "utf8")
    assert module is not None
    # testing for file location =

# Generated at 2022-06-26 04:09:06.571006
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_file_name = './test_case_0.py'
    module_name = 'test_case_0'
    module_instance = load_module_from_file_location(path_file_name, "utf-8")
    assert(module_instance.__name__ == module_name)

test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:08.885732
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_case_0()

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:09:13.943866
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    mod_0 = load_module_from_file_location(
        'sanic.config',
        '/Users/nephiel/Programming/github/sanic/sanic/config.py',
        None
    )

# Generated at 2022-06-26 04:09:22.817157
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location_0 = (
        "sanic_openapi.__main__"
    )  # location with package path and then file name
    result_0 = load_module_from_file_location(
        location_0
    )  # call function load_module_from_file_location
    assert result_0 is not None  # assert that result is not empty

    location_1 = (
        "tests/openapi_directory/swagger.yaml"
    )  # location with directory path without file extension
    result_1 = load_module_from_file_location(
        location_1
    )  # call function load_module_from_file_location
    assert result_1 is not None  # assert that result is not empty

# Generated at 2022-06-26 04:09:26.298112
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = "opt.py"
    module = load_module_from_file_location(path)
    assert module.opt == 1


# Generated at 2022-06-26 04:09:36.627473
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from os import unsetenv

    # 1) Check that str_to_bool works as expected
    test_case_0()
    test_case_1()

    # 2) Check that we can load module from file
    module_1 = load_module_from_file_location(
        "tests/test_config/asdasd.py"
    )
    assert module_1.test_variable_1 == 1
    assert module_1.test_variable_2 == "some_string"
    assert module_1.test_variable_3 == [1, 2, 3, 4, 5]

    # 3) Check that we can load module directly from environment
    #    variable with relative path (will be relative to current
    #    working directory)

# Generated at 2022-06-26 04:09:45.871698
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from random import randint
    from tempfile import NamedTemporaryFile

    # Create random name for a file.

# Generated at 2022-06-26 04:09:56.164854
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # str
    str_0 = "./test_str.py"
    module = load_module_from_file_location(str_0)
    assert module.attr == "attr"

    # bytes
    bytes_0 = b"./test_str.py"
    module = load_module_from_file_location(bytes_0)
    assert module.attr == "attr"

    # Path
    Path_0 = "./test_str.py"
    module = load_module_from_file_location(Path_0)
    assert module.attr == "attr"

    # Error
    try:
        load_module_from_file_location("./test_error.py")
    except LoadFileException as e:
        assert "Unable to load configuration file" in e.args[0]

# Generated at 2022-06-26 04:10:05.273291
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Load script with invalid command "g("
    location = os.path.dirname(os.path.realpath(__file__))
    location = os.path.join(location, "load_module_invalid.py")
    # Should skip load and return None
    module = load_module_from_file_location(location)
    assert module is None
    
    location = os.path.dirname(os.path.realpath(__file__))
    location = os.path.join(location, "load_module_valid.py")
    # Should load the module
    module = load_module_from_file_location(location)
    assert str(module.__file__) == location
    assert module.config is not None
    assert 'some_config' in module.config

# Generated at 2022-06-26 04:10:15.216723
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_loc = 'config/config.py'
    mod = load_module_from_file_location(file_loc)
    print(mod)


if __name__ == "__main__":
    # test_load_module_from_file_location()
    test_case_0()

# Generated at 2022-06-26 04:10:20.556997
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/path/module.py'
    module_0 = load_module_from_file_location(str_0)
    assert isinstance(module_0, types.ModuleType)

# Generated at 2022-06-26 04:10:22.677335
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    reload(helpers)
    helpers.load_module_from_file_location('./helpers.py')

# Generated at 2022-06-26 04:10:31.379696
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("./dataset_descriptor.py", "utf8")
    assert module.__name__ == "dataset_descriptor"
    module = load_module_from_file_location("./train_config.json", "utf8")
    assert module.__name__ == 'config'

# Generated at 2022-06-26 04:10:33.302029
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "test.py"
    module = load_module_from_file_location(location)

# Generated at 2022-06-26 04:10:38.438322
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    module_1 = load_module_from_file_location('config_3.py')
    assert module_1.WHATEVER[1] == 2
    assert module_1.WHATEVER_2[0] == 0


# Generated at 2022-06-26 04:10:46.776468
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test for Type error
    try:
        # Load module for existing file path
        module = load_module_from_file_location('sanic/app.py')
        assert module.__name__ == 'app'
    except Exception as e:
        print(e)
        assert False

    try:
        # Load module for non existing file path
        module = load_module_from_file_location('sanic/abc.py')
        assert False
    except IOError as e:
        assert True

    try:
        # Load module for non python file (.txt)
        module = load_module_from_file_location('sanic/app.txt')
        assert False
    except LoadFileException as e:
        assert True

# Generated at 2022-06-26 04:10:56.337964
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests loading module in the following 3 ways:
        1) passing path with environment variable of
           the location of file.
        2) passing path of the location of file.
        3) passing just module name.
    """
    # 1)
    load_module_from_file_location(
        "test_module",
        "${PWD}/test_utils.py"
    )

    # 2)
    load_module_from_file_location(
        "test_module",
        f"{Path.cwd()}/test_utils.py"
    )

    # 3)
    load_module_from_file_location(
        "test_utils"
    )

# Generated at 2022-06-26 04:11:04.502193
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Try to load nonexisting file
    nonexisting_file = "tests/test_nonexisting_file.py"
    try:
        load_module_from_file_location(nonexisting_file)
        assert False
    except FileNotFoundError:
        pass


# Check if load_module_from_file_location can
# load module without extensions

# Generated at 2022-06-26 04:11:17.170030
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 1
    location = "sanic.config.test_data.test_load_module_from_file_location_test_data"
    module = load_module_from_file_location(location)
    assert module.TEST_VAR_0 == "Test variable 0"
    assert module.TEST_VAR_1 == 1

    # Test 2
    location = "sanic.config.test_data.test_load_module_from_file_location_test_data.ini"
    module = load_module_from_file_location(location)
    assert module.TEST_VAR_0 == "Test variable 0"
    assert module.TEST_VAR_1 == 1

# Generated at 2022-06-26 04:11:22.147987
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("sanic.views")

# Generated at 2022-06-26 04:11:23.040700
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location('test_file.py')
    except Exception:
        assert True
    else:
        assert False

# Generated at 2022-06-26 04:11:27.362906
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        assert_module = load_module_from_file_location('./test/test.py')
        assert assert_module.my_config == 2
    except Exception as e:
        print(e)


# Generated at 2022-06-26 04:11:33.784240
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    check_0 = load_module_from_file_location(__file__)
    assert check_0 == __name__

if __name__ == '__main__':
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:11:38.726556
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_0 = ('/home/lrb/Downloads/fuzzer/sanic/fuzzer/' +
              'test_cases/load_module_from_file_location/test_file_0.json')
    module_0 = load_module_from_file_location(path_0)


# Generated at 2022-06-26 04:11:45.995669
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # test case 0
    with pytest.raises(IOError):
        load_module_from_file_location('g')

    # test case 1
    assert load_module_from_file_location('os')
    with pytest.raises(LoadFileException):
        load_module_from_file_location('')


# Generated at 2022-06-26 04:11:48.667792
# Unit test for function load_module_from_file_location

# Generated at 2022-06-26 04:11:58.255535
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    os.environ["ENV_1"] = "1"
    os.environ["ENV_2"] = "2"
    str_0 = "./tt"
    module_0 = load_module_from_file_location(str_0)
    str_1 = "/tt"
    module_1 = load_module_from_file_location(str_1)
    str_2 = "${ENV_1}"
    module_2 = load_module_from_file_location(str_2)
    str_3 = "${ENV_2}${ENV_2}"
    module_3 = load_module_from_file_location(str_3)
    str_4 = "${ENV_2}${ENV_2}.py"
    module_4 = load_module_from_

# Generated at 2022-06-26 04:12:03.454851
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location('sanic.config') is not None


# Generated at 2022-06-26 04:12:05.124799
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert os.path.abspath(dir_path) in sys.path



# Generated at 2022-06-26 04:12:08.943537
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

# Generated at 2022-06-26 04:12:18.376780
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import os.path
    import sys
    import stat
    import random
    import string
    import tempfile
    import unittest
    import unittest.mock

    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()

    # Create the module in temporary directory
    some_module_path = os.path.join(temp_dir.name, 'some_module.py')
    with open(some_module_path, 'w+') as some_module_file:
        some_module_file.write("print('Test load module from file')\n")
    some_module_file.close()

    # Change the file mode so it can be executed
    os.chmod(some_module_path, stat.S_IEXEC)

    # mock sys.path
    sys_path

# Generated at 2022-06-26 04:12:33.117754
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # 1. Successful import from path
    assert load_module_from_file_location(
        'tests/blueprints/point/point_blu.py', 'r')

    # 2. Unsuccessful import with path to non-existing file
    assert load_module_from_file_location(
        'tests/blueprints/point/point_blu_non_existing.py', 'r')

    # 3. Unsuccessful import with bad path
    assert load_module_from_file_location(
        'tests/blueprints/point/point_blu_non_existing', 'r')

    # 4. Unsuccessful import with bad encoding
    assert load_module_from_file_location(
        'tests/blueprints/point/point_blu.py', 'r')

# Generated at 2022-06-26 04:12:43.194092
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # In case location is of a bytes type.
    path = b'/path/to/py/file.py' # type: bytes
    module = load_module_from_file_location(path)
    assert module is not None

    # In case location is of a string type.
    path = '/path/to/py/file.py' # type: str
    module = load_module_from_file_location(path)
    assert module is not None

    # In case location is Path type.
    path = Path('/path/to/py/file.py') # type: Path
    module = load_module_from_file_location(path)
    assert module is not None

    # In case location contains environment variables
    # in format ${some_env_var}.
    env_var_name = 'PATH'
    os_en

# Generated at 2022-06-26 04:12:52.196305
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_0 = 'sanic/test/test_helpers.py'
    str_0 = path_0
    module_0 = load_module_from_file_location(str_0)
    path_1 = 'sanic/test/test_helpers.py'
    str_1 = path_1
    module_1 = load_module_from_file_location(str_1)
    path_2 = 'sanic/test/test_helpers.py'
    str_2 = path_2
    module_2 = load_module_from_file_location(str_2)

# Generated at 2022-06-26 04:12:53.726041
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_path = './config_test.py'
    module = load_module_from_file_location(file_path)


# Generated at 2022-06-26 04:13:00.918050
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import configparser
    import os

    # TODO Check if file can be loaded with no errors
    # and if not, then raise

    # load_module_from_file_location("config.py")
    # load_module_from_file_location("other_config.cfg")
    # load_module_from_file_location("other_config.toml")
    # load_module_from_file_location("./config.py")
    # load_module_from_file_location("./other_config.cfg")
    # load_module_from_file_location("./other_config.toml")
    # load_module_from_file_location("/etc/myapp/config.py")
    # load_module_from_file_location("/etc/myapp/other_config.cfg")
   

# Generated at 2022-06-26 04:13:13.270778
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test for loading module from file location."""

    location = "tests/fixtures/test_config.py"
    module = load_module_from_file_location(location)
    assert module.TEST_CONFIG_KEY_0 == "test_config_val_0"

    module = load_module_from_file_location(b"tests/fixtures/test_config.py")
    assert module.TEST_CONFIG_KEY_0 == "test_config_val_0"

    os_environ["TEST_ENV_VAR_0"] = "test_env_var_val_0"

    location = "${TEST_ENV_VAR_0}/tests/fixtures/test_config.py"
    module = load_module_from_file_location(location)
    assert module.T

# Generated at 2022-06-26 04:13:14.012466
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

# Generated at 2022-06-26 04:13:20.107255
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/tmp/sanic_testcase_0.py'
    module_0 = load_module_from_file_location(str_0)

# Generated test cases for variable str_to_bool
test_case_0()

# Generated at 2022-06-26 04:13:28.150668
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_path = 'tc0.py'
    module_value = load_module_from_file_location(file_path)
    assert module_value

# Test case for function str_to_bool

# Generated at 2022-06-26 04:13:34.467054
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_name_0 = 'test_config.py'
    file_name_1 = 'test_config${PWD}.py'
    module_0 = load_module_from_file_location(file_name_0)
    module_1 = load_module_from_file_location(file_name_1)

test_load_module_from_file_location()

# Generated at 2022-06-26 04:13:39.782248
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = 'extension/sanic_sentry.py'
    try:
        module = load_module_from_file_location(location)
        print(module)
    except Exception as e:
        print(e)

# Generated at 2022-06-26 04:13:44.902540
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 0
    # (a)
    test_case_0()

    #(b)
    module_0_b = load_module_from_file_location("tests/fixtures/test_load_module_from_file_location_0.py")
    assert module_0_b.__name__ == "test_load_module_from_file_location_0"
    assert module_0_b.TEST_VALUE_0 == "test value 0"
    assert module_0_b.TEST_VALUE_0_INT == 0

    #(c)
    module_0_c = load_module_from_file_location("tests/fixtures/test_load_module_from_file_location_0.py", False)

# Generated at 2022-06-26 04:13:58.001032
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_module_name = "test_module_1"
    module = load_module_from_file_location(
        test_module_name,
        "/Users/yinchen/Documents/GitHub/sanic/tests/test_lazy_load.py",
        False,
        False,
    )
    assert test_module_name == module.__name__
    # module.__file__ is not a filename, it's
    # '/Users/yinchen/Documents/GitHub/sanic/tests/test_lazy_load.py'
    assert "/Users/yinchen/Documents/GitHub/sanic/tests/test_lazy_load.py" == module.__file__
    assert 9 == module.hello_world()


if __name__ == "__main__":
    test_case

# Generated at 2022-06-26 04:14:09.432425
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys
    import time
    print('- starting test_load_module_from_file_location')
    argv = './test_load_module_from_file_location.py'
    pid = os.fork()
    if pid:
       # This is the parent. Wait for the child to finish
       os.waitpid(pid, 0)
    else:
       # This is the child. Load the module
       load_module_from_file_location(argv)
       # Give the parent time to catch up
       time.sleep(10)
    print('- finishing  test_load_module_from_file_location')

# Generated at 2022-06-26 04:14:21.768069
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 1
    location_1 = './config.py'
    module_1 = load_module_from_file_location(location_1)
    assert module_1.config == 'value'
    # Test 2
    location_2 = Path('./config.py')
    module_2 = load_module_from_file_location(location_2)
    assert module_2.config == 'value'
    # Test 3
    os_environ['path'] = '/path/to/config/file.py'
    location_3 = '/path/to/${path}'
    module_3 = load_module_from_file_location(location_3)
    assert module_3.config == 'value'
    # Test 4

# Generated at 2022-06-26 04:14:26.017395
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = 'sanic/tests/resources/test_module.py'
    module = load_module_from_file_location(location)
    assert isinstance(module, types.ModuleType)

# Generated at 2022-06-26 04:14:31.134754
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = './test_env/config.py'
    result = load_module_from_file_location(location)

    assert result.TEST_VARIABLE == 'test variable'
    assert result.TEST_VARIABLE_2 == 'test variable 2'


# Generated at 2022-06-26 04:14:33.905519
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_module = load_module_from_file_location(
        "sanic-shell", "./sanic-shell.py"
    )

test_case_0()
test_load_module_from_file_location()

# Generated at 2022-06-26 04:14:41.701470
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Arrange
    import sanic.config
    # make a copy of the sanic.config.DEFAULTS
    from copy import deepcopy

    # Act
    config_0 = load_module_from_file_location(sanic.__file__, 'sanic/config.py')

    # Assert
    assert config_0.DEFAULTS == sanic.config.DEFAULTS

# Generated at 2022-06-26 04:14:46.783974
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location("some_file_that_does_not_exist")
    except LoadFileException as e:
        assert "Unable to load configuration file" in str(e)

# Generated at 2022-06-26 04:14:51.263669
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    configuration_file = Path('./tests/testdata/custom_config.py')
    config = load_module_from_file_location(configuration_file)
    assert config.TEST == 1

# Generated at 2022-06-26 04:14:56.971247
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("./config/config_test")
    assert module.foo == "Bar"
    assert module.spam == "Eggs"



# Generated at 2022-06-26 04:15:02.827006
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        a = load_module_from_file_location(
            "/have/no/idea/if/it/exists/at/all.py"
        )
        b = load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var}"
        )
    except LoadFileException:
        raise PyFileError

# Generated at 2022-06-26 04:15:05.366721
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location("/home/yangye/mypassport.py")

# Generated at 2022-06-26 04:15:12.955662
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    path_module = load_module_from_file_location('${HOME}', 'test3.py')
    path_1 = {'a', 'b', 'c'}
    path_2 = path_module.path
    assert path_1 == path_2
    print('Tests are passed')


if __name__ == '__main__':
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:15:22.328016
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str1 = "false"
    str2 = "enable"
    str3 = "disabled"

    assert load_module_from_file_location(str1) == False
    assert load_module_from_file_location(str2) == True
    assert load_module_from_file_location(str3) == False

    str4 = "g("
    bool4 = str_to_bool(str4)

    try:
        load_module_from_file_location(str4)
    except:
        assert True

# Generated at 2022-06-26 04:15:35.494735
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os.environ['STR_VAR'] = 'test'
    module_0 = load_module_from_file_location('./test.py')
    module_1 = load_module_from_file_location('./test_dir/test.py')
    module_2 = load_module_from_file_location('./test_dir/test_dir2/test.py')
    module_3 = load_module_from_file_location('/test_dir/test_dir2/test.py')
    module_4 = load_module_from_file_location('/test_dir/${STR_VAR}')
    module_5 = load_module_from_file_location('/test_dir/${STR_VAR}/test.py')
    module_6 = load_module_from_file_location

# Generated at 2022-06-26 04:15:46.471749
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    path_0 = './data/config_0.py'
    name_0 = 'config_0'
    module_0 = load_module_from_file_location(
        path_0,
        name_0
    )

    path_1 = './data/config_1.py'
    name_1 = 'config_1'
    module_1 = load_module_from_file_location(
        path_1,
        name_1,
        'utf_8'
    )

    path_2 = './data/config_2.py'
    name_2 = 'config_2'
    module_2 = load_module_from_file_location(
        path_2,
        name_2,
        'utf_8'
    )

