

# Generated at 2022-06-26 04:05:56.668290
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

import pathlib as module_1


# Generated at 2022-06-26 04:06:01.635983
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert callable(load_module_from_file_location)
    path_0 = module_0.Path()
    var_0 = load_module_from_file_location(path_0)


# Generated at 2022-06-26 04:06:12.220781
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pathlib as module_1
    path_1 = module_1.Path()
    var_1 = load_module_from_file_location(path_1)

    import os as module_2
    path_2 = module_2.environ['USER']
    var_2 = load_module_from_file_location(path_2)

    import pathlib as module_3
    path_3 = module_3.Path()
    var_3 = load_module_from_file_location(path_3, '/tmp')

    import os as module_4
    path_4 = module_4.environ['USER']
    var_4 = load_module_from_file_location(path_4, '/tmp')


# Generated at 2022-06-26 04:06:13.191179
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert False

# Generated at 2022-06-26 04:06:25.550814
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from importlib.util import module_from_spec, spec_from_file_location
    from pathlib import Path
    import types
    import os

    # Test for failing when location parameter is of a bytes type, but
    # encoding is not valid.
    with pytest.raises(UnicodeDecodeError):
        module = load_module_from_file_location(
            bytes("random_bytes", encoding="utf2"), encoding="utf2"
        )

    # Test for failing when location parameter is of a bytes type and
    # encoding is valid.
    module = load_module_from_file_location(
        bytes("random_bytes", encoding="utf8"), encoding="utf8"
    )
    assert isinstance(module, types.ModuleType)

    # Test for failing when location parameter is of a str type

# Generated at 2022-06-26 04:06:31.570251
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    path_0 = Path()
    path_1 = Path()
    path_2 = Path()
    var_0 = path_0
    var_1 = load_module_from_file_location()
    var_2 = load_module_from_file_location(var_0)
    var_3 = load_module_from_file_location(var_0, var_0)
    var_4 = load_module_from_file_location(var_0, var_0, var_0)
    var_5 = load_module_from_file_location(var_0, var_0, var_0, var_0)
    var_6 = load_module_from_file_location(var_0, var_0, var_0, var_0, var_0)
    var_

# Generated at 2022-06-26 04:06:42.930166
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Assumes Python 3
    if sys.version_info.major < 3:
        pytest.skip("Python 2 cannot run the tests")

    class Node:
        def __init__(self, name, value=None):
            self.name = name
            self.value = value


    class Document(Node):
        def __init__(self, filename):
            Node.__init__(self, filename)
            self.children = []

        def add_child(self, node):
            self.children.append(node)

    def load_file(name, recursive=True):
        path = os.path.join(ROOT_DIR, name)
        doc = Document(path)

        # if the "name" is a directory, we load all files and subdirectories
        # unless recursive is False

# Generated at 2022-06-26 04:06:45.726012
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert callable(load_module_from_file_location)


import os as module_0


# Generated at 2022-06-26 04:06:48.453116
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_0 = pathlib.Path()
    assert load_module_from_file_location(path_0).__name__ == 'config'

# Generated at 2022-06-26 04:07:00.129714
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location(): # noqa
    import pathlib as module_0

    def test_case_0(): # noqa
        path_0 = module_0.Path()
        var_0 = load_module_from_file_location(path_0)

    def test_case_1(): # noqa
        var_0 = load_module_from_file_location(None)

    def test_case_2(): # noqa
        path_0 = module_0.Path()
        var_0 = load_module_from_file_location(path_0, None)

    def test_case_3(): # noqa
        path_0 = module_0.Path()
        var_0 = load_module_from_file_location(path_0, None, None)

    def test_case_4(): # noqa
        path_0 = module_

# Generated at 2022-06-26 04:07:10.085851
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_file = "tests/config/test_file.py"
    test_module = load_module_from_file_location(test_file)

    assert test_module.config_key1 == "config_value1"
    assert test_module.config_key2 == "config_value2"



# Generated at 2022-06-26 04:07:11.447598
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '^\x0b][%.SvJsT?B'
    module = load_module_from_file_location(str_0)

# Generated at 2022-06-26 04:07:25.418349
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location_0 = load_module_from_file_location('QY\t?Wl\x7f')
    location_1 = load_module_from_file_location('W\t*\x05J0')
    location_2 = load_module_from_file_location('\x12\x0b\x10\x10\x05\x1f\x06\x0f\x02\x19')
    location_3 = load_module_from_file_location('\x14\x0b\x01\x0c\n\x1f\x07\x1d\x01\x0f\x03\x1e\x0f\x0b\x13')

# Generated at 2022-06-26 04:07:32.820210
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "test_file"
    module = load_module_from_file_location(location)
    assert module.__file__ == location
    assert module.a == 1
    assert module.variables.b == 2
    assert module.variables.c == 3
    assert module.some_obj.some_attr == "hi"



# Generated at 2022-06-26 04:07:46.191837
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Set up
    valid_path = "/some/path/some_module.py"
    valid_path2 = "some_module.py"
    invalid_path = "/bad/path/to/some_module.py"
    invalid_path2 = "path/to/some_module.py"
    invalid_path3 = "some_module.py"
    # the test
    with pytest.raises(LoadFileException):
        load_module_from_file_location(invalid_path)
    with pytest.raises(LoadFileException):
        load_module_from_file_location(invalid_path2)
    with pytest.raises(LoadFileException):
        load_module_from_file_location(invalid_path3)
    load_module_from_file_location(valid_path)

# Generated at 2022-06-26 04:07:51.312751
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = Path("test_file.py")
    load_module_from_file_location(location)

if __name__ == "__main__":

    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:07:54.004053
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "some_module_name"
    load_module_from_file_location(location)

# Generated at 2022-06-26 04:07:54.872024
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location("")

# Generated at 2022-06-26 04:08:08.302293
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Check if it can find and load module if full path to it is provided.
    path_to_config_file = Path(__file__).parent / "non_sanic_based_config.py"
    loaded_module = load_module_from_file_location(path_to_config_file)
    assert loaded_module.name == "some_config"
    assert loaded_module.number == 45
    assert loaded_module.string == "some string"

    # Check if it can find and load module if path to it is ${some_env_var}.
    os_environ["some_env_var"] = str(path_to_config_file.parent)

# Generated at 2022-06-26 04:08:12.556133
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_module = load_module_from_file_location("test_file.py")
    assert test_module.__spec__.name == "test_file"


# Generated at 2022-06-26 04:08:20.181596
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import tempfile

    # Create empty file for test
    tmp_file = tempfile.NamedTemporaryFile(mode="w", delete=False)
    tmp_file.write("test=True")
    tmp_file.close()

    # New path for test (temp dir + filename)
    path = sys.path[0] + "/" + tmp_file.name

    # Try load module, and check if it works
    module = load_module_from_file_location(path)
    assert module.test is True
    import os

    os.unlink(path)

# Generated at 2022-06-26 04:08:27.073359
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location("./sample_json_file.json")
    load_module_from_file_location("./sample_yaml_file.yaml")


if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:08:35.874685
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    config_path = './tests/_test_configs/config_hello.py'
    mod = load_module_from_file_location(config_path)
    assert hasattr(mod, 'hello')
    assert getattr(mod, 'hello') == 'world'


if __name__ == '__main__':
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:08:40.765123
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '^\x0b][%.SvJsT?B'
    str_1 = 'e"MhfDheS]'
    str_2 = 'b,8*q>4t=F|.z'
    module_0 = load_module_from_file_location(str_0, str_1, str_2)

test_case_0()
test_load_module_from_file_location()

# Generated at 2022-06-26 04:08:44.169062
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "config.py"
    module = load_module_from_file_location(location)
    assert module.__file__ == location


# Generated at 2022-06-26 04:08:53.626937
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_name = "regex.py"
    file_path = str_to_bool.__globals__["__file__"]
    if "/" in file_path:
        file_path = "/".join(file_path.split("/")[:-1]) + file_path.split("/")[-1]
    location = file_path + "/" + file_name
    module = load_module_from_file_location(location)
    assert hasattr(module, 'str_to_bool')
    bool_1 = modul.str_to_bool('^\x0b][%.SvJsT?B')

# Generated at 2022-06-26 04:08:57.388551
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location('test_file.py')
    except IOError:
        pass
    except Exception as e:
        raise e


# Generated at 2022-06-26 04:09:00.777592
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location_0 = '/home/sanic/.config/autostart/1334.py'
    module_0 = load_module_from_file_location(location_0)
    print(module_0)


test_case_0()
test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:02.564776
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = "./test/test_server/test_config_module.py"

    module = load_module_from_file_location(path)
    assert module.TEST_CONFIG_VARIABLE == True

# Generated at 2022-06-26 04:09:07.256486
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test for correct handling of non-existent file
    with pytest.raises(FileNotFoundError) as excinfo:
        load_module_from_file_location(r'/\*\?\"\:<>\|', "utf8")

    # Test for correct handling of non-existent path
    with pytest.raises(FileNotFoundError) as excinfo:
        load_module_from_file_location(r'\?', "utf8")

# Generated at 2022-06-26 04:09:21.964765
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import makedirs
    from tempfile import mkdtemp

    # We will use the temp dir for testing, so let's create it
    tmp_dir = mkdtemp(prefix='tmp_')
    dst_dir = Path(tmp_dir) / 'dst' / 'dir'

    # Test 1 - Test if it can load module from path
    module_name = 'some_module_name'
    file_path = str(dst_dir / f'{module_name}.py')

    # A) Create fake module in tmp dir
    makedirs(dst_dir, exist_ok=True)
    Path(file_path).touch()

    # B) Test
    res_module = load_module_from_file_location(file_path)
    assert 'some_module_name' == res_module.__name

# Generated at 2022-06-26 04:09:34.003216
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_0 = Path(__file__)
    path_parent = path_0.parent
    path = path_parent / 'config_test.py'
    import config_test
    module = load_module_from_file_location(path)
    assert module.value == config_test.value
    assert module.value_2 == config_test.value_2
    assert module.value_3 == config_test.value_3
    assert module.value_4 == config_test.value_4

    path_0 = '/home/marcinkukawka/Desktop/Python/PythonProjects/sanic/sanic/helpers.py'
    str_0 = str(path_0)
    module_0 = load_module_from_file_location(str_0)
    assert module_0.__file__ == path_

# Generated at 2022-06-26 04:09:39.738707
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    start_time_0 = time.time()
    mod_0 = load_module_from_file_location(
        '0.py',
        '/home/arpit/Desktop/cs699_project/sanic/sanic/'
    )
    assert(mod_0)
    end_time_0 = time.time()
    print('execution time for load_module_from_file_location = ', (end_time_0 - start_time_0)*1000, 'ms')

# Generated at 2022-06-26 04:09:47.005816
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '^\x0b][%.SvJsT?B'
    bool_0 = str_to_bool(str_0)
    str_1 = "f"
    bool_1 = str_to_bool(str_1)
    str_2 = "yep"
    bool_2 = str_to_bool(str_2)
    str_3 = "1"
    bool_3 = str_to_bool(str_3)
    str_4 = "0"
    bool_4 = str_to_bool(str_4)
    str_5 = "0"
    bool_5 = str_to_bool(str_5)
    str_6 = "yep"
    bool_6 = str_to_bool(str_6)
    str_7 = "on"
   

# Generated at 2022-06-26 04:09:50.063332
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with_file = load_module_from_file_location("async_logging/__init__.py")
    assert "__version__" in with_file.__dict__


# RUN
if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()
    print("Test ran successfully")

# Generated at 2022-06-26 04:09:55.600212
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
        The issue is in the function load_module_from_file_location and
        it is triggered when a file is not found.
    """
    str_1 = '^\x0b][%.SvJsT?B'
    try:
        load_module_from_file_location(str_1)
    except LoadFileException:
        pass

if __name__ == '__main__':
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:58.179285
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = '/some/path/some_module_name.py'
    module = load_module_from_file_location(path)

# Generated at 2022-06-26 04:10:01.255489
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = './settings.py'
    module = load_module_from_file_location(location)
    if module.__file__ != './settings.py':
        return False
    else:
        return True


# Generated at 2022-06-26 04:10:03.624111
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location('config.py')

# Generated at 2022-06-26 04:10:06.692725
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = './examples/tests/test_file_location.py'
    x = load_module_from_file_location(location)
    assert x.x == True
    assert x.y == 42
    assert x.z == 'test_file_location'
    assert x.__file__ == location

test_case_0()
test_load_module_from_file_location()

# Generated at 2022-06-26 04:10:13.997231
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import types
    from pathlib import Path
    from werkzeug.datastructures import ImmutableDict
    location: Union[str, Path] = Path(__file__).absolute()
    module = load_module_from_file_location(location)
    assert isinstance(module, types.ModuleType)
    # The module must be loaded in the current process.
    assert module in sys.modules.values()

# Generated at 2022-06-26 04:10:24.591318
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # We need to add a file test_module from which we will import the module
    # It is created at the folder level with the current file
    # with the required content
    f = open("../test_module.py", "w+")
    f.write("""a = 2\nb = "test"\nc = {"t": 1, 214: 0}""")
    f.close()

    # Now we load the module and import the variables
    # Using absolute path
    current_dir = os.path.dirname(os.path.abspath(__file__))
    test_module = load_module_from_file_location(current_dir + "/../test_module.py")

    assert test_module.a == 2
    assert test_module.b == "test"

# Generated at 2022-06-26 04:10:30.881797
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        "/home/makazu/MEGAsync/Private/master-degree/Project/sanic/examples/asset_folder.py")


# Generated at 2022-06-26 04:10:32.037088
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_string('/usr/')


# Generated at 2022-06-26 04:10:36.804655
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with tempfile.TemporaryDirectory() as temp_directory:
        f = open(os.path.join(temp_directory, "test.py"), "w")
        f.write("a = 42")
        f.close()
        module = load_module_from_file_location(os.path.join(temp_directory, "test.py"))
        assert module.a == 42

# Stress tests for function load_module_from_file_location

# Generated at 2022-06-26 04:10:40.678357
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = "/home/ubuntu/.local/lib/python3.6/site-packages/sanic/config.py"
    load_module_from_file_location(str_0)

# Generated at 2022-06-26 04:10:46.496268
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "tasks.py"
    str_encoding = "utf8"
    args = [1, 2]
    kwargs = {"kwarg1": "val1", "kwarg2": "val2"}

    module = load_module_from_file_location(location, str_encoding, *args, **kwargs)
    assert module.__name__ == "tasks"
    # assert module.arg1 == args[0]
    # assert module.kwarg1 == kwargs['kwarg1']



# Generated at 2022-06-26 04:10:52.523911
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location_0 = '^\x0b][%.SvJsT?B'
    encoding_0 = 'b'
    module_0 = load_module_from_file_location(location_0, encoding_0)
    assert module_0 is None



# Generated at 2022-06-26 04:10:56.309670
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = os.path.dirname(__file__) + '\\test_script'
    module = load_module_from_file_location(location)

    assert module.__name__ == 'test_script'


if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:11:07.557665
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_path = './config.txt'
    module = load_module_from_file_location(file_path)


if __name__ == '__main__':
    # Unit test for function load_module_from_file_location
    test_load_module_from_file_location()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # Unit test for function str_to_bool

# Generated at 2022-06-26 04:11:15.851418
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("sanic_cors")
    print(module)

if __name__ == '__main__':
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:11:25.736527
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 0:
    file_name_0 = 'config0.py'
    try:
        config0 = load_module_from_file_location(file_name_0)
    except Exception as error:
        print("Failed with exception: {}".format(error))

    print("Succeed to load {} as a module".format(file_name_0))

if __name__ == '__main__':
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:11:30.723306
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Try to load config.py file in current directory.
    module = load_module_from_file_location("config.py")

    # This line should not pass the test.
    # module = load_module_from_file_location("/some/missing/config.py")
    # This line should not pass the test as well.
    # module = load_module_from_file_location("user.json")
    # You can safely comment it out for this test won't be executed.
    # module = load_module_from_file_location("user.json", "utf8")

# Generated at 2022-06-26 04:11:36.976254
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "./config.py"
    config = load_module_from_file_location(location)
    print(config)

if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:11:38.006186
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass



# Generated at 2022-06-26 04:11:41.557733
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    result = load_module_from_file_location("config/test.py")
    assert result.__file__ == "config/test.py"

# Generated at 2022-06-26 04:11:43.093721
# Unit test for function load_module_from_file_location

# Generated at 2022-06-26 04:11:52.749697
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # create a test config file for testing the function
    with open('test_load_module_from_file_location.py', 'w') as f:
        f.write('# Created for testing the function load_module_from_file_location\n')
        f.write('# Add any config params as needed.\n')
        f.write('foo = "bar"\n')
        f.write('bar = "baz"\n')
        f.write('baz = "foo"\n')
    mod = load_module_from_file_location('test_load_module_from_file_location.py')
    assert mod.foo == "bar"
    assert mod.bar == "baz"
    assert mod.baz == "foo"

# Generated at 2022-06-26 04:11:58.208194
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # getcwd() is used to get current working directory
    # and is used to get the current path in which the file from which
    # the test case is running.
    path_to_file = os.getcwd() + "/application.py"
    module = load_module_from_file_location(path_to_file)
    assert isinstance(module, types.ModuleType)
    assert module.__name__ == "application"


test_case_order = [test_case_0, test_load_module_from_file_location]

# Generated at 2022-06-26 04:12:04.681779
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    os.environ['test_load_module_from_file_location'] = 'test_load_module_from_file_location'
    module = load_module_from_file_location(
        '$test_load_module_from_file_location'
    )
    assert module == 'test_load_module_from_file_location'

# Generated at 2022-06-26 04:12:09.401879
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

# Generated at 2022-06-26 04:12:18.504261
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_var = "test_value"
    test_var2 = "test_value2"
    test_conf_string = f"CONF1 = '{test_var}'\nCONF2 = CONF1\nCONF3 = '{test_var2}'"
    module = load_module_from_file_location(
        "test_config_file_location1", test_conf_string
    )
    assert module.CONF1 == test_var
    assert module.CONF2 == test_var
    assert module.CONF3 == test_var2
    module = load_module_from_file_location(
        "/test_config_file_location2", test_conf_string
    )
    assert module.CONF1 == test_var
    assert module.CONF2 == test_var

# Generated at 2022-06-26 04:12:29.410889
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    some_module = load_module_from_file_location("some_module_name", "./some_module.py")
    # type checks
    assert isinstance(some_module, types.ModuleType)


if __name__ == "__main__":
    # run all the tests
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:12:32.823025
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    f = load_module_from_file_location('sanic/tests/__init__.py')

# Generated at 2022-06-26 04:12:36.673818
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = './test_location'
    module = load_module_from_file_location(location)
    assert module.__name__ == 'test_location'

# Generated at 2022-06-26 04:12:43.850118
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    print("Testing load_module_from_file_location")
    str_0 = "config.py"
    module_0 = load_module_from_file_location(str_0)
    print("\t- Test OK!")
    print("\t- Config file loaded: " + str(module_0))

print("Running test for load_module_from_file_location")
test_load_module_from_file_location()

print("Running test for str_to_bool")
test_case_0()

# Generated at 2022-06-26 04:12:46.791044
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    loc_0 = '^\x0b][%.SvJsT?B'
    module = load_module_from_file_location(loc_0, loc_0, loc_0, loc_0)


# Generated at 2022-06-26 04:12:48.987402
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    fp = __file__
    module = load_module_from_file_location(fp, __name__)
    expected_module = __import__(__name__)
    assert module == expected_module

# Generated at 2022-06-26 04:12:57.779688
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_1 = load_module_from_file_location('./utils.py')
#    print(type(module_1))
    module_2 = load_module_from_file_location('utils')
#    print(type(module_2))
#    print(module_1)
#    print(module_2)


# Generated at 2022-06-26 04:13:01.694816
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location('test.py')
    assert module.foo == 1
    assert module.bar == 'hello'


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 04:13:13.106043
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    name = 'sanic_envconfig'
    location = 'sanic_envconfig/__init__.py'
    args = (False,)
    kwargs = {'has_location': True}
    module = load_module_from_file_location(location, *args, **kwargs)
    assert hasattr(module, '__file__')
    assert hasattr(module, '__spec__')
    assert name == module.__spec__.name


# Generated at 2022-06-26 04:13:17.845156
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    config_file = "tests/data/config/config.py"
    assert load_module_from_file_location(config_file).value == "sanic"

# Generated at 2022-06-26 04:13:22.190975
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("os") is os


if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:13:33.183618
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("tests/test_load_file.py")
    path = Path("tests/test_load_file.py")
    assert load_module_from_file_location(path)
    with pytest.raises(IOError):
        assert load_module_from_file_location("tests/test_load_file_no_exist.py")


if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:13:45.006442
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("test_data/test_0.py").test_0 == "test_0_0"
    assert (
        load_module_from_file_location("test_data/test_0.py").test_0_var.test_0_var
        == "test_0_var_0"
    )
    assert (
        load_module_from_file_location("test_data/test_0.py").test_0_0.test_0_0_var
        == "test_0_0_var_0"
    )



# Generated at 2022-06-26 04:13:58.072272
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_1 = '.py'
    str_2 = 'Path'
    str_3 = '/'
    str_4 = '$'
    str_5 = '${some_env_var}'
    str_6 = '${some_env_var'
    str_7 = 'some_env_var}'
    str_8 = 'some_module_name'
    str_9 = '${some_env_var}'
    str_10 = 'utils'
    str_11 = '${some_env_var}'

    load_module_from_file_location(str_1)
    load_module_from_file_location(str_2)
    load_module_from_file_location(str_3)
    load_module_from_file_location(str_4)
    load_module_

# Generated at 2022-06-26 04:14:02.563971
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("config")

    assert load_module_from_file_location("not_existing_module") == None

# Generated at 2022-06-26 04:14:05.479414
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location("sanic.config.None")


# Generated at 2022-06-26 04:14:07.984265
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Case 1. Example 1.
    cfg_1 = load_module_from_file_location(
        "tests/config.py"
    )


# Generated at 2022-06-26 04:14:21.348858
# Unit test for function load_module_from_file_location

# Generated at 2022-06-26 04:14:28.733935
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    with pytest.raises(ImportError):
        load_module_from_file_location("/home/c")


# Generated at 2022-06-26 04:14:31.114560
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    loc = 'test_cases/test_load_module_from_file_location.py'
    module = load_module_from_file_location(loc)
    module.test_func()


# Generated at 2022-06-26 04:14:39.673152
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = '/Users/markus/Documents/Projekte/Python/sanic/test_1.py'
    module = load_module_from_file_location(location)

    for key in module.__dict__.keys():
        if key not in ('__builtins__', '__cached__', '__doc__', '__file__',
                       '__name__', '__package__'):
            print('{} : {}'.format(key, module.__dict__[key]))

if __name__ == '__main__':
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:14:42.211389
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = '/pypy3.6-v7.3.3-linux64/bin/python3'
    load_module_from_file_location(location)


# Generated at 2022-06-26 04:14:46.149547
# Unit test for function load_module_from_file_location

# Generated at 2022-06-26 04:14:50.872002
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_module = load_module_from_file_location(
        './utils/load_file.py', encoding='utf-8'
    )
    test_module.str_to_bool(str_0)

# Generated at 2022-06-26 04:14:52.732965
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

# Generated at 2022-06-26 04:15:02.826340
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test for case 1
    try:
        module_1 = load_module_from_file_location('module_1.py')
        assert module_1.__name__ == 'module_1'
    except (IOError, LoadFileException, AttributeError):
        assert False

    # Test for case 2
    try:
        module_2 = load_module_from_file_location('./module_2.py')
        assert module_2.__name__ == 'module_2'
    except (IOError, LoadFileException, AttributeError):
        assert False


# Generated at 2022-06-26 04:15:14.365886
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Tests passed
    ## test case 0
    test_case_0()
    ## test case 1
    str_1 = '^6U9s8Y.h0\x1a/0QV'
    str_2 = '\x0bM00\x17\x16,3\x1a?\x1a'
    location, encoding = str_1, str_2
    args, kwargs = (), {}
    load_module_from_file_location(location, encoding, *args, **kwargs)
    ## test case 2
    str_3 = '=\x18\x1e6\x0b\x1d\x03\x04\x08\x01Y\x1f\x07\x1cK\x1a\x04\x1d\x0e'


# Generated at 2022-06-26 04:15:21.602369
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import re

    string = "some_module_name"
    location = "/some/path/${some_env_var}"
    location_pattern = re.compile(r"[/some/path/.+]")
    location = load_module_from_file_location(location, string)
    assert location_pattern.fullmatch(location)

# Generated at 2022-06-26 04:15:36.076135
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = Path("/common/test_config_files/test_config_0.py")
    module = load_module_from_file_location(location)

test_case_0()
test_load_module_from_file_location()


# Generated at 2022-06-26 04:15:39.069448
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "./test.py"
    module = load_module_from_file_location(location)



# Generated at 2022-06-26 04:15:43.400246
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = 'test_data/test_config.py'
    module = load_module_from_file_location(location)
    assert module.__file__ == location
    assert module.CONFIGVAR == 'configvalue'

# Generated at 2022-06-26 04:15:51.969715
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    os.environ['TEST_VAR'] = './tests'
    path = './tests/test_config.py'
    mod = load_module_from_file_location(path)
    assert mod.TEST_STR == 'It works!'


if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()