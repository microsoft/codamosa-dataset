

# Generated at 2022-06-26 04:05:41.432597
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Utility function to load module from file location"""

    # Test 1: Load configuration module with location as pathlib.Path
    config_path = Path("../app.py")
    assert isinstance(
        load_module_from_file_location(config_path), types.ModuleType
    )

    # Test 2: Load configuration module with location as string
    config_path = "../app.py"
    assert isinstance(
        load_module_from_file_location(config_path), types.ModuleType
    )

    # Test 3: Should raise ValueError
    config_path = "~/app.py"

# Generated at 2022-06-26 04:05:52.522231
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('0') == False
    assert str_to_bool('1') == True
    assert str_to_bool('true') == True
    assert str_to_bool('True') == True
    assert str_to_bool('TRUE') == True
    assert str_to_bool('truE') == True
    assert str_to_bool('TruE') == True
    assert str_to_bool('f') == False
    assert str_to_bool('f') == False
    assert str_to_bool('F') == False
    assert str_to_bool('F') == False
    assert str_to_bool('F') == False
    assert str_to_bool('F') == False
    assert str_to_bool('F') == False
    assert str_to_bool('fAlSe')

# Generated at 2022-06-26 04:06:06.867791
# Unit test for function str_to_bool
def test_str_to_bool():
    str_1 = "yes"
    str_2 = "y"
    str_3 = "Y"
    str_4 = "Yep"
    str_5 = "no"
    str_6 = "N"
    str_7 = "off"
    str_8 = "t"
    str_9 = "true"
    # str_10 = "j`&~'&_R"

    if str_to_bool(str_1) != True:
        raise ValueError("test_1 failed")
    elif str_to_bool(str_2) != True:
        raise ValueError("test_2 failed")
    elif str_to_bool(str_3) != True:
        raise ValueError("test_3 failed")

# Generated at 2022-06-26 04:06:13.672055
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        mod_0 = load_module_from_file_location("")
        mod_1 = load_module_from_file_location(b"")
        mod_2 = load_module_from_file_location(Path(""))
        mod_3 = load_module_from_file_location(b"", encoding="utf8")
        mod_4 = load_module_from_file_location(Path(""), encoding="utf8")
    except Exception:
        pass


# Generated at 2022-06-26 04:06:17.975433
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    location = NamedTemporaryFile(suffix=".py")
    with location as f:
        f.seek(0)
        f.write(b"a = 1")
        f.flush()
        load_module_from_file_location(f.name)

# Generated at 2022-06-26 04:06:27.112206
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('y') == True, "str_to_bool('y') == True"
    assert str_to_bool('yes') == True, "str_to_bool('yes') == True"
    assert str_to_bool('yes') == True, "str_to_bool('yes') == True"
    assert str_to_bool('yep') == True, "str_to_bool('yep') == True"
    assert str_to_bool('yup') == True, "str_to_bool('yup') == True"
    assert str_to_bool('t') == True, "str_to_bool('t') == True"
    assert str_to_bool('true') == True, "str_to_bool('true') == True"

# Generated at 2022-06-26 04:06:29.929508
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    name = "config"
    location = "tests/integration/config.py"
    config = load_module_from_file_location(location)

    assert name in config.__name__

# Generated at 2022-06-26 04:06:39.621823
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_0 = load_module_from_file_location(
        'sanic.log.LOGGING_CONFIG_DEFAULTS'
    )  # Retrieve default sanic logger settings
    print(f"module_0.__name__ = {module_0.__name__}")
    print(f"module_0.LOGGING = {module_0.LOGGING}")

if __name__ == '__main__':
    #test_load_module_from_file_location()

    #test_case_0()
    pass

# Generated at 2022-06-26 04:06:49.971015
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # case_0: Some file name.
    some_file_0 = "project/test_helpers.py"  # It doesn't matter if it exists.
    module_0 = load_module_from_file_location(some_file_0)
    assert module_0.__name__ == "project.test_helpers"

    # case_1: Some file name with the extension.
    some_file_1 = "project/test_helpers"  # It doesn't matter if it exists.
    module_1 = load_module_from_file_location(some_file_1)
    assert module_1.__name__ == "project.test_helpers"

    # case_2: Some file name relative to the project root.
    some_file_2 = "project/test_helpers"  # It doesn't matter if

# Generated at 2022-06-26 04:06:59.611338
# Unit test for function str_to_bool
def test_str_to_bool():
    str_0 = "enable"
    str_1 = "enable"
    str_2 = "enable"
    str_3 = "enable"

    str_0_1 = "enable"
    str_0_2 = "enable"

    if str_0:
        if str_1:
            if str_2:
                if str_3:
                    if str_0_1:
                        if str_0_2:
                            return True
                    else:
                        return False
                else:
                    return False
            else:
                return False
        else:
            return False
    else:
        return False



# Generated at 2022-06-26 04:07:11.243927
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location1 = Path(__file__).parent / 'test_module.py'
    mod1 = load_module_from_file_location(location1)
    assert mod1.some_num == 42
    assert mod1.some_str == 'some string'
    assert mod1.some_list == [1, 2, 3]
    assert mod1.some_dict == {'some': 'dictionary'}

# Generated at 2022-06-26 04:07:24.552493
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_0 = load_module_from_file_location("sanic")
    module_1 = load_module_from_file_location(
        b"sanic", encoding="utf8"
    )
    # Test passing bytes object
    module_2 = load_module_from_file_location(
        bytes("sanic", encoding="utf8"), encoding="utf8"
    )
    # Test passing Path object
    module_3 = load_module_from_file_location(
        Path.home() / "sanic" / "sanic" / "__init__.py", encoding="utf8"
    )
    # Test passing path string
    module_4 = load_module_from_file_location(
        "/home/sanic/sanic/__init__.py", encoding="utf8"
    )
    # Test

# Generated at 2022-06-26 04:07:36.670462
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # test for successful module load
    module_name = "module_name_that_should_not_exist"
    module_path = "module_that_should_not_exist.py"
    module = load_module_from_file_location(module_name, module_path)
    assert module.__name__ == module_name

    # test for passing module path as Path object
    module = load_module_from_file_location(
        "another_module_name_that_should_not_exist",
        Path(module_path),
    )
    assert (
        module.__name__ == "another_module_name_that_should_not_exist"
    )

    # test for exception when module is not a file path
    with pytest.raises(IOError) as e_info:
        module = load_module

# Generated at 2022-06-26 04:07:46.175486
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_loc = "sanic.config_reader"
    module_mod = load_module_from_file_location(file_loc)
    assert hasattr(module_mod, "ConfigReader")

    file_loc = "sanic/config_reader.py"
    module_mod = load_module_from_file_location(file_loc)
    assert hasattr(module_mod, "ConfigReader")

    file_loc = Path("sanic") / "config_reader.py"
    module_mod = load_module_from_file_location(file_loc)
    assert hasattr(module_mod, "ConfigReader")



# Generated at 2022-06-26 04:07:48.803636
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "config0.py"
    module = load_module_from_file_location(location)

    assert module.config_var0 == "some_value"
    assert module.config_var1 == "some_value"
    assert module.config_var2 == "some_value"



# Generated at 2022-06-26 04:07:58.638121
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 0
    with pytest.raises(LoadFileException) as error:
        load_module_from_file_location("/tmp/does_not_exist.py")
    # Test case 1
    with pytest.raises(LoadFileException) as error:
        load_module_from_file_location("/tmp/${SOME_ENV_VAR_THAT_IS_NOT_SET}.py")
    # Test case 2
    with pytest.raises(LoadFileException) as error:
        load_module_from_file_location(b"/tmp/does_not_exist.py")
    # Test case 3

# Generated at 2022-06-26 04:08:07.360378
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # import os, tempfile
    # _, path = tempfile.mkstemp()
    # with open(path, "w") as f:
    #     f.write("a = 1")
    # mod = load_module_from_file_location(path)
    # os.remove(path)
    # assert mod.a == 1

    pass


if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:08:18.274761
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check simple case
    module = load_module_from_file_location("os.path")
    assert module.__name__ == "os.path"

    module = load_module_from_file_location(Path("os.path"))
    assert module.__name__ == "os.path"

    # B) Check path of the file case
    import sysconfig
    path_to_sysconfig = sysconfig.__file__
    module = load_module_from_file_location(path_to_sysconfig)
    assert module.__name__ == "sysconfig._sysconfigdata_m_linux_armv7l"

    # C) Check that environment variable substitution works
    #    with os.path.
    os_environ["SOME_VAR"] = "os.path"
    module = load_module_from

# Generated at 2022-06-26 04:08:30.328925
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Import some_module.py file with file name
    some_module = load_module_from_file_location(
        "some_module_name", "./some_module.py"
    )
    assert some_module.some_module_variable == "some_module_value"

    # Import some_module.py file with file path
    some_module = load_module_from_file_location(
        "./some_module.py", "some_module_name"
    )
    assert some_module.some_module_variable == "some_module_value"

    # Import some_module.py file with file path and environment variable
    os_environ["some_env_var"] = "./"

# Generated at 2022-06-26 04:08:38.889805
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import io
    # original stdout
    stdout = sys.stdout
    # set stdout to a buffer
    sys.stdout = io.StringIO()
    try:
        # do sth that prints to stdout
        try:
            f = load_module_from_file_location("", "", "")
        except IOError:
            pass
    finally:
        # reset stdout to the original
        sys.stdout = stdout

# Generated at 2022-06-26 04:08:53.980090
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Loads a module from a location.
    """
    conf_file = "test_conf.py"
    with open(conf_file, "w+") as file:
        file.write("DEFAULT = 1")

    module = load_module_from_file_location("./test_conf.py")
    assert module.DEFAULT == 1

    # TODO:  fix this test
    # os.environ["BLAH"] = "./test_conf.py"
    # module = load_module_from_file_location("${BLAH}")
    # print(f"module: {module}")
    # assert module.DEFAULT == 1
    #
    # os.environ["BLAH"] = "./test_conf.py"
    # module = load_module_from_file_location("${BL

# Generated at 2022-06-26 04:09:06.042392
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check location as Path object.
    #    NOTE: Path object must be string!
    #          Path('string') will be interpreted as path
    #          and will result in errors.
    #          SO Path('str') is incorrect usage!
    path_0 = Path("hello_world.txt")
    path_1 = Path("hello_world.py")
    #path_2 = Path('hello_world') # reason why Path() can't be used
    path_3 = Path("hello_world").absolute()
    path_4 = Path("hello_world").absolute().resolve()
    path_5 = "/path/to/file/hello_world.py"
    path_6 = "/path/to/file/${HOME}/some_file.py"

# Generated at 2022-06-26 04:09:14.996263
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    For some reason I needed to provide a different encoding in
    test_load_module_from_file_location()
    """
    location = (
        "tests/config_files/test_config_module_utf8.py"
    )
    encoding = "utf8"
    module = load_module_from_file_location(location, encoding)
    assert "test_string" in dir(module)
    assert module.test_string == "test_string"

    location = (
        "tests/config_files/test_config_module_cp1251.py"
    )
    encoding = "cp1251"
    module = load_module_from_file_location(location, encoding)
    assert "test_string" in dir(module)

# Generated at 2022-06-26 04:09:25.596837
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from configparser import ConfigParser

    # Test if function can resolve environment variables.
    os_environ["SANIC_CONFIG_MODULE"] = "testing_config"
    os_environ["SANIC_CONFIG_FILE"] = "sanic/configuration/testing_config.py"

    # Test if function can load file.
    module = load_module_from_file_location(
        "${SANIC_CONFIG_MODULE}", "${SANIC_CONFIG_FILE}"
    )

    config_parser = ConfigParser()

    # Test if function can load file and return module with config.
    assert hasattr(module, "config")
    assert isinstance(module.config, dict)

    # Test if function can load file and load module with configparser.
    config_parser.read_dict(module.config)
   

# Generated at 2022-06-26 04:09:34.958349
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        "sanic.config",
        "/home/nicholas/Desktop/Sanic/sanic/config.py",
        origin="sanic/config.py",
    )
    assert module is not None
    module = load_module_from_file_location(
        "/home/nicholas/Desktop/Sanic/sanic/config.py"
    )
    assert module is not None
    module = load_module_from_file_location(
        Path("/home/nicholas/Desktop/Sanic/sanic/config.py")
    )
    assert module is not None

# Generated at 2022-06-26 04:09:40.730119
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    filepath = "./config/config_file_sample.py"
    config_module = load_module_from_file_location(filepath)
    assert str(config_module.TEST) == "test"
    assert config_module.TEST_NUMBER == 1

# Generated at 2022-06-26 04:09:47.771814
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_0 = load_module_from_file_location("sanic", os.getcwd())
    module_1 = load_module_from_file_location("sanic", cwd)
    module_2 = load_module_from_file_location("${HOME}/Downloads/sanic")

# Generated at 2022-06-26 04:10:03.559315
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Check Pathlib Path object
    config = load_module_from_file_location(Path(__file__))
    assert config.__name__ == "test_utils"
    assert config.__doc__

    # Check string object
    config = load_module_from_file_location(__file__)
    assert config.__name__ == "test_utils"
    assert config.__doc__

    # Check bytes object
    config = load_module_from_file_location(__file__.encode())
    assert config.__name__ == "test_utils"
    assert config.__doc__

    # Check bytes object with encoding
    config = load_module_from_file_location(__file__.encode(), "utf8")
    assert config.__name__ == "test_utils"
    assert config.__doc__

# Generated at 2022-06-26 04:10:11.398194
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    print("Unit test for function load_module_from_file_location:")
    file_location = "./test_load_module_from_file_location"
    module = load_module_from_file_location(file_location)
    assert module.name == "test_load_module_from_file_location"
    print("Passed")


# Function unit test runner

# Generated at 2022-06-26 04:10:14.755698
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Load the config file
    config_module = load_module_from_file_location("sanic_mongo_tests/config.py")
    assert config_module.MONGO_DATABASE_NAME == "sanic_mongo_tests"

# Generated at 2022-06-26 04:10:26.129758
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Load module from the file.
    a = load_module_from_file_location("./tests/data/module_0.py")
    assert a.string_0 == "module_0"

    # B) Load module from the directory.
    a = load_module_from_file_location("./tests/data")
    assert a.string_0 == "module_0"

    # C) Load module from the .py file, but pass file path as a bytes.
    a = load_module_from_file_location(
        b"./tests/data/module_0.py", encoding="utf8"
    )
    assert a.string_0 == "module_0"

    # D) Load module from the non-.py file, but pass file path as a bytes.
    a = load_module_from_

# Generated at 2022-06-26 04:10:34.862605
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 0
    test_mod_0_path = Path(__file__).parent / "resources" / "some_module"
    mod_0 = load_module_from_file_location(test_mod_0_path)
    mod_0_result = mod_0.some_func()
    mod_0_expected = "This is some module"
    assert mod_0_result == mod_0_expected, f'Got "{mod_0_result}"'

if __name__ == "__main__":
    # test_load_module_from_file_location()
    test_case_0()

# Generated at 2022-06-26 04:10:44.363809
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 0:
    str_0 = "tests/test_helpers/load_config_test.py"

    mod_0 = load_module_from_file_location(str_0)

    assert hasattr(mod_0, "CONFIG_VAR_1")
    assert mod_0.CONFIG_VAR_1 == "CONFIG_VAR_1_VALUE"
    assert hasattr(mod_0, "CONFIG_VAR_2")
    assert mod_0.CONFIG_VAR_2 == "CONFIG_VAR_2_VALUE"

# Generated at 2022-06-26 04:10:56.397598
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from os import environ as os_environ

    def create_test_module_file(
        test_module_file_path: str,
        test_module_body: str,
        module_name: str = "test_module",
    ) -> None:
        with open(test_module_file_path, "w") as test_module_file:
            test_module_file.write(test_module_body)

    def test_module_body_line_1(test_module_var: str):
        return f"{test_module_var} = 100"


# Generated at 2022-06-26 04:11:02.534859
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    some_path = "../example_config.py"
    expected_out = "test"
    module_0 = load_module_from_file_location(some_path)
    assert module_0.config_val == expected_out


# Generated at 2022-06-26 04:11:09.146976
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test the first type of input: Module name.
    module_0 = load_module_from_file_location("os")
    # Test the second type of input: Import string.
    module_1 = load_module_from_file_location("os.path")
    # Test the third type of input: Environment variable
    os_environ["TEST_MODULE"] = "os"
    module_2 = load_module_from_file_location("${TEST_MODULE}")
    # Test the fifth type of input: Existing file with .py extension.
    file_path = os_path.abspath(os_path.join(__file__, os_pardir, "__init__.py"))
    module_4 = load_module_from_file_location(file_path)
    # Test the sixth type of input

# Generated at 2022-06-26 04:11:14.922312
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_file_location = (
        "/home/user/some_directory/some_file_name.py"
    )
    module = load_module_from_file_location(
        module_file_location, "utf8"
    )


# Generated at 2022-06-26 04:11:21.121433
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_path = "tests/test_load_module_from_file_location.py"
    # Code taken from https://docs.python.org/3/library/unittest.html
    # and modified to fit with this function test.
    import unittest
    import tempfile

    class TestLoadModuleFromFileLocation(unittest.TestCase):
        """Test class for function load_module_from_file_location()."""
        # A) Check if location contains any environment variables
        #    in format ${some_env_var}.
        # B) Check these variables exists in environment.
        # C) Substitute them in location.

# Generated at 2022-06-26 04:11:27.657143
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ['SANIC_CONFIG'] = 'something'
    load_module_from_file_location('/config.json', '/config.py', '/test_module.py')

if __name__ == "__main__":
    print(test_case_0.__name__)
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:11:29.736539
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("importlib", "")

# Generated at 2022-06-26 04:11:42.447798
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test passing Path
    path_0 = Path("/home/sanic/my_config.py")
    module_0 = load_module_from_file_location(path_0)
    assert module_0.__dict__ == {}
    assert module_0.__name__ == "my_config"
    assert module_0.__file__ == "/home/sanic/my_config.py"

    # Test passing str
    str_0 = "/home/sanic/my_config.py"
    module_0 = load_module_from_file_location(str_0)
    assert module_0.__dict__ == {}
    assert module_0.__name__ == "my_config"
    assert module_0.__file__ == "/home/sanic/my_config.py"

    # Test passing bytes
   

# Generated at 2022-06-26 04:11:52.991460
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 0:
    # Import something which is not a path and not a module.
    # Result:
    # Raises ValueError as it should.
    try:
        load_module_from_file_location("galeb")

    except ValueError:
        pass

    # Test 1:
    # Import a module which does not exists.
    # Result:
    # Raises ModuleNotFoundError as it should.
    try:
        load_module_from_file_location("sanic.views.1")

    except ModuleNotFoundError:
        pass

    # Test 2:
    # Import a path which does not exists.
    # Result:
    # Raises FileNotFoundError as it should.

# Generated at 2022-06-26 04:11:53.631952
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert False

# Generated at 2022-06-26 04:12:01.799655
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "test_config.py"
    module = load_module_from_file_location(location)
    assert hasattr(module, "name") and hasattr(module, "test_value")

    location = (Path(__file__).parent.parent / "test_config.py").resolve()
    module = load_module_from_file_location(location)
    assert hasattr(module, "name") and hasattr(module, "test_value")



# Generated at 2022-06-26 04:12:06.736828
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_module = load_module_from_file_location("./tests/test_config.py")
    assert test_module.MY_CONSTANT == "some_value"


if __name__ == "__main__":
    print("Test case 0:")
    test_case_0()
    print("Test load_module_from_file_location:")
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:12:16.450987
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Create temporary file and write there some text.
    fd, temp_file_path = tempfile.mkstemp()
    with open(temp_file_path, "w") as f:
        f.write("test_var = True")

    # B) Load this file as module.
    mod = load_module_from_file_location(
        temp_file_path
    )

    # C) Remove the temporary file.
    os.close(fd)
    os.remove(temp_file_path)

    assert mod.test_var

# Generated at 2022-06-26 04:12:25.780265
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # raise Exception('test')
    test_module = load_module_from_file_location(
        './tests/test_file.py'
    )
    assert test_module.test_var == 1
    assert test_module.test_var_2 == 'some_value'

# Generated at 2022-06-26 04:12:34.589176
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    This is a unit test for function load_module_from_file_location
    """
    test_str = "__init__.py"
    error_str = "./__ini.py"
    module = load_module_from_file_location(test_str)
    flag = isinstance(module, types.ModuleType)
    assert flag == True
    # test exception: LoadFileException
    try:
        module = load_module_from_file_location(error_str)
    except LoadFileException:
        flag = True
    assert flag == True
    # test exception: PyFileError
    try:
        module = load_module_from_file_location(test_str)
    except PyFileError:
        flag = True
    assert flag == True
    flag = False

# Generated at 2022-06-26 04:12:37.738170
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = "j`&~'&_R"
    location = load_module_from_file_location(str_0)

# Generated at 2022-06-26 04:12:41.020352
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location(
        "sanic_plugins.plugin",
        "sanic_plugins/plugin.py",
        False,
        False,
    )



# Generated at 2022-06-26 04:12:45.789963
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location("utils.py", "./")

# Generated at 2022-06-26 04:12:55.126883
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    class Tester:
        pass

    mod = load_module_from_file_location("tests.test_utils")
    assert mod == test_load_module_from_file_location.__module__

    mod = load_module_from_file_location("tests.test_utils.Tester")
    assert mod == Tester

    mod = load_module_from_file_location("tests.test_utils.Tester.mro")
    assert mod == Tester.mro

    mod = load_module_from_file_location("tests.test_utils.Tester.foo_bar")
    assert mod == Tester.__dict__["foo_bar"]

    mod = load_module_from_file_location(
        "/tmp/${PWD}/tests/test_utils.Tester.foo_bar"
    )
   

# Generated at 2022-06-26 04:13:04.751505
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test for a file path.
    assert load_module_from_file_location("some_module_name", __file__)

    # Test for environment variable in file path.
    with os_environ.copy() as orig_env:
        # B) Check these variables exists in environment.
        os_environ["dataset"] = "images/"
        # A) Check if location contains any environment variables
        #    in format ${some_env_var}.
        assert load_module_from_file_location(
            "some_module_name", "${dataset}"
        )

    # Test for invalid encoding.

# Generated at 2022-06-26 04:13:13.952035
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert import_string("asyncio") == load_module_from_file_location(
        "asyncio"
    )
    assert asyncio == load_module_from_file_location("asyncio")

    assert import_string("asyncio.streams") == load_module_from_file_location(
        "asyncio.streams"
    )
    assert asyncio.streams == load_module_from_file_location(
        "asyncio.streams"
    )

    path = "sanic/log/__init__.py"
    assert import_string("sanic.log") == load_module_from_file_location(path)
    assert sanic.log == load_module_from_file_location(path)


# Generated at 2022-06-26 04:13:25.547306
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    importlib.reload(types)
    importlib.reload(import_string)
    importlib.reload(module_from_spec)
    importlib.reload(spec_from_file_location)
    importlib.reload(Path)
    importlib.reload(re)
    importlib.reload(os)

    # Test that raises LoadFileException on not set env var
    try:
        load_module_from_file_location("/some/path/${NOT_SET_ENV_VAR}")
    except LoadFileException as e:
        if "NOT_SET_ENV_VAR" in str(e):
            print("Test 'str_to_bool' passed")
        else:
            print("Test 'str_to_bool' failed")

# Generated at 2022-06-26 04:13:36.914044
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import random

    seed_value = 12345
    random.seed(seed_value)
    file_name = f"file_name_{random.randint(0, 1000)}_"
    module_name = str(file_name).replace(".", "_")
    module_location = f"/tmp/{file_name}"

    module_content = f"some_variable = {random.randint(0, 1000)}"

    with open(module_location, "w") as f:
        f.write(module_content)

    module = load_module_from_file_location(module_location)
    assert module_name == module.__name__
    assert module_location == module.__file__
    assert locals()["module_content"] == module.__dict__["some_variable"]

# Generated at 2022-06-26 04:13:47.597886
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # check load_module_from_file_location with bytes location
    location_bytes = b"asd/asdasdasd/asd/asdsadasd.py"
    module_bytes = load_module_from_file_location(location_bytes)

    assert module_bytes.__name__ == "asdsadasd"

    # check load_module_from_file_location with string location
    location_string = "/asd/asdasdasd/asd/asdsadasd.py"
    module_string = load_module_from_file_location(location_string)

    assert module_string.__name__ == "asdsadasd"

    # check load_module_from_file_location with path location

# Generated at 2022-06-26 04:13:57.711672
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_dir = Path(__file__).parent
    module = load_module_from_file_location(
        f"{test_dir}/fixtures/test_config.py", "utf-8"
    )
    assert module.config_option == "config_option"
    assert module.config_option_bytes == b"config_option_bytes"
    assert type(module.config_option_bytes) == bytes
    assert module.config_option_int == 1
    assert type(module.config_option_int) == int
    assert module.config_option_bool == True
    assert type(module.config_option_bool) == bool



# Generated at 2022-06-26 04:14:10.763446
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import os
    import tempfile
    import importlib
    import pathlib

    sys.path.insert(0, tempfile.gettempdir())
    module_name = "my_module"
    module_name_2 = "my_module_2"

    # Test with module path as string
    module_path_name = os.path.join(tempfile.gettempdir(), module_name + ".py")
    module_path_name_2 = os.path.join(tempfile.gettempdir(), module_name_2 + ".py")
    with open(module_path_name, "w+") as f:
        f.write("my_var = 'my_value'")

    loaded_module = load_module_from_file_location(
        module_path_name, encoding=None
    )


# Generated at 2022-06-26 04:14:17.985895
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("/home/Harsh/Python/sanic_tutorial/examples/async_db_sanic.py")
    assert isinstance(module, types.ModuleType)
    # assert module.__name__ == "async_db_sanic"
    # assert module.__file__.endswith("async_db_sanic.py")


# Generated at 2022-06-26 04:14:33.883753
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # A) Load sample module from test_data/sample_module.py
    sample_module = load_module_from_file_location(
        str(Path(__file__).parent.parent / "test_data" / "sample_module.py")
    )

    # B) Check if it's loaded by verifying some signature.
    assert sample_module.SOME_SAMPLE_VARIABLE == "sample_module"
    assert hasattr(sample_module, "sample_function")
    assert callable(sample_module.sample_function)
    assert sample_module.sample_function() == "sample_function"
    assert hasattr(sample_module, "SampleClass")
    assert callable(sample_module.SampleClass)
    assert sample_module.SampleClass().sample_method() == "sample_method"

    # C)

# Generated at 2022-06-26 04:14:38.642924
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "/Users/ryo.uchiyama/Documents/PycharmProjects/sanic/examples/files/config.py"
    module = load_module_from_file_location(location)
    assert module.TESTING is True

# Generated at 2022-06-26 04:14:44.141648
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    '''
    Check whether a module is imported correctly
    '''
    module = load_module_from_file_location("Config/Config.py")
    assert(module.database == "sanic")

# Generated at 2022-06-26 04:14:54.344503
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_dict = {"1": 1, "2": 2, "3": 3}
    import tempfile
    import os
    with tempfile.TemporaryDirectory() as tmp_dir:
        module_path = tmp_dir + '/module.py'
        with open(module_path, 'w') as module_file:
            module_file.write("module_dict = {'1': 1, '2': 2, '3': 3}")
        os.environ["MODULE_PATH"] = tmp_dir
        module = load_module_from_file_location(
            "module_dict", "${MODULE_PATH}/module.py")
        assert module.module_dict == module_dict

# Generated at 2022-06-26 04:14:59.679757
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ['SANIC_CONFIG_MODULE'] = "config"
    location = "${SANIC_CONFIG_MODULE}"
    module = load_module_from_file_location(location)
    bool_test = bool(module)

# Generated at 2022-06-26 04:15:01.653754
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location("sanic")
    except Exception:
        assert False


# Generated at 2022-06-26 04:15:14.074101
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # If location is None then return None
    assert load_module_from_file_location(None) is None

    # Case A) location is a string
    # Case A.1) value of location starts with `~`
    module_1 = load_module_from_file_location("~/scratch.py")
    assert module_1 is not None
    assert isinstance(module_1, types.ModuleType)

    # Case A.2) value of location doesn't start with `~`
    module_2 = load_module_from_file_location("/scratch.py")
    assert module_2 is not None
    assert isinstance(module_2, types.ModuleType)

    # Case B) location is a Path
    # Case B.1) value of location starts with `~`
    module_3 = load_module_

# Generated at 2022-06-26 04:15:25.160076
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    file_name = "config.py"
    file_dir = Path(".") / "tests"
    file_path = file_dir / file_name

    # Case 0
    # Test when file exists
    result = load_module_from_file_location(file_path)
    assert result.DB_TRUE
    assert result.DB_FALSE

    # Case 1
    # Test when file does not exist
    file_path = Path(".") / "test" / "test_config.py"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(file_path)

    # Case 2
    # Test when location is not pathlib.Path, str or bytes type.
    with pytest.raises(TypeError):
        test_list = [1, 2, 3]
        load

# Generated at 2022-06-26 04:15:36.122670
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 0
    module_0 = load_module_from_file_location("test_config_0.py")
    assert module_0.config_var_0 == "test_0"
    assert module_0.config_var_1 == "test_1"

    # Test 1
    module_1 = load_module_from_file_location("test_config_1.py")
    assert module_1.config_var_0 == "test_2"
    assert module_1.config_var_1 == "test_3"

    # Test 2
    module_2 = load_module_from_file_location("test_config_2.py")
    assert module_2.config_var_0 == "test_4"
    assert module_2.config_var_1 == "test_5"

    # Test 3