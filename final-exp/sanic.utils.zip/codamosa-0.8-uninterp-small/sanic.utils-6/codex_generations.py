

# Generated at 2022-06-26 04:05:51.186816
# Unit test for function str_to_bool
def test_str_to_bool():
    str_1 = 'y'
    bool_1 = str_to_bool(str_1)
    assert bool_1 is True
    str_2 = 'yes'
    bool_2 = str_to_bool(str_2)
    assert bool_2 is True
    str_3 = 'yep'
    bool_3 = str_to_bool(str_3)
    assert bool_3 is True
    str_4 = 'yup'
    bool_4 = str_to_bool(str_4)
    assert bool_4 is True
    str_5 = 't'
    bool_5 = str_to_bool(str_5)
    assert bool_5 is True
    str_6 = 'true'
    bool_6 = str_to_bool(str_6)
    assert bool_6 is True

# Generated at 2022-06-26 04:06:06.765251
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    
    assert str_to_bool("no") == False
    assert str_to_bool("nope") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("disabled") == False
    assert str_to_bool("0") == False


# Generated at 2022-06-26 04:06:10.327328
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Loads module based on its file name
    base_dir = os.path.dirname(os.path.abspath(__file__))
    loaded = load_module_from_file_location(os.path.join(base_dir, "app.py"))
    assert "app" == loaded.__name__


# Generated at 2022-06-26 04:06:24.522192
# Unit test for function str_to_bool
def test_str_to_bool():
    str_0 = "true"
    str_1 = "false"
    str_2 = "on"
    str_3 = "off"
    str_4 = "enable"
    str_5 = "disable"
    str_6 = "enabled"
    str_7 = "disabled"
    str_8 = "y"
    str_9 = "n"
    str_10 = "yes"
    str_11 = "no"
    str_12 = "1"
    str_13 = "0"
    str_14 = "yep"
    str_15 = "nope"
    str_16 = "t"
    str_17 = "f"
    str_18 = "yup"
    str_19 = "nop"
    str_20 = "Y"

# Generated at 2022-06-26 04:06:27.454325
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = '/tmp/test.py'
    location_bytes = b'/tmp/test.py'

    mod = load_module_from_file_location(location)
    mod = load_module_from_file_location(location_bytes)


# Generated at 2022-06-26 04:06:38.521039
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("True") == True
    assert str_to_bool("true") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("tRUE") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("on") == True
    assert str_to_bool("0") == False
    assert str_to_bool("f") == False
    assert str_to_bool("F") == False
    assert str_to_bool("False") == False
    assert str_to_bool("false") == False
    assert str_to_bool("FALSE") == False


# Generated at 2022-06-26 04:06:49.557420
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from sanic.exceptions import LoadFileException, PyFileError

    with TemporaryDirectory() as dir_path:

        # A) Test 1:
        #    Check if function works in case of environment variables provided
        #    in file path.
        # NOTE:
        # Test setUp():
        dir_path_0 = Path(dir_path) / 'A'
        dir_path_1 = Path(dir_path) / 'B'
        Path(dir_path_1).mkdir()
        # Test Execution:
        environ['TEST_ENV_VAR_0'] = dir_path_0
        environ['TEST_ENV_VAR_1'] = dir_path_1

# Generated at 2022-06-26 04:06:52.998306
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    some_module = load_module_from_file_location(
        "some_module_name",
        "/some/path/${some_env_var}"
    )

# Generated at 2022-06-26 04:06:54.657124
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "websocket.accept"
    load_module_from_file_location(location)


# Generated at 2022-06-26 04:06:56.695943
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    result = load_module_from_file_location("test")
    assert result != None

# Generated at 2022-06-26 04:07:05.458835
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location('config.py')
    print(module)

# Generated at 2022-06-26 04:07:13.488334
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Case 0:
    str_0 = 'app.py'
    module_0 = load_module_from_file_location(str_0)
    assert module_0

    # Case 1:
    str_1 = 'app_1.py'
    module_1 = load_module_from_file_location(str_1)
    assert module_1

    # Case 2:
    str_2 = 'app_2.py'
    module_2 = load_module_from_file_location(str_2)
    assert module_2

# Generated at 2022-06-26 04:07:22.422859
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        '/Users/zhangjian/Desktop/SJTU/SEMESTER/SEMESTER4/网络编程/shadowsocks/shadowsocks-libev/src/config.h'
    )
    print(module)
    pass

if __name__ == '__main__':
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:07:29.347341
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    print(load_module_from_file_location('/Users/maohuagui/Downloads/repo/sanic-demo/sanic_demo/app.py'))

if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:07:36.445264
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # path = '${DEST}/tests/test_dir/config.py'
    path = '/home/gth/workspace/sanic/tests/test_dir/config.py'
    module = load_module_from_file_location(path)
    assert module.config['GLOBAL_KEY'] == 'value'
    assert module.config['GLOBAL_LIST'][1] == '2'

if __name__ == '__main__':
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:07:47.173565
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  #noqa
    location = './tests/a'
    module = load_module_from_file_location(location)
    print(module.__file__)
    assert isinstance(module.__file__, str)
    location = './tests/a.py'
    module = load_module_from_file_location(location)
    print(module.__file__)
    assert isinstance(module.__file__, str)
    # location = './tests/'
    # module = load_module_from_file_location(location)
    # print(module.__file__)
    # assert isinstance(module.__file__, str)
    # location = './tests'
    # module = load_module_from_file_location(location)
    # print(module.__file__)
    # assert

# Generated at 2022-06-26 04:07:54.975020
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "config.py"
    module_name = location.split('.')[0]
    module = load_module_from_file_location(location)
    if type(module) != types.ModuleType:
        raise Exception('Should return module')
    if module.__name__ != module_name:
        raise Exception('Module name should be the same as passed')
    return module



# Generated at 2022-06-26 04:08:08.373144
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    #
    # Some cases
    #
    module = load_module_from_file_location(
        '${HOME}/github/dhatim/python-http-client/lib/http_client/__init__.py',
    )
    module.__file__
    module.__package__

    module = load_module_from_file_location(
        '${HOME}/github/dhatim/python-http-client/lib/http_client/app.yaml',
    )
    module.__file__
    module.__package__
    module.runtime
    module.instance_class
    
    module = load_module_from_file_location(
        '${HOME}/github/dhatim/python-http-client/lib/http_client/appengine_config.py',
    )
    module

# Generated at 2022-06-26 04:08:10.745913
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with  pytest.raises(ValueError):
        str_to_bool('2')

# Generated at 2022-06-26 04:08:16.392305
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 0
    str_0 = 'app.py'
    module_0 = load_module_from_file_location(str_0)
    assert module_0.__name__ == 'app'
    assert module_0.__file__ == '/Users/shuwang/code/sanic-crud/sanic_crud/app.py'

# Generated at 2022-06-26 04:08:25.377110
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        location = 'tests/test_module_to_serve.py'
        module = load_module_from_file_location(location)
        assert module.test_var == 'aaa'
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-26 04:08:28.322096
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location('/home/mirko/IT/Devops/python-app/app.py')
    assert module.__name__ == 'app'

# Generated at 2022-06-26 04:08:33.182623
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = 'app.py'
    m = load_module_from_file_location(str_0)
    print(type(m))
    print(vars(m))


# Generated at 2022-06-26 04:08:38.551825
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "app/app.py"
    load_module_from_file_location(location)
    print('load_module_from_file_location passed test')

if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:08:45.201470
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location('app.py', '/Users/kang/OneDrive/Projects/Honeypot/pyHoneypot/sanic')
    except Exception as e:
        print(e)
        assert False
    assert True

# Generated at 2022-06-26 04:08:55.257736
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    err_msg_0 = "Fail load_module_from_file_location: "
    err_msg_1 = "Fail load_module_from_file_location.__file__: "
    err_msg_2 = "Fail load_module_from_file_location.__name__: "
    err_msg_3 = "Fail load_module_from_file_location.__package__: "
    try:
        location = 'app.py'
        result = load_module_from_file_location(location)
        assert result.__name__ == 'app'
        assert result.__package__ == ''
        assert result.__file__ == '/Users/mengweitu/Documents/GitHub/webapp/app.py'
    except AssertionError:
        print(err_msg_0)

# Generated at 2022-06-26 04:08:59.879625
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "app.py"
    mod = load_module_from_file_location(location)
    mod.app.run(host="0.0.0.0", port=8000)

if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:02.585790
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:10.901247
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 0
    str_0 = 'app.py'
    m_0 = load_module_from_file_location(str_0)
    print('m_0 = ', m_0)

    # Test 1
    str_1 = 'app.py'
    m_1 = load_module_from_file_location(str_1)
    print('m_1 = ', m_1)

if __name__ == "__main__":
    # test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:12.666375
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    passed_location = 'F:/Projects/Sanic/app.py'
    passed_location_rslt = load_module_from_file_location(passed_location)
    assert passed_location_rslt == 'app'



# Generated at 2022-06-26 04:09:23.434400
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_0 = load_module_from_file_location(
        'tests/test_config/test_1.py',
        'utf8',
        'r',
    )
    module_1 = load_module_from_file_location(
        'tests/test_config/test_2.py',
        'utf8',
        'r',
    )
    module_2 = load_module_from_file_location(
        'tests/test_config/test_3.py',
        'utf8',
        'r',
    )
    var_0 = module_0.TEST_1
    var_1 = module_1.TEST_2
    var_2 = module_2.TEST_3
    var_3 = module_1.TEST_4

# Generated at 2022-06-26 04:09:26.907935
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    mymodule = load_module_from_file_location('websocket_module.py')
    assert type(mymodule) == types.ModuleType

# Generated at 2022-06-26 04:09:32.398762
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # unit test 1
    module_0 = load_module_from_file_location('sanic.app')
    assert module_0.app_utils.str_to_bool
    # unit test 2
    module_0 = load_module_from_file_location('sanic.app')
    assert module_0.app_utils.str_to_bool

# Generated at 2022-06-26 04:09:39.387827
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "test_config.py"
    module = load_module_from_file_location(location)
    assert module.TEST_KEY_0 == 'TEST_VAL_0'
    assert module.TEST_KEY_1 == 'TEST_VAL_1'
    assert module.TEST_KEY_2 == 'TEST_VAL_2'

# Generated at 2022-06-26 04:09:43.413158
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = '/Users/jdye/code/sanic/examples/sanic/config.py'
    module = load_module_from_file_location(path)
    print(module)


if __name__ == '__main__':
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:49.524887
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    _module = load_module_from_file_location('sanic_restful.unit_test.resource_test')

if __name__ == "__main__": 
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:57.858986
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_0 = load_module_from_file_location("./example.py")

if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()
    print("Test passed!")

# Generated at 2022-06-26 04:10:04.453262
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    location = "env_var_test.py"
    os_environ['VAR_0'] = "asd"
    module = load_module_from_file_location(location)
    assert module.TEST_VAR == "asd" # check that variable is substituted properly
    assert (module.__file__ == Path(location).resolve()) # check that module file is set properly
    assert (module.__spec__ is not None) # check that spec is set properly
    assert (module.__spec__.name == "env_var_test") # check that spec module name is set properly

# Generated at 2022-06-26 04:10:09.532917
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location_0 = "/home/dev/sanic/sanic/.coveragerc"
    module_0 = load_module_from_file_location(location_0)
    print(module_0)

# Generated at 2022-06-26 04:10:13.636779
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # we will try to load this file
    path_to_this_file = __file__
    # load_module_from_file_location with only path to this file
    loaded_module_0 = load_module_from_file_location(path_to_this_file)
    # check if it is really loaded file
    assert loaded_module_0.__file__ == path_to_this_file

# Generated at 2022-06-26 04:10:25.170538
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    import os

    # 1. Passing unix-style path
    res = load_module_from_file_location(
        Path(os.path.dirname(__file__)+"/test.py")
    )
    assert res.var1==1
    assert res.var2=="str"

    # 2. Passing windows-style path
    res = load_module_from_file_location(
        Path(os.path.dirname(__file__)+"\\test.py")
    )
    assert res.var1==1
    assert res.var2=="str"

    # 3. Passing windows-style path and raising exception

# Generated at 2022-06-26 04:10:32.155313
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = 'test_module.py'
    module_1 = load_module_from_file_location(location)
    test_vars = vars(module_1)
    return test_vars

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:10:40.441727
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = 'websocket.accept'
    bool_0 = str_to_bool(str_0)
    # Test load_module_from_file_location
    def test_case_0():
        str_0 = 'websocket.accept'
        bool_0 = str_to_bool(str_0)
        str_1 = 'websocket.accept_offer'
        bool_1 = str_to_bool(str_1)
        str_2 = 'websocket.close'
        bool_2 = str_to_bool(str_2)
        str_3 = 'websocket.close_connection'
        bool_3 = str_to_bool(str_3)
        str_4 = 'websocket.connect'
        bool_4 = str_to_bool(str_4)

# Generated at 2022-06-26 04:10:44.143568
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location_0 = '/home/liming/code/sanic/examples/chat/config.py'
    load_module_from_file_location(location_0)

test_load_module_from_file_location()

# Generated at 2022-06-26 04:10:49.516516
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location_0 = 'some_module_name'
    location_1 = '/some/path/${some_env_var}'

    module_0 = load_module_from_file_location(location_0)

# Sanic benchmark

# Generated at 2022-06-26 04:10:53.691544
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "sanic.app"
    module = load_module_from_file_location(location)
    # The loaded module have no documentation
    assert hasattr(module, "__doc__") is False

# Generated at 2022-06-26 04:11:02.911380
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("./test/test_config_0.yaml")

    assert module.name_0 == "John"
    assert module.age_0 == 25
    assert module.occupation_0 == "programmer"
    assert module.gender_0 == "male"
    assert module.hobbies_0 == ['nursing', 'music', 'reading']



# Generated at 2022-06-26 04:11:08.250530
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = './test_file.py'
    module = load_module_from_file_location(location)
    assert module.__file__ == location
    assert module.name == 'test_file'
    assert module.attr_1 == 'test_1'
    assert module.attr_2 == 'test_2'

test_case_0()
test_load_module_from_file_location()
print('Test Case Passed')

# Generated at 2022-06-26 04:11:19.283719
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = 'tests/fixtures/test_import_config.py'
    module = load_module_from_file_location(location=location, encoding='utf-8')
    assert module.__name__ == 'config'
    assert module.TEST_VAL == True
    # an example of next line:
    # https://github.com/huge-success/sanic/blob/master/sanic/config.py#L95
    assert type(module.TEST_VAL) is bool

# Benchmark
if __name__ == '__main__':
    import timeit
    print(timeit.timeit(test_case_0, number=10000))
    print(timeit.timeit(test_load_module_from_file_location, number=10000))

# References
# https://docs.python.org/3

# Generated at 2022-06-26 04:11:22.877619
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = "../sanic.py"
    mod = load_module_from_file_location(path)


# Generated at 2022-06-26 04:11:28.490131
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "sanic/examples/basics.py"
    module = load_module_from_file_location(location)


if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:11:40.843723
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("os") == os
    assert load_module_from_file_location("os.path") == os.path
    assert load_module_from_file_location("os.path.abspath") == os.path.abspath
    try:
        assert (
            load_module_from_file_location("os.some_unknown_module") == os.path
        )
    except ModuleNotFoundError:
        assert True
    try:
        assert load_module_from_file_location("some_unknown_module") == os.path
    except ModuleNotFoundError:
        assert True
    # Test scenario 1.
    p = Path(__file__)

# Generated at 2022-06-26 04:11:44.765417
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "sanic.exceptions.LoadFileException"
    module = load_module_from_file_location(location)

## Unit test for function str_to_bool

# Generated at 2022-06-26 04:11:49.267307
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_str = "app.app.app"
    print(f"Testing imported module {import_str}")

    module = load_module_from_file_location(import_str)
    #module.app()
    print(module)



# Generated at 2022-06-26 04:11:56.006358
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location('/Users/akshaykumar/Desktop/abcd.py')
    load_module_from_file_location(
        '/Users/akshaykumar/Desktop/abcd.py',
        'utf8'
    )
    load_module_from_file_location(
        'utf8',
        '/Users/akshaykumar/Desktop/abcd.py',
    )
    load_module_from_file_location(
        '/Users/akshaykumar/Desktop/abcd.py',
        encoding='utf8'
    )

# Generated at 2022-06-26 04:12:02.104563
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        location=str(Path(__file__).parent / 'test_case/test_config.py')
    )

if __name__ == '__main__':
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:12:04.866710
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_path = "config.py"
    config_module = load_module_from_file_location(file_path)


# Generated at 2022-06-26 04:12:08.380809
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location_1 = '../unit_tests/config.py'
    config_1 = load_module_from_file_location(
        location_1
    )
    assert config_1.HOST == '127.0.0.1'
    assert config_1.PORT == '8001'
    assert config_1.DEBUG == True

# Generated at 2022-06-26 04:12:12.982647
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    mod = load_module_from_file_location(
        "sanic.async_hacks", encoding='utf8'
    )
    #assert mod is not None
    assert mod



# Generated at 2022-06-26 04:12:18.039274
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = 'sanic_module_stub.py'
    result = load_module_from_file_location(location)
    assert(result)
    assert(result == 'sanic_module_stub')

# Generated at 2022-06-26 04:12:27.642833
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_0 = 'websocket.accept'
    path_1 = 'websocket.accept'
    encoding_0 = 'utf8'
    location_1 = load_module_from_file_location(path_1, encoding_0)

# Generated at 2022-06-26 04:12:33.048543
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "/dev/null"
    encoding = "utf8"
    new_module = load_module_from_file_location(
        location, encoding, *tuple(), **dict()
    )
    print(f"test_load_module_from_file_location: {new_module}")


# if __name__ == "__main__":
#     test_case_0()
#     test_load_module_from_file_location()

# Generated at 2022-06-26 04:12:35.766186
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_location = 'app.py'
    load_module_from_file_location(file_location)

# Generated at 2022-06-26 04:12:37.015999
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location("__main__.py", __file__)

# Generated at 2022-06-26 04:12:41.559852
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_path = "test_module.py"
    module = load_module_from_file_location(file_path)
    assert (
        module.__file__
        == os.path.join(os.path.dirname(os.path.realpath(__file__)), file_path)
    )

# Generated at 2022-06-26 04:12:45.323526
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = '${PWD}/test_config/test_config.py'
    module = load_module_from_file_location(location)
    assert module.TEST_CONFIG == "test message"

# Generated at 2022-06-26 04:12:49.254745
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
	location_str_1 = "handler.py"
	module_1 = load_module_from_file_location(location_str_1)
	assert module_1.__file__ == location_str_1

# Test case for function load_module_from_file_location

# Generated at 2022-06-26 04:13:02.549221
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_0 = '/some/path/some_module.py'
    module_0 = load_module_from_file_location(path_0)
    path_1 = '/some/path/config.py'
    module_1 = load_module_from_file_location(path_1)
    encoding_0 = 'ascii'
    bytes_0 = b'\x80'
    module_2 = load_module_from_file_location(
        bytes_0, encoding=encoding_0)
    location_0 = '/some/path/${env_var}/config.py'
    module_3 = load_module_from_file_location(location_0)


# Generated at 2022-06-26 04:13:07.114731
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "some_module_name"
    args = ""
    kwargs = ""
    load_module_from_file_location(location, args, kwargs)


# Generated at 2022-06-26 04:13:16.049045
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test for simple usecase.
    module_from_file = load_module_from_file_location('./dataset/structure.py')
    module_from_file.x = 3
    module_from_file.y = 4
    print(module_from_file.x)
    print(module_from_file.y)

    # Test for case when we provide path to file with environment variables.
    module_from_file_with_env_vars = load_module_from_file_location('./dataset/${some_var}/structure.py')
    module_from_file_with_env_vars.x = 3
    module_from_file_with_env_vars.y = 4
    print(module_from_file_with_env_vars.x)
    print

# Generated at 2022-06-26 04:13:24.894840
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    filename = "test.txt"
    #file_content = "Some content"

    #with open(filename, 'w') as f:
    #    f.write(file_content)

    module = load_module_from_file_location(filename)
    assert module.__name__ == filename.split(".")[0]

    #os.remove(filename)


if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:13:31.935136
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_1 = 'test_cases/test_case.py'
    mod_0 = load_module_from_file_location(str_1)
    assert mod_0.name == 'test_case'

if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:13:34.745899
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_path = Path('.').resolve().joinpath('tests', 'test_data', 'test0.py')
    load_module_from_file_location(file_path)


# Generated at 2022-06-26 04:13:40.071921
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = 'test_cases.py'
    assert load_module_from_file_location(location)

# Unit test code for function str_to_bool
# Can only run once
# test_case_0()

# Generated at 2022-06-26 04:13:45.477088
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "/some/path/${some_env_var}"
    location_provider = "test_file.txt"
    module = load_module_from_file_location(location, location_provider)
    module_2 = load_module_from_file_location(location, location_provider)
    assert module == module_2

# Generated at 2022-06-26 04:13:51.400272
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "test/test_config_location.py"
    module = load_module_from_file_location(location)
    assert hasattr(module, 'TEST_CONFIG')
    assert module.TEST_CONFIG is True

# Generated at 2022-06-26 04:13:57.527123
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "app.py"
    loaded_module = load_module_from_file_location(location)
    assert type(loaded_module) == types.ModuleType
    assert loaded_module.__name__ == "app"
    assert loaded_module.__file__ == "app.py"


if __name__ == '__main__':
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:14:03.892078
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = '/home/pda/PycharmProjects/sanic_aioorm/tests/model_0.py'
    module = load_module_from_file_location(location)
    assert module.UserId.id



# Generated at 2022-06-26 04:14:09.294002
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    sys.path.append('./')
    module_name = 'test_module'
    file_path = './test_module.py'
    test_module = load_module_from_file_location(file_path)
    function_name = 'test_case_0'
    assert hasattr(test_module, function_name)
    assert getattr(test_module, function_name) != None

# Generated at 2022-06-26 04:14:21.700963
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 1
    in1 = './test/resource/test_config.py'
    out1 = load_module_from_file_location(in1)
    assert out1.test_key == 42
    assert out1.test_str == 'Hello'

    # Test 2 
    in2 = './test/resource/test_config.yaml'
    out2 = load_module_from_file_location(in2)
    assert out2.test_key == 42
    assert out2.test_str == 'Hello'
    assert out2.test_list[0] == 0
    assert out2.test_list[1] == 1
    assert out2.test_list[2] == 2
    assert out2.test_dict.test_key == 42
    assert out2.test_dict.test_str

# Generated at 2022-06-26 04:14:32.106634
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = 'hello'
    str_1 = '${HELLO}'
    e = ''
    
    try:
        load_module_from_file_location(str_0)
    except LoadFileException as e:
        pass
    except Exception as e:
        pass

    try:
        load_module_from_file_location(str_1)
    except LoadFileException as e:
        pass
    except Exception as e:
        pass

# Generated at 2022-06-26 04:14:39.125122
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 1. Pass an invalid path and expect error
    try:
        import_string('/Users/shubham/Desktop/invalid_module.py')
    except IOError:
        pass
    else:
        assert False

    # Test 2. Pass a valid path and expect module loaded
    test_module = import_string('/Users/shubham/Desktop/test_module.py')
    assert test_module.TEST_CONSTANT == 111

# Generated at 2022-06-26 04:14:43.593897
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    some_module = load_module_from_file_location('./test_file.py')
    assert some_module.my_var == 1



# Generated at 2022-06-26 04:14:51.574875
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    ''' Tests that module can be loaded from the valid path name.'''

    path = '/Users/sharmila/GitRepo/sanic/sanic/config.py'

    try:
        module = load_module_from_file_location(path)
        assert module is not None
        # assert type(module) == types.ModuleType

    except Exception:
        assert False

# Generated at 2022-06-26 04:15:04.286398
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # case 1:
    str_1 = '"net" in dependencies or "net" in extensions'
    module_1 = load_module_from_file_location(str_1)
    assert repr(module_1) == "<module 'config' from 'net'>"

    # case 2:
    str_2 = '"net" in dependencies or "net" in extensions'
    module_2 = load_module_from_file_location(str_2)
    assert repr(module_2) == "<module 'config' from 'net'>"

    # case 3:
    str_3 = '"%s" in dependencies or "%s" in extensions'
    module_3 = load_module_from_file_location(str_3)
    assert repr(module_3) == "<module 'config' from '%s'>"

    #

# Generated at 2022-06-26 04:15:08.733991
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "test/test_config/test_config.py"
    test_module = load_module_from_file_location(location)
    assert test_module.some_attribute == 'some attribute'

# Generated at 2022-06-26 04:15:11.735041
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Case 0
    location = 'sanic.config'
    module = load_module_from_file_location(location)


# Generated at 2022-06-26 04:15:14.459094
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = '${HOME}/.secret'
    load_module_from_file_location(location)


# Generated at 2022-06-26 04:15:21.169947
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import config
    import os

    path = os.path.dirname(config.__file__)
    location = path + '/../../tests/config_file.py'
    loaded_module = load_module_from_file_location(location)

    assert loaded_module.config_value == 'Pizza'

# Generated at 2022-06-26 04:15:24.496372
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    filepath = 'config.py'
    module = load_module_from_file_location(filepath)
    assert type(module) == type(object)

    filepath = 'config.py'
    module = load_module_from_file_location(filepath)
    assert type(module) == type(object)


# Generated at 2022-06-26 04:15:31.088088
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location_str = "sanic_session.__version__"
    location_module = load_module_from_file_location(location_str)

# Generated at 2022-06-26 04:15:35.382866
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = 'websocket.accept'
    result = load_module_from_file_location(location)
    print(result)
    # assert(isinstance(location, bytes))
    # assert(isinstance(location, str))
    # if isinstance(location, bytes):
    #     location = location.decode(encoding)
    #     assert(location)

# Generated at 2022-06-26 04:15:46.472002
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test Empty Value
    try:
        ret = load_module_from_file_location(None)
    except Exception as err:
        assert err.args[0] == 'Unable to load configuration None'
    else:
        raise Exception('Test should have failed, but it passed')
    # Test No File Extension
    try:
        ret = load_module_from_file_location('/no/file/ext')
    except Exception as err:
        assert err.args[0] == 'Unable to load configuration file (e.strerror)'
    else:
        raise Exception('Test should have failed, but it passed')
    # Test Only File Name
    try:
        ret = load_module_from_file_location('test_load_module_from_file_location.py')
    except Exception as err:
        raise Exception