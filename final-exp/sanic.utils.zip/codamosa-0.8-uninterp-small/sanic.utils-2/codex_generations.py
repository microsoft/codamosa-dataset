

# Generated at 2022-06-26 04:05:52.654562
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # test for relative file path
    relative_file_path = "./test_config.py"
    assert load_module_from_file_location(relative_file_path).key == 1

    # test for absolute file path
    # getcwd is added as we are testing on mac/linux machines,
    # since windows don't need abspath.
    absolute_file_path = os.getcwd() + "/test_config.py"
    assert load_module_from_file_location(absolute_file_path).key == 1

    # test for file uri
    file_uri = f"file://{absolute_file_path}"
    assert load_module_from_file_location(file_uri).key == 1

    # test for relative file path in bytes

# Generated at 2022-06-26 04:06:01.253134
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Expected error
    try:
        load_module_from_file_location("key_1")
    except LoadFileException as e:
        assert "The following environment variables are not set: key_1" in str(e)
    else:
        assert False

    os_environ["key_2"] = "value_2"
    os_environ["key_3"] = "value_3"

    path = Path("${key_2}/file_1")
    module = load_module_from_file_location(path)
    assert module.__file__ == "value_2/file_1"

    path = "file_2"
    try:
        load_module_from_file_location(path)
    except LoadFileException as e:
        assert "The following environment variables are not set: file_2"

# Generated at 2022-06-26 04:06:08.692469
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = load_module_from_file_location(
        "sanic.config"
    )
    assert location

    location = load_module_from_file_location(
        'test.test_load_module_from_file_location'
    )
    assert location


# Generated at 2022-06-26 04:06:20.328384
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from shutil import copyfile

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        config_file_path = temp_dir / "some_config.py"
        # Simplest config file:
        template = f"some_var = {os_environ['HOME']}"
        # Create config file
        with open(config_file_path, "w") as config_file:
            config_file.write(template)

        # Load it
        config_mod = load_module_from_file_location(config_file_path)

        assert config_mod.some_var == Path(os_environ["HOME"])

# Generated at 2022-06-26 04:06:25.326371
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "sanic_babel/tests/test_config.py"
    module = load_module_from_file_location(location)
    assert module.some_string == "some string"
    assert module.some_int == 42
    assert module.some_list == [42]
    assert module.some_dict == {"some": "dict"}
    assert module.some_bool is True
    assert module.some_none is None
    assert module.some_class == TestClass



# Generated at 2022-06-26 04:06:31.004844
# Unit test for function str_to_bool
def test_str_to_bool():
    # Assertion 1
    str_1 = "Y"
    bool_1 = True
    assert str_to_bool(str_1) == bool_1

    # Assertion 2
    str_2 = "NO"
    bool_2 = False
    assert str_to_bool(str_2) == bool_2

    # Assertion 3
    str_3 = "off"
    bool_3 = False
    assert str_to_bool(str_3) == bool_3

    # test for non-valid strings
    try:
        str_0 = "ok"
        str_to_bool(str_0)
    except ValueError as e:
        print(e)

# Generated at 2022-06-26 04:06:35.801269
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "/some/config/path/config.py"
    module = load_module_from_file_location(location)
    assert "dir" in module.__dir__()

# Generated at 2022-06-26 04:06:46.966749
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from from_file.load_module_from_file_location import SanicConfig

    module = load_module_from_file_location(Path(__file__).parent / "config.py")
    assert module.CONFIG.TEST == SanicConfig.TEST
    assert module.CONFIG.PORT == SanicConfig.PORT

    module = load_module_from_file_location(
        "${PWD}/" + str(Path(__file__).parent / "config.py")
    )
    assert module.CONFIG.TEST == SanicConfig.TEST
    assert module.CONFIG.PORT == SanicConfig.PORT


if __name__ == "__main__":
    """
    Running unit test.

    Coverage is currently not working with Pytest.
    """
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 04:06:59.141103
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unit test for function load_module_from_file_location"""

    # 1. Test config from string
    config_from_str = "sanicconfig"
    config_from_str_loaded = load_module_from_file_location(
        config_from_str
    )
    assert config_from_str_loaded == import_string(config_from_str)

    # 2. Test config from path
    #    with config in sanicconfig subdirectory.
    config_from_path = Path("sanicconfig")
    config_from_path_loaded = load_module_from_file_location(
        config_from_path
    )
    assert config_from_path_loaded == config_from_str_loaded

    # 3. Test config from path
    #    with config in config subdirectory.
   

# Generated at 2022-06-26 04:07:08.964711
# Unit test for function str_to_bool
def test_str_to_bool():
    str_0 = 'N'
    str_1 = 'Yes'
    str_2 = 'oh'
    str_3 = 'YEs'
    str_4 = 'n0'
    str_5 = 'no'
    str_6 = '1'
    str_7 = '0'
    str_8 = 'y'
    str_9 = 'n'
    str_10 = 'yep'
    str_11 = 't'
    str_12 = 'true'
    str_13 = 'on'
    str_14 = 'f'
    str_15 = 'false'
    str_16 = 'off'
    ans_0 = False
    ans_1 = True
    ans_2 = None
    ans_3 = True
    ans_4 = None
    ans_5 = False
   

# Generated at 2022-06-26 04:07:26.034328
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    mod_0 = load_module_from_file_location(
        "/home/user/Documents/dev/sanic-boilerplate/sanic_boilerplate/settings.py"
    )

    dir(mod_0)

    mod_0.DEBUG
    mod_0.SANIC_BOILERPLATE_SENTRY_ENABLED
    mod_0.SANIC_BOILERPLATE_SENTRY_DSN
    mod_0.SANIC_BOILERPLATE_SENTRY_RELEASE
    mod_0.SANIC_BOILERPLATE_REDIS_ENABLED
    mod_0.SANIC_BOILERPLATE_REDIS_HOST
    mod_0.SANIC_BOILERPLATE_REDIS_PORT
    mod_0.SANIC_BOILERPL

# Generated at 2022-06-26 04:07:33.455173
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_ = load_module_from_file_location(
        "sanic.utils.test_module.test_module",
        #"/home/npetrov/Git/sanic/sanic/utils/test_module.py"
    )
    assert hasattr(module_, "test_module")
    assert module_.test_module is True


# Generated at 2022-06-26 04:07:43.508990
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        Path("/home/slaw/git_repos/python/tasks/sanic_learn/config.py")
    )

    assert module.DATABASE_HOST == "127.0.0.1"


if __name__ == "__main__":
    # test_case_0()
    # test_case_1()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:07:52.126503
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "test_application.py"
    module = load_module_from_file_location(location)
    path = Path(module.__file__)
    assert path.is_file()
    assert module.TEST_FILE == True
    assert module.TEST_DATA == "abcd1234"


test_load_module_from_file_location()

# Generated at 2022-06-26 04:07:58.151332
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    globals()["test"] = load_module_from_file_location(
        "/home/siorki/Documents/pwr/rkw/rkw-env/lib/python3.7/site-packages/sanic/config.py",
        "",
        True,
        True,
        True,
        "",
        "",
        "",
        "",
        "",
        True,
    )
    assert type(globals()["test"]) == types.ModuleType
    return 0


# Generated at 2022-06-26 04:08:04.200849
# Unit test for function load_module_from_file_location

# Generated at 2022-06-26 04:08:11.277472
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Testing file with extension
    test_file_1 = "sanic/tests/test_helpers.py"
    module_1 = load_module_from_file_location(test_file_1)
    test_file_2 = "/sanic/tests/test_helpers.py"
    module_2 = load_module_from_file_location(test_file_2)

    # Testing file without extension
    test_file_3 = "sanic/tests/test_helpers"
    module_3 = load_module_from_file_location(test_file_3)
    test_file_4 = "/sanic/tests/test_helpers.py"
    module_4 = load_module_from_file_location(test_file_4)

    # Testing file that does not exist
    test_file_5

# Generated at 2022-06-26 04:08:16.592920
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    mod = load_module_from_file_location("./conf.py")
    print(mod.__file__)
    print(mod.DEBUG)
    print(mod.LOGGING)


if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:08:29.482148
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    result = load_module_from_file_location(
        "tests/framework_tests/data/load_module_from_file_location_test_file"
    )
    assert result.VARIABLE_1 == "VARIABLE_1"
    assert result.VARIABLE_2 == "VARIABLE_2"
    assert result.VARIABLE_3 == "VARIABLE_3"
    assert result.VARIABLE_4 == "VARIABLE_4"
    assert result.VARIABLE_5 == "VARIABLE_5"
    assert result.VARIABLE_6 == "VARIABLE_6"
    assert result.VARIABLE_7 == "VARIABLE_7"



# Generated at 2022-06-26 04:08:41.147566
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    env_vars_in_location = set(re_findall(r"\${(.+?)}", '${FOO}'))

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(
        os_environ.keys()
    )
    if not_defined_env_vars:
        raise LoadFileException(
            "The following environment variables are not set: "
            f"{', '.join(not_defined_env_vars)}"
        )

    # C) Substitute them in location.

# Generated at 2022-06-26 04:08:54.736712
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/home/slaw/git_repos/python/tasks/sanic_learn/config.py'
    config = load_module_from_file_location(str_0)
    print(config)
    assert config.SANIC_INTERNAL_TIMEOUT == 1
    assert config.SANIC_KEEP_ALIVE_TIMEOUT == 1
    assert config.SANIC_REQUEST_MAX_SIZE == 100000000
    assert config.SANIC_REQUEST_TIMEOUT == 1
    assert config.SANIC_RESPONSE_TIMEOUT == 1
    assert config.SANIC_LIMIT_CONCURRENCY == 1
    assert config.SANIC_WORKERS == 1


if __name__ == '__main__':
    test_load_module_from_file_location()
    test_case_

# Generated at 2022-06-26 04:08:59.867429
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/home/slaw/git_repos/python/tasks/sanic_learn/config.py'
    str_1 = 'config'

    assert(str_1 == load_module_from_file_location(str_0).__name__)



if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:06.649596
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/home/slaw/git_repos/python/tasks/sanic_learn/config.py'
    mdl = load_module_from_file_location(str_0)


if __name__ == '__main__':
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:12.756379
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/home/slaw/git_repos/python/tasks/sanic_learn/config.py'
    str_1 = 'config.py'
    
    module_0 = load_module_from_file_location(str_0)
    module_1 = load_module_from_file_location(str_1)
    print(f"module_0 = {module_0}")
    print(f"module_1 = {module_1}")

test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:18.948147
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/home/slaw/git_repos/python/tasks/sanic_learn/config.py'
    mod_0 = load_module_from_file_location(str_0)
    assert_not_equal(mod_0, None, 'Unit test for function load_module_from_file_location: variable mod_0 is None!')
    assert_true(hasattr(mod_0, 'PORT'), 'Unit test for function load_module_from_file_location: variable mod_0 has not attribure mod_0.PORT!')
    assert_equal(mod_0.PORT, 8000, 'Unit test for function load_module_from_file_location: variable mod_0.PORT = 8000!')

# Generated at 2022-06-26 04:09:23.605126
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location('/home/slaw/git_repos/python/tasks/sanic_learn/config.py')


# Generated at 2022-06-26 04:09:31.482509
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = "sanic_learn.config"
    module = load_module_from_file_location(str_0)
    assert module.__name__ == "config"
    assert module.__file__ == "/home/slaw/git_repos/python/tasks/sanic_learn/config.py"

if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:44.043891
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from pathlib import Path
    from tempfile import TemporaryDirectory
    import pytest
    
    from load_module_from_file_location import (
        load_module_from_file_location,
        LoadFileException,
        PyFileError,
    )

    def create_temp_mod_file(content="", *args, **kwargs) -> Path:
        """Creates new temporary file with content passed inside it.

        :param content:
            content that is to be put into temporary file.
        :param args:
            Coresponds to tempfile.NamedTemporaryFile positional arguments.
        :param kwargs:
            Coresponds to tempfile.NamedTemporaryFile positional arguments.
        """
        with TemporaryDirectory() as tmpdirname:
            tmpdirname = Path

# Generated at 2022-06-26 04:09:47.877842
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_case_0()

    _module = load_module_from_file_location(str_0)
    print(_module)


# Generated at 2022-06-26 04:09:59.444961
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # test_case_0
    config_file_location = "/home/slaw/git_repos/python/tasks/sanic_learn/config.py"
    config = load_module_from_file_location(config_file_location)
    assert config.DEBUG is False
    assert config.AUTH_LOGIN == "mustafa"
    assert config.AUTH_PASSWORD == "monkey123"

# Generated at 2022-06-26 04:10:11.464664
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import getenv as os_getenv

    my_module = load_module_from_file_location(
        "my_module", "/tmp/${HOME}/my_module.py"
    )

    assert hasattr(my_module, "my_val")
    assert my_module.my_val
    os_environ.clear()

test_case_0()
test_load_module_from_file_location()

# Generated at 2022-06-26 04:10:18.825326
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # General cases
    path = '$HOME/test/some_mod.py'
    mod = load_module_from_file_location(path)
    assert mod.__name__ == 'some_mod'
    path = '$HOME/test/some_mod.py'
    mod = load_module_from_file_location(path, 'utf8')
    assert mod.__name__ == 'some_mod'
    path = '$HOME/test/some_mod.py'
    mod = load_module_from_file_location(path, 'utf8', 'some_class')
    assert mod.__name__ == 'some_class'
    path = '$HOME/test/some_mod.py'
    mod = load_module_from_file_location(path, 'utf8', 'some_class', True)


# Generated at 2022-06-26 04:10:22.717198
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_name = 'sanic/test_load_module_from_file_location.py'
    module = load_module_from_file_location(file_name)
    assert module is not None

# Generated at 2022-06-26 04:10:28.585495
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = __file__
    loaded_module = load_module_from_file_location(location)
    assert isinstance(loaded_module, types.ModuleType)
    assert loaded_module.__file__ == location



# Generated at 2022-06-26 04:10:33.961504
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    config_file_name = 'config.py'
    file_path = '/some/path/${some_env_var}'
    module = load_module_from_file_location(file_path) 


# Generated at 2022-06-26 04:10:45.830689
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = "./fixtures/some_module.py"
    str_0 = 'rf[v >B'
    path_0 = Path(str_0)
    int_0 = 11416
    bytes_0 = b'\x83\xfb\xac\x9a\x9d\x84\xb3\x83\xa3'
    bytes_1 = b'\xde\xa4\x9d\x91\x81\x89\xf1\xca\x98'
    bytes_2 = b'\x9d\xfe\x86\x83\x8a\x8f\xad\x83\xaa'
    str_1 = '\xde\xa4\x9d\x91\x81\x89\xf1\xca\x98'
   

# Generated at 2022-06-26 04:10:51.121662
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    config = load_module_from_file_location(
        "/mnt/c/Users/Administrator/Desktop/Projects/workflow-analyzer/sanic/app/config/config.py"
    )

    a = 1

# Generated at 2022-06-26 04:10:54.984614
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_to_file = "/home/vminin/GitHub/Sanic_FS_Framework/config.py"
    mod = load_module_from_file_location(path_to_file)
    assert isinstance(mod, types.ModuleType)

# Generated at 2022-06-26 04:10:59.700076
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "test_config.py"
    config_module = load_module_from_file_location(location)
    assert config_module.FOO == "bar"



# Generated at 2022-06-26 04:11:03.684976
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location('some_config', './asd.py')
    except LoadFileException:
        pass

# Generated at 2022-06-26 04:11:18.809365
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 0
    loc = "./test/conf_test/test_conf.py"
    _mod_spec = spec_from_file_location(
        "test_conf", loc, *(), **{"loader": importlib.machinery.SourceFileLoader}
    )
    module = module_from_spec(_mod_spec)
    _mod_spec.loader.exec_module(module)  # type: ignore
    assert module.test_key == "some_value"
    assert module.test_key_bool == True
    assert module.test_key_int == -15
    assert module.test_key_float == 1.3
    assert type(module.test_key_float) == float

    # Test case 1
    loc = "./test/conf_test/test_conf.py"

# Generated at 2022-06-26 04:11:23.180419
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    path = os.getcwd()
    load_module_from_file_location(path + '/test_module.py')


# Generated at 2022-06-26 04:11:24.653540
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("/Users/maggie/Desktop/test1.py")
    assert module.__name__ == 'config'
    assert module.__file__ == '/Users/maggie/Desktop/test1.py'

# Generated at 2022-06-26 04:11:28.244979
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test type of return value.
    assert isinstance(
        load_module_from_file_location("/tmp/environment"), types.ModuleType
    )

    # Test if value is correct.
    assert load_module_from_file_location("/tmp/environment").env == "dev"

# Generated at 2022-06-26 04:11:31.980366
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("__init__.py")
    assert type(module) == types.ModuleType

# Generated at 2022-06-26 04:11:42.131840
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import pathlib

    # Create file and configs directory
    path_0 = pathlib.Path('configs/')
    path_0.mkdir(parents=True, exist_ok=True)
    with open(path_0 / 'example.py', 'w+') as f:
        f.write('config = {"key": "val"}')

    # Load module from file location
    module_0 = load_module_from_file_location(path_0 / 'example.py')

    # Check if module was loaded
    assert "example" in module_0.__name__
    assert module_0.__dict__["key"] == "val"

    # Remove created directories and files
    os.remove(path_0 / 'example.py')
    os.removedirs(path_0)



# Generated at 2022-06-26 04:11:51.695549
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    relative_path = "src/sanic/load_config.py"
    absolute_path = "utils/src/sanic/load_config.py"
    assert load_module_from_file_location(absolute_path)
    assert load_module_from_file_location(relative_path)
    try:
        load_module_from_file_location(
            "not_existing.py"
        )  # will raise LoadFileException
    except:
        pass
    try:
        load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var}"
        )
    except:
        pass

# Generated at 2022-06-26 04:11:58.366601
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    module_0 = load_module_from_file_location("test_cases/test_file_0")
    module_1 = load_module_from_file_location("test_cases/test_file_1")
    module_2 = load_module_from_file_location("test_cases/test_file_2")
    module_3 = load_module_from_file_location("test_cases/test_file_3")

test_load_module_from_file_location()

# Generated at 2022-06-26 04:12:06.346211
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location_0 = './src/utils.py'
    module_0 = load_module_from_file_location(location_0)
    assert module_0.load_module_from_file_location == load_module_from_file_location


# Generated at 2022-06-26 04:12:11.812384
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        "/home/clove11/Documents/code-repositories/sanic_adapter/tests/test_app.py"
    )

# Generated at 2022-06-26 04:12:19.885853
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = '../examples/config/config.py'
    module = load_module_from_file_location(location)
    assert module.DEBUG
    print(module.DEBUG)



# Generated at 2022-06-26 04:12:28.059577
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location(): 
    # Test case "1.yml" 
    with pytest.raises(ValueError, match = 'Invalid truth value 1.yml'):
        test_case_0()
    # Test case "1.json" 
    with pytest.raises(ValueError, match = 'Invalid truth value 1.json'):
        test_case_1()
    # Test case "1.py" 
    with pytest.raises(ValueError, match = 'Invalid truth value 1.py'):
        test_case_2()
    # Test case "1" 
    with pytest.raises(ValueError, match = 'Invalid truth value 1'):
        test_case_3()
    # Test case "False.json" 

# Generated at 2022-06-26 04:12:36.987427
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Assuming following environment variable is set:
    # `export some_env_var="/some/path/"`
    location = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location)
    assert isinstance(module, types.ModuleType)
    assert "config" == module.__name__

    location = "/some/path/${some_env_var_that_is_not_set}"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    location = "tests/config.json"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    location = "tests/config.py"
    module = load_module_from_file_location(location)


# Generated at 2022-06-26 04:12:43.230047
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_module_name = "test_module_name"
    test_module_location = "/test_module/location/test.py"
    test_module = load_module_from_file_location(
        test_module_location, test_module_name
    )
    assert test_module.__name__ == test_module_name
    assert test_module.__file__ == test_module_location

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 04:12:48.203878
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        file_location = "../sanic_auth/__init__.py"
        m = load_module_from_file_location(file_location)
        assert type(m) == types.ModuleType
    except:
        raise

    try:
        file_location = "../sanic_auth"
        m = load_module_from_file_location(file_location)
        assert type(m) == types.ModuleType
    except:
        raise

# Generated at 2022-06-26 04:12:56.902234
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "sanic.config"
    encoding = "utf8"
    args = ()
    kwargs = {}

    load_module_from_file_location(location, encoding, *args, **kwargs)
    # t = load_module_from_file_location("sanic.config")
    # print(t)

# Generated at 2022-06-26 04:13:00.388901
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with open(
        'C:\\Users\\micha\\PycharmProjects\\hackaton_2019-06-22\\sanic\\test.py', 'r'
    ) as f:
        f_contents = f.read()
        exec(f_contents)
        assert 'only_test_variable' in globals()
        assert only_test_variable == 'only_test_variable_value'



# Generated at 2022-06-26 04:13:06.723983
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        'config.py', '/Users/dariusmccalpin/Desktop/OneDrive/Desktop/'
    )
    assert module.HOST == '0.0.0.0'

# Generated at 2022-06-26 04:13:10.417781
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with raises(PyFileError):
        load_module_from_file_location('./examples/extensions/sample.py', 'utf8')
    

# Generated at 2022-06-26 04:13:17.159850
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_0 = '/tmp/test.txt'
    with open(path_0, 'w') as fout:
        fout.write('a = 1\nb = 2\n')

    prj_root_abspath = Path(__file__).absolute().parent.parent
    fpath_1 = prj_root_abspath.joinpath('sanic/exceptions.py')
    fpath_2 = prj_root_abspath.joinpath('sanic/response.py')

    module_1 = load_module_from_file_location(str(fpath_1))
    module_2 = load_module_from_file_location(fpath_2)

    assert module_1.__file__ == fpath_1
    assert module_2.__file__ == fpath_2

    os_en

# Generated at 2022-06-26 04:13:26.919749
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A)
    # 1. Load some python file obviously existing in the file system as path.
    location = os.path.abspath(__file__)
    module = load_module_from_file_location(location)
    assert module.__file__ == location

    # 2. Load some python file obviously existing in the file system as string.
    location = os.path.abspath(__file__)
    location = location.replace("\\", "/")
    module = load_module_from_file_location(location)
    assert module.__file__ == location

    # 3. Load some python file obviously existing in the file system
    #    as Path object.
    location = os.path.abspath(__file__)
    location = Path(location)
    module = load_module_from_file_location(location)

# Generated at 2022-06-26 04:13:37.377839
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("tests/testing_load_module.py")
    print("module is:", module)
    print("module.key is:", module.key)
    print("module.a.b.c is:", module.a.b.c)
    print("module.a.b.c.d is:", module.a.b.c.d)
    print("module.a.b.c[1] is:", module.a.b.c[1])
    # print("module.a.b.c.e is:", module.a.b.c.e)
    print("module.key_list is:", module.key_list)
    print("module.key_list[2] is:", module.key_list[2])

    print()

# Generated at 2022-06-26 04:13:47.740465
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile() as tmp_file:
        tmp_file.write(
            'config_0 = {"__config_path__": "test_test_test"}\n'.encode(
                "utf8"
            )
        )
        tmp_file.flush()
        config_0 = load_module_from_file_location(tmp_file.name)
        assert config_0.__config_path__ == "test_test_test"

    with NamedTemporaryFile() as tmp_file:
        tmp_file.write(
            'class Config_0:\n    config_path = "test_test_test"\n'.encode(
                "utf8"
            )
        )
        tmp_file.flush()
        config_0 = load_module_from_

# Generated at 2022-06-26 04:13:58.352551
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    importlib.reload(load_module_from_file_location)
    cmd = 'load_module_from_file_location'
    import sys
    if sys.argv[0].find(cmd) != -1:
        str_0 = 'rf[v >B'
        bool_0 = str_to_bool(str_0)
    elif sys.argv[0].find(cmd) != -1:
        str_0 = 'rf[v >B'
        bool_0 = str_to_bool(str_0)
    else:
        pass


# Point of Entry
if __name__ == '__main__':
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:14:03.368343
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    bad_location = '/sanic/config.py'
    import os
    os.path.exists(bad_location)
    load_module_from_file_location(bad_location)

# Generated at 2022-06-26 04:14:12.366089
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test cases for load_module_from_file_location
    val0 = load_module_from_file_location(
        "/data/github/chmurakrajowa/chmurakrajowa/tests/test_files/test_data.py",
        "/data/github/chmurakrajowa/chmurakrajowa/tests/test_files/test_data.py",
    )
    val1 = load_module_from_file_location(
        "/data/github/chmurakrajowa/chmurakrajowa/tests/test_files/test_data.py",
        b"/data/github/chmurakrajowa/chmurakrajowa/tests/test_files/test_data.py",
    )

# Generated at 2022-06-26 04:14:22.713986
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Sanity test
    """

    str_1: str = "fff"
    str_2: str = "../../../../../../../../../../../../../../../../etc/passwd"
    str_3: str = "../../../../../../../../../../../../../../../../etc"

    try:
        load_module_from_file_location("../../../../../../../../../../../../../../../../etc")
    except LoadFileException as lfe:
        print("LoadFileException: " + lfe.message)

    try:
        load_module_from_file_location("../../../../../../../../../../../../../../../../etc", "..")
    except LoadFileException as lfe:
        print("LoadFileException: " + lfe.message)

# Generated at 2022-06-26 04:14:28.217092
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import inspect
    test_func_location = inspect.getsourcefile(test_case_0)
    module = load_module_from_file_location(test_func_location)
    assert hasattr(module, 'test_case_0')

# Generated at 2022-06-26 04:14:36.503111
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_config_file_pth = 'test_config.py'
    module = load_module_from_file_location(test_config_file_pth)
    assert module.TEST_VAR == 100
#
# def test_load_module_from_file_location_with_subs():
#     test_config_file_pth = '/path/${var}/test_config.py'
#     os_environ['var'] = 'name'
#     module = load_module_from_file_location(test_config_file_pth)
#     assert module.TEST_VAR == 100
#
#
# def test_load_module_from_file_location_bytes():
#     test_config_file_pth = b'/path/${var}/test_config.py'
#

# Generated at 2022-06-26 04:14:46.381027
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_01 = Path("/Users/kirill/Projects/Sanic/sanic/sanic/config.py")
    # path_01 = Path("/Users/kirill/Projects/Sanic/sanic/sanic/config_test.txt")
    path_02 = Path("/Users/kirill/Projects/Sanic/sanic/sanic/config_1.py")
    path_03 = Path("/Users/kirill/Projects/Sanic/sanic/sanic/config_not_exists.py")
    my_env_var = '${"MY_ENV_VAR"}'
    path_04 = Path(f"/Users/kirill/Projects/Sanic/sanic/sanic/{my_env_var}")
    

# Generated at 2022-06-26 04:14:58.230100
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    # this test is for
    # load_module_from_file_location("app.app")
    module = load_module_from_file_location("app.app")
    assert "app" in sys.modules

    # this test is for
    # load_module_from_file_location("./app.app")
    module = load_module_from_file_location("./app.app")
    assert "app" in sys.modules

    # this test is for
    # load_module_from_file_location("../app.app")
    module = load_module_from_file_location("../app.app")
    assert "app" in sys.modules

    # this test is for
    # load_module_from_file_location("./config/config.py")
    module = load_

# Generated at 2022-06-26 04:15:05.899208
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os.path
    import os

    current_dir = os.getcwd()

    # Create test files
    with open(os.path.join(current_dir, 'test.py'), 'w') as the_file:
        the_file.write('#!/usr/bin/env python\n')
        the_file.write('# -*- coding: utf-8 -*-\n')
        the_file.write('#\n')
        the_file.write('# test.py\n')
        the_file.write('# This file is part of VScope.\n')
        the_file.write('# Created by E.D.Miller.\n')
        the_file.write('#\n')

# Generated at 2022-06-26 04:15:11.064113
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = 'sanic/examples/config.py'
    test_module = load_module_from_file_location(location)
    assert(test_module.TEST_VARIABLE == 'this is a test for the config file')

# Generated at 2022-06-26 04:15:15.452764
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Assignment Statements
    location = '/Users/rj/sanic/app.py'
    encoding = 'utf8'
    location_2 = '/Users/rj/sanic/app.py'
    encoding_2 = 'utf8'
    test_load_mod_file_location = load_module_from_file_location(location, encoding)
    test_load_mod_file_location_2  = load_module_from_file_location(location_2, encoding_2)



# Generated at 2022-06-26 04:15:20.290754
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os.path
    mod = load_module_from_file_location(os.path.dirname(__file__) + "/../../conf/config_default.py")
    assert(mod is not None)

# Generated at 2022-06-26 04:15:23.882109
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    home_dir = str(Path.home())
    module_str = "config"
    conf_path = home_dir + "/config.py"

    config = load_module_from_file_location(conf_path)
    if config.__name__ == module_str:
        return True
    else:
        return False

# Generated at 2022-06-26 04:15:36.002287
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import os
    import shutil
    test_file_location = 'test_file_location.py'
    test_file_location_compiled = 'test_file_location.pyc'
    test_file_location_path = os.path.join(os.path.dirname(__file__), test_file_location)
    test_file_location_compiled_path = os.path.join(os.path.dirname(__file__), test_file_location_compiled)
    shutil.copy2(test_file_location_path, test_file_location_compiled_path)
    os.environ['TEST_ENV_VAR'] = 'test_env_var'

# Generated at 2022-06-26 04:15:45.743211
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os.environ["temp_var"] = "test/test_files/"
    try:
        module_0 = load_module_from_file_location("test")
        module_0 = load_module_from_file_location("./test")
    except:
        pass
    try:
        module_1 = load_module_from_file_location('${temp_var}test')
        module_2 = load_module_from_file_location('${temp_var}test.py')
    except:
        pass


if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()