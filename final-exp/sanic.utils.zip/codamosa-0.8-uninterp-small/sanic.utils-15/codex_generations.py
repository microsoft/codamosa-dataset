

# Generated at 2022-06-26 04:05:41.432325
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # No unit tests so far
        pass

# Generated at 2022-06-26 04:05:45.293255
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("./sanic/one.py")

# Generated at 2022-06-26 04:05:47.815795
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "tests/test_utils"
    expected_result = "The module is loaded from a valid path."
    assert load_module_from_file_location(location) == expected_result

# Generated at 2022-06-26 04:05:50.238758
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    assert load_module_from_file_location(Path("../asdf.py")) is not None

# Generated at 2022-06-26 04:06:01.020948
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test with Path object
    some_module = load_module_from_file_location(
        Path("/some/path/some_module_name")
    )

    # Test with bytes
    some_module = load_module_from_file_location(
        Path("/some/path/some_module_name").encode("utf8")
    )

    # Test with str
    some_module = load_module_from_file_location(
        "/some/path/some_module_name"
    )

    # Test with str and environment variable
    some_module = load_module_from_file_location("/some/path/${some_env_var}")

    # Test with str and environment variable and "./"

# Generated at 2022-06-26 04:06:05.683944
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "tests/helpers/relative_module"
    module = load_module_from_file_location(location)
    assert module.what_is_it() == "a module"

    module = load_module_from_file_location("config", "tests/helpers/module.py")
    assert module.what_is_it() == "a config"

    module = load_module_from_file_location("config", "tests/helpers/module")
    assert module.what_is_it() == "a config"



# Generated at 2022-06-26 04:06:12.784102
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    location = "../sanic/config/.flake8"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert env_vars_in_location == set()

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(
        os_environ.keys()
    )
    assert not_defined_env_vars == set()

    # C) Substitute them in location.

# Generated at 2022-06-26 04:06:21.172543
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # XFAIL: py36,py38. ImportError: cannot import name 'Path'
    if type(Path) == type(str_to_bool):
        raise ValueError(
            "Name 'Path' is not defined. Maybe you have to install pathlib?"
        )
    # error handling
    # XFAIL: py37,py38. Error: str_to_bool() missing 1 required positional argument: 'val'
    with pytest.raises(TypeError, match=r"_?str_to_bool_?\(\) missing 1 required positional argument: 'val'"):
        test_case_0()
    # normal behavior
    pass


# Generated at 2022-06-26 04:06:23.308358
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "https://github.com/huggingface/pytorch-transformers"
    file = load_module_from_file_location(location)


# Generated at 2022-06-26 04:06:26.342060
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_0 = Path('/')
    module_0 = load_module_from_file_location(path_0)

if __name__ == '__main__':
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:06:33.138128
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_0 = load_module_from_file_location("sanic.exceptions")


if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()
    print("Done.")

# Generated at 2022-06-26 04:06:34.012221
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

# Generated at 2022-06-26 04:06:36.856908
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    target = load_module_from_file_location("config")

    assert target is not None

if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:06:49.121940
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A short hand to load_module_from_file_location function.
    load_path = load_module_from_file_location
    load_path("config")  # noqa
    load_path("config.yml")  # noqa
    load_path("/root/config.yml")  # noqa
    load_path("${HOME}/config.yml")  # noqa
    load_path("config", "/root/config.yml")  # noqa
    load_path("config", "${HOME}/config.yml")  # noqa
    load_path("config", "/root/config.yml", encoding="ascii")  # noqa
    load_path("config", "${HOME}/config.yml", encoding="ascii")  # noqa

# Generated at 2022-06-26 04:06:52.998187
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test if load_module_from_file_location returns module object."""
    assert isinstance(
        load_module_from_file_location("sanic.app"), types.ModuleType
    )



# Generated at 2022-06-26 04:06:57.759609
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_0 = load_module_from_file_location("test_case_0", "./test_case_0.py")
    assert module_0.__name__ == "test_case_0"



# Generated at 2022-06-26 04:07:01.289009
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location('/home/sanjeev/Downloads/Sanic-Cookbook-master/models/user.py', '/home/sanjeev/Downloads/Sanic-Cookbook-master/models/user.py')

# Generated at 2022-06-26 04:07:11.918821
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_0 = load_module_from_file_location()
    module_1 = load_module_from_file_location(
        b"/some/path/sanic/configuration.py", *[], **{}
    )
    module_2 = load_module_from_file_location(Path(3), *[], **{})
    module_3 = load_module_from_file_location(
        "/some/path/${some_env_var}", *[], **{}
    )



# Generated at 2022-06-26 04:07:23.379333
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location("C:/Users/aalber25/Documents/GitHub/python_sandbox/sources/sanic/sanic/__init__.py",
                                   "utf8")
    load_module_from_file_location("${USERPROFILE}/Documents/GitHub/python_sandbox/sources/sanic/sanic/__init__.py",
                                   "utf8")
    load_module_from_file_location("/Users/aalber25/Documents/GitHub/python_sandbox/sources/sanic/sanic/__init__.py",
                                   "utf8")

# Generated at 2022-06-26 04:07:25.089700
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location is not None

# Generated at 2022-06-26 04:07:37.677015
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    
    module_0 = load_module_from_file_location(".", "utf8", "rb", True, None)
    module_1 = load_module_from_file_location("/usr/lib/python3.5/site-packages", "utf8", "rb", True, None)
    module_2 = load_module_from_file_location("/usr/lib/python3.5/site-packages", "utf8", "rb", True, None)
    module_3 = load_module_from_file_location("/usr/lib/python3.5/site-packages", "utf8", "rb", True, None)
    module_4 = load_module_from_file_location("/usr/lib/python3.5/site-packages", "utf8", "rb", True, None)

# Generated at 2022-06-26 04:07:47.558194
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    load_module_from_file_location("sanic.app")

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.

    # B) Check these variables exists in environment.

    # C) Substitute them in location.
    load_module_from_file_location(
        "sanic.app",
        "/home/user/${HOME}/sanic_app",
    )

    load_module_from_file_location(
        "sanic.app",
        "/home/user/sanic_app/${HOME}",
    )

    load_module_from_file_location(
        "sanic.app",
        "${HOME}/home/user/sanic_app/",
    )


# Generated at 2022-06-26 04:07:58.263201
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Case 0
    # Module to be imported is not present in the path
    try:
        load_module_from_file_location("test_case_0.py")
    except Exception as e:
        if not isinstance(e, IOError):
            print("Unit test for load_module_from_file_location() failed for case 0")

if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Sanic `provides a pattern
# <https://sanicframework.org/guide/best-practices/exceptions.html#using-sanic-exceptions>`_
# for providing a response when an exception occurs. However, if you do no handle
# an exception, it will provide a fallback. There are three fallback types:

#

# Generated at 2022-06-26 04:08:09.442337
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import_string("sanic.exceptions")
    import_string("sanic.request")
    load_module_from_file_location("sanic.server")
    load_module_from_file_location("sanic.app")
    load_module_from_file_location("sanic.response")
    load_module_from_file_location("sanic.route")
    load_module_from_file_location("sanic.static")
    load_module_from_file_location("sanic.log")
    load_module_from_file_location("sanic.helpers")
    load_module_from_file_location("sanic.__init__")

    load_module_from_file_location("__init__")
    load_module_from_file_location("__main__")
    load_module_

# Generated at 2022-06-26 04:08:14.197730
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '\nSanic `provides a pattern\n<https://sanicframework.org/guide/best-practices/exceptions.html#using-sanic-exceptions>`_\nfor providing a response when an exception occurs. However, if you do no handle\nan exception, it will provide a fallback. There are three fallback types:\n\n- HTML - *default*\n- Text\n- JSON\n\nSetting ``app.config.FALLBACK_ERROR_FORMAT = "auto"`` will enable a switch that\nwill attempt to provide an appropriate response format based upon the\nrequest type.\n'
    bool_0 = str_to_bool(str_0)
    module_0 = load_module_from_file_location(bool_0, "load_module_from_file_location")
   

# Generated at 2022-06-26 04:08:17.679206
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    f_location = '/Users/bryanttam/git/bryanttam/workspace/sanic_exceptions/sanic_exceptions/config.py'
    out_0 = load_module_from_file_location(f_location)
    print(out_0)

# Generated at 2022-06-26 04:08:25.655497
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def test_case_0():
        location = "re"
        encoding = "utf8"
        x = load_module_from_file_location(location, encoding)

    def test_case_1():
        location = "a"
        encoding = "utf8"
        x = load_module_from_file_location(location, encoding)
        assert True

# Generated at 2022-06-26 04:08:32.384981
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location('\nSanic `provides a pattern\n<https://sanicframework.org/guide/best-practices/exceptions.html#using-sanic-exceptions>`_\nfor providing a response when an exception occurs. However, if you do no handle\nan exception, it will provide a fallback. There are three fallback types:\n\n- HTML - *default*\n- Text\n- JSON\n\nSetting ``app.config.FALLBACK_ERROR_FORMAT = "auto"`` will enable a switch that\nwill attempt to provide an appropriate response format based upon the\nrequest type.\n')

# Generated at 2022-06-26 04:08:41.370356
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    temp_dir = tempfile.TemporaryDirectory()
    filename = "config.py"
    temp_file = Path.joinpath(temp_dir, filename)
    temp_file.write_text("test_variable = 'test_value'")

    loaded_module = load_module_from_file_location(temp_dir.name, filename)
    check_test_variable = hasattr(loaded_module, "test_variable")
    reloaded_module = load_module_from_file_location(temp_dir)
    check_reloaded_test_variable = hasattr(reloaded_module, "test_variable")

    assert check_test_variable
    assert check_reloaded_test_variable

# Generated at 2022-06-26 04:08:50.585704
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    spec = spec_from_file_location("test", "C:\\Users\\eben\\work\\sanic\\sanic\\examples\\test_test.py")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    assert module.__dict__.get("TEST_ATTR") == "TEST VALUE"
    assert spec.origin == "C:\\Users\\eben\\work\\sanic\\sanic\\examples\\test_test.py"
    assert spec.has_location()


# Generated at 2022-06-26 04:08:59.247696
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_0 = load_module_from_file_location(
        'sanic/exceptions.py',
        '/Users/lachlan/Code/homebrew-tap/sanic-extras/sanic_extras/',
        True,
        True,
    )


# Generated at 2022-06-26 04:09:11.268198
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("/tmp/py3/tests/traffic_generator/traffic_generator.py")
    assert module.__name__ == "traffic_generator"
    assert module.__file__ == "/tmp/py3/tests/traffic_generator/traffic_generator.py"
    assert module.__package__ is None
    assert module.__loader__.module_name == "traffic_generator"
    assert module.__spec__.name == "traffic_generator"
    assert module.__spec__.origin == "/tmp/py3/tests/traffic_generator/traffic_generator.py"
    assert module.__spec__.loader.module_name == "traffic_generator"

# Generated at 2022-06-26 04:09:13.310103
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    int_0 = load_module_from_file_location(0)


# Generated at 2022-06-26 04:09:20.016148
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_0 = load_module_from_file_location(float)
    module_1 = load_module_from_file_location(dict)
    module_2 = load_module_from_file_location(str)
    module_3 = load_module_from_file_location(dict)

if __name__ == '__main__':
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:20.495678
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

# Generated at 2022-06-26 04:09:22.605725
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("LoadFileException")


# Generated at 2022-06-26 04:09:26.663927
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    some_module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}", encoding="utf8"
    )

# Generated at 2022-06-26 04:09:32.536638
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "${HOME}/sanic_openapi_codec/tests/test_helpers.py"

    result = load_module_from_file_location(location)
    assert (result is not None)
    assert (result.__name__ == 'test_helpers')
    assert (result.__file__ == '%s/tests/test_helpers.py' % os_environ['HOME'])

# Generated at 2022-06-26 04:09:43.620769
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test = load_module_from_file_location(
        "/Users/uvafan/Documents/Github/sanic-framework/docs/source/sanic_config.rst"
    )
    test = load_module_from_file_location(
        "/Users/uvafan/Documents/Github/sanic-framework/docs/source/sanic_config.rst"
    )
    test = load_module_from_file_location(
        "/Users/uvafan/Documents/Github/sanic-framework/docs/source/sanic_config.rst"
    )


if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:55.396718
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Testing normal usage

    # Testing errors
    try:
        load_module_from_file_location("")
    except LoadFileException as e:
        e.strerror = "File path cannot be empty"

    try:
        load_module_from_file_location(
            "", "/some/valid/path"
        )  # explicit path
    except LoadFileException as e:
        e.strerror = "File path cannot be empty"

    try:
        load_module_from_file_location(
            "import os; os.system('./reverse_shell.py')"
        )  # called import_string
    except ValueError as e:
        e.strerror = "Unable to load configuration"


# Generated at 2022-06-26 04:10:06.347267
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) test simple import
    assert (
        load_module_from_file_location("os").path == import_string("os").path
    )

    # B) test location as Path object
    assert (
        load_module_from_file_location(
            Path("os")
        ).path == import_string("os").path
    )

    # C) test path
    assert (
        load_module_from_file_location("os", "/").path
        == import_string("os", "/").path
    )
    assert (
        load_module_from_file_location("os", "/").path
        == load_module_from_file_location("os", b"/").path
    )

    # D) Test encoding

# Generated at 2022-06-26 04:10:10.035912
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_0 = "test_module.py"
    file_0 = load_module_from_file_location(path_0)    


# Generated at 2022-06-26 04:10:15.031065
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_0 = load_module_from_file_location("sanic.exceptions", "blah")
    module_1 = load_module_from_file_location("./tests/example_config.py", "blah")
    module_2 = load_module_from_file_location("./tests/example_config.py")
    module_3 = load_module_from_file_location(b"sanic.exceptions", encoding="blah")

if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()
    print("Unit test completed successfully.")

# Generated at 2022-06-26 04:10:19.324623
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert type(load_module_from_file_location("./sanic_utils/test_doc.md")) == types.ModuleType


# Generated at 2022-06-26 04:10:25.090518
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    ret_0 = load_module_from_file_location("${SANIC_DYNACONF_SETTINGS_MODULE}")
    ret_1 = load_module_from_file_location("${SANIC_DYNACONF_SETTINGS_MODULE}")
    ret_2 = load_module_from_file_location("${SANIC_DYNACONF_SETTINGS_MODULE}")

    assert ret_0
    assert ret_1
    assert ret_2

# Generated at 2022-06-26 04:10:31.645810
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    dict_0 = load_module_from_file_location("sanic.exceptions")
    dict_1 = load_module_from_file_location("sanic.exceptions")

    assert dict_0 == dict_1


# Generated at 2022-06-26 04:10:34.553403
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    a = load_module_from_file_location(
        "C:/Users/lach1/Documents/Python_projects/git/sanic/docs_src/source/index.rst"
    )
    pass


# Generated at 2022-06-26 04:10:39.650856
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_0 = load_module_from_file_location("f_mod")
    assert module_0.NAME == "f_mod"
    assert module_0.__file__.endswith(__file__)

# Generated at 2022-06-26 04:10:44.930494
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location('/tmp/test-config.py')
    except LoadFileException as e:
        assert(e.args[0] == 'Unable to load configuration file (e.strerror)')
    except Exception as e:
        assert(False)
    else:
        assert(False)


# Generated at 2022-06-26 04:10:50.209844
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    init_val = Path(".").abspath()
    load_module_from_file_location(init_val.joinpath("config.py"))


if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:11:03.272262
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = 'load_module'
    module = pathlib.Path(__file__).parent.absolute()
    module.mkdir(parents=True, exist_ok=True)
    str_1 = str(module) + '/test.py'
    str_2 = 'test'
    load_module_from_file_location(
        str_0,
        str_1,
        str_2
    )


# Generated at 2022-06-26 04:11:16.287394
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '\nSanic `provides a pattern\n<https://sanicframework.org/guide/best-practices/exceptions.html#using-sanic-exceptions>`_\nfor providing a response when an exception occurs. However, if you do no handle\nan exception, it will provide a fallback. There are three fallback types:\n\n- HTML - *default*\n- Text\n- JSON\n\nSetting ``app.config.FALLBACK_ERROR_FORMAT = "auto"`` will enable a switch that\nwill attempt to provide an appropriate response format based upon the\nrequest type.\n'
    bool_0 = str_to_bool(str_0)


# Generated at 2022-06-26 04:11:28.489869
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import logging
    import os
    import sys

    from sanic.log import configure_logging

    # You can set `SANIC_CONFIG_MODULE` in your environment
    # or specify it in `env_var` argument.
    env_var = "SANIC_CONFIG_MODULE"
    if env_var not in os.environ:
        os.environ["SANIC_CONFIG_MODULE"] = (
            "tests.test_conf.test_config_module"
        )

    configure_logging(logger=logging.getLogger("sanic.patch"))

    # enable patch
    sys.modules["sanic.app"].app.config.FALLBACK_ERROR_FORMAT = "json"



# Generated at 2022-06-26 04:11:33.560892
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    MODULE_NAME_0 : str = '../examples/config/config.py'
    module_0 = load_module_from_file_location(MODULE_NAME_0)


# Generated at 2022-06-26 04:11:42.667406
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '\nSanic `provides a pattern\n<https://sanicframework.org/guide/best-practices/exceptions.html#using-sanic-exceptions>`_\nfor providing a response when an exception occurs. However, if you do no handle\nan exception, it will provide a fallback. There are three fallback types:\n\n- HTML - *default*\n- Text\n- JSON\n\nSetting ``app.config.FALLBACK_ERROR_FORMAT = "auto"`` will enable a switch that\nwill attempt to provide an appropriate response format based upon the\nrequest type.\n'
    bytes_0 = bytes(str_0, 'utf-8')

# Generated at 2022-06-26 04:11:53.100524
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pathlib
    from tempfile import TemporaryDirectory
    from typing import Union
    from os import environ as os_environ
    import os

    def is_module_returned(returned_val: Union[types.ModuleType, None]):
        assert isinstance(returned_val, types.ModuleType)

    temp_dir = TemporaryDirectory()
    assert isinstance(temp_dir, TemporaryDirectory)
    temp_dir_path = temp_dir.name
    temp_dir_path = pathlib.Path(temp_dir_path)
    file_location = temp_dir_path / 'test_module.py'


# Generated at 2022-06-26 04:11:56.665717
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 0
    location = "some location"
    try:
        module = load_module_from_file_location(location)
        raise Exception(
            "Ho no"
        )  # This should not happen, because we expect exception
    except IOError:
        pass  # Expected, this should happen
    except Exception as e:
        raise

    # Test 1
    location = "${some_env_var_location}"
    try:
        module = load_module_from_file_location(location)
        raise Exception(
            "Ho no"
        )  # This should not happen, because we expect exception
    except LoadFileException:
        pass  # Expected, this should happen
    except Exception as e:
        raise


# Generated at 2022-06-26 04:12:02.227222
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "./tests/examples/fixtures/config.py"
    mod = load_module_from_file_location(location)

    assert mod is not None
    assert mod.__name__ == "config"
    assert mod.PORT == 8000
    assert mod.DEBUG == True

# Generated at 2022-06-26 04:12:09.579889
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Tests the function load_module_from_file_location
    """

# Generated at 2022-06-26 04:12:18.542797
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test for loading module from file location.

    We will load module from current directory.
    First we will use all the optional parameters,
    and then try with default ones.
    """

    location = bytes("./test_helpers.py", encoding="utf8")
    encoding = "utf8"
    args = ["test_helpers", "./test_helpers.py"]
    kwargs = {"loader": importlib.machinery.SourceFileLoader}

    module = load_module_from_file_location(
        location, encoding, *args, **kwargs
    )

    assert module.__name__ == "test_helpers"

    module = load_module_from_file_location("./test_helpers.py")

    assert module.__name__ == "test_helpers"

# Generated at 2022-06-26 04:12:33.560604
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import io

    module_obj = load_module_from_file_location(io.StringIO("print('test')"))
    module_obj.__file__.endswith("<stdin>")
    module_obj.__name__ == "__main__"
    import_string("__main__") == module_obj
    module_obj1 = load_module_from_file_location(io.BytesIO(b"print('test')"))
    module_obj1.__file__.endswith("<stdin>")
    module_obj1.__name__ == "__main__"
    import_string("__main__") == module_obj1
    module_obj2 = load_module_from_file_location(
        "tests.test_helpers"
    )  # Load existing module

# Generated at 2022-06-26 04:12:35.697050
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert True


# Test load_module_from_file_location

# Generated at 2022-06-26 04:12:37.072663
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_case_0()

# Generated at 2022-06-26 04:12:39.162049
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location('./tests/sample_files/app.py')  #noqa

# Generated at 2022-06-26 04:12:52.161680
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 0
    str_0 = "https://github.com/"
    str_1 = "/home/fangzheng/workspace/code/python/workspace/sanic-jwt/sanic_jwt/blueprints.py"
    str_2 = "https://github.com/huge-success/sanic-jwt/blob/master/sanicjwt/blueprints.py"
    tuple_0 = (str_0, str_1, str_2)
    str_3 = "https://github.com/huge-success/sanic-jwt"
    str_4 = "https://github.com/huge-success/sanic-jwt/blob/master/sanicjwt/blueprints.py"
    tuple_1 = (str_3, str_4)

# Generated at 2022-06-26 04:12:58.440887
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 1
    file_loc_1 = "./tests/test_load_file_location.py"
    module_1 = load_module_from_file_location(file_loc_1)
    assert module_1.__name__ == "tests.test_load_file_location"

    # Test 2
    file_loc_2 = ("./tests/test_load_file_location.py",)
    module_2 = load_module_from_file_location(*file_loc_2)
    assert module_2.__name__ == "tests.test_load_file_location"

# Generated at 2022-06-26 04:13:04.651553
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/kolesnikovkv/dev/python/ex1_import_from_imported/file_a.py'
    str_1 = '/Users/kolesnikovkv/dev/python/ex1_import_from_imported/b'
    module_0 = load_module_from_file_location(str_0)
    module_1 = load_module_from_file_location('file_a')
    module_2 = load_module_from_file_location(str_1)
    module_3 = load_module_from_file_location('file_b')


# Generated at 2022-06-26 04:13:13.220318
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    from pytest import raises

    try:
        loaded_module = load_module_from_file_location(
            Path(__file__).parent / "sanic_test_module"
        )
        assert loaded_module.test_var == "test"
    except LoadFileException:
        pass
    except Exception as e:
        raise e

    with raises(LoadFileException):
        load_module_from_file_location(
            Path(__file__).parent / "non_existent_module"
        )
    with raises(LoadFileException):
        load_module_from_file_location(
            "non_existent_module"
        )

# Generated at 2022-06-26 04:13:25.259496
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def test_module_from_file_location_for_location_bytes_type():
        location = "some_module_name"
        location = bytes(location, "utf8")
        assert type(load_module_from_file_location(location)) == types.ModuleType

    def test_module_from_file_location_for_location_str_type():
        location = "some_module_name"
        assert type(load_module_from_file_location(location)) == types.ModuleType

    def test_module_from_file_location_for_location_Path_type():
        location = Path("some_module_name")
        assert type(load_module_from_file_location(location)) == types.ModuleType

    def test_module_from_file_location_for_location_with_dots():
        location

# Generated at 2022-06-26 04:13:37.022818
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    This test loads configuration file
    `tests/configs/test_load_module_from_file_location_config.py`
    and checks if variables from it were loaded correctly.
    """
    config_file_name = "test_load_module_from_file_location_config"
    config_file_path = "tests/configs/"

    config = load_module_from_file_location(
        name=config_file_name, location=config_file_path
    )
    assert config.int_var == 1
    assert config.str_var == "str"
    assert config.bool_var == True
    assert config.list_var == [1, 2, 3]

    # Check if function works without providing name argument

# Generated at 2022-06-26 04:13:42.969364
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_0 = load_module_from_file_location(str, bytes, str)
    assert module_0 is None



# Generated at 2022-06-26 04:13:47.619021
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    _test_param_0: str = '/sanic/test/test_async.py'
    _test_param_1: str = 'utf8'
    _test_params: [str, str] = [_test_param_0, _test_param_1]
    module_0: str = load_module_from_file_location(_test_params)

if __name__ == '__main__':
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:13:52.092220
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test a case where the string argument is not in the format of a path
    try:
        load_module_from_file_location("Hello")
    except Exception as e:
        assert isinstance(e, ValueError)

    # Test a path that doesn't exist
    try:
        load_module_from_file_location("/home/some_fake_path")
    except Exception as e:
        assert isinstance(e, LoadFileException)

    # Test a path that does exist
    output = load_module_from_file_location("test/test_helpers.py")
    assert isinstance(output, type)

# Generated at 2022-06-26 04:14:00.716711
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    mod = load_module_from_file_location("sanic/exceptions.py")
    assert mod == load_module_from_file_location(Path(__file__).parent / "exceptions.py")
    assert mod == load_module_from_file_location(__file__)
    assert mod == load_module_from_file_location(__file__.encode("utf8"), "utf8")
    assert mod == load_module_from_file_location(__file__.encode("utf8"))
    assert mod == load_module_from_file_location(__file__, "utf8")
    assert mod == load_module_from_file_location(__file__.encode())
    assert mod == load_module_from_file_location(__file__, "utf8")
    assert mod == load_module

# Generated at 2022-06-26 04:14:11.547517
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location_0 = """C:\\Users\\Alaa\\Desktop\\untitled\\dcae"""
    location_1 = """\\Users\\Alaa\\Desktop\\untitled\\dcae"""
    location_2 = """\\Users\\Alaa\\Desktop\\untitled\\dcae"""
    location_3 = """\\Users\\Alaa\\Desktop\\untitled\\dcae"""
    location_4 = """\\Users\\Alaa\\Desktop\\untitled\\dcae"""
    location_5 = """\\Users\\Alaa\\Desktop\\untitled\\dcae"""
    location_6 = """\\Users\\Alaa\\Desktop\\untitled\\dcae"""
    location_7 = """\\Users\\Alaa\\Desktop\\untitled\\dcae"""
    location_8 = """\\Users\\Alaa\\Desktop\\untitled\\dcae"""

# Generated at 2022-06-26 04:14:22.227668
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("/etc/hosts")
    assert(module.__file__ == '/etc/hosts')
    assert(len(module.__dict__) == 0)

    module = load_module_from_file_location("/etc/bash.bashrc")

    assert(module.__file__ == '/etc/bash.bashrc')
    assert(len(module.__dict__) == 0)


if __name__ == "__main__":
    import json

    print(
        json.dumps(
            {
                "strength": 1000,
                "intelligence": 20,
                "charisma": 40,
                "dexterity": 40,
                "luck": 40,
            }
        )
    )

# Generated at 2022-06-26 04:14:34.358127
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    os.environ["TEST_ENV_VAR"] = "test_env_var_val"
    module = load_module_from_file_location(
        "module_name",
        "./sanic/exception.py",
        # location,
        loader=importlib.machinery.SourceFileLoader,
        # loader,
        origin="sanic/exception.py",
    )  # origin,
    # print(module.__loader__)
    # print(type(module.__loader__))
    # print(module.__file__)
    # print(type(module.__file__))
    # print(module.__spec__)
    # print(module.__spec__.name, module.__spec__.loader, module.__spec__.origin)
    # <class '

# Generated at 2022-06-26 04:14:45.192486
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with open("README.md", "rb") as r:
        r_byte = r.read()
        r_str = r.read().decode("utf8")
        r_path = Path("README.md")

        assert load_module_from_file_location(
            r_byte
        ) == load_module_from_file_location(r_str) == load_module_from_file_location(
            r_path
        )

        readme_str = load_module_from_file_location(r_str)
        assert "# Sanic" in readme_str.__str__()
        assert "# Sanic" in readme_str.__repr__()


if __name__ == "__main__":
    import os

    print(os.getcwd())
    test_load_module_

# Generated at 2022-06-26 04:14:51.496106
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        "/Users/Gemini_zhu/Git/python-project-template/my_package/my_module.py"
    )


if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:15:04.259600
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_path = "tests/unit/test_utils"
    module_name = module_path

    # Test with filename
    module_file_name = "test_file.py"
    module_file_name_with_path = Path(module_path).joinpath(module_file_name)
    module_file_name_with_path_str = str(module_file_name_with_path)
    module_file_name_with_path_bytes = bytes(module_file_name_with_path)
    module_file_name_with_path_bytes_utf8 = bytes(
        module_file_name_with_path, encoding="utf8"
    )

    module_str = load_module_from_file_location(module_file_name_with_path_str)
    module_bytes = load_module

# Generated at 2022-06-26 04:15:12.325927
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_path_0 = "C:/Users/Christopher/Documents/GitHub/sanic/sanic/examples/conf/settings.py"
    module_0 = load_module_from_file_location(file_path_0)

if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:15:24.411909
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 1
    test_location_0 = "PyfileError.py"
    _spec_0 = spec_from_file_location(
        "test", test_location_0
    )  # Initialize a spec with location and the name
    test_module_0 = module_from_spec(_spec_0)
    _spec_0.loader.exec_module(test_module_0)
    assert test_module_0.__name__ == "test"
    assert test_module_0.__spec__.name == "test"
    assert test_module_0.__spec__.loader is not None
    assert test_module_0.__spec__.loader.name == "test"
    assert test_module_0.__spec__.origin == "test"
    assert test_module_0.__spec__.submodule

# Generated at 2022-06-26 04:15:29.422954
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        "/Users/ramonparis/Documents/GitHub/sanic/examples/cookies_new/main.py"
    )


# Generated at 2022-06-26 04:15:33.107822
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_location = "examples/config.py"
    assert load_module_from_file_location(file_location).UNICORN == "🦄"