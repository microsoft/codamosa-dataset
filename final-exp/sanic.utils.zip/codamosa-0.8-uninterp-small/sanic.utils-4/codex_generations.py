

# Generated at 2022-06-26 04:05:44.417342
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_case_0()

# Generated at 2022-06-26 04:05:53.116270
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 0
    location_0 = '/etc/my.cnf'
    module_0 = load_module_from_file_location(location_0)
    assert len(module_0) == 6
    assert module_0.__file__ == "/etc/my.cnf"
    # Test case 1
    location_1 = '/etc/passwd'
    module_1 = load_module_from_file_location(location_1)
    assert len(module_1) == 6
    assert module_1.__file__ == "/etc/passwd"
    # Test case 2
    location_2 = '/etc/mysql/my.cnf'
    module_2 = load_module_from_file_location(location_2)
    assert len(module_2) == 0
    assert module_2.__file__

# Generated at 2022-06-26 04:05:54.982282
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # test case 0
    location_0 = os.getcwd() + '/docs/tutorial/config.py'
    loaded_module_0 = load_module_from_file_location(location_0)
    assert loaded_module_0 is not None



# Generated at 2022-06-26 04:06:09.972116
# Unit test for function load_module_from_file_location

# Generated at 2022-06-26 04:06:15.645833
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_name = 'sanic_plugins'
    location = './sanic_plugins/plugin.py'
    module = load_module_from_file_location(location)

# Generated at 2022-06-26 04:06:18.147829
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_name, location = 'module_name', '/some/path/module_name.py'
    module = load_module_from_file_location(location)
    assert module.__name__ == module_name
    assert module.__file__ == location
    assert hasattr(module, 'var_0')


# Generated at 2022-06-26 04:06:24.722725
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "0bWrtABuT7cxxTkh.py"
    encoding = "utf-8"
    module = load_module_from_file_location(location, encoding)

benchmark(test_case_0)
benchmark(test_load_module_from_file_location)

# These are the results for a timing test for my machine.
# The defferences are negligible.
'''
test_case_0 took 0.000161 seconds
test_load_module_from_file_location took 0.000140 seconds
'''

# Generated at 2022-06-26 04:06:30.438050
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location_0 = 'C:/Users/hongx/Documents/GitHub/Sanic-SQLAlchemy/setup.py'
    location_1 = 'C:/Users/hongx/Documents/GitHub/Sanic-SQLAlchemy/sanic_sqlalchemy/__init__.py'
    location_2 = 'C:/Users/hongx/Documents/GitHub/Sanic-SQLAlchemy/sanic_sqlalchemy/__main__.py'

    load_module_from_file_location(location_0)
    load_module_from_file_location(location_1)
    load_module_from_file_location(location_2)


# Generated at 2022-06-26 04:06:42.838714
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from tempfile import TemporaryDirectory


# Generated at 2022-06-26 04:06:47.217137
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_module = load_module_from_file_location("test_module.test_module")
    assert hasattr(test_module, "test")
    assert test_module.test() == 10



# Generated at 2022-06-26 04:07:02.595974
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os.path import expanduser
    from os import environ
    import os
    import re
    import yaml

    # A)
    location = '{"a": "b"}'
    module = load_module_from_file_location(location)
    assert module.__dict__ == {"a": "b"}
    location = {"a": "b"}
    module = load_module_from_file_location(location)
    assert module.__dict__ == {"a": "b"}

    # B)
    location = "not_a_module_or_file_name"
    module = load_module_from_file_location(location)
    assert module.__dict__ == {}

    # C)
    location = "/some/file/${HOME}"
    module = load_module_from_file_location(location)


# Generated at 2022-06-26 04:07:14.453172
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    from filecmp import cmp
    from os import getcwd, path, remove
    from tempfile import NamedTemporaryFile
    import contextlib
    #test for exist file
    #test 1, test for valid path
    location = getcwd() + "/tests/config.toml"
    mod_0 = load_module_from_file_location(location)
    assert mod_0.__name__ == "config"
    assert mod_0.__file__ == location
    assert mod_0.TEST

    #test 2, test for invalid path
    location = getcwd() + "/tests/config.tomly"
    try:
        mod_0 = load_module_from_file_location(location)
    except IOError:
        assert True
    else:
        assert False



    #

# Generated at 2022-06-26 04:07:21.992134
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """We will test the load_module_from_file_location function with an already existing file"""
    #Load a file
    file_path = load_module_from_file_location('..\config.py')
    #Check the path
    assert(file_path.__file__=='..\config.py')



# Generated at 2022-06-26 04:07:25.379069
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    L = load_module_from_file_location('./test_file.txt')
    assert L.__file__ == './test_file.txt'

# Generated at 2022-06-26 04:07:37.006259
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Str
    location = 'some_module_name'
    module = load_module_from_file_location(location)
    # Path
    location = Path('some_module_name')
    module = load_module_from_file_location(location)
    # bytes
    location = b'some_module_name'
    module = load_module_from_file_location(location)
    # bytes with encoding
    location = b'some_module_name'
    encoding = 'utf8'
    module = load_module_from_file_location(location, encoding)
    # bytes with encoding and args
    location = b'some_module_name'
    encoding = 'utf8'
    arg = 'a'
    module = load_module_from_file_location(location, encoding, arg)
    # bytes with encoding

# Generated at 2022-06-26 04:07:47.370550
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    test_file = Path(__file__).parent.absolute() / "test_config.py"
    test_bytes = test_file.open('rb').read()

    test_module = load_module_from_file_location(test_bytes)
    assert test_module.TEST_VAR == "test var"

    test_module = load_module_from_file_location(test_file)
    assert test_module.TEST_VAR == "test var"

    os_environ.update({
        "TEST_ENV_VAR": "test env var"
    })

    test_file = Path(__file__).parent.absolute() / "test_config_with_env_var.py"
    test_module = load_module_from_file_location(test_file)

# Generated at 2022-06-26 04:07:53.084035
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    from tempfile import TemporaryDirectory

    from pep484checker import check_source

    with TemporaryDirectory() as tmpdir:
        mod_name = "a_mod"
        mod_path = Path(tmpdir) / f"{mod_name}.py"
        mod_path.write_text(
            textwrap.dedent(
                """
                """
            )
        )
        sys.path.insert(0, tmpdir)
        mod = load_module_from_file_location(mod_path)
        assert check_source(mod) == "No errors"

    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile() as mod_file:
        mod_path = Path(mod_file.name)

# Generated at 2022-06-26 04:07:59.073423
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(__file__)


# Install hotshot and run "python -m hotshot perf.prof <script>" to profile
if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()


# vim:ts=4:sw=4:softtabstop=4:smarttab:expandtab

# Generated at 2022-06-26 04:08:09.702544
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_dir = Path(__file__).parent / "test_load_module_from_file_location"
    sys.path.append(str(test_dir))

    # Test file without extension
    from test_config_file import test_variable_1
    assert test_variable_1 == 1

    # Test file with .py extension
    from test_config_file_py import test_variable_2
    assert test_variable_2 == 2

    # Test file with $VARIABLE in name
    os_environ["TEST_VARIABLE"] = "variable"

# Generated at 2022-06-26 04:08:15.486145
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location_0 = '/home/vadim/Desktop/Projects/personal/sanic/examples/multiple_apps/sanic_app_0.py'
    module_0 = load_module_from_file_location(location_0)

# Run all unit test

# Generated at 2022-06-26 04:08:26.338871
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Should load the module provided as a filepath."""
    location = """/some/path/config.py"""
    module = load_module_from_file_location(location)
    assert callable(module)

if __name__ == "__main__":
    test_load_module_from_file_location()
    test_case_0()

# Generated at 2022-06-26 04:08:39.688049
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    
    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(
        os_environ.keys()
    )
    if not_defined_env_vars:
        raise LoadFileException(
            "The following environment variables are not set: "
            f"{', '.join(not_defined_env_vars)}"
        )

    # C) Substitute them in location.

# Generated at 2022-06-26 04:08:43.133922
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    string_00 = '1vDP\\OOX R'
    assert load_module_from_file_location(string_00)

# Generated at 2022-06-26 04:08:49.929593
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Load configuration from "Nonexistent.yaml"
    # Note that yaml is ignored as a file extension
    load_module_from_file_location('Nonexistent')

    # Load script from current directory
    load_module_from_file_location('.')


if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:08:57.598427
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_name = "load_module_from_file_location_test_module"
    location = "./tests/load_module_from_file_location_test_module.py"
    module = load_module_from_file_location(location)
    module_name_0 = module.__name__
    assert module_name == module_name_0
    

# Generated at 2022-06-26 04:08:59.601711
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    unittest.main()
# test_case_0()
test_load_module_from_file_location()

# EOF

# Generated at 2022-06-26 04:09:11.381038
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as dirpath:
        # Create real file in filesystem.
        file_name = "tmp.py"
        file_path = os.path.join(dirpath, file_name)
        with open(file_path, "w") as f:
            f.write("VAR = 10")

        # Load it by its path.
        mod = load_module_from_file_location(file_path)
        assert mod.__file__ == file_path
        assert mod.VAR == 10

        # Load it by its path with special characters.
        mod = load_module_from_file_location(file_path + "+")
        assert mod.__file__ == file_path
        assert mod.VAR == 10

        # Load it by its filename only.


# Generated at 2022-06-26 04:09:15.352198
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "utils/test_file.py" # relative location to main.py
    module = load_module_from_file_location(location)
    assert module.var == 10

# Generated at 2022-06-26 04:09:21.148299
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "tests/data/config_loader_test_0.py"
    module = load_module_from_file_location(location)

    assert module.__name__ == "config_loader_test_0"
    assert module.__file__ == "tests/data/config_loader_test_0.py"
    assert module.foo == 1
    assert module.bar == 2
    assert module.baz == 3



# Generated at 2022-06-26 04:09:24.923284
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_file = "test.py"
    module = load_module_from_file_location(test_file)
    assert module.CONFIG == 'config'

# Generated at 2022-06-26 04:09:31.371868
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_path = "models/model.py"
    my_module = load_module_from_file_location(module_path)
    # print(my_module)



# Generated at 2022-06-26 04:09:40.637924
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location('akshay')
    except:
        pass
    module = load_module_from_file_location(r"C:\Users\Akshay\AppData\Local\Continuum\anaconda3\envs\py37\lib\site-packages\webtest\test.py")
    assert isinstance(module, type)
    assert module.__name__ == 'test'

# Generated at 2022-06-26 04:09:43.708317
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test 1 - Load module from file path
    module = load_module_from_file_location(
        location="encoding.py",
        package=None,
        encoding=None,
        is_package=False,
        path=None,
    )
    assert True

# Generated at 2022-06-26 04:09:55.452612
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    importlib.reload(sys)
    print("Testing load_module_from_file_location")
    sys_path = sys.path
    sys.path.append("../")
    test_module_0 = load_module_from_file_location("../test_module.py")
    test_module_1 = load_module_from_file_location("test_module.py")
    test_module_2 = load_module_from_file_location("./test_module.py")
    test_module_3 = load_module_from_file_location("./test_module.py")
    test_module_4 = load_module_from_file_location("./test_module.py")
    assert test_module_0.mod_var_0 == "test string"
    assert test_module_1.mod

# Generated at 2022-06-26 04:09:57.583165
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location('1') == None

test_load_module_from_file_location()

# Generated at 2022-06-26 04:10:05.897107
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    fname = 'temp_path.py'

    def write_temp(content):
        with open(fname, "w") as f:
            f.write(content)

    # Test - default encoding
    write_temp("x = 1")
    mod_0 = load_module_from_file_location(fname)
    assert(mod_0.x == 1)

    # Test - explicit encoding
    write_temp("x = 2")
    mod_0 = load_module_from_file_location(fname, encoding='utf-8')
    assert(mod_0.x == 2)
    assert(mod_0.__dict__['x'] == 2)

    # Test - bytes location
    write_temp("x = 3")

# Generated at 2022-06-26 04:10:11.679190
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    twitter_config = load_module_from_file_location("social_auth/twitter.py")
    assert twitter_config.SOCIAL_AUTH_TWITTER_KEY == "Twitter Key"
    assert twitter_config.SOCIAL_AUTH_TWITTER_SECRET == "Twitter Secret"

# Generated at 2022-06-26 04:10:14.655197
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location('imports')
    test = load_module_from_file_location('imports')
    print(f"Test: {test}")

# Run all unit tests

# Generated at 2022-06-26 04:10:24.799105
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Case 0:
    #   - provide a string with a path to file, which has function add(a, b)
    #   - provide wrong arguments
    #   - expect an exception.
    location_0 = './tasks/examples/function_add.py'
    with pytest.raises(Exception):
        module_0 = load_module_from_file_location(location_0, 'utf8', 'abc', 'bcd')

    # Case 1:
    #   - provide a string with a path to file, which has function add(a, b)
    #   - expect that function add(a, b) is present in module loaded from file.
    location_1 = './tasks/examples/function_add.py'

# Generated at 2022-06-26 04:10:31.991579
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    some_path_to_file = "./python/tests/unit/fixtures/some_config.py"
    module = load_module_from_file_location(some_path_to_file)
    assert module.__name__ == "config"



# Generated at 2022-06-26 04:10:38.957223
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location_bytes = b"/some/path/some.py"
    module = load_module_from_file_location(location_bytes)

# Generated at 2022-06-26 04:10:40.773914
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    fp_1 = "app_config"
    load_module_from_file_location(fp_1)


# Generated at 2022-06-26 04:10:43.076320
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location('sanic/config.py')
    module


# Generated at 2022-06-26 04:10:55.977015
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import numpy
    sys.modules["numpy"] = numpy
    # Relative import
    module_0 = load_module_from_file_location(
        "numpy",
        "./tests/examples/module_0.py",
        origin="some_file_0.py",
    )
    assert module_0
    assert module_0.__name__ == "module_0"
    assert module_0.__file__ == "./tests/examples/module_0.py"

    # Absolute import
    module_1 = load_module_from_file_location(
        "module_1",
        "/home/workstation/tests/examples/module_1.py",
        origin="some_file_1.py",
    )
    assert module_1
    assert module_1.__

# Generated at 2022-06-26 04:11:02.687446
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_case_str_0 = '1vDP\\OOX R'

# Generated at 2022-06-26 04:11:05.546316
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # test case 0
    module_0: types.ModuleType = load_module_from_file_location('application.py')
    assert module_0.__name__ == 'application'



# Generated at 2022-06-26 04:11:08.330694
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test exception
    test_exception()

    # Test success
    test_success()



# Generated at 2022-06-26 04:11:19.335266
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # First test case:
    try:
        module_name = 'testing_module'
        test_case_module1 = load_module_from_file_location(
            module_name, '/Users/benjamin/Desktop/Projects/sanic/testing_module.py'
        )
        print(test_case_module1)
        #test_case_module1.hello()
    except Exception as e:
        print('test_case_module1 failed due to ' + str(e))
        pass

    # Second test case:

# Generated at 2022-06-26 04:11:20.693358
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Case 1: test for params values
    loc = '/Users/wangshichun/sanic'
    module = load_module_from_file_location(loc)

# Generated at 2022-06-26 04:11:30.590254
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Testing any kind of path
    try:
        result = load_module_from_file_location('A')
    except Exception as e:
        pass
    finally:
        assert type(result) == types.ModuleType

    # Testing anything that is not a path
    try:
        result = load_module_from_file_location(1)
    except Exception as e:
        pass
    finally:
        assert type(result) == types.ModuleType

    # Testing anything that is not a path
    try:
        result = load_module_from_file_location(False)
    except Exception as e:
        pass
    finally:
        assert type(result) == types.ModuleType

    # Testing anything that is not a path

# Generated at 2022-06-26 04:11:42.614701
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # No error
    load_module_from_file_location("./test_load_module_from_file_location.py")

    # PyFileError
    with pytest.raises(PyFileError):
        load_module_from_file_location("./test_load_module_from_file_location_pyfileerror.py")

    # LoadFileException
    with pytest.raises(LoadFileException):
        load_module_from_file_location("./test_load_module_from_file_location_loadfileexception")

    # IOError
    with pytest.raises(IOError):
        load_module_from_file_location("./test_load_module_from_file_location_ioerror")

# Coverage

# Generated at 2022-06-26 04:11:47.581786
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '1vDP\\OOX R'
    load_module_from_file_location(str_0)

# Line Coverage
# python -m pytest --cov=app tests/test_app.py -vv --color=yes

# Generated at 2022-06-26 04:11:57.828212
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 1
    # Given location is a path to file
    location = "./tests/test_data/configs/template_config.json"
    module = load_module_from_file_location(location)
    assert hasattr(module, "KEY")
    assert module.KEY == "value"

    # Test 2
    # Given location is a path to folder
    location = "./tests/test_data/configs"
    module = load_module_from_file_location(location)
    assert type(module).__name__ == "ModuleType"

    # Test 3
    # Given location is a path to file using environment variables
    location = "./tests/test_data/configs/${TEST_ENV_VAR}/template_config.json"
    os_environ["TEST_ENV_VAR"]

# Generated at 2022-06-26 04:11:59.883674
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # test_path = './test/test.json'
    pass

# Generated at 2022-06-26 04:12:09.160592
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    loc_0 = '/Users/vakhnaht/sanic/test1.py'
    module_0 = load_module_from_file_location(loc_0)
    module_0.x = '1vDP\\OOX R'
    str_0 = module_0.x
    bool_0 = str_to_bool(str_0)
    assert bool_0   
    

if __name__ == "__main__":
    # test_load_module_from_file_location()
    test_case_0()

# Generated at 2022-06-26 04:12:14.711116
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with open("test_file.py", "w") as f:
        f.write("test_variable = 1")

    pkg = load_module_from_file_location("test_file")
    assert pkg.test_variable == 1

    os.remove("test_file.py")

# Generated at 2022-06-26 04:12:26.271246
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "tests/fixtures/test_config.py"
    default_module = load_module_from_file_location(location=location)
    custom_module = load_module_from_file_location(
        location=location,
        target="test",
        loader=None,
        is_package=False,
        origin=None,
    )
    assert str(default_module) == "<module 'test_config' from 'tests/fixtures/test_config.py'>"  # noqa
    assert str(custom_module) == "<module 'test' from 'tests/fixtures/test_config.py'>"  # noqa
    assert default_module.__package__ == ""
    assert custom_module.__package__ == ""
    assert default_module.TEST == "OK"
    assert custom_module.T

# Generated at 2022-06-26 04:12:34.950356
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 1) Test "load_module_from_file_location(location: Path)"

    some_path_to_pyfile = Path("some_path_to_pyfile.py")
    loaded_module = load_module_from_file_location(some_path_to_pyfile)

    assert loaded_module

    # 2) Test "load_module_from_file_location(location: str)"

    some_string_with_path_to_pyfile = "some_string_with_path_to_pyfile.py"
    loaded_module = load_module_from_file_location(
        some_string_with_path_to_pyfile
    )

    assert loaded_module

    # 3) Test "load_module_from_file_location(location: bytes)"

    some_bytes_with_path_to_

# Generated at 2022-06-26 04:12:46.441853
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_name = "some_config"
    path_to_file = Path(__file__).parent / "{}.py".format(file_name)

    module = load_module_from_file_location(path_to_file)
    assert module.some_variable == "some value"

    # With just file name.
    module = load_module_from_file_location(file_name)
    assert module.some_variable == "some value"

    # With full path.
    path_to_file = str(path_to_file)
    module = load_module_from_file_location(path_to_file)
    assert module.some_variable == "some value"

    # With environment variables.
    os_environ["ENV_VAR_0"] = path_to_file
    env_var_0

# Generated at 2022-06-26 04:12:47.836868
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    x = load_module_from_file_location("/some/path")
    # The assert is not correct.
    assert x



# Generated at 2022-06-26 04:12:56.972429
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "tests/mock_module.py"
    module = load_module_from_file_location(location)
    assert module.__name__ == "mock_module"
    assert module.mock_var == 42

# Generated at 2022-06-26 04:13:02.718479
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location('cfg.py', 'tests/')

    assert module is not None
    assert module.SOME_PARAM == 'some_value'
    assert module.SOME_OTHER_PARAM == 'some_other_value'

if __name__ == '__main__':
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:13:13.410826
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys
    from _pytest.tmpdir import TempdirFactory
    from unittest import mock
    import pytest

    from text_loader import load_module_from_file_location

    tmp_dir = TempdirFactory().mktemp('tmp_dir')
    tmp_dir.join('setup.py').write(
        'assert 1',
    )
    tmp_dir.join('__init__.py').write(
        'assert 1',
    )
    tmp_dir_str = str(tmp_dir.realpath())

    sys.path.append(tmp_dir_str)

    # setup.py
    mod_0 = load_module_from_file_location(tmp_dir_str + '/setup.py')
    assert mod_0.__name__ == 'setup' # type: ignore

# Generated at 2022-06-26 04:13:18.759719
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        "/home/justas/code/sanic_poc/sanic_poc/config/environment_variables.py"
    )

# Generated at 2022-06-26 04:13:26.685462
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '1vDP\\OOX R'
    bool_0 = str_to_bool(str_0)
    str_1 = '\\Yg9m7ZUx'
    bool_1 = str_to_bool(str_1)
    str_2 = '-Y0U6f+U6'
    bool_2 = str_to_bool(str_2)
    str_3 = ' lB9+EI#'
    bool_3 = str_to_bool(str_3)
    str_4 = 'eNXtZ@%tG'
    bool_4 = str_to_bool(str_4)
    path_0 = Path('/TdHViT/hBoT/')
    str_5 = '+BvBSdR'
    bool_5

# Generated at 2022-06-26 04:13:37.346616
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test good case
    # Note: The path has to be absolute here.
    path = '/path/to/good/module.py'
    module = load_module_from_file_location(path)
    assert module.name == 'good_module'
    assert module.sub_module.sub_name == 'good_sub_module'
    assert module.sub_module.sub_sub_module.sub_sub_name == 'good_sub_sub_module'

    # Test import error
    # Note: The path has to be absolute here.
    path = '/path/to/bad/module.py'
    module = load_module_from_file_location(path)
    assert module.name == 'bad_module'
    assert module.sub_module.sub_name == 'bad_sub_module'
    assert module.sub

# Generated at 2022-06-26 04:13:47.717693
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        module = load_module_from_file_location("t_try", "test.py")
    except Exception as e:
        pass
    assert type(module) == types.ModuleType

    try:
        module_2 = load_module_from_file_location("t_try", "tes.py")
    except Exception as e:
        pass
    assert type(module_2) == IOError

    try:
        module_3 = load_module_from_file_location("t_try", "test.py", "r")
    except Exception as e:
        pass
    assert type(module_3) == types.ModuleType

    try:
        module_4 = load_module_from_file_location("t_try", "test.py", "None")
    except Exception as e:
        pass
   

# Generated at 2022-06-26 04:13:59.055969
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test loading module from PYZ file.
    module_from_file = load_module_from_file_location("tests/test_sanic.pyz")
    assert module_from_file.TEST_DATA == "geo_location_data"

    # B) Test loading module from ZIP file
    module_from_zip = load_module_from_file_location("tests/test_sanic.zip")
    assert module_from_zip.TEST_DATA == "geo_location_data"

    # C) Test loading module from TAR.GZ file.
    module_from_tar_gz = load_module_from_file_location(
        "tests/test_sanic.tar.gz"
    )

# Generated at 2022-06-26 04:14:04.838190
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        'sanic.__main__'
    )
    assert 'sanic.__main__' in module.__name__ 



# Generated at 2022-06-26 04:14:13.225439
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_str = '''
    print('Hello, World!')
    '''

    with open('module_str.py', 'w') as m_str_file:
        m_str_file.write(module_str)

    m_str_module = load_module_from_file_location('module_str.py')

    module_not_found = '''
    print('Hello, World!')
    '''

    with open('module_not_found.py', 'w') as m_not_found_file:
        m_not_found_file.write(module_not_found)
    
    m_not_found_module = load_module_from_file_location('module_not_found.py')

    module_wrong_file = '''
    print('Hello, World!')
    '''



# Generated at 2022-06-26 04:14:18.348421
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "sanic.log"
    load_module_from_file_location(location)

# Generated at 2022-06-26 04:14:27.101902
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    current_path = os.path.abspath(os.path.dirname(__file__))
    path = os.path.join(current_path, 'test.py')

    test_mod = load_module_from_file_location(path)
    assert test_mod.test_var == "test_value"



# Generated at 2022-06-26 04:14:36.184070
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # test_case 1
    l_0 = load_module_from_file_location('/Users/albert/Documents/Python/Sanic/sanic/app/__main__.py')
    assert type(l_0) == types.ModuleType

    # test_case 2
    class A:
        pass
    try:
        l_1 = load_module_from_file_location(A)
        assert False
    except LoadFileException:
        assert True

    # test_case 3
    str_0 = '1vDP\\OOX R'
    try:
        l_2 = load_module_from_file_location(str_0)
        assert False
    except IOError:
        assert True

    # test_case 4

# Generated at 2022-06-26 04:14:39.424889
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "../sanic/server.py"
    module = load_module_from_file_location(location)

if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:14:43.065181
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
        location = "../../confs/conf_sanic.py"
        module = load_module_from_file_location(location)
        assert module.SERVER_PORT

if __name__ == '__main__':
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:14:54.770834
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from pathlib import Path
    import tempfile
    from unittest.mock import patch

    # Test 1, environment variables resolution and file detection
    environ["PY_TEST_DIR"] = str(Path(tempfile.gettempdir()))
    module = load_module_from_file_location(
        "/${PY_TEST_DIR}/some_file.py"
    )
    assert type(module) == types.ModuleType
    module = load_module_from_file_location(
        Path(tempfile.gettempdir()) / "some_file.py"
    )
    assert type(module) == types.ModuleType
    module = load_module_from_file_location(
        Path(tempfile.gettempdir())
    )

# Generated at 2022-06-26 04:15:01.416243
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "/home/user/Desktop/sanic/config_for_testing.py"
    module = load_module_from_file_location(location)
    print(module)


if __name__ == '__main__':
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:15:06.322724
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = 'test_config.py'
    module = load_module_from_file_location(location)
    assert module.__name__ == 'config'
    assert module.__file__ == location

# Generated at 2022-06-26 04:15:15.706078
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("sanic.config")
    assert module.DEBUG == False
    assert module.TESTING == False

# Generated at 2022-06-26 04:15:19.894511
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "/home/stefan/git/py-codedx-sanic/run.py"
    mod = load_module_from_file_location(location)
    assert mod

# Generated at 2022-06-26 04:15:27.657519
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module =  load_module_from_file_location('test/test.py')
    assert module.__name__ == 'test.test'

# Generated at 2022-06-26 04:15:32.876872
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '1vDP\\OOX R'
    module_0 = load_module_from_file_location(str_0)


test_case_0()
test_load_module_from_file_location()

# Generated at 2022-06-26 04:15:33.633072
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

# Generated at 2022-06-26 04:15:39.143218
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_module = load_module_from_file_location(
        "app/app.py"
    )

test_case_0()
test_load_module_from_file_location()