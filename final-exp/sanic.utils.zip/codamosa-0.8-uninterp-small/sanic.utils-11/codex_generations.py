

# Generated at 2022-06-26 04:05:52.602655
# Unit test for function load_module_from_file_location

# Generated at 2022-06-26 04:06:06.868017
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Unit test for function load_module_from_file_location
    """
    import os
    import tempfile
    from sanic.config import BaseConfig

    class MyConfig(BaseConfig):
        """
        Initial configuration file
        """

        TEST_VAL = 10

    # create tempfile
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)
    temp_config = os.path.join(temp_dir, "config.py")

    # write configuration file
    with open(temp_config, "w") as f:
        f.write("from sanic.config import BaseConfig\n")
        f.write("\n")
        f.write("class MyConfig(BaseConfig):\n")
        f.write("    TEST_VAL = 10\n")

# Generated at 2022-06-26 04:06:12.389471
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_string = load_module_from_file_location(
        "/home/pielipp/Projects/sanic/tests/test_module.py"
    )


load_module_from_file_location(  # noqa
    "/home/pielipp/Projects/sanic/tests/test_module.py"
)

# Generated at 2022-06-26 04:06:20.409103
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    filename = Path(__file__).parent / "test" / "test_import" / "test.py"
    module_1 = load_module_from_file_location(filename)

    assert module_1.var == 10
    assert module_1.var_2 == 20
    

# Generated at 2022-06-26 04:06:22.965208
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    locations = ["", "", "", "/", "/", "/", "/", "/", "/", "/",]
    encoding = "utf8"
    assert callable(load_module_from_file_location)



# Generated at 2022-06-26 04:06:36.144119
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 0
    try:
        module_0 = load_module_from_file_location(
            "path_to_file_0.py"
        )
    except LoadFileException as e:
        print("Error: {}".format(e))
        
    # Test 1
    try:
        module_1 = load_module_from_file_location(
            "/path/to/dir_1/file_in_dir_1.py"
        )
    except LoadFileException as e:
        print("Error: {}".format(e))
        
    # Test 2

# Generated at 2022-06-26 04:06:40.118361
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '#c?3i|;!T7\\7'
    bool_0 = str_to_bool(str_0)

    assert not bool_0
    assert bool_0 is False


if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:06:44.798913
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Testing with test case 0
    config_path = Path(__file__).parent.parent / 'config.py'
    module = load_module_from_file_location(config_path)


# Test for case where the file cannot be loaded

# Generated at 2022-06-26 04:06:53.004004
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_0 = "config/settings.py"
    path_1 = Path(path_0)
    path_2 = bytes(path_0, encoding="utf8")
    for path in [path_0, path_1, path_2]:
        module_0 = load_module_from_file_location(path)
        assert type(module_0) == types.ModuleType
        assert hasattr(module_0, "salt")
        assert module_0.salt == "0"

# Generated at 2022-06-26 04:07:03.020084
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_to_tests = Path(__file__).parent.parent.joinpath("tests")
    module = load_module_from_file_location(path_to_tests.joinpath("test.py"))
    assert module.CONFIG_VALUE == 42
    module = load_module_from_file_location(
        path_to_tests.joinpath("test.pyc")
    )
    assert module.CONFIG_VALUE == 42
    module = load_module_from_file_location(
        path_to_tests.joinpath("test.json")
    )
    assert module.CONFIG_VALUE == 42
    module = load_module_from_file_location(
        path_to_tests.joinpath("test.yml")
    )
    assert module.CONFIG_VALUE == 42
    module = load_module_

# Generated at 2022-06-26 04:07:13.070077
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(
        'config', './config/config.py').BASE_URI == 'https://localhost:3001'
    assert load_module_from_file_location(
        'config', './config/config.py').CONFIG_DICT.get("swagger_title") == 'Sanic API Blueprint'
    assert load_module_from_file_location(
        'config', './config/config.py').CONFIG_DICT.get("swagger_desc") == 'API for Doctor App'
    assert load_module_from_file_location(
        'config', './config/config.py').CONFIG_DICT.get("swagger_version") == "1.0.0"

# Generated at 2022-06-26 04:07:19.548116
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = 'config.py'

    module = load_module_from_file_location('config.py', '.')
    assert module.__file__ == 'config.py'
    assert module.TESTING == True
    assert module.TESTING_NUM == 1


# Generated at 2022-06-26 04:07:23.236271
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = 'config.py'
    try:
        load_module_from_file_location(location)
    except PyFileError:
        print("Test Failed")
    else:
        print("Test Passed")


# Generated at 2022-06-26 04:07:27.221947
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    global str_0

    # test case 0
    str_0 = 'config.py'
    test_case_0()


# Generated at 2022-06-26 04:07:34.260805
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test cases
    test_cases = ['config.py', './config.py', '${CODE_ROOT}/config.py']
    for test_case in test_cases:
        test_config = load_module_from_file_location(test_case)
        assert 'x' in test_config.__dict__, f'test_case[{test_case}] isn\'t working'



# Generated at 2022-06-26 04:07:36.899739
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = 'config.py'
    assert load_module_from_file_location(str_0) == 0

# Generated at 2022-06-26 04:07:47.322116
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic_openapi import swagger_blueprint
    config = load_module_from_file_location('config')
    config.API_TITLE = 'Hello, Swagger!'
    config.BLUEPRINTS = [swagger_blueprint]
    config.API_VERSION = '1.0'
    config.API_DESCRIPTION = 'API Description'
    config.API_TERMS_OF_SERVICE = 'Use with caution!'
    config.API_PRODUCES_CONTENT_TYPES = ['application/json']
    config.API_CONTACT_EMAIL = 'apiteam@swagger.io'
    config.API_LICENSE_NAME = 'Apache 2.0'

# Generated at 2022-06-26 04:07:49.070542
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        config_module = load_module_from_file_location('./config.py')
    except Exception as e:
        print(e)
    else:
        print(config_module.DEBUG)

# Generated at 2022-06-26 04:07:50.215082
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_0 = import_string('config')
    str_0 = load_module_from_file_location('config')



# Generated at 2022-06-26 04:07:53.083384
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(Path('./config.py'))
    assert load_module_from_file_location(Path('./test_utils.py'))
    assert load_module_from_file_location(Path('./test_load_module_from_file_location.py'))


# Generated at 2022-06-26 04:08:02.447407
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    filepath = './config.py'
    config = load_module_from_file_location('./config.py')
    assert config


if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:08:04.756840
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("config.py")


# Generated at 2022-06-26 04:08:07.473863
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = 'config.py'
    mod_0 = load_module_from_file_location(str_0)
    assert mod_0.__name__ == 'config'


# Generated at 2022-06-26 04:08:11.059429
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 0
    result_0 = load_module_from_file_location('config.py')

    assert result_0



# Generated at 2022-06-26 04:08:15.236625
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from pytest import raises
    import os
    import os.path as osp

    def _test(mod_name, fname):
        module = load_module_from_file_location(fname)
        assert osp.basename(module.__file__) == mod_name + '.py'


    # 1. pathlib.Path
    dirname = '.'
    mod_name = 'config'

    p = Path(dirname, mod_name+'.py')
    with p.open('w') as fp:
        fp.write('')

    _test(mod_name, p)
    p.unlink()

    # 2. string
    fname = osp.join(dirname, mod_name+'.py')
    _test(mod_name, fname)

   

# Generated at 2022-06-26 04:08:16.238841
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_case_0()

# Generated at 2022-06-26 04:08:24.186297
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert isinstance(load_module_from_file_location('./config.py'),module.__class__)
    assert isinstance(load_module_from_file_location('./plugins.py'),module.__class__)

if __name__ == '__main__':
    test_load_module_from_file_location()
    test_case_0()

# Generated at 2022-06-26 04:08:27.352860
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = "config.py"
    b = load_module_from_file_location(str_0)
    assert b is not None
    

# Generated at 2022-06-26 04:08:35.496403
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = 'config.py'
    module_0 = load_module_from_file_location(str_0)
    assert module_0 is not None
    assert module_0.__name__ == 'config'
    assert module_0.__file__ == str_0
    assert module_0.TEST_CASE_0 is True


# Generated at 2022-06-26 04:08:39.001567
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test Case 0: str
    str_0 = 'config.py'
    assert load_module_from_file_location(str_0)

    # Test Case 1: bytes

test_load_module_from_file_location()

# Generated at 2022-06-26 04:08:48.346630
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location('config.py')
    except Exception as e:
        print("[ERROR] Unit test for load_module_from_file_location_0 failed: %s" % e)


# Generated at 2022-06-26 04:08:54.372766
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = 'config.py'
    module = load_module_from_file_location(location)
    assert module.__name__ == 'config', 'module.__name__ == "config"'
    assert module.__file__ == location, 'module.__file__ == location'

# Generated at 2022-06-26 04:08:57.018456
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    print(load_module_from_file_location('config.py', encoding='utf8'))


# Generated at 2022-06-26 04:09:02.455568
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 
    str_0 = 'config.py'
    str_1 = 'config.py'

    print(dir(load_module_from_file_location(str_0)))
    print(dir(load_module_from_file_location(str_1)))

    # 
    str_0 = 'config.txt'
    str_1 = 'config.txt'
    print(dir(load_module_from_file_location(str_0)))
    print(dir(load_module_from_file_location(str_1)))

# 

# Generated at 2022-06-26 04:09:12.157237
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def test_0():
        print("load_module_from_file_location")
        str_0 = 'config.py'

        # Get full path of the file config.py
        str_1 = os.path.abspath('config.py')
        dict_0 = load_module_from_file_location(str_0)

        print(dict_0.__dict__)

        assert dict_0.__dict__['MY_CONFIG'] == 'my_default'

    def test_1():
        # Should fail because file config.py does not exist
        str_0 = 'config.py2'
        dict_0 = load_module_from_file_location(str_0)



# Generated at 2022-06-26 04:09:14.062044
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    name = str_to_bool(str('config.py'))
    assert load_module_from_file_location('config.py', location = name) == True


# Generated at 2022-06-26 04:09:23.182102
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_tmp = load_module_from_file_location('config_dummy.py')

    # Test 1)
    assert(module_tmp.DEBUG is False)

    # Test 2)
    assert(module_tmp.HOST == '127.0.0.1')

    # Test 3)
    assert(module_tmp.PORT == 8000)

    # Test 4)
    assert(module_tmp.DB_HOST == '127.0.0.1')

    # Test 5)
    assert(module_tmp.DB_PORT == 5432)

    # Test 6)
    assert(module_tmp.DB_NAME == 'sanic_rest_db')

    # Test 7)
    assert(module_tmp.DB_USER == 'postgres')

    # Test 8)

# Generated at 2022-06-26 04:09:27.295049
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = 'config.py'
    spec = spec_from_file_location(str_0, str_0)
    assert spec == None


# Generated at 2022-06-26 04:09:32.305895
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    print(load_module_from_file_location('config.py'))
    print(load_module_from_file_location('config.py'))
    # print(load_module_from_file_location('config.py'))
    print(load_module_from_file_location('config.py'))



# Generated at 2022-06-26 04:09:35.047009
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '../app/config.py'
    load_module_from_file_location(str_0)

# Generated at 2022-06-26 04:09:42.211166
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = 'config.py'
    encoding = 'utf8'
    args = ''
    kwargs = ''
    module = load_module_from_file_location(location, encoding, args, kwargs)


# Generated at 2022-06-26 04:09:45.325586
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_mod = load_module_from_file_location("config.py")
    assert test_mod.DEBUG == True
    assert test_mod.HOST == "127.0.0.1"
    assert test_mod.PORT == 8000


if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:47.750202
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = 'config.py'

# Generated at 2022-06-26 04:09:50.472671
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location('test/test_persist_config')


# Generated at 2022-06-26 04:09:51.895475
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_case_0()

# Generated at 2022-06-26 04:09:58.049148
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    str_0 = 'config.py'

    #test case 0
    module = load_module_from_file_location(str_0)
    assert module is not None

    # test case 1
    str_1 = 'app.py'
    module = load_module_from_file_location(str_1)
    assert module is not None



# Generated at 2022-06-26 04:10:06.122106
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test 1
    str_1 = 'config.py'
    module_1 = load_module_from_file_location(str_1)
    assert module_1.__name__ == 'config'

    # Test 2
    str_2 = './config.py'
    module_2 = load_module_from_file_location(str_2)
    assert module_2.__name__ == 'config'

    # Test 3
    str_3 = './config'
    module_3 = load_module_from_file_location(str_3)
    assert module_3.__name__ == 'config'

    # Test 4
    str_4 = './config/config.py'
    module_4 = load_module_from_file_location(str_4)

# Generated at 2022-06-26 04:10:10.890436
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # importlib.reload(load_module_from_file_location)
    res = load_module_from_file_location('config.py')
    print(res)
    assert res is not None

# Generated at 2022-06-26 04:10:13.229246
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    result = load_module_from_file_location('config.py')
    print(result)


# Generated at 2022-06-26 04:10:23.886614
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    print('Test for load_module_from_file_location')
    try:
        location = 'py_test/test_case_0.py'
        print('loading', location)
        print(load_module_from_file_location(location))
    except Exception as e:
        print(e)

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print('test cases:')
        print('test_case_0')
        sys.exit(0)

    try:
        {
            'test_case_0' : test_case_0
        }[sys.argv[1]]()
    except Exception as e:
        print(e)

# Generated at 2022-06-26 04:10:32.636658
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location('./test/test_config.py')


# Generated at 2022-06-26 04:10:36.917745
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    module = load_module_from_file_location('config.py')
    assert module.DB_HOST == 'localhost'
    assert module.DB_USER == 'root'

# Generated at 2022-06-26 04:10:38.060645
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("config.py")

# Generated at 2022-06-26 04:10:39.319983
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import imp
    import_module = imp.load_source('import_module', './config.py')
    assert import_module == load_module_from_file_location('config.py')


# Generated at 2022-06-26 04:10:45.302017
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from types import ModuleType

    # Non existent file
    assert issubclass(
        type(
            load_module_from_file_location("non_existent_file.py")
        ),
        ModuleType,
    ) == False

    # Existing py file
    assert issubclass(
        type(load_module_from_file_location("tests/config.py")), ModuleType,
    ) == True


# Generated at 2022-06-26 04:10:48.758803
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 0
    config_0 = load_module_from_file_location('config.py')
    assert config_0

# Generated at 2022-06-26 04:10:56.129078
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 1: Correct case
    str_0 = 'config.py'
    # Should be able to load module config
    __assert_load_module_from_file_location(str_0)

    # Test case 2: Check it raises right exception
    # when file path don't exists
    str_1 = '/nonexistent/path/to/file'
    # Should not be able to load module nonexistent
    with pytest.raises(ImportError):
        __assert_load_module_from_file_location(str_1)


# Generated at 2022-06-26 04:11:04.669407
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    This function is the test for the function 
    load_module_from_file_location

    Return
    ------
    None
    """
    test_file = "./tests/test_config_load.py"
    module = load_module_from_file_location(test_file)
    assert module.TEST_1 == 1000
    assert module.TEST_2 == 'test_str_2'

# Generated at 2022-06-26 04:11:14.460417
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 0
    str_0 = 'config.py'
    module_0 = load_module_from_file_location(str_0)
    assert hasattr(module_0, 'DB_URL')
    assert hasattr(module_0, 'DB_DATABASE')
    assert hasattr(module_0, 'DB_USERNAME')
    assert hasattr(module_0, 'DB_PASSWORD')



# Generated at 2022-06-26 04:11:16.211381
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    pytest.main()
test_load_module_from_file_location()


# Generated at 2022-06-26 04:11:30.249496
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # test 0, 1
    str_0 = 'config.py'
    assert(type(load_module_from_file_location(str_0)) == type(types.ModuleType))

    # test 2, 3
    str_0 = 'config.py'
    str_1 = 'config1.py'
    assert(type(load_module_from_file_location(str_0)) == type(load_module_from_file_location(str_1)))

    # test 4, 5
    tuple_0 = ('config.py',)
    tuple_1 = ('config1.py',)
    assert(type(load_module_from_file_location(*tuple_0)) == type(load_module_from_file_location(*tuple_1)))

    # test 6, 7

# Generated at 2022-06-26 04:11:35.244814
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    app = load_module_from_file_location('/Users/kirillrumyantsev/sanic/sanic/examples/config.py')
    print(app.test_key)

# Generated at 2022-06-26 04:11:43.165329
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_1 = 'config.py'

    # Config file exists
    assert load_module_from_file_location(str_1)

    # Config file does not exist
    str_2 = 'config_does_not_exist.py'
    try:
        load_module_from_file_location(str_2)
    except Exception as e:
        # print(str(e))
        assert str(e) == 'Unable to load configuration file (e.strerror)'

    # Config file does not exist
    str_3 = 'not-a-config.txt'
    try:
        load_module_from_file_location(str_3)
    except Exception as e:
        # print(str(e))
        assert str(e) == 'Unable to load configuration file (e.strerror)'

# Generated at 2022-06-26 04:11:47.852047
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from_0 = load_module_from_file_location('/home/shantanu/code/deploy-sanic/src/config.py')
    assert from_0.TEST_NAME == 'TEST_VAL'


# Generated at 2022-06-26 04:11:57.926200
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        print('load_module_from_file_location')
        #config_module = load_module_from_file_location('config.py')
        config_module = load_module_from_file_location('../../dev/sanic/config.py')
        print(config_module.__file__)

        print('+++++')
        print(config_module.MYSQL_DATABASE_HOST)
        print(config_module.MYSQL_DATABASE_PASSWORD)
        print(config_module.MYSQL_DATABASE_USER)
        print('------')
    except LoadFileException as e:
        print(e)

if __name__ == '__main__':
    test_case_0()
    #test_load_module_from_file_location

# Generated at 2022-06-26 04:12:07.341360
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # First case:
    str_0 = 'config.py'
    # Second case:
    str_1 = 'config'
    # Third case:
    str_2 = 'config.txt'
    # Fourth case:
    str_3 = 'config.py.txt'
    # Fifth case:
    str_4 = 'config_file'

    print(load_module_from_file_location(str_0))
    print(load_module_from_file_location(str_1))
    print(load_module_from_file_location(str_2))
    print(load_module_from_file_location(str_3))
    print(load_module_from_file_location(str_4))



# Generated at 2022-06-26 04:12:18.088981
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    str_0 = 'config.py'
    str_1 = 'config.py'
    str_2 = 'config.py'


if __name__ == '__main__':
    # print(load_module_from_file_location('/Users/thomas/Documents/GitHub/polaris/resources/config.py'))
    test_case_0()

    module_0 = load_module_from_file_location('./test/test.py')
    print(module_0.param_0)
    print(module_0.param_1)
    print(module_0.param_2)

    module_1 = load_module_from_file_location('test.test')
    print(module_1.param_0)
    print(module_1.param_1)

# Generated at 2022-06-26 04:12:25.000566
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import sys

    # A0) Check if file ./config.py exist
    test_case_0()

# Generated at 2022-06-26 04:12:28.742543
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location_0 = './config.py'
    result_0 = load_module_from_file_location(location_0)
    print(result_0)
    locals()['config'] = result_0
    config.DEBUG = True
    app = Sanic()
    app.run(host="0.0.0.0", port=8000)


if __name__ == '__main__':
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:12:32.737657
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    # test 1
    # assert pytest.raises(LoadFileException, load_module_from_file_location, str_0)
    with pytest.raises(LoadFileException) as excinfo:
        load_module_from_file_location(str_0)
    assert excinfo.type == LoadFileException
    assert excinfo.value.args

# Generated at 2022-06-26 04:12:38.591930
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    print(load_module_from_file_location('config.py'))


# Generated at 2022-06-26 04:12:39.244415
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert True

# Generated at 2022-06-26 04:12:43.600819
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-26 04:12:49.395665
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = 'config.py'
    try:
        assert load_module_from_file_location(str_0)
        assert type(load_module_from_file_location(str_0)) is types.ModuleType
    except:
        load_module_from_file_location(str_0)
# test_case_0()
test_load_module_from_file_location()

# Generated at 2022-06-26 04:12:57.049520
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 0: 'config.py'
    str_0 = 'config.py'
    assert isinstance(load_module_from_file_location(str_0), types.ModuleType)
    print(load_module_from_file_location(str_0))
    

# Generated at 2022-06-26 04:13:05.289344
# Unit test for function load_module_from_file_location

# Generated at 2022-06-26 04:13:15.381405
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test wether load_config_from_file_location import config.py

    This test also checks if config file is being imported twice (once in
    test_config.py and second time in load_config_from_file_location).
    If it is, then the test will fail, because config.py is importing
    second import of config.py as well. In general, importing
    imported file is not allowed due to circular dependency."""

    config = load_module_from_file_location("config.py")
    print(config.INT)
    print("--")
    print(config.STR)
    print("--")
    print(config.LIST)
    print("--")
    print(config.DICT)

test_case_0()
test_load_module_from_file_location()

# Generated at 2022-06-26 04:13:25.545708
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/jhuang/Downloads/sanic-2.0.0b1/examples/config.py'
    str_1 = '/Users/jhuang/Downloads/sanic-2.0.0b1/examples/load_config.py'
    str_2 = '/Users/jhuang/Downloads/sanic-2.0.0b1/examples/not_exist_config.py'
    try:
        load_module_from_file_location(str_0)
        load_module_from_file_location(str_1)
        load_module_from_file_location(str_2)
    except IOError as e:
        print(e.strerror)


# Generated at 2022-06-26 04:13:33.803630
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_0 = load_module_from_file_location('config.py')
    assert module_0.HOST == '0.0.0.0'
    assert module_0.PORT == 5000
    assert module_0.KEEP_ALIVE == 10
    assert module_0.DEBUG == True

if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:13:46.723724
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import getcwd, sep
    # A) Check if function returns module as exec file
    assert isinstance(load_module_from_file_location(f'{getcwd()}{sep}test_config.py'), types.ModuleType)
    # B) Check if function returns module as import string
    assert isinstance(load_module_from_file_location(f'{getcwd()}{sep}test_config'), types.ModuleType)
    # C) Check if function returns module as exec file, using environment variable
    assert isinstance(load_module_from_file_location(f'{"${"+getcwd().split(sep)[1]+"}"}{sep}test_config.py'), types.ModuleType)
    # D) Check if function returns module as import string, using environment variable

# Generated at 2022-06-26 04:13:53.176774
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    func = load_module_from_file_location
    test_case_0()

test_load_module_from_file_location()

# Generated at 2022-06-26 04:13:58.071210
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with pytest.raises(ValueError):
        load_module_from_file_location('c?3i|;!T7\\7')
    with pytest.raises(ValueError):
        load_module_from_file_location('{y}es')
    with pytest.raises(ValueError):
        load_module_from_file_location('t{r}ue')


# Generated at 2022-06-26 04:14:10.926262
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os.environ["A"] = "a"
    os.environ["B"] = "b"
    os.environ["C"] = "c"
    os.environ["D"] = "d"

    assert load_module_from_file_location(
        "sanic.config",
        "/Users/jing/CSEC-490/W8D1/config/config.py",
        "sanic"
    ) is config

    assert load_module_from_file_location(
        "/Users/jing/CSEC-490/W8D1/config/config.py",
    ) is config
    
    # We use the assertTrue() method to verify the truthiness in True and False

# Generated at 2022-06-26 04:14:17.472007
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    "Test load_module_from_file_location function"
    mod_spec = spec_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    mod = module_from_spec(mod_spec)
    mod_spec.loader.exec_module(mod)  # type: ignore

# Generated at 2022-06-26 04:14:32.350107
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  
    str_1 = '#c?3i|;!T7\\7'
    str_2 = 'A\x08NDV\x1a\x1aK\x00\x0bP'
    str_3 = '\x06\r\x1e\x05t\x00\x1c'
    path_1 = '../test_file\x08'
    path_2 = './test_file\x08'
    path_3 = './test_file'
    module_1 = load_module_from_file_location(str_1)
    module_2 = load_module_from_file_location(str_2)
    module_3 = load_module_from_file_location(str_3)

# Generated at 2022-06-26 04:14:36.529584
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = './tests/test_project/test_app/config.py'
    loaded_module = load_module_from_file_location(location)
    assert loaded_module is not None
    assert hasattr(loaded_module, "TEST_KEY")
    assert loaded_module.TEST_KEY == "test_value"

# Generated at 2022-06-26 04:14:46.418025
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location_invalid_data = [
        42,
        ("some_module_name", 42),
    ]
    location_correct_data = [
        ("some_module_name", "/some/path/some_module_name.py"),
        ("pathlib", "/some/path/pathlib.py"),
        ("config_file_location", "config_file_location.py"),
    ]

    def test_invalid_data():
        for data in location_invalid_data:
            module = load_module_from_file_location(*data)

    def test_correct_data():
        for name, location in location_correct_data:
            module = load_module_from_file_location(name, location)
            assert module.__name__ == name
            assert module.__file__ == location


# Generated at 2022-06-26 04:14:51.886023
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_path = Path(__file__).parent / "test_module_for_loading.py"
    module = load_module_from_file_location(test_path)
    assert hasattr(module, "test_name")
    assert module.test_name == "test_value"



# Generated at 2022-06-26 04:14:55.685368
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    obj = load_module_from_file_location("./tests/main_import.py")

# Generated at 2022-06-26 04:15:05.251920
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys, os

    config_dir = os.path.dirname(os.path.abspath(__file__)) + '/config'
    sys.path.insert(0, config_dir)

    conf = load_module_from_file_location(config_dir + '/config.py')
    assert conf.secret == "foo"

    conf = load_module_from_file_location(config_dir + '/config.json')
    assert conf.secret == "foo"

    conf = load_module_from_file_location(config_dir + '/config.yml')
    assert conf.secret == "foo"

    conf = load_module_from_file_location(config_dir + '/config.yaml')
    assert conf.secret == "foo"


# Generated at 2022-06-26 04:15:16.338442
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Checking if function raises expected errors
    # if value passed to it does not satify the contract
    # 1. location parameter ir not of a string or bytes type
    location = []
    try:
        load_module_from_file_location(location, "utf8")
    except TypeError:
        pass
    # 2. location parameter is of a string type and it contains environment
    #    variable which is not defined.
    location = "${VAR_IS_NOT_DEFINED}"
    try:
        load_module_from_file_location(location, "utf8")
    except LoadFileException:
        pass
    # 3. location parameter is of a bytes type and it contains environment
    #    variable which is not defined.
    location = b"${VAR_IS_NOT_DEFINED}"

# Generated at 2022-06-26 04:15:19.969628
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("sanic.app")
    assert hasattr(module, "Sanic")



# Generated at 2022-06-26 04:15:21.805960
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_0 = load_module_from_file_location('config.py')

# Generated at 2022-06-26 04:15:29.731915
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # simple_module_name = "simple_module"
    # simple_module_location = "./simple_module.py"
    # simple_module = load_module_from_file_location(
    #     simple_module_name, simple_module_location
    # )
    # x = simple_module.CONST_0
    pass

# Generated at 2022-06-26 04:15:34.105834
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "/home/example/"
    module_to_test = load_module_from_file_location(location)
    location_error = "example"
    module_error = load_module_from_file_location(location_error)
    # print("Test ran")

# Generated at 2022-06-26 04:15:46.179180
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from copy import deepcopy
    from tempfile import mkdtemp
    from os import environ, getcwd
    from shutil import rmtree
    import sys
    import os

    # Create temporary directory.
    temp_dir = mkdtemp()
    os.chdir(temp_dir)

    # Create test file.
    f = open("test_file", "w+")
    f.write("a = 1")
    f.close()

    # Write to test file.
    with open("test_file", "w") as test_file:
        test_file.write("a = 1")

    # Test when file is absolute path.
    module = load_module_from_file_location(os.path.join(temp_dir, "test_file"))
    assert hasattr(module, "a") and module.a