

# Generated at 2022-06-26 04:05:56.667516
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    test_str = "/some/path/${var_name}"
    os.environ["var_name"] = "test_path"
    test_path = "/some/path/test_path"

    # D) Test with location as a path.
    location = test_path
    try:
        module = load_module_from_file_location(location)
    except Exception as e:
        assert(False, f"Exception: {e}")

    data = module.__dict__
    assert(data["test_var"]==0)


    # E) Test with location as a string.
    location = test_path
   

# Generated at 2022-06-26 04:06:04.734345
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = 'R.@o'
    bool_0 = str_to_bool(str_0)
    os_environ['str_0'] = str_0
    str_1 = os_environ['str_0']
    bool_1 = str_to_bool(str_1)
    bool_2 = bool_0 == bool_1


# Generated at 2022-06-26 04:06:12.481417
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 0
    str_0 = 'R.@o'
    str_1 = ''
    str_2 = '../configurations/configuration.py'
    # Test case 1
    str_3 = '../configurations/configuration.py'
    str_4 = ''
    str_5 = '../configurations/configurat'
    # Test case 2
    str_6 = '../configurations/configuration'
    str_7 = '../configurations/configuration.py'
    str_8 = '../configurations/configuration'
    # Test case 3
    str_9 = '../configurations/configuration'
    str_10 = '../configurations/configuration.py'
    str_11 = '../configurations/configuration'
    # Test case 4

# Generated at 2022-06-26 04:06:25.241840
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Case 1
    x = load_module_from_file_location(location="tests/test_config/test_case_1.py")
    assert x.FOO_VAR == 1
    assert x.FOO_STR_VAR == '1'

    # Case 2
    x = load_module_from_file_location(location="tests/test_config/test_case_2.py")
    assert x.FOO_VAR == 1
    assert x.FOO_STR_VAR == '1'
    assert x.STR_VAR == 'foo'

    # Case 3
    x = load_module_from_file_location(location="tests/test_config/test_case_3.py")
    assert x.FOO_VAR == 1

# Generated at 2022-06-26 04:06:28.971533
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_location = 'sanic/examples/hello.py'
    module = load_module_from_file_location(file_location)
    assert module.routes
    assert module.routes[0][0] == 'GET'
    assert module.routes[0][1] == '/'
    assert module.routes[0][2] == 'main.index'


# Generated at 2022-06-26 04:06:36.369968
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "/home/laptop/Documents/Python/Python/Python-3.x/simultaneous_logging_of_multiple_input_signals_using_analog_discovery/config.py"
    loaded_module = load_module_from_file_location(location, encoding = 'utf8')
    print(loaded_module)
    
    # Assert function and variable in module
    assert hasattr(loaded_module, 'str_to_bool')
    assert hasattr(loaded_module, 'DIRECTORY')
    
#Unit test for function to_str

# Generated at 2022-06-26 04:06:47.553819
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "sanic_envconfig/tests_data/some_module.py"
    module = load_module_from_file_location(location, "sanic_envconfig")
    assert module.SOME_CONSTANT == "Some value"
    location_1 = "sanic_envconfig/tests_data/some_module_1"
    module_1 = load_module_from_file_location(location_1, "sanic_envconfig")
    assert module_1.SOME_CONSTANT == "Some value"
    location_2 = "some_module"
    module_2 = load_module_from_file_location(location_2)
    assert module_2.__name__ == "some_module"
    assert module_2.__file__ == "some_module.py"

# Generated at 2022-06-26 04:06:51.573496
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "./tests/data/config.py"

    # assert statements
    assert load_module_from_file_location(location).DEBUG is True
    assert load_module_from_file_location(location).TESTING is False

# Generated at 2022-06-26 04:07:02.773167
# Unit test for function load_module_from_file_location

# Generated at 2022-06-26 04:07:08.056596
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "sanic_jwt/examples/"
    module = load_module_from_file_location(location)
    assert module
    print(module.__file__)

    location = "/Users/jonathanhilgart/Documents/GitHub/sanic-jwt/sanic_jwt/examples/"
    module = load_module_from_file_location(location)
    assert module
    print(module.__file__)


if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:07:13.589130
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A valid location that points to a python file
    valid_location = "sanic/test/test_config_test.py"

    msfl = load_module_from_file_location(valid_location)

    assert msfl.__name__ == "test_config_test"

# Generated at 2022-06-26 04:07:20.699629
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Unit test when providing a location that does not exist
    config_test = load_module_from_file_location(
        'testing', 'test/test_file_does_not_exist.py'
    )

    assert config_test.__file__ == './test/test_file_does_not_exist.py'

# Generated at 2022-06-26 04:07:25.868583
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Fill in with test inputs & expected outputs
    in0 = ''
    in1 = ''
    in2 = ''
    in3 = ''
    
    expected_out = None

    # Run function
    actual_out = load_module_from_file_location(in0, in1, in2, in3)

    # Verify
    assert expected_out == actual_out


# Generated at 2022-06-26 04:07:37.145972
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 0
    location_0 = '${HOME}/.config/sanic/.env_example'
    module_0 = load_module_from_file_location(location_0)

    expected_0 = {'good_key': 'good_value', 'key_with_spaces': 'value_with_spaces', 'key_with_dots': 'value_with_dots', 'key_with_dollar': 'value_with_dollar', 'key_with_double_quote': 'value_with_double_quote', 'key_with_single_quote': 'value_with_single_quote', 'key_with_single_quote_q': 'value_with_single_quote_q'} # noqa


# Generated at 2022-06-26 04:07:39.578202
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/adnan/Projects/sanic-decorators/tests/'
    os_environ['ENV'] = '/Users/adnan/Projects/sanic-decorators/tests/'
    load_module_from_file_location('${ENV}a.py')

# Generated at 2022-06-26 04:07:46.043859
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Case 0
    location_0 = '/some/path/some_module.py'
    load_module_from_file_location(location_0)

    # Case 1
    location_1 = '/some/path/some_module.py'
    load_module_from_file_location(location_1)

    # Case 2
    location_2 = '/some/path/some_module.py'
    load_module_from_file_location(location_2)

# Generated at 2022-06-26 04:07:53.054794
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    class_to_test = load_module_from_file_location(Path('/Users/lucaslefevre/Downloads/sanic/examples/app.py'))
    class_to_test

test_case_0()
test_load_module_from_file_location()
 

# Code coverage
## coverage html

# Generated at 2022-06-26 04:08:05.446374
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_0 = "/Users/robinluo/workplace/sanic_learn/sanic_examples/config.py"
    
    # The path parameter type is string
    result_0 = load_module_from_file_location(path_0)

    # The path parameter type is Path
    result_1 = load_module_from_file_location(Path(path_0))

    # The path parameter type is bytes
    result_2 = load_module_from_file_location(b"/Users/robinluo/workplace/sanic_learn/sanic_examples/config.py")


if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:08:09.080373
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    function_0 = load_module_from_file_location('R.@o')
    function_1 = load_module_from_file_location('R.@o')
    function_2 = load_module_from_file_location('R.@o')

if __name__ == '__main__':
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:08:13.914963
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = 'load_module_from_file_location.py'
    module = load_module_from_file_location(location)
    assert module.__name__ == 'load_module_from_file_location'

# Generated at 2022-06-26 04:08:18.857165
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    module_0 = load_module_from_file_location(str_0)

test_load_module_from_file_location()
print(load_module_from_file_location(str_0))

# Generated at 2022-06-26 04:08:26.242883
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    BASE_PATH = '/home/lefevre'
    str_0 = '${BASE_PATH}/lucas/'
    print(load_module_from_file_location(str_0))
if __name__ == '__main__':
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:08:28.990321
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    assert load_module_from_file_location(str_0) is not None

# Generated at 2022-06-26 04:08:40.486897
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import unittest
    class TestLoadModuleFromFileLocation(unittest.TestCase):
        def test_case_0(self):
            str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
            spec_0 = importlib.util.spec_from_file_location("app", str_0)
            module_0 = importlib.util.module_from_spec(spec_0)
            spec_0.loader.exec_module(module_0)  # type: ignore
            module_from_file_location = load_module_from_file_location(str_0)
            self.assertEqual(module_from_file_location, module_0)
    unittest.main()

# Generated at 2022-06-26 04:08:45.497562
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location(
        '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    )
    print("\n")


# Generated at 2022-06-26 04:08:49.918922
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    try:
        load_module_from_file_location(str_0)
    except Exception as e:
        print(e)

    str_1 = 'app'
    try:
        load_module_from_file_location(str_1)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 04:08:55.763931
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    mod = load_module_from_file_location(str_0)
    # print(mod)
    print('Test case 1 passed')


# Generated at 2022-06-26 04:09:00.854994
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        "/Users/lucaslefevre/Downloads/sanic/examples/app.py",
    )
    assert hasattr(module, 'app')
    assert callable(module.app)

# test_case_0()
# test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:04.864164
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    location = Path('/Users/lucaslefevre/Downloads/sanic/examples/app.py')
    name = location.split('/')[-1].split('.')[0]  # get just the file name without path and .py extension
    _mod_spec = spec_from_file_location(name,location)
    module = module_from_spec(_mod_spec)
    _mod_spec.loader.exec_module(module)  # type: ignore


# Generated at 2022-06-26 04:09:10.105247
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    location = load_module_from_file_location(str_0)
    print(location)


if __name__ == '__main__':
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:19.809928
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    module = load_module_from_file_location(str_0)
    print(module)
    print(module.__dict__)
    print(type(module))
    print(type(module.__dict__))

if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:09:22.243037
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    module = load_module_from_file_location(location)
    assert module.__file__ == location
    assert module.__name__ == 'app'


# Generated at 2022-06-26 04:09:28.168438
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    result = load_module_from_file_location(str_0)
    assert result.__spec__.name == 'app'


# Generated at 2022-06-26 04:09:37.405851
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # test case 1:
    str_1 = '${PWD}/examples/app.py'
    # ====== Expected Result ======
    class module_1:
        def __init__(self, name, file):
            self.__name__ = name
            self.__file__ = file
        def __repr__(self):
            return "Module({}, {})".format(self.__name__, self.__file__)

    mod_1 = module_1('app', '/Users/lucaslefevre/Downloads/sanic/examples/app.py')

    assert(load_module_from_file_location(str_1) == mod_1)

    # test case 2:
    str_2 = '${PWD}/examples/does_not_exist.py'
    #

# Generated at 2022-06-26 04:09:41.645322
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import path
    from pathlib import Path
    from os.path import join
    import cProfile
    cProfile.runctx('load_module_from_file_location(Path("./app.py"))', globals(), locals())

# Generated at 2022-06-26 04:09:46.100765
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    assert load_module_from_file_location(str_0)



# Generated at 2022-06-26 04:09:53.984788
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    str_1 = './examples/app.py'

    module = load_module_from_file_location(str_0, encoding = 'utf8')
    assert True # add assertions later
    
    module = load_module_from_file_location(str_1, encoding = 'utf8')
    assert True # add assertions later


# Generated at 2022-06-26 04:09:58.877158
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    app = load_module_from_file_location(str_0)
    assert app.Hello().__name__ == "Hello"


# Generated at 2022-06-26 04:10:06.447505
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 1
    location = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    m = load_module_from_file_location(location)
    assert m.__file__ == location

    # Test 2
    location = Path('/Users/lucaslefevre/Downloads/sanic/examples/app.py')
    m = load_module_from_file_location(location)
    assert m.__file__ == location

    # Test 3
    location = '/Users/lucaslefevre/Downloads/sanic/examples/app'
    exception_raised_0 = False
    try:
        m = load_module_from_file_location(location)
    except ValueError:
        exception_raised_0 = True
    assert exception_

# Generated at 2022-06-26 04:10:17.186590
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    # str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/config.py'
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/email.py'
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/blueprints/blueprint.py'
    # str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.saniccfg'
    # str_0 = '/Users/l

# Generated at 2022-06-26 04:10:26.744479
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    # Test case 0
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    load_module_from_file_location(str_0)

    # Test case 1
    str_1 = '/Users/lucaslefevre/Downloads/sanic/examples/'
    with pytest.raises(LoadFileException):
        load_module_from_file_location(str_1)

    # Test case 2
    str_2 = './examples/app.py'
    with pytest.raises(LoadFileException):
        load_module_from_file_location(str_2)

    # Test case 3
    str_3 = './examples/'

# Generated at 2022-06-26 04:10:36.345392
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    str_1 = 'sanic.examples.aiohttp_demo.app'
    str_2 = 'sanic.examples.asgi_demo.app'
    str_3 = 'sanic.examples.async_demo.app'
    str_4 = 'sanic.examples.async_demo_db'
    str_5 = 'sanic.examples.basic_demo.app'
    str_6 = 'sanic.examples.debug_error_handler_demo.app'
    str_7 = 'sanic.examples.error_handler_demo.app'

# Generated at 2022-06-26 04:10:44.508541
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    import inspect
    from os import environ as os_environ

    assert inspect.getfile(inspect.currentframe()) == "/Users/lucaslefevre/Downloads/sanic/sanic/loader.py"
    assert os_environ == environ
    assert {} == environ

    assert load_module_from_file_location(str_0) == module

# Generated at 2022-06-26 04:10:47.457914
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # TODO need run the test case in the terminal
    test_case_0()



# Generated at 2022-06-26 04:10:57.391054
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert str_to_bool('t')
    assert str_to_bool('y')
    assert str_to_bool('1')
    assert str_to_bool('True')
    assert str_to_bool('yes')
    assert str_to_bool('on')
    assert str_to_bool('Y')
    assert str_to_bool('T')
    assert str_to_bool('YES')
    assert str_to_bool('YEP')
    assert str_to_bool('on')
    assert str_to_bool('ON')
    assert str_to_bool('f')
    assert str_to_bool('n')
    assert str_to_bool('0')
    assert str_to_bool('false')
    assert str_to_bool('no')
    assert str_to_bool('F')


# Generated at 2022-06-26 04:11:07.845122
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    str_1 = '/Users/lucaslefevre/Downloads/sanic/sanic/request.py'
    str_2 = '/Users/lucaslefevre/Downloads/sanic-0.8.1/CHANGELOG.rst'

    location = str_0
    if isinstance(location, bytes):
        location = location.decode('utf8')


# Generated at 2022-06-26 04:11:13.643191
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(__file__).__name__ == "config_helpers"

if __name__ == "__main__":
    test_case_0()
    # test_load_module_from_file_location()

# Generated at 2022-06-26 04:11:17.610328
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os.path import join, abspath, dirname
    test_config_module_path = join(
        dirname(abspath(__file__)), "test_config.py"
    )

    assert load_module_from_file_location(test_config_module_path)



# Generated at 2022-06-26 04:11:25.877588
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 1
    str_1 = "/Users/lucaslefevre/Downloads/sanic/examples/app.py"
    load_module_from_file_location(str_1)
    # Test case 2
    str_2 = "sanic.examples.app"
    load_module_from_file_location(str_2)



# Generated at 2022-06-26 04:11:30.143382
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'

    obj_0 = load_module_from_file_location(
        str_0,
    )
    obj_1 = load_module_from_file_location(
        str_0
    )
    obj_2 = load_module_from_file_location(str_0)

    assert obj_0 is obj_1
    assert obj_1 is obj_2

# Generated at 2022-06-26 04:11:38.967390
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    # module = load_module_from_file_location(
    #     str_0
    # )
    # print(module.__dict__)
    # assert module is not None


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 04:11:48.667611
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    str_1 = 'sanic.examples.app'

    loaded_module = load_module_from_file_location(str_0)
    assert type(loaded_module) == types.ModuleType
    print(loaded_module.__name__)
    assert loaded_module.__name__ == str_1

test_load_module_from_file_location()



# Generated at 2022-06-26 04:11:52.581946
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    module_name = load_module_from_file_location(str_0)
    str_1 = 'tests.integration.test_load_module_from_file_location'
    assert module_name == str_1


# Generated at 2022-06-26 04:11:58.834081
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    old_modification_timestamp = Path(str_0).stat().st_mtimespec
    module = load_module_from_file_location(str_0)
    print(module)
    new_modification_timestamp = Path(str_0).stat().st_mtimespec
    print(old_modification_timestamp, new_modification_timestamp)
    assert(old_modification_timestamp == new_modification_timestamp)

if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:12:04.745095
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    base_path = '/Users/lucaslefevre/Downloads/sanic/'
    module_from_file_location = load_module_from_file_location(
        base_path + 'examples/app.py')
    assert module_from_file_location.__name__ == 'app'


# Generated at 2022-06-26 04:12:08.350742
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    module = load_module_from_file_location(location)
    assert module.__name__ == 'app'

if __name__  == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:12:16.815153
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    module = load_module_from_file_location(str_0)
    print(f'module.__file__: {module.__file__}')
    print(f'module.__package__: {module.__package__}')
    print(f'module.__name__: {module.__name__}')


if __name__ == '__main__':
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:12:27.716313
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        '/Users/lucaslefevre/Downloads/sanic/examples/app.py')
    assert module
    assert module.__file__ == '/Users/lucaslefevre/Downloads/sanic/examples/app.py'


# Generated at 2022-06-26 04:12:30.024701
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 0
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    expected_result = str_0
    actual_result = load_module_from_file_location(str_0).__file__
    assert expected_result == actual_result


test_load_module_from_file_location()

# Generated at 2022-06-26 04:12:39.239854
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Prepare environment.
    os_environ['TEST_LOAD_MODULE_0'] = '/tmp/test_load_module_0.py'
    os_environ['TEST_LOAD_MODULE_1'] = '/tmp/test_load_module_1.py'
    os_environ['TEST_LOAD_MODULE_2'] = '/tmp/test_load_module_2.py'

    # Prepare data for test.
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    str_1 = '/tmp/test_load_module_0.py'
    str_2 = './examples/static_file.py'
    str_3 = '${TEST_LOAD_MODULE_0}'

# Generated at 2022-06-26 04:12:47.476184
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 0
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    mod = load_module_from_file_location(str_0)
    assert type(mod) == type(types.ModuleType('a'))


# Generated at 2022-06-26 04:12:53.174853
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    module_0 = load_module_from_file_location(file_0)
    function_0 = module_0.app
    assert type(function_0) == types.FunctionType

if __name__ == "__main__":

    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:13:00.921272
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_string('app')
    #load_module_from_file_location('app')
    # some_module = load_module_from_file_location(
    #    "some_module_name",
    #    "/some/path/${some_env_var}"
    # )


if __name__ == "__main__":
    test_load_module_from_file_location()


"""

"""

# Generated at 2022-06-26 04:13:11.320685
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 1)
    module = load_module_from_file_location(
        '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    )
    assert(module)

    # 2)
    module = load_module_from_file_location(
        '/Users/lucaslefevre/Downloads/sanic/examples/app.py',
        *[], **{}
    )
    assert(module)


# Generated at 2022-06-26 04:13:24.412978
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test_case 0
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    mod = load_module_from_file_location(str_0)
    assert(mod.app.app == None)

    # Test_case 1
    str_1 = 'sanic.app'
    mod = load_module_from_file_location(str_1)
    assert(mod == sanic.app)

    # Test_case 2
    str_2 = 'sanic'
    mod = load_module_from_file_location(str_2)
    assert(mod == sanic)

    # Test_case 3
    #str_3 = '$HOME/Downloads/sanic/examples/app.py'
    #mod = load_module_from

# Generated at 2022-06-26 04:13:36.082843
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Pass
    val = load_module_from_file_location(
        "/Users/lucaslefevre/Downloads/sanic/examples/app.py")
    assert type(val) == module
    assert str(val.__file__) == '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    assert val.__name__ == 'app'

    # Fail
    # val = load_module_from_file_location(
    #     "Users/lucaslefevre/Downloads/sanic/examples/app.py")

if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:13:41.136586
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    module = load_module_from_file_location(
        location
    )
    assert module.__name__ == '__main__'

# Generated at 2022-06-26 04:13:43.856873
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    module = load_module_from_file_location(str_0)
    print(module)

if __name__ == "__main__":
    print("Sanic/helpers.py")
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:13:50.771049
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(__file__) is __import__(__name__)
    print("test_load_module_from_file_location OK")

if __name__ == '__main__':
    test_load_module_from_file_location()
    test_case_0()

# Generated at 2022-06-26 04:14:00.225668
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    module = load_module_from_file_location(str_0)
    assert type(module) == types.ModuleType

    str_1 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    module = load_module_from_file_location(str_1)
    assert type(module) == types.ModuleType

    str_2 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    module = load_module_from_file_location(str_2)
    assert type(module) == types.ModuleType


# Generated at 2022-06-26 04:14:06.699366
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    load_module_from_file

# Generated at 2022-06-26 04:14:14.218965
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_0 = load_module_from_file_location("/Users/lucaslefevre/Downloads/sanic/examples/app.py")
    assert module_0.__file__ == '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    assert module_0.__name__ == 'app'
    assert module_0.__package__ == 'examples'
    assert module_0.__spec__.name == 'app'
    assert module_0.__spec__.loader.name == 'app'
    assert module_0.__spec__.loader.path == '/Users/lucaslefevre/Downloads/sanic/examples/app.py'

# Generated at 2022-06-26 04:14:22.366970
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    mod_0 = load_module_from_file_location(str_0)
    print(mod_0.app)
    print(mod_0.app.get('/'))
    print(mod_0.app.listeners)
    print(mod_0.app.router.routes_all)
    print(mod_0.app.run)
    print(mod_0.__file__)
    print(mod_0.__name__)
    print(mod_0.__path__)

# Generated at 2022-06-26 04:14:27.781229
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    try:
        load_module_from_file_location(str_0)
    except:
        pass



# Generated at 2022-06-26 04:14:32.472950
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
        load_module_from_file_location(str_0)
        assert True
    except Exception:
        assert False

if __name__ == '__main__':
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:14:33.241997
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import numpy

# Generated at 2022-06-26 04:14:42.700418
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location(
            "some_module_name",
            "/some/path/${some_env_var}",
        )
    except LoadFileException as e:
        assert (
            str(e)
            == "The following environment variables are not set: some_env_var"
        )

    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    try:
        load_module_from_file_location(str_0)
    except Exception as e:
        assert(str(e) == 'Unable to load configuration file (e.strerror)')

# Generated at 2022-06-26 04:14:43.132568
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass



# Generated at 2022-06-26 04:14:54.100317
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_0 = '/Users/lucaslefevre/Downloads/sanic/examples/app.py'
    str_1 = '/Users/lucaslefevre/Downloads/sanic/examples/skeleton.py'
    str_2 = '/Users/lucaslefevre/Downloads/sanic/examples/return_bytes.py'
    str_3 = '/Users/lucaslefevre/Downloads/sanic/examples/mock_server.py'
    str_4 = '/Users/lucaslefevre/Downloads/sanic/examples/proxy_server.py'
    str_5 = '/Users/lucaslefevre/Downloads/sanic/examples/uvloop_server.py'

# Generated at 2022-06-26 04:15:01.414997
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    config_module = load_module_from_file_location(str_0)
    # module = importlib.util.module_from_spec(spec)
    # spec.loader.exec_module(module)
    print(config_module)

if __name__ == "__main__":
    # test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:15:09.300931
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_0 = ''
    mod_0 = load_module_from_file_location(path_0)


if __name__ == "__main__":
    test_case_0()
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:15:12.398851
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test case 0
    str_0 = 'R.@o'
    bool_0 = load_module_from_file_location(location=str_0)

# Generated at 2022-06-26 04:15:16.645721
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    loaction = './config.py'
    load_module_from_file_location(loaction)

if __name__ == '__main__':
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:15:22.400589
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = Path(__file__).resolve()
    module = load_module_from_file_location(location)
    assert module.__name__ == "helpers" and module.__file__ == str(location)

if __name__ == '__main__':
    test_load_module_from_file_location()

# Generated at 2022-06-26 04:15:35.506825
# Unit test for function load_module_from_file_location

# Generated at 2022-06-26 04:15:43.400268
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    #
    assert load_module_from_file_location(location="a") == types.ModuleType("a")
    assert load_module_from_file_location(
        location="${a}"
    ) == types.ModuleType("config")
    assert load_module_from_file_location(location="${a}") == types.ModuleType(
        "config"
    )