

# Generated at 2022-06-18 06:12:22.916844
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test with file path.
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("a = 1")
        temp.flush()
        module = load_module_from_file_location(temp.name)
        assert module.a == 1

    # B) Test with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("a = 1")
        temp.flush()
        os_environ["TEMP_FILE_PATH"] = temp.name
        module = load_module_from_file_location("${TEMP_FILE_PATH}")
        assert module.a == 1

    # C) Test with bytes.

# Generated at 2022-06-18 06:12:30.653667
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-18 06:12:41.653918
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import remove as os_remove
    from os import mkdir as os_mkdir
    from os import rmdir as os_rmdir
    from os import path as os_path
    from tempfile import mkdtemp as tempfile_mkdtemp
    from tempfile import mkstemp as tempfile_mkstemp
    from shutil import rmtree as shutil_rmtree

    # A) Test if function works with bytes type.
    #    Create temporary file with some content.
    temp_dir = tempfile_mkdtemp()
    temp_file_path = os_path.join(temp_dir, "temp_file.py")
    temp_file = open(temp_file_path, "w")

# Generated at 2022-06-18 06:12:49.045566
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if module was loaded correctly.
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        temp_file = temp_dir / "temp_file.py"
        temp_file.write_text("some_var = 'some_value'")
        os.environ["TEMP_DIR"] = str(temp_dir)
        module = load_module_from_file_location(
            "${TEMP_DIR}/temp_file.py"
        )
        assert module.some_var == "some_value"



# Generated at 2022-06-18 06:13:00.340477
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["SOME_ENV_VAR"] = "some_value"
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("some_variable = 'some_value'")
        tmp_file.seek(0)
        module = load_module_from_file_location(
            tmp_file.name, "/some/path/${SOME_ENV_VAR}"
        )
    assert module.some_variable == "some_value"

    # A) Check if location contains any environment variables
    #    in

# Generated at 2022-06-18 06:13:11.312884
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-18 06:13:16.740110
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-18 06:13:26.080729
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-18 06:13:35.621861
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    This function tests load_module_from_file_location function.
    """
    import os
    import tempfile

    # A) Test with a file path.
    # A.1) Test with a file path with a .py extension.
    with tempfile.TemporaryDirectory() as tmpdirname:
        file_path = os.path.join(tmpdirname, "some_file.py")
        with open(file_path, "w") as file:
            file.write("some_var = 'some_value'")
        module = load_module_from_file_location(file_path)
        assert module.some_var == "some_value"

    # A.2) Test with a file path without a .py extension.

# Generated at 2022-06-18 06:13:44.079552
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("TEST_VAR = 'test_var'")
        tmp_file.seek(0)
        module = load_module_from_file_location(
            tmp_file.name, "/some/path/${TEST_ENV_VAR}"
        )
        assert module.TEST_VAR == "test_var"

    # A) Check if location contains any environment

# Generated at 2022-06-18 06:13:55.495373
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var_value"
    module = load_module_from_file_location(
        "test_module", "${TEST_ENV_VAR}/test_module.py"
    )
    assert module.test_var == "test_var_value"
    del os_environ["TEST_ENV_VAR"]

    # B) Check these variables exists in environment.

# Generated at 2022-06-18 06:14:05.441837
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.NamedTemporaryFile() as f:
        f.write(b"TEST_VAR = 'test_var'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.TEST_VAR == "test_var"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute

# Generated at 2022-06-18 06:14:15.017847
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_value"
    location = "some_module_name"
    assert load_module_from_file_location(location)

    # B) Check these variables exists in environment.
    location = "some_module_name"
    assert load_module_from_file_location(location)

    # C) Substitute them in location.
    location = "some_module_name"
    assert load_module_from_file_location(location)

    # D) Check if location is of a bytes type.
    location = b"some_module_name"
    assert load_module_from_file_location(location)

    # E)

# Generated at 2022-06-18 06:14:25.145387
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["test_env_var"] = "test_env_var_value"
    location = "test_location/${test_env_var}"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert env_vars_in_location == {"test_env_var"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:14:33.180815
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    location = "test_module_name"
    module = load_module_from_file_location(
        location, "/some/path/${TEST_ENV_VAR}/test_module_name.py"
    )
    assert module.__name__ == "test_module_name"
    assert module.__file__ == "/some/path/test_env_var/test_module_name.py"

    # B) Check these variables exists in environment.

# Generated at 2022-06-18 06:14:43.264592
# Unit test for function load_module_from_file_location

# Generated at 2022-06-18 06:14:49.629748
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("test_var = 'test_value'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.test_var == "test_value"

    # B) Test if function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("test_var = 'test_value'")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name

# Generated at 2022-06-18 06:14:58.988209
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with environment variables.
    #    Create temporary file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("test_var = 'test_value'")
        temp.flush()

        # Set environment variable.
        os.environ["TEMP_FILE_PATH"] = temp.name

        # Load module from file location with environment variable.
        module = load_module_from_file_location(
            "${TEMP_FILE_PATH}",
            "test_module",
        )

        # Check if module was loaded correctly.
        assert module.test_var == "test_value"

    # B) Test with Path object.
    #    Create temporary file with environment variables.

# Generated at 2022-06-18 06:15:08.791963
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # Test 1
    # Test if function can load module from file location
    # and return it.
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("some_var = 'some_val'")
        temp.seek(0)
        module = load_module_from_file_location(temp.name)
        assert module.some_var == "some_val"

    # Test 2
    # Test if function can load module from file location
    # and return it.
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("some_var = 'some_val'")
        temp.seek(0)
        module = load_module_from_file_location(temp.name)

# Generated at 2022-06-18 06:15:20.064154
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with NamedTemporaryFile("w") as temp_file:
        temp_file.write("test_var = 'test'")
        temp_file.flush()
        os_environ["TEST_VAR"] = "test"
        module = load_module_from_file_location(
            f"{temp_file.name}",
            f"{temp_file.name}/${TEST_VAR}",
        )
        assert module.test_var == "test"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.

# Generated at 2022-06-18 06:15:30.951178
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Test with file path
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("test_var = 'test'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.test_var == "test"

    # Test with file path and environment variables
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("test_var = 'test'")
        f.seek(0)
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}",
        )

# Generated at 2022-06-18 06:15:41.013430
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location, path)
    assert module.__name__ == location
    assert module.__file__ == path
    assert module.__package__ == "some_module_name"
    assert module.__spec__.name == location
    assert module.__spec__.origin == path
    assert module.__spec__.loader.name == location
    assert module.__spec__.loader.path == path
    assert module.__spec__.loader.package == "some_module_name"

# Generated at 2022-06-18 06:15:46.908659
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    os.environ["some_env_var"] = "some_value"
    os.environ["some_env_var2"] = "some_value2"

    with tempfile.NamedTemporaryFile(mode="w") as f:
        f.write("some_var = 'some_value'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    with tempfile.NamedTemporaryFile(mode="w") as f:
        f.write("some_var = 'some_value'")
        f.flush()
        module = load_module_from_file_location(f.name, "some_module_name")

# Generated at 2022-06-18 06:15:58.065540
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    assert (
        set(re_findall(r"\${(.+?)}", "/some/path/${some_env_var}"))
        == {"some_env_var"}
    )

    # B) Check these variables exists in environment.
    assert set({"some_env_var"}).difference(os_environ.keys()) == set()

    # C) Substitute them in location.
    assert (
        "/some/path/${some_env_var}".replace("${some_env_var}", os_environ["some_env_var"])
        == "/some/path/some_env_var_value"
    )

    # D) Check if location contains any environment variables
    #    in

# Generated at 2022-06-18 06:16:05.898876
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("TEST_VAR = 'test_var_value'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.TEST_VAR == "test_var_value"


# Generated at 2022-06-18 06:16:15.046948
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test if function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # C) Test if function can load module from file with environment variables.

# Generated at 2022-06-18 06:16:24.138900
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove
    from os import mkdir as os_mkdir
    from os import rmdir as os_rmdir

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with TemporaryDirectory() as tmpdirname:
        os_environ["TEST_ENV_VAR"] = tmpdirname
        os_mkdir(os_path.join(tmpdirname, "test_dir"))

# Generated at 2022-06-18 06:16:33.711107
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import os
    import tempfile

    # A) Test if function can load module from file.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / "tmp_file.py"
        with open(tmp_file, "w") as f:
            f.write("some_var = 'some_val'")
        module = load_module_from_file_location(tmp_file)
        assert module.some_var == "some_val"

    # B) Test if function can load module from file with environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_

# Generated at 2022-06-18 06:16:43.593665
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create temporary file
    temp_file = os.path.join(temp_dir, "temp_file.py")
    with open(temp_file, "w") as f:
        f.write("a = 1")
    # Create temporary module
    temp_module = os.path.join(temp_dir, "temp_module")
    os.mkdir(temp_module)
    temp_module_file = os.path.join(temp_module, "__init__.py")
    with open(temp_module_file, "w") as f:
        f.write("b = 2")
    # Add temporary directory to sys.path

# Generated at 2022-06-18 06:16:54.022061
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    location = "/some/path/${some_env_var}"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert env_vars_in_location == {"some_env_var"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:17:04.607779
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var_value"
    location = "test_location/${TEST_ENV_VAR}"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert env_vars_in_location == {"TEST_ENV_VAR"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:17:15.302534
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test that function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("test_var = 'test'")
        temp.seek(0)
        module = load_module_from_file_location(temp.name)
        assert module.test_var == "test"

    # B) Test that function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("test_var = 'test'")
        temp.seek(0)
        os.environ["TEST_ENV_VAR"] = temp.name

# Generated at 2022-06-18 06:17:23.979625
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import os
    import tempfile
    import shutil
    import importlib
    import pytest

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=tmp_dir, delete=False
    )

    # Write some content to temporary file
    tmp_file.write("some_var = 'some_value'")

    # Close temporary file
    tmp_file.close()

    # Get temporary file path
    tmp_file_path = tmp_file.name

    # Get temporary file name
    tmp_file_name = os.path.basename(tmp_file_path)

    # Get temporary file name without extension
    tmp_file_name_without_ext

# Generated at 2022-06-18 06:17:34.735923
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test if function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test if function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        os_environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location("${TEST_ENV_VAR}")
        assert module.a == 1

    #

# Generated at 2022-06-18 06:17:44.748134
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables
    # A.1) Test with environment variables in format ${some_env_var}
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        module = load_module_from_file_location(
            "test_module", "${TEST_ENV_VAR}/test_module.py"
        )
        assert module.__file__ == os.path.join(tmpdirname, "test_module.py")

    # A.2) Test with environment variables in format $some_env_var
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        module = load

# Generated at 2022-06-18 06:17:53.260398
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import os
    import tempfile
    import shutil

    # A) Test with file path.
    # A.1) Test with file path without environment variables.
    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("TEST_VAR = 'test_value'")

    module = load_module_from_file_location(tmp_file)
    assert module.TEST_VAR == "test_value"
    shutil.rmtree(tmp_dir)

    # A.2) Test with file path with environment variables.
    tmp_dir = tempfile.mkdtemp

# Generated at 2022-06-18 06:18:05.586098
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # Create temporary file
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, "w") as tmp:
        tmp.write("test_var = 'test_value'")

    # Test loading module from file
    module = load_module_from_file_location(path)
    assert module.test_var == "test_value"

    # Test loading module from file with environment variables
    os.environ["TEST_ENV_VAR"] = "test_env_value"
    module = load_module_from_file_location(f"{path}${TEST_ENV_VAR}")
    assert module.test_var == "test_value"

    # Test loading module from file with environment variables
    # that are not set

# Generated at 2022-06-18 06:18:14.828983
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove
    from os import mkdir as os_mkdir
    from os import rmdir as os_rmdir
    from os import getcwd as os_getcwd
    from os import chdir as os_chdir
    from os import getenv as os_getenv
    from os import putenv as os_putenv
    from os import unsetenv as os_unsetenv
    from os import listdir as os_listdir
    from os import pardir as os_pardir
    from os import devnull as os_devnull
    from os import fdopen as os_fdopen
    from os import close as os_close
    from os import fsync as os_fsync
    from os import fch

# Generated at 2022-06-18 06:18:22.169698
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    env_vars_in_location = set(re_findall(r"\${(.+?)}", "some_module_name"))
    assert env_vars_in_location == set()

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not_defined_env_vars == set()

    # C) Substitute them in location.
    location = "some_module_name"
    for env_var in env_vars_in_location:
        location = location.replace("${" + env_var + "}", os_environ[env_var])

# Generated at 2022-06-18 06:18:32.288203
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if function can load module from file.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file, "w") as f:
            f.write("var = 'test'")
        module = load_module_from_file_location(tmp_file)
        assert module.var == "test"

    # B) Test if function can load module from file with environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file, "w") as f:
            f.write("var = 'test'")
       

# Generated at 2022-06-18 06:18:47.349323
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Test with file path.
    # A.1) Test with file path with environment variables.
    # A.1.1) Test with file path with environment variables
    #        that are not set.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file, "w") as f:
            f.write("a = 1")
        os.environ["TEST_ENV_VAR"] = "test_env_var"

# Generated at 2022-06-18 06:18:54.381504
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Test with file path
    # A.1) Test with file path with .py extension
    # A.1.1) Test with file path with .py extension and without environment variables
    with tempfile.TemporaryDirectory() as tmpdirname:
        test_file_path = os.path.join(tmpdirname, "test_file.py")
        with open(test_file_path, "w") as test_file:
            test_file.write("test_var = 'test_value'")
        test_module = load_module_from_file_location(test_file_path)
        assert test_module.test_var == "test_value"

    # A.1.2) Test with file path with .py extension and with environment variables

# Generated at 2022-06-18 06:19:03.364640
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from os import environ as os_environ

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    location = "${some_env_var}/some/path/some_file.py"
    assert load_module_from_file_location(location)

    # B) Check these variables exists in environment.
    location = "${some_env_var}/some/path/${some_env_var_2}/some_file.py"
    try:
        load_module_from_file_location(location)
    except LoadFileException:
        pass
    else:
        raise AssertionError("Should raise LoadFileException")

    # C)

# Generated at 2022-06-18 06:19:14.074485
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test loading module from file path.
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        temp_file_path = temp_dir / "temp_file.py"
        temp_file_path.touch()

        module = load_module_from_file_location(temp_file_path)
        assert module.__file__ == str(temp_file_path)

    # B) Test loading module from file path with environment variables.
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        temp_file_path = temp_dir / "temp_file.py"
        temp_file_path.touch()

        os_environ["TEMP_DIR"] = str(temp_dir)

# Generated at 2022-06-18 06:19:21.167783
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from a file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("a = 1")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test if function can load module from a file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("a = 1")
        f.seek(0)
        os.environ["TEST_ENV_VAR"] = f.name

# Generated at 2022-06-18 06:19:28.615004
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location, path)
    assert module.__name__ == location
    assert module.__file__ == path
    del os_environ["some_env_var"]

# Generated at 2022-06-18 06:19:35.797880
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Create temporary file with some content
    with tempfile.NamedTemporaryFile(mode="w+", delete=False) as f:
        f.write("some_var = 'some_value'")
        f.close()
        # Load module from temporary file
        module = load_module_from_file_location(f.name)
        # Check if module has some_var variable
        assert module.some_var == "some_value"
        # Remove temporary file
        os.unlink(f.name)

# Generated at 2022-06-18 06:19:43.468093
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with tempfile.TemporaryDirectory() as tmp_dir:
        os.environ["TEST_ENV_VAR"] = tmp_dir
        with open(os.path.join(tmp_dir, "test_file.py"), "w") as f:
            f.write("test_var = 'test_value'")
        module = load_module_from_file_location(
            "test_file", "${TEST_ENV_VAR}/test_file.py"
        )
        assert module.test_var == "test_value"

    # A) Check if location

# Generated at 2022-06-18 06:19:53.125498
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from string.
    module = load_module_from_file_location("types")
    assert module.ModuleType is types.ModuleType

    # B) Test if function can load module from bytes.
    module = load_module_from_file_location(b"types", encoding="utf8")
    assert module.ModuleType is types.ModuleType

    # C) Test if function can load module from pathlib.Path.
    module = load_module_from_file_location(Path("types"))
    assert module.ModuleType is types.ModuleType

    # D) Test if function can load module from pathlib.Path.
    module = load_module_from_file_location(Path("types"))
    assert module.ModuleType is types.ModuleType

    # E) Test

# Generated at 2022-06-18 06:19:59.061564
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Create temporary file
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, "w") as tmp:
        tmp.write("a = 1")
    # Load module from temporary file
    module = load_module_from_file_location(path)
    # Check if module is loaded correctly
    assert module.a == 1
    # Remove temporary file
    os.remove(path)



# Generated at 2022-06-18 06:20:10.794364
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    location = "test_location/${TEST_ENV_VAR}"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert env_vars_in_location == {"TEST_ENV_VAR"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:20:22.002998
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if location is of a string type.
    # E) Check if location is of a bytes type.
    # F) Check if location is of a Path type.
    # G) Check if location is of a Path type.
    # H) Check if location is of a Path type.
    # I) Check if location is of a Path type.
    # J) Check if location is of a Path type.
    # K) Check if location is of a Path type.
    # L) Check if location is of a Path type.
    # M) Check if location is of a Path type.
    #

# Generated at 2022-06-18 06:20:31.449495
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from os.path import join
    from tempfile import TemporaryDirectory

    from sanic.config import Config

    # A) Test with string
    # A.1) Test with string that contains environment variables
    #      in format ${some_env_var}.
    environ["some_env_var"] = "some_value"
    with TemporaryDirectory() as temp_dir:
        temp_dir_path = Path(temp_dir)
        temp_file_path = temp_dir_path / "some_file.py"
        temp_file_path.touch()
        temp_file_path.write_text("some_var = 'some_value'")


# Generated at 2022-06-18 06:20:42.153412
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("test_var = 'test_var'")
        f.flush()
        module = load_module_from_file_location(
            f"{f.name}", "/some/path/${TEST_ENV_VAR}"
        )
        assert module.test_var == "test_var"

    # A) Check if location contains any environment variables
    #    in format ${some_

# Generated at 2022-06-18 06:20:51.249390
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("test_var = 'test_value'")
        tmp_file.seek(0)
        module = load_module_from_file_location(
            tmp_file.name,
            "/some/path/${TEST_ENV_VAR}",
        )
        assert module.test_var == "test_value"

    # If location is of a bytes type

# Generated at 2022-06-18 06:21:00.251498
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create temporary file
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("test_var = 'test_value'")

    # Test loading module from file
    module = load_module_from_file_location(tmp_file)
    assert module.test_var == "test_value"

    # Test loading module from file with environment variables
    os.environ["TEST_ENV_VAR"] = tmp_dir

# Generated at 2022-06-18 06:21:11.215627
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from os import environ as os_environ
    from os import remove as os_remove

    # Test 1:
    # Check if function can load module from file.
    with NamedTemporaryFile(
        mode="w", suffix=".py", delete=False
    ) as temp_file:
        temp_file.write("test_var = 'test_value'")
        temp_file.close()
        module = load_module_from_file_location(temp_file.name)
        assert module.test_var == "test_value"
        os_remove(temp_file.name)

    # Test 2:
    # Check if function can load module from file with environment variables.

# Generated at 2022-06-18 06:21:18.510910
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function."""
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    location = "some_module_name"
    location_with_env_var = "some_module_name_${TEST_ENV_VAR}"

    # B) Check these variables exists in environment.
    not_defined_env_vars = set(re_findall(r"\${(.+?)}", location_with_env_var))
    not_defined_env_vars = not_defined_env_vars.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute

# Generated at 2022-06-18 06:21:29.977020
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if it can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # B) Test if it can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        os.environ["TEST_ENV_VAR"] = f.name

# Generated at 2022-06-18 06:21:37.782685
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil
    import sys

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w", dir=tmp_dir, suffix=".py", delete=False
    )

    # Write some content to temporary file
    tmp_file.write("some_var = 'some_value'")
    tmp_file.close()

    # Add temporary directory to sys.path
    sys.path.append(tmp_dir)

    # Load module
    module = load_module_from_file_location(tmp_file.name)

    # Check if module has attribute some_var
    assert hasattr(module, "some_var")

    # Check if module.some_var is equal to

# Generated at 2022-06-18 06:21:52.723003
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from file location.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # B) Test if function can load module from file location
    #    with environment variables in it.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_

# Generated at 2022-06-18 06:22:01.150968
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # A) Test with file path.
    #    Create temporary directory.
    temp_dir = tempfile.mkdtemp()
    #    Create temporary file.
    temp_file = tempfile.NamedTemporaryFile(
        mode="w+", suffix=".py", dir=temp_dir, delete=False
    )
    #    Write some content to it.
    temp_file.write("some_var = 'some_value'")
    temp_file.close()
    #    Load module from this file.
    module = load_module_from_file_location(temp_file.name)
    #    Check that module has attribute 'some_var' with value 'some_value'.
    assert hasattr(module, "some_var")
    assert module

# Generated at 2022-06-18 06:22:08.759604
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if it can load module from file.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # B) Test if it can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name