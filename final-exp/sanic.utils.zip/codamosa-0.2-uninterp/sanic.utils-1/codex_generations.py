

# Generated at 2022-06-18 06:12:20.705350
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["some_env_var"] = "some_value"
    location = "/some/path/${some_env_var}"
    assert location.replace(
        "${some_env_var}", os.environ["some_env_var"]
    ) == "/some/path/some_value"

    # D) Check if location is of a bytes type.
    location = b"/some/path/some_value"
    assert isinstance(location, bytes)

    # E) Check if location is of a string type.
    location = "/some/path/some_value"

# Generated at 2022-06-18 06:12:29.264898
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""
    from tempfile import TemporaryDirectory
    from os import environ as os_environ
    from os.path import join as os_path_join

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with TemporaryDirectory() as tmp_dir:
        os_environ["TEST_ENV_VAR"] = tmp_dir
        location = os_path_join(tmp_dir, "test_file.py")
        with open(location, "w") as test_file:
            test_file.write("test_var = 'test_value'")

# Generated at 2022-06-18 06:12:40.899935
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys
    import tempfile
    import unittest

    from sanic.exceptions import LoadFileException

    class TestLoadModuleFromFileLocation(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.TemporaryDirectory()
            self.temp_dir_path = Path(self.temp_dir.name)
            self.temp_file_path = self.temp_dir_path / "test_file.py"

            self.temp_file_path.touch()

            self.temp_file_path.write_text(
                text="""
                TEST_VAR = "test_value"
                """
            )

        def tearDown(self):
            self.temp_dir.cleanup()


# Generated at 2022-06-18 06:12:50.997658
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test loading module from file path.
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
        tmp_file = tmpdirname / "tmp_file.py"
        tmp_file.write_text("some_var = 'some_value'")
        module = load_module_from_file_location(tmp_file)
        assert module.some_var == "some_value"

    # B) Test loading module from file path with environment variables.
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
        tmp_file = tmpdirname / "tmp_file.py"
        tmp_file.write_text("some_var = 'some_value'")

# Generated at 2022-06-18 06:13:01.604881
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ as os_environ
    from os import remove
    from os import makedirs
    from os import path as os_path
    from tempfile import mkdtemp
    from tempfile import NamedTemporaryFile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if location is of a Path type.
    # E) Check if location is of a bytes type.
    # F) Check if location is of a string type.
    # G) Check if location is of a string type and contains .py extension.
    # H) Check if location is of a string type and does not contain .py
    #    extension.
    # I) Check

# Generated at 2022-06-18 06:13:12.373004
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("tmp_variable = 'tmp_value'")

    # Create temporary module
    tmp_module = os.path.join(tmp_dir, "tmp_module.py")
    with open(tmp_module, "w") as f:
        f.write("tmp_variable = 'tmp_value'")

    # Create temporary package
    tmp_package = os.path.join(tmp_dir, "tmp_package")
    os.mkdir(tmp_package)
    tmp_package

# Generated at 2022-06-18 06:13:22.984882
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w") as temp:
        temp.write("a = 1")
        temp.flush()
        module = load_module_from_file_location(temp.name)
        assert module.a == 1

    # B) Test if function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w") as temp:
        temp.write("a = 1")
        temp.flush()
        os.environ["TEMP_FILE_NAME"] = temp.name
        module = load_module_from_file_location(
            "${TEMP_FILE_NAME}"
        )  # noqa
        assert module.a == 1

    # C) Test

# Generated at 2022-06-18 06:13:26.553038
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("some_var = 'some_value'")
        tmp_file.flush()
        module = load_module_from_file_location(tmp_file.name)
        assert module.some_var == "some_value"

# Generated at 2022-06-18 06:13:36.175431
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Test 1:
    # Test if function can load module from file.
    # Create temporary file with some content.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.some_var == 1

    # Test 2:
    # Test if function can load module from file with environment variables.
    # Create temporary file with some content.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 1")
        f.flush()
        # Set environment variable.

# Generated at 2022-06-18 06:13:44.443477
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with file path.
    with tempfile.NamedTemporaryFile(mode="w+", delete=False) as f:
        f.write("test_var = 'test_value'")
    try:
        module = load_module_from_file_location(f.name)
        assert module.test_var == "test_value"
    finally:
        os.remove(f.name)

    # B) Test with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", delete=False) as f:
        f.write("test_var = 'test_value'")

# Generated at 2022-06-18 06:13:56.395598
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    location = "./tests/test_config_files/${TEST_ENV_VAR}/test_config.py"
    module = load_module_from_file_location(location)
    assert module.TEST_CONFIG_VAR == "test_config_var"
    del os_environ["TEST_ENV_VAR"]

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Subst

# Generated at 2022-06-18 06:14:05.801438
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    from os import environ
    from os.path import dirname, join
    from tempfile import TemporaryDirectory

    from pytest import raises

    # A) Test that it can load module from file.
    #    We will use here some_module.py file from this directory.
    #    We will load it as some_module_name.
    #    We will check that it has some_var variable with value some_value.
    some_module = load_module_from_file_location(
        join(dirname(__file__), "some_module.py"), "some_module_name"
    )
    assert some_module.some_var == "some_value"

    # B) Test that it can load module from file with environment variables.
    #    We

# Generated at 2022-06-18 06:14:15.092232
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    env_vars_in_location = set(re_findall(r"\${(.+?)}", "some/path/${some_env_var}"))
    assert env_vars_in_location == {"some_env_var"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not_defined_env_vars == set()

    # C) Substitute them in location.
    location = "some/path/${some_env_var}"

# Generated at 2022-06-18 06:14:25.181389
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with environment variables in location.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        location = "${TEST_ENV_VAR}/test_module.py"
        with open(location, "w") as f:
            f.write("test_var = 'test_value'")
        module = load_module_from_file_location(location)
        assert module.test_var == "test_value"

    # B) Test with location as bytes.
    with tempfile.TemporaryDirectory() as tmpdirname:
        location = os.path.join(tmpdirname, "test_module.py")
        with open(location, "w") as f:
            f

# Generated at 2022-06-18 06:14:33.294953
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Test 1:
    # Test if function can load module from file location.
    # Create temporary file with some content.
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        f.write("some_var = 'some_value'")

    # Load module from this file.
    module = load_module_from_file_location(f.name)

    # Check if module has attribute some_var with value 'some_value'.
    assert module.some_var == "some_value"

    # Remove temporary file.
    os.remove(f.name)

    # Test 2:
    # Test if function can load module from file location
    # with environment variables in it.
    # Create temporary file with some content.

# Generated at 2022-06-18 06:14:43.409337
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("a = 1")

    # Create temporary file with environment variables
    tmp_file_with_env_vars = os.path.join(tmp_dir, "tmp_file_with_env_vars.py")
    with open(tmp_file_with_env_vars, "w") as f:
        f.write("b = 2")

    # Create temporary file with environment variables

# Generated at 2022-06-18 06:14:49.761003
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    location_with_env_var = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location_with_env_var)
    assert module.__file__ == "/some/path/some_env_var_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Subst

# Generated at 2022-06-18 06:14:57.753743
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    module = load_module_from_file_location(
        "test_module_name", "/some/path/${TEST_ENV_VAR}"
    )
    assert module.__file__ == "/some/path/test_env_var"
    assert module.__name__ == "test_module_name"
    del os_environ["TEST_ENV_VAR"]

# Generated at 2022-06-18 06:15:07.620983
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os_environ["TEST_ENV_VAR"] = tmpdirname
        location = "./${TEST_ENV_VAR}/test_file.py"
        module = load_module_from_file_location(location)
        assert module.__file__ == os_environ["TEST_ENV_VAR"] + "/test_file.py"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C)

# Generated at 2022-06-18 06:15:18.099734
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["some_env_var"] = "some_value"
    location = "some_module_name"
    location_with_env_var = "/some/path/${some_env_var}"
    assert (
        load_module_from_file_location(location_with_env_var)
        == load_module_from_file_location(location)
    )
    del os.environ["some_env_var"]

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B)

# Generated at 2022-06-18 06:15:28.531915
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(mode="w+", dir=tmp_dir, delete=False)
    tmp_file.write("some_var = 'some_value'")
    tmp_file.close()

    # Create temporary file with .py extension
    tmp_file_py = tempfile.NamedTemporaryFile(
        mode="w+", dir=tmp_dir, suffix=".py", delete=False
    )
    tmp_file_py.write("some_var = 'some_value'")
    tmp_file_py.close()

    # Create temporary file with .py extension

# Generated at 2022-06-18 06:15:38.131510
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Create temporary file with some content.
    some_content = "some_content"
    with tempfile.NamedTemporaryFile(mode="w+", delete=False) as f:
        f.write(some_content)
        f.seek(0)
        f.close()

    # B) Check that we can load this file.
    module = load_module_from_file_location(f.name)
    assert module.__file__ == f.name
    assert module.__name__ == "config"
    assert module.__doc__ == some_content

    # C) Check that we can load this file with some environment variables.
    os.environ["some_env_var"] = f.name

# Generated at 2022-06-18 06:15:45.013588
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with file path.
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmp_file_path = os.path.join(tmpdirname, "tmp_file.py")
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("some_var = 'some_value'")

        module = load_module_from_file_location(tmp_file_path)
        assert module.some_var == "some_value"

    # B) Test with environment variable in file path.
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmp_file_path = os.path.join(tmpdirname, "tmp_file.py")

# Generated at 2022-06-18 06:15:55.666733
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test for location parameter of a string type.
    # A.1) Test for location parameter with environment variables.
    os_environ["some_env_var"] = "some_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    assert module.__file__ == "/some/path/some_value"
    del os_environ["some_env_var"]

    # A.2) Test for location parameter without environment variables.
    module = load_module_from_file_location(
        "some_module_name", "/some/path/some_value"
    )
    assert module.__file__ == "/some/path/some_value"

    # B) Test for location parameter of a bytes type.

# Generated at 2022-06-18 06:16:03.850195
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    test_config = """
    TEST_CONFIG_VAR = "test_config_var_value"
    """
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmp_config_file = os.path.join(tmpdirname, "test_config.py")
        with open(tmp_config_file, "w") as f:
            f.write(test_config)

# Generated at 2022-06-18 06:16:14.068225
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with file path.
    # A.1) Test with file path without environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file, "w") as f:
            f.write("a = 1")
        module = load_module_from_file_location(tmp_file)
        assert module.a == 1

    # A.2) Test with file path with environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "tmp_file.py")

# Generated at 2022-06-18 06:16:22.971697
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # A) Test if it works with string.
    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("a = 1")
    sys.path.append(tmp_dir)
    module = load_module_from_file_location(tmp_file)
    assert module.a == 1
    shutil.rmtree(tmp_dir)

    # B) Test if it works with Path.
    tmp_dir = tempfile.mkdtemp()
    tmp_file = Path(os.path.join(tmp_dir, "tmp_file.py"))

# Generated at 2022-06-18 06:16:32.408906
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os_environ["TEST_ENV_VAR"] = tmpdirname
        location = f"${TEST_ENV_VAR}/test.py"
        module = load_module_from_file_location(location)
        assert module.__file__ == f"{tmpdirname}/test.py"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.

# Generated at 2022-06-18 06:16:42.588481
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("test_var = 'test_var'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.test_var == "test_var"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C

# Generated at 2022-06-18 06:16:52.477322
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    from os import environ
    from tempfile import NamedTemporaryFile

    # Test with environment variables.
    with NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("some_var = 'some_value'")
        temp_file.seek(0)
        environ["TEST_ENV_VAR"] = temp_file.name
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}",
            encoding="utf8",
            loader=None,
            origin=None,
        )
        assert module.some_var == "some_value"

    # Test with Path object.

# Generated at 2022-06-18 06:17:04.337628
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ as os_environ
    from os import remove as os_remove
    from os import system as os_system
    from os import path as os_path
    from tempfile import mkstemp as tempfile_mkstemp
    from tempfile import mkdtemp as tempfile_mkdtemp
    from shutil import rmtree as shutil_rmtree

    # Create temporary directory
    tmp_dir = tempfile_mkdtemp()

    # Create temporary file
    tmp_file_path = os_path.join(tmp_dir, "tmp_file.py")
    tmp_file = open(tmp_file_path, "w")
    tmp_file.write("TEST_VAR = 'test_value'")
    tmp_file.close()

    # Create temporary file with environment variables


# Generated at 2022-06-18 06:17:14.927149
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w", dir=tmp_dir, suffix=".py", delete=False
    )
    tmp_file.write("some_var = 'some_value'")
    tmp_file.close()

    # Create temporary environment variable
    os.environ["TEST_ENV_VAR"] = tmp_dir

    # Test load_module_from_file_location
    module = load_module_from_file_location(
        f"${TEST_ENV_VAR}/{tmp_file.name.split('/')[-1]}"
    )

# Generated at 2022-06-18 06:17:23.736930
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with file path
    # A.1) Test with file path without environment variables
    file_path = tempfile.mkstemp()[1]
    with open(file_path, "w") as f:
        f.write("a = 1")
    module = load_module_from_file_location(file_path)
    assert module.a == 1
    os.remove(file_path)

    # A.2) Test with file path with environment variables
    file_path = tempfile.mkstemp()[1]
    with open(file_path, "w") as f:
        f.write("a = 1")
    os.environ["file_path"] = file_path
    module = load_module_from_file_location("${file_path}")


# Generated at 2022-06-18 06:17:34.457598
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["some_env_var"] = "some_value"
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.flush()
        module = load_module_from_file_location(
            f.name, "/some/path/${some_env_var}"
        )
        assert module.some_var == "some_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables

# Generated at 2022-06-18 06:17:44.494718
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_env_var_value"
    assert (
        load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var}"
        )
        == "some_env_var_value"
    )

    # B) Check these variables exists in environment.
    assert (
        load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var}"
        )
        == "some_env_var_value"
    )

    # C) Substitute them in location.

# Generated at 2022-06-18 06:17:53.104426
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil
    import sys

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    sys.path.append(tmp_dir)
    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w+", suffix=".py", dir=tmp_dir, delete=False
    )
    # Write some content to temporary file
    tmp_file.write("some_var = 'some_value'")
    tmp_file.close()
    # Get temporary file name
    tmp_file_name = tmp_file.name
    # Get temporary file name without extension
    tmp_file_name_without_ext = tmp_file_name.split(".")[0]
    # Get temporary file name without extension and path
    tmp_file_name

# Generated at 2022-06-18 06:18:05.585634
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from file path.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("test_var = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.test_var == 1

    # B) Test if function can load module from file path with environment
    #    variables in format ${some_env_var}.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("test_var = 1")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name

# Generated at 2022-06-18 06:18:14.838259
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import os
    import tempfile

    # A) Test if function works with bytes location.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file_path = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("test_var = 'test_value'")

        module = load_module_from_file_location(
            tmp_file_path.encode("utf8"), encoding="utf8"
        )
        assert module.test_var == "test_value"

    # B) Test if function works with string location.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file

# Generated at 2022-06-18 06:18:22.159565
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test for function load_module_from_file_location.
    """
    import os
    import tempfile

    # A) Test with pathlib.Path
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmp_file_path = Path(tmpdirname) / "test_file.py"
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("test_var = 'test_value'")

        module = load_module_from_file_location(tmp_file_path)
        assert module.test_var == "test_value"

    # B) Test with string
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmp_file_path = Path(tmpdirname) / "test_file.py"

# Generated at 2022-06-18 06:18:32.287829
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test if function can load module from file path.
    module = load_module_from_file_location(
        "tests/test_configs/test_config.py"
    )
    assert module.TEST_CONFIG_VARIABLE == "test_config_value"

    # B) Test if function can load module from environment variable.
    os_environ["TEST_ENV_VAR"] = "tests/test_configs/test_config.py"
    module = load_module_from_file_location(
        "${TEST_ENV_VAR}"
    )
    assert module.TEST_CONFIG_VARIABLE == "test_config_value"

    # C) Test if function can load module from file path with environment
    #    variable in it.
    module = load_

# Generated at 2022-06-18 06:18:48.267920
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("test_var = 'test_value'")
        f.seek(0)
        module = load_module_from_file_location(
            f"${TEST_ENV_VAR}/{f.name}",
        )
        assert module.test_var == "test_value"

    # B) Test with Path object.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("test_var = 'test_value'")
        f

# Generated at 2022-06-18 06:18:54.901170
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    # Test 1
    # Test if function can load module from file path
    # and if it can load module from file path containing environment variables.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    module = load_module_from_file_location(
        "test_module", "tests/test_module.py"
    )
    assert module.test_var == "test_var_value"
    module = load_module_from_file_location(
        "test_module", "tests/${TEST_ENV_VAR}/test_module.py"
    )
    assert module.test_var == "test_var_value"
    del os.environ["TEST_ENV_VAR"]

    # Test 2
    # Test if function

# Generated at 2022-06-18 06:19:03.898613
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir_path = Path(tmp_dir)
        tmp_file_path = tmp_dir_path / "tmp_file.py"
        os.environ["TMP_ENV_VAR"] = str(tmp_dir_path)
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("TMP_VAR = 1")


# Generated at 2022-06-18 06:19:14.601907
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["SOME_ENV_VAR"] = "some_value"
    location = "${SOME_ENV_VAR}/some/path/some_module_name.py"
    assert "some_value" in location

    # B) Check these variables exists in environment.
    assert "SOME_ENV_VAR" in os.environ.keys()

    # C) Substitute them in location.
    location = location.replace("${SOME_ENV_VAR}", os.environ["SOME_ENV_VAR"])
    assert "some_value" in location

    # D) Check if location is of a string type.

# Generated at 2022-06-18 06:19:21.486354
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove
    from os import mkdir as os_mkdir
    from os import rmdir as os_rmdir
    from tempfile import mkdtemp as tempfile_mkdtemp

    from sanic.exceptions import LoadFileException

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if location is a path to a file.
    # E) Check if location is a path to a directory.
    # F) Check if location is a path to a file with .py extension.
    # G) Check if location is a path to a file without .py

# Generated at 2022-06-18 06:19:32.651076
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test if function works with string path.
    assert load_module_from_file_location(
        "tests/test_utils/test_config.py"
    ).TEST_CONFIG_VARIABLE == "test_config_value"

    # B) Test if function works with bytes path.
    assert load_module_from_file_location(
        b"tests/test_utils/test_config.py"
    ).TEST_CONFIG_VARIABLE == "test_config_value"

    # C) Test if function works with pathlib.Path path.
    assert load_module_from_file_location(
        Path("tests/test_utils/test_config.py")
    ).TEST_CONFIG_VARIABLE == "test_config_value"

    # D) Test if function works

# Generated at 2022-06-18 06:19:41.593608
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables.
    #    Create temporary file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        f.write("TEST_ENV_VAR = 'some_value'")

    #    Set environment variable.
    os.environ["TEST_ENV_VAR"] = "some_value"

    #    Load module from file location with environment variable.
    module = load_module_from_file_location(f.name)

    #    Check that module has TEST_ENV_VAR attribute.
    assert hasattr(module, "TEST_ENV_VAR")

    #    Check that module has TEST_ENV_VAR attribute with value "some_value".

# Generated at 2022-06-18 06:19:50.827437
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with file path
    with tempfile.NamedTemporaryFile() as f:
        f.write(b"test_var = 'test_value'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.test_var == "test_value"

    # B) Test with environment variables
    with tempfile.NamedTemporaryFile() as f:
        f.write(b"test_var = 'test_value'")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location("${TEST_ENV_VAR}")
        assert module.test_var == "test_value"

    # C

# Generated at 2022-06-18 06:20:00.472953
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", dir=temp_dir, delete=False
    )

    # Write some content to temporary file
    temp_file.write("a = 1")
    temp_file.close()

    # Load module from temporary file
    module = load_module_from_file_location(temp_file.name)

    # Check if module has attribute a
    assert hasattr(module, "a")

    # Check if module.a is equal to 1
    assert module.a == 1

    # Remove temporary directory
    shutil.rmtree(temp_dir)

    # Create temporary directory

# Generated at 2022-06-18 06:20:08.997803
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import tempfile
    import os
    import shutil
    import sys

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["SOME_ENV_VAR"] = "some_env_var_value"
    temp_dir = tempfile.mkdtemp()
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", dir=temp_dir, suffix=".py", delete=False
    )
    temp_file.write("SOME_VAR = 'some_var_value'")
    temp_file.close()
    temp_file_path = Path

# Generated at 2022-06-18 06:20:25.421398
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove
    from tempfile import mkstemp

    # A) Test with a file path.
    # A.1) Test with a file path without environment variables.
    # A.1.1) Test with a file path with .py extension.
    # A.1.1.1) Test with a file path with .py extension and with
    #          a module name.
    # A.1.1.2) Test with a file path with .py extension and without
    #          a module name.
    # A.1.2) Test with a file path without .py extension.
    # A.1.2.1) Test with a file path

# Generated at 2022-06-18 06:20:32.858147
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ as os_environ
    from os import remove
    from os import path as os_path
    from tempfile import NamedTemporaryFile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_env_var_value"
    with NamedTemporaryFile(mode="w", suffix=".py") as temp_file:
        temp_file.write("some_var = 'some_value'")
        temp_file.flush()
        module = load_module_from_file_location(
            temp_file.name, "/some/path/${some_env_var}"
        )


# Generated at 2022-06-18 06:20:38.768540
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile(mode="w", suffix=".py") as tmp_file:
        tmp_file.write("test_var = 'test_value'")
        tmp_file.flush()
        module = load_module_from_file_location(tmp_file.name)
        assert module.test_var == "test_value"

# Generated at 2022-06-18 06:20:48.162195
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Tests function load_module_from_file_location.
    """
    import os
    import tempfile
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    test_config_file_name = "test_config_file.py"
    test_config_file_content = "test_config_file_content"
    test_config_file_path = os.path.join(
        tempfile.gettempdir(), test_config_file_name
    )

# Generated at 2022-06-18 06:20:54.875746
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    assert (
        load_module_from_file_location(
            "test_module_name", "/some/path/${TEST_ENV_VAR}"
        ).__file__
        == "/some/path/test_env_var"
    )
    del os_environ["TEST_ENV_VAR"]

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.

# Generated at 2022-06-18 06:21:05.429096
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["SOME_ENV_VAR"] = "some_env_var"
    assert (
        load_module_from_file_location(
            "some_module_name", "/some/path/${SOME_ENV_VAR}"
        ).__file__
        == "/some/path/some_env_var"
    )

    # B) Check these variables exists in environment.
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "some_module_name", "/some/path/${SOME_ENV_VAR_NOT_DEFINED}"
        )

    # C) Substitute them in

# Generated at 2022-06-18 06:21:13.724687
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test if function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # B) Test if function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.flush()
        os_environ["some_env_var"] = f.name
        module = load_module_from_file_location(
            "/some/path/${some_env_var}"
        )

# Generated at 2022-06-18 06:21:23.570661
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location, path)
    assert module.__name__ == location
    assert module.__file__ == path

    # B) Check these variables exists in environment.
    del os_environ["some_env_var"]
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location, path)

    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    module = load_

# Generated at 2022-06-18 06:21:33.608408
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = os.path.join(temp_dir, "temp_file.py")
    with open(temp_file, "w") as f:
        f.write("a = 1")

    # Create temporary file with environment variables
    temp_file_with_env_vars = os.path.join(temp_dir, "temp_file_with_env_vars.py")
    with open(temp_file_with_env_vars, "w") as f:
        f.write("b = 1")

    # Create temporary file with environment variables

# Generated at 2022-06-18 06:21:41.355060
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "test_file.py")
        with open(tmp_file, "w") as f:
            f.write("TEST_VAR = 'test_var'")
        module = load_module_from_file_location(tmp_file)
        assert module.TEST_VAR == "test_var"

        tmp_file = os.path

# Generated at 2022-06-18 06:22:02.019956
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        tmp_dir_path = Path(tmp_dir)
        tmp_file_path = tmp_dir_path / "tmp_file.py"
        tmp_file_path.touch()

        # A) Check if location contains any environment variables
        #    in format ${some_env_var}.
        env_var_name = "TEST_ENV_VAR"
        env_var_value = "test_env_var_value"
        os_environ[env_var_name] = env_var_value
        location = str(tmp_file_path) + "${" + env_var_name + "}"
        module = load_module_from_file_location(location)
        assert module.__file__ == str(tmp_file_path)

# Generated at 2022-06-18 06:22:09.660737
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_value"
    os.environ["some_env_var2"] = "some_value2"
    os.environ["some_env_var3"] = "some_value3"
    os.environ["some_env_var4"] = "some_value4"

    # B) Check these variables exists in environment.
    location = "/some/path/${some_env_var}/${some_env_var2}/${some_env_var3}/${some_env_var4}"
    module = load_module_from_file_location(location)
    assert module.__file__