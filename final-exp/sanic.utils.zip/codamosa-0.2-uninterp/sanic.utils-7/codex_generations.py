

# Generated at 2022-06-18 06:12:22.245925
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w", dir=tmp_dir, delete=False
    )

    # Write some content to temporary file
    tmp_file.write("some_var = 'some_value'")
    tmp_file.close()

    # Load module from temporary file
    module = load_module_from_file_location(tmp_file.name)

    # Check if module has attribute some_var
    assert hasattr(module, "some_var")

    # Check if module.some_var has value 'some_value'
    assert getattr(module, "some_var") == "some_value"

    # Remove temporary directory
    shut

# Generated at 2022-06-18 06:12:30.277889
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import sys

    # Test 1.
    # Test if function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # Test 2.
    # Test if function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name

# Generated at 2022-06-18 06:12:41.372190
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if location is of a Path type.
    # E) Check if location is of a bytes type.
    # F) Check if location is of a string type.
    # G) Check if location is of a string type and contains .py extension.
    # H) Check if location is of a string type and does not contain .py extension.
    # I) Check if location is of a string type and does not contain .py extension.
    # J) Check if location is of a string type and does not contain .py extension.
    # K) Check if location is of a string type and does

# Generated at 2022-06-18 06:12:48.904896
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import os
    import tempfile
    import shutil
    import pytest
    from pathlib import Path

    # Create temporary directory
    tmp_dir = Path(tempfile.mkdtemp())

    # Create temporary file
    tmp_file = tmp_dir / "tmp_file.py"
    tmp_file.touch()

    # Create temporary module
    tmp_module = tmp_dir / "tmp_module.py"
    tmp_module.write_text("test = 'test'")

    # Create temporary module with environment variable
    tmp_module_with_env_var = tmp_dir / "tmp_module_with_env_var.py"
    tmp_module_with_env_var.write_text("test = '${TEST_ENV_VAR}'")

    # Create temporary module with environment variable in

# Generated at 2022-06-18 06:13:00.302914
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    location_with_env_var = f"/some/path/${{some_env_var}}"
    assert (
        load_module_from_file_location(location_with_env_var).__file__
        == f"/some/path/{os_environ['some_env_var']}/{location}.py"
    )

    # B) Check these variables exists in environment.
    location_with_not_defined_env_var = f"/some/path/${{some_not_defined_env_var}}"

# Generated at 2022-06-18 06:13:11.268279
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import path as os_path
    from tempfile import TemporaryDirectory

    from sanic.exceptions import LoadFileException, PyFileError

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        os_environ["TEST_ENV_VAR"] = str(tmp_dir)
        tmp_file = tmp_dir / "test_file.py"
        tmp_file.touch()
        tmp_file.write_text("test_var = 'test_value'")


# Generated at 2022-06-18 06:13:21.796429
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with file path.
    with tempfile.TemporaryDirectory() as tmpdirname:
        # A.1) Test with file path and environment variables.
        os.environ["TEST_ENV_VAR"] = tmpdirname
        module = load_module_from_file_location(
            "test_module", "${TEST_ENV_VAR}/test_module.py"
        )
        assert module.__file__ == os.path.join(tmpdirname, "test_module.py")
        assert module.__name__ == "test_module"
        assert module.TEST_VAR == "test_value"

        # A.2) Test with file path and no environment variables.

# Generated at 2022-06-18 06:13:28.120246
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    location = "some_module_name"
    location_with_env_var = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location_with_env_var)
    assert module.__name__ == location
    assert module.__file__ == location_with_env_var.replace(
        "${some_env_var}", os_environ["some_env_var"]
    )

    # A) Check

# Generated at 2022-06-18 06:13:37.822216
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # A) Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # B) Create temporary file
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("some_var = 1")

    # C) Create temporary environment variable
    os.environ["TMP_ENV_VAR"] = tmp_dir

    # D) Run function
    module = load_module_from_file_location(
        "tmp_file", "${TMP_ENV_VAR}", "utf8"
    )

    # E) Check result
    assert module.some_var == 1

    # F) Cleanup
    shutil.rmt

# Generated at 2022-06-18 06:13:45.533694
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        config_file = temp_dir / "config.py"
        config_file.write_text(
            """
            TEST_VAR = "test_value"
            """
        )
        module = load_module_from_file_location(config_file)
        assert module.TEST_VAR == "test_value"

        config_file = temp_dir / "config.json"
        config_file.write_text(
            """
            {
                "TEST_VAR": "test_value"
            }
            """
        )
        module = load_module_from_file_location(config_file)
        assert module.__file__ == str(config_file)

       

# Generated at 2022-06-18 06:13:59.472842
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with bytes location.
    # A.1) Test with valid location.
    # A.1.1) Test with valid location and valid encoding.
    # A.1.1.1) Test with valid location and valid encoding and valid module.
    # Create temporary file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as temp:
        temp.write("test_var = 'test_value'")
        temp.seek(0)
        # Get its name.
        temp_file_name = temp.name
        # Get its path.
        temp_file_path = os.path.dirname(temp_file_name)
        # Get its name without extension.
        temp_file_name_without_ext = os.path.splitext

# Generated at 2022-06-18 06:14:06.945528
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location, path)
    assert module.__file__ == "/some/path/some_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    location

# Generated at 2022-06-18 06:14:15.746624
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove
    from os import mkdir as os_mkdir
    from os import rmdir as os_rmdir
    from tempfile import mkdtemp as tempfile_mkdtemp
    from tempfile import mkstemp as tempfile_mkstemp

    # A) Test with file path.
    # A.1) Test with file path with environment variables.
    # A.1.1) Test with file path with environment variables
    #        which are not set.
    # A.1.1.1) Test with file path with environment variables
    #          which are not set and with .py extension.
    # A.1.1.1

# Generated at 2022-06-18 06:14:24.110949
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary file
    f = open(os.path.join(tmpdir, "test.py"), "w")
    f.write("test_var = 'test'")
    f.close()

    # Load module from file
    module = load_module_from_file_location(os.path.join(tmpdir, "test.py"))

    # Check if module was loaded correctly
    assert module.test_var == "test"

    # Remove temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-18 06:14:29.928037
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location, path)
    assert module.__file__ == "/some/path/some_value"

    # B) Check these variables exists in environment.
    not_defined_env_var = "not_defined_env_var"
    location = "some_module_name"
    path = "/some/path/${not_defined_env_var}"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location, path)

    # C

# Generated at 2022-06-18 06:14:39.825556
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    # Test 1:
    # Check if function raises LoadFileException when
    # environment variable is not set.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("${some_env_var}")

    # Test 2:
    # Check if function raises LoadFileException when
    # environment variable is not set.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("/some/path/${some_env_var}")

    # Test 3:
    # Check if function raises LoadFileException when
    # environment variable is not set.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("/some/path/${some_env_var}/some_file.py")

   

# Generated at 2022-06-18 06:14:47.329526
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    temp_dir_path = Path(temp_dir)

    # Create temporary module
    temp_module_name = "temp_module"
    temp_module_path = temp_dir_path / f"{temp_module_name}.py"
    temp_module_path.touch()
    temp_module_path.write_text(
        text="""
        some_var = "some_value"
        """
    )

    # Create temporary module with environment variables
    temp_module_with_env_vars_name = "temp_module_with_env_vars"

# Generated at 2022-06-18 06:14:57.116188
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test loading module from file.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test loading module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}"
        )  # type: ignore
        assert module.a == 1

    # C)

# Generated at 2022-06-18 06:15:07.329851
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if it works with string.
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("a = 1")
        tmp_file.seek(0)
        module = load_module_from_file_location(tmp_file.name)
        assert module.a == 1

    # B) Test if it works with Path.
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("a = 1")
        tmp_file.seek(0)
        module = load_module_from_file_location(Path(tmp_file.name))
        assert module.a == 1

    # C) Test if it works with bytes.

# Generated at 2022-06-18 06:15:17.675670
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import remove as os_remove
    from os import path as os_path
    from tempfile import NamedTemporaryFile as NamedTemporaryFile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with NamedTemporaryFile(mode="w+", suffix=".py") as temp_file:
        temp_file.write("TEST_VAR = 'test_var'")
        temp_file.seek(0)
        os_environ["TEST_ENV_VAR"] = os_path.dirname(temp_file.name)

# Generated at 2022-06-18 06:15:30.920480
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # A) Test with file path.
    # A.1) Test with .py file.
    # A.1.1) Test with file path with environment variables.
    # A.1.1.1) Test with file path with environment variables
    #          that are not set.
    # A.1.1.1.1) Test with file path with environment variables
    #            that are not set and with file that does not exist.
    # A.1.1.1.2) Test with file path with environment variables
    #            that are not set and with file that exists.
    # A.1.1.2) Test with file path with environment variables
    #          that are set.
    # A.1.1.2.1) Test with file path with environment variables
    #

# Generated at 2022-06-18 06:15:40.980061
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w+", dir=tmp_dir, suffix=".py"
    )
    # Write some content to temporary file
    tmp_file.write("some_var = 'some_value'")
    # Close temporary file
    tmp_file.close()

    # Get path to temporary file
    tmp_file_path = tmp_file.name

    # Load module from temporary file
    module = load_module_from_file_location(tmp_file_path)

    # Check that module has some_var variable
    assert hasattr(module, "some_var")

    # Check that some_var variable has correct

# Generated at 2022-06-18 06:15:46.890210
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove
    from tempfile import mkstemp as tempfile_mkstemp

    # Create temporary file
    fd, path = tempfile_mkstemp()
    with open(fd, "w") as tmp:
        tmp.write("TEST_VAR = 'test'")

    # Test if module is loaded
    module = load_module_from_file_location(path)
    assert module.TEST_VAR == "test"

    # Test if module is loaded with environment variable
    os_environ["TEST_ENV_VAR"] = "test"

# Generated at 2022-06-18 06:15:58.065620
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # A) Create temporary directory.
    temp_dir = tempfile.mkdtemp()

    # B) Create temporary file in this directory.
    temp_file = tempfile.NamedTemporaryFile(
        mode="w+", dir=temp_dir, delete=False
    )

    # C) Write some content to this file.
    temp_file.write("test_var = 'test_value'")
    temp_file.close()

    # D) Load this file as a module.
    module = load_module_from_file_location(temp_file.name)

    # E) Check if module has attribute test_var.
    assert hasattr(module, "test_var")

    # F) Check if this attribute has value 'test_value'.
    assert getattr

# Generated at 2022-06-18 06:16:05.936729
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    from pathlib import Path
    from os import environ as os_environ

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["SOME_ENV_VAR"] = "some_value"
    location = "some_module_name"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert not env_vars_in_location

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:16:15.082435
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Tests for function load_module_from_file_location.
    """
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location, path)
    assert module.__name__ == location
    assert module.__file__ == path
    del os_environ["some_env_var"]

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables

# Generated at 2022-06-18 06:16:24.138087
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    location = "some_module_name"
    _mod_spec = spec_from_file_location(
        location, "/some/path/${TEST_ENV_VAR}"
    )
    assert _mod_spec.name == "some_module_name"
    assert _mod_spec.origin == "/some/path/test_env_var"

    # B) Check these variables exists in environment.
    not_defined_env_vars = {"TEST_ENV_VAR"}.difference(os.environ.keys())
    assert not not_defined_env_vars

# Generated at 2022-06-18 06:16:33.710048
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from os import environ

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    environ["TEST_ENV_VAR"] = "test_env_var"
    location = "${TEST_ENV_VAR}/test_location"
    assert load_module_from_file_location(location) == "test_env_var/test_location"

    # B) Check these variables exists in environment.
    location = "${TEST_ENV_VAR}/test_location"
    assert load_module_from_file_location(location) == "test_env_var/test_location"

    # C) Substitute them in location.

# Generated at 2022-06-18 06:16:43.605432
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    module = load_module_from_file_location(
        "test_module_name", "/some/path/${TEST_ENV_VAR}"
    )
    assert module.__name__ == "test_module_name"
    assert module.__file__ == "/some/path/test_env_var"
    del os_environ["TEST_ENV_VAR"]

    # B) Check these variables exists in environment.

# Generated at 2022-06-18 06:16:54.021818
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function.
    """
    import tempfile

    # A) Test if it works with string path.
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("test_var = 'test'")
        temp.seek(0)
        module = load_module_from_file_location(temp.name)
        assert module.test_var == "test"

    # B) Test if it works with Path path.
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("test_var = 'test'")
        temp.seek(0)
        module = load_module_from_file_location(Path(temp.name))
        assert module.test_var == "test"

    #

# Generated at 2022-06-18 06:17:11.507680
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # A) Test if function can load module from a file.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file, "w") as f:
            f.write("a = 1")

        module = load_module_from_file_location(tmp_file)
        assert module.a == 1

    # B) Test if function can load module from a file with environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file, "w") as f:
            f.write("a = 1")



# Generated at 2022-06-18 06:17:21.681258
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from file location.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.seek(0)
        assert load_module_from_file_location(f.name).a == 1

    # B) Test if function can load module from file location with environment
    #    variables in format ${some_env_var}.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.seek(0)
        os.environ["TEST_ENV_VAR"] = f.name
        assert load_module_from_file_location(
            "${TEST_ENV_VAR}"
        ).a

# Generated at 2022-06-18 06:17:31.680193
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests load_module_from_file_location function."""
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var_value"
    module = load_module_from_file_location(
        "test_module", "/some/path/${TEST_ENV_VAR}"
    )
    assert module.__file__ == "/some/path/test_env_var_value"

    # B) Check these variables exists in environment.
    os_environ.pop("TEST_ENV_VAR")

# Generated at 2022-06-18 06:17:42.255917
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=temp_dir, delete=False
    )
    temp_file.write("some_var = 'some_value'")
    temp_file.close()

    # Create temporary file with environment variable
    temp_file_with_env_var = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=temp_dir, delete=False
    )
    temp_file_with_env_var.write("some_var = 'some_value'")
    temp_file_with_env_var.close()

    # Create temporary file

# Generated at 2022-06-18 06:17:47.968361
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Test with environment variables
    #    in format ${some_env_var}.
    #    Mark that $some_env_var will not be resolved as environment variable.
    #    Mark that environment variables are not resolved in location
    #    if they are not in format ${some_env_var}.
    #    Mark that if environment variable is not set,
    #    then LoadFileException will be raised.
    #    Mark that if environment variable is set,
    #    then it will be resolved in location.
    #    Mark that if environment variable is set,
    #    then it will be resolved in location
    #    even if it is not in format ${some_env_var}.
    #    Mark that if environment variable is set,
    #    then it will be resolved in location


# Generated at 2022-06-18 06:17:54.333932
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=tmp_dir, delete=False
    )

    # Write to temporary file
    tmp_file.write("some_var = 'some_val'")
    tmp_file.close()

    # Test load_module_from_file_location
    module = load_module_from_file_location(tmp_file.name)
    assert module.some_var == "some_val"

    # Remove temporary directory
    shutil.rmtree(tmp_dir)



# Generated at 2022-06-18 06:18:05.757982
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # Create temporary directory
    tmp_dir_path = tempfile.mkdtemp()

    # Create temporary file
    tmp_file_path = os.path.join(tmp_dir_path, "tmp_file.py")
    with open(tmp_file_path, "w") as tmp_file:
        tmp_file.write("a = 1")

    # Create temporary environment variable
    os.environ["TMP_ENV_VAR"] = tmp_dir_path

    # Test load_module_from_file_location
    module = load_module_from_file_location(tmp_file_path)
    assert module.a == 1


# Generated at 2022-06-18 06:18:15.005543
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # Test 1
    # Test if function can load module from file location
    # with environment variables in it.
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
        os_environ["TEST_ENV_VAR"] = str(tmpdirname)
        test_file = tmpdirname / "test_file.py"
        test_file.touch()
        test_file.write_text("test_var = 'test_value'")
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}/test_file.py"
        )
        assert module.test_var == "test_value"

    # Test 2
    # Test if function can load module from file location
    # with environment variables

# Generated at 2022-06-18 06:18:22.483764
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    # Add it to the system path
    sys.path.append(temp_dir)

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=temp_dir, delete=False
    )
    temp_file.write("a = 1")
    temp_file.close()

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=temp_dir, delete=False
    )
    temp_file.write("b = 2")
    temp_file.close()

    # Create temporary file
    temp_file = tempfile

# Generated at 2022-06-18 06:18:32.837688
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # Test 1
    # A) Create temporary file.
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as temp:
        temp.write("TEST_VAR = 'test'")
        temp_file_path = temp.name

    # B) Load module from this file.
    module = load_module_from_file_location(temp_file_path)

    # C) Check that module has TEST_VAR variable.
    assert module.TEST_VAR == "test"

    # D) Delete temporary file.
    os.remove(temp_file_path)

    # Test 2
    # A) Create temporary file.

# Generated at 2022-06-18 06:18:55.629814
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with file path
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("TEST_VAR = 'test'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.TEST_VAR == "test"

    # B) Test with environment variables
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("TEST_VAR = 'test'")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name

# Generated at 2022-06-18 06:19:05.334799
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["SOME_ENV_VAR"] = "some_env_var_value"
    location = "some_module_name"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert not env_vars_in_location

    # B) Check these variables exists in environment.
    location = "some_module_name"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    not_defined_env_vars = env_vars_in_location.difference(os.environ.keys())

# Generated at 2022-06-18 06:19:15.362550
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with file path.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as tmp_file:
        tmp_file.write("test_var = 'test_value'")
        tmp_file.flush()
        module = load_module_from_file_location(tmp_file.name)
        assert module.test_var == "test_value"

    # B) Test with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as tmp_file:
        tmp_file.write("test_var = 'test_value'")
        tmp_file.flush()
        os.environ["TEST_ENV_VAR"] = tmp_file.name
        module = load_module_from

# Generated at 2022-06-18 06:19:21.848298
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test that function can load module from file.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file, "w") as f:
            f.write("a = 1")
        module = load_module_from_file_location(tmp_file)
        assert module.a == 1

    # B) Test that function can load module from file with environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file, "w") as f:
            f.write("a = 1")

# Generated at 2022-06-18 06:19:33.507866
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
        tmp_file = tmpdirname / "tmp_file.py"
        tmp_file.write_text("a = 1")
        module = load_module_from_file_location(tmp_file)
        assert module.a == 1

        tmp_file = tmpdirname / "tmp_file.py"
        tmp_file.write_text("a = 2")
        module = load_module_from_file_location(str(tmp_file))
        assert module.a == 2

        tmp_file = tmpdirname / "tmp_file.py"
        tmp_file.write_text("a = 3")
        module = load_module_from_file_location(bytes(tmp_file))


# Generated at 2022-06-18 06:19:41.956490
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import pytest

    # Test 1
    # Test if function can load module from file location
    # with environment variables in it.
    # Set environment variable.
    os_environ["TEST_ENV_VAR"] = "test_env_var_value"
    # Create module file.
    module_file_path = Path(__file__).parent / "test_module.py"
    with open(module_file_path, "w") as module_file:
        module_file.write("TEST_VAR = 'test_var_value'")
    # Load module.

# Generated at 2022-06-18 06:19:51.397602
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=tmp_dir, delete=False
    )

    # Write some content to temporary file
    tmp_file.write("a = 1\n")
    tmp_file.write("b = 2\n")
    tmp_file.write("c = 3\n")
    tmp_file.close()

    # Test load_module_from_file_location
    module = load_module_from_file_location(tmp_file.name)
    assert module.a == 1
    assert module.b == 2
    assert module.c == 3

    # Remove temporary directory

# Generated at 2022-06-18 06:20:00.981528
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import tempfile

    # A) Test if function raises LoadFileException
    #    when environment variable is not set.
    with tempfile.TemporaryDirectory() as temp_dir:
        with open(temp_dir + "/some_file.py", "w") as some_file:
            some_file.write("SOME_VAR = 'some_value'")

        try:
            load_module_from_file_location(
                temp_dir + "/some_file.py",
                "${SOME_ENV_VAR}/${SOME_OTHER_ENV_VAR}",
            )
        except LoadFileException:
            pass
        else:
            raise AssertionError("LoadFileException not raised.")

    # B) Test if function

# Generated at 2022-06-18 06:20:09.507732
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location, path)
    assert module.__name__ == "some_module_name"
    assert module.__file__ == "/some/path/some_value"
    del os_environ["some_env_var"]

    # B) Check these variables exists in environment.
    location = "some_module_name"
    path = "/some/path/${some_env_var}"

# Generated at 2022-06-18 06:20:14.951083
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with environment variables.
    # A.1) Create temporary file.
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("some_var = 'some_value'")
        temp.seek(0)

        # A.2) Set environment variable.
        os.environ["TEST_ENV_VAR"] = temp.name

        # A.3) Test.
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}",
            # location,
            # encoding="utf8",
            # *args,
            # **kwargs
        )

        assert module.some_var == "some_value"

    # B) Test with pathlib.Path.
    # B

# Generated at 2022-06-18 06:20:33.584139
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function.
    """
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(mode="w", dir=tmp_dir, delete=False)
    tmp_file.write("test_var = 'test'")
    tmp_file.close()

    # Create temporary environment variable
    os.environ["TEST_ENV_VAR"] = tmp_dir

    # Test load_module_from_file_location function

# Generated at 2022-06-18 06:20:44.214322
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables.
    #    Create temporary file.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        # Write some content to it.
        f.write("some_var = 'some_value'")
        # Save file name.
        file_name = f.name
        # Close file.
        f.close()

        # Create environment variable.
        os.environ["some_env_var"] = file_name

        # Load module from file location.
        module = load_module_from_file_location(
            "${some_env_var}", encoding="utf8"
        )

        # Check if module has some_var attribute.
        assert hasattr(module, "some_var")
        # Check if some_var attribute

# Generated at 2022-06-18 06:20:52.497033
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function raises LoadFileException
    #    when environment variable is not set.
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, "config.py"), "w") as f:
            f.write("SOME_VAR = 'some_val'")

        os.environ["SOME_ENV_VAR"] = tmpdirname

# Generated at 2022-06-18 06:20:58.900885
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = os.path.join(tmp_dir, "tmp.py")
    with open(tmp_file, "w") as f:
        f.write("a = 1")

    # Load module from file
    module = load_module_from_file_location(tmp_file)
    assert module.a == 1

    # Remove temporary directory
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 06:21:09.909484
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if it works with string.
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        f.write("a = 1")
    try:
        module = load_module_from_file_location(f.name)
        assert module.a == 1
    finally:
        os.remove(f.name)

    # B) Test if it works with Path.
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        f.write("b = 2")
    try:
        module = load_module_from_file_location(Path(f.name))
        assert module.b == 2
    finally:
        os.remove(f.name)

    # C) Test if it works with bytes

# Generated at 2022-06-18 06:21:15.852317
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests load_module_from_file_location function."""
    import os
    import tempfile

    # Test 1:
    # Test if function raises LoadFileException
    # if location contains environment variable
    # which is not set.
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmp_file_path = os.path.join(tmpdirname, "tmp_file.py")
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("some_var = 'some_val'")

        os.environ["TEST_ENV_VAR"] = "test_env_var_val"
        location = os.path.join(tmpdirname, "tmp_file.py")
        assert load_module_from_file_location(location).some_var

# Generated at 2022-06-18 06:21:26.660711
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function.
    """
    import os
    import tempfile
    import shutil

    def _create_config_file(config_file_name, config_file_content):
        """
        Create config file with specified name and content.
        """
        with open(config_file_name, "w") as config_file:
            config_file.write(config_file_content)

    def _remove_config_file(config_file_name):
        """
        Remove config file with specified name.
        """
        os.remove(config_file_name)


# Generated at 2022-06-18 06:21:35.404944
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # Test 1:
    # Test if function works with string.
    # Create temporary file and write some content to it.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as temp:
        temp.write("some_var = 'some_value'")
        temp.seek(0)
        module = load_module_from_file_location(temp.name)

    assert module.some_var == "some_value"

    # Test 2:
    # Test if function works with bytes.
    # Create temporary file and write some content to it.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as temp:
        temp.write("some_var = 'some_value'")
        temp.seek(0)
        module = load_module

# Generated at 2022-06-18 06:21:43.803811
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function load_module_from_file_location
    #    can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as temp:
        temp.write("x = 1")
        temp.seek(0)
        module = load_module_from_file_location(temp.name)
        assert module.x == 1

    # B) Test if function load_module_from_file_location
    #    can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as temp:
        temp.write("x = 1")
        temp.seek(0)
        os.environ["TEST_ENV_VAR"] = temp.name
       

# Generated at 2022-06-18 06:21:52.358447
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test function load_module_from_file_location."""
    import os
    import tempfile

    # A) Test that it works with string.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        module = load_module_from_file_location(
            "test_module", f"${TEST_ENV_VAR}/test_module.py"
        )
        assert module.__name__ == "test_module"

    # B) Test that it works with Path.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname