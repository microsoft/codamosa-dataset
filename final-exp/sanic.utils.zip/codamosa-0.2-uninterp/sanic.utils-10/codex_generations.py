

# Generated at 2022-06-18 06:12:26.183728
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_env_var_value"
    os.environ["some_env_var_2"] = "some_env_var_value_2"

    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    location = "some_module_name"
    location_with_env_var = "some_module_name_with_env_var"
    location_with_env_var_2 = "some_module_name_with_env_var_2"
    location_with_env_var_3 = "some_module_name_with_env_var_3"

# Generated at 2022-06-18 06:12:36.196258
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function works with string.
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        f.write("a = 1")
    try:
        module = load_module_from_file_location(f.name)
        assert module.a == 1
    finally:
        os.remove(f.name)

    # B) Test if function works with Path.
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        f.write("a = 2")
    try:
        module = load_module_from_file_location(Path(f.name))
        assert module.a == 2
    finally:
        os.remove(f.name)

    # C) Test if function works with environment

# Generated at 2022-06-18 06:12:45.961010
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if function can load module from file.
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        temp_file = temp_dir / "temp_file.py"
        temp_file.write_text("a = 1")
        module = load_module_from_file_location(temp_file)
        assert module.a == 1

    # B) Test if function can load module from file with environment variables.
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        temp_file = temp_dir / "temp_file.py"
        temp_file.write_text("a = 1")

# Generated at 2022-06-18 06:12:52.219591
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Create temporary file
    with tempfile.NamedTemporaryFile(mode="w+", delete=False) as f:
        f.write("a = 1\nb = 2")

    # Load module from temporary file
    module = load_module_from_file_location(f.name)

    # Check if module is loaded correctly
    assert module.a == 1
    assert module.b == 2

    # Clean up
    os.remove(f.name)

# Generated at 2022-06-18 06:13:02.509381
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ
    from os import path as os_path
    from os import makedirs as os_makedirs
    from os import remove as os_remove

    from sanic.config import load_module_from_file_location

    # Test 1
    # A) Create a temporary directory
    with TemporaryDirectory() as temp_dir:
        # B) Create a temporary file
        temp_file = os_path.join(temp_dir, "temp_file.py")
        with open(temp_file, "w") as f:
            f.write("a = 1")

        # C) Load this file as a module
        module = load_module_from_file_location(temp_file)

        # D) Check that module is loaded correctly

# Generated at 2022-06-18 06:13:13.179095
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(
        os_environ.keys()
    )
    if not_defined_env_vars:
        raise LoadFileException(
            "The following environment variables are not set: "
            f"{', '.join(not_defined_env_vars)}"
        )

    # C) Substitute them in location.

# Generated at 2022-06-18 06:13:23.761206
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary file
    fd, path = tempfile.mkstemp(suffix=".py", dir=tmpdir)
    with os.fdopen(fd, "w") as tmp:
        tmp.write("a = 1")

    # Create temporary file
    fd, path2 = tempfile.mkstemp(suffix=".py", dir=tmpdir)
    with os.fdopen(fd, "w") as tmp:
        tmp.write("b = 2")

    # Create temporary file
    fd, path3 = tempfile.mkstemp(suffix=".py", dir=tmpdir)
    with os.fdopen(fd, "w") as tmp:
        tmp.write

# Generated at 2022-06-18 06:13:29.836262
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # Test 1:
    # A) Create a temporary file.
    # B) Write some content to it.
    # C) Load it as a module.
    # D) Check if it has the same content as we wrote.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as tmp_file:
        tmp_file.write("some_var = 'some_value'")
        tmp_file.seek(0)
        module = load_module_from_file_location(tmp_file.name)
        assert module.some_var == "some_value"

    # Test 2:
    # A) Create a temporary file.
    # B) Write some content to it.
    # C) Load it as a module.
    # D) Check if it has the same content as we

# Generated at 2022-06-18 06:13:39.719512
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # A) Test if function raises LoadFileException
    #    when environment variable is not set.
    os.environ["SOME_ENV_VAR"] = "some_value"
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
        tmp_file = tmpdirname / "some_file.py"
        tmp_file.touch()
        with pytest.raises(LoadFileException):
            load_module_from_file_location(
                tmp_file, "${SOME_ENV_VAR}/${SOME_ENV_VAR_NOT_SET}"
            )

    # B) Test if function raises LoadFileException
    #    when file does not exist.

# Generated at 2022-06-18 06:13:46.178776
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(mode="w", delete=False)
    tmp_file.write("TEST_VAR = 'test_value'")
    tmp_file.close()

    # Create temporary file with .py extension
    tmp_file_py = tempfile.NamedTemporaryFile(
        mode="w", delete=False, suffix=".py"
    )
    tmp_file_py.write("TEST_VAR = 'test_value'")
    tmp_file_py.close()

    # Create temporary file with .py extension

# Generated at 2022-06-18 06:14:00.275085
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os_environ["TEST_ENV_VAR"] = tmpdirname
        with open(f"{tmpdirname}/test_file.py", "w") as f:
            f.write("TEST_VAR = 'test_value'")

        module = load_module_from_file_location(
            f"{tmpdirname}/test_file.py"
        )
        assert module.TEST_VAR == "test_value"


# Generated at 2022-06-18 06:14:07.369664
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    env_vars_in_location = set(re_findall(r"\${(.+?)}", "some/path/${some_env_var}"))
    assert env_vars_in_location == {"some_env_var"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not_defined_env_vars == {"some_env_var"}

    # C) Substitute them in location.
    location = "some/path/${some_env_var}"

# Generated at 2022-06-18 06:14:17.044575
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Create temporary directory.
    temp_dir = tempfile.mkdtemp()
    # B) Create temporary file.
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=temp_dir, delete=False
    )
    # C) Write some content to this file.
    temp_file.write("some_var = 'some_value'")
    temp_file.close()
    # D) Create environment variable.
    os.environ["TEST_ENV_VAR"] = temp_dir
    # E) Load module from this file.

# Generated at 2022-06-18 06:14:25.898829
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # B) Create temporary file in this directory
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("some_var = 'some_value'")

    # C) Create environment variable
    os.environ["TEST_ENV_VAR"] = tmp_dir

    # D) Test function
    module = load_module_from_file_location(
        "tmp_file.py", "${TEST_ENV_VAR}", "utf8"
    )
    assert module.some_var == "some_value"

    # E) Remove temporary directory


# Generated at 2022-06-18 06:14:34.089971
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # A) Test with file path.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file_path = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("test_var = 'test_value'")

        module = load_module_from_file_location(tmp_file_path)
        assert module.test_var == "test_value"

    # B) Test with file path and environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        os.environ["TEST_ENV_VAR"] = "test_env_var"
        tmp_file_path = os.path.join

# Generated at 2022-06-18 06:14:43.990275
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_env_var_value"

    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmp_file_path = Path(tmpdirname) / "some_file.py"
        tmp_file_path.write_text(
            "some_var = 'some_var_value'\n"
            "some_env_var = '${some_env_var}'\n"
        )


# Generated at 2022-06-18 06:14:50.124230
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_env_var_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    assert module.__file__ == "/some/path/some_env_var_value"

    # B) Check these variables exists in environment.
    os_environ.pop("some_env_var")

# Generated at 2022-06-18 06:14:59.402392
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ
    from os.path import join as path_join
    from shutil import copyfile

    # Prepare environment
    with TemporaryDirectory() as tmp_dir:
        os_environ["TEST_ENV_VAR"] = tmp_dir
        copyfile(
            path_join(
                path_join(path_join(__file__, ".."), ".."), "config.py"
            ),
            path_join(tmp_dir, "config.py"),
        )

        # Test
        assert load_module_from_file_location(
            path_join(tmp_dir, "config.py")
        ).TEST_CONFIG_VAR == "test_config_var"

# Generated at 2022-06-18 06:15:09.173587
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test if function works with bytes.
    with tempfile.NamedTemporaryFile() as f:
        f.write(b"a = 1")
        f.flush()
        module = load_module_from_file_location(f.name.encode())
        assert module.a == 1

    # B) Test if function works with strings.
    with tempfile.NamedTemporaryFile() as f:
        f.write(b"a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # C) Test if function works with Path objects.
    with tempfile.NamedTemporaryFile() as f:
        f.write(b"a = 1")
        f.flush()

# Generated at 2022-06-18 06:15:14.962944
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # A) Test if function can load module from file
    #    with absolute path.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as tmp_file:
        tmp_file.write("a = 1")
        tmp_file.flush()
        module = load_module_from_file_location(tmp_file.name)
        assert module.a == 1

    # B) Test if function can load module from file
    #    with relative path.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as tmp_file:
        tmp_file.write("a = 1")
        tmp_file.flush()

# Generated at 2022-06-18 06:15:24.696976
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.write(b"test_var = 'test_value'")
    temp_file.close()

    # Load module from temporary file
    module = load_module_from_file_location(temp_file.name)

    # Check if module was loaded correctly
    assert module.test_var == "test_value"

    # Remove temporary directory
    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 06:15:31.798892
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""
    import os
    import tempfile
    import shutil

    # A) Test if it works with normal path
    #    and if it returns module object.
    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, "temp_file.py")
    with open(temp_file, "w") as f:
        f.write("test_var = 'test_value'")
    module = load_module_from_file_location(temp_file)
    assert module.test_var == "test_value"
    shutil.rmtree(temp_dir)

    # B) Test if it works with environment variables.
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 06:15:41.518272
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    location = "some_module_name"
    module = load_module_from_file_location(location)
    assert module.__name__ == location

    # B) Check these variables exists in environment.
    location = "some_module_name"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    # C) Substitute them in location.
    location = "some_module_name/${TEST_ENV_VAR}"
    module = load_module_from_file_location(location)

# Generated at 2022-06-18 06:15:51.573554
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if location is of a Path type.
    # E) Check if location is of a string type.
    # F) Check if location is of a bytes type.
    # G) Check if location is of a string type and contains .py extension.
    # H) Check if location is of a string type and doesn't contain .py extension.
    # I) Check if location is of a bytes type and contains .py extension.
    # J) Check if location is of a bytes type and doesn't contain .py extension.
    # K) Check if location is of a Path type and contains .py extension.
   

# Generated at 2022-06-18 06:16:01.156086
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    assert module.__file__ == "/some/path/some_value"

    # B) Check these variables exists in environment.
    del os_environ["some_env_var"]
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var}"
        )

    # C) Substitute them in location.

# Generated at 2022-06-18 06:16:12.347204
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test that function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("some_var = 1")
        temp_file.seek(0)
        module = load_module_from_file_location(temp_file.name)
        assert module.some_var == 1

    # B) Test that function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("some_var = 1")
        temp_file.seek(0)
        os.environ["TEMP_FILE_NAME"] = temp_file.name

# Generated at 2022-06-18 06:16:20.278527
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    assert module.__file__ == "/some/path/some_value"
    del os_environ["some_env_var"]

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.

# Generated at 2022-06-18 06:16:30.393628
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if function raises LoadFileException
    #    when environment variable is not set.
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, "some_module.py"), "w") as f:
            f.write("some_var = 'some_value'")

        with pytest.raises(LoadFileException):
            load_module_from_file_location(
                os.path.join(tmpdirname, "${some_env_var}/some_module.py")
            )

    # B) Test if function loads module from file.

# Generated at 2022-06-18 06:16:40.703006
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Test if it can load module from file.
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmp_file_path = os.path.join(tmpdirname, "tmp_file.py")
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("some_var = 'some_value'")

        module = load_module_from_file_location(tmp_file_path)
        assert module.some_var == "some_value"

    # B) Test if it can load module from file with environment variables.
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmp_file_path = os.path.join(tmpdirname, "tmp_file.py")

# Generated at 2022-06-18 06:16:47.973456
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove
    from tempfile import mkstemp as tempfile_mkstemp

    # A) Test that function raises LoadFileException
    #    if environment variable is not defined.
    os_environ["TEST_ENV_VAR"] = "test_env_var_value"
    try:
        load_module_from_file_location(
            "some_module_name", "/some/path/${TEST_ENV_VAR}/${NOT_DEFINED_ENV_VAR}"
        )
    except LoadFileException as e:
        assert (
            str(e)
            == "The following environment variables are not set: NOT_DEFINED_ENV_VAR"
        )

# Generated at 2022-06-18 06:17:01.696984
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Test loading module from string with environment variables.
    os.environ["some_env_var"] = "some_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    assert module.__name__ == "some_module_name"
    assert module.__file__ == "/some/path/some_value"

    # B) Test loading module from Path with environment variables.
    os.environ["some_env_var"] = "some_value"
    module = load_module_from_file_location(
        Path("/some/path/${some_env_var}")
    )

# Generated at 2022-06-18 06:17:11.746288
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if module is loaded.
    # E) Check if module is loaded correctly.
    # F) Check if module is loaded correctly.

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if module is loaded.
    # E) Check if module is loaded correctly.
    # F) Check if module is loaded correctly.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    module = load

# Generated at 2022-06-18 06:17:21.896163
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    location = "./test_config_file.py"
    module = load_module_from_file_location(location)
    assert module.TEST_CONFIG_VARIABLE == "test_config_variable"

    # B) Check these variables exists in environment.
    location = "./test_config_file.py"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    # C) Substitute them in location.
    location = "./test_config_file.py"
    module = load_module_from_file_location(location)
    assert module

# Generated at 2022-06-18 06:17:31.895133
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary file
    tmpfile = tempfile.NamedTemporaryFile(
        mode="w+", dir=tmpdir, delete=False
    )

    # Write to temporary file
    tmpfile.write("some_var = 'some_value'")
    tmpfile.close()

    # Load module from temporary file
    module = load_module_from_file_location(tmpfile.name)

    # Check if module is loaded
    assert module.some_var == "some_value"

    # Delete temporary directory
    shutil.rmtree(tmpdir)

    # Check if module is loaded
    assert module.some_var == "some_value"

    # Create temporary directory
    tmpdir

# Generated at 2022-06-18 06:17:42.440255
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with non existing file.
    try:
        load_module_from_file_location("/some/non/existing/file")
    except LoadFileException as e:
        assert str(e) == "Unable to load configuration file (e.strerror)"

    # B) Test with existing file.
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmp_file = os.path.join(tmpdirname, "tmp_file.py")
        with open(tmp_file, "w") as f:
            f.write("some_var = 'some_value'")
        module = load_module_from_file_location(tmp_file)
        assert module.some_var == "some_value"

    # C) Test with existing file, but without .

# Generated at 2022-06-18 06:17:51.778768
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from file path.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("test_var = 'test_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.test_var == "test_value"

    # B) Test if function can load module from file path with environment
    #    variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("test_var = 'test_value'")
        f.seek(0)
        os.environ["TEST_ENV_VAR"] = f.name

# Generated at 2022-06-18 06:18:05.495871
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test loading module from file
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # B) Test loading module from file with environment variables
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.flush()
        os_environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}"
        )  # type: ignore


# Generated at 2022-06-18 06:18:11.208228
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if function can load module from file location.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # B) Test if function can load module from file location
    #    with environment variables in it.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        os.environ["SOME_ENV_VAR"] = f.name
       

# Generated at 2022-06-18 06:18:19.486536
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    from tempfile import TemporaryDirectory
    from os import environ as os_environ
    from os.path import join as os_path_join

    # A) Test with file path.
    with TemporaryDirectory() as temp_dir:
        # A.1) Test with file path without environment variables.
        file_path = os_path_join(temp_dir, "some_file.py")
        with open(file_path, "w") as f:
            f.write("some_var = 'some_value'")

        module = load_module_from_file_location(file_path)
        assert module.some_var == "some_value"

        # A.2) Test with file path with environment variables.

# Generated at 2022-06-18 06:18:29.976345
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    assert (
        load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var}"
        ).__file__
        == "/some/path/some_value"
    )
    del os_environ["some_env_var"]

    # B) Check these variables exists in environment.
    assert (
        load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var}"
        ).__file__
        == "/some/path/${some_env_var}"
    )

    # C) Substitute them in location.

# Generated at 2022-06-18 06:18:39.190949
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    location = "/some/path/${some_env_var}"
    assert load_module_from_file_location(location) == "some_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"

# Generated at 2022-06-18 06:18:48.588419
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables
    # A.1) Test with environment variables in location
    # A.1.1) Test with environment variables in location
    #        and with existing environment variables
    # A.1.1.1) Test with environment variables in location
    #          and with existing environment variables
    #          and with location as a string
    # A.1.1.2) Test with environment variables in location
    #          and with existing environment variables
    #          and with location as a bytes
    # A.1.1.3) Test with environment variables in location
    #          and with existing environment variables
    #          and with location as a Path
    # A.1.2) Test with environment variables in location
    #        and with non existing environment variables
    # A.1.2.1) Test

# Generated at 2022-06-18 06:18:57.011417
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_value"
    location = "some_module_name"
    assert load_module_from_file_location(location) is None

    # B) Check these variables exists in environment.
    location = "some_module_name"
    assert load_module_from_file_location(location) is None

    # C) Substitute them in location.
    location = "some_module_name"
    assert load_module_from_file_location(location) is None

    # D) Check if location contains any environment variables
    #    in format ${some_env_var}.
    location = "some_module_name"
    assert load

# Generated at 2022-06-18 06:19:07.073397
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if it works with string path.
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, "test_file.py"), "w") as f:
            f.write("test_var = 'test_value'")
        module = load_module_from_file_location(
            os.path.join(tmpdirname, "test_file.py")
        )
        assert module.test_var == "test_value"

    # B) Test if it works with bytes path.

# Generated at 2022-06-18 06:19:16.768495
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    location_with_env_var = "some_module_name_with_env_var"
    location_with_env_var_value = "some_module_name_with_env_var_value"
    location_with_env_var_value_and_path = "some_module_name_with_env_var_value_and_path"
    location_with_env_var_value_and_path_and_ext = "some_module_name_with_env_var_value_and_path_and_ext"
    location_

# Generated at 2022-06-18 06:19:22.472764
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    def create_temp_file(content):
        temp_dir = tempfile.mkdtemp()
        temp_file = tempfile.NamedTemporaryFile(
            mode="w", dir=temp_dir, delete=False
        )
        temp_file.write(content)
        temp_file.close()
        return temp_file.name

    def remove_temp_dir(temp_dir):
        shutil.rmtree(temp_dir)

    # Test 1
    temp_file_name = create_temp_file("a = 1")
    module = load_module_from_file_location(temp_file_name)
    assert module.a == 1
    remove_temp_dir(Path(temp_file_name).parent)

    # Test 2
    temp_file_name

# Generated at 2022-06-18 06:19:34.313249
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    assert load_module_from_file_location(location) is None

    # B) Check these variables exists in environment.
    location = "some_module_name"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    # C) Substitute them in location.
    location = "/some/path/${some_env_var}"
    assert load_module_from_file_location(location) is None

    # D) Check if location is of a bytes type.

# Generated at 2022-06-18 06:19:42.539087
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    location = "some_module_name"
    location_with_env_var = "some_module_name_with_env_var"
    location_with_env_var_in_path = (
        "/some/path/${TEST_ENV_VAR}/some_module_name_with_env_var"
    )
    location_with_env_var_in_path_and_py = (
        "/some/path/${TEST_ENV_VAR}/some_module_name_with_env_var.py"
    )
    location_with_env_var_in_path_and

# Generated at 2022-06-18 06:19:52.215072
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test loading module from file path.
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, "test_module.py"), "w") as f:
            f.write("test_var = 'test_value'")
        module = load_module_from_file_location(
            os.path.join(tmpdirname, "test_module.py")
        )
        assert module.test_var == "test_value"

    # B) Test loading module from environment variable.

# Generated at 2022-06-18 06:20:01.574747
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["SOME_ENV_VAR"] = "some_value"
    location = "some_module_name"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert not env_vars_in_location

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:20:13.307869
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_value"
    location = "/some/path/${some_env_var}"
    assert load_module_from_file_location(location) is None

    # B) Check these variables exists in environment.
    location = "/some/path/${some_env_var}/${some_env_var_2}"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    # C) Substitute them in location.
    os.environ["some_env_var_2"] = "some_value_2"

# Generated at 2022-06-18 06:20:24.934279
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["SOME_ENV_VAR"] = "some_value"
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(
            f.name, "/some/path/${SOME_ENV_VAR}"
        )
        assert module.some_var == "some_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.

# Generated at 2022-06-18 06:20:32.575087
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from os import path
    from tempfile import TemporaryDirectory

    from sanic.config import load_module_from_file_location

    with TemporaryDirectory() as tmpdirname:
        # A) Test if it works with a string path.
        path_to_config = path.join(tmpdirname, "config.py")
        with open(path_to_config, "w") as config_file:
            config_file.write("TEST_VAR = 'test'")
        config = load_module_from_file_location(path_to_config)
        assert config.TEST_VAR == "test"

        # B) Test if it works with a Path object.
        path_to_config = path.join(tmpdirname, "config.py")

# Generated at 2022-06-18 06:20:43.404702
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # Create temp directory
    temp_dir = tempfile.mkdtemp()

    # Create temp file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=temp_dir, delete=False
    )
    temp_file.write("test_var = 'test_value'")
    temp_file.close()

    # Create temp module
    temp_module = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=temp_dir, delete=False
    )
    temp_module.write("test_var = 'test_value'")
    temp_module.close()

    # Create temp module with environment variables
    temp_module_with_env_vars = temp

# Generated at 2022-06-18 06:20:51.917432
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    assert module.__file__ == "/some/path/some_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    module = load_module_from_

# Generated at 2022-06-18 06:21:00.967847
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test if function load_module_from_file_location
    #    can load module from file path.
    assert load_module_from_file_location(
        "tests/test_helpers/test_config.py"
    ).TEST_CONFIG_VARIABLE == "test_config_variable"

    # B) Test if function load_module_from_file_location
    #    can load module from file path with environment variables.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    assert load_module_from_file_location(
        "tests/test_helpers/${TEST_ENV_VAR}/test_config.py"
    ).TEST_CONFIG_VARIABLE == "test_config_variable"
    del os_en

# Generated at 2022-06-18 06:21:12.001379
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_value"
    location = "${some_env_var}"
    assert load_module_from_file_location(location) == "some_value"

    # B) Check these variables exists in environment.
    location = "${some_env_var}/some_path"
    assert load_module_from_file_location(location) == "some_value/some_path"

    # C) Substitute them in location.
    location = "${some_env_var}/some_path"
    assert load_module_from_file_location(location) == "some_value/some_path"

    # D) Check if

# Generated at 2022-06-18 06:21:20.543564
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ
    from os import path as os_path

    # A) Test loading module from file location.
    with TemporaryDirectory() as tmp_dir:
        # A.1) Create a file.
        tmp_file_path = os_path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("some_var = 'some_value'")

        # A.2) Test loading module from file location.
        loaded_module = load_module_from_file_location(tmp_file_path)
        assert loaded_module.some_var == "some_value"

    # B) Test loading module from file location with environment variables.

# Generated at 2022-06-18 06:21:31.386579
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from os import environ as os_environ

    os_environ["TEST_ENV_VAR"] = "test_env_var_value"

    with NamedTemporaryFile(mode="w+", suffix=".py") as temp_file:
        temp_file.write("test_var = 'test_value'")
        temp_file.seek(0)
        module = load_module_from_file_location(temp_file.name)
        assert module.test_var == "test_value"

    with NamedTemporaryFile(mode="w+", suffix=".py") as temp_file:
        temp_file.write("test_var = 'test_value'")
        temp_file.seek(0)

# Generated at 2022-06-18 06:21:36.705468
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test loading module from file path.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test loading module from file path with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}"
        )  # type: ignore


# Generated at 2022-06-18 06:21:48.594144
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # A) Create temporary directory and file.
    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("a = 1")

    # B) Test if function load_module_from_file_location works.
    module = load_module_from_file_location(tmp_file)
    assert module.a == 1

    # C) Clean up.
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 06:21:57.130196
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        location = "${TEST_ENV_VAR}/test_module.py"
        env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
        assert env_vars_in_location == {"TEST_ENV_VAR"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not_defined_env_vars == set()



# Generated at 2022-06-18 06:22:04.594122
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_env_var_value"
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(
            f.name, "/some/path/${some_env_var}"
        )
        assert module.some_var == "some_value"

    # B) Check these variables exists in environment.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
       

# Generated at 2022-06-18 06:22:14.512479
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # A) Test if function can load module from file.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "some_module.py")
        with open(tmp_file, "w") as f:
            f.write("some_var = 'some_val'")
        sys.path.append(tmp_dir)
        module = load_module_from_file_location(tmp_file)
        assert module.some_var == "some_val"

    # B) Test if function can load module from file with environment variables
    #    in path.