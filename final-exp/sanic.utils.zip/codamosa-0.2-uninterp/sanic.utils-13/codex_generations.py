

# Generated at 2022-06-18 06:12:23.773021
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import sys
    import shutil
    import pytest

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if location is of a Path type.
    # E) Check if location is of a string type.
    # F) Check if location is of a bytes type.
    # G) Check if location is of a string type with .py extension.
    # H) Check if location is of a string type without .py extension.
    # I) Check if location is of a string type with .py extension
    #    and contains environment variables.
    # J) Check if location is of a string type without .py extension
    #    and contains environment variables

# Generated at 2022-06-18 06:12:33.113716
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # A) Test that function can load module from file.
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Create test module.
        module_path = os.path.join(tmpdirname, "test_module.py")
        with open(module_path, "w") as f:
            f.write("test_var = 'test_value'")

        # Load test module.
        test_module = load_module_from_file_location(module_path)

        # Check that test module is loaded correctly.
        assert test_module.test_var == "test_value"

    # B) Test that function can load module from file with environment variables.

# Generated at 2022-06-18 06:12:44.433941
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with TemporaryDirectory() as tmp_dir:
        os_environ["TEST_ENV_VAR"] = tmp_dir
        location = os_path.join(tmp_dir, "test_file.py")
        with open(location, "w") as test_file:
            test_file.write("test_var = 'test_value'")

# Generated at 2022-06-18 06:12:55.316548
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # B) Create temporary file
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("a = 1")

    # C) Create temporary environment variable
    tmp_env_var = "TMP_ENV_VAR"
    tmp_env_var_value = "tmp_env_var_value"
    os.environ[tmp_env_var] = tmp_env_var_value

    # D) Test load_module_from_file_location
    module = load_module_from_file_location(tmp_file)
    assert module.a == 1



# Generated at 2022-06-18 06:13:04.304243
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    env_vars_in_location = set(re_findall(r"\${(.+?)}", "some_path/${some_env_var}"))
    assert env_vars_in_location == {"some_env_var"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not_defined_env_vars == set()

    # C) Substitute them in location.
    location = "some_path/${some_env_var}"

# Generated at 2022-06-18 06:13:14.603586
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import remove as os_remove
    from os import makedirs as os_makedirs
    from os import path as os_path
    from tempfile import mkdtemp as tempfile_mkdtemp
    from shutil import rmtree as shutil_rmtree

    # A) Create temporary directory
    temp_dir = tempfile_mkdtemp()
    os_makedirs(os_path.join(temp_dir, "some_dir"))

    # B) Create temporary file
    temp_file = os_path.join(temp_dir, "some_dir", "some_file.py")
    with open(temp_file, "w") as f:
        f.write("some_var = 'some_value'")

    # C) Create environment variable
    os

# Generated at 2022-06-18 06:13:24.899813
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Tests load_module_from_file_location function.
    """
    import tempfile
    import os

    # A) Test if function raises LoadFileException
    #    when environment variable is not set.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        with open(os.path.join(tmpdirname, "test_config.py"), "w") as f:
            f.write("TEST_CONFIG_VAR = 'test_config_var'")


# Generated at 2022-06-18 06:13:33.486280
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with file path.
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("a = 1")
        tmp_file.seek(0)
        module = load_module_from_file_location(tmp_file.name)
        assert module.a == 1

    # B) Test with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("a = 1")
        tmp_file.seek(0)
        os.environ["TMP_FILE_NAME"] = tmp_file.name
        module = load_module_from_file_location(
            "${TMP_FILE_NAME}"
        )  # noqa

# Generated at 2022-06-18 06:13:42.907964
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Test for loading module from string
    module_from_string = load_module_from_file_location(
        "sanic.exceptions"
    )
    assert module_from_string.__name__ == "sanic.exceptions"

    # Test for loading module from path
    module_from_path = load_module_from_file_location(
        Path(__file__).parent / "test_load_module_from_file_location.py"
    )
    assert module_from_path.__name__ == "test_load_module_from_file_location"

    # Test for loading module from path with environment variables
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        module_

# Generated at 2022-06-18 06:13:48.513778
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    import tempfile
    import os

    # Test for case when location is of a bytes type.
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, "test_module.py"), "w") as f:
            f.write("test_var = 'test_value'")

        module = load_module_from_file_location(
            os.path.join(tmpdirname, "test_module.py").encode("utf8")
        )
        assert module.test_var == "test_value"

    # Test for case when location is of a string type.

# Generated at 2022-06-18 06:14:02.214206
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["SOME_ENV_VAR"] = "some_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${SOME_ENV_VAR}"
    )
    assert module.__file__ == "/some/path/some_value"

    # B) Check these variables exists in environment.

# Generated at 2022-06-18 06:14:08.485861
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables
    os.environ["some_env_var"] = "some_value"
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("some_var = 'some_value'")
        tmp_file.seek(0)
        module = load_module_from_file_location(
            "some_module_name",
            "${some_env_var}/" + tmp_file.name,
        )
        assert module.some_var == "some_value"

    # B) Test with Path
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("some_var = 'some_value'")
        tmp_file.seek

# Generated at 2022-06-18 06:14:18.518139
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    # Create temporary directory
    temp_dir_path = tempfile.mkdtemp()
    # Create temporary file
    temp_file_path = Path(temp_dir_path) / "temp_file.py"
    temp_file_path.touch()

    # Create temporary file with content
    temp_file_with_content_path = Path(temp_dir_path) / "temp_file_with_content.py"

# Generated at 2022-06-18 06:14:26.885178
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables
    #    in format ${some_env_var}.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        os.environ["TEST_ENV_VAR_2"] = "test_env_var_2"
        with open(os.path.join(tmpdirname, "test_file.py"), "w") as f:
            f.write("test_var = 'test_value'")

        module = load_module_from_file_location(
            "${TEST_ENV_VAR}/test_file.py"
        )
        assert module.test_var == "test_value"

        module = load_module_from_file

# Generated at 2022-06-18 06:14:36.064850
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test with environment variables
    os_environ["some_env_var"] = "some_value"
    assert load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    del os_environ["some_env_var"]

    # B) Test with Path
    assert load_module_from_file_location(
        "some_module_name", Path("/some/path/some_file.py")
    )

    # C) Test with string
    assert load_module_from_file_location(
        "some_module_name", "/some/path/some_file.py"
    )

    # D) Test with bytes

# Generated at 2022-06-18 06:14:45.035518
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    location = "test_module_name"
    location_with_env_var = "test_module_name_with_env_var"
    location_with_env_var_in_path = "test_module_name_with_env_var_in_path"
    location_with_not_defined_env_var = "test_module_name_with_not_defined_env_var"
    location_with_not_defined_env_var_in_path = "test_module_name_with_not_defined_env_var_in_path"
    location_with_not_defined_env

# Generated at 2022-06-18 06:14:52.471765
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # Create temporary file with some content
    temp_file = tempfile.NamedTemporaryFile(mode="w+", delete=False)
    temp_file.write("some_var = 'some_value'")
    temp_file.close()

    # Load module from this file
    module = load_module_from_file_location(temp_file.name)

    # Check that module has attribute some_var with value 'some_value'
    assert hasattr(module, "some_var")
    assert module.some_var == "some_value"

    # Remove temporary file
    os.unlink(temp_file.name)

# Generated at 2022-06-18 06:15:02.109190
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["SOME_ENV_VAR"] = "some_value"
    location = "some_module_name"
    assert load_module_from_file_location(location) is None

    # B) Check these variables exists in environment.
    location = "some_module_name"
    os.environ.pop("SOME_ENV_VAR")
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    # C) Substitute them in location.
    os.environ["SOME_ENV_VAR"] = "some_value"

# Generated at 2022-06-18 06:15:11.322153
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Test 1.
    # Test that function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py", delete=False) as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1
    os.unlink(f.name)

    # Test 2.
    # Test that function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py", delete=False) as f:
        f.write("a = 1")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name
        module = load

# Generated at 2022-06-18 06:15:22.525408
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(mode="w", dir=tmp_dir, delete=False)
    # Write some content to temporary file
    tmp_file.write("some_var = 'some_value'")
    tmp_file.close()

    # Create temporary module
    tmp_module = tempfile.NamedTemporaryFile(
        mode="w", dir=tmp_dir, suffix=".py", delete=False
    )
    # Write some content to temporary module
    tmp_module.write("some_var = 'some_value'")
    tmp_module.close()

    # Create temporary environment variable

# Generated at 2022-06-18 06:15:33.044837
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test that function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test that function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}",
        )
        assert module.a == 1

    #

# Generated at 2022-06-18 06:15:42.756577
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    assert set(re_findall(r"\${(.+?)}", "/some/path/${some_env_var}")) == {
        "some_env_var"
    }

    # B) Check these variables exists in environment.
    assert set(re_findall(r"\${(.+?)}", "/some/path/${some_env_var}")) == {
        "some_env_var"
    }

    # C) Substitute them in location.

# Generated at 2022-06-18 06:15:53.242447
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["test_env_var"] = "test_env_var_value"
    assert (
        load_module_from_file_location(
            "some_module_name", "/some/path/${test_env_var}"
        ).__file__
        == "/some/path/test_env_var_value"
    )

    # B) Check these variables exists in environment.
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "some_module_name", "/some/path/${not_defined_env_var}"
        )

    # C) Substitute them in location.

# Generated at 2022-06-18 06:16:02.429018
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove
    from os import mkdir as os_mkdir
    from os import rmdir as os_rmdir
    from os import getcwd as os_getcwd
    from os import chdir as os_chdir
    from os import getenv as os_getenv
    from os import unsetenv as os_unsetenv
    from os import setenv as os_setenv
    from os import listdir as os_listdir
    from os import makedirs as os_makedirs
    from os import system as os_system
    from os import devnull as os_devnull
    from os import fdopen as os_fdopen
    from os import close as os_close
   

# Generated at 2022-06-18 06:16:13.374997
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # Test 1
    # Test if function can load module from file
    # and if it can load module from file with .py extension
    # and if it can load module from file with .pyc extension
    # and if it can load module from file with .pyo extension
    # and if it can load module from file with .pyd extension
    # and if it can load module from file with .so extension
    # and if it can load module from file with .dll extension
    # and if it can load module from file with .dylib extension
    # and if it can load module from file with .sl extension
    # and if it can load module from file with .a extension
    # and if it can load module from file with .o extension
    # and if it can load module from file with .h extension
    # and if it can

# Generated at 2022-06-18 06:16:21.193121
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test loading module from file path.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "test_module.py")
        with open(tmp_file, "w") as f:
            f.write("test_var = 'test_value'")

        module = load_module_from_file_location(tmp_file)
        assert module.test_var == "test_value"

    # B) Test loading module from file path with environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "test_module.py")

# Generated at 2022-06-18 06:16:31.450219
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if location is of a bytes type, then use this encoding
    #    to decode it into string.
    # E) Check if location is of a Path type, then convert it into string.
    # F) Check if location is of a string type, then check if it contains
    #    any environment variables in format ${some_env_var}.
    # G) Check if location is of a string type, then check if it contains
    #    any environment variables in format $some_env_var.
    # H) Check if location is of a string type, then check if it contains


# Generated at 2022-06-18 06:16:41.755076
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    assert module.__file__ == "/some/path/some_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    module = load_module_from_

# Generated at 2022-06-18 06:16:48.643138
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["SOME_ENV_VAR"] = "some_value"
    location = "some_module_name"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert not env_vars_in_location

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:16:59.418558
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables in location.
    #    Create temporary file.
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.close()

    #    Create environment variable.
    os.environ["TEST_ENV_VAR"] = temp_file.name

    #    Check that module is loaded.
    assert load_module_from_file_location(
        "${TEST_ENV_VAR}"
    ) is not None

    #    Delete temporary file.
    os.unlink(temp_file.name)

    #    Delete environment variable.
    del os.environ["TEST_ENV_VAR"]

    # B) Test with environment variables in location.
    #    Create temporary file.

# Generated at 2022-06-18 06:17:16.651811
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["some_env_var"] = "some_value"
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", delete=False
    ) as config_file:
        config_file.write("some_var = 'some_value'")
    module = load_module_from_file_location(
        "some_module_name",
        "/some/path/${some_env_var}/" + config_file.name,
    )
    assert module.some_var == "some_value"

# Generated at 2022-06-18 06:17:24.270135
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test for case when location is a string
    # and it contains environment variables in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    assert (
        load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var}"
        )
        == "some_value"
    )
    del os_environ["some_env_var"]

    # Test for case when location is a string
    # and it contains environment variables in format ${some_env_var}.
    # But some_env_var is not set.

# Generated at 2022-06-18 06:17:35.061040
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function."""
    import os
    import tempfile

    # A) Test if function raises LoadFileException
    #    when environment variable is not defined.
    try:
        load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var}"
        )
    except LoadFileException as e:
        assert (
            str(e) == "The following environment variables are not set: some_env_var"
        )
    else:
        assert False

    # B) Test if function loads module from file
    #    when environment variable is defined.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["some_env_var"] = tmpdirname
        module = load_module_from_file_

# Generated at 2022-06-18 06:17:45.081438
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("a = 1")

    # Create temporary module
    tmp_module = os.path.join(tmp_dir, "tmp_module.py")
    with open(tmp_module, "w") as f:
        f.write("b = 2")

    # Create temporary package
    tmp_package = os.path.join(tmp_dir, "tmp_package")
    os.mkdir(tmp_package)

# Generated at 2022-06-18 06:17:53.429355
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    assert load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )

    # B) Check these variables exists in environment.
    os_environ.pop("some_env_var")
    try:
        load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var}"
        )
    except LoadFileException:
        pass
    else:
        assert False

    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    assert load

# Generated at 2022-06-18 06:18:05.673543
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    env_vars_in_location = set(re_findall(r"\${(.+?)}", "some_path/${some_env_var}"))
    assert env_vars_in_location == {"some_env_var"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not_defined_env_vars == set()

    # C) Substitute them in location.
    location = "some_path/${some_env_var}"

# Generated at 2022-06-18 06:18:14.920284
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    from os import environ as os_environ
    from os.path import join as os_path_join

    # A) Create temporary directory.
    temp_dir = tempfile.mkdtemp()

    # B) Create temporary file in this directory.
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", dir=temp_dir, delete=False
    )
    temp_file.write("some_var = 'some_value'")
    temp_file.close()

    # C) Create environment variable.
    os_environ["TEMP_ENV_VAR"] = temp_dir

    # D) Test function load_module_from_file_location.

# Generated at 2022-06-18 06:18:22.317362
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    def create_temp_module(name, content):
        temp_dir = tempfile.mkdtemp()
        temp_file = os.path.join(temp_dir, name)
        with open(temp_file, "w") as f:
            f.write(content)
        return temp_file

    def create_temp_package(name, content):
        temp_dir = tempfile.mkdtemp()
        temp_file = os.path.join(temp_dir, name)
        with open(temp_file, "w") as f:
            f.write(content)
        return temp_dir

    def remove_temp_dir(dir):
        shutil.rmtree(dir)


# Generated at 2022-06-18 06:18:32.442170
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test loading module from file path.
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", prefix="test_", delete=False
    ) as f:
        f.write("a = 1")
    module = load_module_from_file_location(f.name)
    assert module.a == 1
    os.remove(f.name)

    # B) Test loading module from file path with environment variables.
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", prefix="test_", delete=False
    ) as f:
        f.write("a = 1")
    os.environ["TEST_ENV_VAR"] = f.name

# Generated at 2022-06-18 06:18:38.250865
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Create temporary file
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py", delete=False) as f:
        f.write("test_var = 'test_value'")
        f.flush()
        temp_file_path = f.name

    # B) Load module from file
    module = load_module_from_file_location(temp_file_path)

    # C) Check that module has attribute test_var
    assert hasattr(module, "test_var")
    assert module.test_var == "test_value"

    # D) Remove temporary file
    os.remove(temp_file_path)

# Generated at 2022-06-18 06:18:57.991495
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # A) Test if function can load module from file.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / "some_module.py"
        with open(tmp_file, "w") as f:
            f.write("some_var = 'some_value'")
        sys.path.append(str(tmp_dir))
        module = load_module_from_file_location(tmp_file)
        assert module.some_var == "some_value"

    # B) Test if function can load module from file with environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp

# Generated at 2022-06-18 06:19:08.245056
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # Test 1
    # Test if function can load module from file path
    # and if it can load module from environment variable
    # in format ${some_env_var}.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("test_var = 'test_value'")
        f.seek(0)
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}", encoding="utf8"
        )
        assert module.test_var == "test_value"

    # Test 2
    # Test if function can load module from file path
    # and if it can load module from environment variable
   

# Generated at 2022-06-18 06:19:17.727490
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function.

    This function is tested by loading some_module.py file
    from the same directory as this test file.
    """
    import os
    import sys
    import tempfile
    import unittest

    from os import path

    # A) Create temporary directory and file.
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = path.abspath(tmp_dir.name)
    tmp_file_path = path.join(tmp_dir_path, "some_module.py")
    with open(tmp_file_path, "w") as tmp_file:
        tmp_file.write("some_var = 'some_value'")

    # B) Add temporary directory to the system path.

# Generated at 2022-06-18 06:19:24.156006
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove
    from tempfile import mkstemp as tempfile_mkstemp

    # A) Test with file path.
    # A.1) Test with file path with environment variables.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    _, temp_file_path = tempfile_mkstemp(suffix=".py")
    with open(temp_file_path, "w") as temp_file:
        temp_file.write("test_var = 'test_var'")

# Generated at 2022-06-18 06:19:35.796733
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test if it works with string.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test if it works with Path.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(Path(f.name))
        assert module.a == 1

    # C) Test if it works with bytes.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f

# Generated at 2022-06-18 06:19:43.266924
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    # A) Test loading module from file path.
    with NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1\n")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test loading module from file path with environment variables.
    with NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1\n")
        f.flush()
        os_environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}"
        )  # type: ignore
        assert module.a

# Generated at 2022-06-18 06:19:52.956813
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    location = "test_module_name"
    location_with_env_var = "test_module_name_with_env_var"
    location_with_env_var_in_path = "test_module_name_with_env_var_in_path"
    location_with_env_var_in_path_and_name = (
        "test_module_name_with_env_var_in_path_and_name"
    )

# Generated at 2022-06-18 06:20:02.156427
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location, path)
    assert module.__file__ == path
    del os_environ["some_env_var"]

    # B) Check these variables exists in environment.
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location, path)

    # C) Substitute them in location.

# Generated at 2022-06-18 06:20:10.655066
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests for function load_module_from_file_location."""
    # A) Test for loading module from file path.
    module_from_file_path = load_module_from_file_location(
        "tests/test_configs/test_config.py"
    )
    assert module_from_file_path.TEST_CONFIG_VARIABLE == "test_config_variable"

    # B) Test for loading module from file path with environment variables.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    module_from_file_path_with_env_vars = load_module_from_file_location(
        "tests/test_configs/${TEST_ENV_VAR}/test_config.py"
    )

# Generated at 2022-06-18 06:20:21.845540
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_env_var_value"
    location = "/some/path/${some_env_var}"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert env_vars_in_location == {"some_env_var"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:20:44.253494
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import remove as os_remove
    from os import mkdir as os_mkdir
    from os import rmdir as os_rmdir
    from os import path as os_path
    from tempfile import mkdtemp
    from shutil import copyfile as shutil_copyfile
    from shutil import rmtree as shutil_rmtree

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if location is of a string type.
    # E) Check if location is of a bytes type.
    # F) Check if location is of a Path type.
    # G) Check if location is of a Path type

# Generated at 2022-06-18 06:20:52.526384
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # Test 1.
    # Create temporary file.
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("some_var = 'some_value'")
        temp.seek(0)
        # Load module from temporary file.
        module = load_module_from_file_location(temp.name)
        assert module.some_var == "some_value"

    # Test 2.
    # Create temporary file.
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("some_var = 'some_value'")
        temp.seek(0)
        # Load module from temporary file.
        module = load_module_from_file_location(Path(temp.name))

# Generated at 2022-06-18 06:21:01.001062
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove
    from tempfile import mkstemp

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if location is a file path.
    # E) Check if location is a file path to .py file.
    # F) Check if location is a file path to non .py file.
    # G) Check if location is a module name.
    # H) Check if location is a module name with wrong format.

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B

# Generated at 2022-06-18 06:21:12.000923
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("a = 1")

    # Create temporary file with environment variables
    tmp_file_with_env_vars = os.path.join(tmp_dir, "tmp_file_with_env_vars.py")
    with open(tmp_file_with_env_vars, "w") as f:
        f.write("b = 2")

    # Create environment variable
    os.environ["TMP_FILE_WITH_ENV_VARS"] = tmp_file_with_env

# Generated at 2022-06-18 06:21:20.542876
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(mode="w", dir=tmp_dir, delete=False)
    tmp_file.write("some_var = 'some_value'")
    tmp_file.close()

    # Create temporary environment variable
    os.environ["TEST_ENV_VAR"] = tmp_dir

    # Test load_module_from_file_location
    module = load_module_from_file_location(
        f"${TEST_ENV_VAR}/{tmp_file.name.split('/')[-1]}"
    )
    assert module.some_var == "some_value"

    # Delete

# Generated at 2022-06-18 06:21:31.391239
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from os import environ

    # Test 1:
    # Check if function can load module from file.
    with NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # Test 2:
    # Check if function can load module from file with environment variables.
    with NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        environ["TEST_ENV_VAR"] = str(f.name)

# Generated at 2022-06-18 06:21:36.724301
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    location = "/some/path/${some_env_var}"
    assert (
        load_module_from_file_location(location).__file__
        == "/some/path/some_value"
    )
    del os_environ["some_env_var"]

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"

# Generated at 2022-06-18 06:21:45.109991
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # Test 1
    # Test if function can load module from file path
    # and return it as module.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # Test 2
    # Test if function can load module from file path
    # and return it as module.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from

# Generated at 2022-06-18 06:21:53.541906
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["TEST_ENV_VAR"] = "test_env_var_value"
    module = load_module_from_file_location(
        "test_module_name", "/some/path/${TEST_ENV_VAR}"
    )
    assert module.__file__ == "/some/path/test_env_var_value"
    assert module.__name__ == "test_module_name"
    del os_environ["TEST_ENV_VAR"]

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B)

# Generated at 2022-06-18 06:22:01.961613
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove
    from os import mkdir as os_mkdir
    from os import rmdir as os_rmdir
    from tempfile import mkdtemp as tempfile_mkdtemp
    from tempfile import mkstemp as tempfile_mkstemp
    from shutil import rmtree as shutil_rmtree

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if location is a file.
    # E) Check if location is a directory.
    # F) Check if location is a module.
    # G) Check if location is a