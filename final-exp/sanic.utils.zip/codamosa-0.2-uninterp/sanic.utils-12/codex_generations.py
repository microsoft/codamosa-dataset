

# Generated at 2022-06-18 06:12:23.215520
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / "tmp_file.py"
        tmp_file.write_text("a = 1")

        # A) Check if location contains any environment variables
        #    in format ${some_env_var}.
        env_vars_in_location = set(re_findall(r"\${(.+?)}", str(tmp_file)))

        # B) Check these variables exists in environment.
        not_defined_env_vars = env_vars_in_location.difference(
            os_environ.keys()
        )
        assert not not_defined_env_vars

        # C) Substitute them

# Generated at 2022-06-18 06:12:30.838598
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-18 06:12:41.838418
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # 1. Test if it can load module from file path.
    with tempfile.NamedTemporaryFile(mode="w") as temp:
        temp.write("some_var = 'some_value'")
        temp.flush()
        module = load_module_from_file_location(temp.name)
        assert module.some_var == "some_value"

    # 2. Test if it can load module from file path with environment variables.
    with tempfile.NamedTemporaryFile(mode="w") as temp:
        temp.write("some_var = 'some_value'")
        temp.flush()
        os.environ["TEST_ENV_VAR"] = temp.name

# Generated at 2022-06-18 06:12:49.169392
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test that function works with bytes location.
    with tempfile.NamedTemporaryFile(mode="w+b") as f:
        f.write(b"a = 1")
        f.seek(0)
        module = load_module_from_file_location(f.name.encode())
        assert module.a == 1

    # B) Test that function works with string location.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # C) Test that function works with Path location.

# Generated at 2022-06-18 06:13:00.347457
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ
    from os import path as os_path

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_env_var_value"
    with TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
        tmp_file = tmpdirname / "tmp_file.py"
        tmp_file.write_text("some_var = 'some_value'")
        module = load_module_from_file_location(
            f"{tmpdirname}/${some_env_var}/tmp_file.py"
        )
        assert module.some_var == "some_value"

    # B) Check these

# Generated at 2022-06-18 06:13:11.311241
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test function load_module_from_file_location.
    """
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)
    tmp_file.write(b"a = 1\nb = 2\n")
    tmp_file.close()

    # Create temporary file with environment variable
    tmp_file_with_env_var = tempfile.NamedTemporaryFile(
        dir=tmp_dir, delete=False
    )
    tmp_file_with_env_var.write(b"a = 1\nb = 2\n")
    tmp_file_with_env_var.close()

    # Create

# Generated at 2022-06-18 06:13:16.740137
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from file location.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 1")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == 1

    # B) Test if function can load module from file location
    #    with environment variables in it.
    os.environ["some_env_var"] = "some_value"
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 1")
        f.seek(0)

# Generated at 2022-06-18 06:13:26.080711
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_val'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_val"

    # B) Test if function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_val'")
        f.seek(0)
        os.environ["some_env_var"] = f.name

# Generated at 2022-06-18 06:13:35.621115
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Check if function raises LoadFileException
    #    when environment variable is not set.
    with tempfile.NamedTemporaryFile() as tmp_file:
        with pytest.raises(LoadFileException):
            load_module_from_file_location(
                f"{tmp_file.name}/${some_env_var}"
            )

    # B) Check if function raises LoadFileException
    #    when environment variable is not set.
    with tempfile.NamedTemporaryFile() as tmp_file:
        with pytest.raises(LoadFileException):
            load_module_from_file_location(
                f"{tmp_file.name}/${some_env_var}"
            )

    # C) Check if function raises LoadFileException
    #    when environment variable is not

# Generated at 2022-06-18 06:13:44.063128
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    assert load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    del os_environ["some_env_var"]

    # B) Check these variables exists in environment.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("some_module_name", "/some/path/${some_env_var}")

    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"

# Generated at 2022-06-18 06:13:55.580922
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_env_var_value"

    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    assert module.__file__ == "/some/path/some_env_var_value"

    # D) Check if location contains any environment variables
    #    in format $some_env_var.
    module = load_module_from_file_location(
        "some_module_name", "/some/path/$some_env_var"
    )
    assert module.__file

# Generated at 2022-06-18 06:14:05.505348
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    module = load_module_from_file_location(
        "test_module_name", "/some/path/${TEST_ENV_VAR}"
    )
    assert module.__name__ == "test_module_name"
    assert module.__file__ == "/some/path/test_env_var"
    del os_environ["TEST_ENV_VAR"]

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists

# Generated at 2022-06-18 06:14:15.017564
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with file path.
    # A.1) Test with file path and module name.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file, "w") as f:
            f.write("TEST_VAR = 'test_value'")

        module = load_module_from_file_location(tmp_file)
        assert module.TEST_VAR == "test_value"

    # A.2) Test with file path and module name.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "tmp_file.py")

# Generated at 2022-06-18 06:14:25.145161
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if function can load module from file path.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # B) Test if function can load module from file path with environment
    #    variables in it.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        os.environ["some_env_var"] = f.name
        module = load

# Generated at 2022-06-18 06:14:33.215567
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["SOME_ENV_VAR"] = "some_env_var_value"
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        temp_file = temp_dir / "some_file.py"
        temp_file.touch()

        # A) Check if location contains any environment variables
        #    in format ${some_env_var}.
        # B) Check these variables exists in environment.
        # C) Substitute them in location.

# Generated at 2022-06-18 06:14:43.351125
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    from sanic.exceptions import LoadFileException

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["SOME_ENV_VAR"] = "some_env_var_value"
    location = "some_module_name"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert not env_vars_in_location

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:14:49.709573
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    from sanic.exceptions import LoadFileException

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if location is of a Path type.
    # E) Check if location is of a string type.
    # F) Check if location is of a bytes type.
    # G) Check if location is of a string type and contains .py extension.
    # H) Check if location is of a string type and does not contain .py
    #    extension.
    # I) Check if location is of a string type and does not contain .py
    #    extension and contains environment variables in format ${some_env_var

# Generated at 2022-06-18 06:14:59.077397
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if it works.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["some_env_var"] = tmpdirname
        with open(os.path.join(tmpdirname, "some_module.py"), "w") as f:
            f.write("some_var = 'some_val'")
        module = load_module_from_file_location(
            "some_module", "${some_env_var}/some_module.py"
        )
        assert module.some_var == "some_val"

    # E

# Generated at 2022-06-18 06:15:08.867191
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test if it works with string.
    # A.1) Test if it works with string and without environment variables.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # A.2) Test if it works with string and with environment variables.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        os_environ["some_env_var"] = f.name
       

# Generated at 2022-06-18 06:15:14.791260
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if function can load module from file
    #    with environment variables in path.
    with tempfile.TemporaryDirectory() as tmp_dir:
        os.environ["TEST_ENV_VAR"] = tmp_dir
        config_file_path = os.path.join(tmp_dir, "config.py")
        with open(config_file_path, "w") as config_file:
            config_file.write("TEST_CONFIG_VAR = 'test_config_var'")

        module = load_module_from_file_location(
            "config", "${TEST_ENV_VAR}/config.py"
        )
        assert module.TEST_CONFIG_VAR == "test_config_var"

    # B) Test if

# Generated at 2022-06-18 06:15:26.428757
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ

    with TemporaryDirectory() as tmpdir:
        # A) Test that function works with Path object.
        path = Path(tmpdir) / "some_module.py"
        path.touch()
        module = load_module_from_file_location(path)
        assert module.__file__ == str(path)

        # B) Test that function works with string.
        path = Path(tmpdir) / "some_module.py"
        path.touch()
        module = load_module_from_file_location(str(path))
        assert module.__file__ == str(path)

        # C) Test that function works with bytes.
        path = Path(tmpdir) / "some_module.py"
        path.touch()

# Generated at 2022-06-18 06:15:36.042418
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("a = 1")

    # Create temporary file with environment variables
    tmp_file_with_env_vars = os.path.join(
        tmp_dir, "tmp_file_with_env_vars.py"
    )
    with open(tmp_file_with_env_vars, "w") as f:
        f.write("b = 2")

    # Create temporary file with environment variables

# Generated at 2022-06-18 06:15:40.895557
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test with file path.
    with tempfile.NamedTemporaryFile() as temp:
        temp.write(b"some_var = 'some_value'")
        temp.flush()
        module = load_module_from_file_location(temp.name)
        assert module.some_var == "some_value"

    # B) Test with environment variables in file path.
    with tempfile.NamedTemporaryFile() as temp:
        temp.write(b"some_var = 'some_value'")
        temp.flush()
        os_environ["some_env_var"] = temp.name
        module = load_module_from_file_location(
            "/some/path/${some_env_var}"
        )
        assert module.some_var == "some_value"

# Generated at 2022-06-18 06:15:50.681779
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["some_env_var"] = "some_value"
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.

# Generated at 2022-06-18 06:16:00.421579
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with environment variables.
    #    Create temporary file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        # Write some content to it.
        f.write(
            "some_var = 'some_value'\n"
            "some_other_var = 'some_other_value'\n"
        )
        # Set file name as environment variable.
        os.environ["TEST_ENV_VAR"] = f.name
        # Load module from this file.

# Generated at 2022-06-18 06:16:05.284188
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary file
    fd, path = tempfile.mkstemp(dir=tmpdir)
    with os.fdopen(fd, "w") as tmp:
        tmp.write("test = 'test'")

    # Load module from temporary file
    module = load_module_from_file_location(path)
    assert module.test == "test"

    # Remove temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-18 06:16:14.499521
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test loading module from file path.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file_path = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("some_var = 'some_val'")

        tmp_module = load_module_from_file_location(tmp_file_path)
        assert tmp_module.some_var == "some_val"

    # B) Test loading module from file path with environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file_path = os.path.join(tmp_dir, "tmp_file.py")

# Generated at 2022-06-18 06:16:23.564601
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # Test 1
    # Check if function raises LoadFileException
    # when environment variable is not set.
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(f"{tmpdirname}/some_file.py", "w") as f:
            f.write("some_var = 1")
        with pytest.raises(LoadFileException):
            load_module_from_file_location(
                f"{tmpdirname}/some_file.py", "${some_env_var}"
            )

    # Test 2
    # Check if function raises LoadFileException
    # when environment variable is not set.

# Generated at 2022-06-18 06:16:33.077686
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # Test 1:
    # Test if function can load module from file location.
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        f.write("a = 1")
        f.close()
        module = load_module_from_file_location(f.name)
        assert module.a == 1
        os.remove(f.name)

    # Test 2:
    # Test if function can load module from file location
    # with environment variables in it.
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        f.write("a = 1")
        f.close()
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file

# Generated at 2022-06-18 06:16:43.030747
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # Test 1
    # Test if function can load module from file location
    # with environment variables in it.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        module = load_module_from_file_location(
            "test_module", "${TEST_ENV_VAR}/test_module.py"
        )
        assert module.__name__ == "test_module"
        assert module.__file__ == f"{tmpdirname}/test_module.py"

    # Test 2
    # Test if function can load module from file location
    # with environment variables in it.

# Generated at 2022-06-18 06:16:59.477580
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test loading module from file path.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # B) Test loading module from bytes.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.read().encode())
        assert module.some_var == "some_value"

    # C) Test loading module from bytes with encoding.

# Generated at 2022-06-18 06:17:08.400981
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test if function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location(
            "/some/path/${TEST_ENV_VAR}"
        )

# Generated at 2022-06-18 06:17:19.883598
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("a = 1")

    # Create temporary environment variable
    os.environ["TMP_ENV_VAR"] = tmp_dir

    # Test load_module_from_file_location
    module = load_module_from_file_location(tmp_file)
    assert module.a == 1

    module = load_module_from_file_location(tmp_file.encode())
    assert module.a == 1


# Generated at 2022-06-18 06:17:24.481374
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Create temporary file and write some content to it.
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        f.write("some_var = 'some_value'")

    # B) Load module from this file.
    module = load_module_from_file_location(f.name)

    # C) Check that module was loaded correctly.
    assert module.some_var == "some_value"

    # D) Clean up.
    os.remove(f.name)



# Generated at 2022-06-18 06:17:35.245965
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_value"
    location = "some_module_name"
    assert load_module_from_file_location(location) is not None

    # B) Check these variables exists in environment.
    location = "some_module_name"
    os.environ["some_env_var"] = "some_value"
    assert load_module_from_file_location(location) is not None

    # C) Substitute them in location.
    location = "some_module_name"
    os.environ["some_env_var"] = "some_value"

# Generated at 2022-06-18 06:17:45.251980
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    location = "/some/path/${some_env_var}"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert env_vars_in_location == {"some_env_var"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:17:53.523527
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove
    from os import mkdir as os_mkdir
    from os import rmdir as os_rmdir
    from os import listdir as os_listdir
    from os import getcwd as os_getcwd
    from os import chdir as os_chdir
    from os import getenv as os_getenv
    from os import putenv as os_putenv
    from os import unsetenv as os_unsetenv
    from os import pardir as os_pardir
    from os import sep as os_sep
    from os import devnull as os_devnull
    from os import fdopen as os_fdopen
    from os import fsync as os_fsync


# Generated at 2022-06-18 06:18:05.679665
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil
    import sys

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, suffix=".py")
    # Write some content to temporary file
    temp_file.write(b"some_var = 'some_value'")
    # Close temporary file
    temp_file.close()

    # Add temporary directory to sys.path
    sys.path.append(temp_dir)

    # Load module from temporary file
    module = load_module_from_file_location(temp_file.name)

    # Check if module has attribute some_var
    assert hasattr(module, "some_var")
    # Check if module.some_var is equal to '

# Generated at 2022-06-18 06:18:11.357088
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    env_vars_in_location = set(re_findall(r"\${(.+?)}", "some/path/${some_env_var}"))
    assert env_vars_in_location == {"some_env_var"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not_defined_env_vars == set()

    # C) Substitute them in location.
    location = "some/path/${some_env_var}"

# Generated at 2022-06-18 06:18:16.388446
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ
    from os import path as os_path
    from shutil import copyfile

    # A) Test if function works with bytes location.
    with TemporaryDirectory() as tmp_dir:
        tmp_file = os_path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file, "w") as f:
            f.write("a = 1")
        module = load_module_from_file_location(tmp_file.encode())
        assert module.a == 1

    # B) Test if function works with Path location.
    with TemporaryDirectory() as tmp_dir:
        tmp_file = os_path.join(tmp_dir, "tmp_file.py")

# Generated at 2022-06-18 06:18:37.644908
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function.
    """
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    module = load_module_from_file_location(
        "test_module", "/some/path/${TEST_ENV_VAR}"
    )
    assert module.__file__ == "/some/path/test_env_var_value"

    # Test if location is of a bytes type.

# Generated at 2022-06-18 06:18:47.870989
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # Create temporary directory and file
    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, "test_file.py")
    with open(tmp_file, "w") as f:
        f.write("test_var = 'test_value'")

    # Add temporary directory to sys.path
    sys.path.append(tmp_dir)

    # Test that module can be loaded from file
    module = load_module_from_file_location(tmp_file)
    assert module.test_var == "test_value"

    # Test that module can be loaded from file with relative path
    module = load_module_from_file_location("test_file.py")
    assert module.test_var

# Generated at 2022-06-18 06:18:54.603966
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    def create_temp_file(content):
        fd, temp_file_path = tempfile.mkstemp()
        with os.fdopen(fd, "w") as tmp:
            tmp.write(content)
        return temp_file_path

    def remove_temp_file(temp_file_path):
        os.remove(temp_file_path)

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    temp_file_path = create_temp_file("")

# Generated at 2022-06-18 06:19:03.617535
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["some_env_var"] = "some_env_var_value"
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("some_var = 'some_value'")
        temp_file.seek(0)
        module = load_module_from_file_location(
            temp_file.name, "/some/path/${some_env_var}"
        )
        assert module.some_var == "some_value"

    # A) Check if location contains any environment variables
    #    in format ${

# Generated at 2022-06-18 06:19:14.326908
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # Test 1:
    # Test if function can load module from file location
    # with environment variables in it.
    #
    # Create temporary file with some content.
    with tempfile.NamedTemporaryFile(mode="w+", delete=False) as f:
        f.write("some_var = 'some_value'")
        f.flush()
        f.close()
    # Set environment variable with path to temporary file.
    os.environ["TEST_ENV_VAR"] = f.name
    # Load module from file location with environment variable in it.
    module = load_module_from_file_location(
        "some_module_name", "${TEST_ENV_VAR}"
    )
    # Check if module was loaded.
    assert module.some_

# Generated at 2022-06-18 06:19:21.306835
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import tempfile

    # A) Test with file path.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / "tmp_file.py"
        tmp_file.write_text("some_var = 'some_value'")
        module = load_module_from_file_location(tmp_file)
        assert module.some_var == "some_value"

    # B) Test with file path and environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / "tmp_file.py"
        tmp_file.write_text("some_var = 'some_value'")

# Generated at 2022-06-18 06:19:32.455811
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_env_var_value"
    assert (
        load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var}"
        ).__file__
        == "/some/path/some_env_var_value"
    )
    del os_environ["some_env_var"]

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_en

# Generated at 2022-06-18 06:19:41.454174
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test loading module from file.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
    assert module.a == 1

    # B) Test loading module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location("${TEST_ENV_VAR}")
    assert module.a == 1

    # C) Test loading module from file with environment variables
   

# Generated at 2022-06-18 06:19:50.687174
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os
    import sys

    # A) Create temporary directory.
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    # B) Create temporary module.
    with open("temp_module.py", "w") as f:
        f.write("some_var = 'some_value'")

    # C) Load module.
    temp_module = load_module_from_file_location("temp_module.py")

    # D) Check that module is loaded.
    assert temp_module.some_var == "some_value"

    # E) Check that module is not in sys.modules.
    assert "temp_module" not in sys.modules

    # F) Remove temporary directory.
    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 06:20:00.374456
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    location = "some_module_name"
    location_with_env_var = "some_module_name/${TEST_ENV_VAR}"
    assert (
        load_module_from_file_location(location)
        == load_module_from_file_location(location_with_env_var)
    )

    # B) Check these variables exists in environment.
    location_with_not_defined_env_var = "some_module_name/${NOT_DEFINED_ENV_VAR}"

# Generated at 2022-06-18 06:20:29.370175
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("test_var = 'test'")

    # Create temporary environment variable
    os.environ["TEST_ENV_VAR"] = tmp_dir

    # Test load_module_from_file_location
    module = load_module_from_file_location(tmp_file)
    assert module.test_var == "test"

    module = load_module_from_file_location(
        "${TEST_ENV_VAR}/tmp_file.py"
    )
   

# Generated at 2022-06-18 06:20:40.214469
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    import os
    import tempfile
    import shutil

    def create_temp_file(content):
        fd, path = tempfile.mkstemp()
        with os.fdopen(fd, "w") as tmp:
            tmp.write(content)
        return path

    def create_temp_dir():
        return tempfile.mkdtemp()

    def remove_temp_file(path):
        os.remove(path)

    def remove_temp_dir(path):
        shutil.rmtree(path)

    def test_load_module_from_file_location_with_env_var_in_location(
        monkeypatch
    ):
        monkeypatch.setenv("SOME_ENV_VAR", "some_value")

# Generated at 2022-06-18 06:20:49.545581
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test if function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location("${TEST_ENV_VAR}")
        assert module.a == 1



# Generated at 2022-06-18 06:20:55.641994
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location, path)
    assert module.__name__ == "some_module_name"
    assert module.__file__ == "/some/path/some_env_var_value"

    # B) Check these variables exists in environment.
    del os_environ["some_env_var"]

# Generated at 2022-06-18 06:21:06.237810
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # Test 1:
    # Check if function raises LoadFileException
    # when environment variable is not set.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = Path(tmp_dir) / "test.py"
        tmp_file.write_text("test_var = 'test'")
        with pytest.raises(LoadFileException):
            load_module_from_file_location(
                tmp_file, "${SOME_ENV_VAR}"
            )

    # Test 2:
    # Check if function raises IOError
    # when file does not exist.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = Path(tmp_dir) / "test.py"
        with pytest.raises(IOError):
            load_

# Generated at 2022-06-18 06:21:14.262548
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "/some/path/${some_env_var}"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert env_vars_in_location == {"some_env_var"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not_defined_env_vars == set()

    # C) Substitute them in location.

# Generated at 2022-06-18 06:21:24.220273
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["TEST_ENV_VAR"] = "test_env_var_value"
    module = load_module_from_file_location(
        "test_module_name", "/some/path/${TEST_ENV_VAR}"
    )
    assert module.__file__ == "/some/path/test_env_var_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.

# Generated at 2022-06-18 06:21:34.139319
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "test_file.py")
        with open(tmp_file, "w") as f:
            f.write("test_var = 'test_value'")
        module = load_module_from_file_location(tmp_file)
        assert module.test_var == "test_value"

        tmp_file = os.path.join

# Generated at 2022-06-18 06:21:42.263279
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check that location is a pathlib.Path object.
    # E) Check that location is a string.
    # F) Check that location is a bytes object.
    # G) Check that location is a string with .py extension.
    # H) Check that location is a string without .py extension.
    # I) Check that location is a string with .py extension
    #    and contains environment variables in format ${some_env_var}.
    # J) Check that location is a string without .py extension
    #    and contains environment variables in format ${some_env_var}.
    # K) Check that location is a

# Generated at 2022-06-18 06:21:47.906784
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from os import path
    from tempfile import TemporaryDirectory
    from unittest import TestCase

    class TestLoadModuleFromFileLocation(TestCase):
        def setUp(self):
            self.tmp_dir = TemporaryDirectory()
            self.tmp_dir_path = self.tmp_dir.name
            self.tmp_file_path = path.join(self.tmp_dir_path, "test.py")
            self.tmp_file_path_without_ext = path.join(
                self.tmp_dir_path, "test"
            )
            self.tmp_file_path_with_env_var = path.join(
                self.tmp_dir_path, "${TEST_ENV_VAR}.py"
            )
            self.tmp_file_path_with_env_