

# Generated at 2022-06-18 06:12:20.121280
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Create temporary file.
    temp_file = tempfile.NamedTemporaryFile(mode="w+", delete=False)
    temp_file.write("some_var = 'some_value'")
    temp_file.close()

    # B) Load module from this file.
    module = load_module_from_file_location(temp_file.name)

    # C) Check if module contains variable some_var.
    assert module.some_var == "some_value"

    # D) Cleanup.
    os.unlink(temp_file.name)

# Generated at 2022-06-18 06:12:28.855869
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=tmp_dir, delete=False
    )
    tmp_file.write("a = 1")
    tmp_file.close()

    # Create temporary file with environment variable
    tmp_file_with_env_var = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=tmp_dir, delete=False
    )
    tmp_file_with_env_var.write("b = 2")
    tmp_file_with_env_var.close()

    # Create temporary file with environment variable
    tmp_file_with_env_var_in

# Generated at 2022-06-18 06:12:39.777515
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, "test_file.py"), "w") as f:
            f.write("TEST_VAR = 'test_var'")
        sys.path.append(tmpdirname)

# Generated at 2022-06-18 06:12:48.195093
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function.
    """
    # Test for loading module from file.
    module = load_module_from_file_location(
        "tests/test_files/test_config.py"
    )
    assert module.TEST_CONFIG_VARIABLE == "test_config_value"

    # Test for loading module from file with environment variables.
    os_environ["TEST_ENV_VARIABLE"] = "test_env_value"
    module = load_module_from_file_location(
        "tests/test_files/${TEST_ENV_VARIABLE}_config.py"
    )
    assert module.TEST_CONFIG_VARIABLE == "test_env_value_config_value"

    # Test for loading

# Generated at 2022-06-18 06:12:59.835526
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("test_var = 'test_var'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.test_var == "test_var"


# Generated at 2022-06-18 06:13:10.452805
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    assert (
        load_module_from_file_location(
            location, "/some/path/${some_env_var}"
        ).__file__
        == "/some/path/some_env_var_value"
    )

    # B) Check these variables exists in environment.
    os.environ.pop("some_env_var")
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location, "/some/path/${some_env_var}")

    # C) Substitute them

# Generated at 2022-06-18 06:13:15.724637
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if function can load module from file.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        module = load_module_from_file_location(
            "test_module", "${TEST_ENV_VAR}/test_module.py"
        )
        assert module.test_var == "test_value"

    # B) Test if function can load module from file with absolute path.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        module = load_module_from_file_location(
            f"{tmpdirname}/test_module.py"
        )


# Generated at 2022-06-18 06:13:25.548989
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables
    #    in format ${some_env_var}.
    #    Mark that $some_env_var will not be resolved as environment variable.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        module = load_module_from_file_location(
            "some_module_name", f"/some/path/${{TEST_ENV_VAR}}"
        )
        assert module.__file__ == f"{tmpdirname}/some/path/"

    # B) Test with environment variables
    #    in format ${some_env_var}.
    #    Mark that $some_env_var will not be resolved as environment variable.

# Generated at 2022-06-18 06:13:35.059081
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-18 06:13:43.626154
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from sanic.exceptions import LoadFileException, PyFileError

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / "tmp_file.py"
        tmp_file.write_text("a = 1")
        environ["TMP_FILE"] = str(tmp_file)
        assert (
            load_module_from_file_location(
                "${TMP_FILE}",
            ).a == 1
        )

    # A) Check if location

# Generated at 2022-06-18 06:13:53.964399
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if file exists.
    # E) Check if file is a python file.
    # F) Check if file is a module.
    # G) Check if file is a package.
    # H) Check if file is a directory.
    # I) Check if file is a file.
    # J) Check if file is a file with .py extension.
    # K) Check if file is a file with .pyc extension.
    # L) Check if file is a file with .pyo extension.
    # M) Check if file is a file with .

# Generated at 2022-06-18 06:14:04.112908
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    module = load_module_from_file_location(
        location, "/some/path/${some_env_var}"
    )
    assert module.__file__ == "/some/path/some_env_var_value"
    del os.environ["some_env_var"]

    # B) Check these variables exists in environment.
    location = "some_module_name"

# Generated at 2022-06-18 06:14:09.740738
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w+", suffix=".py", dir=temp_dir, delete=False
    )
    temp_file.write("test_var = 'test_value'")
    temp_file.close()

    # Create temporary environment variable
    os.environ["TEST_ENV_VAR"] = temp_dir

    # Test if module is loaded correctly
    module = load_module_from_file_location(
        "test_module", f"${TEST_ENV_VAR}/{temp_file.name}"
    )
    assert module.test_var == "test_value"

   

# Generated at 2022-06-18 06:14:20.031098
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test for function load_module_from_file_location.
    """
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    module = load_module_from_file_location(
        "test_module_name", "/some/path/${TEST_ENV_VAR}"
    )
    assert module.__file__ == "/some/path/test_env_var"
    assert module.__name__ == "test_module_name"
    del os_environ["TEST_ENV_VAR"]

    # A) Check if location contains any environment variables


# Generated at 2022-06-18 06:14:27.932852
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w", dir=tmp_dir, delete=False
    )

    # Write some content to temporary file
    tmp_file.write("some_var = 'some_value'")
    tmp_file.close()

    # Check that file is created
    assert os.path.exists(tmp_file.name)

    # Load module from temporary file
    module = load_module_from_file_location(tmp_file.name)

    # Check that module is loaded
    assert module

    # Check that module has attribute some_var
    assert hasattr(module, "some_var")

    # Check that

# Generated at 2022-06-18 06:14:37.312197
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["SOME_ENV_VAR"] = "some_env_var_value"
    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, "some_file.py")
    with open(tmp_file, "w") as f:
        f.write("some_var = 'some_value'")

# Generated at 2022-06-18 06:14:45.952209
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function works with string location.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test if function works with Path location.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(Path(f.name))
        assert module.a == 1

    # C) Test if function works with environment variables in location.

# Generated at 2022-06-18 06:14:55.745371
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    def _create_temp_file(content):
        with tempfile.NamedTemporaryFile(mode="w+", delete=False) as f:
            f.write(content)
            return f.name

    def _remove_temp_file(filename):
        import os

        os.remove(filename)

    # Test 1
    # Test if function works with string location
    # and if it can load module from string location.
    location = "sanic.exceptions"
    module = load_module_from_file_location(location)
    assert module.__name__ == "sanic.exceptions"

    # Test 2
    # Test if function works with bytes location
    # and if it can load module from bytes location.
    location = b"sanic.exceptions"
    module = load_module_from_

# Generated at 2022-06-18 06:15:05.528051
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    # A) Test with environment variables.
    with NamedTemporaryFile(mode="w") as f:
        f.write("some_var = 'some_value'")
        f.flush()
        os_environ["some_env_var"] = f.name
        module = load_module_from_file_location(
            "/some/path/${some_env_var}", encoding="utf8"
        )
        assert module.some_var == "some_value"

    # B) Test with Path object.
    with NamedTemporaryFile(mode="w") as f:
        f.write("some_var = 'some_value'")
        f.flush()

# Generated at 2022-06-18 06:15:13.324861
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import pytest

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w+", dir=temp_dir, suffix=".py"
    )
    temp_file.write("a = 1")
    temp_file.seek(0)

    # Create temporary file with environment variable
    temp_file_with_env = tempfile.NamedTemporaryFile(
        mode="w+", dir=temp_dir, suffix=".py"
    )
    temp_file_with_env.write("b = 2")
    temp_file_with_env.seek(0)

    # Create temporary file with environment variable
    temp_file_with_env_

# Generated at 2022-06-18 06:15:26.050193
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w+", suffix=".py", dir=temp_dir, delete=False
    )
    temp_file.write("test_var = 'test_value'")
    temp_file.close()

    # Create temporary file with environment variable
    temp_file_with_env_var = tempfile.NamedTemporaryFile(
        mode="w+", suffix=".py", dir=temp_dir, delete=False
    )
    temp_file_with_env_var.write("test_var = 'test_value'")
    temp_file_with_env_var.close()

    # Create

# Generated at 2022-06-18 06:15:35.775558
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w+", suffix=".py", dir=temp_dir, delete=False
    )
    temp_file.write("a = 1")
    temp_file.close()
    # Create temporary file with env variable in path
    temp_file_with_env_var = tempfile.NamedTemporaryFile(
        mode="w+", suffix=".py", dir=temp_dir, delete=False
    )
    temp_file_with_env_var.write("a = 2")
    temp_file_with_env_var.close()
    # Create temporary file with env variable in path
    temp

# Generated at 2022-06-18 06:15:43.877401
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    assert load_module_from_file_location(location)

    # B) Check these variables exists in environment.
    location = "some_module_name"
    os.environ.pop("some_env_var")
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    # C) Substitute them in location.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    assert load_module_

# Generated at 2022-06-18 06:15:54.206362
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function.
    """
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("test_var = 'test_value'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.test_var == "test_value"

    # A) Check if location contains any environment variables
    #    in format ${some

# Generated at 2022-06-18 06:16:02.956412
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location, path)
    assert module.__name__ == location
    assert module.__file__ == path
    del os.environ["some_env_var"]

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C

# Generated at 2022-06-18 06:16:13.522615
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import tempfile

    # A) Check if function raises exception when file does not exist.
    with pytest.raises(IOError):
        load_module_from_file_location("some_non_existing_file")

    # B) Check if function raises exception when file is not a python file.
    with tempfile.NamedTemporaryFile() as temp_file:
        with pytest.raises(PyFileError):
            load_module_from_file_location(temp_file.name)

    # C) Check if function raises exception when environment variable
    #    is not set.
    with tempfile.NamedTemporaryFile(suffix=".py") as temp_file:
        with pytest.raises(LoadFileException):
            load_module_

# Generated at 2022-06-18 06:16:21.368506
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["some_env_var"] = "some_value"
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("some_var = 'some_value'")
        tmp_file.seek(0)
        module = load_module_from_file_location(
            tmp_file.name, "/some/path/${some_env_var}"
        )
        assert module.some_var == "some_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_

# Generated at 2022-06-18 06:16:31.655669
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function."""
    import tempfile

    # A) Test with file path.
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("some_var = 'some_value'")
        temp.seek(0)
        module = load_module_from_file_location(temp.name)
        assert module.some_var == "some_value"

    # B) Test with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("some_var = 'some_value'")
        temp.seek(0)
        os_environ["TEMP_FILE_PATH"] = temp.name

# Generated at 2022-06-18 06:16:42.036465
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test if function can load module from file location.
    module = load_module_from_file_location(
        "sanic.config.test_load_module_from_file_location",
        __file__,
    )
    assert module.__name__ == "sanic.config.test_load_module_from_file_location"

    # B) Test if function can load module from file location
    #    with environment variables in it.
    os_environ["SANIC_TEST_ENV_VAR"] = "test_env_var"

# Generated at 2022-06-18 06:16:51.293972
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Test with file path.
    # A.1) Test with .py file.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / "tmp_file.py"
        with open(tmp_file, "w") as f:
            f.write("test_var = 1")
        module = load_module_from_file_location(tmp_file)
        assert module.test_var == 1

    # A.2) Test with non .py file.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / "tmp_file"

# Generated at 2022-06-18 06:17:04.075839
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        dir=tmp_dir, suffix=".py", delete=False
    )

    # Write some code to temporary file
    tmp_file.write(b"test_var = 'test_value'")
    tmp_file.close()

    # Add temporary directory to sys.path
    sys.path.append(tmp_dir)

    # Load module from temporary file
    module = load_module_from_file_location(tmp_file.name)

    # Check if module has attribute test_var
    assert hasattr(module, "test_var")

    # Check if module.test_var is equal

# Generated at 2022-06-18 06:17:14.633553
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function works with string location.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test if function works with bytes location.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name.encode())
        assert module.a == 1

    # C) Test if function works with Path location.

# Generated at 2022-06-18 06:17:23.586661
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import tempfile

    # A) Test if function raises LoadFileException
    #    when environment variable is not set.
    with tempfile.NamedTemporaryFile() as config_file:
        with pytest.raises(LoadFileException):
            load_module_from_file_location(
                config_file.name, "${SOME_ENV_VAR_WHICH_IS_NOT_SET}"
            )

    # B) Test if function raises LoadFileException
    #    when environment variable is not set.

# Generated at 2022-06-18 06:17:34.318788
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    from os import environ as os_environ
    from os.path import join as os_path_join

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if location is a file path.
    # E) Check if location is a file path with .py extension.
    # F) Check if location is a module name.
    # G) Check if location is a module name with .py extension.
    # H) Check if location is a module name with .py extension
    #    and module is not in sys.path.
    # I) Check if location is a module name with .py extension
    #    and module is not in sys.path

# Generated at 2022-06-18 06:17:43.250112
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Create temporary file with some content
    temp_file = tempfile.NamedTemporaryFile(mode="w+", delete=False)
    temp_file.write("some_var = 'some_value'")
    temp_file.close()

    # Load module from this file
    module = load_module_from_file_location(temp_file.name)

    # Check that module has some_var attribute
    assert hasattr(module, "some_var")

    # Check that some_var attribute has correct value
    assert getattr(module, "some_var") == "some_value"

    # Remove temporary file
    os.remove(temp_file.name)

# Generated at 2022-06-18 06:17:52.379770
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["some_env_var"] = "some_value"
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.

# Generated at 2022-06-18 06:17:56.788368
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function works with bytes type
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name.encode())
        assert module.some_var == "some_value"

    # B) Test if function works with string type
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # C) Test if function works with Path type

# Generated at 2022-06-18 06:18:07.762799
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary file
    f = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    f.write(b"some_var = 'some_value'")
    f.close()

    # Create temporary file
    f = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    f.write(b"some_var = 'some_value'")
    f.close()

    # Create temporary file
    f = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    f.write(b"some_var = 'some_value'")
    f.close()

    # Create temporary file
    f = tempfile

# Generated at 2022-06-18 06:18:16.806941
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test if it works with string path.
    assert (
        load_module_from_file_location(
            "tests/test_utils/test_config.py"
        ).TEST_CONFIG_VARIABLE
        == "test_config_variable_value"
    )

    # B) Test if it works with bytes path.
    assert (
        load_module_from_file_location(
            b"tests/test_utils/test_config.py"
        ).TEST_CONFIG_VARIABLE
        == "test_config_variable_value"
    )

    # C) Test if it works with pathlib.Path path.

# Generated at 2022-06-18 06:18:24.674990
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if function raises LoadFileException
    #    when environment variable is not set.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        with open(os.path.join(tmpdirname, "test_file.py"), "w") as f:
            f.write("test_var = 'test_value'")
        with pytest.raises(LoadFileException):
            load_module_from_file_location(
                os.path.join(
                    "${TEST_ENV_VAR_NOT_SET}", "test_file.py"
                )
            )

    # B) Test if function raises LoadFileException
    #    when environment variable is not set.
   

# Generated at 2022-06-18 06:18:38.035612
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("TEST_CONSTANT = 'test_constant'")
        tmp_file.seek(0)
        module = load_module_from_file_location(
            tmp_file.name,
            "/some/path/${TEST_ENV_VAR}",
        )
        assert module.TEST_CONSTANT == "test_constant"

    # A

# Generated at 2022-06-18 06:18:46.130100
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary file
    f = open(os.path.join(tmpdir, "test.py"), "w")
    f.write("test = True")
    f.close()

    # Load module from temporary file
    module = load_module_from_file_location(os.path.join(tmpdir, "test.py"))

    # Check if module is loaded
    assert module.test

    # Remove temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-18 06:18:53.475949
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    assert module.__file__ == "/some/path/some_value"
    del os_environ["some_env_var"]

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.

# Generated at 2022-06-18 06:19:03.145263
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)

    # Write some content to temporary file
    tmp_file.write(b"a = 1")
    tmp_file.close()

    # Load module from temporary file
    mod = load_module_from_file_location(tmp_file.name)

    # Check if module has attribute a
    assert hasattr(mod, "a")

    # Check if module has attribute a equal to 1
    assert mod.a == 1

    # Remove temporary directory
    shutil.rmtree(tmp_dir)

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp

# Generated at 2022-06-18 06:19:13.877491
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys
    import importlib

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if module is loaded.
    # E) Check if module is loaded from correct file.
    # F) Check if module is loaded with correct name.
    # G) Check if module is loaded with correct attributes.
    # H) Check if module is loaded with correct attributes values.
    # I) Check if module is loaded with correct attributes types.
    # J) Check if module is loaded with correct attributes values.
    # K) Check if module is loaded with correct attributes types.
    # L) Check if module is loaded with correct attributes values.


# Generated at 2022-06-18 06:19:21.049375
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        config_file = temp_dir / "config.py"
        config_file.write_text("a = 1\nb = 2")
        module = load_module_from_file_location(config_file)
        assert module.a == 1
        assert module.b == 2

        config_file = temp_dir / "config"
        config_file.write_text("a = 1\nb = 2")
        module = load_module_from_file_location(config_file)
        assert module.a == 1
        assert module.b == 2

        config_file = temp_dir / "config.json"
        config_file.write_text('{"a": 1, "b": 2}')


# Generated at 2022-06-18 06:19:32.136714
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with environment variables.
    #    Create temporary file.
    temp_file = tempfile.NamedTemporaryFile(mode="w+")
    temp_file.write("TEST_VAR = 'test_value'")
    temp_file.seek(0)

    #    Set environment variable.
    os.environ["TEST_ENV_VAR"] = temp_file.name

    #    Load module.
    module = load_module_from_file_location(
        "${TEST_ENV_VAR}",
    )

    #    Check if module was loaded correctly.
    assert module.TEST_VAR == "test_value"

    #    Clean up.
    temp_file.close()

# Generated at 2022-06-18 06:19:41.161023
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w+", dir=tmpdir, suffix=".py", delete=False
    )

    # Write some content to temporary file
    temp_file.write("some_var = 'some_value'")
    temp_file.close()

    # Load module from temporary file
    module = load_module_from_file_location(temp_file.name)

    # Check if module has some_var variable
    assert hasattr(module, "some_var")

    # Check if some_var variable has correct value
    assert getattr(module, "some_var") == "some_value"

    # Remove temporary directory
    shutil

# Generated at 2022-06-18 06:19:50.374560
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Unit test for function load_module_from_file_location
    """
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    location = "some_module_name"
    location_with_env_var = "/some/path/${some_env_var}"
    assert (
        load_module_from_file_location(location_with_env_var)
        == load_module_from_file_location(location)
    )

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.

# Generated at 2022-06-18 06:20:00.099722
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    location = "./test_load_module_from_file_location.py"
    module = load_module_from_file_location(
        "./test_load_module_from_file_location.py"
    )
    assert module.TEST_ENV_VAR == "test_env_var"
    assert module.__file__ == location

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C)

# Generated at 2022-06-18 06:20:13.240354
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    # A) Test if function works with Path object.
    #    It should work with Path object.
    #    If it doesn't work, then it will raise an exception.
    load_module_from_file_location(Path(__file__))

    # B) Test if function works with environment variables in location.
    #    It should work with environment variables in location.
    #    If it doesn't work, then it will raise an exception.
    os_environ["SANIC_TEST_ENV_VAR"] = __file__
    load_module_from_file_location(
        "sanic_test_env_var/${SANIC_TEST_ENV_VAR}"
    )

# Generated at 2022-06-18 06:20:24.893837
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os_environ["TEST_ENV_VAR"] = tmpdirname
        location = f"{tmpdirname}/test_file.py"
        with open(location, "w") as f:
            f.write("test_var = 'test_value'")
        module = load_module_from_file_location(
            f"${TEST_ENV_VAR}/test_file.py"
        )
        assert module.test_var == "test_value"

    # A) Check if location contains any environment variables


# Generated at 2022-06-18 06:20:32.544843
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        dir=tmp_dir, suffix=".py", delete=False
    )
    # Write some content to temporary file
    tmp_file.write(b"a = 1\nb = 2\n")
    tmp_file.close()

    # Create temporary environment variable
    os.environ["TEST_ENV_VAR"] = tmp_dir
    # Create temporary file path
    tmp_file_path = Path(tmp_file.name)

    # Test with bytes

# Generated at 2022-06-18 06:20:43.366982
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if location is of a bytes type.
    # E) Check if location is of a Path type.
    # F) Check if location is of a string type.
    # G) Check if location is of a string type and contains .py extension.
    # H) Check if location is of a string type and does not contain .py
    #    extension.
    # I) Check if location is of a string type and does not contain .py
    #    extension and contains environment variables in format
    #    ${some_env_var}.

    # A) Check if location contains any environment

# Generated at 2022-06-18 06:20:51.883140
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function.
    """
    # Test that function is able to load module from file
    # with environment variables in path.
    os_environ["SOME_ENV_VAR"] = "some_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${SOME_ENV_VAR}"
    )
    assert module.__name__ == "some_module_name"

    # Test that function raises LoadFileException
    # if environment variable is not set.
    os_environ.pop("SOME_ENV_VAR")

# Generated at 2022-06-18 06:21:00.968280
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test if it works with string
    config_file = tempfile.NamedTemporaryFile(
        mode="w", prefix="config_", suffix=".py", delete=False
    )
    config_file.write("some_var = 'some_value'")
    config_file.close()
    module = load_module_from_file_location(config_file.name)
    assert module.some_var == "some_value"

    # B) Test if it works with Path
    module = load_module_from_file_location(Path(config_file.name))
    assert module.some_var == "some_value"

    # C) Test if it works with bytes
    module = load_module_from_file_location(config_file.name.encode())
    assert module.some

# Generated at 2022-06-18 06:21:12.001204
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables in location
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("test_var = 'test_value'")
        f.seek(0)
        module = load_module_from_file_location(
            f"${TEST_ENV_VAR}/{f.name}"
        )
        assert module.test_var == "test_value"

    # B) Test with bytes location
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("test_var = 'test_value'")
        f.seek(0)
        module = load_

# Generated at 2022-06-18 06:21:20.543451
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        test_file_path = os.path.join(tmpdirname, "test_file.py")
        with open(test_file_path, "w") as f:
            f.write("TEST_VAR = 'test_value'")
        module = load_module_from_file_location(
            "TEST_ENV_VAR/test_file.py"
        )
        assert module.TEST_VAR == "test_value"

    # B) Test with Path.
    with tempfile.TemporaryDirectory() as tmpdirname:
        test_file_path = os.path

# Generated at 2022-06-18 06:21:31.386398
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from os import remove
    from os import mkdir
    from os import path
    from tempfile import mkdtemp
    from shutil import rmtree

    # Test for location as a string
    # Test for location as a string with environment variables
    # Test for location as a Path
    # Test for location as a Path with environment variables
    # Test for location as a bytes
    # Test for location as a bytes with environment variables
    # Test for location as a string with non-existing environment variables
    # Test for location as a Path with non-existing environment variables
    # Test for location as a bytes with non-existing environment variables

    # Test for location as a string
    # Test for location as a string with environment variables
    # Test for location as a Path
    # Test for location as a Path with environment variables
    # Test for location

# Generated at 2022-06-18 06:21:39.197977
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import os

    # 1) Test with file path
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    module = load_module_from_file_location(
        "test_module",
        "/some/path/${TEST_ENV_VAR}/test_module.py",
        submodule_search_locations=["/some/path/${TEST_ENV_VAR}"],
    )
    assert module.test_var == "test_var"

    # 2) Test with file path and bytes

# Generated at 2022-06-18 06:21:53.541780
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)
    tmp_file.write(b"test_var = 'test_value'")
    tmp_file.close()

    # Create temporary environment variable
    os.environ["TEST_ENV_VAR"] = tmp_dir

    # Test load_module_from_file_location
    module = load_module_from_file_location(
        "${TEST_ENV_VAR}/" + tmp_file.name.split("/")[-1]
    )
    assert module.test_var == "test_value"

    # Remove temporary directory
   

# Generated at 2022-06-18 06:21:59.650938
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import shutil
    import tempfile

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary file
    fname = os.path.join(tmpdir, "test.py")
    with open(fname, "w") as f:
        f.write("test = 'test'")

    # Load module from temporary file
    module = load_module_from_file_location(fname)

    # Check if module was loaded correctly
    assert module.test == "test"

    # Remove temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-18 06:22:07.976151
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    module = load_module_from_file_location(
        location, "/some/path/${some_env_var}"
    )
    assert module.__name__ == "some_module_name"
    assert module.__file__ == "/some/path/some_env_var_value"

    # B) Check these variables exists in environment.
    os.environ.pop("some_env_var")