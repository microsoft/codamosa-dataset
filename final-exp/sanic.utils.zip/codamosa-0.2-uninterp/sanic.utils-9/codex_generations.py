

# Generated at 2022-06-18 06:12:25.730194
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-18 06:12:35.426313
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    def create_temp_file(content):
        fd, path = tempfile.mkstemp()
        with os.fdopen(fd, "w") as tmp:
            tmp.write(content)
        return path

    def remove_temp_file(path):
        os.remove(path)

    # Test for loading file with environment variables
    os.environ["SOME_ENV_VAR"] = "some_env_var"
    path = create_temp_file("some_var = 'some_value'")
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${SOME_ENV_VAR}/" + path
    )
    assert module.some_var == "some_value"
    remove_temp_file

# Generated at 2022-06-18 06:12:45.390295
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 1
    # Test with file path
    file_path = "tests/test_config.py"
    module = load_module_from_file_location(file_path)
    assert module.TEST_VARIABLE == "test_value"

    # Test 2
    # Test with file path and environment variables
    file_path = "tests/${TEST_ENV_VAR}/test_config.py"
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    module = load_module_from_file_location(file_path)
    assert module.TEST_VARIABLE == "test_value"

    # Test 3
    # Test with file path and environment variables
    # and with bytes type

# Generated at 2022-06-18 06:12:56.080516
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests load_module_from_file_location function."""
    # Test for loading module from file location
    # with environment variables in it.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    module = load_module_from_file_location(
        "test_module",
        "/some/path/${TEST_ENV_VAR}/test_module.py",
    )
    assert module.test_var == "test_var"
    del os_environ["TEST_ENV_VAR"]

    # Test for loading module from file location
    # with environment variables in it.
    # But with not defined environment variable.

# Generated at 2022-06-18 06:13:04.763172
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test for function load_module_from_file_location
    """
    from tempfile import TemporaryDirectory
    from os import environ
    from os.path import join
    from shutil import copyfile

    # Create temporary directory
    with TemporaryDirectory() as tmp_dir:
        # Create temporary file
        tmp_file = join(tmp_dir, "tmp_file.py")
        copyfile(__file__, tmp_file)

        # Test for file path
        module = load_module_from_file_location(tmp_file)
        assert module.__file__ == tmp_file

        # Test for bytes path
        module = load_module_from_file_location(tmp_file.encode())
        assert module.__file__ == tmp_file

        # Test for Path path
        module = load_module_from_

# Generated at 2022-06-18 06:13:15.029903
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-18 06:13:25.281763
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("test_var = 'test_value'")
        f.seek(0)
        module = load_module_from_file_location(
            f.name, "/some/path/${TEST_ENV_VAR}"
        )
    assert module.test_var == "test_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_

# Generated at 2022-06-18 06:13:34.799231
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-18 06:13:43.420206
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-18 06:13:50.483029
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["SOME_ENV_VAR"] = "some_env_var_value"
    temp_dir = tempfile.TemporaryDirectory()
    temp_file_path = Path(temp_dir.name) / "some_file.py"
    temp_file_path.touch()
    location = str(temp_file_path)
    location_with_env_var = location.replace(
        temp_dir.name, "${SOME_ENV_VAR}"
    )
    module = load_module_from_file_location(location_with_env_var)

# Generated at 2022-06-18 06:14:03.329717
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from pathlib import Path

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)

        # Test if it works with Path
        tmp_file = tmp_dir / "tmp_file.py"
        tmp_file.touch()
        assert load_module_from_file_location(tmp_file)

        # Test if it works with string
        tmp_file = tmp_dir / "tmp_file.py"
        tmp_file.touch()
        assert load_module_from_file_location(str(tmp_file))

        # Test if it works with bytes
        tmp_file = tmp_dir / "tmp_file.py"
        tmp_file.touch()
        assert load_module_from_file_location(bytes(tmp_file))

        # Test if

# Generated at 2022-06-18 06:14:12.239041
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=temp_dir, delete=False
    )
    temp_file.write("a = 1")
    temp_file.close()

    # Create temporary file with environment variable
    temp_file_env = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=temp_dir, delete=False
    )
    temp_file_env.write("b = 2")
    temp_file_env.close()

    # Create temporary file with environment variable

# Generated at 2022-06-18 06:14:22.412349
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # Test 1:
    # Test if function can load module from file location.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("test_var = 'test_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.test_var == "test_value"

    # Test 2:
    # Test if function can load module from file location
    # with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("test_var = 'test_value'")
        f.seek(0)
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module

# Generated at 2022-06-18 06:14:29.047123
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function.
    """
    import os
    import tempfile
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    test_config = """
    TEST_VAR = "test_var"
    """
    with tempfile.TemporaryDirectory() as tmpdirname:
        test_config_path = os.path.join(tmpdirname, "test_config.py")
        with open(test_config_path, "w") as f:
            f.write(test_config)
        test_config

# Generated at 2022-06-18 06:14:38.485448
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test with file path
    assert (
        load_module_from_file_location(
            "tests/test_helpers/test_config.py"
        ).TEST_CONFIG_VARIABLE
        == "test_config_variable"
    )

    # Test with file path and environment variables
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    assert (
        load_module_from_file_location(
            "tests/test_helpers/${TEST_ENV_VAR}/test_config.py"
        ).TEST_CONFIG_VARIABLE
        == "test_config_variable"
    )

    # Test with file path and environment variables

# Generated at 2022-06-18 06:14:46.863069
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # 1) Test with environment variables.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("TEST_VAR = 'test_var'")
        f.flush()
        module = load_module_from_file_location(
            f"${TEST_ENV_VAR}/{f.name}"
        )
        assert module.TEST_VAR == "test_var"

    # 2) Test with Path object.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("TEST_VAR = 'test_var'")

# Generated at 2022-06-18 06:14:56.633540
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["test_env_var"] = "test_env_var_value"
    location = "test_module_name"
    location_with_env_var = "${test_env_var}/test_module_name"
    location_with_env_var_in_path = "test_env_var_value/test_module_name"
    location_with_env_var_in_path_and_name = (
        "test_env_var_value/test_env_var_value"
    )

    # B) Check these variables exists in environment.
    not_defined_env_var = "not_defined_env_var"
    location_with_

# Generated at 2022-06-18 06:15:06.512303
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    def _create_temp_file(content):
        fd, path = tempfile.mkstemp()
        with os.fdopen(fd, "w") as tmp:
            tmp.write(content)
        return path

    def _remove_temp_file(path):
        os.remove(path)

    def _test_load_module_from_file_location(
        location,
        expected_module_name,
        expected_module_content,
        expected_module_file,
        encoding="utf8",
        *args,
        **kwargs
    ):
        module = load_module_from_file_location(
            location, encoding, *args, **kwargs
        )
        assert module.__name__ == expected_module_name
        assert module.__dict__ == expected

# Generated at 2022-06-18 06:15:13.874932
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    location = "some_module_name"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert not env_vars_in_location

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:15:24.220038
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from sanic.config import load_module_from_file_location

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    env_vars_in_location = set(re_findall(r"\${(.+?)}", "/some/path/${some_env_var}"))

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    if not_defined_env_vars:
        raise LoadFileException(
            "The following environment variables are not set: "
            f"{', '.join(not_defined_env_vars)}"
        )

    # C) Substitute them in location.

# Generated at 2022-06-18 06:15:36.041468
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables in location.
    #    Create temporary file.
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("test_var = 'test_value'")
        temp.seek(0)

        # Set environment variable to point to this file.
        os.environ["TEST_ENV_VAR"] = temp.name

        # Load module from this file.
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}", encoding="utf8"
        )

        # Check if module was loaded correctly.
        assert module.test_var == "test_value"

    # B) Test with environment variables in location.
    #    Create temporary file.

# Generated at 2022-06-18 06:15:43.962792
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Create temporary directory
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)

    # Create temporary file
    tmp_file = tmp_dir_path / "tmp_file.py"
    tmp_file.touch()
    tmp_file.write_text("some_var = 'some_value'")

    # Create temporary environment variable
    os.environ["TMP_ENV_VAR"] = str(tmp_dir_path)

    # Test
    module = load_module_from_file_location(
        tmp_file,
        "/some/path/${TMP_ENV_VAR}",
        "some_module_name",
        True,
        True,
    )


# Generated at 2022-06-18 06:15:54.286515
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # A) Test with file path
    # A.1) Test with file path and no environment variables
    # A.1.1) Test with file path and no environment variables and no .py extension
    # A.1.1.1) Test with file path and no environment variables and no .py extension and no file
    # A.1.1.2) Test with file path and no environment variables and no .py extension and file
    # A.1.2) Test with file path and no environment variables and .py extension
    # A.1.2.1) Test with file path and no environment variables and .py extension and no file
    # A.1.2.2) Test with file path and no environment variables and .py extension and file
    # A.2) Test with file path and environment variables


# Generated at 2022-06-18 06:16:03.020306
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import os
    import tempfile
    import shutil

    # A) Test if function can load module from file.
    #    Create temporary directory.
    tmp_dir = tempfile.mkdtemp()
    #    Create temporary file with some content.
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=tmp_dir, delete=False
    )
    tmp_file.write("some_var = 'some_value'")
    tmp_file.close()
    #    Load module from this file.
    module = load_module_from_file_location(tmp_file.name)
    #    Check if module has some_var variable with some_value value.

# Generated at 2022-06-18 06:16:13.561550
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with file path.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file_path = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("a = 1")
        module = load_module_from_file_location(tmp_file_path)
        assert module.a == 1

    # B) Test with environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file_path = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("a = 1")


# Generated at 2022-06-18 06:16:21.365488
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_value"
    location = "some_module_name"
    assert load_module_from_file_location(location) is None

    # B) Check these variables exists in environment.
    location = "some_module_name"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    # C) Substitute them in location.
    location = "/some/path/${some_env_var}"
    assert load_module_from_file_location(location) is None

    # D) Check if location contains any environment variables
    #    in format $some_env_var.

# Generated at 2022-06-18 06:16:31.655924
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    from tempfile import NamedTemporaryFile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with NamedTemporaryFile(mode="w+", suffix=".py") as tmp_file:
        tmp_file.write("some_var = 'some_value'")
        tmp_file.flush()
        os.environ["some_env_var"] = tmp_file.name
        module = load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var}"
        )
        assert module.some_var == "some_value"

    # A) Check if location contains any environment variables
    #    in format

# Generated at 2022-06-18 06:16:42.075794
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    from tempfile import TemporaryDirectory
    from os import environ as os_environ
    from os import path as os_path
    from shutil import copyfile

    with TemporaryDirectory() as tmp_dir:
        os_environ["TEST_ENV_VAR"] = tmp_dir
        os_environ["TEST_ENV_VAR_2"] = "test_env_var_2"
        os_environ["TEST_ENV_VAR_3"] = "test_env_var_3"

        # Create test file
        test_file_path = os_path.join(tmp_dir, "test_file.py")

# Generated at 2022-06-18 06:16:48.875765
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function.
    """
    import os
    import tempfile
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if location is of a string type.
    # E) Check if location is of a bytes type.
    # F) Check if location is of a pathlib.Path type.
    # G) Check if location is of a pathlib.Path type.
    # H) Check if location is of a pathlib.Path type.
    # I) Check if location is of a pathlib.Path type.
    # J) Check if location is of a pathlib.Path type.
    # K)

# Generated at 2022-06-18 06:16:59.649429
# Unit test for function load_module_from_file_location

# Generated at 2022-06-18 06:17:11.962197
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function.
    """
    import sys
    import os
    import tempfile
    import shutil

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=temp_dir, delete=False
    )
    temp_file.write("a = 1")
    temp_file.close()

    # Create temporary file with environment variable
    temp_file_with_env_var = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=temp_dir, delete=False
    )
    temp_file_with_env_var.write("b = 2")
    temp_file_with_

# Generated at 2022-06-18 06:17:22.070573
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    location_with_env_var = "some_module_name_with_env_var"
    location_with_env_var_value = "some_module_name_with_env_var_value"
    location_with_env_var_value_and_path = (
        "some_module_name_with_env_var_value_and_path"
    )

    # B) Check these variables exists in environment.
    not_defined_env_var = "not_defined_env_var"
    location_with_not_defined_

# Generated at 2022-06-18 06:17:32.156658
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    from os import environ as os_environ
    from os import remove as os_remove
    from os import system as os_system
    from os import chdir as os_chdir
    from os import getcwd as os_getcwd
    from os import mkdir as os_mkdir
    from os import rmdir as os_rmdir
    from os import path as os_path
    from tempfile import mkdtemp as tempfile_mkdtemp

    from pytest import raises

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if module is loaded correctly.
    # E)

# Generated at 2022-06-18 06:17:42.670517
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Create temporary file with some content.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as temp_file:
        temp_file.write("some_var = 'some_value'")
        temp_file.flush()

        # B) Load module from this file.
        module = load_module_from_file_location(temp_file.name)

        # C) Check that module has some_var variable.
        assert hasattr(module, "some_var")

        # D) Check that this variable has expected value.
        assert module.some_var == "some_value"

    # E) Create temporary file with some content.

# Generated at 2022-06-18 06:17:51.988124
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["SOME_ENV_VAR"] = "some_env_var_value"
    location = "some_module_name"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert not env_vars_in_location

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:18:05.494096
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create temporary file
    tmpfile = os.path.join(tmpdir, "tmpfile.py")
    with open(tmpfile, "w") as f:
        f.write("a = 1")
    # Create temporary module
    sys.path.insert(0, tmpdir)
    import tmpfile as tmp_module

    # Test if module is loaded
    assert load_module_from_file_location(tmpfile) == tmp_module

    # Test if environment variables are resolved
    os.environ["TEST_ENV_VAR"] = "test_env_var"

# Generated at 2022-06-18 06:18:12.600646
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Create temporary file with some content.
    with tempfile.NamedTemporaryFile(mode="w+", delete=False) as temp:
        temp.write("test_var = 'test_value'")

    # B) Load this file as module.
    module = load_module_from_file_location(temp.name)

    # C) Check if module has a test_var variable with a test_value value.
    assert module.test_var == "test_value"

    # D) Remove temporary file.
    os.remove(temp.name)



# Generated at 2022-06-18 06:18:20.476123
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with empty file.
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmp_file = os.path.join(tmpdirname, "tmp_file.py")
        with open(tmp_file, "w") as f:
            f.write("")
        module = load_module_from_file_location(tmp_file)
        assert module.__file__ == tmp_file

    # B) Test with file containing only one variable.
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmp_file = os.path.join(tmpdirname, "tmp_file.py")
        with open(tmp_file, "w") as f:
            f.write("some_var = 1")
        module = load_module_from_file_location

# Generated at 2022-06-18 06:18:31.002416
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test with environment variables
    #    in format ${some_env_var}.
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
        tmp_file = tmpdirname / "test_file.py"
        tmp_file.touch()
        os_environ["TEST_ENV_VAR"] = str(tmpdirname)
        module = load_module_from_file_location(
            "test_file", "${TEST_ENV_VAR}/test_file.py"
        )
        assert module.__file__ == str(tmp_file)
        del os_environ["TEST_ENV_VAR"]

    # B) Test with environment variables
    #    in format $some_env_var.
   

# Generated at 2022-06-18 06:18:38.330377
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove
    from os import makedirs as os_makedirs
    from os import getcwd as os_getcwd
    from os import chdir as os_chdir
    from os import getenv as os_getenv
    from os import putenv as os_putenv
    from os import listdir as os_listdir
    from os import rmdir as os_rmdir
    from shutil import rmtree as shutil_rmtree
    from tempfile import mkdtemp as tempfile_mkdtemp
    from tempfile import mkstemp as tempfile_mkstemp
    from tempfile import gettempdir as tempfile_gettempdir
    from tempfile import mktemp as tempfile_mktemp

# Generated at 2022-06-18 06:18:52.004414
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        with open(os.path.join(tmpdirname, "test_file.py"), "w") as f:
            f.write("TEST_VAR = 'test_value'")
        module = load_module_from_file_location(
            "test_file", "${TEST_ENV_VAR}/test_file.py"
        )
        assert module.TEST_VAR == "test_value"

    # B) Test with pathlib.Path.

# Generated at 2022-06-18 06:19:01.707051
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, "test_file.py"), "w") as f:
            f.write("test_var = 'test_var'")
        test_module = load_module_from_file_location(
            os.path.join(tmpdirname, "test_file.py")
        )
        assert test_module.test_var == "test_var"


# Generated at 2022-06-18 06:19:11.455902
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # B) Create temporary file with some content
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("some_var = 'some_value'")

    # C) Load module from this file
    module = load_module_from_file_location(tmp_file)

    # D) Check that module has some_var variable
    assert hasattr(module, "some_var")

    # E) Remove temporary directory
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 06:19:19.449559
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with a file path.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file, "w") as f:
            f.write("a = 1")

        module = load_module_from_file_location(tmp_file)
        assert module.a == 1

    # B) Test with a file path with environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file, "w") as f:
            f.write("a = 1")

        os.environ["TMP_DIR"] = tmp

# Generated at 2022-06-18 06:19:29.634886
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    # A) Test loading module from file path.
    with NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # B) Test loading module from file path with environment variables.
    with NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        os_environ["some_env_var"] = f.name

# Generated at 2022-06-18 06:19:39.036489
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys
    import importlib
    import pytest

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w",
        suffix=".py",
        dir=tmp_dir,
        delete=False,
    )
    # Write some content to temporary file
    tmp_file.write("some_var = 1")
    tmp_file.close()

    # Create temporary directory
    tmp_dir2 = tempfile.mkdtemp()
    # Create temporary file

# Generated at 2022-06-18 06:19:45.486759
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with file path.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test with file path and environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.seek(0)
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location(
            "/some/path/${TEST_ENV_VAR}"
        )
        assert module.a == 1

    # C

# Generated at 2022-06-18 06:19:55.393946
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import sys

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("test_var = 'test_var'")
        f.seek(0)
        module = load_module_from_file_location(
            f.name,
            "/some/path/${TEST_ENV_VAR}",
            origin="test_load_module_from_file_location",
        )

# Generated at 2022-06-18 06:20:04.242614
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    # A) Test with file path.
    # A.1) Test with relative path.
    # A.1.1) Test with relative path and .py extension.
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        temp_file = temp_dir / "test_file.py"
        temp_file.touch()
        temp_file.write_text("test_var = 'test_value'")
        module = load_module_from_file_location(temp_file)
        assert module.test_var == "test_value"

    # A.1.2) Test with relative path and without .py extension.
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)

# Generated at 2022-06-18 06:20:12.041738
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys
    import tempfile

    from sanic.exceptions import LoadFileException

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["SOME_ENV_VAR"] = "some_value"
    location = "some_module_name"
    assert load_module_from_file_location(location) is None

    # B) Check these variables exists in environment.
    location = "some_module_name"
    os.environ.pop("SOME_ENV_VAR")
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    # C) Substitute them in location.

# Generated at 2022-06-18 06:20:32.231820
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var_value"
    module = load_module_from_file_location(
        "test_module", "test_module.py", "/some/path/${TEST_ENV_VAR}"
    )
    assert module.TEST_VAR == "test_module_value"

    # B) Check these variables exists in environment.
    os_environ.pop("TEST_ENV_VAR")

# Generated at 2022-06-18 06:20:39.812298
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Create temporary file
    fd, path = tempfile.mkstemp(suffix=".py")
    with os.fdopen(fd, "w") as tmp:
        tmp.write("test_var = 'test_value'")

    # Load module from file
    module = load_module_from_file_location(path)

    # Check if module was loaded correctly
    assert module.test_var == "test_value"

    # Remove temporary file
    os.remove(path)

# Generated at 2022-06-18 06:20:49.219051
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if function can load module from file.
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Create a file with some content.
        file_path = os.path.join(tmpdirname, "some_file.py")
        with open(file_path, "w") as f:
            f.write("some_var = 'some_value'")

        # Load module from file.
        module = load_module_from_file_location(file_path)

        # Check if module has some_var variable.
        assert module.some_var == "some_value"

    # B) Test if function can load module from file with environment variables.
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Create a file with some content.
        file_

# Generated at 2022-06-18 06:20:55.438790
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Test loading module from file path.
    #    1) Create temporary directory.
    temp_dir = tempfile.mkdtemp()

    #    2) Create temporary file with some content.
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", dir=temp_dir, delete=False
    )
    temp_file.write("some_var = 'some_value'")
    temp_file.close()

    #    3) Load module from this file.
    module = load_module_from_file_location(temp_file.name)

    #    4) Check that module has attribute some_var with value 'some_value'.
    assert hasattr(module, "some_var")

# Generated at 2022-06-18 06:21:06.057852
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test if function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test if function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        os_environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}"
        )  # type: ignore

# Generated at 2022-06-18 06:21:14.141085
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test if it works with string.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test if it works with Path.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(Path(f.name))
        assert module.a == 1

    # C) Test if it works with bytes.

# Generated at 2022-06-18 06:21:24.098062
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("test_var = 'test_var'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.test_var == "test_var"

    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("test_var = 'test_var'")


# Generated at 2022-06-18 06:21:34.041314
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Test 1:
    # Test if function can load module from file
    # when file path is provided as a string.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.chdir(tmpdirname)
        with open("test_module.py", "w") as f:
            f.write("test_var = 'test_value'")

        module = load_module_from_file_location("test_module.py")
        assert module.test_var == "test_value"

    # Test 2:
    # Test if function can load module from file
    # when file path is provided as a Path object.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.chdir(tmpdirname)

# Generated at 2022-06-18 06:21:42.157501
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Test with environment variables.
    #    1) Create temporary directory.
    tmp_dir = tempfile.mkdtemp()
    #    2) Create temporary file in it.
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("x = 1")
    #    3) Set environment variable.
    os.environ["TEST_ENV_VAR"] = tmp_dir
    #    4) Test.
    module = load_module_from_file_location(
        "${TEST_ENV_VAR}/tmp_file.py"
    )
    assert module.x == 1
    #    5) Remove temporary directory.

# Generated at 2022-06-18 06:21:50.442195
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "${some_env_var}/some_path/some_file.py"
    assert (
        load_module_from_file_location(location).__file__
        == "some_env_var_value/some_path/some_file.py"
    )

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os