

# Generated at 2022-06-18 06:12:18.058838
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-18 06:12:27.405158
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-18 06:12:37.979970
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-18 06:12:50.437046
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-18 06:13:01.200756
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-18 06:13:12.061383
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-18 06:13:22.671671
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-18 06:13:30.752941
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Tests load_module_from_file_location function.
    """
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["SOME_ENV_VAR"] = "some_env_var_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${SOME_ENV_VAR}"
    )
    assert module.__file__ == "/some/path/some_env_var_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Subst

# Generated at 2022-06-18 06:13:40.495892
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # A) Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # B) Create temporary file with some content
    tmp_file_path = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file_path, "w") as tmp_file:
        tmp_file.write("test_var = 'test_value'")

    # C) Create environment variable
    os.environ["TEST_ENV_VAR"] = tmp_dir

    # D) Test function load_module_from_file_location
    module = load_module_from_file_location(
        "tmp_file", "${TEST_ENV_VAR}", "r", True
    )
    assert module.test_var

# Generated at 2022-06-18 06:13:46.653161
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-18 06:14:00.020202
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile(mode="w+") as f:
        f.write("test_var = 'test_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.test_var == "test_value"

    with NamedTemporaryFile(mode="wb+") as f:
        f.write(b"test_var = 'test_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name, encoding="utf8")
        assert module.test_var == "test_value"

    with NamedTemporaryFile(mode="w+") as f:
        f.write("test_var = 'test_value'")

# Generated at 2022-06-18 06:14:07.209009
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import sys

    # Test 1
    # Check if function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("test_var = 'test_value'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.test_var == "test_value"

    # Test 2
    # Check if function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("test_var = 'test_value'")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name

# Generated at 2022-06-18 06:14:16.666393
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(mode="w", dir=tmp_dir, delete=False)
    tmp_file.write("test_var = 'test_value'")
    tmp_file.close()

    # Create temporary environment variable
    os.environ["TEST_ENV_VAR"] = tmp_dir

    # Test load_module_from_file_location
    module = load_module_from_file_location(
        "${TEST_ENV_VAR}/" + tmp_file.name.split("/")[-1]
    )
    assert module.test_var == "test_value"

    # Remove temporary directory

# Generated at 2022-06-18 06:14:25.767888
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(mode="w+", suffix=".py")
    temp_file.write("test_var = 'test_value'")
    temp_file.seek(0)

    # Test if file is loaded correctly
    module = load_module_from_file_location(temp_file.name)
    assert module.test_var == "test_value"

    # Test if file is loaded correctly with environment variable
    os.environ["TEST_ENV_VAR"] = temp_file.name

# Generated at 2022-06-18 06:14:33.319821
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import sys
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create temporary module
    tmp_module_path = os.path.join(tmp_dir, "tmp_module.py")
    with open(tmp_module_path, "w") as tmp_module:
        tmp_module.write("tmp_var = 1")
    # Add temporary directory to system path
    sys.path.append(tmp_dir)

    # Test if module is loaded
    tmp_module = load_module_from_file_location(tmp_module_path)
    assert tmp_module.tmp_var == 1

    # Remove temporary directory
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 06:14:43.448671
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables.
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Create test file.
        path = os.path.join(tmpdirname, "test.py")
        with open(path, "w") as f:
            f.write("test_var = 'test'")

        # Set environment variable.
        os.environ["TEST_ENV_VAR"] = tmpdirname

        # Test.
        module = load_module_from_file_location(
            "test", "${TEST_ENV_VAR}/test.py"
        )
        assert module.test_var == "test"

    # B) Test with Path.

# Generated at 2022-06-18 06:14:51.720519
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, "test_file.py"), "w") as f:
            f.write("test_var = 'test_var'")
        module = load_module_from_file_location(
            os.path.join(tmpdirname, "test_file.py")
        )
        assert module.test_var == "test_var"

        module = load

# Generated at 2022-06-18 06:15:01.208341
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with file path
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, "test.py"), "w") as f:
            f.write("test_var = 'test_val'")

        module = load_module_from_file_location(
            os.path.join(tmpdirname, "test.py")
        )
        assert module.test_var == "test_val"

    # B) Test with environment variable
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, "test.py"), "w") as f:
            f.write("test_var = 'test_val'")


# Generated at 2022-06-18 06:15:10.725803
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, "test_file.py"), "w") as f:
            f.write("test_var = 'test_value'")
        module = load_module_from_file_location(
            os.path.join(tmpdirname, "${TEST_ENV_VAR}", "test_file.py")
        )
        assert module.test_

# Generated at 2022-06-18 06:15:22.005840
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys
    import pytest

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if module is loaded.
    # E) Check if module is loaded with correct value.
    # F) Check if module is loaded with correct value.
    # G) Check if module is loaded with correct value.
    # H) Check if module is loaded with correct value.
    # I) Check if module is loaded with correct value.
    # J) Check if module is loaded with correct value.
    # K) Check if module is loaded with correct value.
    # L) Check if module is loaded with correct value.
    # M) Check

# Generated at 2022-06-18 06:15:31.477621
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from file path.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test if function can load module from bytes path.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("b = 2")
        f.flush()
        module = load_module_from_file_location(f.name.encode())
        assert module.b == 2

    # C) Test if function can load module from bytes path with encoding.

# Generated at 2022-06-18 06:15:40.665045
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w+", dir=tmp_dir, suffix=".py", delete=False
    )

    # Write some content to temporary file
    tmp_file.write("some_var = 'some_value'")
    tmp_file.close()

    # Load module from temporary file
    module = load_module_from_file_location(tmp_file.name)

    # Check if module was loaded correctly
    assert module.some_var == "some_value"

    # Remove temporary directory
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 06:15:46.689343
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from path
    #    with environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file_path = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("test_var = 'test_value'")

        os.environ["TMP_DIR"] = tmp_dir
        module = load_module_from_file_location(
            "${TMP_DIR}/tmp_file.py"
        )
        assert module.test_var == "test_value"

    # B) Test if function can load module from path
    #    with environment variables.

# Generated at 2022-06-18 06:15:57.855089
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from os import environ as os_environ

    # A) Test with environment variables
    os_environ["TEST_ENV_VAR"] = "test_env_var_value"
    with NamedTemporaryFile(mode="w+", suffix=".py") as temp_file:
        temp_file.write("test_var = 1")
        temp_file.flush()
        module = load_module_from_file_location(
            f"${os_environ['TEST_ENV_VAR']}/{temp_file.name}"
        )
        assert module.test_var == 1

    # B) Test with Path

# Generated at 2022-06-18 06:16:05.085586
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ
    from os import path
    from os import remove
    from tempfile import mkstemp

    # Test 1
    # Test if function works with string location.
    # Test if function works with string location containing environment
    # variables in format ${some_env_var}.
    # Test if function works with string location containing environment
    # variables in format $some_env_var.
    # Test if function works with string location containing environment
    # variables in format ${some_env_var} and $some_env_var.
    # Test if function works with string location containing environment
    # variables in format ${some_env_var} and $some_env_var and
    # some_env_var is not defined.
    # Test if function works with string location containing environment
    # variables in format ${some_env_

# Generated at 2022-06-18 06:16:14.282120
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert not env_vars_in_location

    # B) Check these variables exists in environment.
    location = "some_module_name/${some_env_var}"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    not_defined_env_vars = env_vars_in_location.difference(os.environ.keys())

# Generated at 2022-06-18 06:16:23.153035
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import tempfile
    import os
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    location = "some_module_name"
    assert load_module_from_file_location(location) == import_string(location)

    # B) Check these variables exists in environment.
    location = "some_module_name"
    assert load_module_from_file_location(location) == import_string(location)

    # C) Substitute them in location.
    location = "some_module_name"
    assert load_module_from_file_location(location) == import_string

# Generated at 2022-06-18 06:16:32.534233
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_value"
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location, path)
    assert module.__file__ == "/some/path/some_value"

    # B) Check these variables exists in environment.
    os.environ.pop("some_env_var")

# Generated at 2022-06-18 06:16:42.690479
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.NamedTemporaryFile("w", suffix=".py") as temp:
        temp.write("test_var = 'test_var'")
        temp.flush()
        module = load_module_from_file_location(
            f"{temp.name}",
            f"{temp.name}/${TEST_ENV_VAR}",
        )
        assert module.test_var == "test_var"

    # Check if location is a pathlib.Path object

# Generated at 2022-06-18 06:16:49.230461
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from os import environ

    # Test 1
    # Create temporary file with some content
    with NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # Test 2
    # Create temporary file with some content
    with NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name.encode("utf8"))
        assert module.some_var == "some_value"

    # Test 3

# Generated at 2022-06-18 06:17:02.465962
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Test with string
    with tempfile.TemporaryDirectory() as tmpdirname:
        file_path = os.path.join(tmpdirname, "test_file.py")
        with open(file_path, "w") as f:
            f.write("a = 1")
        module = load_module_from_file_location(file_path)
        assert module.a == 1

    # Test with Path
    with tempfile.TemporaryDirectory() as tmpdirname:
        file_path = os.path.join(tmpdirname, "test_file.py")
        with open(file_path, "w") as f:
            f.write("a = 1")
        module = load_module_from_file_location(Path(file_path))

# Generated at 2022-06-18 06:17:12.509691
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function."""
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        config_file = temp_dir / "config.py"
        config_file.write_text("SOME_VAR = 'some_value'")

        module = load_module_from_file_location(config_file)
        assert module.SOME_VAR == "some_value"

        module = load_module_from_file_location(config_file.as_posix())
        assert module.SOME_VAR == "some_value"

        module = load_module_from_file_location(config_file.as_uri())
        assert module.SOME_VAR == "some_value"

        module = load

# Generated at 2022-06-18 06:17:22.465768
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=tmp_dir, delete=False
    )
    tmp_file.write("test_var = 'test_value'")
    tmp_file.close()

    # Create temporary file with environment variables
    tmp_file_with_env_vars = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=tmp_dir, delete=False
    )
    tmp_file_with_env_vars.write("test_var = '${TEST_ENV_VAR}'")
    tmp_file_with_env_v

# Generated at 2022-06-18 06:17:32.543962
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["SOME_ENV_VAR"] = "some_env_var_value"
    tmp_dir = tempfile.mkdtemp()
    tmp_file = tempfile.NamedTemporaryFile(
        dir=tmp_dir, suffix=".py", delete=False
    )
    tmp_file.write(b"some_var = 'some_value'")
    tmp_file.close()

# Generated at 2022-06-18 06:17:42.988225
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from os import environ

    # A) Test if function can load module from file path.
    with NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test if function can load module from environment variable.
    environ["TEST_ENV_VAR"] = f.name
    module = load_module_from_file_location(
        "${TEST_ENV_VAR}"
    )  # type: ignore
    assert module.a == 1

    # C) Test if function can load module from environment variable
    #    and file path.
    module = load_module_from_

# Generated at 2022-06-18 06:17:52.213558
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    location = "test_module_name"
    location_with_env_var = "test_module_name_${TEST_ENV_VAR}"

    # B) Check these variables exists in environment.
    not_defined_env_vars = set(re_findall(r"\${(.+?)}", location_with_env_var))
    not_defined_env_vars = not_defined_env_vars.difference(os.environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:18:05.539455
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Create temporary file with some content.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as temp:
        temp.write("some_var = 'some_value'")
        temp.flush()

        # B) Load module from this file.
        loaded_module = load_module_from_file_location(temp.name)

        # C) Check that module contains expected variable.
        assert loaded_module.some_var == "some_value"

    # D) Create temporary file with some content.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as temp:
        temp.write("some_var = 'some_value'")
        temp.flush()

        # E) Set environment variable with path to this file.

# Generated at 2022-06-18 06:18:14.792994
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    location = "./test_location/${TEST_ENV_VAR}"
    assert load_module_from_file_location(location) == "test_env_var"

    # B) Check these variables exists in environment.
    location = "./test_location/${NOT_DEFINED_ENV_VAR}"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    # C) Substitute them in location.
    location = "./test_location/${TEST_ENV_VAR}"
    assert load_module_from_file_location(location)

# Generated at 2022-06-18 06:18:22.080414
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test for module loading from file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as tmp_file:
        tmp_file.write("a = 1\n")
        tmp_file.flush()
        module = load_module_from_file_location(tmp_file.name)
        assert module.a == 1

    # B) Test for module loading from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as tmp_file:
        tmp_file.write("a = 1\n")
        tmp_file.flush()
        os.environ["TEST_ENV_VAR"] = tmp_file.name

# Generated at 2022-06-18 06:18:32.210525
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Create temporary directory and file
    temp_dir = tempfile.TemporaryDirectory()
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", dir=temp_dir.name, suffix=".py"
    )

    # Write some code to temporary file
    temp_file.write("some_var = 'some_value'")
    temp_file.flush()

    # Load module from temporary file
    module = load_module_from_file_location(temp_file.name)

    # Check if module was loaded correctly
    assert module.some_var == "some_value"

    # Clean up
    temp_file.close()
    temp_dir.cleanup()

    # Check if environment variables are resolved correctly

# Generated at 2022-06-18 06:18:50.111106
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys
    import tempfile

    # A) Test loading module from string.
    # A.1) Test loading module from string with .py extension.
    # A.1.1) Test loading module from string with .py extension
    #        with correct path.
    # A.1.1.1) Test loading module from string with .py extension
    #          with correct path and without environment variables.
    #          It should load module from file.
    #          It should return module.
    #          It should return module with __file__ attribute.
    #          It should return module with __file__ attribute
    #          with correct path.
    #          It should return module with __file__ attribute
    #          with correct path and with .py extension.
    #          It should return module with __file__ attribute
    #          with correct path

# Generated at 2022-06-18 06:18:56.232985
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys
    import pytest

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=tmp_dir, delete=False
    )
    # Write some content to temporary file
    tmp_file.write("some_var = 'some_value'")
    tmp_file.close()

    # Create temporary module
    tmp_module = load_module_from_file_location(tmp_file.name)

    # Check if module has some_var variable
    assert hasattr(tmp_module, "some_var")

    # Check if some_var variable has correct value

# Generated at 2022-06-18 06:19:06.078849
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests load_module_from_file_location function."""
    import os
    import tempfile

    # Test 1.
    # Test loading module from file.
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Create file with some content.
        file_path = os.path.join(tmpdirname, "test_file.py")
        with open(file_path, "w") as f:
            f.write("some_var = 1")

        # Load module from file.
        module = load_module_from_file_location(file_path)

        # Check that module is loaded correctly.
        assert module.some_var == 1

    # Test 2.
    # Test loading module from file with environment variables.

# Generated at 2022-06-18 06:19:16.017069
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    assert module.__file__ == "/some/path/some_value"
    assert module.__name__ == "some_module_name"
    del os_environ["some_env_var"]

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location

# Generated at 2022-06-18 06:19:22.145048
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    assert module.__file__ == "/some/path/some_value"
    del os_environ["some_env_var"]

    # B) Check these variables exists in environment.

# Generated at 2022-06-18 06:19:33.914102
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove
    from os import mkdir as os_mkdir
    from os import rmdir as os_rmdir
    from tempfile import mkdtemp

    # Create temporary directory
    temp_dir = mkdtemp()

    # Create temporary file
    temp_file = os_path.join(temp_dir, "temp_file.py")
    with open(temp_file, "w") as f:
        f.write("a = 1")

    # Create temporary file with environment variable
    temp_file_with_env_var = os_path.join(temp_dir, "temp_file_with_env_var.py")

# Generated at 2022-06-18 06:19:42.245166
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w",
        suffix=".py",
        dir=tmp_dir,
        delete=False,
    )

    # Write some content to temporary file
    tmp_file.write("some_var = 'some_value'")
    tmp_file.close()

    # Load module from temporary file
    module = load_module_from_file_location(tmp_file.name)

    # Check if module has some_var variable
    assert hasattr(module, "some_var")

    # Check if some_var variable has correct value
    assert module.some_var == "some_value"

    #

# Generated at 2022-06-18 06:19:51.859941
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with file path
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        f.write("a = 1")

    module = load_module_from_file_location(f.name)
    assert module.a == 1

    os.remove(f.name)

    # B) Test with environment variable
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        f.write("a = 2")

    os.environ["TEST_ENV_VAR"] = f.name
    module = load_module_from_file_location("${TEST_ENV_VAR}")
    assert module.a == 2

    os.remove(f.name)

    # C) Test with bytes

# Generated at 2022-06-18 06:20:01.257850
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_value"
    location = "some_module_name"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert not env_vars_in_location

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:20:09.467389
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Unit test for function load_module_from_file_location.
    """
    import tempfile
    import os

    # Create temporary file with some content.
    with tempfile.NamedTemporaryFile(mode="w+", delete=False) as f:
        f.write("some_var = 'some_value'")
        temp_file_path = f.name

    # Load module from this file.
    module = load_module_from_file_location(temp_file_path)

    # Check that module has attribute some_var with value 'some_value'.
    assert hasattr(module, "some_var")
    assert module.some_var == "some_value"

    # Remove temporary file.
    os.remove(temp_file_path)

# Generated at 2022-06-18 06:20:33.806406
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if function can load module from file.
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Create file with some content.
        tmp_file_path = os.path.join(tmpdirname, "tmp_file.py")
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("some_var = 'some_value'")

        # Load module from file.
        module = load_module_from_file_location(tmp_file_path)

        # Check if module has some_var attribute.
        assert hasattr(module, "some_var")

    # B) Test if function can load module from file with environment variables.

# Generated at 2022-06-18 06:20:44.403035
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    os.environ["TEMP_DIR"] = temp_dir

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", dir=temp_dir, suffix=".py", delete=False
    )
    temp_file.write("a = 1")
    temp_file.close()

    # Test
    module = load_module_from_file_location(temp_file.name)
    assert module.a == 1

    module = load_module_from_file_location(temp_file.name)
    assert module.a == 1


# Generated at 2022-06-18 06:20:52.637954
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with file path
    with tempfile.TemporaryDirectory() as tmpdirname:
        file_path = os.path.join(tmpdirname, "test_file.py")
        with open(file_path, "w") as f:
            f.write("a = 1")

        module = load_module_from_file_location(file_path)
        assert module.a == 1

    # B) Test with file path and environment variable
    with tempfile.TemporaryDirectory() as tmpdirname:
        file_path = os.path.join(tmpdirname, "test_file.py")
        with open(file_path, "w") as f:
            f.write("a = 1")

        os.environ["TEST_ENV_VAR"] = tmp

# Generated at 2022-06-18 06:21:01.028889
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with a string path.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        with open(os.path.join(tmpdirname, "test_file.py"), "w") as f:
            f.write("test_var = 'test_val'")
        module = load_module_from_file_location(
            "test_file", tmpdirname, "r", "utf8"
        )
        assert module.test_var == "test_val"

    # B) Test with a bytes path.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname

# Generated at 2022-06-18 06:21:12.032729
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    location = "./test_module.py"
    module = load_module_from_file_location(location)
    assert module.test_var == "test_var"
    assert module.test_env_var == "test_env_var"

    # B) Check these variables exists in environment.
    del os_environ["TEST_ENV_VAR"]
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    # C) Substitute them in location.
    os_environ["TEST_ENV_VAR"] = "test_env_var"

# Generated at 2022-06-18 06:21:20.553154
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["SOME_ENV_VAR"] = "some_value"
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, "some_module.py"), "w") as f:
            f.write("some_variable = 'some_value'")

        module = load_module_from_file_location(
            "some_module", os.path.join(tmpdirname, "${SOME_ENV_VAR}")
        )
        assert module.some_variable == "some_value"

   

# Generated at 2022-06-18 06:21:31.386120
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if it works with string path.
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("test_var = 'test_value'")
        tmp_file.seek(0)
        module = load_module_from_file_location(tmp_file.name)
        assert module.test_var == "test_value"

    # B) Test if it works with Path object.
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("test_var = 'test_value'")
        tmp_file.seek(0)
        module = load_module_from_file_location(Path(tmp_file.name))

# Generated at 2022-06-18 06:21:39.197588
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.NamedTemporaryFile(mode="w") as f:
        f.write("test_var = 'test_var'")
        f.flush()
        module = load_module_from_file_location(
            f"${TEST_ENV_VAR}/{f.name}",
        )
        assert module.test_var == "test_var"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.


# Generated at 2022-06-18 06:21:47.871305
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil
    import sys

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w+", suffix=".py", dir=temp_dir, delete=False
    )

    # Write some content to temporary file
    temp_file.write("test_var = 'test'")
    temp_file.close()

    # Add temporary directory to system path
    sys.path.append(temp_dir)

    # Test if function works with pathlib.Path
    assert (
        load_module_from_file_location(Path(temp_file.name)).test_var
        == "test"
    )

    # Test if function works with string

# Generated at 2022-06-18 06:21:54.536977
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary file
    f = open(os.path.join(tmpdir, "test.py"), "w")
    f.write("test_var = 'test'")
    f.close()

    # Load module from temporary file
    module = load_module_from_file_location(
        os.path.join(tmpdir, "test.py")
    )

    # Check if module has been loaded correctly
    assert module.test_var == "test"

    # Remove temporary directory
    shutil.rmtree(tmpdir)