

# Generated at 2022-06-18 06:12:22.629697
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    def create_temp_file(content: str) -> str:
        fd, path = tempfile.mkstemp()
        with os.fdopen(fd, "w") as tmp:
            tmp.write(content)
        return path

    def remove_temp_file(path: str):
        os.remove(path)

    def create_temp_dir(content: str) -> str:
        path = tempfile.mkdtemp()
        with open(os.path.join(path, "__init__.py"), "w") as tmp:
            tmp.write(content)
        return path

    def remove_temp_dir(path: str):
        shutil.rmtree(path)


# Generated at 2022-06-18 06:12:30.482508
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if function load_module_from_file_location
    #    can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test if function load_module_from_file_location
    #    can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_

# Generated at 2022-06-18 06:12:41.560077
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test if function works with string path.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = Path(tmp_dir) / "test_file.py"
        with open(tmp_file, "w") as f:
            f.write("TEST_VAR = 'test'")

        module = load_module_from_file_location(str(tmp_file))
        assert module.TEST_VAR == "test"

    # B) Test if function works with bytes path.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = Path(tmp_dir) / "test_file.py"
        with open(tmp_file, "w") as f:
            f.write("TEST_VAR = 'test'")

        module

# Generated at 2022-06-18 06:12:49.019937
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    assert load_module_from_file_location(location) is None

    # B) Check these variables exists in environment.
    location = "some_module_name"
    try:
        load_module_from_file_location(location)
    except LoadFileException as e:
        assert "The following environment variables are not set: " in str(e)

    # C) Substitute them in location.
    location = "some_module_name/${some_env_var}"
    assert load_module_from_file_location(location) is None



# Generated at 2022-06-18 06:13:00.297666
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location, path)
    assert module.__file__ == "/some/path/some_env_var_value"

    # B) Check these variables exists in environment.
    del os_environ["some_env_var"]
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location, path)

    # C) Substitute them in location.

# Generated at 2022-06-18 06:13:11.268511
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Create temporary directory.
    temp_dir_path = tempfile.mkdtemp()

    # B) Create temporary file in this directory.
    temp_file_path = os.path.join(temp_dir_path, "temp_file.py")
    with open(temp_file_path, "w") as temp_file:
        temp_file.write("test_var = 'test_value'")

    # C) Create environment variable.
    os.environ["TEST_ENV_VAR"] = temp_dir_path

    # D) Test function.

# Generated at 2022-06-18 06:13:16.673946
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location, path)
    assert module.__name__ == location
    assert module.__file__ == path
    del os_environ["some_env_var"]

    # B) Check these variables exists in environment.
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location, path)

    # C) Substitute them in

# Generated at 2022-06-18 06:13:26.017422
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function works with simple file path.
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("test_var = 1")
        temp_file.seek(0)
        module = load_module_from_file_location(temp_file.name)
        assert module.test_var == 1

    # B) Test if function works with environment variables in file path.
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("test_var = 1")
        temp_file.seek(0)
        os.environ["TEMP_FILE_NAME"] = temp_file.name

# Generated at 2022-06-18 06:13:35.541157
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function."""
    import tempfile
    import os
    import shutil

    # A) Create temporary directory.
    tmp_dir = tempfile.mkdtemp()

    # B) Create temporary file in this directory.
    tmp_file_path = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file_path, "w") as tmp_file:
        tmp_file.write("TEST_VAR = 'test'")

    # C) Create temporary environment variable.
    os.environ["TEST_ENV_VAR"] = tmp_dir

    # D) Test load_module_from_file_location function.

# Generated at 2022-06-18 06:13:43.993097
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test with file path.
    with tempfile.NamedTemporaryFile(mode="w") as tmp_file:
        tmp_file.write("some_var = 'some_value'")
        tmp_file.flush()
        module = load_module_from_file_location(tmp_file.name)
        assert module.some_var == "some_value"

    # B) Test with bytes path.
    with tempfile.NamedTemporaryFile(mode="w") as tmp_file:
        tmp_file.write("some_var = 'some_value'")
        tmp_file.flush()
        module = load_module_from_file_location(tmp_file.name.encode())
        assert module.some_var == "some_value"

    # C) Test with Path path.

# Generated at 2022-06-18 06:13:55.192162
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with environment variables.
    #    Create temporary file with environment variable in it.
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("some_var = '${SOME_ENV_VAR}'")
        tmp_file.flush()

        # Set environment variable.
        os.environ["SOME_ENV_VAR"] = "some_value"

        # Load module from temporary file.
        module = load_module_from_file_location(tmp_file.name)

        # Check that module has been loaded correctly.
        assert module.some_var == "some_value"

    # B) Test with file path.
    #    Create temporary file with some variable in it.

# Generated at 2022-06-18 06:14:05.171094
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    assert load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )

    # B) Check these variables exists in environment.
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var_not_defined}"
        )

    # C) Substitute them in location.
    assert load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )

    # D) Check

# Generated at 2022-06-18 06:14:14.980714
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with file path.
    # A.1) Test with file path with no environment variables.
    with tempfile.NamedTemporaryFile(mode="w") as f:
        f.write("some_var = 'some_val'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_val"

    # A.2) Test with file path with environment variables.
    with tempfile.NamedTemporaryFile(mode="w") as f:
        f.write("some_var = 'some_val'")
        f.flush()
        os.environ["some_env_var"] = f.name

# Generated at 2022-06-18 06:14:25.108069
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function works with normal path.
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, "config.py"), "w") as f:
            f.write("CONFIG_VAR = 'some_value'")

        module = load_module_from_file_location(
            os.path.join(tmpdirname, "config.py")
        )
        assert module.CONFIG_VAR == "some_value"

    # B) Test if function works with environment variables in path.

# Generated at 2022-06-18 06:14:33.146171
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with file path
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test with environment variables
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.seek(0)
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location("${TEST_ENV_VAR}")
        assert module.a == 1
        del os.environ["TEST_ENV_VAR"]



# Generated at 2022-06-18 06:14:43.264537
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    import tempfile
    import os
    import sys

    def create_temp_file(content):
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
            f.write(content)
            return f.name

    def create_temp_dir(content):
        with tempfile.TemporaryDirectory() as temp_dir:
            with open(os.path.join(temp_dir, "__init__.py"), "w") as f:
                f.write(content)
            return temp_dir

    def test_module_content(module, content):
        assert module.__file__ == content["__file__"]
        assert module.__name__ == content["__name__"]
        assert module.__package__ == content["__package__"]
        assert module.__doc__

# Generated at 2022-06-18 06:14:51.720773
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import remove as os_remove
    from os import mkdir as os_mkdir
    from os import rmdir as os_rmdir
    from os import path as os_path
    from tempfile import mkdtemp as tempfile_mkdtemp
    from tempfile import mkstemp as tempfile_mkstemp
    from shutil import rmtree as shutil_rmtree

    # A) Test if function can load module from file path.
    #    Create temporary file and put some content in it.
    temp_dir = tempfile_mkdtemp()
    temp_file_path = os_path.join(temp_dir, "temp_file.py")

# Generated at 2022-06-18 06:15:01.208291
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    location = "some_module_name"
    assert not re_findall(r"\${(.+?)}", location)

    # B) Check these variables exists in environment.
    location = "some_module_name"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.
    location = "some_module_name"

# Generated at 2022-06-18 06:15:10.453605
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    # A) Create temporary directory.
    temp_dir = tempfile.mkdtemp()

    # B) Create temporary file.
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", dir=temp_dir, delete=False
    )

    # C) Write some content to it.
    temp_file.write("some_var = 'some_val'")
    temp_file.close()

    # D) Load module from this file.
    module = load_module_from_file_location(temp_file.name)

    # E) Check if module was loaded correctly.
    assert module.some_var == "some_val"

    # F) Remove temporary directory.
    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 06:15:21.723342
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function works with bytes.
    with tempfile.NamedTemporaryFile(mode="wb") as f:
        f.write(b"test_var = 'test_value'")
        f.flush()
        module = load_module_from_file_location(f.name.encode("utf8"))
        assert module.test_var == "test_value"

    # B) Test if function works with strings.
    with tempfile.NamedTemporaryFile(mode="w") as f:
        f.write("test_var = 'test_value'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.test_var == "test_value"

    # C) Test if function works with Path.


# Generated at 2022-06-18 06:15:31.654052
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Test 1
    # Create temporary file
    with tempfile.NamedTemporaryFile(mode="w+", delete=False) as f:
        f.write("""
        some_var = "some_value"
        """)
    # Load module from file
    module = load_module_from_file_location(f.name)
    # Check if module has some_var attribute
    assert hasattr(module, "some_var")
    # Check if some_var attribute has correct value
    assert getattr(module, "some_var") == "some_value"
    # Remove temporary file
    os.remove(f.name)

    # Test 2
    # Create temporary file
    with tempfile.NamedTemporaryFile(mode="w+", delete=False) as f:
        f

# Generated at 2022-06-18 06:15:41.383205
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w", delete=False, dir=tmp_dir
    )
    tmp_file.write("some_var = 'some_value'")
    tmp_file.close()

    # Create temporary module
    tmp_module_file = tempfile.NamedTemporaryFile(
        mode="w", delete=False, dir=tmp_dir, suffix=".py"
    )
    tmp_module_file.write("some_var = 'some_value'")
    tmp_module_file.close()

    # Create temporary module with __init__.py
    tmp_module_dir = temp

# Generated at 2022-06-18 06:15:51.485565
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function.
    """
    # Test 1:
    # Test if function can load module from file.
    # Test if function can load module from file with environment variables.
    # Test if function can load module from file with environment variables
    # and with .py extension.
    # Test if function can load module from file with .py extension.
    # Test if function can load module from file with .py extension
    # and with environment variables.
    # Test if function can load module from file with .py extension
    # and with environment variables.
    # Test if function can load module from file with .py extension
    # and with environment variables.
    # Test if function can load module from file with .py extension
    # and with environment variables.
    # Test if function can load module from file with .py extension


# Generated at 2022-06-18 06:16:01.118707
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test with file path.
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("a = 1")
        temp_file.seek(0)
        module = load_module_from_file_location(temp_file.name)
        assert module.a == 1

    # B) Test with file path and environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("a = 1")
        temp_file.seek(0)
        os_environ["TEMP_FILE_NAME"] = temp_file.name
        module = load_module_from_file_location(
            "${TEMP_FILE_NAME}", encoding="utf8"
        )
       

# Generated at 2022-06-18 06:16:12.310764
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("test_var = 'test_value'")
        f.flush()
        module = load_module_from_file_location(
            f"{f.name}", "/some/path/${TEST_ENV_VAR}"
        )
        assert module.test_var == "test_value"

    # A) Check if location contains any environment variables
    #    in format ${

# Generated at 2022-06-18 06:16:20.211089
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ, pathsep
    from tempfile import TemporaryDirectory
    from unittest import TestCase

    from sanic.config import load_module_from_file_location

    class TestLoadModuleFromFileLocation(TestCase):
        def setUp(self):
            self.temp_dir = TemporaryDirectory()
            self.temp_dir_path = self.temp_dir.name

        def tearDown(self):
            self.temp_dir.cleanup()

        def test_load_module_from_file_location_with_path(self):
            # Create test file
            test_file_path = path.join(self.temp_dir_path, "test_file.py")

# Generated at 2022-06-18 06:16:30.312795
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function works with string as location parameter.
    #    Test if function works with environment variables in location parameter.
    #    Test if function works with .py file as location parameter.
    #    Test if function works with .py file as location parameter.
    #    Test if function works with .py file as location parameter.
    #    Test if function works with .py file as location parameter.
    #    Test if function works with .py file as location parameter.
    #    Test if function works with .py file as location parameter.
    #    Test if function works with .py file as location parameter.
    #    Test if function works with .py file as location parameter.
    #    Test if function works with .py file as location parameter.
    #    Test if function works with .py file as location parameter.


# Generated at 2022-06-18 06:16:40.626169
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("TEST_VAR = 'test_value'")
        temp_file.flush()
        module = load_module_from_file_location(
            temp_file.name,
            "/some/path/${TEST_ENV_VAR}",
        )
        assert module.TEST_VAR == "test_value"

    # If location is of a

# Generated at 2022-06-18 06:16:47.916103
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function.
    """
    import os
    import tempfile

    # A) Test loading module from file path.
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, "test_module.py"), "w") as f:
            f.write(
                """
                test_var = "test_value"
                """
            )
        module = load_module_from_file_location(
            os.path.join(tmpdirname, "test_module.py")
        )
        assert module.test_var == "test_value"

    # B) Test loading module from file path with environment variables.

# Generated at 2022-06-18 06:16:58.615613
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    location = "some_module_name"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert not env_vars_in_location

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(
        os.environ.keys()
    )
    assert not not_defined_env_vars

    # C) Substitute them in location.
    for env_var in env_vars_in_location:
        location = location.replace("${" + env_var + "}", os.environ[env_var])

# Generated at 2022-06-18 06:17:12.085533
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("some_var = 'some_value'")
        temp_file.flush()
        os_environ["TEMP_FILE_PATH"] = temp_file.name
        module = load_module_from_file_location(
            "config", "${TEMP_FILE_PATH}"
        )
        assert module.some_var == "some_value"

    # B) Test with Path object.
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("some_var = 'some_value'")
        temp_file.flush()

# Generated at 2022-06-18 06:17:22.172881
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    assert load_module_from_file_location(
        "test_env_var", "/some/path/${TEST_ENV_VAR}"
    ) == "test_env_var"
    del os_environ["TEST_ENV_VAR"]

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.

# Generated at 2022-06-18 06:17:32.253473
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test if function works with Path object.
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("test_var = 1")
        temp_file.flush()
        module = load_module_from_file_location(Path(temp_file.name))
        assert module.test_var == 1

    # B) Test if function works with string.
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("test_var = 1")
        temp_file.flush()
        module = load_module_from_file_location(temp_file.name)
        assert module.test_var == 1

    # C) Test if function works with bytes.

# Generated at 2022-06-18 06:17:42.761784
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create temporary file with .py extension
    fd, tmpfile_py = tempfile.mkstemp(dir=tmpdir, suffix=".py")
    os.close(fd)

    # Create temporary file with .py extension
    fd, tmpfile_pyc = tempfile.mkstemp(dir=tmpdir, suffix=".pyc")
    os.close(fd)

    # Create temporary file with .py extension
    fd, tmpfile_pyo = tempfile.mkstemp(dir=tmpdir, suffix=".pyo")
    os

# Generated at 2022-06-18 06:17:52.057184
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test with environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / "some_file.py"
        tmp_file.touch()

        os_environ["TMP_DIR"] = str(tmp_dir)
        os_environ["TMP_FILE"] = str(tmp_file)

        assert load_module_from_file_location(
            "${TMP_DIR}/${TMP_FILE}"
        ).__file__ == str(tmp_file)

        del os_environ["TMP_DIR"]
        del os_environ["TMP_FILE"]

    # B) Test with bytes.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp

# Generated at 2022-06-18 06:18:05.494047
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("os") == os
    assert load_module_from_file_location("os.path") == os.path

    assert load_module_from_file_location("os.path.abspath") == os.path.abspath

    assert load_module_from_file_location("os.path.abspath", "os") == os.path.abspath

    assert load_module_from_file_location("os.path.abspath", "os.path") == os.path.abspath

    assert load_module_from_file_location("os.path.abspath", "os.path.abspath") == os.path.abspath


# Generated at 2022-06-18 06:18:14.744931
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # A) Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # B) Create temporary file in this directory
    tmp_file_path = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file_path, "w") as tmp_file:
        tmp_file.write("some_var = 'some_value'")

    # C) Create temporary environment variable
    tmp_env_var = "TMP_ENV_VAR"
    tmp_env_var_value = "tmp_env_var_value"
    os.environ[tmp_env_var] = tmp_env_var_value

    # D) Test load_module_from_file_location function
    #    with different parameters.


# Generated at 2022-06-18 06:18:21.945550
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with environment variables.
    # A.1) Test with environment variables in format ${some_env_var}.
    # A.1.1) Test with environment variables in format ${some_env_var}
    #        when some_env_var is not set.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        with open(os.path.join(tmpdirname, "test_file.py"), "w") as f:
            f.write("test_var = 'test_value'")

        module = load_module_from_file_location(
            "test_file", "${TEST_ENV_VAR}/test_file.py"
        )
        assert module

# Generated at 2022-06-18 06:18:32.099844
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove
    from os import makedirs as os_makedirs
    from os import getcwd as os_getcwd
    from os import chdir as os_chdir
    from os import listdir as os_listdir
    from os import rmdir as os_rmdir
    from os import getcwd as os_getcwd
    from os import getenv as os_getenv
    from os import unsetenv as os_unsetenv
    from os import system as os_system
    from os import mkdir as os_mkdir
    from os import getcwd as os_getcwd
    from os import getenv as os_getenv

# Generated at 2022-06-18 06:18:39.002684
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location, path)
    assert module.__file__ == "/some/path/some_value"

    # B) Check these variables exists in environment.
    del os_environ["some_env_var"]
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location, path)

    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    module = load_module_

# Generated at 2022-06-18 06:18:50.820645
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import sys

    # A) Test if function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 'some_val'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_val"

    # B) Test if function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 'some_val'")
        f.seek(0)
        module = load_module_from_file_location(f"{f.name}")
        assert module

# Generated at 2022-06-18 06:18:59.811606
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil
    import sys

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    sys.path.append(tmp_dir)

    # Create temporary file
    tmp_file = os.path.join(tmp_dir, "test_file.py")
    with open(tmp_file, "w") as f:
        f.write("test_var = 'test_value'")

    # Create temporary file with environment variable
    tmp_file_env = os.path.join(tmp_dir, "test_file_env.py")
    with open(tmp_file_env, "w") as f:
        f.write("test_var = 'test_value'")

    # Create temporary file with environment variable
    tmp_file_env_2 = os.path

# Generated at 2022-06-18 06:19:10.932439
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=tmp_dir, delete=False
    )

    # Write some content to temporary file
    tmp_file.write("some_var = 'some_value'")
    tmp_file.close()

    # Load module from temporary file
    module = load_module_from_file_location(tmp_file.name)

    # Check if module has attribute some_var
    assert hasattr(module, "some_var")

    # Check if module.some_var is equal to 'some_value'
    assert module.some_var == "some_value"

    # Remove

# Generated at 2022-06-18 06:19:19.095583
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    temp_dir_path = tempfile.mkdtemp()

    # Create temporary file
    temp_file_path = os.path.join(temp_dir_path, "temp_file.py")
    with open(temp_file_path, "w") as temp_file:
        temp_file.write("test_var = 'test_value'")

    # Create temporary environment variable
    os.environ["TEST_ENV_VAR"] = temp_dir_path

    # Test load_module_from_file_location
    module = load_module_from_file_location(
        "temp_file", "${TEST_ENV_VAR}", "r"
    )
    assert module.test_var == "test_value"

# Generated at 2022-06-18 06:19:28.508963
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("test_var = 'test_var_value'")
        f.seek(0)
        module = load_module_from_file_location(
            f.name, "/some/path/${TEST_ENV_VAR}"
        )
        assert module.test_var == "test_var_value"

    # A) Check if location contains any environment variables
    #    in

# Generated at 2022-06-18 06:19:38.340032
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_value"
    os.environ["some_env_var2"] = "some_value2"
    os.environ["some_env_var3"] = "some_value3"
    os.environ["some_env_var4"] = "some_value4"
    os.environ["some_env_var5"] = "some_value5"
    os.environ["some_env_var6"] = "some_value6"
    os.environ["some_env_var7"] = "some_value7"
    os.environ["some_env_var8"] = "some_value8"

# Generated at 2022-06-18 06:19:45.089083
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    module = load_module_from_file_location(
        "test_module_name",
        "/some/path/${TEST_ENV_VAR}/test_module.py",
    )
    assert module.__name__ == "test_module_name"
    assert module.__file__ == "/some/path/test_env_var/test_module.py"
    del os_environ["TEST_ENV_VAR"]

    # B) Check these variables exists in environment.

# Generated at 2022-06-18 06:19:54.812422
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    location = "some_module_name"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert not env_vars_in_location

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:20:03.615475
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables.
    #    1) Create temporary file.
    #    2) Create temporary environment variable.
    #    3) Write some content to temporary file.
    #    4) Load module from temporary file using environment variable.
    #    5) Check if module is loaded correctly.
    #    6) Clean up.
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("some_var = 'some_value'")
        temp_file.seek(0)

        os.environ["TEMP_ENV_VAR"] = temp_file.name

        module = load_module_from_file_location(
            "some_module_name", "${TEMP_ENV_VAR}"
        )



# Generated at 2022-06-18 06:20:11.760738
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(mode="w", delete=False)
    # Write some content to temporary file
    tmp_file.write("test_var = 'test_value'")
    tmp_file.close()
    # Move temporary file to temporary directory
    shutil.move(tmp_file.name, tmp_dir)

    # Load module from temporary file
    module = load_module_from_file_location(
        os.path.join(tmp_dir, os.path.basename(tmp_file.name))
    )

    # Check if module has attribute test_var
    assert hasattr(module, "test_var")
    #

# Generated at 2022-06-18 06:20:26.208642
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("a = 1")

    # Create temporary environment variable
    os.environ["TMP_ENV_VAR"] = tmp_dir

    # Test
    module = load_module_from_file_location(
        "tmp_file", "${TMP_ENV_VAR}", "r", True, True
    )
    assert module.a == 1

    # Remove temporary directory
    shutil.rmtree(tmp_dir)

    # Remove temporary environment variable
    del os.en

# Generated at 2022-06-18 06:20:31.768693
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location, path)
    assert module.__name__ == "some_module_name"
    assert module.__file__ == "/some/path/some_value"
    del os_environ["some_env_var"]

# Generated at 2022-06-18 06:20:42.333314
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("some_var = 'some_value'")
        temp_file.flush()
        module = load_module_from_file_location(temp_file.name)
        assert module.some_var == "some_value"

    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("some_var = 'some_value'")
        temp_file.flush()
        module = load_module_from_file_location(Path(temp_file.name))
        assert module.some_var == "some_value"

    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write

# Generated at 2022-06-18 06:20:51.360220
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with file path.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}"
        )  # noqa
        assert module.a == 1



# Generated at 2022-06-18 06:21:00.367821
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ

    with TemporaryDirectory() as tmp_dir:
        # Create a file with some content
        tmp_file_path = Path(tmp_dir) / "tmp_file.py"
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("some_variable = 'some_value'")

        # Test that file is loaded correctly
        module = load_module_from_file_location(tmp_file_path)
        assert module.some_variable == "some_value"

        # Test that environment variables are resolved correctly
        os_environ["SOME_ENV_VAR"] = tmp_file_path

# Generated at 2022-06-18 06:21:11.262672
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["some_env_var"] = "some_value"
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.

# Generated at 2022-06-18 06:21:18.762741
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test for function load_module_from_file_location.
    """
    # Test for loading module from file path.
    assert load_module_from_file_location(
        "tests/test_helpers/test_config.py"
    ).TEST_CONFIG_VARIABLE == "test_config_value"

    # Test for loading module from file path with environment variables.
    os_environ["TEST_ENV_VAR"] = "test_env_var_value"
    assert load_module_from_file_location(
        "tests/test_helpers/${TEST_ENV_VAR}/test_config.py"
    ).TEST_CONFIG_VARIABLE == "test_config_value"
    del os_environ["TEST_ENV_VAR"]

# Generated at 2022-06-18 06:21:30.081797
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # Test for loading module from string
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # Test for loading module from bytes
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name.encode())
        assert module.a == 1

    # Test for loading module from Path
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.flush()
        module = load

# Generated at 2022-06-18 06:21:37.863726
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        module = load_module_from_file_location(
            "some_module_name",
            f"{tmpdirname}/some_file.py",
        )
        assert module.__file__ == f"{tmpdirname}/some_file.py"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.


# Generated at 2022-06-18 06:21:46.134981
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    assert load_module_from_file_location(location) is None

    # B) Check these variables exists in environment.
    location = "some_module_name"
    try:
        load_module_from_file_location(location)
    except LoadFileException as e:
        assert (
            str(e) == "The following environment variables are not set: "
            "some_env_var"
        )

    # C) Substitute them in location.
    location = "${some_env_var}"
    assert load_module_from_

# Generated at 2022-06-18 06:21:57.603519
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables in location.
    # A.1) Test with environment variables in location
    #      and with non-existing file.
    # A.1.1) Test with environment variables in location
    #        and with non-existing file and with non-existing environment
    #        variables.
    os.environ["TEST_ENV_VAR_1"] = "test_env_var_1"
    os.environ["TEST_ENV_VAR_2"] = "test_env_var_2"
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmp_file_path = os.path.join(tmpdirname, "test_file.py")
        with pytest.raises(LoadFileException):
            load_module_from_file

# Generated at 2022-06-18 06:22:05.507160
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import os
    import tempfile

    # Test 1
    # Test if function can load module from file location
    # and return it.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        file_name = "test_file.py"
        file_path = os.path.join(tmpdirname, file_name)
        with open(file_path, "w") as f:
            f.write("test_var = 'test_value'")
        module = load_module_from_file_location(file_path)
        assert module.test_var == "test_value"

    # Test 2
    # Test if function can load module from file location
    # and return it.

# Generated at 2022-06-18 06:22:15.189098
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=tmp_dir, delete=False
    )
    tmp_file.write("TEST_VAR = 'test'")
    tmp_file.close()

    # Create temporary module
    tmp_module = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=tmp_dir, delete=False
    )
    tmp_module.write("TEST_VAR = 'test'")
    tmp_module.close()

    # Create temporary package