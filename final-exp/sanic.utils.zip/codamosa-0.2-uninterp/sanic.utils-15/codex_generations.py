

# Generated at 2022-06-18 06:12:24.300774
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function raises LoadFileException
    #    if environment variable is not set.
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, "some_module.py"), "w") as f:
            f.write("some_var = 1")
        with pytest.raises(LoadFileException):
            load_module_from_file_location(
                os.path.join(tmpdirname, "some_module.py"),
                "${some_env_var}",
            )

    # B) Test if function raises LoadFileException
    #    if environment variable is not set.

# Generated at 2022-06-18 06:12:33.284376
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test if it can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # B) Test if it can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        os_environ["TEST_ENV_VAR"] = f.name

# Generated at 2022-06-18 06:12:44.443752
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function.
    """
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(mode="w", dir=tmp_dir, delete=False)
    tmp_file.write("a = 1")
    tmp_file.close()

    # Create temporary file with environment variables
    tmp_file_with_env_vars = tempfile.NamedTemporaryFile(
        mode="w", dir=tmp_dir, delete=False
    )
    tmp_file_with_env_vars.write("b = 2")
    tmp_file_with_env_vars.close()

    # Create temporary file with environment variables

# Generated at 2022-06-18 06:12:55.316561
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${TEST_ENV_VAR}"
    )
    assert module.__file__ == "/some/path/test_env_var"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.


# Generated at 2022-06-18 06:13:04.303955
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    assert module.__file__ == "/some/path/some_value"

    # B) Check these variables exists in environment.
    os_environ.pop("some_env_var")

# Generated at 2022-06-18 06:13:14.602872
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test loading module from file path
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # B) Test loading module from file path with environment variables
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        os_environ["TEST_ENV_VAR"] = f.name

# Generated at 2022-06-18 06:13:24.900002
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-18 06:13:33.526167
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Tests for function load_module_from_file_location
    """
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("a = 1")
        tmp_file.seek(0)
        module = load_module_from_file_location(tmp_file.name)
        assert module.a == 1

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.

# Generated at 2022-06-18 06:13:42.908093
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["some_env_var"] = "some_value"
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["tmpdirname"] = tmpdirname
        config_file_path = os.path.join(tmpdirname, "config.py")
        with open(config_file_path, "w") as config_file:
            config_file.write("CONFIG_VAR = 'some_value'")


# Generated at 2022-06-18 06:13:50.480891
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-18 06:14:03.329831
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["SOME_ENV_VAR"] = "some_env_var_value"
    tmp_dir = tempfile.mkdtemp()
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w", dir=tmp_dir, delete=False
    )
    tmp_file.write("some_var = 'some_value'")
    tmp_file.close()

# Generated at 2022-06-18 06:14:09.230035
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    from os import environ as os_environ
    from pathlib import Path

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    location = "/some/path/${some_env_var}"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:14:19.423322
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test if function can load module from file location.
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("some_var = 'some_value'")
        temp_file.flush()
        module = load_module_from_file_location(temp_file.name)
        assert module.some_var == "some_value"

    # B) Test if function can load module from file location
    #    with environment variables in it.
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("some_var = 'some_value'")
        temp_file.flush()
        os_environ["TEMP_FILE_NAME"] = temp_file.name
        module = load_

# Generated at 2022-06-18 06:14:27.525833
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import path as os_path
    from tempfile import TemporaryDirectory
    from unittest import TestCase

    from sanic.exceptions import LoadFileException, PyFileError

    class TestLoadModuleFromFileLocation(TestCase):
        def test_load_module_from_file_location(self):
            with TemporaryDirectory() as temp_dir:
                temp_dir = Path(temp_dir)
                temp_file = temp_dir / "temp_file.py"
                temp_file.write_text("a = 1")
                module = load_module_from_file_location(temp_file)
                self.assertEqual(module.a, 1)

                temp_file = temp_dir / "temp_file"
                temp_file.write_text("a = 1")

# Generated at 2022-06-18 06:14:36.885215
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test if function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}", encoding="utf8"
        )
        assert module.a

# Generated at 2022-06-18 06:14:45.593747
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import os
    import tempfile

    # A) Test with file path.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / "tmp_file.py"
        tmp_file.touch()
        tmp_file.write_text("TEST_VAR = 'test_value'")
        module = load_module_from_file_location(tmp_file)
        assert module.TEST_VAR == "test_value"

    # B) Test with file path and environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)

# Generated at 2022-06-18 06:14:55.174707
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with environment variables
    #    in format ${some_env_var}.
    #    Mark that $some_env_var will not be resolved as environment variable.
    #    Mark that ${some_env_var} will be resolved as environment variable.
    #    Mark that ${some_env_var} will be resolved as environment variable
    #    only if it is defined in environment.
    #    Mark that ${some_env_var} will be resolved as environment variable
    #    only if it is defined in environment.
    #    Mark that ${some_env_var} will be resolved as environment variable
    #    only if it is defined in environment.
    #    Mark that ${some_env_var} will be resolved as environment variable
    #    only if it is defined in environment.
    #    Mark

# Generated at 2022-06-18 06:15:05.062603
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", dir=temp_dir, delete=False
    )

    # Write to temporary file
    temp_file.write("some_var = 'some_value'")
    temp_file.close()

    # Create temporary environment variable
    os.environ["TEMP_ENV_VAR"] = temp_dir

    # Test function
    module = load_module_from_file_location(
        "${TEMP_ENV_VAR}/" + temp_file.name.split("/")[-1]
    )

    # Check if module is loaded

# Generated at 2022-06-18 06:15:13.082342
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    assert module.__file__ == "/some/path/some_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["some_env_var"] = "some_value"
    module = load_module_from_

# Generated at 2022-06-18 06:15:23.496637
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with file path.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("a = 1")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location(
            "/some/path/${TEST_ENV_VAR}"
        )
        assert module.a == 1

    # C) Test with environment variables and bytes

# Generated at 2022-06-18 06:15:34.131162
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "/some/path/${some_env_var}"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert env_vars_in_location == {"some_env_var"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:15:43.471481
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    module = load_module_from_file_location(
        "test_module", "${TEST_ENV_VAR}/test_module.py"
    )
    assert module.test_var == "test_module"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.

# Generated at 2022-06-18 06:15:54.125176
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # 1. Test loading module from file path.
    #    Create temporary file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as tmp_file:
        tmp_file.write("a = 1")
        tmp_file.flush()
        module = load_module_from_file_location(tmp_file.name)
        assert module.a == 1

    # 2. Test loading module from file path with environment variables.
    #    Create temporary file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as tmp_file:
        tmp_file.write("a = 1")
        tmp_file.flush()
        # A) Set environment variable.

# Generated at 2022-06-18 06:16:02.932483
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from file path.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 1")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.some_var == 1

    # B) Test if function can load module from file path with environment
    #    variables in it.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 1")
        f.flush()
        os.environ["TEST_ENV_VAR"] = f.name

# Generated at 2022-06-18 06:16:13.485458
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # A) Test with file path.
    # A.1) Test with file path and no environment variables.
    with tempfile.TemporaryDirectory() as tmpdirname:
        file_path = os.path.join(tmpdirname, "some_file.py")
        with open(file_path, "w") as f:
            f.write("some_variable = 'some_value'")
        module = load_module_from_file_location(file_path)
        assert module.some_variable == "some_value"

    # A.2) Test with file path and environment variables.
    with tempfile.TemporaryDirectory() as tmpdirname:
        file_path = os.path.join(tmpdirname, "some_file.py")

# Generated at 2022-06-18 06:16:21.331970
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["some_env_var"] = "some_env_var_value"
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Create a file in the temporary directory
        file_path = os.path.join(tmpdirname, "some_file.py")
        with open(file_path, "w") as f:
            f.write("some_var = 'some_value'")


# Generated at 2022-06-18 06:16:31.606975
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if function works with bytes.
    temp_file_path = tempfile.mkstemp()[1]
    with open(temp_file_path, "w") as temp_file:
        temp_file.write("some_var = 'some_val'")

    module = load_module_from_file_location(
        bytes(temp_file_path, "utf8"), encoding="utf8"
    )
    assert module.some_var == "some_val"

    # B) Test if function works with string.
    module = load_module_from_file_location(temp_file_path)
    assert module.some_var == "some_val"

    # C) Test if function works with Path.

# Generated at 2022-06-18 06:16:42.036321
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    module = load_module_from_file_location(
        "test_module_name", "/some/path/${TEST_ENV_VAR}"
    )
    assert module.__name__ == "test_module_name"
    assert module.__file__ == "/some/path/test_env_var"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    module

# Generated at 2022-06-18 06:16:48.824921
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import tempfile

    # A) Test with file path.
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
        tmp_file_path = tmpdirname / "tmp_file.py"
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("TEST_VAR = 'test_value'")
        loaded_module = load_module_from_file_location(tmp_file_path)
        assert loaded_module.TEST_VAR == "test_value"

    # B) Test with file path and environment variables.
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
       

# Generated at 2022-06-18 06:16:59.607491
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from sanic.exceptions import LoadFileException
    from tempfile import NamedTemporaryFile
    from os import environ as os_environ
    from os import remove as os_remove

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    with NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("some_var = 'some_value'")
        tmp_file.seek(0)
        tmp_file_path = tmp_file.name
        tmp_file_name = tmp_file_path.split("/")[-1]
        tmp_file_name_without_ext = tmp_file_name.split(".")[0]

        # 1) Check if location contains any environment variables
        #    in format ${some_

# Generated at 2022-06-18 06:17:15.145259
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    temp_dir = tempfile.mkdtemp()
    os.environ["TEST_ENV_VAR"] = temp_dir

    temp_file = os.path.join(temp_dir, "test_file.py")
    with open(temp_file, "w") as f:
        f.write("test_var = 'test_value'")

    module = load_module_from_file_location(temp_file)
    assert module.test_var == "test_value"

    module = load_module_from_file_location(temp_file.encode())
    assert module.test_var == "test_value"

    module = load_module_from_file_location(Path(temp_file))

# Generated at 2022-06-18 06:17:23.859598
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function."""
    import os
    import tempfile

    # A) Test with environment variables in location.
    #    Create temporary file.
    tmp_file = tempfile.NamedTemporaryFile(mode="w+", delete=False)
    tmp_file.write("test_var = 1")
    tmp_file.close()

    #    Create environment variable.
    os.environ["TEST_ENV_VAR"] = tmp_file.name

    #    Test function.
    module = load_module_from_file_location(
        "${TEST_ENV_VAR}"
    )  # type: ignore
    assert module.test_var == 1

    #    Remove temporary file.
    os.remove(tmp_file.name)

    # B) Test with

# Generated at 2022-06-18 06:17:34.643233
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import os
    import tempfile

    # Test 1:
    # Test if function raises LoadFileException
    # if environment variable is not set.
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmp_file_path = os.path.join(tmpdirname, "tmp_file.py")
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("TEST_VAR = 'test_value'")


# Generated at 2022-06-18 06:17:44.673641
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with file path.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("a = 1")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("a = 1")
        f.seek(0)
        os.environ["TEST_ENV_VAR"] = f.name
        module = load_module_from_file_location(
            "/some/path/${TEST_ENV_VAR}"
        )

# Generated at 2022-06-18 06:17:53.210152
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ
    from os import path as os_path

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with TemporaryDirectory() as tmp_dir:
        os_environ["TEST_ENV_VAR"] = tmp_dir
        tmp_file_path = os_path.join(tmp_dir, "test_file.py")
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("TEST_VAR = 'test_value'")


# Generated at 2022-06-18 06:18:05.585508
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["TEST_ENV_VAR"] = "test_env_var_value"
    assert (
        load_module_from_file_location(
            "some_module_name", "/some/path/${TEST_ENV_VAR}"
        ).__file__
        == "/some/path/test_env_var_value"
    )

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.

# Generated at 2022-06-18 06:18:11.318587
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    test_file_name = "test_file_name"
    test_file_path = os.path.join(
        tempfile.gettempdir(), test_file_name + ".py"
    )

# Generated at 2022-06-18 06:18:19.583451
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # Test that it can load module from file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # Test that it can load module from file with environment variables
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.flush()
        os_environ["TEST_ENV_VAR"] = f.name

# Generated at 2022-06-18 06:18:30.134899
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables.
    #    Create temporary file with environment variable.
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("some_var = ${SOME_ENV_VAR}")
        temp.seek(0)

        # Set environment variable.
        os.environ["SOME_ENV_VAR"] = "some_value"

        # Load module from temporary file.
        module = load_module_from_file_location(temp.name)

        # Check if environment variable was substituted.
        assert module.some_var == "some_value"

    # B) Test with environment variables in path.
    #    Create temporary file with environment variable.

# Generated at 2022-06-18 06:18:37.731853
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with environment variables.
    # A.1) Create temporary file with environment variable in it.
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("TEST_ENV_VAR = 'test_env_var'")
        temp_file.flush()

        # A.2) Set environment variable.
        os.environ["TEST_ENV_VAR"] = "test_env_var"

        # A.3) Load module from file location.
        module = load_module_from_file_location(temp_file.name)

        # A.4) Check if module was loaded correctly.
        assert module.TEST_ENV_VAR == "test_env_var"

        # A.5)

# Generated at 2022-06-18 06:18:58.173681
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    path = "/some/path/${some_env_var}"
    module = load_module_from_file_location(location, path)
    assert module.__file__ == "/some/path/some_env_var_value"

    # B) Check these variables exists in environment.
    del os_environ["some_env_var"]
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location, path)

    # C) Substitute them in location.

# Generated at 2022-06-18 06:19:08.418729
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["test_env_var"] = "test_env_var_value"
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("test_var = 'test_var_value'")
        f.flush()
        module = load_module_from_file_location(
            f"{f.name}",
            "/some/path/${test_env_var}",
        )
        assert module.test_var == "test_var_value"

    # A) Check if location contains any environment variables
    #    in format

# Generated at 2022-06-18 06:19:17.881508
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    # A) Create temporary directory.
    temp_dir = tempfile.mkdtemp()

    # B) Create temporary file in this directory.
    temp_file = tempfile.NamedTemporaryFile(
        mode="w+", dir=temp_dir, suffix=".py"
    )

    # C) Write some content to this file.
    temp_file.write(
        """
        some_var = "some_value"
        """
    )

    # D) Close file.
    temp_file.close()

    # E) Load module from this file.
    module = load_module_from_file_location(temp_file.name)

    # F) Check if module was loaded correctly.
    assert module.some_var == "some_value"

    # G) Remove temporary

# Generated at 2022-06-18 06:19:24.823674
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with file path
    # A.1) Test with file path with .py extension
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as temp:
        temp.write("a = 1")
        temp.seek(0)
        module = load_module_from_file_location(temp.name)
        assert module.a == 1

    # A.2) Test with file path without .py extension
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("a = 1")
        temp.seek(0)
        module = load_module_from_file_location(temp.name)
        assert module.a == 1

    # B) Test with environment variables
    # B.1) Test with environment

# Generated at 2022-06-18 06:19:36.217901
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import remove as os_remove
    from os import mkdir as os_mkdir
    from os import rmdir as os_rmdir
    from os import path as os_path
    from tempfile import mkdtemp as tempfile_mkdtemp
    from tempfile import mkstemp as tempfile_mkstemp
    from shutil import rmtree as shutil_rmtree

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if location is a path to a file.
    # E) Check if location is a path to a directory.
    # F) Check if location is a path to a file with .

# Generated at 2022-06-18 06:19:43.747843
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.NamedTemporaryFile(mode="w") as f:
        f.write("TEST_CONSTANT = 'test_constant'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.TEST_CONSTANT == "test_constant"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.


# Generated at 2022-06-18 06:19:53.403442
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w+", suffix=".py", dir=temp_dir, delete=False
    )

    # Write some content to temporary file
    temp_file.write("some_var = 'some_value'")
    temp_file.close()

    # Load module from temporary file
    module = load_module_from_file_location(temp_file.name)

    # Check if module has attribute some_var
    assert hasattr(module, "some_var")

    # Check if module.some_var is equal to 'some_value'
    assert module.some_var == "some_value"

    # Remove temporary directory


# Generated at 2022-06-18 06:20:02.529053
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ
    from os import path as os_path
    from os import remove as os_remove
    from os import mkdir as os_mkdir

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with TemporaryDirectory() as tmpdirname:
        os_environ["TEST_ENV_VAR"] = tmpdirname
        test_file_name = "test_file.py"
        test_file_path = os_path.join(tmpdirname, test_file_name)

# Generated at 2022-06-18 06:20:10.962957
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil
    import sys

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=temp_dir, delete=False
    )
    # Write some content to temporary file
    temp_file.write("some_var = 'some_value'")
    temp_file.close()

    # Create temporary file
    temp_file_2 = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=temp_dir, delete=False
    )
    # Write some content to temporary file
    temp_file_2.write("some_var_2 = 'some_value_2'")
    temp_file

# Generated at 2022-06-18 06:20:22.188542
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import os
    import tempfile

    # A) Test with environment variables.
    # A.1) Create temporary file.
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("TEST_VAR = 'test_value'")
        temp_file.flush()
        # A.2) Set environment variable.
        os.environ["TEST_ENV_VAR"] = temp_file.name
        # A.3) Test.
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}", encoding="utf8"
        )
        assert module.TEST_VAR == "test_value"
        # A.4) Remove

# Generated at 2022-06-18 06:21:13.311723
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if module is loaded.
    # E) Check if module is loaded.
    # F) Check if module is loaded.
    # G) Check if module is loaded.

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if module is loaded.
    # E) Check if module is loaded.
    # F) Check if module is loaded.
    # G) Check if module is loaded.

   

# Generated at 2022-06-18 06:21:22.652460
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # Test 1
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("test_var = 'test_value'")
        tmp_file.seek(0)
        module = load_module_from_file_location(tmp_file.name)
        assert module.test_var == "test_value"

    # Test 2
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("test_var = 'test_value'")
        tmp_file.seek(0)
        module = load_module_from_file_location(tmp_file.name.encode())
        assert module.test_var == "test_value"

    # Test 3

# Generated at 2022-06-18 06:21:33.078478
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ
    from os import path as os_path

    # A) Test that function can load module from file location.
    with TemporaryDirectory() as tmp_dir:
        tmp_file_path = os_path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("some_var = 'some_value'")

        tmp_module = load_module_from_file_location(tmp_file_path)
        assert tmp_module.some_var == "some_value"

    # B) Test that function can load module from file location
    #    with environment variables in it.
    with TemporaryDirectory() as tmp_dir:
        tmp_file_path = os

# Generated at 2022-06-18 06:21:40.899155
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with environment variables.
    # A.1) Create temporary file.
    tmp_file = tempfile.NamedTemporaryFile(mode="w+", delete=False)
    tmp_file.write("some_var = 'some_value'")
    tmp_file.close()

    # A.2) Set environment variable.
    os.environ["some_env_var"] = tmp_file.name

    # A.3) Test.
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    assert module.some_var == "some_value"

    # A.4) Clean up.
    os.remove(tmp_file.name)
    del os.environ

# Generated at 2022-06-18 06:21:49.340186
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        tmp_file.write("test_var = 'test_value'")
        tmp_file.seek(0)
        module = load_module_from_file_location(
            tmp_file.name,
            "/some/path/${TEST_ENV_VAR}",
        )
        assert module.test_var == "test_value"

    # A) Check if location contains any

# Generated at 2022-06-18 06:21:57.746992
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ as os_environ
    from os import remove as os_remove
    from os import path as os_path
    from tempfile import mkstemp as tempfile_mkstemp
    from tempfile import gettempdir as tempfile_gettempdir

    # Test if function works with bytes location
    def test_bytes_location():
        # Create temporary file
        fd, file_path = tempfile_mkstemp(
            suffix=".py", dir=tempfile_gettempdir()
        )
        os_remove(file_path)
        file_path = file_path.encode()

        # Write some content to it
        with open(fd, "w") as f:
            f.write("some_var = 'some_value'")

        # Load it
        module = load_

# Generated at 2022-06-18 06:22:04.035977
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create temporary file
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    # Write some content to temporary file
    with open(tmp_file, "w") as f:
        f.write("some_var = 'some_value'")

    # Load module from temporary file
    module = load_module_from_file_location(tmp_file)
    assert module.some_var == "some_value"

    # Delete temporary directory
    shutil.rmtree(tmp_dir)



# Generated at 2022-06-18 06:22:14.024268
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    location = "test_location/${TEST_ENV_VAR}"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert env_vars_in_location == {"TEST_ENV_VAR"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.