

# Generated at 2022-06-18 06:12:26.814790
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-18 06:12:37.178787
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function works with string path.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # B) Test if function works with bytes path.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name.encode())
        assert module.some_var == "some_value"

    # C) Test if function works with

# Generated at 2022-06-18 06:12:46.643982
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("YEP") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("YUP") is True
    assert str_to_bool("t") is True
    assert str_to_bool("T") is True
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True

# Generated at 2022-06-18 06:12:57.536410
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.flush()
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # B) Test if function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.flush()
        os.environ["some_env_var"] = f.name

# Generated at 2022-06-18 06:13:05.527829
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if it can load module from file path.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.some_var == "some_value"

    # B) Test if it can load module from file path with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("some_var = 'some_value'")
        f.seek(0)
        os.environ["some_env_var"] = f.name
        module = load_module_from_file

# Generated at 2022-06-18 06:13:15.911611
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    location = "test_module_name"
    location_with_env_var = "test_module_name_${TEST_ENV_VAR}"
    assert re_findall(r"\${(.+?)}", location_with_env_var) == ["TEST_ENV_VAR"]

    # B) Check these variables exists in environment.
    not_defined_env_vars = set(re_findall(r"\${(.+?)}", location_with_env_var)).difference(
        os.environ.keys()
    )

# Generated at 2022-06-18 06:13:25.720916
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-18 06:13:35.221849
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=temp_dir, delete=False
    )
    temp_file.write("TEST_VAR = 'test'")
    temp_file.close()

    # Create temporary file with environment variable
    temp_file_with_env_var = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=temp_dir, delete=False
    )
    temp_file_with_env_var.write("TEST_VAR = '${TEST_ENV_VAR}'")
    temp_file_with

# Generated at 2022-06-18 06:13:43.753414
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("test_var = 'test_var'")
        temp.seek(0)
        module = load_module_from_file_location(
            "test_module",
            f"{temp.name}",
        )
        assert module.test_var == "test_var"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
   

# Generated at 2022-06-18 06:13:50.502840
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-18 06:14:04.379046
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary file
    f = open(os.path.join(tmpdir, "test_file.py"), "w")
    f.write("test_var = 'test_value'")
    f.close()

    # Load module from file
    module = load_module_from_file_location(os.path.join(tmpdir, "test_file.py"))

    # Check if module has test_var variable
    assert module.test_var == "test_value"

    # Remove temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-18 06:14:13.885662
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    location_with_env_var = f"/some/path/${{some_env_var}}"
    location_with_not_defined_env_var = f"/some/path/${{not_defined_env_var}}"

    # B) Check these variables exists in environment.

# Generated at 2022-06-18 06:14:24.036196
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile

    # A) Test with environment variables.
    #    Create temporary file.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("some_var = 'some_value'")
        f.flush()

        # Set environment variable.
        os_environ["some_env_var"] = f.name

        # Test.
        module = load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var}"
        )

        # Check if module was loaded.
        assert module.some_var == "some_value"

        # Clean up.
        del os_environ["some_env_var"]

    # B) Test with Path object.
    #    Create temporary file.

# Generated at 2022-06-18 06:14:29.909091
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    # A) Test if function raises LoadFileException
    #    if environment variable is not set.
    try:
        load_module_from_file_location("${some_env_var}")
    except LoadFileException as e:
        assert "The following environment variables are not set: some_env_var" in str(
            e
        )
    else:
        assert False, "LoadFileException was not raised."

    # B) Test if function raises LoadFileException
    #    if environment variable is not set.
    os_environ["some_env_var"] = "some_value"

# Generated at 2022-06-18 06:14:39.827182
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_value"
    location = "/some/path/${some_env_var}"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert env_vars_in_location == {"some_env_var"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:14:44.231532
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil
    import sys

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var"
    test_module = load_module_from_file_location(
        "test_module", "${TEST_ENV_VAR}/test_module.py"
    )
    assert test_module.test_var == "test_var"

    # Check if location is of a bytes type.
    test_module = load_module_from_file_location(
        b"test_module", b"test_module.py"
    )

# Generated at 2022-06-18 06:14:52.506741
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from os import path
    from os import remove
    from tempfile import mkstemp

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    environ["test_env_var"] = "test_env_var"
    location = "${test_env_var}"
    assert load_module_from_file_location(location) == "test_env_var"

    # B) Check these variables exists in environment.
    location = "${test_env_var}/some_path"
    assert load_module_from_file_location(location) == "test_env_var/some_path"

    # C) Substitute them in location.
    location = "${test_env_var}/some_path"
    assert load_module_from_

# Generated at 2022-06-18 06:14:58.680211
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(mode="w+", delete=False)
    temp_file.write("some_var = 'some_value'")
    temp_file.close()

    # Test
    module = load_module_from_file_location(temp_file.name)
    assert module.some_var == "some_value"

    # Cleanup
    os.remove(temp_file.name)

# Generated at 2022-06-18 06:15:08.513548
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Create temporary file
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, "w") as tmp:
        tmp.write("a = 1")

    # Test if file is loaded
    module = load_module_from_file_location(path)
    assert module.a == 1

    # Test if file is loaded with environment variable
    os.environ["TEST_ENV_VAR"] = path
    module = load_module_from_file_location("${TEST_ENV_VAR}")
    assert module.a == 1

    # Test if file is loaded with environment variable
    os.environ["TEST_ENV_VAR"] = path

# Generated at 2022-06-18 06:15:19.631002
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import remove as os_remove
    from os import makedirs as os_makedirs
    from os import path as os_path
    from tempfile import mkdtemp as tempfile_mkdtemp
    from shutil import rmtree as shutil_rmtree

    # A) Create temporary directory.
    temp_dir = tempfile_mkdtemp()

    # B) Create temporary file with some content.
    temp_file_path = os_path.join(temp_dir, "temp_file.py")
    with open(temp_file_path, "w") as temp_file:
        temp_file.write("some_var = 'some_value'")

    # C) Create temporary environment variable.
    os_environ["TEMP_ENV_VAR"]

# Generated at 2022-06-18 06:15:29.568706
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert not env_vars_in_location

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:15:39.391025
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ
    from os.path import join as os_path_join
    from shutil import rmtree

    with TemporaryDirectory() as tmp_dir:
        # A) Create config file
        config_file_name = "config.py"
        config_file_path = os_path_join(tmp_dir, config_file_name)
        with open(config_file_path, "w") as config_file:
            config_file.write(
                """
                SOME_CONFIG_VAR = "some_config_value"
                """
            )

        # B) Create env var
        env_var_name = "SOME_ENV_VAR"
        env_var_value = "some_env_value"

# Generated at 2022-06-18 06:15:45.825238
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(suffix=".py", delete=False)
    temp_file.write(b"test_var = 'test'")
    temp_file.close()

    # Create temporary module
    sys.path.append(temp_dir)
    temp_module = types.ModuleType("temp_module")
    temp_module.test_var = "test"
    sys.modules["temp_module"] = temp_module

    # Test load_module_from_file_location
    assert load_module_from_file_location(temp_file.name).test_var

# Generated at 2022-06-18 06:15:56.588520
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        with open(os.path.join(tmpdirname, "test_file.py"), "w") as f:
            f.write("TEST_VAR = 'test_value'")
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}/test_file.py"
        )
        assert module.TEST_VAR == "test_value"
        shutil

# Generated at 2022-06-18 06:16:04.461397
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test with file path
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file_path = os.path.join(tmp_dir, "test_file.py")
        with open(tmp_file_path, "w") as f:
            f.write("test_var = 'test_value'")

        module = load_module_from_file_location(tmp_file_path)
        assert module.test_var == "test_value"

    # B) Test with environment variables
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file_path = os.path.join(tmp_dir, "test_file.py")

# Generated at 2022-06-18 06:16:14.140631
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    import tempfile
    from os import environ as os_environ
    from os.path import join as os_path_join

    # Create temporary directory
    temp_dir = tempfile.TemporaryDirectory()

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        dir=temp_dir.name, suffix=".py", delete=False
    )
    temp_file.write(b"some_var = 'some_value'")
    temp_file.close()

    # Create temporary file with environment variables
    temp_file_with_env_vars = tempfile.NamedTemporaryFile(
        dir=temp_dir.name, suffix=".py", delete=False
    )

# Generated at 2022-06-18 06:16:23.010169
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["SOME_ENV_VAR"] = "some_value"
    location = "some_module_name"
    assert load_module_from_file_location(location) == import_string(location)

    # B) Check these variables exists in environment.
    location = "some_module_name"
    os.environ.pop("SOME_ENV_VAR")
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    # C) Substitute them in location.
    location = "some_module_name"

# Generated at 2022-06-18 06:16:32.450880
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["env_var"] = "env_var_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${env_var}"
    )
    assert module.__file__ == "/some/path/env_var_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["env_var"] = "env_var_value"
    module = load_module_from_

# Generated at 2022-06-18 06:16:42.615741
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_env_var_value"
    location = "/some/path/${some_env_var}"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert env_vars_in_location == {"some_env_var"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:16:49.186523
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys
    import importlib

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        mode="w+", suffix=".py", dir=tmp_dir, delete=False
    )
    tmp_file.write("a = 1")
    tmp_file.close()
    # Create temporary module
    tmp_module = os.path.join(tmp_dir, "tmp_module.py")
    with open(tmp_module, "w+") as tmp_module_file:
        tmp_module_file.write("b = 2")

    # Test 1
    # Test if load_module_from_file_location works with file path
    module = load_module

# Generated at 2022-06-18 06:17:01.628801
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil
    import sys
    import importlib

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(
        mode="w+", suffix=".py", delete=False
    )
    temp_file.write("a = 1")
    temp_file.close()

    # Create temporary module
    temp_module = tempfile.NamedTemporaryFile(
        mode="w+", suffix=".py", delete=False
    )
    temp_module.write("b = 2")
    temp_module.close()

    # Create temporary module with environment variables
    temp_module_with_env_vars = tempfile.NamedTemporary

# Generated at 2022-06-18 06:17:11.708500
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os
    import sys

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = os.path.join(tmp_dir, "tmp_file.py")
    with open(tmp_file, "w") as f:
        f.write("a = 1")

    # Create temporary module
    tmp_module = os.path.join(tmp_dir, "tmp_module")
    os.mkdir(tmp_module)
    with open(os.path.join(tmp_module, "__init__.py"), "w") as f:
        f.write("b = 2")

    # Create temporary package
    tmp_package = os.path.join(tmp_dir, "tmp_package")
    os.mkdir

# Generated at 2022-06-18 06:17:21.860299
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        test_file_name = "test_file.py"
        test_file_path = os.path.join(tmpdirname, test_file_name)
        with open(test_file_path, "w") as test_file:
            test_file.write("test_var = 'test_value'")


# Generated at 2022-06-18 06:17:31.895591
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test with environment variables
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
        tmp_file = tmpdirname / "tmp_file.py"
        tmp_file.write_text("some_var = 'some_value'")
        os_environ["TMP_FILE_PATH"] = str(tmp_file)
        module = load_module_from_file_location(
            "${TMP_FILE_PATH}", encoding="utf8"
        )
        assert module.some_var == "some_value"

    # B) Test with Path object
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
        tmp_file = tmpdirname / "tmp_file.py"

# Generated at 2022-06-18 06:17:40.269470
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Create temporary file with some content.
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.write(b"some_var = 'some_value'")
    tmp_file.close()

    # B) Load module from this file.
    module = load_module_from_file_location(tmp_file.name)

    # C) Check that module has attribute some_var with value 'some_value'.
    assert module.some_var == "some_value"

    # D) Delete temporary file.
    os.unlink(tmp_file.name)

# Generated at 2022-06-18 06:17:50.357124
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil
    import sys

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    test_location = "test_location/${TEST_ENV_VAR}/test_location"
    test_location_resolved = "test_location/test_env_var_value/test_location"
    assert (
        load_module_from_file_location(test_location).__file__
        == test_location_resolved
    )

    # D) Check if location is a Path object.

# Generated at 2022-06-18 06:17:55.748073
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import remove as os_remove
    from os import mkdir as os_mkdir
    from os import rmdir as os_rmdir
    from os import path as os_path
    from tempfile import mkdtemp as tempfile_mkdtemp
    from tempfile import mkstemp as tempfile_mkstemp
    from tempfile import gettempdir as tempfile_gettempdir

    # A) Test if function raises LoadFileException
    #    if location contains environment variables
    #    which are not defined in environment.

# Generated at 2022-06-18 06:18:06.795778
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from os import path
    from os import remove
    from os import makedirs
    from os import mkdir
    from os import rmdir
    from os import getcwd
    from os import chdir
    from os import getenv
    from os import putenv
    from os import unsetenv
    from os import listdir
    from os import fdopen
    from os import open
    from os import O_CREAT
    from os import O_RDWR
    from os import O_TRUNC
    from os import O_RDONLY
    from os import O_WRONLY
    from os import O_APPEND
    from os import O_EXCL
    from os import O_NOINHERIT
    from os import O_RANDOM
    from os import O_SEQUENTIAL
   

# Generated at 2022-06-18 06:18:15.998115
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with file path.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file_path = os.path.join(tmp_dir, "some_file.py")
        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("some_var = 'some_value'")

        module = load_module_from_file_location(tmp_file_path)
        assert module.some_var == "some_value"

    # B) Test with file path and environment variables.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file_path = os.path.join(tmp_dir, "some_file.py")

# Generated at 2022-06-18 06:18:23.796430
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables
    #    in format ${some_env_var}.
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["TEST_ENV_VAR"] = tmpdirname
        location = os.path.join(
            "${TEST_ENV_VAR}", "some_module_name.py"
        )
        module = load_module_from_file_location(location)
        assert module.__file__ == os.path.join(
            tmpdirname, "some_module_name.py"
        )

    # B) Test with environment variables
    #    in format $some_env_var.

# Generated at 2022-06-18 06:18:35.638928
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ

    # A) Test with file path.
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / "some_file.py"
        tmp_file.touch()
        assert load_module_from_file_location(tmp_file)

    # B) Test with env var in file path.
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / "some_file.py"
        tmp_file.touch()
        os_environ["some_env_var"] = str(tmp_dir)

# Generated at 2022-06-18 06:18:45.499551
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if function can load module from file path.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("test_var = 1")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.test_var == 1

    # B) Test if function can load module from file path with environment
    #    variables in it.
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("test_var = 1")
        f.seek(0)
        os.environ["TEST_ENV_VAR"] = f.name

# Generated at 2022-06-18 06:18:52.983310
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_value"
    location = "some_module_name"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert not env_vars_in_location

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-18 06:19:03.135984
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"
    location = "some_module_name"
    assert load_module_from_file_location(location) == import_string(location)

    # B) Check these variables exists in environment.
    location = "some_module_name"
    assert load_module_from_file_location(location) == import_string(location)

    # C) Substitute them in location.
    location = "${some_env_var}"
    assert load_module_from_file_location(location) == import_string(
        os_environ["some_env_var"]
    )

    # D) Check if location contains any environment variables
    #    in format ${

# Generated at 2022-06-18 06:19:13.830439
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ, path
    from tempfile import TemporaryDirectory

    # Test for case when location is a string
    # and it contains environment variable.
    with TemporaryDirectory() as tmp_dir:
        # Create file with some content.
        file_path = path.join(tmp_dir, "some_file.py")
        with open(file_path, "w") as f:
            f.write("some_var = 'some_value'")

        # Set environment variable.
        environ["TEST_ENV_VAR"] = tmp_dir

        # Test.
        module = load_module_from_file_location(
            "some_file", "${TEST_ENV_VAR}/some_file.py"
        )
        assert module.some_var == "some_value"

# Generated at 2022-06-18 06:19:21.023600
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import tempfile

    # A) Check if function raises LoadFileException
    #    when environment variable is not set.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / "tmp_file.py"
        tmp_file.write_text("TEST = 'test'")
        with pytest.raises(LoadFileException):
            load_module_from_file_location(
                f"{tmp_file}/${some_env_var}"
            )

    # B) Check if function raises LoadFileException
    #    when file does not exist.

# Generated at 2022-06-18 06:19:32.097877
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import os
    import tempfile

    # A) Test with file path.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "tmp_file.py")
        with open(tmp_file, "w") as f:
            f.write("TEST_VAR = 'test_value'")

        module = load_module_from_file_location(tmp_file)
        assert module.TEST_VAR == "test_value"

    # B) Test with environment variable in file path.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "tmp_file.py")

# Generated at 2022-06-18 06:19:41.123195
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ, remove
    from pathlib import Path
    from tempfile import NamedTemporaryFile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # D) Check if module is loaded.
    with NamedTemporaryFile(mode="w", suffix=".py") as f:
        f.write("a = 1")
        f.flush()
        environ["TEST_ENV_VAR"] = str(Path(f.name).parent)
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}/${TEST_ENV_VAR}/{}".format(f.name)
        )

# Generated at 2022-06-18 06:19:50.293963
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import remove as os_remove
    from os import path as os_path
    from tempfile import NamedTemporaryFile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    env_vars_in_location = set(re_findall(r"\${(.+?)}", "${some_env_var}"))
    assert env_vars_in_location == {"some_env_var"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not_defined_env_vars == set()

    # C) Substitute them in location.

# Generated at 2022-06-18 06:20:00.063712
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Create temporary file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as temp:
        temp.write("some_var = 'some_value'")
        temp.seek(0)

        # B) Load module from this file.
        module = load_module_from_file_location(temp.name)

        # C) Check if module is loaded correctly.
        assert module.some_var == "some_value"

    # D) Create temporary file with environment variable in path.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as temp:
        temp.write("some_var = 'some_value'")
        temp.seek(0)

        # E) Set environment variable.
        os.environ

# Generated at 2022-06-18 06:20:10.349983
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmp_file = tmpdir / "tmp_file.py"
        tmp_file.touch()

        tmp_file_2 = tmpdir / "tmp_file_2.py"
        tmp_file_2.touch()

        tmp_file_3 = tmpdir / "tmp_file_3.py"
        tmp_file_3.touch()

        tmp_file_4 = tmpdir / "tmp_file_4.py"
        tmp_file_4.touch()

        tmp_file_5 = tmpdir / "tmp_file_5.py"
        tmp_file_5.touch()

        tmp_file_6 = tmpdir / "tmp_file_6.py"

# Generated at 2022-06-18 06:20:21.533669
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Test if function raises LoadFileException
    #    when environment variable is not set.
    with tempfile.TemporaryDirectory() as tmp_dir:
        os.environ["TEST_ENV_VAR"] = tmp_dir
        with open(os.path.join(tmp_dir, "test_file.py"), "w") as test_file:
            test_file.write("test_var = 'test_value'")
        with pytest.raises(LoadFileException):
            load_module_from_file_location(
                "test_file", "${TEST_ENV_VAR_NOT_SET}/test_file.py"
            )

    # B) Test if function returns module with correct attributes
    #    when environment variable is set.

# Generated at 2022-06-18 06:20:31.065305
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test for loading module from file path
    module = load_module_from_file_location(
        "tests/test_utils/test_config.py"
    )
    assert module.TEST_CONFIG_VAR == "test_config_var"

    # Test for loading module from file path with environment variables
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    module = load_module_from_file_location(
        "tests/test_utils/${TEST_ENV_VAR}/test_config.py"
    )
    assert module.TEST_CONFIG_VAR == "test_config_var"

    # Test for loading module from file path with environment variables
    # and bytes type location
    os_environ["TEST_ENV_VAR"]

# Generated at 2022-06-18 06:20:41.820578
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables in location.
    #    1) Create temporary file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        #    2) Create environment variable.
        os.environ["TEST_ENV_VAR"] = f.name
        #    3) Load module from file location.
        module = load_module_from_file_location(
            "${TEST_ENV_VAR}",
        )
        #    4) Check if module is loaded.
        assert module.__file__ == f.name
        #    5) Delete environment variable.
        del os.environ["TEST_ENV_VAR"]

    # B) Test with pathlib.Path object in location.
    #    1

# Generated at 2022-06-18 06:20:50.951804
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_env_var_value"
    location = "some_module_name"
    assert load_module_from_file_location(location) is None

    # B) Check these variables exists in environment.
    location = "some_module_name"
    try:
        load_module_from_file_location(location)
    except LoadFileException as e:
        assert "The following environment variables are not set: " in str(e)

    # C) Substitute them in location.
    location = "some_module_name"
    assert load_module_from_file_location(location) is None

    # D) Check if location

# Generated at 2022-06-18 06:20:56.420877
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    # A) Test loading module from file.
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, "test_module.py"), "w") as f:
            f.write("test_var = 'test_val'")

        module = load_module_from_file_location(
            os.path.join(tmpdirname, "test_module.py")
        )
        assert module.test_var == "test_val"

    # B) Test loading module from file with environment variables.

# Generated at 2022-06-18 06:21:07.976408
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import sys

    # A) Create temporary directory.
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)

    # B) Create temporary file with some content.
    tmp_file_path = tmp_dir_path / "tmp_file.py"
    with open(tmp_file_path, "w") as tmp_file:
        tmp_file.write("some_var = 'some_value'")

    # C) Create environment variable.
    os.environ["TMP_ENV_VAR"] = str(tmp_file_path)

    # D) Test load_module_from_file_location function.
    # D.1) Test with pathlib.Path object.
    module = load_module_from_file_location

# Generated at 2022-06-18 06:21:14.756226
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test if function can load module from file.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("a = 1")
        f.seek(0)
        module = load_module_from_file_location(f.name)
        assert module.a == 1

    # B) Test if function can load module from file with environment variables.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("a = 1")
        f.seek(0)
        os.environ["TEST_ENV_VAR"] = f.name

# Generated at 2022-06-18 06:21:25.381752
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # A) Test with environment variables.
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    with tempfile.NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("test_var = 'test_value'")
        temp_file.flush()
        module = load_module_from_file_location(
            f"{temp_file.name}",
            f"/some/path/${{TEST_ENV_VAR}}",
        )
        assert module.test_var == "test_value"

    # B) Test with Path object.

# Generated at 2022-06-18 06:21:34.515130
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # Test with bytes
    with tempfile.NamedTemporaryFile(mode="w+b") as temp:
        temp.write(b"test_var = 'test_value'")
        temp.seek(0)
        module = load_module_from_file_location(temp.name.encode())
        assert module.test_var == "test_value"

    # Test with string
    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write("test_var = 'test_value'")
        temp.seek(0)
        module = load_module_from_file_location(temp.name)
        assert module.test_var == "test_value"

    # Test with Path

# Generated at 2022-06-18 06:21:45.320994
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test if function can load module from file path.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as temp:
        temp.write("some_var = 'some_value'")
        temp.flush()
        module = load_module_from_file_location(temp.name)
        assert module.some_var == "some_value"

    # B) Test if function can load module from file path with environment
    #    variables.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as temp:
        temp.write("some_var = 'some_value'")
        temp.flush()
        os_environ["SOME_ENV_VAR"] = temp.name

# Generated at 2022-06-18 06:21:53.719850
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from os import environ as os_environ
    from os import remove as os_remove
    from os import path as os_path
    from tempfile import NamedTemporaryFile as tempfile_NamedTemporaryFile

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    with tempfile_NamedTemporaryFile(mode="w+", suffix=".py") as tmp_file:
        tmp_file.write("test_var = 'test_value'")
        tmp_file.seek(0)

# Generated at 2022-06-18 06:22:02.134242
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    # A) Test if function works with string location.
    #    Create temporary file with some content.
    temp_dir = tempfile.mkdtemp()
    temp_file_path = Path(temp_dir) / "temp_file.py"
    temp_file_path.touch()
    temp_file_path.write_text("some_var = 'some_value'")

    # B) Test if function works with bytes location.
    #    Create temporary file with some content.
    temp_dir_bytes = tempfile.mkdtemp()
    temp_file_path_bytes = Path(temp_dir_bytes) / "temp_file.py"
    temp_file_path_bytes.touch()

# Generated at 2022-06-18 06:22:09.860137
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import sys
    import shutil

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary module
    temp_module_path = os.path.join(temp_dir, "temp_module.py")
    with open(temp_module_path, "w") as temp_module:
        temp_module.write("test_var = 'test_value'")

    # Add temporary directory to sys.path
    sys.path.append(temp_dir)

    # Load module
    temp_module = load_module_from_file_location(temp_module_path)

    # Check if module was loaded correctly
    assert temp_module.test_var == "test_value"

    # Remove temporary directory
    shutil.rmtree(temp_dir)