

# Generated at 2022-06-21 23:40:14.102154
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:40:24.393460
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert(load_module_from_file_location(
        "tests/project_template/config.py",
        "./tests/project_template",
    ))
    assert(load_module_from_file_location(b"./tests/project_template/config.py"))
    assert(load_module_from_file_location(
        "tests/project_template/config.py",
        b"./tests/project_template",
    ))
    assert(load_module_from_file_location(b"./tests/project_template/config.py"))
    assert(load_module_from_file_location(
        "tests/project_template/config.py",
        "./tests/project_template",
        encoding="utf8",
    ))

# Generated at 2022-06-21 23:40:35.263839
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: E501
    # pylint: disable=redefined-outer-name,too-many-locals
    """Tests if function load_module_from_file_location works
    propertly.
    """
    import pytest

    test_env_var = "TEST_ENV_VAR"

    def create_test_file(name, content):
        with open(name, "w") as test_file:
            test_file.write(content)

    def remove_test_file(name):
        Path(name).unlink(missing_ok=True)

    def prepare_test_env():
        os_environ[test_env_var] = "/home/some_user/some/path"

# Generated at 2022-06-21 23:40:49.683180
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    from builtins import str as text

    # I) Simple check if module was loaded.
    os.environ["TEST_ENV"] = "test"
    with tempfile.NamedTemporaryFile(suffix=".py") as f:
        f.write(
            text(
                "config_loaded = 'SUCCESS'\n__all__ = ['config_loaded']"
            ).encode()
        )
        f.flush()
        module = load_module_from_file_location(
            f.name, package=None, reload=False
        )
    del os.environ["TEST_ENV"]

    assert module.__all__ == ["config_loaded"]
    assert module.config_loaded == "SUCCESS"

    # II) Check if module from current directory

# Generated at 2022-06-21 23:41:00.207032
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    from shutil import rmtree
    import os

    # Prepare temporary directory and file with content to be loaded.
    temp_directory = tempfile.mkdtemp()
    location = os.path.join(temp_directory, "test_module.py")
    with open(location, "w") as file:
        file.write(
            """
        class SomeClass():
            some_class_attribute = 1
        some_function = lambda x: x*10
        SOME_CONSTANT = "TEST_CONSTANT"
        """
        )

    # Check that it has the same content as above.
    loaded_module = load_module_from_file_location(location)
    assert hasattr(loaded_module, "SomeClass")
    assert hasattr(loaded_module, "some_function")

# Generated at 2022-06-21 23:41:06.190501
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(__file__).__name__ == "helpers"
    assert load_module_from_file_location(
        "sanic.helpers"
    ).__name__ == "helpers"  # this depends on PYTHONPATH

    assert load_module_from_file_location(
        Path(__file__)
    ).__name__ == "helpers"  # Unit test itself
    assert load_module_from_file_location(
        Path(__file__).parent / "app.py"
    ).__name__ == "app"  # from examples/app.py
    assert load_module_from_file_location(
        Path(__file__).parent / "basic_router.py"
    ).__name__ == "basic_router"  # from examples/

# Generated at 2022-06-21 23:41:17.325490
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test that worked on all supported python versions.
    #    Test for case when location is a string.
    conf_path = Path(__file__).parent / "test_config.py"
    module = load_module_from_file_location(str(conf_path))
    assert module.MY_CONSTANT == "some_value"

    #    Test for case when location is a Path.
    conf_path = Path(__file__).parent / "test_config.py"
    module = load_module_from_file_location(conf_path)
    assert module.MY_CONSTANT == "some_value"

    #    Test for case when location is a Path encoded in utf-8.
    conf_path = Path(__file__).parent / "test_config.py"
    module = load_module_

# Generated at 2022-06-21 23:41:26.136524
# Unit test for function str_to_bool
def test_str_to_bool():
    assert True is str_to_bool("True")
    assert True is str_to_bool("t")
    assert True is str_to_bool("yes")
    assert True is str_to_bool("1")
    assert False is str_to_bool("false")
    assert False is str_to_bool("f")
    assert False is str_to_bool("no")
    assert False is str_to_bool("0")
    try:
        assert True is str_to_bool("not_bool")
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-21 23:41:35.142891
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    from shutil import rmtree

    with tempfile.TemporaryDirectory() as tmpdirname:
        contents = "config_name = 'test'"
        path = Path(tmpdirname) / "test_load_file.py"
        path.write_bytes(contents.encode("utf-8"))

        module = load_module_from_file_location(str(path))
        assert module.config_name == "test"

# Generated at 2022-06-21 23:41:48.416516
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Testing load_module_from_file_location function.

    It is kind of dangerous to set any environment variable.
    What if user for example wants to test with some environment variable
    that contains JSON configuration?
    This variable will be changed during this unit test.
    That's why we will save original value of OS_ENV variable and restore it
    after testing.
    """

    # Create temporary folder.
    temp_dir = Path(tempfile.mkdtemp())

    # Create temporary python module in this folder.
    temp_py_module_path = temp_dir / "temp_py_module.py"
    with open(temp_py_module_path, "w") as temp_py_module:
        temp_py_module.write("a = 1\n")

    # Create temporary JSON file in this folder.
    temp_

# Generated at 2022-06-21 23:42:03.017847
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from sanic import Sanic
    from tempfile import TemporaryDirectory

    # A) Check if function can load Sanic config from file
    #    without resolving any environment variables.
    with Sanic("some_sanic_app") as app:
        app.config.load_module_from_file_location(__file__)
    assert app.config.REQUEST_MAX_SIZE

    # B) Check if function can load Sanic config from file
    #    when resolving environment variables.
    with TemporaryDirectory() as tmp_dir:
        # B.1) Create config file.
        config_file_name = tmp_dir + "/sanic_app_config.py"

# Generated at 2022-06-21 23:42:09.871934
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("TrUe") == True
    assert str_to_bool("t") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("y") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("1") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True

    assert str_to_bool("false") == False
    assert str_to_bool("FALSE") == False

# Generated at 2022-06-21 23:42:19.254281
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") is True
    assert str_to_bool("yEs") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("eNable") is True
    assert str_to_bool("Enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("N") is False
    assert str_to_bool("no") is False
    assert str_to_bool("F") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-21 23:42:28.911081
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("YeP") == True
    assert str_to_bool("Yep") == True
    assert str_to_bool("YUP") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("True") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("on") == True
  

# Generated at 2022-06-21 23:42:40.701095
# Unit test for function str_to_bool
def test_str_to_bool():
    try:
        assert str_to_bool('1') == True
    except ValueError:
        print("str_to_bool failed on '1'")
    try:
        assert str_to_bool('0') == False
    except ValueError:
        print("str_to_bool failed on '0'")
    try:
        assert str_to_bool('3') == False
    except ValueError:
        print("str_to_bool failed on '3'")
    try:
        assert str_to_bool('y') == True
    except ValueError:
        print("str_to_bool failed on 'y'")
    try:
        assert str_to_bool('n') == False
    except ValueError:
        print("str_to_bool failed on 'n'")

# Generated at 2022-06-21 23:42:51.868548
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True  # noqa
    assert str_to_bool("false") == False  # noqa
    assert str_to_bool("On") == True  # noqa
    assert str_to_bool("off") == False  # noqa
    assert str_to_bool("Y") == True  # noqa
    assert str_to_bool("n") == False  # noqa
    assert str_to_bool("1") == True  # noqa
    assert str_to_bool("0") == False  # noqa
    with pytest.raises(ValueError) as e:
        str_to_bool("not_valid")
    assert "Invalid truth value not_valid" in str(e.value)

# Generated at 2022-06-21 23:43:02.798704
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("true")
    assert str_to_bool("yes")
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yup")
    assert str_to_bool("yep")
    assert str_to_bool("t")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("false")
    assert not str_to_bool("foo")
    assert not str_to_bool("n")
    assert not str_to_bool("f")
    assert not str_to_bool("no")
    assert not str_to_bool("off")


# Generated at 2022-06-21 23:43:13.705155
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    def get_test_file_contents():
        return """
            VAR = "a"
            ANOTHER_VAR = 123
        """

    test_filename = Path("./tests/fixtures/test_load_file_location.py")
    environment_variables_sets = [
        {"SOME_ENV_VAR": "tests/fixtures"},
        {
            "SOME_ENV_VAR": "tests",
            "ANOTHER_ENV_VAR": "fixtures",
        },
    ]

# Generated at 2022-06-21 23:43:20.607278
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("1") is True
    assert str_to_bool("no") is False
    assert str_to_bool("Off") is False
    assert str_to_bool("0") is False
    assert str_to_bool("foo") is True
    assert str_to_bool("") is False



# Generated at 2022-06-21 23:43:32.089535
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("abc") == True
    assert str_to_bool("") == False
    assert str_to_bool(1) == True
    assert str_to_bool(0) == False
    assert str_to_bool(1.1) == True
    assert str_to_bool(0.0) == False
    assert str_to_bool(None) == False
    assert str_to_bool(True) == True
    assert str_to_bool(False) == False

# Generated at 2022-06-21 23:43:45.851116
# Unit test for function str_to_bool
def test_str_to_bool():
    # Using a dict for input: True if all values equal
    valdic = {
        "y": True,
        "yes": True,
        "yep": True,
        "yup": True,
        "t": True,
        "true": True,
        "on": True,
        "enable": True,
        "enabled": True,
        "1": True,
        "n": False,
        "no": False,
        "f": False,
        "false": False,
        "off": False,
        "disable": False,
        "disabled": False,
        "0": False,
    }
    for val, valcompare in valdic.items():
        assert str_to_bool(val) == valcompare

    # Check the exception is raised if a string is not listed:
    val

# Generated at 2022-06-21 23:43:51.740714
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_me = Path(__file__).parent / "test_files" / "import_me.py"
    module = load_module_from_file_location(import_me)
    assert module.__file__ == str(import_me)
    assert module.testing_import == "123"

# Generated at 2022-06-21 23:44:04.889425
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("y")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("1")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")

    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("n")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-21 23:44:14.548910
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys

    import pytest

    from .static.configs import test_config as test_config_module
    from .static.configs.test_config import test_config as test_config_dict

    # Some basic checks for default pathlib.Path string spec usage.
    test_config_str = str(Path(__file__).resolve().parent / "static/configs/test_config.py")
    assert load_module_from_file_location(test_config_str) == test_config_module

    # Check that environment variables are substituted properly.
    os.environ["TEST_TEST_ENV_VARIABLE_UNIT_TEST"] = "succeeded"

# Generated at 2022-06-21 23:44:28.100443
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool(val="y")
    assert str_to_bool(val="yes")
    assert str_to_bool(val="Y")
    assert str_to_bool(val="YES")
    assert str_to_bool(val="yep")
    assert str_to_bool(val="Yep")
    assert str_to_bool(val="yup")
    assert str_to_bool(val="YUP")
    assert str_to_bool(val="t")
    assert str_to_bool(val="truE")
    assert str_to_bool(val="on")
    assert str_to_bool(val="enable")
    assert str_to_bool(val="enabled")
    assert str_to_bool(val="1")


# Generated at 2022-06-21 23:44:35.973867
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""

    def test_load_environment_variable(tmp_path):
        """Test the ability to arrive at the environment from the file path."""
        os_environ["SOME_ENV_VAR"] = "some_file_path"
        location = "some_module_name/${SOME_ENV_VAR}"
        with open(tmp_path / os_environ["SOME_ENV_VAR"], "w") as some_file:
            some_file.write("TEST_VAR = value")

        module = load_module_from_file_location(location)
        assert module.TEST_VAR == "value"

    # On this test we rely on "doctest", that's why we turn off pylint
    # and my

# Generated at 2022-06-21 23:44:47.597111
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from unittest import TestCase
    from tempfile import TemporaryDirectory

    class TestStrToBool(TestCase):
        def test_valid_true(self):
            for true in (
                "y",
                "yes",
                "yep",
                "yup",
                "t",
                "true",
                "on",
                "enable",
                "enabled",
                "1",
            ):
                self.assertTrue(str_to_bool(true))

        def test_valid_false(self):
            for false in (
                "n",
                "no",
                "f",
                "false",
                "off",
                "disable",
                "disabled",
                "0",
            ):
                self.assertFalse(str_to_bool(false))


# Generated at 2022-06-21 23:44:57.767589
# Unit test for function str_to_bool
def test_str_to_bool():
    # Positive tests
    assert str_to_bool("Y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("T") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("True") is True
    assert str_to_bool("true") is True
    assert str_to_bool("t") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("On") is True
    assert str_to_bool("on") is True

# Generated at 2022-06-21 23:45:04.571502
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("TrUE") is True
    assert str_to_bool("y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("yEs") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("oN") is True
    assert str_to_bool("1") is True
    assert str_to_bool("fAlSe") is False
    assert str_to_bool("F") is False
    assert str_to_bool("off") is False
    assert str_to_bool("OFF") is False
    assert str_to_bool("disable") is False
    assert str_to_bool("DISABLED") is False

# Generated at 2022-06-21 23:45:13.523075
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    try:
        # This is correct.
        load_module_from_file_location(
            "tests/blueprints/test_blueprint/config_file.py"
        )
    except:  # noqa
        assert False

    # Without extension.
    try:
        load_module_from_file_location(
            "tests/blueprints/test_blueprint/config_file"
        )
        assert False
    except LoadFileException:
        pass

    # Wrong path.
    try:
        load_module_from_file_location(
            "tests/blueprints/test_blueprint/wrong_path.py"
        )
        assert False
    except FileNotFoundError:
        pass

    # Wrong path in bytes.

# Generated at 2022-06-21 23:45:29.329199
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Test if we can read just any file.
    module_a = load_module_from_file_location(location=__file__)

    # Test that we can read any file if it has .py extension.
    module_b = load_module_from_file_location(location=__file__)

    # Test that we can read any file if it has .py extension.
    module_c = load_module_from_file_location(
        location=Path(__file__)
    )

    assert module_a == module_b == module_c

    # Test load_module_from_file_location with relative path that contains
    # ${some_env_var}
    os_environ["sometestenvvar"] = str(Path(__file__).parent)
    module_d = load_module_from

# Generated at 2022-06-21 23:45:41.989284
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("true")
    assert str_to_bool("1")
    assert str_to_bool("y")

    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")

    assert str_to_bool("no")
    assert str_to_bool("false")
    assert str_to_bool("0")
    assert str_to_bool("f")

    assert str_to_bool("n")
    assert str_to_bool("off")
    assert str_to_bool("disable")
    assert str_to_bool("disabled")

    assert str_to_bool("YES")
    assert str_to_bool("FALSE")
    assert str_to_bool("0")


# Generated at 2022-06-21 23:45:52.283926
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for load_module_from_file_location helper function."""

    # A) Test if load_module_from_file_location raises PyFileError
    #    when path to config file doesn't exist
    with pytest.raises(PyFileError):
        load_module_from_file_location(f"{__file__}.config")

    # B) Test if load_module_from_file_location raises LoadFileException
    #    when environment variable does not exist.
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            f"{__file__}/some_module_name", "${some_env_var}"
        )

    # C) Test if load_module_from_file_location tries to load
    #    configuration file by specified path
    os_

# Generated at 2022-06-21 23:46:03.698103
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pprint import pprint

    from sanic.config import load_module_from_file_location
    from sanic.exceptions import LoadFileException

    CURRENT_DIR = Path(__file__)
    PROJECT_DIR = (
        CURRENT_DIR.parent.parent.parent
    )  # project dir (for testing) is parent of parent of current dir
    CONFIG_DIR = PROJECT_DIR / "test" / "test_applications"

    # Check error on no file
    try:
        load_module_from_file_location(CONFIG_DIR / "config_error_no_file.py")
    except IOError as e:
        error_message_expected = f"Unable to load configuration file {CONFIG_DIR / 'config_error_no_file.py'}"
        assert e.strerror

# Generated at 2022-06-21 23:46:10.101035
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SANIC_TEST_ENV_VAR"] = "testenvvar"
    assert load_module_from_file_location(
        "SANIC_TEST_ENV_VAR",
        __file__.rsplit("/", 1)[0] + "/test_config_loader.py",
    ).config_dict["env_var_key"] == "testenvvar"

# Generated at 2022-06-21 23:46:22.246432
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Common test function to test function load_module_from_file_location
    def _test_load_module_from_file_location(
        location: Union[bytes, str, Path],
        expected_module_name: str,
        expected_module_file: str,
        expected_module_file_abs_path: str,
        expected_module_dict: dict,
        expected_module_dict_keys: set = None,
    ):
        if expected_module_dict_keys is None:
            expected_module_dict_keys = set(expected_module_dict.keys())
        module = load_module_from_file_location(location)
        assert module.__name__ == expected_module_name
        assert module.__file__ == expected_module_file
        assert module.__file__ == expected_module_file_abs

# Generated at 2022-06-21 23:46:33.694843
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import pytest

    import sanic.config

    config_file = "tests/unittest_configs/config.py"

    # Set values in os.environ for test purposes.
    os.environ["test_env_1"] = "/test_val_1"
    os.environ["test_env_2"] = "/test_val_2"
    os.environ["test_env_3"] = "/test_val_3"
    os.environ["test_env_4"] = "/test_val_4"

    # 1. Load config by file path
    loaded_module = sanic.config.load_module_from_file_location(config_file)
    assert loaded_module.TEST_VALUE_FOR_FILE_CONFIG == "path_config"

    # 2. Load config

# Generated at 2022-06-21 23:46:43.542231
# Unit test for function str_to_bool
def test_str_to_bool():
    """Tests the function str_to_bool and raises AssertionError if the test fails"""
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True

    assert str_to_bool("n") == False
    assert str_to_bool("false") == False
    assert str_to_bool("f") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False

    try:
        assert str_to_bool("no")
        raise AssertionError
    except ValueError:
        pass

# Generated at 2022-06-21 23:46:55.496101
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("yes") == True
    assert str_to_bool("n") == False
    assert str_to_bool("true") == True
    assert str_to_bool("false") == False
    assert str_to_bool("on") == True
    assert str_to_bool("off") == False
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("Yes") == True
    assert str_to_bool("False") == False
    try:
        str_to_bool("5")
    except ValueError as e:
        assert str(e) == "Invalid truth value 5"

# Generated at 2022-06-21 23:47:04.059324
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function."""
    import types
    import os

    # Test case 1:
    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    module = load_module_from_file_location(
        "tests/app/app.py", "${TEST_ENV_VAR}/tests/app"
    )
    assert isinstance(module, types.ModuleType)
    assert module.__file__ == "${TEST_ENV_VAR}/tests/app/app.py"
    assert module.some_text == "some_text"
    assert module.some_number == 123
    assert module.some_bool_value is True

    # Test case 2:

# Generated at 2022-06-21 23:47:19.247292
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys

    # Test pathlib.Path
    assert load_module_from_file_location(Path(__file__)) == sys.modules[
        __name__
    ]

    # Test str
    assert load_module_from_file_location(__file__) == sys.modules[__name__]

    # Test bytes
    assert load_module_from_file_location(__file__.encode("utf8")) == sys.modules[
        __name__
    ]

    # Test importing package
    # Create new .py module
    with open("tmp.py", "w+") as file:
        file.write("var = 5")

    module = load_module_from_file_location("tmp.py")

    assert module.var == 5

    # Test importing module from nested directory

# Generated at 2022-06-21 23:47:28.637440
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Check if load_module_from_file_location works as expected."""
    import pytest  # noqa
    from os import path  # noqa

    # Load file using function load_module_from_file_location
    # and check if it was loaded successfully.
    module = load_module_from_file_location(
        path.join(path.dirname(__file__), "auxiliary_module.py")
    )

    assert module.AUXILIARY_INT == 1  # noqa
    assert module.AUXILIARY_STR == "AUXILIARY_STR"  # noqa
    assert module.AUXILIARY_NONE is None  # noqa

    # Load file using function load_module_from_file_location
    # and check if it was loaded successfully.


# Generated at 2022-06-21 23:47:38.604228
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Yes") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("ok") is True
    assert str_to_bool("1") is True
    assert str_to_bool("No") is False
    assert str_to_bool("") is False
    assert str_to_bool("0") is False
    assert str_to_bool("f") is False
    try:
        assert str_to_bool("nof") is False
    except ValueError:
        pass
    try:
        assert str_to_bool("yop") is False
    except ValueError:
        pass

# Generated at 2022-06-21 23:47:50.131327
# Unit test for function str_to_bool
def test_str_to_bool():
    example_str_bool = {
        "Y": True,
        "yes": True,
        "yep": True,
        "yup": True,
        "t": True,
        "true": True,
        "on": True,
        "enable": True,
        "enabled": True,
        "1": True,
        "N": False,
        "no": False,
        "f": False,
        "false": False,
        "off": False,
        "disable": False,
        "disabled": False,
        "0": False,
        "YEs": True,
        "No": False,
    }
    assert all([str_to_bool(key) == value for key, value in example_str_bool.items()])

# Generated at 2022-06-21 23:47:59.913321
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    This test will require access to relative path.
    """
    test_file_name = "test_file.py"
    test_file_path = str(Path(__file__).parent.absolute()) + "/" + test_file_name
    test_file_content = """
    TEST_FILE_ENV_VAR="~/test_file_env_var"
    TEST_FILE_BASE_PORT=8080
    TEST_FILE_UPLOAD_FOLDER="./uploads"
    TEST_FILE_UNICODE_HELLO_WORLD = "你好，世界"
    """
    with open(test_file_path, "w") as f:
        f.write(test_file_content)

    from os import environ as os_environ

    os

# Generated at 2022-06-21 23:48:11.185757
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Runs unit tests for load_module_from_file_location function."""
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdirname:
        # 1) Check if load_module_from_file_location can load file
        #    independent of location type (Path or string).
        Path(tmpdirname).joinpath("some_module.py").write_text(
            "SOME_VAR = 'some string'"
        )
        imported_module_1 = load_module_from_file_location(
            Path(tmpdirname).joinpath("some_module.py")
        )
        imported_module_2 = load_module_from_file_location(
            f"{tmpdirname}/some_module.py"
        )
        assert imported_module_1.SOME_

# Generated at 2022-06-21 23:48:23.678328
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-21 23:48:25.033160
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") == True



# Generated at 2022-06-21 23:48:38.211163
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("On") is True
    assert str_to_bool("on") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("1") is True

    assert str_to_bool("No") is False
    assert str_to_bool("n") is False
    assert str_to_bool("N") is False
    assert str_to_bool("Off") is False
    assert str_to_bool("off") is False
    assert str_to_bool("OFF") is False
    assert str_to_bool("0") is False

    with pytest.raises(ValueError):
        str_to_

# Generated at 2022-06-21 23:48:49.219110
# Unit test for function str_to_bool
def test_str_to_bool():
    # all examples from docstring:
    assert str_to_bool("")
    assert str_to_bool("yes")
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert not str_to_bool("no")
    assert not str_to_bool("n")
    assert not str_to_bool("N")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert not str_to_bool("nup")
    assert not str_to_bool("nope")
    assert str_to_bool("true")
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert not str_to_bool("false")
    assert not str_to_bool("f")
    assert not str

# Generated at 2022-06-21 23:49:07.686382
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:49:16.757739
# Unit test for function str_to_bool
def test_str_to_bool():
    true_vals = ("yes", "y", "YeS", "True", "1", "ON", "yEs")
    false_vals = ("no", "n", "NO", "False", "0", "off", "nO")
    for val in true_vals:
        assert str_to_bool(val)
    for val in false_vals:
        assert not str_to_bool(val)

# Generated at 2022-06-21 23:49:26.746025
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    """Unit test for function str_to_bool"""

    assert str_to_bool("1") is True
    assert str_to_bool("0") is False

    assert str_to_bool("y") is True
    assert str_to_bool("n") is False

    assert str_to_bool("on") is True
    assert str_to_bool("off") is False

    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False

    assert str_to_bool("yup") is True
    assert str_to_bool("nope") is False

    assert str_to_bool("enable") is True
    assert str_to_bool("disable") is False

    assert str_to_bool("enabled") is True

# Generated at 2022-06-21 23:49:37.622681
# Unit test for function str_to_bool
def test_str_to_bool():
    assert True == str_to_bool("y")
    assert True == str_to_bool("yes")
    assert True == str_to_bool("yep")
    assert True == str_to_bool("yup")
    assert True == str_to_bool("t")
    assert True == str_to_bool("true")
    assert True == str_to_bool("on")
    assert True == str_to_bool("enable")
    assert True == str_to_bool("enabled")
    assert True == str_to_bool("1")

    assert False == str_to_bool("n")
    assert False == str_to_bool("no")
    assert False == str_to_bool("f")
    assert False == str_to_bool("false")
    assert False == str_to_bool("off")

# Generated at 2022-06-21 23:49:50.590040
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # A) When path is not given
    with pytest.raises(ValueError) as exc_info:
        load_module_from_file_location("some_module_name")
    assert (
        str(exc_info.value) == "Unable to load configuration file (e.strerror)"
    )

    # B) When path is given without environment variable
    location = "tests/test_configs/config.py"
    result = load_module_from_file_location(location)
    assert isinstance(result, types.ModuleType)
    assert result.TEST_CONFIG == "test"

    # C) When path is given and contains environment variable
    os_environ["config_location"] = "tests/test_configs/config.py"
    location = "${config_location}"


# Generated at 2022-06-21 23:49:55.381001
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    source = parse("""
name = "Adam"
age = 33
is_human = True
friends = ["Pawel", "Janek", "Franek", "Wujek"]
""")

    filename = Path("/tmp/test_load_file_location_test_module.py")
    filename.touch()
    filename.write_text(source.strip())
    module = load_module_from_file_location(filename)
    assert module.name == "Adam"
    assert module.age == 33
    assert module.is_human == True
    assert module.friends == ["Pawel", "Janek", "Franek", "Wujek"]
    filename.unlink()

# Generated at 2022-06-21 23:50:05.409756
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("true") == True
    assert str_to_bool("TrUe") == True
    assert str_to_bool("1") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("on") == True
    assert str_to_bool("y") == True
    assert str_to_bool("<<TrUe>>") == True
    assert str_to_bool("<<1>>") == True
    assert str_to_bool("<<enable>>") == True
    assert str_to_bool("<<on>>") == True
    assert str_to_bool("<<y>>") == True

    assert str_to_bool("False") == False