

# Generated at 2022-06-21 23:40:14.102117
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import os

    import pytest

    from sanic import Sanic
    from sanic.exceptions import LoadFileException, PyFileError
    from sanic.utils import load_module_from_file_location

    # A) Prepare example config file.
    config_file_name = "example_config.py"
    config_module_name = "example_config"

    config_file_content = """
    FIRST_VAR = "First variable value"
    """
    with open(config_file_name, "w") as config_file:
        config_file.write(config_file_content)

    # B) Test that it works with pathlib.Path object.
    app = Sanic("test_app")
    app.config.from_pyfile

# Generated at 2022-06-21 23:40:24.393139
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests for ``load_module_from_file_location`` function."""

    test_file = Path(__file__).parent / "load_module_from_file_location_file.py"
    test_module = load_module_from_file_location(str(test_file))
    assert test_module.test_name == "test_module_name"
    assert test_module.test_callable(2) == 4

    test_module_bytes = load_module_from_file_location(b"ascii", test_file)
    assert test_module_bytes.test_name == "test_module_name"
    assert test_module_bytes.test_callable(2) == 4

    os_environ["test_var"] = "test_module_name"

# Generated at 2022-06-21 23:40:35.263276
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-21 23:40:39.843701
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("true") is True
    assert str_to_bool("1") is True
    assert str_to_bool("no") is False

# Generated at 2022-06-21 23:40:51.934405
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("t") is True
    assert str_to_bool("on") is True
    assert str_to_bool("1") is True
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("off") is False
    assert str_to_bool("0") is False
    try:
        str_to_bool("yeah")
        assert False
    except ValueError as e:
        assert True

# Unit tests for function load_module_from_file_location

# Generated at 2022-06-21 23:41:04.697768
# Unit test for function load_module_from_file_location

# Generated at 2022-06-21 23:41:15.952996
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Testing ability to load module from file location."""
    file_contents = (
        "# Some comment\n"
        "VAR1 = 1\n"
        "# Another comment\n"
        "VAR2 = 2\n"
    )
    with TemporaryDirectory() as tmp_dir:
        # Write file with string.
        tmp_file_path = Path(tmp_dir) / "test_file"
        tmp_file_path.write_text(file_contents)

        # Test that module is being loaded properly.
        loaded_module = load_module_from_file_location(tmp_file_path)
        assert hasattr(loaded_module, "VAR1")
        assert hasattr(loaded_module, "VAR2")
        assert loaded_module.VAR1 == 1

# Generated at 2022-06-21 23:41:27.574218
# Unit test for function str_to_bool
def test_str_to_bool():
    # True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    # False
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool

# Generated at 2022-06-21 23:41:37.773365
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("F") == False
    assert str_to_bool("FALSE") == False
    assert str_to_bool("0") == False

    try:
        assert str_to_bool("dsfdsf")
    except Exception as err:
        assert isinstance(err, ValueError)

# Generated at 2022-06-21 23:41:49.323155
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location() function."""
    from pathlib import Path

    from pytest import raises

    from sanic.utils import load_module_from_file_location

    location = Path("tests/example_config.py")

    expected_locals = {
        "TEST_KEY_1": "config",
        "TEST_KEY_2": 2,
        "TEST_KEY_3": ["a", 1, True],
        "TEST_KEY_4": {"a": "A", 1: "I"},
    }

    config = load_module_from_file_location(location)

    for key, val in expected_locals.items():
        assert getattr(config, key) == val

    # Test location with environment variables

# Generated at 2022-06-21 23:42:07.382758
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import types
    import time
    import tempfile

    assert isinstance(
        load_module_from_file_location("types"), types.ModuleType
    )

    assert load_module_from_file_location("types").__name__ == "types"

    assert load_module_from_file_location("sanic.exceptions").__name__ == "sanic.exceptions"  # noqa

    assert load_module_from_file_location("sanic.exceptions").__file__.endswith("sanic/exceptions.py")  # noqa

    assert not load_module_from_file_location("time").__file__  # builtin module

    # Check if load_module_from_file_location raise proper exceptions
    # in case of invalid path.
    expected_error_msg = "No such file or directory"

# Generated at 2022-06-21 23:42:19.350074
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    _os_environ = dict(os_environ)  # type: ignore
    test_file = Path(__file__).parent / "test_load_module_from_file_location.py"
    test_file_content = test_file.read_text()

    # A) with unicode
    module = load_module_from_file_location(
        str(test_file), encoding="utf8"
    )

    assert module.my_var == "my_var"
    assert module.__name__ == "test_load_module_from_file_location"
    assert module.__file__ == str(test_file)

    # B) with bytes
    module = load_module_from_file_location(
        test_file.read_bytes(), encoding="utf8"
    )

    assert module.my_

# Generated at 2022-06-21 23:42:31.450142
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("ON") is True
    assert str_to_bool("off") is False
    assert str_to_bool("yup") is True
    assert str_to_bool("NO") is False
    assert str_to_bool("y") is True
    assert str_to_bool("FALSE") is False
    assert str_to_bool("Y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("N") is False
    assert str_to_bool("True") is True
    assert str_to_bool("0") is False
    assert str_to_bool("1") is True
    assert str_to_bool("YeP") is True
    assert str_to_bool("OFF") is False
    assert str_to_bool("yEs") is True


# Generated at 2022-06-21 23:42:41.941150
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("YeS") is True
    assert str_to_bool("YeP") is True
    assert str_to_bool("YeU") is True
    assert str_to_bool("YeA") is True
    assert str_to_bool("t") is True
    assert str_to_bool("tRue") is True
    assert str_to_bool("TrUe") is True
    assert str_to_bool("TRUe") is True
    assert str_to_bool("TrUE") is True
    assert str_to_bool("TruE") is True
    assert str_to_bool("True") is True
    assert str_to_bool("on") is True
    assert str_

# Generated at 2022-06-21 23:42:51.062207
# Unit test for function str_to_bool
def test_str_to_bool():
    from pytest import raises
    from numpy.testing import assert_

    assert_(str_to_bool("true") is True)
    assert_(str_to_bool("TRUE") is True)
    assert_(str_to_bool("1") is True)
    assert_(str_to_bool("y") is True)
    assert_(str_to_bool("YEa") is True)

    assert_(str_to_bool("false") is False)
    assert_(str_to_bool("FALSE") is False)
    assert_(str_to_bool("0") is False)
    assert_(str_to_bool("n") is False)
    assert_(str_to_bool("no") is False)

    with raises(ValueError):
        str_to_bool("-")



# Generated at 2022-06-21 23:43:02.466585
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("True") == True
    assert str_to_bool("False") == False
    assert str_to_bool("true") == True
    assert str_to_bool("false") == False
    assert str_to_bool("TRUE") == True
    assert str_to_bool("FALSE") == False
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("Y") == True
    assert str_to_bool("N") == False
    assert str_to_bool("YES") == True
    assert str_to_bool("NO") == False
    assert str_to_bool("yes") == True

# Generated at 2022-06-21 23:43:13.494528
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("YEP") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("YUP") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("T") is True
    assert str_to_bool("True") is True
    assert str_to_bool("True") is True
    assert str_to_bool("on") is True
    assert str_to_bool("oN") is True
    assert str_to_bool("ON") is True


# Generated at 2022-06-21 23:43:23.090328
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # 1) Test that one can load config module from a file path.
    import tempfile
    import pathlib

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = pathlib.Path(tmp_dir)
        tmp_file = tmp_dir / "config.py"
        tmp_file.touch()
        tmp_file.write_text("SOME_CONFIG_CONSTANT = 1")

        from_path = load_module_from_file_location(str(tmp_file))

        assert from_path.SOME_CONFIG_CONSTANT == 1

    # 2) Test that one can load config module from a file path
    #    with special characters in its name.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = pathlib.Path(tmp_dir)


# Generated at 2022-06-21 23:43:34.657743
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa: D202
    assert str_to_bool("Yes") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("1") is True
    assert str_to_bool("On") is True
    assert str_to_bool("Enable") is True
    assert str_to_bool("False") is False
    assert str_to_bool("f") is False
    assert str_to_bool("Off") is False
    assert str_to_bool("0") is False
    assert str_to_bool("yup") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("t") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False

# Generated at 2022-06-21 23:43:45.690365
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Just simple test of a single function.
    # To run it:
    #  1. cd src/sanic
    #  2. pytest test_helpers.py

    # Here we create file that will be used in testing.
    # It has to be in a separate function because it will be called
    # in a subprocess.
    def create_config_file(location):
        with open(location, "w") as test_file:
            test_file.write("TEST_VAR_1 = 1\n")
            test_file.write("TEST_VAR_2 = 2\n")

    # A) Testing with plain string file path.
    test_file_path = "test_helpers_config_file.py"
    create_config_file(test_file_path)
    test_module = load

# Generated at 2022-06-21 23:43:56.635584
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        __file__.replace(".py", "_module.py"),
        "${TEST_PROJECT_PATH}",
    )
    assert module.somelist == ["v1", "v2"]
    assert module.somestring == "somestring"



# Generated at 2022-06-21 23:44:06.610407
# Unit test for function str_to_bool
def test_str_to_bool():
    string_true = (
        "Y",
        "YES",
        "YEP",
        "YUP",
        "T",
        "TRUE",
        "ON",
        "ENABLE",
        "ENABLED",
        "1",
    )
    string_false = (
        "N",
        "NO",
        "F",
        "FALSE",
        "OFF",
        "DISABLE",
        "DISABLED",
        "0",
    )
    for string in string_true:
        assert str_to_bool(string)
    for string in string_false:
        assert not str_to_bool(string)
    try:
        str_to_bool(123)
        raise Exception("Should raise ValueError")
    except ValueError:
        pass

# Generated at 2022-06-21 23:44:15.154095
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from os import makedirs, environ, remove
    from os.path import exists, isdir
    from shutil import rmtree
    from tempfile import gettempdir

    # Python multiline statement
    import ast

    def _ast_to_py_multiline_statement(python_ast: ast.Module) -> str:
        import astor

        return "\n".join(astor.to_source(python_ast, add_line_information=False))

    # Create temporary directory
    tmp_dir = Path(gettempdir()) / "sanic-test"

    # Create nested structure

# Generated at 2022-06-21 23:44:28.534926
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:44:29.270862
# Unit test for function str_to_bool
def test_str_to_bool():
    pass


# Generated at 2022-06-21 23:44:36.173686
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from tempfile import TemporaryDirectory

    from .test_config import get_test_config

    from sanic import Sanic

    with TemporaryDirectory() as temp_dir:
        sanic_conf_file = (
            Path(temp_dir) / "sanic_config.py"
        )  # Expected existence of this file
        sanic_conf_file.write_text(get_test_config())

        # Set environment variables to use them in config file path
        environ["TEST_ENV_VAR_1"] = str(sanic_conf_file.parent)
        environ["TEST_ENV_VAR_2"] = str(sanic_conf_file.name)

        # 1) Load config file via file path in format
        #    "/path/to/config/file.py

# Generated at 2022-06-21 23:44:47.679162
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys
    import pytest
    from pathlib import Path
    import tempfile

    # Test basic functionality
    path = Path(tempfile.gettempdir()) / "config.py"
    path.write_text('FOO = "bar"')
    # Test Path
    test_module = load_module_from_file_location(path)
    assert test_module.FOO == "bar"
    # Test str
    test_module = load_module_from_file_location(str(path))
    assert test_module.FOO == "bar"
    # Test bytes
    test_module = load_module_from_file_location(path.read_bytes())
    assert test_module.FOO == "bar"
    # Test bytes with encoding
    test_module = load_module_from_file_

# Generated at 2022-06-21 23:44:55.558432
# Unit test for function str_to_bool
def test_str_to_bool():
    for truth_string in (
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ):
        assert str_to_bool(truth_string)
    for false_string in (
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ):
        assert not str_to_bool(false_string)



# Generated at 2022-06-21 23:45:08.452857
# Unit test for function str_to_bool
def test_str_to_bool():
    """
    Tests if str_to_bool works as expected
    """
    true_strings = (
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    )

    false_strings = (
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    )

    assert all([str_to_bool(s) for s in true_strings])
    assert not all([str_to_bool(s) for s in false_strings])

    for s in true_strings:
        assert str_to_bool(s.upper()) is True


# Generated at 2022-06-21 23:45:21.102895
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test for load_module_from_file_location
    """
    # Test load file from location as string
    content = """
    SANIC_TEST_VAR = "I'm test var"
    """

    with tempfile.NamedTemporaryFile("wt", suffix=".py") as file_obj:
        file_obj.write(content)
        file_obj.flush()
        module = load_module_from_file_location(file_obj.name)
        assert module.SANIC_TEST_VAR == "I'm test var"

    # Test load file from location as Path
    with tempfile.NamedTemporaryFile("wt", suffix=".py") as file_obj:
        file_obj.write(content)
        file_obj.flush()
        module = load_module_from_file_

# Generated at 2022-06-21 23:45:39.706071
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # Prepare some env vars and modules in temporary files
    os_environ["some_env_var"] = "some_env_value"
    with tempfile.NamedTemporaryFile("wt") as f:
        f.write("foo = 2\n")
        f.flush()
        f_location = Path(f.name)

    with tempfile.NamedTemporaryFile("wt") as f:
        f.write("foo = 1\n")
        f.flush()
        f_location_2 = Path(f.name)

    # Test str case
    assert (
        load_module_from_file_location(f_location).foo == 2
    )  # Test case with file location

# Generated at 2022-06-21 23:45:50.387360
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-21 23:46:01.641493
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        "tests.test_helpers.fixtures",
        Path(__file__).parent / "fixtures/config_module.py",
    )
    assert module.TEST_VALUE_STR == "test value str"
    assert module.TEST_VALUE_INT == 123
    assert module.TEST_VALUE_FLOAT == 12.3
    assert module.TEST_VALUE_LIST == [1, 2, 3]
    assert module.TEST_VALUE_DICT == {"a": 1, "b": 2, "c": 3}
    assert module.TEST_VALUE_SET == {"a", "b", "c"}
    assert module.TEST_VALUE_TUPLE == (1, 2, 3)
    assert module.TEST_VALUE_BOOL is True

# Generated at 2022-06-21 23:46:13.999668
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from tempfile import mkstemp
    from os import remove

    # Creates temporary files and writes a number to each of them
    _, temp_file_1 = mkstemp(suffix=".py")
    _, temp_file_2 = mkstemp(suffix=".py")
    with open(temp_file_1, "w") as test_file:
        test_file.write("TEST_CONSTANT = 1")
    with open(temp_file_2, "w") as test_file:
        test_file.write("TEST_CONSTANT = 2")

    # 1. Loads module from absolute path
    assert (
        load_module_from_file_location(temp_file_1).TEST_CONSTANT == 1
    )  # noqa

    # 2. Load

# Generated at 2022-06-21 23:46:25.209423
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def test_load_module_from_file_location_get_file_name(location, exp_name):
        assert load_module_from_file_location(location).__name__ == exp_name

    def test_load_module_from_file_location_get_file_path(location, exp_path):
        assert load_module_from_file_location(location).__file__ == exp_path

    def test_load_module_from_file_location_get_file_content(location, exp_content):
        assert load_module_from_file_location(location).__dict__ == exp_content

    # Simple path
    test_load_module_from_file_location_get_file_name(
        "/srv/my_app/config.py", "config"
    )
    # Path with .py extension

# Generated at 2022-06-21 23:46:36.753797
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import os

    # Prepare test environment
    env_vars = {
        "var1": "value1",
        "var2": "value2",
        "var3": "value3",
        "var4": "value4",
    }
    for name, value in env_vars.items():
        os.environ[name] = value

    # Test without environment variables
    some_module = load_module_from_file_location(
        "sanic_openapi.test_load_module",
        os.path.join(
            os.path.dirname(__file__),
            "test_load_module.py",
        ),
    )
    assert sys.modules.get("sanic_openapi.test_load_module.test_load_module")

# Generated at 2022-06-21 23:46:45.811989
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("disable") is False
    assert str_to_bool("0") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("1") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True

# Generated at 2022-06-21 23:46:57.125675
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from .constants import TEST_DIR

    # A) Testing the main body of function.

    # 1.1) Should load module from .py file.
    path_to_py_file = os.path.join(TEST_DIR, "test_load_module_from_file_location.py")

    with pytest.raises(SystemExit):
        test_module = load_module_from_file_location(path_to_py_file)
        test_module.main()

    # 1.2) Should load module from .txt file.
    path_to_txt_file = os.path.join(TEST_DIR, "test_load_module_from_file_location")
    with open(path_to_txt_file, "w") as f:
        f.write("var = 'val'")

# Generated at 2022-06-21 23:47:04.707706
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Checks if function load_module_from_file_location loads module
    correctly if location is a string, bytes, or path."""
    # A) Check string locations
    module_by_string = load_module_from_file_location(
        "__future__",  # this is a module name of course
        "__future__.py",
        "aurora/sanic/utils/__init__.py",
        __package__,
        os_environ["HOME"] + "/Documents",
    )
    assert module_by_string is __future__

    # B) Bytes locations

# Generated at 2022-06-21 23:47:14.745578
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("true") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("1") == True
    assert str_to_bool("no") == False
    assert str_to_bool("false") == False
    assert str_to_bool("f") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("0") == False
    try:
        str_to_bool("bla")
        assert False
    except ValueError:
        pass
    try:
        str_to_bool("2")
        assert False
    except ValueError:
        pass

# Generated at 2022-06-21 23:47:30.803072
# Unit test for function str_to_bool
def test_str_to_bool():
    # Test True:
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("yes")
    assert str_to_bool("YeS")
    assert str_to_bool("yep")
    assert str_to_bool("YEP")
    assert str_to_bool("yup")
    assert str_to_bool("YUP")
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert str_to_bool("on")
    assert str_to_bool("ON")
    assert str_to_bool("true")
    assert str_to_bool("tRUE")
    assert str_to_bool("enable")
    assert str_to_bool("Enable")
    assert str_to_bool("enabled")

# Generated at 2022-06-21 23:47:35.864791
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    file_path = "tests/configs/module_example.py"

    module = load_module_from_file_location(file_path)

    assert module.VARIABLE == "config"



# Generated at 2022-06-21 23:47:45.997495
# Unit test for function str_to_bool
def test_str_to_bool():
    import pytest

    with pytest.raises(ValueError):
        str_to_bool("not_boolean_str")

    assert str_to_bool("1") is True
    assert str_to_bool("0") is False

    assert str_to_bool("on") is True
    assert str_to_bool("off") is False

    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False

# Generated at 2022-06-21 23:47:56.937425
# Unit test for function str_to_bool
def test_str_to_bool():
    " This test is used by pytest"
    assert str_to_bool("True") is True
    assert str_to_bool("truE") is True
    assert str_to_bool("FALSE") is False
    assert str_to_bool("0") is False
    assert str_to_bool("1") is True
    assert str_to_bool("on") is True
    assert str_to_bool("off") is False
    assert str_to_bool("enable") is True
    assert str_to_bool("disable") is False
    assert str_to_bool("Y") is True
    assert str_to_bool("F") is False
    assert str_to_bool("Yes") is True
    assert str_to_bool("No") is False
    assert str_to_bool("N") is False
    assert str

# Generated at 2022-06-21 23:48:06.685242
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests load_module_from_file_location function.
    """
    import sys

    mod_name = "test_module"
    mod_location = "./test_module.py"
    module = load_module_from_file_location(mod_name, mod_location)
    assert mod_location in sys.modules
    assert "test_module" in sys.modules
    assert module is sys.modules["test_module"]
    assert module.__file__ == "./test_module.py"



# Generated at 2022-06-21 23:48:18.838347
# Unit test for function str_to_bool
def test_str_to_bool():
    """Test function str_to_bool."""
    assert str_to_bool("True") is True
    assert str_to_bool("TRuE") is True
    assert str_to_bool("t") is True
    assert str_to_bool("1") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("enable") is True

    assert str_to_bool("False") is False
    assert str_to_bool("falSe") is False
    assert str_to_bool("f") is False
    assert str_to_bool("0") is False
    assert str_to_bool("no") is False

# Generated at 2022-06-21 23:48:28.461816
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-21 23:48:31.274070
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("false") is False

# Generated at 2022-06-21 23:48:38.931375
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir_name:

        # Create file.
        file_name = "test_config.py"
        file_path = Path(temp_dir_name, file_name)
        file_path.touch()

        # Create file with no .py extension
        file_name_nopie = "test_config_nopie"
        file_path_nopie = Path(temp_dir_name, file_name_nopie)
        file_path_nopie.touch()

        # Create file which contains env variables.
        file_name_with_env_vars = "test_config_with_env_vars.py"

# Generated at 2022-06-21 23:48:47.183465
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("trUE") is True
    assert str_to_bool("yeP") is True

    assert str_to_bool("n") is False
    assert str_to_bool("NO") is False
    assert str_to_bool("F") is False

    try:
        str_to_bool("maybe")
    except ValueError as e:
        assert str(e) == "Invalid truth value maybe"


# Generated at 2022-06-21 23:49:07.486189
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("") is False
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str

# Generated at 2022-06-21 23:49:20.921249
# Unit test for function str_to_bool

# Generated at 2022-06-21 23:49:33.828957
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-21 23:49:43.560484
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Test with no env vars.
    location = "tests/config.py"
    module = load_module_from_file_location(location)
    assert module.TEST == "test"

    # Test with env vars.
    location = "tests/${SANIC_TEST_MODULE}"
    module = load_module_from_file_location(location)
    assert module.TEST == "test"

    # Test with not defined env vars.
    location = "tests/${SANIC_NOT_DEFINED_VARIABLE}"
    try:
        load_module_from_file_location(location)
    except LoadFileException as e:
        assert "The following environment variables are not set: SANIC_NOT_DEFINED_VARIABLE" == str(e)

# Generated at 2022-06-21 23:49:54.969542
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import pytest

    def _create_and_open_temp_file():
        f = tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False)
        f.close()
        return f.name

    # Test IOError
    with pytest.raises(IOError) as e:
        load_module_from_file_location("/not_existing_path/to/file.py")
    assert e.value.strerror == "Unable to load configuration file (e.strerror)"

    # Test non existing file as pathlib.Path
    with pytest.raises(FileNotFoundError):
        load_module_from_file_location(Path("/not_existing_path/to/file.py"))

    # Test non existin file as bytes

# Generated at 2022-06-21 23:50:05.383794
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def assert_exception(val):
        try:
            load_module_from_file_location(val)
        except Exception:
            return True
        return False

    assert assert_exception(Path("/some/invalid/path.py"))
    assert assert_exception(Path("/some/invalid/path.pyt"))
    assert assert_exception("./some/invalid/path.py")
    assert assert_exception("../some/invalid/path.py")
    assert assert_exception("../some/invalid/path.pyt")
    assert assert_exception("some/invalid/path.py")
    assert assert_exception("some/invalid/path")

    # Load config with the right path