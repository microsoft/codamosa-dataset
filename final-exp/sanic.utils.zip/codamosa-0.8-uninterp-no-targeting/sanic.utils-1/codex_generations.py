

# Generated at 2022-06-21 23:40:31.805756
# Unit test for function str_to_bool
def test_str_to_bool():
    # lowercase and uppercase
    assert str_to_bool("yes")
    assert str_to_bool("YES")
    assert not str_to_bool("no")
    assert not str_to_bool("NO")

    # some typos
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("enabled")

    assert not str_to_bool("n")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")

    # numbers
    assert str_to_bool("1")
    assert not str_to_bool("0")

    # wrong values
    with pytest.raises(ValueError):
        str_to_bool("some")

# Generated at 2022-06-21 23:40:44.051475
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    ##########
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    ##########

    # Test location with environment variable.
    location_with_env_var = "this_is_env_var_${ENV_VAR1}_this_is_env_var"

    # Test that `load_module_from_file_location` works with
    # location containing environment variable.
    load_module_from_file_location(location_with_env_var)

    # Test that `load_module_from_file_location` fails with
    # location containing undefined environment variable.
    # Mark that we can not use `os.environ.copy()` because
    # it returns `os._Environ` type.

# Generated at 2022-06-21 23:40:52.666086
# Unit test for function str_to_bool
def test_str_to_bool():
    valid_true_list = [
        "y", "yes", "yep", "yup", "t", "true", "on", "enable", "enabled", "1"
    ]
    valid_false_list = [
        "n", "no", "f", "false", "off", "disable", "disabled", "0"
    ]
    for value in valid_true_list:
        assert str_to_bool(value) is True
    for value in valid_false_list:
        assert str_to_bool(value) is False
    with pytest.raises(ValueError):
        str_to_bool("somewhat")

# Generated at 2022-06-21 23:41:04.837963
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    from os import environ as os_environ, mkdir, remove
    from os.path import abspath, isdir, isfile, join

    # Create temporary configuration file with content:
    # {"test_key": "test_value"}
    tempdir_path = abspath(tempfile.gettempdir())

    test_configuration_filename = "sanic-test-config.json"
    test_configuration_file_path = join(
        tempdir_path, test_configuration_filename
    )
    test_configuration_file_content = '{"test_key": "test_value"}'

    with open(test_configuration_file_path, "w") as f:
        f.write(test_configuration_file_content)

    # Load configuration file as module and make sure
    # it

# Generated at 2022-06-21 23:41:15.997639
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    # A) TEST 1:
    # Check that the function loads modules from directory
    # without the use of environment variables.
    test_dir_path = os.path.dirname(__file__)
    os.chdir(test_dir_path)

    # Create file config_file.py with some content
    config_file_path = "config_file.py"
    with open(config_file_path, "w") as f:
        f.write("a = True")

    # Run the load_module_from_file_location() function.
    module = load_module_from_file_location(config_file_path)

    # Assert that the function returned module.
    assert isinstance(module, types.ModuleType)

    # Assert that the module has attribute 'a' with value of True.


# Generated at 2022-06-21 23:41:27.604760
# Unit test for function str_to_bool
def test_str_to_bool():
    # "y", "yes", "yep", "yup", "t",
    # "true", "on", "enable", "enabled", "1"
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    # "n", "no", "f", "false", "off", "disable", "disabled", "0"

# Generated at 2022-06-21 23:41:36.366234
# Unit test for function str_to_bool

# Generated at 2022-06-21 23:41:39.785179
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    assert load_module_from_file_location("tests.test_configuration") == tests.test_configuration  # noqa

# Generated at 2022-06-21 23:41:48.821132
# Unit test for function str_to_bool
def test_str_to_bool():
    # True
    assert str_to_bool(" yes ") == True
    assert str_to_bool("on") == True
    assert str_to_bool("1") == True

    # False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("0") == False

    #Raise ValueError
    try:
        str_to_bool("some_str")
        raise AssertionError("str_to_bool should have raised ValueError")
    except ValueError as e:
        assert str(e) == "Invalid truth value some_str"

# Generated at 2022-06-21 23:41:58.243171
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    with pytest.raises(ValueError):
        assert load_module_from_file_location("")
    with pytest.raises(ValueError):
        assert load_module_from_file_location("/path/to/file")
    with pytest.raises(AttributeError):
        assert load_module_from_file_location(
            "/path/to/file.py", "not_existing_attr", "module_name"
        )
    with pytest.raises(TypeError):
        assert load_module_from_file_location(
            "/path/to/file.py", "module_name", "not_existing_attr"
        )

# Generated at 2022-06-21 23:42:10.286421
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():    # noqa
    """
    Check load_module_from_file_location function behaviour
    """
    import os
    from io import BytesIO
    from tempfile import NamedTemporaryFile

    from .helpers import TestLine, TestError

    some_module_file_content = b"VARIABLE = 123"

    # A) Check if function raises LoadFileException
    #    if location contains undefined environment variables.
    os_environ.pop("SOME_ENV_VAR", None)
    try:
        load_module_from_file_location(
            b"/some/path/${SOME_ENV_VAR}", encoding="utf8"
        )
    except LoadFileException as e:
        pass

# Generated at 2022-06-21 23:42:19.450961
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("YeS") is True
    assert str_to_bool("true") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("YUP") is True
    assert str_to_bool("yEs") is True
    assert str_to_bool("YeP") is True
    assert str_to_bool("ENABLE") is True

# Generated at 2022-06-21 23:42:31.523875
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("True")
    assert str_to_bool("on")
    assert str_to_bool("1")
    assert str_to_bool("Yep")
    assert str_to_bool("Y")
    assert str_to_bool("T")
    assert str_to_bool("YES")
    assert str_to_bool("TRUE")
    assert str_to_bool("ON")
    assert str_to_bool("YUP")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("False")
    assert not str_to_bool("off")
    assert not str_to_bool("0")
    assert not str_

# Generated at 2022-06-21 23:42:42.680459
# Unit test for function str_to_bool
def test_str_to_bool():
    # True
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    # False
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool

# Generated at 2022-06-21 23:42:53.618752
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:42:57.545807
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1")
    assert str_to_bool("True")
    assert str_to_bool("t")
    assert not str_to_bool("0")
    assert not str_to_bool("False")
    assert not str_to_bool("f")
    assert not str_to_bool("No")

# Generated at 2022-06-21 23:43:03.570140
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True")
    assert str_to_bool("true")
    assert str_to_bool("TrUe")
    assert str_to_bool("1")
    assert not str_to_bool("False")
    assert not str_to_bool("false")
    assert not str_to_bool("fAlSe")
    assert not str_to_bool("0")
    try:
        str_to_bool("wtf")
    except ValueError as e:
        assert str(e) == "Invalid truth value wtf"
    else:
        assert False, "Expected ValueError"



# Generated at 2022-06-21 23:43:14.138895
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    filename = "test_load_module_from_file_location.py"
    # Some random variable name and value to use in test config file
    var_name = "my_var"
    var_value = "my_value"

    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as test_config_file:
        test_config_file.file.write(f"{var_name} = '{var_value}'")
        test_config_file.file.close()

        # First, test with valid test configuration file
        test_config_module = load_module_from_file_location(
            test_config_file.name
        )
        assert getattr(test_config_module, var_name, None) == var_value

        # Delete the test config file

# Generated at 2022-06-21 23:43:17.268425
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("false") == False

# Generated at 2022-06-21 23:43:24.614206
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("Y")
    assert str_to_bool("YES")
    assert str_to_bool("yep")
    assert str_to_bool("Yep")
    assert str_to_bool("yUP")
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("TRUE")
    assert str_to_bool("on")
    assert str_to_bool("ON")
    assert str_to_bool("enable")
    assert str_to_bool("Enable")
    assert str_to_bool("Enabled")

# Generated at 2022-06-21 23:43:31.895059
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    os_environ["SOME_ENV_VAR"] = "some_env_var_value"
    assert (
        load_module_from_file_location(
            "some_module_name", "/some/path/${SOME_ENV_VAR}"
        )
        == load_module_from_file_location(
            "some_module_name", "/some/path/some_env_var_value"
        )
    )

    del os_environ["SOME_ENV_VAR"]

# Generated at 2022-06-21 23:43:44.367937
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    current_dir = Path(__file__).parent
    os_environ["path_to_module"] = str(current_dir.absolute())

    module = load_module_from_file_location(
        current_dir / "module_for_testing.py"
    )
    assert module.module_for_testing_attribute == "some value"

    module = load_module_from_file_location(
        "${path_to_module}/module_for_testing.py"
    )
    assert module.module_for_testing_attribute == "some value"

    # Try if we can load module from directory via environment variable
    assert status == "some status"

    # Try if we can load module from directory via environment variable
    # provided as bytes object
    assert status == "some status"

# Generated at 2022-06-21 23:43:55.329359
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    MODULE_LOCATION = None
    MODULE_LOCATION = Path(__file__).parent.parent / "app.py"

    module = load_module_from_file_location(MODULE_LOCATION)
    assert hasattr(module, "app") is True

    MODULE_LOCATION = None
    MODULE_LOCATION = str(Path(__file__).parent.parent / "app.py")

    module = load_module_from_file_location(MODULE_LOCATION)
    assert hasattr(module, "app") is True

    MODULE_LOCATION = None
    MODULE_LOCATION = Path(__file__).parent.parent / "app.py"

    module = load_module_from_file_location(MODULE_LOCATION)
    assert hasattr(module, "app") is True

    MODULE_LOCATION = None


# Generated at 2022-06-21 23:44:06.578792
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    passed = 0
    failed = 0
    total = 0

# Generated at 2022-06-21 23:44:15.134165
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert not str_to_bool("no")
    assert str_to_bool("y")
    assert not str_to_bool("n")
    assert str_to_bool("yes")
    assert str_to_bool("true")
    assert not str_to_bool("false")
    assert str_to_bool("on")
    assert not str_to_bool("off")
    assert str_to_bool("enable")
    assert not str_to_bool("disable")
    assert str_to_bool("enabled")
    assert not str_to_bool("disabled")
    assert str_to_bool("1")
    assert not str_to_bool("0")
    assert str_to_bool("yep")
    assert not str_to_bool("nope")

# Generated at 2022-06-21 23:44:28.584285
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    from os import pathsep
    from tempfile import TemporaryFile

    from sanic.utils import load_module_from_file_location

    with TemporaryFile("w+") as config_file:
        config_file.write("some_var = 42\n")
        config_file.seek(0)
        config_file_name = config_file.name
        module = load_module_from_file_location(config_file_name)
        assert module.some_var == 42
        sys.modules.pop(config_file_name)

    with TemporaryFile("w+") as config_file:
        config_file.write("some_var = 42\n")
        config_file.seek(0)
        config_file_name = config_file.name
        config_file_path = pathsep.join

# Generated at 2022-06-21 23:44:36.513773
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    # prepare temp dir
    tempdir = tempfile.mkdtemp()
    os.chdir(tempdir)

    # prepare and save test config file
    py_file_name = "test_py_conf.py"
    file_path = Path(tempdir) / py_file_name
    f = file_path.open("w")
    f.write(
        'test_var = "test_value"\n'
        'test_dict = {"test_key": "test_value"}'
    )
    f.close()

    # prepare non py file
    non_py_file_name = "test_non_py_conf"
    non_py_file_path = Path(tempdir) / non_py_file_name
    non_file_path = non_

# Generated at 2022-06-21 23:44:46.197008
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("ON")
    assert str_to_bool("on")
    assert str_to_bool("1")
    assert str_to_bool("Yup")
    assert str_to_bool("EnABLed")
    assert not str_to_bool("OFF")
    assert not str_to_bool("0")
    assert not str_to_bool("FAlse")
    assert not str_to_bool("DISABLED")

    try:
        str_to_bool("foo")
    except ValueError:
        pass
    else:
        assert False, "Should raise ValueError"



# Generated at 2022-06-21 23:44:56.278927
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    from contextlib import suppress

    from sanic.exceptions import LoadFileException

    # pylint: disable=unused-argument,redefined-outer-name
    def _create_mod_file(location):
        """Creates a module file with specified location.

        Returns:
            tuple: (module_instance, file_name, location)
                module_instance - Module instance which is created.
                file_name - Name of module file.
                location - Location of created module.
        """
        import tempfile

        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            location = f.name

# Generated at 2022-06-21 23:45:06.892205
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Ensure that you can load module using using
    load_module_from_file_location function.
    """
    current_dir = str(Path(__file__).parent)
    location = current_dir + "/file_for_testing.py"

    # A) Test that module can be properly imported.
    module = load_module_from_file_location(location)

    # B) Test that imported module contains the same data
    #    as it was in file for testing.
    assert module.coresponding_variable == "coresponding value"
    assert module.coresponding_variable2 == "coresponding value 2"



# Generated at 2022-06-21 23:45:21.241172
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Define some test variables
    location_variable = "some_variable"
    location_module = "some_module"
    location_file_py = "some_file.py"
    location_file_other = "some_file.other"
    some_value = "some_value"

    # Create a temporary directory and save it as module location
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
        # Create file location_file_py and write to it some content
        tmpfile_py = tmpdirname / location_file_py
        tmpfile_py.write_text(
            f"""variable = "{some_value}"
            module = "{location_module}"
            """  # noqa
        )
        # Define a variable using environment variable
        location_variable_

# Generated at 2022-06-21 23:45:31.804567
# Unit test for function str_to_bool
def test_str_to_bool():
    # Check documentation examples
    assert str_to_bool("Y")
    assert not str_to_bool("no")
    assert str_to_bool("YES") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False

# Generated at 2022-06-21 23:45:43.641592
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests load_module_from_file_location function.

    1. Tests environment variables substitution.
    2. Tests module loading without .py extension.
    """
    import_string_orig = import_string


# Generated at 2022-06-21 23:45:53.426329
# Unit test for function str_to_bool
def test_str_to_bool():
    tests = [
        [["y", "yes", "yep", "yup", "t", "true", "on", "enable", "enabled", "1"], True],
        [["n", "no", "f", "false", "off", "disable", "disabled", "0"], False],
        [["Y", "YES", "YEP", "YUP", "T", "TRUE", "ON", "ENABLE", "ENABLED", "1"], True],
        [["N", "NO", "F", "FALSE", "OFF", "DISABLE", "DISABLED", "0"], False],
        [["abcde"], ValueError],
    ]

# Generated at 2022-06-21 23:46:04.954900
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import faker
    import pytest
    import tempfile

    # A) Test if location is a string.
    location = tempfile.mkstemp(dir=Path.cwd(), suffix=".py")[1]

    with open(location, "w") as f:
        f.write("a = 1")

    module1 = load_module_from_file_location(location)
    assert module1.a == 1

    # B) Test if location is a Path.

    location = Path.cwd() / location
    module2 = load_module_from_file_location(location)
    assert module2.a == 1

    # C) Test if location is a bytes.
    location = tempfile.mkstemp(dir=Path.cwd(), suffix=".py")[1]

# Generated at 2022-06-21 23:46:10.218664
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("true") == True
    assert str_to_bool("TruE") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("On") == True
    assert str_to_bool("1") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("YUP") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("YEP") == True
    assert str_to_bool("n") == False
    assert str_to_bool

# Generated at 2022-06-21 23:46:22.340238
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location.

    Tests both for errors and for successful call.
    Errors are captured in:
    - LoadFileException
    - PyFileError
    """
    # Raise LoadFileException
    with pytest.raises(LoadFileException):
        load_module_from_file_location("/some/path/${some_env_var}")

    # Raise PyFileError
    with pytest.raises(PyFileError):
        load_module_from_file_location(
            os.path.join(os.path.dirname(__file__), "test_config_file.py")
        )
    # Successfully load module

# Generated at 2022-06-21 23:46:33.797800
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("y") == True
    assert str_to_bool("t") == True
    assert str_to_bool("1") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("YEP") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("YUP") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("on") == True
    assert str_to_bool("ENABLE") == True
    assert str_to_bool("enable") == True

    assert str_to_bool("False") == False


# Generated at 2022-06-21 23:46:43.985080
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests load_module_from_file_location function"""
    import tempfile
    import shutil

    # ------------------------------------------------------------
    # Part A) Check if function is capable of loading Python files

    # Temporarily create some Python file.
    module_name = "some_module_name"
    temp_dir = tempfile.mkdtemp()
    module_path = os.path.join(temp_dir, module_name + ".py")


# Generated at 2022-06-21 23:46:49.586080
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("Y")
    assert str_to_bool("Yes")
    assert str_to_bool("yep")
    assert str_to_bool("Yep")
    assert str_to_bool("yup")
    assert str_to_bool("Yup")
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("on")
    assert str_to_bool("On")
    assert str_to_bool("enable")
    assert str_to_bool("Enabled")
    assert str_to_bool("enabled")

# Generated at 2022-06-21 23:47:03.770021
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool(" true ")
    assert not str_to_bool(" False ")
    assert str_to_bool("0") is False
    assert str_to_bool("1") is True
    assert not str_to_bool("no")
    assert str_to_bool("YES")
    assert not str_to_bool("off")
    assert str_to_bool("on")
    assert str_to_bool("True")
    assert not str_to_bool("False")
    assert str_to_bool("yeS")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert not str_to_bool("n")
    assert str_to_bool("y")
    assert str_to_bool("on")

# Generated at 2022-06-21 23:47:14.184495
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ, pathsep

    # some_dir/${SOME_ENV_VAR}/some_file.py
    environ["SOME_ENV_VAR"] = "some_dir"

    _location = __file__
    _location = "some_dir/${SOME_ENV_VAR}/some_file.py"
    _location = "/some/path/some_file.py"
    _location = "/some_dir/some_file.py"
    _location = "/home/user/some_file.py"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    env_vars_in_location = set(re_findall(r"\${(.+?)}", _location))
   

# Generated at 2022-06-21 23:47:22.306436
# Unit test for function str_to_bool
def test_str_to_bool():
    with pytest.raises(ValueError) as e:
        str_to_bool("some invalid value")

    assert "Invalid truth value" in str(e.value)

    assert str_to_bool("Enable") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("1") is True

    assert str_to_bool("False") is False
    assert str_to_bool("off") is False
    assert str_to_bool("0") is False


# Generated at 2022-06-21 23:47:27.622400
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert isinstance(
        load_module_from_file_location(
            "sanic_openapi.utils.load_module_from_file_location"
        ),
        types.FunctionType,
    )

    assert "utils" in load_module_from_file_location(
        "/sanic_openapi/utils"  # <-- because of "initialize_by" in setup.cfg
    ).__dict__



# Generated at 2022-06-21 23:47:39.325653
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys
    import shutil
    import tempfile
    import unittest

    try:
        from importlib import reload
    except ImportError:
        try:
            from imp import reload
        except ImportError:
            pass

    import unittest

    class LoadModuleFromFileLocationTest(unittest.TestCase):
        """Class for unit testing"""

        def setUp(self):
            """Create temporary directory for tests and save current working
            directory"""
            # Create temporary directory for the tests
            tmpdir = self.tmpdir = tempfile.mkdtemp()

            # Create directory for test modules
            modules = self.modules = os.path.join(tmpdir, "modules")
            os.mkdir(modules)

            # Save current working directory
            cwd = self.cwd = os.getcwd

# Generated at 2022-06-21 23:47:50.791942
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os, pathlib

    some_module_name = "some_module_name"

    # Cleanup
    if some_module_name in sys.modules:
        del sys.modules[some_module_name]

    some_var = "some_var_value"
    test_file_contents = f"""
        some_var = "{some_var}"
    """

    with tempfile.NamedTemporaryFile("w", suffix=".py") as f:
        f.write(test_file_contents)
        f.flush()

        # Checking if we can load module from path in filesystem
        loaded_module = load_module_from_file_location(f.name)
        assert some_module_name == loaded_module.__name__
        assert some_var == loaded_module.some_var

    # Cleanup

# Generated at 2022-06-21 23:47:58.650942
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("1")
    assert not str_to_bool("false")
    assert not str_to_bool("False")
    assert not str_to_bool("0")
    assert str_to_bool("yeS")
    assert not str_to_bool("nO")
    try:
        str_to_bool("y")
    except ValueError as e:
        assert str(e) == "Invalid truth value y"
    try:
        str_to_bool("n")
    except ValueError as e:
        assert str(e) == "Invalid truth value n"

# Generated at 2022-06-21 23:48:10.613407
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("t") is True
    assert str_to_bool("0") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("off") is False
    assert str_to_bool("Y") is True
    assert str_to_bool("N") is False
    assert str_to_bool("YES") is True
    assert str_to_bool("OFF") is False
    assert str_to_bool("True") is True
    assert str_to_bool("False") is False
    assert str_to_bool("true") is True
    assert str_to_bool("false") is False
    assert str_to_bool("trUe") is True
    assert str_to_bool("fAlSe") is False

# Generated at 2022-06-21 23:48:21.095931
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("on") == True
    assert str_to_bool("1") == True
    assert str_to_bool("OFF") == False
    assert str_to_bool("0") == False
    assert str_to_bool("enabled") == True
    assert str_to_bool("disabled") == False
    assert str_to_bool("no") == False
    assert str_to_bool("yes") == True
    assert str_to_bool("true") == True
    assert str_to_bool("false") == False
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("yup") == True
    assert str_to_bool("nope") == False
    assert str_to_bool("yep") == True
   

# Generated at 2022-06-21 23:48:28.335483
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('false') == False
    assert str_to_bool('no') == False
    assert str_to_bool('n') == False
    assert str_to_bool('f') == False
    assert str_to_bool('off') == False
    assert str_to_bool('offf') == False
    assert str_to_bool('offff') == False
    assert str_to_bool('offfff') == False
    assert str_to_bool('offffff') == False
    assert str_to_bool('offfffff') == False
    assert str_to_bool('offffffff') == False
    assert str_to_bool('offfffffff') == False
    assert str_to_bool('offffffffff') == False
    assert str_to_bool('offfffffffff') == False

# Generated at 2022-06-21 23:48:48.524276
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("1")
    assert str_to_bool("true")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("0")
    assert not str_to_bool("false")
    with pytest.raises(ValueError):
        str_to_bool("abc")



# Generated at 2022-06-21 23:48:57.801065
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yip") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("1") is True
    assert str_to_bool("true") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("T") is True
    assert str_to_bool("True") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("ENABLE") is True
    assert str_to_bool("on") is True
    assert str_to_bool("ON") is True

# Generated at 2022-06-21 23:49:09.210378
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""
    import pytest
    from os import getcwd, mkdir

    from os.path import join
    from shutil import rmtree
    from tempfile import mkdtemp

    from sanic.exceptions import PyFileError

    from .test_utils import TEST_DIR

    with open(join(TEST_DIR, "test_files", "config.py"), "r") as f:
        config_string = f.read()

    tempdir_name = mkdtemp(prefix="test_load_module_from_file_location-")


# Generated at 2022-06-21 23:49:22.498917
# Unit test for function str_to_bool
def test_str_to_bool():
    # Good cases
    assert str_to_bool("true") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("y") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("1") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("false") == False
    assert str_to_bool("no") == False
    assert str_to_bool("n") == False
    assert str_to_bool("f") == False
    assert str_to_bool("0") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:49:33.506410
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Tests for load_module_from_file_location function
    """

    # Case 1:
    # Passing pathlib.Path as location
    location = Path(__file__).parent / "test_file.py"
    module = load_module_from_file_location(location)
    assert module.bar == "foo"

    # Case 2:
    # Passing path as a bytes object location
    location = Path(__file__).parent / "test_file.py"
    location = location.as_posix().encode("utf8")
    module = load_module_from_file_location(location)
    assert module.bar == "foo"

    # Case 3:
    # Passing path as a string location
    location = Path(__file__).parent / "test_file.py"

# Generated at 2022-06-21 23:49:43.390674
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test if function load_module_from_file_location works as you think it should.
    """
    import_string_not_working = False
    try:
        import_string("test_config_test_file")
    except ValueError:
        import_string_not_working = True
    assert import_string_not_working, "import_string works?"

    os_environ["TEST_VAR1"] = "test_value"
    os_environ["TEST_VAR2"] = "test_value"

    path_to_test_config = Path(__file__).parent / "test_config_test_file.py"
    test_config = load_module_from_file_location(
        path_to_test_config, encoding="ASCII"
    )

# Generated at 2022-06-21 23:49:54.889662
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa

    config_path = Path(__file__).parent / "config_for_tests.py"

    module = load_module_from_file_location(
        config_path, "utf8", *(), **{}
    )

    assert module.DEBUG_LEVEL == 8
    assert module.ENVIRONMENT == "staging"
    assert module.TEST_INTEGRATION == False
    assert module.TEST_INTEGRATION_WITH_YAML == False
    assert module.PATH_TO_ENV_FILE == "/opt/env_vars/example.env"
    assert module.SECRET_KEY == "VerySecretKey"
    assert module.PASSWORD == "mysql_pw"

# Generated at 2022-06-21 23:50:05.386386
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("t") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("1") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True

    assert str_to_bool("false") is False
    assert str_to_bool("False") is False
    assert str_to_bool("FALSE") is False


# Generated at 2022-06-21 23:50:17.355446
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Path object
    import_path = Path(__file__).parent.parent / "app.py"
    # Load module
    module = load_module_from_file_location(import_path)
    assert module.__name__ == "app"

    # Load module with some environment variable
    def _replace_env_var(location, var_name, var_value):
        return location.replace("${" + var_name + "}", var_value)

    import_path = Path(__file__).parent.parent / "app.py"
    import_path = _replace_env_var(
        str(import_path), "SOME_ENV_VAR", os_environ["SANIC_APP_MODULE"]
    )
    import_path = Path(import_path)

    # Load module