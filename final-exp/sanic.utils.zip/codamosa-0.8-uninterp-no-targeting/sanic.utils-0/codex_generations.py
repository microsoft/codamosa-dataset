

# Generated at 2022-06-21 23:40:25.094992
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("False") is False
    assert str_to_bool("0") is False
    assert str_to_bool("1") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("true") is True

# Generated at 2022-06-21 23:40:35.873170
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from .config_decorator import ConfigDecorator

    config_path = Path(__file__).parent / "tests" / "config.py"
    config = load_module_from_file_location(config_path)
    assert isinstance(config, types.ModuleType)
    assert isinstance(config.TESTING_VAR_1, ConfigDecorator)
    assert isinstance(config.TESTING_VAR_2, ConfigDecorator)
    assert isinstance(config.TESTING_VAR_3, ConfigDecorator)
    assert config.TESTING_VAR_1.get() == "testing_var_1"
    assert config.TESTING_VAR_2.get() == "testing_var_2"

# Generated at 2022-06-21 23:40:42.560873
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("False") is False

    assert str_to_bool("true") is True
    assert str_to_bool("false") is False

    assert str_to_bool("TRUE") is True
    assert str_to_bool("FALSE") is False

    assert str_to_bool("y") is True
    assert str_to_bool("n") is False

    assert str_to_bool("Y") is True
    assert str_to_bool("N") is False

    assert str_to_bool("Yes") is True
    assert str_to_bool("No") is False

    assert str_to_bool("YES") is True
    assert str_to_bool("NO") is False

    assert str_to_bool("yEp") is True
   

# Generated at 2022-06-21 23:40:53.499676
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from tempfile import NamedTemporaryFile
    from os import remove
    moduleName = "my_module"
    content = (
        "class MyClass:\n"
        "    pass\n"
        'if __name__ == "__main__":\n'
        "    m = MyClass()"
    )
    path = f"/tmp/{moduleName}.py"

    # UNIT 1:
    # Check if module can be loaded from path
    # given as string.
    with open(path, "w") as f:
        f.write(content)

    module = load_module_from_file_location(path)
    class_ = getattr(module, "MyClass")

    try:
        assert issubclass(class_, object)
    except AssertionError:
        py

# Generated at 2022-06-21 23:41:04.893357
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Check that it is working for strings
    test_string = "test_string"
    test_string_module = load_module_from_file_location(
        test_string, encoding="utf8"
    )
    assert test_string == test_string_module.__name__

    # Check that it is working for bytes
    test_byte = b"test_byte"
    test_byte_module = load_module_from_file_location(test_byte, encoding="utf8")
    assert test_byte.decode("utf8") == test_byte_module.__name__

    # Check that it is working for pathlib.Path
    test_path = Path().absolute() / "test_path"
    test_path_module = load_module_from_file_location(test_path, encoding="utf8")

# Generated at 2022-06-21 23:41:16.034660
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function."""
    # A) Test ${some_env_var} resolution.
    try:
        module = load_module_from_file_location(
            "/test/test.py", "${some_env_var}"
        )
    except LoadFileException as e:
        assert "The following environment variables are not set: some_env_var" in str(
            e
        )
    else:
        assert False
    os_environ["some_env_var"] = "test"

# Generated at 2022-06-21 23:41:23.586036
# Unit test for function str_to_bool
def test_str_to_bool():
    from random import choice
    from string import ascii_lowercase

    for letter in ascii_lowercase:
        if letter in ("y", "n"):
            continue
        random_str = choice(ascii_lowercase) + letter
        with pytest.raises(ValueError):
            str_to_bool(random_str)


# Generated at 2022-06-21 23:41:27.786954
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('y')
    assert str_to_bool('yes')
    assert str_to_bool('true')
    assert not str_to_bool('n')
    assert not str_to_bool('NO')
    assert not str_to_bool('False')
    try:
        str_to_bool('wrong input')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-21 23:41:40.425176
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["some_env_var"] = "some_value"

    mod = load_module_from_file_location(
        "sanic.helpers.test_helper_config",
        __file__.replace("test_helper.py", "test_helper_config.py"),
    )

    assert mod.some_value == "some_value"

    mod = load_module_from_file_location(
        Path(__file__.replace("test_helper.py", "test_helper_config.py"))
    )

    assert mod.some_value == "some_value"

    mod = load_module_from_file_location("/")

    assert mod.__name__ == "config"

    mod = load_module_from_file_location("")

    assert mod.__name__

# Generated at 2022-06-21 23:41:50.550108
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:41:57.609821
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("on")
    assert str_to_bool("true")
    assert not str_to_bool("off")
    assert not str_to_bool("no")
    assert not str_to_bool("false")

# Generated at 2022-06-21 23:42:02.829052
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("0") == False

# Generated at 2022-06-21 23:42:09.839964
# Unit test for function str_to_bool

# Generated at 2022-06-21 23:42:20.197823
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("on") is True
    assert str_to_bool("off") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("yep") is True
    assert str_to_bool("nope") is False
    assert str_to_bool("t") is True
    assert str_to_bool("f") is False
    assert str_to_bool("true") is True
    assert str_to_bool("false") is False
    assert str_to_bool("enable") is True

# Generated at 2022-06-21 23:42:31.855098
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    from shutil import rmtree

    from assertpy import assert_that

    from sanic.utils import load_module_from_file_location

    # A test configuration file
    test_config_file_content = """\
    SOME_ENV = "SOME_ENV"
    SOME_OTHER_ENV = "SOME_OTHER_ENV"
    SOME_STRING = "SOME_STRING"
    SOME_DICT = {"SOME_KEY": "SOME_VALUE"}
    """

    # Test load configuration from file.
    # Test file not found.

# Generated at 2022-06-21 23:42:42.721699
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import importlib.util as util
    import types
    import tempfile

    assert util
    assert types
    assert tempfile

    # Test if we can import module from a file
    with tempfile.TemporaryDirectory() as tmpdirname:
        name_of_file = "some_module.py"
        module_name = name_of_file.split(".")[0]

        with open(f"{tmpdirname}/{name_of_file}", "w") as f:
            f.write("x = 5")

        module = load_module_from_file_location(f"{tmpdirname}/{name_of_file}")

        assert module.__name__ == module_name
        assert module.__file__.startswith(str(tmpdirname))
        assert module.x == 5

        #

# Generated at 2022-06-21 23:42:53.619929
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    #
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    #
    #
    # Check if from this location something will be loaded
    #
    # If without valid path then should raise IOError.
    with pytest.raises(
        IOError,
        match="Unable to load configuration /nonexistent_path/some_module_name.py",
    ):
        load_module_from_file_location(
            "/nonexistent_path/some_module_name.py"
        )

    # If without valid path then should raise IOError.

# Generated at 2022-06-21 23:43:03.236524
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from .test import helpers
    import sys
    import os

    temp_config_path = Path(helpers.HERE, "temp_config.py")
    temp_config_path.touch()

    # Test for both str and Path for location parameter.
    for location in [str(temp_config_path), temp_config_path]:
        sys.modules.pop("temp_config", None)

        loaded_module = load_module_from_file_location(location)

        assert loaded_module.__name__ == "config"
        assert loaded_module.__file__ == str(location)

        assert "temp_config" in sys.modules
        assert sys.modules["temp_config"].__name__ == "config"
        assert sys.modules["temp_config"].__file__ == str(location)

    os

# Generated at 2022-06-21 23:43:13.988656
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # The following test assumes that name of this file is utils.py
    # and that this file is in the same directory as file
    # test_load_module_from_file_location.py

    import sanic
    from .utils import str_to_bool, load_module_from_file_location

    print(sanic.__file__)
    print(Path(__file__).parent / "test_load_module_from_file_location.py")
    print(Path(__file__).parent / "../test_load_module_from_file_location.py")
    print(Path(__file__).parent / "../../test_load_module_from_file_location.py")
    print(Path(__file__).parent / "../../../test_load_module_from_file_location.py")
   

# Generated at 2022-06-21 23:43:23.376105
# Unit test for function str_to_bool
def test_str_to_bool():  # pragma: no cover
    assert str_to_bool("y") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("YeP") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("YES") is True

    assert str_to_bool("yup") is True
    assert str_to_bool("YUp") is True
    assert str_to_bool("yUP") is True
    assert str_to_bool("YUP") is True

    assert str_to_bool("t") is True
    assert str_to_bool("T") is True

    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("TRUE") is True

    assert str_

# Generated at 2022-06-21 23:43:32.791335
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Some tests below requires environment variables
    # to be set.
    os_environ["some_env_var"] = "some_value"

    # Assert that location of type bytes
    # is correct loaded
    assert load_module_from_file_location(
        b"tests.test_helpers.test_load_module_from_file_location", "utf8"
    )

    # Assert that location of type string
    # is correct loaded
    assert load_module_from_file_location(
        "tests.test_helpers.test_load_module_from_file_location"
    )

    # Assert that location of type Path
    # is correct loaded
    assert load_module_from_file_location(
        Path(__file__)
    )

    # Assert that a location of type string


# Generated at 2022-06-21 23:43:40.578158
# Unit test for function str_to_bool
def test_str_to_bool():
    # TODO: Add more tests
    assert str_to_bool("0") == False
    assert str_to_bool("1") == True
    assert str_to_bool("No") == False
    assert str_to_bool("YeS") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("on")
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:43:54.205810
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import pytest

    fd, modname_path = tempfile.mkstemp(suffix=".py")
    with os.fdopen(fd, "w") as modname_file:
        modname_file.write(
            "print('executing module')\nname = 'modname'\n"
        )
    modname_file.close()
    modname_path = os.path.abspath(modname_path)
    module = load_module_from_file_location(modname_path)
    os.unlink(modname_path)
    assert module.name == "modname"


# Generated at 2022-06-21 23:44:06.206177
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Check exception is raised if environment variable is not defined.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("/some/path/${non_existing_env_var}")

    # Check that environment variables are substituted.
    # Also check that existing environment variables are not affected.
    x = "some_value"
    os_environ["x"] = x
    os_environ["y"] = x
    os_environ["z"] = x
    os_environ["xx"] = x
    os_environ["yy"] = x
    os_environ["zz"] = x

# Generated at 2022-06-21 23:44:09.277725
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("./sanic/test_utils.py").__file__ == "./sanic/test_utils.py"

# Generated at 2022-06-21 23:44:14.944223
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("false") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False

# Generated at 2022-06-21 23:44:28.386626
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("false")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-21 23:44:36.107231
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool(b"yes") == True
    assert str_to_bool("y") == True
    assert str_to_bool(b"y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool(b"Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool(b"YES") == True
    assert str_to_bool("yes") == True
    assert str_to_bool(b"yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool(b"yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool(b"yup") == True

# Generated at 2022-06-21 23:44:44.340426
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("f") == False
    assert str_to_bool("off") == False
    assert str_to_bool("off") == False
    with pytest.raises(ValueError):
        str_to_bool("unsupported")



# Generated at 2022-06-21 23:44:55.440707
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def test_assert(location, expected):
        module = load_module_from_file_location(location)
        if isinstance(expected, Exception):
            with pytest.raises(expected):
                module = load_module_from_file_location(location)
        else:
            assert module.TEST == expected

    # A) Not existing file
    with pytest.raises(IOError):
        test_assert("/etc/some_not_existing_file_on_path", "")

    # B) Not existing file with environment variable
    os_environ["some_env_var"] = "some_not_existing_file_on_path"
    with pytest.raises(IOError):
        test_assert(
            Path("/etc") / "${some_env_var}", ""
        )  # type

# Generated at 2022-06-21 23:45:10.140510
# Unit test for function str_to_bool
def test_str_to_bool():
    import pytest

    # Some examples
    assert str_to_bool("True") is True
    assert str_to_bool("true") is True

    assert str_to_bool("False") is False
    assert str_to_bool("false") is False

    assert str_to_bool("1") is True
    assert str_to_bool("0") is False

    assert str_to_bool("-1") is True
    assert str_to_bool("-0") is False

    assert str_to_bool("Yes") is True
    assert str_to_bool("Y") is True

    assert str_to_bool("No") is False
    assert str_to_bool("n") is False

    assert str_to_bool("on") is True
    assert str_to_bool("off") is False

    assert str_to

# Generated at 2022-06-21 23:45:21.413739
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["some_env_var"] = "some_env_var_value"
    module = load_module_from_file_location(
        "tests/fixtures/config/test_reload.py",
        "/${some_env_var}/config/test_${some_env_var}.py",
    )

    assert hasattr(module, "TEST")
    assert module.TEST == 1

    module = load_module_from_file_location(
        "tests/fixtures/config/test_reload.py",
        Path("tests") / "fixtures" / "config" / "test_reload.py",
    )

    assert hasattr(module, "TEST")
    assert module.TEST == 1

# Generated at 2022-06-21 23:45:31.875176
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # A) Test when location is a string.
    # A.1) Test with a real file.
    assert load_module_from_file_location(
        "tests/conftest.py"
    ).TEST_VARIABLE_FROM_FILE == "Test variable from file"
    # A.2) Test with environment variable in location.
    config_file = Path(__file__).parent.parent / "config.py"
    os_environ["SANIC_CONFIG_FILE"] = str(config_file)
    assert load_module_from_file_location(
        "/whatever/${SANIC_CONFIG_FILE}"
    ).TEST_VARIABLE_FROM_FILE == "Test variable from file"
    # A.3) Check if function raises LoadFileException if environment variable
   

# Generated at 2022-06-21 23:45:43.633719
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("True") == True
    assert str_to_bool("On") == True
    assert str_to_bool("1") == True
    assert str_to_bool("F") == False
    assert str_to_bool("f") == False
    assert str_to_bool("yep") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("off") == False
    assert str_to_bool("OFF") == False
    assert str_to_bool("0") == False
   

# Generated at 2022-06-21 23:45:53.424737
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import json

    conf_path = tempfile.TemporaryDirectory().name

# Generated at 2022-06-21 23:45:57.721417
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") == True
    assert str_to_bool("FALSE") == False
    assert str_to_bool("0") == False
    assert str_to_bool("1") == True
    assert str_to_bool("NO") == False

# Generated at 2022-06-21 23:46:09.651050
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    test_dir = Path(__file__).parent / "test_dir"
    config_dir = test_dir / "config_dir"
    config_file = config_dir / "sanic_env.py"

    os_environ["SOME_ENV_VAR"] = str(config_dir)
    os_environ["OTHER_ENV_VAR"] = "OTHER_ENV_VAR_VALUE"

    # test with file path
    module = load_module_from_file_location(config_file)
    assert module.TEST_KEY == "TEST_VALUE"

    # teat with environment variables in file path
    module = load_module_from_file_location(
        f"{config_dir}/${OTHER_ENV_VAR}/sanic_env.py"
    )
   

# Generated at 2022-06-21 23:46:21.634427
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yeS")
    assert str_to_bool("1")
    assert str_to_bool("T")
    assert str_to_bool("YEP")
    assert str_to_bool("yup")
    assert str_to_bool("on")
    # Also, it's not a bug, it's a feature:
    assert not str_to_bool("OFF")

    assert not str_to_bool("No")
    assert not str_to_bool("N")
    assert not str_to_bool("False")
    assert not str_to_bool("0")
    assert not str_to_bool("n")
    assert not str_to_bool("f")


# Generated at 2022-06-21 23:46:25.346394
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("ON") is True
    assert str_to_bool("OFF") is False



# Generated at 2022-06-21 23:46:36.854788
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import os

    os_environ["TEST_ENV_VAR_ENV_VAR"] = "TEST_ENV_VAR_ENV_VAR_VALUE"
    sys.path = sys.path + ["/usr/bin/python3"]

    # A) location is a string
    mod = load_module_from_file_location(
        "os",
        "/usr/lib/python3.6/os.py"
    )
    assert mod is os

    # B) location is a string with environment variables in format ${SOME_ENV_VAR}

# Generated at 2022-06-21 23:46:47.692519
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("YeS") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("YEP") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
   

# Generated at 2022-06-21 23:46:57.942192
# Unit test for function str_to_bool
def test_str_to_bool():
    tests = [
        ("y", True),
        ("yes", True),
        ("yep", True),
        ("yup", True),
        ("t", True),
        ("true", True),
        ("1", True),
        ("on", True),
        ("enable", True),
        ("enabled", True),
        ("n", False),
        ("no", False),
        ("f", False),
        ("false", False),
        ("0", False),
        ("off", False),
        ("disable", False),
        ("disabled", False),
    ]
    for test_case in tests:
        val = test_case[0]
        expected = test_case[1]
        assert str_to_bool(val) == expected, f"{val} != {expected}"

# Generated at 2022-06-21 23:47:10.455479
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["some_env_var"] = "some_env_var_value"
    os_environ["another_env_var"] = "another_env_var_value"

    for location in ["some_module_name", "/some/path/${some_env_var}"]:
        assert (
            load_module_from_file_location(location)
        )  # check that it will not raise any exception
    assert (
        load_module_from_file_location("/some/path/${qwerty}")
    )  # check that it will not raise any exception


# Generated at 2022-06-21 23:47:16.355088
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    here = Path(__file__).parent.resolve()
    tests_dir = here.joinpath("tests").resolve()
    # Remember to update this path to match your tests
    test_module_file = tests_dir.joinpath("test_module.py").resolve()
    test_module_name = "test_module"

    assert (
        load_module_from_file_location(test_module_file).test == "test"
    ), "Unable to load module by the file"
    assert (
        load_module_from_file_location(test_module_name).test == "test"
    ), "Unable to load module by the module name"

# Generated at 2022-06-21 23:47:26.842145
# Unit test for function str_to_bool

# Generated at 2022-06-21 23:47:38.561313
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import shutil
    from os.path import exists, isfile, isdir
    from tempfile import mkdtemp

    # D) Create a temporary directory with file for testing.
    os.environ["TEST_ENV_VAR"] = mkdtemp()
    with open(os.environ["TEST_ENV_VAR"] + "/some_file.py", "w") as f:
        f.write("testing = True")

    # E) Perform tests.
    result = load_module_from_file_location(os.environ["TEST_ENV_VAR"])
    assert result == os.environ["TEST_ENV_VAR"]


# Generated at 2022-06-21 23:47:50.441333
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location(): # noqa
    def _do_assertions(some_module):
        assert hasattr(some_module, "LOAD_FROM_FILE_LOCATION_INT_VAL")
        assert some_module.LOAD_FROM_FILE_LOCATION_INT_VAL == 1
        assert hasattr(some_module, "LOAD_FROM_FILE_LOCATION_STR_VAL")
        assert some_module.LOAD_FROM_FILE_LOCATION_STR_VAL == "str_val"
        assert hasattr(some_module, "LOAD_FROM_FILE_LOCATION_NESTED")
        assert hasattr(
            some_module.LOAD_FROM_FILE_LOCATION_NESTED, "NESTED_STR_VAL"
        )

# Generated at 2022-06-21 23:47:55.902413
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["test_env_var"] = "/test/path"

    module = load_module_from_file_location(
        "test_module", "/test/path/${test_env_var}"
    )

    assert module.CONFIG_VARIABLE == "Test value"

    del os_environ["test_env_var"]

# Generated at 2022-06-21 23:48:09.270612
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    file_path = Path(tempfile.mkdtemp()) / "test_module.py"
    with open(file_path, "w") as fd:
        fd.write("some_value = 1\n")

    module = load_module_from_file_location(str(file_path))
    assert module.some_value == 1

    # Test that you can use environment variables in location.
    env_var_name = "__TEST_ENV_VAR_NAME__"
    env_var_value = "some_value"

    file_path = Path(tempfile.mkdtemp()) / f"module_${env_var_name}.py"

# Generated at 2022-06-21 23:48:20.304558
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from os import environ as os_environ
    from os import mkdir
    from os import rmdir
    from os import remove
    from os.path import isdir
    from os.path import isfile

    from tempfile import mkdtemp

    from sanic import helpers

    # Set test environment
    config_file_content = """\
        SOME_VAR = "some_value"
        SOME_OTHER_VAR = "some_other_value"
    """

    # A) Create temporary dir
    tmp_dir = mkdtemp()

    # B) Create temporary file
    config_path = tmp_dir + "/config.py"
    config_file = open(config_path, "w+")
    config_file.write(config_file_content)
    config_file.close()

    #

# Generated at 2022-06-21 23:48:29.332772
# Unit test for function str_to_bool
def test_str_to_bool():
    # True
    assert str_to_bool("1") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    # False
    assert str_to_bool("no") is False
    assert str_to_bool("0") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    # Error
    with pytest.raises(ValueError):
        str_to_bool("random")

# Generated at 2022-06-21 23:48:39.755974
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test if load_module_from_file_location can load module from
    # a string location.
    module_1 = load_module_from_file_location("sanic.helpers")

    # Test if load_module_from_file_location can load module from
    # a bytes location.
    module_2 = load_module_from_file_location(b"sanic.helpers")

    # Test if load_module_from_file_location can load module from
    # a pathlib.Path location.
    module_3 = load_module_from_file_location(Path("sanic.helpers"))

    assert module_1 == module_2 == module_3
    # Test if load_module_from_file_location can load module from
    # a string location containing a environment variable.
    module_4 = load_module

# Generated at 2022-06-21 23:48:49.382530
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test if load_module_from_file_location returns a module,
    which has a 'TEST_VAL' attribute in it"""
    os_environ["TEST_ENV_VAR"] = "__test_dir__"

    test_module = load_module_from_file_location(
        f"${TEST_ENV_VAR}/py_test_config.py"
    )
    assert test_module.TEST_VAL == "test_val"

    test_module = load_module_from_file_location(
        Path("/__test_dir__") / "py_test_config.py"
    )
    assert test_module.TEST_VAL == "test_val"


# Generated at 2022-06-21 23:48:58.238134
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(
        "tests.test_utils.test_load_module_from_file_location"
    )

    assert load_module_from_file_location(
        location="tests.test_utils.test_load_module_from_file_location"
    )

    assert load_module_from_file_location(
        location=Path(__file__).parent / "test_load_module_from_file_location.py"
    )

    assert load_module_from_file_location(
        location=Path(__file__).parent
        / "test_load_module_from_file_location.pyc"
    )


# Generated at 2022-06-21 23:49:09.353111
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Should pass
    assert load_module_from_file_location("os") is os
    assert load_module_from_file_location(os) is os
    assert (
        load_module_from_file_location(Path(__file__))
        == load_module_from_file_location(Path(__file__).as_posix())
    )
    # Shouldn't pass
    try:
        load_module_from_file_location(__file__)
        assert False
    except ValueError:
        assert True
    try:
        load_module_from_file_location("file_that_does_not_exist")
        assert False
    except FileNotFoundError:
        assert True

# Generated at 2022-06-21 23:49:22.564072
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """It test if:
    - Works properly with string.
    - Works properly with bytes (with and without encoding).
    - Works properly with Path.
    - Works properly with environment variables in location.
    - Raises errors if:
      - Location is incorrect.
      - Location contains environment variables that are not set.
    """
    from os import environ, makedirs, path as os_path
    from shutil import rmtree
    from tempfile import gettempdir

    temp_dir = gettempdir()

# Generated at 2022-06-21 23:49:32.879832
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    location = "/some/path/${some_env_var}/some_module_name.py"
    os_environ["some_env_var"] = "some_env_var"

    try:
        some_module = load_module_from_file_location(location)
    except LoadFileException:
        assert False

    with open(location, "r") as some_module_file:
        data = some_module_file.read()

    assert some_module.__file__ == location
    assert some_module.__doc__ == data

    del os_environ["some_env_var"]
    some_module_file.close()


# Generated at 2022-06-21 23:49:36.272277
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location(123)
        assert False
    except AssertionError:
        raise
    except:
        assert True



# Generated at 2022-06-21 23:49:49.643592
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Set up some environment variables.
    os_environ["SOME_VAR"] = "some path"

    # Test some file names:
    # A) If file name contains environment variables.
    module_1 = load_module_from_file_location("${SOME_VAR}/some_module.py")
    assert module_1.__name__ == "some_module"

    # B) If file name does not contain environment variables.
    module_2 = load_module_from_file_location("some_module.py")
    assert module_2.__name__ == "some_module"
    assert module_2.__file__ == "some_module.py"

    # C) If file name contains environment variables, but these variables
    #    are not set.

# Generated at 2022-06-21 23:50:01.678643
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:50:18.106414
# Unit test for function str_to_bool
def test_str_to_bool():
    assert(str_to_bool("1") is True) == True
    assert(str_to_bool("yes") is True) == True
    assert(str_to_bool("t") is True) == True
    assert(str_to_bool("true") is True) == True
    assert(str_to_bool("on") is True) == True
    assert(str_to_bool("enable") is True) == True
    assert(str_to_bool("enabled") is True) == True
    assert(str_to_bool("0") is False) == True
    assert(str_to_bool("no") is False) == True
    assert(str_to_bool("f") is False) == True
    assert(str_to_bool("false") is False) == True