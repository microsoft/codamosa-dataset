

# Generated at 2022-06-21 23:40:23.830692
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 1.
    # This tests checks if environment variables in path are resolved.
    #
    # A) Create temporary environment variable.
    config_path = Path(__file__).parent / "config.py"
    os_environ["test_env_var"] = str(config_path.parent)

    # B) Check if load_module_from_file_location raises error
    #    if this environment variable not defined.
    os_environ.pop("test_env_var", None)
    try:
        load_module_from_file_location(
            f"${test_env_var}/config.py"
        )
    except LoadFileException:
        pass
    else:
        raise Exception("Test 1. failed")

    # C) Check if load_module_from_file_location works properly
    #

# Generated at 2022-06-21 23:40:28.728198
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:40:43.490697
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Django style.
    res = load_module_from_file_location("sanic.config.settings.base")
    assert res

    # File path with .py extension
    res = load_module_from_file_location("./tests/config/settings")
    assert res

    # File path without .py extension.
    res = load_module_from_file_location("./tests/config/settings.py")
    assert res

    # Support for environment variables in file path.
    os_environ["CONFIG_PATH"] = "/some/path"
    res = load_module_from_file_location(
        "./${CONFIG_PATH}/settings"
    )  # noqa
    assert res


# Import a module or fetch an attribute. Used primarily as a callable
# `from_string

# Generated at 2022-06-21 23:40:51.517484
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    # Test positive cases.
    assert str_to_bool("YES")
    assert str_to_bool("yes")
    assert str_to_bool("on")
    assert str_to_bool("True")
    assert str_to_bool("1")
    assert str_to_bool("y")
    # Test negative cases.
    assert str_to_bool("No") is False
    assert str_to_bool("False") is False
    assert str_to_bool("0") is False

# Generated at 2022-06-21 23:41:04.498918
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-21 23:41:15.841666
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("YES")
    assert str_to_bool("Yes")
    assert str_to_bool("yep")
    assert str_to_bool("YEP")
    assert str_to_bool("Yep")
    assert str_to_bool("yup")
    assert str_to_bool("YUP")
    assert str_to_bool("Yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("no")
    assert not str_to_bool("NO")
    assert not str_

# Generated at 2022-06-21 23:41:24.839392
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def test_location_with(location):
        loaded_module = load_module_from_file_location(location)
        assert loaded_module.test_val == "test_val"
        assert loaded_module.test_val2 == "test_val2"

    test_location_with("tests/test_configs/config1.py")
    test_location_with("tests/test_configs/config2.yaml")
    test_location_with("tests/test_configs/config3.json")

# Generated at 2022-06-21 23:41:37.632593
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Set the testing variables in environment
    os_environ["TEST_ENV_VAR"] = "test_value"
    os_environ[
        "TEST_ENV_VAR_TO_BE_DROPPED"
    ] = "test_value_to_be_dropped"


# Generated at 2022-06-21 23:41:41.501730
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("Y")

    assert not str_to_bool("n")
    assert not str_to_bool("N")

# Generated at 2022-06-21 23:41:50.980584
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("True") == True
    assert str_to_bool("t") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("ohh yeah") == True
    assert str_to_bool("1") == True
    assert str_to_bool("tr") == True

    assert str_to_bool("f") == False
    assert str_to_bool("none") == False
    assert str_to_bool("nope") == False
    assert str_to_bool("no") == False

# Generated at 2022-06-21 23:42:02.335581
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile
    import os
    import sys

    # Test variable
    import_str = "import sys\nvar = 42"

    # Create temporary file with variable inside
    with tempfile.NamedTemporaryFile() as f:
        f.write(import_str.encode())
        f.flush()

        # Test if variable is imported
        sys.path.append(os.path.dirname(f.name))
        module = load_module_from_file_location(f.name)
        assert module.var == 42

        # Test if variable is imported with env var
        os.environ["path"] = os.path.dirname(f.name)

# Generated at 2022-06-21 23:42:12.340382
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as tmp_path:
        tmp_path = Path(tmp_path)

        # 1) with string file path
        with (tmp_path / "file_to_load.py").open("w") as tmp_file:
            tmp_file.write("x = 5")

        module = load_module_from_file_location(tmp_path / "file_to_load.py")
        assert module.x == 5

        # 2) with Path file path
        module = load_module_from_file_location(tmp_path / "file_to_load.py")
        assert module.x == 5

        # 3) raises on non-existing path

# Generated at 2022-06-21 23:42:20.941065
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    from types import ModuleType

    file_path = Path(__file__).parent.parent / "config.py"
    loaded_module = load_module_from_file_location(file_path)
    assert isinstance(loaded_module, ModuleType)

    file_path_with_env_var = (
        Path(__file__).parent.parent / "${FILE_PATH_WITH_ENV_VAR}/config.py"
    )
    os_environ["FILE_PATH_WITH_ENV_VAR"] = str(Path(__file__).parent.parent)
    loaded_module = load_module_from_file_location(file_path_with_env_var)
    assert isinstance(loaded_module, ModuleType)

# Generated at 2022-06-21 23:42:31.928259
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.

    #   A.1 Test existing variable
    os_environ["name"] = "foo"
    assert load_module_from_file_location("/foo/${name}").__file__ == "/foo/foo"

    #   A.2 Test non-existing variable
    try:
        load_module_from_file_location("/foo/${name}")
    except LoadFileException:
        pass
    else:
        raise AssertionError("Should raise LoadFileException")

    # B) Check if passed as a bytes then it should be decoded as expected.

    #   B.1 Bytes

# Generated at 2022-06-21 23:42:42.864334
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Location with abs path
    location_with_abs_path = "tests/examples/config.py"
    module_with_abs_path = load_module_from_file_location(
        location_with_abs_path
    )
    assert module_with_abs_path.FOO == "bar"

    # Location with env var.
    location_with_env_var = "${PWD}/tests/examples/config.py"
    module_with_env_var = load_module_from_file_location(
        location_with_env_var
    )
    assert module_with_env_var.FOO == "bar"

    # Location with env var and bytes.

# Generated at 2022-06-21 23:42:53.715551
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Tests for function load_module_from_file_location."""

    def raise_err(err):
        raise err

    # Test load from env variables.
    test_env = os_environ.copy()
    test_env["TEST_ENV"] = "test_env"
    test_env["TEST_ENV_2"] = "test_env_2"

    # A Test for loading from path with environment variables
    # in format ${some_env_var}.
    module = load_module_from_file_location(
        "/tmp/${TEST_ENV}/${TEST_ENV_2}", "/tmp/test_env/test_env_2"
    )
    assert module.__file__ == "/tmp/test_env/test_env_2"

    # B

# Generated at 2022-06-21 23:43:03.252306
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("f") == False
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:43:13.988520
# Unit test for function str_to_bool
def test_str_to_bool():

    # Check that the function works without raising error.
    # Unless ValueError is raised from str_to_bool.
    for val in (
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0"
    ):
        assert str_to_bool(val) in (True, False)

    # Check that an error is raised.
    for val in ("xyz", "no, thanks", "yes"):
        with pytest.raises(ValueError):
            str_to_bool(val)

# Generated at 2022-06-21 23:43:22.492830
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("trUe")
    assert not str_to_bool("false")
    assert not str_to_bool("False")
    assert str_to_bool("1")
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert not str_to_bool("0")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    with pytest.raises(ValueError):
        str_to_bool("a")
        str_to_bool("abc")
        str_to_bool("a1")

# Generated at 2022-06-21 23:43:34.449309
# Unit test for function str_to_bool
def test_str_to_bool():
    # "y"
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("yes") == True
    # "yes"
    assert str_to_bool("yes") == True
    assert str_to_bool("YeS") == True
    assert str_to_bool("YEs") == True
    assert str_to_bool("yES") == True
    assert str_to_bool("yes") == True
    # "yep"
    assert str_to_bool("yep") == True
    assert str_to_bool("YEP") == True
    assert str_to_bool("yEp") == True
    assert str_to

# Generated at 2022-06-21 23:43:46.881958
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from unittest.mock import patch

    # Testing with pre defined environment variable substitution
    some_env_var = "some_var"
    some_env_var_value = "some_val"
    os_environ[some_env_var] = some_env_var_value
    location = (
        f"/some/path/{some_env_var}/"
        f"/subpath/${{{some_env_var}}}/"
        f"/subsubpath/{some_env_var_value}/some.py"
    )

    with patch("sanic.exceptions.LoadFileException.__init__") as load_file_exc:
        load_module_from_file_location(location)
        # Check that LoadFileException was not raised
       

# Generated at 2022-06-21 23:43:57.046551
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("1") is True
    assert str_to_bool("On") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True

    assert str_to_bool("false") is False
    assert str_to_bool("False") is False
    assert str_to_bool("0") is False
    assert str_to_bool("off") is False
    assert str_to_bool("no") is False
    assert str_to_bool("n") is False

# Generated at 2022-06-21 23:44:03.047284
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SANIC_EXAMPLE_VARIABLE"] = "example_value"
    location = "/some/path/${SANIC_EXAMPLE_VARIABLE}/config.py"
    module = load_module_from_file_location(location)
    assert module.EXAMPLE_SETTINGS == "example_value"

# Generated at 2022-06-21 23:44:14.071913
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") is True
    assert str_to_bool("yeS") is True
    assert str_to_bool("off") is False
    assert str_to_bool("no") is False
    assert str_to_bool("true") is True
    assert str_to_bool("false") is False
    assert str_to_bool("0") is False
    assert str_to_bool("y") is True
    assert str_to_bool("f") is False
    assert str_to_bool("OFF") is False
    assert str_to_bool("YES") is True
    assert str_to_bool("off") is False
    assert str_to_bool("No") is False
    assert str_to_bool("True") is True
    assert str_to_bool("False") is False
    assert str

# Generated at 2022-06-21 23:44:27.767069
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("1") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yEs") is True
    assert str_to_bool("YE") is True
    assert str_to_bool("YEs") is True
    assert str_to_bool("niCE") is True
    assert str_to_bool("TRUe") is True

    assert str_to_bool("no") is False
    assert str_to_bool("Disable") is False
    assert str_to_bool("0") is False
    assert str_to_bool("N") is False

# Generated at 2022-06-21 23:44:35.804280
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from .test_utils import get_test_file_path

    # Create an example module.
    example_module = """
    import os

    TEST_ENV_VAR = os.environ['TEST_ENV_VAR']
    """
    some_module_name = "some_module_name"
    tmp_module_path = get_test_file_path(some_module_name)
    with open(tmp_module_path, "w+") as tmp_module:
        tmp_module.write(example_module)

    loaded_module = load_module_from_file_location(tmp_module_path)
    assert loaded_module.TEST_ENV_VAR == "test_value"


# Generated at 2022-06-21 23:44:47.539566
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") == True
    assert str_to_bool("true") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("1") == True
    assert str_to_bool("on") == True
    assert str_to_bool("On") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("False") == False
    assert str_to_bool("false") == False
    assert str_to_bool("FALSE") == False

# Generated at 2022-06-21 23:44:57.703535
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("Yes")
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("yep")
    assert str_to_bool("Yep")
    assert str_to_bool("yup")
    assert str_to_bool("Yup")
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("on")
    assert str_to_bool("On")
    assert str_to_bool("enable")
    assert str_to_bool("Enable")
    assert str_to_bool("enabled")

# Generated at 2022-06-21 23:45:04.237843
# Unit test for function str_to_bool
def test_str_to_bool():
    for c in ("y", "yes", "yep", "yup", "t", "true", "on", "enable", "enabled", "1"):
        assert str_to_bool(c) == True
    for c in ("n", "no", "f", "false", "off", "disable", "disabled", "0"):
        assert str_to_bool(c) == False


# Generated at 2022-06-21 23:45:11.588610
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """ Tests function load_module_from_file_location """

    os_environ["PATH_TO_TEST_CONFIG"] = "/some/path"
    os_environ["NAME_OF_TEST_CONFIG"] = "config"

    module = load_module_from_file_location(
        "/some/path/${PATH_TO_TEST_CONFIG}/${NAME_OF_TEST_CONFIG}.py"
    )

    assert hasattr(module, "MY_SECRET_KEY")
    assert hasattr(module, "MY_USER")


# Generated at 2022-06-21 23:45:30.300034
# Unit test for function load_module_from_file_location

# Generated at 2022-06-21 23:45:42.720771
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    class Mod:
        pass

    Mod.__file__ = "location"
    Mod.name = "name"

    # Check bytes input
    assert load_module_from_file_location(b"location") == Mod

    # Check too long input
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            os_environ["PATH"][:-20] + b"name.py"
        )

    # Check input containing not defined environment variable
    with pytest.raises(LoadFileException):
        load_module_from_file_location(os_environ["PATH"] + b"${name}")

    # Check input containing defined environment variable

# Generated at 2022-06-21 23:45:52.754335
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os
    import tempfile
    import unittest

    class TestLoadModuleFromFileLocationCase(unittest.TestCase):

        def setUp(self):
            self.config_name = "test_config"
            self.config_location = tempfile.gettempdir()
            self.config_str = f"""
                OPTION = 'value'
                ANOTHER_OPTION = True
            """

            with open(f"{self.config_location}/{self.config_name}.py", "w") as config_file:
                config_file.write(self.config_str)

        def tearDown(self):
            os.remove(f"{self.config_location}/{self.config_name}.py")

        def test_load_from_file(self):
            config = load

# Generated at 2022-06-21 23:46:04.144625
# Unit test for function str_to_bool
def test_str_to_bool():
    """Tests str_to_bool function."""
    def _assert_str_to_bool(input: str, output: bool):
        """Tests str_to_bool."""
        assert str_to_bool(input) == output

    _assert_str_to_bool("yes", True)
    _assert_str_to_bool("YES", True)
    _assert_str_to_bool("yes", True)
    _assert_str_to_bool("YES", True)
    _assert_str_to_bool("y", True)
    _assert_str_to_bool("Y", True)
    _assert_str_to_bool("yep", True)
    _assert_str_to_bool("YEP", True)
    _assert_str_to_bool("yup", True)
    _assert

# Generated at 2022-06-21 23:46:10.540685
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("os").__name__ == os.__name__
    assert load_module_from_file_location("os").__name__ == os.__name__
    assert load_module_from_file_location("os").__path__ == os.__path__
    assert load_module_from_file_location("tests.test_helpers").__file__ == __file__

# Generated at 2022-06-21 23:46:22.153544
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A)
    os_environ["test_env_var"] = "/test/path/test_file"
    assert (
        load_module_from_file_location(
            "/some/path/${test_env_var}/test_file.py"
        )
        == "test_file"
    )

    # B)
    assert (
        load_module_from_file_location(
            "./tests/test_helpers.py", "./tests"
        )
        == "tests.test_helpers"
    )

    # C)
    assert (
        load_module_from_file_location(
            "/some/path/test_file", "./tests"
        )
        == "test_file"
    )



# Generated at 2022-06-21 23:46:33.605535
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test environment variable substitution.
    os_environ["test_env_var"] = "test_env_var_value"
    assert "test_env_var_value" in load_module_from_file_location(
        "${test_env_var}/test_file"
    ).__file__
    os_environ["test_env_var"] = ""

    # B) Test load from string parameter.
    assert "test_module_name" in load_module_from_file_location(
        "test_module_name", "path/to/some/my/module.py"
    ).__name__

    # C) Test load from Path parameter.

# Generated at 2022-06-21 23:46:43.145983
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "tests/test_utils_config.py"
    module = load_module_from_file_location(location)
    assert module.env_var == "MY_ENV_VAR"
    assert module.env_var_lower_case == "my_env_var"

    with os.environ.copy():
        os.environ["MY_ENV_VAR"] = "Dummy value."
        location = "${MY_ENV_VAR}/tests/test_utils_config.py"
        module = load_module_from_file_location(location)
        assert module.env_var == "Dummy value."
        assert module.env_var_lower_case == "my_env_var"



# Generated at 2022-06-21 23:46:55.200460
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["VAR"] = "var"
    spec_args = ("test_package", "/some/path/var", True, "test_name", True)

    os_environ.pop("VAR")
    assert (
        load_module_from_file_location(*spec_args)
        is not load_module_from_file_location(*spec_args)
    )

    os_environ["VAR"] = "var"
    assert (
        load_module_from_file_location(*spec_args)
        is load_module_from_file_location(*spec_args)
    )

    os_environ.pop("VAR")

# Generated at 2022-06-21 23:47:02.026167
# Unit test for function str_to_bool
def test_str_to_bool():
    # To pass Travis CI tests, we have to get rid of the deprecation warning
    # for Python 3.4.
    import warnings

    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")

        # Trigger a warning.
        str_to_bool("enable")

        # Verify some things
        assert 1 == len(w)
        assert issubclass(w[-1].category, DeprecationWarning)


if __name__ == "__main__":
    test_str_to_bool()

# Generated at 2022-06-21 23:47:20.419211
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from unittest.mock import patch
    from _pytest.monkeypatch import MonkeyPatch
    from types import ModuleType

    # A) Check that environment variables are substituted correctly
    # In case of env vars substitution, location should be of a string type
    m = MonkeyPatch()
    m.setattr(
        os_environ,
        "get",
        lambda key, default=None: {
            "env_var_1": "/this/is/path/to/first/module",
            "env_var_2": "module_name_2",
        }.get(key, default),
    )

    # Check that it works with string
    location1 = "/some/unresolved/path/${env_var_1}"
    result1 = load_module_from_file_location(location1)
    assert isinstance

# Generated at 2022-06-21 23:47:30.147920
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("Yo") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("Yup") == True
    assert str_to_bool("True") == True
    assert str_to_bool("On") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("N") == False
    assert str_to_bool("no") == False
    assert str_to_bool("False") == False
    assert str_to_bool("f") == False
    assert str_to_bool("0") == False

# Generated at 2022-06-21 23:47:38.648567
# Unit test for function str_to_bool
def test_str_to_bool():
    # bool values returned by str_to_bool are equal to bool type?
    assert str_to_bool("1") == bool(1)
    assert str_to_bool("0") == bool(0)

    # non-bool values cause ValueError
    try:
        str_to_bool("")
    except ValueError as e:
        assert "Invalid truth value " in str(e)

    # case insensitive
    assert str_to_bool("YES") == bool(1)
    assert str_to_bool("FALSE") == bool(0)

# Generated at 2022-06-21 23:47:50.473830
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Location is a file path
    module = load_module_from_file_location("tests/test_example_conf.py")
    assert module.TEST_CONFIG_VARIABLE == "valid_value"

    # Location is a unicode string with environment variable in it
    os_environ["TEST_UNICODE_CONF"] = "tests/test_example_conf.py"
    module = load_module_from_file_location("${TEST_UNICODE_CONF}")
    assert module.TEST_CONFIG_VARIABLE == "valid_value"

    # Location is a bytes string (encoded with utf-8) without environment variables in it

# Generated at 2022-06-21 23:48:00.204733
# Unit test for function str_to_bool
def test_str_to_bool():
    """
    Unit test for function str_to_bool
    """
    import pytest
    with pytest.raises(ValueError, match=r'Invalid truth value")'):
        str_to_bool("invalid")
    assert str_to_bool("true") is True
    assert str_to_bool("false") is False
    assert str_to_bool("TRUE") is True
    assert str_to_bool("FALSE") is False
    assert str_to_bool("True") is True
    assert str_to_bool("False") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("on") is True
    assert str_to_bool("off") is False
    assert str_to_bool("0") is False

# Generated at 2022-06-21 23:48:11.339200
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("T") is True
    assert str_to_bool("True") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("N") is False
    assert str_to_bool("No") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_

# Generated at 2022-06-21 23:48:23.888618
# Unit test for function str_to_bool
def test_str_to_bool():
    # Case sensitive
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("TRUE") == True
    with pytest.raises(ValueError):
        str_to_bool("TRUe")

    assert str_to_bool("f") == False
    assert str_to_bool("F") == False
    assert str_to_bool("false") == False
    assert str_to_bool("False") == False
    assert str_to_bool("FALSE") == False
    with pytest.raises(ValueError):
        str_to_bool("FALS")

    # Case insensitive
    assert str_to_bool("y")

# Generated at 2022-06-21 23:48:27.773187
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover
    from tempfile import mkstemp
    from os import write, close

    fd, location = mkstemp(".py")
    write(fd, b"some_var = True")
    close(fd)

    module = load_module_from_file_location(location)
    assert module.some_var is True

# Generated at 2022-06-21 23:48:39.130870
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import pytest

    with pytest.raises(ValueError):
        load_module_from_file_location(location="ANY")

    with pytest.raises(LoadFileException) as exc_info:
        load_module_from_file_location(
            location="The wrong file location."
        )
        assert "Unable to load configuration file (The wrong file location.)" in str(exc_info.value)

    with pytest.raises(LoadFileException) as exc_info:
        load_module_from_file_location(location="${PATH}")
        assert "The following environment variables are not set: PATH" in str(exc_info.value)


# Generated at 2022-06-21 23:48:47.946825
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("T") is True
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("on") is True
    assert str_to_bool("On") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False

# Generated at 2022-06-21 23:49:07.243721
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from pathlib import Path
    import tempfile
    import builtins
    # override open builtin to test files that are to be opened
    open_files = {}

    def open_mock(file, mode="r", encoding=None, errors=None, buffering=None):
        if "w" in mode:
            open_files[file] = ""
            return open_files[file]
        else:
            if isinstance(file, str):
                real_file = Path(file)
            else:
                real_file = file
            if not real_file.is_file():
                raise IOError(f"No such file: '{real_file}'")
            return open(file, mode, encoding, errors, buffering)

    builtins.open = open_mock

# Generated at 2022-06-21 23:49:20.852911
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("enable") is True
    assert str_to_bool("disabled") is False
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("True") is True
    assert str_to_bool("False") is False
    assert str_to_bool("true") is True
    assert str_to_bool("false") is False
    assert str_to_bool("On") is True
    assert str_to_bool("Off") is False
    assert str_to_bool("ON") is True
    assert str_to_bool("OFF") is False
    with pytest.raises(ValueError):
        str_to_

# Generated at 2022-06-21 23:49:33.791527
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check locations without environ variables.
    assert isinstance(
        load_module_from_file_location("os"), types.ModuleType
    )
    assert isinstance(
        load_module_from_file_location("os.path"), types.ModuleType
    )

    # B) Check if value error is raised when location is not a string
    #    and if is not a Path object.
    with pytest.raises(TypeError):
        load_module_from_file_location(object())

    # C) Check locations with environ variables.
    assert isinstance(
        load_module_from_file_location(str(Path.cwd())),
        types.ModuleType,
    )

# Generated at 2022-06-21 23:49:37.234744
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool(" false ") is False

    with pytest.raises(ValueError):
        str_to_bool("no_idea_what_should_I_put_here")

# Generated at 2022-06-21 23:49:50.297373
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile
    import os

    # A) Helper function to create temporary file, write data to it
    #    and close it.
    def create_temp_file(file_name, data):
        file_path = os.path.join(tempfile.mkdtemp(), file_name)
        with open(file_path, "w") as tmp_file:
            tmp_file.write(data)
            return file_path

    # B) Create some temporary python scripts.
    test_script_data = """
    some_var = 'some_value'
    """
    test_script = create_temp_file("test_script.py", test_script_data)

    test_script_with_env_var_data = """
    some_var = 'some_value'
    """
    test_

# Generated at 2022-06-21 23:49:56.134264
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    assert load_module_from_file_location(
        "tests/templates/options/${some_env_var}"
    ) is None
    assert load_module_from_file_location(
        "tests/templates/options/${some_env_var}.py"
    ) is None
    assert load_module_from_file_location(
        "tests/templates/options/${some_env_var}.pyc"
    ) is None

    # B) Check these variables exists in environment.
    assert load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    ) is None

    # C) Substitute them in location.

# Generated at 2022-06-21 23:50:05.528977
# Unit test for function str_to_bool
def test_str_to_bool():
    """Test str_to_bool function"""
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("1") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("t") is True
    assert str_to_bool("false") is False
    assert str_to_bool("False") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False
    assert str_to_bool("0") is False
    assert str_to_bool("n") is False
    assert str_to_