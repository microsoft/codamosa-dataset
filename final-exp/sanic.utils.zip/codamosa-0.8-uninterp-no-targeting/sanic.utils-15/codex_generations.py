

# Generated at 2022-06-21 23:40:25.240201
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # test str_to_bool
    assert str_to_bool("yes")
    assert str_to_bool("YeS")
    assert str_to_bool("1")
    assert str_to_bool("True")
    assert str_to_bool("T")
    assert str_to_bool("on")
    assert str_to_bool("enable")

    assert not str_to_bool("0")
    assert not str_to_bool("No")
    assert not str_to_bool("False")
    assert not str_to_bool("F")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")

    with pytest.raises(ValueError):
        str_to_bool("123")

    # test load_module_from_file_location
    assert load_module

# Generated at 2022-06-21 23:40:35.969150
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile, os

    def test_return_type():
        test_module = load_module_from_file_location(
            __name__, __file__
        )  # this file itself
        assert isinstance(test_module, types.ModuleType)

    with tempfile.NamedTemporaryFile(mode="w+") as temporary_file:

        def test_file_doesnt_exist():
            with pytest.raises(IOError):
                load_module_from_file_location(temporary_file.name)

        def test_module_is_loaded():
            temporary_file.write("MY_VAR = 'value'")
            temporary_file.flush()
            module = load_module_from_file_location(temporary_file.name)

# Generated at 2022-06-21 23:40:46.987675
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # SETUP
    some_env_var = "SOME_ENV_VAR"

    # BEGIN

# Generated at 2022-06-21 23:40:58.085791
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    from unittest.mock import patch

    test_location = Path("/some/path/some_module_name.py")

    with patch("importlib.util.module_from_spec") as mocked_module_from_spec:
        mocked_module = mocked_module_from_spec.return_value

        with patch("importlib.util.spec_from_file_location") as mocked_spec_from_file_location:
            mocked_spec = mocked_spec_from_file_location.return_value

            # When:
            load_module_from_file_location(test_location)

            # Then:
            mocked_spec_from_file_location.assert_called_once_with(
                "some_module_name", str(test_location)
            )
            mocked_module_from

# Generated at 2022-06-21 23:41:02.483090
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = Path(__file__).parent / "example.py"
    assert path.exists()
    module = load_module_from_file_location(path)
    assert module is not None
    assert module.SOME_CONSTANT == 20
    assert module.SOME_DEFAULT_CONSTANT == 10

# Generated at 2022-06-21 23:41:15.004888
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('y')
    assert not str_to_bool('n')
    assert str_to_bool('yes')
    assert not str_to_bool('no')
    assert str_to_bool('t')
    assert not str_to_bool('f')
    assert str_to_bool('true')
    assert not str_to_bool('false')
    assert str_to_bool('on')
    assert not str_to_bool('off')
    assert str_to_bool('enable')
    assert not str_to_bool('disable')
    assert str_to_bool('enabled')
    assert not str_to_bool('disabled')
    assert str_to_bool('1')
    assert not str_to_bool('0')

# Generated at 2022-06-21 23:41:27.075324
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:41:39.047338
# Unit test for function str_to_bool
def test_str_to_bool():
    bool_true = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]
    bool_false = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]
    for value in bool_true:
        assert str_to_bool(value) == True

    for value in bool_false:
        assert str_to_bool(value) == False

    try:
        str_to_bool("")
    except ValueError:
        pass


# Generated at 2022-06-21 23:41:49.901146
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from tempfile import TemporaryDirectory

    def func_for_conf(parameter):
        return "something"

    def func_for_conf2(parameter):
        return "something2"

    # 1. Check if I can load modules from the files.
    #    Check if the proper exceptions are raised if ommited the file
    #    or the file does not exist.
    with TemporaryDirectory() as tmpdirname:
        with open(f"{tmpdirname}/conf.py", "w") as f:
            f.write(
                f"some_var = 1\n"
                "some_function = lambda parameter: 'something'"
            )


# Generated at 2022-06-21 23:42:00.557635
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location has any environment variables in format ${some_env_var}.
    location = "${some_env_var}"
    env_vars_in_location = re_findall(r"\${(.+?)}", location)
    assert len(env_vars_in_location) == 1

    # B) Check these variables exist in environment.
    not_defined_env_vars = set(env_vars_in_location).difference(
        os_environ.keys()
    )
    assert len(not_defined_env_vars) == 0

    # C) Substitute them in location.
    for env_var in env_vars_in_location:
        location = location.replace("${" + env_var + "}", os_environ[env_var])
    assert location

# Generated at 2022-06-21 23:42:13.483975
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("0") == False

    # Make sure it is case insensitive
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("T") == True
    assert str_to_bool("TRue") == True
    assert str_to_bool

# Generated at 2022-06-21 23:42:21.562596
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("1") is True
    assert str_to_bool("False") is False
    assert str_to_bool("false") is False
    assert str_to_bool("false") is False
    assert str_to_bool("FALSE") is False
    assert str_to_bool("off") is False
    assert str_to_bool("No") is False
    assert str_to_bool("0") is False
    exception_raised = False

# Generated at 2022-06-21 23:42:32.153550
# Unit test for function str_to_bool
def test_str_to_bool():
    # True
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    # False
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool

# Generated at 2022-06-21 23:42:43.156205
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location(
            "config_dir/some_false_file.py",
            "tests",
        )
    except IOError as ioe:
        if ioe.strerror == "Unable to load configuration file (e.strerror)":
            pass
        else:
            raise
    else:
        raise Exception(
            "Failed to raise IOError"
            "if path to config is not a module"
        )

    try:
        load_module_from_file_location(
            "config_dir/client_certs.yml",
            "tests",
        )
    except IOError as ioe:
        if ioe.strerror == "Unable to load configuration file (e.strerror)":
            pass
        else:
            raise

# Generated at 2022-06-21 23:42:53.814856
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location(): # noqa
    import tempfile
    import os

    def boolean_module():
        def enable(): return True
        def disable(): return False
        def enable_true(): return True
        def enable_false(): return False

        return enable, disable, enable_true, enable_false

    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["CONFIG_MOD_NAME"] = tmpdirname + "/config"
        with open(f"{os.environ['CONFIG_MOD_NAME']}.py", "w") as conf:
            conf.write(
                "enable = 0; disable = 1; enable_true=True; enable_false=False"
            )

        res = load_module_from_file_location(
            "${CONFIG_MOD_NAME}",
            False
        )


# Generated at 2022-06-21 23:43:03.276781
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("1") is True
    assert str_to_bool("on") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("t") is True
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("0") is False
    assert str_to_bool("") is False
    assert str_to_bool("fa") is False
    assert str_to_bool("FALSE") is False
    assert str_to_bool("n") is False
    assert str

# Generated at 2022-06-21 23:43:10.833901
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    # Environment variable existing in file path
    os.environ["some_env_var"] = "some_value"
    # Path with existing environment variable.
    location = "tests/some_module_name.py"
    loaded_module = load_module_from_file_location(location)
    assert loaded_module.__name__ == "some_module_name"
    # Path without existing environment variable.
    location = "tests/${some_other_env_var}/some_module_name.py"

# Generated at 2022-06-21 23:43:22.435808
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("YeS") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("YEP") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("ENABLE") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True



# Generated at 2022-06-21 23:43:34.418362
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from os.path import curdir, abspath
    from os import environ
    from os import path

    root_dir = "/some/path/to/root/dir"
    environ["root_dir"] = root_dir
    with open(abspath(curdir + "/tests/temp_module.py"), "w") as f:
        f.write("module_var_1 = '123'")

    module = load_module_from_file_location(
        "tests/temp_module.py",
        f"{root_dir}/{path.abspath(curdir)}/tests/temp_module.py",
        f"${root_dir}/{path.abspath(curdir)}/tests/temp_module.py",
    )

    assert module.module_var_

# Generated at 2022-06-21 23:43:42.714091
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("TRUE")
    assert str_to_bool("yes")
    assert str_to_bool("y")
    assert str_to_bool("1")
    assert not str_to_bool("false")
    assert not str_to_bool("no")
    assert not str_to_bool("0")
    assert not str_to_bool("")
    assert not str_to_bool("foo")

# Generated at 2022-06-21 23:43:48.841668
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # defining dummy module for testing purposes
    tmp_dir = Path(__file__).parent / "unit_tests"
    filepath = tmp_dir / "dummy_module.py"
    with open(filepath, "w") as fp:
        fp.write("MODULE_VAR = 5")
    # loading module without importing it
    module = load_module_from_file_location(filepath)
    # checking if module is loaded
    assert module.MODULE_VAR == 5
    # cleaning files
    filepath.unlink()



# Generated at 2022-06-21 23:43:57.608501
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import random

    path_for_env_var = os.path.join(
        tempfile.gettempdir(),
        str(random.randint(0, 10 ** 10)),  # nosec
    )
    os.mkdir(path_for_env_var)
    enum_classes = {"one": 1, "two": 2, "three": 3}

    with open(
        os.path.join(path_for_env_var, "module_to_import.py"), "w"
    ) as module_to_import:
        module_to_import.write("enum_classes = %s" % enum_classes)

    os.environ["ENUM_CLASSES_PATH"] = path_for_env_var

    # Try import as a string
    mod = load_module_

# Generated at 2022-06-21 23:44:07.366863
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("yes") == True
    assert str_to_bool("no") == False
    assert str_to_bool("Yep") == True
    assert str_to_bool("Nope") == False
    assert str_to_bool("T") == True
    assert str_to_bool("F") == False
    assert str_to_bool("y") == True
    assert str_to_bool("f") == False
    assert str_to_bool("true") == True
    assert str_to_bool("False") == False
    assert str_to_bool("on") == True
    assert str_to_bool("Off") == False
    assert str_to_bool("yep") == True

# Generated at 2022-06-21 23:44:16.027792
# Unit test for function str_to_bool
def test_str_to_bool():
    with pytest.raises(ValueError):
        str_to_bool("0.0")
    assert str_to_bool("T")
    assert str_to_bool("F")
    assert str_to_bool("NO")
    assert str_to_bool("yes")
    assert not str_to_bool("0")
    assert str_to_bool("1")
    assert not str_to_bool(False)
    assert str_to_bool(True)



# Generated at 2022-06-21 23:44:29.428768
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import sys

    test_dir = Path(tempfile.mkdtemp())
    sys.path.append(test_dir)

    # Create some test config file
    config_file_path = test_dir.joinpath("config.py")
    with open(config_file_path, "w") as config_file:
        config_file.write("CONFIG_VAR = 4")

    # Test it.
    test_config = load_module_from_file_location(config_file_path)
    assert test_config.CONFIG_VAR == 4

    # Create some test config file with env variable
    env_var = "SANIC_CONFIG_TEST_ENV_VAR"
    os_environ[env_var] = str(config_file_path)
   

# Generated at 2022-06-21 23:44:36.229082
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("false") is False
    assert str_to_bool("True") is True
    assert str_to_bool("False") is False
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("Yes") is True
    assert str_to_bool("No") is False
    assert str_to_bool("on") is True
    assert str_to_bool("off") is False
    assert str_to_bool("ON") is True
    assert str_to_bool("OFF") is False
    assert str_to_bool("Enabled") is True
    assert str_

# Generated at 2022-06-21 23:44:47.705293
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:44:57.857548
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if ${XYZ} will be found in location string.
    location = "some/location/${XYZ}"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert env_vars_in_location == {"XYZ"}

    # B) Check if ${XYZ} will be found in location string.
    os_environ["XYZ"] = "qwerty"
    assert "qwerty" in load_module_from_file_location(
        "config/development.py", "some/location/${XYZ}"
    ).__file__
    assert "qwerty" not in load_module_from_file_location(
        "config/development.py", "some/location/${XYZ}"
    ).database
    del os

# Generated at 2022-06-21 23:45:09.868976
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("disabled") == False
    assert str_

# Generated at 2022-06-21 23:45:21.792364
# Unit test for function str_to_bool
def test_str_to_bool():
    print(str_to_bool("y"))
    print(str_to_bool("yes"))
    print(str_to_bool("yep"))
    print(str_to_bool("yup"))
    print(str_to_bool("t"))
    print(str_to_bool("true"))
    print(str_to_bool("on"))
    print(str_to_bool("enable"))
    print(str_to_bool("enabled"))
    print(str_to_bool("1"))
    print(str_to_bool("n"))
    print(str_to_bool("no"))
    print(str_to_bool("f"))
    print(str_to_bool("false"))
    print(str_to_bool("off"))
    print(str_to_bool("disable"))

# Generated at 2022-06-21 23:45:40.720900
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from .test_utils import TempDirectory

    with TempDirectory() as temp_path:
        config = "config.py"
        config_vars = """LIST = [1, 2, 3]\nDICT = {'a': 1}\nSTR = 'test'\n"""
        with open(temp_path / config, "w+") as f:
            f.write(config_vars)

        with TempDirectory(temp_path):
            submodule = "submodule"
            with open(temp_path / submodule / "__init__.py", "w") as f:
                pass
            with open(temp_path / submodule / config, "w+") as f:
                f.write(config_vars)

            submodule_with_dashes = "submodule-1"

# Generated at 2022-06-21 23:45:51.214021
# Unit test for function str_to_bool
def test_str_to_bool():
    """Tests for str_to_bool function."""
    # If val is in case insensitive ("y", "yes", "yep", "yup", "t",
    # "true", "on", "enable", "enabled", "1") returns True.
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yeP") is True
    assert str_to_bool("yUP") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("On") is True
    assert str_to_bool("ENABLED") is True
    assert str_to_bool("1") is True

    # If val is in case insensitive ("n", "no", "f",

# Generated at 2022-06-21 23:46:02.579991
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") == True
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("yes.") == True
    assert str_to_bool("yes!") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yEP") == True
    assert str_to_bool("yep.") == True
    assert str_to_bool("yep!") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("yUP") == True
    assert str_to_bool("yup.") == True
    assert str_to_bool("yup!") == True
    assert str_to_

# Generated at 2022-06-21 23:46:11.361453
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import tempfile, shutil

    tempdir = tempfile.gettempdir()
    test_file = Path(tempdir, "test_load_module.py")

    if test_file.exists():
        os.remove(test_file)

    with open(test_file, "w") as f:
        f.write("""
foo = "bar"
""")

    module = load_module_from_file_location(test_file)
    assert module.foo == "bar"
    shutil.rmtree(tempdir)

# Generated at 2022-06-21 23:46:21.954774
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("True") == True
    assert str_to_bool("true") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("on") == True
    assert str_to_bool("1") == True
    assert str_to_bool("False") == False
    assert str_to_bool("false") == False
    assert str_to_bool("yup") == True
    assert str_to_bool("off") == False
    assert str_to_bool("0") == False
    try:
        str_to_bool("whatever")
        assert False, "Some ValueError expected!"
    except ValueError:
        assert True



# Generated at 2022-06-21 23:46:30.184322
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") == True
    assert str_to_bool("t") == True
    assert str_to_bool("On") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("False") == False
    assert str_to_bool("off") == False
    assert str_to_bool("no") == False
    assert str_to_bool("0") == False


# Unit tests for function load_module_from_file_location

# Generated at 2022-06-21 23:46:40.694414
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("n") is False
    assert str_to_bool("F") is False
    assert str_to_bool("false") is False
    assert str_to_bool("True") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("disable") is False
    assert str_to_bool("on") is True
    assert str_to_bool("off") is False
    assert str_to_bool("enabled") is True
    assert str_to_bool("disabled") is False
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_

# Generated at 2022-06-21 23:46:48.035595
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        assert load_module_from_file_location("")
    except ValueError:
        pass

    assert load_module_from_file_location("os") == os
    assert load_module_from_file_location("./sanic/config") == config

    try:
        load_module_from_file_location("${some_env_var}")
    except LoadFileException:
        pass

    if "PYTHONPATH" in os_environ:
        assert (
            load_module_from_file_location("${PYTHONPATH}") == os_environ["PYTHONPATH"]
        )
    # Module tests
    # >>> In file ./tests/test_config.py exists a dict test_conf_dict
    # >>> with key test_config_value = True
    # >>> In

# Generated at 2022-06-21 23:46:58.762167
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    from unittest.mock import patch  # Python3.3+
    from os.path import join

    with patch.dict("os.environ", {"PWD": "/home/some_user"}, clear=True):
        # 1. Full path.
        location = "/home/some_user/some_dir/some_file.py"
        module = load_module_from_file_location(
            location=location, encoding="utf8"
        )
        assert module.__file__ == location

        # 2. Relative path.
        location = "some_file.py"
        module = load_module_from_file_location(
            location=location, encoding="utf8"
        )

# Generated at 2022-06-21 23:47:11.438281
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic.config import Config
    import configparser
    import json
    import os
    import tempfile
    import yaml

    def make_sample_file(file_type="ini"):
        if file_type == "ini":
            config = configparser.ConfigParser()
            config["foo"] = {"bar": "baz"}
            file_path = tempfile.NamedTemporaryFile(
                mode="w", delete=False, suffix="." + file_type
            ).name
            with open(file_path, "w") as f:
                config.write(f)
        elif file_type in {"json", "yaml"}:
            if file_type == "yaml":
                import yaml

            file_content = {"foo": {"bar": "baz"}}
            file_path = tempfile.N

# Generated at 2022-06-21 23:47:27.710494
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        importlib.reload(importlib)
    except:
        import importlib
    import tempfile

    # Test 1:
    # Test case with using a pathlib object,
    # not containing any environment variables.
    # File is exists and contains no errors.
    tmp_file_path = Path(tempfile.gettempdir())
    tmp_file_path = tmp_file_path / "tmp_file_path.py"
    with open(tmp_file_path, "w") as tmp_file:
        tmp_file.write(
            "configuration = {'some_parameter': 'some_value'}"
        )

    module = load_module_from_file_location(tmp_file_path)
    assert module.configuration["some_parameter"] == "some_value"

    # Test 2

# Generated at 2022-06-21 23:47:39.410358
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("yesY") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("YeP") == True
    assert str_to_bool("yES") == True
    assert str_to_bool("1") == True
    assert str_to_bool("True") == True
    assert str_to_bool("true") == True
    assert str_to_bool("t") == True
    assert str_to_bool("truE") == True
    assert str_to_bool("12345") == True

    assert str_to_bool("n")

# Generated at 2022-06-21 23:47:50.857851
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import importlib
    import tempfile

    tmp_dir = Path(tempfile.gettempdir())
    tmp_module_file = tmp_dir / "test_module.py"
    tmp_module_name = "test_module"
    tmp_module_no_py = tmp_dir / "test_module_no_py"
    tmp_module_not_exist = tmp_dir / "test_module_not_exist.py"
    tmp_module_name_not_exist = "test_module_not_exist"

    # 1. Creating a module.
    with open(tmp_module_file, "w") as tmp_module_file:
        tmp_module_file.write("test_var = 7")


# Generated at 2022-06-21 23:47:58.864021
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Testing function load_module_from_file_location."""
    # TODO: There should be unit tests for:
    # A) load_module_from_file_location("some_module_name", "/some/path/${some_env_var}")
    # B) load_module_from_file_location("/some/path/${some_env_var}")
    # and other variants of this function.
    assert load_module_from_file_location("time").__name__ == "time"
    assert load_module_from_file_location("sanic.server").__name__ == "sanic.server"

# Generated at 2022-06-21 23:48:10.733237
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from unittest.mock import patch

    with patch.dict(os_environ, {"SOME_ENV_VAR": "some_value", "SOME_VAR": "bar"}):
        module = load_module_from_file_location(
            "some module name", "some_config", "/some/path/${SOME_ENV_VAR}"
        )
        assert module.__name__ == "config"
        assert module.SOME_VAR == "bar"

        module = load_module_from_file_location(
            "some module name", "some_config", "/some/path/${SOME_VAR}"
        )
        assert module.__name__ == "some_config"
        assert module.SOME_VAR == "bar"

        module = load_module_from_file_

# Generated at 2022-06-21 23:48:21.932383
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa

    # True
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    # False
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")

# Generated at 2022-06-21 23:48:30.286171
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("YEP") is True
    assert str_to_bool("YUP") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("on") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("ENABLE") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("ENABLED") is True
    assert str_to_bool("1") is True


# Generated at 2022-06-21 23:48:38.353733
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with tempfile.NamedTemporaryFile(mode="w") as config_file:
        config_file.write("A='a'")
        config_file.flush()
        conf = load_module_from_file_location(config_file.name)
        assert conf.A == "a"

        with pytest.raises(PyFileError):
            load_module_from_file_location(config_file.name, "utf8", "garbage")

    with pytest.raises(ValueError):
        load_module_from_file_location("/some/invalid/path")

# Generated at 2022-06-21 23:48:46.630751
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("YEP") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("YUP") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("on") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("enable") == True

# Generated at 2022-06-21 23:48:56.735249
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with tempfile.TemporaryDirectory() as location:
        os.mkdir(os.path.join(location, "some_dir"))
        with open(os.path.join(location, ".path.py"), "w") as path:
            config_text = """
import os
config_dir = os.path.dirname(os.path.abspath(__file__))
""".strip()
            path.write(config_text)
        with open(os.path.join(location, "config1.py"), "w") as config:
            config_text = """
env_var_test = True
""".strip()
            config.write(config_text)

# Generated at 2022-06-21 23:49:22.595148
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-21 23:49:33.766632
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("y") == True
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("yEs") == True
    assert str_to_bool("YEs") == True
    assert str_to_bool("YEs") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("1") == True
    assert str_to_bool("On") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("oN") == True
    assert str_to_bool("True") == True


# Generated at 2022-06-21 23:49:43.535069
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test A)
    test_path = "/some/path/to/module.py"
    test_module = load_module_from_file_location(test_path)
    assert test_module.__file__ == test_path

    # Test B)
    test_path = "./module.py"
    test_module = load_module_from_file_location(test_path)
    assert test_module.__file__ == test_path

    # Test C)
    test_path = Path("./module.py")
    test_module = load_module_from_file_location(test_path)
    assert test_module.__file__ == str(test_path)

    # Test D)
    test_path = b"./module.py"
    test_module = load_module_from_file_location

# Generated at 2022-06-21 23:49:50.951480
# Unit test for function str_to_bool
def test_str_to_bool():
    with pytest.raises(ValueError) as excinfo:
        str_to_bool("nope")

    assert "Invalid truth value nope" in str(excinfo.value)
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("YES") == True
    assert str_to_bool("NO") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False

# Generated at 2022-06-21 23:50:03.055925
# Unit test for function str_to_bool
def test_str_to_bool():
    true_strings = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]
    true_strings += [x.upper() for x in true_strings]
    for t_str in true_strings:
        assert str_to_bool(t_str) is True

    false_strings = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]
    false_strings += [x.upper() for x in false_strings]
    for f_str in false_strings:
        assert str_to_bool(f_str) is False

# Generated at 2022-06-21 23:50:14.417355
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    from tempfile import NamedTemporaryFile
    from types import ModuleType
    import json

    # A) Test getting loaded module from file path
    with NamedTemporaryFile(mode="w", dir=Path().cwd()) as tmp:
        tmp.write(json.dumps({"some_key": "some_value"}))
        tmp.flush()
        assert (
            load_module_from_file_location(tmp.name) is not None
            and isinstance(load_module_from_file_location(tmp.name), ModuleType)
        )

    # B) Test getting loaded module from file path
    with NamedTemporaryFile(mode="w", dir=Path().cwd(), suffix=".py") as tmp:
        tmp.write("SOME_CONSTANT = 42")
        tmp.flush()
