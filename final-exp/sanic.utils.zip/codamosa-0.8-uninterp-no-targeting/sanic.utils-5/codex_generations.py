

# Generated at 2022-06-21 23:40:02.726783
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from shutil import rmtree

    from tempfile import mkdtemp
    from unittest import mock

    # A) Test for loading file with absolute path (when file does exist)
    try:
        from tempfile import TemporaryDirectory
    except ImportError:  # Python < 3.2
        from backports.tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        module_name = "test_config"
        module_location = tmp_dir + "/" + module_name + ".py"
        with open(module_location, "w") as test_config:
            test_config.write("CONFIG = {'key': 'value'}")
        test_config.close()
        test_module = load_module_from_file_location(module_location)

# Generated at 2022-06-21 23:40:12.649693
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-21 23:40:24.426930
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import io
    import sys

    from unittest.mock import patch

    from sanic.exceptions import PyFileError

    # A) Test case when location is a file path.
    content = """
    class SomeObject:
        def __init__(self):
            pass
    """
    with patch.object(sys, "argv", ["test"]):
        with patch(
            "builtins.open",
            new=mock.mock_open(read_data=content),
        ):
            with patch(
                "os.path.abspath",
                new=mock.Mock(return_value="some/file.py"),
            ):
                module = load_module_from_file_location("some/file.py")

# Generated at 2022-06-21 23:40:35.302840
# Unit test for function str_to_bool
def test_str_to_bool():
    # When string is one of the True values, function returns True.
    assert str_to_bool("yes")
    assert str_to_bool("y")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    # When string is one of the False values, function returns False.
    assert not str_to_bool("no")
    assert not str_to_bool("n")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_

# Generated at 2022-06-21 23:40:49.681433
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("1") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("0") == False
    assert str_to_bool("no") == False
    assert str_to_bool("OFF") == False
    assert str_to_bool("nope") == False

# Generated at 2022-06-21 23:41:00.205658
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""
    from sanic.conf import CONFIG_DEFAULTS
    import tempfile

    conf_path = tempfile.mktemp(suffix=".py")
    conf_path = Path(conf_path)
    conf = """
SANIC_CONFIG = {
    "foo": "bar",
    "access_log": false
}"""

    with open(conf_path, "w") as f:
        f.write(conf)

    mod = load_module_from_file_location(conf_path)
    assert mod.SANIC_CONFIG == {
        "foo": "bar",
        "access_log": False
    }

    mod = load_module_from_file_location(conf_path.as_posix())
    assert mod.SANIC_

# Generated at 2022-06-21 23:41:06.190782
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for load_module_from_file_location function.

    This unit test should cover all if statements in
    load_module_from_file_location function.
    """
    location = "/some/location/${env_var}/with/env_var/file.py"
    os_environ["env_var"] = "env_var_value"
    module = load_module_from_file_location(location)
    assert module.__file__ == (
        "/some/location/env_var_value/with/env_var/file.py"
    )
    del os_environ["env_var"]

    location = "/some/location/with/file/wo/extension"
    module = load_module_from_file_location(location)

# Generated at 2022-06-21 23:41:17.323879
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("yep") == True
    assert str_to_bool("no") == False
    assert str_to_bool("t") == True
    assert str_to_bool("false") == False
    assert str_to_bool("on") == True
    assert str_to_bool("off") == False
    assert str_to_bool("enable") == True
    assert str_to_bool("disable") == False
    assert str_to_bool("enabled") == True
    assert str_to_bool("disabled") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("yup") == True

# Generated at 2022-06-21 23:41:27.852749
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SANIC_TEST_MODULE"] = "TESTING"
    mod_1 = load_module_from_file_location(
        "/some/path/${SANIC_TEST_MODULE}", "utf8"
    )
    mod_2 = load_module_from_file_location(
        "/some/path/${SANIC_TEST_MODULE}", "utf8"
    )
    mod_3 = load_module_from_file_location(
        "./tests/test_helpers.py", "utf8"
    )
    assert mod_1.__file__ == mod_2.__file__ == "/some/path/TESTING"
    assert mod_3.__file__ == "./tests/test_helpers.py"

# Generated at 2022-06-21 23:41:36.606134
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover

    # Set some environment variables for test purposes
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    os_environ["TEST_ENV_VAR_1"] = "test_env_var_1"
    os_environ["TEST_ENV_VAR_2"] = "test_env_var_2"
    os_environ["TEST_ENV_VAR_3"] = "test_env_var_3"

    # Create test module for file-based configuration
    test_module_file = Path("/tmp") / "test_module.py"
    with test_module_file.open("w") as test_module_file_object:
        test_module_file_object.write("test_var = 'ok'")



# Generated at 2022-06-21 23:41:49.806753
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:41:55.572758
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("No") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("True") is True
    with pytest.raises(ValueError):
        str_to_bool("foo")


# Generated at 2022-06-21 23:42:06.501368
# Unit test for function str_to_bool
def test_str_to_bool():
    true_cases = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]
    false_cases = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]
    for case in true_cases:
        assert str_to_bool(case) is True
    for case in false_cases:
        assert str_to_bool(case) is False

# Generated at 2022-06-21 23:42:14.146839
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("off") is False
    assert str_to_bool("Quack") is False

# Generated at 2022-06-21 23:42:21.849484
# Unit test for function load_module_from_file_location

# Generated at 2022-06-21 23:42:29.506378
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    conf_path = "tests/examples_for_doc/config.py"
    try:
        conf = load_module_from_file_location(conf_path)
    except Exception:
        raise

    assert conf.TESTING
    assert conf.SANIC_CONFIG["TESTING"]
    assert conf.SANIC_CONFIG["KEEP_ALIVE"] is False
    assert conf.SANIC_CONFIG["SERVER_NAME"] == "127.0.0.1:8000"

# Generated at 2022-06-21 23:42:41.002199
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location("tests.helpers.test_load_module_from_file_location")
        == test_load_module_from_file_location
    )

    assert (
        load_module_from_file_location(
            "/".join(__file__.split("/")[:-1]) + "/test_helpers.py"
        )
        == load_module_from_file_location
    )

    assert (
        load_module_from_file_location(__file__)
        == load_module_from_file_location
    )


# Generated at 2022-06-21 23:42:52.558228
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Test with different types of path
    load_module_from_file_location("/some/path")
    from sanic import __path__ as sanic_path  # noqa
    load_module_from_file_location(
        Path(f"{sanic_path[0]}/../sanic/app.py")
    )
    import tempfile

    tempfile_name = tempfile.NamedTemporaryFile().name
    load_module_from_file_location(tempfile_name)

    # Test it throws error when environment variable is not set
    os_environ["SOME_ENV_VAR"] = "some_value"
    load_module_from_file_location("${SOME_ENV_VAR}")

# Generated at 2022-06-21 23:43:03.090666
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile  # noqa
    from os import environ as os_environ
    from os.path import dirname, join, realpath
    from shutil import rmtree
    from types import ModuleType
    from unittest.mock import patch

    import pytest

    from sanic import Sanic

    from .helpers import get_test_loop

    mock_location: str = "mock_location"
    mock_content: str = "mock_content"
    mock_encoding: str = "mock_encoding"
    mock_args: tuple = ("mock_args", "mock_args")
    mock_kwargs: dict = {"mock_kwargs": "mock_kwargs"}
    mock_env_var: str = "some_env_var"
    mock_env_var_value

# Generated at 2022-06-21 23:43:13.913555
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    # Load module from not-existing file will raise IOError
    with pytest.raises(IOError):
        load_module_from_file_location("some_invalid_name")

    # Load module from invalid Python code will raise PyFileError
    with pytest.raises(PyFileError):
        load_module_from_file_location(
            "tests/config_files/config_with_invalid_python_code.py"
        )

    # Load valid module from valid file path
    some_module = load_module_from_file_location(
        "tests/config_files/config_file.py"
    )

    # Check that some_module has attribute a_valid_attr

# Generated at 2022-06-21 23:43:24.529702
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test for:
      - load_module_from_file_location.
      - Raising errors at unexpected situations.
    """
    from .empty_module import empty_module
    from ..utils import get_test_config_list

    def run_test(config_file):
        config_list = get_test_config_list(config_file)

        with os_environ.copy():
            # A)  Check if imported module is working as expected.
            os_environ["ABC_VAR"] = 'some value'
            imported_config = load_module_from_file_location(config_list[0])
            # B) Check if environment variables are set correctly.
            assert os_environ["ABC_VAR"] == 'some value'

            # C) Check if imported module has correct values.
            assert imported_

# Generated at 2022-06-21 23:43:32.994871
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("1") == True
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False
    assert str_to_bool("0") == False
    assert str_to_bool("yes") == True
    assert str_to_bool("no") == False

    try:
        str_to_bool("banana")
    except ValueError:
        return True
    return False

# Generated at 2022-06-21 23:43:44.906728
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:43:50.243366
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") and str_to_bool("t") and str_to_bool("true")
    assert not (str_to_bool("no") or str_to_bool("f") or str_to_bool("false"))

# Generated at 2022-06-21 23:43:58.176522
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    expected_module = types.ModuleType("config")
    expected_module.__file__ = "some_location_as_string"
    os_environ["some_env_var"] = "some_env_var_value"

    assert load_module_from_file_location(
        b"some_location_as_bytes", encoding="utf8"
    ) == expected_module
    assert load_module_from_file_location(
        "some_location_as_string", encoding="utf8"
    ) == expected_module
    assert load_module_from_file_location(
        Path("some_location_as_pathlib_path")
    ) == expected_module

# Generated at 2022-06-21 23:44:10.468389
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = Path(__file__).parent / "config.py"

    mod = load_module_from_file_location(location=path)
    assert mod.TEST_VARIABLE == "JUST_A_TEST"

    mod = load_module_from_file_location("config", path)
    assert mod.TEST_VARIABLE == "JUST_A_TEST"

    mod = load_module_from_file_location("config", path.as_posix())
    assert mod.TEST_VARIABLE == "JUST_A_TEST"

    mod = load_module_from_file_location("config", path.as_uri())
    assert mod.TEST_VARIABLE == "JUST_A_TEST"


# Generated at 2022-06-21 23:44:19.974663
# Unit test for function str_to_bool
def test_str_to_bool():
    """Makes sure str_to_bool is working as expected."""
    # Boolean True
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("1")
    assert str_to_bool("On")
    assert str_to_bool("ON")
    assert str_to_bool("true")
    assert str_to_bool("TRUE")
    assert str_to_bool("yes")
    assert str_to_bool("YES")
    assert str_to_bool("YEP")
    assert str_to_bool("yup")
    assert str_to_bool("YUP")
    assert str_to_bool("T")
    assert str_to_bool("t")

    # Boolean False
    assert not str_to_bool("n")

# Generated at 2022-06-21 23:44:28.589368
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("N") is False
    assert str_to_bool("no") is False

# Generated at 2022-06-21 23:44:36.539960
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    This unit test check:
    1. If function load_module_from_file_location
       can load module from a string without errors.
    2. If function load_module_from_file_location
       can load module, that contains environment variable.
    3. If function load_module_from_file_location
       raise LoadFileException if
       a location contains not defined environment variable.
    4. If function load_module_from_file_location
       raise LoadFileException if
       a location contains not defined environment variable.
    """
    def get_location_exception_error_message(module):
        module_is_invalid = False
        try:
            load_module_from_file_location(module)
        except LoadFileException as e:
            module_is_invalid = True
            assert module_is_in

# Generated at 2022-06-21 23:44:42.639068
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("no") == False
    # raise ValueError if invalid string is passed
    try:
        assert str_to_bool("maybe") == None
    except ValueError:
        assert True


# Generated at 2022-06-21 23:44:56.326574
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["KEYS_FROM_ENV_VARS_1"] = "value_1"
    os_environ["KEYS_FROM_ENV_VARS_2"] = "value_2"
    os_environ["KEYS_FROM_ENV_VARS_3"] = "value_3"

    # A)
    # 1)
    os_environ["KEYS_FROM_ENV_VARS_3"] = "value_3"
    os_environ["KEYS_FROM_ENV_VARS_1"] = "value_1"
    os_environ["KEYS_FROM_ENV_VARS_2"] = "value_2"
    os_environ["KEYS_FROM_ENV_VARS_4"] = "value_4"



# Generated at 2022-06-21 23:45:08.918810
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("ON") is True
    assert str_to_bool("True") is True
    assert str_to_bool("t") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("y") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("Off") is False
    assert str_to_bool("Disable") is False
    assert str_to_bool("0") is False
    assert str_to_bool("no") is False
    assert str_to_bool("yup") is True
    assert str_to_bool("off") is False
    assert str_to_bool("yep") is True
    assert str_to_bool("false") is False
    assert str_to_bool("yup") is True
   

# Generated at 2022-06-21 23:45:21.379982
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("YeS") == True
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("True") == True
    assert str_to_bool("trUe") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("TruE") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("on") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("On") == True
    assert str_to_bool("oN")

# Generated at 2022-06-21 23:45:30.719582
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys, os

    # 1. Create simple module in runtime
    some_module_code = "a=1\nb='string'\n"
    with open("some_file_with_some_module.py", "w") as f:
        f.write(some_module_code)

    sys.path.insert(0, os.getcwd())
    module = load_module_from_file_location("some_file_with_some_module")
    os.remove("some_file_with_some_module.py")
    assert module.a == 1
    assert module.b == "string"

    print("Test load_module_from_file_location: OK")

# Generated at 2022-06-21 23:45:42.613904
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        from .test_utils import config1, config2, config3

        loaded_module = load_module_from_file_location(
            __file__.replace("test_helpers.py", "test_utils/config1.py")
        )
        assert config1 == loaded_module
        loaded_module = load_module_from_file_location(
            __file__.replace("test_helpers.py", "test_utils/config2")
        )
        assert config2 == loaded_module
        loaded_module = load_module_from_file_location(
            __file__.replace("test_helpers.py", "test_utils/config3.json")
        )
        assert config3 == loaded_module
    except ImportError:
        pass

# Generated at 2022-06-21 23:45:52.754518
# Unit test for function load_module_from_file_location

# Generated at 2022-06-21 23:46:04.155658
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("YeS") == True
    assert str_to_bool("yEp") == True
    assert str_to_bool("Yup") == True
    assert str_to_bool("YUP") == True
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("on") == True
    assert str_to_bool("On") == True

# Generated at 2022-06-21 23:46:16.664769
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") is True
    assert str_to_bool("T") is True
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("on") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("yep") is True

# Generated at 2022-06-21 23:46:28.409502
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import sanic.exceptions as ex
    from sanic.config import Config
    from tempfile import mkdtemp
    from os import remove, mkdir
    from os.path import join
    from shutil import rmtree

    ##################################################################
    # Check if we able to load module from environment variable
    ##################################################################

    os_environ["SOME_ENV_VAR"] = "env_var_value"
    config = Config()
    module = load_module_from_file_location(
        "${SOME_ENV_VAR}", config.CONFIG_NOT_SET
    )
    assert module == config.CONFIG_NOT_SET

    ##################################################################
    # Check if we able to load module from pathlib.Path instance
    ##################################################################

    module = load_module

# Generated at 2022-06-21 23:46:39.190537
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("Y")
    assert str_to_bool("Yes")
    assert str_to_bool("yeS")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("TrUe")
    assert str_to_bool("1")
    assert not str_to_bool("false")
    assert not str_to_bool("0")
    assert not str_to_bool("no")
    assert not str_to_bool("n")
    assert not str_to_bool("")
    assert not str_to_bool("f")
    with pytest.raises(ValueError):
        str_to_bool("dd")

# Generated at 2022-06-21 23:46:55.052689
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("yEs") == True
    assert str_to_bool("y") == True

    assert str_to_bool("yup") == True
    assert str_to_bool("Yup") == True
    assert str_to_bool("yU") == True
    assert str_to_bool("Yu") == True

    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("TruE") == True
    assert str_to_bool("TRUE") == True

    assert str_to_bool("t") == True
    assert str_to_bool("T")

# Generated at 2022-06-21 23:46:57.265707
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(__file__).__name__ == "utils"

# Generated at 2022-06-21 23:47:04.772444
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("Yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("yup") is True
    assert str_to_bool("Nope") is False
    assert str_to_bool("True") is True
    assert str_to_bool("false") is False
    assert str_to_bool("ON") is True
    assert str_to_bool("Off") is False
    assert str_to_bool("t") is True
    assert str_to_bool("f") is False
    assert str_to_bool("enable") is True
    assert str_to_bool("Disable") is False
    assert str_to_bool("y") is True

# Generated at 2022-06-21 23:47:07.890822
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("false") == False
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("False") == False

# Generated at 2022-06-21 23:47:19.888382
# Unit test for function str_to_bool
def test_str_to_bool():

    # A set of strings as would be expected by human.
    to_check_true = {
        "y",
        "Y",
        "yes",
        "Yes",
        "YES",
        "yep",
        "Yep",
        "YEP",
        "yup",
        "YUP",
        "t",
        "T",
        "true",
        "True",
        "TRUE",
        "on",
        "On",
        "ON",
        "enable",
        "Enable",
        "ENABLE",
        "enabled",
        "Enabled",
        "ENABLED",
        "1",
    }

    for val in to_check_true:
        assert str_to_bool(val)

    # A set of strings as would be expected by human.
    to_check

# Generated at 2022-06-21 23:47:29.435317
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from unittest.mock import patch

    from os.path import dirname, join
    from pathlib import Path

    from sanic.utils import IS_WINDOWS

    # A) Try not to break original load_module_from_file_location
    #    functionality.
    data = {
        "some_str": "str1",
        "some_int": 1,
        "some_bool": True,
        "some_tuple": (1, True),
        "some_list": [1, "str"],
        "some_dict": {"key1": "value"},
        "some_nested_list": [[1, 2], (1, "2")],
        "some_nested_dict": {"key1": {"key2": True}},
    }

    module_loaded_from_path = load

# Generated at 2022-06-21 23:47:40.662032
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_file_location = Path(".").parent / "tests" / "test_files"

    assert load_module_from_file_location(
        "tests.test_files.test_config.test_config_1"
    )
    assert load_module_from_file_location("tests.test_files.test_config_1")

    assert (
        load_module_from_file_location(
            test_file_location.as_posix()
            + "/test_config/test_config_2.py"
        ).object
        == "object_2"
    )
    assert (
        load_module_from_file_location(
            test_file_location.as_posix() + "/test_config_2.py"
        ).object
        == "object_2"
    )


# Generated at 2022-06-21 23:47:47.010393
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True")
    assert str_to_bool("TRUE")
    assert str_to_bool("On")
    assert not str_to_bool("FALSE")
    assert not str_to_bool("off")
    assert not str_to_bool("False")
    assert not str_to_bool("false")

# Generated at 2022-06-21 23:47:53.461955
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from types import ModuleType

    from sanic.config import CONFIG_DEFAULTS

    import os

    import tempfile

    # Create temporary file for tests
    some_config_file = tempfile.NamedTemporaryFile(mode="r+")
    some_config_file.write(
        "REQUEST_MAX_SIZE = 100\n"
        "RESPONSE_MAX_SIZE = 800\n"
        "REQUEST_TIMEOUT = 30\n"
    )
    some_config_file.flush()

    # Load this temporary file as a module
    module_from_file = load_module_from_file_location(
        some_config_file.name
    )

    # Tests
    assert isinstance(module_from_file, ModuleType)

# Generated at 2022-06-21 23:47:59.347617
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-21 23:48:18.837618
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import uuid

    with tempfile.TemporaryDirectory() as tmp_dir:
        os.environ["TEST_VAR_1"] = "a"
        os.environ["TEST_VAR_2"] = "b"

        tmp_file = tempfile.NamedTemporaryFile(
            "w+", dir=tmp_dir, encoding="UTF-8"
        )
        tmp_file.write(
            "TEST_VAR_1='a'\nTEST_VAR_2={TEST_VAR_1}\nTEST_VAR_3={TEST_VAR_2}\n"
        )
        tmp_file.flush()


# Generated at 2022-06-21 23:48:28.425279
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("On") is True
    assert str_to_bool("OFF") is False
    assert str_to_bool("y") is True
    assert str_to_bool("N") is False
    assert str_to_bool("0") is False
    assert str_to_bool("1") is True
    assert str_to_bool("t") is True
    assert str_to_bool("f") is False
    assert str_to_bool("yup") is True
    assert str_to_bool("NOP") is False
    assert str_to_bool("YeS") is True
    assert str_to_bool("nO") is False
    assert str_to_bool("True") is True


# Generated at 2022-06-21 23:48:39.398990
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil

    # 0. Environment setup.
    curr_dir = os.path.abspath(os.curdir)
    tmp_dir_name = tempfile.mkdtemp()
    os.chdir(tmp_dir_name)

    # 1. No such file.
    path = "some_file.py"
    with pytest.raises(IOError):
        load_module_from_file_location(path)

    # 2. Not python file.
    path = "some_file.txt"
    open(path, "w").close()
    with pytest.raises(LoadFileException):
        load_module_from_file_location(path)

    # 3. Missing imports.
    # Note that it raises import error of a specific module,
    #

# Generated at 2022-06-21 23:48:49.291479
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import random
    import os
    import string

    def get_random_string(length: int = 10) -> str:
        letters = string.ascii_lowercase
        return "".join(random.choice(letters) for i in range(length))

    # Test A)
    location = (
        get_random_string()
        + "${"
        + os.environ.keys().__iter__().__next__()
        + "}"
    )
    module = load_module_from_file_location(location)
    assert module.__file__ == os.path.dirname(os.path.abspath(__file__))

    # Test B)

# Generated at 2022-06-21 23:48:53.005565
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("on") is True
    assert str_to_bool("OFF") is False
    assert str_to_bool("False") is False

# Generated at 2022-06-21 23:48:59.616870
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("ON")
    assert str_to_bool("Yes")
    assert str_to_bool("y")
    assert str_to_bool("1")
    assert str_to_bool("True")
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert str_to_bool("TRUE")
    assert str_to_bool("Y")
    assert str_to_bool("Enabled")
    assert str_to_bool("OFF") is False
    assert str_to_bool("No") is False
    assert str_to_bool("n") is False
    assert str_to_bool("0") is False
    assert str_to_bool("False") is False
    assert str_to_bool("f") is False
    assert str_to_bool("F")

# Generated at 2022-06-21 23:49:09.953541
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if environment variables in location are resolved.
    import tempfile
    import pathlib
    import os

    os.environ["var"] = "env"
    fd, temp_module_path = tempfile.mkstemp(suffix=".py")
    with os.fdopen(fd, "w") as temp_module:
        temp_module.write("a = 1\n")

    loaded_module = load_module_from_file_location(
        pathlib.Path(os.getcwd()) / "${var}/${var}.py"
    )
    assert loaded_module.a == 1
    with os.fdopen(fd, "w") as temp_module:
        temp_module.write("a = 2\n")
    reload(loaded_module)
    assert loaded_module.a == 2

# Generated at 2022-06-21 23:49:22.795880
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("True") == True
    assert str_to_bool("trUe") == True
    assert str_to_bool("YEs") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("on") == True
    assert str_to_bool("on") == True
    assert str_to_bool("OuI") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False

# Generated at 2022-06-21 23:49:31.379048
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("n") == False
    assert str_to_bool("enable") == True
    assert str_to_bool("off") == False
    assert str_to_bool("0") == False

    try:
        str_to_bool("invalid_str")
        assert False, "Should not come to this point as it should raise ValueError"  # noqa
    except ValueError:
        pass

# Generated at 2022-06-21 23:49:41.575797
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import json

    import pytest

    from sanic import Sanic

    from sanic.config import ContentType

    from sanic_test import SanicTestClient

    from .utils import get_test_config_file_path

    # Set up environment variables
    test_config_file_path = get_test_config_file_path("test.env")
    with test_config_file_path.open("r") as test_config_file:
        test_env_vars_str_dict = json.load(test_config_file)

    os_environ.update(test_env_vars_str_dict)

    # A) Test simple environment variable like ${DOMAIN_NAME}
    location = "config_string/${DOMAIN_NAME}/some_dir/some_file.py"

    # B) Test deeply nested