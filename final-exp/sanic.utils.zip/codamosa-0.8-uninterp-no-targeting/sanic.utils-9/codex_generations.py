

# Generated at 2022-06-21 23:40:31.805373
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    param = Path.home() / "some_module_name.py"

    with open(param, "w+") as config_file:
        config_file.write("some_dict = {'a': 5}")

    module = load_module_from_file_location(param)
    assert hasattr(module, "some_dict")
    assert module.some_dict == {"a": 5}

    param = Path.home() / "some_module_name.txt"

    with open(param, "w+") as config_file:
        config_file.write("some_dict = {'a': 5}")

    module = load_module_from_file_location(param)
    assert hasattr(module, "some_dict")
    assert module.some_dict == {"a": 5}


# Generated at 2022-06-21 23:40:44.051716
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import mkdtemp
    from pathlib import Path
    from os import environ
    from os.path import join
    from shutil import rmtree
    import configparser

    temp_dir = mkdtemp()

# Generated at 2022-06-21 23:40:55.395546
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    open_tmp_file = tempfile.NamedTemporaryFile(mode="w+")

    with open_tmp_file as f:
        f.write("some_var = 'some_val'")
        f.seek(0)
        some_var = load_module_from_file_location(f.name)

    assert some_var.__file__.endswith(f.name)
    assert some_var.some_var == "some_val"

    with open_tmp_file as f:
        f.write("some_var_2 = 'some_val_2'")
        f.seek(0)
        some_var_2 = load_module_from_file_location(Path(f.name))


# Generated at 2022-06-21 23:41:07.864552
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ

    from os import getcwd
    from tempfile import TemporaryDirectory

    from sanic.app_class import Sanic
    from sanic.config import Config

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    some_env_var = "SOME_ENV_VAR"
    os_environ[some_env_var] = "some_env_var"

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)

        # 1) location contains environment variables in format ${some_env_var}

        location = temp_dir / "${SOME_ENV_VAR}"

        assert type(load_module_from_file_location(location)) == Config

        # 2) location contains environment

# Generated at 2022-06-21 23:41:16.903968
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("YEP") == True
    assert str_to_bool("YUP") == True
    assert str_to_bool("T") == True


# Generated at 2022-06-21 23:41:28.361551
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import shutil
    import tempfile

    from os import environ as os_environ
    from os.path import join as os_path_join
    from importlib import reload as importlib_reload

    here = os_path_join(os_path_join(os_path_join(os_path_join(
        os_environ["VIRTUAL_ENV"],
        "lib"
    ), "python3.5"), "site-packages"), "sanic")

    correct_module_code = """
    class A:
        pass
    """
    correct_module_name = "test_module"

    with tempfile.TemporaryDirectory() as tmpdirname:
        # Create directory for module
        os.mkdir(os_path_join(tmpdirname, "test_path"))

        # Create module

# Generated at 2022-06-21 23:41:40.554974
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys

    try:
        import builtins  # Python 3
    except ImportError:
        import __builtin__ as builtins  # Python 2

    # Create a config file
    from tempfile import NamedTemporaryFile

    TEST_CONFIG_FILE_TEMPLATE = """
    TEST_CONFIG_FILE_VARIABLE = 42
    TEST_CONFIG_FILE_VARIABLE_STRING = 'A string'
    """

    with NamedTemporaryFile("w", delete=False) as f:
        f.write(TEST_CONFIG_FILE_TEMPLATE)
        TEST_CONFIG_FILE_NAME = f.name

    # Create a config file with no variables
    from tempfile import NamedTemporaryFile


# Generated at 2022-06-21 23:41:49.213483
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "some_value"

    # B) Check these variables exists in environment.
    location = "/some/path/${some_env_var}"
    location = str_to_module_name(location)
    some_module = load_module_from_file_location(location)
    assert some_module.__name__ == location
    assert some_module.__file__ == "/some/path/some_value"
    assert some_module.SOME_VALUE == "some_value"

# Generated at 2022-06-21 23:42:00.607206
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["some_env_var"] = "some_value"
    assert load_module_from_file_location(__file__) is not None
    assert load_module_from_file_location(__file__).__name__ == "sanic.helpers"
    assert load_module_from_file_location(  # noqa
        "sanic.helpers"
    ) is not None
    assert load_module_from_file_location(  # noqa
        "sanic.helpers"
    ).__name__ == "sanic.helpers"
    assert load_module_from_file_location(  # noqa
        "sanic.helpers"
    ) == load_module_from_file_location(
        __file__
    )

# Generated at 2022-06-21 23:42:09.256105
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if it loads module from file.
    mod = load_module_from_file_location("./tests/app/app_folder_structure.py")
    assert mod.route_blueprint.__name__ == (
        "tests.app.app_folder_structure.route_blueprint"
    )

    # B) Check if it loads module from file with environment variables.
    mod = load_module_from_file_location(
        "./tests/${SANIC_TEST_FILE_ENV}/app_folder_structure.py",
        encoding="utf8",
    )
    assert mod.route_blueprint.__name__ == (
        "tests.app.app_folder_structure.route_blueprint"
    )

    # C) Check if it loads module from path.
    mod

# Generated at 2022-06-21 23:42:17.825431
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("no") == False
    assert str_to_bool("False") == False
    assert str_to_bool("t") == True
    assert str_to_bool("1") == True

    try:
        assert str_to_bool("2")
    except ValueError:
        pass
    else:
        assert False, "ValueError did not raised"

# Generated at 2022-06-21 23:42:30.721227
# Unit test for function str_to_bool
def test_str_to_bool():

    # Testing valid values
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")

# Generated at 2022-06-21 23:42:40.512725
# Unit test for function str_to_bool
def test_str_to_bool():
    true_vals = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]
    false_vals = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]
    exception_vals = ["gfdghfd"]

    for val in true_vals:
        assert str_to_bool(val) is True

    for val in false_vals:
        assert str_to_bool(val) is False

    for val in exception_vals:
        try:
            str_to_bool(val)
        except ValueError:
            pass

# Generated at 2022-06-21 23:42:48.948700
# Unit test for function str_to_bool
def test_str_to_bool():
    # Test true cases
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("Yep") == True
    assert str_to_bool("YEP") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("Yup") == True
    assert str_to_bool("YUP") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("true") == True
    assert str_to

# Generated at 2022-06-21 23:43:01.354917
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool(
        "y"
    ) == True, "String 'y' should be True in this function"
    assert str_to_bool(
        "Y"
    ) == True, "String 'y' should be True in this function"
    assert str_to_bool(
        "YES"
    ) == True, "String 'y' should be True in this function"
    assert str_to_bool(
        "yes"
    ) == True, "String 'y' should be True in this function"
    assert str_to_bool(
        "yep"
    ) == True, "String 'y' should be True in this function"
    assert str_to_bool(
        "yup"
    ) == True, "String 'y' should be True in this function"
    assert str_to

# Generated at 2022-06-21 23:43:13.046658
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("True") == True
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("t") == True
    assert str_to_bool("y") == True
    assert str_to_bool("1") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("on") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("OFF") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("False") == False


# Generated at 2022-06-21 23:43:13.997395
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

# Generated at 2022-06-21 23:43:23.400389
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("YES")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert str_to_bool("YES")
    assert str_to_bool("YES")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")
    assert not str_

# Generated at 2022-06-21 23:43:34.741784
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ

    # A) Test if location parameter is of a bytes type.
    module_name = "some_file_name"
    path = Path(__file__)
    location = (path.parent / f"{module_name}.py").absolute()

    module = load_module_from_file_location(location.encode())
    assert module.__name__ == module_name

    # B) Test if location parameter is of enum str and Path type.
    module = load_module_from_file_location(location)
    assert module.__name__ == module_name

    # C) Test if environment variable substitution works.
    environ["TEST_ENV_VAR"] = "{some_value}"

# Generated at 2022-06-21 23:43:45.726471
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Tests load_module_from_file_location. Mocked os.environ and Path
    objects.
    """

    from mock import patch
    from os import environ

    from tests.conftest import new_temp_file


# Generated at 2022-06-21 23:43:54.650358
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("y")
    assert str_to_bool("YES")
    assert str_to_bool("True")
    assert str_to_bool("true")
    assert str_to_bool("1")

    assert not str_to_bool("no")
    assert not str_to_bool("n")
    assert not str_to_bool("NO")
    assert not str_to_bool("False")
    assert not str_to_bool("false")
    assert not str_to_bool("0")

    try:
        str_to_bool("may be")
    except ValueError:
        pass
    else:
        raise AssertionError("ValueError was not raised")

# Generated at 2022-06-21 23:44:06.329773
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("TruE") is True
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("YeS") is True
    assert str_to_bool("on") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("1") is True
    assert str_to_bool("false") is False
    assert str_to_bool("fAlse") is False
    assert str_to_bool("n") is False
    assert str_to_bool("N") is False
    assert str_to_bool("no") is False

# Generated at 2022-06-21 23:44:15.074307
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test function to check if load_module_from_file_location will do what it
    should do.

    1) Checks if the function can load importable modules by import string.
    2) Checks if we can load file without .py extension.
    3) Checks if we can load file with .py extension.
    4) Checks if we can load file by using environment variables.
    5) Checks if the function will raise exception if environment variable is
       not defined.
    """

    # 1)
    # Load module by import string
    mod_str = "sanic.app"
    mod_loaded_by_str = load_module_from_file_location(mod_str)
    assert (
        mod_loaded_by_str == imports.import_module("sanic.app")
    ), "Import string functionality is broken"

    #

# Generated at 2022-06-21 23:44:22.543967
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("On") is True
    assert str_to_bool("off") is False

# Generated at 2022-06-21 23:44:29.637101
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('y') == True
    assert str_to_bool('n') == False
    assert str_to_bool('True') == True
    assert str_to_bool('False') == False
    assert str_to_bool('yes') == True
    assert str_to_bool('no') == False
    assert str_to_bool('on') == True
    assert str_to_bool('off') == False
    assert str_to_bool('0') == False
    assert str_to_bool('1') == True
    with pytest.raises(ValueError):
        assert str_to_bool('2') == True

# Generated at 2022-06-21 23:44:36.311236
# Unit test for function str_to_bool
def test_str_to_bool():
    # True
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    # False
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool

# Generated at 2022-06-21 23:44:47.737658
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Tests function load_module_from_file_location.

    :return: Boolean that confirms if test passed.
    """

    # A) Load file with just some variables and functions.
    just_variables = load_module_from_file_location("tests/files/just_variables.py")
    assert just_variables.var1 == 1
    assert just_variables.var2 == "2"
    assert just_variables.var3 == [1, 2, 3]
    assert just_variables.func1() == "1"
    assert just_variables.func2() == "2"

    # B) Load file with environment variables in path.
    os_environ["ENV_VAR_B"] = "env_var_b"

# Generated at 2022-06-21 23:44:53.687554
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    os.environ["SOME_ENV_VAR"] = "some_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${SOME_ENV_VAR}"
    )
    del os.environ["SOME_ENV_VAR"]
    assert module.__name__ == "some_module_name"

# Generated at 2022-06-21 23:45:07.146717
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-21 23:45:20.266407
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True

    assert str_to_bool("false") is False
    assert str_to_bool("False") is False

    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("YES") is True

    assert str_to_bool("n") is False
    assert str_to_bool("N") is False
    assert str_to_bool("No") is False
    assert str_to_bool("NO") is False

    assert str_to_bool("1") is True
    assert str_to_bool("0") is False

    assert str_to_bool("t") is True
    assert str_

# Generated at 2022-06-21 23:45:32.108392
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest

    location = Path(__file__).parent.parent.resolve()
    assert location == Path(
        load_module_from_file_location(location).__file__
    ).parent.parent.resolve()

    location2 = str(location)
    assert location2 == Path(
        load_module_from_file_location(location2).__file__
    ).parent.parent.resolve()

    location3 = location.as_uri()
    assert location3 == Path(
        load_module_from_file_location(location3).__file__
    ).parent.parent.resolve()

    os_environ["test"] = "test"
    location4 = "test/${test}"

# Generated at 2022-06-21 23:45:43.838455
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import os

    os.environ["env_var"] = "some_value"
    assert load_module_from_file_location(__file__) is sys.modules[__name__]

    config_file_location = __file__.replace(".py", "") + ".config.py"
    config_module = load_module_from_file_location(config_file_location)
    assert config_module.some_property == "some_value"

    config_file_location = __file__.replace(".py", "") + ".config.py"
    config_file_location = config_file_location.replace(__file__, "${PWD}")
    config_module = load_module_from_file_location(config_file_location)

# Generated at 2022-06-21 23:45:47.460753
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = Path(__file__).parent.parent / "test_app.py"
    location = str(location)
    module = load_module_from_file_location(location)
    assert module.get_text() == "true"

# Generated at 2022-06-21 23:45:55.273373
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test load module from a string path
    location = "tests/stuff.py"
    module = load_module_from_file_location(location)
    assert module.var == "stuff"

    # Test it works with environment variables in the path
    location = "tests/${PWD}/stuff.py"
    os_environ["PWD"] = str(Path("tests"))
    module = load_module_from_file_location(location)
    assert module.var == "stuff"

    # Test it works with non ascii files
    location = "tests/кириллица.py"
    module = load_module_from_file_location(location)
    assert module.var == "кириллица"

    # Test it works with non ascii files and environment variables

# Generated at 2022-06-21 23:46:07.466787
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("on") == True
    assert str_to_bool("true") == True
    assert str_to_bool("off") == False
    assert str_to_bool("false") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("y") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("n") == False
    assert str_to_bool("nope") == False
    assert str_to_bool("no") == False
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("f") == False
   

# Generated at 2022-06-21 23:46:19.802644
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y")
    assert str_to_bool("y")
    assert str_to_bool("YES")
    assert str_to_bool("yEs")
    assert str_to_bool("yES")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("1")
    assert str_to_bool("on")
    assert str_to_bool("On")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("TRUE")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")

    assert not str_to_bool("N")
    assert not str_to

# Generated at 2022-06-21 23:46:22.709861
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "tests/test_utils/test_config.py"
    mod = load_module_from_file_location(location)
    assert isinstance(mod, types.ModuleType)
    assert mod.SOME_CONFIG_VAR == "SOME_VALUE"

# Generated at 2022-06-21 23:46:34.204179
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ, getcwd
    from shutil import rmtree
    from tempfile import mkdtemp

    def _random_string(length: int = 8) -> str:
        import random
        import string
        return "".join(
            random.choice(string.ascii_uppercase + string.digits)
            for _ in range(length)
        )

    # Make a fake project with a config
    with open("config.py", "w+") as cfg_file:
        cfg_file.write("SOME_URL = 'http://127.0.0.1:8000/'\n")

    # Test load_module_from_file_location based on current directory
    config_module = load_module_from_file_location("config")
    assert config_module.SOME_URL

# Generated at 2022-06-21 23:46:44.256270
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("tests/files/test_config.py")
    assert type(module) == types.ModuleType
    assert type(module.test_config) == dict
    assert module.test_config["param"] == 1
    assert module.test_config["param_str"] == "string"

    module = load_module_from_file_location("tests/files/test_config")
    assert type(module) == types.ModuleType
    assert type(module.test_config) == dict
    assert module.test_config["param"] == 1
    assert module.test_config["param_str"] == "string"

    module = load_module_from_file_location(
        Path("tests/files/test_config")
    )  # type: ignore

# Generated at 2022-06-21 23:46:52.994565
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        os_environ["some_env_var"] = "."
    except KeyError:
        os_environ["some_env_var"] = "."
        to_remove = True
    else:
        to_remove = False

    location = "./$some_env_var/test_location"
    module = load_module_from_file_location(location)

    assert module.__file__ == location

    if to_remove:
        del os_environ["some_env_var"]

# Generated at 2022-06-21 23:46:59.640267
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["some_env_var"] = "works"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    assert module.__name__ == "some_module_name"

# Generated at 2022-06-21 23:47:11.949270
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("true")
    assert not str_to_bool("false")
    assert str_to_bool("on")
    assert str_to_bool("off")
    assert str_to_bool("yes")
    assert str_to_bool("no")
    assert str_to_bool("y")
    assert str_to_bool("n")
    assert str_to_bool("1")
    assert not str_to_bool("0")
    assert str_to_bool("yep")
    assert str_to_bool("no")
    assert str_to_bool("yup")
    assert str_to_bool("disable")
    assert str_to_bool("enabled")
    assert str_to_bool("enable")
    assert not str_to_bool("disable")

# Generated at 2022-06-21 23:47:23.554715
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True

    assert str_to_bool("True") is True

    assert str_to_bool("TRUE") is True

    assert str_to_bool("yes") is True

    assert str_to_bool("Yes") is True

    assert str_to_bool("YES") is True

    assert str_to_bool("y") is True

    assert str_to_bool("Y") is True

    assert str_to_bool("yep") is True

    assert str_to_bool("Yep") is True

    assert str_to_bool("YEP") is True

    assert str_to_bool("yup") is True

    assert str_to_bool("Yup") is True

    assert str_to_bool("YUP") is True


# Generated at 2022-06-21 23:47:35.068129
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from subprocess import check_call  # nosec
    from tempfile import TemporaryDirectory


# Generated at 2022-06-21 23:47:43.411960
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    assert load_module_from_file_location("test_config")
    assert load_module_from_file_location("./test_config")
    assert load_module_from_file_location("./test_config.py")
    path = Path(__file__).parent / "test_config.py"
    assert load_module_from_file_location(path)
    assert load_module_from_file_location(str(path))
    assert load_module_from_file_location(b"test_config")
    assert load_module_from_file_location(b"./test_config")
    assert load_module_from_file_location(b"./test_config.py")
    assert load_module_from_file_location(bytes(str(path), "utf8"))

# Generated at 2022-06-21 23:47:55.510786
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests that function load_module_from_file_location
    correctly loads module from file and sets global variables.

    Loading modules is tested also in other tests, this one
    is just example how it can be tested.
    """
    import pytest
    import types
    import tempfile

    # Create temporary file with config
    _, config_file = tempfile.mkstemp(".py")

# Generated at 2022-06-21 23:48:03.545210
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('f') == False
    assert str_to_bool('off') == False
    assert str_to_bool('false') == False
    assert str_to_bool('yes') == True
    assert str_to_bool('t') == True
    assert str_to_bool('y') == True
    assert str_to_bool('1') == True

# Generated at 2022-06-21 23:48:13.431204
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("1") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:48:25.552930
# Unit test for function load_module_from_file_location

# Generated at 2022-06-21 23:48:37.952503
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # nopytypes
    try:
        load_module_from_file_location("${some_env_var}")
    except LoadFileException:
        pass

    try:
        load_module_from_file_location("${some_env_var}", "some_lp_arg")
    except LoadFileException:
        pass

    try:
        load_module_from_file_location("${some_env_var}", "some_lp_arg", "some_lp_kwarg")
    except LoadFileException:
        pass

    os_environ["some_env_var"] = "some_env_var"
    assert load_module_from_file_location("${some_env_var}")["some_env_var"]

# Generated at 2022-06-21 23:48:50.891390
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import io

    import pytest

    from .utils import TEST_DIR
    from tests.utils import SANIC_SERVER

    os_environ["SANIC_CONF_LOCATION"] = str(TEST_DIR / "some_config.py")
    os_environ["SANIC_CONF_VALUE"] = "5"

    with pytest.raises(PyFileError):
        load_module_from_file_location(
            str(TEST_DIR / "some_config_bad_syntax.py")
        )

    with pytest.raises(IOError):
        load_module_from_file_location(str(TEST_DIR / "some_config_not_existing"))

    with pytest.raises(Exception):
        load_module_from_file_location(SANIC_SERVER)

   

# Generated at 2022-06-21 23:48:58.645904
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ
    from random import randint

    def write_module(location: str, name: str, value: str):
        with open(location, "w") as f:
            f.write(f"{name} = '{value}'")

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / "tmp_module.py"
        name = "some_non_existent_env_var"
        value = "some_value"
        os_environ[name] = value
        write_module(tmp_file, name, value)

        loaded_module = load_module_from_file_location(tmp_file)
        assert loaded_module.some_non_existent_env

# Generated at 2022-06-21 23:49:09.609715
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    def check_content(module: types.ModuleType, test_data):
        assert "_meta_data" in module.__dict__
        assert "_meta_data" in test_data
        for _key in module.__dict__:
            if _key.startswith("_"):
                continue
            assert _key in test_data
            assert test_data[_key] == module.__dict__[_key]


# Generated at 2022-06-21 23:49:22.650614
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from os import makedirs, environ
    from sys import path as sys_path
    from tempfile import mkdtemp
    from shutil import rmtree

    from nose.tools import *

    # log.setLevel(10)

    # Logger for unit test
    # unit_test_log = logging.getLogger('unit test')

    # Creating temporary directory for testing purposes
    temp_dir = mkdtemp(prefix="sanic_test_load_module_from_file_location_")
    # Path to temp directory
    temp_path = Path(temp_dir)
    # Add temp_path to PYTHONPATH
    sys_path.append(str(temp_path))
    # Create test files
    # test_file.py

# Generated at 2022-06-21 23:49:35.468738
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ as os_environ

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.

    location_1 = "path/to/${some_env_var}/my_module_name"
    assert set(re_findall(r"\${(.+?)}", location_1)) == {"some_env_var"}

    # B) Check these variables exists in environment.

    not_defined_env_vars_1 = set(re_findall(r"\${(.+?)}", location_1)).difference(
        os_environ.keys()
    )
    assert not_defined_env_vars_1 != set()


# Generated at 2022-06-21 23:49:39.842497
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("true")
    assert str_to_bool("enable")
    assert str_to_bool("On")

    assert not str_to_bool("No")
    assert not str_to_bool("false")
    assert not str_to_bool("disable")
    assert not str_to_bool("Off")

# Generated at 2022-06-21 23:49:46.374339
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""

    module = load_module_from_file_location("tests/test_config.py")
    assert module.TEST_VAR == "test_value"

    module = load_module_from_file_location("tests/test_config.pyc")
    assert module.TEST_VAR == "test_value"

    module = load_module_from_file_location("tests/test_config.json")
    assert module.TEST_VAR == "test_value"

    module = load_module_from_file_location("tests/test_config.yaml")
    assert module.TEST_VAR == "test_value"

    module = load_module_from_file_location("tests/test_config.yml")

# Generated at 2022-06-21 23:49:57.461486
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SOME_ENV_VAR"] = "/etc/some_config_folder"
    current_dir = Path(__file__).parent.resolve()

    module = load_module_from_file_location(
        "some_module_name", current_dir.joinpath("config.py")
    )
    assert module.LOGO == "SANIC"
    assert module.WORKERS == 3

    module = load_module_from_file_location(
        "some_module_name", current_dir.joinpath("config.py"), "r"
    )
    assert module.LOGO == "SANIC"
    assert module.WORKERS == 3


# Generated at 2022-06-21 23:50:06.033097
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-21 23:50:15.584244
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D103
    module = load_module_from_file_location(
        f"{Path(__file__).absolute().parent}/test_module.py"
    )
    assert module.__name__ == "test_module"
    assert module.test_var == "123"
    assert module.test_func() == 456

    module = load_module_from_file_location(
        f"{Path(__file__).absolute().parent}/test_module"
    )
    assert module.__name__ == "config"
    assert module.test_var == "123"
    assert module.test_func() == 456