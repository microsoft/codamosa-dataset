

# Generated at 2022-06-21 23:40:25.124805
# Unit test for function str_to_bool
def test_str_to_bool(): # noqa
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("N") is False
    assert str_to_bool("NO") is False


# Generated at 2022-06-21 23:40:35.873462
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    from tempfile import NamedTemporaryFile

    from sanic.exceptions import LoadFileException, PyFileError

    # Check if it returns module if location is of a string type and
    # contains just a module name.
    config_module = load_module_from_file_location("pathlib")
    assert isinstance(config_module, types.ModuleType)

    # Check if it raises PyFileError if location is of a string type and
    # contains a file name.
    try:
        load_module_from_file_location("os")
    except PyFileError:
        pass
    else:
        raise AssertionError(
            "load_module_from_file_location function"
            + " didn't raise PyFileError"
        )

    # Check if it returns module if location is of a Path

# Generated at 2022-06-21 23:40:42.560792
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    pytest.importorskip("pipenv")
    from pipenv._compat import TemporaryDirectory

    from .constants import TEST_PYTHON_FILE_VALUES_CONTENT

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)

        values_file = temp_dir / "values.py"
        values_file.write_text(TEST_PYTHON_FILE_VALUES_CONTENT)
        values_module = load_module_from_file_location(values_file)

        assert values_module.TEST_VAL == 6
        assert values_module.TEST_TUP == (1, 2, 3)

        values_module = load_module_from_file_location(str(values_file))

        assert values_module.TEST_

# Generated at 2022-06-21 23:40:53.154146
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("TruE") == True
    assert str_to_bool("TrUe") == True
    assert str_to_bool("TRuE") == True
    assert str_to_bool("t") == True
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("on") == True
    assert str_to_bool("1") == True

# Generated at 2022-06-21 23:41:04.632416
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    # Create a config file as a contextmanager
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmp_file = tmpdir / "config.py"
        tmp_file.touch()

        # Create a module from context file
        module = load_module_from_file_location(tmp_file)
        # Check if module is loaded
        assert "config" in module.__file__

        # Replace it with an invalid file
        tmp_file.unlink()
        tmp_file.touch()
        with pytest.raises(PyFileError):
            module = load_module_from_file_location(tmp_file)


# Generated at 2022-06-21 23:41:15.909658
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_path = "tests/test_config.py"
    module = load_module_from_file_location(module_path)
    assert module.TEST_DICT == {1: 2, 2: 3}
    assert module.TEST_LIST == [1, 2, 3]
    assert module.TEST_VAR == "test"
    module_path = "tests/test_bad_config.py"
    module = load_module_from_file_location(module_path)
    assert module.TEST_DICT == {1: 2, 2: 3}
    assert module.TEST_LIST == [1, 2, 3]
    assert module.TEST_VAR == "test"
    module_path = "tests/test_bad_config.py"

# Generated at 2022-06-21 23:41:24.202180
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    result_bool = (
        str_to_bool("yes")
        and str_to_bool("true")
        and str_to_bool("1")
        and str_to_bool("1")
        and not str_to_bool("no")
        and not str_to_bool("false")
        and not str_to_bool("0")
    )
    assert result_bool, "str_to_bool failed!"

# Generated at 2022-06-21 23:41:37.371388
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest

    with pytest.raises(IOError) as e:
        load_module_from_file_location(
            "~/somewhere/over_the/rainbow", "/some/path/${some_env_var}"
        )
    assert (
        str(e.value)
        == "Unable to load configuration file "
        "(Unable to load configuration ~/somewhere/over_the/rainbow)"
    )

    with pytest.raises(LoadFileException) as e:
        load_module_from_file_location(
            "~/somewhere/over_the/rainbow", "/some/path/${some_env_var}"
        )

# Generated at 2022-06-21 23:41:44.934701
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("1")
    assert str_to_bool("true")
    assert str_to_bool("Yes")
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("on")
    assert str_to_bool("ON")
    assert str_to_bool("Ok") == ValueError

# Generated at 2022-06-21 23:41:58.270459
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_string_original = import_string

    import_string = lambda x: x  # noqa
    assert isinstance(
        load_module_from_file_location("asdf"), str
    ), "load_module_from_file_location should return a string when string input"

    import_string = lambda x: x  # noqa
    assert isinstance(
        load_module_from_file_location(Path("asdf")), Path
    ), "load_module_from_file_location should return a Path when Path input"

    import_string = lambda x: x  # noqa
    assert isinstance(
        load_module_from_file_location(b"asdf"), str
    ), "load_module_from_file_location should return a string when bytes input"

    import_string = lambda x: x  # no

# Generated at 2022-06-21 23:42:09.336662
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("on") == True
    assert str_to_bool("1") == True

    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("Off") == False
    assert str_to_bool("0") == False

    try:
        str_to_bool("maybe")
    except ValueError as e:
        assert "Invalid truth value" in str(e)



# Generated at 2022-06-21 23:42:20.115209
# Unit test for function str_to_bool
def test_str_to_bool():
    # from helpers import str_to_bool
    assert str_to_bool("yes") is True
    assert str_to_bool("true") is True
    assert str_to_bool("T") is True
    assert str_to_bool("y") is True
    assert str_to_bool("1") is True
    assert str_to_bool("on") is True
    assert str_to_bool("Yo") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("YeP") is True
    assert str_to_bool("TrUE") is True
    assert str_to_bool("tu") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("0") is False
    assert str

# Generated at 2022-06-21 23:42:26.792890
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("false") is False
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("n") is False

# Generated at 2022-06-21 23:42:30.488477
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1")
    assert str_to_bool("yes")
    assert not str_to_bool("0")
    assert not str_to_bool("no")
    assert not str_to_bool("false")
    assert str_to_bool("True")



# Generated at 2022-06-21 23:42:40.085040
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover
    from os import getcwd
    from pathlib import Path
    from tempfile import TemporaryDirectory

    import pytest

    from sanity_server.server import load_module_from_file_location
    from sanity_server.helpers import import_string

    with TemporaryDirectory() as tempdir:

        # A) Create errorneous file config_error.py
        with open(Path(tempdir) / "config_error.py", "w") as file:
            file.write("bad = int('asd')")

        # B) Create valid file config_valid.py
        with open(Path(tempdir) / "config_valid.py", "w") as file:
            file.write("valid = 20")

        # C) Check if str_to_bool raises exceptions as it should

# Generated at 2022-06-21 23:42:52.162282
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    # test data
    strings_that_should_be_converted_to_true = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]
    strings_that_should_be_converted_to_false = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]
    for test_string in strings_that_should_be_converted_to_true:
        assert str_to_bool(test_string)

# Generated at 2022-06-21 23:43:02.948433
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False

# Generated at 2022-06-21 23:43:13.772690
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["ENV_VAR_1"] = "env_var_1"
    import shutil
    import tempfile
    import os
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    location = tempfile.mkdtemp(
        dir=os.path.join(os.getcwd(), "tests"),
        prefix="test_load_module_from_file_location",
    )
    # location = 'file:///usr/local/python/lib/python3.7/site-packages/sanic_openapi'
    # location = 'file:///Users/pf/Documents/Python/Sanic/sanic/sanic'
    # location = 'file:///Users/pf/Documents/Python/Sanic/sanic/sanic/helpers.

# Generated at 2022-06-21 23:43:23.246806
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("Y") is True
    assert str_to_bool("N") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("YES") is True
    assert str_to_bool("NO") is False
    assert str_to_bool("yep") is True
    assert str_to_bool("nope") is False
    assert str_to_bool("YEP") is True
    assert str_to_bool("NOPE") is False
    assert str_to_bool("yup") is True
    assert str_to_bool("nup") is False
    assert str_to_bool("YUP")

# Generated at 2022-06-21 23:43:34.704242
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_ENV_VARIABLE"] = "test_env_var_value"
    # A) Test usage with Path argument
    module = load_module_from_file_location(
        Path("./test/test_utils/_test_config.py")
    )
    assert module.TEST_CONFIG_VARIABLE == "test_config_value"

    # B) Test usage with string argument
    module = load_module_from_file_location(
        "./test/test_utils/_test_config.py"
    )
    assert module.TEST_CONFIG_VARIABLE == "test_config_value"

    # C) Test usage with string argument and environment variables.

# Generated at 2022-06-21 23:43:46.794225
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # intialize environment variable
    os_environ["some_env_var"] = "/some/path/"

    # relative path
    module = load_module_from_file_location("server.py")
    assert module.__name__ == "server"

    # absolute path
    module = load_module_from_file_location("/home/me/server.py")
    assert module.__name__ == "server"

    # path with environment variable
    module = load_module_from_file_location(
        "/home/${some_env_var}/server.py"
    )
    assert module.__name__ == "server"

    # path with environment variable, using Path object

# Generated at 2022-06-21 23:43:57.026252
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sanic.config
    import pytest

    config_file = Path(__file__).resolve().parent / "test_load_module_from_file_location.py"
    config = load_module_from_file_location(
        config_file, encoding="utf-8"
    )
    assert config.a == "1"
    assert config.b == "2"
    assert config.c == "3"

    # only_file_name
    config_file = Path(__file__).resolve().parent / "test_load_module_from_file_location.py"
    config = load_module_from_file_location(config_file.name, encoding="utf-8")
    assert config.a == "1"
    assert config.b == "2"
    assert config.c == "3"



# Generated at 2022-06-21 23:44:07.654917
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("true") is True
    assert str_to_bool("t") is True
    assert str_to_bool("T") is True
    assert str_to_bool("1") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("ye") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("on") is True

    assert str_to_bool("False") is False
    assert str_to_bool("false") is False
    assert str_to_bool("f") is False
    assert str_to_bool("F") is False
    assert str

# Generated at 2022-06-21 23:44:14.548752
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") == True
    assert str_to_bool("True") == True
    assert str_to_bool("y") == True
    assert str_to_bool("1") == True
    assert str_to_bool("f") == False
    assert str_to_bool("False") == False
    assert str_to_bool("n") == False
    assert str_to_bool("0") == False
    assert str_to_bool("0") == False
    try:
        str_to_bool("bob")
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-21 23:44:26.983319
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    test_config_path = "tests/test_configs/test_config_load_module_from_file_location.py"  # noqa
    test_config = load_module_from_file_location(test_config_path)
    test_values = (
        (test_config.CONFIG_PROPERTY, "config value"),
        (test_config.CONFIG_PROPERTY_FROM_PATH, "config value from actual path"),  # noqa
        (test_config.CONFIG_PROPERTY_FROM_ENV_VAR, "test_value"),
    )
    for (test_value, correct_value) in test_values:
        assert test_value == correct_value

# Generated at 2022-06-21 23:44:35.375918
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool('True') is True
    assert str_to_bool('TRUE') is True
    assert str_to_bool('true') is True
    assert str_to_bool('On') is True
    assert str_to_bool('ON') is True
    assert str_to_bool('on') is True
    assert str_to_bool('t') is True
    assert str_to_bool('T') is True
    assert str_to_bool('Yes') is True
    assert str_to_bool('YES') is True
    assert str_to_bool('yes') is True
    assert str_to_bool('Y') is True
    assert str_to_bool('y') is True
    assert str_to_bool('1') is True
    assert str_to_bool('False') is False

# Generated at 2022-06-21 23:44:47.365419
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import path, environ as os_environ

    test_env_var = "UNITTEST_ENV_VAR"
    test_env_var_value = "some_unittest_value_1234"
    os_environ[test_env_var] = test_env_var_value
    test_file_fname = "unittest_config_file.py"
    test_file_path = path.join(path.dirname(path.abspath(__file__)), test_file_fname)
    test_config = load_module_from_file_location(test_file_path)

    assert test_config.test_param == "some_param_value"

# Generated at 2022-06-21 23:44:50.742455
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") is True
    assert str_to_bool("f") is False
    try:
        assert str_to_bool("2")
    except ValueError:
        pass
    else:
        assert False, "Should raise ValueError when str_to_bool('2')!"

# Generated at 2022-06-21 23:44:59.585136
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") == True, "assertion failed. 'Y' should True"
    assert str_to_bool("Yes") == True, "assertion failed. 'Yes' should True"
    assert str_to_bool("TrUe") == True, "assertion failed. 'TrUe' should True"
    assert str_to_bool("oN") == True, "assertion failed. 'oN' should True"
    assert str_to_bool("EnaBle") == True, "assertion failed. 'EnaBle' should True"
    assert str_to_bool("1") == True, "assertion failed. '1' should True"
    assert str_to_bool("N") == False, "assertion failed. 'N' should False"

# Generated at 2022-06-21 23:45:07.202525
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import json

    # Make sure it works
    os_environ["SANIC_TEST_ENV_VAR_1"] = "test_value_1"
    os_environ["SANIC_TEST_ENV_VAR_2"] = "test_value_2"
    module = load_module_from_file_location(
        "${SANIC_TEST_ENV_VAR_1}",
        "${SANIC_TEST_ENV_VAR_2}",
    )
    assert module.__file__ == "test_value_2"

    # Make sure it raises when environment variables are not set
    del os_environ["SANIC_TEST_ENV_VAR_1"]
    del os_environ["SANIC_TEST_ENV_VAR_2"]

# Generated at 2022-06-21 23:45:22.016123
# Unit test for function str_to_bool
def test_str_to_bool():
    assert(str_to_bool("t") is True)
    assert(str_to_bool("true") is True)
    assert(str_to_bool("TRUE") is True)
    assert(str_to_bool("T") is True)

    assert(str_to_bool("f") is False)
    assert(str_to_bool("false") is False)
    assert(str_to_bool("FALSE") is False)
    assert(str_to_bool("F") is False)

    assert(str_to_bool("1") is True)
    assert(str_to_bool("0") is False)

    assert(str_to_bool("on") is True)
    assert(str_to_bool("off") is False)

    assert(str_to_bool("y") is True)

# Generated at 2022-06-21 23:45:32.140957
# Unit test for function str_to_bool
def test_str_to_bool():
    # If True
    assert str_to_bool("y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("yeP") is True
    assert str_to_bool("yU") is True
    assert str_to_bool("T") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enABLE") is True
    assert str_to_bool("enABLed") is True
    assert str_to_bool("1") is True
    # If False
    assert str_to_bool("n") is False
    assert str_to_bool("N") is False
    assert str_to_bool("NO") is False
    assert str_to_bool("f") is False

# Generated at 2022-06-21 23:45:43.839882
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location(__file__, "utf8").__file__
    ) == __file__
    assert (
        load_module_from_file_location(
            Path("configs/config.yml"), "utf8"
        ).__file__
        == str(Path("configs/config.yml"))
    )
    os_environ["CONFIGS_PATH"] = str(Path("configs/config.yml").parent)
    assert (
        load_module_from_file_location(
            Path("${CONFIGS_PATH}/config.yml"), "utf8"
        ).__file__
        == str(Path("${CONFIGS_PATH}/config.yml"))
    )

# Generated at 2022-06-21 23:45:53.524667
# Unit test for function str_to_bool

# Generated at 2022-06-21 23:46:05.058532
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("Y")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("1")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert not str_to_bool("n")
    assert not str_to_bool("N")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str

# Generated at 2022-06-21 23:46:17.809794
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_ENV_VAR"] = "test_env_var_value"

    module_from_location_1 = load_module_from_file_location(
        "/some/path/with/module.py"
    )
    assert module_from_location_1.ARG1 == "ARG1"

    module_from_location_1 = load_module_from_file_location(
        "/some/path/with/module.py", raise_errors=True
    )
    assert module_from_location_1.ARG1 == "ARG1"

    module_from_location_2 = load_module_from_file_location(
        "./tests/test_utils/data/module.py"
    )

# Generated at 2022-06-21 23:46:29.501186
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:46:40.033925
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests load_module_from_file_location function."""
    assert_raises = pytest.raises(
        LoadFileException, match="The following environment variables are not set"
    )

    with pytest.raises(IOError, match="Unable to load configuration %s" % str("./")):
        load_module_from_file_location("./")

    with pytest.raises(
        IOError, match="Unable to load configuration %s" % str("some_module_name")
    ):
        load_module_from_file_location("some_module_name")

    # Test environment variables in format ${some_var}
    with assert_raises:
        load_module_from_file_location("some_module_name", "/some/path/${some_env_var}")



# Generated at 2022-06-21 23:46:47.692382
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:46:58.401377
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic import Sanic
    from sanic.config import LOGGING

    # A) Check if location is a string
    def _assert_(s: str, condition: bool) -> None:
        assert condition, "{} is not a string".format(s)

    _assert_(
        "location",
        isinstance(load_module_from_file_location("location"), Sanic),
    )
    _assert_(
        b"location",
        isinstance(
            load_module_from_file_location(b"location", encoding="utf8"), Sanic
        ),
    )
    _assert_(
        Path("location"),
        isinstance(
            load_module_from_file_location(Path("location")), Sanic  # type: ignore
        ),
    )

# Generated at 2022-06-21 23:47:12.815901
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False

# Generated at 2022-06-21 23:47:24.344656
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = Path(__file__).parent / "test_config.py"
    try:
        module = load_module_from_file_location(location)
    except Exception as e:
        raise e

    assert module.TEST_CONFIG_VALUE == 1
    assert module.TEST_CONFIG_VALUE2 == 2
    assert module.TEST_CONFIG_VALUE3 == {
        "TEST_KEY1": 2,
        "TEST_KEY2": 3
    }

    with open(location) as f:
        data = f.read()
    assert data in module.__doc__

    # Not str, not bytes, not Path
    with pytest.raises(LoadFileException):
        load_module_from_file_location(5)
    # With non-existent variable

# Generated at 2022-06-21 23:47:35.961232
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from random import choice, randint
    from string import ascii_lowercase
    from tempfile import mkdtemp
    from os import path

    abspath = path.abspath(path.dirname(__file__))
    f_path = path.join(abspath, "sample_files", "test_load_file.py")

    test_spec_from_file_location_args = ("mod", f_path, False, "UTF-8")
    test_spec_from_file_location_kwargs = {"submodule_search_locations": None}


# Generated at 2022-06-21 23:47:49.576188
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    """ Unit test for function load_module_from_file_location.
    """

    def compare_config(config_a, config_b):
        assert (
            set(config_a.keys()) == set(config_b.keys())
        ), "Config keys mismatch"
        for key, value in config_a.items():
            assert (
                config_b[key] == value
            ), "Config values mismatch for key " + str(key)

    # 1. Define some .py module contents

# Generated at 2022-06-21 23:47:56.077354
# Unit test for function str_to_bool
def test_str_to_bool():
    with pytest.raises(ValueError):
        str_to_bool("test_value")
    assert str_to_bool("T") == True
    assert str_to_bool("true") == True
    assert str_to_bool("1") == True
    assert str_to_bool("N") == False
    assert str_to_bool("f") == False
    assert str_to_bool("0") == False

# Generated at 2022-06-21 23:48:09.383830
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil
    from os.path import join, dirname, abspath

    # Create temporary directory to store some files.
    tmp_path = tempfile.mkdtemp()

    # Create some file with ".py" extension.
    py_file = join(tmp_path, "py_file.py")
    with open(py_file, "w") as f:
        f.write("foo = 'bar'")

    # Create some file without ".py" extension.
    no_ext_file = join(tmp_path, "no_ext_file")
    with open(no_ext_file, "w") as f:
        f.write("foo = 'bar'")

    # Create some file with ".py" extension.

# Generated at 2022-06-21 23:48:20.339615
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    path = os_environ.get("HOME")

    # Check functionality using .py file
    some_module = load_module_from_file_location(
        path + "/repos/sanic/sanic/sanic/log.py"
    )
    assert hasattr(some_module, "app_log")

    # Check functionality using .json file
    some_module = load_module_from_file_location(
        path + "/repos/sanic/sanic/examples/async_demo/config.json"
    )
    assert hasattr(some_module, "FOO")

    # Check if errors raised properly
    # A) Error caused by not finding file

# Generated at 2022-06-21 23:48:28.135558
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile(delete=False) as temp_file:
        temp_file.write(b"#!/usr/bin/env python\n")
        temp_file.write(b"import sys\n")
        temp_file.write(b"1/0")

    try:
        load_module_from_file_location(temp_file.name)
    except PyFileError:
        pass
    else:
        assert (
            False
        ), "PyFileError should be raised if we try to load module with exception"

    # test if pathlib path is loaded
    module = load_module_from_file_location(Path(temp_file.name))
    assert module.__name__ == "config"

    # test if ${env_var} will be substituted
    os_

# Generated at 2022-06-21 23:48:39.278994
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("YeP") == True
    assert str_to_bool("YeUp") == True
    assert str_to_bool("T") == True
    assert str_to_bool("TrUE") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("1") == True

    assert str_to_bool("N") == False
    assert str_to_bool("No") == False
    assert str_to_bool("F") == False
    assert str_to_bool("False") == False
    assert str_to_bool("FALSE") == False
    assert str_to_bool("off") == False


# Generated at 2022-06-21 23:48:43.964936
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Yes") == True
    assert str_to_bool("NO") == False
    assert str_to_bool("True") == True
    assert str_to_bool("m") == False

# Generated at 2022-06-21 23:48:57.029487
# Unit test for function str_to_bool
def test_str_to_bool():
    # Case insensitive test
    assert str_to_bool("t") == str_to_bool("T") == str_to_bool("true") == str_to_bool(
        "TRUE"
    ) is True
    assert str_to_bool("f") == str_to_bool("F") == str_to_bool("false") == str_to_bool(
        "FALSE"
    ) is False
    assert str_to_bool("y") == str_to_bool("Y") == str_to_bool("yes") == str_to_bool(
        "YES"
    ) is True
    assert str_to_bool("n") == str_to_bool("N") == str_to_bool("no") == str_to_bool(
        "NO"
    ) is False

    # Whitespace test
   

# Generated at 2022-06-21 23:49:08.610588
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Testing function load_module_from_file_location."""
    import pytest
    import os

    env_var_key = "test_env_var"
    env_var_val = "test_env_var_val"
    env_var_val2 = "test_env_var_val2"

    # A) Check if environment variable is empty.
    with pytest.raises(
        LoadFileException,
        match="The following environment variables are not set: ",
    ):
        load_module_from_file_location(f"${env_var_key}/some_file.py")

    # B) Check if environment variable is not empty.
    os.environ[env_var_key] = env_var_val

# Generated at 2022-06-21 23:49:22.177763
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("TrUe") == True
    assert str_to_bool("YeP") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("On") == True
    assert str_to_bool("1") == True
    assert str_to_bool("Enable") == True
    assert str_to_bool("Enabled") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True


# Generated at 2022-06-21 23:49:33.563056
# Unit test for function str_to_bool
def test_str_to_bool():
    # Test True cases:
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("1") is True

    # Test False cases:
    assert str_to_bool("no") is False
    assert str_to_bool("n") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("0") is False


# Generated at 2022-06-21 23:49:43.379361
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("True") == True
    assert str_to_bool("t") == True
    assert str_to_bool("False") == False
    assert str_to_bool("f") == False
    assert str_to_bool("Yes") == True
    assert str_to_bool("y") == True
    assert str_to_bool("no") == False
    assert str_to_bool("n") == False
    assert str_to_bool("Yup") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("on") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("off") == False
    assert str

# Generated at 2022-06-21 23:49:54.889730
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(__file__).__file__ == __file__
    fake_file = "/some/fake/file"
    fake_file_as_bytes = fake_file.encode("utf-8")
    fake_file_as_path = Path(fake_file)

    with pytest.raises(LoadFileException):
        load_module_from_file_location(fake_file)
    with pytest.raises(LoadFileException):
        load_module_from_file_location(fake_file_as_bytes)
    with pytest.raises(LoadFileException):
        load_module_from_file_location(fake_file_as_path)

# Generated at 2022-06-21 23:50:03.006539
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import tempfile

    # Create dummy module
    test_file_location = None
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as tmp:
        test_file_location = tmp.name
        tmp.write("test = 1")

    # Load module from file location
    module = load_module_from_file_location(test_file_location)

    # Test
    assert module.test == 1

    # Cleanup
    os.remove(test_file_location)



# Generated at 2022-06-21 23:50:14.378067
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "/etc/passwd", "module_name", "/home/${some_env_var}"
        )

    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "/etc/passwd", "module_name", "/home/${nonexisting_env_var}"
        )

    with pytest.raises(FileNotFoundError):
        load_module_from_file_location(
            "/etc/passwd", "module_name", "/home/nonexisting_file"
        )