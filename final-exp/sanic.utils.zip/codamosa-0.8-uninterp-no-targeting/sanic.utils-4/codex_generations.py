

# Generated at 2022-06-21 23:40:16.299617
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool('y') is True
    assert str_to_bool('yes') is True
    assert str_to_bool('n') is False
    assert str_to_bool('no') is False
    assert str_to_bool('yep') is True
    assert str_to_bool('yup') is True
    assert str_to_bool('t') is True
    assert str_to_bool('true') is True
    assert str_to_bool('false') is False
    assert str_to_bool('f') is False
    assert str_to_bool('off') is False
    assert str_to_bool('on') is True
    assert str_to_bool('enable') is True
    assert str_to_bool('enabled') is True

# Generated at 2022-06-21 23:40:25.335451
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    assert load_module_from_file_location(
        Path("test_data/test_module.py")
    ).function() == "hello world"

    assert load_module_from_file_location(
        Path("test_data/test_module_bool.py")
    ).function() is True

    assert load_module_from_file_location(
        Path("test_data/test_module_bool.py").resolve()
    ).function() is True

    assert load_module_from_file_location(
        Path("test_data/test_module_bool.py").resolve().as_uri()
    ).function() is True

    assert load_module_from_file_location(
        str(Path("test_data/test_module_bool.py").resolve())
    ).function() is True

# Generated at 2022-06-21 23:40:35.968747
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # pylint: disable=redefined-outer-name,unused-variable
    # pylint: disable=redefined-outer-name,unused-variable
    module = load_module_from_file_location("/some/file/name.py")
    assert module.__dict__ == {}

    module = load_module_from_file_location("/some/file/name.py", "a=1")
    assert module.__dict__ == {"a": 1}

    module = load_module_from_file_location("/some/file/name.py", "a=2")
    assert module.__dict__ == {"a": 2}

    module = load_module_from_file_location("/some/file/name.py", "a=3")

# Generated at 2022-06-21 23:40:46.925628
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    assert "some_function" in dir(
        load_module_from_file_location(
            "tests.test_helpers_load_module_from_file_location.py"
        )
    )
    assert (
        load_module_from_file_location(
            "tests.test_helpers_load_module_from_file_location.py"
        ).some_function()
        == 42
    )
    assert "some_function" in dir(
        load_module_from_file_location(Path(__file__))
    )
    assert (
        load_module_from_file_location(Path(__file__)).some_function()
        == 42
    )

    os_environ["SOME_VAR"] = "unit tests!"

# Generated at 2022-06-21 23:40:54.432891
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import copy
    from pathlib import Path
    from os import environ
    from tempfile import TemporaryDirectory

    # 1) Check if simple case works well
    with TemporaryDirectory() as tmp_conf_dir:

        # A) Setup environment
        test_module_name = "test_config"
        test_module_location = Path(tmp_conf_dir) / f"{test_module_name}.py"
        test_module_contents = "a = 1"
        with open(test_module_location, "w") as test_conf_file:
            test_conf_file.write(test_module_contents)

        # B) Run the function and check result
        test_module = load_module_from_file_location(
            test_module_location, encoding="utf8"
        )

# Generated at 2022-06-21 23:41:01.741837
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location(
            "/home/workspace/awesome-project/config.py"
        )
    )
    assert load_module_from_file_location("config")
    assert load_module_from_file_location(b"config", encoding="ASCII")
    assert load_module_from_file_location(Path("config"))



# Generated at 2022-06-21 23:41:14.954662
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_file_path = Path(__file__).parent / "test_load_module_from_file_location.py"
    test_module = load_module_from_file_location(test_file_path)
    assert test_module.__file__ == str(test_file_path)

    # with environment variable
    test_file_path = "test_files/test_load_module_from_file_location.py"
    test_file_path = "${PWD}/test_files/test_load_module_from_file_location.py"
    test_module = load_module_from_file_location(test_file_path)
    assert test_module.__file__ == str(Path(__file__).parent / test_file_path)

    # we should be able to pass here utf-8

# Generated at 2022-06-21 23:41:27.075531
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("t") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yeah") is True
    assert str_to_bool("1") is True
    assert str_to_bool("false") is False
    assert str_to_bool("no") is False
    assert str_to_bool("off") is False
    assert str_to_bool("0") is False
    assert str_to_bool("yep") is True
    assert str_to_bool("nope") is False
    assert str_to_bool("n") is False
    assert str_to_bool("y") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("on") is True
   

# Generated at 2022-06-21 23:41:39.048343
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import unittest
    import unittest.mock as mock
    from os import environ, pathsep
    from tempfile import mkdtemp
    from shutil import rmtree

    # Create a directory tree that we can use to test
    # loading modules from.
    dir_name = mkdtemp()

# Generated at 2022-06-21 23:41:44.797899
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from .test_server import test_config

    module_from_file_location = load_module_from_file_location(
        test_config, encoding="utf8"
    )
    assert module_from_file_location.KEEP_ALIVE == False



# Generated at 2022-06-21 23:41:56.745644
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    try:
        # a) Test it with file path
        path = Path(tempfile.mkdtemp())
        file = path / "some_module.py"
        with open(file, "w") as new_file:
            new_file.write("x = 5")
        # Now load the file.
        module = load_module_from_file_location(file)
        assert module.x == 5
        # b) Test it with nonexistent file
        nonexistent_file = path / "nonexistent_file.py"
        with pytest.raises(IOError):
            load_module_from_file_location(nonexistent_file)

    finally:
        path.rmdir()

# Generated at 2022-06-21 23:42:08.116747
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D103
    from tempfile import NamedTemporaryFile
    from os import environ
    from os.path import dirname, abspath

    # Test if function can load file from path as string
    with NamedTemporaryFile(suffix=".py") as tmp_file:
        tmp_file.write(b"foo = 1")
        tmp_file.flush()
        my_module = load_module_from_file_location(tmp_file.name)
        assert my_module.foo == 1

    # Test if function can load file from path as Path
    with NamedTemporaryFile(suffix=".py") as tmp_file:
        tmp_file.write(b"foo = 12")
        tmp_file.flush()

# Generated at 2022-06-21 23:42:19.711010
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") == True
    assert str_to_bool("true") == True
    assert str_to_bool("1") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("y") == True
    assert str_to_bool("t") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True

    assert str_to_bool("False") == False
    assert str_to_bool("false") == False

# Generated at 2022-06-21 23:42:31.626157
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Simple usage of load_module_from_file_location.
    # We should get module config_vars
    # which contains variables:
    # var_1 = "var_1"
    # var_2 = "var_2"
    config_vars = load_module_from_file_location(
        "tests/config_vars.py"  # Here just a string
    )

    assert isinstance(config_vars, types.ModuleType)
    assert config_vars.var_1 == "var_1"
    assert config_vars.var_2 == "var_2"

    # Usage of os.path.join
    config_vars = load_module_from_file_location(
        "tests/config_vars.py"  # Here just a string
    )


# Generated at 2022-06-21 23:42:42.227401
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import remove, makedirs, symlink
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from tempfile import NamedTemporaryFile

    from shutil import rmtree

    from .test_helpers import is_same_dir_content

    with TemporaryDirectory(prefix="sanic-test-dir") as tempdir:
        with NamedTemporaryFile(dir=tempdir) as tmp_test_file:
            test_config_path = Path(tmp_test_file.name).resolve()

            test_module_content_0 = """
module_var_0 = "val0"
module_var_1 = "val1"
"""

# Generated at 2022-06-21 23:42:51.131281
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from tempfile import TemporaryDirectory  # noqa
    from shutil import copyfile  # noqa

    test_config_file_text = """
test_conf = 'test_value'
test_conf2 = "test_value2"
test_conf3 = True
test_conf4 = 1.5
test_conf5 = ['test_value3', 'test_value4', 1, 2, True]
test_conf6 = {'test_value5': 1, 'test_value6': 2}
    """

    # Test config file with non-standart name
    with TemporaryDirectory() as tmp_dir:
        tmp_dir_path = Path(tmp_dir)
        tmp_config_path = tmp_dir_path / "some_config_file.conf"

# Generated at 2022-06-21 23:43:00.462283
# Unit test for function str_to_bool
def test_str_to_bool():
    for val in [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]:
        assert str_to_bool(val) is True
    for val in [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]:
        assert str_to_bool(val) is False

# Generated at 2022-06-21 23:43:12.604260
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test cases for function load_module_from_file_location
    """
    # test case 1
    # Test that test file is loaded from correct location
    # setup
    location = "app.test_sanic:load_module_from_file_location"
    # assertion
    try:
        load_module_from_file_location(location)
        assert False
    # expect exception
    except AttributeError:
        assert True
    except Exception:
        assert False

    # test case 2
    # Test that configuration file is loaded from environment variable.
    # setup
    location = "${SANIC_CONFIG_FILE}"
    # assertion
    try:
        load_module_from_file_location(location)
        assert True
    except:
        assert False

    # test case 3
    # Test that configureation

# Generated at 2022-06-21 23:43:22.904063
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("True") == True
    assert str_to_bool("TrUE") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("Enable") == True
    assert str_to_bool("1") == True
    assert str_to_bool("N") == False
    assert str_to_bool("No") == False
    assert str_to_bool("f") == False
    assert str_to_bool("False") == False
    assert str_to_bool("OFF") == False
    assert str_to_bool("Disable") == False
    assert str_to_bool("0") == False

# Generated at 2022-06-21 23:43:34.610722
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import json
    from unittest.mock import patch

    test_module_content = """
test_module_key = "test_module_value"
test_module_list = ['a', 'b', 'c', 'd']
test_module_dict = {"a": "b"}
test_module_dict_nested = {"a": {"b": "c"}}
test_module_module = None
"""

    expected_test_module_dict = {
        "test_module_key": "test_module_value",
        "test_module_list": ["a", "b", "c", "d"],
        "test_module_dict": {"a": "b"},
        "test_module_dict_nested": {"a": {"b": "c"}},
        "test_module_module": None,
    }



# Generated at 2022-06-21 23:43:46.661182
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test: load config from file.
    assert load_module_from_file_location(__file__).__file__ == __file__

    # Test: load config from bytes.
    file_location = __file__.encode("utf-8")
    module = load_module_from_file_location(file_location)
    assert isinstance(module, types.ModuleType)
    assert module.__file__ == __file__

    # Test: load config from Path
    module = load_module_from_file_location(Path(__file__))
    assert isinstance(module, types.ModuleType)
    assert module.__file__ == __file__

    # Test: load config from string with $some_env_var format.
    os_environ["some_env_var"] = __file__
    module = load_module

# Generated at 2022-06-21 23:43:56.974346
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: C901, WPS211
    if sys.version_info < (3, 7):
        return

    # Create file with content:
    #
    # # this is comment
    # some_variable = 1
    # some_variable_with_str = "string"
    # some_variable_with_str_with_quotes = "str\'in\"g"
    # some_variable_with_str_with_new_lines = "new\nline"
    # some_variable_with_multiline_string = """this is
    # multiline string"""

    import tempfile

    # write content
    file_descriptor, file_path = tempfile.mkstemp(
        text=True, prefix="some_config_", suffix=".py"
    )

# Generated at 2022-06-21 23:44:06.888327
# Unit test for function str_to_bool
def test_str_to_bool():
    for v in (
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ):
        assert str_to_bool(v)
    for v in (
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ):
        assert not str_to_bool(v)
    for v in ("q", "qwerty", "asd", "[", "]", "*", "a1", "a0"):
        with pytest.raises(ValueError):
            str_to_bool(v)

# Generated at 2022-06-21 23:44:15.207715
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    _module_name = "test_module_name"
    _path_to_module = Path(__file__).parent / "test_module.py"

    os_environ["test_module_env_var"] = str(_path_to_module)

    # Module is loaded.
    assert (
        _module_name
        == load_module_from_file_location(
            _module_name, _path_to_module
        ).__name__
    )
    assert (
        _module_name
        == load_module_from_file_location(
            _path_to_module
        ).__name__
    )
    assert (
        _module_name
        == load_module_from_file_location(
            bytes(_path_to_module), "utf8"
        ).__name__
    )

# Generated at 2022-06-21 23:44:28.573537
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    from io import BytesIO
    from pathlib import Path

    from pytest import raises
    from sanic.utils import load_module_from_file_location

    with raises(TypeError):
        load_module_from_file_location(None)

    with raises(FileNotFoundError):
        load_module_from_file_location("/")

    with raises(OSError):
        load_module_from_file_location(b"/")

    with raises(FileNotFoundError):
        load_module_from_file_location(Path("/"))

    with raises(IOError):
        load_module_from_file_location(Path("./tests/test_settings.py"))

    with raises(OSError):
        load_module_from

# Generated at 2022-06-21 23:44:36.514632
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("1") is True
    assert str_to_bool("true") is True
    assert str_to_bool("T") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("0") is False
    assert str_to_bool("false") is False
    assert str_to_bool("F") is False
    assert str_to_bool("disable") is False

# Generated at 2022-06-21 23:44:47.780603
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ, remove
    from tempfile import TemporaryDirectory

    from sanic.log import logger

    logger.info(
        "Testing load_module_from_file_location"
        " with valid python filename.\n"
    )
    # create temporary directory and test file
    with TemporaryDirectory(prefix="sanic_test_") as temp_dir:
        filename = Path(temp_dir, "test.py")
        assert filename.name == "test.py"

# Generated at 2022-06-21 23:44:57.910587
# Unit test for function str_to_bool
def test_str_to_bool():
    """Unit test for function str_to_bool."""
    assert str_to_bool("false") is False
    assert str_to_bool("enable") is True
    assert str_to_bool("1") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("0") is False
    assert str_to_bool("no") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("t") is True
    assert str_to_bool("f") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("nope") is False
   

# Generated at 2022-06-21 23:45:01.020477
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_module_test = load_module_from_file_location("os", "")
    assert import_module_test is os

# Generated at 2022-06-21 23:45:11.445753
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:45:22.879254
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("1") is True
    assert str_to_bool("t") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("false") is False
    assert str_to_bool("0") is False
    assert str_to_bool("f") is False
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False

# Generated at 2022-06-21 23:45:23.798946
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert False

# Generated at 2022-06-21 23:45:32.665759
# Unit test for function str_to_bool
def test_str_to_bool():
    from pytest import raises
    assert str_to_bool("True") == True
    assert str_to_bool("1") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("t") == True
    assert str_to_bool("on") == True

    assert str_to_bool("False") == False
    assert str_to_bool("0") == False
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("off") == False

    with raises(ValueError):
        str_to_bool("foo bar")

    with raises(ValueError):
        str_to_bool("")

    with raises(ValueError):
        str_to_

# Generated at 2022-06-21 23:45:44.217796
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def test_equal(a, b):
        assert a == b, f"\n{a} \nnot equal to \n{b}"

    test_equal(
        load_module_from_file_location("os.path"),
        import_string("os.path")
    )
    test_equal(
        load_module_from_file_location("os.path.abspath"),
        import_string("os.path.abspath")
    )
    test_equal(
        load_module_from_file_location("config/environment"),
        load_module_from_file_location("config/environment.py")
    )
    test_equal(
        load_module_from_file_location("config/environment"),
        load_module_from_file_location("config/environment.pyw")
    )

# Generated at 2022-06-21 23:45:53.769797
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from os import getcwd, remove, environ as os_environ

    from tempfile import mkstemp

    from scripttest import TestFileEnvironment

    def _create_temp_file(file_content: str):
        fd, file_name = mkstemp()
        with open(file_name, "w") as temp_file:
            temp_file.write(file_name)
        remove(file_name)
        return file_name

    with TestFileEnvironment() as env:
        env.writefile(
            "some_module.py", "some_var = 1\n" "some_other_var = 'some_value'"
        )

        # Testing if str parameter works
        module = load_module_from_file_location(
            env.getpath("some_module.py")
        )

# Generated at 2022-06-21 23:46:05.366864
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True,\
        "should be True when y"
    assert str_to_bool("yes") == True,\
        "should be True when yes"
    assert str_to_bool("yep") == True,\
        "should be True when yep"
    assert str_to_bool("yup") == True,\
        "should be True when yup"
    assert str_to_bool("t") == True,\
        "should be True when t"
    assert str_to_bool("true") == True,\
        "should be True when true"
    assert str_to_bool("on") == True,\
        "should be True when on"
    assert str_to_bool("enable") == True,\
        "should be True when enable"
    assert str

# Generated at 2022-06-21 23:46:18.112794
# Unit test for function str_to_bool
def test_str_to_bool():
    # TODO:
    #   - convert "true" to False (false positive)
    #   - If val is in case insensitive
    #       ("y", "yes", "t", "true", "on") returns True.
    #   - If val is in case insensitive
    #       ("n", "no", "f", "false", "off") returns False.
    #   - convert "true" to False (false positive)

    # inputs / outputs
    pos_in_vals = ("Y", "YES", "YEP", "YUP", "T", "TRUE", "ON", "ENABLE", "ENABLED", "1")
    neg_in_vals = ("N", "NO", "F", "FALSE", "OFF", "DISABLE", "DISABLED", "0")
    out = True
    test_cases = []

# Generated at 2022-06-21 23:46:29.844044
# Unit test for function str_to_bool
def test_str_to_bool():
    assert(str_to_bool("y") == True)
    assert(str_to_bool("Y") == True)
    assert(str_to_bool("yes") == True)
    assert(str_to_bool("YES") == True)
    assert(str_to_bool("yep") == True)
    assert(str_to_bool("yup") == True)
    assert(str_to_bool("t") == True)
    assert(str_to_bool("T") == True)
    assert(str_to_bool("true") == True)
    assert(str_to_bool("True") == True)
    assert(str_to_bool("TRUE") == True)
    assert(str_to_bool("on") == True)
    assert(str_to_bool("on") == True)
   

# Generated at 2022-06-21 23:46:40.360472
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unit tests for function load_module_from_file_location."""
    # Standard usage with file path.
    config = load_module_from_file_location(
        f"{Path(__file__).parent}/../test_configs/config.py",
    )
    assert config.TEST_CONFIG == "It works!"

    # Usage with environment variables in path.
    os_environ["TEST_ENV_VAR"] = "test_configs"
    config = load_module_from_file_location(
        f"${TEST_ENV_VAR}/config.py",
        __file__,
    )
    assert config.TEST_CONFIG == "It works!"

    # Usage with environment variables in path, but without .py extension
    config = load_module_

# Generated at 2022-06-21 23:46:47.867533
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    import pytest

    # Checking loading normal file.
    module = load_module_from_file_location("os")
    assert module == os

    # Checking case when location parameter is "os" (string).
    module = load_module_from_file_location("os")
    assert module == os

    # Checking case when location parameter is "os" (byte).
    module = load_module_from_file_location(b"os")
    assert module == os

    # Checking case when location parameter is:
    # 1) Bytes type.
    # 2) It is path to file.
    # 3) It contains environment variable in format ${some_env_var}.
    #    So, /some/path/${some_env_var}/some_file.py will be loaded.

# Generated at 2022-06-21 23:46:57.434629
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    loaded_module = load_module_from_file_location(
        "../tests/test_files/test_load_module_from_file_location/test_file.py"
    )

    assert loaded_module.TEST_ENVVAR == "TEST_VALUE"
    assert loaded_module.TEST_CONSTANT == "Test Const."
    assert loaded_module.TEST_FUNCTION() == "Test Func."
    assert loaded_module.TEST_CLASS.test() == "Test Class."

# Generated at 2022-06-21 23:47:10.220739
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:47:22.211573
# Unit test for function str_to_bool
def test_str_to_bool():
    cases = {
        ""
        "": True,
        "y": True,
        "Y": True,
        "yd": True,
        "n": False,
        "f": False,
        "true": True,
        "True": True,
        "false": False,
        "False": False,
        "yes": True,
        "yeah": True,
        "no": False,
        "None": False,
        "": False,
        1: True,
        0: False,
        10: True,
        -1: False,
        "1": True,
        "0": False,
        "10": True,
        "-1": False,
        "on": True,
        "off": False,
    }
    for case, expected in cases.items():
        assert str_to_bool

# Generated at 2022-06-21 23:47:27.873611
# Unit test for function str_to_bool
def test_str_to_bool():
    for true_value in ['True', 'true', 'yes', 'YES', 'on', 'ON', 'y', 'Y']:
        assert str_to_bool(true_value) is True

    for false_value in ['False', 'false', 'no', 'NO', 'off', 'OFF', 'n', 'N']:
        assert str_to_bool(false_value) is False

# Example of how to use load_module_from_file_location used in Sanic.

# Generated at 2022-06-21 23:47:39.569273
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from textwrap import dedent

    # A) Test pickle
    with NamedTemporaryFile(mode="w", suffix=".pickle") as file:
        file_location = file.name

        module = load_module_from_file_location(file_location)

        assert module.__name__ == "config"

        assert not hasattr(module, "__file__")

    # B) Test pyc
    with NamedTemporaryFile(mode="w", suffix=".pyc") as file:
        file_location = file.name

        module = load_module_from_file_location(file_location)

        assert module.__name__ == "config"

        assert not hasattr(module, "__file__")

    # C) Test py

# Generated at 2022-06-21 23:47:50.923877
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Case 1: Pathlib.Path object as location parameter.
    some_module = load_module_from_file_location(
        Path(__file__)
    )  # type: ignore
    assert hasattr(
        some_module, "test_load_module_from_file_location"
    )

    # Case 2: Path as a string as location parameter.
    some_module = load_module_from_file_location(
        __file__
    )  # type: ignore
    assert hasattr(
        some_module, "test_load_module_from_file_location"
    )

    # Case 3: Path with environment variable as location parameter.
    os_environ["SOME_ENV_VAR"] = "."

# Generated at 2022-06-21 23:48:01.205071
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    with tempfile.TemporaryDirectory() as path:
        path = Path(path)
        prefix = "file"
        file_name = "some_file.py"
        file_path = path / file_name
        os.environ["some_env_var"] = str(file_path)
        file_path.write_text(
            textwrap.dedent(
                """
                from os import environ
                foo = environ["some_env_var"]
                """
            )
        )
        try:
            result = load_module_from_file_location(
                "${some_env_var}", prefix, location=path
            )
            assert file_path == result.foo
        finally:
            del os.environ["some_env_var"]

# Generated at 2022-06-21 23:48:12.481245
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("t")
    assert str_to_bool("TRUE")
    assert str_to_bool("T")
    assert str_to_bool("yes")
    assert str_to_bool("y")
    assert str_to_bool("YES")
    assert str_to_bool("Y")
    assert str_to_bool("false")
    assert str_to_bool("f")
    assert str_to_bool("FALSE")
    assert str_to_bool("F")
    assert str_to_bool("no")
    assert str_to_bool("n")
    assert str_to_bool("NO")
    assert str_to_bool("N")


# Generated at 2022-06-21 23:48:17.293962
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False

    with pytest.raises(ValueError):
        str_to_bool("yup")
    with pytest.raises(ValueError):
        str_to_bool("nope")


# pylint: disable=unreachable

# Generated at 2022-06-21 23:48:27.376608
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from uuid import uuid4
    from os import environ as os_environ

    # A) Check that function works like intended if the file doesn't exists.
    #    That function raises an IOError.
    #    Used NamedTemporaryFile to generate random name of a not existing
    #    file.
    with NamedTemporaryFile(suffix=".py") as tmp_file:
        try:
            load_module_from_file_location(tmp_file.name)
        except IOError:
            pass
        else:
            assert False

    # B) Check that function works like intended if file contains invalid
    #    python code.
    #    That function raises an PyFileError.

# Generated at 2022-06-21 23:48:37.860452
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:48:49.218431
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    valid_true = [
        "Y",
        "YES",
        "yep",
        "YUP",
        "t",
        "TRUE",
        "ON",
        "ENABLE",
        "EnaBleD",
        "1",
    ]
    valid_false = [
        "N",
        "NO",
        "f",
        "FALSE",
        "OFF",
        "DISABLE",
        "disabled",
        "0",
    ]
    invalid = ["A", "ASDF", "@", ""]

    for valid in valid_true:
        assert str_to_bool(valid)

    for valid in valid_false:
        assert not str_to_bool(valid)


# Generated at 2022-06-21 23:48:58.248230
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Path
    module = load_module_from_file_location(Path("not_exist"))
    assert module is None

    module = load_module_from_file_location(
        Path(__file__).parent.absolute() / "test_utils.py"
    )
    assert module is not None

    # Bytes location
    module = load_module_from_file_location(
        bytes(Path(__file__).parent.absolute() / "test_utils.py"),
        encoding="utf8",
    )
    assert module is not None

    # Invalid encoding

# Generated at 2022-06-21 23:49:03.089572
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("TruE") == True
    assert str_to_bool("fAlsE") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:49:12.293111
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import tempfile
    from os import path as os_path
    from os import environ as os_environ
    from contextlib import contextmanager

    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = tmp_dir.name

    # unit_test_config can be found in ./unit_tests folder
    unit_tests_dir = os_path.dirname(os_path.realpath(__file__))
    with open(
        os_path.join(unit_tests_dir, "unit_test_config.py"), "r"
    ) as config_file, open(tmp_dir_path + "/unit_test_config.py", "w") as f:
        f.write(config_file.read())

    # Make sure that tmp_dir is in PYTHONPATH
   

# Generated at 2022-06-21 23:49:20.921987
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("n") == False
    assert str_to_bool("Y") == True
    assert str_to_bool("NO") == False
    assert str_to_bool("false") == False
    assert str_to_bool("true") == True
    assert str_to_bool("TRUE") == True
    with pytest.raises(ValueError):
        assert str_to_bool("invalid str")

# Generated at 2022-06-21 23:49:29.703758
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Expects the test module will be available at
    test_file_path. Expects that module has 'test_variable'
    in it."""
    test_file_path = Path(__file__).absolute().parent / "test_file.py"
    test_module = load_module_from_file_location(
        test_file_path, submodule_search_locations=[]
    )
    assert test_module.test_variable



# Generated at 2022-06-21 23:49:40.520317
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from pytest import fixture, raises

    @fixture(scope="module")
    def py_file_code(tmpdir_factory):
        file_path = tmpdir_factory.mktemp("test_load_module_from_file_location")
        file_str = (
            "/* some comment */"
            "CONST_STR = 'test string'"
            "CONST_INTEGER = 123"
            "CONST_LIST = [1, 2, 3]"
            "CONST_DICT = {1: 'one', 2: 'two', 3: 'three'}"
        )

        file = file_path.join("example.py")
        file.write(file_str)

        return file_str


# Generated at 2022-06-21 23:49:52.683251
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    tmp_dir = Path(tempfile.gettempdir())
    test_module_name = "test_module_name.py"
    full_path_to_test_module = tmp_dir / test_module_name
    value = "random_value"

    # Creating test module
    with full_path_to_test_module.open("w") as f:
        f.write(f'test_variable = "{value}"')

    # Loading module from file
    loaded_module = load_module_from_file_location(
        full_path_to_test_module
    )

    # Removing test module
    full_path_to_test_module.unlink()

    # Checking the test module has been loaded correctly
    assert loaded_module.test_variable == value

# Generated at 2022-06-21 23:50:04.021043
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("True") == True
    assert str_to_bool("true") == True
    assert str_to_bool("t") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("YUP") == True
    assert str_to_bool("On") == True
    assert str_to_bool("on") == True
    assert str_to_bool("Enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("no") == False
    assert str_to_bool("No") == False
    assert str_to_bool("False") == False