

# Generated at 2022-06-21 23:40:11.219217
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("f") is False
    assert str_to_bool("False") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False
    assert str_to_bool("disabled") is False
    assert str_to_bool("0") is False
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True

# Generated at 2022-06-21 23:40:23.106747
# Unit test for function str_to_bool
def test_str_to_bool():
    true_values = {
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    }
    for value in true_values:
        assert str_to_bool(value)

    false_values = {"n", "no", "f", "false", "off", "disable", "disabled", "0"}
    for value in false_values:
        assert not str_to_bool(value)

    expected_error_msg = "Invalid truth value "
    try:
        str_to_bool("somedumbstuff")
    except ValueError as error:
        actual_error_msg = str(error)

    assert expected_error_msg == actual_error_msg

# Generated at 2022-06-21 23:40:34.620109
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("false") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("TRUE") is True
    assert str_to_bool("FALSE") is False
    assert str_to_bool("YES") is True
    assert str_to_bool("NO") is False
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("t") is True
    assert str_to_bool("f") is False
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("on") is True

# Generated at 2022-06-21 23:40:46.975173
# Unit test for function str_to_bool
def test_str_to_bool():
    """Check if str_to_bool converts strings to booleans as expected."""
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("true") is True
    assert str_to_bool("false") is False
    assert str_to_bool("on") is True
    assert str_to_bool("off") is False
    assert str_to_bool("enable") is True
    assert str_to_bool("disable") is False
    assert str_to_bool("enabled") is True
    assert str_to_bool("disabled") is False
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("t") is True
    assert str_to_bool("f")

# Generated at 2022-06-21 23:40:54.451601
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile

    with tempfile.TemporaryDirectory() as tmp_path:
        tmp_path = Path(tmp_path)
        module_file_path = tmp_path / "module.py"
        module_file_path.touch()

        module_file_with_invalid_path = "module.py"
        module_file_with_invalid_path = tmp_path / module_file_with_invalid_path
        module_file_with_invalid_path.touch()
        module_file_with_invalid_path.unlink()

        # A) Check if location contains any environment variables
        #    in format ${some_env_var}.
        env_vars_in_location = set(re_findall(r"\${(.+?)}", "any_location"))

# Generated at 2022-06-21 23:41:05.147974
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(
        "sanic.exceptions"
    ).__name__ == "sanic.exceptions"

    file_path = Path(__file__).parent / "module.py"
    assert load_module_from_file_location(file_path).__name__ == "module"

    file_path = Path(__file__).parent / "module.py"
    os_environ["TEST_ENV_VAR"] = str(file_path)
    assert (
        load_module_from_file_location(
            f"{file_path.parent}/${{TEST_ENV_VAR}}"
        ).__name__
        == "module"
    )
    del os_environ["TEST_ENV_VAR"]


# Generated at 2022-06-21 23:41:08.288570
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("") == False

# Generated at 2022-06-21 23:41:17.005349
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location(): # noqa
    import sanic.config
    import os

    def clean_up_env():
        if "test_env_var" in os.environ:
            del os.environ["test_env_var"]

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    tmp_location = "test_env_var"
    os.environ[tmp_location] = "test_env_var"
    assert load_module_from_file_location(
        "${" + tmp_location + "}"
    ) == sanic.config
    clean_up_env()

    # B) Check these variables exists in environment.
    tmp_location = "test_env_var"
    assert "test_env_var" not in os.environ

# Generated at 2022-06-21 23:41:22.993834
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    try:
        str_to_bool("not a boolean")
        raise ValueError  # pragma: no cover
    except ValueError:
        pass



# Generated at 2022-06-21 23:41:37.143937
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:41:50.466296
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location({})
    except TypeError as e:
        assert "has to be of a string or bytes type" in str(e)

    try:
        load_module_from_file_location(123)
    except TypeError as e:
        assert "has to be of a string or bytes type" in str(e)

    try:
        load_module_from_file_location(b'123')
    except TypeError as e:
        assert "has to be of a string or bytes type" in str(e)

    os_environ['test_env_var'] = 'test_env_var_value'

# Generated at 2022-06-21 23:42:01.715070
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("1")
    assert str_to_bool("yes")
    assert str_to_bool("y")

    assert not str_to_bool("false")
    assert not str_to_bool("False")
    assert not str_to_bool("0")
    assert not str_to_bool("no")
    assert not str_to_bool("n")

    try:
        str_to_bool("some_string")
        assert False
    except ValueError:
        assert True

    try:
        str_to_bool("2")
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-21 23:42:11.566312
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import json
    import tempfile
    import os

    config_str = """
    {
        "app": {
            "DEBUG": true,
            "HOST": "0.0.0.0",
            "PORT": 5000,
            "KEEP_ALIVE": 60
        }
    }
    """

    with tempfile.NamedTemporaryFile() as config_file:
        config_file.write(config_str.encode())
        config_file.flush()

        module = load_module_from_file_location(config_file.name)

    module_dict = json.loads(json.dumps(module.__dict__))
    config_dict = json.loads(config_str)

    assert module_dict == config_dict

    # Testing environment variables substitutions

# Generated at 2022-06-21 23:42:20.885995
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # TODO: Improve test for coverage
    os_environ["SOME_ENV_VAR"] = "abc"
    module = load_module_from_file_location("./package_tests/test_module_1")
    assert module.VAR1 == 1
    assert module.VAR2 == 2
    assert module.VAR3 == 3

    # test os path
    module = load_module_from_file_location(
        f"{os.path.dirname(__file__)}/package_tests/test_module_1"
    )
    assert module.VAR1 == 1
    assert module.VAR2 == 2
    assert module.VAR3 == 3

    # Test ${some_env_var}

# Generated at 2022-06-21 23:42:29.736719
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    import random
    import string

    random_string = "".join(
        random.choice(string.ascii_letters + string.digits)
        for _ in range(10)
    )

    env_var = "TEST_ENV_VAR" + random_string

    os_environ[env_var] = random_string


# Generated at 2022-06-21 23:42:41.152788
# Unit test for function str_to_bool
def test_str_to_bool():

    # Check that function return True for some True-like strings
    assert str_to_bool("true") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yep") is True

    # Check that function return False for some True-like strings
    assert str_to_bool("false") is False
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False

    # Check that function raises ValueError if it can not be converted
    # to bool.
    try:
        str_to_bool("tree")
    except ValueError:
        pass
    else:
        assert False, "Function str_to_bool did not raise ValueError"


# Generated at 2022-06-21 23:42:52.654920
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    #
    # A) Some simple checks for basic cases.
    #

    # A1) Check if it works well with Path.
    import os
    import sys

    location = Path(os.path.dirname(__file__)) / "test_data" / "test_module.py"
    module = load_module_from_file_location(location)
    assert module.__file__ == str(location)
    assert module.__name__ == "test_module"
    assert module.var == "test_var"
    assert module.var1 == "test_var1"

    # A2) Check if it works well with string.

# Generated at 2022-06-21 23:43:03.117895
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") == True
    assert str_to_bool("true") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("y") == True
    assert str_to_bool("On") == True
    assert str_to_bool("on") == True
    assert str_to_bool("1") == True

    assert str_to_bool("False") == False
    assert str_to_bool("false") == False
    assert str_to_bool("No") == False
    assert str_to_bool("no") == False
    assert str_to_bool("F") == False
    assert str_to_bool("f") == False
    assert str_

# Generated at 2022-06-21 23:43:13.913146
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import inspect

    # 1. Pathlib.Path test
    module_with_pathlib = load_module_from_file_location(
        Path("tests/test_config/config_with_pathlib.py")
    )
    assert (
        inspect.getfile(module_with_pathlib) == "tests/test_config/config_with_pathlib.py"
    )
    assert module_with_pathlib.TEST == "test"

    # 2. Test with concrete path
    module_with_concrete_path = load_module_from_file_location(
        "tests/test_config/config_with_concrete_path.py"
    )

# Generated at 2022-06-21 23:43:23.228610
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("on") is True
    assert str_to_bool("on") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("enable")

# Generated at 2022-06-21 23:43:32.625092
# Unit test for function str_to_bool

# Generated at 2022-06-21 23:43:44.757832
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D103
    os_environ["ENV_VAR_NAME"] = "env_var_name_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${ENV_VAR_NAME}/some_module.py"
    )  # noqa
    assert module.__name__ == "some_module_name"
    assert module.__file__ == "/some/path/env_var_name_value/some_module.py"


# Generated at 2022-06-21 23:43:50.418808
# Unit test for function load_module_from_file_location

# Generated at 2022-06-21 23:44:03.442901
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("N")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str

# Generated at 2022-06-21 23:44:14.269961
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("True") is True
    assert str_to_bool("on") is True
    assert str_to_bool("1") is True
    assert str_to_bool("nope") is False
    assert str_to_bool("False") is False
    assert str_to_bool("off") is False
    assert str_to_bool("0") is False
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("N") is False
    assert str_to_bool("F") is False
    assert str_to_bool("t") is True
    assert str_to_bool("T") is True
    assert str_to_bool("f") is False
    assert str

# Generated at 2022-06-21 23:44:24.420660
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    from textwrap import dedent

    try:
        fd, path = tempfile.mkstemp()
        with os.fdopen(fd, "w") as tmp:
            tmp.write(
                dedent(
                    """
            class A:
                pass
            """
                )
            )
        cfg = load_module_from_file_location(path)
        assert isinstance(cfg.A, type)
    finally:
        os.remove(path)

# Generated at 2022-06-21 23:44:31.709269
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("y")
    assert str_to_bool("on")
    assert str_to_bool("True")
    assert str_to_bool("1")
    assert not str_to_bool("no")
    assert not str_to_bool("off")
    assert not str_to_bool("False")
    assert not str_to_bool("0")
    try:
        assert not str_to_bool("lol")
        assert False
    except ValueError:
        pass

# Generated at 2022-06-21 23:44:38.951251
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("1") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-21 23:44:42.562658
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") == True
    assert str_to_bool("1") == True
    assert str_to_bool("false") == False

# Generated at 2022-06-21 23:44:47.420243
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("1") == True
    assert str_to_bool("no") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("0") == False
    assert str_to_bool("maybe") == False or True

# Generated at 2022-06-21 23:44:56.314812
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["LOCATION_ENV"] = "/location/environment"
    assert load_module_from_file_location(
        "tests/example_module.py", "/location"
    ).example_method() == "/location"
    assert load_module_from_file_location(
        "/location/${LOCATION_ENV}/example_module.py"
    ).example_method() == "/location/environment"

# Generated at 2022-06-21 23:45:08.918363
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        os_environ["HOME"]
    except KeyError:
        os_environ["HOME"] = "/"
    try:
        os_environ["SANIC_APP_CONFIG"]
    except KeyError:
        os_environ["SANIC_APP_CONFIG"] = ""
    try:
        os_environ["SOME_TEST_ENV_VAR"]
    except KeyError:
        os_environ["SOME_TEST_ENV_VAR"] = ""


# Generated at 2022-06-21 23:45:21.389527
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdirname:
        test_config_file_path = Path(tmpdirname)/"config.py"
        test_config_module_name = "config"
        os.environ["SOME_VAR"] = tmpdirname
        test_config_file_path.touch()

        # (1) Test if function can load modules from py files.
        with test_config_file_path.open("w") as f:
            f.write("""content = 1\n""")

        loaded_module = load_module_from_file_location(
            test_config_file_path
        )
        assert loaded_module.__name__ == test_config_module_name
        assert loaded_module.content == 1

        # (2) Test if we

# Generated at 2022-06-21 23:45:31.875156
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from tempfile import TemporaryFile
    from types import ModuleType

    # Test wrong param types
    with pytest.raises(TypeError):
        load_module_from_file_location(b"${THIS_ENV_VAR_DOES_NOT_EXIST}")
    with pytest.raises(LoadFileException):
        load_module_from_file_location("${THIS_ENV_VAR_DOES_NOT_EXIST}")

    # Test simple case
    some_env_var = "tmp"
    environ["THIS_ENV_VAR_EXISTS"] = some_env_var
    with TemporaryFile("w+") as f:
        f.write("some_var = 10")
        f.seek(0)

        module = load_module_from_file_

# Generated at 2022-06-21 23:45:43.633928
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import uuid

# Generated at 2022-06-21 23:45:53.424092
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    current_file_path = os.path.dirname(os.path.abspath(__file__))
    location = "tests/test_config.py"

    # Test if location is substitude with environment variable
    # and doesn't contain dots in it.
    loaded_module = load_module_from_file_location(
        os.path.join("$", current_file_path, location)
    )
    assert loaded_module.SANIC_TEST_CONFIG == "OK"

    # Test if location is substitude with environment variable
    # and contains dots in it.
    location_with_dots = "tests/test.config.py"

# Generated at 2022-06-21 23:46:04.954120
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D103
    # A. Check if normal work.
    # Some_module.py has the following content:
    # FOO = 1
    # BAR = {"a": 1, "b": 2}
    #
    # BAZ = """
    # {
    #     "key": "value"
    # }
    # """
    #
    loaded_module = load_module_from_file_location(
        "/tmp/some_module.py", "utf8"
    )
    assert loaded_module.FOO == 1
    assert loaded_module.BAR == {"a": 1, "b": 2}
    assert loaded_module.BAZ == "{\"key\": \"value\"}\n"

    # B. Check if location with environment variable would work.

# Generated at 2022-06-21 23:46:17.709473
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import makedirs
    from shutil import rmtree

    def create_temp_file(name: str, path: str, content: str = "") -> None:
        if not path:
            path = os.getcwd()
        else:
            makedirs(path)
        Path(f"{path}/{name}").touch()
        with open(f"{path}/{name}", "w") as f:
            f.write(content)

    def remove_temp_file(name: str, path: str) -> None:
        if path:
            rmtree(path)
        else:
            os.remove(name)


# Generated at 2022-06-21 23:46:22.200376
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True")
    assert not str_to_bool("False")
    assert str_to_bool("Y")
    assert not str_to_bool("n")

    try:
        assert str_to_bool("a")
    except ValueError:
        pass


# Generated at 2022-06-21 23:46:33.644816
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from .util import config_for_test
    from .config import Config, load_config
    import os


# Generated at 2022-06-21 23:46:45.874062
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    def _test_load_module_from_file_location_with_params(
        location: Union[bytes, str, Path],
        encoding: str = "utf8",
        *args,
        **kwargs
    ):
        module = load_module_from_file_location(
            location, encoding, *args, **kwargs
        )
        assert module.__file__ == location
        assert module.TEST_ENV_VAR == "TEST_ENV_VAR_VALUE"

    def _test_load_module_from_file_location_exception(
        location: Union[str, Path], *args, **kwargs
    ):
        with pytest.raises(LoadFileException):
            load_module_from_file_location(location, *args, **kwargs)


# Generated at 2022-06-21 23:46:57.127747
# Unit test for function str_to_bool
def test_str_to_bool():
    """Test function str_to_bool."""
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("Y")
    assert str_to_bool("Yes")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("N")
    assert not str_to_bool("No")
    assert str_to_bool("t")
    assert not str_to_bool("f")
    assert str_to_bool("true")
    assert not str_to_bool("false")
    assert str_to_bool("1")
    assert not str_to_bool("0")
    assert str_to_bool("on")
    assert not str_to_bool("off")

# Generated at 2022-06-21 23:47:04.709877
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("T") is True
    assert str_to_bool("True") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("Enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("F") is False
    assert str_to_bool("False") is False
    assert str_to_bool("N") is False
    assert str_to_bool("No") is False
    assert str_to_bool("OFF") is False
    assert str_to_bool("Disabled") is False
    assert str_to_bool("0") is False

    assert str_to_bool("") is False
    assert str_

# Generated at 2022-06-21 23:47:09.761477
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Setup
    test_data = [
        (
            b"sanic.__init__",
            "utf8",
        )
    ]

    # Exercise
    for td in test_data:
        result = load_module_from_file_location(*td)

    # Verify
    assert hasattr(result, "__name__") == True

    # Cleanup - none necessary

# Generated at 2022-06-21 23:47:21.726204
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("yEs") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("Yep") == True
    assert str_to_bool("yEp") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("Yup") == True
    assert str_to_bool("yUp") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("true") == True

# Generated at 2022-06-21 23:47:32.386154
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os
    import tempfile

    # 1. Load module from existing file.
    # Create a temporary file.
    file_handle, path_with_file = tempfile.mkstemp()
    with os.fdopen(file_handle, "w") as opened_file:
        opened_file.write(
            """
        def from_file():
            return "from_file"
    """
        )
    assert load_module_from_file_location(path_with_file).from_file() == "from_file"

    # 2. Load module from existing file with in case insensitive 'y' as
    #    value in it.
    file_handle, path_with_file = tempfile.mkstemp()
    with os.fdopen(file_handle, "w") as opened_file:
        opened

# Generated at 2022-06-21 23:47:41.743733
# Unit test for function str_to_bool
def test_str_to_bool():
    import pytest
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("YeS") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False

# Generated at 2022-06-21 23:47:51.819304
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unit test for function load_module_from_file_location."""
    from copy import deepcopy
    from pathlib import Path
    from os import environ, remove
    from os.path import join
    from re import compile

    from tempfile import NamedTemporaryFile

    from hypothesis import given
    from hypothesis.strategies import binary, composite, text
    from pytest import raises

    import_string_hypothesis = given(
        location_submodule=text().filter(
            lambda x: "." in x and len(x) < 100
        ),  # Importable string
        location_file=binary(min_size=1).filter(lambda x: b".py" in x),
    )


# Generated at 2022-06-21 23:47:58.929133
# Unit test for function str_to_bool
def test_str_to_bool():
    def check_value(val: str) -> None:
        return str_to_bool(val)

    assert check_value("Y") == True
    assert check_value("Yes") == True
    assert check_value("YES") == True
    assert check_value("y") == True
    assert check_value("yes") == True
    assert check_value("yup") == True
    assert check_value("T") == True
    assert check_value("true") == True
    assert check_value("True") == True
    assert check_value("Enable") == True
    assert check_value("EnablEd") == True
    assert check_value("1") == True

    assert check_value("N") == False
    assert check_value("n") == False
    assert check_value("No") == False

# Generated at 2022-06-21 23:48:10.789854
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import getcwd, environ
    from pathlib import Path
    from shutil import rmtree
    from tempfile import TemporaryDirectory

    from helpers import load_module_from_file_location

    with TemporaryDirectory() as tmpdir:

        # Sanity checks.
        tmpdir = Path(tmpdir)
        assert tmpdir.exists()
        assert tmpdir.is_dir()

        # Function logic tests.

        # Test1: Loads module from valid python file.
        empty_file_name = tmpdir / "empty_file.py"
        empty_file_name.touch()
        empty = load_module_from_file_location(empty_file_name)
        assert empty.__file__ == str(empty_file_name)
        assert empty.__name__ == empty_file_name.stem

        #

# Generated at 2022-06-21 23:48:25.145473
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("yes")
    assert str_to_bool("1")
    assert str_to_bool("y")
    assert str_to_bool("t")
    assert not str_to_bool("f")
    assert not str_to_bool("no")
    assert not str_to_bool("0")
    assert not str_to_bool("n")
    try:
        str_to_bool("maybe")
    except ValueError:
        pass

# Generated at 2022-06-21 23:48:38.282181
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for load_module_from_file_location function"""
    # Set up the environment
    os_environ["SOME_ENV_VAR"] = "some_env_var"

    module = load_module_from_file_location(
        "tests/functional/files/configs/config.py"
    )

    assert module.foo == "bar"

    module = load_module_from_file_location(
        "tests/functional/files/configs/config.py", "/some/path/to/"
    )

    assert module.foo == "bar"

    module = load_module_from_file_location(
        "tests/functional/files/configs/config.py", "/some/path/${SOME_ENV_VAR}"
    )

    assert module.foo == "bar"



# Generated at 2022-06-21 23:48:49.218281
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import shutil
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir_path:
        temp_file_path = Path(temp_dir_path).joinpath("test_file.py")

        expected = "success"

        with open(temp_file_path, "w") as config_file:
            config_file.write(
                "result = 'success'"
            )

        module = load_module_from_file_location(temp_file_path)
        assert expected == module.result

        # Test resolution of environment variables
        os_environ["some_env_var_name"] = "success"
        module = load_module_from_file_location(
            f"{temp_dir_path}/${some_env_var_name}/test_file.py"
        )
        assert expected

# Generated at 2022-06-21 23:48:58.212294
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-21 23:49:09.352968
# Unit test for function str_to_bool
def test_str_to_bool():
    assert(str_to_bool("true") == True)
    assert(str_to_bool("True") == True)
    assert(str_to_bool("TRUE") == True)
    assert(str_to_bool("t") == True)
    assert(str_to_bool("T") == True)
    assert(str_to_bool("y") == True)
    assert(str_to_bool("Y") == True)
    assert(str_to_bool("Yup") == True)
    assert(str_to_bool("yup") == True)
    assert(str_to_bool("yep") == True)
    assert(str_to_bool("yEs") == True)
    assert(str_to_bool("YEs") == True)

# Generated at 2022-06-21 23:49:20.359690
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    __location__ = os.path.realpath(os.path.join(
        os.getcwd(), os.path.dirname(__file__)
    ))

    sys.path.append(__location__)

    module_1 = load_module_from_file_location(
        "test_configs/config_file.py"
    )

    assert module_1.TEST_VAR == "test_value"

    module_2 = load_module_from_file_location(
        "test_configs/config_file"
    )

    assert module_2.TEST_VAR2 == "test_value2"

# Generated at 2022-06-21 23:49:26.522291
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys

    sys.path.append("tests")

    location = "tests/module_for_test.py"
    module = load_module_from_file_location(location)

    assert module.test_var == "1"
    assert module.test_var2 == "test_var2"



# Generated at 2022-06-21 23:49:37.518704
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function
    """

    def test_invalid_type_loaded(location: Union[bytes, str, Path]):
        """Check if below error is raised.

            assertRaises(
                TypeError,
                load_module_from_file_location,
                location
            )
        """
        with pytest.raises(TypeError):
            load_module_from_file_location(location)

    # Test invalid types
    test_invalid_type_loaded(object())
    test_invalid_type_loaded(True)
    test_invalid_type_loaded(1)
    test_invalid_type_loaded(0.0)
    test_invalid_type_loaded({"a": "a"})

# Generated at 2022-06-21 23:49:50.507792
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 1: Load module from file path.
    path = os.path.dirname(os.path.abspath(__file__))
    file_name = "module.py"
    module = load_module_from_file_location(
        os.path.join(path, file_name), "utf8"
    )
    assert module.__file__ == (
        os.path.join(path, file_name)
    )  # Check that module has been loaded

    # Test 2: Load module from file name.
    module = load_module_from_file_location(file_name, "utf8")
    assert module.__file__ == (
        os.path.join(path, file_name)
    )  # Check that module has been loaded

    # Test 3: Load module from file path with environment variable.

# Generated at 2022-06-21 23:49:57.158232
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    prefix_path = Path(__file__).parent / "resources/config_prefix"
    location = str(prefix_path / "configuration.py")
    module = load_module_from_file_location(location)

    assert module.NAME == "configuration"
    assert module.VALUE_FROM_PY_FILE == "value from py file"

