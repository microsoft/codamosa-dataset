

# Generated at 2022-06-21 23:40:23.830480
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-21 23:40:34.579217
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D103

    os_environ["KILI_ENV"] = "test"

    # Test three possible arguments bytes, str, Path

    # `bytes`
    module = load_module_from_file_location(b"test", "foo.py")
    assert module.name == "foo"
    assert module.__file__ == "foo.py"

    # `Path`
    module = load_module_from_file_location(Path(__file__), "foo.py")
    assert module.name == "foo"
    assert module.__file__ == Path(__file__) / "foo.py"

    # `str`
    module = load_module_from_file_location(
        Path(__file__).absolute().parent, "foo.py"
    )

# Generated at 2022-06-21 23:40:46.925789
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa

    # Testing correct values
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("YEP") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("YUP") is True
    assert str_to_bool("t") is True
    assert str_to_bool("T") is True
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("TRUE") is True

# Generated at 2022-06-21 23:40:58.047835
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from uuid import uuid4
    from tempfile import NamedTemporaryFile
    from os import environ
    from os import remove

    filename = "test"
    file_config_name = filename + ".py"
    file_config_path = NamedTemporaryFile(mode="w", suffix=".py", delete=False)
    file_config_path.write(
        f"config_value_1 = {uuid4()}\n"
        f"config_value_2 = {uuid4()}"
    )
    file_config_path.close()

    TEST_ENV_NAME = "TEST_ENV_NAME"
    TEST_ENV_VALUE = uuid4()
    environ[TEST_ENV_NAME] = str(TEST_ENV_VALUE)


# Generated at 2022-06-21 23:41:05.476584
# Unit test for function str_to_bool
def test_str_to_bool():
    # Form here: https://en.wikipedia.org/wiki/Yoda_conditions

    # True examples:
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("2")
    assert str_to_bool("yEP")
    assert str_to_bool("True")
    assert str_to_bool("ON")
    assert str_to_bool("Yep")
    assert str_to_bool("1")

    # False examples:
    assert not str_to_bool("n")
    assert not str_to_bool("No")
    assert not str_to_bool("0")
    assert not str_to_bool("F")
    assert not str_to_bool("off")
    assert not str_to_bool("False")
    assert not str_

# Generated at 2022-06-21 23:41:16.220841
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic.log import logger
    from pathlib import Path
    from io import StringIO
    from contextlib import redirect_stdout, redirect_stderr
    from os import environ
    from os.path import dirname, realpath
    from importlib import reload
    from sys import modules

    # Import __main__ module, which contains this test.
    # This module is already loaded, so we need to reload here his config.
    # Without it: module test_load_module_from_file_location will not be
    # able to import some_module.py because Sanic will load it with
    # name test_load_module_from_file_location from __main__.
    main_module = modules["__main__"]
    main_module = reload(main_module)

    # Import some_module after Sanic had loaded it with

# Generated at 2022-06-21 23:41:27.660704
# Unit test for function str_to_bool

# Generated at 2022-06-21 23:41:36.484758
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location(): # noqa
    import_tests_path = Path(__file__).parent / "import_stubs"
    simple_module_location = (
        import_tests_path / "simple_module.py"
    ).resolve().as_posix()
    empty_module_location = (
        import_tests_path / "empty_module.py"
    ).resolve().as_posix()
    badly_located_module_location = (
        import_tests_path / "badly_located_module.py"
    ).resolve().as_posix()
    env_var_used_module_location = (
        import_tests_path / "env_var_used_module.py"
    ).resolve().as_posix()

    # Test when location is in correct format.
    assert load_module_from_

# Generated at 2022-06-21 23:41:48.717527
# Unit test for function str_to_bool
def test_str_to_bool():  # pylint: disable=missing-docstring
    assert isinstance(str_to_bool("On"), bool)
    assert str_to_bool("On") is True
    assert isinstance(str_to_bool("OfF"), bool)
    assert str_to_bool("OfF") is False
    assert isinstance(str_to_bool("1"), bool)
    assert str_to_bool("1") is True
    assert isinstance(str_to_bool("0"), bool)
    assert str_to_bool("0") is False
    assert isinstance(str_to_bool("y"), bool)
    assert str_to_bool("y") is True
    try:
        assert str_to_bool("random")
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 23:41:58.024692
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("builtins") is builtins
    assert load_module_from_file_location("os") is os
    assert load_module_from_file_location("sys") is sys
    assert load_module_from_file_location("sanic") is sanic
    assert load_module_from_file_location("check_environ_loaded_module") is sanic_core

    try:
        load_module_from_file_location("some_non_existent_module_name")
    except ImportError:
        pass
    else:
        assert False

    assert load_module_from_file_location("${HOME}/example.py").some_var == 777

    assert load_module_from_file_location("$HOME/example.py").some_var == 777


# Generated at 2022-06-21 23:42:10.286606
# Unit test for function str_to_bool
def test_str_to_bool():
    
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no")== False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False


# Generated at 2022-06-21 23:42:19.315521
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("Yes")
    assert str_to_bool("Y")
    assert str_to_bool("yep")
    assert str_to_bool("Yup")
    assert not str_to_bool("n")
    assert not str_to_bool("No")
    assert not str_to_bool("N")
    assert not str_to_bool("f")
    assert not str_to_bool("F")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    with pytest.raises(ValueError):
        str_to_bool("gibberish")
    with pytest.raises(ValueError):
        str_to_bool("onoff")

# Generated at 2022-06-21 23:42:31.451006
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests load_module_from_file_location function."""
    # A) Check if function imports module.
    import some_module

    some_module = load_module_from_file_location("some_module")
    assert some_module is not None

    # B) Check if location parameter can be of a Path type.
    location = Path("some_module")
    some_module = load_module_from_file_location(location)
    assert some_module is not None

    # C) Check if location parameter can be of a bytes type.
    location = b"some_module"
    some_module = load_module_from_file_location(location.decode("utf8"))
    assert some_module is not None

    # D) Check if location parameter can contain environment variable
    #    in format ${some_env_var

# Generated at 2022-06-21 23:42:36.112902
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import os

    os.environ["TEST_ENV_VAR"] = "test"

    some_file = load_module_from_file_location("${TEST_ENV_VAR}")
    assert some_file is not None

    another_file = load_module_from_file_location("test")
    assert another_file is not None

    del os.environ["TEST_ENV_VAR"]

# Generated at 2022-06-21 23:42:44.185773
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool('yes') == True
    assert str_to_bool('t') == True
    assert str_to_bool('true') == True
    assert str_to_bool(True) == True
    assert str_to_bool('1') == True
    assert str_to_bool(1) == True

    assert str_to_bool('n') == False
    assert str_to_bool('no') == False
    assert str_to_bool('f') == False
    assert str_to_bool('false') == False
    assert str_to_bool(False) == False
    assert str_to_bool('0') == False
    assert str_to_bool(0) == False


# Generated at 2022-06-21 23:42:53.933569
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") == True
    assert str_to_bool("true") == True
    assert str_to_bool("t") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("on") == True
    assert str_to_bool("y") == True
    assert str_to_bool("0") == False
    assert str_to_bool("false") == False
    assert str_to_bool("f") == False
    assert str_to_bool("no") == False
    assert str_to_bool("off") == False
    assert str_to_bool("n") == False
    try:
        str_to_bool("not a valid boolean value")
        raise AssertionError("ValueError expected")
    except ValueError:
        pass

# Generated at 2022-06-21 23:43:03.301281
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    from tempfile import TemporaryDirectory
    from types import ModuleType
    from typing import Callable, Union

    # This just a list of all functions available for testing:
    test_functions = [
        "load_module_from_file_location",
    ]

    # This variable is used when needed to pass an argument of a string type
    # to the tested function. It is just a alias to the string type.
    # This variable is needed because os.environ["some_env_var"] is of a
    # byte type, but tested function expects an argument of a string type.
    str = str

    # When running unit test, some environment variables can be defined.
    # This just a list of all these variables:
    env_var_list = ["TEST_LOAD_FILE_LOCATION"]

    # This variable is used to store

# Generated at 2022-06-21 23:43:10.862802
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import sys
    import tempfile

    # A) Check if loading module with correct parameters works.
    sys.modules.pop("test_module", None)
    with tempfile.NamedTemporaryFile(mode="w+") as f:
        f.write("test_module_var = 1")
        f.seek(0)
        module = load_module_from_file_location(f.name)
    assert module.__name__ == "test_module"
    assert module.test_module_var == 1
    # Check if load_module_from_file_location does not override
    # test_module for every call.
    module = load_module_from_file_location(f.name)
    assert module.__name__ == "test_module"
    assert module.test_module_var == 1
    # Check if this

# Generated at 2022-06-21 23:43:20.061347
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function."""
    # Need to add test also for environments variables
    x = load_module_from_file_location(__file__)
    assert x
    assert hasattr(x, "__file__")
    assert x.__file__ == __file__
    y = load_module_from_file_location(Path(__file__))
    assert y
    assert hasattr(y, "__file__")
    assert y.__file__ == __file__

# Generated at 2022-06-21 23:43:33.307633
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_statement = (
        "from sanic.utils import load_module_from_file_location\n"
        "os.environ['TEST_ENV_VAR'] = 'test_value'\n"  # nosec
        "some_module = load_module_from_file_location(\n"
        "    'sanic.utils',\n"
        "    '/some/path/${TEST_ENV_VAR}/Sanic/utils.py'\n"
        ")"
    )

    local_scope = {}
    exec(  # nosec
        compile(import_statement, "testfile", "exec"), {}, local_scope
    )
    assert local_scope["some_module"].__file__ == "utils.py"

# Generated at 2022-06-21 23:43:47.078403
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import sys
    import os

    # A) Test if function raises LoadFileException when incorrect environment
    #    variable was passed.
    try:
        load_module_from_file_location("/some/path/${some_incorrect_var}")
    except LoadFileException:
        pass
    else:
        raise Exception("Test for incorrect environment variable failed!")

    # B) Test if function successfully loads module from file if path to it
    #    was provided.
    test_module = load_module_from_file_location(
        "/".join(os.path.realpath(__file__).split("/")[:-1])
        + "/test_data/test_module.py"
    )
    assert "test_module" in sys.modules
    assert "test_module" == test_module.__

# Generated at 2022-06-21 23:43:54.986202
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import pytest

    def _clean_modules():
        # Clean up modules after testing
        _cpath = sys.path[-1]
        sys.path.pop()
        sys.modules.pop("test_config")
        sys.modules.pop("test_config_package")
        sys.modules.pop("test_config_package.test_config_package")
        del sys.modules["test_config"]
        del sys.modules["test_config_package"]
        del sys.modules["test_config_package.test_config_package"]
        try:
            sys.path.remove(_cpath)
        except ValueError:
            pass

    def _get_config(location):
        config = load_module_from_file_location(location)
        _clean_modules()
        return config

    # Case

# Generated at 2022-06-21 23:44:06.443705
# Unit test for function str_to_bool
def test_str_to_bool():
    # Testing truth values.
    assert str_to_bool("Y") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("YEP") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("YUP") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("T") is True
    assert str_to_bool("True") is True
    assert str_to_bool("TRUE") is True
    assert str_

# Generated at 2022-06-21 23:44:15.091828
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True, "Should be True"
    assert str_to_bool("TruE") == True, "Should be True"
    assert str_to_bool("y") == True, "Should be True"
    assert str_to_bool("Y") == True, "Should be True"
    assert str_to_bool("yes") == True, "Should be True"
    assert str_to_bool("Yes") == True, "Should be True"
    assert str_to_bool("yeti") != True, "Should not be True"

    assert str_to_bool("false") == False, "Should be False"
    assert str_to_bool("FALSE") == False, "Should be False"
    assert str_to_bool("n") == False, "Should be False"
    assert str_

# Generated at 2022-06-21 23:44:28.529739
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("YES") == True
    assert str_to_bool("Enable") == True
    assert str_to_bool("1") == True
    assert str_to_bool("no") == False
    assert str_to_bool("FAlSe") == False
    assert str_to_bool(" off ") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("0") == False
    try:
        str_to_bool("1 2")
    except ValueError as err:
        assert str(err) == 'Invalid truth value 1 2'
    try:
        str_to_bool("Yuppi")
    except ValueError as err:
        assert str(err) == 'Invalid truth value yuppi'

# Generated at 2022-06-21 23:44:36.129415
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os.path
    # Check loading existing file.
    with tempfile.NamedTemporaryFile(mode="w+") as file:
        file.write("import os\n")
        file.flush()
        assert load_module_from_file_location(file.name).os is os
    # Check loading file using path which contains env variables.
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = os.path.join(tmpdir, "${foo}", "baz")
        os.makedirs(tmpdir)
        with open(os.path.join(tmpdir, "foo.py"), "w") as file:
            file.write("import os\n")

# Generated at 2022-06-21 23:44:46.006962
# Unit test for function str_to_bool
def test_str_to_bool():  # pylint: disable=unused-variable,redefined-outer-name
    assert str_to_bool("True") is True
    assert str_to_bool("1") is True
    assert str_to_bool("y") is True
    assert str_to_bool("on") is True

    assert str_to_bool("False") is False
    assert str_to_bool("0") is False
    assert str_to_bool("n") is False
    assert str_to_bool("off") is False

    with pytest.raises(ValueError):
        str_to_bool("Trues")

# Generated at 2022-06-21 23:44:47.158144
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

# Generated at 2022-06-21 23:44:50.459116
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os

    parent_dir = os.path.dirname(os.path.realpath(__file__))
    load_module_from_file_location(
        parent_dir + "/files/test_load_module_from_file_location.py"
    )



# Generated at 2022-06-21 23:44:59.457935
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["ENV_VAR_TEST_A"] = "env_var_test_a_value"
    os_environ["ENV_VAR_TEST_B"] = "env_var_test_b_value"
    os_environ["ENV_VAR_TEST_C"] = "env_var_test_c_value"
    os_environ["ENV_VAR_TEST_D"] = "env_var_test_d_value"

    current_dir_file = load_module_from_file_location(
        Path(__file__).absolute().parent / "resources" / "config.py"
    )
    package_file = load_module_from_file_location(
        "test_utils.test_helpers.resources.config"
    )
    simple

# Generated at 2022-06-21 23:45:13.522565
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    from os.path import isfile
    from os import environ, remove

    def create_module_file(file_name, content):
        """Create temporary python file"""
        temp_file = tempfile.NamedTemporaryFile(mode="w", delete=False)
        temp_file.write(content)
        temp_file.close()
        return temp_file.name

    # Check environment variables in config file to load
    environ["var"] = "test_var"
    temp_file_name = create_module_file("test", "a = 1")

    module = load_module_from_file_location(temp_file_name)
    assert module.a == 1
    remove(temp_file_name)


# Generated at 2022-06-21 23:45:22.707195
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    It is a unit test for function load_module_from_file_location:

    - It check that this function works properly with the file path
      without the environment variables.
    - It check that this function works properly with the file path
      with the environment variables.
    - It check that this function raises the LoadFileException
      with invalid environment variables.
    - It check that this function works properly with the module name.
    - It check that this function works properly with the module name
      which has dots.
    - It check that this function raises the ValueError with invalid
      module name.
    """
    import os

    from pathlib import Path

    from sanic.exceptions import LoadFileException

    from sanic_envconfig import load_module_from_file_location

    # 1) It check that this function works properly with the file path
   

# Generated at 2022-06-21 23:45:30.143673
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # A) Given.
    os_environ["some_env_var"] = "some_value"
    # B) When.
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}/somefile.name"
    )

    # C) Then.
    assert module
    assert module.__name__ == "some_module_name"
    assert module.__file__ == "/some/path/some_value/somefile.name"

# Generated at 2022-06-21 23:45:42.564497
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test if we can provide a module name in format
    # "some_module_name" and its location in
    # format "/some/path/some_module_name.py" and get
    # a module from it
    module_0 = load_module_from_file_location(
        "some_module_name",
        "/home/milosz/Documents/sanic-motor/tests/test_module_0.py",
    )
    assert hasattr(module_0, "test_attribute")
    assert module_0.test_attribute == 2

    # Test if we can provide a module name in format
    # "some_module_name" and its location in
    # format "/some/path/${SOME_ENV_VAR}/some_module_name.py"
    # where ${SOME_ENV

# Generated at 2022-06-21 23:45:52.716092
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Yes") == True
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("No") == False
    assert str_to_bool("False") == False
    assert str_to_bool("true") == True
    assert str_to_bool("yeP") == True
    assert str_to_bool("yUP") == True
    assert str_to_bool("0") == False
    assert str_to_bool("1") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("T") == True
    assert str_to_bool("F") == False


# Generated at 2022-06-21 23:46:04.090087
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert str_to_bool("Y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("TrUe") is True
    assert str_to_bool("N") is False
    assert str_to_bool("NO") is False
    assert str_to_bool("fALS") is False
    with pytest.raises(ValueError):
        assert str_to_bool("invalid_input")
    assert type(
        load_module_from_file_location(__file__)
    ) == types.ModuleType
    assert os_environ["HOME"] == load_module_from_file_location(
        "${HOME}/${HOME}"
    ).__file__.split("/")[-2]
    assert "/tmp/${HOME}" != load_module_from_file_

# Generated at 2022-06-21 23:46:09.595305
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("YES")
    assert str_to_bool("yEs")
    assert str_to_bool("yep")
    assert str_to_bool("yUp")
    assert str_to_bool("true")
    asse

# Generated at 2022-06-21 23:46:21.590612
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    class MyException(Exception):
        pass

    # 1. Test with file that exist.
    some_conf_file = load_module_from_file_location("./tests/config_empty.py")
    assert some_conf_file.__file__ == "./tests/config_empty.py"

    # 2. Test with folder that exist.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("./tests")

    # 3. Test with file that does not exist.
    with pytest.raises(IOError):
        load_module_from_file_location("./tests/_non_existing_file.py")

    # 4. Test with file without extension.

# Generated at 2022-06-21 23:46:33.183128
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # We use fake environment variables to not pollute our own environment
    # variables.
    location = "./config.py"
    os_environ["FAKE_VAR"] = "fake_path"
    os.environ["FAKE_VAR2"] = "fake_path2"
    os.environ["FAKE_VAR3"] = "fake_path3"

    # Check that function load_module_from_file_location
    # raises LoadFileException if not all of environment
    # variables provided in location ${env_var} are defined
    # in environment.
    location = "${NOT_DEFINED_VAR}/config.py"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    # Check that function load_module_from_file_location

# Generated at 2022-06-21 23:46:43.461517
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unit test for function load_module_from_file_location."""

    import pytest
    from tempfile import TemporaryDirectory

    from sanic.constants import CONFIG_DEFAULTS
    from sanic.server import HttpProtocol
    from sanic.server import create_protocol

    from . import _get_server_settings
    from . import load_module_from_file_location

    # A) By Path-like object.
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)

        tmp_path = tmp_dir / "some_module_name.py"


# Generated at 2022-06-21 23:46:58.913556
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("T") == True
    assert str_to_bool("F") == False
    assert str_to_bool("Yes") == True
    assert str_to_bool("No") == False
    assert str_to_bool("Y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("y") == True
    assert str_to_bool("off") == False
    assert str_to_bool("on") == True
    assert str_to_bool("true") == True
    assert str_to_bool("False") == False
    assert str_to_bool("Yep") == True
    assert str_to_bool("nope") == False
    assert str

# Generated at 2022-06-21 23:47:11.479740
# Unit test for function str_to_bool

# Generated at 2022-06-21 23:47:21.880828
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('true') == True
    assert str_to_bool('True') == True
    assert str_to_bool('TRUE') == True
    assert str_to_bool('t') == True
    assert str_to_bool('yep') == True
    assert str_to_bool('1') == True
    assert str_to_bool('no') == False
    assert str_to_bool('f') == False
    assert str_to_bool('0') == False
    try:
        assert str_to_bool('yes')
        raise
    except ValueError:
        pass
    try:
        assert str_to_bool('perhaps')
        raise
    except ValueError:
        pass

# Generated at 2022-06-21 23:47:33.308573
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os
    import tempfile
    from shutil import rmtree

    from importlib import reload

    # Test A)
    with tempfile.TemporaryDirectory() as tempdir:
        os.environ["SOME_ENV_VAR"] = tempdir
        name = "some_module_name"
        location = "${SOME_ENV_VAR}/some_module.py"
        with open(os.path.join(tempdir, "some_module.py"), "w") as file:
            file.write("import os\na = 1\n")
        module = load_module_from_file_location(
            name, location, *(), **{}
        )
        assert module.a == 1

    reload(module)  # Module was imported so it was cached in sys.modules,


# Generated at 2022-06-21 23:47:41.887425
# Unit test for function str_to_bool
def test_str_to_bool():
    assert (
        str_to_bool("n") == False
    ), "n should be evaluated as False!"
    assert (
        str_to_bool("f") == False
    ), "f should be evaluated as False!"
    assert (
        str_to_bool("false") == False
    ), "false should be evaluated as False!"
    assert (
        str_to_bool("off") == False
    ), "off should be evaluated as False!"
    assert (
        str_to_bool("disable") == False
    ), "disable should be evaluated as False!"
    assert (
        str_to_bool("disabled") == False
    ), "disabled should be evaluated as False!"
    assert (
        str_to_bool("no") == False
    ), "no should be evaluated as False!"

# Generated at 2022-06-21 23:47:51.842892
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests 'load_module_from_file_location' function.

    1. Checks if function raises error if location consists of not
       existing environment variable.
    2. Checks if function successfully loaded module provided as
       a string of a module name.
    3. Checks if function successfully loaded module provided as
       a bytes path with environment variable
       and with encoding='utf8'.
    4. Checks if function successfully loaded module provided as
       a string path with environment variable.
    5. Checks if function successfully loaded module provided as
       a string path with environment variable and with encoding='utf8'.
    6. Checks if function successfully loaded module provided
       as an instance of Path object with environment variable.
    """
    from os import environ as os_environ
    from os import path as os_path
    from tempfile import mkstemp
    from textwrap import ded

# Generated at 2022-06-21 23:48:01.797965
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    PATH_TO_FILE_WITH_ENV_VAR = Path(os.path.dirname(__file__)) / "test_file_with_env_var.py"
    assert load_module_from_file_location(PATH_TO_FILE_WITH_ENV_VAR).module_var == "hello_world"

    PATH_TO_FILE_WITHOUT_ENV_VAR = "/nonexistent_path/nonexistent_file.py"
    try:
        load_module_from_file_location(PATH_TO_FILE_WITHOUT_ENV_VAR)
    except LoadFileException:
        pass


# Generated at 2022-06-21 23:48:12.666622
# Unit test for function str_to_bool
def test_str_to_bool():
    t_v = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]
    for _v in t_v:
        assert str_to_bool(_v) is True

    f_v = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]
    for _v in f_v:
        assert str_to_bool(_v) is False


# Generated at 2022-06-21 23:48:17.081807
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover
    from pathlib import Path


# Generated at 2022-06-21 23:48:27.226008
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    def _test_location(location, expected_return_value):
        if expected_return_value == "visit":
            os_environ["VISIT_BASE_PATH"] = "/some_path/visit/bin"
            result = load_module_from_file_location(location=location)
            assert result.visit_bin == "/some_path/visit/bin"
        else:
            result = load_module_from_file_location(location=location)
            assert result.some_key == "some_value"

    # A) Check if location is of string type (import_string() is callable)
    #    and it does not contain path separators.
    _test_location(location="some_module_name", expected_return_value="visit")

    # B) Check if location is of bytes type.

# Generated at 2022-06-21 23:48:47.526616
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("trUe") == True
    assert str_to_bool("1") == True

    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("0") == False
    assert str_to_bool("off") == False

    with pytest.raises(ValueError) as e:
        str_to_bool("x")

# Generated at 2022-06-21 23:48:57.208373
# Unit test for function str_to_bool
def test_str_to_bool():
    for true_value in {
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    }:
        assert str_to_bool(true_value) is True
    for false_value in {
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    }:
        assert str_to_bool(false_value) is False
    for bad_value in {"haha", "True", "TRUE", "True1"}:
        try:
            str_to_bool(bad_value)
            assert False
        except ValueError:
            pass

# Generated at 2022-06-21 23:49:01.582853
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    # Test simple load

# Generated at 2022-06-21 23:49:11.173861
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("Y")
    assert str_to_bool("n")
    assert str_to_bool("N")
    assert not str_to_bool("f")
    assert str_to_bool("true")
    assert not str_to_bool("false")
    assert str_to_bool("True")
    assert str_to_bool("t")
    assert str_to_bool("1")
    assert str_to_bool("F")
    assert str_to_bool("no")
    assert not str_to_bool("No")
    assert str_to_bool("0")
    assert str_to_bool("enable")
    assert not str_to_bool("disable")

# Generated at 2022-06-21 23:49:23.340524
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    try:
        import unittest.mock
    except ImportError:
        import mock

    test_env = {
        "some_env_var": "/some/path",
        "other_env_var": "other/path",
        "some_var": "some string",
    }


# Generated at 2022-06-21 23:49:35.878457
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("YeS") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("YEp") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("YUP") is True
    assert str_to_bool("t") is True
    assert str_to_bool("T") is True
    assert str_to_bool("true") is True

# Generated at 2022-06-21 23:49:43.139281
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    sys.path.append(".")
    os_environ["some_env_var"] = "path\\with\\env\\var"
    mod = load_module_from_file_location(
        "tests/test_config/test_config_location.py",
        bytes("tests/test_config/test_config_location.py", "utf-8"),
        "${some_env_var}/test_config_location.py",
    )
    assert mod.some_bool == False
    assert mod.some_int == 3
    assert mod.some_str == "some_str"



# Generated at 2022-06-21 23:49:52.551953
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("on") is True
    assert str_to_bool("y") is True
    assert str_to_bool("true") is True
    assert str_to_bool("1") is True
    assert str_to_bool("off") is False
    assert str_to_bool("n") is False
    assert str_to_bool("false") is False
    assert str_to_bool("0") is False
    try:
        str_to_bool("wrong")
    except ValueError:
        pass
    else:
        assert False, "Should have raised ValueError"

# Generated at 2022-06-21 23:50:03.912551
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import subprocess  # noqa
    import tempfile  # noqa
    import shutil  # noqa
    import sys  # noqa
    import os  # noqa

    config = """
config = {}
config['a'] = 'b'
"""

    def create_tmp_config_file(content):  # noqa
        fd, path = tempfile.mkstemp(suffix=".py", prefix="test_config_")
        os.close(fd)
        with open(path, "wb") as f:
            f.write(content.encode("utf8"))
        return path

    p = create_tmp_config_file(config)
    module = load_module_from_file_location(p)
    assert module.config["a"] == "b"

    module = load_module

# Generated at 2022-06-21 23:50:15.109557
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True")
    assert str_to_bool("tRue")
    assert str_to_bool("TRUE")
    assert str_to_bool("t")
    assert str_to_bool("1")
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("YeP")
    assert str_to_bool("UP")
    assert not str_to_bool("False")
    assert not str_to_bool("f")
    assert not str_to_bool("no")
    assert not str_to_bool("nO")
    assert not str_to_bool("0")
    assert not str_to_bool("n")
    assert not str_to_bool("off")
    assert not str_to_bool("OFF")