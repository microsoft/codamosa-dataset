

# Generated at 2022-06-21 23:40:23.830691
# Unit test for function str_to_bool
def test_str_to_bool():
    """Test function"""
    assert str_to_bool('y') == True
    assert str_to_bool('n') == False
    try:
        str_to_bool('some_string')
    except ValueError as exc:
        assert str(exc) == "Invalid truth value some_string"
    else:
        raise ValueError("Invalid truth value some_string", "not raised")

# Generated at 2022-06-21 23:40:34.579123
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory  # noqa

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)

        # Create example module in tmpdir
        tmpdir.joinpath("tmp_module.py").write_text(
            "test_var = 'test_val'"
        )
        tmpdir.joinpath("tmp_module.ini").write_text(
            "test_var = 'test_val'"
        )

        # Test loading module from str location
        assert (
            load_module_from_file_location(
                tmpdir.joinpath("tmp_module.py").absolute().as_posix()
            ).test_var
            == "test_val"
        )

# Generated at 2022-06-21 23:40:49.544202
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("Yes")
    assert str_to_bool("yEs")
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("on")
    assert str_to_bool("On")
    assert str_to_bool("ON")

    assert not str_to_bool("no")
    assert not str_to_bool("No")
    assert not str_to_bool("NO")
    assert not str_to_bool("off")
    assert not str_to_bool("Off")
    assert not str_to_bool("OFF")
    assert not str_to_bool("")
    assert not str_to_bool("f")
    assert not str_to_bool("F")

# Generated at 2022-06-21 23:41:00.205633
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    from io import StringIO

    test_config = '''
        key = "value"
        key2 = "value2"
        '''
    with open("test_config.py", "w") as f:
        f.write(test_config)

    cfg = load_module_from_file_location("test_config")

    assert cfg.key == "value"
    assert cfg.key2 == "value2"

    os.remove("test_config.py")

    # Environment variables
    os.environ["TEST_ENV_VAR"] = "env_var_value"
    cfg = load_module_from_file_location("./${TEST_ENV_VAR}/test_config")
    assert cfg.key == "value"
    assert cfg.key

# Generated at 2022-06-21 23:41:06.191195
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test module with a dotted location.
    assert (
        load_module_from_file_location("tests.test_common.test_module")
        == test_module  # noqa
    )

    # Test module with no extension.
    assert (
        load_module_from_file_location("tests.test_common.test_module_no_ext")
        == test_module_no_ext  # noqa
    )

    # Test module from custom path.
    assert (
        load_module_from_file_location("/tests/test_common/test_module.py")
        == test_module  # noqa
    )

    # Test module from custom path which is converted to Path.

# Generated at 2022-06-21 23:41:14.955111
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("True") == True
    assert str_to_bool("false") == False
    assert str_to_bool("YeS") == True
    assert str_to_bool("nO") == False

    try:
        str_to_bool("tr")
    except ValueError as exc:
        assert str(exc) == "Invalid truth value {val}".format(val='tr')


if __name__ == "__main__":
    test_str_to_bool()

# Generated at 2022-06-21 23:41:24.290250
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from pathlib import Path

    # test success import
    config = Path("tests/integration/configs/config.py")

    assert load_module_from_file_location(config) is not None

    # test failed import
    config = Path("tests/integration/configs/bad_config.py")
    try:
        # we assert that exception is raised
        load_module_from_file_location(config)
        assert False
    except PyFileError:
        assert True

# Generated at 2022-06-21 23:41:36.100388
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # You can use environment variables in format ${some_env_var}.
    os_environ["TEST_ENV_VAR"] = "/etc"
    config_file = load_module_from_file_location(
        "test_config", "/${TEST_ENV_VAR}/test_config.py"
    )
    assert config_file.test_config_test_value == 1

    # You can also use here pathlib.Path instances.
    config_file = load_module_from_file_location(
        Path("/etc/test_config.py")
    )
    assert config_file.test_config_test_value == 1

# Generated at 2022-06-21 23:41:47.676245
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa: D202
    # Check for correct values.
    assert str_to_bool("yes") == True
    assert str_to_bool("1") == True
    assert str_to_bool("true") == True
    assert str_to_bool("YES") == True

    assert str_to_bool("no") == False
    assert str_to_bool("0") == False
    assert str_to_bool("false") == False
    assert str_to_bool("False") == False

    # Check for incorrect values.
    try:
        str_to_bool("incorrect value")
        assert False, "ValueError was not raised"
    except ValueError:
        assert True



# Generated at 2022-06-21 23:42:00.469138
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("disabled") == False
    assert str_to_bool("1") == True
    assert str_

# Generated at 2022-06-21 23:42:13.634395
# Unit test for function str_to_bool
def test_str_to_bool():
    # Positive tests
    assert str_to_bool("y")
    assert str_to_bool("Yes")
    assert str_to_bool("TRUE")
    assert str_to_bool("1")
    assert str_to_bool("YEP")
    assert str_to_bool("Yup")
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")

# Generated at 2022-06-21 23:42:20.965426
# Unit test for function str_to_bool
def test_str_to_bool():
    truthy_values = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]
    falsy_values = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]
    for truthy in truthy_values:
        assert str_to_bool(truthy) == True
    for falsy in falsy_values:
        assert str_to_bool(falsy) == False

# Generated at 2022-06-21 23:42:31.927011
# Unit test for function str_to_bool
def test_str_to_bool():
    """Tests for function str_to_bool."""
    test_dict = {
        "y": True,
        "yes": True,
        "yep": True,
        "yup": True,
        "t": True,
        "true": True,
        "on": True,
        "enable": True,
        "enabled": True,
        "1": True,
        "n": False,
        "no": False,
        "f": False,
        "false": False,
        "off": False,
        "disable": False,
        "disabled": False,
        "0": False,
    }

# Generated at 2022-06-21 23:42:34.394547
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("on")
    assert str_to_bool("off") is False
    assert str_to_bool("anything else") is None

# Generated at 2022-06-21 23:42:43.824899
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("Y")
    assert str_to_bool("YES")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("N")
    assert not str_to_bool("NO")
    assert not str_to_bool("f")
    assert not str_

# Generated at 2022-06-21 23:42:53.850008
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    os.environ = dict(
        # this is not used in here, but is expected to be defined in environment
        some_env_var="some_value",
        # this must be used in here
        TEST_ENV_VAR="some_value",
    )
    LOCATION_TEXT_CONTENT = "TEST_NAME = 'some_value'"
    MOD_NAME = "some_module_name"
    temp_dir = Path(tempfile.gettempdir())
    bad_path = os.path.join(str(temp_dir), "some_bad_path", "module.py")
    # exists, but not a file
    os.mkdir(bad_path)
    # exists, but not a file

# Generated at 2022-06-21 23:43:02.009804
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-21 23:43:13.320439
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_ENV_VAR"] = "environment_variable"
    os_environ["TEST_ENV_VAR_2"] = "environment_variable_2"

    # Test if location contains environment variables.
    selected_module_name = "module_from_env_var"
    selected_module = load_module_from_file_location(
        selected_module_name,
        "/some/path/${TEST_ENV_VAR}/modules/${TEST_ENV_VAR_2}/modules/"
        f"{selected_module_name}.py",
    )
    assert selected_module.some_var == "environment_variable_2"

    # Test if some of environment variables are not set.
    # This should raise LoadFileException.

# Generated at 2022-06-21 23:43:19.873592
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_ENV_VAR"] = "test_val"
    location = "${TEST_ENV_VAR}/test_module.py"
    module = load_module_from_file_location(location)
    assert module.TEST_VAR == "test_val"
    del os_environ["TEST_ENV_VAR"]

# Generated at 2022-06-21 23:43:33.501816
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Loading file with some variables inside.
    os_environ["env_variable_1"] = "env_variable_1_value"
    location = (
        "${env_variable_1}/some_path/my_config.py"
    )
    module = load_module_from_file_location(location)
    assert module.__file__ == (
        "env_variable_1_value/some_path/my_config.py"
    )

    # B) Loading file without variables.
    location = "/path/to/file/my_config.py"
    module = load_module_from_file_location(location)
    assert module.__file__ == location

    # C) Loading file with non existing variables inside.

# Generated at 2022-06-21 23:43:46.948373
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("1") == True
    assert str_to_bool("y") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True

    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("False") == False
    assert str_to_bool("0") == False
    assert str_to_bool("n") == False
    assert str

# Generated at 2022-06-21 23:43:57.068846
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os.path
    import tempfile

    # test with unvalid path
    try:
        load_module_from_file_location("unvalid_path")
    except FileNotFoundError:
        pass


# Generated at 2022-06-21 23:44:07.794590
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('yes') == True
    assert str_to_bool('Yes') == True
    assert str_to_bool('no') == False
    assert str_to_bool('true') == True
    assert str_to_bool('false') == False
    assert str_to_bool('n') == False
    assert str_to_bool('off') == False
    try:
        str_to_bool('nod')
    except ValueError as e:
        assert 'Invalid truth value nod' == str(e)
    try:
        str_to_bool('fals')
    except ValueError as e:
        assert 'Invalid truth value fals' == str(e)

# Unit tests for function load_module_from_file_location
if __name__ == '__main__':
    __spec__ = None


# Generated at 2022-06-21 23:44:14.445728
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert __name__ == "__main__"
    try:
        module_ = load_module_from_file_location(__file__)
    except LoadFileException:
        import sys

        module_ = sys.modules[__name__]

    assert module_ is not None

# Generated at 2022-06-21 23:44:28.054289
# Unit test for function str_to_bool
def test_str_to_bool():
    """Tests str_to_bool function"""

# Generated at 2022-06-21 23:44:35.949832
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_string("sanic.websocket")
    load_module_from_file_location("sanic.websocket.websocket")
    load_module_from_file_location("sanic/websocket/websocket.py")
    assert Path("sanic/websocket/websocket.py").exists()
    load_module_from_file_location("sanic/websocket/websocket.py")
    assert load_module_from_file_location("sanic/websocket/websocket.py")
    assert load_module_from_file_location("sanic/websocket/websocket.py")
    assert os_environ["PATH"]
    os_environ["PATH"] = str(Path(".").absolute())

# Generated at 2022-06-21 23:44:47.598544
# Unit test for function str_to_bool
def test_str_to_bool():
    """Test str_to_bool function."""
    true_values = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]
    for true_value in true_values:
        assert str_to_bool(true_value)
    #
    false_values = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]
    for false_value in false_values:
        assert not str_to_bool(false_value)
    #

# Generated at 2022-06-21 23:44:55.161207
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("1") == True

    assert str_to_bool("no") == False
    assert str_to_bool("false") == False
    assert str_to_bool("f") == False
    assert str_to_bool("0") == False

    with pytest.raises(ValueError):
        str_to_bool("Some random text")

# Generated at 2022-06-21 23:45:08.204208
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "tests/config_files/module_to_load.py"
    module = load_module_from_file_location(location)
    assert module.name == "module_to_load"
    assert module.SECRET_KEY == "SECRET_KEY"
    assert module.SERVER_NAME == "localhost"
    assert module.MAX_CONNECTIONS == 12

    location = "tests/config_files/module_to_load"
    module = load_module_from_file_location(location)
    assert module.name == "module_to_load"
    assert module.SECRET_KEY == "SECRET_KEY"
    assert module.SERVER_NAME == "localhost"
    assert module.MAX_CONNECTIONS == 12

    location = "tests/config_files/conf_with_env_vars.py"

# Generated at 2022-06-21 23:45:18.018958
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1")
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("True")

    assert not str_to_bool("0")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("False")
    context = pytest.raises(ValueError, match="Invalid truth value")
    with context:
        str_to_bool("123y")

# Generated at 2022-06-21 23:45:32.757461
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True, "str_to_bool('y') should return True."
    assert str_to_bool("Y") == True, "str_to_bool('Y') should return True."
    assert str_to_bool("yes") == True, "str_to_bool('yes') should return True."
    assert str_to_bool("Yes") == True, "str_to_bool('Yes') should return True."
    assert str_to_bool("yEP") == True, "str_to_bool('yEP') should return True."
    assert str_to_bool("YeP") == True, "str_to_bool('YeP') should return True."
    assert str_to_bool("yup") == True, "str_to_bool('yup') should return True."
    assert str_

# Generated at 2022-06-21 23:45:44.260840
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import sys
    import os

    file_location = tempfile.mkdtemp()
    file_name = "test.py"
    file_path = os.path.join(file_location, file_name)

    with open(file_path, "w") as file:
        file.writelines(
            [
                "test_var = 'hello world!'\n",
                "print(test_var)\n",
                "other_var = 100\n",
            ]
        )


# Generated at 2022-06-21 23:45:53.799863
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """ Tests for load_module_from_file_location function.
    """
    from random import randint
    from string import ascii_letters

    # Test if module loads correctly.
    for _ in range(100):
        _test_module_name = "".join(
            ascii_letters[randint(0, len(ascii_letters) - 1)]
            for _ in range(randint(10, 20))
        )
        _test_module_text1 = "def foo():\n    return {randint}"
        _test_module_fn = "random"


# Generated at 2022-06-21 23:45:57.280401
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location(
            "bad location", "some_module_name", "/some/path/", True
        )
        assert False
    except LoadFileException:
        pass

# Generated at 2022-06-21 23:46:09.179137
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # With bytes location
    with tempfile.NamedTemporaryFile(mode="wb", dir=os.getcwd()) as f:
        f.write(b"some_module = object\n")
        f.flush()
        _module = load_module_from_file_location(f.name)
    assert isinstance(_module, types.ModuleType)
    assert _module.some_module is object

    # With str location
    with tempfile.NamedTemporaryFile(
        mode="w", dir=os.getcwd(), suffix=".py"
    ) as f:
        f.write("some_module = object\n")
        f.flush()
        _module = load_module_from_file_location(f.name)
    assert isinstance(_module, types.ModuleType)
    assert _module.some

# Generated at 2022-06-21 23:46:21.259932
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-21 23:46:32.879386
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (load_module_from_file_location(
        "${PWD}/tests/sanic_helpers/config.py",
    ).__dict__["HELLO_WORLD"]) == "HELLO WORLD"

    os_environ["SOME_ENV_VAR"] = os_environ["PWD"]
    assert (load_module_from_file_location(
        "${SOME_ENV_VAR}/tests/sanic_helpers/config.py"
    ).__dict__["HELLO_WORLD"]) == "HELLO WORLD"


# Generated at 2022-06-21 23:46:43.230222
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from nose.tools import assert_raises

    # A) Check that LoadFileException is raised if env variable does not exist.
    with NamedTemporaryFile(mode="w+", encoding="utf8") as conf_file:
        conf_file.write("some_var = 1")
        conf_file.seek(0)

        with assert_raises(LoadFileException) as e:
            load_module_from_file_location(
                "${UNDEFINED_ENV_VARIABLE}/some_file.txt"
            )
        assert (
            "The following environment variables are not set: "
            "UNDEFINED_ENV_VARIABLE"
        ) in str(e.exception)

    # B) Check that LoadFileException is raised if multiple env variables

# Generated at 2022-06-21 23:46:55.344182
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Yes")
    assert str_to_bool("True")
    assert str_to_bool("on")
    assert str_to_bool("1")
    assert not str_to_bool("No")
    assert not str_to_bool("False")
    assert not str_to_bool("off")
    assert not str_to_bool("0")
    assert str_to_bool("y")
    assert str_to_bool("n")
    assert str_to_bool("Y")
    assert str_to_bool("N")
    assert not str_to_bool("yep")
    assert not str_to_bool("yup")
    assert not str_to_bool("t")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")
   

# Generated at 2022-06-21 23:47:01.854716
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False

    assert str_to_bool("YES") is True
    assert str_to_bool("OFF") is False
    assert str_to_bool("TRUE") is True

    assert str_to_bool("yup") is True
    assert str_to_bool("disable") is False

    assert str_to_bool("1") is True
    assert str_to_bool("0") is False

    assert str_to_bool("") is False

# Generated at 2022-06-21 23:47:13.429737
# Unit test for function str_to_bool
def test_str_to_bool():

    assert str_to_bool("yes") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("TrUe") is True
    assert str_to_bool("off") is False
    assert str_to_bool("DisAbLed") is False

    with pytest.raises(Exception) as e:
        str_to_bool("lol")
    assert str(e.value) == "Invalid truth value lol"

# Generated at 2022-06-21 23:47:24.945170
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test for ModuleNotFoundError and PyFileError
    with pytest.raises(ImportError) as excinfo:
        load_module_from_file_location("some_non_existing_module")
    assert excinfo.value.name == "some_non_existing_module"

    with pytest.raises(PyFileError) as excinfo:
        load_module_from_file_location(
            "tests/files/pyfile_error.py"
        )  # test for PyFileError and IOError

    assert isinstance(excinfo.value, PyFileError)
    assert excinfo.value.file == "tests/files/pyfile_error.py"

    # Test for environment variables in configuration file path

# Generated at 2022-06-21 23:47:36.590080
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    #
    # load a module file
    #
    module = load_module_from_file_location("./tests/app.py")
    assert module.app.route("/")[0].__self__.name == "test_app"

    #
    # load a module from path
    #
    module = load_module_from_file_location("tests/app.py")
    assert module.app.route("/")[0].__self__.name == "test_app"

    #
    # raise exception if file not found
    #
    try:
        module = load_module_from_file_location("tests/wrong.py")
    except LoadFileException as err:
        assert str(err) == "Unable to load configuration file (tests/wrong.py)"
    else:
        assert False

    #

# Generated at 2022-06-21 23:47:49.974692
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) If wrong type of location is passed as a parameter:
    assert type(load_module_from_file_location(b"some_location", "bytes"))
    assert type(load_module_from_file_location({}, "dict"))
    assert type(load_module_from_file_location(42, "int"))
    assert type(load_module_from_file_location(3.14, "float"))

    # B) If location is not an environment variable ${...}
    #    and it does not contains /
    #    then import_string would be used:
    try:
        assert type(load_module_from_file_location("some_location", "dict"))
    except Exception as e:
        assert type(e) == ValueError

    # C) If location contains environment variable ${some_env_var}
   

# Generated at 2022-06-21 23:47:58.401965
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        str_to_bool(load_module_from_file_location('sanic.settings').TESTING)
        is False
    )
    assert (
        str_to_bool(load_module_from_file_location('sanic.settings').DEBUG)
        is False
    )
    assert (
        str_to_bool(load_module_from_file_location('sanic.settings').LOGO)
        is True
    )
    assert (
        str_to_bool(load_module_from_file_location('sanic.settings').SERVER_NAME)
        is True
    )
    assert (
        str_to_bool(load_module_from_file_location('sanic.settings').KEEP_ALIVE)
        is True
    )

# Generated at 2022-06-21 23:48:10.487200
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Unit tests for function load_module_from_file_location.
    Mark that the function uses some hardcoded system variables
    with which it's tested.
    """
    from os import environ as os_environ
    from os import path as os_path
    from tempfile import NamedTemporaryFile as ntf
    from contextlib import contextmanager as cm

    from copy import deepcopy as copy

    from pytest import fixture as pytest_fixture

    from sanic import Sanic
    from sanic.websocket import WebSocketProtocol

    from . import TestDefaults

    if not TestDefaults.files_to_remove:
        TestDefaults.files_to_remove = list()


# Generated at 2022-06-21 23:48:18.154717
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["HEROKU"] = "1"
    os_environ["SOME_NEW_ENV_VAR"] = "y"

    base_location = "/some/path"
    module_name = "test_module"
    module_path = f"{base_location}/{module_name}.py"


# Generated at 2022-06-21 23:48:24.329601
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('True') == True
    assert str_to_bool('FALSE') == False
    assert str_to_bool('YES') == True
    assert str_to_bool('No') == False

    try:
        str_to_bool('nothing')
        assert False
    except ValueError:
        assert True

    return True

# Generated at 2022-06-21 23:48:37.757088
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa

    str_yes = ["y", "yes", "yep", "yup", "t", "true", "on", "enable", "enabled", "1"]
    str_no = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]

    for val in str_yes:
        assert str_to_bool(val) is True
        assert str_to_bool(val.upper()) is True

    for val in str_no:
        assert str_to_bool(val) is False
        assert str_to_bool(val.upper()) is False

    try:
        str_to_bool("sss")
    except ValueError:
        pass
    else:
        raise Assertion

# Generated at 2022-06-21 23:48:49.191324
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("") is False
    assert str_to_bool(" ") is False
    assert str_to_bool("F") is False
    assert str_to_bool("FALSE") is False
    assert str_to_bool("faLse") is False
    assert str_to_bool("0") is False
    assert str_to_bool("n") is False
    assert str_to_bool("NO") is False
    assert str_to_bool("no") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False
    assert str_to_bool("disabled") is False
    assert str_to_bool("true") is True
    assert str_to_bool("T") is True

# Generated at 2022-06-21 23:49:07.446846
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def module_to_dict(module):
        return {
            attr: value
            for attr, value in module.__dict__.items()
            if not callable(value) and not attr.startswith("__")
        }

    def test_load_module_from_file_location(
        location_to_path, module_name, expected_result
    ):
        os_environ["DIR_NAME"] = "tests"
        os_environ["FILE_NAME"] = "config.py"

        location = location_to_path[module_name]
        module = load_module_from_file_location(location)
        result = module_to_dict(module)

        if expected_result.get("exception"):
            assert result.get("exception") is not None

# Generated at 2022-06-21 23:49:16.527664
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_file_path = Path("test.txt")
    with open(test_file_path, "w+") as test_file:
        test_file.write("test_text = 'Test text'")
    test_module = load_module_from_file_location(test_file_path)
    assert test_module.test_text == "Test text"
    os.remove(Path("test.txt"))

# Generated at 2022-06-21 23:49:22.845241
# Unit test for function str_to_bool
def test_str_to_bool():
    # some simple tests
    assert str_to_bool("on") is True
    assert str_to_bool("Off") is False
    assert str_to_bool("yup") is True
    assert str_to_bool("False") is False

    # some regression tests
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False

    # some negative tests
    from pytest import raises

    with raises(ValueError):
        str_to_bool("anything else")

# Generated at 2022-06-21 23:49:34.308644
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from pathlib import Path
    from os import path, environ
    import tempfile

    # A) Check if location contains any environment variables in format
    #    ${some_env_var}.
    test_module = Path(__file__).parent / "test_files" / "test_module.py"
    with tempfile.TemporaryDirectory() as tmpdirname:
        test_module_copy = path.join(
            tmpdirname, test_module.name.replace(".", "-" + os.getpid() + ".")
        )
        shutil.copy(
            str(test_module), test_module_copy
        )  # Modify test_module path to avoid
        test_module_copy = Path(test_module_copy)

# Generated at 2022-06-21 23:49:36.937075
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("Yes")
    assert str_to_bool("2") == False



# Generated at 2022-06-21 23:49:48.441968
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") == True
    assert str_to_bool("T") == True
    assert str_to_bool("1") == True
    assert str_to_bool("True") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("y") == True
    assert str_to_bool("false") == False
    assert str_to_bool("F") == False
    assert str_to_bool("0") == False
    assert str_to_bool("False") == False
    assert str_to_bool("no") == False
    assert str_to_bool("n") == False


# Generated at 2022-06-21 23:49:50.064485
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location("python-boilerplate.boilerplate")
        .__doc__
        .strip()
        == "python-boilerplate application configuration"
    )

# Generated at 2022-06-21 23:49:54.380642
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from subprocess import check_call

    try:
        check_call(["touch", "./__config.py"])
        from .__config import CONFIG
    finally:
        check_call(["rm", "./__config.py"])

    assert CONFIG == "Test"

# Generated at 2022-06-21 23:50:05.086247
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from collections import namedtuple

    # A) Test with some file that does not have .py extension.
    os_environ["some_env_var"] = "some/path"
    mod = load_module_from_file_location(
        "/${some_env_var}/location", encoding="utf8"
    )
    built_in = namedtuple("mock_module", ("name", "location", "encoding"))
    built_in.__module__ = "mock_module"
    assert mod == built_in(
        name="location", location="/some/path/location", encoding="utf8"
    )

    # B) Test with python file
    mod = load_module_from_file_location(
        "/${some_env_var}/file.py", encoding="utf8"
    )
    built

# Generated at 2022-06-21 23:50:17.003734
# Unit test for function str_to_bool
def test_str_to_bool():

    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("YeP") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("YUP") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("on") is True
    assert str_to_bool("On") is True
    assert str_to_bool("eNable") is True
    assert str_to_bool("enabled") is True