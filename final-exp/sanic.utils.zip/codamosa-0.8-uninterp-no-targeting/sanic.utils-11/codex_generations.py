

# Generated at 2022-06-21 23:40:24.325918
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    import tempfile

    # Check for any wrong initialization.
    try:
        load_module_from_file_location("")
    except LoadFileException as e:
        assert str(e) == "The following environment variables are not set: "
    except Exception:
        assert False, "Unexpected exception."

    # Check for doesnt_exist_location parameters.
    try:
        load_module_from_file_location("doesnt_exist_location")
    except LoadFileException as e:
        assert str(e) == "The following environment variables are not set: "
    except Exception:
        assert False, "Unexpected exception."

    # Check for doesnt_exist_location parameters with environment variable.

# Generated at 2022-06-21 23:40:35.184316
# Unit test for function str_to_bool
def test_str_to_bool():
    assert(str_to_bool("t") == True)
    assert(str_to_bool("T") == True)
    assert(str_to_bool("true") == True)
    assert(str_to_bool("TRUE") == True)
    assert(str_to_bool("1") == True)
    assert(str_to_bool("y") == True)
    assert(str_to_bool("Y") == True)
    assert(str_to_bool("yes") == True)
    assert(str_to_bool("YES") == True)
    assert(str_to_bool("yep") == True)
    assert(str_to_bool("YEP") == True)
    assert(str_to_bool("yup") == True)
    assert(str_to_bool("YUP") == True)

# Generated at 2022-06-21 23:40:40.232106
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # This test is only needed when users have dependencies that they
    # install using importlib.util.spec_from_file_location, hence it
    # raises an error.
    # TODO: Find out way to test it, because it's kinda hard.
    pass

# Generated at 2022-06-21 23:40:52.829661
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os
    from pathlib import Path

    some_module = load_module_from_file_location(
        "some_module_name", os.path.join(__file__, "../", "../", "sanic.py")
    )
    assert hasattr(some_module, "app")
    assert isinstance(some_module.app, type)
    assert some_module.app.__name__ == "Sanic"

    path = Path(os.path.join(__file__, "../", "../", "sanic.py"))
    some_module = load_module_from_file_location(
        "some_module_name", path
    )
    assert hasattr(some_module, "app")
    assert isinstance(some_module.app, type)

# Generated at 2022-06-21 23:41:04.865707
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:41:15.996969
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # To properly test this function we have to mock functions it uses
    # to retrieve environment variables, so that our virtual environment
    # has no effect on which variables will be available to our test.

    # We save original implementations of os.environ.__getitem__
    # and os.environ.keys to restore them after this test
    os_env_getitem_orig = os_environ.__getitem__
    os_env_keys_orig = os_environ.keys
    # And change them to our mocked implementation
    # which will be calling os.environ.get instead
    os_environ.__getitem__ = os_environ.get

    # We need to clean os.environ.keys so that it will not be affected
    # by our virtual environment from where we run tests.
    os_environ.keys = os_en

# Generated at 2022-06-21 23:41:27.604923
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Some string location
    assert load_module_from_file_location("./utils.py")
    assert load_module_from_file_location("/some/path/some_file.py")
    assert load_module_from_file_location("utils")

    # Some bytes location
    assert (
        load_module_from_file_location(b"./utils.py", encoding="utf8")
        == load_module_from_file_location("./utils.py")
    )

    # Path location
    assert (
        load_module_from_file_location(Path("./utils.py"))
        == load_module_from_file_location("./utils.py")
    )

    # Location with not defined env var
    with pytest.raises(LoadFileException) as e:
        load_

# Generated at 2022-06-21 23:41:37.809471
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Yes") == True
    assert str_to_bool("True") == True
    assert str_to_bool("On") == True
    assert str_to_bool("Enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("NO") == False
    assert str_to_bool("FALSE") == False
    assert str_to_bool("OFF") == False
    assert str_to_bool("DISABLED") == False
    assert str_to_bool("0") == False
    try:
        assert str_to_bool("foo")
        raise Exception()
    except ValueError:
        pass

# Generated at 2022-06-21 23:41:45.667792
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    # A) Test loading module from file path
    module_from_file_path = load_module_from_file_location(
        "sanic/helpers.py"
    )
    assert module_from_file_path.__file__.endswith("/helpers.py")
    assert hasattr(module_from_file_path, "str_to_bool")

    # B) Test loading module from pathlib.Path object
    module_from_path_object = load_module_from_file_location(
        Path("sanic/helpers.py")
    )
    assert module_from_path_object.__file__.endswith("/helpers.py")
    assert hasattr(module_from_path_object, "str_to_bool")

    # C) Test loading module from file

# Generated at 2022-06-21 23:41:58.691032
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pytest import raises, warns

    from . import app_config_file

    warn_message = "Unable to load configuration file"

    with warns(UserWarning, match=warn_message):
        raises(LoadFileException, load_module_from_file_location, "")

    with warns(UserWarning, match=warn_message):
        raises(LoadFileException, load_module_from_file_location, "")

    with warns(UserWarning, match=warn_message):
        raises(LoadFileException, load_module_from_file_location, "${}")

    with warns(UserWarning, match=warn_message):
        raises(LoadFileException, load_module_from_file_location, "${varA}")


# Generated at 2022-06-21 23:42:09.415453
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-21 23:42:18.988468
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from . import test_config_file

    # Test if location is a string and if it's loaded from file.
    assert isinstance(load_module_from_file_location(test_config_file), types.ModuleType)

    # Test 'A' from docstring.
    old_env = os_environ["TEST_ENV_VAR"]
    os_environ["TEST_ENV_VAR"] = "NEW_VALUE"
    assert isinstance(
        load_module_from_file_location(
            "config_file_env",
            "/some/path/${TEST_ENV_VAR}/${NON_EXISTENT_ENV_VAR}.py",
        ),
        types.ModuleType,
    )
    os_environ["TEST_ENV_VAR"] = old_

# Generated at 2022-06-21 23:42:31.260489
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import unittest
    from unittest.mock import patch

    from sanic.config import Config

    class Test(unittest.TestCase):
        def setUp(self):
            self.config = Config()

        def test_load_module_from_file_location_can_load_module_from_file_path(self):  # noqa
            module = load_module_from_file_location("tests/config_tests/module.py")
            self.assertTrue(hasattr(module, "hello"))

        def test_load_module_from_file_location_can_load_module_from_python_module(self):  # noqa
            module = load_module_from_file_location("tests.config_tests.module")
            self.assertTrue(hasattr(module, "hello"))

# Generated at 2022-06-21 23:42:35.940892
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("f") is False
    assert str_to_bool("F") is False
    assert str_to_bool("n") is False
    assert str_to_bool("N") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("t") is True
    assert str_to_bool("T") is True

# Generated at 2022-06-21 23:42:44.348859
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:42:49.277500
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("T") == True
    assert str_to_bool("true") == True
    assert str_to_bool("1") == True
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("0") == False
    with pytest.raises(ValueError):
        str_to_bool("qwerty")

# Generated at 2022-06-21 23:43:01.528173
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Tests for load_module_from_file_location function.

    # module_from_string
    assert load_module_from_file_location("os").system == os.system

    # module_from_path
    # A) Using environment variables in path.
    with patch("os.environ", {"PYTHONPATH": "/some/path/to/dir"}), patch(
        "os.path.isfile", lambda x: True
    ):
        assert (
            load_module_from_file_location("${PYTHONPATH}/some_module.py")
            .__file__
            == "/some/path/to/dir/some_module.py"
        )

    # B) Without using environment variables in path.

# Generated at 2022-06-21 23:43:13.114177
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:43:19.461270
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Check the case when the file can't be found
    try:
        load_module_from_file_location("invalid")
    except LoadFileException:
        pass

    # Check the case when the file is outside of the current directory.
    load_module_from_file_location("." + os.path.sep + "utilities" + os.path.sep + "__init__.py")

# Generated at 2022-06-21 23:43:23.203441
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Yes")
    assert str_to_bool("ON")
    assert str_to_bool("FALSE")

# Generated at 2022-06-21 23:43:32.317236
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    some_env_var = "some_env_var_name_to_test"
    some_env_var_value = "TEST_VALUE"

    os.environ[some_env_var] = some_env_var_value
    mod = load_module_from_file_location(
        "/some/dir/${%s}/file.py" % some_env_var
    )
    assert mod.__file__ == "/some/dir/TEST_VALUE/file.py"

    os.environ[some_env_var] = some_env_var_value
    mod_b = load_module_from_file_location("${%s}/file.py" % some_env_var)
    assert mod_b.__file__ == "TEST_VALUE/file.py"
   

# Generated at 2022-06-21 23:43:44.719562
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Yes")
    assert str_to_bool("YES")
    assert str_to_bool("yes")
    assert str_to_bool("y")
    assert str_to_bool("yup")
    assert str_to_bool("YUP")
    assert str_to_bool("true")
    assert str_to_bool("TRUE")
    assert str_to_bool("TrUe")
    assert str_to_bool("on")
    assert str_to_bool("ON")
    assert str_to_bool("1")
    assert str_to_bool("enable")
    assert str_to_bool("yep")
    assert str_to_bool("yEs")
    assert str_to_bool("0") == False
    assert str_to_bool("1") == True
   

# Generated at 2022-06-21 23:43:54.277756
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("Yes!") == True
    assert str_to_bool("1") == True

    assert str_to_bool("f") == False
    assert str_to_bool("F") == False
    assert str_to_bool("False") == False
    assert str_to_bool("FALSE") == False
    assert str_to_bool("False!") == False
    assert str_to_bool("0") == False

# Generated at 2022-06-21 23:44:06.205698
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("n") == False
    assert str_to_bool("FALSE") == False
    assert str_to_bool("1") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("off") == False
    assert str_to_bool("disabled") == False
    assert str_to_bool("t") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("true") == True
    assert str_to_bool("f") == False
    assert str_to_bool("0") == False
    assert str_to_bool("enable") == True

# Generated at 2022-06-21 23:44:17.320251
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests load_module_from_file_location function."""

    try:
        loaded_module = load_module_from_file_location(
            "applications.test_app_without_environ_vars",
            "tests/applications/test_app_without_environ_vars.py",
        )
    except Exception:
        assert False

    if not hasattr(loaded_module, "TEST_CONST") or loaded_module.TEST_CONST != 1:
        assert False


# Generated at 2022-06-21 23:44:30.135484
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    from sanic.config import Config
    from contextlib import contextmanager  # noqa

    @contextmanager
    def make_config_file(text: str) -> Iterator[Path]:
        # with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = tempfile.mkdtemp()
        file_path = Path(temp_dir) / "file.py"
        with open(file_path, "w") as file:
            file.write(text)
        yield file_path
        shutil.rmtree(temp_dir)

    with make_config_file(
        """
        SOME_VALUE = "value"
        """
    ) as file_path:
        config = Config(file_path)
        assert config.SOME_VALUE == "value"

# Generated at 2022-06-21 23:44:38.365341
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) When location is just path to file and no env variables in it.
    print("A) load_module_from_file_location")
    print("------")
    file_path = Path(__file__).parent.parent / "examples" / "aiohttp"
    config_path = file_path / "config.py"
    module = load_module_from_file_location(config_path)
    assert module.TEST == "OK"
    print("TEST=OK")

    # B) When location contains environment variables in format ${some_env_var}.
    print("B) load_module_from_file_location")
    print("------")
    env_var = "SANIC_EXAMPLE_AIOHTTP_CONFIG_PATH"

# Generated at 2022-06-21 23:44:47.055274
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("0") is False
    assert str_to_bool("not_bool") is False
    try:
        str_to_bool('True')
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 23:44:57.214502
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile as tmp_file

    tmpl = tmp_file(delete=False)
    tmpl.write(b"FOO=23")
    tmpl.close()


# Generated at 2022-06-21 23:45:09.510972
# Unit test for function str_to_bool
def test_str_to_bool():
    from pytest import raises

    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("off") is False
    assert str_to_bool("on") is True
    assert str_to_bool("f") is False
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("false") is False

    with raises(ValueError):
        assert str_to_bool("yest") is True
    with raises(ValueError):
        assert str_to_

# Generated at 2022-06-21 23:45:22.121609
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    config_file_name = "config.py"

    os_environ["config_path_env_variable"] = "/some/path"
    config_file = open(
        "/tmp/" + config_file_name, "w"
    )  # config file in temporary directory
    config_file.write("config_var=1\n")
    config_file.close()

    # 1.
    config = load_module_from_file_location(
        "/tmp/" + config_file_name
    )  # load config from file
    assert config.config_var == 1

    # 2. absolute path
    config = load_module_from_file_location(
        "/tmp/${config_path_env_variable}/${config_path_env_variable}.py"
    )
    assert config.config_var == 1

# Generated at 2022-06-21 23:45:32.205084
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("os") is os
    assert load_module_from_file_location("os.path") is os.path
    assert load_module_from_file_location("__builtin__") is __builtin__

    assert load_module_from_file_location("sys.path") is sys.path
    assert load_module_from_file_location("os.path.sep") is os.path.sep
    assert load_module_from_file_location("__builtin__.True") is True

    dummy_module = load_module_from_file_location(
        "sanic.test_module.test_module"
    )
    assert dummy_module
    assert dummy_module.test_module_var == "test_module_var"


# Generated at 2022-06-21 23:45:43.894022
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("1") == True
    assert str_to_bool("false") == False
    assert str_to_bool("False") == False
    assert str_to_bool("f") == False
    assert str_to_bool("F") == False
    assert str_to_bool("n") == False
    assert str_to_bool("N") == False
    assert str_

# Generated at 2022-06-21 23:45:53.275878
# Unit test for function str_to_bool
def test_str_to_bool():
    true_vals = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]
    false_vals = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]
    for val in true_vals:
        assert str_to_bool(val) is True
    for val in false_vals:
        assert str_to_bool(val) is False
    try:
        str_to_bool("something_else")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-21 23:46:04.802153
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("TrUe") is True
    assert str_to_bool("true ") is True
    assert str_to_bool("true  ") is True
    assert str_to_bool("true   ") is True
    assert str_to_bool("1") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool(" y ") is True
    assert str_to_bool(" yes ") is True
    assert str_to_bool("t") is True

    assert str_to_bool("false") is False
    assert str_to_bool("False") is False
    assert str_to_bool("false ") is False
    assert str_to_bool

# Generated at 2022-06-21 23:46:17.607552
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-21 23:46:23.265367
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("1") is True
    assert str_to_bool("no") is False
    assert str_to_bool("NO") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False
    assert str_to_bool("0") is False
    try:
        str_to_bool("true!")
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-21 23:46:34.508078
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("YeS")
    assert str_to_bool("Yes")
    assert str_to_bool("yeP")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("NO")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")

# Generated at 2022-06-21 23:46:44.514823
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test A, B, C from docstring.
    location = (
        "./tests/integration/test_config_files/config.py"
        if "DRONE" in os_environ
        else "tests/integration/test_config_files/config.py"
    )
    module = load_module_from_file_location(location)
    assert module.TEST_NAME == "integration"
    assert module.TEST_HELLO == "world"

    # Test without arguments.
    module = load_module_from_file_location(location)
    assert module.TEST_NAME == "integration"
    assert module.TEST_HELLO == "world"

    # Test with file path name as bytes object.

# Generated at 2022-06-21 23:46:56.627534
# Unit test for function str_to_bool
def test_str_to_bool():
    data_tuple_of_tuples = (
        ("y", True),
        ("yes", True),
        ("Y", True),
        ("Yes", True),
        ("YES", True),
        ("yEs", True),
        ("n", False),
        ("false", False),
        ("nO", False),
        ("f", False),
        ("FALSE", False),
        ("FaLsE", False),
    )

    for string, expected_bool in data_tuple_of_tuples:
        assert str_to_bool(string) == expected_bool

    # Test some bad value
    try:
        string = "somestring"
        str_to_bool(string)
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-21 23:47:11.439113
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes"), "yes"
    assert str_to_bool("YeS"), "YeS"
    assert str_to_bool("true"), "true"
    assert str_to_bool("True"), "True"
    assert str_to_bool("TrUe"), "TrUe"
    assert str_to_bool("on"), "on"
    assert str_to_bool("1"), "1"

    assert not str_to_bool("no"), "no"
    assert not str_to_bool("No"), "No"
    assert not str_to_bool("false"), "false"
    assert not str_to_bool("FaLse"), "FaLse"
    assert not str_to_bool("off"), "off"
    assert not str_to_bool("0"), "0"

   

# Generated at 2022-06-21 23:47:23.026485
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("no") == False
    assert str_to_bool("YeS") == True
    assert str_to_bool("N") == False
    assert str_to_bool("Yes") == True
    assert str_to_bool("nO") == False
    assert str_to_bool("Y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("y") == True
    assert str_to_bool("No") == False
    assert str_to_bool("YEP") == True
    assert str_to_bool("f") == False
    assert str_to_bool("YUP") == True
    assert str_to_bool("0") == False
    assert str_to_bool("T") == True


# Generated at 2022-06-21 23:47:34.543493
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D103
    import sys
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from .utils import create_file_in_directory_with_given_content

    # Create temporary directory
    with TemporaryDirectory() as tmp_dir_name:
        tmp_dir = Path(tmp_dir_name)

        # A) Create simple config file with content 'some_variable = "some_value"'
        simple_config_file = tmp_dir / "simple_config_file.py"
        create_file_in_directory_with_given_content(
            tmp_dir, "simple_config_file.py", "some_variable = \"some_value\""
        )

        # Load the config

# Generated at 2022-06-21 23:47:42.565893
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import json
    import tempfile
    from os import environ as os_environ

    # A) Test loading .json files
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)

        # 1. Test loading not existing .json file
        with pytest.raises(IOError):
            load_module_from_file_location(temp_dir / "some_not_existing.json")

        # 2. Test loading empty .json file
        with (temp_dir / "empty.json").open("w") as json_file:
            json.dump({}, json_file)

        with pytest.warns(UserWarning) as warnings:
            json_module = load_module_from_file_location(temp_dir / "empty.json")

# Generated at 2022-06-21 23:47:47.764372
# Unit test for function str_to_bool
def test_str_to_bool():
    values = (
        ("true", True),
        ("false", False),
        ("yes", True),
        ("no", False),
        ("on", True),
        ("off", False),
        ("y", True),
        ("n", False),
    )
    for val, expected in values:
        assert str_to_bool(val) == expected

# Generated at 2022-06-21 23:47:55.997303
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('Y') == True
    assert str_to_bool('N') == False
    assert str_to_bool('y') == True
    assert str_to_bool('n') == False
    assert str_to_bool('yes') == True
    assert str_to_bool('no') == False
    assert str_to_bool('Yep') == True
    assert str_to_bool('F') == False
    assert str_to_bool('False') == False
    assert str_to_bool('Nope') == False

# Generated at 2022-06-21 23:48:09.347336
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test function 'load_module_from_file_location'.
    Return True if test was successful, otherwise raise
    an error."""

    def _test_load_module_from_file_location(location, expected):

        module_to_test = load_module_from_file_location(location)
        for attr in expected:
            assert getattr(module_to_test, attr) == expected[attr]

    # Test if it loaded the module from a relative file path
    location = ".test_module"
    expected = {"hello": "world!"}
    _test_load_module_from_file_location(location, expected)

    # Test if it loaded the module from an absolute file path
    location = Path.cwd() / location
    _test_load_module_from_file_location(location, expected)

   

# Generated at 2022-06-21 23:48:20.339893
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("no")
    assert not str_to_bool("n")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-21 23:48:29.775144
# Unit test for function str_to_bool
def test_str_to_bool():
    """
    >>> test_str_to_bool()
    
    """
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("no") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("true") is True
    assert str_to_bool("false") is False
    assert str_to_bool("t") is True
    assert str_to_bool("f") is False
    assert str_to_bool("on") is True
    assert str_to_bool("off") is False
    assert str_to_bool("enable") is True

# Generated at 2022-06-21 23:48:39.903154
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ
    from pickle import dumps, loads

    from tempfile import NamedTemporaryFile
    from unittest.mock import patch

    def get_dumped_loaded_module_equivalent(location):
        _module = load_module_from_file_location(location)
        return loads(dumps(_module))

    def set_env_var(key, variable):
        environ[key] = variable

    def del_env_var(key):
        del environ[key]

    test_config_name1 = "test_config_name1"
    test_config_name2 = "test_config_name2"
    test_config_name3 = "test_config_name3"
    test_config_name4 = "test_config_name4"

    test_config

# Generated at 2022-06-21 23:48:51.752003
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    def _test_mod(location: Union[bytes, str, Path], **kwargs):

        if isinstance(location, str):
            location = location.encode()

        module = load_module_from_file_location(location, **kwargs)
        assert hasattr(module, "test_attr")
        assert module.test_attr == "test_value"

    _test_mod("tests/test_module")
    _test_mod("tests/test_module.py")

    _test_mod(b"tests/test_module.py", encoding="utf8")

    path = Path("tests/test_module.py")
    _test_mod(path)

    _test_mod("/some/path/tests/test_module")


# Generated at 2022-06-21 23:48:59.037042
# Unit test for function str_to_bool
def test_str_to_bool():
    # test positive cases
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    # test negative cases
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")

# Generated at 2022-06-21 23:49:09.822046
# Unit test for function str_to_bool

# Generated at 2022-06-21 23:49:22.735637
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # load_module_from_file_location(location, encoding=utf8, *args, **kwargs):
    # A) Create some file.
    with tempfile.TemporaryDirectory() as tmpdirname:
        file_path = Path(tmpdirname)/"some_file.py"
        with file_path.open("w+") as f:
            f.write("some_string = 'some_string'")

        # B) Load it with load_module_from_file_location.
        f = load_module_from_file_location(file_path)

        # C) Assert that it has some_string attribute.
        assert hasattr(f, "some_string")
        assert f.some_string == "some_string"

        # D) Create some file, but with wrong name.
        file_wrong_path

# Generated at 2022-06-21 23:49:35.512155
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("true") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("on") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("ENABLE") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("ENABLED") == True
    assert str_to_bool("1") == True



# Generated at 2022-06-21 23:49:44.169498
# Unit test for function str_to_bool
def test_str_to_bool():
    """Function test_str_to_bool() tests function str_to_bool().

    :returns: True if test passed, else False.

    """
    import string

    lowercase_true_examples = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]
    uppercase_true_examples = [x.upper() for x in lowercase_true_examples]
    lowercase_false_examples = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]

# Generated at 2022-06-21 23:49:56.606799
# Unit test for function str_to_bool
def test_str_to_bool():

    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("disabled") == False

# Generated at 2022-06-21 23:50:05.638381
# Unit test for function str_to_bool
def test_str_to_bool():
    assert(str_to_bool("Y") == True)
    assert(str_to_bool("y") == True)
    assert(str_to_bool("yes") == True)
    assert(str_to_bool("yup") == True)
    assert(str_to_bool("t") == True)
    assert(str_to_bool("true") == True)
    assert(str_to_bool("on") == True)
    assert(str_to_bool("enable") == True)
    assert(str_to_bool("enabled") == True)
    assert(str_to_bool("1") == True)
    assert(str_to_bool("N") == False)
    assert(str_to_bool("n") == False)
    assert(str_to_bool("no") == False)

# Generated at 2022-06-21 23:50:17.651993
# Unit test for function str_to_bool
def test_str_to_bool():

    from nose.tools import assert_true, assert_false, assert_raises

    assert_true(str_to_bool("True"))
    assert_true(str_to_bool("Yes"))
    assert_true(str_to_bool("t"))
    assert_true(str_to_bool("true"))
    assert_true(str_to_bool("1"))
    assert_true(str_to_bool("on"))
    assert_true(str_to_bool("y"))

    assert_false(str_to_bool("false"))
    assert_false(str_to_bool("f"))
    assert_false(str_to_bool("False"))
    assert_false(str_to_bool("NO"))
    assert_false(str_to_bool("0"))