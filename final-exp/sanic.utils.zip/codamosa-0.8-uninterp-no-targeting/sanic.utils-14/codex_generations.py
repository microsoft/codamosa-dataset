

# Generated at 2022-06-21 23:40:24.199029
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import mkdir, getcwd, environ

    def _create_config(tmp_directory):
        with open(tmp_directory + "/config.py", "w") as f:
            f.write("""
import os
CONFIG_OPTION = "CONFIG_OPTION_VALUE"
SECRET_KEY = os.environ['SECRET_KEY']
""")
        return tmp_directory + "/config.py"

    # Testing that it works with a string
    frompath = _create_config(mkdtemp())
    os_environ["SECRET_KEY"] = "testing"
    config = load_module_from_file_location(frompath)
    assert config.CONFIG_OPTION == "CONFIG_OPTION_VALUE"
   

# Generated at 2022-06-21 23:40:32.979203
# Unit test for function str_to_bool
def test_str_to_bool():
    for true_vals in ["y", "yes", "yep", "yup", "t", "true", "on", "enable", 
                "enabled", "1"]:
        assert True == str_to_bool(true_vals)
    
    for false_vals in ["n", "no", "f", "false", "off", "disable", "disabled", "0"]:
        assert False == str_to_bool(false_vals)

    try:
        str_to_bool('maybe')
        assert False
    except ValueError as e:
        assert 'Invalid truth value' in str(e)

# Generated at 2022-06-21 23:40:44.442826
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("N") == False
    assert str_to_bool("NO") == False
    assert str_to_bool("f") == False
    assert str_

# Generated at 2022-06-21 23:40:50.739013
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("on") is True
    assert str_to_bool("0") is False
    assert str_to_bool("No") is False
    assert str_to_bool("False") is False
    assert str_to_bool("Off") is False
    assert str_to_bool("T") is True
    assert str_to_bool("F") is False
    with pytest.raises(ValueError):
        str_to_bool("OMG")
    with pytest.raises(ValueError):
        str_to_bool("1omg")
    with pytest.raises(ValueError):
        str_to_bool("omg")

# Generated at 2022-06-21 23:41:02.939271
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("y") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("1") == True
    assert str_to_bool("no") == False
    assert str_to_bool("n") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("0") == False


# Generated at 2022-06-21 23:41:15.362759
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile
    import json
    import os

    # Prepare test variables.
    temp = tempfile.NamedTemporaryFile(delete=False)
    temp.close()
    temp_filename = temp.name

    json_dict = {"some_key": "some_val"}
    json.dump(json_dict, open(temp_filename, "w"))

    json_string = """
    [
        {"some_key": "some_val"},
        {"some_key": "some_val"}
    ]
    """
    json.dump(json.loads(json_string), open(temp_filename, "w"))

    # A) Test for valid json file.
    module = load_module_from_file_location(temp_filename, encoding="utf8")

# Generated at 2022-06-21 23:41:27.276581
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    import os
    import tempfile

    good_path_with_env_vars = f"/good/path/${{some_env_var}}/some_module_name.py"
    good_env_var_value = "value"

    @pytest.fixture
    def one_of_good_module_locations(scope="function"):
        yield good_env_var_value
        yield good_path_with_env_vars

    @pytest.fixture
    def module_with_all_good_locations(scope="function"):
        with tempfile.TemporaryDirectory() as good_path_with_env_var_value:
            with tempfile.TemporaryDirectory() as good_path:
                os.environ["some_env_var"] = good_path_with_env_

# Generated at 2022-06-21 23:41:37.632906
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    cases = (
        ("y", True),
        ("yes", True),
        ("yep", True),
        ("yup", True),
        ("t", True),
        ("true", True),
        ("enable", True),
        ("enabled", True),
        ("on", True),
        ("1", True),
        ("n", False),
        ("no", False),
        ("false", False),
        ("disable", False),
        ("disabled", False),
        ("off", False),
        ("0", False),
    )

    for v, result in cases:
        if result is not str_to_bool(v):
            raise ValueError

# Generated at 2022-06-21 23:41:47.394107
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("on") is True
    assert str_to_bool("1") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True

    assert str_to_bool("off") is False
    assert str_to_bool("0") is False
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False

    with pytest.raises(ValueError):
        str_to_bool("yuiop")

    with pytest.raises(ValueError):
        str_to_bool("20")

# Generated at 2022-06-21 23:42:00.398297
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    os_environ["for"] = "for"
    os_environ["b"] = "b"
    os_environ["c"] = "c"
    expected_result = "aaa_bbb_ccc"

    with tempfile.NamedTemporaryFile() as tmp_file:
        tmp_file.write(b"file_text = 'test'")
        tmp_file.flush()

        # Test for case where location is provided as a bytes instance
        module = load_module_from_file_location(
            location=b"${for}_${b}_${c}", encoding="ascii"
        )
        assert module.file_text == "test"
        assert module.__file__ == expected_result

        # Test for case where location is provided as a string instance


# Generated at 2022-06-21 23:42:06.797039
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("no") is False
    assert str_to_bool("0") is False
    assert str_to_bool("yEs") is True
    with pytest.raises(ValueError):
        str_to_bool("I'm not a boolean")

# Generated at 2022-06-21 23:42:17.549100
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") == True
    assert str_to_bool("YeS") == True
    assert str_to_bool("n") == False
    assert str_to_bool("yup") == True
    assert str_to_bool("off") == False
    assert str_to_bool("0") == False
    assert str_to_bool("1") == True
    assert str_to_bool("True") == True
    assert str_to_bool("FALSE") == False
    try:
        str_to_bool("some")
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-21 23:42:20.223032
# Unit test for function str_to_bool
def test_str_to_bool():
    import pytest
    with pytest.raises(ValueError):
        str_to_bool("")

# Generated at 2022-06-21 23:42:30.294025
# Unit test for function str_to_bool
def test_str_to_bool():
    data = (
        ("y", True),
        ("yes", True),
        ("yep", True),
        ("yup", True),
        ("t", True),
        ("true", True),
        ("on", True),
        ("enable", True),
        ("enabled", True),
        ("1", True),
        ("n", False),
        ("no", False),
        ("f", False),
        ("false", False),
        ("off", False),
        ("disable", False),
        ("disabled", False),
        ("0", False),
    )
    for value, expected in data:
        assert str_to_bool(value) is expected

# Generated at 2022-06-21 23:42:41.444158
# Unit test for function str_to_bool
def test_str_to_bool():
    # In case sensitive strings
    assert str_to_bool("True") == True
    assert str_to_bool("False") == False
    assert str_to_bool("On") == True
    assert str_to_bool("Off") == False
    assert str_to_bool("Enable") == True
    assert str_to_bool("Disable") == False
    assert str_to_bool("Enabled") == True
    assert str_to_bool("Disabled") == False

    # In case insensitive strings
    assert str_to_bool("t") == True
    assert str_to_bool("f") == False
    assert str_to_bool("true") == True
    assert str_to_bool("false") == False
    assert str_to_bool("on") == True
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:42:52.824979
# Unit test for function str_to_bool
def test_str_to_bool(): 
    assert str_to_bool('yes') == True
    assert str_to_bool('y') == True
    assert str_to_bool('Y') == True
    assert str_to_bool('1') == True
    assert str_to_bool('true') == True
    assert str_to_bool('t') == True
    assert str_to_bool('T') == True
    assert str_to_bool('enable') == True
    assert str_to_bool('on') == True
    assert str_to_bool('enabled') == True

    assert str_to_bool('no') == False
    assert str_to_bool('n') == False
    assert str_to_bool('N') == False
    assert str_to_bool('0') == False
    assert str_to_bool('false') == False
    assert str

# Generated at 2022-06-21 23:43:00.350382
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import os

    os.environ["SOMETHING"] = "/some/path"
    loaded_module = load_module_from_file_location(
        "test_config_module", "${SOMETHING}/test_config_module.py"
    )

    assert loaded_module.a == 3
    assert loaded_module.c == 1000

    del os.environ["SOMETHING"]

# Generated at 2022-06-21 23:43:12.568246
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool(None) == False
    assert str_to_bool("") == False
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("true") == True
    assert str_to_bool("false") == False
    assert str_to_bool("YES") == True
    assert str_to_bool("N") == False
    assert str_to_bool("yEs") == True
    assert str_to_bool("no") == False
    assert str_to_bool("TRUE") == True
    assert str_to_bool("FALSE") == False
    assert str_to_bool("yep") == True
    assert str_to_bool("nope") == False
    assert str_to_bool("on") == True


# Generated at 2022-06-21 23:43:22.003557
# Unit test for function str_to_bool
def test_str_to_bool():
    """Unit test for function str_to_bool."""
    assert str_to_bool("yes") is True
    assert str_to_bool("t") is True
    assert str_to_bool("1") is True
    assert str_to_bool("True") is True
    assert str_to_bool("TRue") is True
    assert str_to_bool("false") is False
    assert str_to_bool("f") is False
    assert str_to_bool("off") is False
    assert str_to_bool("0") is False
    assert str_to_bool("garbage") is not True
    assert str_to_bool("garbage") is not False

# Generated at 2022-06-21 23:43:34.264196
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # 1. Load module by name.
    assert (
        load_module_from_file_location("os").__name__ == "os"
    ), "Wrong module loaded."

    # 2. Load module by file path.
    assert (
        load_module_from_file_location("tests/integration/test_helpers_module.py")
        .__file__
        == str(Path("tests/integration/test_helpers_module.py"))
    ), "Wrong module loaded."

    # 3. Load module by file path containing environment variables.
    import os, sys

    os.environ["SOME_VAR"] = "test_helpers_module.py"
    assert load_module_from_file_location("tests/integration/${SOME_VAR}").__file__

# Generated at 2022-06-21 23:43:46.424669
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from importlib import reload
    from pathlib import Path
    from os import environ
    from os import remove as os_remove
    from os import mkdir as os_mkdir
    from shutil import rmtree as shutil_rmtree
    from tempfile import mkdtemp
    from textwrap import dedent
    from uuid import uuid4
    from warnings import warn

    temp_dir = Path(mkdtemp())

    # A) IOError if file doesn't exist.
    with pytest.raises(IOError):
        load_module_from_file_location(temp_dir / "some_file.py")

    # B) Module is loaded, if it's a file.

# Generated at 2022-06-21 23:43:56.893217
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True

    assert str_to_bool("false") == False
    assert str_to_bool("False") == False
    assert str_to_bool("f") == False
    assert str_to_bool("F") == False

    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True

    assert str_to_bool("no") == False
    assert str_to_bool("No") == False
    assert str_to_bool("n") == False
    assert str_

# Generated at 2022-06-21 23:44:07.061776
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test for function load_module_from_file_location with the case
    # when location is an environment variable.
    # In this case we test that function is able to substitute this variable
    # and then load module from file.

    # A) Create environment variable.
    # loc_in_env is just a random name for variable and
    # location points to a module which is going to be loaded.
    loc_in_env = "some_loc_in_env"
    location = Path(__file__).parent / "test_config.py"
    os_environ[loc_in_env] = str(location)

    # B) Load module.

# Generated at 2022-06-21 23:44:18.354581
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y")
    assert str_to_bool("YES")
    assert str_to_bool("YES")
    assert str_to_bool("YEP")
    assert str_to_bool("YUP")
    assert str_to_bool("T")
    assert str_to_bool("TRUE")
    assert str_to_bool("ON")
    assert str_to_bool("ENABLE")
    assert str_to_bool("ENABLED")
    assert str_to_bool("1")

    assert not str_to_bool("N")
    assert not str_to_bool("NO")
    assert not str_to_bool("F")
    assert not str_to_bool("FALSE")
    assert not str_to_bool("OFF")

# Generated at 2022-06-21 23:44:30.331419
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    load_module_from_file_location(
        "/some/path/some_file.py"  # Works even without extension
    )

    load_module_from_file_location("some_name", "/some/path/some_file.py")

    load_module_from_file_location("some_name", "/some/path/some_file")

    load_module_from_file_location(
        "some_name",
        "/some/path/some_file.py",
        "r",
    )  # Pass additional arguments to spec_from_file_location

    load_module_from_file_location(
        "some_name",
        "/some/path/some_file.py",
        encoding="utf8",
    )  # Pass additional keyworded arguments to spec_from_file_location

    load_

# Generated at 2022-06-21 23:44:38.477431
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    import sys
    import os
    import random

    def import_from_file_location(
        location: Union[bytes, str, Path], encoding: str = "utf8", *args, **kwargs
    ):  # noqa
        """Same as function load_module_from_file_location, but has specific
        interface to make it a bit easier to use for testing purposes."""

        return load_module_from_file_location(
            location=location, encoding=encoding, *args, **kwargs
        )

    def import_from_string(module_name: str, module_string: str) -> types.ModuleType:
        """Creates temporary file in system tmp dir,
        writes module_string to it and imports it with name module_name"""


# Generated at 2022-06-21 23:44:48.310789
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("yEs") is True
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("N") is False
    assert str_to_bool("No") is False
    assert str_to_bool("n0") is False
    assert str_to_bool("false") is False
    assert str_to_bool("False") is False
    assert str_to_bool("0") is False
   

# Generated at 2022-06-21 23:44:58.223287
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import random

    location_without_env_vars = Path("/tmp/temporary_config.py")
    location_with_env_vars = (
        Path(os_environ["HOME"]) / "temporary_config.py"
    )

    # If we have environment var env_var_for_file_location
    # then we will use it as a value to test load_module_from_file_location
    # function, otherwise we will generate random value.
    env_var_for_file_location = "env_var_for_file_location"
    if env_var_for_file_location in os_environ:
        location = location_with_env_vars
    else:
        location = location_without_env_vars

    value_to_load = random.randint(0, 1000)

# Generated at 2022-06-21 23:45:10.063108
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    os_environ["environ_var"] = "env_value"

    with open(os.devnull, "w") as null:
        content = "var = 1"

        with tempfile.NamedTemporaryFile(
            "w", delete=False, suffix=".py", dir=os.getcwd()
        ) as tmp_config_file:
            tmp_config_file_name = tmp_config_file.name
            tmp_config_file.write(content)
        with tempfile.TemporaryDirectory(dir=os.getcwd()) as tmp_dir:
            with open(os.path.join(tmp_dir, "config.py"), "w") as tmp_config_file:
                tmp_config_file.write(content)

            # A) Test succesfull file

# Generated at 2022-06-21 23:45:21.906088
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    # Make sure that positive values returns True
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    # Make sure that negative values returns False
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")

# Generated at 2022-06-21 23:45:32.957612
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = Path(__file__).parent.parent.joinpath(
        "examples/loading_module_from_file_and_module/some_module_name.py"
    )
    module = load_module_from_file_location(location)
    assert module.some_var == "some_value"
    assert module.some_var_with_env_var == "some_value_with_env_var"
    location = Path(__file__).parent.parent.parent.joinpath(
        "examples/loading_module_from_file_and_module/${RESULT_FOLDER}/some_module_name.py"
    )
    module = load_module_from_file_location(location)
    assert module.some_var == "some_value"
    assert module.some_var_with_

# Generated at 2022-06-21 23:45:38.203607
# Unit test for function str_to_bool
def test_str_to_bool():
    assert(str_to_bool("false") == False)
    assert(str_to_bool("yep") == True)
    assert(str_to_bool("no") == False)
    assert(str_to_bool("disable") == False)
    assert(str_to_bool("0") == False)

# Generated at 2022-06-21 23:45:39.915114
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("true") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("false") == False
    assert str_to_bool("0") == False

# Generated at 2022-06-21 23:45:50.567323
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def _load_module_from_file_location_not_path(
        location: str, encoding: str = "utf8", *args, **kwargs
    ) -> types.ModuleType:
        return load_module_from_file_location(
            location=location, encoding=encoding, *args, **kwargs
        )

    # 1a)
    module = _load_module_from_file_location_not_path(
        location="sanic.test_utils.test_app_settings",
        # package=None,
        # loader=None,
        # is_package=None,
    )
    assert module.FOO == "FOO"
    assert module.BAR == "BAR"
    assert module.BAZ == "BAZ"
    assert module.BOOL_TRUE is True
    assert module

# Generated at 2022-06-21 23:46:01.847860
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    temp_file_path = os.path.join(tempfile.gettempdir(), "test_config.txt")
    env_var_key = "TEST_VAR"
    env_var_value = "MY_TEST_VALUE"

    # Check that it returns module from ./
    os.environ[env_var_key] = env_var_value
    try:
        test_module = load_module_from_file_location(temp_file_path)
        assert type(test_module) is types.ModuleType
        assert test_module.__file__ == temp_file_path
    finally:
        os.environ.pop(env_var_key, None)

    # Check that it returns module from /some/path
    os.environ[env_var_key]

# Generated at 2022-06-21 23:46:13.219581
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_name = "test_file"
    file_dir = Path(Path(__file__).parent, "test_files")
    file_path = Path(file_dir, file_name)

    try:
        os_environ["TEST_VAR"] = "TEST_VAR_VALUE"
        test_module = load_module_from_file_location(
            Path(file_dir, Path("${TEST_VAR}") / file_name)
        )
        assert test_module.test == "test"
        test_module = load_module_from_file_location(file_path)
        assert test_module.test == "test"
    finally:
        os_environ.pop("TEST_VAR")

# Generated at 2022-06-21 23:46:24.530713
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("1") == True
    assert str_to_bool("true") == True
    assert str_to_bool("t") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("Enabled") == True

    assert str_to_bool("no") == False
    assert str_to_bool("false") == False
    assert str_to_bool("f") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("0") == False
    assert str_to_bool("Disabled") == False

    with pytest.raises(ValueError):
        str_to_bool("123")

# Generated at 2022-06-21 23:46:36.079007
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Checks correctness of module loading from file."""
    import distutils.util
    import importlib.util
    from os import environ, path
    from tempfile import TemporaryDirectory

    from sanic.exceptions import LoadFileException, PyFileError
    from sanic.helpers import load_module_from_file_location

    # Function body.
    with TemporaryDirectory() as directory:
        config_file_name = path.join(directory, "config.py")

# Generated at 2022-06-21 23:46:41.483829
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("__builtins__").__name__ == "builtins"

    assert (
        load_module_from_file_location("sanic.helpers").__name__ == "sanic.helpers"
    )

    assert (
        load_module_from_file_location("sanic.helpers").__file__.endswith("__init__.py")
    )

# Generated at 2022-06-21 23:46:48.394767
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location

    This test checks ability of load_module_from_file_location
    to expand environment variables in the file path.
    """
    # A) Empty string, should raise LoadFileException
    try:
        assert load_module_from_file_location("") is not None
    except LoadFileException:
        pass
    else:
        raise AssertionError(
            "Cannot check LoadFileException if there are no environment variables"
        )

    # B) Wrong environment variable, should raise LoadFileException
    try:
        assert load_module_from_file_location("${SOME_WRONG_ENV_VAR}") is not None
    except LoadFileException:
        pass

# Generated at 2022-06-21 23:47:01.307612
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile as tf
    tf_dir_path = tf.mkdtemp()
    tf_file_path = tf_dir_path + "/test_config.py"
    with open(tf_file_path, "w") as tf_file:
        tf_file.write("name = 'test'")
    module = load_module_from_file_location(tf_file_path)
    assert module.name == "test"

    tf_file_path = tf_dir_path + "/test_config"
    with open(tf_file_path, "w") as tf_file:
        tf_file.write("name = 'test'")
    module = load_module_from_file_location(tf_file_path)
    assert module.name == "test"


# Generated at 2022-06-21 23:47:12.767899
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False

# Generated at 2022-06-21 23:47:24.303585
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    environ = os.environ
    os.environ = {}

    assert "SOME_VAR" not in os.environ
    with pytest.raises(LoadFileException):
        _ = load_module_from_file_location("/some/path/${SOME_VAR}")
    os.environ = environ

    assert "SOME_VAR" not in os.environ
    with pytest.raises(LoadFileException):
        _ = load_module_from_file_location("/some/path/${SOME_VAR}")
    os.environ = environ

    os.environ["SOME_VAR"] = "/some/path"
    assert "SOME_VAR" in os.environ

# Generated at 2022-06-21 23:47:35.913954
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function."""
    from pathlib import Path
    import sys

    # 1st test
    current_dir = sys.path[0]
    module_path = "test_sanic_utils.py"
    module_name = Path(module_path).name
    module_name = module_name.replace(".py", "")

    module = load_module_from_file_location(Path(current_dir) / module_path)
    assert module.__name__ == module_name

    # 2nd test
    module = load_module_from_file_location(module_path)
    assert module.__name__ == module_name

    # 3rd test
    module_path = Path(current_dir) / "test_sanic_utils.txt"

# Generated at 2022-06-21 23:47:49.200928
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("Yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("y") is True
    assert str_to_bool("F") is False
    assert str_to_bool("true") is True
    assert str_to_bool("n") is False
    assert str_to_bool("0") is False
    assert str_to_bool("1") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("DISABLE") is False
    assert str_to_bool("yep") is True
    assert str_to_bool("nope") is False
    try:
        assert str_to_bool("NOPE")
    except ValueError:
        pass

# Generated at 2022-06-21 23:47:54.971726
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("NO") is False
    assert str_to_bool("t") is True
    assert str_to_bool("FALSE") is False
    assert str_to_bool("OFF") is False
    assert str_to_bool("0") is False
    assert str_to_bool("1") is True

# Generated at 2022-06-21 23:48:02.829956
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:48:15.117602
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def test_file_location(location, expected_name=None, expected_file=None):
        result = load_module_from_file_location(location)
        if expected_name is not None:
            assert result.__name__ == expected_name
        if expected_file is not None:
            assert result.__file__ == expected_file

    test_file_location("os.path", expected_name="posixpath")
    test_file_location(os.path, expected_name="posixpath")
    test_file_location(
        "tests.test_utils.test_load_module_from_file_location",
        expected_name="tests.test_utils.test_load_module_from_file_location",
    )

# Generated at 2022-06-21 23:48:26.641295
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    some_env_var = Path("/some/path/to/some/location").absolute()
    os_environ["some_env_var"] = str(some_env_var)

    # A) Test for location path with environment variable.
    loc1 = "${some_env_var}/some_module.py"
    mod1 = load_module_from_file_location(loc1)
    assert os.path.normpath(mod1.__file__) == str(some_env_var / "some_module.py")

    # B) Test for location path without environment variable.
    loc2 = str(some_env_var) + "/some_module.py"
    mod2 = load_module_from_file_location(loc2)
    assert os.path.normpath(mod2.__file__) == str

# Generated at 2022-06-21 23:48:38.871180
# Unit test for function str_to_bool
def test_str_to_bool():
    letters = list(map(chr, range(65, 91)))
    letters = letters + letters
    letters = letters + ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
    letters = letters + ["y", "n", "t", "f", "o", "s_e_p_a_r_a_t_o_r"]
    for letter in letters:
        for n in range(1, 10):
            for i in range(1, 10):
                try:
                    string = "".join([letter for _ in range(i)])
                    str_to_bool(string)
                except ValueError:
                    pass
                else:
                    assert False
                    # failure if no ValueError was raised

        assert str_to_bool("yes") is True

# Generated at 2022-06-21 23:48:51.808013
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from importlib import reload

    location_0 = "tests.test_utils"
    location_1 = Path("tests/test_utils.py")
    location_2 = "${PWD}/tests/test_utils.py"
    location_3 = b"${PWD}/tests/test_utils.py"
    location_4 = b"${PWD}/tests/test_utils"

    module_0 = load_module_from_file_location(location_0)
    module_1 = load_module_from_file_location(location_1)
    module_2 = load_module_from_file_location(location_2)
    module_3 = load_module_from_file_location(location_3)
    module_4 = load_module_from_file_location(location_4)

    assert module

# Generated at 2022-06-21 23:48:57.441566
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('yes')
    assert str_to_bool('on')
    assert str_to_bool('True')
    assert str_to_bool('TRUE')
    assert str_to_bool('1')
    assert str_to_bool('True 8')
    assert not str_to_bool('disable')
    assert not str_to_bool('FALSE')
    assert not str_to_bool('False')
    assert not str_to_bool('0')
    assert not str_to_bool('False 0')

# Generated at 2022-06-21 23:49:02.753374
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os
    import sys

    # Create test module
    test_mod_location = "/tmp/test_mod.py"

# Generated at 2022-06-21 23:49:11.096571
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """A function used for testing only"""
    try:
        location = (
            Path(__file__).parent.parent / "etc/config_test.py"
        )  # type: ignore
        mod = load_module_from_file_location(location)

    except Exception as e:
        print(f"Unexpected error: {e!r}")
    else:
        # For example, if we have a configuration file with this content:
        # some_variable = 5
        # some_variable2 = 45
        # then "mod" should be an object with 2 fields "some_variable" and
        # "some_variable2"
        assert mod.some_variable == 5
        assert mod.some_variable2 == 45

# Generated at 2022-06-21 23:49:23.308954
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    is_test_ok = True

    # Test 1: test pathlib.Path type passed
    try:
        with open("./tests/utils/test_config.py", "w") as f:
            f.write(
                'some_var = "some_val"\n'
                "some_list = [1, 2, 3, 4, 5]\n"
                'some_dict = {1: "one", 2: "two"}'
            )
        config = load_module_from_file_location(Path("./tests/utils/test_config"))
    except Exception as e:
        print("Test 1: Error - ", e)
        is_test_ok = False
    else:
        os.remove("./tests/utils/test_config")

# Generated at 2022-06-21 23:49:35.840112
# Unit test for function str_to_bool
def test_str_to_bool():
    # Test for return True case.
    assert str_to_bool("Y")
    assert str_to_bool("y")
    assert str_to_bool("YeS")
    assert str_to_bool("yEs")
    assert str_to_bool("yup")
    assert str_to_bool("Yes")
    assert str_to_bool("yep")
    assert str_to_bool("true")
    assert str_to_bool("1")
    assert str_to_bool("enabled")
    assert str_to_bool("enable")
    assert str_to_bool("T")
    assert str_to_bool("t")
    assert str_to_bool("On")
    assert str_to_bool("oN")
    assert str_to_bool("on")

# Generated at 2022-06-21 23:49:44.320322
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ
    from tempfile import TemporaryDirectory

    @pytest.fixture
    def make_tmp_py_file(tmpdir):
        # Makes py file with given content
        # and returns path to it.
        def f(content: str) -> str:
            file_name = tmpdir.join("test_file.py")
            file_name.write(content)
            return str(file_name)

        return f

    @pytest.fixture
    def make_tmp_py_file_path(make_tmp_py_file):
        # Makes py file with given content
        # and returns pathlib.Path to it.
        def f(content: str) -> Path:
            return Path(make_tmp_py_file(content))

        return f

    # Tests for file location

# Generated at 2022-06-21 23:49:56.694921
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    # A) Test raises LoadFileException if environment variable
    #    is not present.
    os_environ["SOME_ENVIRONMENT"] = "some_value"
    del os_environ["SOME_ENVIRONMENT"]
    try:
        load_module_from_file_location(
            "/some/path/${SOME_ENVIRONMENT}",
            location_arg="some_location_arg",
            some_kwarg="some_kwarg",
        )
        raise Exception("LoadFileException wasn't raised")
    except LoadFileException:
        pass

    # B) Test that it works with all types of paths.
    os_environ["SOME_ENVIRONMENT"] = "some_value"
    # B.1) pathlib.

# Generated at 2022-06-21 23:50:05.683425
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("yEs") == True
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("YEP") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("YUP") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("T") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("ON") == True

# Generated at 2022-06-21 23:50:17.687179
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("N") is False