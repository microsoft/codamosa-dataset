

# Generated at 2022-06-21 23:40:14.102112
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("no") == False
    assert str_to_bool("on") == True
    assert str_to_bool("off") == False
    assert str_to_bool("yep") == True
    assert str_to_bool("nope") == False
    assert str_to_bool("true") == True
    assert str_to_bool("false") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("enable") == True
    assert str_to_bool("disable") == False
    assert str_to_bool("enabled") == True
    assert str_to_bool("disabled") == False
    assert str_to_bool("y") == True

# Generated at 2022-06-21 23:40:22.794781
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # set environment variables
    os_environ["some_env_var_1"] = "some_value_1"
    os_environ["some_env_var_2"] = "some_value_2"

    # create module
    mod = load_module_from_file_location(
        Path.cwd() / "tests" / "unit" / "test_helpers.py"
    )
    assert mod.__name__ == "test_helpers"
    assert mod.__file__ == str(Path.cwd() / "tests" / "unit" / "test_helpers.py")

    # create module from python module path
    mod = load_module_from_file_location(
        "sanic.helpers.sockets.wait_for_sockets"
    )

# Generated at 2022-06-21 23:40:33.717384
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_config_dict = {"test_config_key": "test_config_value"}

    with open("test_config_file", "w") as config_file:
        config_file.write(f"test_config_dict = {test_config_dict}\n")

    test_module = load_module_from_file_location("test_config_file")

    assert test_module.test_config_dict == test_config_dict

    os_environ["TEST_ENV_VAR_FOR_CONFIG_FILE_LOAD_TEST"] = "test_config_file"
    test_module = load_module_from_file_location(
        "${TEST_ENV_VAR_FOR_CONFIG_FILE_LOAD_TEST}"
    )
    assert test_module.test_config_dict == test

# Generated at 2022-06-21 23:40:44.743082
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """This is a simple unit test for function
    'load_module_from_file_location'.
    """
    import pytest  # type: ignore
    from .config.test_load_module_from_file_location import (
        ConfigError,
        ConfigPath,
        ConfigEnv,
        ConfigDict,
        ConfigBytes,
    )

    # ConfigError
    test_config_error = ConfigError()

    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            location=test_config_error.location,
            *test_config_error.args,
            **test_config_error.kwargs,
        )

    # ConfigPath
    test_config_path = ConfigPath()

    test_config_path_result = load_module_from_file_location

# Generated at 2022-06-21 23:40:57.843162
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["key1"] = "val1"

    # Test str_to_bool
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_

# Generated at 2022-06-21 23:41:03.745377
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # get current location of this file
    file_path = os.path.realpath(__file__)
    # set location of module file
    module_path = file_path.replace('utils.py', 'module.py')
    # loading module from file
    module = load_module_from_file_location(module_path)

    assert module.variable == "some_value"
    assert module.variable_with_docstring == "some_value"

# Generated at 2022-06-21 23:41:15.471051
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import sys

    # Create temporary python module
    py_path = os.path.join(tempfile.gettempdir(), "tmp_test_module.py")

    with open(py_path, "w") as f:
        f.write(
            """
import os
import sys

test_var = "test"
test_var2 = os.getenv("test_var2")
test_var3 = sys.argv[1]
"""
        )

    # Assert it is available as module
    loaded_module = load_module_from_file_location(py_path)
    assert loaded_module.test_var == "test"

    # Assert it is available as module if path falls in some directory
    # which is not in sys.path
    loaded_module = load_module

# Generated at 2022-06-21 23:41:27.342975
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import os

    # Testing importing from .py file
    os.environ["some_env_var"] = "some_value"
    res = load_module_from_file_location(
        "tests/unit/core/helpers/test_vars_module.py"
    )
    assert res.TEST_VAR == "test_value"
    del os.environ["some_env_var"]

    # Testing importing from .py file with ${some_env_var}
    os.environ["some_env_var"] = "some_value"
    res = load_module_from_file_location(
        "tests/unit/core/helpers/${some_env_var}/test_vars_module.py"
    )
    assert res.TEST_VAR == "test_value"
   

# Generated at 2022-06-21 23:41:37.667856
# Unit test for function str_to_bool
def test_str_to_bool():
    for s in [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]:
        assert str_to_bool(s) is True, "{} not True".format(s)

    for s in [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]:
        assert str_to_bool(s) is False, "{} not False".format(s)



# Generated at 2022-06-21 23:41:49.287726
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("true") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("true") is True
    assert str_to_bool("On") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("on") is True
    assert str_to_bool("1") is True
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("YEP") is True
    assert str_to_bool("yup") is True
   

# Generated at 2022-06-21 23:42:01.790418
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests the load_module_from_file_location function"""

    # Test if loading from string is correct
    if sys.version_info >= (3, 8):
        module = load_module_from_file_location(
            "test_load_module_from_file_location.test_file",
            "tests/test_load_module_from_file_location/test_file.py"
        )
    else:
        module = load_module_from_file_location(
            "test_load_module_from_file_location.test_file",
            "tests/test_load_module_from_file_location/test_file.py",
            False
        )

    assert module.TEST_VARIABLE == "This is a test variable"

    # Test if loading from path is correct

# Generated at 2022-06-21 23:42:11.650734
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        "configs",
        "importlib_test.py",
    )
    module = load_module_from_file_location(location)
    assert module.__name__ == "importlib_test"
    assert module.some_text == "some_text"

    # Test bytes as a location
    module = load_module_from_file_location(location.encode())
    assert module.__name__ == "importlib_test"
    assert module.some_text == "some_text"

    # Test Path as a location
    module = load_module_from_file_location(Path(location))
    assert module.__name__ == "importlib_test"

# Generated at 2022-06-21 23:42:20.914949
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # WARN: Due to dynamic nature of python and usage of exec()
    #       in load_module_from_file_location function this test can
    #       fail in future if spec_from_file_location, module_from_spec
    #       or importlib.util functions change their code in ways
    #       this test doesn't account for.

    import tempfile
    import importlib.util

    from os import environ as os_environ
    from pathlib import Path

    # Prepare temporary environment variables
    new_env_vars = {
        "env_var_1": "env_var_1_value",
        "env_var_2": "env_var_2_value",
    }
    old_env_vars = {}
    os_environ_copy = os_environ.copy()

# Generated at 2022-06-21 23:42:31.926614
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ

    import json

    import pytest

    os_environ["SANIC_ENV_VAR"] = "1"
    os_environ["SANIC_NO_ENV_VAR"] = "1"

    obj_1 = load_module_from_file_location("json")
    obj_2 = json

    assert obj_1 == obj_2

    with pytest.raises(ImportError):
        load_module_from_file_location("not_existing_module_name")

    with pytest.raises(PyFileError):
        load_module_from_file_location("./tests/import_error.py")

    obj_3 = load_module_from_file_location(
        "./tests/not_existing_path/config.py"
    )

# Generated at 2022-06-21 23:42:40.015568
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1")
    assert str_to_bool("y")
    assert not str_to_bool("off")
    assert str_to_bool("T")
    assert str_to_bool("YUP")
    assert str_to_bool("0")
    assert str_to_bool("n")
    assert not str_to_bool("ON")
    assert str_to_bool("TRUE")
    assert not str_to_bool("DISABLED")
    assert not str_to_bool("offf")
    assert not str_to_bool("Trues")
    assert not str_to_bool("noooo")

# Generated at 2022-06-21 23:42:52.126503
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-21 23:43:02.919632
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    def test_open_and_exec_file_calls_import_string(mocker):
        # when
        actual = load_module_from_file_location("some_path")

        # then
        mocker.patch.object(import_string, "__name__", "mock")
        import_string.return_value.__name__ = "mock"
        assert actual == import_string.return_value
        import_string.assert_called_once_with("some_path")

    def test_spec_from_file_location_calls_import_string(mocker):
        # when
        actual = load_module_from_file_location("./some_module_name.py")

        # then

# Generated at 2022-06-21 23:43:13.738639
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Yep") == True
    assert str_to_bool("YUP") == True
    assert str_to_bool("t") == True
    assert str_to_bool("True") == True
    assert str_to_bool("On") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("False") == False
    assert str_to_bool("Off") == False
    assert str_to_bool("disabled") == False
    assert str

# Generated at 2022-06-21 23:43:23.221213
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("N") is False
    assert str_to_bool("false") is False
    assert str_to_bool("0") is False
    assert str_to_bool("no") is False

    try:
        str_to_bool("woot")
    except Exception as e:
        assert isinstance(e, ValueError)



# Generated at 2022-06-21 23:43:34.713740
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit tests for function load_module_from_file_location."""

    # All these, except WORKING_DIR, are set in test_main.
    WORKING_DIR = Path(__file__).resolve().parent

    assert load_module_from_file_location(
        WORKING_DIR / "config_test_file.py"
    )
    assert load_module_from_file_location(
        WORKING_DIR / "config_test_file.py", "latin1"
    )

    os_environ["some_env_var"] = str(WORKING_DIR)

    assert load_module_from_file_location(
        WORKING_DIR / "config_test_file.py",
        "${some_env_var}/config_test_file.py",
    )

    del os_

# Generated at 2022-06-21 23:43:46.811932
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from pathlib import Path
    from shutil import copyfile

    python_source_file = Path("config.py")
    python_source_file_copy = Path("config_copy.py")
    python_empty_file = Path("empty_file.py")
    python_nonexistent_file = Path("nonexistent_file.py")
    text_file = Path("config.txt")
    text_empty_file = Path("empty_file.txt")
    text_nonexistent_file = Path("nonexistent_file.txt")
    env_var_location = "/config.py"
    env_var_name = "config_path"

    class PyFileError(Exception):
        pass

    class LoadFileException(Exception):
        pass

    # Needed to set these as global variables
    #

# Generated at 2022-06-21 23:43:57.024857
# Unit test for function str_to_bool
def test_str_to_bool():

    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("on") is True
    assert str_to_bool("On") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("N") is False
    assert str_to_bool("NO") is False
    assert str_to_bool("false") is False
    assert str_to_bool("False") is False
    assert str_to_bool("off") is False
    assert str_

# Generated at 2022-06-21 23:44:07.724153
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest
    import tempfile
    import os

    # A) It loads files as parameter
    test_file_1 = tempfile.NamedTemporaryFile(mode="w", delete=False)
    test_file_1.write("test_variable_1 = True")
    test_file_1.close()
    test_module_1 = load_module_from_file_location(
        test_file_1.name, test_file_1.name
    )
    with pytest.raises(PyFileError):
        load_module_from_file_location(
            test_file_1.name, test_file_1.name + "x"
        )
    assert hasattr(test_module_1, "test_variable_1")

    # B) It loads directories as parameter
    test

# Generated at 2022-06-21 23:44:15.426072
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from sanic.config import  load_module_from_file_location
    import os

    os.environ["some_env_var"] = "some_env_var_path"

# Generated at 2022-06-21 23:44:28.981868
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location(
            "tests/samples/test_load_module_from_file_location_sample_1.py"
        ).SOME_VAR
        == "some_val"
    )
    assert (
        load_module_from_file_location(
            Path("tests/samples/test_load_module_from_file_location_sample_2.py")
        ).SOME_VAR
        == "some_val"
    )
    os_environ["SOME_ENV_VAR"] = "some_path"

# Generated at 2022-06-21 23:44:34.747536
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests if function load_module_from_file_location returns
    proper module if location is string or Path type."""
    os_environ["TEST_ENV_VAR"] = "/some/path"
    module = load_module_from_file_location(
        "some_module_name",
        "/some/path/${TEST_ENV_VAR}/some_config.py"
    )
    assert module.__name__ == "some_module_name"
    del os.environ["TEST_ENV_VAR"]



# Generated at 2022-06-21 23:44:47.163381
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from unittest.mock import patch

    # Set test environment variables
    os_environ["SOME_VAR"] = "some_value"
    os_environ["SOME_INT_VAR"] = "42"

    def mock_module_from_spec(spec):
        # Import Sanic
        from sanic import Sanic
        # Mock Sanic application instance
        sanic_app = Sanic("sanic_app")
        # Mock Sanic routes
        sanic_app.add_route = lambda handler, uri: None
        # Return mocked module
        return Sanic

    # Patch spec_from_file_location to make it return mocked spec
    # with mocked loader
    mocked_spec = types.SimpleNamespace()
    mocked_spec.loader = types.SimpleNamespace()
    mocked_spec.loader.exec

# Generated at 2022-06-21 23:44:54.691535
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True")
    assert str_to_bool("yes")
    assert str_to_bool("1")
    assert str_to_bool("t")
    assert str_to_bool("n")
    assert not str_to_bool("False")
    assert not str_to_bool("no")
    assert not str_to_bool("0")
    assert not str_to_bool("f")
    try:
        str_to_bool(" ")
    except ValueError:
        pass
    else:
        assert False, "Should raise ValueError"

# Generated at 2022-06-21 23:45:07.802571
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from io import StringIO
    import tempfile
    import sys
    import pytest
    from pathlib import Path
    from importlib.util import module_from_spec, spec_from_file_location
    from os import environ as os_environ
    
    envs = {
        "key1": "val1",
        "key2": "val2",
        "key3": "val3",
        "key4": "val4"
    }
    
    # Paths
    config_file_name = "config.py"
    # 1) Update current working dir
    current_dir = Path.cwd()
    
    # 1) Create temporary file with config
    # 2) Provide absolute path
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)


# Generated at 2022-06-21 23:45:19.069475
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("no") == False
    assert str_to_bool("t") == True
    assert str_to_bool("y") == True
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("false") == False
    assert str_to_bool("True") == True
    assert str_to_bool("Enabled") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("Yuk") == False
    assert str_to_bool("Y") == False

# Generated at 2022-06-21 23:45:32.172347
# Unit test for function str_to_bool
def test_str_to_bool():
    from sanic.exceptions import LoadFileException
    assert str_to_bool("1") == True
    assert str_to_bool("on") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("0") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False
    import pytest
    with pytest.raises(ValueError):
        str_to_bool("2")
        str_to_bool("on-off")
        str_to_bool("nope")
        str_to_bool("on-nope")



# Generated at 2022-06-21 23:45:43.005264
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("TRUE") == True

    assert str_to_bool("f") == False
    assert str_to_bool("F") == False
    assert str_to_bool("false") == False
    assert str_to_bool("False") == False
    assert str_to_bool("FALSE") == False

    with pytest.raises(ValueError):
        str_to_bool("a")
    with pytest.raises(ValueError):
        str_to_bool("b")

# Generated at 2022-06-21 23:45:52.040448
# Unit test for function str_to_bool
def test_str_to_bool():
    for true_val in [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]:
        assert str_to_bool(true_val) is True

    for false_val in [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]:
        assert str_to_bool(false_val) is False

    with pytest.raises(ValueError):
        str_to_bool("some_undefined_value")

# Generated at 2022-06-21 23:46:03.551883
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    def remove_path(path):
        try:
            path.unlink()
        except:
            pass

    tmp_script_name = "test_load_module_from_file_location"
    tmp_script_ext = ".py"

    tmp_script_path = Path(tempfile.gettempdir())
    tmp_script_path /= tmp_script_name + tmp_script_ext

    if tmp_script_path.exists():
        remove_path(tmp_script_path)


# Generated at 2022-06-21 23:46:07.628839
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_config = "tests/test_helpers/test_config.py"
    module = load_module_from_file_location(test_config)

    assert module.TEST_CONFIG == "test_config_value"



# Generated at 2022-06-21 23:46:19.956106
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("no") == False
    assert str_to_bool("n") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-21 23:46:25.902163
# Unit test for function str_to_bool
def test_str_to_bool():
    true_strings = {
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    }
    for string in true_strings:
        assert str_to_bool(string) is True

    false_strings = {
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    }
    for string in false_strings:
        assert str_to_bool(string) is False

    with pytest.raises(ValueError):
        str_to_bool("true1")


# Generated at 2022-06-21 23:46:36.906120
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("tRUE") is True
    assert str_to_bool("1") is True
    assert str_to_bool("E") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("+") is True
    assert str_to_bool("y") is True
    assert str_to_bool("FALSE") is False
    assert str_to_bool("0") is False
    assert str_to_bool("N") is False
    assert str_to_bool("no") is False
    assert str_to_bool("-") is False
    assert str_to_bool("n") is False
    with pytest.raises(ValueError):
        str_to_bool("invalid")
    with pytest.raises(ValueError):
        str_to_

# Generated at 2022-06-21 23:46:44.620071
# Unit test for function str_to_bool
def test_str_to_bool():
    for string in (
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ):
        assert str_to_bool(string)

    for string in (
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ):
        assert not str_to_bool(string)

    with pytest.raises(ValueError):
        str_to_bool("Some garbage")

# Generated at 2022-06-21 23:46:57.001957
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test with pathlike object.
    # A1) with defined env var.
    os_environ["SOME_ENV_VAR"] = "some_env_var"
    assert load_module_from_file_location(
        "/some/path/${SOME_ENV_VAR}/location.py"
    )
    # A2) with not defined env var.
    try:
        load_module_from_file_location("/some/path/${C}/location.py")
    except LoadFileException:
        assert True
    # A3) without env var.
    assert load_module_from_file_location("/some/path/location.py")

    # B) Test with bytes
    os_environ["SOME_ENV_VAR"] = "some_env_var"

# Generated at 2022-06-21 23:47:03.986439
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

# Generated at 2022-06-21 23:47:14.421086
# Unit test for function str_to_bool
def test_str_to_bool():
    """Tests if str_to_bool function works as expected."""

    assert str_to_bool("Y") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("YES") is True

    assert str_to_bool("N") is False
    assert str_to_bool("No") is False
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("NO") is False

    try:
        str_to_bool("Maybe")
    except ValueError:
        pass
    else:
        assert False  # if it didn't raise Value error, then raise regular one.


# Generated at 2022-06-21 23:47:25.839527
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa: D202
    assert str_to_bool("false") == False
    assert str_to_bool("0") == False
    assert str_to_bool("000") == False
    assert str_to_bool("F") == False
    assert str_to_bool("OFF") == False
    assert str_to_bool("off") == False
    assert str_to_bool("Off") == False
    assert str_to_bool("OFF") == False
    assert str_to_bool("No") == False
    assert str_to_bool("N") == False
    assert str_to_bool("FALSE") == False
    assert str_to_bool("FAlse") == False
    assert str_to_bool("") == False
    assert str_to_bool("FALS") == False
    assert str_to_bool

# Generated at 2022-06-21 23:47:37.517988
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("N") is False

# Generated at 2022-06-21 23:47:50.327205
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    location = "tests/config_example/example.py"
    assert location == load_module_from_file_location(location).__file__
    assert location == load_module_from_file_location(Path(location)).__file__
    assert location == load_module_from_file_location(bytes(location, "utf-8")).__file__

    os_environ["some_env_var"] = "config_example"
    location = f"tests/${{some_env_var}}/example.py"
    assert location == load_module_from_file_location(location).__file__
    assert location == load_module_from_file_location(Path(location)).__file__
    assert location == load_module_from_file_location(bytes(location, "utf-8")).__file__




# Generated at 2022-06-21 23:47:58.505943
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("no") == False
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("on") == True
    assert str_to_bool("off") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("yep") == True
    assert str_to_bool("nop") == False
    assert str_to_bool("enable") == True
    assert str_to_bool("disable") == False
    assert str_to_bool("t") == True
    assert str_to_bool("f") == False
    assert str_to_bool("true") == True

# Generated at 2022-06-21 23:48:01.363851
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False

# Generated at 2022-06-21 23:48:12.510474
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("Y")
    assert str_to_bool("YES")
    assert str_to_bool("YES")
    assert str_to_bool("true")
    assert str_to_bool("t")
    assert str_to_bool("True")
    assert str_to_bool("T")
    assert str_to_bool("1")
    assert str_to_bool("enable")
    assert str_to_bool("on")
    assert str_to_bool("enabled")
    assert str_to_bool("Enabled")
    assert str_to_bool("ENABLED")
    assert str_to_bool("ON")
    assert str_to_bool("ON")


# Generated at 2022-06-21 23:48:24.640642
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    from os import environ, path, mkdir
    import tempfile

    # A) Test if file is not found
    # B) Test if environment variables does not corresponds to any env var.
    # C) Test if file contains syntax error.
    # D) Test if all magic works.

    # A) Test if file is not found

# Generated at 2022-06-21 23:48:37.953169
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pylint: disable=too-many-locals
    from os import environ as os_environ, remove
    os_environ["test_env_var"] = "test_env_var_value"
    test_config_file_name = "test_config.py"
    with open(test_config_file_name, "w") as test_config_file:
        test_config_file.write("CONFIG_VAR_1 = 'CONFIG_VAR_1'\n")
        test_config_file.write("CONFIG_VAR_2 = 'CONFIG_VAR_2'\n")
        test_config_file.write("CONFIG_VAR_3 = 'CONFIG_VAR_3'\n")

# Generated at 2022-06-21 23:48:52.828734
# Unit test for function str_to_bool
def test_str_to_bool():
    import numpy as np
    for true_values in [
        "y", "yes", "yep", "yup", "t", "true", "on", "enable", "enabled", "1"
    ]:
        assert str_to_bool(true_values) is True
    for false_values in [
        "n", "no", "f", "false", "off", "disable", "disabled", "0"
    ]:
        assert str_to_bool(false_values) is False


# Generated at 2022-06-21 23:48:59.540094
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    class TestClass:
        pass

    import json

    import requests

    # A) Testing if load_module_from_file_location works correctly
    #    with file with import and function.
    mod = load_module_from_file_location(
        (Path(__file__).parent / "assets" / "test_settings.py")
    )
    assert mod.some_setting == 15
    assert mod.some_func() == "some_func"
    assert mod.SOME_CONST == "some_const"

    # B) Testing if load_module_from_file_location works correctly
    #    with file without import.
    mod = load_module_from_file_location(
        (Path(__file__).parent / "assets" / "test_environment_variables.py")
    )

# Generated at 2022-06-21 23:49:09.925026
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-21 23:49:19.014762
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("") is False
    assert str_to_bool("Y") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("foo") is False
    assert str_to_bool("True") is True
    assert str_to_bool("on") is True
    assert str_to_bool("whatever") is False

# Generated at 2022-06-21 23:49:32.527866
# Unit test for function str_to_bool

# Generated at 2022-06-21 23:49:39.661993
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def assert_module_loaded(module: types.ModuleType, location) -> None:
        # A) Check module is loaded
        assert module, f"{location} module is not loaded"

        # B) Check module __file__ attribute is properly set.
        if isinstance(location, str):
            assert (
                module.__file__ == location
            ), f"{location} module filename is not expected"
        else:
            assert (
                module.__file__ == str(location)
            ), f"{location} module filename is not expected"

    # 1) Testing valid file module path
    location = "tests/test_config_load_file/test_config_load_file.py"
    module = load_module_from_file_location(location)
    assert_module_loaded(module, location)
    assert module.T

# Generated at 2022-06-21 23:49:52.552222
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from io import StringIO
    from os import environ
    from tempfile import TemporaryDirectory

    import pytest

    from sanic.exceptions import LoadFileException

    from .helpers import mock_location

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    with pytest.raises(LoadFileException) as exception:
        load_module_from_file_location(
            "sanic/${undefined_var_name}/exceptions.py"
        )
    assert (
        str(exception.value)
        == "The following environment variables are not set: undefined_var_name"
    )

    # C) Substitute them in location.
    with TemporaryDirectory() as temp_dir:
        temp_dir = Path

# Generated at 2022-06-21 23:50:03.913386
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["some_env_var"] = "abra"
    module_as_string = load_module_from_file_location(
        b"# -*- coding: utf8 -*-\na = 'abra'", encoding="utf8"
    )
    module_as_bytes = load_module_from_file_location(
        b"# -*- coding: utf8 -*-\na = 'abra'", encoding="utf8"
    )
    module_as_path = load_module_from_file_location(Path(__file__))
    module_as_str = load_module_from_file_location(
        "sanic.helpers", package="sanic"
    )
    module_as_str_and_env_var = load_module_from_file_location