

# Generated at 2022-06-12 09:38:00.755347
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("on") == True
    assert str_to_bool("off") == False

# Generated at 2022-06-12 09:38:09.541586
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sanic
    from random import randint
    from os import environ as os_environ

    # Test 1: Load module from .py file with name from path.
    file_path = f"{Path(__file__).parent}/this.py"
    module = load_module_from_file_location(file_path)
    assert module.__file__ == file_path
    assert module.x == "hello"

    # Test 2: Load module from a file with any extension.
    file_path = f"{Path(__file__).parent}/this"
    module = load_module_from_file_location(file_path)
    assert module.__file__ == file_path
    assert module.x == "hello"

    # Test 3: Load module from a file with any extension,
    # Test 3: but

# Generated at 2022-06-12 09:38:19.565810
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """ Tries to use load_module_from_file_location
    with different parameters and checks outcome.
    """
    # load_module_from_file_location("some_module_name",
    #                                "/some/path/${some_env_var}")
    path = os.path.abspath("test_load_module_from_file_location.py")
    os_environ["test"] = path
    assert load_module_from_file_location("tests/utils.py") is utils
    assert load_module_from_file_location(path) is utils
    assert load_module_from_file_location("tests/${test}") is utils
    assert load_module_from_file_location(b"tests/utils.py") is utils
    with raises(ImportError):
        load_

# Generated at 2022-06-12 09:38:25.332302
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import unittest

    class TestLoadModuleFromFileLocation(unittest.TestCase):
        def test_load_module_from_file_location(self):
            import tempfile
            import importlib.util
            import shutil


# Generated at 2022-06-12 09:38:35.508364
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("No") == False
    assert str_to_bool("0") == False
    assert str_to_bool("true") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("false") == False
    assert str_to_bool("FALSE") == False
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("f") == False
    assert str_to_bool("F") == False
    assert str_to_bool("on") == True

# Generated at 2022-06-12 09:38:44.436368
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from unittest.mock import patch

    test_env = {"SOME_ENV_VAR": "/some/path"}
    with patch.dict(os_environ, test_env):
        assert (
            load_module_from_file_location("/some/path/some_module_name.py")
            == "import_string(location)"
        )
        assert (
            load_module_from_file_location(
                "/some/path/bad_name.py", str_to_bool("No")
            )
            == "spec_from_file_location(name, location)"
        )
        assert (
            load_module_from_file_location("/some/path/${SOME_ENV_VAR}.py")
            == "module_from_spec(_mod_spec)"
        )

# Generated at 2022-06-12 09:38:54.833007
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(
        "sanic.helpers.test_load_module_from_file_location"
    ).test_str == "some_val"

    assert load_module_from_file_location(
        str.encode("sanic.helpers.test_load_module_from_file_location"),
        encoding="utf8",
    ).test_str == "some_val"

    assert load_module_from_file_location(
        Path(__file__)
    ).test_str == "some_val"

    assert load_module_from_file_location(
        Path(__file__).parent / "test_helpers.py"
    ).test_str == "some_val"


# Generated at 2022-06-12 09:39:02.501965
# Unit test for function str_to_bool
def test_str_to_bool():
    """
    test_str_to_bool
    """
    assert str_to_bool("true")
    assert str_to_bool("y")
    assert str_to_bool("enable")
    assert str_to_bool("1")
    assert not str_to_bool("false")
    assert not str_to_bool("n")
    assert not str_to_bool("disable")
    assert not str_to_bool("0")
    assert not str_to_bool("false")
    assert not str_to_bool("disable")
    assert not str_to_bool("3")
    assert not str_to_bool("test")

# Generated at 2022-06-12 09:39:09.381296
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location(): # noqa
    """Loads module from the file location.

    The function checks following things:
        1. If paths are working properly (
           mod_should_have_file_attribute).
        2. If environment variables are loaded properly.
           (mod_should_have_env_attribute).
    """

    # A) Create a test module that has a single attribute called "file".
    #    It will be used to check if import_module is working properly.

    # A.1) Create test config file (./config.py)
    location_of_test_config_file = str(Path(".")) + "/config.py"
    with open(location_of_test_config_file, "w") as f:
        f.write("file = 'test'")
    # A.2) Import test config file as module.
    mod_should

# Generated at 2022-06-12 09:39:18.749324
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    from tempfile import mkstemp
    from types import ModuleType

    from os.path import dirname, basename, getmtime, getsize
    from sanic.utils import load_module_from_file_location

    def create_temp_module():
        _, tmp_module_location = mkstemp(".py")
        tmp_module = ModuleType(
            basename(tmp_module_location).split(".")[0]
        )  # name of the module
        tmp_module.__file__ = tmp_module_location

        tmp_module.some_attr = "some_attr"
        tmp_module.some_method = lambda: "some_method"
        tmp_module.some_class = type("SomeClass", (), {"some_method": lambda: None})


# Generated at 2022-06-12 09:39:28.954502
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import sys

    def fill_module_with_values(module):
        module.var_1 = "var_1"
        module.var_2 = 2
        module.var_3 = True
        module.var_4 = [1, 2, 3]
        module.var_5 = {"1": "1", "2": "2"}

    fill_module_with_values(sys.modules["__main__"])

    sys.modules["__main__"].var_1 = "var_1 updated"

    # Load module from environment variable
    module_path_env_var = Path("$HOME", "module.py")
    module_as_env_var = load_module_from_file_location(module_path_env_var)

# Generated at 2022-06-12 09:39:30.024361
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("os") == os

# Generated at 2022-06-12 09:39:40.027218
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # 1) Arrange
    test_module_location = Path(__file__).parent / "test_module.py"

    def load_module_from_path(path: Union[Path, bytes, str]) -> types.ModuleType:
        return load_module_from_file_location(path)

    # 2) Act
    actual_module_1 = load_module_from_path(test_module_location)
    actual_module_2 = load_module_from_path(
        str(test_module_location)
    )  # You can also send here string!
    actual_module_3 = load_module_from_path(
        bytes(str(test_module_location), encoding="utf8")
    )  # You can also send here bytes!

    # 3) Assert
    assert actual_module_1.T

# Generated at 2022-06-12 09:39:48.282135
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("json").__name__ == "json"
    assert load_module_from_file_location(b"json").__name__ == "json"
    assert load_module_from_file_location("yaml").__name__ == "yaml"
    assert load_module_from_file_location(b"yaml").__name__ == "yaml"
    assert load_module_from_file_location("yaml", encoding="ascii").__name__ == "yaml"

    os_environ["TESTING_OS_ENV"] = "value"
    assert load_module_from_file_location("json", "/some/${TESTING_OS_ENV}").__name__ == "json"

    with pytest.raises(LoadFileException):
        __ = load

# Generated at 2022-06-12 09:39:57.662413
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    assert str_to_bool("1")
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")

    assert not str_to_bool("0")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

    assert not str_to_bool("")
    assert not str

# Generated at 2022-06-12 09:40:05.996825
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Environment variables are not set.
    try:
        load_module_from_file_location("${unset_env_var}")
    except LoadFileException as e:
        assert str(e) == "The following environment variables are not set: unset_env_var"
    else:
        raise Exception("Test failed.")

    # Environment variables are set.
    assert load_module_from_file_location("${PWD}").__file__ == os_environ["PWD"]

    # Environment variables are set.
    assert (
        load_module_from_file_location("${" + os_environ["PWD"] + "}").__file__
        == os_environ["PWD"]
    )

    # Environment variables are set.

# Generated at 2022-06-12 09:40:13.727372
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Just a tests of function load_module_from_file_location."""
    from tempfile import gettempdir

    # A) Check .py file loading
    location = gettempdir() + "/test_file.py"

    with open(location, "w") as test_file:
        test_file.write("i = 0")
    try:
        module = load_module_from_file_location(location)
    except Exception:
        os.remove(location)
        raise
    os.remove(location)

    assert module.__name__ == "test_file"
    assert module.__file__ == location

    # B) Check .py file loading with environment variables in location
    location = gettempdir() + "/test_file.py"
    os_environ["ENV_VAR"] = gettempdir()  #

# Generated at 2022-06-12 09:40:22.941844
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        Path(__file__).parent.joinpath("utils_fixtures", "config_file.py")
    )
    assert module.variable == "var"
    os_environ["config_file_path"] = "/tmp"
    module = load_module_from_file_location(
        "${config_file_path}/some_dir/${config_file_path}/my_config.py"
    )
    assert module.variable == "var"
    del os_environ["config_file_path"]
    try:
        load_module_from_file_location(
            "${config_file_path}/some_dir/${config_file_path}/my_config.py"
        )
    except LoadFileException:
        pass

# Generated at 2022-06-12 09:40:30.948876
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Set fake environment variables.
    os_environ["SANIC_CONFIG_PATH"] = "/some/path/to/file.py"
    os_environ["SOME_KEY"] = "some_value"

    # Test loading from existing file.
    module = load_module_from_file_location("${SANIC_CONFIG_PATH}")
    assert module is not None
    assert module.SOME_KEY == "some_value"

    # Test loading from not existing file.
    wrong_path = "/some/not/existing/path"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(wrong_path)

    # Test loading with environment variables not set.

# Generated at 2022-06-12 09:40:36.863432
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D103
    assert load_module_from_file_location(
        "testutils.test_helpers.test_module"
    )
    assert load_module_from_file_location(
        "testutils.test_helpers.test_module.TestClass"
    )
    assert load_module_from_file_location(
        "testutils.test_helpers.test_module.TestClass.test_attribute"
    )

    assert load_module_from_file_location(
        "testutils/test_helpers/test_module.py"
    )
    assert load_module_from_file_location(
        "testutils/test_helpers/test_module"
    )
    assert load_module_from_file_location("testutils/test_helpers/test_module")



# Generated at 2022-06-12 09:40:52.026514
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover
    os_environ["some_env_var"] = "some_env_var_value"

# Generated at 2022-06-12 09:41:02.023143
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""

    def prepare_enviroment(some_env_var: str, test_file_content: str):
        # Prepare environment for test.

        # Add some another environemnt varibale to not affect
        # global os.environ.
        os_environ["ad_hoc_environment_variable"] = "is_here"

        # Create test file content
        test_file = Path("./test_file")
        with open(test_file, "w", encoding="utf8") as file:
            file.write(test_file_content)

        # Add environment variable to os.environ
        os_environ[some_env_var] = "some_value"

        return test_file


# Generated at 2022-06-12 09:41:07.614912
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test import from a path with environment variables
    from os import environ as os_environ
    from os import putenv, unsetenv
    from os.path import join, exists
    from tempfile import mkdtemp
    from shutil import rmtree

    from sanic.helpers import load_module_from_file_location

    temp_dir = mkdtemp()
    putenv("TEST_CONFIG_DIR", temp_dir)
    MODULE_CONTENT = (
        "DB_CONNECTION = 'localhost'\n" "SECRET_KEY = '123123123'\n"
    )
    module_path = join(temp_dir, "pipline_config.py")
    with open(module_path, "w+") as module_file:
        module_file.write(MODULE_CONTENT)

# Generated at 2022-06-12 09:41:15.875732
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import unittest

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            pass

        def exec_module(self, module):
            module.FOO = "BAR"

    # Save old functions.
    old_spec_from_file_location = importlib.util.spec_from_file_location
    old_module_from_spec = module_from_spec
    old_declarative_base = declarative_base

    # Create mock functions.
    def mock_spec_from_file_location(name, location, *args, **kwargs):
        spec = old_spec_from_file_location(name, location, *args, **kwargs)
        spec.loader = MockModule()
        return spec


# Generated at 2022-06-12 09:41:23.904246
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest

    def load_module_from_file_location_wrapper(location):  # noqa
        return (
            load_module_from_file_location(
                location, "/some/path", "rb", False
            )  # type: ignore
        )

    location = "/some/path/some_module_name.py"
    name = location.split("/")[-1].split(".")[0]
    module = types.ModuleType(name)
    module.__file__ = location

    with pytest.raises(LoadFileException):
        load_module_from_file_location_wrapper("/some/path/${some_env_var}")


# Generated at 2022-06-12 09:41:30.023559
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""
    from pathlib import Path
    from os import environ as os_environ

    # 1) Test if it will load test config file provided as a Path
    new_temp_config_file = Path(
        "/tmp/test_load_module_from_file_location_new_temp_config_file.conf"
    )
    new_temp_config_file.touch()


# Generated at 2022-06-12 09:41:40.052662
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    1. check if it can load the module when it is imported by full path
    2. check if it can raise LoadFileException if environment variable is
       not defined
    3. check if it can load the module when it is imported by path containing
       a environment variables (ie. "/some/path/${some_env_var}")
    4. check if it can raise LoadFileException if there is no python file on the
       given path
    """
    import os
    from tempfile import mkdtemp
    from shutil import rmtree
    from uuid import uuid4

    # 1. check if it can load the module when it is imported by full path
    location = "sanic/log.py"
    module = load_module_from_file_location(location)
    assert module is not None, "The module was not loaded."

# Generated at 2022-06-12 09:41:43.917356
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # pack config.txt into module_from_string_test.py
    test_config_content = "a = 'test_load_module_from_file_location'\n"

# Generated at 2022-06-12 09:41:47.630340
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test the load_module_from_file_location function."""
    class_with_module = load_module_from_file_location(
        "{0}/examples/module_with_var.py".format(Path(__file__).parent)
    )

    assert class_with_module.test_variable == 42



# Generated at 2022-06-12 09:41:58.360680
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import json
    import os
    import sys
    import tempfile
    from os import environ as os_environ
    from pathlib import Path

    from sanic.exceptions import PyFileError
    from sanic.helpers import load_module_from_file_location

    def prepare_config_file(path: Path, content: str) -> None:
        """Create config file with given content and add it to sys.path."""
        Path(path).write_text(content)
        sys.path.insert(0, str(path.parent))

    def cleanup_config_file(path: str) -> None:
        """Remove given config file and it's parent directory from sys.path."""
        sys.path.remove(str(Path(path).parent))
        Path(path).unlink()

    # 1) Test string path to

# Generated at 2022-06-12 09:42:14.087777
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from io import StringIO
    from pathlib import Path
    # Load module from path.
    mod = load_module_from_file_location(Path("tests/app/app.py"))
    # Check if module successfully loaded.
    assert mod.sanic_app.__name__ == "app.sanic_app"
    assert mod.sanic_app.__class__.__name__ == "Application"
    # Check if excluded Environment Variable
    with pytest.raises(LoadFileException) as excinfo:
        load_module_from_file_location(Path("tests/app/${some_wrong_env_var}"))
    assert (
        "The following environment variables are not set: some_wrong_env_var"
        in excinfo.value.args[0]
    )
    # Check if included

# Generated at 2022-06-12 09:42:19.795118
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    test_env = os_environ.copy()

    import random

    some_test_value = random.randrange(10)
    test_env["SOME_TEST_ENV_VAR"] = str(some_test_value)

    test_module = load_module_from_file_location(
        f"/some/path/${{SOME_TEST_ENV_VAR}}/testmodule.py", environ=test_env
    )

    assert test_module.some_value == some_test_value

# Generated at 2022-06-12 09:42:29.986429
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    def try_load_config_with_exception(
        location, exception_class, message=None
    ):
        with pytest.raises(exception_class) as e:
            load_module_from_file_location(location)
            if message is not None and message not in e.strerror:
                pytest.fail(
                    "Expected message is %s, but got %s" % (message, e.strerror)
                )

    def try_load_config(location, expected_module, expected_module_name=None):
        assert isinstance(expected_module, type(types.ModuleType))
        module = load_module_from_file_location(location)
        assert isinstance(module, type(types.ModuleType))
        assert module == expected_module

# Generated at 2022-06-12 09:42:39.938804
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Lets say we have
    # /some_dir/module_name.py:
    #
    #     test_var = "some_value"
    #
    # /another_dir/config.py:
    #
    #     another_test_var = "another_value"
    #
    # /some_dir/__init__.py:
    #
    #     import module_name

    # A) Test if module name can be loaded from path.
    m = load_module_from_file_location(
        "/some_dir/module_name.py",
        "/some_dir/__init__.py",
    )
    assert m.test_var == "some_value"

    # B) Test if module name with env vars can be loaded from path.

# Generated at 2022-06-12 09:42:41.917154
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location("__main__").__file__
        == __file__
    )  # type: ignore


# Generated at 2022-06-12 09:42:49.011418
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import tempfile

    # Test with file like object, to simulate environment variables.
    tf_handler, tf_name = tempfile.mkstemp()
    with open(tf_handler, "w") as config_file:
        config_file.write(
            "API_HOST = '${API_HOST}'\n"
            "API_PORT = '${API_PORT}'"
        )
    os_environ["API_HOST"] = "api.example.com"
    os_environ["API_PORT"] = "12345"
    module = load_module_from_file_location(tf_name)
    assert module.API_HOST == os_environ["API_HOST"]
    assert module.API_PORT == os_environ["API_PORT"]

# Generated at 2022-06-12 09:42:53.982885
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SANIC_TEST_VAR"] = "It is working good"

    location = "sanic/config.py"
    assert isinstance(load_module_from_file_location(location), types.ModuleType)

    location = Path("sanic/config.py")
    assert isinstance(load_module_from_file_location(location), types.ModuleType)

    location = b"sanic/config.py"
    assert isinstance(load_module_from_file_location(location), types.ModuleType)

    location = "~/Documents/config.py"
    assert isinstance(load_module_from_file_location(location), types.ModuleType)

    location = "~/Documents/config"
    assert isinstance(load_module_from_file_location(location), types.ModuleType)

# Generated at 2022-06-12 09:43:02.157060
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        "tests/configs/test_config.py"
    )
    assert module.value == "1234"

    module = load_module_from_file_location(
        "tests/configs/test_config.json"
    )
    assert module.value == 1234

    module = load_module_from_file_location(
        "tests/configs/test_config_yaml.yml"
    )
    assert module.value == 1234

    with pytest.raises(IOError):
        load_module_from_file_location("also_not_exist.py")

    path = "tests/configs/test_config.py"
    assert load_module_from_file_location(path).value == "1234"


# Generated at 2022-06-12 09:43:07.165024
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location(
            location="/some/path/${some_undefined_env_var}"
        )  # This should not be run
        assert False, "Expected LoadFileException but no exception was thrown"
    except LoadFileException:
        pass

    try:
        some_module = load_module_from_file_location(
            location=os.path.abspath(
                os.path.join(os.path.dirname(__file__), "../../", "setup.py")
            )
        )
        assert some_module
    except LoadFileException:
        assert False, "Expected no exception but an exception was thrown"

# Generated at 2022-06-12 09:43:15.237052
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("tests.unit.test_common.mock_module")
    assert (
        load_module_from_file_location(
            "tests.unit.test_common.mock_module_not_dot_py"
        )
        is None
    )
    assert (
        load_module_from_file_location(Path("tests/unit/test_common/mock_module.py"))
        is not None
    )
    assert (
        load_module_from_file_location(
            Path("tests/unit/test_common/mock_module_not_dot_py")
        )
        is None
    )
    assert load_module_from_file_location("") is None
    assert load_module_from_file_location("/tmp") is None
   

# Generated at 2022-06-12 09:43:32.970811
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import sys
    import tempfile

    import pytest

    # ---------
    #   Load module from string path.
    # ---------
    module_name = "__test_module_2"
    try:
        del sys.modules[module_name]
    except KeyError:
        pass

    module_path = Path(__file__).parent / "test_server.py"
    # A) Test if module is loaded from it's path
    module = load_module_from_file_location(module_path)
    # Check if it's the same as by import keyword
    assert module == import_string(module.__name__)
    # Check if module name is not changed
    assert module.__name__ == module_name

    module_name = "__test_module_1"

# Generated at 2022-06-12 09:43:36.395205
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from .utils import TESTS_PATH

    location = str(TESTS_PATH / "test_params.py")
    module = load_module_from_file_location(location)
    assert module.some_param == "value"

# Generated at 2022-06-12 09:43:42.391908
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import ast

    # Testing if location argument is of a bytes type, it will be decoded.
    location = "/tmp/some_file".encode()
    module = load_module_from_file_location(location)
    assert module.__file__ == "ast"

    # Testing if location argument is of a bytes type, it will be decoded.
    location = Path("/tmp/some_file")
    module = load_module_from_file_location(location)
    assert module.__file__ == "ast"

    # Testing if location argument is of a bytes type, it will be decoded.
    location = "/tmp/some_file"
    module = load_module_from_file_location(location)
    assert module.__file__ == "ast"

    # Testing if location argument is of a bytes type, it will be dec

# Generated at 2022-06-12 09:43:51.969833
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def import_module(location, encoding="utf8"):
        return load_module_from_file_location(location, encoding=encoding)

    # Test location string
    assert import_module("tests.files.config_files.module_a")
    assert import_module("tests.files.config_files.module_a.py")
    assert import_module("tests.files.config_files.module_a.pyc")

    # Test location bytes
    assert import_module(b"tests.files.config_files.module_a")
    assert import_module(b"tests.files.config_files.module_a.py")
    assert import_module(b"tests.files.config_files.module_a.pyc")

    # Test location path with Py2 and Py3

# Generated at 2022-06-12 09:43:59.863829
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 1) Load module from a string as a location (should pass)
    module = load_module_from_file_location("types")
    assert module is types

    # 2) Load module from a string as a location, which contains a module
    # that does not exists (should raise)
    with pytest.raises(ImportError):
        load_module_from_file_location("some_module_only_for_testing")

    # 3) Load module from a string as a location, which contains a package
    # (should raise)
    with pytest.raises(ImportError):
        load_module_from_file_location("six.moves")

    # 4) Load module from a bytes as a location, which is not a valid path,
    # (should pass with high probability)
    module = load_module_from_file_location

# Generated at 2022-06-12 09:44:07.383969
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test if load_module_from_file_location returns expected module."""
    assert load_module_from_file_location(
        "tests/test_utils/test_module.py"
    ) == load_module_from_file_location(
        Path("tests/test_utils/test_module.py")
    )
    assert load_module_from_file_location(
        b"tests/test_utils/test_module.py", encoding="utf8"
    ) == load_module_from_file_location(
        Path("tests/test_utils/test_module.py")
    )

# Generated at 2022-06-12 09:44:16.941441
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "tests/fixtures/configs/config_a.py"

    assert load_module_from_file_location(location).TEST == "TEST"

    os_environ["TEST_ENV"] = "TEST"
    location = "tests/fixtures/configs/${TEST_ENV}.py"

    assert load_module_from_file_location(location).TEST == "TEST"
    del os_environ["TEST_ENV"]

    location = b"tests/fixtures/configs/config_a.py"
    assert load_module_from_file_location(location).TEST == "TEST"

    location = Path("tests/fixtures/configs/config_a.py")

# Generated at 2022-06-12 09:44:27.538639
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    def create_env_vars(config_path: str, some_env_var: str = "") -> str:
        env_vars = {
            "${some_env_var}": some_env_var,
            "${SOME_ENV_VAR}": some_env_var.upper(),
            "${Some_Env_Var}": some_env_var.title(),
        }
        return config_path.format(**env_vars)

    # B) Check these variables exists in environment.
    SOME_ENV_VAR = "1"
    os_environ["SOME_ENV_VAR"] = SOME_ENV_VAR

    # C) Substitute them in location.


# Generated at 2022-06-12 09:44:35.358888
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from sanic.helpers import load_module_from_file_location
    from os import environ, path

    test_env_var_name = "test_env_var"
    test_env_var_path = "/test/${test_env_var}"

    environ[test_env_var_name] = "/test/${test_env_var}"

    assert load_module_from_file_location(test_env_var_path) == path
    assert load_module_from_file_location(test_env_var_path.encode()) == path
    assert load_module_from_file_location(Path(test_env_var_path)) == path

# Generated at 2022-06-12 09:44:43.727340
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tempdir:
        test_file_location = Path(tempdir, "foo.py")
        test_file_location.write_text("foo = 'bar'")
        assert (
            load_module_from_file_location(test_file_location).foo == "bar"
        )

        test_file_location = Path(tempdir, "foo")
        test_file_location.write_text("foo = 'bar'")
        assert (
            load_module_from_file_location(test_file_location).foo == "bar"
        )

        test_file_location = Path(tempdir, "bar.py")
        test_file_location.write_text(
            "import sys; foo = sys; foo.foo = 'bar'"
        )
       

# Generated at 2022-06-12 09:45:00.989223
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile
    import pytest

    #    with tempfile.NamedTemporaryFile(delete=False, suffix=".py") as w:
    #        w.write("hello".encode("utf8"))
    #    try:
    #        load_module("{}.hello".format(tempfile.gettempdir()))()
    #    finally:
    #        os.remove(w.name)

    with tempfile.NamedTemporaryFile(
        delete=False, suffix=".py"
    ) as w:  # type: ignore
        w.write("test = 'some test'".encode("utf8"))


# Generated at 2022-06-12 09:45:06.625929
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    from os import environ as os_environ

    os_environ["TEST_ENV_VAR"] = "env_value"


# Generated at 2022-06-12 09:45:15.598903
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module1 = load_module_from_file_location(
        "sanic.tests.test_config.test_module_1",
        "sanic/tests/test_config/test_module_1.py",
    )
    assert module1.foo == "bar"

    module2 = load_module_from_file_location(
        "sanic.tests.test_config.test_module_2",
        "sanic/tests/test_config/test_module_2.py",
    )
    assert module2.baz == "qux"

    module3 = load_module_from_file_location(
        "sanic.tests.test_config.test_module_3",
        "sanic/tests/test_config/test_module_3.py",
    )
    assert module3.quux

# Generated at 2022-06-12 09:45:25.273071
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import logging

    # Create tempory directory.
    temp_dir = tempfile.mkdtemp()

    # Setup environment variables.
    TEST_ENV_VAR_NAME_1 = "TEST_ENV_VAR_NAME_1"
    os.environ[TEST_ENV_VAR_NAME_1] = TEST_ENV_VAR_NAME_1
    TEST_ENV_VAR_NAME_2 = "TEST_ENV_VAR_NAME_2"
    os.environ[TEST_ENV_VAR_NAME_2] = TEST_ENV_VAR_NAME_2

    # Setup expected test configuration.
    EXPECTED_CONFIG_FILE_NAME = "expected_config.py"
    EXPECTED_

# Generated at 2022-06-12 09:45:33.009530
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import getcwd
    from pathlib import Path
    from sanic.exceptions import PyFileError
    from sanic.helpers import is_coroutine_function

    import json

    # A) Load module provided as string.
    some_json = '{"some_json": "var"}'
    some_module = load_module_from_file_location(some_json)
    assert some_module["some_json"] == "var"

    # B) Load module provided as bytes.
    some_json = b'{"some_json": "var"}'
    some_module = load_module_from_file_location(some_json)
    assert some_module["some_json"] == "var"

    # C) Load module provided as object not string nor bytes type.

# Generated at 2022-06-12 09:45:33.849735
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # TODO: Write unit tests.
    pass

# Generated at 2022-06-12 09:45:42.957785
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # A) Load some module from absoulte file path
    some_module = load_module_from_file_location(
        "/home/some_user/some_module_name.py"
    )
    assert "some_module_name" in some_module.__name__
    assert "/home/some_user/some_module_name.py" in some_module.__file__

    # B) Load some module from relative path
    some_module = load_module_from_file_location("some_module_name")
    assert "some_module_name" in some_module.__name__

    # C) Try to load some module from invalid path.
    #    It should raise exception.

# Generated at 2022-06-12 09:45:52.244876
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import pytest

    with pytest.raises(IOError):
        load_module_from_file_location(
            location="${some_not_existing_environment_variable}"
        )

    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            location="${some_not_existing_env_var}/some/path"
        )

    with pytest.raises(PyFileError):
        load_module_from_file_location(
            location=__file__.replace(".py", ".nonextentension")
        )

    module = load_module_from_file_location(location=__file__, mode="r")
    assert module.__file__ == __file__

    location = Path(__file__)
    module = load_module_from_file_

# Generated at 2022-06-12 09:45:52.939369
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

# Generated at 2022-06-12 09:46:01.289403
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location("invalid_env_var_name")
    except LoadFileException:
        pass
    else:
        raise ValueError("load_module_from_file_location should failed here")

    load_module_from_file_location("/etc/passwd")
    load_module_from_file_location(
        "tests/config.py"
    )  # This will also trigger another unit test for function import_string
    load_module_from_file_location(
        "/etc/passwd",
        "${PYTHONPATH}"
    )  # This will also test environment variables substitution.
    # This will also test bytes parameters.

# Generated at 2022-06-12 09:46:17.023246
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""

    from os import system, environ, remove
    from pathlib import Path

    from sanic.helpers import load_module_from_file_location

    # A) Check if function `load_module_from_file_location` which accepts
    #    just a name of a module as a string and returns loaded module as
    #    expected.
    some_module = load_module_from_file_location("json")
    assert some_module is not None
    assert some_module.dumps is not None
    assert some_module.JSONDecodeError is not None

    # B) Check if function `load_module_from_file_location` which accepts
    #    a file path as a string and returns loaded module as expected.

# Generated at 2022-06-12 09:46:25.658690
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from unittest.mock import MagicMock

    config_module = types.ModuleType("test_module")
    config_module.test_atribute = 55
    config_module.test_method = MagicMock()

    mock_module_from_spec = MagicMock(return_value=config_module)

    importlib_spec_from_file_location = MagicMock(return_value=MagicMock())


# Generated at 2022-06-12 09:46:35.567066
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from shutil import rmtree

    from os import makedirs, environ as os_environ
    from os.path import exists as os_path_exists, join as os_path_join
    from tempfile import gettempdir

    from unittest import TestCase
    from unittest.mock import patch

    from types import ModuleType

    from tblib import pickling_support
    from tblib.util import get_stack, get_traceback

    from .test_sanic_config import test_module

    config_file_path = os_path_join(gettempdir(), "load_config_module.py")

    test_module.__file__ = config_file_path
    pickling_support.install()

    # -----------------------------------------------------------

# Generated at 2022-06-12 09:46:41.754794
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """This unit test verifies that load_module_from_file_location works
    as expected.
    """

    def check_module_loaded_by_function(module_expected, module_loaded):
        """This function checks that module loaded
        by load_module_from_file_location is the same
        as module_expected.
        """


# Generated at 2022-06-12 09:46:52.296439
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function."""

    import os
    import tempfile

    # Create temporary directory and change working directory to it
    with tempfile.TemporaryDirectory() as temp_dir:
        old_cwd = os.getcwd()
        os.chdir(temp_dir)

        # Try to load some settings module like this:
        # settings.py:
        #
        #   SOME_VAR = 1
        #   SOME_OTHER_VAR = 2
        #
        # and in script:
        #
        #   assert settings.SOME_VAR == 1
        #   assert settings.SOME_OTHER_VAR == 2
        settings = Path("settings.py")
        settings.touch()

# Generated at 2022-06-12 09:47:00.288944
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from unittest.mock import MagicMock

    def mock_module_from_spec(*args):
        module = MagicMock()
        module.__file__ = "test.py"
        module.__name__ = "test"
        return module

    def mock_module(*args):
        module = MagicMock()
        module.__file__ = "test.py"
        setattr(module, "foo", "bar")
        return module

    module_from_spec_mock = MagicMock(side_effect=mock_module_from_spec)
    module_from_spec_mock.loader.exec_module = MagicMock()

    spec_from_file_location_mock = MagicMock(
        side_effect=lambda *args: module_from_spec_mock
    )

    module_

# Generated at 2022-06-12 09:47:10.081100
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sanic.config

    assert (
        sanic.config.load_module_from_file_location("sanic.config")
        is sanic.config
    )

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    #    If not, then raise LoadFileException.
    os_environ["SOME_ENV_VAR"] = str(Path(__file__).parent)
    assert (
        sanic.config.load_module_from_file_location(
            "sanic.config", "${SOME_ENV_VAR}/config.py"
        )
        is sanic.config
    )
    del os_environ["SOME_ENV_VAR"]

    # If file

# Generated at 2022-06-12 09:47:14.170637
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with open("test.py", "w") as f:
        f.write("def test():\n    return 'test'\n")

    test = load_module_from_file_location("test.py")

    assert test.test()



# Generated at 2022-06-12 09:47:21.184187
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Prepare the environment
    assert "TEST_ENV_VAR" not in os_environ
    assert "TEST_ENV_VAR_2" not in os_environ
    import tempfile
    os_environ["TEST_ENV_VAR"] = tempfile.gettempdir()
    test_file = (
        os_environ["TEST_ENV_VAR"]
        + "/test_mod_1.py"
    )  # note that ${TEST_ENV_VAR} is not working here
    test_file2 = (
        os_environ["TEST_ENV_VAR"]
        + "/test_mod_2.py"
    )  # note that ${TEST_ENV_VAR} is not working here

# Generated at 2022-06-12 09:47:30.205285
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Check if module can be loaded when environment variables are used in path
    os_environ["env_var"] = "something"
    try:
        module = load_module_from_file_location("/some/${env_var}/path")
    except LoadFileException as e:
        assert "The following environment variables are not set" not in str(e)

    # Check if error is raised if not all environment variables are set
    os_environ["wrong_env_var"] = "something"
    try:
        load_module_from_file_location("/some/${wrong_env_var}/${env_var}/path")
    except LoadFileException as e:
        assert "The following environment variables are not set: env_var" in str(
            e
        )

    # Check if error is raised if module cannot be

# Generated at 2022-06-12 09:47:51.606250
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sanic.config
    from os import chdir, getcwd, environ as os_environ
    from os.path import dirname, join
    from sys import path as sys_path

    # Mock function sys.path.insert
    mocked_sys_path_insert = MagicMock()
    sys_path.insert = mocked_sys_path_insert
    # Mock function os.makedirs
    mocked_makedirs = MagicMock(side_effect=OSError)
    os.makedirs = mocked_makedirs
    # Mock function os.path.exists
    mocked_exists = MagicMock(return_value=False)
    os.path.exists = mocked_exists
    # Mock function os.rename
    mocked_rename = MagicMock(side_effect=OSError)

# Generated at 2022-06-12 09:47:59.607204
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""

    # Test if function produces expected output for path = None.
    assert isinstance(
        load_module_from_file_location(None), types.ModuleType
    )

    # Test if function produces expected output for path = "".
    assert isinstance(
        load_module_from_file_location(""), types.ModuleType
    )

    os_environ["some_env_var"] = "some_env_var_value"

    # Test if function produces expected output for path = "something".
    assert isinstance(
        load_module_from_file_location("something"), types.ModuleType
    )

    # Test if function produces expected output for path =
    # "/some/path/${some_env_var}".