

# Generated at 2022-06-12 09:38:10.130258
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """
    No need to test it with py file.
    """
    os_environ["TEST_LOAD_MODULE_FROM_FILE_LOCATION_ENV_VAR1"] = "env1"
    os_environ["TEST_LOAD_MODULE_FROM_FILE_LOCATION_ENV_VAR2"] = "env2"
    os_environ["TEST_LOAD_MODULE_FROM_FILE_LOCATION_ENV_VAR3"] = "env3"
    os_environ["TEST_LOAD_MODULE_FROM_FILE_LOCATION_ENV_VAR4"] = "env4"


# Generated at 2022-06-12 09:38:20.057498
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    from tempfile import TemporaryDirectory
    from shutil import copyfile

    with TemporaryDirectory() as tmp_dir:
        # First test with environment variable
        os_environ["TEST_ENV_VAR"] = tmp_dir
        # Create file with some content
        Path(os_environ["TEST_ENV_VAR"], "some_module_name.py").write_text(
            """
            some_value = 12345
            """
        )
        assert (
            load_module_from_file_location(
                "some_module_name", "${TEST_ENV_VAR}/some_module_name.py"
            )
            .some_value
            == 12345
        )
        # Also test that it works with

# Generated at 2022-06-12 09:38:25.332184
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from tempfile import TemporaryDirectory
    from shutil import copyfile

    with TemporaryDirectory() as td:
        # A) Check if function raises exception when env_var does not exist.
        try:
            load_module_from_file_location(
                "/some/path/${NON_EXISTING_ENV_VAR}"
            )
        except LoadFileException as e:
            assert str(e) == "The following environment variables are not set: "
        else:
            assert False

        # B) Check if function resolves env_vars correctly
        os_environ["ENV_VAR"] = "env_var"
        os_environ["ENV_VAR_IN_PATH"] = "env_var_in_path"

# Generated at 2022-06-12 09:38:35.508658
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import sanic.config

    test_config_1 = sanic.config.Config
    test_config_2 = sanic.config.Config(
        {"TEST_PARAMETER_1": "TEST_VALUE_1", "TEST_PARAMETER_2": "TEST_VALUE_2"}
    )

    with pytest.raises(LoadFileException):
        sanic.config.load_module_from_file_location(
            "TEST_PARAMETER_1", "${TEST_PARAMETER_1}"
        )

    os_environ["TEST_PARAMETER_1"] = "TEST_ENVIRONMENT_VALUE_1"

    with pytest.raises(PyFileError):
        sanic.config.load_module_from_file

# Generated at 2022-06-12 09:38:44.436670
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import shutil
    import tempfile

    tmp_dir = tempfile.mkdtemp()


# Generated at 2022-06-12 09:38:54.833093
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    def make_config_file(config_name: str, config_content: str) -> str:
        with tempfile.NamedTemporaryFile(mode="w") as f:
            f.write(config_content)
            f.flush()
            return f.name


# Generated at 2022-06-12 09:38:58.682499
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("./tests/test_file.py")

    assert module.test_value == 1
    assert module.test_value2 == ["test", "test2"]
    assert module.test_value3 is True

# Generated at 2022-06-12 09:39:07.031006
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover
    import json
    import os
    import tempfile

    def load_and_compare_configs(**kwargs):
        with tempfile.NamedTemporaryFile(delete=False) as tf:
            sample_config = {"foo": "bar"}
            tf.write(json.dumps(sample_config).encode())
        try:
            sample_config = load_module_from_file_location(
                tf.name, **kwargs
            )
        finally:
            os.remove(tf.name)

        assert sample_config.__doc__ is None
        assert type(sample_config) == types.ModuleType
        assert sample_config.__file__ == tf.name
        assert type(sample_config.__dict__) == dict
        assert sample_config.__dict__ == sample_

# Generated at 2022-06-12 09:39:16.502457
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from shutil import rmtree, copyfile
    from tempfile import mkdtemp
    import json

    # Create temporary directory.
    tmpdir = mkdtemp()
    path_to_dir = Path(tmpdir)

    # Create temporary module file.
    path_to_file = path_to_dir / "test_module.py"
    path_to_file.touch()

    file_content = "#!/usr/bin/env python\n"
    file_content += "TEST_VAR = 'some_value'\n"

    path_to_file.write_text(file_content)

    #
    # Test 1.
    #
    # Test where path to the file is given directly and
    # file name doesn't have .py extension.
    #
    loaded_module_1 = load_module_from

# Generated at 2022-06-12 09:39:24.329850
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    import os

    with TemporaryDirectory() as tmpdirname:
        os.environ["TMP"] = tmpdirname
        some_file = Path(tmpdirname, "some_file").with_suffix(".py")


# Generated at 2022-06-12 09:39:36.476587
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    load_module_from_file_location("os")

    import os
    import sys
    import tempfile
    import unittest

    # Create temporary file and write test modules to it.
    handle, _path = tempfile.mkstemp(
        prefix="sanic_", suffix=".py", dir=None, text=True
    )
    assert os.path.exists(_path)
    _module = """var = 10"""
    with os.fdopen(handle, "w") as f:
        f.write(_module)

    # 1) Load some_module_name from file
    some_module = load_module_from_file_location(
        "some_module_name", _path, "rb"
    )

    assert hasattr(some_module, "var")
    assert some_module.var == 10



# Generated at 2022-06-12 09:39:45.199078
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa

    from tempfile import NamedTemporaryFile

    # A.
    with NamedTemporaryFile(mode="w+", suffix=".py") as temp_file:

        temp_file.write("SOME_VAR = 1")
        temp_file.flush()

        loaded_module = load_module_from_file_location(temp_file.name)

    assert loaded_module.SOME_VAR == 1

    # B.
    with NamedTemporaryFile(mode="w+", suffix=".py") as temp_file:

        temp_file.write("SOME_VAR = 1")
        temp_file.flush()

        loaded_module = load_module_from_file_location(temp_file.name)

    assert loaded_module.SOME_VAR == 1

    # C.

# Generated at 2022-06-12 09:39:51.834295
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 1
    test_file = "sanic.examples.simple_server.config"
    config_module = load_module_from_file_location(test_file)
    assert hasattr(config_module, "CONFIG")
    assert "FRIENDLY_CONFIG" in config_module.CONFIG

    # Test 2
    test_file = "sanic.examples.simple_server.config.py"
    config_module = load_module_from_file_location(test_file)
    assert hasattr(config_module, "CONFIG")
    assert "FRIENDLY_CONFIG" in config_module.CONFIG

    # Test 3
    test_file = "sanic.examples.simple_server.config"
    test_module = "sanic.examples.simple_server"
    config

# Generated at 2022-06-12 09:40:00.714097
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Test A.1
    try:
        _ = load_module_from_file_location(
            b"some_module_name", b"/some/path/${some_env_var}"
        )
    except LoadFileException:
        pass
    else:
        assert False

    # Test A.2
    try:
        _ = load_module_from_file_location(
            b"some_module_name", b"/some/path/some_value"
        )
    except LoadFileException:
        assert False

    # Test B.1
    os_environ["some_env_var"] = "some_value"

    # Test B.2

# Generated at 2022-06-12 09:40:08.918146
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_SOME_CONFIG"] = "{'hi': 123}"
    os_environ["TEST_SOME_CONFIG2"] = "{'hi': 456}"
    # A) Test with .py location
    loaded_module = load_module_from_file_location(
        "./tests/test_utils/test_some_config.py"
    )
    assert loaded_module.some_config == {"hi": 123}
    assert loaded_module.some_config2 == {"hi": 456}
    # B) Test with json location and
    #    location with ${some_env_var} in it.
    loaded_module = load_module_from_file_location(
        "./tests/test_utils/${TEST_SOME_CONFIG2}"
    )
    assert loaded_

# Generated at 2022-06-12 09:40:15.685342
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Tests for function load_module_from_file_location"""

    # A) If location is not a path, then use standard import_string
    #    to load it.
    module = load_module_from_file_location("os")
    assert module == os

    # B) If location is path and contains any environment variables,
    #    and there is file with name ${some_env_var} in path, then
    #    load this file.
    os_environ["some_env_var"] = "config"
    module = load_module_from_file_location("./tests/config.py")
    assert module.test_config_var == "test_config_value"

    # C) If location is path and contains any environment variables,
    #    but there is no file with name ${some_env

# Generated at 2022-06-12 09:40:24.988610
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import tempfile

    # 1. test loading module

    # 1.1. test with file_path
    content = "my_var = 10"

    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as fp:
        fp.write(content)
        fp.seek(0)
        module_from_file = load_module_from_file_location(fp.name)
        module_from_file_path = load_module_from_file_location(Path(fp.name))
        assert module_from_file.my_var == 10
        assert module_from_file_path.my_var == 10

        # 1.2. test with file_path like argument
        module_from_path = load_module_from_file_location(fp.name)
       

# Generated at 2022-06-12 09:40:32.378360
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    env_vars_in_location = set(re.findall(r"\${(.+?)}", "/some/path/${some_env_var}"))
    assert env_vars_in_location == {"some_env_var"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os.environ.keys())
    assert not_defined_env_vars == {"some_env_var"}

    # C) Substitute them in location.

# Generated at 2022-06-12 09:40:38.123632
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # 1. Check if it is loaded when called with normal string
    # 2. Check if it is loaded when called with pathlib.Path object
    # 3. Check if it is loaded when called with bytes
    # 4. Check if it is loaded when called with bytes and additional parameters
    # 5. Check if it raises IO error when there is no file
    # 6. Check if it raises LoadFileException if there are
    #    undefined environment variables used
    #    in file path

    # 1. Check if it is loaded when called with normal string
    module_name = "test_module_with_normal_string"
    file_path = "./tests/test_utils/test_module_with_normal_string.py"
    test_module = load_module_from_file_location(file_path)
    assert module_name == test_module.__

# Generated at 2022-06-12 09:40:42.232780
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import json

    config_file_path = Path(__file__).parent / "config_file_for_tests.json"
    module_1 = load_module_from_file_location(config_file_path)
    module_2 = Path(config_file_path)  # type: ignore
    module_3 = json.loads(module_1)  # type: ignore

    assert module_1
    assert module_2 == module_3

# Generated at 2022-06-12 09:40:52.436252
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["some_env_var"] = "some_value"
    location = "./tests/test_utils/${some_env_var}/test_file.py"
    loaded_module = load_module_from_file_location(location)
    assert loaded_module.test_variable == "test_value"

# Generated at 2022-06-12 09:41:02.533644
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    This test make sure that:
    - The string path is correctly resolved.
    - The bytes path is correctly decoded.
    - The Path path is correctly converted.
    - The exception LoadFileException is raised if one of environment
      variables isn't set.
    - The PyFileError is raised if one of the wrong exceptions from
      load_module_from_file_location is caught.
    """
    import sanic
    from sanic.exceptions import PyFileError, LoadFileException

    test_module = "sanic.exceptions"
    test_path_string = "/home/user/workspace/sanic/sanic/exceptions.py"
    test_path_encoded = b"/home/user/workspace/sanic/sanic/exceptions.py"

# Generated at 2022-06-12 09:41:11.574168
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    from types import ModuleType

    # A.0) test with non existing file.
    try:
        load_module_from_file_location(
            os.path.join(tempfile.gettempdir(), "not_existing_file")
        )
        assert False
    except FileNotFoundError:
        assert True

    # A.1) test with non existing environment variable in path.
    try:
        load_module_from_file_location(
            "/${not_existing_environment_variable_in_path}"
        )
        assert False
    except LoadFileException:
        assert True

    # B.1) test with existing environment variable in path
    os.environ.update({"env_var": tempfile.gettempdir()})

# Generated at 2022-06-12 09:41:21.056931
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest
    import os
    import tempfile
    import shutil

    # TODO: add more tests

    # test with environment variable
    tempdir = tempfile.mkdtemp(dir=os.path.dirname(__file__))
    test_file_path = os.path.join(tempdir, "test_configuration.py")
    with open(test_file_path, "w") as fd:
        fd.write("TEST = True")
    os.environ["TESTVAR"] = test_file_path[:-3]
    module = load_module_from_file_location("$TESTVAR")
    assert module.TEST is True
    assert module.__file__ == test_file_path
    shutil.rmtree(tempdir)

    # test

# Generated at 2022-06-12 09:41:29.321163
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unit test for function load_module_from_file_location."""
    # Some examples.

# Generated at 2022-06-12 09:41:39.401991
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os
    import tempfile
    import shutil

    # A) Check that exception is raised if env_var is not defined.
    temp_dir = tempfile.mkdtemp()
    conf_file = os.path.join(
        temp_dir, "test_load_module_from_file_location.py"
    )
    with open(conf_file, "w") as f:
        f.write(
            """
        VAR_1 = 1
        VAR_2 = "${SOME_ENV_VAR}"
        VAR_3 = 5
        """
        )

    # A.1) Check that exception is raised if env_var is not defined.
    with pytest.raises(LoadFileException):
        load_module_from_file_location(conf_file)

   

# Generated at 2022-06-12 09:41:48.262394
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # A) Set some environment variables for tests
    os_environ["some_env_var"] = "some_value"
    os_environ["some_other_env_var"] = "/some/other/value"

    # B) Set path variables
    tests_path = Path(__file__).absolute().parent
    example_config_path = tests_path / "example_config.py"
    another_config_path = tests_path / "another_config.yml"

    # C) Test loads module with path
    example_config = load_module_from_file_location(example_config_path)
    assert hasattr(example_config, "EXAMPLE_CONFIG_VAR")
    assert example_config.EXAMPLE_CONFIG_VAR == "example_config_value"

    # D

# Generated at 2022-06-12 09:41:59.128744
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    # Without environment variables
    loc1 = "tests/example_config.py"
    loc2 = Path("tests/example_config.py")
    assert (
        load_module_from_file_location(loc1).TEST_VARIABLE
        == load_module_from_file_location(loc2).TEST_VARIABLE
        == "sanic"
    )

    # With environment variables
    os.environ["TEST_ENV_VARIABLE"] = "sanic"
    assert (
        load_module_from_file_location(
            "tests/example_config.py", "/$TEST_ENV_VARIABLE/example_config.py"
        ).TEST_VARIABLE
        == "sanic"
    )

# Generated at 2022-06-12 09:42:08.593573
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory  # type: ignore

    def _create_module(directory, name, content='"""Module docstring"""\n'):
        _path = directory / name
        _path.write_text(content)
        return _path

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        path = _create_module(temp_dir, "config.py")
        os.environ["TMP_ENV_VAR"] = str(temp_dir)
        os.environ["TMP_ENV_VAR2"] = "${TMP_ENV_VAR}"
        path_with_env_vars = _create_module(Path(temp_dir / "sub_dir"), "config.py")


# Generated at 2022-06-12 09:42:18.094236
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        test_file_name = "test_file.py"
        test_path_str = str(Path(temp_dir).joinpath(test_file_name))
        with open(test_path_str, "w") as test_file:
            test_file.write("test_identifier = 42")
        module = load_module_from_file_location(
            test_path_str
        )
        assert module.test_identifier == 42
        module = load_module_from_file_location(Path(test_path_str))
        assert module.test_identifier == 42

# Generated at 2022-06-12 09:42:33.420237
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""
    location = "tests/test_module"

    module = load_module_from_file_location(location)
    assert hasattr(module, "test_module_attribute")
    assert module.test_module_attribute == 1

    location = Path(location)

    module = load_module_from_file_location(location)
    assert hasattr(module, "test_module_attribute")
    assert module.test_module_attribute == 1

    location = location.absolute()

    module = load_module_from_file_location(location)
    assert hasattr(module, "test_module_attribute")
    assert module.test_module_attribute == 1

    os_environ["SOME_ENV_VAR"] = str(location)


# Generated at 2022-06-12 09:42:41.855343
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Testing function load_module_from_file_location"""

    import docopt  # test import_string

    # A) Check if load_module_from_file_location works properly
    #    for a file in an absolute path.
    mod = load_module_from_file_location(
        location=Path(__file__).absolute().parent / "configs" / "tester.py",
        encoding="utf8"
    )

    assert mod.TEST_VARIABLE == "test"

    # B) Check if load_module_from_file_location works properly
    #    for a file in an relative path.
    mod = load_module_from_file_location(
        location="configs/tester.py", encoding="utf8"
    )

    assert mod.TEST_VARIA

# Generated at 2022-06-12 09:42:48.951804
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test function load_module_from_file_location.

    Test function load_module_from_file_location with all possible
    combinations:
        - Providing location as bytes vs str
        - Providing location as file path vs relative path
        - If file is Python file or not
        - Providing location with vs without environment variables
        - Providing location with vs without .encoding
        - Providing location with vs without .klass
        - Providing location with vs without .data
    """

    # Check for relative path to file
    TEST_RELATIVE_PATH = "./test_module"
    TEST_MODULE_RELATIVE_PATH = load_module_from_file_location(
        TEST_RELATIVE_PATH
    )
    assert TEST_MODULE_RELATIVE_PATH.test_func()

    # Check for absolute path to file


# Generated at 2022-06-12 09:42:57.195179
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import random, string, os
    import pytest
    from os import environ as os_environ
    from tempfile import NamedTemporaryFile

    @pytest.fixture
    def clean_up_env_variables():
        old_env_variables = os_environ.copy()  # Save old environment
        yield
        os.environ.clear()
        os.environ.update(old_env_variables)

    @pytest.fixture
    def random_file_content():
        content = "".join(
            random.choice(string.ascii_uppercase + string.digits)
            for _ in range(random.randint(50, 100))
        )

# Generated at 2022-06-12 09:43:05.270959
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    def load_config_module(
        location: Union[bytes, str, Path],
        encoding: str = "utf8",
        *args,
        **kwargs,
    ):
        return load_module_from_file_location(
            location, encoding, *args, **kwargs
        )

    with pytest.raises(IOError):
        load_config_module("bad_path")

    with pytest.raises(PyFileError):
        load_config_module("./tests/config_module_with_syntax_error.py")

    config_module = load_config_module("./tests/config_module.py")
    assert config_module.some_string == "some_string_value"
    assert config_module.some_int == 1
    assert config_module.some

# Generated at 2022-06-12 09:43:13.068408
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from tempfile import TemporaryDirectory

    tempdir = TemporaryDirectory(prefix="sanic-test-config-")
    tempdir_path = Path(tempdir.name)

    # 1. Loading file in .py format.
    # A) Check that file loads in normal way.
    assert (
        load_module_from_file_location(
            tempdir_path / "testfile.py", b"1"
        )
        == 1
    )

    # B) Check that file loads with Path object.
    assert (
        load_module_from_file_location(
            Path(tempdir_path / "testfile.py"), b"1"
        )
        == 1
    )

    # 2. Loading file in any other format.

# Generated at 2022-06-12 09:43:20.871106
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    location_str = "str_location"
    location_path = Path("path_location")
    location_bytes = bytes("bytes_location", "utf8")

    # Test with str location.
    module = load_module_from_file_location(location_str)
    assert module.__name__ == "str_location"
    assert module.__file__ == location_str

    # Test with Path location.
    module = load_module_from_file_location(location_path)
    assert module.__name__ == "path_location"
    assert module.__file__ == str(location_path)

    # Test with bytes location.
    module = load_module_from_file_location(location_bytes)
    assert module.__name__ == "bytes_location"

# Generated at 2022-06-12 09:43:26.974005
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "tests/fixtures/test.py"

    # A) Load test config
    loaded_module = load_module_from_file_location(location)

    assert loaded_module.setting_1 == 123
    assert loaded_module.setting_2 == "Some string"
    assert loaded_module.setting_3 == True
    assert loaded_module.setting_4 == False
    assert loaded_module.setting_5 == {
        "complex": "settings",
        "some_list": [
            {"some_dict": "in_list"},
            1,
            True,
            1234.5678,
        ],
    }

# Generated at 2022-06-12 09:43:32.767754
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from os import environ as os_environ
    from pathlib import Path
    from textwrap import dedent
    from unittest import TestCase

    class TestLoadModuleFromFileLocation(TestCase):
        def test_load_module_from_file_location_with_str(self):
            location = "some_module_name"
            some_module = load_module_from_file_location(location)

            self.assertEqual(some_module.__name__, location)

            # Check that module is imported, not loaded from file.
            self.assertEqual(some_module.__loader__, None)

            # Check that module is imported from source,
            # not from bytecode cache.
            self.assertEqual(some_module.__file__, location + ".py")
            self.assertE

# Generated at 2022-06-12 09:43:40.669051
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # Should work.
    os_environ.update({"env_var_1": "env_var_1_value"})
    location = "${env_var_1}/some/path"
    module = load_module_from_file_location(location)
    assert module.__file__ == "env_var_1_value/some/path"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    # Should not work since "env_var_2

# Generated at 2022-06-12 09:43:56.193873
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Checks if function load_module_from_file_location works as intended."""
    import pytest  # type: ignore
    import tempfile  # type: ignore
    import os

    # A) Setup test cases.

    # A.1) Test loading existing file.
    test_cases = [
        (Path("tests/test_files/test_file_1.py"),),
        ("tests/test_files/test_file_1.py",),
        ("tests/test_files/test_file_3",),
    ]

    # A.2) Test loading nonexistent file.
    nonexistent_path = "tests/not_existing_path/not_existing_file.py"
    test_cases.append((nonexistent_path,))

    # A.3) Test loading file with invalid path.
   

# Generated at 2022-06-12 09:44:02.046777
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: WPS440
    import inspect

    file_location = inspect.getsourcefile(load_module_from_file_location)
    module = load_module_from_file_location(file_location)

    assert module.__name__ == "config"
    assert isinstance(module.__dict__, dict)

    assert module.__dict__["str_to_bool"] is str_to_bool
    assert module.__dict__["load_module_from_file_location"] is load_module_from_file_location

# Generated at 2022-06-12 09:44:11.214263
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    class SomeTestModule:
        pass

    spec = importlib.util.spec_from_file_location(
        "somename", "some_path", loader=None
    )
    module = importlib.util.module_from_spec(spec)
    SomeTestModule = module
    del module

    spec = importlib.util.spec_from_file_location(
        "somename", "some_path", loader=None
    )
    module = importlib.util.module_from_spec(spec)
    SomeTestModule1 = module
    del module

    def test_load_module_from_file_location_from_file_object():
        path_string = Path(__file__).parent / "test_helper" / "test_load_module"

# Generated at 2022-06-12 09:44:13.388601
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location
    """
    # TODO: add file to test
    pass



# Generated at 2022-06-12 09:44:21.079391
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    bytes_location = load_module_from_file_location(
        bytes("./tests/unit_tests/config_file.conf", "utf8"), "ascii"
    )
    assert bytes_location.a == 1
    assert bytes_location.b == 2
    assert bytes_location.c == 3

    str_location = load_module_from_file_location("./tests/unit_tests/config_file.conf")
    assert str_location.a == 1
    assert str_location.b == 2
    assert str_location.c == 3

    location_with_env_var = load_module_from_file_location(
        "/tmp/${SOME_ENV_VAR}/config_file.py"
    )
    assert location_with_env_var.d == 4
    assert location_

# Generated at 2022-06-12 09:44:30.929959
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""

    # A-1) location as pathlib.Path.
    class A1:
        pass
    expected_module = A1()
    expected_module.__file__ = "/tmp/A1"
    got_module = load_module_from_file_location(Path(expected_module.__file__))
    assert got_module.__file__ == expected_module.__file__
    assert got_module.__class__ is types.ModuleType

    # A-2) location as string.
    class A2:
        pass
    expected_module = A2()
    expected_module.__file__ = "/tmp/A2"
    got_module = load_module_from_file_location(expected_module.__file__)
    assert got_module

# Generated at 2022-06-12 09:44:40.067954
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import json

    from tempfile import NamedTemporaryFile

    from sanic.helpers import load_module_from_file_location
    from sanic.exceptions import PyFileError, LoadFileException

    # Test cases
    test_cases = {
        # Success one
        "my_module": "my_module",
        # Failure one
        "my_module.": PyFileError,
        # Success one
        "my_module.example_module.example_module_2": "example_module_2",
        # Failure one
        "my_module.example_module.example_module_2.": LoadFileException,
    }

    # Check that every test case is passing

# Generated at 2022-06-12 09:44:45.644234
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    try:
        module = load_module_from_file_location("${some_env_var}")
    except LoadFileException as e:
        assert (
            str(e)
            == "The following environment variables are not set: "
            "some_env_var"
        )
        os_environ["some_env_var"] = "/path/to/module.py"
        module = load_module_from_file_location("${some_env_var}")
        assert module
        os_environ["some_env_var"] = "/path/to/file"

# Generated at 2022-06-12 09:44:52.605652
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "sanic/helpers.py"

    with pytest.raises(FileNotFoundError, match="Unable to load configuration file"):
        load_module_from_file_location("${FAKE_LOCATION}")

    assert load_module_from_file_location(location) == load_module_from_file_location(
        Path(location)
    )

    module = load_module_from_file_location("${PWD}", Path(location))
    assert module.__file__.endswith(location)

    module = load_module_from_file_location("${PWD}/" + location)
    assert module.__file__.endswith(location)

# Generated at 2022-06-12 09:45:01.060235
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 1. Without any environment variables in location
    _mod = load_module_from_file_location(
        "sanic.exceptions",
        "sanic/exceptions.py",
        origin="sanic/exceptions.py",
    )
    assert _mod
    assert _mod.LoadFileException

    # 2. With environment variables in location
    # Environment variable SANIC_TEST_ENV_VARIABLE must be set
    # to the absolute path of the sanic/exceptions.py file.

# Generated at 2022-06-12 09:45:15.927114
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test with absolute path.
    location = str(
        Path(__file__).parent.joinpath("mock_configs", "mock_config.py")
    )
    module = load_module_from_file_location(location)
    assert module.a == "test_a_value"

    # B) Test with relative path.
    location = "mock_configs/mock_config.py"
    module = load_module_from_file_location(location)
    assert module.a == "test_a_value"

    # C) Test with location variable containing environment variable.
    os_environ["some_env_var"] = "env_var_value"
    location = "mock_configs/${some_env_var}/mock_config.py"
    module = load_

# Generated at 2022-06-12 09:45:25.680915
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover
    from pathlib import Path
    import tempfile
    import unittest

    PATH = str(Path(__file__).parent / "config.py")

    class TestLoadModule(unittest.TestCase):
        def test_load_module_from_file_location(self):
            """Check that the configuration is loaded properly."""

            # A) File location is provided as a string.
            with self.assertRaises(FileNotFoundError):
                load_module_from_file_location(
                    "unexisting_file.py",
                    path=Path(__file__).parent,
                )

            actual = load_module_from_file_location(PATH)
            self.assertTrue(actual)

            # B) File location is provided as a Path.
            actual = load_module_from_file

# Generated at 2022-06-12 09:45:30.158796
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Successfully loading module from directory
    module = load_module_from_file_location(
        __file__, "tests/config_dir/config.py"
    )
    assert hasattr(module, "key")
    assert module.key == "value"

    # Successfully loading module from environment variables
    module = load_module_from_file_location(
        __file__, "/some/path/${PWD}/tests/config_dir/config.py"
    )
    assert hasattr(module, "key")
    assert module.key == "value"

    # Should raise an error when no such file
    try:
        load_module_from_file_location(__file__, "tests/config_dir/config2.py")
    except IOError:
        pass

# Generated at 2022-06-12 09:45:39.425522
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    from os import environ
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        module = """
        a = "a"
        b = "b"
        """

        config_path = Path(tmpdir).joinpath("config.py")
        config_path.write_text(module)
        assert load_module_from_file_location(config_path).a == "a"
        assert load_module_from_file_location(config_path).b == "b"

        module = """
        a = "a"
        b = "b"
        """

        config_path = Path(tmpdir).joinpath("config")
        config_path.write_text(module)
        assert load_module_from_file_location(config_path).a == "a"

# Generated at 2022-06-12 09:45:48.414243
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = Path(__file__).parent / "fixtures" / "test_config.py"
    assert isinstance(
        load_module_from_file_location(location),
        types.ModuleType,
    )

    assert isinstance(
        load_module_from_file_location(location.as_posix()),
        types.ModuleType,
    )

    assert isinstance(
        load_module_from_file_location(location.as_uri()),
        types.ModuleType,
    )

    assert isinstance(
        load_module_from_file_location(location.read_bytes()),
        types.ModuleType,
    )

    assert isinstance(
        load_module_from_file_location(location.read_bytes(), encoding="utf8"),
        types.ModuleType,
    )



# Generated at 2022-06-12 09:45:57.390276
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile, TemporaryDirectory

    # Test 1
    module = load_module_from_file_location(
        "tests/configs/test.py", "/some/path"
    )
    assert module.LOGGING_CONFIG == {"loggers": {"sanic": {"level": "DEBUG"}}}

    # Test 2
    module = load_module_from_file_location(
        "tests/configs/test.py", "${userprofile}/some/path"
    )

    # Test 3
    with TemporaryDirectory() as temp_dir:
        with open(os.path.join(temp_dir, "__init__.py"), "w") as f:
            f.write('CONFIG = {"key": "value"}')

# Generated at 2022-06-12 09:46:01.489424
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    file_name = str(Path(tempfile.gettempdir(), "file_name.py"))
    with open(file_name, "w+") as f:
        f.write("some_value = 'abc'")

    module = load_module_from_file_location(file_name)
    assert getattr(module, "some_value") == "abc"

# Generated at 2022-06-12 09:46:09.642225
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    spec = importlib.util.spec_from_file_location(
        'test_config', '/some/path/to/test_config.py'
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    assert module.TEST_CONFIG_CONSTANT == "some string"
    assert module.TEST_CONFIG_DICT == {"test_dict_key": "some string"}

    spec = importlib.util.spec_from_file_location(
        'test_config', '/some/path/to/test_config.json'
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    assert module.TEST_CONFIG_CONSTANT

# Generated at 2022-06-12 09:46:15.023883
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        module = load_module_from_file_location("some_module_name", "should_fail")
    except LoadFileException:
        pass
    else:
        assert False  # Pragma: no cover
    module = load_module_from_file_location("some_module_name", "sanic/server.py")

    assert module.__name__ == "some_module_name"
    assert module.__file__ == "sanic/server.py"



# Generated at 2022-06-12 09:46:24.324160
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Unit test for function load_module_from_file_location.
    """

    test_location1 = "tests/sample_config.py"
    test_location2 = Path(test_location1)
    test_location4 = "tests/sample_config_bytes.py"
    test_location5 = Path(test_location4)

    test_module1 = load_module_from_file_location(test_location1)
    test_module2 = load_module_from_file_location(test_location2)
    test_module4 = load_module_from_file_location(test_location4)
    test_module5 = load_module_from_file_location(test_location5)


# Generated at 2022-06-12 09:46:39.238640
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "some_module_name"
    import_string(location)  # check if module is available
    assert load_module_from_file_location(
        location
    ) == import_string(location)

    location = "some_module_name.py"
    import_string(location)  # check if module is available
    assert load_module_from_file_location(
        location
    ) == import_string(location)

    location = "/some/path/${some_env_var}"  # type: ignore
    os_environ["some_env_var"] = "some_value"  # type: ignore
    expected_location = "/some/path/some_value"
    assert load_module_from_file_location(
        location
    ) == load_module_from_file_location(expected_location)

# Generated at 2022-06-12 09:46:47.651599
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Given
    test_dir = Path("test_dir")
    test_dir.mkdir()
    test_dir_file = Path(test_dir, "test_file.py").absolute()
    test_str = "test variable"
    with test_dir_file.open("w") as test_file:
        test_file.write(f"test_variable = {repr(test_str)}")
        test_file.write("\n")

    # When
    loaded_module = load_module_from_file_location(
        location=test_dir_file
    )

    # Then
    assert loaded_module.test_variable == test_str

    # Cleanup
    test_dir.rmdir()

# Generated at 2022-06-12 09:46:57.958357
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import sys

    test_module = tempfile.NamedTemporaryFile(suffix=".py")
    test_module_dir = os.path.dirname(test_module.name)
    test_module_name = os.path.basename(test_module.name).split(".py")[0]
    test_module.write(b"a = 2\nb = 3\nc = 5")
    test_module.flush()

    sys.path.insert(0, test_module_dir)
    got_mod = load_module_from_file_location(test_module.name)
    sys.path.pop(0)

    assert got_mod.a == 2
    assert got_mod.c == 5
    assert got_mod.__name__ == test_module_name
   

# Generated at 2022-06-12 09:47:07.118585
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import io
    from tempfile import TemporaryDirectory

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    def test_environ_vars_in_location():
        tmp_dir = TemporaryDirectory()
        tmp_file = tmp_dir.name + "/test.py"

        with open(tmp_file, "w+") as f:
            f.write("")

# Generated at 2022-06-12 09:47:17.236431
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_location = "$TEST_ENV_VARIABLE/somewhere/somewhat"
    test_location_success = "/somewhere/somewhat"
    os_environ["TEST_ENV_VARIABLE"] = test_location_success
    loaded_module = load_module_from_file_location(test_location)
    assert loaded_module.__file__ == (os_environ["TEST_ENV_VARIABLE"] + "/somewhat")

    test_location_fail = "$TEST_ENV_VARIABLE_FAIL/somewhere/somewhat"
    with pytest.raises(LoadFileException):
        loaded_module = load_module_from_file_location(test_location_fail)

# Generated at 2022-06-12 09:47:27.594443
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if we can load module from relative path
    test_module = load_module_from_file_location(
        os.path.join(
            os.path.dirname(__file__), "..", "test_utils", "test_config.py"
        )
    )
    test_module_attributes = vars(test_module)
    assert all([
        test_module_attributes.get(k) == v for k, v in test_module_attributes.items()
        if k not in ["__builtins__", "__spec__", "__package__", "__name__"]
    ])

    # B) Check if we can load module from absolute path

# Generated at 2022-06-12 09:47:36.483616
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from sphinx.util.osutil import ensuredir
    from tempfile import mkdtemp
    from shutil import rmtree

    def modify_pyfile_basically(file_name: str):
        with open(file_name, "w") as f:
            f.write("#!/usr/bin/env python3\n" "variable = 0")

    def modify_pyfile_more_advanced(file_name: str):
        with open(file_name, "w") as f:
            f.write(
                """#!/usr/bin/env python3
                '''This module is created only
                for testing load_module_from_file_location()'''

                variable = 0

                def variable_adder(added_number):
                    variable += added_number
                    return variable

                """
            )


# Generated at 2022-06-12 09:47:46.062472
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    def test_file_import_from_os_environ(tmpdir):
        # Given:
        # A file named test.py with content of one line saying "test_var = 0"
        # Environment variable SANIC_TEST_ENV_VAR set to a name of directory
        # which contains test.py file.
        # When:
        # I load module from file
        # located at path ${SANIC_TEST_ENV_VAR}/test.py
        # Then:
        # I get the module which imports successfully.

        sanic_test_env_var = tmpdir.mkdir("sanic_test_env_var")
        file = sanic_test_env_var.join("test.py")
        file.write("test_var = 0")
        test_module = load_

# Generated at 2022-06-12 09:47:52.583187
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    os.environ["VAR_NAME"] = "var-value"

    module = load_module_from_file_location(
        "tests/test_config_files/environ.py"
    )

    assert module.test_var == "value"
    assert module.test_env_var == "var-value"

    module = load_module_from_file_location(Path("tests/test_config_files/environ.py"))
    assert module.test_var == "value"
    assert module.test_env_var == "var-value"

# Generated at 2022-06-12 09:48:00.084155
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # pylint: disable=unused-import
    from sanic.config import ModulePathDict, ModuleType

    location = "tests/test_config.py"
    module = load_module_from_file_location(location)
    assert module
    assert isinstance(module.TEST_CONFIG, ModuleType)
    assert module.TEST_CONFIG.TEST_KEY == "test_value"
    assert module.TEST_CONFIG.TEST_DICT == {"test_subkey": "test_subvalue"}
    assert isinstance(module.TEST_DICT, dict)
    assert module.TEST_DICT == {"TEST_KEY": "test_value"}
    assert isinstance(module.TEST_CONFIG_DICT, ModulePathDict)
    assert module.TEST_CONFIG_D