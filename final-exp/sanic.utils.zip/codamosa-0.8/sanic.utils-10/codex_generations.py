

# Generated at 2022-06-12 09:38:09.871981
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    # pylint: disable=E1120
    assert str_to_bool('y') == True
    assert str_to_bool('Y') == True
    assert str_to_bool('True') == True
    assert str_to_bool('t') == True
    assert str_to_bool('1') == True
    assert str_to_bool('yes') == True
    assert str_to_bool('N') == False
    assert str_to_bool('f') == False
    assert str_to_bool('0') == False
    assert str_to_bool('off') == False
    assert str_to_bool('false') == False
    try:
        str_to_bool('xyz')
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-12 09:38:19.870518
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import tempfile
    import shutil
    import pathlib

    class TemporaryDirectory(object):
        """
        Context manager for tempfile.mkdtemp() so it's usable with "with" statement.
        Taken from: https://stackoverflow.com/a/13448458
        License: CC BY-SA 4.0
        """

        def __init__(self, suffix="", prefix="tmp", dir=None):
            self.name = tempfile.mkdtemp(suffix, prefix, dir)
            self.name = pathlib.Path(self.name)

        def __enter__(self):
            return self.name


# Generated at 2022-06-12 09:38:27.996654
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from io import StringIO

    import sys

    # case when location is string
    module = load_module_from_file_location(location="sys")
    assert module is sys
    assert module.__dict__ == sys.__dict__
    assert module.__name__ == sys.__name__

    # case when location is Path
    module = load_module_from_file_location(
        location=sys.modules["sanic.config"].__file__
    )
    assert module.__file__ == sys.modules["sanic.config"].__file__
    assert module.__dict__ == sys.modules["sanic.config"].__dict__

    # case when location is bytes

# Generated at 2022-06-12 09:38:39.073038
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function."""
    os_environ["name_of_env_var"] = "some_env_var"
    test_cwd = str(Path.cwd())
    assert load_module_from_file_location(
        test_cwd + "/tests/test_load_module_from_file_location.py"
    ).test == "test"
    assert load_module_from_file_location(
        test_cwd + "/tests/test_load_module_from_file_location.py"
    ).env_var == "some_env_var"

# Generated at 2022-06-12 09:38:42.699213
# Unit test for function str_to_bool
def test_str_to_bool():
    assert not str_to_bool("no")
    assert str_to_bool(
        "y"
    )  # I was just curious to know if this will allso work

    with pytest.raises(ValueError):
        # Just in case
        str_to_bool("I don't know")



# Generated at 2022-06-12 09:38:44.022005
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("sanic.__init__", "sanic/__init__.py")

# Generated at 2022-06-12 09:38:54.040202
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import makedirs
    from random import choice
    from shutil import rmtree

    def get_random_string():
        import os
        return (''.join(
            choice(os.environ['SYSTEMDRIVE'] + os.path.sep + "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789") for i in range(8)
        ))

    def create_content_file(dir_name, file_name, content):
        with open(dir_name + os.path.sep + file_name, 'w') as file:
            file.write(content)
            file.close()

    import sys

    sys.modules.pop('config', None)

    import os
    dir_name, file_name, file_name_without_ext, content = get_random_

# Generated at 2022-06-12 09:38:59.079832
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    tmpdir = tempfile.TemporaryDirectory()
    os.environ["TEST_ENV_VAR"] = tmpdir.name


# Generated at 2022-06-12 09:39:07.346303
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import sys
    import os
    import tempfile
    import shutil
    import io

    import pytest

    # Let's write a simple module into temporary directory.
    temp_dir = tempfile.mkdtemp()
    temp_file_path = os.path.join(temp_dir, "temp_file.py")
    with open(temp_file_path, "w") as temp_file:
        temp_file.write("VAR = 1")

    # add temp_dir to sys.path
    sys.path.append(temp_dir)

    # import this module.
    temp_file_import_name = "temp_file"
    module = import_string(temp_file_import_name)
    # check if it was loaded properly
    assert module.VAR == 1

    # clean up

# Generated at 2022-06-12 09:39:16.834644
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ, pathsep
    from tempfile import gettempdir

    from pytest import raises

    from .helpers_tests import (
        ModuleWithAttributes,
        ModuleWithMutableAttributes,
    )

    # some_config.py
    # config_string = """
    # foo = 42
    # bar = True
    # """

    # Test 1
    # path_to_config = gettempdir() + "/some_config.py"
    # with open(path_to_config, "w") as config_file:
    #     config_file.write(config_string)
    a = load_module_from_file_location(
        gettempdir() + "/some_config.py", encoding="utf8"
    )
    assert a.foo == 42

    # Test 2
    # path_

# Generated at 2022-06-12 09:39:27.071245
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location(
            "/some/path/${SOME_ENV_VAR}/some_module_name.py"
        )
        == "SomeModuleName"
    )
    assert (
        load_module_from_file_location(
            "/some/path/${NOT_DEFINED_ENV_VAR}/some_module_name.py"
        )
        == "SomeModuleName"
    )
    # Create file
    temp_file = "/tmp/test_load_module_from_file_location.py"
    handle = open(temp_file, "w")
    handle.close()

    assert load_module_from_file_location(temp_file)

    os.remove(temp_file)

# Generated at 2022-06-12 09:39:36.551075
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module1 = load_module_from_file_location("./tests/test_app/my_module.py")
    module2 = load_module_from_file_location("./tests/test_app/my_module")
    module1.value = "hello"
    assert module1.value == module2.value



# Generated at 2022-06-12 09:39:45.273797
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load module from file location.
    In this test we use project configuration.
    """
    os_environ["SANIC_CONFIG_FILE"] = "test.py"
    import pytest

    with pytest.raises(ValueError):
        load_module_from_file_location("any_string")

    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "/usr/lib/python3.6/site-packages/${SANIC_CONFIG_FILE}"
        )


# Generated at 2022-06-12 09:39:51.873533
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import inspect

    # Function is defined in this file, so lets check it.
    assert inspect.getsource(load_module_from_file_location) == inspect.getsource(
        globs()["load_module_from_file_location"]
    )

    # Test with bytes path
    test_bytes_module = load_module_from_file_location(
        b"sanic/helpers/test_load_module_from_file_location.py", "utf8"
    )
    assert test_bytes_module.__name__ == "test_load_module_from_file_location"

    # Test with string path and pathlib path
    test_string_module = load_module_from_file_location(
        "sanic/helpers/test_load_module_from_file_location.py"
    )


# Generated at 2022-06-12 09:40:00.713248
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os

    from tempfile import mktemp
    from pathlib import Path

    SOME_ENV_VAR = "SOME_ENV_VAR"
    SOME_ENV_VAR_VALUE = "SOME_ENV_VAR_VALUE"
    SOME_ENV_VAR_VALUE_MODIFIED = "SOME_ENV_VAR_VALUE_MODIFIED"
    SOME_ENV_VAR_WITHOUT_VALUE = "SOME_ENV_VAR_WITHOUT_VALUE"
    SOME_ENV_VAR_WITHOUT_VALUE_MODIFIED = "SOME_ENV_VAR_WITHOUT_VALUE_MODIFIED"

    # A) Create temporary files and environment variables
    #    that will be used in testing.
    temp_file_for_bytes = mk

# Generated at 2022-06-12 09:40:08.919965
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os
    import pytest
    from tempfile import TemporaryDirectory

    def prepare_module_in_temp_dir(module_content):
        with TemporaryDirectory() as temp_dir:
            tmp_file_path = os.path.join(temp_dir, "config.py")
            with open(tmp_file_path, "w") as f_out:
                f_out.write(module_content)
            return load_module_from_file_location(
                tmp_file_path, encoding=None
            )

    def test_load_module_from_file_location_with_content(module_content):
        config_module = prepare_module_in_temp_dir(module_content)
        assert config_module.value == 1


# Generated at 2022-06-12 09:40:15.685396
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""

    # A) Check that this function correctly handle bytes file path
    #    and correctly decode it
    some_test_path = b"./some_test_path.py"
    some_test_module = load_module_from_file_location(  # noqa: F841
        some_test_path, encoding="utf8"
    )

    # B) Check that this function correctly handle environment vars in file path
    os_environ["some_env_var"] = "some_value"
    some_test_path = b"./${some_env_var}.py"
    some_test_module = load_module_from_file_location(  # noqa: F841
        some_test_path, encoding="utf8"
    )
   

# Generated at 2022-06-12 09:40:24.946625
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # We can't unit test function which load environment variables.
    # So we take a bit different approach.
    # 1. We mock module.
    # 2. We mock set of env variables.
    # 3. Check that all environments variables in given location
    #    are defined in mocked env.
    # 4. Check that given module is loaded.

    # 1. Mock module.
    module = types.ModuleType("config")
    module.__file__ = "some_module_name"
    module.some_attr = "some_attr_value"

    # 2. Mock env.
    mock_env = {"SOME_ENV_VAR": "some_env_var_value"}

    # 3. Check that all environments variables in given location
    #    are defined in mocked env.

# Generated at 2022-06-12 09:40:32.348497
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os.path import join, abspath
    from time import time
    from tempfile import mkdtemp

    TEMP_DIR = abspath(join(mkdtemp(), "tmp"))

    TEMP_FILE = join(TEMP_DIR, f"{int(time())}.tmp")
    with open(TEMP_FILE, "w") as tf:
        tf.truncate(0)
        tf.write('TEMP_VAR = "test_val"')

    TEMP_FILE2 = join(TEMP_DIR, f"{int(time())}.tmp")
    with open(TEMP_FILE2, "wb") as tf:
        tf.truncate(0)
        tf.write('TEMP_VAR = "test_val"'.encode("utf8"))

    # Test for when path is given as Path

# Generated at 2022-06-12 09:40:35.249028
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("mock_module") == __import__("mock_module")
    assert load_module_from_file_location("mock_module.mock_class") == __import__("mock_module").mock_class

    assert load_module_from_file_location(__file__) == __import__("tests.test_utils")

# Generated at 2022-06-12 09:40:46.409643
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Module from simple path
    module = load_module_from_file_location("tempfile")
    assert hasattr(module, "TemporaryDirectory")

    # Module from unicode path
    module = load_module_from_file_location("tempfile")
    assert hasattr(module, "TemporaryDirectory")

    # Module from path/filename
    module = load_module_from_file_location("tempfile.py")
    assert hasattr(module, "TemporaryDirectory")

    # Module from path that is environment variable
    module = load_module_from_file_location("${TEMP}/temp")
    assert hasattr(module, "TemporaryDirectory")

    # Module from not existing filename

# Generated at 2022-06-12 09:40:55.018963
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def try_location(location: str, *args, **kwargs):
        loaded_module = load_module_from_file_location(location, *args, **kwargs)
        return getattr(loaded_module, "some_attribute", None)

    test_var = "test_name"
    os_environ["test_env_var"] = test_var
    path_to_test_file = Path("test_config.py")
    path_to_test_file.write_text("some_attribute = 'some_value'")

    assert try_location(path_to_test_file) == "some_value"

    path_to_test_file.unlink()

    path_to_test_file = Path("test_config.py")


# Generated at 2022-06-12 09:40:58.008355
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(  # nosec
        "test_module", "./test_module.py"
    ).main == "test_module"



# Generated at 2022-06-12 09:41:05.858108
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = types.ModuleType("module")
    module.__file__ = str(Path("mock_path"))
    module.some_param = "some_value"
    module.some_function = lambda: "some_value"

    importlib.util.spec_from_file_location = mock.Mock(
        return_value=types.SimpleNamespace(
            name="mock_name", loader=mock.Mock(exec_module=mock.Mock())
        )
    )

    with mock.patch("sanic.helpers.get_source_from_pyfile") as mocked_file:
        mocked_file.return_value = """
        some_param = "some_value"
    """.strip()

        # If location is Path-compatible.

# Generated at 2022-06-12 09:41:14.437701
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test for case when location has environment variable in format ${}.
    module = load_module_from_file_location(
        "/some/path/${some_env_var}",
    )
    module = load_module_from_file_location(
        "/some/path/${some_env_var}/some_file.py",
    )

    # Test for case when location has environment variable in format $.
    module = load_module_from_file_location(
        "/some/path/$some_env_var",
    )
    module = load_module_from_file_location(
        "/some/path/$some_env_var/some_file.py",
    )

    # Test for case when location have not have environment variables.

# Generated at 2022-06-12 09:41:23.225045
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import sys
    import os

    sys.path.append(os.path.join(os.path.dirname(__file__), 'loadfile_test_files'))  # noqa

    import loadfile_test_files.regular_file

    assert id(load_module_from_file_location("loadfile_test_files/regular_file.py")) == id(  # noqa
        loadfile_test_files.regular_file
    )
    assert id(
        load_module_from_file_location("loadfile_test_files/regular_file")
    ) == id(loadfile_test_files.regular_file)


# Generated at 2022-06-12 09:41:29.405015
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from . import load_module_from_file_location
    from os import environ
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        tmp_dir_path = Path(tmp_dir)
        tmp_py_file = tmp_dir_path / "tmp.py"

        with tmp_py_file.open("w") as tmp_py_file_write:
            tmp_py_file_write.write(
                """
                some_var_0 = 1
                some_var_1 = "some_string"
                """
            )

        module = load_module_from_file_location(tmp_py_file)
        assert module.some_var_0 == 1
        assert module.some_var_1 == "some_string"


# Generated at 2022-06-12 09:41:39.473663
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from pathlib import Path
    from tempfile import TemporaryDirectory

    # Test under the condition that path to file
    # is provided as a bytes type with encoding.
    with TemporaryDirectory() as tempdir:
        path_to_module_file = Path(tempdir) / "module.py"
        path_to_module_file.touch()
        module = load_module_from_file_location(
            location=bytes(path_to_module_file),
            encoding="utf-8",
        )

        assert "module" == module.__name__

    # Test under the condition that path to file
    # is provided as a string with environment variables.
    with TemporaryDirectory() as tempdir:
        environ["TEST_PATH"] = tempdir
        path_to_module_file = Path(tempdir)

# Generated at 2022-06-12 09:41:45.220123
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_path = Path(__file__).parent.joinpath("config_for_tests.py")
    config = load_module_from_file_location(
        test_path, import_errors=["Too many module level imports"]
    )
    assert config.NAME == "config_for_tests"
    assert config.A == 1
    assert config.B == [1, 2, 3]
    assert config.C == {"a": 1, "b": 2}

# Generated at 2022-06-12 09:41:51.734676
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import json

    tmpdir = tempfile.TemporaryDirectory(prefix="sanic-tests-")

    # Test file loading.
    with open(f"{tmpdir.name}/test_json.txt", "w") as f:
        f.write(json.dumps({"key": "value"}))

    module = load_module_from_file_location(f"{tmpdir.name}/test_json.txt")

    assert module.key == "value"

    # Test environment variable substituting.
    with open(f"{tmpdir.name}/test_env_var.txt", "w") as f:
        f.write(json.dumps({"key": "value"}))


# Generated at 2022-06-12 09:42:06.026132
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    assert load_module_from_file_location("./tests/config/example.py")
    assert load_module_from_file_location("./tests/config/example.ini")

    assert load_module_from_file_location(b"some_module_name", b"./tests/config/example.py")
    assert load_module_from_file_location(b"some_module_name", b"./tests/config/example.ini")

    os_environ["TEST_ENV_VAR"] = "test_env_var_value"
    assert load_module_from_file_location("./tests/config/example.py", "/tests/${TEST_ENV_VAR}/config")

# Generated at 2022-06-12 09:42:15.684972
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_path = "./tests/configs/test_module_from_file.py"
    module = load_module_from_file_location(file_path)
    assert module.CONFIG_TEST_TRUE is True
    assert module.CONFIG_TEST_FALSE is False
    assert module.CONFIG_TEST_NONE is None
    assert module.CONFIG_TEST_NUMBER == 1
    assert module.CONFIG_TEST_STRING == "This is config test string"
    assert module.CONFIG_TEST_DICT["a"] == 1
    assert module.CONFIG_TEST_DICT["b"] == 2
    assert module.CONFIG_TEST_DICT["c"] == 3


if __name__ == "__main__":
    test_load_module_from_file_

# Generated at 2022-06-12 09:42:25.333480
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A)
    # A1)
    os.environ["hello"] = "world"
    config = load_module_from_file_location(
        "./tests/test_config.py", "${hello}/tests/${hello_2}/test_config.py"
    )  # Real env variable
    assert config.OWN_CONFIG_VAR == "hello:world"
    del os.environ["hello"]
    # A2)
    os.environ["hello_2"] = "world_2"
    config = load_module_from_file_location(
        "./tests/test_config.py", "${hello}/tests/${hello_2}/test_config.py"
    )  # Missing env variable

# Generated at 2022-06-12 09:42:34.659056
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from .utils import get_test_config
    from .utils import TEST_FOLDER_PATH, TEST_CONFIG_PATH, TEST_CONFIG_FILE

    config = get_test_config(TEST_FOLDER_PATH)

    assert (
        load_module_from_file_location(
            TEST_CONFIG_PATH, TEST_CONFIG_FILE
        ).CONFIG_ENV == config.get(
            "CONFIG_ENV"
        )
    )  # Load with bytes and str path

    assert (
        load_module_from_file_location(
            Path(TEST_CONFIG_FILE), TEST_CONFIG_PATH
        ).CONFIG_ENV == config.get(
            "CONFIG_ENV"
        )
    )  # Load with pathlib.Path and str

# Generated at 2022-06-12 09:42:39.901085
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    another_module_location = os.path.abspath(
        "tests/test_apps/anothermodule.py"
    )
    another_module = load_module_from_file_location(
        another_module_location
    )
    assert hasattr(another_module, "test_method_1")
    assert hasattr(another_module, "test_var_1")
    assert another_module.test_method_1() == 1



# Generated at 2022-06-12 09:42:47.261430
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import sanic

    sanic_config = load_module_from_file_location(
        bytes(sanic.__file__, "utf8"), "utf8"
    )
    assert sanic_config.__name__ == "sanic"

    import os
    import pathlib

    # Testing with Path object
    # Current directory
    curr_dir = pathlib.Path.cwd()
    # Name of current directory
    curr_dir_name = curr_dir.name
    # Creating configuration file in current directory
    with curr_dir.joinpath(curr_dir_name + ".py").open(mode="w") as conf_file:
        conf_file.write("# This is config file")


# Generated at 2022-06-12 09:42:55.950710
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from unittest import TestCase

    from sanic.exceptions import InvalidUsage

    from sanic.testing import HOST, PORT

    from .helpers import TestInstance, TestSanic

    class TestEnvironmentVar:
        def __init__(
            self, env_var_name, env_var_value, test_app_config_location
        ):
            self.env_var_name = env_var_name
            self.env_var_value = env_var_value
            self.test_app_config_location = test_app_config_location

        def setUp(self):
            os_environ[self.env_var_name] = self.env_var_value

        def tearDown(self):
            del os_environ[self.env_var_name]


# Generated at 2022-06-12 09:43:04.086403
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["sanic_test_env_var"] = "test_val"

    assert load_module_from_file_location("./tests/fake_module")
    assert load_module_from_file_location(
        "/tests/${sanic_test_env_var}/fake_module"
    )

    with pytest.raises(
        LoadFileException, match="The following environment variables are not set"
    ):
        load_module_from_file_location("/tests/${fake_env_var}/fake_module")

    assert load_module_from_file_location(b"./tests/fake_module", "utf-8")

# Generated at 2022-06-12 09:43:11.303026
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    # Create temporary directory because
    # we will create a lot of files in it.
    temp_dir_path = tempfile.mkdtemp()
    os.environ["TEMP_DIR_PATH"] = temp_dir_path # noqa

    # Create a file with module with one integer
    # variable and it's definition.
    file_path = temp_dir_path + "/test_file.py"
    with open(file_path, "w") as test_file:
        test_file.write("variable = 446")

    # Test if this module is properly loaded.
    module = load_module_from_file_location(file_path)
    assert module.variable == 446

    # Test if env variable is properly resolved.
    module = load_module_from_

# Generated at 2022-06-12 09:43:18.917929
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import configparser  # noqa
    import unittest

    class TestUtils(unittest.TestCase):
        def setUp(self):
            self.some_dir = Path(__file__).parent / Path("test_some_dir")
            self.some_dir_file = self.some_dir / Path("file_in_dir.py")
            self.some_dir_file.parent.mkdir(exist_ok=True)
            self.some_dir_file.touch()
            self.some_dir_file.write_text(
                "some_var=3", encoding="utf8"
            )  # nosec
            self.another_dir = Path(__file__).parent / Path("test_another_dir")

# Generated at 2022-06-12 09:43:31.258314
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    # Sanity check - returns module if no configuration is required.
    module_mock = types.ModuleType("test_module")
    assert load_module_from_file_location("test_module") == module_mock

    # If location is pathlib.Path object, then first replace it to a string
    # and then pass to a regular path.
    module_mock = types.ModuleType("test_module")
    module_mock.__file__ = str(Path("some_path"))
    assert (
        load_module_from_file_location(Path("some_path")) == module_mock
    )

    # If location contains environment variable in format ${some_env_var},
    # then substitute it from the os.environ.
    #


# Generated at 2022-06-12 09:43:39.706357
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    test_mod_path = "tests/test_utils.py"
    test_mod = load_module_from_file_location(test_mod_path)
    assert test_mod.test_function() == "test"
    test_mod_path = (
        os.path.dirname(os.path.realpath(__file__)) + "/tests/test_utils.py"
    )
    test_mod = load_module_from_file_location(test_mod_path)
    assert test_mod.test_function() == "test"
    test_mod_path = Path("tests/test_utils.py")
    test_mod = load_module_from_file_location(test_mod_path)
    assert test_mod.test_function() == "test"

# Generated at 2022-06-12 09:43:49.265270
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # A) Check if location contains any environment variables and replace them.
    os_environ["some_env_var"] = "some_value"
    os_environ["some_other_env_var"] = "some_other_value"
    _module = load_module_from_file_location(
        r"${some_env_var}/${some_other_env_var}/some_module_name.py"
    )
    assert _module.__name__ == "some_module_name"
    assert _module.__file__ == r"some_value/some_other_value/some_module_name.py"

    # B) Test if it can load .py file if it's provided as just a string.

# Generated at 2022-06-12 09:43:58.367484
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    from os import environ as os_environ
    from os import unlink as os_unlink
    from os import path as os_path

    class TestClass(object):
        def __init__(self, a, b, c="a"):
            self.a = a
            self.b = b
            self.c = c

    # Setup test environment.
    with tempfile.NamedTemporaryFile("w", delete=False) as f:
        f.write("a=1\n")
        f.write("b=2\n")
        f.write("c=3\n")
        test_conf_path = f.name

    test_key = "test_env_var"
    test_env_var = os_path.split(test_conf_path)[0]
    # Mark

# Generated at 2022-06-12 09:44:05.677515
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import tempfile

    expected_config_values = {"some_key": "some_value"}
    file, filepath = tempfile.mkstemp(suffix=".py")
    with open(file, "w") as file_opened:
        dump_str = "some_key = " + "'" + expected_config_values["some_key"] + "'"
        file_opened.write(dump_str)
    loaded_module = load_module_from_file_location(filepath)
    assert expected_config_values["some_key"] == loaded_module.some_key

# Generated at 2022-06-12 09:44:15.207241
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # str_to_bool
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool

# Generated at 2022-06-12 09:44:21.951060
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["ENV_VAR_A"] = "test_A"
    os_environ["ENV_VAR_B"] = "test_B"

    # Path
    class_path_1 = Path(__file__).parent / "test_1.py"
    module_1 = load_module_from_file_location(class_path_1)
    assert module_1.var == 1

    # Path with env variable in the middle
    class_path_2 = Path(__file__).parent / (
        "test_2_${ENV_VAR_A}.py"
    )  # type: ignore
    module_2 = load_module_from_file_location(class_path_2)
    assert module_2.var == 2

    # Path with env variable as parent directory
    class_

# Generated at 2022-06-12 09:44:31.679548
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from types import ModuleType
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile("w", suffix=".py") as t1:
        t1.write("test_string = 42")
        t1.seek(0)
        module = load_module_from_file_location(t1.name)

    assert type(module) == ModuleType
    assert module.test_string == 42

    with NamedTemporaryFile("wb") as t2:
        t2.write(b"test_string = 42")
        t2.seek(0)
        module_bytes = load_module_from_file_location(t2.name, encoding="utf8")

    assert type(module_bytes) == ModuleType
    assert module_bytes.test_string == 42

# Generated at 2022-06-12 09:44:40.438411
# Unit test for function load_module_from_file_location

# Generated at 2022-06-12 09:44:47.942125
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Raise no error
    # A) load module from path
    load_module_from_file_location(__file__)
    # B) load module from path with env var
    module_path = str(Path(__file__).parent)
    os_environ["SANIC_TEST_MODULE_DIR"] = module_path
    load_module_from_file_location(
        "${SANIC_TEST_MODULE_DIR}/helpers.py"
    )
    # C) load module from path (instead of module name)
    load_module_from_file_location(f"{module_path}/helpers.py")

    # Raise errors
    # A) load module from path - Raise LoadFileException

# Generated at 2022-06-12 09:45:02.036702
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    temp_dir = Path(tempfile.gettempdir())
    test_path = temp_dir.joinpath("test_config.py")
    test_path_relative = "test_config.py"
    with test_path.open("w") as test_file:
        test_file.write("CONFIG_VALUE = True")

    module = load_module_from_file_location(test_path)
    assert module.CONFIG_VALUE is True

    module = load_module_from_file_location(test_path_relative)
    assert module.CONFIG_VALUE is True

    module = load_module_from_file_location(temp_dir)
    assert module.__file__ == str(temp_dir)

    module = load_module_from_file_location(module)
    assert module.__

# Generated at 2022-06-12 09:45:12.098800
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
        Unit test for function load_module_from_file_location.

        For this function is needed to have a file:
            "./.temp_cfg_file_for_test.py"
        with content:

           ONE_VARIABLE = 1

        To prepare environment before running unit tests just run:

            make setup-for-tests
    """
    from os import environ as os_environ
    from sys import path as sys_path
    from tempfile import mkdtemp
    from textwrap import dedent

    from pytest import raises


    # A) Setup environment for testing
    #    ==================================================

    # Take a name for temporary directory where
    # temporary configuration file will be created

# Generated at 2022-06-12 09:45:21.179203
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert isinstance(
        load_module_from_file_location(
            r'assert load_module_from_file_location("tests/test_helper.py").__name__ == "test_helper"',
            r"tests\test_helper.py",
        ),
        types.ModuleType,
    )
    assert isinstance(
        load_module_from_file_location(
            r'assert load_module_from_file_location(r"tests\test_helper.py").__name__ == "test_helper"',
            r"tests/test_helper.py",
        ),
        types.ModuleType,
    )

# Generated at 2022-06-12 09:45:30.347570
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    from os import environ as os_environ

    os_environ["ENV_VAR"] = "xxx"

    def _test_load_module_from_file_location(
        location, with_main_dirname=False
    ):
        with tempfile.TemporaryDirectory() as tempdir:
            tempdir_path = Path(f"{tempdir}")
            with open(tempdir_path / "test_file.py", "w") as test_file:
                test_file.write(
                    f"test_var = {repr(location)}\ntest_var\n"
                )

# Generated at 2022-06-12 09:45:39.706046
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_ENV_VAR"] = "test-env-var-value"
    os_environ["TEST_ENV_VAR_WITHOUT_DASH"] = "test-env-var-without-dash-value"
    location = Path("test/test_helpers.py")

    module = load_module_from_file_location(location)
    assert module.__file__ == str(location)

    module = load_module_from_file_location("test/test_helpers.py")
    assert module.__file__ == str(location)

    module = load_module_from_file_location(location.as_posix())
    assert module.__file__ == str(location)

    module = load_module_from_file_location("test/test_helpers.py")

# Generated at 2022-06-12 09:45:41.583513
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location(None) is None
    ), "Loaded module should be None."



# Generated at 2022-06-12 09:45:50.760881
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys
    import tempfile
    import unittest

    import yaml

    class TestCase(unittest.TestCase):
        cur_dir = os.path.dirname(__file__)
        for_yaml = os.path.join(cur_dir, "for_yaml.yml")
        random_path = tempfile.mkdtemp()
        random_file = os.path.join(random_path, "__init__.py")

        with open(for_yaml, "w") as f:
            yaml.dump({"sanic": "Hello"}, f)

        def tearDown(self):
            os.remove(self.for_yaml)
            os.rmdir(self.random_path)


# Generated at 2022-06-12 09:45:59.579060
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def _load_module_from_file_location_environ_as_utf8(
        env_var_utf8: str,
        location: str,
        expected: type,
        expected_attribute: str,
    ):
        os_environ[env_var_utf8] = env_var_utf8
        module = load_module_from_file_location(location)
        assert isinstance(module, expected)
        assert hasattr(module, expected_attribute)
        assert getattr(module, expected_attribute) == getattr(
            expected, expected_attribute
        )
        assert os_environ[env_var_utf8] == env_var_utf8
        del os_environ[env_var_utf8]


# Generated at 2022-06-12 09:46:05.586965
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from unittest.mock import patch

    # For Python 3.4
    if not hasattr(Path, "resolve"):
        Path.resolve = Path.absolute

    load_module_from_file_location("pathlib")

    with patch("sanic.helpers.load_module_from_file_location.Path") as mock_path:
        with patch("sanic.helpers.load_module_from_file_location.os_environ"):
            mock_path.resolve.return_value = Path("path")

# Generated at 2022-06-12 09:46:14.525271
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from textwrap import dedent

    # A) Testing loading module from path with environment variables.

    # A.1) When environment variables are set.
    os_environ["some_env_var"] = "some_value"
    config = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}/${some_env_var}.py"
    )
    assert config.__file__ == "/some/path/some_value/some_value.py"
    assert config.module_property == "module_value"
    del os_environ["some_env_var"]

    # A.2) When environment variables are not set.

# Generated at 2022-06-12 09:46:28.295174
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 1) Check that a file can be loaded.
    dict_from_file = load_module_from_file_location(
        __file__.replace(".py", ".ini")
    )
    assert "test" in dict_from_file
    assert "test_load_module_from_file_location" in dict_from_file
    # 2) Check that when no file is provided,
    #    ValueError is raised.
    try:
        load_module_from_file_location(None)
    except ValueError:
        pass
    # 3) Check that file specified by path can be loaded.
    dict_from_file_by_path = load_module_from_file_location(
        Path(__file__).parent / Path(__file__).stem + ".ini"
    )
    assert dict_from_file

# Generated at 2022-06-12 09:46:35.834779
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    some_test_string = "some_test_string"

    with tempfile.NamedTemporaryFile(delete=False) as temp:
        temp.write(b"SOME_TEST_CONFIG_VAR = '%s'\n" % some_test_string.encode())

    try:
        module = load_module_from_file_location(temp.name)
        assert module.SOME_TEST_CONFIG_VAR == some_test_string
    finally:
        os.unlink(temp.name)



# Generated at 2022-06-12 09:46:40.819096
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    location = Path(
        "./tests/test_folder/test_module.py"
    )  # relative path to this file
    module_location = load_module_from_file_location(
        location.absolute(), "utf-8"
    )
    assert module_location.__name__ == "test_module"
    assert hasattr(module_location, "__file__")
    assert module_location.__file__ == str(location.absolute())
    assert module_location.a == 1
    assert module_location.b == 2



# Generated at 2022-06-12 09:46:51.489858
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    location = "/some/path/${some_env_var}"
    os_environ["some_env_var"] = "some_env_val"
    assert load_module_from_file_location(location).__file__ == (
        "/some/path/some_env_val"
    )

    location = "/some/path/${some_env_var_not_set}"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    location = "configs.config"
    assert load_module_from_file_location(location).__file__.endswith(
        "configs/config.py"
    )

    location = "configs/config.py"
    assert load_module_from_file_location(location).__file__.endswith

# Generated at 2022-06-12 09:46:59.916626
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    class SanicConfigMock:
        """Mock Sanic config class that loads a settings module or a settings
        dictionary and returns the loaded settings.
        """

        def __init__(self, settings):
            self.settings = settings

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    location = "config.py"
    module = load_module_from_file_location(location)
    assert isinstance(module, types.ModuleType)
    assert module.__name__ == "config"

    # B) Check these variables exists in environment.
    os_environ.setdefault("CONFIG_FILE", "config.py")
    location = "./${CONFIG_FILE}"
    module = load_module_from_file_location(location)

# Generated at 2022-06-12 09:47:03.986724
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    if sys.version_info < (3, 6):
        return
    config = load_module_from_file_location(
        Path(__file__).parent / "test_dir" / "valid_config.py"
    )
    assert config.PORT == 8000

# Generated at 2022-06-12 09:47:14.460592
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test error with environment variables in location
    with pytest.raises(LoadFileException):
        load_module_from_file_location("./sanic/tests/test_config.py", location="${UNDEFINED_ENV}") # noqa

    # Valid configuration file
    config = load_module_from_file_location("./sanic/tests/test_config.py")
    assert config.TEST_KEY == "test value"

    # Valid configuration file in string
    config = load_module_from_file_location("./sanic/tests/test_config.py", location="./sanic/tests/test_config.py") # noqa
    assert config.TEST_KEY == "test value"

    # Valid configuration file in bytes

# Generated at 2022-06-12 09:47:19.071735
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    given_location = "tests/test_utils/test_functions.py"
    given_function = "test_function"
    given_args = "hello"
    assert hasattr(
        load_module_from_file_location(given_location), given_function
    )
    assert getattr(
        load_module_from_file_location(given_location), given_function
    )(given_args) == given_args

# Generated at 2022-06-12 09:47:28.398706
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import time

    # A) Create tmp dir
    tmp_dir_path = tempfile.mkdtemp()

    # B) Create file with some data
    some_text = "some text"
    some_file_name = "some_file.py"
    some_file_path = Path(tmp_dir_path) / some_file_name
    open(some_file_path, "w").write(some_text)

    # C) Define environment variables.
    test_env_variable_name = "TEST_ENV_VARIABLE"
    test_env_variable_value = "test_env_variable_value"
    os_environ[test_env_variable_name] = test_env_variable_value

    # D) Function load_module_from_file

# Generated at 2022-06-12 09:47:37.271451
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ

    from tempfile import TemporaryFile
    from pathlib import Path

    environ["TEST_ENV_VAR"] = "test_env_var_value"

# Generated at 2022-06-12 09:47:51.938496
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """try reload of module, by import it from new location"""
    import sanic.config

    sanic.config.CONFIG_PATH = "some_module_name"
    some_module = load_module_from_file_location(sanic.config.CONFIG_PATH)
    assert some_module is not None

    new_path = "some_module_name_1"
    some_module = load_module_from_file_location(new_path)
    assert some_module is not None

    try:
        load_module_from_file_location(new_path, {})
    except TypeError:
        pass

    try:
        load_module_from_file_location(None)
    except TypeError:
        pass


# Generated at 2022-06-12 09:47:55.414760
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = Path(__file__).parent / "data" / "fake_module.py"

    module = load_module_from_file_location(
        location
    )

    assert module.__name__ == "fake_module"
    assert module.some_var == "some_val"

# Generated at 2022-06-12 09:47:55.913091
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass



# Generated at 2022-06-12 09:48:00.747112
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # f = load_module_from_file_location(
    #     "tests.test_helpers.test_load_module_from_file_location",
    #     "tests/test_helpers.py",
    # )
    f = load_module_from_file_location(
        (Path(__file__).parent / "test_load_module_from_file_location.py").resolve(),  # noqa
        # "tests/test_helpers.py",
    )
    assert f.foo == 42
    assert f.bar == "answer"