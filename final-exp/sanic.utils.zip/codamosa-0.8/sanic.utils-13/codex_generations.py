

# Generated at 2022-06-12 09:38:06.776849
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("NO") is False
    assert str_to_bool("0") is False

    with pytest.raises(ValueError):
        str_to_bool("hello")



# Generated at 2022-06-12 09:38:11.823415
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from os import environ, path
    from unittest.mock import patch
    from tempfile import mkstemp
    from re import compile as re_compile

    from sanic import Sanic

    RE_FILE_ERA = re_compile(r"^\d{4}_[0-1][0-9]_[0-3][0-9]_[0-2][0-9]_[0-5][0-9]")

    def check_config(config_name, config_dict, config_era_string):
        assert config_name == config_dict["LOG_CONFIG"]["LOGGERS"]["test_logger"]

        assert config_name == config_dict["TEST_1"]
        assert config_name == config_dict["TEST_2"]
        assert config

# Generated at 2022-06-12 09:38:19.451534
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("Y") == True
    assert str_to_bool("YeS") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("True") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("False") == False
    assert str_to_bool("off") == False
    assert str_to_bool("dalek") == False



# Generated at 2022-06-12 09:38:28.024645
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test if location contains any environment variables in format ${some_env_var}.
    #    And test if these variables exists in environment.
    os_environ["SOME_ENV_VAR"] = "some_env_value"
    temp_module = load_module_from_file_location(
        "/some/path/${SOME_ENV_VAR}/some_module_name.py",
    )
    assert temp_module.__name__ == "some_module_name"

    # B) Test if location is of a bytes type.
    temp_module = load_module_from_file_location(
        b"/some/path/some_module_name.py",
    )
    assert temp_module.__name__ == "some_module_name"

    # C) Test if location is of a

# Generated at 2022-06-12 09:38:39.074966
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test string parameter
    with tempfile.NamedTemporaryFile(suffix=".py") as config_file:
        config_file.write(b'some_var = "some_value"')
        config_file.flush()
        some_module = load_module_from_file_location(config_file.name)
        assert some_module.__dict__.get("some_var") == "some_value"

    # Test bytes parameter
    with tempfile.NamedTemporaryFile(suffix=".py") as config_file:
        config_file.write(b'some_var = "some_value"')
        config_file.flush()
        some_module = load_module_from_file_location(
            config_file.name.encode("utf8")
        )
        assert some_module.__

# Generated at 2022-06-12 09:38:46.343735
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("on")
    assert str_to_bool("yEs")
    assert str_to_bool("True")
    assert str_to_bool("enable")
    assert str_to_bool("1")

    assert not str_to_bool("f")
    assert not str_to_bool("off")
    assert not str_to_bool("n")
    assert not str_to_bool("False")
    assert not str_to_bool("disable")
    assert not str_to_bool("0")

    try:
        str_to_bool("")
        assert False, "Empty string check failed"
    except ValueError:
        pass


# Generated at 2022-06-12 09:38:56.765736
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("YeP") is True
    assert str_to_bool("YUP") is True
    assert str_to_bool("YUP") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("ReAllY_TrUE") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("nope") is False
    assert str_to_bool("f") is False

# Generated at 2022-06-12 09:39:02.617596
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    os_environ["SANIC_ENV_VAR"] = "some_value"
    module = load_module_from_file_location(  # noqa
        "sanic/config.py", __file__, __package__
    )
    assert module.TEST is True
    assert module.TEST_WITH_ENV_VAR is "some_value"
    os_environ.pop("SANIC_ENV_VAR")

# Generated at 2022-06-12 09:39:06.124804
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module_name = "some_module"
    module_location = os.path.join(os.path.dirname(__file__), module_name + ".py")
    module = load_module_from_file_location(module_location)
    assert module.__name__ == module_name



# Generated at 2022-06-12 09:39:15.441558
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test A)
    # Create pretend enviroment variable
    os_environ["fake_env_var"] = "fake_env_var_val"

    # Prepare location with enviroment variable in format ${fake_env_var}.
    location_with_env_var = "location_with_env_var_${fake_env_var}"

    # Try load module and check that it's location was
    # successfully substituted with enviroment variable value.
    m = load_module_from_file_location(location_with_env_var)
    assert m.__file__ == "location_with_env_var_fake_env_var_val"

    # Test B)
    location_without_env_var = "location_without_env_var"

    # Try load module and check that it's location was
    #

# Generated at 2022-06-12 09:39:25.353997
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from os import getcwd  # noqa
    from pprint import pformat  # noqa

    from pytest import raises  # noqa
    from tempfile import NamedTemporaryFile  # noqa

    from sanic import Sanic  # noqa

    cwd = getcwd()

    # Do not let the function to get environment variables from
    # actual environment space.
    environ = {"some_env_var": "some_value"}
    environ.update(os_environ)
    os_environ.clear()
    os_environ.update(environ)

    with NamedTemporaryFile(mode="w+") as temp_config_file:
        temp_config_file_path = Path(temp_config_file.name)

        # Add some content to temp config file.
        temp_config

# Generated at 2022-06-12 09:39:27.725107
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    __location__ = Path(__file__).parent
    configuration = load_module_from_file_location(__location__ / "test_config.py")
    assert configuration.__file__ == str(__location__ / "test_config.py")

# Generated at 2022-06-12 09:39:37.328557
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 1: Test if function try to load module from path,
    #         and module is valid python file.
    assert load_module_from_file_location("/tmp/__init__.py")
    assert load_module_from_file_location("/tmp/__init__.py").__name__ == "__init__"

    # Test 2: Test if function try to load module from path,
    #         and module is valid python file.
    assert load_module_from_file_location("/tmp/__init__.py")
    assert load_module_from_file_location("/tmp/__init__.py").__name__ == "__init__"

    # Test 3: Test if function try to load module from path with env var.

# Generated at 2022-06-12 09:39:46.110286
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from sanic import Sanic
    from sanic.config import Config

    # Test 1
    app = Sanic("my_app")
    database_url = "test://test:test@test/test"
    database_config = load_module_from_file_location(database_url)
    assert isinstance(database_config, dict)
    database_url_value = database_config["DATABASE_URL"]
    assert database_url_value == database_url

    # Test 2
    app.config.from_object("tests.test_config.test_dummy")
    app.config.from_object("tests.test_config.test_dummy")
    expected_config = app.config.copy()
    app.config.from_object("tests.test_config.test_dummy")

# Generated at 2022-06-12 09:39:52.267111
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Prepare the environment.
    os_environ["env_var_1"] = "env_var_1_val"
    os_environ["env_var_2"] = "env_var_2_val"
    os_environ["env_var_3"] = "env_var_3_val"


# Generated at 2022-06-12 09:40:00.981774
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic_envconfig.config import BaseConfig, ConfigType

    os_environ["SOME_ENV_VAR"] = "SOME_ENV_VAR_VALUE"

    config_module = load_module_from_file_location(
        "sanic_envconfig.tests.load_module_from_file_location_test",
        Path(__file__).parent / "load_module_from_file_location_test.py",
    )

    assert config_module.TEST_VAR == "TEST_VAR"
    assert config_module.TEST_VAR_WITH_ENV_VAR == "SOME_ENV_VAR_VALUE"
    assert isinstance(config_module.some_config, BaseConfig)
    assert config_module.some_config.var_1 == 1


# Generated at 2022-06-12 09:40:09.208894
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    def assert_load(location):
        result = load_module_from_file_location(location)

        assert not result.__file__.endswith(".pyc")
        assert isinstance(result, types.ModuleType)

    # A) Tests with file path.
    # 1) path is Path object
    assert_load(Path("./tests/test_module.py"))

    # 2) path is string
    assert_load("./tests/test_module.py")

    # 3) path is string with $VARIABLES
    assert_load("./tests/$MY_MODULE.py")
    assert_load("./tests/$MODULE_NAME.py")

    # B) Tests with package name.
    # 1) package name is string
    assert_load("sanic.server")

    # C

# Generated at 2022-06-12 09:40:15.623022
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ, pathsep
    from collections import namedtuple
    from tempfile import NamedTemporaryFile

    from sanic.exceptions import PyFileError
    from pytest import raises

    environ["PATH"] = (
        environ["PWD"] + pathsep + environ["PATH"]
    )  # Add test directory to env variable PATH.
    environ["TEXT"] = "New Text"
    environ["NUMBER"] = "12345"
    environ["PYTHON_FILE"] = "tests/config_files/config1.py"

    with NamedTemporaryFile(suffix=".py") as temp_py:
        temp_py.write(
            b"""
            TEXT="Old Text"
            NUMBER=54321
        """
        )
        temp_py.flush()
   

# Generated at 2022-06-12 09:40:24.892295
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import os
    import pytest
    from types import ModuleType

    # default_location points to directory that contains this file
    default_location = os.path.dirname(__file__)


# Generated at 2022-06-12 09:40:32.320068
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    test_env = os.environ.copy()
    test_env["TEST_ENV_VAR"] = "test_env_var_value"

    # Check errors
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "/some/path/${TEST_ENV_VAR}/${NOT_DEFINED_ENV_VAR}",
            "/some/path/${TEST_ENV_VAR}",
            "/some/path/${TEST_ENV_VAR}/${NOT_DEFINED_ENV_VAR}",
            env=test_env,
        )
    with pytest.raises(LoadFileException):
        load_module_from_file_location("$", env=test_env)
   

# Generated at 2022-06-12 09:40:38.624517
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def mock_env_vars():
        os_environ["some_env_var"] = "/some/path/to/module"

    mock_env_vars()

    module_name = "some_module_name"
    location = "./tests/resources/some_module.py"
    module = load_module_from_file_location(location)

    assert module.__name__ == module_name
    assert module.SOME_CONSTANT == 1

# Generated at 2022-06-12 09:40:47.116185
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import random
    import shutil
    import tempfile

    file_contents = f"""
    RANDOM = {random.randint(0, 10000)}
    """


# Generated at 2022-06-12 09:40:55.356111
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """To run unittests you need to install development dependencies:

    pip install -r requirements.txt
    """

    import pytest

    def test_str_to_bool():
        assert str_to_bool("True") is True
        assert str_to_bool("true") is True
        assert str_to_bool("TrUe") is True
        with pytest.raises(ValueError) as _value_error:
            str_to_bool("True_")
        assert str(_value_error.value) == "Invalid truth value True_"

        assert str_to_bool("False") is False
        assert str_to_bool("false") is False
        assert str_to_bool("FalsE") is False

# Generated at 2022-06-12 09:41:04.486257
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test if function returns loaded module.
    def test_return_loaded_module():
        location = (
            Path(__file__).parent / "test_load_module_from_file_location"
        )
        module = load_module_from_file_location(location / "some.py")
        assert module.some_variable == 12345

    # Test if environment variables in location are correctly replaced.
    def test_env_vars_in_location():
        location = "/test/test/${TEST_VAR}/test_test.py"
        os_environ["TEST_VAR"] = "some_test_var"
        module = load_module_from_file_location(location)
        assert module.another_variable == "some_test_var"

# Generated at 2022-06-12 09:41:13.794955
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    _file = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "config.py"
    )
    _config_module = load_module_from_file_location(_file)
    assert _config_module.some_config_value_1 == "test"
    assert _config_module.some_config_value_2 == "test"
    os_environ["SOME_ENV_VAR"] = "undefined"
    _config_module = load_module_from_file_location(
        "/${SOME_ENV_VAR}/config.py"
    )
    assert _config_module.some_config_value_1 == "test"
    assert _config_module.some_config_value_2 == "test"

# Generated at 2022-06-12 09:41:23.192552
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic.exceptions import LoadFileException
    import pytest

    location = "./sanic/examples/hello.py"
    file_not_exist_location = "./sanic/examples/file_not_exist.py"
    file_not_exist_location_dir = "./sanic/examples/file_not_exist"
    env_var_not_exist_location = "./sanic/examples/${env_var_not_exist}.py"
    env_var_not_exist_location_dir = "./sanic/examples/${env_var_not_exist}"
    env_var_location = "./sanic/examples/${env_var}.py"

    # Test module from file
    module_from_file = load_module_from_file_location(location)


# Generated at 2022-06-12 09:41:29.347001
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    location = "/some/path/${SOME_ENV_VAR}"
    os_environ["SOME_ENV_VAR"] = "some_env_var"
    location_post_env_change = "/some/path/some_env_var"

    def test_module(location):
        m = load_module_from_file_location(location)
        assert m.attr_from_module == "some_attr_from_module"
        assert m.attr_from_file == "some_attr_from_file"
        assert m.attr_from_env == "some_attr_from_env"

    test_module(location)
    test_module(location_post_env_change)

    os_environ["SOME_ENV_VAR"] = "some_env_var"

# Generated at 2022-06-12 09:41:39.400107
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Load some_module_name module from file "/some/path/some_module_file.py".
    #
    # Normally it would be impossible due to security restrictions in Python,
    # but we use a workaround described in:
    # http://stackoverflow.com/questions/67631/how-to-import-a-module-given-the-full-path
    location = "tests/test_configs/some_module_file.py"
    some_module = load_module_from_file_location(location)

    assert (
        "some_module_name" == some_module.__name__
    )  # Tests if some_module_name.__name__ = "some_module_name".
    assert (
        location == some_module.__file__
    )  # Tests if some_module_name.__

# Generated at 2022-06-12 09:41:44.545686
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_path = "some/path/${some_env_var}/some.py"
    os_environ["some_env_var"] = "some_value"
    module = load_module_from_file_location(file_path)
    assert module.__file__ == "some/path/some_value/some.py"
    assert module.some_variable == "some_value"

# Generated at 2022-06-12 09:41:45.949693
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(
        "sanic.exceptions"
    ) == sanic.exceptions

# Generated at 2022-06-12 09:41:59.380409
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 1. Test raise PyFileError if file not exists.
    with pytest.raises(PyFileError) as err:
        load_module_from_file_location(
            "/home/some-user/some/path/some_module_name.py"
        )
    assert str(err.value).startswith("/home/some-user/some/path/some_module_name.py")

    # 2. Test raise LoadFileException if environment var not defined.
    with pytest.raises(LoadFileException) as err:
        load_module_from_file_location(
            "some_module_name", "/home/${SOME_ENV_VAR}/some_module_name.py"
        )

# Generated at 2022-06-12 09:42:08.781532
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 1. Create temporary file, which will be imported.
    temp_file = Path("./test_config.py").resolve()

    with open(temp_file, "w") as file:
        file.write("TEST = 'test'\n")
        file.write("TEST2 = 'test2'\n")

    # 2. Check if it is imported properly.
    module = load_module_from_file_location(temp_file)
    assert module.TEST == "test"
    assert module.TEST2 == "test2"
    assert module.__file__ == str(temp_file)

    # 3. Check if environment variables are imported properly.
    os_environ["TEMP_FILE"] = str(temp_file)


# Generated at 2022-06-12 09:42:16.572572
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location("/some/path/${some_env_var}")
        == import_string("/some/path/${some_env_var}")
    )

    assert (
        load_module_from_file_location("/some/path/some_module_name")
        == import_string("/some/path/some_module_name")
    )

    assert (
        load_module_from_file_location("/some/path/some_module_name.py")
        == import_string("/some/path/some_module_name")
    )

# Generated at 2022-06-12 09:42:22.500908
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Returns a dict of function parameters,
    which should lead to different type of assertions.

    Example:

        @pytest.mark.parametrize(
            "some_param",
            test_load_module_from_file_location()
        )
        def test_something(some_param):
            with pytest.raises(Exception):
                load_module_from_file_location(some_param)

    """

    # In python3.6 you can import
    # the following function using
    # ``exec(open(__file__).read())``.
    # # In python 3.6 you can use:
    # #     exec(open("load_module_from_file_location.py").read())
    # def load_module_from_file_location(
    #     location: Union[bytes, str, Path

# Generated at 2022-06-12 09:42:31.680179
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from types import ModuleType
    from os import environ
    from shutil import rmtree

    assert isinstance(load_module_from_file_location("os"), ModuleType)
    assert isinstance(load_module_from_file_location("os.path"), ModuleType)

    with NamedTemporaryFile(mode="w+") as config_file:
        config_file.write("CONFIG_VAR = 'config_var'")
        config_file.seek(0)
        assert load_module_from_file_location(config_file.name).CONFIG_VAR == (
            "config_var"
        )


# Generated at 2022-06-12 09:42:41.162814
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    f = os.path.join("tests", "test_project_sanic", "test_config.py")
    module = load_module_from_file_location(f)
    assert "test_config" == module.__name__

    f = os.path.join("tests", "test_project_sanic", "test_config.py")
    module = load_module_from_file_location(f)
    assert "test_config" == module.__name__

    f = Path(os.path.join("tests", "test_project_sanic", "test_config.py"))
    module = load_module_from_file_location(f)
    assert "test_config" == module.__name__


# Generated at 2022-06-12 09:42:48.263036
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import sys

    file_path = "test_data/test.py"
    sys.modules["test"] = load_module_from_file_location(file_path)
    assert sys.modules["test"].__file__ == str(file_path)  # nosec

    # Check for exception for non existing file case
    with pytest.raises(IOError, match="Unable to load configuration"):
        load_module_from_file_location("test_data/test_1.py")

    # Check for ValueError exception for non-str and non-bytes file path case
    with pytest.raises(ValueError, match="Invalid truth value"):
        load_module_from_file_location(True)

    # Check for ValueError exception for non-str and non-bytes file path case

# Generated at 2022-06-12 09:42:56.460536
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import mkdtemp
    from os import makedirs, environ, mkdir
    from os.path import join, dirname
    from shutil import rmtree
    from contextlib import contextmanager

    @contextmanager
    def temp_dir():
        old_dir = os.getcwd()
        temp_dir = mkdtemp()
        os.chdir(temp_dir)
        try:
            yield
        finally:
            os.chdir(old_dir)
            rmtree(temp_dir)


# Generated at 2022-06-12 09:43:04.544347
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    def _check_if_module_is_loaded_correctly(module_name):
        assert module_name == "test"
        assert isinstance(module_name, str) is True
        assert isinstance(module_name, int) is False

    module = load_module_from_file_location(
        "tests.test_helpers.test_load_module_from_file_location_test"
    )
    _check_if_module_is_loaded_correctly(module.__name__)

    module = load_module_from_file_location(
        "test_load_module_from_file_location_test",
        __file__[: __file__.rfind("/")],
    )
    _check_if_module_is_loaded_correctly(module.__name__)

    module = load

# Generated at 2022-06-12 09:43:12.384189
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from unittest.mock import patch, call

    some_module_name = "some_module_name"
    some_module_path = "some/path/some_module_path"
    some_module_file = "some_module_file.py"
    some_module_location = (
        some_module_path + "/" + some_module_file
    )  # /some/path/some_module_path/some_module_file.py
    some_module_env_var_name = "some_env_var"
    some_module_env_var_val = "some_env_var_val"
    some_module_encoding = "utf8"


# Generated at 2022-06-12 09:43:23.120223
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test if load_module_from_file_location works normally."""
    import unittest  # Import unittest here,
    # becouse pytest uses it in its own test suite.

    _os_environ = dict(os_environ)

    class TestLoadModuleFromFileLocation(unittest.TestCase):
        """Unit test for function load_module_from_file_location."""


# Generated at 2022-06-12 09:43:30.006484
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Tests function load_module_from_file_location."""

    # Testing that it works as expected when it is called without parameters
    # corresponding to location parameter.
    some_module = load_module_from_file_location("some_module_name")
    assert (
        some_module.__name__ == "some_module_name"
    ), f"Expected some_module.__name__ == 'some_module_name', got {some_module.__name__}"

    # Testing that it works as expected when it is called with location
    # parameters.
    some_module = load_module_from_file_location("some_module_name", "./")

# Generated at 2022-06-12 09:43:38.738866
# Unit test for function load_module_from_file_location

# Generated at 2022-06-12 09:43:44.233827
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # ToDo:
    #   test that function raises exception
    #   IOError("Unable to load configuration %s" % str(location))
    #   when location is not of a string or bytes type
    #   and when location is not of a Path type.
    import_string("sanic.log")
    load_module_from_file_location(
        Path("sanic", "log.py").absolute(), "utf8"
    )

# Generated at 2022-06-12 09:43:53.935833
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test if load_module_from_file_location raises error
    # if some environment variable are not set.
    os_environ["test"] = "test"
    s = "/some/path/${test}"
    load_module_from_file_location(s)

    # Some environment variables are not set.
    with pytest.raises(LoadFileException) as e:
        load_module_from_file_location("/some/path/${test}/foo/${foo}")
    e.match("The following environment variables are not set: foo")

    # Test if load_module_from_file_location raises error
    # if location is of a bytes type
    with pytest.raises(TypeError) as e:
        load_module_from_file_location(b"/some/path/${test}")


# Generated at 2022-06-12 09:44:02.047632
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # type: ignore
    """Test if load_module_from_file_location works as expected."""

    # 1. Check if load_module_from_file_location works with normal path.
    # assert load_module_from_file_location("test_module") is test_module

    # 2. Check if load_module_from_file_location raises error when file does
    #    not exists.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("some/path/to/nowhere")

    # 3. Check if load_module_from_file_location raises error when
    #    environment variable does not exists.

# Generated at 2022-06-12 09:44:11.213737
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Patch os.environ
    os_environ_original = dict(os_environ)
    os_environ["some_env_var"] = "some_env_value"

    # test with string
    path = Path(__file__).parent / "test_load_module.py"
    path_str = str(path)
    module = load_module_from_file_location(path_str)
    assert module.CONST == "test"

    # test with Path
    module = load_module_from_file_location(path)
    assert module.CONST == "test"

    # test with bytes
    path_bytes = path_str.encode("utf8")
    module = load_module_from_file_location(path_bytes, encoding="utf8")
    assert module.CONST == "test"

# Generated at 2022-06-12 09:44:15.816515
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    tmpfile_name = "tmp_file.py"
    tmpfile_content = """
        foo = "bar"
        baz = "btb"
        """

    import os
    import sys
    import shutil

    tmpfile = open(tmpfile_name, "w+")
    tmpfile.write(tmpfile_content)
    tmpfile.close()

    loaded_module1 = load_module_from_file_location(tmpfile_name)
    assert loaded_module1.foo == "bar"
    assert loaded_module1.baz == "btb"
    loaded_module2 = load_module_from_file_location(Path(tmpfile_name))
    assert loaded_module2.foo == "bar"
    assert loaded_module2.baz == "btb"

    # Tests for for environment variables


# Generated at 2022-06-12 09:44:22.274705
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Testing load_module_from_file_location function."""

    # Testing with path which contains environment variable.
    # This is not actually unit test, due the fact that
    # needs to have environment variable "PWD" set to
    # some path. In my view it is rather functional test,
    # but ok let's treat it as unit test.
    assert (
        load_module_from_file_location(
            "/${PWD}/tests/test_parsers.py", "utf-8"
        )
        is not None
    )

    # Testing with path which doesn't contain environment variable.
    assert (
        load_module_from_file_location(
            __file__, encoding="utf-8"
        )
        is not None
    )

    # Testing with wrong path.

# Generated at 2022-06-12 09:44:32.229191
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import types
    import tempfile
    from os import environ as os_environ

    # Since this function is doing import,
    # we have to remove any previously imported modules with the same name.
    for name in ["config_for_test", "custom_test_module"]:
        if name in sys.modules:
            del sys.modules[name]

    # Test with a simple string.
    mod_str = "config_for_test"
    assert sys.modules.get(mod_str) is None
    assert load_module_from_file_location(mod_str) is not None
    assert sys.modules.get(mod_str) is not None

    # Test with file path to a python module.

# Generated at 2022-06-12 09:44:43.201081
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from tempfile import NamedTemporaryFile
    from unittest import TestCase

    from sanic.helpers import load_module_from_file_location

    class TestLoadModuleFromFileLocation(TestCase):
        def test_should_load_module_from_string_path(self):
            with self.subTest("Should load module from string path"):
                with NamedTemporaryFile("w") as tmp_file:
                    tmp_file.write("something = 'something'")
                    tmp_file.seek(0)  # this needed because tmp_file
                    # was moved to the end of the file after f.write()
                    module = load_module_from_file_location(tmp_file.name)
                    assert module.something == "something"


# Generated at 2022-06-12 09:44:50.944556
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["env_var"] = "/some/path"
    assert load_module_from_file_location(
        "some_module_name", "/some/path/${env_var}/other/path"
    ) is not None
    assert load_module_from_file_location(
        "some_module_name", "/some/path/other/path"
    ) is not None
    assert load_module_from_file_location(
        b"some_module_name", "/some/path/${env_var}/other/path"
    ) is not None
    assert load_module_from_file_location(
        "some_module_name",
        "/some/path/${env_var_that_does_not_exist}/other/path",
    ) is None  # noqa


# Generated at 2022-06-12 09:44:58.857214
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test that load_module_from_file_location loads correct module."""
    from module_for_testing.test_file_config import file_config
    from module_for_testing.test_file_config import (
        file_config as file_config_module,
    )

    module = load_module_from_file_location(
        "module_for_testing.test_file_config.file_config"
    )

    assert module == file_config
    assert module == file_config_module
    assert module.__file__ == file_config.__file__
    assert module.__file__ == file_config_module.__file__
    assert module.some_key == "some_value"

# Generated at 2022-06-12 09:45:05.508578
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa

    #
    # Testing with bytes and environment variables
    #

    import pytest

    # A) Successfully created module without environment variables.
    module = load_module_from_file_location(
        location=b"some_module_name",
        origin="some_module_name.py",
        loader=None,
        submodule_search_locations=None,
    )
    assert isinstance(module, types.ModuleType)
    assert module.__name__ == "some_module_name"
    assert module.__file__ == "some_module_name.py"

    # B) Environment variable substitution.

# Generated at 2022-06-12 09:45:13.408801
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Tests load_module_from_file_location function."""
    location = "${PWD}/tests/module_to_load.py"
    module = load_module_from_file_location(location)

    assert isinstance(module, types.ModuleType)
    assert module.opt_a
    assert not module.opt_b

    location = "${PWD}/tests/module_to_load_1.py"
    module = load_module_from_file_location(location)

    assert isinstance(module, types.ModuleType)
    assert module.opt_a
    assert not module.opt_b

# Generated at 2022-06-12 09:45:22.675293
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import chdir, system
    from shutil import rmtree
    from tempfile import mkdtemp
    from sys import path as sys_path

    def create_file(
        dir_path, file_name, content="", encoding="utf-8", ext="py", full=False
    ):
        """Creates file with some content in dir_path."""
        with open(dir_path + "/" + file_name + "." + ext, "w") as f:
            f.write(content)
        if full:
            return dir_path + "/" + file_name + "." + ext
        else:
            return file_name

    # Temporary directory creation.

    tmp_dir = mkdtemp()
    tmp = tmp_dir.rsplit("/", 1)[-1]

# Generated at 2022-06-12 09:45:27.286952
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    file_path: Union[str, Path] = Path(
        "tests/integration/test_config.py"
    ).resolve()

    module = load_module_from_file_location(file_path)

    assert hasattr(module, "test_key")
    assert module.test_key == 1



# Generated at 2022-06-12 09:45:34.285346
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    file_content = """
    SOME_INT_VAR = 42
    SOME_STR_VAR = "Sanic"
    SOME_DICT_VAR = {"key": "val"}
    """

    # Preparation
    tmp = tempfile.NamedTemporaryFile(delete=False)
    tmp.write(file_content.encode())
    tmp.close()
    os.environ["TEST_LOAD_MODULE_INT_ENV_VAR"] = "42"
    os.environ["TEST_LOAD_MODULE_STR_ENV_VAR"] = "Sanic"
    os.environ["TEST_LOAD_MODULE_DICT_ENV_VAR"] = "{'key': 'val'}"

    # Test if __name__ is set properly
   

# Generated at 2022-06-12 09:45:43.467901
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    # Test 1:
    # if nothing was passed
    load_module_from_file_location()

    # Test 2:
    # check if it is a py file
    load_module_from_file_location(
        Path(__file__).parent / "fixtures" / "config_file.py"
    )

    # Test 3:
    # Check if you can use real environment variables in location path.
    # We will inject ${FAKE_ENV_VAR} in fixture config_file location.
    # Then set this variable in environment and check if it was set correctly.
    # Afterwards we will clear variable from environ.
    # 1) Create fixture to test this case.

# Generated at 2022-06-12 09:45:48.021585
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location("foo")
    except ValueError:
        pass
    else:
        raise RuntimeError("Should raise ValueError...")

    try:
        load_module_from_file_location("foo.json")
    except PyFileError:
        pass
    else:
        raise RuntimeError("Should raise PyFileError...")



# Generated at 2022-06-12 09:45:59.365911
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "tests/load_module_from_file_location_test"
    module = load_module_from_file_location(location)
    assert module.STRING == "some string"
    assert module.INT == 1
    assert module.BOOL == True

    # Check if the environment variables are correctly substituted in the test
    # module file.
    location = "tests/load_module_from_file_location_test_env"
    module = load_module_from_file_location(location)
    assert module.STRING == "some string"
    assert module.INT == 1
    assert module.BOOL == True

    os_environ["DUMMY_ENV_VAR"] = "dummy_value"
    location = "tests/load_module_from_file_location_test_env"
    module = load

# Generated at 2022-06-12 09:46:05.485481
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    location = "tests/config/config.py"
    config_module = load_module_from_file_location(location)
    assert config_module.TEST_VAR == str(location)
    assert config_module.TEST_VAR_FROM_ENV_VAR == "~/test"
    assert config_module.TEST_VAR_FROM_UNSET_ENV_VAR == "~/test"
    assert config_module.TEST_VAR_FROM_SAME_ENV_VAR == "~/test"

    location = Path(location)
    config_module = load_module_from_file_location(location)
    assert config_module.TEST_VAR == str(location)
    assert config_module.TEST_VAR_FROM_ENV

# Generated at 2022-06-12 09:46:14.403090
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["test_load_module_from_file_location"] = "test_value"

    # A
    test_module_a_contents = """
    class TestClassA:
        pass
    """
    test_module_a = types.ModuleType("test_module_a")
    test_module_a.__file__ = "test_module_a"
    exec(compile(test_module_a_contents, test_module_a.__file__, "exec"), test_module_a.__dict__)  # noqa
    assert load_module_from_file_location("test_module_a", test_module_a_contents) == test_module_a  # noqa

# Generated at 2022-06-12 09:46:23.738835
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    tmp_dir = Path(tempfile.mkdtemp())

# Generated at 2022-06-12 09:46:30.448903
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from yarl import URL

    # Test that it imports given module.
    test_module = load_module_from_file_location(
        "sanic.request", "sanic/request.py"
    )
    assert test_module.__name__ == "sanic.request"
    assert isinstance(test_module.HTTPMessage, type)
    assert test_module.HTTPMessage.__name__ == "HTTPMessage"
    assert test_module.Request.__name__ == "Request"
    assert isinstance(test_module.Request, type)

    # Test that it can import example module from examples/examples
    # that uses asyncio and async/await.

# Generated at 2022-06-12 09:46:39.770700
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    class Sentry:
        def __init__(self):
            self.error_logged = False
            self.logging_exception = None

        def captureException(self, exception):
            self.error_logged = True
            self.logging_exception = exception

    # Test A)
    # Test B)
    os_environ["SOME_ENV_VAR"] = "test"
    location = "./tests/test_app.py"
    sentry = Sentry()
    assert not sentry.error_logged
    assert load_module_from_file_location(location)
    assert not sentry.error_logged
    os_environ.pop("SOME_ENV_VAR")
    assert load_module_from_file_location(location, sentry=sentry)

# Generated at 2022-06-12 09:46:49.617233
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D102
    import unittest

    from os import environ
    from os.path import join as path_join
    from sys import version_info

    import copy

    location = "${SANIC_TEST_LOCATION}/sanic/config/sanic.py"
    assert load_module_from_file_location(location).__name__ == "config.sanic"

    location = path_join(
        "${SANIC_TEST_LOCATION}/sanic",
        "config",
        "sanic.py" if version_info >= (3, 6) else "sanic.txt",  # type: ignore
    )
    assert load_module_from_file_location(location).__name__ == "config.sanic"

    # A) Check if location contains any environment variables
    #    in

# Generated at 2022-06-12 09:46:59.204603
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Expected behaviour.
    import tempfile
    import os

    os.environ["test_1"] = "test_1"
    os.environ["test_2"] = "test_2"
    with tempfile.TemporaryDirectory() as tmpdirname:
        path = Path(tmpdirname)
        with open(path / "test_file.py", "w") as test_file:
            test_file.write(
                f"test_var = 'test_var_1{os_environ['test_1']}test_var_2{os_environ['test_2']}test_var_3'"
            )

        loaded_module = load_module_from_file_location(
            f"{path}/test_file.py"
        )
        assert loaded_module.test_var

# Generated at 2022-06-12 09:47:09.585967
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_string_success = load_module_from_file_location(
        "importlib.util",
    )
    import_string_fail = None
    try:
        load_module_from_file_location(
            "some_not_existing_package",
        )
    except ValueError:
        import_string_fail = True

    assert import_string_success
    assert import_string_fail

    os_environ["test_env_var"] = "/test"
    module_success = load_module_from_file_location(
        "/test/${test_env_var}/test.py"
    )

    module_fail_not_exist = None

# Generated at 2022-06-12 09:47:11.866678
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(
        "test_utils.test_load_module_from_file_location"
    )

# Generated at 2022-06-12 09:47:21.277274
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import getcwd, environ as os_environ
    from tempfile import TemporaryDirectory

    # Open temporary directory
    with TemporaryDirectory() as tmp_dir:
        # Create file for importing
        file_path = Path(tmp_dir) / "test.py"
        file_path.write_text("config = 'Hello world'")

        # Assert that file was imported okay
        module = load_module_from_file_location(file_path)
        assert module.config == "Hello world"

        # Test ommiting py suffix
        module = load_module_from_file_location(file_path.parent / "test")
        assert module.config == "Hello world"

        # Test setting name to module
        module = load_module_from_file_location(file_path, name="foo")

# Generated at 2022-06-12 09:47:30.243005
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_file = Path(__file__).parent / "test_load_module_from_file_location.py"
    assert load_module_from_file_location(test_file).loaded_module_name == "test_load_module_from_file_location"
    assert load_module_from_file_location(bytes(test_file, "utf-8")).loaded_module_name == "test_load_module_from_file_location"
    assert load_module_from_file_location(str(test_file)).loaded_module_name == "test_load_module_from_file_location"
    assert load_module_from_file_location(__name__).loaded_module_name == "test_load_module_from_file_location"

# Generated at 2022-06-12 09:47:38.197845
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Sets environment variables and tests them against location strings"""

    os_environ["some_env_var"] = "/some/path/some_env_var"
    os_environ["foo"] = "/some/path/foo"

    assert (
        load_module_from_file_location("/some/path/some_env_var")
        == load_module_from_file_location("/some/path/${some_env_var}")
    )
    assert (
        load_module_from_file_location("/some/path/foo")
        == load_module_from_file_location("/some/path/${foo}")
    )

    del os_environ["some_env_var"]
    del os_environ["foo"]



# Generated at 2022-06-12 09:47:47.764855
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import random
    import string
    import sys

    from os import environ

    import pytest

    from sanic.helpers import load_module_from_file_location

    sys.path.append("tests/")

# Generated at 2022-06-12 09:47:55.414219
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def foo_module(n):
        return n ** 3

    Path("foo").mkdir()
    with open("foo/foo.py", "w") as f:
        f.write("foo_module = lambda n: n ** 3")

    assert foo_module(2) == load_module_from_file_location("foo/foo.py").foo_module(2)  # noqa
    assert foo_module(2) == load_module_from_file_location("foo.foo").foo_module(2)  # noqa
    assert foo_module(2) == load_module_from_file_location("foo/foo").foo_module(2)  # noqa



# Generated at 2022-06-12 09:48:01.631534
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # 1. When module is available in PYTHONPATH
    assert load_module_from_file_location("some_python_module")

    # 2. When module is available in current location
    assert load_module_from_file_location(
        "examples.app_dir.run_app:app"
    )
    assert load_module_from_file_location(
        "examples.app_dir.run_app.app"
    )

    # 3. When module is available in location with environment
    #    variables in it.
    os_environ["TEMP_LOCATION"] = "examples/app_dir"
    assert load_module_from_file_location(
        "run_app:app", "/some/${TEMP_LOCATION}/"
    )
    assert load_module_