

# Generated at 2022-06-12 09:38:06.366384
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile

    # Create temporary file with contents
    #   some_var = "some_value"
    with tempfile.NamedTemporaryFile(suffix=".py") as f:
        f.file.write(b"some_var = 'some_value'")
        f.file.seek(0)

        # Load module from file location.
        module = load_module_from_file_location(f.name)

        # Check that module has some_var set to "some_value"
        assert module.some_var == "some_value"

    # Create temporary file with contents
    #   some_var = "some_value"

# Generated at 2022-06-12 09:38:08.218461
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic.types import ModuleType

    loaded_mod = load_module_from_file_location(
        "tests/test_server_config.py"
    )
    assert isinstance(loaded_mod, ModuleType)



# Generated at 2022-06-12 09:38:18.172116
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover
    def test_py_file():
        some_module = load_module_from_file_location(
            "test_py_file", "tests/config_for_tests/some_module.py"
        )
        assert some_module.some_dict == {"key": 1, "other_key": 2}
        assert some_module.some_var == 1
        assert some_module.some_func() == 10

    def test_py_file_as_path_with_env_vars():
        some_module = load_module_from_file_location(
            Path("tests/config_for_tests/${DIR_NAME}/some_module.py")
        )
        assert some_module.some_dict == {"key": 1, "other_key": 2}

# Generated at 2022-06-12 09:38:26.242326
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("on")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("1")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("off")
    assert not str_to_bool("false")
    assert not str_to_bool("0")
    assert not str_to_bool("disable")

# Generated at 2022-06-12 09:38:34.030427
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function."""
    import os

    tmp_dir = Path(os.getenv("TMPDIR", "/tmp")) / "sanic_test_module"
    if tmp_dir.exists():
        tmp_dir.rmdir()
    tmp_dir.mkdir()

    file_dir = tmp_dir / "file.py"

# Generated at 2022-06-12 09:38:42.733561
# Unit test for function str_to_bool
def test_str_to_bool():
    """DocString from test_str_to_bool"""

    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

    with pytest.raises(ValueError):
        str_to_bool("")
    with pytest.raises(ValueError):
        str_to_bool("1")
    with pytest.raises(ValueError):
        str_to_bool("0")

# Generated at 2022-06-12 09:38:51.872149
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("n") is False
    assert str_to_bool("f") is False
    assert str_to_bool("0") is False

    assert str_to_bool("y") is True
    assert str_to_bool("t") is True
    assert str_to_bool("1") is True

    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("true") is True

    assert str_to_bool("no") is False

# Generated at 2022-06-12 09:38:57.596449
# Unit test for function str_to_bool
def test_str_to_bool():
    for tr in ["y", "yes", "yep", "yup", "t", "true", "on", "enable", "enabled", "1"]:
        assert str_to_bool(tr) == True
    for fls in ["n", "no", "f", "false", "off", "disable", "disabled", "0"]:
        assert str_to_bool(fls) == False

# Generated at 2022-06-12 09:39:06.463596
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")      == True
    assert str_to_bool("yes")     == True
    assert str_to_bool("yep")     == True
    assert str_to_bool("yup")     == True
    assert str_to_bool("t")       == True
    assert str_to_bool("true")    == True
    assert str_to_bool("on")      == True
    assert str_to_bool("enable")  == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1")       == True
    
    assert str_to_bool("n")       == False
    assert str_to_bool("no")      == False
    assert str_to_bool("f")       == False
    assert str_to_bool("false")   == False


# Generated at 2022-06-12 09:39:15.727297
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test for function load_module_from_file_location
    """
    from sanic import Sanic as sanic
    from os import environ as os_environ
    from shutil import rmtree
    import uuid
    app = sanic()
    temp_folder_for_test_configs = "/tmp/test_configs_" + uuid.uuid4().hex
    os_environ["TEST_ENV_VAR"] = f"{temp_folder_for_test_configs}/test_config.py"

# Generated at 2022-06-12 09:39:25.798172
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from os import environ as os_environ
    from string import ascii_letters as letters
    from tempfile import TemporaryDirectory

    import_string = load_module_from_file_location

    def run_test_for_ext(ext: str):
        with TemporaryDirectory() as dir_str:
            with open(dir_str + "/a_config" + ext, "w") as f:
                f.write("a=1")

            a_module = import_string(dir_str + "/a_config" + ext)

            assert hasattr(a_module, "__file__")
            assert hasattr(a_module, "a")
            assert a_module.a == 1
            assert a_module.__file__ == dir_str + "/a_config" + ext


# Generated at 2022-06-12 09:39:35.114440
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    def _test_with_file_object(_module):
        assert isinstance(
            load_module_from_file_location(_module), types.ModuleType
        )
        assert hasattr(load_module_from_file_location(_module), "foo")
        assert load_module_from_file_location(_module).foo == "bar"

        with pytest.raises(TypeError):
            load_module_from_file_location(object())

    with NamedTemporaryFile() as config_file:
        config_file.write(b"foo = 'bar'")
        config_file.flush()

        # A) Check case when file is provided as file path
        _test_with_file_object(config_file.name)

        # B) Check case when file is provided as Path object

# Generated at 2022-06-12 09:39:43.376158
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from re import search
    from pathlib import Path

    from tests.test_utils import full_path

    def _assert(package_path: Path, file_name: str, module_name: str):
        module = load_module_from_file_location(
            full_path(package_path, file_name)
        )
        assert search(module_name, module.__file__)

    _assert(Path("tests/test_utils"), "module_for_load_file_location.py",
            "module_for_load_file_location")
    _assert(Path("tests/test_utils"), "module_for_load_file_location",
            "module_for_load_file_location")


load_module = load_module_from_file_location

# Generated at 2022-06-12 09:39:50.836986
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """This function is here only for unit testing purposes.

    It is executed only in pytest with '-s' (or '--capture=no')
    option to enable stdout and stderr.

    Usage:
        python -m pytest tests/helpers/test_load_module_from_file_location.py \
            -s

            or

        python -m pytest tests/helpers/test_load_module_from_file_location.py \
            --capture=no
    """

    # Raise LoadFileException if environment variables are not set.
    os.environ["UNDEFINED_ENV_VAR"] = ""
    del os.environ["UNDEFINED_ENV_VAR"]

# Generated at 2022-06-12 09:39:57.115947
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    module = types.ModuleType("config")
    module.__file__ = __file__
    with open(__file__) as config_file:
        exec(
            compile(config_file.read(), __file__, "exec"),
            module.__dict__,
        )
    assert load_module_from_file_location(__file__) == module
    assert load_module_from_file_location(__file__.encode()) == module

# Generated at 2022-06-12 09:40:04.496698
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import shutil
    import tempfile
    import types

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os.environ["some_env_var"] = "some_path"
    assert (
        load_module_from_file_location(
            "/some/path/${some_env_var}/test_module.py"
        )
    ) is not None

    # B) Check these variables exists in environment.
    assert load_module_from_file_location(
        "/some/path/${not_defined_env_var}/test_module.py"
    ) is None

    del os.environ["some_env_var"]

    # C) Substitute them in location.
    test_dir = tempfile.mkdtemp()


# Generated at 2022-06-12 09:40:12.718479
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import unittest

    class Test(unittest.TestCase):
        def test_load_module_from_file_location(self):
            import os

            os.environ["test"] = "some_test_value"
            module = load_module_from_file_location(
                "sanic.test_config.simple_config",
                "/some/path/to/config/${test}",
            )
            self.assertTrue(module.test_val)

        def test_load_module_from_file_location_with_absent_env_var(self):
            import os


# Generated at 2022-06-12 09:40:21.726430
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # Testing with a file path
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = Path(tmp_dir)
        tmp_file = tmp_path / "some_module.py"

        tmp_file.touch()
        tmp_file.write_text(
            """
            some_var = [1, 2, 3]
            """
        )

        module = load_module_from_file_location(tmp_file)
        assert module.some_var == [1, 2, 3]

    # Testing with str and bytes type
    with tempfile.TemporaryDirectory() as tmp_dir:
        module_name = "some_module"
        tmp_path = Path(tmp_dir)
        tmp_file = tmp_path / f"{module_name}.py"

        tmp

# Generated at 2022-06-12 09:40:30.083069
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    from unittest.mock import patch

    patch_env = patch.dict(
        os_environ, {"HOME": "/home/user", "test_var": "test_value"}
    )
    with patch_env:
        assert load_module_from_file_location("./test_config.py")

        assert load_module_from_file_location("./test_config.pyc")

        assert load_module_from_file_location(
            Path("./test_config.py").resolve()
        )

        assert load_module_from_file_location(
            "${HOME}/test_config.py", resolve=False
        )


# Generated at 2022-06-12 09:40:32.643637
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = Path(__file__).parent / "components" / "config_test.py"
    module = load_module_from_file_location(path)
    print(module.test_param_1)
    print(module.test_param_2)
    print(module.test_param_3)

# Generated at 2022-06-12 09:40:42.166946
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from .test_utils import temp_directory, temp_directory_with_files

    # A) Set up test data

# Generated at 2022-06-12 09:40:52.437525
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Simple string
    assert load_module_from_file_location(__file__).__file__ == __file__

    # Environment variables
    os_environ["TEST_CONF_VAR_1"] = "1"
    assert load_module_from_file_location(
        Path(os_environ["TEST_CONF_VAR_1"])
    ).__file__ == __file__
    del os_environ["TEST_CONF_VAR_1"]

    # Path
    assert load_module_from_file_location(Path(__file__)).__file__ == __file__

    # Import string
    import_string_module = load_module_from_file_location(
        "sanic.helpers"
    ).import_string
    import_string_module == import_string




# Generated at 2022-06-12 09:41:02.524872
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_ENV_VAR"] = "test_env_var"


# Generated at 2022-06-12 09:41:11.573872
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests function load_module_from_file_location

    A) Successful test of load_module_from_file_location
        with string location.
    B) Successful test of load_module_from_file_location
        with pathlib.Path location.
    """
    import_path = importlib.util.import_module("pathlib")

    # A) Successful test of load_module_from_file_location
    #    with string location.

# Generated at 2022-06-12 09:41:17.690012
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    curr_dir = Path(__file__).parent.absolute()

    # Check that module is loaded correctly by module path.
    module = load_module_from_file_location(
        "testing_code.testing_conf.testing_conf_1"
    )
    assert module.CONFIG_VARIABLE == "value"

    # Check that module is loaded correctly by file path.
    module = load_module_from_file_location(
        curr_dir / "testing_conf" / "testing_conf_1.py"
    )
    assert module.CONFIG_VARIABLE == "value"

    # Check that same file_paths raise the same error.

# Generated at 2022-06-12 09:41:26.427100
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # Create a temporary directory
    test_dir = tempfile.TemporaryDirectory()

    # Create a temporary file
    temp_file = os.path.join(test_dir.name, "example.py")
    with open(temp_file, "w") as f_w:
        f_w.write("# Hello world!")

    # Unit test
    module = load_module_from_file_location(temp_file)
    assert module.__file__ == temp_file  # noqa: WPS421

    # Delete the temp file
    os.remove(temp_file)

    # Check if you can use str_to_bool
    assert str_to_bool("true") is True

    test_dir.cleanup()

# Generated at 2022-06-12 09:41:32.148147
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test 1: Path is of string type
    # 1A) Path contains no environment variables
    # Test 1A:
    # Test 1A-1: Path is valid
    path = "path/should/contain/some_file.py"
    loaded_module = load_module_from_file_location(path)
    assert loaded_module.__name__ == "some_file"

    # Test 1A-2: Path is invalid
    with pytest.raises(IOError):
        path = "path/should/contain/some_file.py_INVALID"
        load_module_from_file_location(path)

    # 1B) Path contains environment variables
    # Test 1B-1:
    # Test 1A-1: Path is valid
    # Define environment variables
    os_environ["path"]

# Generated at 2022-06-12 09:41:41.975467
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # testing loading from env variable
    os_environ["SOME_VAR"] = "/some/path"
    module = load_module_from_file_location(
        "${SOME_VAR}/${SOME_FILE}", "SOME_FILE"
    )
    assert module.__file__ == "/some/path/SOME_FILE"
    del os_environ["SOME_VAR"]
    del module

    # testing loading from string var
    module = load_module_from_file_location("/some/path/python_file", "python_file")
    assert module.__file__ == "/some/path/python_file"
    del module

    # testing loading with bytes var

# Generated at 2022-06-12 09:41:50.212286
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from types import ModuleType

    # We have to use temp folder because we don't want to change anything in
    # the repository.
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        # Create configuration file with this content:
        # some_var = "some_value"
        # some_func = lambda: print("test")
        with open(temp_dir + "/test_config.py", "w") as test_config:
            test_config.write("some_var = \"some_value\"\n")
            test_config.write("some_func = lambda: print(\"test\")\n")

        # Test 1) Is the module that we load is actually a module?
        test_module = load_module_from_file_location(
            temp_dir + "/test_config"
        )


# Generated at 2022-06-12 09:41:59.824110
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ, pathsep, popen
    from tempfile import TemporaryDirectory

    from sanic.exceptions import LoadFileException

    # Mock configuration file
    with TemporaryDirectory() as tmpdirname:
        with open(f"{tmpdirname}/some_name.py", "w") as f:
            f.write(
                "class SomeClass:\n"
                "    some_var = 1\n"
                "\n"
                "some_var = 1\n"
            )

        ######################################################################
        # Load module
        ######################################################################

        # a) Successfully load module.
        module = load_module_from_file_location(f"{tmpdirname}/some_name.py")
        assert module.some_var == 1

# Generated at 2022-06-12 09:42:07.593399
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # TODO: create some config for special env var and test it's working
    assert str_to_bool(os_environ["SANIC_TEST_CONF"]) == load_module_from_file_location(
        "${SANIC_TEST_CONF}", Path(__file__).parent / "conf.py"
    ).TEST_CONF

# Generated at 2022-06-12 09:42:17.191935
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    some_test_var_1 = "oops"
    some_test_var_2 = "something"
    some_test_var_3 = "works"

    os.environ["UNITTEST_FILE_LOCATION_VAR3"] = some_test_var_3
    os.environ["UNITTEST_FILE_LOCATION_VAR2"] = some_test_var_2


# Generated at 2022-06-12 09:42:26.398667
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if function raise IOError when
    #    given string parameter is not file path.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("", "some_module_name")

    # B) Check if function raise LoadFileException
    #    when environment variable is not defined.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("", "${is_not_defined_env_var}")

    # C) Check if function raise LoadFileException
    #    when file does not exists.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("", "path/to/file/that/does/not/exists")

# Generated at 2022-06-12 09:42:36.111048
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    config_file_path = Path(__file__).parent.joinpath("test_config.py")

    # A) Should raise FileNotFoundError if file was not found.
    with pytest.raises(FileNotFoundError):
        load_module_from_file_location(
            Path(__file__).parent.joinpath("not_found.py")
        )

    # B) Should raise LoadFileException if environment variable was not found
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            config_file_path.as_posix().replace(
                config_file_path.name,
                "${not_found_env_var}/" + config_file_path.name,
            )
        )

    # C) Should work as expected with properly supplied

# Generated at 2022-06-12 09:42:43.316793
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys

    PY_FILES = {}
    PY_FILES["my_package/my_module.py"] = """
    from my_package import my_inner_module
    import my_package.my_inner_module_2
    from . import my_inner_module_3
    from .my_inner_module_4 import some_var

    mod_var = 2

    def mod_func():
        return some_var

    class MyClass:
        class_var = 42
        def class_func(self):
            return 42
    """

# Generated at 2022-06-12 09:42:50.125183
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import shutil
    import tempfile
    from sys import path as sys_path

    # Create temporary folder.
    temp_dir = tempfile.mkdtemp()
    print(temp_dir)

    # Prepare module file in this folder and store it's path.
    module_file = Path(temp_dir, "some_module.py")
    module_file.touch()
    module_file_path = str(module_file.resolve())

    # Prepare environment variables.
    some_env_var = "SOME_ENV_VAR"
    os_environ[some_env_var] = "/some/path"

    # Prepare config file in this folder and store it's path.
    config_file_name = "some_config_file"
    config_file_extension = "cfg"
    config

# Generated at 2022-06-12 09:42:58.108249
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def create_file_with(file_name, file_content):
        with open(file_name, "w") as f:
            f.write(file_content)

    os_environ["TEST_ENV_VAR_1"] = "some_/path/0"
    os_environ["TEST_ENV_VAR_2"] = "some_name_0"
    os_environ["TEST_ENV_VAR_3"] = "some_name_1"
    os_environ["TEST_ENV_VAR_4"] = "some_/path/1"

    create_file_with("temp_file_0.py", "config = 5")
    create_file_with("/some/path/0/temp_file_1.py", "config = 10")
    create

# Generated at 2022-06-12 09:43:02.521071
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit tests for function load_module_from_file_location."""
    from io import StringIO
    import os
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from types import ModuleType

    tmp_dir = TemporaryDirectory(prefix="test_load_module_from_file_location_")

    # A) location is path to a file.
    # A.1) location is a pathlib.Path object.
    tmp_file_path = Path(tmp_dir.name) / "tmp_file.py"
    with tmp_file_path.open("w") as tmp_file:
        tmp_file.write("a = 1")
    assert load_module_from_file_location(tmp_file_path) == tmp_file_path

    # A.2) location is a string (without environment variables).
   

# Generated at 2022-06-12 09:43:08.693884
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover
    from types import ModuleType
    from os import environ
    from pathlib import Path
    from random import randint
    from tempfile import NamedTemporaryFile
    from re import match

    from .helpers import random_string
    from .testing import SanicTestClient
    from sanic import Sanic, response

    # Prepare an enviroment with some set variables
    some_env_vars = {
        "SANIC_ENV": "development",
        "SANIC_LOG_FORMAT": "test_case_%(filename)s_%(name)s_%(levelname)s",
    }
    for key, val in some_env_vars.items():
        environ[key] = val

    # Prepare a test case.

# Generated at 2022-06-12 09:43:15.482387
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    import os
    os.environ["some_env_var"] = "some_value"
    # test case 1 - An exception if file is not found.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("config.py")
    # test case 2 - An exception if file does not contain python code.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("./tests/fixtures/test_config")
    # test case 3 - An exception if file contains invalid python code.
    with pytest.raises(PyFileError):
        load_module_from_file_location("./tests/fixtures/test_config_invalid.py")
    # test case 4 - File without env variables.
    module = load_

# Generated at 2022-06-12 09:43:26.215397
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Check if function raises ValueError with invalid args
    with pytest.raises(ValueError) as excinfo:
        load_module_from_file_location("not_a_path")
    assert (
        str(excinfo.value) == "Invalid truth value not_a_path"
    )

    # Check if function raises LoadFileException in case
    # of missing environment variables
    os_environ["SOME_ENV_VAR"] = "SOME_ENV_VAR_VALUE"
    with pytest.raises(LoadFileException) as excinfo:
        load_module_from_file_location(
            "/some/path/${SOME_ENV_VAR}/${NOT_DEFINED_ENV_VAR}",
            raise_exceptions=True,
        )

# Generated at 2022-06-12 09:43:32.150927
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import asyncio
    
    async def run_test():

        assert (
            load_module_from_file_location("./tests/test_load_module_from_file_location.py")
            .__file__
            == Path("./tests/test_load_module_from_file_location.py").absolute().as_posix()
        )

        assert (
            load_module_from_file_location(
                "./tests/test_load_module_from_file_location.py"
            )
            .__file__
            == Path("./tests/test_load_module_from_file_location.py").absolute().as_posix()
        )


# Generated at 2022-06-12 09:43:40.293877
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["some_env_var"] = "/some/other/path"

    load_module_from_file_location(
        "./test_config.py"
    )  # Should work with relative path
    load_module_from_file_location(
        "/some/path/to/file.py"
    )  # Should work with absolute path
    load_module_from_file_location(
        "/some/path/${some_env_var}/to/file.py"
    )  # Should work with environment variable in path
    load_module_from_file_location(
        Path("/some/path/to/file.py")
    )  # Should work with Path object

    # Should raise LoadFileException  if environment variable
    # in path is not set.

# Generated at 2022-06-12 09:43:49.922628
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit tests for function load_module_from_file_location."""

    # TEST 1: Using not existing file.
    location = "/some/incorrect/file/that/does/not/exists/file.py"
    try:
        load_module_from_file_location(location)
    except Exception as e:
        assert "Unable to load file" in str(e)
        assert e.errno == 2

    # TEST 2: Using module from current directory.
    location = "tic_tac_toe.py"
    tic_tac_toe_module = load_module_from_file_location(location)
    # No error, since import module from current directory
    # was successful.

    # TEST 3: Using module from current package.
    location = "tic_tac_toe"
    tic_

# Generated at 2022-06-12 09:43:58.802306
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_ENV_VAR"] = "/some/path/"
    os_environ["TEST_ENV_VAR_1"] = "some_module_name.py"
    # A) Load module from file that contains environment variable
    #    in format ${some_env_var}.
    #    And the variable is set in environment.
    loaded_module = load_module_from_file_location(
        "some_module_name", "/some/path/${TEST_ENV_VAR}${TEST_ENV_VAR_1}"
    )
    assert loaded_module.__file__ == "/some/path/some_module_name.py"

# Generated at 2022-06-12 09:44:08.387604
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import mkdtemp
    import json
    import os
    import shutil
    from os import environ as os_environ
    from pathlib import Path
    from io import StringIO

    # Test for loading modules
    for module_name in ("json", "__builtin__", "math", "random"):
        assert load_module_from_file_location(
            module_name
        )

    # Test for loading json module as file
    config = {
        "some_val": "some_value",
        "another_val": "another_value",
    }
    config_path = Path(mkdtemp()) / "config.json"

    with open(config_path, "w") as f:
        json.dump(config, f)


# Generated at 2022-06-12 09:44:17.797198
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    class Class:
        pass

    class_instance = Class()

    # Some test values.

# Generated at 2022-06-12 09:44:28.648943
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """This functions test different cases of load_module_from_file_location
    function usage."""

    import sanic.config

    # Test case A - load normal config file.
    module = sanic.config.load_module_from_file_location(
        Path(__file__).resolve().parent / "example_config.py"
    )
    assert module.__dict__["SOME_VARIABLE"] == "example"

    # Test case B - load config file that use environment variables in path.
    module = sanic.config.load_module_from_file_location(
        Path(__file__).resolve().parent / "${SANIC_PYTHON_REPLICATE_TESTS}_config.py"
    )

# Generated at 2022-06-12 09:44:36.402854
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""

    def bash_export_to_python(bash_export):
        """Transforms bash export code to python one."""
        return (
            "import os; "
            + "; ".join(
                [
                    "os.environ['" + var + "']='" + val + "'"
                    for var, val in [
                        bash_export_line.split("=")
                        for bash_export_line in bash_export.split("\n")
                    ]
                    if (var is not None) and (val is not None)
                ]
            )
        )


# Generated at 2022-06-12 09:44:44.670323
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import json

    location = "tests/config_for_testing/config_from_json.json"
    # first load module from location with PyFileError
    with open(location) as config_file:
        config_from_json_data = json.load(config_file)
        assert Config(
            **config_from_json_data
        ) == load_module_from_file_location(
            location
        )
    # then load module from location with LoadFileException
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "tests/config_for_testing/config_from_json_with_env.json"
        )
    # then load module from location with IOError

# Generated at 2022-06-12 09:44:56.764999
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import pytest
    from pathlib import Path

    from sanic.exceptions import LoadFileException, PyFileError

    # Create temporary directory and test file to test with.
    tmp_dir = Path(tempfile.mkdtemp(prefix="test_load_module_from_file_location"))
    test_file = tmp_dir / "t.py"
    test_created_file = test_file.with_suffix(".created.py")
    test_corrupt_file = test_file.with_suffix(".corrupt.py")
    test_file_content = "a = 1\n"
    test_file_syntax_error_content = "a = 1\n" + "a = 2\n"

# Generated at 2022-06-12 09:45:02.010842
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Use module of this file for testing purposes.
    module_from_file_location = load_module_from_file_location(
        "sanic.utils", "sanic/utils.py"
    )

    # Function load_module_from_file_location should return the same
    # module as importlib.import_module.
    assert import_module("sanic.utils") == module_from_file_location

    # Also make sure that it has the same functions.
    assert import_function("sanic.utils", "import_module") == import_module
    assert import_function(
        "sanic.utils", "import_function"
    ) == import_function

# Generated at 2022-06-12 09:45:12.018858
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from tempfile import NamedTemporaryFile
    from unittest import mock
    from os import unlink
    from os.path import basename, dirname

    from sanic.helpers import load_module_from_file_location

    def assert_load_module_from_file_location(
        location,
        expected_name,
        expected_filename,
        expected_package,
        expected_in_module,
    ):
        module = load_module_from_file_location(location)  # noqa

        assert module.__name__ == expected_name
        assert module.__file__ == expected_filename
        assert module.__package__ == expected_package
        assert module.in_module == expected_in_module

    # Case 1: load module from string
    #         module_name = "module_name"

# Generated at 2022-06-12 09:45:21.096354
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Create a environment variables for testing.
    os_environ["TEST_ENV_VAR1"] = "env_var1"
    os_environ["TEST_ENV_VAR2"] = "env_var2"
    os_environ["TEST_ENV_VAR3"] = "env_var3"
    # Create a file for testing.
    test_filename = (
        "test_" + str(random.randrange(0, 10000, 1)) + ".py"
    )  # nosec
    test_file_path = os.getcwd() + "/" + test_filename
    file = open(test_file_path, "w+")
    file.write("a = 1")
    file.close()

    location = "tests/" + test_file_path
    loaded_module

# Generated at 2022-06-12 09:45:30.276417
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location(
            location="./tests/data/some_config.py",
            encoding="utf8",
            is_package=False,
        ).SOME_INT_CONFIG == 42
    )
    assert (
        load_module_from_file_location(
            location="/some/path/some_config.py",
            encoding="utf8",
            is_package=False,
        ).SOME_INT_CONFIG == 42
    )
    assert (
        load_module_from_file_location(
            location=b"/some/path/some_config.py",
            encoding="utf8",
            is_package=False,
        ).SOME_INT_CONFIG == 42
    )

# Generated at 2022-06-12 09:45:39.584809
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys

    # Test 1.
    sys.path.append("some/path/which/does/not/exists")
    module = load_module_from_file_location("input_file_does_not_exists")
    assert module is None

    # Test 2.
    sys.path.append("some/path/which/does/not/exists")
    module = load_module_from_file_location("input_file_does_not_exists")
    assert module is None

    os.environ["variable_in_config"] = "OK"
    module = load_module_from_file_location(
        "tests/test_config_file.py",
        location=os.path.abspath("tests/test_config_file.py"),
    )

# Generated at 2022-06-12 09:45:48.643200
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import shutil
    import tempfile

    # A. Except environment variables
    sys.path.append(
        "/some/path/1"
    )  # prepare environment for import some_py_module
    dir_path = tempfile.mkdtemp()
    TEST_FILE_PATH = dir_path + "/some_py_module.py"
    with open(TEST_FILE_PATH, "w") as file:
        file.write("TEST_VAR = 'test_var'")

    # Don't use assertRaises here to not mess up with exception handling

# Generated at 2022-06-12 09:45:57.582208
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # With env var in location
    os_environ["SOME_ENV_VAR"] = "some_env_var_value"
    some_module = load_module_from_file_location(
        "some_module_name", "${SOME_ENV_VAR}"
    )
    assert some_module.__name__ == "some_module_name"
    module_dir = Path(some_module.__file__).parent
    assert module_dir.name == "some_env_var_value"

    # With path object
    location_path = Path("some_env_var_value")
    some_module = load_module_from_file_location(
        "some_module_name", location_path
    )
    assert some_module.__name__ == "some_module_name"
    module

# Generated at 2022-06-12 09:46:04.426119
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    from os import environ as os_environ
    from os.path import dirname as os_path_dirname
    from os.path import abspath as os_path_abspath
    from os.path import join as os_path_join
    from shutil import rmtree
    from textwrap import dedent as textwrap_dedent

    module_name = "test_module"

    def create_test_module(file_path):
        with open(file_path, "w") as fp:
            fp.write(textwrap_dedent(f"""\
                test_module_var = "Test module var"
                test_module_dict = {{
                    "Test module key": "Test module value"
                }}
            """))


# Generated at 2022-06-12 09:46:13.180022
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from pathlib import Path
    from tempfile import TemporaryDirectory

    import pytest

    from sanic import Sanic
    from sanic.exceptions import LoadFileException

    from utils import str_to_bool

    # Create a temporary directory
    tmp_dir = Path(TemporaryDirectory().name)

    conf_file = tmp_dir / "config.py"
    conf_file.touch()
    conf_file.write_text('host="0.0.0.0"\nport="8000"\n')

    env_file = tmp_dir / "env.py"
    env_file.touch()
    env_file.write_text('env_var="{}"'.format(tmp_dir))


# Generated at 2022-06-12 09:46:24.942958
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest

    from copy import deepcopy
    from os import environ as os_environ
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from sanic.exceptions import LoadFileException

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.

    with TemporaryDirectory() as temp_dir:
        temp_dir_path = Path(temp_dir)
        assert os.path.exists(temp_dir_path) is True

        # Set environment variable
        os_environ["SANIC_ENV_VAR"] = "CONTENT_OF_ENV_VAR"

        # Create python file

# Generated at 2022-06-12 09:46:34.713593
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Let's create an artificial configuration file in memory.
    cfg_fd, cfg_path = tempfile.mkstemp()
    os.close(cfg_fd)
    cfg_dir, cfg_base = os.path.split(cfg_path)

    # Let's fill the configuration file with some content.
    with open(cfg_path, "w+") as cfg_file:
        cfg_file.write("some_var = 'some_val'\n")

    os_environ["env_var"] = cfg_dir

    # Let's check if we can load it with different load_module_from_file_location
    # calls.
    module = load_module_from_file_location(cfg_path)
    assert module.__file__ == cfg_path

# Generated at 2022-06-12 09:46:41.374105
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import tempfile

    # 1. Environment variables test
    config_path = "config.py"
    env_var_name = "SOME_ENV_VAR"
    env_var_val = "SOME_VAL"

# Generated at 2022-06-12 09:46:52.103110
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from pytest import raises

    from sanic.exceptions import LoadFileException

    def ping():
        return "pong"

    def check_if_module_contains_callables(module_):
        assert callable(module_.pong)
        assert callable(module_.ping)

    # Check module import with custom function import
    mod1 = load_module_from_file_location(ping, "ping")
    assert callable(mod1.ping)

    # Check module import with absolute path to module file
    mod2 = load_module_from_file_location(__file__)
    check_if_module_contains_callables(mod2)

    # Check module import with relative path to module file

# Generated at 2022-06-12 09:47:00.226643
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: no cover
    import os

    some_var = "some_var"
    os.environ["some_env_var"] = some_var

    def test_module_function():
        return "module_function"

    test_module = types.ModuleType("test_module")
    test_module.test_module_function = test_module_function
    test_module.some_var = some_var

    test_include_contains_some_var = """
    from .test_module import some_var
    from .test_module import test_module_function
    """

    test_include_unable_to_import_some_var = """
    from .test_module import some_var_not_exists
    from .test_module import test_module_function
    """


# Generated at 2022-06-12 09:47:10.099525
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover
    from pytest import raises

    module = load_module_from_file_location(
        "tests/test_fixtures/module.py"
    )
    assert module.variable == "module variable"

    module = load_module_from_file_location(
        "tests/test_fixtures/module"
    )
    assert module.variable == "module variable"

    with raises(LoadFileException, match=r"^The following environment variables are not set: variable_not_exist$"):
        module = load_module_from_file_location(
            "${variable_not_exist}/tests/test_fixtures/module.py"
        )


# Generated at 2022-06-12 09:47:19.473557
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    os_environ["test_env_var"] = "test_env_var_value"

    # Try to load made-up file.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("/made/up/file")

    # It should raise IOError if it's unable to load a module.
    with pytest.raises(IOError):
        load_module_from_file_location("made_up_module")

    # Check if environment variables are resolved correctly.
    test_file_location = "/made/up/file/${test_env_var}"
    with patch(
        "sanic_envconfig.utils.spec_from_file_location",
        autospec=True,
    ) as mock_spec_from_file_location:
        load_module_from_file

# Generated at 2022-06-12 09:47:28.680569
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # PASS
    # Load module from normal path.
    assert isinstance(
        load_module_from_file_location(Path(__file__)), types.ModuleType
    )
    # Load module from bytes path.
    assert isinstance(
        load_module_from_file_location(Path(__file__).absolute().as_bytes()),
        types.ModuleType,
    )
    # Load module from path with environment variables.
    os_environ["a"] = "1"
    os_environ["b"] = "2"
    assert isinstance(
        load_module_from_file_location(Path(__file__).absolute() + "${a}/${b}"),
        types.ModuleType,
    )

    # FAIL
    # Raise IOError if location parameter is not Path and does

# Generated at 2022-06-12 09:47:37.500647
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import sys

    # 1. Successfully load module from file in current directory.
    sys.modules.pop("test_module_1", None)
    assert sys.modules.get("test_module_1") is None
    module_1 = load_module_from_file_location("test_module_1")
    assert sys.modules.get("test_module_1") == module_1
    assert module_1.value == 1
    assert module_1.value2 == 2

    # 2. Successfully load module from file in specified directory.
    sys.modules.pop("test_module_2", None)
    assert sys.modules.get("test_module_2") is None

# Generated at 2022-06-12 09:47:47.341680
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    def try_load_module_from_file_location():
        return load_module_from_file_location(
            location=temp_dir / file_name, *args, **kwargs
        )

    temp_dir = Path(tempfile.mkdtemp(prefix="sanic_test"))
    file_name = "test_config.py"
    file_path = temp_dir / file_name
    file_path.touch()

    # A) Check if simple location of a file works.
    args = ()
    kwargs = {}
    config = try_load_module_from_file_location()
    assert config.__name__ == "test_config"
    assert config.__file__ == str(file_path)
    assert config.__package__ is None
    assert config

# Generated at 2022-06-12 09:47:54.220128
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SOME_ENV_VAR"] = "gig"
    assert load_module_from_file_location(
        "sanic.helpers",
        "/home/gig/dev/Projects/Sanic/sanic/helpers.py",
    )



# Generated at 2022-06-12 09:48:00.474815
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # pylint: disable=R0914
    # Note: too-many-locals

    # Mock enviroment variables in os.environ.
    os_environ["some_env_var"] = "some_env_var_value"

    # Create a module with some functions in a file.
    module_path = Path("sanic/utils/module.py")
    module_path.parent.mkdir(parents=True, exist_ok=True)  # create directory