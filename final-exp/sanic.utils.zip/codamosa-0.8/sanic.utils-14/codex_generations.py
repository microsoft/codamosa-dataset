

# Generated at 2022-06-12 09:38:02.502908
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    for val, result in {
        "y": True,
        "yes": True,
        "yep": True,
        "yup": True,
        "t": True,
        "true": True,
        "on": True,
        "enable": True,
        "enabled": True,
        "1": True,
        "n": False,
        "no": False,
        "f": False,
        "false": False,
        "off": False,
        "disable": False,
        "disabled": False,
        "0": False,
    }.items():
        assert str_to_bool(val) == result


# Generated at 2022-06-12 09:38:11.019227
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("Y") is True
    assert str_to_bool("NO") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("FALSE") is False
    assert str_to_bool("false") is False
    assert str_to_bool("n") is False
    assert str_to_bool("True") is True
    assert str_to_bool("False") is False
    assert str_to_bool("T") is True
    assert str_to_bool("F") is False
    assert str_to_bool("t") is True
    assert str_to_bool("on") is True
    assert str_to_bool("OFF") is False

# Generated at 2022-06-12 09:38:12.369910
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

# Generated at 2022-06-12 09:38:21.296997
# Unit test for function str_to_bool
def test_str_to_bool():

    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("1") is True
    assert str_to_bool("on") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("no") is False
    assert str_to_bool("n") is False
    assert str_to_bool("0") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False


# Generated at 2022-06-12 09:38:27.764879
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test OK
    module = load_module_from_file_location(__file__)
    assert module is not None

    # Test error
    try:
        load_module_from_file_location("not_existent_file")
        assert False
    except IOError:
        pass

    # Test env variables
    os_environ["SANIC_ENV_VAR"] = "1"
    load_module_from_file_location("${SANIC_ENV_VAR}")

    try:
        load_module_from_file_location("${SANIC_ENV_VAR_2}")
        assert False
    except LoadFileException:
        pass

# Generated at 2022-06-12 09:38:39.073830
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True

    assert str_to_bool("false") == False
    assert str_to_bool("False") == False
    assert str_to_bool("FALSE") == False
    assert str_to_bool("f") == False
    assert str_to_bool("F") == False

    assert str_to_bool("1") == True
    assert str_to_bool("0") == False

    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("yes") == True

# Generated at 2022-06-12 09:38:46.370060
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ

    from pytest import raises

    from .test_utils import TEST_DIR, SanicTestClient

    # Test string inputs with and without environment variables
    with open(TEST_DIR / "test_server.py") as test_server:

        # Test string with path
        test_module = load_module_from_file_location(
            TEST_DIR / "test_server.py"
        )
        assert test_module.__file__ == str(TEST_DIR / "test_server.py")

        # Test string with environment variables
        environ["test_server"] = "test_server.py"
        test_module = load_module_from_file_location(
            f"{TEST_DIR}/${{test_server}}"
        )
        assert test_module.__file__ == str

# Generated at 2022-06-12 09:38:56.766473
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test if function load_module_from_file_location works properly."""
    import os

    # A) Prepare some test file in tmp directory.
    tmp_dir = os.path.join(os.getcwd(), "test_tmp")
    os.mkdir(tmp_dir)
    tmp_file = os.path.join(tmp_dir, "test_file.py")
    with open(tmp_file, "w") as f:
        f.write("x = 2")

    # B) Prepare environment variables.
    os.environ["TEST_ENV_VAR"] = "test_tmp"

    # C) Import module and assert if the import was done correctly.
    module = load_module_from_file_location(tmp_file)
    assert hasattr(module, "x")
    assert module.x

# Generated at 2022-06-12 09:39:05.946513
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    assert load_module_from_file_location("os") is os
    assert load_module_from_file_location("sys") is sys
    assert load_module_from_file_location(str, "str") is str
    assert load_module_from_file_location(bool, "bool") is bool

    with tempfile.TemporaryDirectory() as tmp_dir:
        file_location = tmp_dir + "/HERE_IS_SOME_CONFIG.py"
        with open(file_location, "w") as f:
            f.write("SOME_VAR = 5")
        assert (
            load_module_from_file_location(file_location).SOME_VAR == 5
        ), "Dynamically loaded module does not contain SOME_VAR"


# Generated at 2022-06-12 09:39:15.176909
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test suite that checks if load_module_from_file_location() works as it should.
    """
    # Test case 1: file located in a relative path
    os_environ["path1"] = "tmp"
    module = load_module_from_file_location(
        location="${path1}/config.py",
        substitude_env_vars=True,
    )
    assert module.__file__ == "tmp/config.py"

    # Test case 2: file located in an absolute path
    os_environ["path2"] = "/tmp"
    module = load_module_from_file_location(
        location="${path2}/config.py",
        substitude_env_vars=True,
    )
    assert module.__file__ == "/tmp/config.py"

   

# Generated at 2022-06-12 09:39:25.124769
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Basic usage test
    module = load_module_from_file_location(Path(__file__).parent / "test_file.py")
    assert module.__name__ == "test_file"
    assert isinstance(module.test_var, float)
    assert module.test_var == 1.0

    # We should be able to import python versions up to py37
    module = load_module_from_file_location(
        Path(__file__).parent / "test_file_py37_compatible.py"
    )
    assert module.__name__ == "test_file_py37_compatible"
    assert isinstance(module.test_var, float)
    assert module.test_var == 1.0

    # Test that non existing files
    with pytest.raises(IOError):
        load_module_

# Generated at 2022-06-12 09:39:33.268395
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Unit test for function load_module_from_file_location
    """

    def check_loading(module_location, is_successful):
        if is_successful:
            assert load_module_from_file_location(module_location)
        else:
            with pytest.raises(
                IOError, match=r"Unable to load configuration file"
            ):
                load_module_from_file_location(module_location)

    module_location = os.path.abspath(__file__)
    check_loading(module_location, True)

    module_location = "/root/sanic_helper_tests_file.py"
    check_loading(module_location, False)

    module_location = os.path.dirname(os.path.abspath(__file__))
    check_

# Generated at 2022-06-12 09:39:42.896208
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import sys
    import os

    os_environ["some_env_var"] = "/some/path"
    abs_path = os.path.dirname(__file__)
    sys.path.append(abs_path)

    # Try to load module without ".py" extension.
    assert load_module_from_file_location("test_load_config")

    # Try to load module with ".py" extension.
    config = load_module_from_file_location("test_load_config.py")
    assert config.CONFIG_VAR is True

    # Try to load module with ".py" extension and relative path.
    config = load_module_from_file_location("test_load_config.py", ".")
    assert config.CONFIG_VAR is True

    # Try to load module with ".

# Generated at 2022-06-12 09:39:50.496386
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile
    import os
    import shutil
    import sys

    from os.path import dirname, abspath, join

    from importlib.machinery import SourceFileLoader
    from os import environ as os_environ

    from sanic.helpers import load_module_from_file_location

    # file for path testing
    cur_dir = dirname(abspath(__file__))
    cur_loc = os.getcwd()
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_loc = tmp_dir.name
    tmp_dir_loc_py = join(tmp_dir_loc, "test1.py")
    tmp_dir_loc_pyc = join(tmp_dir_loc, "test1.pyc")
    tmp_dir_loc_no

# Generated at 2022-06-12 09:39:54.837605
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # we need our environment variable to work
    os_environ["SOME_KEY"] = "some_value"

    some_module = load_module_from_file_location(
        "tests.test_functions.test_helpers"
    )

    assert some_module.foo() == "bar"

# Generated at 2022-06-12 09:40:02.709837
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    env_var_name = "test_load_module_from_file_location_env_var"
    env_var_value = "/some/path"

    def remove_test_env_var():
        """Removes environment variable used in this test."""
        if env_var_name in os_environ:
            del os_environ[env_var_name]

    # A) Prepare environment for testing.
    remove_test_env_var()

    # B) Run tests.

# Generated at 2022-06-12 09:40:11.104623
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile

    def _create_temp_py_file(contents):  # noqa
        f = tempfile.NamedTemporaryFile(suffix=".py", delete=False)
        f.write(contents.encode())
        f.close()
        return f

    _ = _create_temp_py_file(
        "class JustAClass: pass\ndef just_a_function(): pass"
    )
    origin_module = load_module_from_file_location(_.name)
    assert hasattr(origin_module, "JustAClass")
    assert hasattr(origin_module, "just_a_function")

    # Test if it handles environment variables in file paths
    temp_file_name = _.name
    _.close()


# Generated at 2022-06-12 09:40:17.187962
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # A) Test loading file with not existing env var in path.
    file_path_with_env_var = Path(
        "/path/to/some/file/${NOT_EXISTING_ENV_VAR}"
    )
    with pytest.raises(LoadFileException):
        load_module_from_file_location(file_path_with_env_var)

    # B) Test loading file with existing env var in path.
    os_environ["NOT_EXISTING_ENV_VAR"] = Path.home()
    file_path_with_env_var = Path(
        "/path/to/some/file/${NOT_EXISTING_ENV_VAR}"
    )
    load_module_from_file_location(file_path_with_env_var)
    del os_en

# Generated at 2022-06-12 09:40:26.241710
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    cwd = Path(__file__).parent

    # We need test file in current directory
    # to make string and pathlib.Path both valid ways
    # to get to this file location.
    with open("load_module_from_file_location.py", "w") as f:
        f.write("a = 42")

    # This is os.environ that all tests will run with.
    os_environ["A"] = "42"  # type: ignore

    def assert_load_module_from_file_location_succeeded(
        *args, **kwargs
    ):  # type: (...) -> None
        assert load_module_from_file_location(*args, **kwargs).a == 42

# Generated at 2022-06-12 09:40:29.753804
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pathlib
    with pathlib.Path("config.py").open("w") as f:
        f.write("VARIABLE=123")
    module = load_module_from_file_location("config.py")
    assert module.VARIABLE == 123
    pathlib.Path("config.py").unlink()

# Generated at 2022-06-12 09:40:37.694193
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    env_var = "TEST_ENV_VAR"
    env_var_value = "TEST_ENV_VAR_VALUE"
    os_environ[env_var] = env_var_value

    # A) Test that module loading ends up with exception in case
    #    location contains any environment variables
    #    in format ${some_env_var}, that not set in environment.
    fake_env_var = "FAKE_ENV_VAR"
    location_with_fake_env_var = f"/some/path/${{{fake_env_var}}}"
    raised_exception = False
    try:
        module_with_fake_env_var = load_module_from_file_location(
            location_with_fake_env_var
        )
    except LoadFileException:
        raised

# Generated at 2022-06-12 09:40:44.873492
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import datetime
    import tempfile
    import pytest
    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(
        prefix="test_load_module_from_file_location_",
        suffix=".py",
        mode="w+t",
        encoding="utf-8",
    )
    tmp_file.write("date = datetime.date.today()")
    tmp_file.seek(0)
    # Load module
    tmp_module = load_module_from_file_location(str(tmp_file.name))
    assert tmp_module.date == datetime.date.today()
    # Cleanup
    tmp_file.close()
    # Check Env Substitution
    os.environ["test"] = "test_value"
    tmp_module = load_

# Generated at 2022-06-12 09:40:52.471470
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # type: ignore
    class SomeClass:
        pass

    some_instance = SomeClass()
    os_environ["some_env_var"] = "/some/path/"
    module = load_module_from_file_location(
        "tests.test_helpers",
        "/some/path/${some_env_var}tests/test_helpers.py"  # type: ignore
    )
    assert module.some_instance == some_instance
    del os_environ["some_env_var"]

# Generated at 2022-06-12 09:41:02.560359
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Load modules from file system, such as include:

        - A module succeed in loading
        - A module fails because of file doesn't exist
        - A module fails because of environment variables setup to load the
            module doesn't exists.
        - A config file (a file with extension different than .py).
        - A config file that throws an exception.
        - A module succeed in loading but result of loading is not a module.
    """
    import sys
    import tempfile

    # A module succeed in loading
    temp_module_succeed = tempfile.NamedTemporaryFile(
        suffix=".py", prefix="test_sanic_helpers_"
    )
    temp_module_succeed.write(
        b"test_file_content = 'this is a test file'"
    )

# Generated at 2022-06-12 09:41:11.613879
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import datetime
    import os
    import sys

    # remove test_module.py file if exists
    os.remove("test_module.py") if os.path.exists("test_module.py") else None

    # create test_module.py file
    with open("test_module.py", "w", encoding="utf8") as some_file:
        some_file.write("test_variable = 123")

    # test_module.py file will be deleted after testing
    test_module = load_module_from_file_location("test_module.py")
    assert test_module.test_variable == 123
    assert test_module.__file__ == "test_module.py"
    assert os.path.exists("test_module.py") == True

    # test_module.py file will be deleted after testing


# Generated at 2022-06-12 09:41:17.745407
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    os.environ["TEST_ENV_VAR"] = "test_env_var_value"
    os.environ["TEST_ENV_VAR_2"] = "test_env_var_2_value"
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = Path(temp_dir.name)

    temp_file_path = temp_dir_path / "temp.py"
    temp_file_path.touch()

    temp_file_path.write_text("test_var = 123")

    module = load_module_from_file_location(temp_file_path)

    assert module.test_var == 123

    temp_file_path = temp_dir_path / "temp_without_extension"
    temp_file_path

# Generated at 2022-06-12 09:41:26.752286
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location(
            "sanic/config/test_config.py"
        ).TEST_CONFIG_VARIABLE
        == "TEST_VALUE"
    )
    assert (
        load_module_from_file_location(
            Path(__file__).absolute().parent
            / "test_config.py"
        ).TEST_CONFIG_VARIABLE
        == "TEST_VALUE"
    )
    assert (
        load_module_from_file_location(
            "/home/travis/sanic/sanic/config/test_config.py"
        ).TEST_CONFIG_VARIABLE
        == "TEST_VALUE"
    )

# Generated at 2022-06-12 09:41:32.371712
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil


# Generated at 2022-06-12 09:41:42.949407
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # Test that it raises LoadFileException
    # if environment variable does not exist.
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            location="${SOME_ENV_VAR}/some/path", encoding="utf8"
        )

    # Test that it returns module.
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Create file
        path = Path(tmpdirname) / "module.py"
        path.write_text(
            'from sanic.response import text\n'
            'def some_function(request):\n'
            '    return text("OK")'
        )

        module = load_module_from_file_location(location=path, encoding="utf8")

# Generated at 2022-06-12 09:41:50.440362
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def run_test(location, env_vars, result_exp_type):
        for env_var, value in env_vars.items():
            os_environ[env_var] = value

        try:
            result = load_module_from_file_location(location)
        except Exception as result:
            result = result
        finally:
            for env_var in env_vars.keys():
                os_environ.pop(env_var)

        assert isinstance(result, result_exp_type) is True

    run_test(
        "some_module_name",
        {"some_env_var": "some_path"},
        module_from_spec,
    )


# Generated at 2022-06-12 09:42:00.853722
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory

    from unittest import TestCase

    from .helpers import create_and_write_to_temp_file

    class TestLoadModuleFromFileLocation(TestCase):
        def test_load_module_from_file_location(self):
            with TemporaryDirectory() as tmpdir:
                location = tmpdir + "/some_temp_config.py"

                some_content = "\n".join(
                    (
                        "from os import environ",
                        "SOME_CONFIG_KEY = environ['SOME_CONFIG_KEY']",
                    )
                )
                create_and_write_to_temp_file(location, some_content)

                os_environ["SOME_CONFIG_KEY"] = "Some_value"
                config = load_module_from_file_location(location)

# Generated at 2022-06-12 09:42:10.717621
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import pytest

    with tempfile.NamedTemporaryFile(mode="w+") as tmp_file:
        file_path = tmp_file.name

        def get_module_attr(attr_name: str) -> Any:
            return load_module_from_file_location(file_path).__dict__[attr_name]

        def get_content():
            return open(file_path).read()

        def set_content(content: str):
            open(file_path, "w+").write(content)

        # Testing for correct work with file
        set_content("test_value = 42")

        assert get_module_attr("test_value") == 42

        os.remove(file_path)

        # Testing for correct work with dir

# Generated at 2022-06-12 09:42:19.299208
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import unittest
    import tempfile

    class Test(unittest.TestCase):
        """
        We need this class because we want to check importlib
        internals for importing modules.

        https://docs.python.org/3/library/importlib.html#module-importlib
        """

        def test_loading_modules(self):
            dir_name = tempfile.mkdtemp()
            Path(dir_name).joinpath("test_module.py").touch()

            module = load_module_from_file_location(
                Path(dir_name).joinpath("test_module.py")
            )
            self.assertTrue(isinstance(module, types.ModuleType))


# Generated at 2022-06-12 09:42:29.876232
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # 1) Try to load module providing path and name of the module.
    some_module_path = Path(__file__).parent.parent / "tests" / "modules"
    some_module = load_module_from_file_location(
        "some_module", str(some_module_path / "some_module")
    )
    assert some_module.__name__ == "some_module"
    assert some_module.__file__ == str(some_module_path / "some_module.py")

    # 2) Try to load module that does not exist, then IOError should be raised.
    try:
        load_module_from_file_location(
            "some_non_existing_module", str(some_module_path)
        )
    except IOError:
        assert True

    # 3) Try to load

# Generated at 2022-06-12 09:42:30.390478
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass



# Generated at 2022-06-12 09:42:40.245417
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_data = dict(
        test_no_env_var=dict(
            location="tests/config_files/",
            name="test_no_env_var",
            expected_added_to_module_dict=dict(
                TEST_FILE_NAME="test_no_env_var"
            ),
        ),
        test_with_env_var=dict(
            location="${CONFIG_PATH}test_with_env_var",
            name="test_with_env_var",
            expected_added_to_module_dict=dict(
                TEST_FILE_NAME="test_with_env_var"
            ),
        ),
    )

    os_environ["CONFIG_PATH"] = "tests/config_files/"

    for test_case in test_data.values():
        test_name = test

# Generated at 2022-06-12 09:42:45.171078
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Test for load_module_from_file_location function."""
    import sys
    from unittest.mock import patch
    from os import environ
    from pathlib import Path
    from types import ModuleType

    # Prepare enviroment
    environ.update({"ONE": "1", "TWO": "2", "THREE": "3"})

    # Prepare location and test_file_name
    location = "${TWO}/${ONE}/${THREE}/test_file.py"
    test_file_name = f"{environ['TWO']}/{environ['ONE']}/{environ['THREE']}/test_file.py"

    # Prepare test_file
    Path(test_file_name).touch()

    # Perform test
    test_module

# Generated at 2022-06-12 09:42:49.786582
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test that load_module_from_file_location function
       loads configuration from file.
    """
    from os import remove
    from tempfile import NamedTemporaryFile
    import yaml

    try:
        with NamedTemporaryFile("w+", suffix=".yaml") as yaml_file:
            yaml_file.write("DEBUG: true\n")
            yaml_file.flush()
            config = load_module_from_file_location(yaml_file.name)
    except Exception:
        raise

    assert config.DEBUG is True

# Generated at 2022-06-12 09:42:58.072345
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""
    test_env_var_name = "MY_TEST_VAR"
    test_env_var_val = "my_test_val"
    os_environ[test_env_var_name] = test_env_var_val
    test_config = (
        "import json\n"
        'config = json.loads("{\\"test_var\\": \\"test_val\\"}")'
    )
    test_config_location = "test_config.py"
    test_config_location_with_env_var = (
        "${" + test_env_var_name + "}/" + test_config_location
    )

# Generated at 2022-06-12 09:43:06.284794
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory

    td = TemporaryDirectory()
    td_path = Path(td.name)

    # 1.
    os_environ["some_env_var"] = "data"
    path = td_path / "init.py"
    path.write_text(
        text="""
some_var = "some value"
"""
    )

    mod = load_module_from_file_location(
        "some_name", str(td_path / "init.py")
    )
    assert hasattr(mod, "some_var")

    # 2.
    os_environ["some_env_var"] = "data"
    path = td_path / "init.py"
    path.write_text(
        text="""
some_var = "some value"
"""
    )



# Generated at 2022-06-12 09:43:18.052603
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # test_load_module_from_file_location_1
    assert (
        load_module_from_file_location(
            "from typing import Union",
            "<string>",
            True,
            None,
            True,
            "exec",
            False,
            None,
            None,
            None,
            False,
            None,
            None,
        ).__name__
        == "from typing import Union"
    )

    # test_load_module_from_file_location_2

# Generated at 2022-06-12 09:43:19.975513
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "tests/config_example.py"
    assert load_module_from_file_location(location).TEST_VARIABLE == "OK"



# Generated at 2022-06-12 09:43:20.658727
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

# Generated at 2022-06-12 09:43:27.232963
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if True is returned for path leading to existing file.
    assert load_module_from_file_location("sanic/app.py")
    # B) Check if None is returned for non existing file.
    assert not load_module_from_file_location("non_existing_file.py")
    # C) Check if Environment var on path works.
    assert os_environ["PWD"]
    assert load_module_from_file_location("${PWD}/sanic/app.py")
    # D) Check if Environment var on name works.
    assert os_environ["HOME"]
    assert load_module_from_file_location("${HOME}/sanic/app.py")

# Generated at 2022-06-12 09:43:29.215931
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Tests that proper exception is raised when not existing file is provided
    with pytest.raises(LoadFileException):
        load_module_from_file_location("not_existing_location")



# Generated at 2022-06-12 09:43:38.058059
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import tempfile

    import pytest

    # Test to check if function handles bytes object.
    with pytest.raises(TypeError) as exception_info:
        load_module_from_file_location(b"bytes_object")
    assert "str expected" in str(exception_info.value)

    # Test to check if function handles unicode string with non-utf-8 encoding.
    with pytest.raises(UnicodeDecodeError) as exception_info:
        load_module_from_file_location("unicode_string", encoding="utf16")
    assert "utf-16-le" in exception_info.value.encoding

    # Test to check if function handles environment variables in location
    # of format ${some_env_var}.

# Generated at 2022-06-12 09:43:41.708964
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    path = tempfile.mktemp(suffix=".py")
    with open(path, "wt") as f:
        f.write("__ = 'test'")
    module = load_module_from_file_location(path)
    assert module.__ == "test"

# Generated at 2022-06-12 09:43:51.305203
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os.path import join as os_path_join
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        # 1) Test loading module from bytes path
        file_name = b"some_bytes_file_name.py"
        file_path = os_path_join(temp_dir, file_name)
        with open(file_path, "w") as f:
            f.write("VARIABLE=42\ntest_str='test string'")
        module = load_module_from_file_location(file_path)
        assert module.VARIABLE == 42
        assert module.test_str == "test string"

        # 2) Test loading module from bytes path
        file_name = "some_str_file_name.py"
        file_path = os_path_join

# Generated at 2022-06-12 09:43:59.570428
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # pylint: disable=invalid-name
    import os
    import pytest
    import sys
    import tempfile
    from shutil import rmtree

    # Should raise IOError if location is incorrect.
    with pytest.raises(IOError):
        load_module_from_file_location("fake_file_name")

    # Should raise IOError if location is incorrect.
    with pytest.raises(IOError):
        load_module_from_file_location("fake_file_name.py")

    # Should raise LoadFileException if environment variable is not set.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("${fake_env_var}/fake_file_name.py")

    # Should return module if location
    # is path to directory with __init

# Generated at 2022-06-12 09:44:09.451550
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # First: Let's create configuration file
    _path = Path("/tmp/config.py")
    with open(_path, "w+") as _:
        pass

    # Second: Let's prepare environment
    _environ_variables = {
        "some_var": "some_var_value",
        "some_var_with_empty_string_value": "",
    }
    for env_var, env_var_value in _environ_variables.items():
        os_environ[env_var] = env_var_value

    # Third: Let's prepare tests

# Generated at 2022-06-12 09:44:21.744100
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from shutil import rmtree
    from tempfile import mkdtemp
    from os import environ

    some_env_var_value = "some_env_var_value"
    some_env_var_name = "some_env_var_name"
    module_path = mkdtemp()
    module_name = "some_module"
    env_var_template = "${some_env_var_name}"

    environ[f"{some_env_var_name}"] = some_env_var_value

    module_path = Path(module_path).joinpath(env_var_template).joinpath(
        module_name + ".py"
    )
    module_path.parent.mkdir()


# Generated at 2022-06-12 09:44:30.450903
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Create temporary file for tests
    with tempfile.NamedTemporaryFile("w", delete=False) as temp_file:
        # pylint: disable=abstract-class-instantiated
        temp_file.write("import os")

    try:
        # A) Test that it works with file path.
        load_module_from_file_location(temp_file.name)
        # B) Test that it works with environment variables.
        load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var}"
        )
    finally:
        # Cleanup
        os.unlink(temp_file.name)



# Generated at 2022-06-12 09:44:39.649439
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_path = Path(os.path.dirname(__file__))
    import_test_file = file_path / ".." / "sanic" / "test_server.py"
    module = load_module_from_file_location(import_test_file.as_posix())

    assert module is not None
    assert module.__name__ == "test_server"
    assert "test_server" in sys.modules

    test_server_path = file_path / ".." / "sanic" / "test_server.py"
    module = load_module_from_file_location(test_server_path.as_posix())

    assert module is not None
    assert module.__name__ == "test_server"
    assert "test_server" in sys.modules

# Generated at 2022-06-12 09:44:47.074377
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check that function loads module from a string.
    assert load_module_from_file_location(__name__) == __import__(__name__)

    # B) Check that function loads module from a string with a '/' in it.
    assert (
        load_module_from_file_location(__file__)
        == __import__(__name__.split(".")[0])
    )

    # C) Check that function loads module from a Path object.
    current_module_path = Path(__file__)
    assert (
        load_module_from_file_location(current_module_path)
        == __import__(__name__.split(".")[0])
    )

    # D) Check that function loads module from a bytes object with an encoding.
    current_module_path_bytes = bytes

# Generated at 2022-06-12 09:44:56.142979
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from tempfile import NamedTemporaryFile

    script_name = "some_module.py"
    script = (
        f"from typing import Any\n"
        f"global_var: Any = 'val of global var'\n"
        f"env_var = '${ENV_VAR}'\n"
        f"block = """
        f"    'block variable'\n"
    )

    with NamedTemporaryFile("w", encoding="utf8", delete=False) as f:
        f.write(script)
        path = f.name

    os_environ["ENV_VAR"] = "value of env var"
    some_module = load_module_from_file_location(path)
    del os.environ["ENV_VAR"]


# Generated at 2022-06-12 09:45:03.615328
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    import tempfile
    import os

    def _create_config(name: str, config: str):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".py", mode="w") as temp:
            temp.write(f"{config}")
        return Path(temp.name).absolute()

    def _get_config_value(config_path: Path):
        return load_module_from_file_location(config_path).value

    def _get_config_str(config_path: Path):
        return load_module_from_file_location(config_path).str

    def _remove_config_file(path):
        os.remove(path)


# Generated at 2022-06-12 09:45:06.715787
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = Path(__file__).parent / 'test_module.py'
    module = load_module_from_file_location(path)
    assert module.username == 'test'

# Generated at 2022-06-12 09:45:15.659045
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Lets prepare environment variables and config file first.

    env_vars = {
        "some_string": "life",
        "some_number": "42",
        "some_bool_t": "T",
        "some_bool_f": "f",
        "some_bool_y": "y",
        "some_bool_n": "n",
    }

    for var, val in env_vars.items():
        os_environ[var] = val


# Generated at 2022-06-12 09:45:25.366489
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test for function load_module_from_file_location."""

    try:
        from .load_config import load_config  # noqa
    except ImportError:
        pass  # It is OK, since we are testing it here.

    from .load_config import load_config  # noqa

    #  full module name
    try:
        load_module_from_file_location("test.test_module_load_config.load_config")
    except Exception as e:
        raise AssertionError(
            f"Exception raised when it should be not: {type(e)}: {str(e)}"
        )

    #  absolute path
    try:
        load_module_from_file_location(__file__.replace(".pyi", ".py"))
    except Exception as e:
        raise Assertion

# Generated at 2022-06-12 09:45:33.067284
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D103
    import pytest

    # file doesn't exist
    with pytest.raises(IOError, match="Unable to load configuration ./non.py"):
        load_module_from_file_location("./non.py")

    # valid yaml file
    assert load_module_from_file_location("./test.yaml").data == {
        "a": 1,
        "b": "1",
    }

    # valid json file
    assert load_module_from_file_location("./test.json").data == {
        "a": 1,
        "b": "1",
    }

    # valid python file

# Generated at 2022-06-12 09:45:47.262117
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Create configuration file
    test_file_path = Path(__file__).parent.absolute() / "test_file.py"
    test_file_path.touch()
    test_file_path.write_text(
        "foo = 'bar'\nbaz = xyzzy"
    )  # type: ignore

    # Test 1.
    # Set environment variable so we can test it.
    os_environ["test_file_env_var"] = str(test_file_path)

    # Do test
    test_module = load_module_from_file_location(
        "test_module_name", "${test_file_env_var}", "r"
    )

    # Test
    assert test_module.__file__ == str(test_file_path)

# Generated at 2022-06-12 09:45:56.508320
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # ------- A) Example of usage with environment variables. ------- #
    os_environ["TEST_VAR"] = "test_var_value"
    os_environ["TEST_VAR2"] = "test_var_value2"

    config = load_module_from_file_location(
        b"config.py",
        encoding="utf8",
        location="/some/path/${TEST_VAR}",
    )

    # A.0) Check if file is loaded.
    assert config.TEST_VAR1 == "test_var_value"
    assert config.TEST_VAR2 == "test_var_value2"

    # A.1) Check if config have attribute location.
    assert config.location == "/some/path/${TEST_VAR}"
    # A.2) Check

# Generated at 2022-06-12 09:46:03.709788
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_ENV_VAR"] = "test_env_var_value"
    location = "tests/fixtures/configuration/some_config.py"

    # Normal
    module = load_module_from_file_location(location)
    assert module.some_config == "some_config"
    assert module.__name__ == "some_config"

    # Relative
    module = load_module_from_file_location("../fixtures/configuration/some_config.py")
    assert module.some_config == "some_config"
    assert module.__name__ == "some_config"

    # With environment variables

# Generated at 2022-06-12 09:46:12.550919
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # A)
    # Location contains environment variable.
    os_environ["ENV_VAR_1"] = "env_var_1"
    os_environ["ENV_VAR_2"] = "env_var_2"
    env_vars_location = "/some/path/${ENV_VAR_1}/${ENV_VAR_2}/${ENV_VAR_3}"
    location = env_vars_location.replace(
        "${ENV_VAR_3}", "env_var_3"
    )  # create absolute location
    assert (
        load_module_from_file_location(
            env_vars_location, location, "", False
        ).__file__
        == location
    )

    # B)
    # Location is of a bytes type

# Generated at 2022-06-12 09:46:21.841864
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from types import ModuleType
    from os import environ, path

    from tempfile import NamedTemporaryFile as tempfile_NamedTemporaryFile

    from yarl import URL

    environ["TEST_ENV_VAR"] = "test_env_var_value"

    # test for bytes type
    with tempfile_NamedTemporaryFile("w+") as config_file:
        config_file.writelines("TEST_CONFIG_VAR = 'test_config_var_value'")
        config_file.seek(0)
        module = load_module_from_file_location(
            config_file.name.encode("utf8")
        )
        assert isinstance(module, ModuleType)
        assert module.TEST_CONFIG_VAR == "test_config_var_value"

    # test

# Generated at 2022-06-12 09:46:28.692529
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location(__file__).__file__ == __file__
    ), "Should load module from file"

    # for coverage
    try:
        load_module_from_file_location("")
    except LoadFileException as e:
        assert str(e) == "Unable to load configuration file ()"
    except:
        raise
    else:
        raise Exception("Expected exception")

    try:
        load_module_from_file_location("${not_defined_env_var}")
    except LoadFileException as e:
        assert (
            str(e)
            == "The following environment variables are not set: not_defined_env_var"
        )
    except:
        raise
    else:
        raise Exception("Expected exception")


# Generated at 2022-06-12 09:46:31.428982
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    # Case A. Expect not to raise an exception.
    location = Path(tempfile.gettempdir()) / "temp_file.py"


# Generated at 2022-06-12 09:46:40.257444
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa

    def _test_load_module_from_file_location_on_file(
        path: str, location: str, env_var: str
    ):  # noqa

        os_environ.clear()

        # A) Check if location contains any environment variables
        #    in format ${some_env_var}.
        env_vars_in_location = set(re_findall(r"\${(.+?)}", location))

        # B) Check these variables exists in environment.
        not_defined_env_vars = env_vars_in_location.difference(
            os_environ.keys()
        )
        assert not not_defined_env_vars
        # C) Substitute them in location.

# Generated at 2022-06-12 09:46:50.249994
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Function load_module_from_file_location() is using another function to
    load modules by calling function import_string() from this library.
    We are not testing import_string() here and not testing load_module_from_file_location()
    on all parameters possible, but just on a few most important.

    Only one case is being tested with load_module_from_file_location() and
    all other cases are being tested with import_string().
    """
    # Test on load_module_from_file_location()
    # Test on some real file from this repo.
    assert load_module_from_file_location("helpers.test_hacks.test_hacks")
    # Test on some real file from this repo with environment variables.

# Generated at 2022-06-12 09:46:59.509129
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "sanic_envconfig/tests/test_load_envconfig.py"
    assert load_module_from_file_location(location) == (
        import_string(location)
    )
    test_module_name = "sanic_envconfig_test_module"
    os_environ["SANIC_ENVCONFIG_TEST_ENV_VAR"] = location
    assert load_module_from_file_location(
        test_module_name,
        os_environ["SANIC_ENVCONFIG_TEST_ENV_VAR"],
    ) == import_string(test_module_name)
    assert os_environ.get("SANIC_ENVCONFIG_TEST_ENV_VAR") is None

# Generated at 2022-06-12 09:47:15.084464
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["FOO_BAR"] = "some_env_var"
    # A) Check if we can load module from file by its location.
    some_module_name, some_module_location = "some_module_name", "./test_file.py"
    module = load_module_from_file_location(
        some_module_location, some_module_name
    )
    assert module.__name__ == some_module_name
    assert module.__file__ == some_module_location

    # B) Check this module can be overwritten.
    some_other_module_name = "some_other_module_name"
    load_module_from_file_location(
        some_module_location, some_other_module_name
    )
    assert module.__name__ != some_other_

# Generated at 2022-06-12 09:47:21.642963
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SOME_ENV_VAR"] = "env_var_val"

# Generated at 2022-06-12 09:47:30.814194
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import pytest
    import yaml
    from os import environ as os_environ, pathlib
    from pathlib import Path
    from textwrap import dedent

    from sanic.exceptions import LoadFileException, PyFileError

    from .utils import make_temp_dir, make_temp_file

    temp_dir = make_temp_dir("test_temp_dir")
    path_to_temp_dir = str(temp_dir)  # type: ignore

    # Exception in case of wrong configuration file
    os_environ["wrong_configuration_file_name"] = path_to_temp_dir


# Generated at 2022-06-12 09:47:38.618202
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from functools import partial
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir_path = os.path.abspath(tmp_dir)
        os.environ["my_env_var"] = tmp_dir_path

        tmp_file_path = os.path.join(tmp_dir_path, "some_file.py")

        with open(tmp_file_path, "w") as tmp_file:
            tmp_file.write("CONFIG_VAR = 1")

        load_module_from_file_location_with_env = partial(
            load_module_from_file_location,
            location=f"${my_env_var}/some_file.py",  # noqa
        )

# Generated at 2022-06-12 09:47:48.207819
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 1. Test if module loading from file location works properly.
    from os import environ as os_environ
    from sys import path as sys_path
    from tempfile import mkdtemp
    from textwrap import dedent
    from shutil import rmtree
    import pytest

    tmp_dir = mkdtemp()

# Generated at 2022-06-12 09:47:57.171442
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    env_vars_to_set = {"home_dir": "/home", "config_dir": "config"}
    os_environ.update(env_vars_to_set)

    location_variants = [
        "./tests/test_configs/config1.py",
        "./tests/test_configs/config2.py",
        "./tests/test_configs/config3.py",
        "/home/${home_dir}/config/${config_dir}/config1.py",
        "/home/${home_dir}/config/${config_dir}/config2.py",
        "/home/${home_dir}/config/${config_dir}/config3.py",
    ]
