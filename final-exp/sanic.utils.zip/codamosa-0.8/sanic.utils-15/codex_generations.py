

# Generated at 2022-06-12 09:38:00.997074
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    config_file_location = Path(__file__).parent / "test_config.py"
    config_module = load_module_from_file_location(config_file_location)
    assert config_module.TEST_CONFIG_VAR == "TEST_CONFIG_VAL"

# Generated at 2022-06-12 09:38:06.379353
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("true")
    assert str_to_bool("y")
    assert str_to_bool("enable")
    assert str_to_bool("1")
    assert str_to_bool("Y")
    assert str_to_bool("Yep")
    assert str_to_bool("ON")

    assert not str_to_bool("false")
    assert not str_to_bool("F")

# Generated at 2022-06-12 09:38:11.514383
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "fixtures.module"
    module = load_module_from_file_location(location)
    # Are members of module really are in the module ?
    assert hasattr(module, "defined_in_module") and module.defined_in_module
    assert hasattr(module, "not_defined_in_module") and not module.not_defined_in_module

    module = load_module_from_file_location("./fixtures/module.py")
    assert hasattr(module, "defined_in_module") and module.defined_in_module
    assert hasattr(module, "not_defined_in_module") and not module.not_defined_in_module

    import os
    env = os.environ
    os.environ["SOME_ENV_VAR"] = "some_value"
   

# Generated at 2022-06-12 09:38:16.158019
# Unit test for function str_to_bool
def test_str_to_bool():
    # bools tests
    assert str_to_bool('y')
    assert str_to_bool('Y')
    assert str_to_bool('yes')
    assert str_to_bool('YES')
    assert str_to_bool('yep')
    assert str_to_bool('YEPS')
    assert str_to_bool('yup')
    assert str_to_bool('YUP')
    assert str_to_bool('t')
    assert str_to_bool('T')
    assert str_to_bool('true')
    assert str_to_bool('TRUE')
    assert str_to_bool('1')
    assert str_to_bool('on')
    assert str_to_bool('ON')
    assert str_to_bool('enable')
    assert str_to_bool('ENABLE')


# Generated at 2022-06-12 09:38:21.917774
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") == True
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("Yup") == True
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("t") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("1") == True
    assert str_to_bool("No") == False
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False

# Generated at 2022-06-12 09:38:27.631854
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("yes")
    assert str_to_bool("Yep")
    assert str_to_bool("1")
    assert not str_to_bool("false")
    assert not str_to_bool("False")
    assert not str_to_bool("no")
    assert not str_to_bool("nope")
    assert not str_to_bool("0")

    try:
        str_to_bool("maybe")
    except ValueError as e:
        assert "Invalid truth value" in str(e)

# Generated at 2022-06-12 09:38:39.079808
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SANIC_TEST_MODULE_ENV_VAR"] = "test"
    module = load_module_from_file_location(
        "sanic.tests.test_helpers.test_module_loaders"
    )
    # Check import_string
    assert module.TEST_VARIABLE == "Yay"
    # Check that pathlib is working
    module = load_module_from_file_location(
        Path(__file__).parent / "test_module_loaders.py"
    )
    assert module.TEST_VARIABLE == "Yay"
    # Check environmant variables resolving

# Generated at 2022-06-12 09:38:46.368978
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location("config.py").FOO
        == load_module_from_file_location(Path(__file__).parent / "config.py").FOO
    )

    assert load_module_from_file_location(b"config.py").FOO == "bar"

    assert (
        load_module_from_file_location(b"config.py", encoding="ascii").FOO
        == "bar"
    )

    os_environ["loc_env"] = str(Path(__file__).parent)

# Generated at 2022-06-12 09:38:49.727898
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    simulation = Path(__file__).parent / "package" / "full_config.py"
    config = load_module_from_file_location(simulation)
    assert config.DEBUG is False
    assert config.TESTING is True

# Generated at 2022-06-12 09:39:00.088443
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1")
    assert not str_to_bool("0")
    assert str_to_bool("True")
    assert not str_to_bool("False")
    assert str_to_bool("y")
    assert not str_to_bool("n")
    assert str_to_bool("yes")
    assert not str_to_bool("no")
    assert str_to_bool("on")
    assert not str_to_bool("off")
    assert str_to_bool("enable")
    assert not str_to_bool("disable")
    assert str_to_bool("enabled")
    assert not str_to_bool("disabled")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert not str_to_bool("f")
    assert str

# Generated at 2022-06-12 09:39:09.334561
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    mod = load_module_from_file_location(
        "tests/unit/examples/views.py", encoding="utf8"
    )
    assert mod.__dict__.get("example") == 1
    assert mod.__dict__.get("foo") == "bar"

    # A)
    os_environ["some_var"] = "example"
    mod = load_module_from_file_location(
        "tests/unit/examples/${some_var}_views.py"
    )
    assert mod.__dict__.get("example") == 2
    assert mod.__dict__.get("foo") == "bar"

    # B)

# Generated at 2022-06-12 09:39:13.588241
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    try:
        load_module_from_file_location("/tmp/somefile.py")
        load_module_from_file_location("/tmp/${SOME_ENV_VAR}/somefile.py")
        load_module_from_file_location("somefile.py")
    except Exception:
        assert False

# Generated at 2022-06-12 09:39:22.546662
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import random

    # This function generates temporary file with given content.
    def generate_config(content = "some_var = 'some_value'"):
        _, config_file_path = tempfile.mkstemp(".py")
        with open(config_file_path, "w") as config_file:
            config_file.write(content)

        return config_file_path

    # This function generates content of config file.
    def generate_content(some_var_value = "some_value"):
        return f"some_var = '{some_var_value}'"

    # Test for case when location is a bytes string.
    config_file_path = generate_config()

# Generated at 2022-06-12 09:39:23.671798
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests load_module_from_file_location function."""
    pass
    # TODO: write tests

# Generated at 2022-06-12 09:39:26.553457
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        assert not load_module_from_file_location(b"", "ascii")
    except LoadFileException as e:
        assert "Empty configuration name" in str(e)

    try:
        assert not load_module_from_file_location("", "utf8")
    except LoadFileException as e:
        assert "Empty configuration name" in str(e)

# Generated at 2022-06-12 09:39:31.086523
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "sanic/tests/config_tests/config_test.py"
    config_module = "sanic.tests.config_tests.config_test"
    assert load_module_from_file_location(
        location
    ) == import_string(config_module)
    assert load_module_from_file_location(
        Path(location)
    ) == import_string(config_module)
    assert load_module_from_file_location(
        bytes(location, encoding="utf-8")
    ) == import_string(config_module)

    # Test working with environment variables in location
    os_environ["sanic_test_env_var"] = "config_tests/config_test.py"
    location = f"${sanic_test_env_var}"
    assert load_module_from_file

# Generated at 2022-06-12 09:39:40.928000
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    filename = "test_load_module_from_file_location.py"
    os_environ["TEST_ENV_VAR"] = "0"
    with open(filename, "w") as f:
        f.write("TEST_VAR = 1\n")

    module = load_module_from_file_location(filename)
    assert module.TEST_VAR == 1
    assert module.__file__ == filename

    os_environ["TEST_ENV_VAR"] = "1"
    with pytest.raises(LoadFileException) as excinfo:
        load_module_from_file_location(
            "test_${TEST_ENV_VAR}_load_module_from_file_location.py"
        )

# Generated at 2022-06-12 09:39:49.009666
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    from os import environ as os_environ
    from os import path
    from os import remove

    # A) Test load_module_from_file_location with string
    #    by creating temporary file and changing configuration file location.
    #    Finaly, we could check that we can set and get some_option value
    #    from it.
    #    But before that we have to import our module from string
    #    and set some_option to this value.
    my_temp_config_file_name = tempfile.mkstemp(".py")[1]
    some_option = "some_option value"
    my_temp_config_file = open(my_temp_config_file_name, "w")

# Generated at 2022-06-12 09:39:58.389247
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "/home/user/file.py"
    name = "file"
    module = load_module_from_file_location(
        location
    )  # type: ignore

    assert module.__name__ == name, "Module name failure"
    assert module.__file__ == location, "Module file failure"

    location_bytes = b"/home/user/file.py"
    module = load_module_from_file_location(
        location_bytes
    )  # type: ignore

    assert module.__name__ == name, "Module name failure"
    assert module.__file__ == location, "Module file failure"

    location_bytes_encoding = b"/home/\xc5\x9b\xc4\x85\xc5\xbc\xc4\x87/file.py"
    module

# Generated at 2022-06-12 09:40:06.585168
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    load_module_from_file_location.__annotations__ = {}

    # A) Check if works with bytes type.
    location = (
        b"/some/path"
        + os_environ["PWD"].encode("utf8")[1:]
        + b"/${PYTHON_VERSION}"
        + b"/file.py"
    )
    location = load_module_from_file_location(location)

    # B) Check if works with string type.
    location = os_environ["PWD"] + "/${PWD}/file.py"
    location = load_module_from_file_location(location)

    # C) Check if works with Path type.
    location = Path(os_environ["PWD"] + "/${PWD}/file.py")

# Generated at 2022-06-12 09:40:11.071934
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with open("example.py", "w") as f:
        f.write("hello = 'world'")
    module = load_module_from_file_location("example.py")
    assert module.hello == "world"
    Path("example.py").unlink()

# Generated at 2022-06-12 09:40:17.144587
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) test module import from existing file
    some_config_module = load_module_from_file_location(
        location=Path(__file__).parent.parent / "sanic_openapi" / "schema.py"
    )
    assert some_config_module.__name__ == "schema"
    assert some_config_module.__file__ == (
        Path(__file__).parent.parent / "sanic_openapi" / "schema.py"
    )

    # B) test module import from existing file using absolute path
    some_config_module = load_module_from_file_location(
        location="/".join(Path(__file__).absolute().parts[:-3])
        + "/sanic_openapi/schema.py"
    )
    assert some_config_module.__

# Generated at 2022-06-12 09:40:26.205181
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import textwrap

    # Create temporary file
    tmpfile_path = Path(tempfile.mkstemp()[1])
    tmpfile_content = textwrap.dedent(
        """
        some_variable = 'some value'
        another_variable = 123456789
    """
    )
    with open(tmpfile_path, "w") as f:
        f.write(tmpfile_content)

    # Load this file
    module = load_module_from_file_location(tmpfile_path)
    assert module.some_variable == "some value"
    assert module.another_variable == 123456789

    # Check if file cannot be loaded by import_string function
    with pytest.raises(ValueError):
        import_string(str(tmpfile_path))

    # Cleanup tmp

# Generated at 2022-06-12 09:40:32.757114
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test that you can load module
    #    with environment variables in path.
    os_environ["my_env_var"] = "home"
    try:
        module = load_module_from_file_location(
            "load_module_from_file_location_test",
            "/${my_env_var}/test.py",
        )
    finally:
        del os_environ["my_env_var"]

    expected_module_name = "load_module_from_file_location_test"
    assert module.__name__ == expected_module_name

    expected_module_name = "load_module_from_file_location_test"
    assert module.__name__ == expected_module_name

    # B) Test that you can load module with environment variables
    #    in path and that you

# Generated at 2022-06-12 09:40:38.381424
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    def run(file_path: Union[str, Path], file_contents: str):
        # Prepare a temporary directory
        tmp_dir = tempfile.mkdtemp()

        # Prepare file_path
        if isinstance(file_path, str):
            file_path = Path(file_path)

        file_path = Path(tmp_dir) / file_path
        file_path.parent.mkdir(parents=True, exist_ok=True)

        # Write contents to file
        with file_path.open("w") as f:
            f.write(file_contents)

        # Read it and compare
        assert load_module_from_file_location(file_path).t == "test"

        del os_environ["SANIC_CONFIG_MODULE"]
       

# Generated at 2022-06-12 09:40:42.659490
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from tempfile import mkstemp
    from textwrap import dedent

    _ = dedent

    # This one has no need for os environment variables.
    # It has to pass for sure, if not it is a big problem.
    def plain_file_check():
        with mkstemp(text=True) as some_file:
            some_file_content = "some_module_var = True"
            some_file[0].write(
                b"%b" % some_file_content.encode("utf8")
            )
            some_file[0].flush()

            some_module = load_module_from_file_location(some_file[1])

            assert some_module.some_module_var is True

    # This one uses os environment variables.

# Generated at 2022-06-12 09:40:52.901812
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys

    sys.path.insert(0, ".")
    module = load_module_from_file_location("tests.test_helpers.module")
    assert module.variable == "I am a module"
    assert module.module_func() == "I am a module function"
    assert module.module_class().class_func() == "I am a module class function"
    assert str(module.__file__).endswith("tests/test_helpers/module.py")

    if os.path.exists("tests/test_helpers/config.txt"):
        module = load_module_from_file_location(
            "tests/test_helpers/config.txt"
        )
        assert module.variable == "I am a module"
        assert module.module_func() == "I am a module function"

# Generated at 2022-06-12 09:40:57.274177
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from .test import test_app as test_app
    from .test import tmp_app as tmp_app

    assert test_app.TEST_CONFIG["TEST_KEY"] == "TEST_VALUE"
    assert tmp_app.TEST_CONFIG["TEST_KEY"] == "TEST_VALUE"

# Generated at 2022-06-12 09:41:05.426010
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from importlib.machinery import SourceFileLoader
    from tempfile import NamedTemporaryFile

    # A) Check if loading *.py files is working.
    python_module_template = """
# #########################################################################
# Some Python module.
# #########################################################################

some_list = [1, 2, 3]
some_dict = {
    "some_key_in_dict": "some_value_in_dict"
}
some_var = "some_value"
"""

    with NamedTemporaryFile(mode="w+", suffix=".py") as tmp_file:
        tmp_file.write(python_module_template)
        tmp_file.seek(0)
        loaded_module = load_module_from_file_location(tmp_file.name)

    print(str(loaded_module.__spec__))

# Generated at 2022-06-12 09:41:14.009814
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    os.environ["SOME_ENV_VAR"] = "Just_some_path"

    # Some test file.
    example_config = """
    host = '127.0.0.1'
    port = 8000
    workers = 1
    debug = True
    """

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, "tmp.py")

        with open(tmp_file, "w") as f:
            f.write(example_config)

        tmp_file_2 = os.path.join(tmp_dir, "tmp_2.py")

        with open(tmp_file_2, "w") as f:
            f.write(example_config)

        tmp_file_3 = os

# Generated at 2022-06-12 09:41:24.431732
# Unit test for function load_module_from_file_location

# Generated at 2022-06-12 09:41:33.614266
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def custom_exception_handler(request, exception):
        return text(
            "Exception: {}\n\nPath: {}".format(exception, request.path), status=500
        )

    from sanic import Sanic, response as res

    app = Sanic("test_load_module_from_file_location")

    @app.get("/relative/path")
    async def relative_path(request):
        module = load_module_from_file_location("tests/files/config/example.py")
        assert module.EXAMPLE == 42
        return res.text("Everything OK!")


# Generated at 2022-06-12 09:41:43.441262
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import subprocess
    from tempfile import mkdtemp
    from shutil import rmtree

    class MockExecModule():
        """Mock module_from_spec.exec_module."""
        def __call__(self, module):
            self.module = module

    def touch(path):
        with open(path, "w") as f:
            pass

    def clean_tests():
        rmtree(test_path)

    touch(test_path + "/a.py")
    touch(test_path + "/b.py")
    touch(test_path + "/c")
    touch(test_path + "/d")
    touch(test_path + "/e")

    os_environ["A"] = "a"
    os_environ["B"] = "b"

# Generated at 2022-06-12 09:41:50.738929
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Testing with valid test file.
    import tempfile
    with tempfile.NamedTemporaryFile() as test_file:
        test_file.write(b"FOO='bar'#FOO_VAL")
        test_file.flush()
        module = load_module_from_file_location(test_file.name)

    assert module.FOO == "bar"

    # Test with environment variable
    os_environ["TEST_VAR_NAME"] = test_file.name
    module = load_module_from_file_location(
        "/some/path/${TEST_VAR_NAME}",
    )
    assert module.FOO == "bar"

    # Test with invalid path

# Generated at 2022-06-12 09:41:52.666520
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(
        "tests/configs/test_config.py",
    )

# Generated at 2022-06-12 09:42:00.829464
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import types
    import os
    from pathlib import Path
    from tempfile import NamedTemporaryFile

    import pytest

    # A) Test plain string with bytes location.
    code_part_A = b"""
    people = {"Alice" : 1, "Barbara" : 2, "Cecilia" : 3}
    """

    with NamedTemporaryFile(delete=False) as tmp_file:
        tmp_file.write(code_part_A)

    module_A = load_module_from_file_location(tmp_file.name, delete=False)
    assert module_A.people["Alice"] == 1
    os.remove(tmp_file.name)

    # B) Test bytes location.

# Generated at 2022-06-12 09:42:10.718224
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    location = (
        "tests/test_utils/test_load_module_from_file_location.py"
    )
    module = load_module_from_file_location(location)
    assert module.foo == 1
    assert module.bar is True
    assert module.baz == "foobar"

    location = "tests/test_utils/test_load_module_from_file_location.txt"
    module = load_module_from_file_location(location)
    assert module.foo == 1
    assert module.bar is True
    assert module.baz == "foobar"

    location = (
        b"tests/test_utils/test_load_module_from_file_location.py"
    )
    module = load_module_from_file_location(location)
    assert module

# Generated at 2022-06-12 09:42:19.299368
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    from os import path

    # 1) Create test data in temporary folder.
    tmp_dir = tempfile.mkdtemp()
    path_to_test_data = path.join(tmp_dir, "test_data.py")
    with open(path_to_test_data, "w") as f:
        f.write("test_data = {'some': ['dict', 'with', 'data']}")
    path_to_test_data_with_env_var = path.join(
        tmp_dir, "${TEST_DATA_FILE_NAME}.py"
    )

# Generated at 2022-06-12 09:42:29.014786
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    assert load_module_from_file_location(
        Path(__file__).parent / "test_config.py"
    ).SECRET_KEY == "some_secret_key"

    assert load_module_from_file_location(
        __file__, "/" + __name__.replace(".", "/")
    ).SECRET_KEY == "some_secret_key"

    os_environ["some_env_var"] = "my_env_var"
    assert load_module_from_file_location(
        "/${some_env_var}/${some_env_var}.py", f"{__name__}",
    ).SECRET_KEY == "some_secret_key"



# Generated at 2022-06-12 09:42:33.859200
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def _test_invalid_env_var_param(location):
        with pytest.raises(LoadFileException):
            load_module_from_file_location(location)

    def _test_correct_paths_and_env_var_param(location, expected_path):
        assert (
            load_module_from_file_location(location).__file__
            == expected_path
        )

    # Unit test for the case when location contains not existing environment
    # variable.
    _test_invalid_env_var_param(
        "some_module_name", "/some/path/${some_not_defined_env_var}"
    )

    # Unit test for the case when location contains  existing environment
    # variable.
    os_environ["some_env_var"] = "/some/path/"

   

# Generated at 2022-06-12 09:42:40.045032
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Given
    location = str(Path(__file__).parent / 'tests/sample_config.py')
    # When
    loaded_module = load_module_from_file_location(location)
    # Then
    assert loaded_module.SOME_CONFIG == 'whatever'

# Generated at 2022-06-12 09:42:41.684132
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "test.py"
    module = load_module_from_file_location(location)
    assert module is not None

# Generated at 2022-06-12 09:42:45.460749
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("sanic.exceptions").__file__.endswith(
        "sanic/exceptions.py"
    )
    assert load_module_from_file_location(
        "${CONFIG_FILE}", "sanic/exceptions.py"
    ).__file__.endswith("sanic/exceptions.py")
# TODO: Write more tests

# Generated at 2022-06-12 09:42:48.922387
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    test_location = "tests/test_config/test_conf.yml"
    test_config = load_module_from_file_location(test_location)

    assert test_config.TEST_ROOT == "./"
    assert test_config.TEST_HOST == "127.0.0.1"
    assert test_config.TEST_PORT == 8000

# Generated at 2022-06-12 09:42:57.159177
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from os import environ as os_environ
    from unittest import mock  # noqa

    # A) Check if location contains any environment variables.
    #    In this case check if f"${{some_env_var}}" is recognized as
    #    environment variable in format ${some_env_var}
    with mock.patch.dict(
        os_environ,
        {"some_env_var": "something"},
        clear=True
    ):
        assert load_module_from_file_location(
            "some_module_name", "${some_env_var}"
        )

    # B) Check if not recognized environment variable raises LoadFileException

# Generated at 2022-06-12 09:43:05.235470
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import mkstemp

    from os import environ as os_environ, remove
    from os.path import dirname, join

    from types import ModuleType

    from sanic.utils import load_module_from_file_location

    # Config variable is used to indicate whether this test is run independently
    # or not. If its present it means that it is run independently.
    # This is needed to add non-existent environment variable to
    # environment variables.
    # In sanic project this variable can be set to "1" by makefile's
    # run_tests target.
    if "config" in globals().keys():
        os_environ["NOT_EXISTING_ENV_VAR"] = ""

    # Some directory that will be used to store path to configuration files.
    tempdir = dirname(__file__)



# Generated at 2022-06-12 09:43:13.034122
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os.path import join
    from tempfile import TemporaryDirectory

    from sanic.exceptions import LoadFileException
    from sanic.helpers import load_module_from_file_location

    def pytest_generate_tests(metafunc):
        if '_test_location' in metafunc.fixturenames:
            _test_locations = []
            _test_locations.append(Path(__file__))
            _test_locations.append(__file__)
            _test_locations.append(
                str(Path(__file__))
            )  # __file__ is not always of a Path type, so we have to check
            _test_locations.append(
                bytes(Path(__file__))
            )  # __file__ is not always of a Path type,

# Generated at 2022-06-12 09:43:20.835699
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys

    for location in ["m", "m.py", "m.d"]:
        module = load_module_from_file_location(location)
        module.__name__ = "m"
        assert module in sys.modules
        try:
            assert module.__file__ == location
        except AttributeError:
            # Somethimes there is no `__file__` attribute in module.
            # This is the case when downloader is executed by `python -m`.
            # (You can see this happen by `python -m uvloop` in your project
            # where `uvloop` is installed)
            # So this check is not critical.
            pass
        del sys.modules["m"]

    for location in [b"m", b"m.py", b"m.d"]:
        module = load_module

# Generated at 2022-06-12 09:43:25.483869
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from unittest import TestCase

    from sanic.exceptions import LoadFileException

    from tests.async_test_environment import SANIC_CONFIG

    class LoadModuleFromFileLocationTestCase(TestCase):
        def test_can_load_module_from_os_environ(self):
            with NamedTemporaryFile() as f:
                f.write(
                    """
                    some_var = "some_value"
                    """
                )
                f.flush()
                os_environ["file_path_env_var"] = str(f.name)

                some_module = load_module_from_file_location(
                    "some_module", "${file_path_env_var}"
                )


# Generated at 2022-06-12 09:43:27.024407
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest  # type: ignore
    import sys

    # Prepare module for testing


# Generated at 2022-06-12 09:43:39.180447
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    os.environ["VAR_NAME_A"] = "value_a"
    os.environ["VAR_NAME_B"] = "value_b"
    os.environ["VAR_NAME_C"] = "value_c"
    os.environ["VAR_NAME_D"] = "value_d"

    module = load_module_from_file_location(
        "unit_tests/fixtures/custom_config.py"
    )

    assert module.CONFIG_VARIABLE_A == "value_a"
    assert module.CONFIG_VARIABLE_B == "value_b"
    assert module.CONFIG_VARIABLE_C == "value_c"
    assert module.CONFIG_VARIABLE_D == "value_d"



# Generated at 2022-06-12 09:43:48.892138
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from os import environ

    # A) Should load module from .py file.
    with NamedTemporaryFile(prefix="config", suffix=".py") as tmp_py_file:
        tmp_py_file.write(b"config_value = 42\n")
        tmp_py_file.flush()
        result = load_module_from_file_location(tmp_py_file.name)
    assert "config_value" in dir(result)
    assert result.config_value == 42

    # B) Should raise LoadFileException if trying to load
    #    nonexistent file.
    nonexistent_file_name = Path("I_Am_Nonexistent_File.py")

# Generated at 2022-06-12 09:43:58.094500
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D202
    from tempfile import TemporaryDirectory, NamedTemporaryFile

    with TemporaryDirectory() as tmp_dir:
        location = Path(tmp_dir) / "config.py"
        location.write_text("test_var = 123")
        module = load_module_from_file_location(location)
        assert module.test_var == 123

        with NamedTemporaryFile(dir=tmp_dir, prefix="test_", suffix=".py") as f:
            f.file.write(b"test_var = 123")
            f.file.flush()
            module = load_module_from_file_location(f.name)
            assert module.test_var == 123

        with NamedTemporaryFile(dir=tmp_dir, prefix="test_", suffix=".py") as f:
            f.file.write

# Generated at 2022-06-12 09:44:07.611898
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:  # Raises pytest.skip if file location package is not present
        import file_location
    except ModuleNotFoundError:
        pytest.skip()

    import_location = file_location.__file__

    module = load_module_from_file_location(import_location)
    assert module.__file__  # Simply check if file is loaded
    assert module.__file__ == import_location  # Check if file is loaded correctly

    module = load_module_from_file_location(
        Path(import_location)  # Check if Path object works
    )
    assert module.__file__  # Simply check if file is loaded
    assert module.__file__ == import_location  # Check if file is loaded correctly


# Generated at 2022-06-12 09:44:10.040802
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "/dev/null"
    mod = load_module_from_file_location(location)
    assert mod.__file__ == location



# Generated at 2022-06-12 09:44:19.060244
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ as os_environ
    from os import unlink as os_unlink
    from pathlib import Path
    from tempfile import NamedTemporaryFile as tempfile_NamedTemporaryFile

    example_conf = """
    A = "Some string"
    B = 123
    C = 98.6
    D = True
    E = {"A": "Some string",
         "B": 123,
         "C": 98.6,
         "D": True}
    """

    # We'll run tests on these paths

# Generated at 2022-06-12 09:44:28.926145
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic import Sanic

    class Plugin:
        def __init__(self, app: Sanic, *args, **kwargs):
            self._app = app

    def modify_config(config):
        config["MODIFIED"] = True

    config_module_a = load_module_from_file_location("./tests/config_a.py")
    app = Sanic("test_load_module_from_file_location")
    app.config.update(config_module_a.config)
    assert app.config == config_module_a.config

    config_module_b = load_module_from_file_location("./tests/config_b.py")
    app = Sanic("test_load_module_from_file_location")
    app.config.update(config_module_b.config)


# Generated at 2022-06-12 09:44:36.400686
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
        Tests function load_module_from_file_location.
    """
    # A) Check that function correctly loads module
    #    when location is string and contains no env variables in format
    #    ${some_env_var}.
    some_module = load_module_from_file_location(
        "some_module_name", "/some/path/to/some_module.py"
    )
    assert some_module

    # B) Check that function correctly loads module
    #    when location is bytes, contains no env variables in format
    #    ${some_env_var} and file name contains special characters.
    some_module = load_module_from_file_location(
        b"some_module_name", b"/some/path/to/some_m\xc3\xb3dule.py"
    )


# Generated at 2022-06-12 09:44:44.670118
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import unittest

    import sys

    from tests.utils import module_dir_path

    a_module_dir_path = str(module_dir_path(__file__, "a_module"))
    b_package_dir_path = str(module_dir_path(__file__, "b_package"))

    class TestLoadModuleFromFileLocation(unittest.TestCase):

        def test_existing_file_location(self):
            a_module_spec = load_module_from_file_location(
                a_module_dir_path + "/a_module.py"
            )
            self.assertEqual(a_module_spec.x, "x")
            self.assertEqual(a_module_spec.dict_x, {"y": "y"})


# Generated at 2022-06-12 09:44:52.848822
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    class Rock:
        pass

    loaded_module = load_module_from_file_location(
        os.path.join(
            os.path.dirname(os.path.realpath(__file__)),
            "test_config_utils.py",
        ),
        "TestClass",
    )
    assert isinstance(loaded_module.TestClass, type)
    assert isinstance(loaded_module.TestClass(), loaded_module.TestClass)

    loaded_module = load_module_from_file_location(
        os.path.join(
            os.path.dirname(os.path.realpath(__file__)),
            "test_config_utils.py",
        ),
        "str_to_bool",
    )

# Generated at 2022-06-12 09:45:01.587872
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    report_name = "config.py"

    # Test that when you pass string with path to file,
    # and it exists, then you get imported module.
    module = load_module_from_file_location(report_name)
    assert module.__name__ == "config"

    # Test that when you pass string with path to file,
    # and it does not exist, then you get IOError.
    try:
        load_module_from_file_location("/some/non/existing/path/to/config.py")
    except IOError:
        pass

    # Test that when you pass absolute path to file,
    # and it exists, then you get imported module.
    module = load_module_from_file_location("/" + report_name)
    assert module.__name__ == "config"

    # Test that

# Generated at 2022-06-12 09:45:11.336439
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    good_module_test_location = "good_module.py"
    bad_module_test_location = "bad_module.py"

    # Module with one variable with value 1.
    with open(good_module_test_location, "w") as good_module_test_file:
        good_module_test_file.write("test_var = 1")

    # Module with broken syntax.
    with open(bad_module_test_location, "w") as bad_module_test_file:
        bad_module_test_file.write("test_var = ")

    # Test normal behaviour.
    good_module = load_module_from_file_location(good_module_test_location)
    assert hasattr(good_module, "test_var")
    assert good_module.test_var == 1

    #

# Generated at 2022-06-12 09:45:20.516244
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from random import random
    from tempfile import NamedTemporaryFile
    from time import sleep

    def check_load_module_from_file_location(
        location: Union[str, bytes], encoding: str = "utf8", *args, **kwargs
    ):
        if isinstance(location, bytes):
            location = location.decode(encoding)
        elif isinstance(location, Path):
            location = str(location)
        elif "$" in location:
            location = location.replace("${some_env_var}", "env_var_value")

        module = load_module_from_file_location(location, *args, **kwargs)

        if isinstance(location, Path) or "/" in location:
            assert location == module.__file__
        else:
            assert module.__name__ == location

# Generated at 2022-06-12 09:45:29.774254
# Unit test for function load_module_from_file_location

# Generated at 2022-06-12 09:45:38.879999
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest

    def test_load_module_from_file_location_positive(location):
        from sanic_envconfig.helpers import load_module_from_file_location

        loaded_module = load_module_from_file_location(location)

        assert type(loaded_module) == types.ModuleType
        assert loaded_module.__name__ == "config"

    def test_load_module_from_file_location_negative(location):
        from sanic_envconfig.helpers import load_module_from_file_location

        with pytest.raises(LoadFileException) as e:
            load_module_from_file_location(location)

# Generated at 2022-06-12 09:45:47.675939
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os, shutil, tempfile
    import contextlib

    with contextlib.closing(tempfile.NamedTemporaryFile()) as tmp_file:
        tmp_file.write(b"a = 2")
        tmp_file.flush()

        assert load_module_from_file_location(tmp_file.name).a == 2

        tmp_file.write(b"b = 2")
        tmp_file.flush()

        assert load_module_from_file_location(tmp_file.name).a == 2
        assert load_module_from_file_location(tmp_file.name).b == 2

        tmp_file.write(b"def foo(bar): return bar")
        tmp_file.flush()


# Generated at 2022-06-12 09:45:52.244857
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    def test_file_location(location: str, expected: str) -> None:
        # Set up
        test_module = load_module_from_file_location(location)
        # Assert
        assert test_module.VAR == expected

    test_file_location.__name__ = "test_load_module_from_file_location"
    return test_file_location



# Generated at 2022-06-12 09:46:00.806479
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from copy import deepcopy
    from tempfile import TemporaryDirectory
    from uuid import uuid4

    from os import environ, path
    from pathlib import Path
    from textwrap import dedent
    from typing import Any, Callable

    from importlib.util import spec_from_file_location, module_from_spec

    test_dir = TemporaryDirectory()
    environ_and_dir = deepcopy(environ)
    environ_and_dir["test_dir"] = test_dir.name
    environ_and_dir["test_name"] = path.join(test_dir.name, "test.py")

    # Create test file
    test_name: str = "test_name"
    test_value: Any = uuid4()
    test_path: str = "test_dir/test.py"
   

# Generated at 2022-06-12 09:46:08.834477
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdirname:
        location = Path(tmpdirname)
        location.mkdir()
        full_path_with_file_name = location / "temp_file.py"
        full_path_with_file_name.touch()

        # A) Test with a simple string
        test_string = str(full_path_with_file_name)
        assert test_string == full_path_with_file_name.as_posix()
        module = load_module_from_file_location(test_string)
        assert module.__file__ == full_path_with_file_name.as_posix()

        # B) Test with string containing environment variables
        os_environ["TEST_ENV"] = tmpdirname
        module = load_module_from

# Generated at 2022-06-12 09:46:18.129816
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("os").__name__ == "os"
    with pytest.raises(
        LoadFileException,
        match="The following environment variables are not set: not_defined_env_var",
    ):
        load_module_from_file_location("/some/path/${not_defined_env_var}")
    if not os.environ.get("SANIC_TEST_CONFIG", ""):
        assert pytest.raises(
            LoadFileException,
            match="The following environment variables are not set: SANIC_TEST_CONFIG",
        ).type is LoadFileException

# Generated at 2022-06-12 09:46:23.796371
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_ENV_VAR"] = "test_string"
    location = "./tests/test_utils/test_load_module_from_file_location.py"
    module = load_module_from_file_location(location)
    assert "test_variable" in dir(module)
    assert module.test_variable == "test_string"

# Generated at 2022-06-12 09:46:30.496831
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests load_module_from_file_location function."""
    import tempfile
    import os
    import shutil
    import sys

    from os import makedirs
    from os.path import exists

    from importlib import reload

    from pytest import raises

    from .helpers import app_context

    with app_context("test_app"):
        from sanic import Sanic

        from .helpers import create_test_app

        app = create_test_app("test_app", "test_name")

        # A) Check if module can be loaded from file in string form.
        location = "/path/to/module.py"

        _mod_spec = spec_from_file_location("module", location)
        mod = module_from_spec(_mod_spec)
        _mod_spec.loader.exec_

# Generated at 2022-06-12 09:46:39.797359
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def simple_test(string_list, expected):
        for string in string_list:
            assert (
                load_module_from_file_location(string).__file__
                == expected
            )

    simple_test(  # nosec
        ["tests/test_config.py", "tests\\test_config.py"],
        "tests/test_config.py",
    )

    simple_test(
        [b"tests/test_config.py", b"tests\\test_config.py"],  # nosec
        "tests/test_config.py",
    )

    simple_test(
        [Path("tests/test_config.py"), Path("tests\\test_config.py")],  # nosec
        "tests/test_config.py",
    )


# Generated at 2022-06-12 09:46:46.285755
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    class Module:
        pass

    module = Module()
    setattr(module, "__name__", "__main__")
    setattr(module, "__file__", "./tests/unit/helpers/fixtures/mock_config.py")
    setattr(module, "HELLO", "WORLD")

    assert (
        sys.modules[__name__].load_module_from_file_location(
            "./tests/unit/helpers/fixtures/mock_config.py"
        ) == module
    )

# Generated at 2022-06-12 09:46:57.022748
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    config = load_module_from_file_location(
        "tests/test_load_module_from_file_location.py"
    )
    assert config.some_attribute == "some_value"
    assert config.some_other_attribute == "some_other_value"

    config = load_module_from_file_location(
        "tests/test_load_module_from_file_location.py",
        "utf16",
    )
    assert config.some_attribute == "some_value"
    assert config.some_other_attribute == "some_other_value"

    config = load_module_from_file_location(
        "tests/test_load_module_from_file_location.py".encode(),
    )
    assert config.some_attribute == "some_value"

# Generated at 2022-06-12 09:47:05.966430
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert isinstance(
        load_module_from_file_location(
            "sanic.exceptions", "sanic/exceptions.py"
        ),
        types.ModuleType,
    )
    assert isinstance(
        load_module_from_file_location(
            "sanic.exceptions", "sanic/exceptions.py",
        ),
        types.ModuleType,
    )
    assert (
        load_module_from_file_location(
            "sanic.exceptions", "sanic/exceptions.py",
        ).__file__[:-1]
        == "sanic/exceptions"
    )

# Generated at 2022-06-12 09:47:16.366142
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    testfile1 = Path(__file__).parent / "test_file1.py"
    testfile2 = Path(__file__).parent / "test_file2.py"
    testfile3 = Path(__file__).parent / "test_file3.py"
    testfile4 = Path(__file__).parent / "test_file4.py"
    testfile5 = Path(__file__).parent / "test_file5.py"

    # A) Check if location contains any environment ${some_env_var} variables
    #    and environment variables are set.
    # B) Substitute them in location.
    env_var = "HOME"
    os_environ[env_var] = "/home/user"


# Generated at 2022-06-12 09:47:27.139516
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    with tempfile.NamedTemporaryFile(dir=None, prefix="some_module_name", suffix=".py") as file:
        file.write(b"x = 'some_value'")
        file.flush()

        module = load_module_from_file_location(Path(file.name))

        assert module.__file__ == file.name
        assert module.x == "some_value"

        module = load_module_from_file_location(file.name)

        assert module.__file__ == file.name
        assert module.x == "some_value"

        module = load_module_from_file_location(bytes(file.name, "utf8"))

        assert module.__file__ == file.name
        assert module.x == "some_value"



# Generated at 2022-06-12 09:47:35.999106
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Check that True will be returned if there are no env vars.
    assert (
        load_module_from_file_location(
            "tests/project/some_python_module.py"
        ).some_variable
        == "some_value"
    )

    # Check that True will be returned if there are env vars.
    os_environ["some_python_module_env_var"] = "some_python_module_value"
    assert (
        load_module_from_file_location(
            "tests/project/${some_python_module_env_var}/some_python_module.py"
        ).some_variable
        == "some_value"
    )
    os_environ.pop("some_python_module_env_var")

    # Check that error will be returned if there is env

# Generated at 2022-06-12 09:47:42.423605
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert "some_module" == load_module_from_file_location(
        "some_module_name", "tests/fixtures/some_module.py"
    ).__name__
    os_environ["SOME_VAR"] = "tests/fixtures/"
    assert "some_module" == load_module_from_file_location(
        "some_module_name", "${SOME_VAR}some_module2.py"
    ).__name__
    os_environ.pop("SOME_VAR")

# Generated at 2022-06-12 09:47:54.398248
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa

    from tempfile import TemporaryDirectory

    # 1) Check that it returns module, when path doesn't contain environment
    #    variables in format ${some_env_var}.
    with TemporaryDirectory() as tmp_dir:
        config_file_path = Path(tmp_dir) / "config.py"
        config_file_path.touch()
        test_module = load_module_from_file_location(config_file_path)
        assert test_module
        assert isinstance(test_module, types.ModuleType)
        assert test_module.__file__ == str(config_file_path)

    # 2) Check that it returns module, when path contains environment variables
    #    in format ${some_env_var}.
    with TemporaryDirectory() as tmp_dir:
        os_environ["tmp_dir"] = tmp_