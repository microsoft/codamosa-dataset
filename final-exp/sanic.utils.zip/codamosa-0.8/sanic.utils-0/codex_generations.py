

# Generated at 2022-06-12 09:38:08.900434
# Unit test for function load_module_from_file_location

# Generated at 2022-06-12 09:38:18.739568
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from importlib import reload, import_module

    conf_path = Path(__file__).parent / "config_files"

    # 1) Import and reload of module.
    #
    # Module should be able to reload (even if it has alrady been imported).
    #
    # It should be also possible to use here environment variables.
    #
    # Module should be able to import from the same file.
    def test_01_a(path = conf_path / "conf01.py"):

        module_name = "conf_01_a"
        module = load_module_from_file_location(
            path, module_name
        )

        assert module_name == module.__name__
        assert module.os_environ_var == "value"
        assert module.conf_key == "value"
        assert module

# Generated at 2022-06-12 09:38:25.331568
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Setup
    os_environ["TEST_VAR"] = "__test_variable"
    os_environ["TEST_VAR2"] = "test_variable2"
    os_environ["TEST_VAR3"] = "test_variable3"
    os_environ["TEST_VAR4"] = "test_variable4"
    folder = os.path.dirname(__file__)
    # Test
    module = load_module_from_file_location(
        "${TEST_VAR}", os.path.join(folder, "__test_variable.py")
    )
    assert module.TEST_VARIABLE == "TEST_VALUE"
    # Test multiple variables

# Generated at 2022-06-12 09:38:31.125520
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("tests.backends.config_reader_test")

    assert module is not None
    assert module.TEST_VALUE == "test_value"

    if os.environ.get("TEST_ENV_VAR") is not None:
        os.environ["TEST_ENV_VAR"] = None
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.write(b'TEST_VALUE = "test_value"')
    tmp_file.close()
    module = load_module_from_file_location(tmp_file.name)
    assert module is not None
    assert module.TEST_VALUE == "test_value"
    os.unlink(tmp_file.name)


# Generated at 2022-06-12 09:38:41.595475
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import re

    tmpdir = tempfile.mkdtemp()
    tmpdir = Path(tmpdir)
    cwd = Path(os.getcwd())

    # os.getcwd() will contain 'tests' folder,
    # but if we want to test relative paths to config we must be in root folder

    os.chdir(tmpdir.parent)

    # Create test module module1.py
    module1_path = tmpdir / "module1.py"
    with open(module1_path, "wb") as module1:
        module1.write(b"a = 1")

    # Create test module2.py
    module2_path = tmpdir / "module2.py"

# Generated at 2022-06-12 09:38:50.152444
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("enable") is True
    assert str_to_bool("disable") is False
    assert str_to_bool("on") is True
    assert str_to_bool("off") is False
    assert str_to_bool("true") is True
    assert str_to_bool("false") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("yep") is True
    assert str_to_bool("f") is False
    assert str_to_bool("whatever") is True

# Generated at 2022-06-12 09:39:00.545206
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("N") == False

# Generated at 2022-06-12 09:39:08.281169
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    os.environ["text"] = "this is test env var"
    os.environ["number"] = "42"
    # 1. Test if the function load_module_from_file_location works with
    #    environment variables.
    with tempfile.NamedTemporaryFile() as tempf:
        tempf.write(
            f"text = '{os.environ['text']}' \n\nnumber = {os.environ['number']}"
        )
        tempf.flush()
        mod = load_module_from_file_location(
            tempf.name, "/", single_top_level_names=True
        )

    assert mod.text == os.environ["text"]
    assert mod.number == int(os.environ["number"])

    #

# Generated at 2022-06-12 09:39:16.913643
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        os_environ["TEST_ENV_VAR"]
    except KeyError:
        os_environ["TEST_ENV_VAR"] = "Value of test_env_var"

    module = load_module_from_file_location(
        Path(__file__).parent / "test_morepath_config.py",
    )

    assert isinstance(module, types.ModuleType)

    assert module.TEST_VAR == "Value of test_var"
    assert module.TEST_ENV_VAR == "Value of test_env_var"
    assert module.TEST_VAR_FROM_ENV_VAR == "Value of test_var"

# Generated at 2022-06-12 09:39:22.615407
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("truE") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("t") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("1") == True

    assert str_to_bool("fAlSe") == False
    assert str_to_bool("No") == False
    assert str_to_bool("f") == False
    assert str_to_bool("OFF") == False
    assert str_to_bool("0") == False

# Generated at 2022-06-12 09:39:35.241897
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    from sanic.config import Config
    import sys

    def assert_module_name(str_, name):
        assert str_ == name

    def assert_module_file(str_, path):
        assert str_ == path

    def assert_module_path(list_, path):
        assert list_[0] == path

    # Test with config_path None
    config = Config()
    assert_module_name(config.__module__, "config")
    assert_module_name(config.__name__, "config")
    assert_module_file(config.__file__, "config")
    assert_module_path(sys.modules["config"].__path__, "config")

    # Test with config_path "config"
    config = Config("config")
    assert_module_name

# Generated at 2022-06-12 09:39:43.877433
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Create temporary file
    from tempfile import TemporaryDirectory
    from random import random
    from shutil import copyfile

    with TemporaryDirectory() as temp_dir:

        temp_file_path = Path(temp_dir) / str(random()).replace(".", "_")
        temp_file_path_py = temp_file_path.with_suffix(".py")

        # Copy test script to temporary file
        # (so it will be not in the project directory)
        copyfile(
            Path(__file__).parent / "test_load_module_from_file_location.py",
            temp_file_path_py,
        )
        # Check that file is actually copyed.
        assert (
            Path(__file__).parent / "test_load_module_from_file_location.py"
        ).read_bytes

# Generated at 2022-06-12 09:39:51.114120
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unit test for function load_module_from_file_location."""

    # A. Test that a module is loaded correctly from a file location.
    module = load_module_from_file_location(
        "sanic/server.py", "sanic/tests/test_helpers/server.py"
    )
    assert isinstance(module, types.ModuleType)
    assert hasattr(module, "app")
    assert module.app.name == "some_module_name"

    # B. Test that a module is loaded correctly from path.
    module = load_module_from_file_location(
        "sanic/server.py", Path("sanic/tests/test_helpers/server.py")
    )
    assert isinstance(module, types.ModuleType)

# Generated at 2022-06-12 09:40:00.330665
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) First prepare some env vars.
    os_environ["Sanic_config_file_location_var"] = "/some/path/with/env_var/."
    os_environ["Sanic_config_file_name_var"] = "config_file_name"

    # B) Now check how function works with various inputs.
    assert (
        load_module_from_file_location("/some/path/config.py")
        == load_module_from_file_location("/some/path/config.py")
    )
    assert (
        load_module_from_file_location("/some/path/config.py")
        == load_module_from_file_location(Path("/some/path/config.py"))
    )

# Generated at 2022-06-12 09:40:07.601296
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile(suffix=".py") as tmp_file:
        tmp_file.write(b"SOME_ENV_VAR = 'TEST'")
        tmp_file.seek(0)
        module = load_module_from_file_location(tmp_file.name)
    assert module.SOME_ENV_VAR == "TEST"

    with NamedTemporaryFile(suffix=".py") as tmp_file:
        tmp_file.write(b"SOME_ENV_VAR = 'TEST'")
        tmp_file.seek(0)
        environ["ENV_VAR"] = str(tmp_file.name)

# Generated at 2022-06-12 09:40:14.873995
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from itertools import product
    from os import environ, remove
    from tempfile import mkstemp
    from textwrap import dedent

    from hypothesis import example, given
    from hypothesis.strategies import composite, integers, just, text
    from pytest import raises
    from pytest_sanic.utils import HypothesisEqualsSanicTestClient

    # Module configuration
    envs = {
        "envA": "nothing",
        "envB": "123",
        "envC": "123.45",
        "envD": "some_str",
        "envE": "True",
        "envF": "False",
    }

    # Configuration file content

# Generated at 2022-06-12 09:40:24.350049
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from tempfile import NamedTemporaryFile

    from sanic.exceptions import LoadFileException, PyFileError

    os_environ["TEST_ENV"] = "t"

    module_config_string = """
    VAR_CONFIG = "t"
    """

    def get_config_from_module(module) -> str:
        return module.VAR_CONFIG

    def test_location_as_string(location: str):
        module = load_module_from_file_location(location)
        assert get_config_from_module(module) == "t"

    def test_location_as_path(location):
        module = load_module_from_file_location(location)
        assert get_config_from_module(module) == "t"


# Generated at 2022-06-12 09:40:31.866638
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # TODO: Use proper unit test module here
    # for now catch only if nothing is raised,
    # if it does, it will fail

    from pathlib import Path
    from tempfile import NamedTemporaryFile as tmp_file

    # TODO: Check if loaded module is really loaded correctly,
    #       for now just check if it doesn't raise

    # 1. Paths:
    #    A) Pathlib path
    tmp_fp = Path(tmp_file(mode="w", delete=False, suffix=".py").name)
    load_module_from_file_location(tmp_fp)

    #    B) Path as a string
    tmp_fp = tmp_file(mode="w", delete=False, suffix=".py").name
    load_module_from_file_location(tmp_fp)

    #    C) Path

# Generated at 2022-06-12 09:40:34.374675
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    if __name__ == '__main__':
        main_path = "location"
        module_name = "test_module"
        test_module = load_module_from_file_location(
                main_path,
                "/some/path/${some_env_var}")
        print(test_module)

# Generated at 2022-06-12 09:40:40.951525
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    current_directory = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(current_directory, "test_data/test_config_file")
    module = load_module_from_file_location(config_path)
    assert module.TEST_DATA == 1
    module = load_module_from_file_location(Path(config_path))
    assert module.TEST_DATA == 1
    module = load_module_from_file_location(config_path.encode("utf-8"))
    assert module.TEST_DATA == 1


# Generated at 2022-06-12 09:40:53.863968
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import json
    import os
    import tempfile
    import sanic.config as config


# Generated at 2022-06-12 09:41:03.701625
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests for function load_module_from_file_location"""
    import pytest
    from sanic.exceptions import LoadFileException
    from sanic.utils import load_module_from_file_location

    os_environ["TEST_ENV_VAR"] = "test_env_value"

    def _test_import_error():
        """Test importing error.

        :return: None.
        """
        with pytest.raises(LoadFileException):
            load_module_from_file_location("non_existing_module")

        with pytest.raises(LoadFileException):
            load_module_from_file_location("non_existing_module.py")
        return None

    def _test_io_error():
        """Test IO error.

        :return:
        """

# Generated at 2022-06-12 09:41:06.937466
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location(
            "sanic.app", "./tests/empty_config.py"
        ).__name__
        == "sanic.app"
    )



# Generated at 2022-06-12 09:41:15.323677
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ

    # Using environment variables in location.
    path_to_sleep_script = Path("/sleep.py")

    environ["SLEEP_SCRIPT"] = str(path_to_sleep_script.absolute())
    sleep_script = load_module_from_file_location("${SLEEP_SCRIPT}")

    assert sleep_script.__file__ == str(path_to_sleep_script.absolute())

    # Trying to load a module that is not a python file.
    path_to_text_file = Path("/text_file.txt")
    text_file = load_module_from_file_location(path_to_text_file)

    assert text_file.__file__ == str(path_to_text_file.absolute())

    # Trying to load a python file.
    path

# Generated at 2022-06-12 09:41:23.679160
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import pytest

    # Test 1)
    # Test if environment variable can be expanded from /some/path/${env_var}
    # to /some/path/env_var_value
    # We need to create environment variable in this function
    # so it is not available before actual test.
    os.environ["env_var"] = "env_var_value"
    test_module = load_module_from_file_location(
        "test_module_name", "/some/path/${env_var}"
    )
    assert hasattr(test_module, "__file__")
    assert test_module.__file__ == "/some/path/env_var_value"
    assert hasattr(
        test_module, "__spec__"
    )  # in case of running on Python 3.5 +

# Generated at 2022-06-12 09:41:32.463893
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_name = "file_name"
    file_path_without_extension = "/path/to/file_name"
    file_path_with_extension = "/path/to/file_name.py"

    os_environ["some_env_var"] = "/some/env/var"

    # A
    assert (
        load_module_from_file_location(file_name).__name__
        == load_module_from_file_location(file_path_without_extension).__name__
    )

    # B
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            file_path_without_extension + "${not_defined_env_var}"
        )

    # C

# Generated at 2022-06-12 09:41:43.034753
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests main functionality of the function. Can be run with pytest.
    """
    import sys
    from tempfile import TemporaryDirectory
    from pathlib import Path

    from sanic.helpers import get_function_args  # noqa

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ A1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    assert "A1" in get_function_args(load_module_from_file_location)
    res = load_module_from_file_location(None, None)
    assert isinstance(res, types.ModuleType)
    assert res.__file__ == None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ A2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Generated at 2022-06-12 09:41:44.589659
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    assert load_module_from_file_location("os") == os



# Generated at 2022-06-12 09:41:51.380314
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # type: ignore
    import pytest
    import sys
    import tempfile

    config_data = {"some_key": "some_val"}

    location = tempfile.NamedTemporaryFile(delete=False)
    location.write(
        b"\n".join(
            [
                bytes(
                    f"from sanic.config import Config\n"
                    f"config = Config()\n"
                    f"config.update({config_data})\n",
                    "utf-8",
                ),
                b"",
            ]
        )
    )
    location.close()

    module = load_module_from_file_location(location.name)

    assert module.config.get("some_key") == "some_val"


# Generated at 2022-06-12 09:42:00.153258
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from random import random

    location = "./tests/config_test_file.py"
    name = "config"

    module = load_module_from_file_location(location)

    assert hasattr(module, name)
    assert isinstance(load_module_from_file_location(location), types.ModuleType)

    assert module.__file__ == location
    assert module.config.first_key == "f_value"
    assert module.config.second_key == "s_value"

    # Test environment variable
    os_environ["env_variable"] = "env_val"
    module = load_module_from_file_location("${env_variable}")
    assert module.__file__ == "env_val"

    # Test list and boolean

# Generated at 2022-06-12 09:42:12.472282
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def test_location(location, result):
        module = load_module_from_file_location(location)
        assert module == result

    test_location("sanic_session.session", session)
    test_location(".", __main__)

    # Test full path to folder
    test_location(Path("."), __main__)
    # Test relative path to folder
    test_location("tests", __main__)

    test_location("tests/fixtures/test_session.py", fixtures.test_session)

    # Test relative path to file
    test_location("tests/fixtures/test_session.py", fixtures.test_session)

    # Test full path to file
    test_location(Path("tests/fixtures/test_session.py"), fixtures.test_session)

    # Test environment variables
    os_environ

# Generated at 2022-06-12 09:42:20.450933
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test for A) Check if location contains any environment variables
    #            in format ${some_env_var}.

    # Mark that all $some_env_var will not be resolved in this unit test.
    os_environ["__SANIC_UNITTEST_SOME_ENV_VAR__"] = "__SOME_ENV_VALUE__"
    os_environ["__SANIC_UNITTEST_ANOTHER_ENV_VAR__"] = "__ANOTHER_ENV_VALUE__"

    # A1). Check if environment variable is inside location parameter.
    assert (
        load_module_from_file_location(
            "some_module_name",
            "/some/path/${__SANIC_UNITTEST_SOME_ENV_VAR__}",
        )
        is None
    )



# Generated at 2022-06-12 09:42:25.208911
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    some_module_name = "some_module_name"
    filename = "./tests/helpers/some_file_to_load"
    module = load_module_from_file_location(filename)
    assert module
    assert module.name == some_module_name

# Generated at 2022-06-12 09:42:28.205247
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_module = load_module_from_file_location(
        Path("tests/test_helpers_load_module.py"),
    )
    assert test_module.test_var == 1
    assert test_module.__file__



# Generated at 2022-06-12 09:42:33.741242
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with mock_fs(
        '{"some_dir":{"some_file": "\nprint("1")\n"}}'
    ):
        some_module = load_module_from_file_location("./some_dir/some_file")
        print(some_module)
        assert some_module.__name__ == "some_file"
        assert some_module.__file__ == "./some_dir/some_file"  # type: ignore

# Generated at 2022-06-12 09:42:42.051889
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os, os.path

    os_environ["SANIC_CONFIG_LOCATION"] = "./config.py"

    def clear_env_vars():
        os.environ.pop("SANIC_CONFIG_LOCATION")

    def reset_settings():
        path = os.path.join(os.path.dirname(__file__), "config.py")
        with open(path, "w") as f:
            f.write("LOGGING_CONFIG = '/some/path/test_logging_config.py'\n")

    reset_settings()

    some_module = load_module_from_file_location("./config.py")

    assert some_module.LOGGING_CONFIG == "/some/path/test_logging_config.py"

    reset_settings()

    some

# Generated at 2022-06-12 09:42:49.166339
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Loads module with file path
    temp_module = load_module_from_file_location(
        "tests/tools/test_config/test_file"
    )
    assert hasattr(temp_module, "test_arg")
    assert temp_module.test_arg == "test_val"

    # Test bytes path
    temp_module = load_module_from_file_location(
        b"tests/tools/test_config/test_file"
    )
    assert hasattr(temp_module, "test_arg")
    assert temp_module.test_arg == "test_val"

    # Loads module with file path
    temp_module = load_module_from_file_location(
        "tests/tools/test_config/test_file_without_py"
    )

# Generated at 2022-06-12 09:42:54.078090
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from pathlib import Path
    from unittest import TestCase
    from tempfile import NamedTemporaryFile as NTF

    class test_load_module_from_file_location_class(TestCase):
        def test_truthy_and_falsy(self):

            for val in {
                "y",
                "yes",
                "yep",
                "yup",
                "t",
                "true",
                "on",
                "enable",
                "enabled",
                "1",
            }:
                with self.subTest(val):
                    self.assertTrue(str_to_bool(val))


# Generated at 2022-06-12 09:43:02.229729
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os.path import dirname
    from types import ModuleType
    from unittest.mock import patch
    from uuid import uuid4

    location = Path(__file__).parent / "fixtures" / "load_module_from_file_location.yml"

    if Path(__file__).parent.name == "tests":
        location = location.relative_to(Path.cwd())

    assert isinstance(
        load_module_from_file_location(location), types.ModuleType
    )
    assert location.read_text() == load_module_from_file_location(
        location
    ).__file__.replace(dirname(dirname(dirname(location))), "")
    assert isinstance(
        load_module_from_file_location(str(location)), types.ModuleType
    )

# Generated at 2022-06-12 09:43:08.389727
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Unit test for function load_module_from_file_location.

    Checks that function properly loads modules from paths in various formats.
    It also checks that function can load modules from
    non-existing files.
    """
    from tempfile import NamedTemporaryFile
    from os import unlink

    location = NamedTemporaryFile(delete=False)
    location.write(
        b"""
        SOME_VAR = 'some_val'
        SOME_INT_VAR = 20
    """
    )
    location.close()

    loaded_module = load_module_from_file_location(
        location.name, encoding="utf8"
    )
    assert loaded_module.SOME_VAR == "some_val"
    assert loaded_module.SOME_INT_VAR == 20


# Generated at 2022-06-12 09:43:19.054277
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    os_environ["test_load_module_from_file_location_0"] = "test_load_module_from_file_location_0"

    assert (
        load_module_from_file_location(
            "${test_load_module_from_file_location_0}"
        ).__name__
        == "test_load_module_from_file_location_0"
    )

# Generated at 2022-06-12 09:43:26.797214
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Tests for environment variables in location
    # For MS Windows we need to transform ${variable} to %variable%
    # for os.environ.get()
    env_var_name = "SANIC_TEST"
    env_var_value = "test"
    env_var_in_location = f"${{{env_var_name}}}"

    # B) Creates configuration file with name "test_config"
    config_file_location = Path(__file__).parent.resolve()
    config_file_name = "test_config.py"
    config_file = config_file_location / config_file_name

    # C) In this configuration file it creates variable "test"
    config_file_content = f"test = 1"
    config_file.write_text(config_file_content)



# Generated at 2022-06-12 09:43:32.612022
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    assert load_module_from_file_location("os") == os

    assert load_module_from_file_location("os.path") == os.path

    assert (
        load_module_from_file_location(
            "sanic.helpers.test_load_module_from_file_location"
        )
        == test_load_module_from_file_location
    )

    # test_load_module_from_file_location file should be in the same folder,
    # pathlib.Path.parent will get us there

    # A) We can provide a path in the following format:
    #    - "/" is the root of your system
    #    - ".." is the parent folder
    #    - "." is the current folder
    #    - "/root/folder/file.py" is

# Generated at 2022-06-12 09:43:40.597100
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Create a module.
    module = load_module_from_file_location(
        location=__file__,
        encoding=None,
        # C) These values are ignored by this function.
        target=None,
        is_package=None,
        cached=None,
        has_location=None,
        loader=None,
        submodule_search_locations=None,
    )
    assert (
        # B) Check it has been populated as expected.
        (
            module.__package__ == "sanic.utils"
            and module.__name__ == "sanic.utils"
            and module.__path__ == ["sanic/utils"]
            and module.__file__ == __file__
            and module.__cached__ == __cached__
        )
    )


# B)

# Generated at 2022-06-12 09:43:50.285168
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) No file.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("/some/path/some_non_existing_file")

    # B) Not a file.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("/some/path/nonexistent")

    # C) Mock_module.py in test_files directory.
    mock_module = load_module_from_file_location(
        "tests.files.mock_module"
    )
    assert mock_module.mock_value == "mock_value"
    assert mock_module.__name__ == "tests.files.mock_module"

    # D) Mock_module in test_files directory.
    mock_module = load_module_from

# Generated at 2022-06-12 09:43:59.022163
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test default parameters
    location = "load_module_from_file_location.py"
    module = load_module_from_file_location(location=location)
    assert module.foo == "bar"

    # Test encoding
    bytes_location = b"load_module_from_file_location_encoding.py"
    module_encoding = load_module_from_file_location(
        location=bytes_location, encoding="utf8"
    )
    assert module_encoding.foo == "bar"

    # Test if location is a path
    path_location = location
    module_path = load_module_from_file_location(location=path_location)
    assert module_path.foo == "bar"

    # Test *args and **kwargs
    path_location = "some/path/some_file"

# Generated at 2022-06-12 09:44:08.651664
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys
    import tempfile
    import textwrap
    import uuid
    import shutil
    import importlib

    import pytest

    from os import environ as os_environ

    @pytest.fixture
    def custom_tmp_dir():
        """Generate a customised temporary directory.

        This fixture returns a temporary directory which is cleand up
        after test case.
        """
        tmp_dir = Path(tempfile.mkdtemp())

        yield tmp_dir
        shutil.rmtree(tmp_dir)

    @pytest.fixture
    def is_windows_platform(pytestconfig):
        """Check if test configuration is for Windows platform."""
        return pytestconfig.getoption("--platform") == "windows"


# Generated at 2022-06-12 09:44:17.907598
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Tests load_module_from_file_location() function."""

    import tempfile
    import os

    # Create temp dir
    with tempfile.TemporaryDirectory() as temp_dir:

        temp_dir = Path(temp_dir)

        # Create temp file
        temp_file = temp_dir / "temp_file.py"
        temp_file.touch()

        # Create temp env
        env_var_name = "TEST_LOAD_MODULE_FROM_FILE_LOCATION_TEMP_ENV"
        env_var_value = str(temp_dir)
        os.environ[env_var_name] = env_var_value

        # Test paths

# Generated at 2022-06-12 09:44:28.649970
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from tempfile import mkdtemp
    from pathlib import Path
    from shutil import rmtree
    from os import environ

    # We cannot use tempfile.mkstemp() to get tmpfile path, because
    # importlib needs path to dir not to the file.
    tmp_dir_path = Path(mkdtemp())
    tmp_file_path = tmp_dir_path / "tmp.py"

    # Let's write some test data to the tmpfile.
    with tmp_file_path.open("w") as f:
        f.write("some_var = 42")

    # Let's test if it works with Path
    test_module = load_module_from_file_location(tmp_file_path)
    assert hasattr(test_module, "some_var")
    assert test_module

# Generated at 2022-06-12 09:44:36.402673
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import json
    import os

    # Setup
    json_conf = ""
    location = ""
    output_config = {}
    test_env_var = "SANIC_TEST_ENV_VAR"
    os.environ[test_env_var] = "testing"

# Generated at 2022-06-12 09:44:47.793389
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from shutil import rmtree
    from tempfile import mkdtemp

    # Create temporary directory inside of
    # which we will store our configuration file
    # and a file with file name that is equal to
    # module name.
    temp_dir = mkdtemp()
    location = Path(temp_dir) / "some_module_name.py"
    with location.open("w") as file:
        file.write(
            """
            SOME_CONSTANT = "an example string"

            SOME_UTILS_CONSTANT = "an example string"
            """
        )


# Generated at 2022-06-12 09:44:56.804308
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 1:
    # Given file content:
    #     FOO = "bar"
    #     VAL = 1
    # Load this file with
    #     load_module_from_file_location("/test-location/test.py")
    # Expect that this file has attributes FOO and VAL
    # and they are equal to "bar" and 1 respectively.
    test_location = "/test-location/test.py"
    with open(test_location, "w") as f:
        f.seek(0)
        f.truncate()
        f.write("FOO = 'bar'\n")
        f.write("VAL = 1\n")
    test_1 = load_module_from_file_location(test_location)

    assert test_1.FOO == "bar"
    assert test_1

# Generated at 2022-06-12 09:45:01.178383
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    os_environ["TEST_ENV_VAR"] = "test"
    module = load_module_from_file_location(
        location="test_config.py",
        package="sanic.config",
        submodule_search_locations=[
            str(Path(__file__).parent.absolute()),
        ],
    )
    assert module.my_config == "my_config"
    assert module.CONFIG_ENABLED is True
    del os.environ["TEST_ENV_VAR"]

# Generated at 2022-06-12 09:45:10.751326
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("sanic.config.DEFAULT_CONFIG")
    assert load_module_from_file_location(
        Path(__file__).parent / "DEFAULT_CONFIG.py"
    ) is DEFAULT_CONFIG
    assert load_module_from_file_location(
        "/" + str(Path(__file__).parent / "DEFAULT_CONFIG.py")
    ) is DEFAULT_CONFIG
    assert load_module_from_file_location(
        "./DEFAULT_CONFIG.py",
        Path(__file__).parent.parent.parent.parent.parent /
        "tests/testing_configs/test_server_config.py"
    ) is None

# Generated at 2022-06-12 09:45:20.061450
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Create temp file config_file.py
    from tempfile import NamedTemporaryFile
    from shutil import rmtree

    # Copy dir in tests/fixtures/config as temporary dir
    from tests.fixtures import CONFIG_DIR
    from tests import TEST_DIR
    import shutil

    tmp_dir = TEST_DIR / "tmp"
    tmp_dir.mkdir()
    shutil.copytree(CONFIG_DIR, tmp_dir)

    tmp_file = NamedTemporaryFile(mode="w+", suffix=".py", dir=tmp_dir)
    tmp_file.write("FOO = 'bar'")
    tmp_file.seek(0)

    mod = load_module_from_file_location(tmp_file.name)
    assert mod.FOO == "bar"

    tmp_file.close()


# Generated at 2022-06-12 09:45:25.273177
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tests.utils import get_test_data_file_name

    file_name = get_test_data_file_name(
        "conf_files/simple_config_file.py"
    )

    loaded_module = load_module_from_file_location(
        file_name, location=file_name
    )
    assert loaded_module.variable_from_config_file == "some_value"

# Generated at 2022-06-12 09:45:33.010081
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    try:
        from contextlib import redirect_stdout
    except ImportError:
        from io import StringIO as DummyStringIO

        @contextmanager
        def redirect_stdout(destination):
            old = sys.stdout
            sys.stdout = destination
            try:
                yield
            finally:
                sys.stdout = old

    # Create tempfile.
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False)
    f.write("foo = 'bar'")
    f.close()

    # Load with function load_module_from_file_location
    config = load_module_from_file_location(f.name)

    assert config.foo == "bar"

    import shutil

    # Now load with regular import

# Generated at 2022-06-12 09:45:42.080441
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil
    cfg_path = Path(tempfile.mkdtemp())


# Generated at 2022-06-12 09:45:51.339942
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import pytest
    import tempfile
    import shutil
    import os

    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write(
            """
            TEST_A = "test"
            TEST_B = "test"
            """
        )
        temp.flush()
        temp.seek(0)
        with open(temp.name, "r") as temp_conf:
            temp_conf_str = temp_conf.read()

        module_from_temp = load_module_from_file_location(temp.name)
        assert temp_conf_str == module_from_temp.__file__

    with tempfile.NamedTemporaryFile(mode="w+") as temp:
        temp.write

# Generated at 2022-06-12 09:46:00.024430
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Loads modules for some test cases."""

    # Try to load a module from a module name.
    assert load_module_from_file_location("subprocess").__name__ == "subprocess"

    # Try to load a module from a file using environment variables.
    os_environ["TEST_ENV_VAR"] = "test"
    module_from_env_var = load_module_from_file_location(
        "test_module_from_env_var",
        Path(__file__).parent / "test_module_from_env_var.py",
    )
    assert module_from_env_var.test_env_var == "test"

    # Try to load a module from a file with path that contains
    # a string in format $some_env_var.

# Generated at 2022-06-12 09:46:14.989746
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from pathlib import Path
    import os
    import pytest

    from sanic.config import Config, load_module_from_file_location

    os.environ["env_var"] = "env_var_vaule"

    with pytest.raises(IOError):
        load_module_from_file_location("this_python_module_does_not_exist")

    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "./tests/test_apps/config_test.py",
            "/this/does/not/exist/${env_var}/config_test.py",
        )


# Generated at 2022-06-12 09:46:24.284729
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import subprocess
    import shutil

    from tempfile import TemporaryDirectory
    from unittest import TestCase

    TEST_ENV_VAR_NAME = "SOME_TEST_ENV_VAR"


# Generated at 2022-06-12 09:46:33.830067
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from sys import getrefcount, modules

    # Test 1:
    # Check if function loads module from file.
    module_name = "test1_module"
    location_before_import = f"{module_name}.py"
    location_after_import = f"/Users/wojciechszklarski/Programowani/python/sanic/aiohttp/{location_before_import}"

    with open(location_before_import, "w") as test_module:
        test_module.write(
            "test_value = 123\n"
            "def test_123():\n"
            "    print(123)\n"
            "class A:\n"
            "    pass"
        )
    module = load_module_from_file_location(location_after_import)

    assert module

# Generated at 2022-06-12 09:46:40.976749
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import gettempdir

    location = Path(gettempdir()) / "temporary_test_config.py"

    config = """
    name = 'test'
    port = 9090
    enabled = True
    extra_data = {'key': 'value'}
    """

    # Create config file
    with open(location, "w") as f:
        f.write(config)

    # Test if loading as string works
    string_module = load_module_from_file_location(str(location))
    assert string_module.name == 'test'
    assert string_module.port == 9090
    assert string_module.enabled is True
    assert string_module.extra_data == {'key': 'value'}

    # Test if loading as pathlib.Path works
    path_module = load_module_

# Generated at 2022-06-12 09:46:51.683519
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ as os_environ
    from os.path import abspath, dirname, join as path_join
    from tempfile import NamedTemporaryFile

    from .helpers import rstring

    with NamedTemporaryFile("a", suffix="py") as test_file:

        # A) Here we use env_var_name as a environment variable,
        #    and as a file name of test file as well.
        env_var_name = rstring()
        test_file.name = env_var_name + ".py"

        env_var_value = rstring()
        os_environ[env_var_name] = env_var_value
        test_file.write(f"test_var = '{env_var_value}'")
        test_file.seek(0)

       

# Generated at 2022-06-12 09:46:59.993509
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sanic

    mod = load_module_from_file_location("os")
    assert mod.__name__ == "os"
    assert mod.path.realpath.__name__ == "realpath"

    mod = load_module_from_file_location(__file__)
    assert mod.__name__ == __name__

    mod = load_module_from_file_location("/etc/services")
    assert mod.__name__ == "services"

    assert (
        load_module_from_file_location("config.py")
        == load_module_from_file_location("config.py")
    )

    assert (
        load_module_from_file_location("config.py")
        != load_module_from_file_location("config.py", cache=False)
    )


# Generated at 2022-06-12 09:47:10.044702
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Tests helper function load_module_from_file_location."""
    import json
    import os
    import tempfile
    import textwrap

    CONFIG = """
    test_key = "test_value"
    """

    with tempfile.NamedTemporaryFile(mode="w", delete=False) as temp:
        temp.write(CONFIG)
        temp_config_file_name = temp.name


# Generated at 2022-06-12 09:47:19.416960
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import io
    import os
    import tempfile

    from copy import deepcopy

    from pytest import raises

    from . import load_module_from_file_location

    # Test for cases when location is just a string.
    # Test for case when location is just a simple string.
    assert load_module_from_file_location(
        "sanic.exceptions"
    ) == import_string("sanic.exceptions")

    # Test for case when location is a path to file, but with no env vars in it.
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as f:
        f.write("test = 1")
        f.flush()
        assert load_module_from_file_location(f.name).test == 1

    # Test for case when location is a path to

# Generated at 2022-06-12 09:47:28.645056
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from unittest import TestCase, mock

    here = Path(__file__).parent
    config_file_name = here / "config_file"
    config_file_name_wrong = here / "config_file_wrong"
    config_file_name_not_exists = here / "config_file_not_exists"

    with mock.patch("os.environ") as mock_env:
        mock_env.update(
            {
                "some_env_var": "some_value",
                "another_env_var": "another_value",
            }
        )
        mock_env.clear()
        mock_env.update({"some_env_var": "some_value"})
        mock_env.clear()

# Generated at 2022-06-12 09:47:37.470452
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for load_module_from_file_location.

    Marks:
    - Test custom module loader.
    - Test json config loader.
    - Test yaml config loader.
    - Test env variable loading.
    """

    # Test custom module loader.
    loaded_module = load_module_from_file_location("tests/config_for_testing.py")
    assert loaded_module.TEST_CONFIG_VARIABLE == "TEST VALUE"

    # Test json config loader.
    loaded_module = load_module_from_file_location("tests/config_for_testing.json")
    assert loaded_module["TEST_CONFIG_VARIABLE"] == "TEST VALUE"

    # Test yaml config loader.

# Generated at 2022-06-12 09:47:52.914688
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import remove
    from os import environ
    from pathlib import Path
    from types import ModuleType

    def create_temp_file(path: str, content: str = "") -> Path:
        dir_path = Path(path).parent
        dir_path.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf8") as f:
            f.write(content)
        return Path(path)

    with TemporaryDirectory(prefix="test_load_module_from_file_location") as tmp:
        file_path = str(Path(tmp) / "test.py")
        conf_file = create_temp_file(file_path, "some_content")

        # Check if it throws FileNotFoundError if provided file does not exists.

# Generated at 2022-06-12 09:48:00.293373
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Tests load_module_from_file_location function."""

    # 1. Check if function raises exception if path is not provided.
    with pytest.raises(TypeError):
        load_module_from_file_location()

    # 2. Check if function raises exception when path with invalid
    #    type provided.
    with pytest.raises(ValueError):
        load_module_from_file_location(0)

    # 3. Check if function raises exception when path does not exist.
    with pytest.raises(FileNotFoundError) as excinfo:
        load_module_from_file_location("/path/to/non_existent/file")
    assert "Unable to load configuration file" == str(excinfo.value)

    # 4. Check if function raises exception when path is a directory.