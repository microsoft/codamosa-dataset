

# Generated at 2022-06-12 09:38:03.634382
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("on") is True
    assert str_to_bool("true") is True
    assert str_to_bool("1") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("t") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("no") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("0") is False
    assert str_to_bool("n") is False
    assert str_to_bool("f") is False
    assert str

# Generated at 2022-06-12 09:38:11.935492
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("YEP") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("TruE") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("N") is False
    assert str_to_bool("NO") is False
    assert str_to_bool("f") is False
    assert str_to_bool("FaLsE") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable")

# Generated at 2022-06-12 09:38:17.394392
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Location is of a bytes type.
    from sanic.config import load_module_from_file_location
    from os import path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdirname:
        tmpdir_path = Path(tmpdirname)

# Generated at 2022-06-12 09:38:19.981853
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    location = "tests/test_files/test_load_module_from_file_location.py"

    module = load_module_from_file_location(location)

    assert module.a == 1



# Generated at 2022-06-12 09:38:26.099386
# Unit test for function str_to_bool
def test_str_to_bool():
    for val in {
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    }:
        assert str_to_bool(val) is True
    for val in {
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    }:
        assert str_to_bool(val) is False

# Generated at 2022-06-12 09:38:36.479968
# Unit test for function str_to_bool
def test_str_to_bool():
    # Convertion of string to bool
    assert str_to_bool("y") == True
    assert str_to_bool("0") == False
    assert str_to_bool("n") == False
    assert str_to_bool("1") == True
    assert str_to_bool("t") == True
    assert str_to_bool("f") == False
    # Convertion of string with space to bool
    assert str_to_bool(" yes ") == True
    assert str_to_bool(" false ") == False
    # Convertion of string with mixed case to bool
    assert str_to_bool("FALSE") == False
    assert str_to_bool("NO") == False
    assert str_to_bool("Yes") == True
    # Convertion of string with wrong value

# Generated at 2022-06-12 09:38:45.133921
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-12 09:38:55.653188
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("t") == True
    assert str_to_bool("f") == False
    assert str_to_bool("yes") == True
    assert str_to_bool("no") == False
    assert str_to_bool("true") == True
    assert str_to_bool("false") == False
    assert str_to_bool("on") == True
    assert str_to_bool("off") == False
    assert str_to_bool("enable") == True
    assert str_to_bool("disable") == False
    assert str_to_bool("enabled") == True
    assert str_to_bool("disabled") == False
    assert str_to_bool("1") == True
    assert str_

# Generated at 2022-06-12 09:39:04.962933
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_ENV_VAR"] = "test_env_var_value"
    os_environ["TEST_ENV_VAR_2"] = "test_env_var_value_2"
    os_environ["TEST_ENV_VAR_3"] = "test_env_var_value_3"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    assert set(re_findall(r"\${(.+?)}", "/${some_env_var}/path")) == {"some_env_var"}
    assert set(re_findall(r"\${(.+?)}", "${some_env_var}/path")) == {"some_env_var"}

# Generated at 2022-06-12 09:39:13.416558
# Unit test for function str_to_bool
def test_str_to_bool():
    import pytest

    #  Truth positive
    #
    # yup, yes, yep, y, t, true, on, enable, enabled
    assert str_to_bool(val="yup") is True
    assert str_to_bool(val="yes") is True
    assert str_to_bool(val="yep") is True  # (from french "oui")
    assert str_to_bool(val="y") is True
    assert str_to_bool(val="t") is True
    assert str_to_bool(val="true") is True
    assert str_to_bool(val="on") is True
    assert str_to_bool(val="enable") is True
    assert str_to_bool(val="enabled") is True

    #  Truth negative
    #
    # no, n, f,

# Generated at 2022-06-12 09:39:24.484449
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import os
    from os import path
    from shutil import rmtree
    from tempfile import mkdtemp

    test_dir = mkdtemp()

    from tests.fixtures.configs import config  # noqa


# Generated at 2022-06-12 09:39:32.527464
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_string_test_module_path = Path(__file__).parent / "test_module.py"
    # A)
    # 1) Import module from string
    test_module = load_module_from_file_location(
        import_string_test_module_path
    )
    assert test_module is not None
    assert test_module.__file__ == str(import_string_test_module_path)
    assert test_module.v1 == 1
    assert test_module.v2 == "2"
    # 2) Import module from Path
    test_module = load_module_from_file_location(
        import_string_test_module_path
    )
    assert test_module is not None
    assert test_module.__file__ == str(import_string_test_module_path)
   

# Generated at 2022-06-12 09:39:42.225065
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Verifying behaviour of load_module_from_file_location."""
    from . import test_config_file

    file_location = test_config_file.__file__
    loaded_module = load_module_from_file_location(file_location)
    assert loaded_module.TEST_VARIABLE == "Config file for testing purposes"

    # Test for environment variables resolving
    os_environ["SOME_ENV_VAR_FOR_TESTS"] = "config_files"
    file_location = Path("${SOME_ENV_VAR_FOR_TESTS}") / "test_config_file.py"
    loaded_module = load_module_from_file_location(file_location)
    assert loaded_module.TEST_VARIABLE == "Config file for testing purposes"
   

# Generated at 2022-06-12 09:39:50.009287
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    os_environ["SANIC_TEST_CONFIG_VAR_1"] = "test_env_var_1"
    os_environ["SANIC_TEST_CONFIG_VAR_2"] = "test_env_var_2"
    os_environ["SANIC_TEST_CONFIG_VAR_3"] = "test_env_var_3"

    tmp_dir = Path(tempfile.mkdtemp())

    Path(tmp_dir / "test.py").touch()
    os.chmod(str(tmp_dir / "test.py"), 0o777)

    Path(tmp_dir / "test_not_a_module.json").touch()

# Generated at 2022-06-12 09:39:59.440607
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 1. When we provide a string path to file.
    os_environ["TEST_ENV_VAR1"] = "1"
    os_environ["TEST_ENV_VAR2"] = "2"
    location = '${TEST_ENV_VAR1}/${TEST_ENV_VAR2}/some_path/some_file.py'
    loaded_module = load_module_from_file_location(location)
    assert hasattr(
        loaded_module, "test_module_attribute"
    ), "module has not test_module_attribute"
    del os_environ["TEST_ENV_VAR1"]
    del os_environ["TEST_ENV_VAR2"]

    # 2. When we provide a string path to folder.
    location = f

# Generated at 2022-06-12 09:40:07.154763
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest

    # TODO:
    #   - Test load file that doesn't exist.

    # Test that load file without environment variable substitution
    simple_file_path = Path(__file__).parent.parent / "tests" / "test_config.py"
    assert simple_file_path == load_module_from_file_location(simple_file_path).__file__  # noqa: E501

    # Test that load file with environment variable substitution
    environment_variables = {
        "some_env_var": str(Path(__file__).parent.parent),
        "file_name": "test_config.py",
    }

    os_environ.update(environment_variables)


# Generated at 2022-06-12 09:40:14.584808
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from random import sample
    from string import ascii_lowercase

    import os
    import tempfile

    from hypothesis import given
    from hypothesis.strategies import text

    from hypothesis.extra.pytestplugin import hyp_pathlib_strategy

    @given(
        file_location=text(),
        location_args=text(),
        location_kwargs=text(),
        encoding=text(),
    )
    def test_location_as_string(
        file_location, location_args, location_kwargs, encoding
    ):
        if file_location.startswith("/"):
            try:
                module = load_module_from_file_location(
                    file_location, encoding, location_args, location_kwargs
                )
            except Exception:
                pass

# Generated at 2022-06-12 09:40:23.900336
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A)
    try:
        load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var}",
        )
    except LoadFileException as e:
        assert "The following environment variables" in str(e)
        assert "some_env_var" in str(e)
    else:
        raise AssertionError("Exception should be raised.")

    # B)
    with tempfile.TemporaryDirectory() as dirpath:
        file_content = "A = 23"
        filepath = Path(dirpath, "config.py")
        filepath.write_text(file_content)

        module = load_module_from_file_location(filepath)
        assert module.A == 23

        del sys.modules["config"]

# Generated at 2022-06-12 09:40:31.575327
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from .test_utils import IS_APPVEYOR

    # Unit tests for function load_module_from_file_location
    # Check if it can accept as a location argument:
    # - single string;
    string_with_env_var_example = load_module_from_file_location(
        "sanic.helpers.test_helpers.string_example"
    )
    assert hasattr(string_with_env_var_example, "__file__")
    assert string_with_env_var_example.__file__ == "string_example"
    assert hasattr(string_with_env_var_example, "TEST_VAR")
    assert string_with_env_var_example.TEST_VAR == "TEST"

    # - pathlib.Path object
    path_example = load_module

# Generated at 2022-06-12 09:40:37.424006
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # 1. Test loading module from string path - basic case
    os_environ["SOME_ENV_VAR"] = "some_path"
    location = "/some/path/${SOME_ENV_VAR}"
    module = load_module_from_file_location(location)
    assert module.__file__ == os_environ["SOME_ENV_VAR"]
    del os_environ["SOME_ENV_VAR"]

    # 2. Test loading module from string path with invalid environment variable
    location = "/some/path/${SOME_ENV_VAR}"
    try:
        module = load_module_from_file_location(location)
    except LoadFileException:
        pass
    else:
        assert False, "The following environment variable is not set"

    # 3. Test module

# Generated at 2022-06-12 09:40:44.718362
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(__file__, "utf8")

    assert load_module_from_file_location(Path(__file__))

    if "HOME" in os_environ:

        assert load_module_from_file_location("$HOME/init_func.py")

        assert load_module_from_file_location(
            "sanic.helpers_tests.init_func.py"
        )



# Generated at 2022-06-12 09:40:54.459674
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D103

    from tempfile import mkstemp

    import_string = load_module_from_file_location  # for tests readability

    # Try to import non-existing file.
    try:
        import_string(bytes(__file__.encode() + b"1"), __file__)
    except IOError as e:
        assert e.strerror == "Unable to load configuration file (e.strerror)"
    else:
        raise RuntimeError

    # Try to import non-existing file with a custom message.
    try:
        import_string(bytes(__file__.encode() + b"2"), __file__, e_msg="custom")
    except IOError as e:
        assert e.strerror == "Unable to load configuration file (custom)"
    else:
        raise Runtime

# Generated at 2022-06-12 09:41:04.263261
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile
    import os

    def test_load_module_from_file_location_with_env_vars(
        module_name, module_contents, env_vars_in_location
    ):  # noqa
        with tempfile.NamedTemporaryFile(mode="w+t") as module_file:
            module_file.write(module_contents)
            module_file.seek(0)
            os.environ[env_vars_in_location[0]] = module_file.name

            module = load_module_from_file_location(
                module_name, "${" + env_vars_in_location[0] + "}"
            )


# Generated at 2022-06-12 09:41:13.762759
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tests.test_utils.test_app as test_app

    assert load_module_from_file_location(
        "tests.test_utils.test_app", "tests/test_utils/test_app.py"
    ) == test_app

    assert (
        load_module_from_file_location("tests.test_utils.test_app") == test_app
    )

    # Test env_variables substitution
    os_environ["SANIC_TEST_VARIABLE_1"] = "some_string"
    os_environ["SANIC_TEST_VARIABLE_2"] = "tests/test_utils/test_app.py"


# Generated at 2022-06-12 09:41:23.191514
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path

    conf_name = "some_file"
    location = Path(__file__).parent.resolve().joinpath(
        "test_config_files/{}.py".format(conf_name)
    )

    config_module = load_module_from_file_location(location)
    assert config_module.some_list == [1, 2, 3]
    assert config_module.some_dict == {"key": "value"}

    conf_name = "some_file"
    location = "{}/test_config_files/{}.py".format(
        Path(__file__).parent.resolve(), conf_name
    )

    config_module = load_module_from_file_location(location)
    assert config_module.some_list == [1, 2, 3]
    assert config

# Generated at 2022-06-12 09:41:32.425305
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # A) Module given as string.
    module_as_string = load_module_from_file_location(
        "tests.test_helpers.fake_module"
    )
    assert module_as_string.some_string == "some_string"

    # B) Module given as a file path.
    module_as_file_path = load_module_from_file_location(
        "tests/test_helpers/fake_module.py"
    )
    assert module_as_file_path.some_string == "some_string"

    # C) Module given as a file path that
    #    contains environment variable
    #    in format ${VARIABLE_NAME}.

    # D) Case C) - Environment variable was defined.

# Generated at 2022-06-12 09:41:42.992296
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    fake_value = 15

    test_env_variable_name = "SANIC_TEST_ENV_VARIABLE"
    fake_env_variable = "sanic_test_env_variable_value"

    os.environ[test_env_variable_name] = fake_env_variable

    test_file_name = "test_config_file.json"

    with tempfile.NamedTemporaryFile(mode="w") as test_file:
        test_file.write(
            '{"test_config_key": "test_config_value"}'
        )

        test_file.seek(0)

        test_file_path = Path(test_file.name)


# Generated at 2022-06-12 09:41:50.467134
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test that load_module_from_file_location imports config,
    parses environment variables and raises errors correctly."""
    # A) Check that it returns the same module as import_string.
    module_location = "/some/module/location/module.py"
    some_module = types.ModuleType("some_module")
    module_imported_by_sanic = load_module_from_file_location(
        module_location
    )
    import_string = import_string(module_location)
    assert module_imported_by_sanic == import_string

    # B) Check if it parses environment variables.
    assert getattr(
        load_module_from_file_location("/some/path/${SOME_ENV_VAR}"),
        "__file__",
    ) == os_environ

# Generated at 2022-06-12 09:41:59.853381
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Can use string or bytes object
    load_module_from_file_location(
        "sanic.sanic.__init__", __file__, "utf8"
    )
    load_module_from_file_location(b"sanic.sanic.__init__", __file__, "utf8")

    # Can use environment variables in path
    os_environ["SANIC_TEST_PATH"] = "./sanic/sanic/__init__.py"
    load_module_from_file_location(
        "sanic.sanic.__init__", "${SANIC_TEST_PATH}", "utf8"
    )
    load_module_from_file_location(b"sanic.sanic.__init__", b"${SANIC_TEST_PATH}", "utf8")


# Generated at 2022-06-12 09:42:03.575783
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_file_path = str(Path(__file__).parent / "test_config.py")
    module = load_module_from_file_location(test_file_path)
    assert module.test_test_test == "this is just for test"


# Generated at 2022-06-12 09:42:16.203353
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import shutil
    import random
    import string

    def random_string(length: int) -> str:
        return "".join(
            random.choice(string.ascii_uppercase + string.digits)
            for _ in range(length)
        )

    tempdir = tempfile.mkdtemp()
    # test loading existing file
    file_to_load = "temp_file"
    file_path = os.path.join(tempdir, file_to_load + ".py")
    with open(file_path, "w") as temp_file:
        temp_file.write(
            "def test_func():\n"
            "    return 'some'\n"
            "\n"
            "test_func()\n"
        )

# Generated at 2022-06-12 09:42:22.239575
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    tempdir = tempfile.mkdtemp()
    # 1) Check module loaded by importlib.util.spec_from_file_location
    some_file = os.path.join(tempdir, "some_file.py")
    with open(some_file, "w") as sf:
        sf.write("CONFIGURATION = 1")

    some_module = load_module_from_file_location(some_file)

    assert some_module.CONFIGURATION == 1

    # 2) Check module loaded by exec
    some_file = os.path.join(tempdir, "some_file")
    with open(some_file, "w") as sf:
        sf.write("CONFIGURATION = 2")

    some_module = load_

# Generated at 2022-06-12 09:42:28.098382
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    os_environ["CONFIG_PATH"] = "/path/to/config.py"

    module = load_module_from_file_location(
        "config", "/path/to/${CONFIG_PATH}", "utf8"
    )

    assert module
    assert module.__file__ == "/path/to/config.py"
    assert module.TEST_CONFIG_VARIABLE == "test"

# Generated at 2022-06-12 09:42:32.424361
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ.setdefault("SANIC_APPLICATION_SETTINGS", "test.settings")

    import_string(
        "sanic.config.load_module_from_file_location( "
        """
            "sanic.config.str_to_bool",
            "${SANIC_APPLICATION_SETTINGS}"
        """
    )

    from . import load_module_from_file_location
    from . import str_to_bool

    # Test case 1.
    load_module_from_file_location(
        "sanic.config.load_module_from_file_location",
        "${SANIC_APPLICATION_SETTINGS}",
    )

# Generated at 2022-06-12 09:42:37.133905
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests if load_module_from_file_location returns module as expected.

    In order to test it we need to simulate some work with module, so
    we will test if returned module has function 'fibonacci' and
    if it returns correct results."""

    # Test if load_module_from_file_location returns expected module
    module = load_module_from_file_location(
        "tests/test_configs/config.py"
    )
    # Test if it returns module with actual module's name
    assert module.__name__ == "tests.test_configs.config"

    # Test if module has function 'fibonacci'
    assert hasattr(module, "fibonacci")
    # Test if function 'fibonacci' returns expected result

# Generated at 2022-06-12 09:42:43.770528
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import pytest
    import tempfile
    with tempfile.TemporaryDirectory() as tmp_folder:
        tmp_folder = Path(tmp_folder)

        # 1) File path as a string.
        conf_file = tmp_folder / "conf.py"
        with conf_file.open("w") as fp:
            fp.write("a=123")

        conf_module = load_module_from_file_location(str(conf_file))
        assert conf_module.a == 123

        # 2) File path as Path object.
        conf_file = tmp_folder / "conf.py"
        with conf_file.open("w") as fp:
            fp.write("a=123")

        conf_module = load_module_from_file_location(conf_file)

# Generated at 2022-06-12 09:42:50.377578
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(
        "/home/some/path/to/file.py",
    ) is not None
    assert (
        load_module_from_file_location(
            "/home/some/path/${some_env_var}/file.py",
        )
        is not None
    )
    assert (
        load_module_from_file_location(
            "/home/some/path${some_env_var}/file.py",
        )
        is not None
    )
    assert (
        load_module_from_file_location(
            "/home/some path/${some_env_var}/file.py",
        )
        is not None
    )

# Generated at 2022-06-12 09:42:58.321139
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    os.environ["test_load_module_from_file_location_1"] = "test"
    assert os.environ["test_load_module_from_file_location_1"] == "test"

    path = tempfile.TemporaryDirectory()
    path = path.name

    with open(f"{path}/test_load_module_from_file_location_1.py", "w") as f:
        f.write("")

    with open(f"{path}/test_load_module_from_file_location_2.py", "w") as f:
        f.write("AA=")


# Generated at 2022-06-12 09:43:06.725176
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os
    import tempfile

    path = os.path.join(
        os.path.dirname(__file__), "../../../tests/test_load.py"
    )

    module = load_module_from_file_location(path)
    assert module.foo == "bar"

    with tempfile.TemporaryDirectory() as directory:
        with open(os.path.join(directory, "foo.py"), "w+") as f:
            f.write("foo = 'bar'\n")

        path = os.path.join(directory, "foo.py")

        module = load_module_from_file_location(Path(path))
        assert module.foo == "bar"


# Generated at 2022-06-12 09:43:13.925816
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import_string("module:string")
    assert load_module_from_file_location("module:string") is not None

    assert load_module_from_file_location("module:string") is not None

    assert load_module_from_file_location("module:string").string

    assert load_module_from_file_location("module:string").string == "string"

    assert (
        load_module_from_file_location(
            "/some_path/some_file_location.py"
        ) is not None
    )

    assert (
        load_module_from_file_location(
            "/some_path/some_file_location.py"
        ).some_file_location is not None
    )


# Generated at 2022-06-12 09:43:27.762014
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Tests function load_module_from_file_location."""

# Generated at 2022-06-12 09:43:36.357381
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile  # noqa

    # A) Test import from string
    from sanic.config import LOGGING as test_variable_LOGGING  # noqa
    assert load_module_from_file_location("sanic.config").LOGGING == test_variable_LOGGING  # noqa

    # B) Test import from bytes
    assert load_module_from_file_location(b"sanic.config").LOGGING == test_variable_LOGGING  # noqa

    # C) Test import from environment variables
    with NamedTemporaryFile() as temp_file:
        temp_file.write(b"var = 1")
        temp_file.seek(0)

        assert load_module_from_file_location("${PWD}" + temp_file.name).var == 1  # no

# Generated at 2022-06-12 09:43:42.372039
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from .test_config import (  # noqa: F401
        _config_file_1,
        _config_file_2,
        _config_file_3,
        _config_file_4,
        _config_file_5,
        _config_file_6,
        _config_file_7,
        _config_file_8,
        _config_file_9,
        _config_file_10,
    )

    os_environ["HOST"] = "localhost"
    os_environ["PORT"] = "8000"

    # A) Test file as path
    assert (
        load_module_from_file_location(_config_file_1)
        .SERVER_NAME == "localhost"
    )

# Generated at 2022-06-12 09:43:51.970335
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    _tmp_dir = tempfile.TemporaryDirectory(prefix="sanic_")
    os.environ["some_env_var"] = _tmp_dir.name
    _tmp_file_path = os.path.join(
        _tmp_dir.name, "some_tmp_file.py"
    )  # path with environment variable


# Generated at 2022-06-12 09:43:59.885876
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import subprocess
    import sys
    import tempfile

    if sys.version_info < (3, 7):
        import pytest
        import warnings

        warnings.warn(
            "Unit tests for function load_module_from_file_location "
            "are currently not supported for versions below Python 3.7"
        )
        pytest.skip("No support for versions below Python 3.7", allow_module_level=True) # noqa

    # Simple test
    some_file = "some_file.py"
    with open(some_file, 'w') as f:
        f.write("import logging\n")
        f.write("LOG_LEVEL = logging.DEBUG")

    loaded_module = load_module_from_file_location(some_file)
    assert loaded_module.LOG_LEVEL == logging.DEBUG

# Generated at 2022-06-12 09:44:05.602988
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_name = 'sanic.config'
    file_path = Path(__file__).parent / 'config.py'
    module = load_module_from_file_location(file_path)
    assert getattr(module, 'name') == 'hahahah'
    assert getattr(module, 'module') == import_name
    assert getattr(module, 'k') ==10
    

# Generated at 2022-06-12 09:44:13.387583
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A)
    # tests if function can load some module from file location
    # which has .py extension
    module = load_module_from_file_location(
        "sanic.__main__", "./sanic/__main__.py"
    )

    assert module.__name__ == "sanic.__main__"

    # B)
    # tests if function can load some module from file location
    # which has no .py extension
    module = load_module_from_file_location(
        "some_module", "./tests/modules_for_testing/some_module"
    )

    assert module.__name__ == "some_module"


# Generated at 2022-06-12 09:44:21.079270
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile

    # load_module_from_file_location using Path object as location.
    cwd = Path(os.getcwd())
    mod = load_module_from_file_location(cwd / "test_config.py")
    assert mod.TEST_CONFIG_VARIABLE == "test_config_value"

    # load_module_from_file_location using str object as location.
    mod = load_module_from_file_location("test_config.py")
    assert mod.TEST_CONFIG_VARIABLE == "test_config_value"

    # load_module_from_file_location using str_object with invalid path.

# Generated at 2022-06-12 09:44:30.548698
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    tmp_dir = tempfile.gettempdir()
    tmp_file = Path(tmp_dir) / "temp_sanic_config.py"

    with open(tmp_file, "w") as tf:
        tf.write("CONFIG_VAR = 1")

    os_environ["SOME_ENV_VAR"] = "some_env_value"
    try:
        mod = load_module_from_file_location(
            "test_temp_sanic_config.py",
            tmp_dir + "/${SOME_ENV_VAR}/temp_sanic_config.py",
        )
        assert mod.CONFIG_VAR == 1
    finally:
        tmp_file.unlink()



# Generated at 2022-06-12 09:44:39.760714
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # Test 1:
    # Test if function works with alternative file location path.
    location = "sanic/config.py"
    try:
        load_module_from_file_location(location)
    except IOError:
        # Test failed.
        return False
    # Test passed.
    return True

    # Test 2:
    # Test if function properly works with environment variables
    # in format ${some_env_var}.
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Set well known environment variable.
        temporary_env_variable_value = f"{tmpdirname}/test.py"
        os_environ["TEST"] = temporary_env_variable_value
        # Set test variable in this variable.
        temporary_test_variable = "temporary_test_variable"


# Generated at 2022-06-12 09:44:53.972860
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover
    from os import environ as os_environ
    from os import makedirs
    from os import rmdir
    from pathlib import Path
    from shutil import rmtree
    from tempfile import mkdtemp

    def remove_if_exists(path):  # pragma: no cover
        if path.exists():
            if path.is_dir():
                rmtree(path)
            else:
                path.unlink()

    def write_to_file(path, text):  # pragma: no cover
        with open(path, "w") as f:
            f.write(text)

    def set_environ(**environ):  # pragma: no cover
        for key, value in environ.items():
            os_environ[key] = value

   

# Generated at 2022-06-12 09:45:02.177065
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_path = Path(__file__).parent / "test_utils_load_module_from_file.py"
    module = load_module_from_file_location(test_path)
    assert module.__file__ == str(test_path)
    assert module.test_str == "test_str"

    test_path = Path(__file__).parent / "test_utils_load_module_from_file.json"
    module = load_module_from_file_location(test_path)
    assert module.__file__ == str(test_path)
    assert module.test_dict["test_key"] == "test_value"

    test_path = "/tmp/test_utils_load_module_from_file.py"
    module = load_module_from_file_location(test_path)
   

# Generated at 2022-06-12 09:45:12.254169
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Given
    from . import test_config
    not_existing_mod_name = "not_existing_module"
    existing_mod_name = "config"
    not_existing_mod_path = (
        Path(test_config.__file__)
        .parent / "not_existing_file.py"
        .relative_to(Path.cwd())
    )
    existing_mod_path = Path(test_config.__file__).relative_to(Path.cwd())
    existing_mod_path_in_env_var = str(
        existing_mod_path.as_posix().replace(
            "config.py", f"${test_config.test_env_var}/config.py"
        )
    )

# Generated at 2022-06-12 09:45:21.341941
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = Path(__file__).parent.parent.parent / "tests" / "fixtures" / "app.py"
    module = load_module_from_file_location(path)
    assert module.foo == 1
    assert module.bar == 2

    path = (
        Path(__file__)
        .parent.parent.parent
        .parent.parent
        / "tests"
        / "fixtures"
        / ".."
        / "tests"
        / "fixtures"
        / "app.py"
    )
    module = load_module_from_file_location(str(path))
    assert module.foo == 1
    assert module.bar == 2

    path = __file__.replace(".py", ".pyc")
    module = load_module_from_file_location(path)


# Generated at 2022-06-12 09:45:30.490419
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unitest for the load_module_from_file_location function."""

    import tempfile
    from os import environ as os_environ
    from os import remove as os_remove
    from os import mkdir as os_mkdir

    # Create temp config file.
    tconfig = tempfile.mktemp(prefix="sanic_", suffix=".py")
    with open(tconfig, "w") as f:
        f.write("test_python_config: 1234")

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    try:
        load_module_from_file_location(
            tconfig, "test_python_config_name"
        )
    except LoadFileException:
        pass

# Generated at 2022-06-12 09:45:39.772736
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # A) Using locations that are not existing on filesystem.
    #    For example:
    #        "some_module_name"
    #        "package.some_module_name"
    #        "/some/path"
    #        "/some/path/some_module_name"
    #    Should rise ValueError from import_string function.
    with pytest.raises(ValueError):
        load_module_from_file_location("some_module_name")
    with pytest.raises(ValueError):
        load_module_from_file_location("package.some_module_name")
    with pytest.raises(ValueError):
        load_module_from_file_location("/some/path")
    with pytest.raises(ValueError):
        load_module_from_file_

# Generated at 2022-06-12 09:45:48.856761
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(
        __file__.replace(".py", ".json")
    ).__dict__.copy() == {
        "some": "json",
        "__name__": "config",
        "__file__": __file__.replace(".py", ".json"),
    }

    assert load_module_from_file_location(
        __file__.replace(".py", ".yml")
    ).__dict__.copy() == {
        "some": "yaml",
        "__name__": "config",
        "__file__": __file__.replace(".py", ".yml"),
    }

    env_var = "SOME_ENV_VAR_VALUE"
    os_environ["SOME_ENV_VAR_KEY"] = env_var


# Generated at 2022-06-12 09:45:57.773208
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    set_up = """
from sanic.config import load_module_from_file_location

config_file = """
    os_environ = {}
    tear_down = """
    import os
    for key in os_environ.keys():
        del os.environ[key]
    """

# Generated at 2022-06-12 09:46:04.525127
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Define some environment variables.
    os_environ["SOME_ENV_VAR"] = "is_defined"
    os_environ["SOME_ENV_VAR_FROM_FILE"] = "is_defined_from_file"

    # A) Create module_a with some imports
    module_a = load_module_from_file_location(
        "module_a",
        str(Path(__file__).parent / "data" / "load_module_a.py"),
    )
    assert module_a.a == 1
    assert module_a.b == "a"
    assert module_a.c == "a/b"
    assert module_a.d == "a/b/c/d"

    # B) Create module_b with some environment variables
    module_b = load_

# Generated at 2022-06-12 09:46:09.679870
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    try:
        load_module_from_file_location(
            "/some/path/${some_env_var}", "/some/path/${some_env_var}"
        )
    except LoadFileException as e:
        assert "The following environment variables are not set: some_env_var" in str(e)

    assert load_module_from_file_location("sanic.app")
    assert load_module_from_file_location("sanic.app:app")

# Generated at 2022-06-12 09:46:21.646064
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from tempfile import mkdtemp
    import os

    # STEP 0 - Prepare environment.
    # Write some config file.
    temp_dir = mkdtemp()
    with open(os.path.join(temp_dir, "config.py"), "w") as f:
        f.write("CONFIG = 'TEST CONFIG'")

    # STEP 1 - Test bytes location parameter.
    location_bytes = os.path.join(temp_dir, "config.py").encod

# Generated at 2022-06-12 09:46:28.396328
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ, getcwd
    from os.path import dirname as path_dirname, join as path_join

    # Create new module
    with open(
        path_join(
            getcwd(),
            "dummy_load_module_from_file_location.py",
        ),
        "w",
    ) as file:
        file.write("some_var = 'abc'")

    # Import that module the way it would be imported
    with open(  # nosec
        path_join(
            getcwd(),
            "dummy_load_module_from_file_location.py",
        ),
        "r",
    ) as file:
        dummy_module = types.ModuleType("dummy_test_load_module")

# Generated at 2022-06-12 09:46:38.143054
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os.path

    import pytest

    from tests._test_utils.config import get_default_config_location

    config_location = get_default_config_location()

    # Check if it takes Path type
    config_location_as_path = Path(config_location)
    assert os.path.samefile(
        load_module_from_file_location(
            config_location_as_path
        ).__file__,
        config_location,
    )

    # Check if it takes bytes type and decodes it into string
    config_location_as_bytes = config_location.encode("utf8")
    assert os.path.samefile(
        load_module_from_file_location(
            config_location_as_bytes
        ).__file__,
        config_location,
    )
    #

# Generated at 2022-06-12 09:46:45.089991
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # make a simple INI style file
    config_file_location = "test_load_module_from_file_location.ini"
    config_file_content = """
[section_one]
var_one = "value_one"
var_two = "value_two"
"""
    with open(config_file_location, "w") as config_file:
        config_file.write(config_file_content)

    module = load_module_from_file_location(config_file_location)
    assert module.section_one.var_one == "value_one"
    assert module.section_one.var_two == "value_two"



# Generated at 2022-06-12 09:46:55.732301
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function behavior.
    """
    import os.path
    import tempfile
    import unittest

    class TestLoadModuleFromFileLocation(unittest.TestCase):
        # Pylint does not understand @classmethod inheritance
        # pylint: disable=arguments-differ

        def setUp(self):
            self.os_environ_backup = os.environ.copy()

        def tearDown(self):
            os.environ = self.os_environ_backup

        def test_bytes_location(self):
            """Test if load_module_from_file_location function works with
            bytes locations"""

# Generated at 2022-06-12 09:47:02.329841
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) location is of a string type.
    #   1) location is a file path:
    #       a) file type is '.py'
    #       b) file type is not '.py'
    #   2) location is a module name.

    # 1a)
    from os import environ as os_environ

    # A) location is of a bytes type.
    #   1) location is a file path:
    #       a) file type is '.py'
    #       b) file type is not '.py'
    #   2) location is a module name.



# Generated at 2022-06-12 09:47:12.071571
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SANIC_TEST_ENV_VAR"] = "some_value"
    location = "./tests/config_test.py"
    module = load_module_from_file_location(location)
    assert module.TEST_ENV_VAR == "some_value"

    location = "./tests/config_test.py"
    module = load_module_from_file_location(location)
    assert module.TEST_ENV_VAR == "some_value"

    location = "./tests/non_exist_config_test.py"
    with pytest.raises(IOError):
        module = load_module_from_file_location(location)

    location = "./tests/config_test.py"
    module = load_module_from_file_location(location)


# Generated at 2022-06-12 09:47:20.417448
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import logging
    import os
    import tempfile

    with tempfile.NamedTemporaryFile(mode="w+b", name="test_config") as f:
        logging.debug("Created temporary file: %s", f.name)

        # Set-up some env variables
        os.environ["some_env_var"] = "some_val"

        # Write some configuration to it
        f.write(b"some_config = 'some_val'")
        f.seek(0)

        # Load configuration from file via load_module_from_file_location
        mod = load_module_from_file_location(f.name)
        assert mod.some_config == "some_val"

        logging.debug("Deleting temporary file: %s", f.name)
        f.name

# Generated at 2022-06-12 09:47:24.350626
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with TemporaryDirectory() as dir_name:
        with open(os.path.join(dir_name, "config.py"), "w") as file:
            file.write("TEST = True")
        assert load_module_from_file_location(dir_name + "/config.py").TEST

# Generated at 2022-06-12 09:47:33.526188
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""

    class A:
        pass

    class B:
        pass

    # 0. Test module `A` from string.
    module = load_module_from_file_location("A", "os", False)
    assert module is A

    # 1. Test pathlib.Path from string.
    module = load_module_from_file_location(
        "load_module.tests.test_load_module_from_file_location",
        "/some/path/to/load_module.py",
        False,
    )
    assert module is test_load_module_from_file_location

    # 2. Test pathlib.Path from bytes.

# Generated at 2022-06-12 09:47:48.702861
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    print(load_module_from_file_location("abc.py"))


if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-12 09:47:57.492267
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic import Sanic
    from sanic.response import text
    from tempfile import NamedTemporaryFile
    from textwrap import dedent

    APP_NAME = "test_load_module_from_file_location"
    SANIC_CONFIG_MODULE = "config"

    print(
        "*" * 80,
        "NO VALUE FOR ENVIRONMENT VARIABLE SANIC_CONFIG_MODULE",
        "*" * 80,
    )
    # Check when we run app without SANIC_CONFIG_MODULE environment variable set
    app = Sanic(APP_NAME)

    @app.route("/")
    async def test(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.text == "OK"