

# Generated at 2022-06-12 09:38:03.104612
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test for python file with environment variable into path
    some_var = "123"
    assert os_environ.get("SOME_TEST_VAR", None) != some_var
    try:
        os_environ["SOME_TEST_VAR"] = some_var
        assert os_environ["SOME_TEST_VAR"] == some_var
        module = load_module_from_file_location("./tests/test_config")

        assert module.TEST_VAR == "123"

    finally:
        del os_environ["SOME_TEST_VAR"]
        assert os_environ.get("SOME_TEST_VAR", None) != some_var

    # Test for python file without environment variable into path

# Generated at 2022-06-12 09:38:11.499723
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True, "str_to_bool('true') is True"
    assert str_to_bool("False") == False, "str_to_bool('False') is False"
    assert str_to_bool("Y") == True, "str_to_bool('Y') is True"
    assert str_to_bool("n") == False, "str_to_bool('n') is False"
    assert str_to_bool("N") == False, "str_to_bool('N') is False"
    assert str_to_bool("OFF") == False, "str_to_bool('OFF') is False"
    assert str_to_bool("On") == True, "str_to_bool('On') is True"

# Generated at 2022-06-12 09:38:20.955443
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unit tests for load_module_from_file_location function.

    TODO: Add test for checking that if location is of bytes type
          and encoding differs from utf8, then str_to_bool
          should raise exception."""
    from os import environ
    from os.path import join
    from tempfile import TemporaryDirectory
    from types import ModuleType

    from tempfile import TemporaryDirectory
    from types import ModuleType

    def _check_value_in_module(module: ModuleType, var_name: str, var_value):
        assert hasattr(module, var_name)
        assert getattr(module, var_name) == var_value

    # Test 1

# Generated at 2022-06-12 09:38:28.474681
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")

    assert str_to_bool("Yes")

    assert str_to_bool("Y")

    assert str_to_bool("yep")

    assert str_to_bool("YUP")

    assert str_to_bool("true")

    assert str_to_bool("t")

    assert str_to_bool("True")

    assert str_to_bool("TRUE")

    assert str_to_bool("on")

    assert str_to_bool("enable")

    assert str_to_bool("ENABLED")

    assert str_to_bool("1")

    assert not str_to_bool("n")

    assert not str_to_bool("no")

    assert not str_to_bool("NO")

    assert not str_to_bool("off")


# Generated at 2022-06-12 09:38:39.376568
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test for function load_module_from_file_location."""

    def _load_module(path):
        return load_module_from_file_location(
            path,
            # Without this line py.test will not be able to load this file
            # because it uses relative paths.
            Path(__file__).parent.absolute().__str__() + "/",
        )

    # A) Try:
    #
    #   load_module_from_file_location(
    #       "some_module_name",
    #       "/path/${some_env_var}/some_python_file.py"
    #   )
    #
    # Then:
    #
    #   A1) If some_env_var is not set, the exception LoadFileException
    #       is raisen with message:
   

# Generated at 2022-06-12 09:38:46.517749
# Unit test for function str_to_bool
def test_str_to_bool():
    
    assert str_to_bool("1") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True

    assert str_to_bool("0") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("no") is False
    assert str_to_bool("n") is False
    
    assert str_to_bool("False") is False
    assert str_to_bool("False") is False
    assert str_to_bool("FalSe") is False
    assert str_to_bool("FalSE") is False

# Generated at 2022-06-12 09:38:57.105252
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Test if can load module from pathlib.Path
    some_module = load_module_from_file_location(
        Path(__file__).parent /  # type: ignore
        Path("load_module_from_file_location.py")
    )
    assert some_module.__file__ == str(
        Path(__file__)
        .parent / Path("load_module_from_file_location.py")
    )

    # Test if can load module from str
    some_module = load_module_from_file_location(
        str(
            Path(__file__)
            .parent / Path("load_module_from_file_location.py")
        )
    )

# Generated at 2022-06-12 09:39:06.124605
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("YES")
    assert str_to_bool("yes")
    assert str_to_bool("True")
    assert str_to_bool("1")
    assert str_to_bool("  y")
    assert str_to_bool("  y ")
    assert not str_to_bool("n")
    assert not str_to_bool("   No  ")
    assert not str_to_bool("f")
    assert not str_to_bool("FALSE")
    assert not str_to_bool("false")
    assert not str_to_bool("  0 ")
    assert not str_to_bool("off")
    assert not str_to_bool("OFF")
    assert not str_to_bool("disable")
    assert not str_

# Generated at 2022-06-12 09:39:15.441230
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    with open("_tests/test_config.py", "w") as f:
        f.write("test_config = 42")
    with open("_tests/test_config1.py", "w") as f:
        f.write("test_config1 = 42")

    assert (
        load_module_from_file_location("./_tests/test_config")
        .test_config
        == 42
    )
    assert (
        load_module_from_file_location("./_tests/test_config1")
        .test_config1
        == 42
    )

    conf_path = Path("_tests/test_config.py")
    assert getattr(
        load_module_from_file_location(conf_path), "test_config", None
    ) == 42


# Generated at 2022-06-12 09:39:22.546684
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Given
    import random
    import string

    # We have some random bytes string without non-alphanumeric characters.
    # This string will be encoded with provided encoding and used as location
    # to load module.
    location = random.choice(
        string.ascii_letters + string.digits for _ in range(50)
    )
    location = location.encode()

    # We should get here bytes if we try to encode it with provided
    # encoding.
    assert isinstance(location, bytes) is True

    # When
    module = load_module_from_file_location(location)

    # Then
    assert module.__file__.endswith(".py") is True

# Generated at 2022-06-12 09:39:35.634879
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A)
    location = "/some/path/${some_env_var}/some_file_name.py"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    required_env_vars_in_location = {"some_env_var"}
    assert env_vars_in_location == required_env_vars_in_location
    # B)
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not_defined_env_vars == required_env_vars_in_location
    # C)
    location = "${some_env_var}/some_file_name.py"

# Generated at 2022-06-12 09:39:44.295508
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location(): # noqa
    # simple
    module = load_module_from_file_location(
        """
    test_var = "yep"
    """
    )
    assert module.test_var == "yep"

    # simple with Path
    module = load_module_from_file_location(
        """
    test_var = "yep"
    """,
        Path(__file__),
    )
    assert module.test_var == "yep"

    # simple with Path and args
    module = load_module_from_file_location(
        """
    test_var = "yep"
    """,
        Path(__file__),
        follow_symlinks=True,
    )
    assert module.test_var == "yep"

    # simple with path, args and kwargs
   

# Generated at 2022-06-12 09:39:49.576086
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    my_config = {
        "some": "stuff",
        "other": [1, 2, 3],
    }

    # A) Check if function works with string location provided.
    with tempfile.TemporaryDirectory() as tmp_dirname:
        tmp_filename = os.path.join(tmp_dirname, "test_config.py")
        with open(tmp_filename, "w") as conf_file:
            conf_file.write("config = " + str(my_config))

        some_module = load_module_from_file_location(
            tmp_filename,
            "utf8",
            submodule_search_locations=None,
            follow_imports=True,
        )

        # check if config in the module is the same as my_config
        assert some_module.config == my_config



# Generated at 2022-06-12 09:39:58.912486
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location"""

    module = load_module_from_file_location(
        "test_configs/config.py", "test_configs"
    )
    assert module.HOST == "localhost"
    assert module.PORT == 8001

    module = load_module_from_file_location(
        "test_configs/config.py", "test_configs", "utf8"
    )
    assert module.HOST == "localhost"
    assert module.PORT == 8001

    module = load_module_from_file_location(
        "test_configs/config.py", "test_configs", encoding="utf8"
    )
    assert module.HOST == "localhost"
    assert module.PORT == 8001

    module = load_module_from_file_

# Generated at 2022-06-12 09:40:03.928610
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ['ENV_VAR_FOR_TEST'] = 'test'
    module = load_module_from_file_location(
        'tests/integration/test_module_from_path.py',
        '/some/path/${ENV_VAR_FOR_TEST}'
    )

    assert hasattr(module, 'test')
    assert module.test == 'test'

# Generated at 2022-06-12 09:40:12.292471
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test load_module_from_file_location with environment variables
    os_environ["TEST_ENV_VAR"] = "test_env_var_value"
    module = load_module_from_file_location(
        "${TEST_ENV_VAR}/test_name",
        "tests/fixtures/config_with_env_vars.py",
    )
    assert module.TEST_VARIABLE == 1
    del os_environ["TEST_ENV_VAR"]
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "${TEST_ENV_VAR}/test_name",
            "tests/fixtures/config_with_env_vars.py",
        )

    # Test load_module_

# Generated at 2022-06-12 09:40:16.200789
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location(
            Path("example.py"), Path(".").resolve()
        ).FOO
        == "bar"
    )
    assert (
        load_module_from_file_location("example.py", Path(".").resolve()).FOO
        == "bar"
    )

# Generated at 2022-06-12 09:40:25.516348
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from os import remove
    from os import mkdir
    from tempfile import gettempdir
    from textwrap import dedent

    module_name = "some_module"
    module_string = """
    some_string = "Hello world!"
    some_integer = 8
    some_boolean = False
    """


# Generated at 2022-06-12 09:40:32.798473
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    fname = "test_config_file.py"
    test_config_file_path = (
        Path(__file__).parent / "test_config_files" / fname
    )
    test_config_file_path.touch()
    test_config_file_json_path = (
        Path(__file__).parent / "test_config_files" / "test_config_file.json"
    )
    test_config_file_json_path.touch()
    test_config_file_json_path_without_extension = (
        Path(__file__).parent / "test_config_files" / "test_config_file"
    )
    test_config_file_json_path_without_extension.touch()

# Generated at 2022-06-12 09:40:38.404333
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""

    try:
        import example
    except ModuleNotFoundError:
        return

    # Environment variables {{{1
    os_environ["SOME_VAR"] = "test"
    os_environ["SOME_OTHER_VAR"] = "other_test"

    # With string {{{1

# Generated at 2022-06-12 09:40:51.533071
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # TODO: Think if we should test bytes location encoding here,
    #       I think it is more a job for unit test for
    #       importlib.util.spec_from_file_location,
    #       because it is called inside this function.
    test_dict = {
        "a": 42,
        "b": "foo",
    }

    # Simple test
    test_file_content = "test_dict = {'a': 42, 'b': 'foo'}"
    test_file_location = "./test_file_location_file.py"

    with open(test_file_location, "w") as test_file:
        test_file.write(test_file_content)

    with open(test_file_location) as test_file:
        assert test_file.read() == test_file_content

# Generated at 2022-06-12 09:41:01.442397
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    test_config_file = __file__.split("sanic/config.py")[0] + "/test/config.py"
    test_config_file_path = Path(test_config_file)

    test_config_file_bytes = test_config_file.encode("utf8")

    os.environ["TEST_KEY"] = "test_value"

    assert (
        load_module_from_file_location(test_config_file)
        .config_file_variable_without_type
        == "test"
    )

    assert (
        load_module_from_file_location(test_config_file_path)
        .config_file_variable_without_type
        == "test"
    )


# Generated at 2022-06-12 09:41:04.634873
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # TODO: add test load_module_from_file_location

    # NOTE: legacy test
    # config = load_module_from_file_location("./tests/test_config.py")
    # assert config.FOO == "BAR"
    # assert config.BAZ == "FOOBAR"
    pass



# Generated at 2022-06-12 09:41:13.794567
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest

    from os import environ as os_environ
    from os import path as os_path
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from textwrap import dedent

    from sanic.exceptions import LoadFileException

    def create_module(content: str) -> str:
        with TemporaryDirectory() as tmp_dir:
            tmp_module_path = os_path.join(tmp_dir, "mod.py")
            with open(tmp_module_path, "w+") as tmp_module:
                tmp_module.write(content)
            return tmp_module_path


# Generated at 2022-06-12 09:41:18.979280
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(Path(__file__))
    assert module.__name__ == __name__
    module = load_module_from_file_location(
        Path(__file__).parent / "settings_test.py"
    )
    assert module.__name__ == "settings_test"



# Generated at 2022-06-12 09:41:21.694583
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location(
            "config_for_load_module_from_file_location_testing"
        ).TEST_VARIABLE
        == "PASSED"
    )

# Generated at 2022-06-12 09:41:28.329168
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Create test files
    with open("test_load_module_from_file_location.py", "w") as file:
        file.write("test_value = 32")

    with open("test_load_module_from_file_location", "w") as file:
        file.write(
            "test_value = 7\ntest_value_as_environment_variable = ${test_value}"
        )

    # Test with load_module_from_file_location
    os_environ["test_value"] = "8"

    # Test with file_name.py
    assert (
        load_module_from_file_location(
            "test_load_module_from_file_location.py"
        ).test_value
        == 32
    )

# Generated at 2022-06-12 09:41:38.807810
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    def _create_example_module_file(path, name):
        Path(path).mkdir(parents=True, exist_ok=True)

        with open(Path(path) / f"{name}.py", "w") as test_config:
            test_config.write(f"CONST = {name}")

    def _get_test_config_path(test_param):
        return Path(__file__) / ".." / ".." / "tests" / "configs" / test_param

    def _create_test_envs():
        os_environ["test_env_1"] = str(_get_test_config_path("1"))
        os_environ["test_env_2"] = str(_get_test_config_path("2"))


# Generated at 2022-06-12 09:41:47.738806
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # flake8: noqa
    """Tests for function load_module_from_file_location."""
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import mkdir, environ

    tmp_dir = mkdtemp()
    # test filename with non-ascii characters
    non_ascii_tmp_filename = tmp_dir + "/Заголовок.py"
    # test filename with starting space
    starting_space_tmp_filename = tmp_dir + "/ filename.py"
    # test filename with ending space
    ending_space_tmp_filename = tmp_dir + "/filename.py "


# Generated at 2022-06-12 09:41:58.498217
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests if load_module_from_file_location works correctly.
    Raises AssertionError if not passes."""

    import os

    some_path_to_config = "tests/some_config.py"
    some_path_to_config2 = "tests/${PROJECT_ROOT_DIR}/some_config.py"
    some_path_to_config3 = "tests/${PROJECT_ROOT_DIR}/${PROJECT_ROOT_DIR}/some_config.py"  # noqa
    some_path_to_config4 = f"tests/{os.path.basename(os.path.dirname(os.path.realpath(__file__)))}/some_config.py"  # noqa
    dummy_config = "tests/dummy_config.py"

    os

# Generated at 2022-06-12 09:42:10.765221
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sanic
    import pytest

    # A/B) Test location with not existing env_var.
    with pytest.raises(LoadFileException):
        not_existing_env_var_location = "tests/${not_existing_env_var}/test_config.py"
        config = load_module_from_file_location(not_existing_env_var_location)

    # C) Test location with substituted env_var.
    not_existing_env_var_location = "tests/${SOME_VAR}/test_config.py"
    os_environ["SOME_VAR"] = "test_config.py"
    config = load_module_from_file_location(not_existing_env_var_location)

    # Test correct behaviour.

# Generated at 2022-06-12 09:42:19.327819
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ

    # Testing if works with file path as string
    assert load_module_from_file_location("/tmp/file.py").__file__ == "/tmp/file.py"

    # Testing if works with file path as Path
    assert load_module_from_file_location(Path("/tmp/file.py")).__file__ == "/tmp/file.py"

    # Testing if works with Path and arguments
    assert load_module_from_file_location(Path("/tmp/file.py"), "source").__file__ == (
        "/tmp/file.py"
    )

    # Testing if works with Path and arguments
    assert load_module_from_file_location("/tmp/file.py", "source").__file__ == (
        "/tmp/file.py"
    )

    # Testing

# Generated at 2022-06-12 09:42:29.901174
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test that function properly returns module object
    #    created from *.py file.
    test_module = load_module_from_file_location(
        __file__, __name__, "code", None, True
    )
    assert test_module.__spec__.origin == __spec__.origin
    assert __name__ == test_module.__spec__.name
    assert test_module.__spec__.loader is __spec__.loader
    assert test_module.__spec__.submodule_search_locations is __spec__.submodule_search_locations
    assert __package__ == test_module.__spec__.parent
    assert test_module.__spec__.cached is __spec__.cached
    assert test_module.__spec__.origin == __spec__.origin

    # B) Test that

# Generated at 2022-06-12 09:42:36.111505
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D103
    assert load_module_from_file_location("os") == os

    os.environ["SANIC_TEST_CONFIG"] = "./sanic/examples/config.py"
    assert (
        load_module_from_file_location("${SANIC_TEST_CONFIG}")
        == sanic.examples.config
    )
    os.environ.pop("SANIC_TEST_CONFIG")

# Generated at 2022-06-12 09:42:43.316785
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from textwrap import dedent

    # A) Test for normal config
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        # Create config file
        tmp_config_path = tmp_dir / "test_config.py"
        with open(tmp_config_path, "w") as tmp_config_file:
            tmp_config_file.write(
                dedent(
                    """
                class Config:
                    param_1 = "val_1"
                    param_2 = "val_2"
                """
                )
            )
        # Load it
        tmp_module = load_module_from_file_location(str(tmp_config_path))
        assert tmp_module.Config.param_1 == "val_1"
        assert tmp_

# Generated at 2022-06-12 09:42:50.946123
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    def test_load_module_from_file_location_raw(location):
        return load_module_from_file_location(location)

    def test_load_module_from_file_location_not_existing(location):
        with pytest.raises(IOError) as excinfo:
            load_module_from_file_location(location)
        assert "Unable to load configuration" in str(excinfo.value)

    # test loading module from file path
    test_module = test_load_module_from_file_location_raw(
        Path(__file__).as_posix().replace(".py", "_data.py")
    )
    assert isinstance(test_module, types.ModuleType)

    # test loading module from file name
    test_module = test_load_module_from_

# Generated at 2022-06-12 09:42:58.885197
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests that function works as it should."""

    # 1) Load file with simple name.
    module = load_module_from_file_location(
        "/home/user/my_module.py", "utf8"
    )
    assert hasattr(
        module, "__file__"
    ), "Module should have __file__ attribute."
    assert (
        module.__file__ == "/home/user/my_module.py"
    ), "Module should have set __file__ attribute to valid path."
    assert (
        module.__name__ == "my_module"
    ), "Module should have set __name__ attribute to valid value."

    # 2) If location is Pathlib.Path object.

# Generated at 2022-06-12 09:43:07.434062
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import environ, path
    from tempfile import gettempdir, mkstemp

    test_config = path.join(gettempdir(), "test_config.py")
    # create test config
    with open(test_config, "w") as f:
        f.write("TEST_KEY_STR = 'test_value_str' \n")
        f.write("TEST_KEY_INT = 7")

    tmp_dir = gettempdir()
    # create test config in format with env vars
    test_config_with_env_vars = path.join(
        "${TMP_DIR}", "test_config.py"
    )
    # test load module from file location
    # first use environment variable
    environ["TMP_DIR"] = tmp_dir
    # load

# Generated at 2022-06-12 09:43:15.707860
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""

    import os
    import pylint.testutils

    from tests.helpers import patch

    # Test empty location
    with patch(
        "sanic.log.server_logger", autospec=True
    ) as mock_server_logger:
        location = ""
        try:
            load_module_from_file_location(location)
        except IOError:
            log_message = mock_server_logger.exception.call_args[0][0]
            assert "Unable to load configuration" in log_message
        else:
            assert False

    # Test location that contains only one environment variable
    os.environ["SANIC_CONFIG_ENV_VAR_A"] = "env_var_A"

# Generated at 2022-06-12 09:43:23.640880
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    os.environ['a_env_var'] = 'a_value'
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
        f.write('test_var="test_value"')

# Generated at 2022-06-12 09:43:38.238960
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import sys
    import shutil

    import tempfile
    import warnings

    from sanic.log import logger as _logger

    tmp_dir = tempfile.mkdtemp()

    def create_test_config_file(tmp_dir, filename, contents):
        with open(f"{tmp_dir}/{filename}", "wt") as f:
            f.write(contents)

    create_test_config_file(tmp_dir, "test_config.py", "TESTING_CONFIG = True")

    def test_load_path(path):

        module = load_module_from_file_location(
            path,
            # location,
            "utf8",  # encoding
            False,  # was_executed
        )


# Generated at 2022-06-12 09:43:47.753165
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(
        "test_utils", "./test/test_utils.py"
    )
    assert load_module_from_file_location(
        b"test_utils", b"./test/test_utils.py", encoding="utf8"
    )
    assert load_module_from_file_location(
        "test_utils", Path(__file__).parents[1] / "test/test_utils.py"
    )
    assert load_module_from_file_location(
        "test_utils", Path(__file__).parents[1] / "test/test_utils.py"
    )
    assert load_module_from_file_location(
        "test_utils", "./test/${TEST_CONFIGURATION}"
    )

# Generated at 2022-06-12 09:43:57.188915
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    some_dict = {"a": 1, "b": 2}
    some_other_dict = {"c": 3, "d": 4}

    os_environ["some_dict"] = str(some_dict)
    os_environ["some_other_dict"] = str(some_other_dict)

    location = (
        Path(__file__).parent.parent
        / "tests"
        / "config"
        / "dict_config"
        / "config_a.py"
    )

    module = load_module_from_file_location(location)

    # ...check that location parameter accepts also file paths.
    assert module.CONFIG_A == some_dict
    # ...check that resolves ${some_env_var} in location path.
    assert module.CONFIG_B == some_other_dict
   

# Generated at 2022-06-12 09:44:06.417419
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Create test_config.py module
    test_config_module_content = """
from pathlib import Path
from sanic.log import logger

DEBUG = str_to_bool("${DEBUG}")

BASE_DIR = Path("${BASE_DIR}")
logger.debug("BASE_DIR")
"""
    with open("test_config.py", "w") as f:
        f.write(test_config_module_content)

    os_environ["DEBUG"] = "1"
    os_environ["BASE_DIR"] = "some/path/"

    # Test
    TEST_LOCATION = "test_config.py"
    test_config = load_module_from_file_location(TEST_LOCATION)

    assert test_config.DEBUG is True
    assert test_config.BASE_

# Generated at 2022-06-12 09:44:10.985946
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    def get_module_from_string(string):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
            f.write(string)
            f.flush()
            module = load_module_from_file_location(f.name)
        return module


# Generated at 2022-06-12 09:44:19.677270
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from tempfile import NamedTemporaryFile

    # A) Check that it loads module correctly
    with NamedTemporaryFile() as tempfile:
        name = "test_module"
        path = tempfile.name
        tempfile.write(
            f"""
            test_variable = "test"
            test_variable2 = "test2"
            """
        )
        tempfile.flush()
        module = load_module_from_file_location(path)
        assert module.test_variable == "test"
        assert module.test_variable2 == "test2"

    # B) Check that it supports environment variables
    #    in format ${some_env_var}.
    with NamedTemporaryFile() as tempfile:
        name = "test_module"
        path = f"{tempfile.name}.py"


# Generated at 2022-06-12 09:44:29.681645
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sanic.config

    os_environ["DUMMY_ENV_VAR_FOR_TESTING"] = "sanic"


# Generated at 2022-06-12 09:44:39.011259
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest  # noqa

    # A) Check functionality of load_module_from_file_location function.
    # 1) Check if function can load module provided as a Pathlib object.
    some_location = Path("./tests/fixtures/test_module.py")
    some_module = load_module_from_file_location(some_location)
    assert hasattr(some_module, "some_function")

    # 2) Check if function can load module provided as a string.
    some_location = "./tests/fixtures/test_module.py"
    some_module = load_module_from_file_location(some_location)
    assert hasattr(some_module, "some_function")

    # B) Check if load_module_from_file_location raises exceptions properly.
    # 1) Check if load

# Generated at 2022-06-12 09:44:41.361329
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SOME_VAR"] = "/path/to/python"
    assert load_module_from_file_location("${SOME_VAR}") == os
# End unit test

# Generated at 2022-06-12 09:44:49.025145
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    os_environ["HOME"] = "home"
    os_environ["PATH"] = "path"

    assert load_module_from_file_location("HOME") == "home"
    assert load_module_from_file_location("PATH") == "path"
    assert load_module_from_file_location("HOME") != "path"

    assert load_module_from_file_location("tests/fake_module.py") == "fake"
    assert load_module_from_file_location("tests/fake_module.py") != "fake2"

    assert load_module_from_file_location("tests/fake_module.yml") == ""

    assert load_module_from_file_location("./tests/fake_module.txt") == ""


# Generated at 2022-06-12 09:45:02.835499
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import pytest
    from contextlib import contextmanager

    from unittest.mock import patch

    from sanic.exceptions import LoadFileException, PyFileError

    from sanic_configurator import str_to_bool

    @contextmanager
    def os_environ_patched_with(patched_os_environ):
        """Context manager that patches os.environ with new values."""
        with patch.dict("os.environ", patched_os_environ):
            yield

    @contextmanager
    def os_environ_patched_with_fake_module():
        """Context manager that patches os.environ with fake module."""

# Generated at 2022-06-12 09:45:13.101069
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) load_module_from_file_location('some_module')
    #    should be the same as importlib.import_module('some_module')
    import importlib

    try:
        some_module = load_module_from_file_location("some_module")
        some_module_from_importlib = importlib.import_module("some_module")

        assert some_module == some_module_from_importlib

    except ModuleNotFoundError:
        pass

    # B) Check if load_module_from_file_location works with
    #    all string types and bytes type.
    #    Check for errors if can't decode bytes.
    location = "some_module"
    assert load_module_from_file_location(location)

    location = b"some_module"
    assert load_module_from

# Generated at 2022-06-12 09:45:22.310123
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pylint: disable=R0201
    from io import BytesIO
    from unittest.mock import patch

    # Test 1
    with patch(
        "sanic.helpers.load_module_from_file_location.spec_from_file_location",
        spec_from_file_location,
    ) as mock_spec_from_file_location, patch(
        "sanic.helpers.load_module_from_file_location.module_from_spec",
        module_from_spec,
    ) as mock_module_from_spec:
        load_module_from_file_location(
            "some_path/some_location_with.py", "some_package_name"
        )

# Generated at 2022-06-12 09:45:31.206159
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Run unit tests for load_module_from_file_location function."""
    import tempfile
    import unittest

    import pytest

    from sanic.exceptions import LoadFileException, PyFileError

    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)
    tmp_file = tmp_dir_path / "some_config.py"
    with tmp_file.open("w") as f:
        f.write("A = 2")

    class TestLoadModuleFromFileLocation(unittest.TestCase):
        def test_load_file_as_module_with_string(self):
            """Test if we can load file as module when it's path is provided
            as a string."""

# Generated at 2022-06-12 09:45:40.297881
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    path = "/path/to/file.py"
    spec = spec_from_file_location("config", path, submodule_search_locations=[])
    mod = module_from_spec(spec)
    spec.loader.exec_module(mod)

    assert load_module_from_file_location("config", path) == mod
    assert load_module_from_file_location("config", path.encode("utf8")) == mod
    assert load_module_from_file_location("config", Path(path)) == mod

    with pytest.raises(ValueError):
        str_to_bool("g")
    with pytest.raises(ValueError):
        str_to_bool("")
    with pytest.raises(ValueError):
        str_to_bool("False")

# Generated at 2022-06-12 09:45:48.773786
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_location = Path(__file__).parent / "tests/config.py"
    module = load_module_from_file_location(file_location)
    assert hasattr(module, "CONFIG")
    assert hasattr(module.CONFIG, "SOME_VAR")
    assert module.CONFIG.SOME_VAR == "test"
    assert hasattr(module.CONFIG, "SOME_OTHER_VAR")
    assert hasattr(module.CONFIG.SOME_OTHER_VAR, "test")
    assert hasattr(module.CONFIG, "TRUTH_VALUES")
    assert module.CONFIG.TRUTH_VALUES.TRUE == True
    assert module.CONFIG.TRUTH_VALUES.FALSE == False

# Generated at 2022-06-12 09:45:57.697858
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Tests for legacy "location" (accepts only bytes and strings)
    module = load_module_from_file_location(
        b"sanic.tests.config.config_not_exists", file=Path("sanic") / "tests"
    )
    assert module.__file__ == "sanic/tests/config/config_not_exists.py"

    module = load_module_from_file_location(
        "sanic.tests.config.config_not_exists", file=Path("sanic") / "tests"
    )
    assert module.__file__ == "sanic/tests/config/config_not_exists.py"

    # Tests for "Path" location

# Generated at 2022-06-12 09:46:03.099206
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    str_to_bool('Y')
    str_to_bool('T')
    str_to_bool('on')
    str_to_bool('N')
    str_to_bool('F')
    str_to_bool('off')
    assert(str_to_bool('Y') == True)
    assert(str_to_bool('on') == True)
    assert(str_to_bool('off') == False)

if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-12 09:46:11.837340
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert "sanic" in str(load_module_from_file_location("sanic"))
    assert "sanic" in str(load_module_from_file_location("sanic.async"))
    assert (
        "sanic" in str(load_module_from_file_location("sanic.async.tasks"))
    )
    assert (
        "sanic"
        in str(
            load_module_from_file_location(
                "sanic.async.tasks.__init__"
            )
        )
    )
    assert "config" in str(load_module_from_file_location("/dev/null"))
    assert "config" in str(load_module_from_file_location("C:\\dev\\null"))

# Generated at 2022-06-12 09:46:21.169802
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from tempfile import NamedTemporaryFile
    from importlib.util import module_from_spec, spec_from_file_location
    from os import environ as os_environ
    from os import remove as os_remove
    from re import findall as re_findall
    from os import path as os_path
    import unittest

    # A) Test with environment variable with ${some_env_var} format.

    # 1) Use some existing variable with non empty value
    #    to skip raise exception.
    os_environ["TEST_LOAD_MODULE_FROM_FILE_LOCATION_ENV_VAR_EXISTING"] = "yes"

    with NamedTemporaryFile("w", suffix=".py") as temp:
        temp.write(
            "config = True"
        )  # Write

# Generated at 2022-06-12 09:46:37.185189
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test that we can load module and also environment variables are supported."""
    # Load some module
    module = load_module_from_file_location(
        Path(__file__).parent.joinpath("mock", "mock_app.py")
    )
    assert module.FOO == "bar"
    assert module.class_attr == "baz"

    # Load module using environment variable
    os_environ["CONFIG_PATH"] = str((Path(__file__).parent / "mock"))
    module = load_module_from_file_location(
        "${CONFIG_PATH}/mock_app.py"
    )
    assert module.FOO == "bar"
    assert module.class_attr == "baz"

    # Test that we raise LoadFileException
    # when we have environment variable in

# Generated at 2022-06-12 09:46:44.565598
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test for 'load_module_from_file_location' function."""
    conf_file = Path(__file__).parent.parent / "test_app" / "config.py"
    mod_from_file_location = load_module_from_file_location(
        "test_app.config", conf_file, "utf8"
    )

    assert mod_from_file_location.TEST_VAR == "It works"
    assert mod_from_file_location.TEST_LIST == ["1", "2", "3"]
    assert mod_from_file_location.TEST_DICT == {1: "2", 3: "4"}
    assert mod_from_file_location.TEST_BOOL is False

# Generated at 2022-06-12 09:46:52.102803
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = Path(__file__).parent / "../examples/configs/config_from_yaml.py"
    config = load_module_from_file_location(location)

    assert config.DEBUG is False
    assert config.TESTING is False
    assert config.LOGO == "http://sanicframework.org/"
    assert config.DATABASE_URL is "sqlite:////tmp/test.db"
    assert config.PROXIES == ["http://10.10.1.10:3128", "http://10.10.1.11:1080"]

# Generated at 2022-06-12 09:47:00.226922
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import pytest
    from os import environ as os_environ
    from pathlib import Path
    from sanic import Sanic

    from sanic_openapi import doc

    # In this unit test we will test this function with one of it's usages
    # in case of openapi/sanic_openapi loading.

    # A) Test with fake configuration file.
    with Sanic("TestLoadModuleFromFileLocation") as app:
        doc.register(app)

        @app.route("/")
        async def test_handler(request):
            return response.json({"ok": True})

    full_path = str(Path(os.path.dirname(__file__)).resolve())

    conf_path = Path(full_path) / "resources"

# Generated at 2022-06-12 09:47:10.082209
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_config_path = (
        Path(__file__)
        .parent.parent.parent
        .joinpath("test/test_server/test_config.py")
    )

    old_path = os_environ.get("PATH")
    os_environ["PATH"] = "/some/path"
    old_config = os_environ.get("CONFIG")
    os_environ["CONFIG"] = "/some/config"

    some_config = load_module_from_file_location(test_config_path)

    assert some_config.TEST == "OK"

    some_config = load_module_from_file_location(
        "${PATH}/test/test_server/test_config.py"
    )

    assert some_config.TEST == "OK"


# Generated at 2022-06-12 09:47:19.473643
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        from tempfile import mkdtemp, NamedTemporaryFile
    except ImportError:
        from tempfile import TemporaryDirectory, NamedTemporaryFile

    class TempTestDir():
        def __init__(self):
            self.temp_dir = mkdtemp()

        def __enter__(self):
            return self.temp_dir

        def __exit__(self, typ, value, traceback):
            from shutil import rmtree

            rmtree(self.temp_dir)

    # Testing with python module
    with TempTestDir() as temp_dir:
        with NamedTemporaryFile(dir=temp_dir, prefix="test", suffix=".py") as tf:
            tf.write("# This is test".encode("utf8"))
            tf.flush()
            import sys
            import os
            sys.path

# Generated at 2022-06-12 09:47:28.680491
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from tempfile import NamedTemporaryFile

    # 1) Test when working with files:

    # 1.1) Test when working with strings.
    with NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write(
            "a = 1\n"
            "b = 2\n"
            "c = 3\n"
            "d = 5\n"
            "class MyCustomClass:\n"
            "    pass\n"
        )
        temp_file.flush()
        module = load_module_from_file_location(temp_file.name)

        assert module.a == 1
        assert module.b == 2
        assert module.c == 3
        assert module.d == 5
        assert isinstance(module.MyCustomClass, type)

   

# Generated at 2022-06-12 09:47:34.536649
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SANIC_ENV_VAR"] = "some_value"
    some_module = load_module_from_file_location(
        "sanic.test.test_helpers",
        "${ZERO_TEST_LOCATION}/test_helpers.py"
    )
    assert some_module.test_variable == 10, (
        "test_load_module_from_file_location unit test failed"
    )

# Generated at 2022-06-12 09:47:39.971236
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D103
    test_imports = [
        "some_module",
        "/some/path/${some_env_var}",
        Path("/some/path_to/non_existent_file.py"),
        "some_module_with.dots",
        b"some_module_bytes",
        b"/some/path/${some_env_var}",
        Path("/some/path_to/non_existent_file.py"),
        b"some_module_with.dots",
    ]

    for test_import in test_imports:
        assert (load_module_from_file_location(test_import) == None)  # type: ignore

# Generated at 2022-06-12 09:47:49.892869
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    from tempfile import NamedTemporaryFile, TemporaryDirectory

    # ---------- Create temporary modules ---------
    with TemporaryDirectory() as tmp_dir:
        # test_config.py
        config_file = NamedTemporaryFile(
            mode="w", dir=tmp_dir, delete=False
        )  # type: ignore
        config_file.write("var_1 = 5")
        config_file_path = config_file.name

        # test_module.py
        module_file = NamedTemporaryFile(
            mode="w", dir=tmp_dir, delete=False
        )  # type: ignore
        module_file.write("class Test: pass")
        module_file_path = module_file.name

        # test_env_var

        os.environ["test_env_var"] = tmp_dir

