

# Generated at 2022-06-12 09:38:05.281893
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """This function should return imported module.
    Test if it works properly.
    """
    # A) Import module from file path.
    imported_module = load_module_from_file_location(
        __file__,
    )
    assert imported_module
    assert imported_module.__name__ == __name__
    assert imported_module.__file__ == __file__

    # B) Import module from environment variable
    #    (working only in Linux/Unix systems)
    if os.name == "posix":
        os.environ["SANIC_TESTS_UTILS_VARIABLE"] = __file__
        imported_module = load_module_from_file_location(
            "/this/is/${SANIC_TESTS_UTILS_VARIABLE}"
        )
        assert imported_module


# Generated at 2022-06-12 09:38:12.971257
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys

    def test_module_code():
        # Test code for module to be used in
        # different modules_from_file_location tests.
        x = 10
        y = 20

    path_to_test_module = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "test_module.py"
    )
    module_name = "test_module"

    # Test if module is loaded from path with .py extension.
    module = load_module_from_file_location(path_to_test_module)
    assert isinstance(module, types.ModuleType)
    assert (
        str(getattr(module, "__file__", None))
        == path_to_test_module.replace(".py", "")
    )

# Generated at 2022-06-12 09:38:21.993755
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from tempfile import mkstemp
    from sanic.exceptions import LoadFileException, PyFileError

    def create_temp_file(suffix="", prefix="tmp", dir=None):
        from tempfile import mkstemp

        fd, tmp_file = mkstemp(suffix, prefix, dir)
        os.close(fd)

        return tmp_file

    def get_test_value():
        """Helper function to get value of test_variable.
        # Create object module with filed __file__ and test_variable
        # and save it in /tmp/test_module
        # Create object config with filed __file__ and test_variable
        # and save it in /tmp/test_config
        Returns value of test_variable.
        """
        test_value = 42

        # Create object module with

# Generated at 2022-06-12 09:38:29.465083
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) This should pass.
    assert (
        load_module_from_file_location(
            "sanic.app",
            "./tests/test_load_module_from_file_location.py",
        ).__file__
        == "./tests/test_load_module_from_file_location.py"
    )

    # B) This should cause exception LoadFileException because
    #    environment variable $THIS_ENV_VAR_SHOULD_NOT_EXIST is not defined.

# Generated at 2022-06-12 09:38:38.334500
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    PATH_WITH_ENV_VAR = tempfile.NamedTemporaryFile().name
    os.environ["TEST_VAR"] = PATH_WITH_ENV_VAR

    assert (
        load_module_from_file_location(
            "tests.test_utils.test_load_module_from_file_location"
        )
        is test_load_module_from_file_location
    )
    assert (
        load_module_from_file_location(
            "$TEST_VAR"
        )
        is test_load_module_from_file_location
    )

# Generated at 2022-06-12 09:38:45.865907
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # 1) Load module from location (string).
    # In this case location is a bytes type.
    some_module = load_module_from_file_location(__file__.encode(), "utf8")
    assert some_module.__file__ == __file__

    # 2) Load module from location (string).
    # In this case location is a string type.
    some_module = load_module_from_file_location(__file__)
    assert some_module.__file__ == __file__

    # 3) Load module from location (Pathlib).
    some_module = load_module_from_file_location(Path(__file__))
    assert some_module.__file__ == __file__

    # 4) Load module from location (string) with environment variables.
    # Environment variables are in format ${some_env

# Generated at 2022-06-12 09:38:56.337040
# Unit test for function load_module_from_file_location

# Generated at 2022-06-12 09:39:05.588758
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from os import makedirs, remove
    from os.path import join
    from shutil import rmtree
    from tempfile import gettempdir
    from unittest import TestCase
    from unittest.mock import patch

    from sanic.exceptions import LoadFileException, PyFileError

    TEMPDIR = gettempdir()

    class TestLoadModuleFromFileLocation(TestCase):

        # NOTE:  You can't use unittest.mock.patch here because
        # patching os.environ with copy is not enough. Unpatching
        # restores original os.environ.
        class MockOsEnviron(dict):
            def clear(self):
                pass
            def __setitem__(self, key, item):
                dict.__setitem__(self, key, item)
               

# Generated at 2022-06-12 09:39:14.491140
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) It should raise LoadFileException if something goes wrong.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("/some/path")

    # B) It should raise LoadFileException if location contains environment
    #    variable that is not set.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("/some/path/${some_env_var}")

    # C) It should return module object if everything is OK.
    assert (
        load_module_from_file_location(
            __file__, "SANIC_TEST_CONFIG=config.py"
        )
        is not None
    )

    # D) It should work properly with previously persisted configuration file.

# Generated at 2022-06-12 09:39:23.048825
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Test for valid locations
    for location in [
        "/some/path/to/some_module.py",
        "some_module.py",
        b"some_module.py",
        "some_module",
        b"some_module",
        "/some/path/to/some_module",
        b"/some/path/to/some_module",
        "./some_module",
        "./some_module.py",
        b"./some_module.py",
        "some_module.pyc",
    ]:
        load_module_from_file_location(location)
        load_module_from_file_location(location, foo="bar")
        load_module_from_file_location(location, foo="bar", bar="foo")

    # Test for invalid locations
   

# Generated at 2022-06-12 09:39:35.283598
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    from contextlib import contextmanager

    from typing import Generator

    @contextmanager
    def make_temp_file(contents: str = "") -> Generator[Path, None, None]:
        fd, temp_file_path = tempfile.mkstemp()
        with open(temp_file_path, "w") as f:
            f.write(contents)
        try:
            yield Path(temp_file_path)
        finally:
            os.remove(temp_file_path)

    import pytest # type: ignore

    def modify_env_var(env_var: str, new_value: str) -> str:
        original_value = os.environ.get(env_var)
        os.environ[env_var] = new_value
        return original_value


# Generated at 2022-06-12 09:39:43.919043
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_string("math.pi")
    load_module_from_file_location("math.pi")
    load_module_from_file_location("sanic.exceptions.LoadFileException")
    load_module_from_file_location("sanic.exceptions.LoadFileException", "")
    load_module_from_file_location("sanic.exceptions.LoadFileException", "", "")
    load_module_from_file_location("sanic.exceptions.LoadFileException", "", "", "")
    load_module_from_file_location("sanic.exceptions.LoadFileException", "", "", "", "")
    load_module_from_file_location("sanic.exceptions.LoadFileException", "", "", "", "", "")

# Generated at 2022-06-12 09:39:51.134671
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test for function load_module_from_file_location.
    """

    # Set variables for test
    SOME_ENV_VAR_KEY = "SOME_ENV_VAR_KEY"
    SOME_ENV_VAR_VAL = "SOME_ENV_VAR_VALUE"
    SOME_ENV_VAR_VAL_2 = "SOME_ENV_VAR_VALUE_2"

    SOME_CONFIG_NAME = "some_config"
    SOME_CONFIG_NAME_2 = "some_config_2"
    SOME_CONFIG_PATH = Path(__file__).parent / "some_config.py"
    SOME_CONFIG_PATH_2 = Path(__file__).parent / "some_config_2.py"
    SOME_CONFIG_PATH_3 = Path

# Generated at 2022-06-12 09:39:52.752643
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile


# Generated at 2022-06-12 09:39:58.776483
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert str_to_bool("f") == False
    assert load_module_from_file_location("some_module_name", "./some/path/")
    assert load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}", encoding="utf-8"
    )
    assert load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )

# Generated at 2022-06-12 09:40:06.878763
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("./tests/test_load_config.py")
    assert module.a == "b"
    assert module.c["d"] == "e"
    module = load_module_from_file_location("./tests/test_load_config.py", "A")
    assert module.a == "b"
    assert module.c["d"] == "e"
    module = load_module_from_file_location("./tests/test_load_config.py", "a")
    assert module.a == "b"
    assert module.c["d"] == "e"

# Generated at 2022-06-12 09:40:09.816870
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # If a location is a string type and contains environment variables,
    # loads returns module with file name coresponding to the location.
    os_environ["some_env_var"] = "some_var_value"
    module_1 = load_modu

# Generated at 2022-06-12 09:40:16.072232
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "${SOME_ENV_VAR_TO_EXIST}/some_path/something.py"
    with os_environ.copy():
        os_environ["SOME_ENV_VAR_TO_EXIST"] = "some_value"
        module = load_module_from_file_location(location=location)
        assert module
        assert module.__file__ == (
            "some_value/some_path/something.py"
        )

        with os_environ.copy():
            os_environ["SOME_ENV_VAR_NOT_TO_EXIST"] = "some_value"
            with pytest.raises(LoadFileException):
                load_module_from_file_location(location=location)

# Generated at 2022-06-12 09:40:25.405941
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # From Python 3.6 str.format() is going to be depreciated in
    # favour of f-strings, so we don't use it here.
    location = "${USER}/some_module_name"
    # B) Check these variables exists in environment.
    # We assume that ${HOME} and ${USER} are defined in Unix system.
    # And we also assume that user running tests can read/write
    # ${HOME}/${USER} locations.
    # NOTE: In case of multiple users using the same machine if you
    #       want to run them under different ${USER} environment
    #       variables or sudoing into different users.
    #       You can define environment variable SANIC_TEST_USER
    #       with user name

# Generated at 2022-06-12 09:40:32.688439
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import getcwd, pathsep

    import pytest

    from . import utils

    cwd = getcwd()
    location = str(utils.get_fixtures_path(False, "config.py"))
    loaded_module = load_module_from_file_location(location)
    assert loaded_module is not None
    assert loaded_module.KEY == "some_value"

    location = str(utils.get_fixtures_path(False, "config"))
    loaded_module = load_module_from_file_location(location)
    assert loaded_module is not None
    assert loaded_module.KEY == "some_value"
    assert loaded_module.__file__.startswith(cwd + pathsep)


# Generated at 2022-06-12 09:40:47.070481
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    if isinstance(__builtins__, dict):  # Python 3
        builtins_name = "builtins"
    else:  # Python 2
        builtins_name = "__builtin__"

    if type(__import__("os").environ["HOME"]) is not str:
        return

    # A) Test with string without environment variables.
    sys.argv = [sys.argv[0]]
    os_environ["HOME"] = "/home/user"
    os_environ["SANIC_CONFIG_MODULE"] = "my_project.config.DevelopmentConfig"
    config_1 = load_module_from_file_location(
        "/home/user/my_project/config.py"
    )
    config_1.DEBUG  # Assert DEBUG variable not raises KeyError.
    assert config_1

# Generated at 2022-06-12 09:40:55.334996
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import shutil
    import tempfile


# Generated at 2022-06-12 09:41:04.486194
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from datetime import date

    from sqlalchemy.sql import text
    from pytest import raises

    with raises(ValueError, match="Invalid truth value"):
        str_to_bool("?") != False

    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("T") == True
    assert str_to_bool("FaLsE") == False
    assert str_to_bool("off") == False

    with raises(TypeError):
        load_module_from_file_location(date.today())

    with raises(IOError):
        load_module_from_file_location(
            "config_file_not_exists", globals(), "/"
        )


# Generated at 2022-06-12 09:41:13.794268
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic.sanic import Sanic

    application = Sanic("test")

    #### test for case when location is Path
    # 1. current directory
    location = Path(__file__).parent
    module = load_module_from_file_location(location=location)
    assert module.__name__ == "utils"

    # 2. project directory
    location = Path(__file__).parent.parent
    module = load_module_from_file_location(location=location)
    assert module.__name__ == "sanic"

    #### test for case when location is str
    # 1. current directory
    location = str(Path(__file__).parent)
    module = load_module_from_file_location(location=location)
    assert module.__name__ == "utils"

    # 2. project directory


# Generated at 2022-06-12 09:41:23.191788
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from tempfile import gettempdir
    from pathlib import Path
    from datetime import datetime

    import pytest
    from _pytest.monkeypatch import MonkeyPatch

    some_env_var = "some_env_var"
    some_env_var_value = "some_env_var_value"
    monkeypatch = MonkeyPatch()

    def reset_env_var():  # noqa: E301
        monkeypatch.setattr(os.environ, some_env_var, some_env_var_value)

    reset_env_var()

    tempfile = Path(str(gettempdir()) + "/temp_file")
    tempfile.touch()
    assert tempfile.is_file()

    module = load_module_from_file_location(tempfile)

# Generated at 2022-06-12 09:41:32.387433
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D103
    import pytest
    # SUT (System Under Test)
    from sanic.config import load_module_from_file_location
    from pathlib import Path
    import os

    # Setup test
    location = Path(__file__).parent / "data"
    # Case 1
    #       location is a path, ends with .py, not contains $
    #       There are no environment variables
    #       The import is successfull
    # -----------------
    sut = load_module_from_file_location(location / "module1.py")
    assert sut.__name__ == "module1"
    assert sut.config_var == 10

    # Case 2
    #       location is a path, ends with .py, contains $
    #       There are no environment variables
    #       The import is

# Generated at 2022-06-12 09:41:42.950199
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # Test with location as relative path.
    with tempfile.TemporaryDirectory() as tmp_dir:
        with open(f"{tmp_dir}/some_config.py", "w") as file:
            file.write("CONFIG={'param1': 1}")

        module_relative_path = load_module_from_file_location(
            f"./some_config.py", f"{tmp_dir}"
        )
        assert module_relative_path.CONFIG == {"param1": 1}

    # Test with location as absolute path.
    with tempfile.TemporaryDirectory() as tmp_dir:
        with open(f"{tmp_dir}/some_config.py", "w") as file:
            file.write("CONFIG={'param1': 1}")

        module_absolute_

# Generated at 2022-06-12 09:41:50.440212
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import tempfile
    from os import environ as os_environ
    from os import remove
    from os import mkdir
    from os.path import join

    tmp_folder = tempfile.gettempdir()

    # 1) Create module "test_module.py"
    #    It has to contain variable "some_var = 'some_val'"
    module_file_name = "test_module.py"
    module_file = open(join(tmp_folder, module_file_name), "w+")
    module_file.writelines(["some_var = 'some_val'"])
    module_file.close()

    # 2) Check that module is loadable from its path.
    module = load_module_from_file_location(join(tmp_folder, module_file_name))
    assert module.some_

# Generated at 2022-06-12 09:41:59.854911
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # test_module_file.py
    # test_module_file.a
    # test_module_file.b
    # test_module_file.a.py
    # test_module_file.b.py

    # A) Testing if passing an empty string raises LoadFileException
    with pytest.raises(LoadFileException) as execinfo:
        load_module_from_file_location("")
    assert "not set" in str(execinfo.value)

    # B) Testing if passing bytes string raises LoadFileException
    with pytest.raises(LoadFileException) as execinfo:
        load_module_from_file_location(b"")
    assert "not set" in str(execinfo.value)

    # C) Testing if passing environment variables raises LoadFileException

# Generated at 2022-06-12 09:42:06.285882
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile

    some_content = "A = 123"
    tmp_dir = tempfile.gettempdir()
    tmp_file = tempfile.NamedTemporaryFile(mode="w", dir=tmp_dir, delete=False)
    tmp_file.write(some_content)
    tmp_file.close()

    temp_module = load_module_from_file_location(tmp_file.name)
    assert temp_module.A == 123



# Generated at 2022-06-12 09:42:20.402384
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as td:
        td = Path(td)
        some_file = td / "some_file.py"
        some_file.write_text(
            "# -*- coding: utf-8 -*-\n" "some_var = 'some_value'"
        )

        with pytest.raises(LoadFileException):
            load_module_from_file_location(
                "some_module_name", "/some/path/${some_env_var}"
            )

        with pytest.raises(PyFileError):
            load_module_from_file_location(
                "some_module_name", (td / "some_file_which_does_not_exists.py")
            )

        # Test with module name.
       

# Generated at 2022-06-12 09:42:30.313437
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Tests function load_module_from_file_location
    """
    import tempfile
    import textwrap
    import pytest
    from os import environ as os_environ
    from os import makedirs
    from os import mkdir
    from os import rmdir
    from os.path import exists

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    env_vars_in_location = set(re_findall(r"\${(.+?)}", "/some/path/${some_env_var}"))
    expected_env_vars_in_location = {"some_env_var"}
    assert env_vars_in_location == expected_env_vars_in_location

    # mock environ
    environ = {}
    en

# Generated at 2022-06-12 09:42:40.214408
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_in_cwd = Path(__file__).resolve()
    config_in_cwd = load_module_from_file_location(file_in_cwd)
    assert config_in_cwd
    assert config_in_cwd.__file__ == file_in_cwd.as_posix()

    config_in_cwd_abs_path = load_module_from_file_location(
        Path(__file__).resolve().as_posix()
    )
    assert config_in_cwd_abs_path
    assert config_in_cwd_abs_path.__file__ == file_in_cwd.as_posix()


# Generated at 2022-06-12 09:42:47.331498
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test that function yields correct value for
    # path parameter of a string type
    location_str = (
        Path(__file__).parent.parent.parent / "examples" / "app.py"
    )
    loaded_module = load_module_from_file_location(location_str)
    # This example uses "app" module name
    assert loaded_module.__name__ == "app"

    # Test that function yields correct value for
    # path parameter of a bytes type
    location_bytes = (
        Path(__file__).parent.parent.parent / "examples" / "app.py"
    ).as_posix().encode()
    loaded_module = load_module_from_file_location(location_bytes)
    # This example uses "app" module name
    assert loaded_module.__name__

# Generated at 2022-06-12 09:42:55.987698
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # this is the path to the config_for_testing.py file
    # (we are in test/test_utils.py)
    # inside the sanic folder
    config_location = "../examples/config_for_testing.py"
    # use with encoding="utf-8" when passing bytes not possible
    # (for example running on windows)
    _config = load_module_from_file_location(config_location, encoding="utf-8")
    assert _config.TESTING is True
    assert _config.SECRET_KEY == "secret key"
    assert _config.TEST_KEY == "test value"

    # combine with dicts and lists
    assert _config.TEST_LIST == ["other value", 42]
    assert _config.TEST_DICT["other key"] == "other value"

# Generated at 2022-06-12 09:42:59.906019
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Check that import_string raises ValueError for 'configs.py'
    with pytest.raises(ValueError):
        import_string("configs.py")

    # Check that load_module_from_file_location raises an exception
    # if location is not a Path, str or bytes
    with pytest.raises(TypeError):
        load_module_from_file_location([None])

    # Check that load_module_from_file_location raises an exception
    # if location is just a string
    with pytest.raises(LoadFileException):
        load_module_from_file_location("some_path")

    # Check that load_module_from_file_location raises an exception
    # if location contains environment variables and some of them are not
    # defined in environment

# Generated at 2022-06-12 09:43:08.427770
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Module importing test
    # 1)
    path = "tests/config_example.py"
    module = load_module_from_file_location(path)
    assert isinstance(module.DEBUG, bool)
    assert isinstance(module.HOST, str)

    # 2)
    path = Path(path)
    module = load_module_from_file_location(path)
    assert isinstance(module.DEBUG, bool)
    assert isinstance(module.HOST, str)

    # 3)
    path = bytes(path, encoding="utf8")
    module = load_module_from_file_location(path)
    assert isinstance(module.DEBUG, bool)
    assert isinstance(module.HOST, str)

    # 4)
    path = bytes(path, encoding="utf8")

# Generated at 2022-06-12 09:43:15.318149
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from tempfile import mkdtemp

    from .test_utils import TEST_CONFIGS_PATH, tmp_config_path

    # A) test for import string.
    assert load_module_from_file_location("json").__name__ == "json"

    # B) test for pathlib.Path object
    assert load_module_from_file_location(TEST_CONFIGS_PATH / "simple.py") == {
        "a": 1
    }

    # C) test for string in a format '/some/path/to/some_file.py'
    assert load_module_from_file_location(
        str(TEST_CONFIGS_PATH / "simple.py")
    ) == {"a": 1}

    # D) test for environment variables.
   

# Generated at 2022-06-12 09:43:23.232988
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test if file loading works.
    #  Note: This test assumes that you are in the root of a project.
    test_file_path = "tests/test_helpers/test_file.py"
    test_module = load_module_from_file_location(test_file_path)
    assert hasattr(test_module, "test_var")
    assert test_module.test_var == "test"

    # B) Test if environment variables are resolved correctly.
    test_env_var = "TEST_ENV_VAR"
    test_env_var_value = "TEST_ENV_VAR_VALUE"


# Generated at 2022-06-12 09:43:30.111872
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function.
    """
    import os
    import tempfile
    import test_helpers

    file_location = Path(__file__).parent.parent / "tests/config.py"
    config = load_module_from_file_location(file_location)

    # Test correct import from file
    assert config.TEST_KEY_1 == "test value 1"
    assert config.TEST_KEY_2 == "test value 2"

    # Test importing config from environment variable.
    save_os_environ = os.environ

# Generated at 2022-06-12 09:43:42.258888
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """This function is a unit test for function for function
    load_module_from_file_location.
    It is used by py.test on travis and appveyor.
    It should not be called directly."""

    import tempfile
    from os import environ

    from os import path as os_path

    from sys import platform

    # A) Create some file
    temp_file_location = tempfile.NamedTemporaryFile().name

    # B) Test that file can be loaded
    with open(temp_file_location, "w") as temp_file:
        temp_file.write("a=10")
    temp_file_module = load_module_from_file_location(
        temp_file_location, "utf8"
    )
    assert temp_file_module.a == 10

    # C) Test that

# Generated at 2022-06-12 09:43:51.891723
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["CONFIG_PATH"] = "test/"
    os_environ["CONFIG_NAME"] = "test_config"
    os_environ["CONFIG_EXT"] = ".py"
    os_environ["CONFIG_FILE"] = "test/test_config.py"
    module = load_module_from_file_location(
        "${CONFIG_PATH}${CONFIG_NAME}${CONFIG_EXT}"
    )
    assert module.TEST_CONFIG_VARIABLE == 42
    module = load_module_from_file_location(Path("test/test_config.py"))
    assert module.TEST_CONFIG_VARIABLE == 42
    module = load_module_from_file_location("${CONFIG_FILE}")
    assert module.TEST_CONFIG_

# Generated at 2022-06-12 09:43:53.892840
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    var = "test"
    string = f"hello {var}"
    assert string == "hello test"

# Generated at 2022-06-12 09:44:02.003479
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Sane behaviour
    assert load_module_from_file_location("test_utils", "utils.py").__file__
    assert load_module_from_file_location("test_utils", "./utils.py").__file__
    assert (
        load_module_from_file_location("test_utils", Path("utils.py")).__file__
    )
    assert load_module_from_file_location("test_utils", b"utils.py").__file__
    assert (
        load_module_from_file_location("test_utils", Path("utils.py"))
        == load_module_from_file_location("test_utils", "utils.py")
    )

    # Wrong encoding

# Generated at 2022-06-12 09:44:11.165852
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover
    import shlex
    import unittest

    from pathlib import Path

    class LoadModuleFromFileLocationTestCase(unittest.TestCase):
        def setUp(self):
            """Prepare test file for testing function."""
            self.tmp_path = Path(__file__).parent / "test_file.py"
            self.tmp_path.write_text(
                textwrap.dedent(
                    """
                    some_var=12
                    some_other_var="Hello world"

                    class SomeClass:
                        def __init__(self, some_value):
                            self.some_value = some_value

                        def some_method(self):
                            return self.some_value
                    """
                )
            )


# Generated at 2022-06-12 09:44:16.989846
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile(mode="wb") as file:
        file.write(
            b"""t = 1
            def f():
                return 1
            """
        )
        file.flush()
        try:
            load_module_from_file_location(file.name)
        except Exception as e:
            assert (
                False
            ), f"load_module_from_file_location failed with {str(e)}"

# Generated at 2022-06-12 09:44:20.749036
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("./tests/test_module.py")
    assert module.__name__ == "test_module"
    assert module.some_attr == "Value"
    assert module.some_function() == "Value"

# Generated at 2022-06-12 09:44:30.610154
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""

    # START: Tests for name parameter
    test_module_name = "test_module"
    test_module = load_module_from_file_location(test_module_name)
    assert (
        test_module.__name__ == test_module_name
    ), """Expected module with name '{}',
        but got '{}'.""".format(
        test_module_name, test_module.__name__
    )

    # END: Tests for name parameter

    # START: Tests for location parameter

    # A) Import module named test_module.
    #   A1) It should be imported from current directory.
    #   A2) It should have the same name as module from test A1.
    #   A3) It should be imported

# Generated at 2022-06-12 09:44:39.805678
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import json
    from os import environ, pathsep
    from tempfile import TemporaryDirectory

    from jinja2 import Template

    from sanic.exceptions import LoadFileException

    # Preparing and defining test environment variables.
    environ["ENV_VAR_ONE"] = "test_env_var_1"
    environ["ENV_VAR_TWO"] = "test_env_var_2"
    environ["ENV_VAR_THREE"] = "test_env_var_3"
    # Because function load_module_from_file_location is using subprocess.popen,
    # we have to add path to the current directory in os.environment['PATH']
    environ["PATH"] += pathsep + r"."

# Generated at 2022-06-12 09:44:47.211567
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 1) Using just simple file path
    config_file = Path("tests/configs/config.py")
    config = load_module_from_file_location(config_file)
    assert isinstance(config, types.ModuleType)
    assert isinstance(config.SOME_STRING_SETTING, str)
    assert config.SOME_STRING_SETTING == "some_string_setting"

    # 2) Using environment variables in file path

    # 2.1) Set some environment variable
    os_environ["SANIC_ENV_VARIABLE"] = "some_string_setting"

    # 2.2) Path which contains environment variable
    config_file = Path("tests/configs/${SANIC_ENV_VARIABLE}.py")

# Generated at 2022-06-12 09:44:59.107515
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sys import modules
    from os import environ

    sys_modules_copy = modules.copy()
    environ["some_env_var"] = "some_value"
    try:
        module = load_module_from_file_location(
            "some_module_name", "${some_env_var}"
        )

    finally:
        modules.clear()
        modules.update(sys_modules_copy)
        del environ["some_env_var"]
    return module.__name__



# Generated at 2022-06-12 09:45:05.663498
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["some_env_var"] = "some_val"
    # some_module = load_module_from_file_location(
    #     "some_module_name",
    #     "/some/path/${some_env_var}"
    # )
    # assert some_module == None
    os_environ["some_env_var"] = "/Users/ed/Dev/sanic-env/tests/test_config.py"
    test_module = load_module_from_file_location(
        "some_module_name",
        "/Users/ed/Dev/sanic-env/tests/${some_env_var}",
    )
    assert hasattr(test_module, "FOO")
    assert hasattr(test_module, "BAR")

# Generated at 2022-06-12 09:45:14.947669
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Testing not existing file
    try:
        load_module_from_file_location("./not_existing")
    except LoadFileException as e:
        assert str(e) == "Unable to load configuration file (e.strerror)"
    else:
        assert False

    # B) Testing file with environment variable
    from os import name as os_name

    if os_name == "nt":
        from os import getenv as os_getenv
        from os import setenv as os_setenv
        from os import unsetenv as os_unsetenv

        os_setenv("PATH", "test_value")

# Generated at 2022-06-12 09:45:24.475229
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # 1. with env_var_in_location
    os_environ["some_env_var"] = "some_dir"
    module = load_module_from_file_location(
        "file.py", "/some/path/${some_env_var}", "rb"
    )
    assert module.__file__ == "/some/path/some_dir/file.py"

    # 2. without env_var_in_location
    module = load_module_from_file_location(
        "file.py", "/some/path/some_dir/file.py", "rb"
    )
    assert module.__file__ == "/some/path/some_dir/file.py"

    # 3. with Path

# Generated at 2022-06-12 09:45:32.487102
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests if function load_module_from_file_location works properly."""

    # A) Test simple loading.
    content = """#!/usr/bin/env python3
config_key = 1234
config_key_2 = "1234"
config_key_3 = 5678
"""
    location = "/tmp/sanic_test_load_configuration_file"
    with open(location, "w") as f:
        f.write(content)
    loaded_module = load_module_from_file_location(location)
    assert vars(loaded_module) == {
        "config_key": 1234,
        "config_key_2": "1234",
        "config_key_3": 5678,
    }

    # B) Test with environment variables

# Generated at 2022-06-12 09:45:37.745930
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def get_load_module_from_file_location_with_args(
        location_arg, *args, **kwargs
    ):
        def load_module_from_file_location_with_args(
            location: Union[bytes, str, Path]
        ):
            return load_module_from_file_location(location, *args, **kwargs)

        return load_module_from_file_location_with_args

    # A) Check if you can load module provided as a string path.
    #    Just module name is provided.

# Generated at 2022-06-12 09:45:45.876936
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D103
    import_string = load_module_from_file_location(
        "tests.test_helpers.test_helpers_module"
    )
    assert import_string.SOME_TEST_STRING == "SOME_TEST_STRING"

    with pytest.raises(IOError):
        load_module_from_file_location(
            "/non/existent/path.py", "some_name", "some_loader"
        )

    with pytest.raises(PyFileError):
        load_module_from_file_location(
            "tests.test_helpers.raise_file_error",
            "some_name",
            "some_loader",
        )



# Generated at 2022-06-12 09:45:55.107191
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic.testing import SanicTestClient
    from sanic.app import Sanic
    from sanic.config import Config
    from sanic.exceptions import PyFileError

    # Check that fucntion works with bytes.
    app = Sanic(
        "test_load_module_from_file_location",
        load_env=False,
        config=load_module_from_file_location(
            bytes("test_data/config_for_testing.py", "utf8")
        ),
    )

    # Check that fucntion work with paths.

# Generated at 2022-06-12 09:46:02.823529
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Sanity check for load_module_from_file_location function.
    """
    from Sanic_envconfig.config import Config

    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        config_path = Path(temp_dir) / "config.py"
        config_text = """
        TESTING = False
        SECRET_KEY = "123"
        TEST_CONFIG_VAR = "42"
        """

        with open(config_path, "w") as file:
            file.write(config_text)

        config = load_module_from_file_location(config_path)
        assert hasattr(config, "TESTING")
        assert getattr(config, "TESTING") is False

        assert hasattr(config, "SECRET_KEY")
        assert get

# Generated at 2022-06-12 09:46:11.518609
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["CONFIG_PATH"] = str(Path(__file__).parents[1] / "config")
    config = load_module_from_file_location("example_config.yml")
    assert config.TEST == "success"
    config = load_module_from_file_location("$CONFIG_PATH/example_config.yml")
    assert config.TEST == "success"
    config = load_module_from_file_location("example_config.json")
    assert config.TEST == "success"
    config = load_module_from_file_location("$CONFIG_PATH/example_config.json")
    assert config.TEST == "success"
    config = load_module_from_file_location("/example_config.json")
    assert config.TEST == "success"


# Generated at 2022-06-12 09:46:30.497108
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import re
    import pathlib
    from sanic.utils import load_module_from_file_location

    # Test with string as location
    config_file_1 = "some_module.py"
    with open(config_file_1, "w") as temp:
        temp.write("some_key='some_value'")

    module = load_module_from_file_location(config_file_1)
    assert "some_key" in module.__dict__
    os.remove(config_file_1)

    # Test with Path as location
    config_file_2 = "some_module.py"
    with open(config_file_2, "w") as temp:
        temp.write("some_key='some_value'")

    path_config_file_2

# Generated at 2022-06-12 09:46:39.797126
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 1) Check that it recognizes valid paths
    assert "test_module" in load_module_from_file_location(
        "test_module", "./tests/test_module.py"
    ).__dict__

    assert (
        load_module_from_file_location(
            "test_module", "./tests/test_module.py"
        ).test_value
        == 1
    )

    assert "test_module" in load_module_from_file_location(
        b"./tests/test_module.py", b"./tests/test_module.py"
    ).__dict__


# Generated at 2022-06-12 09:46:49.672998
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Bytes path location
    location = b"/some/path/to/config.py"
    name = location.decode("ascii").split("/")[-1].split(".")[0]
    # A) Check case when location points to existing file
    assert name == load_module_from_file_location(location).__name__
    # B) Check that LoadFileException is raised when location points
    #    to not existing file.

# Generated at 2022-06-12 09:46:59.232189
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test that function load_module_from_file_location loads
    # environment variables.
    os_environ.update({"ENV_VAR":"ENV_VAR"})

    try:
        load_module_from_file_location(
            "tests/configs/${ENV_VAR}_test_config.py"
        )
    except LoadFileException as e:
        assert "The following environment variables are not set" in str(e)
    else:
        assert False, "Should raise LoadFileException."

    try:
        load_module_from_file_location(
            "tests/configs/${ENV_VAR_NOT_SET}_test_config.py"
        )
    except LoadFileException as e:
        assert "The following environment variables are not set" in str(e)


# Generated at 2022-06-12 09:47:04.266201
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    This function tests that function
    load_module_from_file_location
    functions properly.
    """
    location = "test_module.py"
    module = load_module_from_file_location(location)
    assert module.__file__ == location
    assert module.TEST_MODULE_STRING == "this is only a test"

# Generated at 2022-06-12 09:47:14.757632
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Check that function can load valid python module.
    class SubModule:
        pass

    class Module:
        submodule = SubModule()

    mod_name = "module"
    mod = types.ModuleType(mod_name)
    mod.__file__ = "module.py"
    mod.__dict__[mod_name] = Module()

    assert (
        load_module_from_file_location("module.py") == mod
    ), "Should load valid python module."
    # Check that function can load module from .py source code.
    class SubModule:
        pass

    class Module:
        submodule = SubModule()


# Generated at 2022-06-12 09:47:21.498499
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # TODO
    test_module = load_module_from_file_location(
        "tests.test_helpers.test_helpers_test_module_config"
    )
    print(
        test_module.some_string,
        test_module.some_string_no_override,
        test_module.some_integer,
    )
    os_environ["TEST_EXAMPLE_ENV_VAR"] = "ciao mondo"
    os_environ["TEST_EXAMPLE_ENV_VAR2"] = "Hola mundo"
    test_module = load_module_from_file_location(
        "tests/test_helpers/test_helpers_test_module_config.py"
    )

# Generated at 2022-06-12 09:47:30.452875
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    os.chdir("tests")

    # Some tests for loading files
    test_module = load_module_from_file_location("test_file")
    assert test_module.name == "test_file"

    test_module = load_module_from_file_location("test_file.py")
    assert test_module.name == "test_file"

    test_module = load_module_from_file_location("/test_file")
    assert test_module.name == "test_file"

    test_module = load_module_from_file_location("/test_file.py")
    assert test_module.name == "test_file"

    test_module = load_module_from_file_location("subdir/subdir_2/test_file")

# Generated at 2022-06-12 09:47:38.473795
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    class TestClass():
        """Class for testing"""
        pass

    # 1. If location is just a string (module name)
    module = load_module_from_file_location(
        "sanic.server"
    )  # so we are sure that we have this module
    assert module.__name__ == "sanic.server"

    # 2. If location is just a Path
    module = load_module_from_file_location(Path(__file__))
    assert hasattr(module, "TestClass")

    # 3. If location is just a string (path)
    module = load_module_from_file_location(__file__)
    assert hasattr(module, "TestClass")

    # 4. If location is just a string (path) with environment variable

# Generated at 2022-06-12 09:47:48.064322
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    location = "sanic.testsuite.config_utils.test2"
    actual_module = load_module_from_file_location(location)
    assert actual_module.name == "test2" and actual_module.surname == "test2"

    location = "sanic.testsuite.config_utils.${SURNAME}"
    os_environ["SURNAME"] = "test2"
    actual_module = load_module_from_file_location(location)
    assert actual_module.name == "test2" and actual_module.surname == "test2"
    os_environ.pop("SURNAME")

    location = "sanic.testsuite.config_utils.${SURNAME}"