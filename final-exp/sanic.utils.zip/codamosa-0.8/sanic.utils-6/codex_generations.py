

# Generated at 2022-06-12 09:38:07.074986
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = Path(__file__).parent / "test_load_from_location.py"
    location = str(location)
    module = load_module_from_file_location(location, "utf8")
    assert module.A == "some"
    assert module.B == 1
    assert module.C == "b"
    assert module.D == True
    assert module.E == False
    assert module.F == "some value"


if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-12 09:38:12.084035
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unit test for function load_module_from_file_location.

    It is checking, that environment variables work in location parameter.

    Note:
        To run unit test for this function use pytest.
    """
    from unittest import mock


# Generated at 2022-06-12 09:38:21.106766
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""

    import tempfile

    from os import path as os_path

    from os import environ as os_environ

    # A) Check if function load_module_from_file_location
    #    raises an exception if we pass a module name
    #    that cannot be found in path.
    with tempfile.TemporaryDirectory() as tmpdir:
        with pytest.raises(LoadFileException) as e:
            load_module_from_file_location(
                os_path.join(tmpdir, "config.py")
            )

    # B) Check if function load_module_from_file_location
    #    loads module if we pass a module name that can be found
    #    in path.

# Generated at 2022-06-12 09:38:28.577181
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    def check(location, expected):
        module = load_module_from_file_location(location)
        if module.__name__ == expected:
            return True
        else:
            raise Exception(
                "__name__ is not equal. \n"
                f"Was: {module.__name__}. \n"
                f"Should be: {expected}."
            )

    assert check(__file__, "test_helpers")
    assert check(
        f"{Path.home()}/Developer/sanic/sanic/.env", "sanic/.env"
    )
    assert check(
        f"{Path.home()}/Developer/sanic/sanic/tests/unit_tests/examples/config_from_string.py",
        "config_from_string",
    )

# Generated at 2022-06-12 09:38:39.376632
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import time
    import os

    def clean_up_test_files(test_dir: str, files: set):
        for file in files:
            os.remove(os.path.join(test_dir, file))
        tempfile.tempdir = None
        os.removedirs(test_dir)

    # A module with function
    # def some_function():
    #     return "some_value"
    some_module_content = """def some_function():
        return "some_value"
    """

    # another module with class
    # class SomeClass:
    #     def some_method(self):
    #         return "some_value"
    some_module_content_2 = """class SomeClass:
        def some_method(self):
            return "some_value"
    """

# Generated at 2022-06-12 09:38:46.511020
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import os
    import subprocess

    import pytest

    # On Windows this function will not work.
    if os.name == "nt":
        pytest.skip("Test is not available on Windows due to env var management.")

    import sys
    import types
    import uuid

    from io import StringIO

    from .utils import get_test_directory

    from sanic.exceptions import LoadFileException

    pytest_dir = get_test_directory()

    # test_load_module_from_file_location
    def _test_load_module_from_file_location(location, module_name):
        module = load_module_from_file_location(location)
        assert isinstance(module, types.ModuleType)
        assert module.__name__ == module_name
        assert module.__file__

    # _test

# Generated at 2022-06-12 09:38:57.105511
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    class BaseFile:
        contents = ""

    class MockFile(BaseFile):
        pass

    class FailedMockFile(BaseFile):
        raise_exception = False

        def __enter__(self):
            return self

        def __exit__(self, type, value, traceback):
            if self.raise_exception:
                raise ValueError('Mocking IOError exception')

        def read(self):
            if self.raise_exception:
                return self.contents
            raise IOError('Mocking IOError exception')

        def write(self, contents):
            self.contents = contents


# Generated at 2022-06-12 09:39:06.124807
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Create a dummy module

    dummy_module_location = "/tmp/dummy_module.py"
    with open(dummy_module_location, "w") as dummy_module:
        dummy_module.write("name = 'dummy_module'")
    try:
        dummy_module = load_module_from_file_location(dummy_module_location)

        assert dummy_module.__name__ == "dummy_module"
    finally:
        os.remove(dummy_module_location)

    # Create a dummy module with path
    dummy_module_location = "/tmp/dummy_module.py"
    os.makedirs("/tmp/tmp/", exist_ok=True)

# Generated at 2022-06-12 09:39:15.441175
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import pytest

    from .path import local_path
    from .test_helpers import NO_BAR_EXCEPTION_MATCH

    # CONFIG_PATH does not contain environment variable
    CONFIG_PATH = local_path("config.py")
    module = load_module_from_file_location(CONFIG_PATH)

    assert module.TEST_CONFIG == 5
    assert module.TEST_CONFIG_2 == ["test"]
    assert module.TEST_CONFIG_3 == {"test": 4}

    # CONFIG_PATH contains environment variable  "${VARIABLE_NAME}"
    CONFIG_PATH = local_path(".env/${VARIABLE_NAME}")

    # VARIABLE_NAME variable is not set in environment
    #  This should raise LoadFileException

# Generated at 2022-06-12 09:39:23.337920
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        "/tmp/test.py",
        """
test = "test data"
"""
    )
    assert module.test == "test data"
    try:
        module = load_module_from_file_location(
            "../tests/test_module.py"  # noqa
        )
        assert module.test_var == "test data"
    except IOError:
        # When running from venv, module path id different
        pass
    try:
        module = load_module_from_file_location(
            "../test_module.py"  # noqa
        )
        assert module.test_var == "test data"
    except IOError:
        # When running from venv, module path id different
        pass

# Generated at 2022-06-12 09:39:35.788612
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 09:39:44.462972
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os.path
    import tempfile
    import unittest
    import unittest.mock
    import sanic.exceptions

    expected_keys = {"a", "b", "c"}

    # A) Load module from file with path
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_file = os.path.join(temp_dir, "file.py")
        with open(temp_file, "w") as temp_file_obj:
            temp_file_obj.write("""
                a = "a"
                b = "b"
                c = "c"
            """)
        module = load_module_from_file_location(temp_file)
        assert set(dir(module)) == expected_keys

    # B) Load module from file without path

# Generated at 2022-06-12 09:39:51.439588
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Testing function load_module_from_file_location."""

    # Test that it is possible to import .py file as module
    # from its path.
    path_to_py_file = (Path(__file__).parent.parent / "doc" / "index.python.rst")
    assert (
        load_module_from_file_location(path_to_py_file).__name__
        == "doc.index.python"
    )
    # Test that it is possible to import .py file as module
    # from its path encoded in string.
    assert (
        load_module_from_file_location(path_to_py_file.__str__()).__name__
        == "doc.index.python"
    )

    # Test that it is possible to import .py file as module
    # from

# Generated at 2022-06-12 09:39:55.510394
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test just loading config module
    module = load_module_from_file_location("config.py")
    assert module.__name__ == "config"

    module = load_module_from_file_location("/etc/passwd")
    assert module.__name__ == "config"

# Generated at 2022-06-12 09:40:02.680746
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(tmpdirname + "/tmp.py", "w") as fd:
            fd.write("some_var = 'some_value'")

        module = load_module_from_file_location(
            f"{tmpdirname}/tmp.py", location=tmpdirname
        )

        assert module.some_var == "some_value"

        os_environ["app_env"] = tmpdirname

        module = load_module_from_file_location(
            f"${app_env}/tmp.py", location=tmpdirname
        )

        assert module.some_var == "some_value"

# Generated at 2022-06-12 09:40:11.068412
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # importlib.util.spec_from_file_location
    # unittests before executing load_module_from_file_location
    importlib.util.spec_from_file_location(
        "name",
        "/some/path",
        submodule_search_locations=None,
        loader=None,
        origin=None,
    )
    with pytest.raises(TypeError):
        importlib.util.spec_from_file_location(
            "name",
            "/some/path",
            submodule_search_locations=None,
            loader=None,
            origin=None,
            foo="foo",
        )

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    #    Should return set of ('some_env_var',)


# Generated at 2022-06-12 09:40:17.143941
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Check that file, that doesn't exist causes LoadFileException error.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("./test_file")

    # 1. Check that we can load module provided with path to it.
    test_module = load_module_from_file_location("tests/test_module.py")

    assert test_module.test_var == "example_value"

    # 2. Check that we can load module provided with path to it,
    #    with sub path in it.
    test_module = load_module_from_file_location("tests/test_folder/test_module")

    assert test_module.test_var == "example_value"

    # 3. Check that we can load module provided with path to it,
    #    with file name.


# Generated at 2022-06-12 09:40:26.204974
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import mkstemp
    from os import close, environ

    environ["some_env_var"] = "from_some_env_var"  # set environment variable

    # A) Create temporary file.
    fd, filename = mkstemp()
    tmp_file = open(filename, "w")
    tmp_file.write("some_var = 'from_file'")
    tmp_file.close()
    close(fd)

    # B) Load module from it using function we are testing
    module = load_module_from_file_location(filename)

    # C) Check that we loaded some_var value.
    assert module.some_var == "from_file"

    # D) Load module from it using function we are testing, but now without
    #    environment variable.
    module = load_module_

# Generated at 2022-06-12 09:40:33.246393
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 1. Test that function correctly loads python file
    #    in current directory.
    assert (
        load_module_from_file_location("sanic_utils/test_helpers.py").name
    ) == "sanic_utils.test_helpers"

    # 2. Test that function correctly loads python file
    #    in current directory with a path.
    assert (
        load_module_from_file_location("sanic_utils/test_helpers")
        .sanic_utils.test_helpers.name
    ) == "sanic_utils.test_helpers"

    # 3. Test that function correctly loads python file
    #    in specified directory.

# Generated at 2022-06-12 09:40:39.421755
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest

    from os import environ

    from os import mkdir
    from os import remove
    from os import rmdir
    from pathlib import Path

    # Part 1:
    #       A) Check if location contains any environment variables
    #          in format ${some_env_var}.
    #       B) Check these variables exists in environment.
    #       C) Substitute them in location.
    with pytest.raises(
        LoadFileException,
        match="The following environment variables are not set: "
        "UNDEFINED_ENV_VAR",
    ):
        load_module_from_file_location(
            "/some/path/${UNDEFINED_ENV_VAR",
            "/some/path/${UNDEFINED_ENV_VAR}",
        )

# Generated at 2022-06-12 09:40:45.437442
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import unittest
    from os import environ as os_environ

    class TestLoadModuleFromFileLocation(unittest.TestCase):
        def setUp(self) -> None:
            env_var = "TEST_ENV_VAR"

            # Avoid changing original os.environ.
            self.os_environ = os_environ.copy()

            # Get temporary file handle.
            self.conf_file = tempfile.NamedTemporaryFile()

        def tearDown(self) -> None:
            os.environ = self.os_environ

        def test_load_module_from_str(self):
            """Test for loading module from string"""

            self.conf_file.write(b"test_config = 123\n")

# Generated at 2022-06-12 09:40:54.751513
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    class _TestModule(types.ModuleType):
        pass

    test_module = _TestModule("test_module")
    test_module.__file__ = "test_module.py"
    test_module.var = 15

    location = "test_module.py"
    module = load_module_from_file_location(location)
    assert module.var == 15

    location = Path("test_module.py")
    module = load_module_from_file_location(location)
    assert module.var == 15

    location = "test_module.py".encode("utf8")
    module = load_module_from_file_location(location)
    assert module.var == 15

    location = b"test_module.py"
    module = load_module_from_file_location(location)

# Generated at 2022-06-12 09:41:04.456179
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    from os import environ as os_environ
    from os import path as os_path
    from pathlib import Path

    empty_mod_spec = importlib.util.spec_from_file_location(
        "some_module_name", "/some/path/to/some/file.py"
    )

    def mock_module_from_spec(*args, **kwargs):
        if args[0] is empty_mod_spec:
            raise Exception("Dummy error")
        else:
            return types.ModuleType("config")

    with patch(
        "sanic.helpers.load_module_from_file_location.module_from_spec",
        side_effect=mock_module_from_spec,
    ):
        with pytest.raises(LoadFileException):
            load_module_

# Generated at 2022-06-12 09:41:13.795184
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    # Set env vars
    os.environ["HOME"] = os.path.dirname(__file__)
    os.environ["TEST_ENV_VAR"] = "test_env_var"

    # A) Case with Path
    # ----------
    # A.1) Case with just Path
    # ----------
    module = load_module_from_file_location(Path(__file__))
    assert module.__file__ == __file__

    # A.2) Case with just Path and additional parameters
    # ----------

# Generated at 2022-06-12 09:41:23.192204
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Should be able to load module specified as Path
    config = Path("tests/unit/config/config_file.py")
    loaded_config = load_module_from_file_location(config)
    assert isinstance(loaded_config, types.ModuleType)

    # B) Should be able to load module specified as string
    config = "tests/unit/config/config_file.py"
    loaded_config = load_module_from_file_location(config)
    assert isinstance(loaded_config, types.ModuleType)

    # C) Should be able to load module specified as bytes
    config = bytes("tests/unit/config/config_file.py", "utf8")
    loaded_config = load_module_from_file_location(config)
    assert isinstance(loaded_config, types.ModuleType)

   

# Generated at 2022-06-12 09:41:26.751557
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location(
            __file__, "/" + "${SOME_ENV_VAR_THAT_MUST_NOT_EXIST}/__main__.py"
        )
        is None
    )

# Generated at 2022-06-12 09:41:32.370276
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import importlib

    # Create temporary folder
    with tempfile.TemporaryDirectory() as tmpdirname:
        filename = os.path.join(tmpdirname, "test_file.py")

        # Create test data
        test_data = [
            "test_var_a = True\n",
            "# A comment\n",
            "\n",
            "test_var_b = False",
            "test_var_c = 'test_str'\n",
            "test_var_d = ['test_str_1', 'test_str_2', 'test_str_3']",
        ]

        # Create test file
        with open(filename, "w") as file:
            file.writelines(test_data)


# Generated at 2022-06-12 09:41:42.949856
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test 1
    # Create a dummy_module.py in a temporary directory
    import tempfile
    import os
    import shutil
    import sys
    # Create a temp dir.
    tmp_dir_path = Path(tempfile.mkdtemp())
    # Add tmp dir to sys path
    sys.path.append(str(tmp_dir_path))
    tmp_dir_path_str = str(tmp_dir_path)
    # Create dummy_mod.py
    tmp_file_path = tmp_dir_path / "dummy_mod.py"
    with tmp_file_path.open("w+") as tmp_file:
        tmp_file.write("a = 5")
    # Import dummy_mod.py
    module_from_path = load_module_from_file_location(tmp_file_path)

# Generated at 2022-06-12 09:41:50.439787
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_string
    """

    Test cases:
    1) Test if import_string works as expected.
    2) Test if it works with pathlib.Path.
    3) Test if it works with bytes.
    4) Test if it works with str.
    5) Test if it works with str as is.
    6) Test if it works with str as str.
    7) Test if it works with str as $ENV_VAR.
    8) Test if it works with str as ${ENV_VAR}.
    9) Test if it works with str as path with ENV_VAR.
    10) Test if it works with str as path with ${ENV_VAR}.
    11) Test if it works with str as path with $ENV_VAR.
    """

    # Test case 1)
    # Test if import_

# Generated at 2022-06-12 09:41:59.853494
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa

    import os
    import tempfile
    from pathlib import Path

    def create_temp_pyfile(fname: str, content: str):
        resource = tempfile.NamedTemporaryFile(delete=False)
        resource.write(bytes(content, "utf-8"))
        resource.close()
        return resource.name

    def remove_temp_pyfile(fname: str):
        Path(fname).unlink()

    try:
        fname = create_temp_pyfile("temp.py", "WARG=5")
        module = load_module_from_file_location(fname)
        assert module.WARG == 5
    finally:
        remove_temp_pyfile(fname)


# Generated at 2022-06-12 09:42:11.060491
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Checking load_module_from_file_location function"""

    # Checking environment variables.
    test_location = "/${PROJECT_ROOT}/config/"
    # Checking if PROJECT_ROOT is defined in environment.
    if "PROJECT_ROOT" not in os_environ:
        os.environ["PROJECT_ROOT"] = os.path.realpath(__file__)
    test_config = load_module_from_file_location(test_location)
    assert test_config.__file__.strip("/") == os.environ["PROJECT_ROOT"]
    # Checking if PROJECT_ROOT is not defined in environment.
    del os.environ["PROJECT_ROOT"]

# Generated at 2022-06-12 09:42:19.522138
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    here = os.path.dirname(__file__)
    os.environ["DEV_CONFIG_PY"] = here

    # A) Check if case with environment variables works.
    module = load_module_from_file_location(
        "/some/path/${DEV_CONFIG_PY}/test_config_file.py"
    )
    assert module.test_variable == "test_value"

    # B) Check if case with non environment variables works.
    module = load_module_from_file_location(
        os.path.join(here, "/test_config_file.py")  # type: ignore
    )
    assert module.test_variable == "test_value"

    # C) Check if case with bytes works.

# Generated at 2022-06-12 09:42:29.929965
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Test 1
    config_file_path = Path(__file__).with_name("config_for_testing.py")

    # Test 1.1
    assert config_file_path.exists()

    # Test 1.2
    with config_file_path.open() as config_file:
        config_file_content = config_file.read()

    # Test 1.3
    test_module = load_module_from_file_location(config_file_path)

    # Test 1.4
    assert test_module.TEST_ATTRIBUTE == 123

    # Test 1.5
    assert test_module.__file__ == str(config_file_path)

    # Test 2

# Generated at 2022-06-12 09:42:39.865911
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("os").__name__ == "os"
    assert load_module_from_file_location(__name__).__name__ == __name__

    os_path = os.path.dirname(os.path.dirname(__file__))

    # Testing environment variable resolving.
    os.environ["SANIC_TEST"] = os_path
    assert load_module_from_file_location(
        "sanic.utils.${SANIC_TEST}/helpers.py"
    ).__name__ == "helpers"
    del os.environ["SANIC_TEST"]

    # Testing resolving environment variable as a path.

# Generated at 2022-06-12 09:42:47.225469
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory

    from pytest import raises

    # A) Creating temporary directory as a directory for loading file (location).
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        # B) File with name `test_conf.py` will be created:
        test_conf_location = tmp_dir / "test_conf.py"
        # C) In the file following code will be put:
        test_conf_code = """
            some_var = "some_value"
            some_list = [1,2,3]
            some_dict = {'a': 1, 'b': 2, 'c': 3}
            """
        # D) Create test_conf.py file in temp directory.

# Generated at 2022-06-12 09:42:55.956424
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import logging
    import os.path
    import pytest
    import sys

    # Prepare testing environment
    current_directory = os.path.dirname(os.path.abspath(__file__))
    some_existing_file_loc = os.path.join(current_directory, "some_file.py")
    some_existing_file_loc_not_ending_with_dot_py = os.path.join(
        current_directory, "some_file"
    )
    some_dir_loc = os.path.join(current_directory, "some_dir")
    some_non_existing_file_loc = os.path.join(
        current_directory, "some_non_existing_file.py"
    )
    some_env_var_name = "EXISTING_ENV_VAR"


# Generated at 2022-06-12 09:43:04.085868
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "tests/test_deprecated/test_config/config.py"
    assert load_module_from_file_location(location).__name__ == "config"

    location = "tests/test_deprecated/test_config/config.pyc"
    assert load_module_from_file_location(location).__name__ == "config"

    location = "tests/test_deprecated/test_config/config.pyc".encode()
    assert load_module_from_file_location(location).__name__ == "config"

    location = "tests/test_deprecated/test_config/config.py"
    assert load_module_from_file_location(
        location, Path(location)
    ).__name__ == "config"

    location = "tests/test_deprecated/test_config"
   

# Generated at 2022-06-12 09:43:11.333178
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import shutil
    import tempfile

    def write_config_file(path, config):
        with open(path, "w") as config_file:
            config_file.write(config)

    class TempDirFixture:
        def __init__(self, **kwargs):
            self.__kwargs = kwargs
            self.__temp_dir = None

        def __enter__(self):
            self.__temp_dir = tempfile.TemporaryDirectory(**self.__kwargs)
            return self.__temp_dir.name

        def __exit__(self, type, value, traceback):
            self.__temp_dir.cleanup()


# Generated at 2022-06-12 09:43:18.987127
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    os_environ["TEST_LOAD_MODULE_FROM_FILE_LOCATION"] = "1"
    assert os_environ["TEST_LOAD_MODULE_FROM_FILE_LOCATION"] == "1"

    import tempfile
    from inspect import ismodule

    # Test that function is able to handle environment variables.
    temp_file = tempfile.NamedTemporaryFile(mode="w+")
    temp_file.write("test_variable = 1")
    temp_file.seek(0)
    module = load_module_from_file_location(
        temp_file.name, encoding="utf8"
    )  # load module with variable
    assert ismodule(module)  # check that module is loaded

    # Check that module object has variable.
    assert "test_variable" in vars

# Generated at 2022-06-12 09:43:22.890638
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 1)
    load_module_from_file_location(
        '/some_path/some_module.py', 'config',
    )
    # 2)
    load_module_from_file_location(
        '/some_path/${some_env_var}/some_module.py', 'config',
    )

# Generated at 2022-06-12 09:43:30.632605
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Unit test for function load_module_from_file_location.
    """
    # 1. Test case when location contains environment variables.
    module_a = load_module_from_file_location(
        "${RANDOM_ENV_VAR}",
        "/some/path/${RANDOM_ENV_VAR}",
    )
    assert module_a.__file__ == (
        os_environ["RANDOM_ENV_VAR"] + "/some/path/" + os_environ["RANDOM_ENV_VAR"]
    )

    # 2. Test case when location does not contain environment variables.
    module_b = load_module_from_file_location("/some/path/",)
    assert module_b.__file__ == "/some/path/"

    # 3

# Generated at 2022-06-12 09:43:39.278020
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    def _test_module(config_module):
        assert hasattr(config_module, "VAR1")
        assert hasattr(config_module, "VAR2")
        assert config_module.VAR1 == os_environ["VAR1"]
        assert config_module.VAR2 == os_environ["VAR2"]

    base_tmp_dir = Path(__file__).parent
    test_conf_py = base_tmp_dir / "config_py.py"
    test_conf_py_str = test_conf_py.as_posix()

    test_conf_txt = base_tmp_dir / "config_txt.txt"
    test_conf_txt_str = test_conf_txt.as_posix()


# Generated at 2022-06-12 09:43:49.017153
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os
    import sys
    import tempfile

# Generated at 2022-06-12 09:43:58.197812
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()

    # create module file
    test_module_file_path = os.path.join(temp_dir, "test.py")

    with open(test_module_file_path, "w") as test_module_file:
        test_module_file.write("TEST = True")

    # load module from file
    test_module = load_module_from_file_location(Path(test_module_file_path))

    # check if test_module has TEST attribute and it is True
    assert hasattr(test_module, "TEST")
    assert test_module.TEST is True

    # clean after yourself
    shutil.rmtree(temp_dir)

# Generated at 2022-06-12 09:44:07.739480
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    some_dict = {}

    # 1) load module from file with .py extension
    some_dict["1_some_module"] = load_module_from_file_location(
        "tests.database.configs.1_some_module"
    )
    assert some_dict["1_some_module"].some_value == "some_value"

    # 2) load module from file with NOT .py extension
    some_dict["2_some_module"] = load_module_from_file_location(
        "tests.database.configs.2_some_module"
    )
    assert some_dict["2_some_module"].some_value == "some_value"

    # 3) load module from path

# Generated at 2022-06-12 09:44:15.649269
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert str_to_bool("true")
    assert not str_to_bool("false")
    with pytest.raises(ValueError) as e:
        str_to_bool("blah")
    assert str(e.value) == "Invalid truth value blah"

    config_path = str(Path(__file__).parent / "test_app.py")
    config = load_module_from_file_location(config_path)
    assert config.TEST == "TEST"

    # Passing a wrong path.
    with pytest.raises(IOError):
        load_module_from_file_location("tests/wrong_path")

# Generated at 2022-06-12 09:44:22.192005
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from os import remove, environ
    import pytest

    # 1. Test for module name
    module = load_module_from_file_location("os")
    assert "os" == module.__name__

    # 2. Test for local file
    with NamedTemporaryFile(
        mode="w", suffix=".py", encoding="utf8"
    ) as temp_config_file:
        temp_config_file.write("TEST_STR = 'TEST_STR'")
        temp_config_file.flush()

        module = load_module_from_file_location(temp_config_file.name)
        assert "TEST_STR" == module.TEST_STR

        import sys
        assert sys.modules[module.__name__].__file__ == temp_config_file

# Generated at 2022-06-12 09:44:32.229575
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Sample usage of the function.
    This function is also the test case for the function.
    """
    # Create test file.
    with open("test_load_module_from_file_location.py", "w") as file:
        file.write("import os\n")
        file.write("print('test')\n")

    # Create test environment variable.
    os_environ["test_var"] = "test_var_value"


# Generated at 2022-06-12 09:44:40.921482
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import io
    import os
    import shutil
    import sys
    import tempfile

    from os import environ

    def configure_environment_variables(temp_env_vars):
        for key, value in temp_env_vars.items():
            environ[key] = value

    def clean_environment_variables():
        for key, value in list(environ.items()):
            del environ[key]

    # Test loading module from a file.
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 09:44:46.309521
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # file location without '/' or '.'
    with pytest.raises(IOError):
        load_module_from_file_location("some_module_name")

    # file path to unexisting file
    with pytest.raises(FileNotFoundError):
        load_module_from_file_location("path/to/unexisting/file.py")

    # file path to unexisting file
    with pytest.raises(IOError):
        load_module_from_file_location("path/to/unexisting/file")

    # file path to file without extension
    with pytest.raises(IOError):
        load_module_from_file_location("path/to/unexisting/file/without/ext")

    # file path to folder - ./test/some_folder_without_py_file

# Generated at 2022-06-12 09:44:57.816179
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ, getcwd
    from os.path import abspath, dirname, join
    import tempfile

    # A) Test case with usage of environment variable in location.
    name = "PYTHON_CONFIG"
    value = abspath(
        join(dirname(__file__), "..", "..", "..", "examples")
    )  # Represents path to the examples folder.
    environ[name] = value
    try:
        module = load_module_from_file_location(
            "sanic_config", f"${name}/sanic_config.py"
        )
    except LoadFileException:
        assert False
    finally:
        environ.pop(name)
    assert module.DEBUG

    # B) Test case with usage of local path to the file.


# Generated at 2022-06-12 09:45:04.858898
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os
    import sys
    from os import environ
    from os.path import dirname, realpath
    from tempfile import mktemp

    from sanic.exceptions import PyFileError

    test_dir = dirname(realpath(__file__))
    test_path = mktemp(suffix=".py", dir=test_dir)

    # Make some python script in test_path
    with open(test_path, "w") as f:
        f.write("a = 3\n")

    # Add test_path to sys.path
    # and as location
    sys.path.insert(0, test_path)
    location = test_path

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.


# Generated at 2022-06-12 09:45:14.307247
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    os_environ["some_env_var"] = "some_env_var_value"
    os_environ["another_env_var"] = "another_env_var_value"
    test_module = load_module_from_file_location(
        "/some/path/${some_env_var}/${another_env_var}/some_module_name.py"
    )
    assert hasattr(test_module, "__name__")
    assert test_module.__name__ == "some_module_name"

    os_environ["some_env_var"] = "some_env_var_value"
    os_environ["another_env_var_2"] = "another_env_var_value_2"

# Generated at 2022-06-12 09:45:24.012417
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    def _test_case(
        location,
        some_env_var_value,
        expected_config_file_content,
        expected_error=None,
    ):
        # type: (str, str, str, Exception) -> None

        # Set some environment variable
        os_environ["some_env_var"] = some_env_var_value

        # A) When expected_error is set - check we raise it.
        if expected_error:
            with pytest.raises(expected_error):
                load_module_from_file_location(location)

        # B) When expected_error is not set - check if the file loaded
        #    correctly and has expected content.
        else:

            # Load config file.
            config_file = load_module_from_file_location(location)

            # Check if

# Generated at 2022-06-12 09:45:32.171628
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    # A) Valid module with imports.
    assert (
        load_module_from_file_location(
            os.path.dirname(os.path.abspath(__file__))
            + "/config_for_testing.py"
        ).MY_CONSTANT_VARIABLE_1
        == "some_value"
    )

    # B) Valid module without imports.
    assert (
        load_module_from_file_location(
            os.path.dirname(os.path.abspath(__file__))
            + "./config_for_testing_without_imports.py"
        ).MY_CONSTANT_VARIABLE_1
        == "some_value"
    )

    # C) Invalid

# Generated at 2022-06-12 09:45:36.683848
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "tests/test_files/environment_variables.py"
    module = load_module_from_file_location(location)

    assert getattr(module, "VAR1") == "Value1"
    assert getattr(module, "VAR2") == "Value2"
    assert getattr(module, "VAR3") == "Value3"
    assert getattr(module, "LOG_LEVEL") == "INFO"

    location = "tests/test_files/with_logging.py"
    module = load_module_from_file_location(location)

    assert getattr(module, "LOG_LEVEL") == "INFO"

# Generated at 2022-06-12 09:45:40.721083
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    module = load_module_from_file_location("./tests/factories.py")
    assert hasattr(module, "string_with_a_b_c")
    assert hasattr(module, "string_with_a_c")
    assert hasattr(module, "string_with_a_b")

# Generated at 2022-06-12 09:45:49.675936
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    class FakeEnvVars:
        def set(self, var_name: str, var_value: str) -> None:
            self.__dict__[var_name] = var_value

    env_vars_in_location = set(re_findall(r"\${(.+?)}", "${fake_env_var}"))
    assert env_vars_in_location == {"fake_env_var"}

    # B) Check these variables exists in environment.
    fake_env = FakeEnvVars()
    fake_env.set("fake_env_var", "fake")

# Generated at 2022-06-12 09:45:58.621241
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Function testing function load_module_from_file_location
    """
    os_environ['ONE_ENV_VAR'] = "1"
    os_environ['TWO_ENV_VAR'] = "2"

    assert load_module_from_file_location("sanic.app").__name__ == "sanic.app"
    assert load_module_from_file_location('sanic.app').__name__ == "sanic.app"

    assert load_module_from_file_location(
        "tests/test_utils.py"
    ).__name__ == "tests.test_utils"

    assert load_module_from_file_location(
        Path(__file__).parent / "test_utils.py"
    ).__name__ == "tests.test_utils"


# Generated at 2022-06-12 09:46:05.053436
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from sanic.config import ModuleNotFoundError

    # 1) Check if it's possible to load modules from file location
    #    and if it's possible to use environemnt variables
    #    in format ${some_env_var}.
    abs_path = os.path.abspath(__file__)
    path_to_this_file = Path(abs_path)
    dir_name = path_to_this_file.parent.parent.parent

    with patch.dict("os.environ", {"var": str(dir_name)}):

        # 1.1) We load module from absolute path
        module_1 = load_module_from_file_location(dir_name)

        # 1.2) We load module from absolute path using environment variable
        module_2 = load_module_from_file_location

# Generated at 2022-06-12 09:46:20.194535
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pylint: disable=unused-variable
    from os import environ
    from os import mkdir
    from os import path
    from os import remove
    from shutil import rmtree

    from pytest import raises

    environ["TEST_ENV_VAR"] = "test_var_value"

# Generated at 2022-06-12 09:46:28.172768
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from unittest import mock

    # checking if loading string fails
    with mock.patch(
        "importlib.util.module_from_spec",
        side_effect=TypeError("this is not a real error"),
    ):
        with mock.patch("importlib.util.spec_from_file_location"):
            try:
                load_module_from_file_location("some_string")
            except PyFileError:
                pass

    # checking if loading file object fails

# Generated at 2022-06-12 09:46:37.892344
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def create_test_file_with_content(content):
        path = Path.cwd() / "some_file.py"
        path.touch()
        path.write_text(content)
        return path

    def confirm_if_module_has_expected_attrs(module, expected_attrs):
        assert set(module.__dict__.keys()) == set(expected_attrs)

    def confirm_if_module_has_expected_attrs_and_values(module, expected_attrs_and_values):
        assert set(module.__dict__.items()) == set(expected_attrs_and_values)

    def remove_test_file(path):
        path.unlink()

    # Test if exception is raised when empty file is provided.

# Generated at 2022-06-12 09:46:45.988687
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Make tests on Unix system, so we test file separator.
    assert os.name == "posix"

    # str arguments types are passed as is to importlib.util.spec_from_file_location.
    # Check we can still use it:
    some_module = load_module_from_file_location(
        "some_module_name", "some/path/file.py"
    )
    assert some_module.__name__ == "some_module_name"

    # Basic usage
    os_environ["ENV_VAR"] = "env_var"

    some_module = load_module_from_file_location(
        r"/some/path/${ENV_VAR}/file.py"
    )

# Generated at 2022-06-12 09:46:56.731352
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def test_load_module_from_file_location_exceptions():
        # A) None
        with pytest.raises(ValueError):
            load_module_from_file_location(None)

        # B) Path without .py extension
        with pytest.raises(LoadFileException) as exc_info:
            load_module_from_file_location("/some/path")

        assert (
            "It looks like you are importing a file that is not a Python "
            "source file." in str(exc_info.value)
        )

        # C) Bytes without encoding
        some_bytes = b"some_bytes"
        with pytest.raises(LoadFileException):
            load_module_from_file_location(some_bytes)

        # D) Not existing environment variable

# Generated at 2022-06-12 09:47:05.694987
# Unit test for function load_module_from_file_location

# Generated at 2022-06-12 09:47:16.093743
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # checking if this function work with Path objects
    with open("config.py", "w") as f:
        f.write("A=2")
    config = load_module_from_file_location(
        Path("config.py").absolute(), "utf8"
    )
    assert config.A == 2

    # checking if this function work with str objects
    with open("config2.py", "w") as f:
        f.write("A=3")
    config = load_module_from_file_location("config2.py", "utf8")
    assert config.A == 3

    # checking if this function work with bytes objects
    with open("config3.py", "wb") as f:
        f.write("A=4".encode("utf8"))
    config = load_module_from_

# Generated at 2022-06-12 09:47:26.517347
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import configparser

    from sanic.config import Config, ConfigLoadError

    location = "tests/fixtures/config/config.cfg"
    env_vars = configparser.ConfigParser()
    env_vars.read(f"{location}")
    if "VARIABLES" in env_vars:
        for key in env_vars["VARIABLES"]:
            os_environ[key] = env_vars["VARIABLES"][key]

    # 1.Using location parameters
    cfg = Config()
    cfg.from_mapping(
        {"location": location, "encoding": "utf8"}
    )  # type: Config
    assert cfg.is_set("location")
    assert not cfg.is_set("encoding")
    assert cfg.location

# Generated at 2022-06-12 09:47:35.592200
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import sys

    module = load_module_from_file_location(__file__)
    assert module.__name__ == "sanic.helpers"
    assert module.__file__ in sys.modules

    os_environ["SOME_ENV_VAR"] = "OK"
    module = load_module_from_file_location(
        "${SOME_ENV_VAR}", __file__
    )
    assert module.__name__ == "OK"
    assert module.__file__ in sys.modules

    module = load_module_from_file_location(__file__)
    assert module.__name__ == "helpers"
    assert module.__file__ in sys.modules

    del os_environ["SOME_ENV_VAR"]

# Generated at 2022-06-12 09:47:41.120965
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 0) Test if function raises exception if location doesn't exists.
    with pytest.raises(IOError) as excinfo:
        load_module_from_file_location("/some/non/existing/path")
    assert "Unable to load configuration file" in str(excinfo.value)

    # 1) Test if function raises exceptiion if environment variables don't exists.
    with pytest.raises(LoadFileException) as excinfo:
        load_module_from_file_location(
            "/some/path/${some_env_var_that_does_not_exists}"
        )
    assert "The following environment variables are not set" in str(
        excinfo.value
    )

    # 2) Test if function can load a module from `.py` file.

# Generated at 2022-06-12 09:47:54.509018
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_module = load_module_from_file_location(
        bytes("${TEST_MODULE_NAME}", encoding="utf8")
    )
    assert test_module.TEST_MODULE_NAME is True

# Generated at 2022-06-12 09:48:01.145299
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "as_empty_environment_var_is_not_set_this_should_raise_LoadFileEx"
            "${empty_environment_var}"
        )

    os_environ["empty_environment_var"] = ""
    try:
        assert(
            # TODO: test if this works with python 3.5 too
            load_module_from_file_location(
                """as_empty_environment_var_is_set_this_should_not_raise_LoadFileEx$"""
                """{empty_environment_var}"""
            ) == object()
        )
    finally:
        del os_environ["empty_environment_var"]
