

# Generated at 2022-06-12 09:38:04.501644
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("true") is True
    assert str_to_bool("False") is False
    assert str_to_bool("0") is False
    assert str_to_bool("y") is True

# Generated at 2022-06-12 09:38:12.542329
# Unit test for function str_to_bool
def test_str_to_bool():
    """Test str_to_bool function."""
    assert str_to_bool("y")
    assert str_to_bool("YES")
    assert str_to_bool("Yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("True")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("No")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disabled")
    assert not str

# Generated at 2022-06-12 09:38:21.573544
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("ON") == True
    assert str_to_bool("on") == True
    assert str_to_bool("On") == True
    assert str_to_bool("oN") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("yeS") == True
    assert str_to_bool("yEs") == True
    assert str_to_bool("yES") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("trUe") == True
    assert str_to_bool("1") == True


# Generated at 2022-06-12 09:38:24.870604
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('0') == False
    assert str_to_bool('1') == True
    assert str_to_bool('No') == False
    assert str_to_bool('Yes') == True
    assert str_to_bool('False') == False
    assert str_to_bool('True') == True

# Generated at 2022-06-12 09:38:30.843167
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True, "It should be True."
    assert str_to_bool("yes") is True, "It should be True."
    assert str_to_bool("yep") is True, "It should be True."
    assert str_to_bool("yup") is True, "It should be True."
    assert str_to_bool("t") is True, "It should be True."
    assert str_to_bool("true") is True, "It should be True."
    assert str_to_bool("on") is True, "It should be True."
    assert str_to_bool("enable") is True, "It should be True."
    assert str_to_bool("enabled") is True, "It should be True."

# Generated at 2022-06-12 09:38:41.560103
# Unit test for function str_to_bool
def test_str_to_bool():
    try:
        str_to_bool("y")
    except ValueError:
        assert False
    else:
        assert True

    try:
        str_to_bool("yes")
    except ValueError:
        assert False
    else:
        assert True

    try:
        str_to_bool("yep")
    except ValueError:
        assert False
    else:
        assert True

    try:
        str_to_bool("yup")
    except ValueError:
        assert False
    else:
        assert True

    try:
        str_to_bool("t")
    except ValueError:
        assert False
    else:
        assert True

    try:
        str_to_bool("true")
    except ValueError:
        assert False
    else:
        assert True


# Generated at 2022-06-12 09:38:50.105477
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    env_vars_in_location = set(re_findall(r"\${(.+?)}", "${TEST_ENV_VAR}"))
    assert env_vars_in_location == {"TEST_ENV_VAR"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os_environ.keys())
    assert not not_defined_env_vars

    # C) Substitute them in location.

# Generated at 2022-06-12 09:39:00.445496
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("true") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("1") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("T") is True
    assert str_to_bool("on") is True
    assert str_to_bool("On") is True


# Generated at 2022-06-12 09:39:08.013437
# Unit test for function str_to_bool
def test_str_to_bool():
    from pytest import raises

    assert str_to_bool("true") is True
    assert str_to_bool("t") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("f") is False
    assert str_to_bool("no") is False
    assert str_to_bool("on") is True
    assert str_to_bool("off") is False
    assert str_to_bool("enable") is True
    assert str_to_bool("off") is False

    with raises(ValueError):
        str_to_bool("")
    with raises(ValueError):
        str_to_bool("whatever")

# Generated at 2022-06-12 09:39:17.520229
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import mkstemp

    from os import environ as os_environ
    from os import close as os_close
    from os import remove as os_remove
    from os import path as os_path

    from copy import deepcopy

    from unittest.mock import patch

    class Params:
        """Container for params used in tests to make them less verbose."""


# Generated at 2022-06-12 09:39:20.940974
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # TODO
    pass

# Generated at 2022-06-12 09:39:26.653949
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # Success scenario
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(b"test_val = 123")
    test_module = load_module_from_file_location(f.name)
    assert test_module.test_val == 123
    # Fail scenario
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(b"test_val = '123'")
    try:
        test_module = load_module_from_file_location(f.name)
    except PyFileError:
        test_module = None  # Make mypy happy.
    assert test_module is None



# Generated at 2022-06-12 09:39:36.056477
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest
    from os import environ as os_environ
    from os import path as os_path
    import os
    import shutil
    import tempfile

    # Setup
    os_environ["TEST_ENV_VAR_A"] = "A"
    os_environ["TEST_ENV_VAR_B"] = "B"

    env_vars_test_dir = tempfile.mkdtemp()

    test_module_a = (
        f"{env_vars_test_dir}/test_module_a.py"
    )
    test_module_b = (
        f"{env_vars_test_dir}/test_module_b.txt"
    )


# Generated at 2022-06-12 09:39:44.752867
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Create temporary file
    tmp_file = Path(
        Path(__file__).parent
        / "tmp_test_config_file."
        + str(time.time())
        + ".py"
    )
    with open(tmp_file, "w+") as f:
        f.write("class Test(): pass")

    from sanic import Sanic
    from sanic.config import LOGGING

    app = Sanic()

    # Test file to load without env variables
    app.config.from_pyfile(tmp_file)

    # Test if file is loaded
    assert app.config.LOGGING == LOGGING is False

    # Test if we can successfully import module from string
    from sources.sanic.config import LOGGING

    assert LOGGING is False

    # Test file to load with env variables
   

# Generated at 2022-06-12 09:39:51.596225
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os
    from tempfile import NamedTemporaryFile

    # config with som comments, imports, statements
    test_config = """
        # Comment

        # Comment
        from config import foo
        from config import bar
        from config import baz

        # Comment
        variable_from_python_script = True
        """

    # loading module from a file path
    with NamedTemporaryFile("w") as test_config_file:
        test_config_file.write(test_config)
        test_config_file.flush()
        module = load_module_from_file_location(test_config_file.name)
        assert module.variable_from_python_script

    # loading module from a file path with environment variable

# Generated at 2022-06-12 09:40:00.716459
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    def write_hello_world_conf(file_handle, module_name="hello_world"):
        file_handle.write(
            f"from sanic.response import text\n\n"
            f"def {module_name}(request):\n"
            f"    return text('Hello World')\n"
        )


# Generated at 2022-06-12 09:40:08.917981
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    import tempfile
    import pytest

    with tempfile.TemporaryDirectory() as folder:

        os_environ["SOME_VAR"] = folder
        test_config = """
            name = "test"
            default = True
            """
        with open(folder + "/test.py", "w") as file:
            file.write(test_config)
        module = load_module_from_file_location(
            folder + "/${SOME_VAR}/test.py"
        )
        assert module.name == "test"
        assert module.default is True

        with open(folder + "/test.txt", "w") as file:
            file.write("test_config = {'name': 'test', 'default': True}\n")
        module = load_

# Generated at 2022-06-12 09:40:12.298728
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    location = Path(__file__).parent.resolve() / "test_load_module.py"

    module = load_module_from_file_location(
        location
    )  # type: ignore

    assert module.test_bool_var is not None
    assert module.test_str_var == "test_str_var"
    assert module.test_int_var == 12345

    assert module.test_env_var == "test_env_var"
    assert module.test_bool_env_var is True

# Generated at 2022-06-12 09:40:21.341735
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # first checking if function works
    import os

    directory = os.path.dirname(os.path.abspath(__file__))
    module = load_module_from_file_location(
        os.path.join(directory, "test_module.py")
    )

    assert module.foo() == 42

    # and now checking that it can handle environmental variables in location
    os.environ["MY_VAR_NAME"] = "test_module.py"
    module = load_module_from_file_location(
        os.path.join(directory, "${MY_VAR_NAME}")
    )

    assert module.foo() == 42

    os.environ["MY_VAR_NAME"] = "test_module.py|test_module1.py"
    module = load_module_from_file

# Generated at 2022-06-12 09:40:27.305627
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("os") == os
    assert (
        load_module_from_file_location(
            "tests/utils",
            os.path.abspath(__file__).rsplit("/", 1)[0],
            "app.py",
        )
        == os
    )
    try:
        load_module_from_file_location("tests/utils", "does_not_exist.py")
        assert False, "PyFileError is not raised"
    except PyFileError:
        pass

# Generated at 2022-06-12 09:40:35.836376
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    class SomeModule:
        pass

    file_path = "/some/path/${some_env_var}"
    some_env_var = "some_var"

    os_environ["some_env_var"] = some_env_var
    os_environ["some_var"] = "some_var_value"

    def test_imports(location):
        loaded_module = load_module_from_file_location(location)
        assert loaded_module is SomeModule
        del os_environ["some_env_var"]

    test_imports(SomeModule)
    test_imports(SomeModule.__name__)
    test_imports(SomeModule.__file__)
    test_imports(SomeModule.__file__.encode())

# Generated at 2022-06-12 09:40:42.097541
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # pylint: disable=C0103
    # pylint: disable=E1101
    file_path = "./config_for_unit_test.py"
    module = load_module_from_file_location(file_path)
    assert module.FOO == "bar"
    assert module.SPAM == "ham"

    # pylint: disable=W0631
    file_path = "./config_with_comments_and_multiline_statements_for_unit_test.py"  # noqa
    module = load_module_from_file_location(file_path)
    assert module.FOO == "bar"
    assert module.SPAM == "ham"



# Generated at 2022-06-12 09:40:47.207399
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Loads a python file, the result is a module object
    assert isinstance(
        load_module_from_file_location("./test/test_config.py"), types.ModuleType
    )

    # Loads a text file
    assert (
        load_module_from_file_location("./test/test.txt").__file__
        == "./test/test.txt"
    )



# Generated at 2022-06-12 09:40:55.397264
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import os
    import pytest
    from tempfile import NamedTemporaryFile
    from os.path import join, dirname

    from sanic import Sanic
    from sanic.config import Config as SanicConfig
    from sanic.config import Config
    from sanic.helpers import get_function_name

    # # #
    # 1.a) Check that we can load default config.

    config_file_location = Config().CONFIG_FILE
    module = load_module_from_file_location(config_file_location)
    assert module.BALANCER_LOGGING["level"] == "info"

    # # #
    # 1.b) Check that we can load environment variable config.

    # 1.b) Set env variable with path to

# Generated at 2022-06-12 09:41:04.487478
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Check that function can load
    # file in format your/absolute/path/to/file.py
    assert load_module_from_file_location(
        "tests/test_configs/config.py",
    )

    # Check that function can load
    # file in format your/python/package/some_module.py
    from . import test_configs

    assert (
        load_module_from_file_location(
            "tests.test_configs.config",
        )
        == test_configs.config
    )

    # Check that function can load
    # file in format your/relative/path/${some_env_var}/to/file.py
    # and substitute location for ${some_env_var}
    # from environment variable.

# Generated at 2022-06-12 09:41:13.807023
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("pathlib").__name__ == "pathlib"
    # __file__ attribute will be empty if imported with importlib.import_module
    assert not load_module_from_file_location("pathlib").__file__

    test_package_path = Path(__file__).parent.parent
    assert (
        load_module_from_file_location(
            test_package_path / "tests" / "test_utils" / "__init__.py"
        ).__name__
        == "test_utils"
    )

# Generated at 2022-06-12 09:41:23.191503
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Unit test for function load_module_from_file_location from utils
    """
    from tempfile import TemporaryDirectory
    import os
    import pytest
    from sanic import Sanic

    def _create_and_write_file(tmp_dir: TemporaryDirectory):
        filename = tmp_dir.name + "/" + "pyfile.py"
        with open(filename, "w") as file:
            file.write("config = 'config'")
        return filename

    def _create_fake_env_var():
        os.environ["ENV"] = "ENV"
        return os.environ["ENV"]

    with TemporaryDirectory() as tmp_dir:
        filename = _create_and_write_file(tmp_dir)
        # A) Test if configuration file will be loaded
        #    without any

# Generated at 2022-06-12 09:41:32.424471
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        # this will raise a ValueError.
        load_module_from_file_location("some_module_name")
    except ValueError:
        pass

    # this will return module object which is loaded by importlib
    importlib = load_module_from_file_location("importlib")
    assert callable(importlib.import_module)

    importlib_util = load_module_from_file_location("importlib.util")
    assert callable(importlib_util.spec_from_file_location)

    # Asserting that file has been loaded correctly.
    location = Path(__file__).parent / "test_load_module_from_file_location.py"
    module = load_module_from_file_location(location)
    assert module.__file__ == str(location)
    assert get

# Generated at 2022-06-12 09:41:42.994815
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import pytest
    import os
    import tempfile
    import uuid
    import inspect

    # Create temporary directory.
    temp_dir_path = str(Path(tempfile.gettempdir()) / uuid.uuid4().hex)
    os.mkdir(temp_dir_path)

    # Create temporary config file.
    module_name = "temp_config"
    module_source = (
        f"class {module_name}: "
        f"    pass"
    )
    config_file_path = str(Path(temp_dir_path) / (module_name + ".py"))
    with open(config_file_path, "w") as config_file:
        config_file.write(module_source)

    # Create environment variables.
    os_environ["some_env_var"] = temp_

# Generated at 2022-06-12 09:41:50.469229
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    from os import environ, getcwd
    from tempfile import mkstemp
    from random import choice
    from string import ascii_letters

    # There are 3 cases checked in this test:
    #
    # 1) Path to file with random name is passed as string (type str object)
    # 2) Path to file with random name is passed as Path object
    # 3) Path to file with random name is passed as bytes (type bytes object)
    #    So we have to pass encoding kwarg to make sure it will be decoded
    #    properly.

    # 1) str object
    #    Note:
    #    If you not pass file name it will be just "None.py", but
    #    you can pass file name as containing env variable in format
    #    ${some_env_var}

# Generated at 2022-06-12 09:42:01.101062
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ

    env_var = "TEST_ENV_VAR"

    test_config_file = """
    env_var_test = True
    env_var = 1
    """

    def assert_test_config_file(test_file, test_config_file_path):

        test_file.write(test_config_file)
        test_file.seek(0)

        module = load_module_from_file_location(test_config_file_path)

        assert module.env_var_test

        try:
            module.env_var
        except AttributeError:
            raise AssertionError(
                "Can't import environment variable from test configuration file"
            )


# Generated at 2022-06-12 09:42:10.723677
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test that it propertly loads python file and that it loads it with
    # correct name.
    test_module_1 = load_module_from_file_location(
        __file__.rsplit("/", 1)[-1], __file__
    )
    assert test_module_1.__name__ == "test_utils"

    # Test that it properly loads json file as config
    test_module_2 = load_module_from_file_location(
        "test_config.json", __file__.rsplit("/", 1)[0]
    )
    assert test_module_2.__name__ == "config"
    assert test_module_2.PORT == 8080

    # Test that it properly works with environment variables.

# Generated at 2022-06-12 09:42:19.298791
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path

    # A) Test .py file as a path.
    location = Path(__file__).parent / "../config_template.yml"

    assert "config" == load_module_from_file_location(location, "utf8").__name__

    # B) Test path, in which file name has no .py extension.
    location = Path(__file__).parent / "../config_template.yml"
    location = str(location)[:-3]  # remove .yml extension

    assert "config" == load_module_from_file_location(location, "utf8").__name__

    # C) Test using path with environment variables.
    import os

    tmp_file_path = "tmp_file_path.ini"

# Generated at 2022-06-12 09:42:29.875297
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_ENV_VAR_1"] = "test"
    os_environ["TEST_ENV_VAR_2"] = "test"
    os_environ["TEST_ENV_VAR_3"] = "test"
    os_environ["TEST_ENV_VAR_4"] = "test"

    # Test for a valid python path to file
    py_file = "./tests/files/config_files/py_file.py"
    assert load_module_from_file_location(py_file) == import_string(
        "tests.files.config_files.py_file"
    )

    # Test for an invalid python path to file.
    py_file_invalid_path = "./tests/files/config_files/py_file"
   

# Generated at 2022-06-12 09:42:39.791871
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """This is a load_module_from_file_location unit test.

    It should test:
        - if the function loads module in a right way
        - if the function throws right exceptions on wrong location
          provided to it.

    This is not complete test for this function.
    The function has many use cases, which can not be tested in one
    unit test.
    For example, it might be useful to test, what happens
    when environment variables are not in format ${some_env_var}
    but in format $some_env_var.
    """
    # Test 1. Provide wrong location and check if it throws right exception.

    # Test 1.1. Provide wrong location of a string type and check
    #           if it throws right exception.
    #           Also include env var in format $some_env_var.
    #           Test that it is

# Generated at 2022-06-12 09:42:47.134832
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    # Test case 1:
    # Test if None is returned if you provide non-existing path.
    # Test if exception is raised if you provide non-path like location.
    non_existing_path = "/some/non/existing/path"
    non_path_like_location = "some_module_name"

    assert load_module_from_file_location(
        non_existing_path
    ) is None

    try:
        load_module_from_file_location(non_path_like_location)
    except IOError:
        pass
    else:
        raise ValueError("does not raise the expected exception")

    # Test case 2:
    # Test if file is loaded and returned as module.
    # Test if file is loaded and returned as module
    # if it's path contains environment

# Generated at 2022-06-12 09:42:55.950712
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if no errors will be raised when environment variables in
    #   location are not defined.

    # 1. Test location with environment variables not set.
    location = "/some/path/${some_env_var}/some_file.py"
    try:
        some_module = load_module_from_file_location(location)
    except LoadFileException:
        pass
    else:
        raise Exception(
            "You should get LoadFileException, if environment variables "
            "in location are not defined."
        )

    # 2. Test location with environment variables not set and which
    #    contains another environment variables in format $some_env_var.
    location = "/some/path/some_file$some_env_var.py"

# Generated at 2022-06-12 09:43:00.781854
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    assert "__file__" in dir(
        load_module_from_file_location("sanic.server")
    )

    assert "__file__" in dir(
        load_module_from_file_location("sanic.server.base")
    )

    assert "test_load_module_from_file_location" in dir(
        load_module_from_file_location(__file__)
    )

    assert "test_load_module_from_file_location" in dir(
        load_module_from_file_location(__file__.encode("utf-8"))
    )


# Generated at 2022-06-12 09:43:06.820497
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    from pathlib import Path
    from sanic.helpers import load_module_from_file_location

    # A) Get temporary path for testing.
    tmpfilepath = Path(tempfile.gettempdir()) / "config.py"
    tmpfilepath2 = Path(tempfile.gettempdir()) / "config2.py"

    # B) Prepare config.py file with some variables.
    with tmpfilepath.open('w+') as config_file:
        config_file.write("foo = 'foo val'")
        config_file.write("\n")
        config_file.write("bar = 'bar val'")

    # C) Prepare config2.py file with some variables.

# Generated at 2022-06-12 09:43:13.982934
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Set up environment
    tmpdir = Path(tempfile.gettempdir()) / "some_tmp_dir"
    os_environ["TEST_ENV"] = str(tmpdir)
    file_path = tmpdir / "some_file"
    file_path.mkdir(exist_ok=True)
    with open(file_path, "w") as f:
        f.write("")

    # Test if it loads file when given file_path
    with open(file_path, "r") as f:
        assert (
            load_module_from_file_location(file_path)
            == sys.modules[os.path.basename(file_path)]
        )

# Generated at 2022-06-12 09:43:21.714766
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SOME_ENV_VAR"] = "some_env_var_value"
    module = load_module_from_file_location(
        "/this/is/path/${SOME_ENV_VAR}", encoding="utf-8"
    )
    assert module.__file__ == "/this/is/path/some_env_var_value"

    assert load_module_from_file_location("test_support.test_utils")

# Generated at 2022-06-12 09:43:28.702297
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from os import environ
    from unittest.mock import Mock

    from sanic.log import logger

    # NOTE: Location parameter of type pathlib.Path.*
    #       is tested in file test_sanic_config.py.
    #       It is not covered here.

    # NOTE: Location parameter of bytes type
    #       is tested in file test_sanic_config.py.
    #       It is not covered here.

    # Location parameter of string type.
    # Location is of a string type.
    # Location contains no /.
    # Location contains no $.
    # Correct path.
    # Extension is .py.
    # File contains some variables.
    # Test if file is loaded correctly.
    logger.debug = Mock()
    location = "some_location_of_a_module"


# Generated at 2022-06-12 09:43:37.498053
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test for function load_module_from_file_location."""

    # Test for case when location is a string.
    # Case of empty string
    try:
        load_module_from_file_location(
            "",
        )
    except LoadFileException as err:
        assert err.args[0] == "Unable to load configuration file (e.strerror)"
    # Case of incorrect location
    try:
        load_module_from_file_location(
            "some_incorrect_location",
        )
    except LoadFileException as err:
        assert err.args[0] == "Unable to load configuration file (e.strerror)"
    # Case of not set environment variable

# Generated at 2022-06-12 09:43:46.480502
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import pytest

    # Test 1
    module = load_module_from_file_location(
        "/app/app_production.py", "app_production"
    )
    assert module.URL["internal"] == "http://localhost:80"
    assert module.URL["public"] == "http://127.0.0.1:80"
    assert module.PORT == 80
    assert module.KEEP_ALIVE == False
    assert module.NUMBER_OF_WORKERS == 1
    assert module.HTTP2 == False
    assert module.LOGO == "https://yields.github.io/sanic/logo.png"
    assert module.PROTOCOL == "HTTP/1.1"
    assert module.REAL_IP_HEADER == "X-Real-IP"
    assert module.REAL_IP_

# Generated at 2022-06-12 09:43:56.078327
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pylint: disable=unused-variable
    test_file_name = "test_load_module_from_file_location.py"
    # A. Create test file
    test_file = Path("./" + test_file_name).touch()
    if sys.version_info > (3, 0):
        with open(test_file_name, "w") as file:
            file.write(
                'TestVar = "test"\n'
                "TestFunc = lambda x : x * 2\n"
                "TestExc = Exception('Testing Exception')\n"
            )

# Generated at 2022-06-12 09:44:01.556132
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    test_file_path = tempfile.mkstemp()[-1]
    test_file_content = "foo = 'bar'"
    with open(test_file_path, "w+") as test_file:
        test_file.write(test_file_content)

    assert load_module_from_file_location(test_file_path).__dict__.get(
        "foo", None
    ) == "bar"
    os.remove(test_file_path)

# Generated at 2022-06-12 09:44:10.642979
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # pylint: disable=unsubscriptable-object
    os_environ["SANIC_CONFIG_ENV_VAR_TEST_1"] = "1"
    os_environ["SANIC_CONFIG_ENV_VAR_TEST_2"] = "2"

    module = load_module_from_file_location(
        "/some/path/${SANIC_CONFIG_ENV_VAR_TEST_1}"
    )
    assert module is None

    module = load_module_from_file_location(
        "tests.test_utils.config_for_load_module_from_file_location"
    )
    assert module["a"] == 1
    assert module["b"] == 2
    assert module["c"]["a"] == 3

# Generated at 2022-06-12 09:44:19.444543
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    os_environ["test_env_var"] = "$test_env_var"

    # file exists, but module doesn't
    location = "/etc/shadow"
    with pytest.raises(PyFileError):
        load_module_from_file_location(location)

    # file exists
    location = __file__
    module = load_module_from_file_location(location)
    assert module.__name__ == "test_utils"

    # file exists, but can not be imported
    location = "/tmp/some_file.py"
    with open(location, "w") as f:
        f.write("test = 1")
    with pytest.raises(PyFileError):
        load_module_from_file_location(location)

    # file exists, and can be imported

# Generated at 2022-06-12 09:44:19.936019
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pass

# Generated at 2022-06-12 09:44:24.093034
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    this_file = __file__
    if this_file.endswith('.pyc'):
        this_file = this_file[:-1]
    module = load_module_from_file_location(this_file)
    assert module == globals()

# Generated at 2022-06-12 09:44:29.846468
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    try:
        load_module_from_file_location(
            location="./tests/config/config.py",
            encoding="utf8",
            is_package=False,
        )
    except Exception:
        return False
    else:
        return True

# Generated at 2022-06-12 09:44:39.170956
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["PATH_TO_MODULE"] = __file__
    os_environ["PATH_TO_MODULE_DIR"] = f"{__file__}dir"
    os_environ["PATH_TO_MODULE_FILE_DIR"] = f"{__file__}dir/file.py"
    os_environ["PATH_TO_MODULE_UNEXISTS_DIR"] = f"{__file__}unexists"
    os_environ["PATH_TO_MODULE_UNEXISTS_FILE_DIR"] = f"{__file__}unexists/file.py"

    from . import __file__ as __this_file__

    assert __file__ == load_module_from_file_location(__file__)

# Generated at 2022-06-12 09:44:43.272464
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Function testing load_module_from_file_location function.
    """
    class A:
        """
        Class for testing of load_module_from_file_location function.
        """
    a = A()
    assert load_module_from_file_location(a) == a
    assert load_module_from_file_location(str(Path.cwd())) is not None

# Generated at 2022-06-12 09:44:46.136542
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Example of usage this function."""

    try:
        some_config_module = load_module_from_file_location(
            "some_config_module",
            "/some/path/${some_env_var}",
        )
        some_config_module.SomeClass  # check if SomeClass inside this module
    except Exception:
        print("Some error happens")

# Generated at 2022-06-12 09:44:54.693191
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Unit testing for load_module_from_file_location function.
    """
    assert (  # Nosec: test a function that takes location as a string.
        load_module_from_file_location("os").name == os.name
    )

    assert (  # Nosec: test a function that takes location as a Path object.
        load_module_from_file_location(Path("os")).name == os.name
    )

    import os
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        MODULE_NAME = "__tmp_module__"
        MODULE_PATH = Path(tmpdir) / MODULE_NAME
        MODULE_PATH.touch()


# Generated at 2022-06-12 09:45:02.695259
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    # I) Test with relative path
    test_path = "sanic/config/test_config.py"
    module = load_module_from_file_location(test_path)
    assert module.foo == "bar"

    # II) Test with absolute path
    test_path = Path(test_path)
    module = load_module_from_file_location(test_path)
    assert module.foo == "bar"

    # III) Test with environment variable in path
    test_path = "sanic/config/${TEST_CONFIG}/test_config.py"
    os_environ["TEST_CONFIG"] = "test_config"
    module = load_module_from_file_location(test_path)
    assert module

# Generated at 2022-06-12 09:45:12.912037
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # A) Prepare module to be loaded.
    test_module_name = "test_module_name"
    test_module_code = dedent(
        """\
        class A:
            '''This is a test module.'''
            pass
        def f():
            pass

        var = 5
        """
    )
    path = Path(__file__).parent.parent.joinpath(
        test_module_name + ".py"
    )  # the path where the module is going to be saved
    path.write_text(test_module_code)

    # B) Load the module
    module = load_module_from_file_location(path)

    # C) Test that the module is loaded correctly
    assert module.__name__ == test_module_name
    assert module.__file__ == str

# Generated at 2022-06-12 09:45:22.101116
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Tests function load_module_from_file_location."""

    # Test A) location is Path instance.
    mod = load_module_from_file_location(Path("config.py"))
    assert mod
    assert mod.TEST_CONFIG_VAR == "TEST"

    # Test B) location is string.
    mod = load_module_from_file_location("config.py")
    assert mod
    assert mod.TEST_CONFIG_VAR == "TEST"

    # Test C) location contains environment variables.
    os_environ["CONFIG_FILE_PATH"] = "config.py"
    mod = load_module_from_file_location("${CONFIG_FILE_PATH}")
    assert mod
    assert mod.TEST_CONFIG_VAR == "TEST"

# Generated at 2022-06-12 09:45:30.240486
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from pathlib import Path

    import_string = load_module_from_file_location
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    location = "${TEST_ENV_VAR}/test_module.py"
    module = import_string(location)

    location = "TEST_ENV_VAR/test_module.py"
    module = import_string(location)

    location = Path(location)
    module = import_string(location)

    location = location.as_posix()
    module = import_string(location)

    location = location.as_uri()
    module = import_string(location)



# Generated at 2022-06-12 09:45:32.162966
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("sanic").__name__ == "sanic"

# Generated at 2022-06-12 09:45:43.301438
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test for :func:`load_module_from_file_location`."""
    from_path = Path("./example.py")
    from_str = from_path.as_posix()
    from_bytes = from_path.as_posix().encode()

    module = load_module_from_file_location(from_path)
    assert module.module_attribute == "module value"

    module = load_module_from_file_location(from_str)
    assert module.module_attribute == "module value"

    module = load_module_from_file_location(from_bytes)
    assert module.module_attribute == "module value"

# Generated at 2022-06-12 09:45:52.714583
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) No environment variables are in location
    # A-1) Location is of a string type
    # A-1-1) Path to file
    assert (
        load_module_from_file_location(Path(__file__).parent)
        is sys.modules[__name__]
    )

    # A-1-2) Just name
    assert load_module_from_file_location("test_to_bool") is sys.modules[
        __name__
    ]

    # A-2) Location is of a bytes type
    # A-2-1) Path to file
    assert (
        load_module_from_file_location(Path(__file__).parent.as_posix().encode())
        is sys.modules[__name__]
    )

    # A-2-2) Just name


# Generated at 2022-06-12 09:45:58.991284
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa

    tmpdir = Path(__file__).parent / "tmp"
    tmpdir.mkdir(exist_ok=True)

    with tmpdir.as_cwd():
        file_name = "config.py"
        with open(file_name, "w") as f:
            f.writelines(["CONFIG_VAR=9", "CONFIG_VAR2=True"])

        module = load_module_from_file_location(file_name)
        assert module.CONFIG_VAR == 9
        assert module.CONFIG_VAR2

# Generated at 2022-06-12 09:46:05.267774
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("load_module_from_file_location")
    assert load_module_from_file_location(
        bytes("load_module_from_file_location", encoding="utf-8")
    )
    assert load_module_from_file_location(
        "load_module_from_file_location",  # noqa
        __file__,
        True,
        False,
        False,
        "module_type",
    )
    test_folder = Path(__file__).parent
    assert load_module_from_file_location(test_folder / "app.py")
    assert load_module_from_file_location(
        test_folder / "test_load_module_from_file_location.py"  # noqa
    )



# Generated at 2022-06-12 09:46:14.152300
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from sanic import Sanic

    app = Sanic("testing_app")
    app.config.from_pyfile = load_module_from_file_location

    filepath = "./tests/test_load_config/test_config.py"
    app.config.from_pyfile(filepath)

    assert app.config.TEST_KEY
    assert app.config.TEST_KEY_2 == 0

    # Test to ensure that #69 bug is fixed
    filepath = "./tests/test_load_config/test_load_config.py"
    app.config.from_pyfile(filepath)

    assert app.config.TEST_VAR

    # Test if None is not overwritten
    filepath = "./tests/test_load_config/test_load_config2.py"

# Generated at 2022-06-12 09:46:20.886764
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Case 0: valid_module

    module = load_module_from_file_location(
        Path(__file__).parent / "test_module_0.py"
    )
    test_data = ("hello", "world")
    assert module.some_key == test_data

    # Case 1: invalid_module_name
    with pytest.raises(
        ImportError,
        match="No module named 'invalid_module_name'",
    ):
        load_module_from_file_location("invalid_module_name")

# Generated at 2022-06-12 09:46:27.229582
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as dirname:

        def name(content):
            d = tempfile.NamedTemporaryFile(dir=dirname, delete=False)
            d.write(content)
            name = d.name
            d.close()
            return name

        assert load_module_from_file_location("os").__name__ == "os"
        assert load_module_from_file_location("os").path.__name__ == "posixpath"

        assert load_module_from_file_location("sys").__name__ == "sys"

        assert load_module_from_file_location("random").__name__ == "random"

        base_path = Path(__file__).resolve().parent


# Generated at 2022-06-12 09:46:31.819429
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_module = load_module_from_file_location(
        "sanic/test_module.test_module"
    )
    assert test_module.test_var == 1
    assert test_module.test_str == "str"
    assert test_module.test_dict == {"key": "value"}
    assert test_module.test_list == ["1", "2"]

# Generated at 2022-06-12 09:46:40.509105
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import random
    import tempfile

    if os.name == "nt":
        # Windows doesn't support environment variables in Path class
        return

    tmp_dir = Path(tempfile.mkdtemp("_sanic_config_test"))
    tmp_file = tmp_dir / "config.py"

    with tmp_file.open("w") as f:
        # random_var is different from random, the random global from the random
        # module, because random(_var) was already imported in this file
        f.write("random_var = 42")

    assert load_module_from_file_location(str(tmp_file)).random_var == 42

    tmp_file = tmp_dir / "config.conf"

# Generated at 2022-06-12 09:46:51.067224
# Unit test for function load_module_from_file_location

# Generated at 2022-06-12 09:47:01.036316
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    s = "{"
    s += '"a": 1, '
    s += '"b": true, '
    s += '"c": "Hello", '
    s += '"d": "Goodbye", '
    s += '"e": '
    s += "[1,2,3] "
    s += "}"
    assert eval(s) == eval(str(load_module_from_file_location(s)))

    s = "{"
    s += '"a": 1, '  # noqa
    s += '"b": true, '  # noqa
    s += '"c": "Hello", '  # noqa
    s += '"d": "Goodbye", '  # noqa
    s += '"e": '  # noqa
    s += "[1,2,3] "  #

# Generated at 2022-06-12 09:47:10.599848
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    from itertools import product
    from string import printable
    from tempfile import NamedTemporaryFile, TemporaryDirectory
    from typing import Set, Dict, Any
    from shutil import rmtree
    import os

    def _create_config(config_content: str) -> Path:
        config_file = NamedTemporaryFile(delete=False)
        config_file.write(config_content.encode("utf-8"))
        config_file.close()

        return Path(config_file.name)

    # Helpers functions
    def _find_py_config_file(
        config_file: Path, config_name: str
    ) -> Set[Path]:
        config_files_set: Set[Path] = set()

# Generated at 2022-06-12 09:47:19.804665
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Load config file with existing environment variable
    os_environ["PROFILE"] = "Testing"
    path = "some_package/some_module.py"
    some_module = load_module_from_file_location(
        "/config/${PROFILE}/" + path
    )
    assert some_module.a == 1, """
        load_module_from_file_location function
        was unable to load existing environment variable
        in config file path.
        """
    # Load config file without existing environment variable
    path = "some_package/some_module.py"
    try:
        load_module_from_file_location("/config/${NON_EXISTING}/" + path)
    except LoadFileException as e:
        pass

# Generated at 2022-06-12 09:47:26.295600
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    assert load_module_from_file_location("os.path") == os.path
    os_environ["SANIC_TEST_ENV_VAR"] = "42"
    assert load_module_from_file_location("os.path") == os.path
    assert (
        load_module_from_file_location(
            "${SANIC_TEST_ENV_VAR}.txt", __file__
        ).__file__
        == str(Path(__file__).parent / "42.txt")
    )

# Generated at 2022-06-12 09:47:35.405869
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    import tempfile
    import shutil
    import os
    import sys

    name = "test"
    path = tempfile.mkdtemp()
    location = Path(f"{path}/{name}.py")
    location_2 = location / "some_config.py"

    data = (
        ("import yaml", None),
        ("import math", None),
        ("import math\n", None),
        ("import math\nbla_bla_bla", None),
    )

    @pytest.mark.parametrize("source, error", data)
    def _test_load_module_from_file_location(source, error):
        location.write_text(source)

        if error:
            with pytest.raises(error):
                load_module_from_file

# Generated at 2022-06-12 09:47:41.004260
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from tempfile import TemporaryDirectory

    # 1. Test with location from the environment
    result_from_env = load_module_from_file_location(
        "$${PWD}/testing.py", __file__, "r"
    )
    assert result_from_env.TEST_SETTING == 42

    # 2. Test with location from env and without
    with pytest.raises(LoadFileException):
        load_module_from_file_location("${PWD}/testing.py", "some/unexisting/path")

    # 3. Test with unexisting location from env and from location
    with TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)


# Generated at 2022-06-12 09:47:46.263997
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_path = Path(__file__).parent / "test_load_module_from_file_location.py"  # noqa
    module = load_module_from_file_location(
        file_path, location="/some/path/${not_exist_env_var}"
    )
    assert "some_function" in dir(module)



# Generated at 2022-06-12 09:47:55.225734
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test that function correctly import module when it is provided
    # as a path to a file without environment variables in the path.
    assert load_module_from_file_location(Path(__file__))
    assert load_module_from_file_location(Path(__file__).absolute())
    assert load_module_from_file_location(str(Path(__file__)))
    assert load_module_from_file_location(str(Path(__file__).absolute()))

    # Test that function correctly import module when it is provided
    # as a path to a file with environment variables in the path.
    os_environ["sanic_test_env_var"] = str(
        Path(__file__).absolute().parent
    )  # noqa

# Generated at 2022-06-12 09:48:01.514313
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    class TestLoadModuleFromFileLocation:
        def test_load_module_from_file_location_with_some_module_name(self):
            import sanic.config

            assert (
                sanic.config
                == load_module_from_file_location("sanic.config")
            )

        def test_load_module_from_file_location_with_some_module_path(self):
            from os import path

            some_path = path.join(path.abspath(path.dirname(__file__)), "config.py")
            import config

            assert config == load_module_from_file_location(some_path)
