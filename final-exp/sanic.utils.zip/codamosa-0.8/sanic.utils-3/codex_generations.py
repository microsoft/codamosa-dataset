

# Generated at 2022-06-12 09:38:05.546837
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("YeS") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("t") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("true") == True
    assert str_to_bool("1") == True
    assert str_to_bool("on") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("On") == True
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("YEp") == True
    assert str_to_bool("YEP") == True


# Generated at 2022-06-12 09:38:13.122615
# Unit test for function str_to_bool
def test_str_to_bool():
    from hypothesis import given, settings, Verbosity
    from hypothesis.strategies import text
    from string import ascii_letters as letters, punctuation, digits

    # We are ok with slow tests, especially on Travis.
    settings.register_profile("slow", max_examples=5000)
    settings.load_profile("slow")


# Generated at 2022-06-12 09:38:22.119192
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-12 09:38:27.903534
# Unit test for function str_to_bool
def test_str_to_bool():
    # TODO: Add more test cases
    # Falsy
    assert not str_to_bool("F")
    assert not str_to_bool("False")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("0")
    # Truthy
    assert str_to_bool("T")
    assert str_to_bool("True")
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("1")

    # Invalid
    with pytest.raises(ValueError):
        str_to_bool("1.0")

# Generated at 2022-06-12 09:38:39.074115
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""

    # A) Check that it properly loads configuration file.
    location = Path(__file__).parent / "fixtures" / "sanic_config.py"
    module = load_module_from_file_location(location)
    assert module.VARIABLE_FROM_CONFIG == "variable_from_config"
    assert module.FUNCTION_FROM_CONFIG() == "function_from_config"

    # B) Check that it properly loads configuration file with environment
    #    variables in format ${some_env_var}.
    location = Path(__file__).parent / "fixtures/${SANIC_CONFIG_NAME}_config.py"
    # Set environment variable

# Generated at 2022-06-12 09:38:43.381754
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from os import environ as os_environ
    from os import unsetenv as os_unsetenv
    from os import path as os_path

    # A) Test with *.py file.
    with NamedTemporaryFile(mode="w", suffix=".py") as tmp_file:
        tmp_file.write("test_var = 'test_1'\n")
        tmp_file.flush()
        module = load_module_from_file_location(tmp_file.name)
        assert module.test_var == "test_1"

    # B) Test with *.conf file.
    with NamedTemporaryFile(mode="w", suffix=".conf") as tmp_file:
        tmp_file.write("test_var = 'test_2'\n")

# Generated at 2022-06-12 09:38:51.913357
# Unit test for function str_to_bool
def test_str_to_bool():
    # str_to_bool_func = partial(str_to_bool, val)
    for val in [
            "y",
            "yes",
            "yep",
            "yup",
            "t",
            "true",
            "on",
            "enable",
            "enabled",
            "1",
            "n",
            "no",
            "f",
            "false",
            "off",
            "disable",
            "disabled",
            "0",
    ]:
        assert str_to_bool(val)
    assert str_to_bool("y")
    assert not str_to_bool("f")
    with pytest.raises(ValueError):
        str_to_bool("2")

# Generated at 2022-06-12 09:39:02.197218
# Unit test for function str_to_bool
def test_str_to_bool():
    assert(str_to_bool("y") == True)
    assert(str_to_bool("yes") == True)
    assert(str_to_bool("yep") == True)
    assert(str_to_bool("yup") == True)
    assert(str_to_bool("on") == True)
    assert(str_to_bool("enable") == True)
    assert(str_to_bool("enabled") == True)
    assert(str_to_bool("true") == True)
    assert(str_to_bool("1") == True)
    assert(str_to_bool("t") == True)
    assert(str_to_bool("n") == False)
    assert(str_to_bool("no") == False)
    assert(str_to_bool("off") == False)

# Generated at 2022-06-12 09:39:04.849597
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "/some_path/some_file.py"
    encoding = "utf8"
    module = load_module_from_file_location(location, encoding)
    assert module.__file__ == location



# Generated at 2022-06-12 09:39:13.416738
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as tmp_dirname:

        # A) Create test config file
        test_data = "some_var = 10"
        test_filepath = os.path.join(tmp_dirname, "test_config.py")
        with open(test_filepath, "w") as test_file:
            test_file.write(test_data)

        # B) Create test environment variables
        os_environ["TEST_ENV_VAR_1"] = "test1"
        os_environ["TEST_ENV_VAR_2"] = "${TEST_ENV_VAR_1}"
        # 1) When location is Path
        assert load_module_from_file_location(Path(test_filepath)).some_var == 10

# Generated at 2022-06-12 09:39:24.020450
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    assert load_module_from_file_location(__file__).__file__ == __file__
    assert (
        load_module_from_file_location(__file__).__name__
        == "sanic.utils.load_module_from_file_location"
    )
    assert load_module_from_file_location(
        __file__ + "${SOME_ENV_VAR}"
    ).__file__ == __file__ + "${SOME_ENV_VAR}"
    assert load_module_from_file_location(
        __file__, submodule_search_locations=["utils"]
    ).__name__ == "sanic.utils.load_module_from_file_location"

# Generated at 2022-06-12 09:39:29.219133
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests load_module_from_file_location function."""
    from tempfile import TemporaryDirectory
    from textwrap import dedent
    from pathlib import Path
    from unittest.mock import patch

    # Create temporary module file.
    with TemporaryDirectory() as temp_dir:
        module_file = Path(temp_dir) / "module.py"
        with open(module_file, "w") as f:
            f.writelines(dedent("""\
                a = 1
                b = 'some_string'
                """))
        module = load_module_from_file_location(module_file)
        assert module.__file__ == str(module_file)
        assert module.a == 1
        assert module.b == "some_string"

    # Create temporary module file and use environment variable.
   

# Generated at 2022-06-12 09:39:38.916589
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""

    from contextlib import suppress

    from sanic.config import (
        BaseConfig,
        Config,
    )

    import os

    # Set some dummy environment variables.
    os.environ["TEST_ENV_VAR_1"] = "some_string"
    os.environ["TEST_ENV_VAR_2"] = "some_other_string"

    config = load_module_from_file_location(
        "/home/some_user/some_project/some_app/some_config.py"
    )

    assert isinstance(config, BaseConfig)

    # Unset dummy environment variables.
    with suppress(KeyError):
        del os.environ["TEST_ENV_VAR_1"]

# Generated at 2022-06-12 09:39:47.389462
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pickle

    file_path = Path.cwd()
    file_path_str = str(file_path)
    file_path_bytes = file_path.as_posix().encode("utf8")

    file_path_with_env_var = (
        file_path_str + "/${PWD}/${PWD}/${PWD}/../sanic_session/__init__.py"
    )

    file_path_with_env_var_bytes = (
        file_path_bytes + b"/${PWD}/${PWD}/${PWD}/../sanic_session/__init__.py"
    )

    os_environ["PWD"] = str(Path.cwd())


# Generated at 2022-06-12 09:39:57.077434
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import pytest

    # Check if the function throws LoadFileException
    # when the following environment variables are not set:
    # SOME_ENV_VAR, OTHER_ENV_VAR
    with pytest.raises(LoadFileException) as excinfo:
        location = "/some/path/${SOME_ENV_VAR}/${OTHER_ENV_VAR}"
        load_module_from_file_location(location)
    assert (
        str(excinfo.value)
        == "The following environment variables are not set: SOME_ENV_VAR, "
        "OTHER_ENV_VAR"
    )

    # Check if the function resolves environment variables
    # in format ${some_env_var} in location.

# Generated at 2022-06-12 09:40:04.465902
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # 1) - Check pathlib
    path = Path(__file__).parent.joinpath("./fixtures/simple_object.py")

    module = load_module_from_file_location(path)
    assert module.name == "simple object name"
    assert module.number == 42

    # 2) - Check env var resolution
    path = Path(__file__).parent.joinpath(
        "./fixtures/${SANIC_TEST_CONFIG_FILE_1}"
    )
    os_environ["SANIC_TEST_CONFIG_FILE_1"] = "simple_object.py"

    module = load_module_from_file_location(path)
    assert module.name == "simple object name"
    assert module.number == 42

    # 3) - Check bytes path
    path

# Generated at 2022-06-12 09:40:12.719985
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys

    # Function is supposed to raise ValueError if cannot turn val into bool.
    def bool_string_to_env_var(val: bool, env_var_name: str) -> None:
        if val:
            os_environ[env_var_name] = "y"
        else:
            os_environ[env_var_name] = "n"
        # Need to do that, because function str_to_bool
        # searches for the environment variable in os_environ.
        # If it does not find it, it will raise ValueError.
        reload(sys)

    class TestCase:
        """Tests function str_to_bool."""

        @staticmethod
        def test_valid_values():
            """Tests if function correctly turns into bool."""

# Generated at 2022-06-12 09:40:21.725395
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("str") == str
    assert load_module_from_file_location("__builtins__.str") == str

    # 1) Test loading modules from file paths
    module = load_module_from_file_location(
        "/home/user/sanic/examples/app.py"
    )
    assert module.app.__name__ == "app"

    module = load_module_from_file_location(
        "/home/user/sanic/examples/app.py",
        attr_name="some_attr",
    )
    assert module.some_attr.__name__ == "app"

    # 2) Test reading relative path

# Generated at 2022-06-12 09:40:30.036367
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import mkdir
    from pathlib import Path
    from shutil import rmtree
    from tempfile import TemporaryDirectory

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # 1) This location contains env_var `name`
    location = "${name}/tests/fixtures/test_load_module_from_file_location/name.py"
    # 2) Check that this environment variable is set
    assert "name" in os_environ
    # 3) Check that this environment variable is not set
    assert "not_defined_env_var" not in os_environ

    with TemporaryDirectory() as tmpdir:
        # Create and import module located in temp directory
        os_environ["name"] = tmpdir


# Generated at 2022-06-12 09:40:35.633126
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import time
    # Check if it correctly loads a file from path
    module_py = load_module_from_file_location(
        Path(__file__).parent.joinpath("_test.py")
    )
    assert module_py.some_var == "something"
    assert module_py.__file__ == Path(__file__).parent.joinpath(
        "_test.py"
    ).resolve()
    # Check if it correctly loads an environment variable located in the path
    os_environ["SANIC_TEST_ENV_VAR"] = str(Path(__file__).parent.joinpath("_test"))
    module_py = load_module_from_file_location(
        "${SANIC_TEST_ENV_VAR}/test_env_var.py"
    )

# Generated at 2022-06-12 09:40:45.025672
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from .config import load_module_from_file_location
    from .config import str_to_bool
    module = load_module_from_file_location(
        "config", "tests/test_loader_config.py"
    )
    assert str_to_bool(module.RESTFUL_JSON["indent"]) is False

    module = load_module_from_file_location(
        "config", "tests/test_loader_config_binary.pyc"
    )
    assert module.RESTFUL_JSON["indent"] == 5

    module = load_module_from_file_location(
        "config", "tests/test_loader_config_py3_binary.pyc"
    )
    assert module.RESTFUL_JSON["indent"] == 5

    module = load_module_from_file

# Generated at 2022-06-12 09:40:54.673805
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    def _getattr(attr_name, default=None, on_none=None):  # noqa
        try:
            return getattr(
                test_load_module_from_file_location, attr_name
            )
        except AttributeError:
            if on_none:
                on_none()
            return default

    def _setattr(attr_name, value):  # noqa
        setattr(
            test_load_module_from_file_location, attr_name, value
        )


# Generated at 2022-06-12 09:41:04.392907
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location("./tests/config.py")
    assert module.FOO_BAR == "foo_bar"

    module = load_module_from_file_location("./tests")
    assert module.config.FOO_BAR == "foo_bar"

    module = load_module_from_file_location("./tests/")
    assert module.config.FOO_BAR == "foo_bar"

    os_environ["some_file_location"] = "tests/config.py"
    module = load_module_from_file_location(
        "./${some_file_location}", "./${some_file_location}"
    )
    assert module.FOO_BAR == "foo_bar"


# Generated at 2022-06-12 09:41:07.409219
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location(
            "/some/path/to/location", "__init__.py"
        ).__name__
        == "__init__"
    )

# Generated at 2022-06-12 09:41:15.613010
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # A) Test module loaded from file path, with no environments variables.
    local_path = Path(__file__).parent

    some_module = load_module_from_file_location(location=local_path / "config.py")
    assert some_module.A == 1
    assert some_module.B == 2
    assert some_module.C == 3

    # B) Test module loaded from file path, with enviroment variables in it.
    os_environ["SOME_ENV_VAR"] = "./"
    some_module = load_module_from_file_location(
        location=local_path / "config.py", package="${SOME_ENV_VAR}tests/"
    )
    assert some_module.A == 1
    assert some_module.B == 2
    assert some_module

# Generated at 2022-06-12 09:41:23.755805
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # A) Assert that returns a module instance.
    module = load_module_from_file_location("./test_data/test_1.txt")
    assert isinstance(module, types.ModuleType)

    # B) Assert that module has got file attribute.
    assert module.__file__ == "./test_data/test_1.txt"

    # C) Assert that module has got aa and bb attributes.
    assert module.aa == "aa"
    assert module.bb == "bb"

    # D) Assert correct removing environment variables in location.
    with os_environ.copy() as environ:
        environ["SANIC_CONFIG_ENV_VAR_1"] = "aa"
        environ["SANIC_CONFIG_ENV_VAR_2"] = "bb"



# Generated at 2022-06-12 09:41:32.464307
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    from unittest import mock

    from os import environ as os_environ

    import pytest

    with tempfile.NamedTemporaryFile() as temp_file:
        temp_file.write(
            b"""
# -*- coding: utf-8 -*-
some_var = 1
some_var_dict = dict(a=1, b=2, c=3)
some_var_list = [1, 2, 3]
some_var_tuple = (1, 2, 3)
some_var_set = set([1, 2, 3])
    """
        )
        temp_file.flush()
        temp_file.seek(0)

        test_mod = load_module_from_file_location(temp_file.name)

        assert test_mod.some_var

# Generated at 2022-06-12 09:41:43.035410
# Unit test for function load_module_from_file_location

# Generated at 2022-06-12 09:41:47.451293
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as config_file:
        config_file.write("SOME_CONFIG = True")

    try:
        config = load_module_from_file_location(config_file.name)
        assert config.SOME_CONFIG is True
    finally:
        Path(config_file.name).unlink()

# Generated at 2022-06-12 09:41:58.152157
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest
    import tempfile
    import os

    def _create_temp_file(with_env_var=False):
        test_string = "some string"
        if with_env_var:
            test_string = "${test_env_var}"

        with tempfile.NamedTemporaryFile(
            suffix=".py", delete=False, mode="wt"
        ) as test_file:
            test_string = test_string.encode()
            test_file.write(test_string)
            test_file.flush()
            return test_file.name

    def _test_load_module_from_file_location(test_string):
        with pytest.raises(PyFileError):
            load_module_from_file_location(test_string)


# Generated at 2022-06-12 09:42:10.717680
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    import_string_setup = "import_string_setup"
    with open(import_string_setup) as import_string_setup_file:
        exec(
            compile(
                import_string_setup_file.read(),
                import_string_setup,
                "exec",
            ),
            {},
        )

# Generated at 2022-06-12 09:42:17.118496
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_path = Path("./tests/some_file.py")  # noqa
    some_module = load_module_from_file_location(file_path)  # noqa
    assert some_module.TEST_DATA == "test"  # noqa

    file_path = Path("./tests/some_file")  # noqa
    some_module = load_module_from_file_location(file_path)  # noqa
    assert some_module.TEST_DATA == "test"  # noqa

# Generated at 2022-06-12 09:42:27.216003
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import remove, environ, path
    from tempfile import mkstemp
    from shutil import rmtree
    from os.path import join, dirname
    from unittest.mock import patch

    abs_path = path.abspath(path.dirname(__file__))

    # Simple load from file path
    simple_example_loaded_module = load_module_from_file_location(
        join(abs_path, "simple_example.py")
    )
    assert simple_example_loaded_module.simple_example_variable == 1

    # Load from file with environment variables
    environ["SIMPLE_ENV_EXAMPLE_VAR"] = "simple_env_example_var_value"

# Generated at 2022-06-12 09:42:32.157430
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Check if it is possible to pass here environment variables in format
    # ${some_env_var}.
    os_environ["ENV_VAR_FOR_UNIT_TEST"] = "file_location"

    # Check if function can load modules from locations with and without
    # environment variables in format ${some_env_var}.
    assert (
        load_module_from_file_location(
            "ENV_VAR_FOR_UNIT_TEST", "${ENV_VAR_FOR_UNIT_TEST}/config.py"
        )
        is load_module_from_file_location("file_location/config.py",)
    )

    # Check if function can load file if it is located inside package.

# Generated at 2022-06-12 09:42:36.809082
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location.__doc__ is not None

    import sys
    import os
    import os.path

    from pathlib import Path
    from tempfile import mkdtemp
    from shutil import rmtree
    from unittest.mock import patch

    from sanic.exceptions import LoadFileException

    # First test that the function throws exception if provided file
    # path is not correct.

    # A) Location is relative path to non existing file.
    def test_location_is_relative_path_to_non_existing_file(caplog):

        # Given.
        some_test_non_existing_file = Path("test_file_name.py")
        assert not os.path.exists(some_test_non_existing_file)

        # When.

# Generated at 2022-06-12 09:42:43.602373
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os, sys
    from pathlib import Path

    STR_MODULE_NAME, STR_MODULE_FILE_NAME = "some_module_name", "some_file.py"

    STR_MODULE_DATA = f'{STR_MODULE_NAME} = "hello"'

    # Create temporary module
    with tempfile.NamedTemporaryFile(mode="wt", suffix=".py") as f:
        f.write(STR_MODULE_DATA)
        f.flush()

        # Try to load it with function load_module_from_file_location
        module = load_module_from_file_location(f.name)

        assert module.__name__ == STR_MODULE_NAME, "module name is wrong"
        assert module.__file__ == f.name, "module file path is wrong"

# Generated at 2022-06-12 09:42:50.125558
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import mkdir
    from shutil import rmtree
    from tempfile import mkdtemp
    from time import time
    from unittest import TestCase

    temp_dir = mkdtemp()
    conf_dir = Path(temp_dir) / "conf"
    conf_dir.mkdir()

    config_file_path = conf_dir / "configuration.py"
    with open(config_file_path, "w") as config_file:
        config_file.write("CONFIG_TEST_VAR = %s" % str(time()))

    module = load_module_from_file_location(config_file_path)

    try:
        assert module.CONFIG_TEST_VAR
    finally:
        rmtree(temp_dir)

# Generated at 2022-06-12 09:42:58.108432
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import_string = "import_string"
    some_module = load_module_from_file_location(import_string, __file__)
    assert some_module is not None
    assert (
        load_module_from_file_location(import_string, "/some/path/to/import_string.py")
        is not None
    )
    assert (
        load_module_from_file_location(
            import_string, "${environment_variable}/import_string.py"
        )
        is not None
    )
    assert (
        load_module_from_file_location(import_string, Path(__file__))
        is not None
    )

# Generated at 2022-06-12 09:43:06.284167
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    def create_file(directory, name, content):
        path = os.path.join(directory, name)
        with open(path, "w") as f:
            f.writelines(content)

    current_dir = os.getcwd()

# Generated at 2022-06-12 09:43:13.830207
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Check for failure if configuration contains environment variables
    # but it is not set
    conf_path = "test_config.py"
    with open(conf_path, "w") as conf:
        conf.write("KEY = '$ENV_VAR'")
    try:
        _mod = load_module_from_file_location(conf_path)
        assert False
    except LoadFileException:
        assert True
    finally:
        Path.unlink(Path(conf_path))

    # Check for correct resolution of environment variables
    # in configuration
    conf_path = "test_config.py"

# Generated at 2022-06-12 09:43:24.786789
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    tmp_file = tempfile.NamedTemporaryFile(suffix=".py")
    # conf = import_string("sanic.conf.test_config")

# Generated at 2022-06-12 09:43:31.151932
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location("sanic.test_helpers.config_module")
        .TEST_CONFIG_VARIABLE
        == "test_config_value"
    )

    assert (
        load_module_from_file_location("sanic.test_helpers.config_module2")
        .TEST_CONFIG_VARIABLE2
        == "test_config_value2"
    )

    assert (
        load_module_from_file_location("sanic.test_helpers.config_module3")
        .TEST_CONFIG_VARIABLE3
        == "test_config_value3"
    )


# Generated at 2022-06-12 09:43:39.677777
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    test_file_location_1 = "${PWD}/tests/test_utils.py"
    test_file_location_2 = "${PWD}/tests/test_config.py"
    test_file_location_3 = "${PWD}/tests/test_config.pyc"
    test_file_location_4 = "${PWD}/tests/not_existing.py"

    # 1. If path to file is provided, and this file exists, then
    #    import this file as Python module.
    assert load_module_from_file_location(
        test_file_location_1
    ).__name__ == "tests.test_utils"

    # 2. If path to file is provided, and this file exists, but does not
    #    contain a valid Python code, raises appropriate exception.

# Generated at 2022-06-12 09:43:49.266068
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    importlib.reload(import_string)
    importlib.reload(types)
    from sanic.helpers import import_string
    from sanic.helpers import load_module_from_file_location
    from types import ModuleType

    module_path_with_env_var = "test_module_path_with_env_var"
    module_path_without_env_var = "test_module_path_without_env_var"
    name = "module_name"

# Generated at 2022-06-12 09:43:58.367515
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import path as os_path
    from tempfile import TemporaryDirectory

    tmp_dir = TemporaryDirectory()
    tmp_dir_path = tmp_dir.name
    # Create some.py with some function.
    some_file_path = os_path.join(tmp_dir_path, "some.py")
    with open(some_file_path, "w", encoding="utf8") as some_file:
        some_file.writelines(
            [
                "def some_func():\n",
                "    return 'some_return_value'\n",
            ]
        )

    # Create tmp.py with variable.
    tmp_file_path = os_path.join(tmp_dir_path, "tmp.py")

# Generated at 2022-06-12 09:44:06.859199
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    assert (
        load_module_from_file_location(
            "tests/test_files/test_settings.py"
        ).TEST_VARIABLE_ONE
        == "TEST_SETTINGS_ONE"
    )
    assert (
        load_module_from_file_location(
            "tests/test_files/test_settings.json"
        ).TEST_VARIABLE_ONE
        == 1
    )
    assert (
        load_module_from_file_location(
            "tests/test_files/test_settings.config"
        ).TEST_VARIABLE_ONE
        == 1
    )


# Generated at 2022-06-12 09:44:16.471307
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile as tf
    import shutil
    import sys

    temp_dir = Path(tf.mkdtemp())

    temp_file_name = temp_dir / "tmp.py"
    with open(str(temp_file_name), "w") as f:
        f.write("a=5")

    module = load_module_from_file_location(temp_file_name)

    assert module.a == 5

    temp_file_name2 = temp_dir / "tmp2.py"
    with open(str(temp_file_name2), "w") as f:
        f.write("b=10")

    module2 = load_module_from_file_location(temp_file_name2)

    assert module2.b == 10

    temp_file_name3 = temp_dir

# Generated at 2022-06-12 09:44:22.164279
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Load path with environment variables."""
    os_environ["SANIC_CONFIG_MODULE"] = "sanic.tests.test_settings"
    loaded_config = load_module_from_file_location(
        "some_unexisting_module_name", "${SANIC_CONFIG_MODULE}.py"
    )
    assert loaded_config.TEST == "Sanic"


# Generated at 2022-06-12 09:44:30.329596
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_path = "tests/test_conf.py"
    module = load_module_from_file_location(file_path)

    assert isinstance(module, types.ModuleType)
    assert module.__file__ == file_path
    assert module.TEST_CONFIG == "TEST_CONFIG"
    assert module.TEST_CONFIG2 == 3

    module = load_module_from_file_location(file_path, "tests/")
    assert isinstance(module, types.ModuleType)
    assert module.__file__ == file_path
    assert module.TEST_CONFIG == "TEST_CONFIG"
    assert module.TEST_CONFIG2 == 3

# Generated at 2022-06-12 09:44:36.480066
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = Path(__file__).parent / "sanic/config.py"
    module = load_module_from_file_location(location)
    assert hasattr(module, "TEST_KEY")
    assert module.TEST_KEY == "TEST_VALUE"

    location = Path(__file__).parent / "sanic/config.py"
    module = load_module_from_file_location(location)
    assert hasattr(module, "TEST_KEY")
    assert module.TEST_KEY == "TEST_VALUE"

# Generated at 2022-06-12 09:44:46.919479
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Valid variables
    location = "sanic.config.test_config.py"
    assert location == load_module_from_file_location(location).__file__
    assert location == load_module_from_file_location(Path(location)).__file__
    location = "sanic.config/test_config.py"
    assert location == load_module_from_file_location(location).__file__
    assert location == load_module_from_file_location(Path(location)).__file__
    location = "sanic.config/test_config"
    assert location == load_module_from_file_location(location).__file__
    assert location == load_module_from_file_location(Path(location)).__file__

    # Invalid variables

# Generated at 2022-06-12 09:44:55.940388
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["test_env_var"] = "test_env_val"
    assert (
        load_module_from_file_location("./test.py")
        == load_module_from_file_location("./test.py")
    )
    assert (
        load_module_from_file_location("${test_env_var}/test.py")
        == load_module_from_file_location("./test.py")
    )
    assert (
        load_module_from_file_location("${test_env_var}/test.py")
        == load_module_from_file_location("${test_env_var}/test.py")
    )

# Generated at 2022-06-12 09:45:01.801230
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def clean_module_attrs(module):
        for k in list(module.__dict__.keys()):
            if not k.startswith("__"):
                del module.__dict__[k]

    # Simple case
    sample_module = load_module_from_file_location(
        "sample", "tests/data/sample_module.py"
    )
    assert sample_module.sample_function() == "sample_function"
    assert sample_module.sample_value == "sample_value"
    clean_module_attrs(sample_module)

    # Case with existing module, but not loaded.
    with pytest.raises(LoadFileException) as excinfo:
        load_module_from_file_location(
            "sample", "tests/data/sample_module_2.py"
        )

# Generated at 2022-06-12 09:45:11.660925
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa

    import os
    import tempfile

    # A) Load python file from file path.
    with tempfile.NamedTemporaryFile(
        "w",
        delete=False,
        prefix="sanic_test_module_from_file_location",
    ) as temp_py_file:
        temp_py_file.write("test = True")
    loaded_module = load_module_from_file_location(temp_py_file.name)
    os.unlink(temp_py_file.name)
    assert loaded_module.test

    # B) Load python file from file path with env variables.
    test_env_var1 = "sanic_test_env_var1"
    test_env_var2 = "sanic_test_env_var2"
    test_env_var1_

# Generated at 2022-06-12 09:45:20.764686
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdirname:
        path = Path(tmpdirname)

        # A) Check if location contains any environment variables
        #    in format ${some_env_var}.
        # B) Check these variables exists in environment.
        # C) Substitute them in location.
        os_environ["SOME_ENV_VAR"] = str(path)
        location = "${SOME_ENV_VAR}/some_file.py"
        module = load_module_from_file_location(location)
        assert module.__file__ == str(path / "some_file.py")

        # test of decoding bytes location into string
        location = str(Path(tmpdirname) / "some_file.py").encode("utf8")
        module

# Generated at 2022-06-12 09:45:29.997257
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """ Unit testing for function load_module_from_file_location. """

    # Test case 1
    # When some_module_name above is inside some_env_var directory
    # that is inside ${some_env_var} directory.
    #
    # A) Set environment variables.
    os_environ["some_env_var"] = tmpfile_path
    os_environ["${some_env_var}"] = tmpfile_path

    # B) Create file tmp/tmpfile_name.py source code.
    tmpfile_content = "# some_module_name source code."
    with open(tmpfile_path + "/tmpfile_name.py", "w") as file_:
        file_.write(tmpfile_content)

    # C) Call function under test.
    some_module = load_module_from_file

# Generated at 2022-06-12 09:45:35.973792
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["some_env_var"] = "some_env_var_value"
    PATH_TO_THIS_FILE = Path(__file__)
    CONFIG_LOCATION = PATH_TO_THIS_FILE.parent

    # A) Passing path with name of file as argument
    some_config = load_module_from_file_location(
        CONFIG_LOCATION / "test_helper_configs" / "config_1.py"
    )
    assert some_config.test_var == "config_1 value"

    # B) Passing path as argument
    some_config = load_module_from_file_location(CONFIG_LOCATION)
    assert some_config.__file__ == str(CONFIG_LOCATION)
    assert some_config.test_var == "config value"

    # C) Passing string

# Generated at 2022-06-12 09:45:39.847358
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    some_module = load_module_from_file_location(
        "some_module_name", "./examples/test.py"
    )

    assert some_module.test_var == "Hello"

# Generated at 2022-06-12 09:45:48.939318
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    def _create_temp_file(file_name: str, content: str, tmp_path: str):
        file_name = str(Path(tmp_path, file_name).absolute())
        with open(file_name, "w") as f:
            f.write(content)

        return file_name

    def test_load_module_from_file_location_from_file(tmp_path):
        file_name = _create_temp_file("config_from_file.py", "some_value = 1", tmp_path)

        module = load_module_from_file_location(file_name)

        assert module.some_value == 1
        assert module.__file__ == file_name


# Generated at 2022-06-12 09:45:57.893817
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Test if it imports file with py extension
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".py") as tf:
        tf.writelines(["some_var = 'some_value'\nany_var = 1\n"])
        tf.flush()

        loaded_module = load_module_from_file_location(tf.name)

        assert getattr(loaded_module, "some_var") == "some_value"
        assert getattr(loaded_module, "any_var") == 1

    # B) Test if it imports file without py extension
    with tempfile.NamedTemporaryFile(mode="w+") as tf:
        tf.writelines(["some_var = 'some_value'\nany_var = 1\n"])

# Generated at 2022-06-12 09:46:05.816939
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["some_env_var"] = "some_env_var_value"

    module = load_module_from_file_location(
        "/some/path/some_module_name",
        "/some/path/${some_env_var}",
        "some_module_name",
    )

    assert module.__name__ == "some_module_name"
    assert module.__file__ == "/some/path/some_env_var_value"

    del os_environ["some_env_var"]



# Generated at 2022-06-12 09:46:14.796372
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    import os

    test_module = "test_module"
    test_module_path = os.getcwd() + "/test_dir/test_module.py"
    test_module_import_string = "test_dir.test_module"
    test_module_env_string = "test_dir/${test_env_var}.test_module"

    os.environ["test_env_var"] = "test_env_var"

    # Test import string
    test_module_import_string_module = load_module_from_file_location(
        test_module_import_string
    )
    assert (test_module_import_string_module.test_module_variable == "test_value")

    # Test module path
    test_module_path_module = load_module_from_file

# Generated at 2022-06-12 09:46:24.126162
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function.
    """
    from os import getcwd
    from ast import literal_eval

    # A) Check if location contains any environment variables.
    #    in format ${some_env_var}.
    os_environ["SOME_ENV_VAR"] = getcwd()
    cfg = load_module_from_file_location(
        "__init__.py",
        "/some/path/${SOME_ENV_VAR}"
        "/sanic/utils/tests/sanic/utils/tests/__init__.py",
    )
    assert cfg.some_global_string == "Hello"

    # B) Check these variables exists in environment.

# Generated at 2022-06-12 09:46:33.629201
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        "config_loader.tests.data.config"
    )
    assert module.TEST_CONFIG_ITEM == "TEST_CONFIG_ITEM"

    module = load_module_from_file_location(
        "config_loader.tests.data.config.py"
    )
    assert module.TEST_CONFIG_ITEM == "TEST_CONFIG_ITEM"

    module = load_module_from_file_location(
        Path("config_loader/tests/data/config.py")
    )
    assert module.TEST_CONFIG_ITEM == "TEST_CONFIG_ITEM"

    # Should return same module as when providing directory path

# Generated at 2022-06-12 09:46:40.867137
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # pass
    assert load_module_from_file_location(
        Path(__file__).parent / "test_config" / "test.conf"
    ).TEST_CONFIG == "test_config"

    # fail - wrong path
    try:
        load_module_from_file_location(
            Path(__file__).parent / "test_config" / "test.conf1"
        )
    except LoadFileException:
        pass
    else:
        assert False

    # fail - wrong content
    try:
        load_module_from_file_location(
            Path(__file__).parent / "test_config" / "test.conf_wrong"
        )
    except PyFileError:
        pass
    else:
        assert False

    # pass

# Generated at 2022-06-12 09:46:51.539162
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    from pathlib import Path
    from os import environ as os_environ

    test_env_var = "TEST_ENV_VAR"

    # Prepare directory for testing
    temp_dir = tempfile.mkdtemp()
    temp_dir_path = Path(temp_dir)

    temp_file_name = "test_file.py"
    temp_file_path = temp_dir_path / temp_file_name
    temp_file_content = """
        class SomeClass:
            def __init__(self, val: str):
                self._val = val
          
            @property
            def val(self) -> str:
                return self._val
        """

# Generated at 2022-06-12 09:46:59.288033
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test if default file is loaded
    assert load_module_from_file_location(
        __file__
    ).__file__ == __file__  # nosec

    # Test if file with py extension is loaded
    path = Path(__file__).parent / "__init__.py"
    assert (
        load_module_from_file_location(path)
        .__file__.replace(".pyc", ".py")
        == str(path)
    )

    # Test if file with other extension is loaded
    path = Path(__file__).parent / "__init__.py"
    assert (path.with_suffix(".txt") == Path(__file__).parent / "__init__.txt")

# Generated at 2022-06-12 09:47:09.779888
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os

    some_config_file, relative_some_config_file = os.path.join(
        os.path.dirname(__file__), "some_config_file.py"
    ), "some_config_file.py"
    os.environ["RELATIVE_PATH"] = "."

    # A) Check if works with Path object.
    some_config_module = load_module_from_file_location(
        Path(some_config_file), encoding="utf8"
    )
    assert some_config_module.SOME_CONFIG_VARIABLE == "some_config_variable_value"

    # B) Check if works with string.

# Generated at 2022-06-12 09:47:16.635543
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # pylint: disable=invalid-name
    assert load_module_from_file_location("os.path").__name__ == "os.path"
    assert load_module_from_file_location("os", "path").__name__ == "os.path"
    assert load_module_from_file_location("os", "path.py").__name__ == "os.path"

    # TODO: Write unit tests for situation when
    #       "location" argument is pathlib.Path object



# Generated at 2022-06-12 09:47:21.697969
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    assert load_module_from_file_location("os").__name__ == "os"

    assert (
        load_module_from_file_location(
            "os", "/usr/bin/${PATH}/python/lib"
        ).__name__
        == "os"
    )

# Generated at 2022-06-12 09:47:35.837634
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from importlib import reload as reload_module
    from tempfile import TemporaryDirectory as _TemporaryDirectory

    from sanic.config import ModuleType, ModuleSpecType

    # Part 1: Test loading a module from a file path.
    with _TemporaryDirectory() as temp_dir_path:
        temp_dir_path = Path(temp_dir_path)

        # A) Check the function is able to load a module from a file path
        #    without any environment variables in this path
        simple_file_path_location = (
            temp_dir_path.joinpath("simple_config.py")
        )

# Generated at 2022-06-12 09:47:45.389696
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function."""

    # test load_module_from_file_location for function which returns dict
    def test_load_module_from_file_location_for_dict():
        print(
            "test_load_module_from_file_location_for_dict - is starting..."
        )
        try:
            location = "tests/test_configs/test_dict_config.py"
            module = load_module_from_file_location(location)
            assert module == {"test_key": "test_value"}
            print(
                "test_load_module_from_file_location_for_dict - is completed."
            )
        except Exception as e:
            print(f"test_load_module_from_file_location_for_dict - is failed!")


# Generated at 2022-06-12 09:47:54.435509
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # This is not actual unit test, but more like demonstration
    # of function load_module_from_file_location working

    # 1) Load module from path.
    module = load_module_from_file_location(
        Path(__file__).parent.joinpath("function_utils.py")
    )
    assert "str_to_bool" in dir(module)

    # 2) Load module from path with environment variables in it.
    # Specify some environment variable.
    os_environ["SOME_ENV_VAR"] = Path(__file__).parent.as_posix()
    # Load module from path using environment variable.
    module = load_module_from_file_location(
        "/${SOME_ENV_VAR}/function_utils.py"
    )