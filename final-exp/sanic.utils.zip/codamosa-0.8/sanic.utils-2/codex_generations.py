

# Generated at 2022-06-12 09:38:11.124256
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    import sys

    def _remove_from_sys_modules(location: str) -> None:
        if isinstance(location, Path):
            location = str(location)
        key = os.path.split(location)[1].split(".")[0]
        if key in sys.modules:
            del sys.modules[key]

    test_file = Path(__file__).parent.__add__("../tests/test_config.py")
    test_file_json = Path(__file__).parent.__add__("../tests/test_config.json")
    test_file_unknown_ext = Path(__file__) / "../tests/test_config"
    test_file.resolve()
    test_file_json.resolve()


# Generated at 2022-06-12 09:38:20.918260
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("builtins").__name__ == "builtins"
    assert load_module_from_file_location("os").__name__ == "os"
    assert load_module_from_file_location("types").__name__ == "types"

    # A) .py file and file name as path
    module = load_module_from_file_location("./../tests/test_config.py")
    assert module.KEY == "value"

    # B) .py file and file name as path
    module = load_module_from_file_location(
        "test_config.py", "./../tests/"
    )  # type: ignore
    assert module.KEY == "value"
    assert module.__name__ == "test_config"

    # C) .py file and file name

# Generated at 2022-06-12 09:38:28.446716
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Load module by path
    path = "./sanic_plugins/tasks.py"
    module = load_module_from_file_location(path)
    assert module.__name__ == "tasks"
    os.remove(path)

    # Load module by name
    module = load_module_from_file_location("types")
    assert module.__name__ == "types"

    # Load module with not defined ${SOME_ENV_VAR} variable
    path = "/some/path/${SOME_ENV_VAR}"
    with pytest.raises(LoadFileException):
        module = load_module_from_file_location(path)

    # Load module with ${SOME_ENV_VAR} variable defined
    os.environ["SOME_ENV_VAR"]

# Generated at 2022-06-12 09:38:38.377165
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # pylint: disable=unused-variable
    test_config_location = "tests/test_config_location.py"
    test_config_location_2 = Path("tests/test_config_location_2.py")
    test_config = load_module_from_file_location(test_config_location)
    test_config_2 = load_module_from_file_location(test_config_location_2)
    assert hasattr(test_config, "test_var")
    assert getattr(test_config, "test_var") == 10
    assert hasattr(test_config_2, "test_var")
    assert getattr(test_config_2, "test_var") == 10

# Generated at 2022-06-12 09:38:45.893630
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import logging
    import os
    import sys
    import unittest
    from pathlib import Path

    from sanic.constants import TEST_DIR
    from sanic import Sanic

    class TestUpper(unittest.TestCase):
        def setUp(self):
            self.app = Sanic("load_module_from_file_location_test")

        def test_load_module_from_file_location_case1(self):
            # This test imitates such a call:
            #   some_module = load_module_from_file_location(
            #       "some_module_name",
            #       "/some/path/${some_env_var}"
            #   )
            #   some_module.some_module_var
            expected_result = 6

            # 1. Create empty config.py file

# Generated at 2022-06-12 09:38:51.692514
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    location = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        "templates",
        "manage_example.py",
    )
    module = load_module_from_file_location(location)
    assert module.__file__.endswith("templates/manage_example.py")
    assert module.__dict__["name"] == "manage_example"

# Generated at 2022-06-12 09:39:01.988285
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_ENV_VAR"] = "value_of_test_env_var"
    some_file_module = load_module_from_file_location(
        "tests/files/coroutine_function.py"
    )
    assert some_file_module.foo() == "bar"
    some_file_module = load_module_from_file_location(
        b"tests/files/coroutine_function.py", encoding="utf8"
    )
    assert some_file_module.foo() == "bar"
    some_file_module = load_module_from_file_location(
        Path("tests/files/coroutine_function.py")
    )
    assert some_file_module.foo() == "bar"
    some_file_module = load_module_from_file

# Generated at 2022-06-12 09:39:09.062192
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ

    environ["TEST"] = "localhost"

    TEST_VAR_VAL = "test"

    test_module = load_module_from_file_location(
        "tests/files/test_load_module_from_file_location.py"
    )

    assert test_module.TEST_VAR == TEST_VAR_VAL

    # Test if location parameter is of bytes type.
    test_module = load_module_from_file_location(
        b"tests/files/test_load_module_from_file_location.py"
    )

    assert test_module.TEST_VAR == TEST_VAR_VAL

    # Test if location parameter is a pathlib.Path object.

# Generated at 2022-06-12 09:39:18.749686
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ, remove
    from os.path import join, isfile

    # Case 1
    # Testing if module could be load from string path
    with TemporaryDirectory() as temp_dir:
        location = join(temp_dir, "config.py")
        content = '''\
        """This is comment"""
        some_value = 'foo'
        """This is comment"""

        some_second_value = 'bar'
        '''
        with open(location, 'w') as config_file:
            config_file.write(content)

        module = load_module_from_file_location(location)
        assert module.some_value == 'foo'
        assert module.some_second_value == 'bar'

    # Case 2
    # Testing if module could be load from string path

# Generated at 2022-06-12 09:39:25.849176
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # import function
    from sanic.config import load_module_from_file_location

    # Define test file content
    some_vars = {"a": 1, "b": "2"}
    file_content = """
        a = '{}'
        b = '{}'
        """.format(
        some_vars["a"], some_vars["b"]
    )

    # Create test file
    import tempfile
    import os

    file_path = tempfile.NamedTemporaryFile(delete=False).name
    os.unlink(file_path)

    with open(file_path, "w") as f:
        f.write(file_content)

    # Load test file
    module = load_module_from_file_location(file_path)

    # Check file loaded correctly
   

# Generated at 2022-06-12 09:39:38.243441
# Unit test for function load_module_from_file_location

# Generated at 2022-06-12 09:39:46.885673
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory(prefix="sanic_config_") as tempdir:
        # A) Config file contains no environment variables.
        config_file_path = Path(tempdir) / "config.py"

        with open(config_file_path, "w") as config_file:
            config_file.write("SIMPLE_CONSTANT = 1\n")

        config = load_module_from_file_location(config_file_path)
        assert config.SIMPLE_CONSTANT == 1

        # B) Config file contains environment variables in format ${some_env_var}.
        config_file_path = Path(tempdir) / "config.py"


# Generated at 2022-06-12 09:39:49.431415
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = Path(__file__).parent / "test_load_module_from_file_location.py"
    module = load_module_from_file_location(path)
    assert module.config_name == "valid_config"

# Generated at 2022-06-12 09:39:58.740388
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Given
    import os
    import json
    import tempfile
    import shutil

    import sanic.config

    # When
    config_dir_path = Path(tempfile.mkdtemp())
    config_dir_path.absolute() # to make sure we use absolute path
    config_path = config_dir_path / "config.py"
    config_str = "test = 'true'"
    config_path.write_text(config_str)
    config_json_path = config_dir_path / "config.json"
    config_json_str = json.dumps({"test_json": "true"})
    config_json_path.write_text(config_json_str)

    config_2_path = Path("tests/test_server/config.py")
    config_2_path.absolute()

# Generated at 2022-06-12 09:40:03.320198
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile
    import sys
    import os

    # A) Module from file
    # A.1) File with .py extension.
    fd, path = tempfile.mkstemp(suffix=".py")

# Generated at 2022-06-12 09:40:11.818007
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ, mkdir
    from os.path import isdir, isfile, join
    from os import remove
    from shutil import rmtree

    test_config_name = "test_config_name"
    test_place = "/tmp/sanic"
    test_config_name_with_path = join(test_place, test_config_name + ".py")

    # Create test file
    if not isdir(test_place):
        mkdir(test_place)

    with open(test_config_name_with_path, "w") as config_file:
        config_file.write("test_config = 42")


# Generated at 2022-06-12 09:40:16.474954
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    simple_config_path = Path(__file__).parent / "configs/simple.yml"
    simple_config = load_module_from_file_location(simple_config_path)
    assert simple_config.knights == "Ni"

    simple_config_path_str = (
        Path(__file__).parent
        / "configs"
        / "${HOME}/example_config_for_testing_env_vars.yml"
    )
    simple_config = load_module_from_file_location(simple_config_path_str)
    assert simple_config.knights == "Ni"

# Generated at 2022-06-12 09:40:25.775219
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with pytest.raises(LoadFileException) as exception:
        load_module_from_file_location("/some_path/${some_env_var}")

    assert (
        str(exception.value)
        == "The following environment variables are not set: some_env_var"
    )
    os_environ["some_env_var"] = "some_value"
    os_environ["some_env_var_with_underscore"] = "some_value"

    # In this case we should have no exception
    load_module_from_file_location("/some_path/${some_env_var}")

    # Test that we can pass file path as Pathlib object

# Generated at 2022-06-12 09:40:32.956639
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    import pytest
    from copy import copy

    os_environ["ENV_VAR"] = "123"
    config_example = """
        var1 = "123"
        var2 = "456${ENV_VAR}"
    """

    with tempfile.NamedTemporaryFile("w", delete=False) as f:
        f.write(config_example)
        tmp_file_path = f.name

    loaded_mod = load_module_from_file_location(tmp_file_path)

    assert loaded_mod.var1 == "123"
    assert loaded_mod.var2 == "456123"

    # Test changing the file path from str to Path
    loaded_mod = load_module_from_file_location(Path(tmp_file_path))

    assert loaded

# Generated at 2022-06-12 09:40:38.531266
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function
    """
    import os
    import tempfile

    from_str = "path/to/some/file.py"
    from_bytes = from_str.encode("utf8")
    from_path = Path(from_str)
    from_env_var = "path/${some_env_var}/to/some/file.py"

    # Prepare environment for the test
    temp_dir = tempfile.TemporaryDirectory()
    os.environ["some_env_var"] = temp_dir.name

    # Create a temp file what will be used in the test
    with open("{}/test_file.py".format(temp_dir.name), "w") as temp_file:
        temp_file.write("test=42")

    # Run

# Generated at 2022-06-12 09:40:51.736423
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # load_module_from_file_location works with string
    assert (
        load_module_from_file_location(
            "tests/test_data/test_configs/config1.py"
        ).TEST_VAR
        == "TEST_VAR"
    )

    # load_module_from_file_location works with bytes
    assert (
        load_module_from_file_location(
            b"tests/test_data/test_configs/config1.py"
        ).TEST_VAR
        == "TEST_VAR"
    )

    # load_module_from_file_location works with Path instance

# Generated at 2022-06-12 09:41:01.700913
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test function load_module_from_file_location."""

    # Test loading file with environment variables.
    _file_with_env_var_path = Path(__file__).parent / "conf" / "env_var"
    _local_module_with_env_var_name = "module_with_env_var"

    # A) Check if local module with environment variables defined
    if _local_module_with_env_var_name in globals().keys():

        # B) Delete It if is.
        del globals()[_local_module_with_env_var_name]

    # 1) Test loading module with environment variables.
    #    Check if environment variable in config file is the same as in os env.

# Generated at 2022-06-12 09:41:02.523563
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # TODO
    pass

# Generated at 2022-06-12 09:41:11.574196
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""
    import os

    from tempfile import mkstemp

    location = ".tests.test_helpers.test_load_module_from_file_location"
    tmp_file = mkstemp(suffix=".py")

    with open(tmp_file[0], "r") as f:
        content = f.read()

    with open(tmp_file[0], "w") as f:
        f.write(
            content
            + '\ntest_loc="'
            + location
            + '"\ntest_int=10\ntest_dict={"key":"value"}\n'
        )

    test_module = load_module_from_file_location(tmp_file[0])
    assert test_module.test_loc == location


# Generated at 2022-06-12 09:41:18.942293
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert callable(load_module_from_file_location("types"))
    test_module = load_module_from_file_location("types")
    assert test_module.ModuleType == types.ModuleType
    os_environ["some_env_var"] = "some_val"
    test_module = load_module_from_file_location(
        "/some/path/${some_env_var}"
    )
    assert test_module.ModuleType == types.ModuleType
    del os_environ["some_env_var"]

# Generated at 2022-06-12 09:41:26.872319
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""

    import tempfile

    config = {"a": "b"}
    try:
        with tempfile.NamedTemporaryFile("w", suffix=".py") as conf_module:
            conf_module.write("__all__ = [" + str(config.keys()) + "]")
            conf_module.flush()
            config_mod = load_module_from_file_location(conf_module.name)
    except Exception as e:
        # If it fails, then os.error will be raised.
        # Since This module is built to work with os.error,
        # then it is OK.
        raise
    else:
        assert config.keys() == config_mod.__dict__.keys()



# Generated at 2022-06-12 09:41:31.803977
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from .test_file_config import fconfig

    # A) Check if fconfig has been loaded.
    assert hasattr(fconfig, "PERFECT_WEB_FRAMEWORK")
    assert fconfig.PERFECT_WEB_FRAMEWORK == "Sanic"

    # B) Check if fconfig has been loaded correctly.
    assert fconfig.settings["setting1"] == "setting1"
    assert fconfig.settings["setting2"] == "setting2"

    # C) Check if import_string() is working fine.
    assert fconfig.settings["setting3"] == "setting3"
    assert fconfig.settings["setting4"] == "setting4"

# Generated at 2022-06-12 09:41:41.564689
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import pytest

    expected_module = {"attr": "attr"}
    filename = "abc_123.py"
    path = tempfile.NamedTemporaryFile().name
    try:
        with open(f"{path}/{filename}", "w") as f:
            f.write(
                "".join(
                    [
                        "# some comment\n",
                        "attr = 'attr'\n",
                        "\n",
                        "def bar():\n",
                        "    pass\n",
                    ]
                )
            )
    except IOError as e:
        e.strerror = "Unable to load configuration file (e.strerror)"
        raise
    module = load_module_from_file_location(Path(path) / filename)

    # clean temporary file

# Generated at 2022-06-12 09:41:45.442808
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D102
    import sys

    assert (
        load_module_from_file_location(
            "/some/path/to/some_module.py", "some_module_name"
        )
        == sys.modules["some_module_name"]
    )



# Generated at 2022-06-12 09:41:51.848012
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    assert load_module_from_file_location("os") == os
    assert load_module_from_file_location("os").__file__ == os.__file__
    assert (
        load_module_from_file_location("tests.common").__file__
        == "tests/common.py"
    )
    # Test for ${some_env_var} in location
    assert load_module_from_file_location("os", "${PWD}").__file__ == os.__file__
    # Test for package in location
    assert (
        load_module_from_file_location("tests.common", "${PWD}").__file__
        == "tests/common.py"
    )
    # Test for bytes

# Generated at 2022-06-12 09:42:00.365117
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    from types import ModuleType
    from pathlib import Path

    fd, path = tempfile.mkstemp(suffix=".py")
    os.close(fd)

    path = Path(path)
    path.write_text("some_var = 5")

    mod = load_module_from_file_location(path)
    assert mod.some_var == 5
    assert isinstance(mod, ModuleType)
    assert mod.__file__ == str(path)

    os.remove(path)

# Generated at 2022-06-12 09:42:10.676848
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from . import test_utils, utils
    from pathlib import Path

    import tempfile
    from unittest import TestCase
    from unittest.mock import patch

    class TestLoadModuleFromFileLocation(TestCase):
        def test_load_module_from_file_location(self):
            # Test that module loaded as expected.
            # Test with bytes and str location types.
            # Test with simple path and path with environment variable.
            mod = test_utils.create_test_module()
            with tempfile.TemporaryDirectory() as temp_dir:
                temp_dir = Path(temp_dir)
                mod.path = temp_dir / "test_mod.py"
                test_utils.write_test_module_to_file(mod.path, mod)

                res_mod = load_module_from_file

# Generated at 2022-06-12 09:42:14.474370
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = (
        "${PWD}/tests/project_config_location/some_module_name.py"
    )
    _module = load_module_from_file_location(location)
    assert _module.ATTR == "I'm defined in some_module_name.py"
    assert _module.test_attribute == "test"

# Generated at 2022-06-12 09:42:21.310907
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from textwrap import dedent

    temp_file = NamedTemporaryFile(mode="w", delete=False, suffix=".py")
    temp_file.write(
        dedent(
            """\
            a = 1
            B ="asdf"
            c = {}
            def d(request):
                return "e"
            """
        )
    )
    temp_file.close()
    module = load_module_from_file_location(temp_file.name)
    assert module.a == 1
    assert module.B == "asdf"
    assert module.c == {}
    assert module.d(None) == "e"



# Generated at 2022-06-12 09:42:30.720015
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Load module from absolute path
    assert (
        load_module_from_file_location("/some/path/to/module.py").__name__
        == "module"
    )
    assert (
        load_module_from_file_location("/some/path/to/module").__name__ == "module"
    )

    # Load module from full path
    with tempfile.TemporaryDirectory() as temp_dir:
        module_path = os.path.join(temp_dir, "module.py")
        with open(module_path, "w") as module_file:
            module_file.write(
                """
dummy_dict = {'key': 'value'}
dummy_list = [1, 2, 3]
dummy_int = 100
            """
            )
        module = load_

# Generated at 2022-06-12 09:42:40.213885
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["ENV_VAR1"] = "1"
    os_environ["ENV_VAR2"] = "2"
    path = Path(__file__).parent / "test_files"
    module_path = path / "test_module.py"
    module_location = (
        "${ENV_VAR1}/"
        + str(module_path.relative_to(Path.cwd()))
        + "${ENV_VAR2}"
    )
    module = load_module_from_file_location(module_location)
    del os_environ["ENV_VAR1"]
    del os_environ["ENV_VAR2"]
    assert module.TEST == "TEST_VALUE"



# Generated at 2022-06-12 09:42:47.330583
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover
    import tempfile
    import random
    import string

    with tempfile.TemporaryDirectory() as tmpdir:
        base_dir = Path(tmpdir)
        file_name = "".join(
            random.choice(string.ascii_uppercase + string.digits)
            for _ in range(6)
        )
        file_path = base_dir / file_name
        os.mkdir(file_path)
        config_file_path = file_path / f"{file_name}.py"
        with open(config_file_path, "w") as f:
            f.write(
                """CONF_VALUE = "test_conf_value"
                CONF_VALUE_2 = None
                CONF_VALUE_3 = False"""
            )
        os_en

# Generated at 2022-06-12 09:42:55.987094
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests function load_module_from_file_location"""

    # Add new environment variable
    os_environ["TEST_CONFIG_FILE_TEST_LOAD_FILE_PATH"] = "server.py"

    # Try loading module with environment variable
    module = load_module_from_file_location(
        "./tests/config_file_test/test_load_file_path/${TEST_CONFIG_FILE_TEST_LOAD_FILE_PATH}"
    )
    assert module.TEST_CONFIG_FILE_TEST_LOAD_FILE_PATH == "server.py"

    # Try loading module with environment variable with wrong name

# Generated at 2022-06-12 09:43:00.781654
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # load some module from a path
    module = load_module_from_file_location(
        "sanic.helpers", "./sanic/helpers/__init__.py"
    )
    assert module.ROOT
    assert module.basic_dict
    assert module.load_module_from_file_location
    assert module.update_arguments
    assert module.get_function_name
    assert module.get_class_name
    assert module.import_string
    assert module.is_stream

    # load config from a path
    config = load_module_from_file_location(
        "config", "./tests/files/config_for_tests.py"
    )
    assert config.DEBUG
    assert config.TEST

    # load some module from a path that contains environment variables

# Generated at 2022-06-12 09:43:06.821270
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    from unittest.mock import patch

    tmp_dir = tempfile.gettempdir()  # get temporary directory path

    # A) Testing loading file directly.
    test_file_name = "test.py"
    test_file_path = Path(tmp_dir) / test_file_name
    test_file_path.touch()  # create empty test file
    test_file = load_module_from_file_location(test_file_path)  # load it
    # Check if test file is really loaded by checking if it's __file__
    # parameter has the same value.
    assert test_file.__file__ == str(test_file_path)

    # B) Testing loading file from an environment variable
    #    in format ${some_env_var}.
    # B.1) Setting environment

# Generated at 2022-06-12 09:43:17.408635
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""

    # pylint: disable=too-many-locals, too-many-branches, line-too-long, invalid-name
    # Test 1) Wrong location type
    try:  # noqa
        load_module_from_file_location(1)
    except TypeError as e:  # noqa
        assert str(e) == "Location has to be of a string type"
    else:
        raise TypeError("Location is not of a string type")

    # Test 2) Import module by name.
    #         This should works the same way as importlib.import_module()
    #         with respect of searching a module in python path.
    #         The only difference is that here we are passing the name
    #         of module as location.
    #        

# Generated at 2022-06-12 09:43:25.331237
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Testing of resolving environment variables in file path.
    import os

    environment_variable_name = "load_module_from_file_location_test_env_var"
    environment_variable_value = "test_value"


# Generated at 2022-06-12 09:43:31.384261
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import os.path
    import sys
    import unittest
    import tempfile
    import shutil

    class MockModules:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.modules = {}

        def _make(self, name):
            spec = importlib.util.spec_from_file_location(
                name, *self.args, **self.kwargs
            )
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            return mod

        def __getitem__(self, name):
            try:
                return self.modules[name]
            except KeyError:
                mod = self._make(name)
                self.modules

# Generated at 2022-06-12 09:43:36.130441
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    some_str = "Hello world"
    some_bytes = b"Hello world"
    some_pathlib = Path("Hello world")

    assert load_module_from_file_location(some_str) is None
    assert load_module_from_file_location(some_bytes) is None
    assert load_module_from_file_location(some_pathlib) is None



# Generated at 2022-06-12 09:43:42.251719
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    PATH = Path(__file__).parent / "test_module.py"
    os_environ["some_env_var"] = PATH.parent.as_posix()
    module = load_module_from_file_location(PATH)

    assert module.TEST_VARIABLE == "Test value"
    assert module.any_function() == "some_value"
    assert module.TEST_CLASS.__name__ == "TestClass"

    module = load_module_from_file_location(
        "${some_env_var}/test_module.py"
    )
    assert module.TEST_VARIABLE == "Test value"


# Generated at 2022-06-12 09:43:49.715285
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from types import ModuleType

    from pytest import raises

    module_location = "tests/test_config.py"

    loaded_module = load_module_from_file_location(module_location)
    assert isinstance(loaded_module, ModuleType)
    assert hasattr(loaded_module, "some_config_variable")
    assert loaded_module.some_config_variable == "some_config_value"

    # This should raise exception because there is no such file.
    with raises(FileNotFoundError):
        load_module_from_file_location("tests/non_existent_file.py")



# Generated at 2022-06-12 09:43:58.671887
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # pylint: disable=bare-except,no-else-raise,needdictwrap,unsubscriptable-object,raise-missing-from
    import pytest

    # Case 0: Import module with absolute path
    module = load_module_from_file_location("/etc/passwd")
    assert hasattr(module, "pw_name")

    # Case 1: Import module with relative path
    module = load_module_from_file_location("sanic/config.py")
    assert hasattr(module, "PORT")

    # Case 2: Load non existing module.
    with pytest.raises(IOError):
        load_module_from_file_location("/non/existing/file")

    # Case 3: Test if IOError.strerror was formatted correctly

# Generated at 2022-06-12 09:44:08.266076
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit tests for function load_module_from_file_location."""

    # A) Test that raises FileNotFoundError if file not found.
    try:
        load_module_from_file_location("/some_wrong_location/")
    except FileNotFoundError:
        pass
    else:
        raise Exception("Not raised FileNotFoundError!")

    # B) Test that raises LoadFileException if environment variable
    #    in format ${some_env_var} does not exists.
    try:
        load_module_from_file_location("/some_wrong_location/${invalid_variable}")
    except LoadFileException:
        pass
    else:
        raise Exception("Not raised LoadFileException!")

    # C) Test loading module from file location when location is
    #    a path to file.
    module

# Generated at 2022-06-12 09:44:17.686306
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["test_load_module_from_file_location"] = "test"

    class Test:
        TEST1 = 0
        TEST2 = "0"
        TEST3 = "a"
        TEST4 = ""

    class Test2:
        TEST1 = 1.1
        TEST2 = "1.1"
        TEST3 = 0
        TEST4 = ""

    # TEST1 - Try to load module from a string
    test_module = load_module_from_file_location(
        "sanic.test_module.test_module",
        __name__ + "/test_module/test_module.py"
    )
    assert test_module.TEST == "Some text test\n"

    # TEST2 - Try to load module from a bytes
    test_module = load_module_from_file_location

# Generated at 2022-06-12 09:44:28.500822
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def _test_import(location, fqn):
        module = load_module_from_file_location(location)
        assert fqn in str(module)

    _test_import(
        location="tests.test_helpers", fqn="tests.test_helpers"
    )
    _test_import(
        location="tests", fqn="tests"
    )
    # Check that function works correctly with
    # location of a bytes type
    _test_import(
        location=b"tests", fqn="tests"
    )
    # Check that function works correctly with
    # location of a pathlib.Path type
    path = Path("tests")
    _test_import(
        location=path, fqn="tests"
    )
    # Check that function works correctly with
    # location containing

# Generated at 2022-06-12 09:44:39.250159
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test for resolving environment variables in location
    # and loading file in format .py
    with tempfile.TemporaryDirectory() as temp_dir:
        some_env_value = "test_some_env_value"
        os.environ["some_env_var"] = some_env_value
        path = Path(temp_dir) / some_env_value / "test.py"
        path.parent.mkdir(parents=True)
        path.touch()
        assert (
            load_module_from_file_location(path) is None
        )  # pylint: disable=no-member

        os.environ.pop("some_env_var")
    # Test for loading file in format .py

# Generated at 2022-06-12 09:44:46.225509
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("os")
    assert (
        load_module_from_file_location(Path("os.py"))
        == load_module_from_file_location(Path("sanic/os.py"))
        == load_module_from_file_location("os.py")
    )
    assert (
        load_module_from_file_location(Path("os.py").absolute())
        == load_module_from_file_location("os.py")
    )
    assert (
        load_module_from_file_location("${PYTHONPATH}/os.py")
        == load_module_from_file_location("${PYTHONPATH}/sanic/os.py")
    )

# Generated at 2022-06-12 09:44:54.809394
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Testing load_module_from_file_location function."""

    # test if name is an importable name
    try:
        from tests.loadmodule_test_module import test_module
    except ImportError:
        raise AssertionError("Unable to import test module")

    try:
        module = load_module_from_file_location(
            "tests.loadmodule_test_module"
        )
        assert module.__name__ == test_module.__name__
        assert module.__file__ == test_module.__file__

    except Exception:
        raise AssertionError(
            "load_module_from_file_location did not imported importable"
            " module name properly"
        )

    # test if name is a file path to *.py file
    module = load_module_from_file_location

# Generated at 2022-06-12 09:45:02.797929
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover
    from pickle import dumps, loads

    location = "test_module.py"
    name = "test_module"
    test_module = load_module_from_file_location(location)

    # Check module name
    assert test_module.__name__ == name

    # Check module content
    assert hasattr(test_module, "var1")
    assert test_module.var1 == 1

    # Check module are not static
    test_module.var1 = 2
    assert test_module.var1 == 2

    # Check module reload
    test_module = load_module_from_file_location(location)
    assert test_module.var1 == 1

    # Check module are not serializable

# Generated at 2022-06-12 09:45:13.063978
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # P = Path
    # f = lambda p: p.as_posix()  # path -> string
    f = lambda p: str(p)
    import shutil
    import tempfile

    os_environ["TEST_ENV_VAR_A"] = "TEST_ENV_VAR_A"
    os_environ["TEST_ENV_VAR_B"] = "TEST_ENV_VAR_B"

    temp_dir = tempfile.mkdtemp()
    curdir = Path.cwd()

    # 1) name, path
    test_module_1 = load_module_from_file_location(
        "test_module_1",
        f"{temp_dir}/__pycache__/test_module_1.cpython-37.pyc",
    )


# Generated at 2022-06-12 09:45:22.267518
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["test_env_var"] = "test_env_var"

    print("The next test should return True")
    print(
        load_module_from_file_location(
            r"tests/fixture_files/test_load_module_from_file_location.py"
        ).vars["test_var"]
    )

    print("The next test should return True")
    print(
        load_module_from_file_location(
            r"tests\fixture_files\test_load_module_from_file_location.py"
        ).vars["test_var"]
    )

    print("The next test should return True")

# Generated at 2022-06-12 09:45:27.888148
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Try to load module using function load_module_from_file_location.
    """
    mod = load_module_from_file_location(
        "tests.unit.config.load_simple",
        "tests/unit/config/load_simple.py",
        is_package=False,
    )  # type: ignore
    assert mod.SIMPLE_VAR == "SIMPLE_VAR_VALUE"



# Generated at 2022-06-12 09:45:34.684812
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    def test_import_module_from_file_location(
        location, expected_filename, expected_name
    ):
        module = load_module_from_file_location(location)
        assert module.__file__ == expected_filename
        assert module.__name__ == expected_name

    # Test import from non-existent file
    try:
        load_module_from_file_location("this_module_does_not_exist")
    except LoadFileException as e:
        assert "Unable to load configuration file" in e.args[0]

    # Test import with environment variables
    os_environ["some_env_var"] = "some_test_variable_value"
    os_environ["other_env_var"] = "other_test_variable_value"

# Generated at 2022-06-12 09:45:43.946821
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from sanic.config import load_module_from_file_location, PyFileError

    # 0) Parameters validation.
    with pytest.raises(TypeError):
        load_module_from_file_location(None)

    with pytest.raises(IOError):
        load_module_from_file_location(None)

    with pytest.raises(IOError):
        load_module_from_file_location(1)

    with pytest.raises(IOError):
        load_module_from_file_location([])

    with pytest.raises(IOError):
        load_module_from_file_location(())

    with pytest.raises(IOError):
        load_module_from_file_location({"key": "value"})


# Generated at 2022-06-12 09:45:47.210064
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    load_module_from_file_location(__file__)
    load_module_from_file_location(Path(__file__))
    load_module_from_file_location(__file__.encode("utf8"), "utf8")

# Generated at 2022-06-12 09:45:58.620274
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def test_load_module_from_file_location_works(
        location, expected_module_name
    ):
        checkpoint_location = location
        module = load_module_from_file_location(location)
        # A) Test that checkpoint_location parameter is not changed by func.
        assert location is checkpoint_location
        # B) Test that function returns module with correct module name.
        assert module.__name__ == expected_module_name

    # A) Test that function works if location is of a string type.
    test_load_module_from_file_location_works(
        "os", "os"
    )
    # B) Test that function raises error if it gets a string but
    #    it can't get module.
    with pytest.raises(LoadFileException):
        load_module_from_file_location

# Generated at 2022-06-12 09:46:03.888933
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    MODULE_NAME = "test_load_module_from_file_location_module"
    os_environ["TEST_LOAD_MODULE_FROM_ENV"] = MODULE_NAME
    
    module = load_module_from_file_location(
        "test_load_module_from_file_location_module",
        __file__.replace("test_utils.py", "") + "${TEST_LOAD_MODULE_FROM_ENV}.py",
    )

    assert module.__name__ == MODULE_NAME

# Generated at 2022-06-12 09:46:12.795231
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Test all function load_module_from_file_location cases.

    To run this test you have to be in root directory.
    """
    import_string, spec_from_file_location
    import configparser
    from os import environ as os_environ, path as os_path
    from pathlib import Path
    from unittest import TestCase, mock

    from sanic.helpers import load_module_from_file_location

    some_env_var = "some_env_var"
    another_env_var = "another_env_var"
    yet_another_env_var = "yet_another_env_var"

    os_environ[some_env_var] = "some_env_value"

# Generated at 2022-06-12 09:46:17.516549
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        os_environ["TMP_DIR"] = temp_dir
        assert (
            load_module_from_file_location(
                b"${TMP_DIR}/a.py", encoding="utf-8"
            ).NAME == "a"
        )


# Generated at 2022-06-12 09:46:26.153259
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests function load_module_from_file_location."""
    import sys
    import os

    # A) Test with Path.
    try:
        "sanic_rfc7807" in sys.modules
    except:
        pass

    mod = load_module_from_file_location(
        (Path(__file__).parent / "test_data" / "test_file.py").as_posix()
    )
    assert mod.foo == "bar"

    # B) Test with path that has environment variable in format ${some_env}.
    # Try incorrect env name.
    os.environ["PATH_VAR"] = "bar"

# Generated at 2022-06-12 09:46:36.179917
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test with bytes location
    location = (
        Path(__file__).parent
        / ".."
        / "config"
        / "sanic_config.py"
    ).resolve().read_bytes()
    assert b"HOST" in location
    assert isinstance(location, bytes)
    module = load_module_from_file_location(location)
    assert hasattr(module, "HOST")
    assert module.HOST == "127.0.0.1"

    # Test with string location
    location = "/".join(location.split(b"/")[:-1]) + b"/sanic_config.py"
    assert b"HOST" in location
    assert isinstance(location, bytes)
    module = load_module_from_file_location(location)

# Generated at 2022-06-12 09:46:44.264848
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from os import environ
    from os.path import join as path_join
    from os.path import dirname as path_dirname
    from tempfile import mkstemp
    from shutil import move, rmtree

    from sanic.config import Config, BASE_LOGGING
    from sanic.constants import DEFAULT_CONFIG_PATH

    __location__ = path_dirname(__file__)

    # Prepare temporary config directory
    temp_dir_path = path_join(__location__, "temp")
    temp_config_path = path_join(temp_dir_path, "temp_config.py")
    temp_config_template_path = path_join(
        __location__, "temp", "temp_config_template.py"
    )

    # Prepare temp config file content
    test

# Generated at 2022-06-12 09:46:45.651698
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    loc = Path(__file__).resolve()
    return load_module_from_file_location(loc)

# Generated at 2022-06-12 09:46:56.331474
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import pytest
    from os import environ

    from sanic.exceptions import LoadFileException

    pyfile_path = Path(__file__).resolve().parent / "sanic_config_test.py"

    # It does not contain '/' and '$', so it should import the module as string.
    test_imp = load_module_from_file_location("sanic_config_test")
    assert test_imp == sys.modules["sanic_config_test"]
    assert test_imp.a == 1
    assert test_imp.b == 2

    # It does contain '/'
    test_module = load_module_from_file_location(pyfile_path)
    assert test_module.a == 1
    assert test_module.b == 2

    # It does contain '$', so it should

# Generated at 2022-06-12 09:46:56.946984
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    pass

# Generated at 2022-06-12 09:47:11.744669
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pathlib
    import pytest

    from sanic.config import Config

    # testing function from_file
    from_file_result = Config.from_file("tests/test_configs/config_sanic.py")
    assert isinstance(from_file_result, Config)
    assert from_file_result.test == "test_value_in_config_sanic_py"

    with pytest.raises(IOError):
        Config.from_file("tests/test_configs/config_not_found.py")

    with pytest.raises(ValueError):
        Config.from_file("tests/test_configs/config_sanic_py")

    # testing function load_module_from_file_location

# Generated at 2022-06-12 09:47:20.268888
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # A)
    location_with_env_var = "/some/path/${UNIT_TEST_ENV_VAR}"
    os_environ["UNIT_TEST_ENV_VAR"] = "some_value"

    with pytest.raises(LoadFileException):
        load_module_from_file_location(location_with_env_var)

    assert (
        load_module_from_file_location(location_with_env_var).__file__
        == "/some/path/some_value"
    )

    del os_environ["UNIT_TEST_ENV_VAR"]
    # B)
    length_of_location = len(location_with_env_var)

# Generated at 2022-06-12 09:47:29.297307
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa

    # Test with location as string
    test_module = load_module_from_file_location(
        "tests/modules_for_tests/some_module.py"
    )
    assert test_module
    assert test_module.TEST_VAR_FROM_MODULE_FILE == (
        "some_module.py TEST_VAR_FROM_MODULE_FILE value"
    )

    # Test with location as bytes
    test_module = load_module_from_file_location(
        bytes("tests/modules_for_tests/some_module.py", encoding="utf-8")
    )
    assert test_module

# Generated at 2022-06-12 09:47:34.988781
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D202

    # GIVEN
    # a path to a file
    location = Path(__file__)

    # WHEN
    # it is used for loading the module.
    mod = load_module_from_file_location(location)

    # THEN
    # it contains the same result as the one of
    # importlib.util.module_from_spec.
    assert mod == module_from_spec(spec_from_file_location("mod", str(location)))

# Generated at 2022-06-12 09:47:40.775453
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests all different cases from module docstring."""

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.

    # A1) location doesn't contain environment variables
    location = "/some/path/to/config.py"
    assert not re_findall(r"\${(.+?)}", location)

    # A2) location contains environment variables
    location = "/some/path/${some_env_var}/config.py"
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))
    assert env_vars_in_location

    # B) Check these variables exists in environment.

    # B1) all specified environment variables are defined
    os_environ["some_env_var"] = "test"

# Generated at 2022-06-12 09:47:51.087745
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import os
    import re
    import pytest
    from os import environ as os_environ
    from pathlib import Path

    # Create dir and file.
    tmp_root = Path(__file__).absolute().parent / "tmp"
    tmp_root.mkdir(parents=True, exist_ok=True)
    test_module = tmp_root / "test_module.py"

    with test_module.open("w") as test_module_file:
        test_module_file.write(
            "test_variable = 5\n\n"
            "def some_function():\n\treturn \"test\""
        )

    # Create environment variable
    os_environ["test_env_var"] = str(test_module)

    # Try to import with load_module_from_file

# Generated at 2022-06-12 09:47:59.168815
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test function with location parameter as an environment variable
    selection = random.randint(1, 3)
    os_environ["some_env_var"] = "some_env_var_value"

    if selection == 1:
        # Test with Path type
        os_environ["some_env_var"] = str(Path(os_environ["some_env_var"]))
    elif selection == 2:
        # Test with str type
        os_environ["some_env_var"] = str(os_environ["some_env_var"])
    else:
        # Test with bytes type
        os_environ["some_env_var"] = bytes(
            os_environ["some_env_var"], encoding="utf8"
        )

    # Test with location parameter as an environment variable
    # with some path