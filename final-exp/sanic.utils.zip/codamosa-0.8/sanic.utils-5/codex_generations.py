

# Generated at 2022-06-12 09:38:02.841644
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("y") == True
    assert str_to_bool("true") == True
    assert str_to_bool("t") == True
    assert str_to_bool("1") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("YE") == True
    assert str_to_bool("yEp") == True
    assert str_to_bool("tRUE") == True
    assert str_to_bool("T") == True
    assert str_to_bool("ON") == True

    assert str_to_bool("no") == False
    assert str_to_bool("n") == False
   

# Generated at 2022-06-12 09:38:11.296595
# Unit test for function str_to_bool
def test_str_to_bool():
    # Test positive cases
    # 1) Lower case letters
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("on") is True
    assert str_to_bool("off") is False
    assert str_to_bool("enable") is True
    assert str_to_bool("disable") is False
    assert str_to_bool("true") is True
    assert str_to_bool("false") is False
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False

    # 2) Upper case letters
    assert str_to_bool("Y") is True
    assert str_to_bool("N") is False
    assert str_to_bool("ON") is True

# Generated at 2022-06-12 09:38:13.651043
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert hasattr(load_module_from_file_location("sanic.app"), "Sanic")

# Generated at 2022-06-12 09:38:19.295445
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("on") == True
    assert str_to_bool("1") == True
    assert str_to_bool("no") == False
    assert str_to_bool("off") == False
    assert str_to_bool("0") == False
    try:
        str_to_bool("something")
        assert False  # this should never be reached
    except ValueError:
        assert True


# Generated at 2022-06-12 09:38:24.696659
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Check correct work with file path
    some_module = load_module_from_file_location(
        # location:
        "test_load_module_from_file_location_test_module",
        # importlib.util.spec_from_file_location location parameter
        "tests/test_load_module_from_file_location_test_module.py",
    )

    assert some_module.__name__ == "test_load_module_from_file_location_test_module"
    assert some_module.secret == "*****"

    # Check correct work with environment variables

# Generated at 2022-06-12 09:38:34.478627
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test function load_module_from_file_location."""
    # A) testing loading of some python module
    #    in case when file path contains environment variable
    os_environ["TEST_ENV_VAR_CONFIG_FILE_A"] = "tests/words"
    os_environ["TEST_ENV_VAR_CONFIG_FILE_B"] = "words"
    config_file_A = load_module_from_file_location(
        "/${TEST_ENV_VAR_CONFIG_FILE_A}/words.py"
    )
    assert config_file_A.__file__.endswith(
        "tests/words/words.py"
    ), "error loading config file"

# Generated at 2022-06-12 09:38:43.611523
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    import os

    with TemporaryDirectory() as temp_dir:
        os.environ["file_path"] = os.path.join(temp_dir, "config.yaml")
        config = "some_config"
        with open(os.environ["file_path"], "w") as config_file:
            config_file.write(config)
        assert load_module_from_file_location(
            "${file_path}", "yaml"
        ) == config
        assert load_module_from_file_location(
            os.environ["file_path"], "yaml"
        ) == config

# Generated at 2022-06-12 09:38:47.130294
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    os.environ["some_env_var"] = "some_val"
    assert hasattr(
        load_module_from_file_location(
            "SomeModule", "/some/path/${some_env_var}/some.py"
        ),
        "SomeModule",
    )

# Generated at 2022-06-12 09:38:52.980308
# Unit test for function str_to_bool
def test_str_to_bool():
    """Testing str_to_bool function"""
    assert str_to_bool("True")
    assert str_to_bool("t")
    assert str_to_bool("y")
    assert not str_to_bool("False")
    assert not str_to_bool("f")
    assert not str_to_bool("n")
    with pytest.raises(ValueError):
        str_to_bool("invalid value")

# Generated at 2022-06-12 09:38:58.719011
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1")
    assert str_to_bool("yes")
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert str_to_bool("true")
    assert str_to_bool("true")
    assert not str_to_bool("FALSE")
    assert not str_to_bool("off")
    assert not str_to_bool("0")

# Generated at 2022-06-12 09:39:04.700308
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile


# Generated at 2022-06-12 09:39:13.346730
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_module = load_module_from_file_location(
        Path(__file__).parents[0] / "tests" / "data" / "config.py"
    )
    assert test_module.name == "config"
    assert test_module.foo == "bar"
    assert test_module.bar == "foo"
    assert test_module.baz == 666
    assert test_module.LIST == ["first_el", "second_el", "third_el"]
    assert test_module.DICT == {"a": "b", "c": "d"}

    with os_environ.copy():
        os_environ["TEST_VAR_1"] = "abcd"
        os_environ["TEST_VAR_2"] = "efgh"

        test_module = load_module_from_

# Generated at 2022-06-12 09:39:22.337704
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Use default import_string if location is not a path
    some_module = load_module_from_file_location("some_module_name")
    assert some_module.__name__ == "some_module_name"

    # Try to import file with an absolute path
    location = "/some/path/sub-path/"
    os.environ["A"] = ""
    os.environ["B"] = location

    name = "some_file.py"
    _mod_spec = spec_from_file_location(
        name, os.path.join(location, name), *args, **kwargs
    )
    module = module_from_spec(_mod_spec)
    _mod_spec.loader.exec_module(module)  # type: ignore

    # Try to import file with an absolute path,
    # where file

# Generated at 2022-06-12 09:39:29.175041
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic.server import HttpProtocol
    from sanic.config import Config
    from sanic.exceptions import LoadFileException

    os_environ["SOME_ENV_VAR"] = "some_env_var"

    location_str = __file__
    location_bytes = location_str.encode()
    location_path = Path(location_str)

    assert load_module_from_file_location(location_str) is Config
    assert load_module_from_file_location(location_bytes) is Config
    assert load_module_from_file_location(location_path) is Config

    assert (
        load_module_from_file_location(
            location_str, "asyncio.protocols", "HttpProtocol"
        )
        is HttpProtocol
    )

# Generated at 2022-06-12 09:39:38.670474
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from contextlib import contextmanager
    from importlib import reload
    from os import remove, environ
    from pathlib import Path
    from tempfile import NamedTemporaryFile

    from sanic import Sanic
    from sanic.exceptions import LoadFileException, PyFileError

    from sanic_test.test_case import TestCase

    # 1. Test case: Location is of a string type.
    #    Assert that str_to_bool was initially not loaded.
    with app_module_not_imported("str_to_bool"):
        # 1a. Test case: Some Python file is provided.
        python_file_location = this_file_path.parent / f"str_to_bool.py"

        #   1a1. Test case: Module is loaded
        some_module = load_module_from

# Generated at 2022-06-12 09:39:47.236358
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import random
    import string

    temp_dir = tempfile.mkdtemp()

    # We need to create module in temporary path, because we do not know, what
    # modules are installed in the enviroment, where we will run tests.
    # So to be sure, that we will create module that no one will use,
    # we will generate random module name.
    random_module_name = "".join(random.choices(string.ascii_letters, k=10))
    random_env_var_name = "".join(random.choices(string.ascii_letters, k=10))

    # Let's create test file in this temporary path, and let's pass to
    # module_from_file_location function path to this file.
    random_

# Generated at 2022-06-12 09:39:56.402526
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("json").__name__ == "json"
    assert load_module_from_file_location(Path("json")).__name__ == "json"
    assert load_module_from_file_location(b"json").__name__ == "json"
    assert load_module_from_file_location(Path(__file__).parent).__name__ == "sanic"
    assert load_module_from_file_location(__file__).__name__ == "sanic.helpers"
    module = load_module_from_file_location(
        Path(__file__).parent / "config.example.py"
    )
    assert getattr(module, "auth_enabled") == False



# Generated at 2022-06-12 09:40:03.666965
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    def compare_module_with_file_content(module, file_content):
        assert module.__name__ == "config"
        assert module.__file__ == os.path.abspath(module.__file__)
        assert file_content == module.some_a

    file_content = "some_a"

    # Testing with file path as string.
    with tempfile.NamedTemporaryFile(mode="w") as temp:
        temp.write(file_content)
        temp.seek(0)
        module = load_module_from_file_location(temp.name)
        compare_module_with_file_content(module, file_content)

    # Testing with file path as bytes.

# Generated at 2022-06-12 09:40:12.126710
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil

    def create_python_file(name, content):
        with open(name + ".py", "w") as file:
            file.write(content)

    def create_ini_file(name, content):
        with open(name + ".ini", "w") as file:
            file.write(content)

    with tempfile.TemporaryDirectory() as tmp:
        create_python_file(tmp + "/my_python_file", "")
        create_python_file(tmp + "/my_python_file_with_dot", "")
        create_ini_file(tmp + "/my_ini_file", "")
        os.environ["test_env_var"] = "test_env_var"


# Generated at 2022-06-12 09:40:17.757290
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_env_var = "TEST_ENV_VAR"
    test_env_value = "test_env_value"
    os_environ[test_env_var] = test_env_value

    import tempfile
    import os

    name = "load_module_from_file_location_unittest"
    temp_path = tempfile.NamedTemporaryFile().name
    temp_name = temp_path + "/" + name + ".py"
    base_name = os.path.basename(temp_name)
    temp_dir = os.path.dirname(temp_name)

    filename = os.path.join(temp_dir, name)
    temp_file = filename + ".py"


# Generated at 2022-06-12 09:40:28.779788
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from importlib.util import module_from_spec, spec_from_file_location
    from os import getcwd, path, environ

    import_location = "tests/config/config.py"
    module_name = "config"

    _mod_spec = spec_from_file_location(
        module_name, import_location, submodule_search_locations=None,
    )
    module = module_from_spec(_mod_spec)
    _mod_spec.loader.exec_module(module)  # type: ignore
    correct_module = module

    loaded_module = load_module_from_file_location(import_location)

    assert correct_module == loaded_module

    environ["SANIC_TEST_ENV_VAR"] = getcwd()


# Generated at 2022-06-12 09:40:34.880604
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile(mode="w", delete=True) as config_file:
        config_file.write("hello = 'world'")
        config_file.flush()
        module = load_module_from_file_location(
            config_file.name
        )

    assert module.hello == "world"

    with NamedTemporaryFile(mode="w", delete=True) as config_file:
        config_file.write("hello = 'world'")
        config_file.flush()
        module = load_module_from_file_location(
            config_file.name, encoding="utf16"
        )

    assert module.hello == "world"


# Generated at 2022-06-12 09:40:41.533181
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location('./test_utils.py')
    assert module.__file__.endswith('test_utils.py')
    assert module.__name__ == 'test_utils'
    assert module.test_var == 'TEST'
    module = load_module_from_file_location('./test_config.py')
    assert module.__file__.endswith('test_config.py')
    assert module.__name__ == 'test_config'

    os_environ["TEST_ENV_VAR"] = "test"
    module = load_module_from_file_location('${TEST_ENV_VAR}')
    assert module.__file__.endswith('test_utils.py')

# Generated at 2022-06-12 09:40:51.772869
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ
    from os.path import join

    with TemporaryDirectory() as tempdir_name:

        file_name_1 = "some_file_name_1.py"
        file_name_2 = "some_file_name_2.py"

        with open(join(tempdir_name, file_name_1), "w") as f:
            f.write("var_1 = 1\n")

        with open(join(tempdir_name, file_name_2), "w") as f:
            f.write("var_2 = 2\n")

        environ["tempdir_name"] = tempdir_name

        # Check that module can be loaded from just module name.

# Generated at 2022-06-12 09:41:01.736557
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import subprocess
    import tempfile

    for location in [
        "sanic.py",
        "tests/pytest_sanic_config.py",
        Path("tests/pytest_sanic_config.py"),
    ]:
        module_name = "test_module_name"
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_file = Path(tmp_dir) / "sanic.py"
            tmp_file.write_text(f"{module_name} = '{location}'")
            subprocess.check_call(["python", "-m", "py_compile", tmp_file])
            loaded_module = load_module_from_file_location(location)
            assert getattr(loaded_module, module_name) == location
            loaded_module = load_module_from

# Generated at 2022-06-12 09:41:07.462589
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""

    test_file_path = Path(__file__).parent / "config_file.py"

    try:
        module = load_module_from_file_location(test_file_path)
        assert module.__name__ == "config_file"
        assert module.SOME_VAR == 100
    except:
        raise AssertionError("Function load_module_from_file_location fails.")

    # Test str_to_bool function

# Generated at 2022-06-12 09:41:15.717776
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """ Unit test for function load_module_from_file_location """
    location = "./sanic/config/test_config.py"
    loaded_module = load_module_from_file_location(location)
    module_from_import_string = import_string(location)
    assert loaded_module is module_from_import_string

    location = "tests.config.test_config"
    loaded_module = load_module_from_file_location(location)
    module_from_import_string = import_string(location)
    assert loaded_module is module_from_import_string

    # Pathlib example.
    location = Path("tests") / "config" / "test_config.py"
    loaded_module = load_module_from_file_location(location)
    module_from_import_string = import_

# Generated at 2022-06-12 09:41:23.848777
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Dummy functions to test
    def my_func(my_arg):
        return my_arg ** 2

    def my_other_func(my_arg):
        return my_arg ** 3

    # Dummy module to test
    my_module_str = """
    def my_func(my_arg):
        return my_arg ** 2

    def my_other_func(my_arg):
        return my_arg ** 3

    var = 42
    some_tuple = ("a", "b", "c")
    some_dict = {1: 2, 3: 4}
    """
    my_module_file = "my_module.py"

    # Dummy config file to test

# Generated at 2022-06-12 09:41:29.969900
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        import shutil
        import sys

        # Create temporary module.
        # For example it will be called
        # "/tmp/tmp_some_module.py"
        tmp_module_path = "tmp_some_module.py"
        tmp_module_path = shutil.copy(
            "tests/test_app/test_config.py",
            os.path.join(tmpdir, tmp_module_path),
        )

        # Add temporary module to sys.path.
        sys.path.append(tmpdir)

        # Try to import it.
        tmp_module = load_module_from_file_location(tmp_module_path)

        # Confirm that it was imported.
        assert tmp_module.test_config

# Generated at 2022-06-12 09:41:40.030785
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pytest import fixture

    from sanic import Sanic

    app = Sanic("test_app")

    # We do not check for actual config values,
    # because we can not know what it contains.
    # We have to check if imported module has
    # the same values as original config.
    @fixture(scope="module")
    def import_config() -> None:
        class ImportConfig:
            def __init__(self) -> None:
                config = Path(__file__).parent / "config.py"
                self.module = load_module_from_file_location(config)
                self.config = self.module.config

        self.import_config = ImportConfig()

    # FIXME: This test fails with python 3.6 on linux.
    #        But it works with python 3.7.
    #       

# Generated at 2022-06-12 09:41:51.809541
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    try:
        # Create configuration file.
        config = tempfile.NamedTemporaryFile(mode="w+t", delete=False)
        config.write(
            "from sanic import Sanic\n"
            "app = Sanic()\n"
            "app.config.DB_NAME = 'sqlite3'\n"
        )
        config.close()

        # Main test for load_module_from_file_location function.
        module = load_module_from_file_location(config.name)
        assert "app" in module.__dict__
        assert isinstance(module.app, Sanic)
        assert module.app.config.DB_NAME == "sqlite3"
    finally:
        os.unlink(config.name)

# Generated at 2022-06-12 09:42:00.365009
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # CASE A.1:
    # Path with one environment variable.
    env_var = "var_A"
    env_var_val = "val_A"
    os_environ[env_var] = env_var_val
    location = f"/some/path/${{{env_var}}}"
    assert (
        load_module_from_file_location(location).__file__
        == f"/some/path/{env_var_val}"
    )

    # CASE A.2:
    # Path with more than one environment variables.
    env_var = "var_B"
    env_var_val = "val_B"
    os_environ[env_var] = env_var_val

# Generated at 2022-06-12 09:42:10.666245
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit tests for load_module_from_file_location function."""
    value_error_msg = "Invalid truth value"
    module_name = "my_module"
    module_path_str = Path("my_module.py")
    module_path_bytes = Path("my_module.py").as_posix()
    module_path_env = Path("my_module.py") / f"${os_environ['TEST_FILE_ENV']}"
    module_path_env_bytes = f"${os_environ['TEST_FILE_ENV']}/my_module.py"
    module_path_env_not_set = Path("my_module.py") / "${NOT_EXISTING_PATH}"

# Generated at 2022-06-12 09:42:19.269883
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # A) Check if it is possible to load module from path which
    #    does not contain environment variables.
    file_name = "test_module.py"
    with tempfile.TemporaryDirectory() as temp_dir:
        file_path = Path(temp_dir) / file_name
        with file_path.open("w") as test_file:
            test_file.write("var_1 = 'test var_1'\n")  # noqa
            test_file.write("var_2 = 123\n")  # noqa
            test_file.write("var_3 = True\n")  # noqa

        module = load_module_from_file_location(file_path, "utf8")

        assert module.var_1 == "test var_1"
        assert module.var_

# Generated at 2022-06-12 09:42:29.843705
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    mod = load_module_from_file_location("sys")
    assert mod is sys

    with tempfile.TemporaryDirectory() as tempdir:
        path = Path(tempdir)

        file_to_test = (
            "test_string = 'test'\n"
            "test_integer = 1\n"
            "test_list = [1, 2, 3]\n"
            "test_bool = True"
        )

        test_file = path / "test_file.py"
        with open(test_file, "w") as f:
            f.write(file_to_test)

        os_environ["TEST_DICT_FILE"] = str(test_file)

        mod = load_module_from_file_location(path)
        assert mod.test_string

# Generated at 2022-06-12 09:42:34.665151
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """This function supposed to be used as a unit test for
    function 'load_module_from_file_location'.
    It tests if it is possible to use this function to load module
    from file correctly."""

    import tempfile
    import os

    tmpdirname = tempfile.mkdtemp()
    # We have to write the file in a directory that exists, so we'll use
    # the temporary directory to write it to.
    temp_module_file_path = os.path.join(tmpdirname, "temp_module.py")
    with open(temp_module_file_path, "w") as temp_module_file:
        temp_module_file.write(
            """
some_var = 'some_value'
some_function = lambda *args: args
    """
        )

    temp_module = load_module

# Generated at 2022-06-12 09:42:42.651582
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # create dummy conf file
    conf_file = """
import os

DEBUG = True
PORT = int(os.getenv("TEST_ENV_VAR", "8000"))
    """
    conf_file_location = "./load_module_from_file_location_test.py"

    with open(conf_file_location, "w") as f:
        f.write(conf_file)

    # load module from file location
    mod = load_module_from_file_location(conf_file_location)
    assert mod.DEBUG == True
    assert mod.PORT == 8000

    # load module from file location and substitute env var
    os_environ["TEST_ENV_VAR"] = "8001"
    mod = load_module_from_file_location(conf_file_location)

# Generated at 2022-06-12 09:42:49.659895
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ

    # A) Test does it works with Path type of parameters
    tmp_dir = TemporaryDirectory(prefix="sanic_config_")
    test_file_path = Path(tmp_dir.name) / "test_config.py"

    test_file_path.touch()

    loaded_module = load_module_from_file_location(test_file_path)
    assert loaded_module.__file__ == str(test_file_path)

    tmp_dir.cleanup()

    # B) Test does it works with bytes type of parameters
    tmp_dir = TemporaryDirectory(prefix="sanic_config_")
    test_file_path = Path(tmp_dir.name) / "test_config.py"

    test_file_path.touch()

# Generated at 2022-06-12 09:42:57.920585
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 09:43:06.107188
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["some_env_var"] = "some/path"
    module = load_module_from_file_location(
        "sanic.utils.py_file_loader", "/${some_env_var}/utils.py"
    )
    assert module.__name__ == "utils"
    os_environ.pop("some_env_var")
    if "some_env_var" in os_environ:
        raise Exception("some_env_var is not deleted")

    # if you try to load_module_from_file_location with not existing file

# Generated at 2022-06-12 09:43:16.083513
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os.path import abspath

    module = load_module_from_file_location(
        "sanic.exceptions",
        abspath(__file__).replace("__init__.py", "exceptions.py"),
    )
    assert LoadFileException.__module__ == module.__name__



# Generated at 2022-06-12 09:43:24.004073
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # We do not need external IO to test that function
    # so we will mock it out.
    class MockModule:
        __file__ = str

    module_from_spec_original = importlib.util.module_from_spec
    importlib.util.module_from_spec = lambda module_spec: MockModule()

    spec_from_file_location_original = importlib.util.spec_from_file_location
    importlib.util.spec_from_file_location = lambda *args, **kwargs: MockModule

    # 1) Test case when location is of a Path type.
    location = Path("/some/path")
    returned = load_module_from_file_location(location)
    assert isinstance(returned, types.ModuleType)
    assert returned.__file__ == str(location)

    # 2)

# Generated at 2022-06-12 09:43:30.214557
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from sanic.log import logger
    from sanic.config import LOGGING
    from unittest.mock import patch
    from tempfile import mktemp

    from importlib import reload

    from .test_config import create_test_dict_config

    TEMP_FILE = mktemp(suffix=".py")
    environ["TEST_TEMP_ENV_VAR"] = TEMP_FILE

    CONFIG_DICT = create_test_dict_config()

    with open(TEMP_FILE, "w") as f:
        f.write("CONFIG = ")
        f.write(str(CONFIG_DICT))

    # Reload LOGGING config
    LOGGING = reload(LOGGING)
    logger.configure(LOGGING["LOGGING"])

   

# Generated at 2022-06-12 09:43:38.948519
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pylint: disable=unused-variable
    """Unit test for function load_module_from_file_location."""
    # Test the case when file is not found.
    with pytest.raises(IOError):
        load_module_from_file_location("not_existing_file.py")

    # Test the case when file exists.
    import tempfile
    import os

    temp_dir = tempfile.mkdtemp()
    filename = "temp_file.py"
    file_path = os.path.join(temp_dir, filename)

    with open(file_path, "w") as temp_file:
        temp_file.write("some_config = 'some val'")

    loaded_module = load_module_from_file_location(file_path)

# Generated at 2022-06-12 09:43:48.627115
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location method.
    """
    import tempfile

    # Test 1.
    # Test if it loads file provided as Path instance.
    with tempfile.NamedTemporaryFile(suffix=".py") as conf_file:
        conf_file.write(b"var = '42'")
        conf_file.flush()

        module = load_module_from_file_location(Path(conf_file.name))
        assert module.var == "42"

    # Test 2.
    # Test if environment variables in format ${some_envar} are being resolved.
    with tempfile.NamedTemporaryFile(suffix=".py") as conf_file:
        some_var = "123"
        os_environ["some_var"] = some_var
        conf_file

# Generated at 2022-06-12 09:43:57.886836
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import pytest

    def import_dynamic_module_from_string(location: str):
        """ Imports a module from a string location """
        return load_module_from_file_location(location)

    def import_dynamic_module_from_path(location: str):
        """ Imports a module from a string location """
        return load_module_from_file_location(Path(location))

    def import_dynamic_module_from_bytes(location: bytes):
        """ Imports a module from a bytes location """
        return load_module_from_file_location(location)

    ###############################################################
    # Test case:
    # - location is of a string type
    ###############################################################
    # Test case:
    # - location is of a bytes type
    ###############################################################

   

# Generated at 2022-06-12 09:44:07.344033
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    location = "./tests/test_path_${PYTHONPATH}"
    os_environ["PYTHONPATH"] = "."
    module = load_module_from_file_location(location)
    assert hasattr(module, "test_var")
    assert getattr(module, "test_var") == "test_value"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.

# Generated at 2022-06-12 09:44:16.903185
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    os.environ["TEST_ENV_VAR_1"] = "test env var 1"
    os.environ["TEST_ENV_VAR_2"] = "test env var 2"


# Generated at 2022-06-12 09:44:27.529347
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def test_create_dummy_module(location):
        with open(location, "w") as f:
            f.write("DUMMY_MODULE = 'dummy_module'")
        return

    dummy_module_location = "/tmp/test_dummy_module.py"
    # It could be a file path
    test_create_dummy_module(dummy_module_location)
    assert (
        load_module_from_file_location(dummy_module_location).DUMMY_MODULE
        == "dummy_module"
    )
    os.remove(dummy_module_location)

    # It could also be a string of a file path
    test_create_dummy_module(dummy_module_location)

# Generated at 2022-06-12 09:44:36.599890
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from os import environ as os_environ
    from os import mkdir
    from os import remove as os_remove
    from os import sep
    from os import unlink
    from shutil import rmtree
    from tempfile import mkdtemp

    from pathlib import Path

    import pytest

    # -----------------------------
    # Tests for enviroment substitutions.
    # -----------------------------

    # There should be no errors
    # when there is no environment variables in location.
    load_module_from_file_location("/some/path/config.py")
    # -----------------------------

    # There should be an error
    # when environment variable is not defined.

# Generated at 2022-06-12 09:44:50.321249
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test if it returns loaded module from file
    import tempfile, importlib

    temp_config_file = tempfile.NamedTemporaryFile(suffix=".py")
    temp_config_file.write(b"some_value = 5")
    temp_config_file.seek(0)

    some_module = load_module_from_file_location(
        "/some/path/some_module_name_file.py"
    )
    assert "some_module_name_file.py" in str(
        some_module
    )  # it should be some_module_name_file.py in module location

    some_module = load_module_from_file_location(
        "/some/path/${some_env_var}/some_module_name_file.py"
    )
    assert os_en

# Generated at 2022-06-12 09:44:59.209633
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
        For each file in /test_configs/ we create environment variable
        TEST_CONFIGS_${filename}_ENV_VAR and assign it a value from the file.
        Then we replace any occurences of ${filename} and ${filename}_ENV_VAR
        in the file's text with the value of the environment variable.
        Finally we compare it to the file's output.
    """
    expected_output_test_configs_dir_path = Path(__file__).parent / "test_configs"

# Generated at 2022-06-12 09:45:05.704120
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if ${some_env_var}
    #    is defined and substituted with it's value

    with mock.patch.dict(
        os_environ,
        {
            "SOME_ENV_VAR": "some_env_var_value",
            "SOME_ENV_VAR2": "some_env_var_value2",
        },
        clear=True,
    ):
        module = load_module_from_file_location(
            "some_module_name",
            "/some/path/${some_env_var}/some/other_path/${some_env_var2}",
        )
        module_file = module.__file__

# Generated at 2022-06-12 09:45:14.979538
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        some_module = load_module_from_file_location("some_module_name")
        assert False  # it should not reach this line
    except IOError:
        assert True

    try:
        os_environ["some_env_var"] = "some_str"
        some_module = load_module_from_file_location(
            "/some/path/${some_env_var}", "/some/path/some_str"
        )
        assert True
    except IOError:
        assert False

    try:
        some_module = (
            load_module_from_file_location(
                b"/some/path/${some_env_var}".decode("utf8")
            )
            == some_module
        )
        assert True
    except IOError:
        assert False

# Generated at 2022-06-12 09:45:18.566249
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = 'test/test_module.py'
    mod = load_module_from_file_location(location)
    assert mod.__name__ == 'test_module'
    assert mod.TEST_MODULE_VAR == 10
    assert mod.test_module_function() == 20

# Generated at 2022-06-12 09:45:27.967218
# Unit test for function load_module_from_file_location

# Generated at 2022-06-12 09:45:34.735731
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test if load_module_from_file_location function works as expected."""
    import sys
    import os

    # 1. Standard import works the same way.
    assert sys.modules.get("tempfile") is None
    tempfile_module = load_module_from_file_location("tempfile")
    assert sys.modules.get("tempfile") is tempfile_module
    if "tempfile" in sys.modules:
        del sys.modules["tempfile"]

    # 2. Path to .py file works the same way.
    assert "helper_module_for_testing" not in sys.modules
    helper_module = load_module_from_file_location(
        "tests/helper_module_for_testing.py"
    )

# Generated at 2022-06-12 09:45:43.990036
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Basic function test
    assert load_module_from_file_location(
        "asyncio.base_events.py"
    ).__name__ == "asyncio.base_events"

    # .env file test
    with tempfile.TemporaryDirectory() as temp_dir:
        env_file = Path(temp_dir) / "test_env"
        with env_file.open("w") as f:
            f.write(
                "DB_HOST = localhost\n"
                "DB_PORT = 3306\n"
                "DB_NAME = ryabina\n"
            )

        env = load_module_from_file_location(env_file)

    assert env.DB_HOST == "localhost"
    assert env.DB_PORT == 3306
    assert env.DB_NAME

# Generated at 2022-06-12 09:45:49.183270
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sanic.config as config

    load_module_from_file_location(__file__)
    load_module_from_file_location(Path(__file__))

    assert (
        config.str_to_bool("no") == False
    )  # Type annotation used to avoid linting error on next line
    assert config.str_to_bool("no") == str_to_bool("no")

# Generated at 2022-06-12 09:45:51.869121
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import time
    import os

    # Create a temporary file and write to it:

# Generated at 2022-06-12 09:46:04.477564
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # A) Config file without environment variable.
    module = load_module_from_file_location(
        "tests.test_config_file_without_env_var"
    )
    assert module.HELLO_WORLD == "Hello World!"

    # B) Config file with environment variable.
    module = load_module_from_file_location(
        "tests.test_config_file_with_env_var"
    )
    assert module.HELLO_WORLD == "Hello World!"

    # C) Config file with not existent environment variable.
    with pytest.raises(LoadFileException) as e:
        module = load_module_from_file_location(
            "tests.test_config_file_with_not_existent_env_var"
        )

# Generated at 2022-06-12 09:46:13.221555
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_ENV_VAR"] = "test_var"

    # Testing bytes location
    b_location = b"/some/path/${TEST_ENV_VAR}"
    assert (
        b_location.decode(encoding="utf8")
        == "/some/path/${TEST_ENV_VAR}"
    )  # just to be sure

    module = load_module_from_file_location(b_location, encoding="utf8")
    assert hasattr(module, "TEST_ENV_VAR")
    assert module.TEST_ENV_VAR == "test_var"

    # Testing str location
    str_location = "/some/path/${TEST_ENV_VAR}"

# Generated at 2022-06-12 09:46:22.435131
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import logging

    import pytest
    from sanic.app import Sanic

    from os import environ as os_environ
    from sanic.helpers import load_module_from_file_location

    app_module = load_module_from_file_location("tests.unit.helpers.app")
    assert app_module.app_config == {
        "SOMETHING": "something",
        "SOMETHING_ELSE": "something_else",
        "SOMETHING_NON_STR": 123,
    }
    assert app_module.app.name == "tests.unit.helpers.app"
    assert isinstance(app_module.app, Sanic)

    # Check if environment variables are resolved

# Generated at 2022-06-12 09:46:29.659876
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables in format ${some_env_var}.
    module = load_module_from_file_location(
        "test_location", "/some/path/${test_env_var}"
    )
    assert module.__file__ == "/some/path/${test_env_var}"
    # B) Check these variables exists in environment.
    try:
        load_module_from_file_location(
            "test_location", "/some/path/${not_existing_env_var}"
        )
    except LoadFileException as e:
        assert "The following environment variables are not set: not_existing_env_var" in e.__str__()
    # C) Substitute them in location.

# Generated at 2022-06-12 09:46:39.106081
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    # 1) Test for exising environment variable in location.
    #    Check that this environment variable is actually set.
    #    Check that location parameter resolved to full path.
    #    Check that module is loaded.
    some_env_var = "PWD"
    if not os.environ.get(some_env_var):
        os.environ[some_env_var] = "."

    location = f"${some_env_var}/tests/test_utils.py"

    module = load_module_from_file_location(location)
    assert module is not None
    assert module.__file__ == os.path.abspath(location)

    # 2) Test for non existing environment variable in location.
    #    Check that exception is raised.

# Generated at 2022-06-12 09:46:48.202798
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from sanic.config import read_config

    with TemporaryDirectory() as tmpdirname:

        # Create test config file
        target_file_name = Path(tmpdirname) / "test_config.py"
        config_content = (
            "# The configuration file for 'Django' app",
            "# https://github.com/huge-success/sanic",
            "example_config = {'MY_VAR': 1}",
        )
        with open(target_file_name, "w") as target_file:
            target_file.write("\n".join(config_content))

        # set environment variable
        os.environ["MY_ENV"] = str(target_file_name)

        # Do the actual test

# Generated at 2022-06-12 09:46:58.363665
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    with open(Path(__file__).parent / "config.py", mode="r") as config_file:
        expected_string_config = config_file.read()

    test_config_file_path_without_extension = (
        Path(__file__).parent / "config"
    )

    test_config_file_path_with_extension = (
        Path(__file__).parent / "config.py"
    )

    # check if .py file location is accepted
    assert load_module_from_file_location(
        test_config_file_path_with_extension
    )

    # check if without .py file location is accepted
    assert load_module_from_file_location(
        test_config_file_path_without_extension
    )

    # check if environment variables substitution works properly

# Generated at 2022-06-12 09:47:07.651994
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from .testing import set_env
    from .testing import unset_env

    # 1. A) Python module
    assert load_module_from_file_location("sanic")

    # 1. B) Invalid python module
    try:
        load_module_from_file_location(__name__ + "abc")
    except ImportError:
        pass

    # 2. A) Environment variables in location
    set_env("SANIC_TEST_ENV_VAR", "TEST")

    path = Path(__file__)
    sanic_test_env_var = path.parent.parent.parent.parent / "TEST"

# Generated at 2022-06-12 09:47:17.959464
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(
        "/dir/dir/dir/dir/dir/file.py"
    ).file_var == "file_var_value"
    assert load_module_from_file_location(
        "/dir/dir/dir/dir/dir/dir/file"
    ).file_var == "file_var_value"
    assert load_module_from_file_location(
        "/dir/dir/dir/dir/dir/dir/other.file"
    ).file_var == "file_var_value"
    assert load_module_from_file_location(
        "/dir/dir/dir/dir/file.py",
        "/dir/dir/dir/dir/other.file",
    ).file_var == "other_file_var_value"
    assert load_module_

# Generated at 2022-06-12 09:47:22.956086
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import sys

    from sanic.helpers import load_module_from_file_location

    class TestModule:
        pass

    sys.modules["test"] = TestModule

    assert id(load_module_from_file_location("test")) == id(TestModule)

    try:
        load_module_from_file_location("os")
        raise AssertionError("Loaded module with name of built-in package")
    except ImportError:
        pass

    try:
        load_module_from_file_location("test.test")
        raise AssertionError(
            "Loaded module with name longer than one period ('.')"
        )
    except ImportError:
        pass


# Generated at 2022-06-12 09:47:37.616993
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Location parameter is of a bytes type
    #    and does not contain any environment variables.
    location = b"some_module_name"
    expected = import_string(location.decode("utf8"))
    assert expected == load_module_from_file_location(location)

    # B) Location parameter is of a str type
    #    and does not contain any environment variables.
    location = "some_module_name"
    expected = import_string(location)
    assert expected == load_module_from_file_location(location)

    # C) Location parameter is of a bytes type
    #    and does contain some environment variables.
    location = b"/some/path/${HOME}/${USER}/some_module_name"

# Generated at 2022-06-12 09:47:47.533716
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sanic.config as test_config

    test_config_path = (
        Path(__file__) / ".." / ".." / "tests" / "test_data" / "config"
    ).resolve()

    test_config_path_without_extension = test_config_path.as_posix()

    test_config_path_with_extension = test_config_path_without_extension + ".py"

    loaded_config = load_module_from_file_location(
        test_config_path_with_extension
    )
    assert loaded_config.TEST == True

    loaded_config = load_module_from_file_location(test_config)
    assert loaded_config.TEST == True

    os_environ["TEST_ENV"] = "test_env"



# Generated at 2022-06-12 09:47:56.315923
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Bad as location parameter - not bytes, string nor Path
    with pytest.raises(TypeError):
        load_module_from_file_location(123)

    # Bad as encoding parameter
    with pytest.raises(TypeError):
        load_module_from_file_location("some_location", 123)

    # Bad as location parameter - not importable
    with pytest.raises(ImportError):
        load_module_from_file_location("some_path/some_file.py")

    # Good as location parameter - importable
    assert (
        load_module_from_file_location(__file__)
        == load_module_from_file_location(Path(__file__))
    )

    # Good as location parameter - importable