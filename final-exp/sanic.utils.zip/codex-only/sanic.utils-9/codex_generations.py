

# Generated at 2022-06-24 04:35:12.254789
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    def _is_loaded_module(obj):
        return isinstance(obj, types.ModuleType)

    # Test 0: check that it raises error if provided module can't be loaded
    with pytest.raises(LoadFileException):
        load_module_from_file_location("module_that_does_not_exist")

    # Test 1: check it can load modules provided as a file path
    # Test 1.A: module provided as a string
    config_module = load_module_from_file_location(
        Path(__file__).parent / "configs/config.py"
    )
    assert _is_loaded_module(config_module)

    # Test 1.B: module provided as a bytes

# Generated at 2022-06-24 04:35:22.365660
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Testing helper function load_module_from_file_location."""

    # A. Test that it handles wrong location paths.

    # A1.A) Test that it raises LoadFileException if location
    #      contains environment variables that are not defined.
    not_defined_env_vars = {"TEST_ENV_VAR", "TEST_ENV_VAR_2"}
    for not_defined_env_var in not_defined_env_vars:
        os_environ[not_defined_env_var] = ""

# Generated at 2022-06-24 04:35:30.583814
# Unit test for function str_to_bool
def test_str_to_bool():
    def test_str_to_bool_helper(val, bool_val):
        assert str_to_bool(val) == bool_val

    test_str_to_bool_helper("y", True)
    test_str_to_bool_helper("YeP", True)
    test_str_to_bool_helper("YUP", True)
    test_str_to_bool_helper("t", True)
    test_str_to_bool_helper("TRUE", True)
    test_str_to_bool_helper("ON", True)
    test_str_to_bool_helper("ENABLE", True)
    test_str_to_bool_helper("ENABLED", True)
    test_str_to_bool_helper("1", True)
    test_str_

# Generated at 2022-06-24 04:35:36.817137
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("On") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False

# Generated at 2022-06-24 04:35:46.896186
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from .config import *  # noqa
    from .config import (  # noqa
        _app_config,
        _app_config_default,
        _app_config_env,
    )

    def case_environment_variable(env_var, value):
        os_environ[env_var] = value
        _config_path = "./tests/configs/config.py"
        _config_path_env = (
            "./tests/${TEST_ENV_VAR}/configs/${TEST_ENV_VAR_2}.py"
        )

        assert load_module_from_file_location(
            _config_path
        ).TEST_CONFIG_VALUE == _app_config.TEST_CONFIG_VALUE
        assert load_module_from_file_

# Generated at 2022-06-24 04:35:52.555848
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("yEs") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("Enable") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("y") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("T") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("1") == True

    assert str_to_bool("no") == False
    assert str_to_bool("nO") == False


# Generated at 2022-06-24 04:36:03.691251
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("t")
    assert str_to_bool("on")
    assert str_to_bool("yes")
    assert str_to_bool("yup")
    assert str_to_bool("yep")
    assert str_to_bool("y")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("false")
    assert not str_to_bool("False")
    assert not str_to_bool("off")
    assert not str_to_bool("no")
    assert not str_to_bool("n")
    assert not str_to_bool("disable")
    assert not str

# Generated at 2022-06-24 04:36:07.022487
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("On") is True
    assert str_to_bool("1") is True
    assert str_to_bool("YeS") is True
    assert str_to_bool("OfF") is False
    assert str_to_bool("No") is False
    assert str_to_bool("TrUE") is True
    assert str_to_bool("NoPE") is False



# Generated at 2022-06-24 04:36:16.697329
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("false") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("T") == True
    assert str_to_bool("F") == False
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("Y") == True
    assert str_to_bool("N") == False
    assert str_to_bool("enabled") == True
    assert str_to_bool("disabled") == False
    assert str_to_bool("on") == True
    assert str_to_bool("off") == False
    assert str_to_bool("yes") == True
    assert str_

# Generated at 2022-06-24 04:36:24.398900
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests load_module_from_file_location function."""
    import pytest

    from .helpers import TEST_DIR

    test_file_name = "test_config.py"
    test_file_path = TEST_DIR / test_file_name

    # -------------------------
    # A) Test cases when location
    #    parameter provided as a
    #    string.
    # -------------------------
    # A1) Test if module is successfully loaded.
    #     Use non existing import in test module
    #     to check if we are importing it from
    #     module file or from a previously loaded
    #     modules from a cache.
    with pytest.raises(ImportError):
        import non_existing_import

    test_config = load_module_from_file_location(test_file_name)

# Generated at 2022-06-24 04:36:31.190582
# Unit test for function str_to_bool
def test_str_to_bool():
    def check_true(val):
        assert str_to_bool(val)

    def check_false(val):
        assert not str_to_bool(val)

    check_true("y")
    check_true("yes")
    check_true("yep")
    check_true("yup")
    check_true("t")
    check_true("true")
    check_true("on")
    check_true("enable")
    check_true("enabled")
    check_true("1")
    check_false("n")
    check_false("no")
    check_false("f")
    check_false("false")
    check_false("off")
    check_false("disable")
    check_false("disabled")
    check_false("0")

# Generated at 2022-06-24 04:36:38.076269
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")
    assert not str_to_bool("0")

# Generated at 2022-06-24 04:36:44.845723
# Unit test for function str_to_bool
def test_str_to_bool():
    for val in {
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    }:
        assert str_to_bool(val) is True

    for val in {
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    }:
        assert str_to_bool(val) is False

    with pytest.raises(ValueError):
        str_to_bool("gibberish")

# Generated at 2022-06-24 04:36:55.251323
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unit test for function load_module_from_file_location

    The test checks if pathlib.Path object can be passed as an argument to
    this function.

    Cause of making this test:
        We were passing pathlib.Path object to load_module_from_file_location
        function and this failed due to this function passing the Path object to
        importlib.util.spec_from_file_location function. This latter function
        was trying to interprete Path object as a string containing
        module name.

        This function was changed to accept pathlib.Path object. This test
        checks if such situation as pathlib.Path object is passed
        to this function
        don't goes wrong anymore.
    """
    import sys
    import tempfile


# Generated at 2022-06-24 04:36:57.315449
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("yup") == T

# Generated at 2022-06-24 04:37:09.323551
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test loading module from file location."""

    _test_string = load_module_from_file_location.__doc__

    assert load_module_from_file_location(__file__) == __name__

    assert (
        load_module_from_file_location(__file__, location=__file__) == __name__
    )

    assert (
        load_module_from_file_location(__file__, location=__file__) == __name__
    )

    assert (
        load_module_from_file_location(__name__, location=__file__)
        == load_module_from_file_location.__module__
    )

    assert (
        load_module_from_file_location(__file__, location=__name__)
        == __name__
    )

   

# Generated at 2022-06-24 04:37:20.379945
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Using string argument.
    # ----------------------------
    # A) Assert case when location is not a path.
    # - Test 1.1
    # Test 1.1.1
    # Test 1.1.1.1
    #    a) Test 1.1.1.1.1
    #    b) Test 1.1.1.1.2
    #    c) Test 1.1.1.1.3
    #    d) Test 1.1.1.1.4
    # - Test 1.2
    # - Test 1.3
    # - Test 1.4
    # - Test 1.5
    assert load_module_from_file_location("/some/path") == \
        load_module_from_file_location("/some/path", "")
    assert load_module

# Generated at 2022-06-24 04:37:21.782846
# Unit test for function str_to_bool
def test_str_to_bool():
    result = str_to_bool(val)

    assert result == True

# Generated at 2022-06-24 04:37:32.737840
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Case 1.
    # location is of a string type.
    # It also contains environment variables.
    os_environ["some_env_var"] = "some_value"
    some_module = load_module_from_file_location(
        "tests/test_project/some_module", "/some/path/${some_env_var}"
    )

    assert some_module.config == {"SOME_CONFIG": "some_value"}

    # Case 2.
    # location is of a string type.
    # It also contains environment variables.
    # Some of them are not defined.
    os_environ.pop("some_env_var")

# Generated at 2022-06-24 04:37:33.680241
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # This function is covered by unit tests.
    pass

# Generated at 2022-06-24 04:37:38.490175
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest

    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "some_module_name", "/some/path/${some_env_var}"
        )

    with pytest.raises(PyFileError):
        load_module_from_file_location(
            "some_module_name", "/some/path/to/some_file.py"
        )

# Generated at 2022-06-24 04:37:41.251169
# Unit test for function str_to_bool
def test_str_to_bool():
    assert isinstance(str_to_bool("true"),bool)
    assert isinstance(str_to_bool("False"),bool)
    assert str_to_bool("y")
    assert not str_to_bool("no")
    assert str_to_bool("True")



# Generated at 2022-06-24 04:37:49.501099
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("true") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("0") == False
    assert str_to_bool("NO") == False
    assert str_to_bool("false") == False
    assert str_to_bool("FaLsE") == False

test_str_to_bool()

# Generated at 2022-06-24 04:37:52.255279
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["FOO"] = "bar"
    assert load_module_from_file_location("/".join(
        ("${FOO}", "file.py")))
    del os_environ["FOO"]

# Generated at 2022-06-24 04:38:03.972279
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("Y")
    assert str_to_bool("YES")
    assert str_to_bool("Yep")
    assert str_to_bool("YUP")
    assert str_to_bool("T")
    assert str_to_bool("TRUE")
    assert str_to_bool("On")
    assert str_to_bool("ENABLE")
    assert str_to_bool("ENABLED")
    assert str_to_bool("1")

    assert not str_to_bool("N")
    assert not str_to_bool("NO")
    assert not str_to_bool("F")
    assert not str_to_bool("FALSE")
    assert not str_to_bool("OFF")
    assert not str_to_bool("DISABLE")
    assert not str_to

# Generated at 2022-06-24 04:38:11.936893
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "/path/to/config.py"
    module = load_module_from_file_location(location)
    module = load_module_from_file_location(module)
    module = load_module_from_file_location(location, "latin-1")

    location = Path(location)
    module = load_module_from_file_location(location)
    module = load_module_from_file_location(module)
    module = load_module_from_file_location(location, "cp1250")

    os_environ["some_env_var"] = location
    module = load_module_from_file_location(f"${os_environ['some_env_var']}")

# Generated at 2022-06-24 04:38:20.059973
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert not any(
        hasattr(load_module_from_file_location(__file__), k)
        for k in ("test_load_module_from_file_location", "test_str_to_bool")
    )
    assert not hasattr(
        load_module_from_file_location(
            "tests/test_sanic_helpers/test_helpers.py"
        ),
        "test_load_module_from_file_location",
    )
    assert hasattr(
        load_module_from_file_location(
            "tests/test_sanic_helpers/test_helpers.py"
        ),
        "test_str_to_bool",
    )

# Generated at 2022-06-24 04:38:26.914281
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("YES")
    assert str_to_bool("No")
    assert not str_to_bool("OFF")
    assert not str_to_bool("False")

    #
    # test invalid value

    from pytest import raises

    with raises(ValueError):
        str_to_bool("True")

# Generated at 2022-06-24 04:38:35.718731
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") == True
    assert str_to_bool("yEs") == True
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("1") == True

    assert str_to_bool("f") == False
    assert str_to_bool("yEs") == True
    assert str_to_bool("false") == False
    assert str_to_bool("False") == False
    assert str_to_bool("0") == False

    try:
        assert str_to_bool(" ") == False
    except ValueError:
        assert True

# Generated at 2022-06-24 04:38:42.556981
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile as named_temp_file

    with named_temp_file(mode="w+", encoding="utf8") as tmp:
        tmp.write("some_var = 42")
        tmp.seek(0)

        module = load_module_from_file_location(tmp.name)
        assert module.some_var == 42

# Generated at 2022-06-24 04:38:54.099890
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from inspect import getfile

    from .testing import TEST_DIR

    assert str(TEST_DIR) == os.path.dirname(getfile(test_load_module_from_file_location))

    # Case 1:
    # fn:     project/utils/load.py
    # module: test_module
    location = str(TEST_DIR / "test_module.py")
    try:
        module = load_module_from_file_location(location)
    except PyFileError as e:
        raise AssertionError(
            f"Case 1: Unable to load file {location} due to: {e}"
        )

    assert module.conf == "test"

    # Case 2:
    # fn:     project/utils/load.py
    # module: test_module.json
    location

# Generated at 2022-06-24 04:39:03.235686
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("No") is False
    assert str_to_bool("off") is False
    assert str_to_bool("on") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("n") is False
    assert str_to_bool(1) is True
    assert str_to_bool(0) is False

    with pytest.raises(ValueError) as e:
        str_to_bool("false-ish")
    assert "truth value" in str(e.value)

# Generated at 2022-06-24 04:39:09.677191
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Yes") == True
    assert str_to_bool("no") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("Yes") == True
    assert str_to_bool("True") == True
    assert str_to_bool("T") == True
    try:
        str_to_bool("tr")
    except ValueError:
        print("Exception works!")

# Generated at 2022-06-24 04:39:16.832932
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from pathlib import Path
    from shutil import rmtree
    from tempfile import mkdtemp
    from textwrap import dedent

    import pytest
    from sanic import Sanic
    from sanic.config import Config, LOGGING

    os_environ["SANIC_ENV_VAR"] = "c"

    # 1) Test if all of the parameters are passing
    #    through to spec_from_file_location and
    #    module_from_spec.
    app = Sanic("test_app")
    assert app.config == Config.from_object(LOGGING)

    # Test that spec_from_file_location is called
    # with given parameters and name.

# Generated at 2022-06-24 04:39:25.870301
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("N") is False
    assert str_to_bool("no") is False
    assert str_to_bool("false") is False
    assert str_to_bool("f") is False
    assert str

# Generated at 2022-06-24 04:39:34.180053
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    from os import environ as os_environ
    from os import remove as os_remove
    from os.path import join as os_path_join

    from sanic_envconfig.helpers import load_module_from_file_location

    def create_temporary_file(contents, file_name="temp.py"):
        """Creates a temporary file with given contents and file name.

        Returns tuple of a Path object to created temporary file
        and a path to temporary directory.
        """
        temp_dir = tempfile.TemporaryDirectory()
        temp_file_path = os_path_join(temp_dir.name, file_name)
        with open(temp_file_path, "w") as temp_file:
            temp_file.write(contents)

# Generated at 2022-06-24 04:39:44.428179
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import builtins

    l = "inspect"
    module = load_module_from_file_location(l)
    assert module == inspect

    l = "__main__"
    module = load_module_from_file_location(l)
    assert module == builtins

    l = "${MOCK_COMMAND}"
    os_environ["MOCK_COMMAND"] = "sanic.__main__"
    module = load_module_from_file_location(l)
    assert module == builtins

    l = "${MOCK_COMMAND}"
    os_environ["MOCK_COMMAND"] = "inspect"
    module = load_module_from_file_location(l)
    assert module == inspect

    l = "config.py"
    module = load_module_from_file

# Generated at 2022-06-24 04:39:52.271774
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Yes") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes please") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("YeS") == True
    assert str_to_bool("   yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("True") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("On") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("Enabled") == True
    assert str_to_bool("Enable") == True
    assert str_to_bool("1") == True

# Generated at 2022-06-24 04:39:58.718654
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("true") is True
    assert str_to_bool("truE") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("t") is True
    assert str_t

# Generated at 2022-06-24 04:40:10.349368
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from unittest import TestCase
    from .unit import core

    class TestLoadModuleFromFileLocation(TestCase):
        def test_file_location(self):
            core.load_module_from_file_location(__file__)

        def test_file_location_does_not_exist(self):
            with self.assertRaises(LoadFileException):
                core.load_module_from_file_location(
                    "/not/existing/path/sanicconfig.py"
                )

        def test_env_variables_in_location(self):
            os_environ["SANICCONFIG_MODULE"] = __file__
            core.load_module_from_file_location(
                "/some/path/${SANICCONFIG_MODULE}"
            )


# Generated at 2022-06-24 04:40:18.469625
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("yes") is True
    assert str_to_bool("NO") is False
    assert str_to_bool("1") is True
    assert str_to_bool("True") is True
    assert str_to_bool("FALSE") is False
    assert str_to_bool("0") is False
    assert str_to_bool("n") is False
    assert str_to_bool("y") is True
    assert str_to_bool("") is not True
    assert str_to_bool(None) is not True

# Generated at 2022-06-24 04:40:29.797976
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:40:39.826633
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # A) Environment variable doesn't exist.
    location = "some_not_existing_env_var/some_file.conf"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    # B) Environment variable exist but after substitution
    #    it is not a file path.
    location = "somerandomtext/some_file.conf"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    # C) Environment variable exist and after substitution
    #    it is a file path.
    location = "./tests/test_file.conf"
    os_environ["TEST_FILE_LOCATION"] = os.path.abspath(location)

# Generated at 2022-06-24 04:40:43.204271
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("yes") is True
    assert str_to_bool("nO") is False

    try:
        str_to_bool("not a boolean string")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-24 04:40:49.849439
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest

    with pytest.raises(PyFileError, match="foo.py"):
        load_module_from_file_location("foo.py")

    import sys

    r = load_module_from_file_location("__main__")
    assert r is sys.modules["__main__"]

    r = load_module_from_file_location("__main__", "config")
    assert r is sys.modules["__main__"]

    r = load_module_from_file_location("__main__", "config", "config")
    assert r is sys.modules["__main__"]

    with pytest.warns(UserWarning, match="Could not load configuration: config"):
        load_module_from_file_location("config")


# Generated at 2022-06-24 04:41:00.714884
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    f_name = "_config_pars_test"
    config_path = "./tests/configs"
    file_path = Path(config_path) / (f_name + ".py")

    # A) Assert that module is loaded when it's file path doesn't contain
    #    any environment variables.
    module = load_module_from_file_location(
        file_path, encoding="utf8", loader_class=None
    )
    assert module.TEST_CONFIG == "hello"
    assert module.TEST_ARGS == ["a", "b", "c"]
    assert module.TEST_KWARGS == {"arg": "true", "arg2": "false"}
    assert module.__file__ == str(file_path)

    # B) Assert that module is loaded when file path contains
    #

# Generated at 2022-06-24 04:41:05.404206
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('y') == True
    assert str_to_bool('yes') == True
    assert str_to_bool('yep') == True
    assert str_to_bool('yup') == True
    assert str_to_bool('t') == True
    assert str_to_bool('true') == True
    assert str_to_bool('on') == True
    assert str_to_bool('enable') == True
    assert str_to_bool('enabled') == True
    assert str_to_bool('1') == True

    assert str_to_bool('n') == False
    assert str_to_bool('no') == False
    assert str_to_bool('f') == False
    assert str_to_bool('false') == False
    assert str_to_bool('off') == False

# Generated at 2022-06-24 04:41:16.181888
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("oh hell no") is False
    assert str_to_bool("FALSE") is False
    assert str_to_bool("0") is False

# Generated at 2022-06-24 04:41:23.974581
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("YES")
    assert str_to_bool("Yes")
    assert str_to_bool("no")
    assert str_to_bool("NO")
    assert str_to_bool("No")
    assert str_to_bool("on")
    assert str_to_bool("ON")
    assert str_to_bool("On")
    assert str_to_bool("off")
    assert str_to_bool("OFF")
    assert str_to_bool("Off")
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("n")
    assert str_to_bool("N")
    assert str_to_bool("t")
    assert str_to_bool("T")
   

# Generated at 2022-06-24 04:41:33.218021
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if environ is correctly used
    os_environ["TEST_ENV_VAR"] = "some val"
    location = "some/path/${TEST_ENV_VAR}"
    module = load_module_from_file_location(location)
    assert module.__file__ == "some/path/some val"
    del os_environ["TEST_ENV_VAR"]

    # B) Check if file is correctly loaded
    location = "tests.unit.test_utilities.test_config"
    module = load_module_from_file_location(location)
    assert module.TEST_CONFIG_VAR == "some_val"

    # C) Check if package is correctly loaded
    location = "tests.unit.test_utilities"
    module = load_module_from

# Generated at 2022-06-24 04:41:43.079083
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_file_name = "{0}/{1}.py".format(
        os.path.dirname(os.path.abspath(__file__)), "test_load_module_from_file_location"
    )

    test_file_content = "test_variable = 'test_value'"

    with open(test_file_name, "w") as test_file:
        test_file.write(test_file_content)

    module = load_module_from_file_location(test_file_name)

    assert module.test_variable == 'test_value'
    assert module.__file__ == test_file_name

    os.remove(test_file_name)

# Generated at 2022-06-24 04:41:53.952074
# Unit test for function str_to_bool
def test_str_to_bool():
    tst_dct = {"y": True, "Y": True, "yes": True, "yup": True, "Yup": True}
    for key, value in tst_dct.items():
        assert str_to_bool(key) == value

    tst_dct = {"n": False, "N": False, "no": False, "No": False}
    for key, value in tst_dct.items():
        assert str_to_bool(key) == value

    tst_lst = ["true", "True", "false", "False", "t", "f"]
    for value in tst_lst:
        with pytest.raises(ValueError):
            str_to_bool(value)

# Generated at 2022-06-24 04:42:02.413979
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Let's create test file with config in it.
    import tempfile

    # Make sure that the config file we create doesn't already exist
    fd, path = tempfile.mkstemp(suffix=".py", prefix="config_")
    os.close(fd)

    with open(path, "w") as f:
        f.write("CONFIG_VARIABLE = 'value'")

    # Check that we can load the config with this function
    new_config = load_module_from_file_location(path)
    assert new_config.CONFIG_VARIABLE == "value"
    os.remove(path)

    # Check that we can load the config with this function with ${example}
    os_environ["EXAMPLE"] = path

# Generated at 2022-06-24 04:42:12.113608
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    from os import getcwd, remove

    current_directory = getcwd()
    file_name = f"{import_string(__name__).__name__}.py"

    # A) Create python file in current directory.
    with open(file_name, "w") as module_file:
        module_file.write("TEST = True")

    # B) Try to import it using load_module_from_file_location().

# Generated at 2022-06-24 04:42:22.329027
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_VARIABLE"] = "TEST_VARIABLE"

    module = load_module_from_file_location(
        "/some/path/${TEST_VARIABLE}/test.py"
    )
    assert module.__file__ == "/some/path/TEST_VARIABLE/test.py"

    module = load_module_from_file_location(
        Path("/some/path/${TEST_VARIABLE}/test.py")
    )
    assert module.__file__ == "/some/path/TEST_VARIABLE/test.py"

    module = load_module_from_file_location(
        Path("/some/path/${TEST_VARIABLE}"), ".py"
    )
    assert module.__

# Generated at 2022-06-24 04:42:31.863528
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ

    from copy import copy
    from pathlib import Path
    from unittest import TestCase

    from sanic import Sanic
    from sanic.exceptions import InvalidUsage

    from sanic_envconfig.env_loader import EnvLoader

    class SomeTestClass(TestCase):
        def test_normal_behavior(self):
            """location is just a file name"""
            environ["ENV_CONFIG_TEST"] = "ENV_CONFIG_TEST_VALUE"
            app = Sanic()
            app.config.from_object(load_module_from_file_location("sanic"))
            app.config["REQUEST_MAX_SIZE"] = 1234
            self.assertEqual(app.config["REQUEST_MAX_SIZE"], 1234)

# Generated at 2022-06-24 04:42:37.781576
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Load module with python path.
    location_1 = "tests.config.module_1"
    module_1 = load_module_from_file_location(location_1)
    assert module_1.var_1 == "module_var_1_py"

    # B) Load module with filepath.
    location_2 = "tests/config/module_2.py"
    module_2 = load_module_from_file_location(location_2)
    assert module_2.var_1 == "module_var_1_py"

    # C) Load module with filepath w/o .py extension.
    location_3 = "tests/config/module_1"
    module_3 = load_module_from_file_location(location_3)

# Generated at 2022-06-24 04:42:44.871392
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    import contextlib
    import importlib

    TEST_DIR = os.path.dirname(os.path.abspath(__file__))

    with tempfile.TemporaryDirectory() as tmpdirname:
        with contextlib.closing(open(os.path.join(TEST_DIR, 'config.py'), 'rt')) as fd:
            config_content = fd.read().replace('test_conf_dir', tmpdirname)

        tmp_test_config = os.path.join(tmpdirname, "test_tmp_config.py")
        with contextlib.closing(open(tmp_test_config, 'wt')) as fd:
            fd.write(config_content)


# Generated at 2022-06-24 04:42:54.155691
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pytest import raises

    # Check if doest not exists file return LoadFileException.
    with raises(LoadFileException):
        load_module_from_file_location("/this/file/doesnt/exists.py")

    # Check if not defined environment varible raise LoadFileException.
    with raises(LoadFileException):
        load_module_from_file_location("/some/path/${not_defined_env_var}")

    # Check if incorrect file path raise LoadFileException.
    with raises(LoadFileException):
        load_module_from_file_location("file_without_py_extension")

    # Check if incorrect file path raise LoadFileException.
    with raises(LoadFileException):
        load_module_from_file_location("/some/path/file_without_py_extension")

   

# Generated at 2022-06-24 04:43:06.476453
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Location parameter is of a Path type.
    module = load_module_from_file_location(Path("tests/test_utils.py"))
    assert module is not None

    # B) Location parameter is of a bytes type.
    module = load_module_from_file_location(
        bytes("tests/test_utils.py", "utf-16"), encoding="utf-16"
    )
    assert module is not None

    # C) Location parameter is of a string type.
    module = load_module_from_file_location("tests/test_utils.py")
    assert module is not None

    # D) Location parameter is of a string type and contains
    #    environment variable in format ${some_env_var}.
    os_environ["ENV_VAR_1"] = "some_value"

# Generated at 2022-06-24 04:43:16.077223
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Given
    path = "/some/path/to/module.py"
    module_name = "module"
    assert path.split("/")[-1].split(".")[0] == module_name

    # When
    module = load_module_from_file_location(path)

    # Then
    assert module.__name__ == module_name
    assert module.__package__ is None

    # When
    module = load_module_from_file_location(
        bytes(path, encoding="utf-8"), encoding="utf-8"
    )

    # Then
    assert module.__name__ == module_name
    assert module.__package__ is None

# Generated at 2022-06-24 04:43:27.114377
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path

    from .test_helpers import make_temp_file

    # Test if load_module_from_file_location can not load non existent file.
    module_file = Path("non_existent_file.py")
    assert module_file.is_file() is False
    with pytest.raises(IOError):
        load_module_from_file_location(module_file)

    # Test if load_module_from_file_location can load file
    # with environment variables in format ${some_env_var} and
    # resolve them.
    module_file = make_temp_file("path_with_env = ${SOME_ENV_VAR}\n")
    os_environ["SOME_ENV_VAR"] = "somedata"
    module = load_module_from

# Generated at 2022-06-24 04:43:36.741440
# Unit test for function str_to_bool
def test_str_to_bool():
    # If val is in case insensitive ("y", "yes", "yep", "yup", "t", "true",
    # "on", "enable", "enabled", "1") returns True.
    assert str_to_bool("y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("Enable") == True
    assert str_to_bool("ENABLED") == True
    assert str_to_bool("1") == True

    # If val is in case insensitive ("n", "no", "f", "

# Generated at 2022-06-24 04:43:43.403839
# Unit test for function str_to_bool
def test_str_to_bool():
    # Cases that are equal to True
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    # Cases that are equal to False
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false")

# Generated at 2022-06-24 04:43:47.375287
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["ENV_VAR"] = "env_var_value"
    module = load_module_from_file_location(
        "some_module_name", "/some/path/${ENV_VAR}"
    )
    assert module.__name__ == "some_module_name"
    assert module.__file__ == "/some/path/env_var_value"



# Generated at 2022-06-24 04:43:57.643241
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("False") is False
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("enable") is True
    assert str_to_bool("disable") is False
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("YEPP") is True
    assert str_to_bool("nope") is False
    assert str_to_bool("") is False

# Generated at 2022-06-24 04:44:09.279337
# Unit test for function str_to_bool

# Generated at 2022-06-24 04:44:18.603600
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:44:28.633435
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool(True) == True # expected to pass
    assert str_to_bool(False) == False # expected to pass
    assert str_to_bool('True') == True # expected to pass
    assert str_to_bool('False') == False # expected to pass
    assert str_to_bool('true') == True # expected to pass
    assert str_to_bool('false') == False # expected to pass
    assert str_to_bool('TRUE') == True # expected to pass
    assert str_to_bool('FALSE') == False # expected to pass
    assert str_to_bool('t') == True # expected to pass
    assert str_to_bool('f') == False # expected to pass
    assert str_to_bool('T') == True # expected to pass
    assert str_to_bool('F')

# Generated at 2022-06-24 04:44:38.716632
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("test.test_helpers.load_module")
    assert load_module_from_file_location("test/test_helpers/load_module.py")
    assert (
        load_module_from_file_location(
            "/test/test_helpers/load_module.py"
        )
    )
    assert (
        load_module_from_file_location(
            "test/test_helpers/${TEST_FILE}"
        )
    )
    assert (
        load_module_from_file_location(
            b"/test/test_helpers/load_module.py", "utf8"
        )
    )

# Generated at 2022-06-24 04:44:44.473823
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("false") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("on") is True
    assert str_to_bool("n") is False
    assert str_to_bool("off") is False
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("") is False
    assert str_to_bool("foo") is False
    assert str_to_bool(" ") is False

# Generated at 2022-06-24 04:44:51.462427
# Unit test for function str_to_bool
def test_str_to_bool():
    assert(str_to_bool("yes") == True)
    assert(str_to_bool("on") == True)
    assert(str_to_bool("TruE") == True)
    assert(str_to_bool("1") == True)

    assert(str_to_bool("n") == False)
    assert(str_to_bool("off") == False)
    assert(str_to_bool("No") == False)
    assert(str_to_bool("0") == False)

    with pytest.raises(ValueError):
        str_to_bool("qwerty")



# Generated at 2022-06-24 04:45:02.175176
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST"] = "test"
    assert "test" == load_module_from_file_location(
        "${TEST}", None, False, False, False
    ).__name__
    os_environ.pop("TEST")

    os_environ["TEST"] = "test"
    assert "test" == load_module_from_file_location(
        "/${TEST}", None, False, False, False
    ).__name__
    os_environ.pop("TEST")

    os_environ["TEST"] = "test"
    assert "test" == load_module_from_file_location(
        "/path/${TEST}", None, False, False, False
    ).__name__
    os_environ.pop("TEST")

    assert "test"

# Generated at 2022-06-24 04:45:09.007121
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yES") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("YEPS") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("YUP") is True
    assert str_to_bool("t") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("True") is True
    assert str_to_bool("on") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("enable") is True