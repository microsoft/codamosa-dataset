

# Generated at 2022-06-24 04:35:07.667214
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys
    import contextlib
    import tempfile
    import types

    from sanic import Sanic
    from sanic.config import LOGGING_CONFIG_DEFAULTS

    os_environ["SANIC_TEST"] = str(os_environ["PYTHONPATH"])

    # This is the normal config file with the environment variables

# Generated at 2022-06-24 04:35:18.436040
# Unit test for function str_to_bool

# Generated at 2022-06-24 04:35:29.210906
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import inspect
    import os

    module_name = "test_module"
    module_path = "tests/unit/config/test_module.py"

    # Just a test for proper work of load_module_from_file_location
    py_module = load_module_from_file_location(module_path)

    # Check that it's not loaded into the sys.modules
    # and will not be reloaded into it next time.
    assert sys.modules.get(module_name) is None

    # It is not just a string copied from the file.
    # We got the proper module with it's code.

# Generated at 2022-06-24 04:35:33.353613
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    location = os.path.abspath("tests/test_module.py")
    module_name = "test_module"
    module = load_module_from_file_location(location, module_name)
    assert hasattr(module, "test_var")
    assert module.test_var == "test"

# Generated at 2022-06-24 04:35:45.528009
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    pwd = Path.cwd()

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["some_env_var"] = "config"
    location = "./${some_env_var}/config.py"

    # B) Check these variables exists in environment.
    not_defined_env_vars = list(
        set(re_findall(r"\${(.+?)}", location)).difference(os_environ.keys())
    )
    assert not_defined_env_vars == []

    # C) Substitute them in location.

# Generated at 2022-06-24 04:35:54.990836
# Unit test for function str_to_bool

# Generated at 2022-06-24 04:36:06.118299
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-24 04:36:16.617193
# Unit test for function str_to_bool
def test_str_to_bool():
    for val in {
        "y",
        "Y",
        "yes",
        "YES",
        "yep",
        "YEP",
        "yup",
        "YUP",
        "True",
        "TRUE",
        "T",
        "t",
        "enable",
        "ENABLE",
        "on",
        "ON",
        "enabled",
        "ENABLED",
        "1",
    }:
        assert str_to_bool(val) is True


# Generated at 2022-06-24 04:36:24.327708
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    conf = load_module_from_file_location(
        "/tests/app.py",
        "/tests/${NOT_DEFINED_ENV_VAR}",
        "/tests/app.py",
        "/tests/${NOT_DEFINED_ENV_VAR}",
    )
    assert conf.SOME_CONSTANT == "some constant"
    assert conf.SOME_PATH == "some path"
    try:
        load_module_from_file_location(
            "/tests/app.py", "/tests/${NOT_DEFINED_ENV_VAR}"
        )
    except LoadFileException:
        pass
    else:
        assert False, "LoadFileException not raised"


# Generated at 2022-06-24 04:36:35.154917
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    """Unit test for function str_to_bool."""

    assert str_to_bool("true")
    assert str_to_bool("false")
    assert str_to_bool("T")
    assert str_to_bool("F")
    assert str_to_bool("1")
    assert str_to_bool("0")
    assert str_to_bool("ON")
    assert str_to_bool("off")
    assert str_to_bool("Y")
    assert str_to_bool("N")
    assert str_to_bool("yes")
    assert str_to_bool("NO")
    assert str_to_bool("Enable")
    assert str_to_bool("Disabled")
    assert str_to_bool("Yes")
    assert str_to_bool("tRue")

# Generated at 2022-06-24 04:36:43.793723
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os

    os_environ["some_env_var"] = "./tests/test_config"
    test_module = load_module_from_file_location(
        "CONFIG_TEST_RESPONSE", "./tests/test_config"
    )
    assert test_module.CONFIG_TEST_RESPONSE == "test_config_test_response"

    test_module = load_module_from_file_location(
        "CONFIG_TEST_RESPONSE", "./tests/test_config/${some_env_var}"
    )
    assert test_module.CONFIG_TEST_RESPONSE == "test_config_test_response"



# Generated at 2022-06-24 04:36:54.124758
# Unit test for function str_to_bool
def test_str_to_bool():
    list_of_true_values = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]
    assert all(str_to_bool(val) for val in list_of_true_values)

    list_of_false_values = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]
    assert all(not str_to_bool(val) for val in list_of_false_values)

    with pytest.raises(ValueError):
        str_to_bool("asd")

# Generated at 2022-06-24 04:37:05.633961
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    scope = {}
    module = load_module_from_file_location(
        __file__, "tests/test_helpers.py", scope=scope
    )
    assert module is not None

    assert module.__name__ == "tests.test_helpers"
    assert module.__file__ == "tests/test_helpers.py"
    assert module.__package__ == "tests"
    assert module.__spec__ is not None
    assert module.__spec__.loader is not None
    assert module.__spec__.loader.get_code(fullname="tests.test_helpers")
    assert module.__spec__.loader.is_package("tests")
    assert module.__spec__.loader.is_package("tests.test_helpers") is False
    assert module.__loader__ is module.__spec__

# Generated at 2022-06-24 04:37:15.314329
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:37:25.019294
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("y") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False
    assert str_to_bool("disabled") is False
    assert str

# Generated at 2022-06-24 04:37:34.910804
# Unit test for function str_to_bool
def test_str_to_bool():
    # Test values that return True
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("yes")
    assert str_to_bool("Yes")
    assert str_to_bool("YES")
    assert str_to_bool("yep")
    assert str_to_bool("Yep")
    assert str_to_bool("YEP")
    assert str_to_bool("yup")
    assert str_to_bool("Yup")
    assert str_to_bool("YUP")
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("TRUE")

# Generated at 2022-06-24 04:37:46.170305
# Unit test for function str_to_bool

# Generated at 2022-06-24 04:37:53.680630
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    fake_module_name = "some_fake_module"
    location = f"some_module/some_module/some_module/{fake_module_name}.py"

    py_file_content = f"def some_func():\n    return '{fake_module_name}'"

    module_parent_dir = Path(tempfile.gettempdir()).joinpath(
        "sanic_compress__test_load_module_from_file_location"
    )

    module_parent_dir.mkdir(parents=True, exist_ok=True)

    py_file_path = module_parent_dir.joinpath(fake_module_name)

    with py_file_path.open("w") as py_file:
        py_file.write(py_file_content)

    module = load_module_from

# Generated at 2022-06-24 04:37:59.291018
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("on") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("On") is True
    assert str_to_bool("tRUE") is True
    assert str_to_bool("1") is True

    assert str_to_bool("off") is False
    assert str_to_bool("disabled") is False
    assert str_to_bool("no") is False
    assert str_to_bool("n") is False
    assert str_to_bool("0") is False
    assert str_to_bool("NO") is False
    assert str_to_bool("nO") is False
    assert str_to_bool("nope") is False



# Generated at 2022-06-24 04:38:10.183820
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # 1) Check with just normal string location.
    module = load_module_from_file_location(
        "/Users/awesome_user/some/path/some_module.py", "ascii"
    )
    assert module

    # 2) Check with Path object location.
    module = load_module_from_file_location(
        Path("/Users/awesome_user/some/path/some_module.py"), "ascii"
    )
    assert module

    # 3) Check with Path object location, but without .py extension.
    module = load_module_from_file_location(
        Path("/Users/awesome_user/some/path/some_module"), "ascii"
    )
    assert module

    # 4) Check with bytes object location.
    module = load

# Generated at 2022-06-24 04:38:18.668858
# Unit test for function str_to_bool
def test_str_to_bool():
    import pytest
    from random import choice
    from string import ascii_lowercase as letters

    true_values = ["y", "yes", "yep", "yup", "t", "true", "on", "enable", "enabled", "1"]
    false_values = ["n", "no", "f", "false", "off", "disable", "disabled", "0"]
    val = choice(true_values)
    assert str_to_bool(val) == True

    val = choice(false_values)
    assert str_to_bool(val) == False

    val = "".join(choice(letters) for i in range(20))
    with pytest.raises(ValueError):
        str_to_bool(val)

# Generated at 2022-06-24 04:38:29.202947
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""

    # Test for file path given as string.
    # Note! If you want to test this function with environment variables,
    #       you need to define needed keys and values
    #       in host system of the given environment variables.
    assert hasattr(
        load_module_from_file_location("python:os"), "path"
    )
    assert hasattr(
        load_module_from_file_location("python:os.path"), "abspath"
    )

    # Test for file path given as bytes
    assert hasattr(
        load_module_from_file_location(b"python:os"), "path"
    )

# Generated at 2022-06-24 04:38:40.622271
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import unittest
    import tempfile
    import os

    class TestLoadModuleFromFileLocation(unittest.TestCase):
        def setUp(self):
            self.temp_test_file = tempfile.NamedTemporaryFile(mode="w+")
            self.temp_test_file.write("test_var = 42")
            self.temp_test_file.flush()

            self.temp_test_file_with_env_var = tempfile.NamedTemporaryFile(
                mode="w+"
            )
            self.temp_test_file_with_env_var.write("test_var = 42")
            self.temp_test_file_with_env_var.flush()


# Generated at 2022-06-24 04:38:53.537660
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False

# Generated at 2022-06-24 04:39:01.090174
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    def test_no_exception(mock_mod, location):
        return load_module_from_file_location(location) == mock_mod

    # A) Try to load file with a path as a string
    with mock.patch.object(
        types, "ModuleType", autospec=True
    ) as mock_module_type, mock.patch(
        "builtins.open",
        mock.mock_open(read_data="some_data"),
        create=True,
    ):
        mock_mod_spec = mock.MagicMock()
        mock_module_type.return_value.__spec__ = mock_mod_spec
        mock_mod_spec.loader.exec_module.return_value = "some_data"

        mock_module = mock_module_type.return_value

# Generated at 2022-06-24 04:39:05.612134
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yep")
    assert str_to_bool("true")
    assert not str_to_bool("nope")
    assert not str_to_bool("false")
    try:
        str_to_bool("I don't know")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-24 04:39:14.335234
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import curdir, environ
    from os.path import abspath, dirname
    from pathlib import Path
    from random import randint
    from tempfile import TemporaryDirectory

    from pytest import fixture
    from pytest import raises

    from ._utils import ModuleDir

    # $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
    #
    # A) The first case of usage - when location is a string.
    #
    # When location is a string pytest.fixture(scope='module') sets
    # in os.environ and uses in location this environment variable.
    @fixture(scope="module")
    def env_var_for_dir_name():
        # A) environment variable
        env_var = "env_var_" + str(randint(0, 9999))


# Generated at 2022-06-24 04:39:14.984161
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # TODO
    pass

# Generated at 2022-06-24 04:39:25.884895
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from shutil import copyfile
    from tempfile import NamedTemporaryFile
    from os import remove, getcwd
    from os.path import join, dirname
    from os import environ

    # Environment variable should be set before running this test.
    assert os.environ["TEST_ENVVAR"]
    CONFIG_FILE = join(getcwd(), "tests", "config.py")
    environ["TEST_CONFIG_FILE"] = CONFIG_FILE
    TEMP_CONFIG_FILE = NamedTemporaryFile()
    TEST_PATH = f"${TEST_ENVVAR}"

    # Testing that env variables are resolved (inside file path)
    copyfile(CONFIG_FILE, TEMP_CONFIG_FILE.name)

# Generated at 2022-06-24 04:39:34.180895
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def count_suite_cases(suite):
        to_run = 0
        for test in suite:
            if isinstance(test, unittest.TestSuite):
                to_run += count_suite_cases(test)
            else:
                to_run += 1
        return to_run

    class Test_load_module_from_file_location(unittest.TestCase):
        def test_import_via_bytes(self):
            location = b"/some/path/to/my/config.py"
            module = load_module_from_file_location(location)
            self.assertEqual(module.__file__, location.decode())

        def test_import_via_string(self):
            location = "/some/path/to/my/config.py"
            module = load_

# Generated at 2022-06-24 04:39:42.338677
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "tests/config/config.py"
    module = load_module_from_file_location(location)
    assert "APP_CONFIG" in module.__dict__
    assert module.APP_CONFIG["TESTING"] is True
    assert module.APP_CONFIG["TESTING_DB_URL"].startswith("sqlite")
    location = "tests/config/config"
    module = load_module_from_file_location(location)
    assert "APP_CONFIG" in module.__dict__
    assert module.APP_CONFIG["TESTING"] is True
    assert module.APP_CONFIG["TESTING_DB_URL"].startswith("sqlite")

# Generated at 2022-06-24 04:39:51.168172
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("1") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("t") == True
    assert str_to_bool("on") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("true") == True
    assert str_to_bool("No") == False
    assert str_to_bool("0") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("f") == False
    assert str_to_bool("off") == False
    assert str_to_bool("false") == False

# Generated at 2022-06-24 04:40:01.101531
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SOME_ENV_VAR"] = "some_env_var_value"

# Generated at 2022-06-24 04:40:10.739365
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('y')
    assert str_to_bool('yes')
    assert str_to_bool('yep')
    assert str_to_bool('yup')
    assert str_to_bool('t')
    assert str_to_bool('true')
    assert str_to_bool('on')
    assert str_to_bool('enable')
    assert str_to_bool('enabled')
    assert str_to_bool('Y')
    assert str_to_bool('YES')
    assert str_to_bool('YEP')
    assert str_to_bool('YUP')
    assert str_to_bool('T')
    assert str_to_bool('TRUE')
    assert str_to_bool('ON')
    assert str_to_bool('ENABLE')
    assert str_to_

# Generated at 2022-06-24 04:40:16.513529
# Unit test for function str_to_bool
def test_str_to_bool():
    true_string = ["y", "yes", "yep", "yup", "t", "true", "on", "enable", "enabled", "1"]  # noqa
    false_string = ["n", "no", "f", "false", "off", "disable", "disabled", "0"]  # noqa

    for word in true_string:
        assert str_to_bool(word) is True
    for word in false_string:
        assert str_to_bool(word) is False

    try:
        str_to_bool("maybe")
    except ValueError:
        pass

    try:
        str_to_bool("NOT DEFINED ENV")
    except ValueError:
        pass

# Generated at 2022-06-24 04:40:28.157966
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import mkdir, makedirs

    from sanic.exceptions import LoadFileException

    # Creates temp directory and set env var TEST_DIR to point at it.
    temp_dir_path = Path(mkdtemp())
    os_environ["TEST_DIR"] = str(temp_dir_path)

    # Creates temp file.
    temp_dir_file = temp_dir_path / "temp_dir_file.py"
    temp_dir_file.write_text(
        text="tst = 'tst_value'."
    )  # Writes some text to this file.

    temp_file_path = Path(mkdtemp())
    temp_file = temp_file_path / "temp_file.py"
    temp

# Generated at 2022-06-24 04:40:36.558340
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location(): # noqa

    test_module_file_content = """
    options = {
        "host": "localhost",
        "port": 8000,
        "request_timeout": 30,
    }
    """

    with open("test_module.py", "w") as test_module_file:
        test_module_file.write(test_module_file_content)

    # Load module
    test_module = load_module_from_file_location("./test_module.py")

    # Check if module has been loaded
    assert test_module.options["host"] == "localhost"
    assert test_module.options["port"] == 8000
    assert test_module.options["request_timeout"] == 30

    # Check if module has been cached

# Generated at 2022-06-24 04:40:45.263142
# Unit test for function str_to_bool
def test_str_to_bool():
    # pylint:disable=redefined-outer-name
    import pytest
    from sanic.helpers import str_to_bool


# Generated at 2022-06-24 04:40:55.834680
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert str_to_bool("true")
    assert not str_to_bool("F")
    assert not str_to_bool("False")
    assert not str_to_bool("FALSE")
    assert not str_to_bool("False")
    assert str_to_bool("1")
    assert str_to_bool("0")
    assert not str_to_bool("2")

    try:
        str_to_bool("asd")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-24 04:41:03.892160
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests load_module_from_file_location function."""

    # Case A) Test if location is of a bytes type.
    assert (
        load_module_from_file_location(
            location=bytes("${test}/test.py", "utf8"),
            encoding="utf8",
            is_package=None,
        ).__file__
        == Path(os_environ["test"]) / "test.py"
    )

    # Case B) Test if location is of a string type and it contains the $ sign.
    assert (
        load_module_from_file_location(location="${test}/test.py").__file__
        == Path(os_environ["test"]) / "test.py"
    )

# Generated at 2022-06-24 04:41:13.659487
# Unit test for function str_to_bool
def test_str_to_bool():

    # checking that function returns expected result for different variables
    test_dict = {
        "true": True,
        "false": False,
        "y": True,
        "n": False,
    }

    for key, val in test_dict.items():
        assert str_to_bool(key) == val

    # checking that function raises ValueError for invalid variable
    try:
        str_to_bool("lorem")
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-24 04:41:19.464510
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Test load_module_from_file_location function.
    """

    # Load something
    _temp_location = __file__
    _temp_module = load_module_from_file_location(_temp_location)
    assert _temp_module

    # Load file with virtual environment variables
    _temp_location = Path(__file__).parent.joinpath("__init__.py")
    assert _temp_location.name == "__init__.py"

    _temp_location = str(_temp_location)
    _temp_location = _temp_location.replace(
        "sanic", "${" + "ENV_VAR_SANIC" + "}"
    )

    os_environ["ENV_VAR_SANIC"] = "sanic"
    _temp_module = load_module_from_file

# Generated at 2022-06-24 04:41:26.494524
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import pytest
    from pathlib import Path

    # Get test current directory and add to PATH so module
    # can be imported from current directory.
    # This directory is where the test file is.
    test_dir_path = Path(sys._getframe(0).f_globals["__file__"]).parent
    sys.path.append(str(test_dir_path))

    def test_load_module_from_file_location_normal(tmp_path):
        from copy import deepcopy

        test_config_location = (tmp_path / "test_config.py")

# Generated at 2022-06-24 04:41:33.687496
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("YES") == True
    assert str_to_bool("no") == False
    assert str_to_bool("on") == True
    assert str_to_bool("off") == False
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False

# Generated at 2022-06-24 04:41:40.362936
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("No") == False
    assert str_to_bool("f") == False
    assert str_to_bool("FALSE") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:41:51.517767
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("t") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("y") == True
    assert str_to_bool("1") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enabled") == True

    assert str_to_bool("false") == False
    assert str_to_bool("False") == False
    assert str_to_bool("f") == False
    assert str_to_bool("no") == False
    assert str_to_bool("n") == False
    assert str_to_bool("0") == False
    assert str_

# Generated at 2022-06-24 04:42:02.197018
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os


# Generated at 2022-06-24 04:42:11.576393
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True

    assert str_to_bool("false") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("disabled") == False

    assert str_to_bool("TRUE") == True
    assert str_to_bool("FALSE") == False



# Generated at 2022-06-24 04:42:16.487504
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("TrUe") == True
    assert str_to_bool("n") == False
    assert str_to_bool("0") == False
    assert str_to_bool("YEs") == True
    assert str_to_bool("N") == False



# Generated at 2022-06-24 04:42:27.448934
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True")
    assert str_to_bool("yes")
    assert str_to_bool("1")
    assert str_to_bool("Y")
    assert not str_to_bool("False")
    assert not str_to_bool("NO")
    assert not str_to_bool("F")
    assert not str_to_bool("0")
    assert not str_to_bool("f")
    assert not str_to_bool("y")
    assert not str_to_bool("n")
    try:
        str_to_bool("shshshshshshs")
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-24 04:42:38.034115
# Unit test for function str_to_bool
def test_str_to_bool():
    from pytest import raises
    from .test_utils import random_string

    raises(ValueError, str_to_bool, random_string())
    assert isinstance(str_to_bool("y"), bool)
    assert isinstance(str_to_bool("yes"), bool)
    assert isinstance(str_to_bool("yep"), bool)
    assert isinstance(str_to_bool("yup"), bool)
    assert isinstance(str_to_bool("t"), bool)
    assert isinstance(str_to_bool("true"), bool)
    assert isinstance(str_to_bool("on"), bool)
    assert isinstance(str_to_bool("enable"), bool)
    assert isinstance(str_to_bool("enabled"), bool)
    assert isinstance(str_to_bool("1"), bool)

# Generated at 2022-06-24 04:42:45.039249
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import types  # noqa
    import tempfile  # noqa

    import pytest  # noqa
    from pytest import raises  # noqa

    from sanic.helpers import load_module_from_file_location  # noqa

    with raises(
        LoadFileException,
        match=(
            "The following environment variables are not set: "
            "some_not_defined_env_var"
        ),
    ):
        load_module_from_file_location(
            "some_module_name",
            "/some/path/${some_not_defined_env_var}",
        )

    with raises(
        LoadFileException,
        match=(
            "The following environment variables are not set: "
            "some_not_defined_env_var"
        ),
    ):
        load_module_

# Generated at 2022-06-24 04:42:48.605711
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Yes") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("No") == False
    assert str_to_bool("no") == False

# Generated at 2022-06-24 04:42:58.443724
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True, "str_to_bool('true') != True"
    assert str_to_bool("yes") is True, "str_to_bool('yes') != True"
    assert str_to_bool("1") is True, "str_to_bool('1') != True"
    assert str_to_bool("TrUe") is True, "str_to_bool('TrUe') != True"
    assert str_to_bool("E") is True, "str_to_bool('E') != True"
    assert str_to_bool("yeS") is True, "str_to_bool('yeS') != True"
    assert str_to_bool("no") is False, "str_to_bool('no') != False"

# Generated at 2022-06-24 04:43:05.366558
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("Enable") is True
    assert str_to_bool(" t ") is True

    assert str_to_bool("False") is False
    assert str_to_bool("no") is False
    assert str_to_bool(" OFF ") is False
    assert str_to_bool(" 0 ") is False

    try:
        str_to_bool("7")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-24 04:43:16.826072
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def test_load_module_from_file_location_from_file_path(
        file_path: str,
        expected_configuration_variable_name: str,
        expected_configuration_variable_value: Union[str, int, bool],
    ):
        path_to_config_file = Path(__file__).parent.parent / file_path
        configuration = load_module_from_file_location(path_to_config_file)
        assert hasattr(
            configuration, expected_configuration_variable_name
        ), "We expect that configuration will have attribute " + expected_configuration_variable_name
        configuration_variable_value = getattr(
            configuration, expected_configuration_variable_name
        )
        assert configuration_variable_value == expected_configuration_variable_value, "We expect that " + expected_

# Generated at 2022-06-24 04:43:28.124309
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import shutil
    import tempfile
    import unittest


# Generated at 2022-06-24 04:43:35.117042
# Unit test for function str_to_bool
def test_str_to_bool():
    input_values = [
        "y", "yes", "yep", "yup", "t", "true", "on", "enable", "enabled", "1"
    ]
    for val in input_values:
        assert str_to_bool(val) == True
    input_values = [
        "n", "no", "f", "false", "off", "disable", "disabled", "0", "aaaaaaaa"
    ]
    for val in input_values:
        try:
            str_to_bool(val)
        except ValueError:
            pass
        except Exception as e:
            raise e

# Generated at 2022-06-24 04:43:43.283363
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = Path("tests/testing_config.py")
    module = load_module_from_file_location(location)
    assert module.TEST_KEY == "TEST_VALUE"

    os_environ["TEST_VALUE"] = "TEST"
    module = load_module_from_file_location("$TEST_VALUE/testing_config.py")
    assert module.TEST_KEY == "TEST_VALUE"

# Generated at 2022-06-24 04:43:50.490956
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import pytest
    from pathlib import Path


# Generated at 2022-06-24 04:43:59.020477
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    os_environ["test_env_var"] = "test_value"

    module = load_module_from_file_location(
        "tests/test_load_module_from_file_location.py"
    )
    assert module.test_var == 42

    module = load_module_from_file_location(
        Path(__file__).parent / "test_load_module_from_file_location.py"
    )
    assert module.test_var == 42

    module = load_module_from_file_location(
        Path(__file__).parent / "test_load_module_from_file_location.py"
    )
    assert module.test_var == 42


# Generated at 2022-06-24 04:44:09.349305
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os
    import tempfile
    import unittest
    from os import environ as os_environ
    from os.path import basename, splitext
    from pathlib import Path
    from sanic.compat import PY_35
    from sanic.exceptions import LoadFileError
    from sanic.helpers import load_module_from_file_location

    def delete_module_from_sys_modules(module_name: str):
        """Delete module from sys.modules."""
        if module_name in sys.modules:
            del sys.modules[module_name]


# Generated at 2022-06-24 04:44:19.855979
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ
    from pathlib import Path

    location = "import foo; foo.bar = 42; foo.bar2 = (1,2,3)"

    # A) By location  (string format)
    with TemporaryDirectory() as tmpdir:

        with open(Path(tmpdir, "temp_config.py"), "w") as temp_config_file:
            temp_config_file.write(location)
        location = Path(tmpdir, "temp_config.py")

        loaded_module = load_module_from_file_location(location)

        assert loaded_module.bar == 42
        assert loaded_module.bar2 == (1, 2, 3)

    # B) By location  (path format)

# Generated at 2022-06-24 04:44:28.547022
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("Y")
    assert str_to_bool("YES")
    assert str_to_bool("YEP")
    assert str_to_bool("ON")
    assert str_to_bool("ENABLE")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("off")
    assert not str_to_bool("N")
    assert not str_to_bool("NO")
    assert not str_to_bool("OFF")

# Generated at 2022-06-24 04:44:33.641509
# Unit test for function str_to_bool
def test_str_to_bool():
    # Should return True
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    # Should return False
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")

# Generated at 2022-06-24 04:44:42.148876
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("Yep") == True
    assert str_to_bool("YEP") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("Yup") == True

# Generated at 2022-06-24 04:44:44.547813
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "./tests/test_config.py"
    module = load_module_from_file_location(location)
    assert hasattr(module, "TEST_KEY_1")



# Generated at 2022-06-24 04:44:52.769700
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Successful cases
    # ----------------

    # 1) load_module_from_file_location from path string
    #    with environment variable (just str)
    import sanic.config

    sanic.config.example_key = "example_value"
    os_environ["some_env_var_name"] = "testing/folder"
    path_to_file = "${some_env_var_name}/sanic/config.py"

    loaded_module = load_module_from_file_location(path_to_file)
    assert loaded_module.example_key == "example_value"

    # 2) load_module_from_file_location from path string
    #    with environment variable (str and Path)
    os_environ["some_env_var_name"] = "testing/folder"
    path_

# Generated at 2022-06-24 04:45:02.635401
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from shutil import copyfile, rmtree
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
        config_file = tmpdirname / "config_file.py"
        config_file_content = """
        a = 1
        b = 2
        """
        file_to_be_imported = tmpdirname / "file_to_be_imported.py"
        file_to_be_imported_content = """
        c = 3
        d = 4
        """

        copyfile("tests/unit/config_uberspace.py", config_file)
        copyfile("tests/unit/file_to_be_imported.py", file_to_be_imported)

        tmp_config = load_module_

# Generated at 2022-06-24 04:45:12.580749
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("enable") == True
    assert str_to_bool("on") == True
    assert str_to_bool("true") == True
    assert str_to_bool("1") == True
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True

    assert str_to_bool("disable") == False
    assert str_to_bool("off") == False
    assert str_to_bool("false") == False
    assert str_to_bool("0") == False
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False