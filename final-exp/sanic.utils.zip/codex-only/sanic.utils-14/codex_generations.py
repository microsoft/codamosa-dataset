

# Generated at 2022-06-24 04:35:04.922038
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile, sys

    def temp_create_file(*args, **kwargs):
        with tempfile.NamedTemporaryFile(*args, **kwargs) as f:
            f.write(b"# -*- coding: utf-8 -*-\n"
                    b'__version__ = "1.0.0"\n'
                    b'key = "value"')
            return f.name

    def temp_create_py_file(*args, **kwargs):
        with tempfile.NamedTemporaryFile(*args, **kwargs) as f:
            f.write(b"# -*- coding: utf-8 -*-\n"
                    b'__version__ = "1.0.0"\n'
                    b'key = "value"')
            _, name = os.path

# Generated at 2022-06-24 04:35:10.278478
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("t") == True
    assert str_to_bool("1") == True

    assert str_to_bool("false") == False
    assert str_to_bool("False") == False
    assert str_to_bool("f") == False
    assert str_to_bool("0") == False

    try:
        assert str_to_bool("foo") is True
    except ValueError:
        pass



# Generated at 2022-06-24 04:35:22.180780
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("on") is True
    assert str_to_bool("y") is True
    assert str_to_bool("1") is True
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("no") is False
    assert str_to_bool("0") is False
    assert str_to_bool("yep") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("True") is True
    assert str_to_bool("YEP") is True
    assert str_to_bool("nope") is False
    assert str_to_bool("NO") is False
    assert str_to_bool("False") is False


# Generated at 2022-06-24 04:35:27.117922
# Unit test for function str_to_bool

# Generated at 2022-06-24 04:35:31.454027
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Unit test for function load_module_from_file_location
    """
    from .test_config import valid_conf
    from .test_config import invalid_conf
    from .test_config import importable_conf

    assert load_module_from_file_location(valid_conf,)
    assert load_module_from_file_location(invalid_conf,)
    assert load_module_from_file_location(importable_conf)

# Generated at 2022-06-24 04:35:40.241543
# Unit test for function str_to_bool
def test_str_to_bool():
    data = [
        ("Y", True),
        ("TRUE", True),
        ("ON", True),
        ("YES", True),
        ("YU", True),
        ("T", True),
        ("N", False),
        ("F", False),
        ("OFF", False),
        ("FALSE", False),
        ("NU", False),
        ("O", False),
    ]
    for (i, o) in data:
        assert str_to_bool(i) == o



# Generated at 2022-06-24 04:35:48.701429
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("true") is True
    assert str_to_bool("1") is True
    assert str_to_bool("yeS") is True
    assert str_to_bool("yES") is True
    assert str_to_bool("YEs") is True
    assert str_to_bool("YeS") is True
    assert str_to_bool("TRUe") is True
    assert str_to_bool("TRUE1") is True
    assert str_to_bool("trUE1") is True
    assert str_to_bool("yes1") is True
    assert str_to_bool("yes") is True
    assert str_to

# Generated at 2022-06-24 04:35:52.334024
# Unit test for function str_to_bool
def test_str_to_bool():
    str_to_bool("True")
    str_to_bool("false")
    str_to_bool("FALSE")
    str_to_bool("Yep")
    str_to_bool("n")
    with pytest.raises(ValueError):
        str_to_bool("super True")
    with pytest.raises(ValueError):
        str_to_bool("not True")
    with pytest.raises(ValueError):
        str_to_bool("not False")

# Generated at 2022-06-24 04:36:03.692295
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    def get_next_tmp_file():
        _, tmp_file = tempfile.mkstemp()
        return tmp_file

    tmp_file_a = get_next_tmp_file()
    tmp_file_b = get_next_tmp_file()

    # `a` is a module from the local file that contains only one int
    # variable equal to 5.
    # `b` is a module from the local file that contains only one text
    # variable equal to "text".
    with open(tmp_file_a, "w+") as f:
        f.write("a = 5")
    with open(tmp_file_b, "w+") as f:
        f.write('b = r"text"')


# Generated at 2022-06-24 04:36:09.108417
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("TRue") == True
    assert str_to_bool("on") == True
    assert str_to_bool("1") == True
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("YUP") == True

    assert str_to_bool("false") == False
    assert str_to_bool("off") == False
    assert str_to_bool("f") == False
    assert str_to_bool("no") == False
    assert str_to_bool("0") == False
    assert str_to_bool("n") == False

    assert str_to_bool("hello")

# Generated at 2022-06-24 04:36:17.836455
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('y') is True
    assert str_to_bool('Yes') is True
    assert str_to_bool('yep') is True
    assert str_to_bool('Yup') is True
    assert str_to_bool('t') is True
    assert str_to_bool('true') is True
    assert str_to_bool('on') is True
    assert str_to_bool('1') is True
    assert str_to_bool('n') is False
    assert str_to_bool('no') is False
    assert str_to_bool('f') is False
    assert str_to_bool('false') is False
    assert str_to_bool('off') is False
    assert str_to_bool('0') is False

# Generated at 2022-06-24 04:36:25.123984
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    # A) Import module from file without provided path.
    os.environ["some_env_var_for_testing"] = "some_path_1"
    os.environ["some_env_var_for_testing_2"] = "some_path_2"
    module_1 = load_module_from_file_location(
        "some_module_name",
        "/some/path/${some_env_var_for_testing}/${some_env_var_for_testing_2}",
    )
    assert(module_1.__name__ == "some_module_name")

    # B) Import module from file with provided path.
    path = Path(__file__).parent
    module_2 = load_module_from_file_location(path / "some_module_name.py")

# Generated at 2022-06-24 04:36:34.150419
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from tempfile import TemporaryDirectory

    from pytest import mark  # noqa

    from sanic.config import Config

    @mark.asyncio
    async def test_working_location():
        with TemporaryDirectory() as tmp_dir:
            conf = Config()
            conf.load_module_from_file_location = load_module_from_file_location
            conf.load_config_file(
                location=Path(tmp_dir) / "some_config_file.py",
                extra="some_extra_kwarg",
            )
            assert conf.extra == "some_extra_kwarg"

    @mark.asyncio
    async def test_wrong_location():
        with TemporaryDirectory() as tmp_dir:
            conf = Config()
            conf.load_module_from_file_location = load_module_from_

# Generated at 2022-06-24 04:36:41.631559
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("true") == True
    assert str_to_bool("1") == True
    assert str_to_bool("y") == True

    assert str_to_bool("no") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False
    assert str_to_bool("0") == False
    assert str_to_bool("n") == False

    try:
        str_to_bool("sdfsdfsdfs")
    except ValueError:
        pass

# Generated at 2022-06-24 04:36:46.495905
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    module_to_import = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )

    assert module_to_import is not None

    module_to_import = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )

    assert module_to_import is not None

# Generated at 2022-06-24 04:36:54.418586
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = (
        "sanic.exceptions.test_load_module_from_file_location.test_file.py"
    )
    # A) Check if file was loaded
    module = load_module_from_file_location(location)
    assert module.__name__ == "test_file"
    assert module.test_variable == "OK"

    # B) Check if environment variable was substuited
    os_environ["some_var"] = "test"
    location = "sanic.exceptions.${some_var}.test_file.py"
    module = load_module_from_file_location(location)
    assert module.__name__ == "test_file"
    assert module.test_variable == "OK"

    # C) Check if exception is raised if one of variables does not exists

# Generated at 2022-06-24 04:37:00.392129
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("y") == True
    assert str_to_bool("T") == True
    assert str_to_bool("t") == True
    assert str_to_bool("True") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("On") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_

# Generated at 2022-06-24 04:37:12.151298
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys
    import tempfile
    import pytest
    import importlib

    # Copy some_module.py to temporary directory.
    test_module_path = Path(__file__).parent / "some_module.py"
    with tempfile.TemporaryDirectory() as tmp_dir:
        os.chdir(tmp_dir)
        tmp_module_path = Path(tmp_dir) / "some_module.py"
        test_module_path.copy(tmp_module_path)

        # Import some_module.py with function.
        sys.path.append(tmp_dir)
        loaded_module = load_module_from_file_location(tmp_module_path)
        assert hasattr(loaded_module, "some_var")

        # Import some_module.py with normal import.
        normal

# Generated at 2022-06-24 04:37:15.404630
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    with pytest.raises(ValueError):
        str_to_bool("invalid_bool")
    assert str_to_bool("true") is True
    assert str_to_bool("1") is True
    assert str_to_bool("false") is False
    assert str_to_bool("-1") is False



# Generated at 2022-06-24 04:37:24.217955
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") == True
    assert str_to_bool("t") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("1") == True
    assert str_to_bool("TRUE") == True

    assert str_to_bool("False") == False
    assert str_to_bool("f") == False
    assert str_to_bool("N") == False
    assert str_to_bool("0") == False
    assert str_to_bool("FALSE") == False

    try:
        str_to_bool("Tru")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-24 04:37:33.142682
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    _location = Path(
        "/path/to/${some_env_var}/${some_env_var}"
        "/${to_file}/${some_env_var}/${some_env_var}"
        "/${some_env_var}.py"
    )
    _dict = {
        "some_env_var": "test",
        "to_file": "test/test",
    }
    _res = load_module_from_file_location(_location, **_dict)
    assert (
        _res.some_env_var
        == "/path/to/test/test/test/test/test/test.py"
    )

# Generated at 2022-06-24 04:37:39.680765
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    with pytest.raises(LoadFileException):
        load_module_from_file_location("some_module_name", "not_existing_path")

    with pytest.raises(LoadFileException):
        load_module_from_file_location("some_module_name", "not_existing_path.py")

    with pytest.raises(ValueError) as excinfo:
        str_to_bool("sdasd")
    assert "Invalid truth value sdasd" in str(excinfo.value)
    assert "Invalid truth value sdasd" in str(excinfo.value)

# Generated at 2022-06-24 04:37:50.073416
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_to_test_files = Path(__file__).parent / "files"

    # 1. Test whether given full path to the file is ok
    module = load_module_from_file_location(
        path_to_test_files / "config.py"
    )
    assert "MY_CONFIG_VAR_1" in dir(module)

    # 2. Test whether given full path to the directory is ok
    module = load_module_from_file_location(path_to_test_files)
    assert "MY_CONFIG_VAR_2" in dir(module)

    # 3. Test whether given path with env_vars is ok
    os_environ["SANIC_TEST_PATH_ENV_VAR"] = str(path_to_test_files)
    module = load_module_from

# Generated at 2022-06-24 04:38:01.159251
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import logging
    import os
    import pytest
    import re
    import tempfile

    from sanic.exceptions import LoadFileException
    from sanic.helpers import load_module_from_file_location
    from sanic.log import error_logger

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    location = "/some/path/${some_env_var}"
    env_vars_in_location = set(re.findall(r"\${(.+?)}", location))
    assert env_vars_in_location == {"some_env_var"}

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(os.environ.keys())

# Generated at 2022-06-24 04:38:10.792577
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with pytest.raises(ValueError) as e:
        load_module_from_file_location(3)
    assert str(e.value) == "location should be of type str or bytes or Path"
    with pytest.raises(ValueError) as e:
        load_module_from_file_location("abc", encoding="abc")
    assert str(e.value) == (
        "encoding encoding is not supported by "
        "your Python interpreter. Try one of: "
    )
    with pytest.raises(ImportError):
        load_module_from_file_location("abc")
    assert test_load_module_from_file_location.__doc__ is not None

# Generated at 2022-06-24 04:38:19.435955
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests if load_module_from_file_location function works as expected."""
    location = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "test_settings.py"
    )
    expected_module = types.ModuleType("config")
    expected_module.__file__ = location
    expected_module.TEST_SETTINGS = True
    config_module = load_module_from_file_location(location)
    assert expected_module.__file__ == config_module.__file__
    assert expected_module.TEST_SETTINGS == config_module.TEST_SETTINGS

    config_module = load_module_from_file_location(
        f"sanic.{__name__}.test_settings"
    )
    assert expected_

# Generated at 2022-06-24 04:38:29.679478
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    from pytest import raises

    assert str_to_bool('y') is True
    assert str_to_bool('yes') is True
    assert str_to_bool('Yep') is True
    assert str_to_bool('Y') is True
    assert str_to_bool('Yup') is True
    assert str_to_bool('YUP') is True
    assert str_to_bool('t') is True
    assert str_to_bool('T') is True
    assert str_to_bool('True') is True
    assert str_to_bool('True') is True
    assert str_to_bool('On') is True
    assert str_to_bool('ON') is True
    assert str_to_bool('Enable') is True
    assert str_to_bool('enable') is True
    assert str_

# Generated at 2022-06-24 04:38:41.253365
# Unit test for function str_to_bool
def test_str_to_bool():

    assert str_to_bool("yes")
    assert str_to_bool("Yes")
    assert str_to_bool("YES")

    assert str_to_bool("ye")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("T")
    assert str_to_bool("TRUE")
    assert str_to_bool("on")
    assert str_to_bool("on")
    assert str_to_bool("1")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("Enable")

    assert not str_to_bool("no")
    assert not str_to_bool

# Generated at 2022-06-24 04:38:51.795869
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yEs") == True
    assert str_to_bool("ENABLED") == True
    assert str_to_bool("True") == True
    assert str_to_bool("oN") == True
    assert str_to_bool("1") == True

    assert str_to_bool("nO") == False
    assert str_to_bool("OFF") == False
    assert str_to_bool("false") == False
    assert str_to_bool("0") == False

    try:
        str_to_bool("maybe")
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-24 04:38:59.897939
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("0") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False
    assert str_to_bool("disabled") is False

# Generated at 2022-06-24 04:39:10.227317
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test for function load_module_from_file_location"""
    from .test_utils import MODULE_FILE_NAME, MODULE_NAME

    # A) Module from string.
    loaded_module = load_module_from_file_location(MODULE_NAME)
    assert (
        loaded_module.SOME_STR
        == os_environ["SOME_ENV_VAR"] + " this is some string"
    )

    # B) Module from file.
    loaded_module = load_module_from_file_location(MODULE_FILE_NAME)
    assert (
        loaded_module.SOME_STR
        == os_environ["SOME_ENV_VAR"] + " this is some string"
    )
    assert loaded_module.__file__ == MODULE_FILE_NAME

    # C) Module from

# Generated at 2022-06-24 04:39:17.154446
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TESTING_ENV_VAR"] = "testing_env_value"

# Generated at 2022-06-24 04:39:29.550430
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    if os_environ.get("TEST_ENV_VAR"):
        del os_environ["TEST_ENV_VAR"]


# Generated at 2022-06-24 04:39:34.290637
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") == True
    assert str_to_bool("True") == True
    assert str_to_bool("On") == True
    assert str_to_bool("N") == False
    assert str_to_bool("No") == False
    assert str_to_bool("F") == False
    with pytest.raises(ValueError):
        str_to_bool("ABC")
    with pytest.raises(ValueError):
        str_to_bool("")



# Generated at 2022-06-24 04:39:40.260758
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("on") == True
    assert str_to_bool("off") == False
    assert str_to_bool("false") == False
    assert str_to_bool("true") == True
    assert str_to_bool("yeS") == True
    assert str_to_bool("T") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("0") == False
    assert str_to_bool("1") == True

# Generated at 2022-06-24 04:39:49.680138
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check module from path works properly
    test_module_path = Path(__file__).parent / "test_module.py"
    test_module_from_path = load_module_from_file_location(test_module_path)
    assert test_module_from_path.TEST_CONFIG_KEY == "test config value"
    assert test_module_from_path.TEST_CONFIG_KEY_2 == 1234

    # B) Check module from path with env vars works properly
    os_environ["TEST_ENV_VAR"] = "test_module.py"
    test_module_path_with_env_vars = Path(__file__).parent / "${TEST_ENV_VAR}"
    test_module_from_path_with_env_vars = load_module

# Generated at 2022-06-24 04:39:58.456479
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location("/some/non/existing/path")
    except LoadFileException as e:
        assert (
            "Unable to load configuration file: "
            "No such file or directory" in str(e)
        )
    try:
        load_module_from_file_location("/some/non/existing/path/config.py")
    except LoadFileException as e:
        assert (
            "Unable to load configuration file: "
            "No such file or directory" in str(e)
        )

# Generated at 2022-06-24 04:40:05.697824
# Unit test for function str_to_bool
def test_str_to_bool():

    # True values
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yEs") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("Yup") == True
    assert str_to_bool("YUP") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("t") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool

# Generated at 2022-06-24 04:40:15.096085
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """This test is working only if You have some_config file
    in Your project root directory"""
    os_environ["test_env_var"] = "test_value"
    from sanic.config import load_module_from_file_location

    # A) Test with file name
    assert load_module_from_file_location(
        "test_module_from_file_location.py"
    ).test_variable == "test_value"
    # B) Test with relative path
    assert load_module_from_file_location(
        "./test_module_from_file_location.py"
    ).test_variable == "test_value"
    # C) Test with absolute path

# Generated at 2022-06-24 04:40:26.433220
# Unit test for function str_to_bool
def test_str_to_bool():
    expected_valid_values = [
        ("y", True),
        ("yes", True),
        ("yep", True),
        ("yup", True),
        ("t", True),
        ("true", True),
        ("on", True),
        ("enable", True),
        ("enabled", True),
        ("1", True),
        ("n", False),
        ("no", False),
        ("f", False),
        ("false", False),
        ("off", False),
        ("disable", False),
        ("disabled", False),
        ("0", False),
    ]

    for value in expected_valid_values:
        assert str_to_bool(value[0]) == value[1]

# Generated at 2022-06-24 04:40:35.055048
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    current_directory = os.path.dirname(os.path.abspath(__file__))
    config = os.path.join(current_directory, "config.py")

    # Check if config.py is loaded properly using function
    # defined in this file
    config_module = load_module_from_file_location(config)
    assert hasattr(config_module, "MY_CONSTANT")
    assert config_module.MY_CONSTANT == 10

    # Check if config.py is loaded properly using function imported
    # from sanic module
    config_module = import_string(config)
    assert hasattr(config_module, "MY_CONSTANT")
    assert config_module.MY_CONSTANT == 10

# Generated at 2022-06-24 04:40:43.789124
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Ensure that we can load module provided as file path.
    assert isinstance(  # noqa
        load_module_from_file_location(
            "tests.integration.app_factory_tests.app_factory_module"
        ),
        types.ModuleType,
    )

    # Ensure that we can also load module provided as file path,
    # but as pathlib.Path object.
    assert isinstance(  # noqa
        load_module_from_file_location(
            Path(
                "tests/integration/app_factory_tests/app_factory_module.py"
            )
        ),
        types.ModuleType,
    )

    # Ensure that we can load module provided as file content.

# Generated at 2022-06-24 04:40:56.957305
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from importlib import reload

    from tempfile import NamedTemporaryFile

    from .test_utils import assert_raises

    # File content creating
    with NamedTemporaryFile(mode="w") as tmp_py_1:
        tmp_py_1.write("_var_1 = 'test_conf'")
        tmp_py_1.seek(0)
        # Loading
        module = load_module_from_file_location(tmp_py_1.name)
        # Testing
        assert module._var_1 == "test_conf"

    # File content creating
    with NamedTemporaryFile(mode="w") as tmp_py_2:
        tmp_py_2.write("_var_2 = 'test_conf'")
        tmp_py_2.seek(0)
        # Loading
        module = import_string

# Generated at 2022-06-24 04:41:04.456859
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests sanic.config.load_module_from_file_location"""

    def load_module_and_assert_values(
        location: Union[bytes, str, Path],
        encoding: str = "utf8",
        *args,
        **kwargs
    ):  # noqa
        module = load_module_from_file_location(
            location, encoding, *args, **kwargs
        )
        assert module.name == "John"
        assert module.age == 30
        assert module.address is None
        assert module.planet == "Earth"
        assert module.environment == {
            "SANIC_CONFIG": "config.yaml",
            "SANIC_PORT": "80",
        }

# Generated at 2022-06-24 04:41:16.126799
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.

    os_environ["ROOT_DIR"] = "."
    os_environ["CONFIG_DIR"] = "tests/configs"
    os_environ["CONFIG_FILE_NAME"] = "config.py"
    module = load_module_from_file_location(
        "${ROOT_DIR}/${CONFIG_DIR}/${CONFIG_FILE_NAME}"
    )
    assert module.TEST_KEY == "TEST_VALUE"

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    #

# Generated at 2022-06-24 04:41:21.839365
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("unittest", "tests/unittest.py")
    assert load_module_from_file_location("unittest", Path("tests/unittest.py"))


# Generated at 2022-06-24 04:41:33.064195
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("on") == True
    assert str_to_bool("On") == True
    assert str_to_bool("oN") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yEs") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("1") == True
    assert str_to_bool("off") == False
    assert str_to_bool("OFF") == False
   

# Generated at 2022-06-24 04:41:44.001851
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("ENABLED") == True
    assert str_to_bool("1") == True
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("asd") == True

    assert str_to_bool("N") == False
    assert str_to_bool("NO") == False


# Generated at 2022-06-24 04:41:51.033517
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("On") == True
    assert str_to_bool("off") == False
    assert str_to_bool("yup") == True
    assert str_to_bool("f") == False
    assert str_to_bool("yes") == True
    assert str_to_bool("0") == False
    assert str_to_bool("1") == True


# Generated at 2022-06-24 04:42:02.165438
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert str_to_bool("yes")
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("on")
    assert str_to_bool("On")
    assert str_to_bool("ON")
    assert str_to_bool("1")
    assert str_to_bool("yup")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert not str_to_bool("false")
    assert not str_to_bool("False")
    assert not str_to_

# Generated at 2022-06-24 04:42:11.280931
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("yEP") == True
    assert str_to_bool("Yup") == True
    assert str_to_bool("True") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("1") == True
    assert str_to_bool("O") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("Enable") == True
   

# Generated at 2022-06-24 04:42:21.612713
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("T") is True
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("on") is True
    assert str_to_bool("On") is True
    assert str_to_bool("enable") is True
   

# Generated at 2022-06-24 04:42:31.402003
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import random # noqa

    # 1. Test using filename string.
    try:
        import_me_1 = str(tempfile.NamedTemporaryFile(mode="w+").name)

        with open(import_me_1, "w+") as fp:
            fp.write("x = True")
        imported_module = load_module_from_file_location(import_me_1)
        assert imported_module.x
    finally:
        try:
            os.remove(import_me_1)
        except FileNotFoundError:
            pass

    # 2. Test using filename string with env variables.

# Generated at 2022-06-24 04:42:40.443368
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from os import environ
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from pytest import raises, mark
    from yaml import dump, safe_load

    from sanic.exceptions import LoadFileException

    with raises(LoadFileException):
        load_module_from_file_location(
            "test_name",
            "/some/path/${not_exist_env_var}",
            submodule_search_locations=[]
        )

    with TemporaryDirectory() as tmp_dir:
        module_name = "test_config"
        module_file_name = "test_config.py"
        module_path = Path(tmp_dir) / module_file_name

# Generated at 2022-06-24 04:42:50.905154
# Unit test for function str_to_bool
def test_str_to_bool():
    if str_to_bool("y") is not True:
        raise AssertionError()
    if str_to_bool("true") is not True:
        raise AssertionError()
    if str_to_bool("yes") is not True:
        raise AssertionError()
    if str_to_bool("1") is not True:
        raise AssertionError()

    if str_to_bool("n") is not False:
        raise AssertionError()
    if str_to_bool("false") is not False:
        raise AssertionError()
    if str_to_bool("no") is not False:
        raise AssertionError()
    if str_to_bool("0") is not False:
        raise AssertionError()

# Generated at 2022-06-24 04:42:58.483436
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Tests load_module_from_file_location function
    """
    import tempfile
    from os import environ as os_environ
    from textwrap import dedent
    from pathlib import Path
    from sanic.helpers import load_module_from_file_location

    def test_module_from_module_name():
        some_module = load_module_from_file_location("collections")
        assert some_module == collections

    def test_module_from_module_name_with_dots():
        some_module = load_module_from_file_location("os.path")
        assert some_module == os.path

    def test_module_from_path():
        some_module = load_module_from_file_location("tests.helpers.test_helpers")
        assert some_module

# Generated at 2022-06-24 04:43:02.060368
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        os.path.join(os.path.dirname(__file__), "test.py")
    )
    assert module.test == "test_success"

# Generated at 2022-06-24 04:43:11.016409
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test that function load_module_from_file_location works as expected."""
    from tempfile import NamedTemporaryFile
    from random import randrange

    # Save environment variables,
    # so we can reset them after testing this function.
    saved_env = os.environ


# Generated at 2022-06-24 04:43:18.227718
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") == True
    assert str_to_bool("t") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("0") == False
    assert str_to_bool("f") == False
    assert str_to_bool("FALSE") == False

# Generated at 2022-06-24 04:43:28.564882
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SANIC_TEST_LOAD_CONFIG_ENV_VAR"] = "test_env_var_value"
    # 1) Test the simplest case.
    file_with_config = Path(__file__).parent / "file_with_config.py"
    loaded_module = load_module_from_file_location(file_with_config)
    assert loaded_module.SOME_CONFIG == 123

    # 2) Test that function can use raw paths
    loaded_module = load_module_from_file_location(str(file_with_config))
    assert loaded_module.SOME_CONFIG == 123

    # 3) Test that function can resolve environment variables in Path() object
    #    and raw path.

# Generated at 2022-06-24 04:43:34.998227
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('y') == True
    assert str_to_bool('yes') == True
    assert str_to_bool('t') == True
    assert str_to_bool('true') == True
    assert str_to_bool('on') == True
    assert str_to_bool('enable') == True

    assert str_to_bool('n') == False
    assert str_to_bool('no') == False
    assert str_to_bool('f') == False
    assert str_to_bool('false') == False
    assert str_to_bool('off') == False
    assert str_to_bool('disable') == False

    try:
        str_to_bool('yep') == False
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 04:43:46.830155
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert isinstance(
        load_module_from_file_location(__file__, "utf8"), types.ModuleType
    )

    # Check if environment variables substituted
    assert os_environ.get("TEST_ENV_VAR_FOR_UNIT_TESTS")
    assert "{TEST_ENV_VAR_FOR_UNIT_TESTS}" not in __file__
    assert (
        "${TEST_ENV_VAR_FOR_UNIT_TESTS}"
        in __file__.replace("{TEST_ENV_VAR_FOR_UNIT_TESTS}", "$")
    )

# Generated at 2022-06-24 04:43:58.410415
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-24 04:44:09.327035
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Verify that str_to_bool() can work with ints.
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    # Case insensitive.
    assert str_to_bool("yEs") is True
    assert str_to_bool("no") is False
    # Raise exception for unsupported values.
    with pytest.raises(ValueError) as e:
        str_to_bool("ok")
    assert str(e.value) == "Invalid truth value ok"

    # Verify that function load_module_from_file_location works as expected.
    # A) Check that function works as expected in normal situation.
    module = load_module_from_file_location(
        "sanic.__main__", "./sanic/__main__.py"
    )
   

# Generated at 2022-06-24 04:44:18.625772
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("YeS") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("Yep") == True
    assert str_to_bool("YeP") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("Yup") == True
    assert str_to_bool("YUp") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("true") == True

# Generated at 2022-06-24 04:44:27.850197
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yup") == True
    assert str_to_bool(u"True") == True
    assert str_to_bool(b"1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool(u"F") == False
    assert str_to_bool(b"0") == False

    try:
        assert str_to_bool("yay")
    except ValueError as err:
        assert str(err) == "Invalid truth value yay"
    else:
        assert False

# Generated at 2022-06-24 04:44:37.150530
# Unit test for function str_to_bool
def test_str_to_bool():
    def test_go(val, expected_bool):
        assert(str_to_bool(val) == expected_bool)

    test_go("y", True)
    test_go("yes", True)
    test_go("yep", True)
    test_go("yup", True)
    test_go("t", True)
    test_go("true", True)
    test_go("on", True)
    test_go("enable", True)
    test_go("enabled", True)
    test_go("1", True)
    
    test_go("n", False)
    test_go("no", False)
    test_go("f", False)
    test_go("false", False)
    test_go("off", False)
    test_go("disable", False)

# Generated at 2022-06-24 04:44:44.918911
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:44:52.964608
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os.path import dirname, join
    from types import ModuleType
    from unittest import TestCase

    # Test 1. Simple test.
    module_path = join(dirname(__file__), "test_app.py")
    module = load_module_from_file_location(module_path)

    assert isinstance(module, ModuleType)
    assert hasattr(module, "app")

    # Test 2. Test with real path.
    module_path = Path(join(dirname(__file__), "test_app.py"))
    module = load_module_from_file_location(module_path)

    assert isinstance(module, ModuleType)
    assert hasattr(module, "app")

    # Test 3. Test with bytes.

# Generated at 2022-06-24 04:45:02.660641
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("t") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("1") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("on") is True

    assert str_to_bool("False") is False
    assert str_to_bool("FALSE") is False
    assert str_to_bool("f") is False
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("0") is False
    assert str_to_bool("disabled") is False