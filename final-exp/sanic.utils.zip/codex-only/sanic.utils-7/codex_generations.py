

# Generated at 2022-06-24 04:35:09.149086
# Unit test for function str_to_bool
def test_str_to_bool():
    for string_val in {"1", "0", "True", "False", "true", "false", "n", "y"}:
        assert str_to_bool(string_val) == eval(string_val)

    error = False
    try:
        str_to_bool("None")
    except ValueError:
        error = True
    assert error



# Generated at 2022-06-24 04:35:14.296636
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unit test for function load_module_from_file_location."""
    import os

    location = "sanic/websocket.py"  # It exists
    module = load_module_from_file_location(location)
    assert module.module_name == "sanic.websocket"

    location = "sanic/some_unknown_module.py"  # It doesn't exist
    try:
        module = load_module_from_file_location(location)
    except PyFileError as e:
        assert (
            str(e) == "Exception occurred while trying to load "
            f"the file at `{location}`."
        )

    location = "${HOME}/test"  # It exists

# Generated at 2022-06-24 04:35:22.737957
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False
    assert str

# Generated at 2022-06-24 04:35:30.860634
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("T") is True
    assert str_to_bool("True") is True
    assert str_to_bool("On") is True
    assert str_to_bool("Enable") is True
    assert str_to_bool("Enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("N") is False
    assert str_to_bool("No") is False
    assert str_to_bool("F") is False
    assert str_to_bool("False") is False
    assert str_to_bool("Off") is False
    assert str

# Generated at 2022-06-24 04:35:44.738765
# Unit test for function str_to_bool
def test_str_to_bool():
    # True
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("YES")
    assert str_to_bool("yep")
    assert str_to_bool("YUP")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("ENABLED")
    assert str_to_bool("1")

    # False
    assert str_to_bool("n") is False
    assert str_to_bool("N") is False
    assert str_to_bool("NO") is False
    assert str_to_bool("f") is False
    assert str_to_bool("F") is False
   

# Generated at 2022-06-24 04:35:54.987480
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:36:06.193380
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import unittest
    import os
    import tempfile
    from pathlib import Path

    from sanic.helpers import load_module_from_file_location

    # Test when path is given as Path object

    os_environ["SOME_ENV_VAR"] = "test"

    with tempfile.NamedTemporaryFile("w+") as test_file:
        test_file.write("test_module_var = 'test'")
        test_file.seek(0)
        test_module = load_module_from_file_location(Path(test_file.name))
    assert hasattr(test_module, "test_module_var")
    assert test_module.test_module_var == "test"

    # Test when path is string, but contains environment variables.
    # It works when environment variables are in

# Generated at 2022-06-24 04:36:16.618721
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("") == False
    assert str_to_bool("0") == False
    assert str_to_bool("n") == False
    assert str_to_bool("NO") == False
    assert str_to_bool("False") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("disabled") == False
    assert str_to_bool("1") == True
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("True") == True
    assert str

# Generated at 2022-06-24 04:36:22.580908
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    For example You can:

        some_module = load_module_from_file_location(
            "some_module_name",
            "/some/path/${some_env_var}"
        )
    """
    filename = "test_config.py"
    config_file = Path(test_load_module_from_file_location.__module__).parent / filename
    config = load_module_from_file_location(config_file)

    assert config.FOLDER == "/some/path/${HOME}"

# Generated at 2022-06-24 04:36:34.616344
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test 1
    module = load_module_from_file_location(__file__)
    assert module.__file__ == __file__

    # Test 2
    module = load_module_from_file_location(__name__)
    assert module.__name__ == __name__

    # Test 3
    try:
        load_module_from_file_location("$NOT_DEFINED_ENV_VAR")
    except LoadFileException:
        pass
    else:
        raise AssertionError("Not raised when expected")

    # Test 4
    os_environ["some_env_var"] = __name__
    module = load_module_from_file_location("$some_env_var")
    assert module.__name__ == __name__
    del os_environ["some_env_var"]

# Generated at 2022-06-24 04:36:43.898680
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:36:54.125788
# Unit test for function str_to_bool
def test_str_to_bool():
    result = str_to_bool("y")
    assert result == True
    result = str_to_bool("yes")
    assert result == True
    result = str_to_bool("yep")
    assert result == True
    result = str_to_bool("yup")
    assert result == True
    result = str_to_bool("t")
    assert result == True
    result = str_to_bool("true")
    assert result == True
    result = str_to_bool("on")
    assert result == True
    result = str_to_bool("enable")
    assert result == True
    result = str_to_bool("enabled")
    assert result == True
    result = str_to_bool("1")
    assert result == True
    result = str_to_bool("n")
    assert result == False

# Generated at 2022-06-24 04:37:03.597851
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("TRUE")
    assert str_to_bool("True")
    assert not str_to_bool("False")
    assert not str_to_bool("FALSE")
    assert str_to_bool("1")
    assert not str_to_bool("0")
    assert not str_to_bool("False_with_end")
    assert str_to_bool("1_with_end")
    assert not str_to_bool("0_with_end")
    assert str_to_bool("yes")
    assert not str_to_bool("no")

# Generated at 2022-06-24 04:37:12.623024
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("no") == False
    assert str_to_bool("True") == True
    assert str_to_bool("False") == False
    assert str_to_bool("0") == False
    assert str_to_bool("1") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("nope") == False
    assert str_to_bool("False") == False
    assert str_to_bool("true") == True
    assert str_to_bool("n") == False
    assert str_to_bool("y") == True
    assert str_to_bool("off") == False
    assert str_to_bool("on") == True
    assert str_to_bool("t") == True

# Generated at 2022-06-24 04:37:16.288523
# Unit test for function str_to_bool
def test_str_to_bool():
    for s in ("Y", "Yes", "YES", "y", "yes", "YES", "yep", "yup", "True", "TRUE"):
        assert str_to_bool(s) == True

    for s in ("N", "No", "NO", "n", "no", "NO", "False", "FALSE"):
        assert str_to_bool(s) == False

    for s in ("Ye", "yess", "", " ", "2"):
        with pytest.raises(ValueError):
            assert str_to_bool(s)


# Generated at 2022-06-24 04:37:23.203073
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("n") is False
    try:
        assert str_to_bool("maybe")
    except ValueError as e:
        assert str(e) == "Invalid truth value maybe"
        assert isinstance(e, ValueError)
    try:
        assert str_to_bool("True")
    except ValueError as e:
        assert str(e) == "Invalid truth value True"
        assert isinstance(e, ValueError)

# Generated at 2022-06-24 04:37:33.927383
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-24 04:37:41.467630
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("true") is True
    assert str_to_bool("1") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("t") is True
    assert str_to_bool("false") is False
    assert str_to_bool("0") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("yep") is True
    with pytest.raises(ValueError):
        str_to_bool("asdf")

# Generated at 2022-06-24 04:37:49.663453
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Function that tests the load_module_from_file_location method.
    """
    import os

    TEST_PATH = "tests/test_config.py"
    os.environ["TEST_VAR"] = "test"
    TEST_PATH_ENV_VAR = "tests/${TEST_VAR}_config.py"

    module = load_module_from_file_location(TEST_PATH)
    assert module.TEST_CONFIG == "test"

    module = load_module_from_file_location(TEST_PATH_ENV_VAR)
    assert module.TEST_CONFIG == "test"

# Generated at 2022-06-24 04:37:56.565812
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("y") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("1") == True
    assert str_to_bool("no") == False
    assert str_to_bool("n") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("0") == False
    assert str_to_bool("0") == False

# Generated at 2022-06-24 04:38:07.647794
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # testing environment variable substitution
    os_environ["TEST_ENV_VAR"] = "/some/path/to/file"
    os_environ["TEST_ENV_VAR_IN_MIDDLE"] = "/some/path"
    os_environ["TEST_ENV_VAR_IN_BEGIN"] = "/"
    os_environ["TEST_ENV_VAR_WITHOUT_PATH"] = "file"
    os_environ["TEST_ENV_VAR_WITHOUT_PATH_IN_MIDDLE"] = "path"
    os_environ["TEST_ENV_VAR_WITHOUT_PATH_IN_BEGIN"] = "."

    # 1. Testing module import from environment variable
    mod_from_env_var = load_module_

# Generated at 2022-06-24 04:38:17.282399
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """I was unable to mock return value of function
    load_module_from_file_location as it is inside of a function
    call. So instead I used actual function itself and tested it
    that it is able to load module loaded by load_module_from_file_location.

    I used two functions here because in future when this
    test will be removed, but function will be left, it will be
    outcommented.
    """

    import tempfile
    from os import environ as os_environ
    from pathlib import Path

    def test_module(location) -> types.ModuleType:
        """This function is to test if function load_module_from_file_location
        can load module already loaded by
        load_module_from_file_location.
        """

        return load_module_from_file_location(location)

   

# Generated at 2022-06-24 04:38:23.860446
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    with tempfile.NamedTemporaryFile(prefix="test-") as tmp:
        tmp.file.write(b"a = 1")
        tmp.file.seek(0)

        module = load_module_from_file_location(tmp.name)
        assert module.a == 1

        with open(os.devnull, "w") as fnull:
            module = load_module_from_file_location(tmp.name, fnull)
            assert module.a == 1



# Generated at 2022-06-24 04:38:31.073793
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")
    assert not str_to_bool("0")

    assert str_to_bool("YES")
    assert str

# Generated at 2022-06-24 04:38:42.001105
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from os import environ as os_environ
    from pathlib import Path
    from tempfile import TemporaryDirectory as TempDir

    module_name = "some_module_name"
    fn_name = "some_function_name"

    # Case 1)
    module = load_module_from_file_location(module_name)
    assert module.__name__ == module_name

    # Case 2)
    with TempDir() as temp_dir:
        temp_dir_path = Path(temp_dir)
        test_file_path = temp_dir_path / "some_file.py"
        with open(test_file_path, "w") as some_file:
            some_file.write(f"def {fn_name}():\n\tpass")

# Generated at 2022-06-24 04:38:53.690830
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("on") is True
    assert str_to_bool("1") is True

    assert str_to_bool("no") is False
    assert str_to_bool("off") is False
    assert str_to_bool("0") is False

    assert str_to_bool("true") is True
    assert str_to_bool("false") is False
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False

    with pytest.raises(ValueError):
        str_to_bool("y2")
    with pytest.raises(ValueError):
        str_to_bool("no2")
    with pytest.raises(ValueError):
        str_to_bool("1.0")

# Generated at 2022-06-24 04:39:05.094655
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    location = "tests/test_helper_functions.py"

    with pytest.raises(ValueError):
        load_module_from_file_location(location)
    with pytest.raises(ValueError):
        load_module_from_file_location("some_bad_module_name", location)
    with pytest.raises(PyFileError):
        load_module_from_file_location("__init__", location)
    with pytest.raises(PyFileError):
        load_module_from_file_location("tests", location)

    module = load_module_from_file_location("test_helper_functions", location)

    assert module.__name__ == "test_helper_functions"


# Generated at 2022-06-24 04:39:14.089262
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    import pytest

    def test_str_to_bool_result(value: bool):
        if value:
            assert str_to_bool("on")
            assert str_to_bool("1")
            assert str_to_bool("y")
            assert str_to_bool("true")
            assert str_to_bool("yes")
            assert str_to_bool("enabled")
            assert str_to_bool("enable")
            assert str_to_bool("yup")
            assert str_to_bool("yep")
            assert str_to_bool("t")
            assert str_to_bool("ok")
        else:
            assert not str_to_bool("off")
            assert not str_to_bool("0")
            assert not str_to_bool("n")
            assert not str_

# Generated at 2022-06-24 04:39:24.623877
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from os import environ as os_environ, path
    from pathlib import Path

    with TemporaryDirectory(prefix="aiohttp_test_temp_dir_") as temp_dir:
        some_value = "some_value"
        temp_dir_path = Path(temp_dir)

        conf_file = temp_dir_path / "test_conf.py"
        conf_file.write_text(f"a = {some_value}")
        loaded_module = load_module_from_file_location(conf_file)
        assert loaded_module.a == some_value

        os_environ["TEST_ENV_VAR"] = "test_env_var"

# Generated at 2022-06-24 04:39:33.060666
# Unit test for function str_to_bool

# Generated at 2022-06-24 04:39:43.019843
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import shutil
    from os.path import dirname, abspath, exists
    from os import makedirs
    from tempfile import gettempdir

    from sanic.log import logger
    from sanic.config import ConfigLoader

    here = dirname(abspath(__file__))
    os.chdir(here)

    # create dummy module with same name as function under tests
    tempdir_path = Path(gettempdir()) / "sanic_test_load_module_from_file_location"
    if not tempdir_path.exists():
        os.mkdir(str(tempdir_path))
    else:
        shutil.rmtree(str(tempdir_path))

    module_file = "config_module.py"

# Generated at 2022-06-24 04:39:53.140429
# Unit test for function str_to_bool
def test_str_to_bool():
    # class BoolVals:
    #     pass
    # make_bool_vals_class = types.new_class('BoolVals', (), {}, lambda ns: ns.update(dict(only_cap=str_to_bool('ONLY_CAP'))))
    # bool_vals_class = make_bool_vals_class()
    # print('dir(bool_vals_class)', dir(bool_vals_class))
    # print(bool_vals_class.only_cap)
    # print(bool_vals_class.only_cap)

    str_to_bool('on')
    str_to_bool('off')
    str_to_bool('ON')
    str_to_bool('OFF')
    str_to_bool('Yes')
    str_to_bool('Y')
    str_to_bool

# Generated at 2022-06-24 04:40:02.439352
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:40:14.642786
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("TRue") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("1") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True

    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("False") is False

# Generated at 2022-06-24 04:40:27.839778
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import pytest

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = Path(tmp_dir)
        tmp_path.joinpath("test_load.py").write_text(
            "CONFIG = {'config_param': 'param_value'}"
        )

        module = load_module_from_file_location(tmp_path)
        assert module.CONFIG.get("config_param") == "param_value"

        # Test for environment variables
        os_environ["SOME_ENV_VAR"] = str(tmp_path)
        module = load_module_from_file_location(
            "${SOME_ENV_VAR}" + "/test_load.py"
        )

# Generated at 2022-06-24 04:40:33.046113
# Unit test for function str_to_bool
def test_str_to_bool():
    for s in ("y", "yes", "yep", "yup", "t", "true", "on", "1"):
        assert str_to_bool(s)

    for s in ("n", "no", "f", "false", "off", "0"):
        assert not str_to_bool(s)

    with pytest.raises(ValueError):
        str_to_bool("infinity")

# Generated at 2022-06-24 04:40:39.390900
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("t") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("1") == True
    assert str_to_bool("false") == False
    assert str_to_bool("f") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("disabled") == False

# Generated at 2022-06-24 04:40:47.906889
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import tempfile
    from os import environ as os_environ
    from os.path import join as os_path_join

    from sanic.exceptions import LoadFileException

    tempdir = tempfile.gettempdir()

    # -- Create env vars for testing.
    # -- Create env var for testing.

    # Create and set a env var for testing.
    # MARK: That it is not very safe, because it is possible,
    #       that this env var will exist in the system.
    os_environ["SANIC_TEST_ENV_VAR"] = tempdir
    # Create and set a env var for testing.
    # MARK: That it is not very safe, because it is possible,
    #       that this env var will exist in the

# Generated at 2022-06-24 04:40:59.906201
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # test existing file
    path = os.path.join(os.path.dirname(__file__), "test_config.py")
    module = load_module_from_file_location(path)
    assert module.TEST_KEY == "TEST_VALUE"

    # test existing file with environment variable in path
    os.environ["ENV_VAR_FOR_TEST"] = "test_config.py"
    temp_path = os.path.join(os.path.dirname(__file__), "${ENV_VAR_FOR_TEST}")
    module = load_module_from_file_location(temp_path)
    assert module.TEST_KEY == "TEST_VALUE"

    # test nonexistent file

# Generated at 2022-06-24 04:41:06.076633
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    """Testing str_to_bool function."""
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")


# Generated at 2022-06-24 04:41:16.230704
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["some_var"] = "some_value"
    mod = load_module_from_file_location(
        Path(__file__).parent / "fixtures" / "test_file.py",
        *["test_file.py".encode("utf8")],
    )
    assert mod.some_var == "test"
    assert mod.some_var_with_func(5) == 10

    mod = load_module_from_file_location(
        "./tests/fixtures/test_file.py", *["test_file.py".encode("utf8")]
    )
    assert mod.some_var == "test"
    assert mod.some_var_with_func(5) == 10


# Generated at 2022-06-24 04:41:22.242935
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("nO") is False
    assert str_to_bool("n") is False
    assert str_to_bool("0") is False
    assert str_to_bool("1") is True


# Generated at 2022-06-24 04:41:33.092439
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    location = "/path/to/some/file"
    args = ()
    kwargs = {}
    location_as_path = Path(location)

    try:
        assert load_module_from_file_location(location)
    except OSError as e:
        assert str(e) == str("Unable to load configuration file ")

    try:
        assert load_module_from_file_location(location_as_path)
    except OSError as e:
        assert str(e) == str("Unable to load configuration file ")

    assert load_module_from_file_location(location, *args, **kwargs)
    assert load_module_from_file_location(location, *args, **kwargs)


# Generated at 2022-06-24 04:41:44.033637
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Example 1: Test loading file with environment variables.

    # A) Prepare some environment variables
    os_environ["TEST_ENV_VAR_1"] = "/some/path"
    os_environ["TEST_ENV_VAR_2"] = "some/file.py"

    # B) Load configuration with them
    location = "some/path/${TEST_ENV_VAR_1}/${TEST_ENV_VAR_2}"
    loaded_module = load_module_from_file_location(location)

    # C) Check if loading was successful
    assert all(
        hasattr(loaded_module, attr)
        for attr in ("A_VAR", "A_FUNCTION", "A_CLASS")
    )

    # Example 2: Test loading file without environment variables.

# Generated at 2022-06-24 04:41:55.168861
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:42:06.522800
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["some_env_var"] = "/some/path"
    file_name = "test_example.py"
    path_to_file = os_environ["some_env_var"] + "/" + file_name
    with open(path_to_file, "w") as file:
        file.write('var = "var value"')

    test_module = load_module_from_file_location(
        path_to_file
    )  # os_environ["some_env_var"]+ "/" + file_name)

    assert (
        "var value" == test_module.var
    ), "Expected value of test_module.var is 'var value'"
    assert "config" == test_module.__package__, "Expected value of test_module.__package__ is 'config'"

# Generated at 2022-06-24 04:42:16.614515
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-24 04:42:28.724084
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location.

    Note:
        This test is intended to be used only along with the source code.
        To run it install pytest and run following command in root of this
        repository:

            pytest sanic/helpers.py

    """

    import pytest, os

    @pytest.fixture
    def os_environ_default(monkeypatch):
        monkeypatch.setattr(os, "environ", {"PY_TEST_PATH": "/test/path"})

    @pytest.fixture
    def os_environ_custom(monkeypatch):
        monkeypatch.setattr(
            os, "environ", {"PY_TEST_PATH": "/test/path", "USER": "pytest"}
        )


# Generated at 2022-06-24 04:42:37.994728
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Yes") is True
    assert str_to_bool("No") is False
    assert str_to_bool("0") is False
    assert str_to_bool("1") is True
    assert str_to_bool("Enable") is True
    assert str_to_bool("Disable") is False
    assert str_to_bool("T") is True
    assert str_to_bool("F") is False
    assert str_to_bool("On") is True
    assert str_to_bool("Off") is False
    with pytest.raises(ValueError):
        str_to_bool("soemthing else")

# Generated at 2022-06-24 04:42:44.993374
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D103
    from os import unlink, environ
    from tempfile import mkstemp

    def _create_temp_config(content: str) -> str:
        _, path = mkstemp()
        with open(path, "w") as f:
            f.write(content)
        return path

    # Test case: When location is of a string type,
    #            but it contains environment variables
    #            in format ${some_env_var}.
    env_var_name = str(uuid4())
    env_var_value = "some_env_var_value"

# Generated at 2022-06-24 04:42:54.269479
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from os import path as os_path
    from os import remove
    from random import randint

    SOME_VAR = "akjsfhaskldhfahskdjfhaskjdfhaskjhfakjsdfhaskjfh"
    SOME_VAR_PATH = "/tmp/asdfasdfasdfasdf/"
    test_conf_path = os_path.join(SOME_VAR_PATH, "config.py")
    test_conf = """
    SOME_CONF = {
        "testing": "some_conf",
        "yaml": "yaml_conf",
        "env": "env_conf",
        "py": "py_conf",
    }
    """
    environ[SOME_VAR] = SOME_VAR_PATH

    #

# Generated at 2022-06-24 04:43:06.487532
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("1") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("yEs") is True
    assert str_to_bool("Enable") is True
    assert str_to_bool("eNable") is True
    assert str_to_bool("false") is False
    assert str_to_bool("False") is False
    assert str_to_bool("0") is False
    assert str_to_bool("N") is False
    assert str_to_bool("NO") is False
    assert str_to_bool("nO") is False
    assert str_to_bool("DISABLE") is False

# Generated at 2022-06-24 04:43:18.196475
# Unit test for function str_to_bool
def test_str_to_bool():
    def test_str(
        val,
        expected_out,
        test_name: str,
        test_function=assert_equal,
        test_function_name="assert_equal",
    ):
        test_function_name = test_function_name
        assert_function_name = test_function_name.replace("_", " ")
        str_to_bool_output = None
        try:
            str_to_bool_output = str_to_bool(val)
        except ValueError:
            pass


# Generated at 2022-06-24 04:43:20.308360
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa FIXME:
    assert load_module_from_file_location(__file__) == sanic.__main__

# Generated at 2022-06-24 04:43:26.677588
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic import Sanic
    from sanic.config import Config

    current_config = "tests.test_config.test_load_module_from_file_location"
    current_config_test_file = "tests/test_config/config_file_location.py"
    with Sanic(config=current_config):
        config = Config.from_object(current_config)
        assert config.TEST_FILE_LOCATION == current_config_test_file



# Generated at 2022-06-24 04:43:32.942214
# Unit test for function str_to_bool
def test_str_to_bool():
    # test lowercase
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    # test uppercase
    assert str_to_bool("Y") is True
    assert str_to_bool("N") is False
    # test non-bool
    with pytest.raises(ValueError):
        str_to_bool("text")

# Generated at 2022-06-24 04:43:37.551960
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("on") == True
    assert str_to_bool("t") == True
    assert str_to_bool("True") == True
    assert str_to_bool("n") == False
    assert str_to_bool("off") == False
    assert str_to_bool("nos") == False
    assert str_to_bool("false") == False

    try:
        str_to_bool("1")
    except ValueError:
        pass

# Generated at 2022-06-24 04:43:44.463756
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # load_module_from_file_location
    # ... with module name
    location = "sanic.config"
    assert (
        load_module_from_file_location(location)
        is import_string(location)  # noqa
    )

    # ... with file path
    location = "/path/to/file.py"
    module = load_module_from_file_location(location)
    assert module.__name__ == "file"
    assert module.__file__ == location

    # ... with file path without extension
    location = "/path/to/file"
    module = load_module_from_file_location(location)
    assert module.__name__ == location
    assert module.__file__ == location

    # ... with environment variables in file path

# Generated at 2022-06-24 04:43:50.558574
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    from os import environ as os_environ, getcwd
    from pathlib import Path
    from unittest import TestCase, main

    from sanic.config import load_module_from_file_location

    from sanic.testing import get_running_loop

    class TestLoadModuleFromFileLocation(TestCase):
        def test_loads_module_from_file_path(self):
            config = load_module_from_file_location(
                Path(__file__).parent / "fixtures" / "test_config.py"
            )
            self.assertTrue(hasattr(config, "test_param"))

        @staticmethod
        def test_loads_module_from_file_path_with_env_vars():
            environ = os_environ

# Generated at 2022-06-24 04:43:59.053795
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:44:09.349780
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Case 1:
    # When param location is a Path object, then it's returned as is,
    # and with no changes.
    mod_path = Path("some_module_path")
    mod_object = load_module_from_file_location(mod_path)
    assert isinstance(mod_object, Path) and (mod_object == mod_path)

    # Case 2:
    # When param location is a string, then if location looks like a path,
    # that's substituted with real path.
    # For example:
    #     location: /some/path/${some_env_var}
    #     real_path: /some/path/some_value
    #
    # Also environment variables in format ${some_env_var} are substituted
    # with values from environment variables (os.environ).
    # For

# Generated at 2022-06-24 04:44:19.855033
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("YeP") is True
    assert str_to_bool("YEP") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("YUP") is True
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("t") is True
    assert str_to_bool("T")

# Generated at 2022-06-24 04:44:28.785413
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import tempfile
    from pathlib import Path
    from os import setenv, environ

    location = Path("$HOME/some_module_name.py")
    setenv("HOME", tempfile.TemporaryDirectory().name)
    assert load_module_from_file_location(
        location
    ) is not sys.modules["somemodulename"]

    location = Path("/some/path/some_module_name.py")
    assert load_module_from_file_location(
        location
    ) is not sys.modules["somemodulename"]

    location = Path("somemodulename.py")
    assert load_module_from_file_location(
        location
    ) is not sys.modules["somemodulename"]


# Generated at 2022-06-24 04:44:38.828553
# Unit test for function str_to_bool

# Generated at 2022-06-24 04:44:46.526334
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Test if it works for non existing files
    try:
        load_module_from_file_location("")
    except LoadFileException:
        pass
    else:
        assert False, "This line should not be called!"

    # Test for correct resolving of environment variables
    # in arguments and resolving them in location.
    try:
        os_environ["SANIC_TEST_ENV_VAR"] = "test_env_var"
        load_module_from_file_location(
            "test_module_name", "./test_data/${SANIC_TEST_ENV_VAR}", "utf-8"
        )
    except LoadFileException:
        assert False, "This line should not be called!"

# Generated at 2022-06-24 04:44:57.123931
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("yup")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("no")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-24 04:45:07.093793
# Unit test for function str_to_bool
def test_str_to_bool():
    bool_in_true_cases = (
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    )
    bool_in_false_cases = (
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    )
    bool_in_false_cases_with_wrong_cases = (
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    )