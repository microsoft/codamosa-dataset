

# Generated at 2022-06-24 04:35:07.356694
# Unit test for function str_to_bool
def test_str_to_bool():
    test_dict = {
        "y": True,
        "yes": True,
        "yep": True,
        "yup": True,
        "t": True,
        "true": True,
        "on": True,
        "enable": True,
        "enabled": True,
        "1": True,
        "n": False,
        "no": False,
        "f": False,
        "false": False,
        "off": False,
        "disable": False,
        "disabled": False,
        "0": False,
    }

    for key, value in test_dict.items():
        assert str_to_bool(key) == value

    with pytest.raises(ValueError):
        str_to_bool("foo")

# Generated at 2022-06-24 04:35:18.413243
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from unittest import TestCase

    # TODO: Make these tests more sophisticated
    class TestLoadModuleFromFileLocation(TestCase):
        def test_load(self):
            file_location = NamedTemporaryFile(mode="w+")
            file_location.write("FOO = True")
            file_location.seek(0)

            mod = load_module_from_file_location(file_location.name)
            self.assertEqual(mod.FOO, True)

        def test_load_file_obj(self):
            file_location = NamedTemporaryFile(mode="w+")
            file_location.write("FOO = True")
            file_location.seek(0)

            mod = load_module_from_file_location(file_location)

# Generated at 2022-06-24 04:35:19.412819
# Unit test for function load_module_from_file_location

# Generated at 2022-06-24 04:35:26.053693
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path = "tests/test_app.py"

    # default behaviour
    module = load_module_from_file_location(path)
    assert "app" in module.__dict__
    assert module.app.name == "test_app"

    # $PWD environment support
    module = load_module_from_file_location(
        "${PWD}/tests/test_app.py"
    )
    assert "app" in module.__dict__
    assert module.app.name == "test_app"

    # custom module name
    module = load_module_from_file_location(path, "custom_module_name")
    assert "custom_module_name" in module.__dict__
    assert module.custom_module_name.name == "test_app"

    # non existen module path
   

# Generated at 2022-06-24 04:35:31.575350
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("on") is True
    assert str_to_bool("OFF") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("No") is False
    assert str_to_bool("EnAbLE") is True
    assert str_to_bool("DisAbLE") is False
    assert str_to_bool("TRUE") is True
    assert str_to_bool("fAlSe") is False
    assert str_to_bool("Y") is True
    assert str_to_bool("N") is False
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False

# Generated at 2022-06-24 04:35:44.739058
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ.setdefault("BASIC_ENV_VAR", "basic")
    os_environ.setdefault("EXTENDED_ENV_VAR", "extended")
    os_environ.setdefault("NON_EXISTING_ENV_VAR", "non_existing")
    os_environ.setdefault("NON_EXISTING_ENV_VAR2", "non_existing2")

    """
    Test simple string.
    """
    module_without_path = load_module_from_file_location("test_module")
    assert module_without_path.test_variable == "success"

    """
    Test string with path.
    """

# Generated at 2022-06-24 04:35:51.422651
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from os import environ as os_environ_test
    from tempfile import TemporaryDirectory
    import uuid

    test_env_var = "TEST_SANIC_ENV_VAR_" + str(uuid.uuid4()).replace("-", "")
    test_env_var_value = str(uuid.uuid4())
    os_environ_test[test_env_var] = test_env_var_value

    with TemporaryDirectory() as tmp_dir_name:
        tmp_dir_name = Path(tmp_dir_name)
        file_name = "config" + str(uuid.uuid4())
        file_path = tmp_dir_name / (file_name + ".py")
        file_path_noext = tmp_dir_name / file_name
        # file_name

# Generated at 2022-06-24 04:35:59.587472
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for load_module_from_file_location.

    This test contains simple test for load_module_from_file_location
    function, that checks whether function raises
    LoadFileException in case when:
    - it is used with environment variables in format ${some_env_var}
      first, and some of these environment variables are
      not defined in os.environ.
    - it's location argument is of non-string, non-bytes and non-Path
      type.
    - it's location is of string type, but extension of this string
      is not 'py'.
    """
    import sys
    import shutil
    import tempfile
    import unittest

    import os

    sys_prefix = sys.prefix
    os_environ["PYTHONPATH"] = sys_prefix


# Generated at 2022-06-24 04:36:06.366971
# Unit test for function str_to_bool
def test_str_to_bool():

    cases = [
        ("y", True),
        ("yes", True),
        ("yep", True),
        ("yup", True),
        ("t", True),
        ("true", True),
        ("on", True),
        ("enable", True),
        ("enabled", True),
        ("1", True),
        ("n", False),
        ("no", False),
        ("f", False),
        ("false", False),
        ("off", False),
        ("disable", False),
        ("disabled", False),
        ("0", False),
    ]

    for (case, expected_result) in cases:
        assert str_to_bool(case) == expected_result

# Generated at 2022-06-24 04:36:07.514320
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('yes') == True
    assert str_to_bool('no') == False

# Generated at 2022-06-24 04:36:16.716848
# Unit test for function str_to_bool
def test_str_to_bool():
    for true_str in (  # noqa
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ):
        assert str_to_bool(true_str)

    for false_str in (  # noqa
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ):
        assert not str_to_bool(false_str)

    try:
        str_to_bool("yass")
    except ValueError:
        pass

    try:
        str_to_bool("nop")
    except ValueError:
        pass

# Generated at 2022-06-24 04:36:24.399340
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import unittest
    from pathlib import Path

    class TestLoadModuleFromFileLocation(unittest.TestCase):
        def setUp(self):
            self.data_path = Path("tests/data").resolve()

        def test_load_env_var(self):
            env = {"SOME_ENV_VAR": str(self.data_path)}
            with self.subTest("Load valid file"):
                abs_location = str(self.data_path / "config.py")
                file_location = (
                    "/some/path/${SOME_ENV_VAR}/config.py"
                )
                with self.assertRaises(LoadFileException):
                    load_module_from_file_location(file_location)


# Generated at 2022-06-24 04:36:33.101364
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("n") == False
    assert str_to_bool("f") == False
    assert str_to_bool("no") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("disabled") == False
    assert str_to_bool("0") == False
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True

# Generated at 2022-06-24 04:36:42.355702
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from tempfile import TemporaryDirectory
    from os import mkdir, environ

    from sanic.config import load_module_from_file_location

    def create_init_py(path):
        with open(path / "__init__.py", "w") as f:
            f.write("")

    def create_test_module(path, module_name: str):
        create_init_py(path)
        with open(path / f"{module_name}.py", "w") as f:
            f.write(f"{module_name} = {module_name}")

    with pytest.raises(IOError):
        load_module_from_file_location("nonexistent_module")


# Generated at 2022-06-24 04:36:51.566252
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True")
    assert str_to_bool("On")
    assert str_to_bool("1")
    assert str_to_bool("Yes")
    assert str_to_bool("EnaBled")

    assert not str_to_bool("FALSE")
    assert not str_to_bool("0")
    assert not str_to_bool("N")

    with pytest.raises(ValueError):
        str_to_bool("sdfsdfsdfsfs")

# Generated at 2022-06-24 04:36:58.041203
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location("./tests/testutils/boolean_config.py")
        .boolean_config.TRUE is True
    )
    assert (
        load_module_from_file_location("./tests/testutils/boolean_config.py")
        .boolean_config.FALSE is False
    )
    assert (
        load_module_from_file_location("./tests/testutils/boolean_config.py")
        .boolean_config.UNKNOWN is None
    )


if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-24 04:37:09.950494
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["PY_BASE_PATH"] = os.path.abspath(os.path.dirname(__file__))
    test_module = load_module_from_file_location(
        "test_load_module_from_file_location",
        "/path/${PY_BASE_PATH}/test_config.py",
        # "/path/abs/${PY_BASE_PATH}/test_config.py",
    )
    assert test_module.__file__ == f"/path/{os_environ.get('PY_BASE_PATH')}/test_config.py"
    assert test_module.TEST_CONFIG == "test_config"


if __name__ == "__main__":
    test_load_module_from_file_location()

# Generated at 2022-06-24 04:37:17.533905
# Unit test for function str_to_bool
def test_str_to_bool():

    assert str_to_bool("true")
    assert not str_to_bool("False")
    assert str_to_bool("1")
    assert not str_to_bool("0")
    assert str_to_bool("Yes")
    assert str_to_bool("YES")
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert not str_to_bool("no")
    assert not str_to_bool("No")
    assert not str_to_bool("N")
    assert not str_to_bool("n")

    with pytest.raises(ValueError):
        str_to_bool("Truee")
        str_to_bool("1.1")
        str_to_bool("ff")
        str_to_bool("truel")

# Generated at 2022-06-24 04:37:25.393551
# Unit test for function str_to_bool
def test_str_to_bool():
    # Check positive values
    assert str_to_bool("true") == True
    assert str_to_bool("T") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("True") == True
    assert str_to_bool("True") == True
    assert str_to_bool("on") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("On") == True
    assert str_to_bool("1") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("yEs") == True

# Generated at 2022-06-24 04:37:35.161205
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    location = "/some/path/${SOME_ENV_VAR}"
    name = "some_module"
    module_file = name + ".py"
    os_environ["SOME_ENV_VAR"] = "."

    module = types.ModuleType("config")
    module.__file__ = str(Path(location) / module_file)
    try:
        with open(Path(location) / module_file) as config_file:
            exec(  # nosec
                compile(config_file.read(), module.__file__, "exec"),
                module.__dict__,
            )
    except Exception as e:
        raise PyFileError(location) from e

    assert load_module_from_file_location(
        location
    ) == module

# Generated at 2022-06-24 04:37:38.956379
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    import os
    import tempfile
    import inspect


# Generated at 2022-06-24 04:37:49.124586
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Prepare test files
    file_name = "test_file.py"
    file_path = Path("/tmp") / file_name
    with open(file_path, "w") as f:
        f.write("test_value = True")
    # Prepare variables
    os_environ["TEST_ENV_VAR"] = "tmp"
    # Test function
    test_module = load_module_from_file_location(
        "/${TEST_ENV_VAR}/${TEST_ENV_VAR}_file.py"
    )
    assert test_module.test_value == True

    # Cleanup
    file_path.unlink()
    del os_environ["TEST_ENV_VAR"]

# Generated at 2022-06-24 04:38:00.567697
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Should import module with environment variables"""
    import pytest

    environ = {
        "PYTHONPATH": "/home/test/test-project",
        "DB_NAME": "test_db",
    }
    os_environ.update(environ)
    module = load_module_from_file_location(
        "test_importer",
        "${PYTHONPATH}/tests/configs/${DB_NAME}.py",
        "utf8",
    )
    assert module.DB_NAME == os_environ["DB_NAME"]

    # Test error handling
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "test_importer", "${NOT_EXISTING_ENV_VAR}", "utf8"
        )



# Generated at 2022-06-24 04:38:11.085646
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    import pytest

    from sanic import Sanic

    from .helpers import get_base_svc

    config_file = "test_app_config.py"
    test_app_config_path = os.path.join(
        os.path.dirname(__file__), config_file
    )
    config_file_with_env_vars = "${APP_CONFIG_ROOT_DIR}/${APP_CONFIG_FILE}"
    tmp_app_config_root_dir = "/tmp/app_root/sanic/config"
    tmp_app_config_file = "test_app_config.py"

    # Set new os environment variables
    os.environ["APP_CONFIG_ROOT_DIR"] = tmp_app_config_root_dir

# Generated at 2022-06-24 04:38:19.596781
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location."""
    from sanic import Sanic

    from sanic.exceptions import ServerError

    sanic = Sanic("test")
    sanic.config.from_pyfile("tests/test_configs/test_config.py")

    assert sanic.config.TEST_KEY == "TEST_VALUE"
    assert sanic.config.TEST_KEY_2 == "TEST_VALUE_2"
    assert sanic.config.TEST_KEY_3 == "TEST_VALUE_3"
    assert sanic.config.TEST_KEY_4 == "TEST_VALUE_4"
    assert sanic.config.TEST_KEY_5 == "TEST_VALUE_5"
    assert sanic.config.DATABASE_HOST == "localhost"


# Generated at 2022-06-24 04:38:27.622808
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("yes")
    assert str_to_bool("NO")
    assert str_to_bool("enable")
    assert str_to_bool("off")
    assert str_to_bool("OFF")
    assert not str_to_bool("false")
    assert not str_to_bool("no")
    assert not str_to_bool("0")

# Generated at 2022-06-24 04:38:35.067995
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A
    class AttrDict(dict):
        __getattr__ = dict.__getitem__

    os_environ["TEST_VAR"] = "/some/path"
    location = '${TEST_VAR}/some_module'
    assert location == '${TEST_VAR}/some_module'

    # B
    module = load_module_from_file_location(location)
    assert isinstance(module, types.ModuleType)
    assert isinstance(module.test_dict, dict)



# Generated at 2022-06-24 04:38:43.322902
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("0") == False
    assert str_to_bool("y") == True
    assert str_to_bool("false") == False
    assert str_to_bool("on") == True
    assert str_to_bool("$%^$%^") == ValueError
    assert str_to_bool("falsee") == ValueError


# unit test for function load_module_from_file_location

# Generated at 2022-06-24 04:38:54.754494
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location.

    It checks if function can handle and return back following cases:
        1) bytes location
        2) string location
        3) Path location
        4) Python module location
        5) JSON file
        6) YAML file
        7) TOML file

    Note that all files are located in tests/test_config_loaders_files
    directory and this test module should be run from root directory.
    """

    from pathlib import Path

    from tomlkit.parser import Parser
    from tomlkit.toml_file import TOMLFile

    import pytest

    # Dictionary with config file loaders.
    # It will be passed as an argument for function load_module_from_file_location
    # file_loader_mapping is a list where every item is tuple with

# Generated at 2022-06-24 04:38:59.590355
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    os_environ["SANIC_CONF"] = "tests/config"
    module = load_module_from_file_location(
        "${SANIC_CONF}/example_config.py"
    )
    assert "example_config" in module.__name__

# Generated at 2022-06-24 04:39:09.928473
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    try:
        _ = load_module_from_file_location(
            "some_module_name", "/nonexisting/path/${nonexisting_env_var}"
        )
    except LoadFileException:
        pass
    else:
        raise AssertionError(
            "test_load_module_from_file_location "
            "failed assert #1: LoadFileException was not raised"
        )
    # 1)
    _ = load_module_from_file_location(
        "./tests/fixtures/module_without_code.py"
    )
    # 2)
    os_environ["SOME_VAR"] = "./tests/fixtures/module_without_code.py"

# Generated at 2022-06-24 04:39:16.989979
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # pathlib.Path test
    class_config = load_module_from_file_location(Path("./config.py"))
    assert class_config.TEST == "TEST"

    # string test
    class_config = load_module_from_file_location("./config.py")
    assert class_config.TEST == "TEST"

    # bytes test
    class_config = load_module_from_file_location(b"./config.py")
    assert class_config.TEST == "TEST"

    # bytes with different encoding test
    class_config = load_module_from_file_location(b"./config.py", "utf16")
    assert class_config.TEST == "TEST"

    # test that no *.py in path is ok
    class_config = load_module_

# Generated at 2022-06-24 04:39:25.937595
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A. When location is of bytes type.
    location = b"/some/path/some_module_name.py"
    some_module = load_module_from_file_location(
        location,
    )
    assert (
        some_module.__name__ == "some_module_name"
    )  # no matter what path was given as location of this module.

    # B. When location is of a Path type.
    some_module = load_module_from_file_location(
        Path(__file__).parent / "location_example.py",
    )
    assert (
        some_module.__name__ == "location_example"
    )  # no matter what path was given as location of this module.

    # C. When location is of a string type.

# Generated at 2022-06-24 04:39:31.658805
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    current_dir = Path(__file__).parent
    fixture_dir = current_dir / 'fixtures'
    test_file = fixture_dir / 'debug_config.py'

    m = load_module_from_file_location(test_file)
    assert m.key == 'value'

    m = load_module_from_file_location(str(test_file))
    assert m.key == 'value'

    m = load_module_from_file_location(bytes(test_file))
    assert m.key == 'value'
    # TODO: add test for when location contains environment variables

# Generated at 2022-06-24 04:39:36.484698
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pytest import raises

    # A)
    assert load_module_from_file_location("sanic.app") is not None

    # B)
    assert (
        load_module_from_file_location(
            "some_module_name",
            "/some/path/${some_env_var}",
        )
        is None
    )

    # C)
    with raises(IOError):
        load_module_from_file_location("sanic.app.DoesNotExists")

    # D)
    with raises(ValueError):
        load_module_from_file_location("sanic.app._$%^&*")

# Generated at 2022-06-24 04:39:45.453050
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test if it can load file and returns module from path.
    from . import helpers

    assert load_module_from_file_location(helpers) is helpers

    # Test if if can load file and returns module from environment variable.
    path = "sanic/tests/files/module_from_file.py"

    os_environ["MODULE_FILE_PATH"] = path

    mod = load_module_from_file_location(
        "${MODULE_FILE_PATH}",
        package=None,
        loader=None,
        origin=None,
    )

    del os_environ["MODULE_FILE_PATH"]

    assert mod



# Generated at 2022-06-24 04:39:57.013823
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from unittest.mock import patch
    from pathlib import Path

    # If a string is provided as argument, it should be returned as is.
    assert load_module_from_file_location("some_configuration_name") == "some_configuration_name"  # noqa

    # If bytes is provided as argument, it should be decoded and returned.
    assert load_module_from_file_location(b"some_configuration_name", encoding='utf8') == "some_configuration_name"  # noqa

    # If location argument is pathlib.Path instance, it should be converted to str.
    assert load_module_from_file_location(Path('some_configuration_name')) == "some_configuration_name"  # noqa

    # If only directory is provided as argument, it should raise IOError.

# Generated at 2022-06-24 04:40:09.588161
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """UnitTest for function load_module_from_file_location."""
    from .test_utils import TEST_DIR
    from .test_utils import get_test_path

    # Try to load file as pathlib.Path object
    test_config_file = Path(get_test_path("configs/test_config.py"))
    config = load_module_from_file_location(test_config_file)
    assert hasattr(config, "TEST_CONFIG_KEY")
    assert config.TEST_CONFIG_KEY == "TEST_CONFIG_VALUE"

    # Try to load file as pathlib.Path object
    env = os_environ.copy()
    env["TEST_VAR"] = TEST_DIR

# Generated at 2022-06-24 04:40:12.778177
# Unit test for function str_to_bool
def test_str_to_bool():
    positive_tests = ("y", "yes", "yep", "yup", "t", "true", "on", "enable", "enabled", "1")
    negative_tests = ("n", "no", "f", "false", "off", "disable", "disabled", "0")
    for val in positive_tests:
        assert str_to_bool(val) == True
    for val in negative_tests:
        assert str_to_bool(val) == False

    try:
        str_to_bool("x")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-24 04:40:25.645997
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys

    assert load_module_from_file_location(__file__) is sys.modules[__name__]

    assert load_module_from_file_location(os.getcwd()) is None

    assert load_module_from_file_location(
        __file__.replace(__name__, "module_with_custom_name")
    ).__name__ == "module_with_custom_name"

    os_environ["TEST_ENV_VAR"] = "foo"
    module_with_env_var = load_module_from_file_location(
        "${TEST_ENV_VAR}/bar/some_module_name.py"
    )
    assert module_with_env_var.__name__ == "some_module_name"

    del os_en

# Generated at 2022-06-24 04:40:34.814635
# Unit test for function str_to_bool
def test_str_to_bool():
    test_parameters = [
        ("y", True),
        ("yes", True),
        ("Y", True),
        ("YES", True),
        ("yep", True),
        ("yup", True),
        ("t", True),
        ("true", True),
        ("on", True),
        ("enable", True),
        ("enabled", True),
        ("1", True),
        ("n", False),
        ("no", False),
        ("f", False),
        ("false", False),
        ("off", False),
        ("disable", False),
        ("disabled", False),
        ("0", False),
    ]

    for test_param in test_parameters:
        assert str_to_bool(test_param[0]) == test_param[1]



# Generated at 2022-06-24 04:40:43.542601
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile
    import shutil
    import os


# Generated at 2022-06-24 04:40:53.243475
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    location = "sanic_openapi_utils/tests/test_env_substitution.py"
    test_config = load_module_from_file_location(location)
    try:
        assert test_config.var_from_env == "value"
    except Exception:
        raise Exception(
            "Sanic loads wrong configuration file. Run tests in "
            "assumed configuration.\nFor example: "
            "`export TEST_VAR_FROM_ENV=value && pytest`"
        )



# Generated at 2022-06-24 04:41:02.483080
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("True") == True
    assert str_to_bool("False") == False
    assert str_to_bool("true") == True
    assert str_to_bool("false") == False
    assert str_to_bool("t") == True
    assert str_to_bool("f") == False
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("on") == True

# Generated at 2022-06-24 04:41:11.156070
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("T") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("TrUe") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("on") is True
    assert str_to_bool("y") is True
    assert str_to_bool("y") is True
    assert str_to_bool("1") is True
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("F") is False
    assert str_to_bool("FALSE") is False
    assert str_to_bool("n") is False


# Generated at 2022-06-24 04:41:21.905465
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys, platform
    location = "/some/path/${python_version}"
    if platform.system() == "Windows":
        location = "c:" + location
    os_environ["python_version"] = ".".join(
        [str(x) for x in sys.version_info[:3]]
    )  # Because we don't want to bother about it in tests.

    # a) No environment variables
    assert load_module_from_file_location(location) == sys

    # b) Environment variables, but it does not exists
    location = "/some/path/${no_exists}"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)

    # c) Environment variables and it exists
    location = "/some/path/${python_version}"

# Generated at 2022-06-24 04:41:33.094115
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("YEP") == True
    assert str_to_bool("Yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("YUP") == True
    assert str_to_bool("Yup") == True

    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("true") == True

# Generated at 2022-06-24 04:41:44.034487
# Unit test for function str_to_bool
def test_str_to_bool():  # pragma: no cover
    for input_, expected_output in (
        ("y", True),
        ("yes", True),
        ("yep", True),
        ("yup", True),
        ("t", True),
        ("true", True),
        ("on", True),
        ("enable", True),
        ("enabled", True),
        ("1", True),
        ("n", False),
        ("no", False),
        ("f", False),
        ("false", False),
        ("off", False),
        ("disable", False),
        ("disabled", False),
        ("0", False),
    ):
        assert str_to_bool(input_) == expected_output


# Generated at 2022-06-24 04:41:55.168928
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unit test for function load_module_from_file_location"""

    # Check for string type input and exception for no .py in path
    with pytest.raises(LoadFileException) as excinfo:
        load_module_from_file_location(
            "/home/",
        )
    assert excinfo.match(".py suffix is not present")

    # Check for bytes type input
    with patch("builtins.print") as print_:
        load_module_from_file_location(
            "/home/sanic/test.py".encode("utf8")
        )
    print_.assert_called_once_with("Testing for bytes path")

    # Check for os.environ and string type input
    os_environ["TEST"] = "/home/sanic/"

# Generated at 2022-06-24 04:42:06.517898
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    module_name = "module"

    # Test A)
    module_location = "${SOME_SHOULD_NOT_BE_SET}"
    try:
        load_module_from_file_location(module_name, module_location)
    except LoadFileException as e:
        # The following environment variables are not set: SOME_SHOULD_NOT_BE_SET
        if "SOME_SHOULD_NOT_BE_SET" in str(e):
            print("Test A) passed")
        else:
            print(
                "Test A) failed: ",
                "Expected to get `The following environment variables "
                "are not set: SOME_SHOULD_NOT_BE_SET`",
                "Got:",
                e,
            )

    # Test B)

# Generated at 2022-06-24 04:42:16.828243
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("logging").__name__ == "logging"

    # Loading module from file and checking some variables
    module = load_module_from_file_location(
        "test_config", "tests/configs/test_config.py"
    )
    assert module.__name__ == "test_config"
    assert module.test == "test"
    assert module.test_int == 1

    # Testing environment variables substitution
    module = load_module_from_file_location(
        "foo", "/some/path/${SOME_VAR}/foo.py"
    )
    assert module.__name__ == "foo"
    os_environ["SOME_VAR"] = "/some/path"

# Generated at 2022-06-24 04:42:24.032746
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["SOME_ENV_VAR"] = "/some/path"

    location = "test_module.py"
    with open(location, "w", encoding="utf-8") as f:
        f.write(
            """ 
            class C: pass
            """
        )


# Generated at 2022-06-24 04:42:33.998638
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover
    import os
    import inspect
    import shutil
    from pathlib import Path

    from sanic import Sanic
    from sanic.config import Module

    dir_path = os.path.dirname(os.path.realpath(__file__))
    tmp_dir = os.path.join(dir_path, "tmp")
    tmp_dir_path = Path(tmp_dir)
    tmp_dir_path.mkdir(exist_ok=True)

    app = Sanic("test_load_module_from_file_location")

    # 1. Check if it's able to load module provided as string.
    loaded_module = load_module_from_file_location("sanic")
    assert loaded_module is not None
    assert loaded_module.__name__ == "sanic"

# Generated at 2022-06-24 04:42:38.192064
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("YeS")
    assert str_to_bool("T")
    assert str_to_bool("true")
    assert str_to_bool("1")
    assert not str_to_bool("no")
    assert not str_to_bool("n")
    assert not str_to_bool("False")
    assert not str_to_bool("0")
    assert not str_to_bool("off")
    with pytest.raises(ValueError):
        str_to_bool("random")

# Generated at 2022-06-24 04:42:41.742476
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("n") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    with pytest.raises(ValueError):
        str_to_bool("invalid")

# Generated at 2022-06-24 04:42:52.199882
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # type: ignore
    # If a location is a string of bytes do nothing.
    assert load_module_from_file_location(b"example") == b"example"
    assert load_module_from_file_location("example") == "example"

    # If a location is a pathlib.Path object do nothing.
    assert load_module_from_file_location(Path("example")) == Path("example")

    # If a location is a pathlib.Path object containing some environment
    # variable in format ${some_env_var}.
    # then substitute it.
    # Mark that $some_env_var will not be resolved as environment variable.
    os_environ["some_var"] = "yep"
    assert load_module_from_file_location(Path(f"${some_var}")) == "yep"

# Generated at 2022-06-24 04:43:00.115470
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("no") == False
    assert str_to_bool("YeS") == True
    assert str_to_bool("nO") == False
    assert str_to_bool("yep") == True
    assert str_to_bool("nope") == False
    assert str_to_bool("yup") == True
    assert str_to_bool("nope") == False
    assert str_to_bool("t") == True
    assert str_to_bool("f") == False
    assert str_to_bool("true") == True
    assert str_to_bool("false") == False
    assert str_to_bool("on") == True
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:43:10.418770
# Unit test for function load_module_from_file_location

# Generated at 2022-06-24 04:43:20.352275
# Unit test for function str_to_bool
def test_str_to_bool():

    # Success
    assert str_to_bool("0") is False
    assert str_to_bool("1") is True
    assert str_to_bool("F") is False
    assert str_to_bool("FALSE") is False
    assert str_to_bool("t") is True
    assert str_to_bool("T") is True
    assert str_to_bool("true") is True
    assert str_to_bool("TRUE") is True

    # Fail
    try:
        str_to_bool("2")
    except ValueError as e:
        assert e.args[0] == "Invalid truth value 2"


__all__ = ["load_module_from_file_location", "str_to_bool"]

# Generated at 2022-06-24 04:43:23.442398
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("on") is True
    assert str_to_bool("OFF") is False
    with pytest.raises(ValueError):
        assert str_to_bool("abracadabra")

# Generated at 2022-06-24 04:43:32.290373
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""
    os_environ["CUSTOM_ENV_VAR"] = "123_ABC"

    # A) Test resolution of environment variables in file path.
    #    And basic file resolving.
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "some_module_name", "/some/path/${NOT_DEFINED_ENV_VAR}"
        )

    load_module_from_file_location(
        "some_module_name", os_environ["CUSTOM_ENV_VAR"], "/some/path"
    )

    # B) Test basic import of a string.
    load_module_from_file_location("some_module_name")

# Generated at 2022-06-24 04:43:41.435200
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    test_file_name = "/tmp/test_config_file_name.py"

    # Preparation phase.
    with open(test_file_name, "w") as test_file:
        test_file.write("CONFIG_EXAMPLE_VAR = 'some_example_value_string'")
    os_environ["TEST_ENV_VAR"] = "test_env_var_value"

    # Tests phase.
    module = load_module_from_file_location(test_file_name)
    assert module.CONFIG_EXAMPLE_VAR == "some_example_value_string"
    assert module.__file__ == test_file_name


# Generated at 2022-06-24 04:43:49.273606
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('true')
    assert not str_to_bool('false')
    assert str_to_bool('1')
    assert not str_to_bool('0')
    assert str_to_bool('TRUE')
    assert not str_to_bool('FALSE')
    assert str_to_bool('Yes')
    assert not str_to_bool('No')
    assert str_to_bool('YES')
    assert not str_to_bool('NO')
    assert str_to_bool('y')
    assert not str_to_bool('n')
    assert str_to_bool('Y')
    assert not str_to_bool('N')
    assert str_to_bool('yup')
    assert not str_to_bool('nope')
    assert str_to_bool('Yup')

# Generated at 2022-06-24 04:43:59.645280
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function."""
    # Prepare enviroment.
    # NOTE: We could use pytest.set_env() but docstring of this function
    # states: "This function should not be used, and will be deprecated
    # in future versions of pytest."
    env = {
        "SOME_ENV_VAR": "some_env_val",
        "SOME_ENV_VAR_WITH_PY": "some_env_val_with_py",
        "SOME_ENV_VAR_WITH_PY_AND_DIR": "some_env_val_with_py_and_dir",
        "SOME_ENV_VAR_WITHOUT_PY": "some_env_val_without_py",
    }

# Generated at 2022-06-24 04:44:07.169470
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Example 1.
    location = "module_name"
    _mod_spec = spec_from_file_location(
        "module_name", location, *("", "r", 1), **{"has_location": True}
    )
    module = module_from_spec(_mod_spec)
    _mod_spec.loader.exec_module(module)  # type: ignore
    assert (
        load_module_from_file_location(
            location, *("", "r", 1), **{"has_location": True}
        )
        == module
    ), "returns module with the same name"

    # Example 2.
    location = "/some/path/some.py"

# Generated at 2022-06-24 04:44:10.394848
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """ Basic test of load_module_from_file_location(...) """
    test_module = load_module_from_file_location("config.py")
    assert test_module.FOOBAR == "baz"

# Generated at 2022-06-24 04:44:16.886502
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("True") == True
    assert str_to_bool("False") == False
    assert str_to_bool("Yes") == True
    assert str_to_bool("No") == False
    assert str_to_bool("Y") == True
    assert str_to_bool("N") == False

# Generated at 2022-06-24 04:44:26.890742
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Make sure that this function works."""
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as module:
        module.write("module_var = 'This is a module variable'")

    try:
        module = load_module_from_file_location(module.name)
        assert module.module_var == "This is a module variable"

        with open(module.name) as module:
            module_file = module.read()
        assert module_file == "module_var = 'This is a module variable'"
    finally:
        os.remove(module.name)

# Generated at 2022-06-24 04:44:34.304729
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import_cwd = Path(__file__)
    from_location = load_module_from_file_location(
        import_cwd.parent / "example_module.py"
    )
    from_location_no_dot_py = load_module_from_file_location(
        import_cwd.parent / "example_module"
    )
    assert from_location.example_module_var
    assert from_location_no_dot_py.example_module_var

# Generated at 2022-06-24 04:44:42.185796
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Creating after test environment.
    old_environ = os_environ
    os_environ = {
        "some_env_var": "for_testing_module_load_from_file_location",
        "another_env_var": "for_testing_module_load_from_file_location2"
    }

    # 1) Test if function load_module_from_file_location loads module correctly
    # if it is provided as a file path as string.

# Generated at 2022-06-24 04:44:46.713728
# Unit test for function str_to_bool
def test_str_to_bool():
    for i in ("yes", "YES", "Yes", "tRuE"):
        assert str_to_bool(i) is True
        assert str_to_bool(i).__class__ == bool

    for i in ("no", "NO", "NO", "NO"):
        assert str_to_bool(i) is False
        assert str_to_bool(i).__class__ == bool

    with pytest.raises(ValueError):
        str_to_bool("yup")



# Generated at 2022-06-24 04:44:57.147138
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("1") == True
    assert str_to_bool("on") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("YEP") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("YUP") == True
    assert str_to_bool("NOT FOUND") == False
    assert str_to_bool("n")

# Generated at 2022-06-24 04:45:03.868049
# Unit test for function str_to_bool
def test_str_to_bool():
    assert True is str_to_bool("true") is str_to_bool("True")
    with pytest.raises(ValueError) as excinfo:
        str_to_bool("hahaha")
    with pytest.raises(ValueError) as excinfo:
        str_to_bool("tru")
    assert False is str_to_bool("false") is str_to_bool("False")
    assert False is str_to_bool("no") is str_to_bool("nope")
    assert True is str_to_bool("yes") is str_to_bool("Yes")
    assert False is str_to_bool("0")
    assert True is str_to_bool("1")
    assert False is str_to_bool("off") is str_to_bool("disable")
    assert True is str_to