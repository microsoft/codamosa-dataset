

# Generated at 2022-06-24 04:35:10.798756
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("yes")
    assert str_to_bool("y")
    assert str_to_bool("YES")
    assert str_to_bool("Y")

    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("T")
    assert str_to_bool("TRUE")

    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("ON")
    assert str_to_bool("ENABLE")
    assert str_to_bool("ENABLED")

    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")

# Generated at 2022-06-24 04:35:22.249369
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import os

    # 1) load module from file path
    file_path = os.path.dirname(os.path.abspath(__file__))
    module = load_module_from_file_location(file_path)
    assert "test" in module.__file__
    assert "test" in module.__name__

    # 2) load module from file path via enviroment variable.
    os.environ["file_path"] = file_path
    module = load_module_from_file_location(
        "${file_path}", location_type="file"
    )
    assert "test" in module.__file__
    assert "test" in module.__name__

    # 3) load module from package

# Generated at 2022-06-24 04:35:24.645885
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True")
    assert not str_to_bool("False")
    assert str_to_bool("off")
    assert str_to_bool("1")
    with pytest.raises(ValueError):
        assert str_to_bool("abc")

# Generated at 2022-06-24 04:35:33.276275
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("true") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("YeP") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("YEP") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("YUP") is True
    assert str_to_bool("On") is True
    assert str_to_bool("on") is True
    assert str_to_bool("ON")

# Generated at 2022-06-24 04:35:45.461093
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import shutil
    import sys

    current_dir = os.getcwd()
    temp_dir = tempfile.gettempdir()

    os.chdir(temp_dir)
    os.environ['BASE_URL'] = "http://www.example.com"
    os.environ['QUERY_PARAM'] = "query"

    # Case 1. Run `load_module_from_file_location` with a file location
    #         that does not exist.
    config_location = "path/to/non_existing/config.py"

    with pytest.raises(IOError):
        load_module_from_file_location(config_location)

    # Case 2. Run `load_module_from_file_location` with a file location
    #         that does exist

# Generated at 2022-06-24 04:35:51.631996
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import libs.config
    cwd = Path(__file__).parent.absolute()
    path_to_config = str(cwd.joinpath("config.py"))
    path_to_config_with_var = Path("${tests_var}/config.py")
    os_environ["tests_var"] = str(cwd)
    assert load_module_from_file_location(path_to_config) == libs.config
    assert load_module_from_file_location(path_to_config_with_var) == libs.config

# Generated at 2022-06-24 04:35:59.851453
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test of load_module_from_file_location."""
    from sanic.config import CONFIG_DEFAULTS

    s_file_location = "sanic_restful.config"
    with open("config.py", "w") as f:
        f.write("""
            CONFIG_DEFAULTS['RESTFUL_JSON']['ensure_ascii'] = False
            CONFIG_DEFAULTS['RESTFUL_JSON']['sort_keys'] = True
        """)

# Generated at 2022-06-24 04:36:05.451906
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    module_name = "test_module"
    with NamedTemporaryFile() as test_file:
        importlib.machinery.SourceFileLoader(
            module_name, str(test_file.name)
        ).exec_module(test_module)
        assert (
            test_module == load_module_from_file_location(str(test_file.name))
        )

# Generated at 2022-06-24 04:36:16.545566
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    os_environ["my_env_var"] = "/some/path"
    os_environ["my_env_var_two"] = "some_path"

    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "some_module_name",
            "/some/path/${undefined_env_var}"
        )

    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "some_module_name",
            "/some/path/${undefined_env_var}/${undefined_env_var_two}"
        )


# Generated at 2022-06-24 04:36:25.730476
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import os
    import sys
    import logging

    import pytest

    # Logging
    handler = logging.StreamHandler(sys.stderr)
    logger = logging.getLogger("sanic.error")
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    # Create fake configuration file
    file_name = "sometestfile.py"
    os.environ.update({"TEST_ENVIRONMENT_VAR_1": "some value 1"})
    os.environ.update({"TEST_ENVIRONMENT_VAR_2": "some env value 2"})
    os.environ.update({"TEST_ENVIRONMENT_VAR_3": "some test value 3"})

# Generated at 2022-06-24 04:36:35.183634
# Unit test for function str_to_bool
def test_str_to_bool():
    test_str = ("y", "yes", "yep", "yup", "t", "true", "on", "enable",
                "enabled", "1", "n", "no", "f", "false", "off", "disable",
                "disabled", "0")
    test_bool = [True, True, True, True, True, True, True, True, True, True,
                 False, False, False, False, False, False, False, False, False]

    for i in range(len(test_str)):
        assert(str_to_bool(test_str[i]) is test_bool[i])

    try:
        str_to_bool("not_valid_truth_value")
    except ValueError:
        pass
    else:
        assert(False)

# Generated at 2022-06-24 04:36:44.371888
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    os_environ["PY_TEST_VAR"] = "test_py_path"

    assert load_module_from_file_location(
        "tests/test_configs/config_1.py"
    ).TEST_CONFIG == "test_config_1"

    assert load_module_from_file_location(
        b"tests/test_configs/config_1.py",
        encoding="utf8",
    ).TEST_CONFIG == "test_config_1"

    assert load_module_from_file_location(
        Path("tests/test_configs/config_1.py")
    ).TEST_CONFIG == "test_config_1"


# Generated at 2022-06-24 04:36:54.177269
# Unit test for function str_to_bool
def test_str_to_bool():
    with pytest.raises(ValueError):
        str_to_bool("")
        str_to_bool("abc")
        str_to_bool("True")
        str_to_bool("some string")
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True

# Generated at 2022-06-24 04:37:00.288378
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unit testing function load_module_from_file_location."""

    assert load_module_from_file_location(
        b"logging", b"/some/path/logging.py", "r"
    )  # bytes

    assert load_module_from_file_location(
        "logging", Path("/some/path/logging.py"), "r"
    )  # Path

    assert load_module_from_file_location(
        "logging", "/some/path/logging.py", "r"
    )  # str

    assert load_module_from_file_location(
        "logging", "${SOME_ENV_VAR}/logging.py", "r", encoding="utf-8"
    )  # str with environment variables


# Generated at 2022-06-24 04:37:12.077502
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("true") is True
    assert str_to_bool("TruE") is True
    assert str_to_bool("On") is True
    assert str_to_bool("on") is True
    assert str_to_bool("1") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("yup") is True

    assert str_to_bool("False") is False
    assert str_to_bool("false") is False
    assert str_to_bool("FalsE") is False
    assert str_to_bool("OFF") is False
    assert str_to_bool("off") is False
    assert str_to_bool("0") is False
    assert str_to_bool("disable") is False

# Generated at 2022-06-24 04:37:21.281516
# Unit test for function str_to_bool
def test_str_to_bool():
    assert isinstance(str_to_bool('1'), bool)
    assert str_to_bool('1') is True
    assert isinstance(str_to_bool('true'), bool)
    assert str_to_bool('true') is True
    assert isinstance(str_to_bool('TRUE'), bool)
    assert str_to_bool('TRUE') is True
    assert isinstance(str_to_bool('y'), bool)
    assert str_to_bool('y') is True
    assert isinstance(str_to_bool('Y'), bool)
    assert str_to_bool('Y') is True
    assert isinstance(str_to_bool('yup'), bool)
    assert str_to_bool('yup') is True
    assert isinstance(str_to_bool('yep'), bool)
    assert str_

# Generated at 2022-06-24 04:37:32.245048
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ as os_environ
    from os import path as os_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from asynctest import CoroutineMock
    from asynctest import MagicMock
    from asynctest import patch
    from asynctest import run_until_complete

    test_string = "test_string"
    test_env_var_name = "ENV_VAR"
    test_env_var = "test_env_var"

    def run(
        location: Union[bytes, Path, str],
        *args,
        **kwargs
    ) -> types.ModuleType:  # noqa
        return load_module_from_file_location(location, *args, **kwargs)

    m = MagicMock()

# Generated at 2022-06-24 04:37:40.632989
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory

    from sanic.log import logger
    from sanic.testing import SanicTestClient

    with TemporaryDirectory() as temp_dir:
        a_path = Path(temp_dir) / "a.py"
        a_path.write_text(
            '"a.py"', encoding="utf8"
        )  # this configuration file contains string "a.py"
        a = load_module_from_file_location(a_path)
        assert a.__file__ == str(a_path), f"a.__file__ should be equal to {a_path}"
        assert (
            a.__file__[-3:] == ".py"
        ), "a.__file__ should have .py extension"

# Generated at 2022-06-24 04:37:50.622131
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False
    assert str

# Generated at 2022-06-24 04:38:02.034516
# Unit test for function str_to_bool
def test_str_to_bool():
    test_true_vals = set([
        "y", "yes", "yep", "yup", "t",
        "true", "on", "enable", "enabled", "1"
    ])
    test_false_vals = set([
        "n", "no", "f", "false", "off", "disable", "disabled", "0"
    ])
    for test_val in test_true_vals:
        assert str_to_bool(test_val) == True
    for test_val in test_false_vals:
        assert str_to_bool(test_val) == False
    is_raise = False
    try:
        str_to_bool("not_true_or_false")
    except ValueError:
        is_raise = True
    assert is_raise == True


# Generated at 2022-06-24 04:38:11.853646
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pylint: disable=C0111
    import tempfile
    import os

    # Check if import_string is called
    with tempfile.TemporaryDirectory() as temp_dir:
        def _import_string(val):
            return import_string(val)

        with open(os.path.join(temp_dir, "some_module"), "w") as file:
            file.write("some_val = 'some_val'\n")
        file.close()

        with patch("sanic.config.import_string") as mock_import:
            mock_import.side_effect = _import_string
            mod = load_module_from_file_location(
                os.path.join(temp_dir, "some_module")
            )
            assert mod.some_val == "some_val"

    # Check if

# Generated at 2022-06-24 04:38:20.006212
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import tempfile
    import os
    import re


# Generated at 2022-06-24 04:38:29.342879
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("on") == True
    assert str_to_bool("off") == False
    assert str_to_bool("yup") == True
    assert str_to_bool("nope") == False
    assert str_to_bool("t") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("disable") == False
    assert str_to_bool("fals") == False
    assert str_to_bool("tr") == False
    assert str_to_bool("gibberish") == False

# Generated at 2022-06-24 04:38:38.839401
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('enable')
    assert str_to_bool('True')
    assert str_to_bool('1')
    assert str_to_bool('off') == False
    assert str_to_bool('false') == False
    assert str_to_bool('n') == False
    assert str_to_bool('0') == False
    # str_to_bool('') # this will raise error
    # str_to_bool('maybe') # this will raise error
    # str_to_bool('something else') # this will raise error
    # str_to_bool('2') # this will raise error


# Generated at 2022-06-24 04:38:47.496154
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_to_module = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, path_to_module)
    print(sys.path)
    module = load_module_from_file_location(
        f"{path_to_module}/test_module.py",
        name="config_module"
    )
    assert module.__file__ == f"{path_to_module}/test_module.py"
    assert module.some_value == True
    assert module.some_value == True
    assert module.some_var == "test"
    assert module.some_raw_var == "test"
    assert module.some_list == ["test", "test1", "test2"]

# Generated at 2022-06-24 04:38:53.107145
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    path_to_test_file = Path(__file__).parent / "test_data" / "config_test.py"
    module = load_module_from_file_location(path_to_test_file)

    assert hasattr(module, "TEST_CONFIG")
    assert module.TEST_CONFIG["foo"] == "bar"
    assert module.TEST_CONFIG["test"] == "test"

# Generated at 2022-06-24 04:39:01.045011
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import os

    def _call_load_module_from_file_location(location: str):
        return load_module_from_file_location(location)

    # 1. Test with path to folder which conaints __init__.py file.
    import_from_folder_path = os.path.abspath("./tests/files")
    module = _call_load_module_from_file_location(import_from_folder_path)
    assert module.__name__ == "files"

    # 2. Test with path to folder which does not contain __init__.py file.
    import_from_non_folder_path = os.path.abspath("./tests/files/base.py")

# Generated at 2022-06-24 04:39:11.125571
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        # Test if function works properly with
        # * pathlib.Path object
        # * and with bytes with utf8 encoding.
        file_name = "example_file"
        file_path = Path(temp_dir) / (file_name + ".py")
        with file_path.open(mode="w") as example_file:
            example_file.write(
                (
                    "some_var_name_1 = 1\n"
                    "some_var_name_2 = 'some string'\n"
                    "some_var_name_3 = True\n"
                )
            )

        example_file_bytes = file_path.read_bytes()


# Generated at 2022-06-24 04:39:14.568798
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    location = os.path.abspath(__file__)
    module = load_module_from_file_location(location)
    assert module == import_string(__name__)

# Generated at 2022-06-24 04:39:24.907377
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    os_environ["pwd"] = str(Path.cwd())
    os_environ["test"] = "test"
    module_from_env_var = load_module_from_file_location(
        "config/test.py", f"${pwd}/config/${test}.py"
    )
    assert module_from_env_var.config_param == "test"
    module_from_bytes = load_module_from_file_location(
        bytes(f"{pwd}/config/test.py", encoding="utf8")
    )
    assert module_from_bytes.config_param == "test"

    # B) Check these variables exists in environment.

# Generated at 2022-06-24 04:39:32.229456
# Unit test for function str_to_bool
def test_str_to_bool():
    # Basic tests
    assert str_to_bool("Yes") == True
    assert str_to_bool("NO") == False
    assert str_to_bool("Y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("True") == True
    assert str_to_bool("False") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False

    # Errors
    error = None
    try:
        str_to_bool("Well, yes, no, maybe?")
    except ValueError as e:
        error = e
    assert error



# Generated at 2022-06-24 04:39:42.935012
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory

    from unittest.mock import patch

    from pytest import raises

    # A) Check that function raises in case one of environment variables is
    #    not set.
    with TemporaryDirectory() as tmp_path:
        tmp_path = Path(tmp_path).resolve()
        with (tmp_path / "config.py").open("w") as config_file:
            config_file.write(
                """
                CONFIG_KEY = "some_value"
                """
            )
        with patch.object(os, "environ", new={"MY_KEY": "some_value"}):
            with raises(LoadFileException):
                load_module_from_file_location(
                    tmp_path / "config.py", encoding="utf16"
                )

    # B) Check that function returns

# Generated at 2022-06-24 04:39:45.861305
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location("__main__")
        == load_module_from_file_location(__file__)
    )

# Generated at 2022-06-24 04:39:53.163568
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Mock some environment variables
    os_environ["PY_FILE_PATH"] = "/some/file.py"
    os_environ["PY_FILE_PATH_WITH_DOT"] = "/some/path/config.py"
    os_environ["PY_FILE_PATH_WITH_EXTRA_EXTENSIONS"] = "/some/path/config.py.ex"
    os_environ["NOT_PY_FILE_PATH"] = "/some/file.txt"
    os_environ["NOT_PY_FILE_PATH_WITH_EXTRA_EXTENSIONS"] = "/some/path/config.py.ex.tx"  # noqa

    # Module
    class TestModule:
        CONFIG_VARIABLE_1 = "CONFIG_VALUE_1"
        CONFIG_VARIABLE

# Generated at 2022-06-24 04:40:00.257303
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys

    import pytest

    # test_load_module_from_file_location_01

    # A) Check if location is of a string type.
    def func_01_path(path):
        return load_module_from_file_location(path / "sanic.py")

    def func_01_str(path):
        return load_module_from_file_location(str(path / "sanic.py"))

    # check if returned module is correct.
    def check_func_01(module):
        assert getattr(module, "__name__") == "sanic"

    # Check if no path TypeError is raised.
    with pytest.raises(TypeError):
        load_module_from_file_location(bytes(i for i in range(256)))


# Generated at 2022-06-24 04:40:05.674343
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("yes")
    assert str_to_bool("YeS")
    assert str_to_bool("Yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("On")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("N")
    assert not str_to_bool("No")
    assert not str_to_bool("NO")
    assert not str_to

# Generated at 2022-06-24 04:40:15.038644
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os
    import sys

    module = load_module_from_file_location(os.path.abspath(__file__))
    assert module.app == sys.modules["sanic.app"]

    module = load_module_from_file_location(
        os.path.abspath(__file__), cache_module=False
    )
    assert module.app == sys.modules["sanic.app"]

    try:
        load_module_from_file_location(os.path.abspath(__file__), "utf1")
    except LookupError:
        pass

    module = load_module_from_file_location("./tests/project/configuration.py")
    assert module.TEST
    assert not module.TEST1
    assert module.TEST2

# Generated at 2022-06-24 04:40:25.590624
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("yes")
    assert str_to_bool("y")
    assert str_to_bool("1")
    assert str_to_bool("on")
    assert not str_to_bool("false")
    assert not str_to_bool("no")
    assert not str_to_bool("n")
    assert not str_to_bool("0")
    assert not str_to_bool("off")
    with pytest.raises(ValueError):
        str_to_bool("meh")


# Unit tests for function load_module_from_file_location

# Generated at 2022-06-24 04:40:30.961122
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("TrUe") is True
    assert str_to_bool("y") is True
    assert str_to_bool("1") is True
    assert str_to_bool("OFF") is False
    assert str_to_bool("f") is False
    assert str_to_bool("0") is False
    with pytest.raises(ValueError):
        str_to_bool("sss")

# Generated at 2022-06-24 04:40:39.950639
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("1") == True
    assert str_to_bool("yes") == True

    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False
    assert str_to_bool("0") == False
    assert str_to_bool("no") == False

    assert str_to_bool("True") == True
    assert str_to_bool("False") == False

    assert str_to_bool("y") == True
    assert str_to_bool("n") == False

    with pytest.raises(ValueError):
        str_to_

# Generated at 2022-06-24 04:40:48.252932
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool(1) == True
    assert str_to_bool(True) == True
    assert str_to_bool(False) == False
    assert str_to_bool(0) == False
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False

# Generated at 2022-06-24 04:40:57.964398
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import tempfile

    test_vars = ["some_var", "var", "somevar"]

    initial_env_vars = dict((k, os_environ.get(k)) for k in test_vars)

    with tempfile.TemporaryDirectory() as tempdir:
        os.environ["some_var"] = str(Path(tempdir) / "${var}")
        os.environ["var"] = "test"
        os.environ["somevar"] = "env_var"

        os.makedirs(os.environ["some_var"])

        config_file_name = "my_config.py"

        # A) Create config file in temp directory

# Generated at 2022-06-24 04:41:09.919869
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("NO") == False
    assert str_to_bool("False") == False
    assert str_to_bool("No") == False
    assert str_to_bool("no") == False
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("On") == True
    assert str_to_bool("on") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("Off") == False
    assert str_

# Generated at 2022-06-24 04:41:18.980399
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    tests = (
        ("t", True),
        ("y", True),
        ("yes", True),
        ("1", True),
        ("true", True),
        ("on", True),
        ("f", False),
        ("n", False),
        ("no", False),
        ("0", False),
        ("false", False),
        ("off", False),
    )
    for input, expected in tests:
        assert str_to_bool(input) == expected

    with pytest.raises(ValueError):
        str_to_bool("unknown")



# Generated at 2022-06-24 04:41:26.145238
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    dir_path = Path(__file__).parent
    test_module_path = dir_path / "test_load_module_from_file_location.py"

    test_module = load_module_from_file_location(
        test_module_path, encoding="utf8"
    )
    assert test_module.__file__ == str(test_module_path)
    assert test_module.test_var == "test_module_var"
    assert test_module.test_func() == "test_module_func_result"

    os_environ["test_env_var"] = str(dir_path)
    test_module_path_env = "${test_env_var}" / "test_load_module_from_file_location.py"

# Generated at 2022-06-24 04:41:34.153514
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("on")
    assert str_to_bool("On")
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("1")

    assert not str_to_bool("false")
    assert not str_to_bool("False")
    assert not str_to_bool("off")
    assert not str_to_bool("Off")
    assert not str_to_bool("n")
    assert not str_to_bool("N")
    assert not str_to_bool("0")


# Generated at 2022-06-24 04:41:38.102788
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("1") is True

    assert str_to_bool("False") is False
    assert str_to_bool("FALSE") is False
    assert str_to_bool("0") is False

    try:
        str_to_bool("Fuck")
    except ValueError:
        assert True



# Generated at 2022-06-24 04:41:43.345946
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # A) Check if location parameter is of a bytes type, then use
    #    encoding to decode it into string.
    assert (
        load_module_from_file_location(
            b"some_module_name", b"/some/path/some_file.py", encoding="utf8"
        ).__file__
        == "/some/path/some_file.py"
    )
    assert (
        load_module_from_file_location(
            b"some_module_name",
            b"/some/path/${HOME}/some_file.py",
            encoding="utf8",
        ).__file__
        == "/some/path/" + os_environ.get("HOME") + "/some_file.py"
    )

    # B) Check if location parameter is of a pathlib

# Generated at 2022-06-24 04:41:54.648983
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover
    import os
    import pytest
    from sanic.helpers import load_module_from_file_location


    def remove_file(filename: str):
        if os.path.isfile(os.path.join(os.getcwd(), filename)):
            os.remove(os.path.join(os.getcwd(), filename))


    def create_file(filename: str):
        # create empty file
        with open(os.path.join(os.getcwd(), filename), "a"):
            os.utime(os.path.join(os.getcwd(), filename), None)

    def test_valid_environment_variables(monkeypatch):
        monkeypatch.setenv("SOME_ENV_VAR", "some_value")

# Generated at 2022-06-24 04:42:05.961489
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    import pytest

    def test_load_module_from_file_location_raises(
        monkeypatch, test_file, test_module_name
    ):
        """Test if function raises LoadFileException
        if environment variable is not set."""

        import os

        os.environ["test_env_var"] = "test"
        monkeypatch.delenv("test_env_var", raising=False)

        with pytest.raises(LoadFileException):
            load_module_from_file_location(
                location=test_file, module_name=test_module_name
            )

    def test_load_module_from_file_location_works(
        monkeypatch, test_file, test_module_name
    ):
        """Test if function works."""
        import os


# Generated at 2022-06-24 04:42:16.802208
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("On") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("y") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("off") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("n") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("disabled") == False
    assert str_

# Generated at 2022-06-24 04:42:28.723527
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("true") is True
    assert str_to_bool("t") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("no") is False
    assert str_to_bool("n") is False
    assert str_to_bool("false") is False
    assert str_to_bool("f") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:42:38.625058
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yEs") == True
    assert str_to_bool("t") == True
    assert str_to_bool("TRue") == True
    assert str_to_bool("oN") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("No") == False
    assert str_to_bool("False") == False
    assert str_to_bool("off") == False
    assert str_to_bool("0") == False

    with pytest.raises(ValueError):
        str_to_bool("wrong value")

# Generated at 2022-06-24 04:42:50.090265
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Get the path to this file
    current_file_path = Path(__file__)
    # Get the path to this file's parent directory
    current_dir = current_file_path.parent
    # Get the path to a directory with a config
    current_dir_with_config = current_dir / "config"

    # Test for working for "regular" files paths
    config_file_location = (current_dir_with_config / "basic_config.py")
    mod = load_module_from_file_location(
        config_file_location,
        is_package=False
    )
    assert mod.test_key == "test_value"

    # Test for working for import_strings
    mod = load_module_from_file_location(
        "sanic.exceptions", is_package=False
    )

# Generated at 2022-06-24 04:42:57.811845
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    os_environ["some_env_var"] = "/home/user"

    location = "conf_module.py"
    module = load_module_from_file_location(location)
    assert module.SOME_ENV_VAR == os_environ["some_env_var"]
    assert module.SOME_VARIABLE == 5
    assert module.SOME_STRING == "Hello World"
    assert module.SOME_LIST == [1, 2, 3]
    assert module.SOME_DICT == {"a": 5}

    location = "/home/user/${some_env_var}/conf/conf_module.py"
    module = load_module_from_file_location(location)

# Generated at 2022-06-24 04:43:02.746335
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("t")
    assert str_to_bool("1")
    assert str_to_bool("on")
    assert not str_to_bool("false")
    assert not str_to_bool("enable")
    assert not str_to_bool("Y")


# Generated at 2022-06-24 04:43:11.523501
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys

    # A) Check if it loads file with content: some_string = "some_value"
    sys_path = sys.path[:]  # save original sys.path
    sys.path.append(str(Path(__file__).parent))

    __location__ = "test_config.py"
    __module__ = load_module_from_file_location(__location__)

    assert __module__.some_string == "some_value"

    # B) Check if it loads file with content: some_string = "some_value"
    #    given as bytes.
    __location__ = b"test_config.py"
    __module__ = load_module_from_file_location(__location__)

    assert __module__.some_string == "some_value"

    # C) Check if it loads

# Generated at 2022-06-24 04:43:21.178296
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("no") == False
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("Y") == True
    assert str_to_bool("N") == False
    assert str_to_bool("t") == True
    assert str_to_bool("f") == False
    assert str_to_bool("true") == True
    assert str_to_bool("false") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("on") == True
    assert str_to_bool("off") == False
    assert str_to_bool("enabled") == True
    assert str_

# Generated at 2022-06-24 04:43:29.666405
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def assert_imported_module_correct(imported_mod, location):
        assert imported_mod.a == 1
        assert imported_mod.b == 2
        assert imported_mod.c == {
            "a": 1,
            "b": 2,
        }
        assert imported_mod.__file__ == str(location)

    # A) Check if it loads module from file when location is bytes.
    location = Path(__file__).parent.joinpath("test_utils.py").read_bytes()
    imported_mod = load_module_from_file_location(location)
    assert_imported_module_correct(
        imported_mod, location=Path(__file__).parent.joinpath("test_utils.py")
    )

    # B) Check if it loads module from file when location is string.
    location

# Generated at 2022-06-24 04:43:37.209499
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:43:45.962392
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("False") is False
    assert str_to_bool("FALSE") is False

    try:
        str_to_bool("")
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-24 04:43:57.165109
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-24 04:44:02.711866
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True, "yes is True"
    assert str_to_bool("Yes") == True, "Yes is True"
    assert str_to_bool("YES") == True, "YES is True"
    assert str_to_bool("no") == False, "no is False"
    assert str_to_bool("No") == False, "No is False"
    assert str_to_bool("NO") == False, "NO is False"
    assert str_to_bool("true") == True, "true is True"
    assert str_to_bool("True") == True, "True is True"
    assert str_to_bool("TRUE") == True, "TRUE is True"
    assert str_to_bool("false") == False, "false is False"
    assert str_to_bool

# Generated at 2022-06-24 04:44:06.602808
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path

    file_path = Path(__file__).parent / "common_functions_test_data" / "test_file.py"

    module = load_module_from_file_location(file_path)
    assert "test_function" in module.__dict__
    assert "test_variable" in module.__dict__
    assert module.test_variable == "test_value"



# Generated at 2022-06-24 04:44:17.300562
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    >>> test_load_module_from_file_location()  # doctest: +NORMALIZE_WHITESPACE
    <module 'module1' from '/tmp/module1.py'>
    """
    import tempfile
    import os

    def create_files(files):
        for filename, content in files.items():
            with open(os.path.join(tempfile.gettempdir(), filename), "w") as f:
                f.write(content)

    # 1. Test. Location is a string with .py extension.
    location = tempfile.mkdtemp()
    create_files({"module1.py": "var1 = None"})
    module = load_module_from_file_location(
        f"{location.rstrip('/')}/module1.py"
    )
   

# Generated at 2022-06-24 04:44:24.140167
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("0") is False
    assert str_to_bool("2") is True
    assert str_to_bool("off") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("enable") is True

# Generated at 2022-06-24 04:44:26.222662
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('true')
    assert not str_to_bool('false')
    try:
        assert not str_to_bool('foo')
    except ValueError:
        pass

# Generated at 2022-06-24 04:44:32.065431
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Case 1:

    # A) Prepare test case
    os_environ.update({"some_env_var": "SomeValue"})
    # B) Test the case
    result = load_module_from_file_location(  # noqa
        "some_module_name", "/some/path/${some_env_var}"
    )
    # C) Clean up test case
    del os_environ["some_env_var"]
    # D) Verify test case
    assert result

    # Case 2:

    # A) Prepare test case
    # B) Test the case
    result = load_module_from_file_location("string")  # noqa
    # C) Clean up test case
    # D) Verify test case
    assert result
    assert isinstance(result, types.ModuleType)

    # Case

# Generated at 2022-06-24 04:44:41.998531
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("yEs") == True
    assert str_to_bool("1") == True
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("disabled") == False
    assert str_to_bool("N") == False
    assert str

# Generated at 2022-06-24 04:44:52.367186
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    # 1. Test: Should raise when trying to load file with invalid
    #          location format.
    try:
        load_module_from_file_location("some_module_name")
        assert False
    except LoadFileException:
        assert True

    # 2. Test: Should be able to resolve environment variables in location.
    #          (A) Check if location contains any environment variables
    #             in format ${some_env_var}.
    #          (B) Check these variables exists in environment.
    #          (C) Substitute them in location.

# Generated at 2022-06-24 04:45:02.609905
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """This function tests load_module_from_file_location function"""

    # test python file with str location
    test_module_1 = load_module_from_file_location(
        f"{__file__}".replace("test_helpers.py", "test_module.py")
    )
    assert test_module_1.test_var == 2

    # test python file with Path location
    test_module_2 = load_module_from_file_location(
        Path(f"{__file__}".replace("test_helpers.py", "test_module.py"))
    )
    assert test_module_2.test_var == 2

    # test python file with bytes location

# Generated at 2022-06-24 04:45:09.387952
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("Y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("YUP") is True
    assert str_to_bool("Yeah") is True
    assert str_to_bool("True") is True
    assert str_to_bool("On") is True
    assert str_to_bool("Enable") is True
    assert str_to_bool("Enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("N") is False
    assert str_to_bool("NO") is False
    assert str_to_bool("No") is False
    assert str_to_bool("F") is False