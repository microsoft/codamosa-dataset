

# Generated at 2022-06-24 04:35:07.032894
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("1") is True
    assert str_to_bool("no") is False
    assert str_to_bool("n") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("0") is False
    with pytest.raises(ValueError):
        str_to_bool("foo")
    with pytest.raises(ValueError):
        str_to_bool("1.1")

# Generated at 2022-06-24 04:35:18.675228
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import os.path
    import tempfile

    # Check that error is raised if env var is not defined
    with open(os.path.join(tempfile.gettempdir(), "temp.py"), "w") as f:
        f.write(
            """
        # some comment
        A = "B"

        # some comment
        C = "D"
        """
        )

    os.environ["LOAD_MODULE_TEST"] = "temp.py"

# Generated at 2022-06-24 04:35:28.544952
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("1") is True
    assert str_to_bool("on") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("0") is False
    assert str_to_bool("off") is False

    with pytest.raises(ValueError):
        str_to_bool("whut")

    with pytest.raises(ValueError):
        str_to_bool("True")
    with pytest.raises(ValueError):
        str_to_bool("false")

# Generated at 2022-06-24 04:35:40.338638
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Yes")
    assert str_to_bool("Y")
    assert str_to_bool("ON")
    assert str_to_bool("1")
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("true")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")

    assert not str_to_bool("No")
    assert not str_to_bool("N")
    assert not str_to_bool("OFF")
    assert not str_to_bool("0")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("False")
    assert not str_to_bool("disable")
    assert not str

# Generated at 2022-06-24 04:35:48.754906
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from os import path as os_path
    from pathlib import Path
    from sys import path as sys_path

    #  add /tmp to sys.path
    sys_path.append("/tmp")

    #  add test_path environment variable to system
    environ["test_path"] = "/tmp"

    #  create config.py in /tmp
    Path("/tmp/config.py").write_text("TEST = True")

    # test file path
    assert load_module_from_file_location("/tmp/config.py").TEST is True

    # test relative file path
    assert load_module_from_file_location(
        os_path.relpath("/tmp/config.py")
    ).TEST is True

    #  test Path
    assert load_module_from_

# Generated at 2022-06-24 04:35:53.864279
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import re
    import tempfile
    import shutil

    fd, path = tempfile.mkstemp(suffix='.py')

# Generated at 2022-06-24 04:36:01.588329
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:36:12.891729
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os.path import dirname, join

    from conf.default import Config
    from conf.test import TestConfig

    # Check if 'load_module_from_file_location' can load valid config
    # file from configs directory.
    config_file_path = join(dirname(__file__), "test.py")
    config_module = load_module_from_file_location(config_file_path)
    assert isinstance(config_module, Config)

    # Check accessing to module attributes and checking that they are the same
    # as in default config module.
    config_module_default = load_module_from_file_location("conf.default")
    assert config_module.API_NAME is not None
    assert config_module.API_VERSION is not None
    assert config_module.API_TITLE is not None


# Generated at 2022-06-24 04:36:20.139562
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unit test for function load_module_from_file_location"""

    # A) Check load_module_from_file_location when
    #    location parameter is wrong.
    try:
        load_module_from_file_location(123)
    except LoadFileException:
        pass
    else:
        raise ValueError("load_module_from_file_location should not accept "
                         "location integer parameter")

    try:
        load_module_from_file_location({})
    except LoadFileException:
        pass
    else:
        raise ValueError("load_module_from_file_location should not accept "
                         "location dictionary parameter")

    # B) Check load_module_from_file_location when
    #    location parameter is correct.

# Generated at 2022-06-24 04:36:30.344984
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    fd, path = tempfile.mkstemp(
        suffix=".py", dir=Path(__file__).parent.parent.resolve()
    )
    with open(fd, "w") as a_file:
        a_file.writelines(
            ["var = True", "", "", "class Foo:", "    pass"]
        )  # nosec

    module = load_module_from_file_location(path)
    assert module.var == True  # nosec
    assert module.Foo  # nosec

    # test env_var resolving
    path = path.replace("test.py", "${SANIC_TEST}.py")
    os_environ["SANIC_TEST"] = "test"
    module = load_module_from_file_location(path)
    assert module

# Generated at 2022-06-24 04:36:40.903830
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unit test for function load_module_from_file_location."""
    # A) Test with 'location' that is not path and does not contain
    #    environment variables.
    import_string_module = load_module_from_file_location("builtins")
    assert str(import_string_module) == "<module 'builtins' (built-in)>"

    # B) Test with 'location' that does not contain environment variables.
    spec_module = load_module_from_file_location(__file__)
    assert spec_module.__name__ == "sanic.helpers"

    # C) Test with 'location' that contains environment variables.
    #    1) Set environment variables.
    os_environ["MY_PROJECT_PATH"] = "/tmp"

# Generated at 2022-06-24 04:36:51.385501
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic import Sanic

    app = Sanic("test_load_module_from_file_location")

    # Test 1
    location1 = "${PWD}/tests/test_config/config_file.py"
    module1 = load_module_from_file_location(location1)
    app.config.from_object(module1)
    assert app.config.CUSTOM_CONFIG_ITEM == "test_value"

    # Test 2
    location2 = "tests/test_config/config_file.py"
    module2 = load_module_from_file_location(location2)
    app.config.from_object(module2)
    assert app.config.CUSTOM_CONFIG_ITEM == "test_value"

    # Test 3

# Generated at 2022-06-24 04:36:55.577187
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        "${SOME_ENV_VAR}",
        "/vendor/python/miniconda3/envs/pypy3-v7.3.1-win32/lib/site-packages/tensorflow/python/util/tf_should_use.py",
    )
    import sys 
    print("sys.path:")
    for i in sys.path:
        print(i)
    print("sys.modules:")
    for i in sys.modules:
        print(i)
    print("module:")
    print(module)

test_load_module_from_file_location()

# Generated at 2022-06-24 04:37:07.157515
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") is True
    assert str_to_bool("1") is True
    assert str_to_bool("true") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("f") is False
    assert str_to_bool("0") is False
    assert str_to_bool("false") is False
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("yup") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False
    assert str

# Generated at 2022-06-24 04:37:12.799842
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from unittest.mock import patch, Mock

    # A) spec_from_file_location() should not be called
    #    if location is not a path.
    with patch("importlib.util.spec_from_file_location") as mock_spec:
        assert not mock_spec.called
        load_module_from_file_location("some_module")
        assert not mock_spec.called

    # B) module_from_spec() should not be called
    #    if location is not a path.
    with patch("importlib.util.module_from_spec") as mock_module:
        assert not mock_module.called
        load_module_from_file_location("some_module")
        assert not mock_module.called

    # C) if location is path, mock_module.exec_module()
    #

# Generated at 2022-06-24 04:37:22.418680
# Unit test for function str_to_bool
def test_str_to_bool():
    """Test for function str_to_bool"""
    assert str_to_bool("Y")
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("YES")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("T")
    assert str_to_bool("t")
    assert str_to_bool("True")
    assert str_to_bool("TRUE")
    assert str_to_bool("On")
    assert str_to_bool("ON")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("N")
    assert not str_to_

# Generated at 2022-06-24 04:37:30.070212
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_ENV_VAR"] = "/test/path"
    assert (
        os_environ["TEST_ENV_VAR"]
        == load_module_from_file_location("${TEST_ENV_VAR}").__file__
    )
    assert (
        os_environ["TEST_ENV_VAR"]
        == load_module_from_file_location("/test/path/${TEST_ENV_VAR}").__file__
    )

# Generated at 2022-06-24 04:37:38.855061
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # 1) Path points to file.
    # There are no environment variables in path
    path_to_conf = os.path.join("test", "config_for_tests.py")
    module = load_module_from_file_location(path_to_conf, "test")
    assert module.TEST_CONFIG_VALUE == 10
    assert module.__file__ == path_to_conf

    # 2) Path points to directory
    path_to_conf = os.path.join("test", "")
    with pytest.raises(LoadFileException):
        load_module_from_file_location(path_to_conf, "test")

    # 3) Path points to not existing file
    path_to_conf = os.path.join("test", "unknown_name.py")

# Generated at 2022-06-24 04:37:49.377625
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:38:00.567635
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A)
    # Test whether exceptions are handled properly
    location = "test_config"
    mod = load_module_from_file_location(location)

    with pytest.raises(PyFileError):
        location = "test_config_error"
        mod = load_module_from_file_location(location)

    with pytest.raises(LoadFileException):
        location = "${TEST_CONFIG_DOESNT_EXIST}"
        mod = load_module_from_file_location(location)

    location = "${TEST_CONFIG}"
    mod = load_module_from_file_location(location)

    # B)
    # Test whether importing from config file works properly
    assert mod.TEST_KEY_1 == "TEST_VALUE_1"
    assert mod.TEST_KEY

# Generated at 2022-06-24 04:38:04.480027
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from copy import deepcopy

    import json
    import os

    # save some original environment variables for future restore
    env_vars_to_restore = set(["PATH", "HOME"])
    original_env_vars = {
        env_var: deepcopy(os.environ.get(env_var))
        for env_var in env_vars_to_restore
    }

    # Test case 1: test if can replace environment variables
    test_var_name = "TEST_VAR"
    test_var_value = "test_value"
    os.environ[test_var_name] = test_var_value


# Generated at 2022-06-24 04:38:14.604167
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("treu") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("1") is True
    assert str_to_bool("false") is False
    assert str_to_bool("0") is False
    assert str_to_bool("oui") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("non") is False
    assert str_to_bool("no") is False
    assert str_to_bool("n") is False
    assert str_to_bool("f") is False
    assert str_to_bool("on") is True
    assert str_to_bool("off") is False
   

# Generated at 2022-06-24 04:38:24.640672
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from os import makedirs
    from os.path import join
    from shutil import rmtree
    from tempfile import mkdtemp

    from sanic.config import load_module_from_file_location

    # noinspection PyPep8Naming
    def test_try_to_load_module_with_not_existing_file():
        temp_dir = mkdtemp()
        config_path = join(temp_dir, "you_should_never_create_file_with_this_name")
        try:
            load_module_from_file_location(config_path, "utf8")  # noqa
        except LoadFileException as e:
            assert "Unable to load" in str(e)
        else:
            raise AssertionError("Should be raised Exception")
        finally:
            rmtree

# Generated at 2022-06-24 04:38:31.716400
# Unit test for function str_to_bool
def test_str_to_bool():
    import itertools

    value_to_bool = {
        "y": True,
        "yes": True,
        "yep": True,
        "yup": True,
        "t": True,
        "true": True,
        "on": True,
        "enable": True,
        "enabled": True,
        "1": True,
        "n": False,
        "no": False,
        "f": False,
        "false": False,
        "off": False,
        "disable": False,
        "disabled": False,
        "0": False,
    }

    # Check all lowercase with the same upper
    for key, value in value_to_bool.items():
        assert str_to_bool(key.upper()) == value

    # Check all lowercase without upper values

# Generated at 2022-06-24 04:38:38.370082
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unit test for load_module_from_file_location function.

    This test is not automatically executed while running tests of whole
    package. It is used only by developers to check if everythong works as
    expected.
    """

    import tempfile

    # A) Check if it raises LoadFileException if at least one of the environment
    #    variables is not set.
    with tempfile.NamedTemporaryFile() as config_file:
        config_file.write(b"SECRET_KEY=${NOT_DEFINED_ENV_VAR}")
        config_file.flush()

# Generated at 2022-06-24 04:38:47.526189
# Unit test for function str_to_bool
def test_str_to_bool():
    """Test str_to_bool function from utils module."""
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("T") is True
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("on") is True
    assert str_to_bool("On") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False

# Generated at 2022-06-24 04:38:57.896425
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(
        os.path.join(os.path.dirname(__file__), "__init__.py")
    )
    assert load_module_from_file_location(
        os.path.join(os.path.dirname(__file__), "__init__.py"),
        "/some/other/path/${some_env_var}",
    )
    assert load_module_from_file_location(
        os.path.join(os.path.dirname(__file__), "__init__.py"),
        "/some/other/path/",
        "/some/other/path/${some_env_var}",
    )

# Generated at 2022-06-24 04:39:08.795582
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # A) Test loading module from its absolute path (A1)
    #      with normal path
    #    and (A2)
    #      with environment variables in path
    #    and (A3)
    #      with both
    #    and (A4)
    #      with invalid path
    #    and (A5)
    #      with invalid environment variable
    not_defined_env_vars_regex = r"The following environment variables are not set: (.*?), "
    invalid_path_regex = r"Unable to load configuration file (.*?)"
    invalid_truth_value_regex = r"Invalid truth value (.*?)"

# Generated at 2022-06-24 04:39:16.272790
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import tempfile
    from shutil import rmtree

    def _load_module_from_file(location: str) -> types.ModuleType:
        location = Path(location)
        Path(location.parent).mkdir(exist_ok=True)
        with location.open("w") as f:
            f.write(
                """
            MY_CONST = 3
            ANOTHER_CONST = "c"
            """  # noqa
            )
        return load_module_from_file_location(location)

    def _create_file_in_tmp_dir(location: str) -> str:
        tmp_dir_path = tempfile.mkdtemp()
        sys.path.append(tmp_dir_path)

# Generated at 2022-06-24 04:39:25.628487
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:39:33.967630
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import unittest
    import tempfile
    import tempfile
    import os
    import shutil
    import random
    import re

    class TestLoadModuleFromFileLocation(unittest.TestCase):

        def setUp(self):
            self.test_dir = Path(tempfile.mkdtemp())
            self.file_name = "test_file.py"
            self.file_path = self.test_dir / self.file_name

            self.file_content = "test_var = 1 + 2"
            self.test_file = open(self.file_path, "a")
            self.test_file.write(self.file_content)
            self.test_file.close()

        def tearDown(self):
            shutil.rmtree(self.test_dir)


# Generated at 2022-06-24 04:39:38.402878
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SOME_ENV_VAR"] = str(Path.cwd())
    location = "tests/test_config.py"
    module = load_module_from_file_location(location)
    assert module.TEST_CONFIG_VAR == "test_string"
    os_environ.pop("SOME_ENV_VAR", None)

# Generated at 2022-06-24 04:39:47.278771
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('true') == True
    assert str_to_bool('TrUe') == True
    assert str_to_bool('1') == True
    assert str_to_bool('on') == True
    assert str_to_bool('yes') == True

    assert str_to_bool('false') == False
    assert str_to_bool('FaLsE') == False
    assert str_to_bool('0') == False
    assert str_to_bool('off') == False
    assert str_to_bool('no') == False

    try:
        str_to_bool('bla')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-24 04:39:58.276745
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False
    assert str_to_bool("disabled") is False
    assert str_to_bool("0") is False

    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True

# Generated at 2022-06-24 04:40:10.311185
# Unit test for function str_to_bool
def test_str_to_bool():
    assert True == str_to_bool("yes")
    assert True == str_to_bool("yep")
    assert True == str_to_bool("t")
    assert True == str_to_bool("true")
    assert True == str_to_bool("on")
    assert True == str_to_bool("enable")
    assert True == str_to_bool("enabled")
    assert True == str_to_bool("1")
    assert True == str_to_bool("y")
    assert True == str_to_bool("Yup")
    assert True == str_to_bool("YES")

    assert False == str_to_bool("no")
    assert False == str_to_bool("f")
    assert False == str_to_bool("false")
    assert False == str_to_bool("off")

# Generated at 2022-06-24 04:40:16.807090
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests several cases for load_module_from_file_location() function."""

    from os import environ, path

    from sys import path as sys_path
    from tempfile import NamedTemporaryFile


# Generated at 2022-06-24 04:40:21.723320
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import sanic.config
    from types import ModuleType

    assert isinstance(
        load_module_from_file_location("sanic.config"), ModuleType
    )
    assert load_module_from_file_location("sanic.config") is sanic.config



# Generated at 2022-06-24 04:40:32.508190
# Unit test for function str_to_bool
def test_str_to_bool():
    """Test function str_to_bool"""
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("NO") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("0") == False
    assert str_to_bool("2") == False
    assert str_to_bool("3") == False
    assert str_to_bool("4") == False
    assert str_to_bool("5") == False
    assert str_to_

# Generated at 2022-06-24 04:40:39.111409
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("on")
    assert not str_to_bool("off")
    assert str_to_bool("1")
    assert not str_to_bool("0")
    assert str_to_bool("true")
    assert not str_to_bool("false")
    assert str_to_bool("yes")
    assert not str_to_bool("no")
    assert str_to_bool("y")
    assert not str_to_bool("n")
    assert str_to_bool("t")
    assert not str_to_bool("f")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert not str_to_bool("nope")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")

# Generated at 2022-06-24 04:40:47.694717
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # pragma: no cover
    # 1.
    some_file = Path(__file__).parent / "load.py"
    some_module = load_module_from_file_location(
        Path(__file__).parent / "load.py"
    )

    assert some_module.__file__ == str(some_file.resolve())
    assert some_module.sanic_config_loaded == True

    # 2.
    os_environ["SOME_ENV_VAR"] = str(Path(__file__).parent / "load.py")
    some_module = load_module_from_file_location(
        "${SOME_ENV_VAR}",
        # This is here in order to check if it will not be taken
        # in consideration.
        encoding="utf-16",
    )

# Generated at 2022-06-24 04:40:59.758643
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    lmffl = load_module_from_file_location
    #
    # PART 1. Location is a file path.
    #

    # 1.1) Test case when location has ${some_env_var} variable.
    #       And this variable is set in environment.
    #
    # 1.1.1) Test case when location has relative path.
    #       It means that location has not absolute path.
    #
    # Setup mocked environment variable.
    os_environ["SOME_ENV_VAR"] = "some_path"
    #
    # Name of module is some_module_name.
    #
    module_name = "some_module_name"
    #
    # Path to module is "some/path/${some_env_var}/${some_env_var}.py"
    #

# Generated at 2022-06-24 04:41:10.057037
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = Path(temp_dir.name)

    temp_dir_path_env_var = tempfile.TemporaryDirectory()
    temp_dir_path_env_var_path = Path(temp_dir_path_env_var.name)

    temp_dir_path_file_name = tempfile.TemporaryDirectory()
    temp_dir_path_file_name_path = Path(temp_dir_path_file_name.name)

    temp_dir_path_env_var_file_name = tempfile.TemporaryDirectory()
    temp_dir_path_env_var_file_name_path = Path(
        temp_dir_path_env_var_file_name.name
    )

    # Make python file in temp_

# Generated at 2022-06-24 04:41:16.602780
# Unit test for function str_to_bool
def test_str_to_bool():
    cases = [
        (True, "true"),
        (True, "yes"),
        (False, "no"),
        (False, "false"),
        (False, "0"),
        (True, "1"),
    ]
    for case in cases:
        assert str_to_bool(case[1]) == case[0]

# Generated at 2022-06-24 04:41:27.684475
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("N")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str

# Generated at 2022-06-24 04:41:35.063286
# Unit test for function str_to_bool
def test_str_to_bool():  # pytype: disable=module-attr
    test_sets = [
        ("Yes", True),
        ("yes", True),
        ("NO", False),
        ("n", False),
        ("0", False),
        ("1", True),
        ("TruE", True),
        ("faLsE", False),
        ("", True),
        (" ", True),
        ("2", True),
        ("-1", True),
    ]
    for test_val, true_res in test_sets:
        assert str_to_bool(test_val) == true_res

# Generated at 2022-06-24 04:41:41.254143
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:41:52.711205
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import subprocess
    from tempfile import TemporaryDirectory

    def create_module(
        content: str, location: Path = Path("./"), module_name: str = "module",
    ) -> Path:
        """Creates module with provided content in provided location"""
        module_path = location / f"{module_name}.py"
        with module_path.open("w") as module_file:
            module_file.write(content)
        return module_path

    def load_module_and_test(
        module_path: Path,
        content: str,
        location: Path = Path("./"),
        module_name: str = "module",
    ):
        """Load the module and test the content"""
        loaded_module = load_module_from_file_location(module_path)

# Generated at 2022-06-24 04:42:02.285718
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    correct_location = os.path.dirname(os.path.realpath(__file__)) + "/test.py"
    try:
        correct = load_module_from_file_location(correct_location)
    except:
        raise AssertionError  # It should not raise an error
    assert correct.this_module_is_imported_correctly  # Check that it is correct

    #  Fail with non-string location
    try:
        load_module_from_file_location(None)
    except Exception as e:
        assert type(e) == TypeError
    except:
        raise AssertionError

    # Fail with non-existing location
    try:
        load_module_from_file_location("no_such_location")
    except Exception as e:
        assert type(e) == IOError
   

# Generated at 2022-06-24 04:42:10.936823
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("") is False
    assert str_to_bool("1") is True
    assert str_to_bool("True") is True
    assert str_to_bool("FaLse") is False
    assert str_to_bool("faLse") is False
    assert str_to_bool("No") is False
    assert str_to_bool("YES") is True
    assert str_to_bool("YeS") is True
    assert str_to_bool("f") is False
    assert str_to_bool("0") is False
    assert str_to_bool("123") is True
    with pytest.raises(ValueError):
        str_to_bool("asdf")

# Generated at 2022-06-24 04:42:21.233678
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-24 04:42:24.928609
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("FaLsE") == False
    assert str_to_bool("1") == True
    assert str_to_bool("No") == False
    assert str_to_bool("yep") == True
    assert str_to_bool("")

# Generated at 2022-06-24 04:42:34.060484
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D102, D103
    from tempfile import TemporaryDirectory
    from textwrap import dedent

    import pytest

    #
    # Test  for proper handling of environment variables in location.
    #
    with TemporaryDirectory() as directory:
        # A) Create test module
        with open(str(Path(directory) / "test.py"), "w") as f:
            f.write(
                dedent(
                    """
                    class Test:
                        pass
                    test_value = "test_value"
                    """
                )
            )

        # B) Define environment variable.
        os_environ["TEST_ENV_VAR_LOCATION"] = str(Path(directory) / "test.py")

        # C) Check that module is properly loaded.
        module = load_module_from_file_location

# Generated at 2022-06-24 04:42:40.150899
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SANIC_TEST_ENV"] = "test_env"
    path = Path(__file__).parent / "sanic/config/test_module.py"
    module = load_module_from_file_location(path)
    module_name = module.__name__
    module_file = module.__file__
    os.unsetenv("SANIC_TEST_ENV")

    assert module_name == "sanic.config.test_module"
    assert module_file == path

test_load_module_from_file_location()

# Generated at 2022-06-24 04:42:51.123314
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # NOTE: Basic test
    # 1. We need to create temporary file.
    # 2. We put in this file some data.
    # 3. We load this file.
    # 4. We check that data from this file is correct.
    #
    with tempfile.NamedTemporaryFile(suffix=".py") as file:
        file.write(b"my_var = 123")
        file.flush()

        config_module = load_module_from_file_location(
            file.name
        )  # type: types.ModuleType
        assert config_module.my_var == 123

    # NOTE: Basic test with some data in bytes
    # 1. We need to create temporary file.
    # 2. We put in this file some data.
    # 3. We load this file with some bytes.

# Generated at 2022-06-24 04:42:58.629690
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest
    from sanic_envconfig.exceptions import LoadFileException, PyFileError
    import shutil
    import tempfile
    import os
    env_var_name = "sanic_envconfig_temp_env"
    os_environ[env_var_name] = tempfile.gettempdir()
    module_test_config_name = "test_module_name"
    sample_module = "def test_func(): return 'test_func_result'"

# Generated at 2022-06-24 04:43:05.474864
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("YeS") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("No") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("0") == False


# Generated at 2022-06-24 04:43:08.746791
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert type(load_module_from_file_location(__file__))
    from .test_app import test_app as test_app_file
    assert (
        load_module_from_file_location(test_app_file) == test_app_file
    )  # Loads already imported module



# Generated at 2022-06-24 04:43:14.249049
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import path, environ as os_environ
    from tempfile import mkdtemp
    from shutil import rmtree
    from uuid import uuid4
    import subprocess as sp

    # Create temporary directory
    TMP_DIR = mkdtemp(suffix="_test_load_module_from_file_location")

    # Create temporary environment variables
    fake_env_vars = {
        uuid4(): "test_",
        uuid4(): "test_2",
        uuid4(): "/",
    }
    for key, value in fake_env_vars.items():
        os_environ[key] = value

    # A) Create temporary python script in ${TMP_DIR}/test_/test_2/${TMP_DIR}/
    #    with name ${TMP_DIR}

# Generated at 2022-06-24 04:43:24.858512
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from types import ModuleType
    from tempfile import mkdtemp

    from .utils import TemporaryDirectory

    class ModuleClass:
        """Just for testing."""
        pass

    # A) Test if raises correct error when asking for not existing variable.
    os_environ["env_var"] = "env_var_content"
    try:
        load_module_from_file_location(r"${env_var}")
    except LoadFileException as e:
        assert "The following environment variables are not set" in str(e)
    else:
        raise ValueError("Should raise LoadFileException")
    del os_environ["env_var"]

    # B) Test if raises correct error when module doesn't exists.

# Generated at 2022-06-24 04:43:30.690113
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Yes") == True
    assert str_to_bool("no") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("ON") == True
    assert str_to_bool("off") == False
    try:
        str_to_bool("some string")
    except ValueError as e:
        assert True, e
    else:
        assert False, "ValueError didn't raise"

# Generated at 2022-06-24 04:43:39.103086
# Unit test for function str_to_bool
def test_str_to_bool():
    truthy = ["y", "yes", "yep", "yup", "t", "true", "on", "enable", "enabled", "1"]
    for val in truthy:
        assert str_to_bool(val) is True, f"{val} should be True"

    falsy = ["n", "no", "f", "false", "off", "disable", "disabled", "0"]
    for val in falsy:
        assert str_to_bool(val) is False, f"{val} should be False"

    try:
        str_to_bool("fjep")
        raise
    except ValueError:
        pass

# Generated at 2022-06-24 04:43:46.274934
# Unit test for function str_to_bool
def test_str_to_bool():
    """Checks of str_to_bool function."""

    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
   

# Generated at 2022-06-24 04:43:52.883636
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    _test_module = load_module_from_file_location(
        "sanic.examples.simple_file",
        Path(__file__).parent / "examples" / "simple_file.py",
        "utf8",
    )
    assert _test_module.__name__ == "simple_file"
    assert "simple route" in _test_module.test_string



# Generated at 2022-06-24 04:44:00.954422
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") == True
    assert str_to_bool("false") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("on") == True
    assert str_to_bool("off") == False
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("yes") == True
    assert str_to_bool("no") == False
    assert str_to_bool("yep") == True
    assert str_to_bool("nope") == False
    assert str_to_bool("yup") == True
    assert str_to_bool("nop") == False
    assert str_to_bool("t") == True


# Generated at 2022-06-24 04:44:10.193740
# Unit test for function str_to_bool
def test_str_to_bool():
    true_vals = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]
    false_vals = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]
    for val in true_vals:
        assert str_to_bool(val) is True
    for val in false_vals:
        assert str_to_bool(val) is False
    try:
        str_to_bool("str_to_bool")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-24 04:44:20.160112
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    location = "tests/test_file.py"
    module = load_module_from_file_location(location)
    assert module.SOME_VAR == "some_val"

    location = Path("tests/test_file.py")
    module = load_module_from_file_location(location)
    assert module.SOME_VAR == "some_val"

    if "CONFIG_PATH" in os_environ:
        location = "${CONFIG_PATH}/test_file.py"
        module = load_module_from_file_location(location)
        assert module.SOME_VAR == "some_val"

        location = Path("${CONFIG_PATH}/test_file.py")
        module = load_module_from_file_location(location)

# Generated at 2022-06-24 04:44:29.116291
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdirname:
        # Test for failure for bytes type
        with pytest.raises(TypeError):
            load_module_from_file_location(b"bytes_type_file.py")

        # Test for failure for not existent file
        with pytest.raises(FileNotFoundError):
            load_module_from_file_location(f"{tmpdirname}/not_existent_file.py")

        # Test for failure with not seting environment variable
        with pytest.raises(LoadFileException):
            load_module_from_file_location(
                f"{tmpdirname}/${not_existent_env_var}/some_file.py"
            )

        # Test for success

# Generated at 2022-06-24 04:44:30.308812
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("os") == os



# Generated at 2022-06-24 04:44:38.515379
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y")
    assert str_to_bool("YES")
    assert str_to_bool("yes")
    assert str_to_bool("YUP")
    assert str_to_bool("True")
    assert str_to_bool("On")
    assert str_to_bool("Enable")
    assert str_to_bool("ENABLED")
    assert str_to_bool("1")
    assert str_to_bool("t")

    assert not str_to_bool("N")
    assert not str_to_bool("No")
    assert not str_to_bool("no")
    assert not str_to_bool("F")
    assert not str_to_bool("False")
    assert not str_to_bool("Off")
    assert not str_to_bool("Off")

# Generated at 2022-06-24 04:44:46.273047
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests load_module_from_file_location with all supported parameters.
    """
    import sys
    import types

    # A) Load module using string of a file location
    some_module = load_module_from_file_location(
        "/some/path/some_module_name.py"
    )
    if not isinstance(some_module, types.ModuleType):
        raise TypeError("Invalid ModuleType returned")

    # B) Load module using string of a file location that contains environment
    #    variables in format ${some_variable}.
    some_module = load_module_from_file_location(
        "/some/path/${SOME_ENV_VAR}/some_module_name.py"
    )

# Generated at 2022-06-24 04:44:54.281581
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("no") == False
    assert str_to_bool("True") == True
    assert str_to_bool("False") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("y") == True
    assert str_to_bool("f") == False

# Generated at 2022-06-24 04:45:05.121739
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # 1. Import module with file path.
    sys.path.insert(1, "/a/b/c")
    sys.path.insert(2, "/d/e/f")
    test_module = load_module_from_file_location(
        "/a/b/c/test_module.py"
    )
    # Check module name.
    assert test_module.__name__ == "test_module"
    # Check module properties.
    assert test_module.test_prop_1 == 1
    assert test_module.test_prop_2 == "A"
    assert test_module.test_prop_3() == ["B", "C"]

    # 2. Import module with module name.
    from test_module import test_func_1, test_func_2

    # Check module function.
