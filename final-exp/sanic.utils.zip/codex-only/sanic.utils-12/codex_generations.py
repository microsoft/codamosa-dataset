

# Generated at 2022-06-24 04:35:12.153114
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["some_env_var"] = "some_value"
    module = load_module_from_file_location(
        Path(__file__).parent / "test_load_module_from_file_location.py",
    )
    assert module.val == 1
    module = load_module_from_file_location(
        "sanic.tests.test_utils.test_load_module_from_file_location",
    )
    assert module.val == 1
    module = load_module_from_file_location(
        Path(__file__).parent / "test_load_module_from_file_location",
    )
    assert module.val == 1

# Generated at 2022-06-24 04:35:19.533815
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("YEP") is True
    assert str_to_bool("T") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("Enable") is True
    assert str_to_bool("ENabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False


# Generated at 2022-06-24 04:35:23.792460
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") is True
    assert str_to_bool("N") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("yEs") is True
    assert str_to_bool("nO") is False

# Generated at 2022-06-24 04:35:27.833957
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    test_module_name = "test"
    test_module = load_module_from_file_location(
        test_module_name, __file__.replace("test_helpers.py", f"{test_module_name}.py")
    )

    assert test_module.some_var == 1
    assert test_module.some_func() == 2

# Generated at 2022-06-24 04:35:34.092498
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False

# Generated at 2022-06-24 04:35:45.835052
# Unit test for function str_to_bool
def test_str_to_bool():
    """
    Testing str_to_bool function
    """
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("YEP") == True
    assert str_to_bool("Yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("true") == True
    assert str_to_bool("On") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("Enable") == True

# Generated at 2022-06-24 04:35:54.377163
# Unit test for function str_to_bool
def test_str_to_bool():
    from pytest import raises

    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert str_to_bool("n")
    assert str_to_bool("no")
    assert str_to_bool("f")
    assert str_to_bool("false")
    assert str_to_bool("off")
    assert str_to_bool("disable")
    assert str_to_bool("disabled")
    assert str

# Generated at 2022-06-24 04:36:01.986314
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    args_true = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]
    args_false = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]

    # Test lower case
    for arg in args_true + args_false:
        assert str_to_bool(arg) == (arg in args_true)

    # Test upper case

# Generated at 2022-06-24 04:36:09.065380
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic_utils.typing import ConfigTypeFunction

    location = "tests.test_configuration"
    module = load_module_from_file_location(location)

    assert isinstance(module, types.ModuleType)
    assert len(module.__dict__.keys()) == 4  # including __dict__
    assert module.__dict__["BASE_URL"] == "example.com"
    assert module.__dict__["ENABLED"] is True
    assert module.__dict__["TIMEOUT"] == 9

# Generated at 2022-06-24 04:36:17.806339
# Unit test for function str_to_bool
def test_str_to_bool():
    from pytest import raises
    from typing import NamedTuple

    class TestCases(NamedTuple):
        value: str
        expected_result: bool


# Generated at 2022-06-24 04:36:25.776888
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("on") is True
    assert str_to_bool("1") is True
    assert str_to_bool("True") is True
    assert str_to_bool("t") is True
    assert str_to_bool("y") is True

    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("off") is False
    assert str_to_bool("0") is False
    assert str_to_bool("False") is False
    assert str_to_bool("FALSE") is False
   

# Generated at 2022-06-24 04:36:34.945725
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(__file__).__name__ == __name__
    assert (
        repr(load_module_from_file_location(__file__, location=__file__))
        == repr(__name__)
    )

    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "some_module_name", "module/location/${NOT_DEFINED_ENV_VAR}"
        )

    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "some_module_name", "module/location/${" + "NOT_DEFINED_ENV_VAR}"
        )

# Generated at 2022-06-24 04:36:43.650606
# Unit test for function str_to_bool
def test_str_to_bool():
    truthy_values = [
        "y",
        "yes",
        "true",
        "on",
        "t",
        "1",
        "yep",
        "yup",
        "enable",
        "enabled",
    ]
    falsy_values = [
        "n",
        "no",
        "false",
        "off",
        "f",
        "0",
        "nope",
        "nup",
        "disable",
        "disabled",
    ]

    for val in truthy_values:
        assert str_to_bool(val) == True
    for val in falsy_values:
        assert str_to_bool(val) == False


# Generated at 2022-06-24 04:36:51.077527
# Unit test for function str_to_bool
def test_str_to_bool():
    # Case insensitive tests
    assert str_to_bool("False") is False
    assert str_to_bool("FALSe") is False
    assert str_to_bool("YES") is True
    assert str_to_bool("YUP") is True

    # Some other truth values
    assert str_to_bool("1") is True

    # Other values
    with pytest.raises(ValueError):
        str_to_bool("other")

# Generated at 2022-06-24 04:36:55.986265
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import importlib
    import os
    import sys

    python_file = (
        "import foo\n"
        "class A:\n"
        "    pass\n"
        "a = 1\n"
        "b = 2\n"
        "c = 3\n"
        "d = 4\n"
    )

    with open("./test_load_module.py", "w") as f:
        f.write(python_file)

    assert load_module_from_file_location(
        "./test_load_module.py"
    ).__file__ == "./test_load_module.py"

    os.remove("./test_load_module.py")


# Generated at 2022-06-24 04:37:08.132287
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("") is False
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False
    assert str_to_bool("disabled") is False
    assert str_to_bool("0") is False
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str

# Generated at 2022-06-24 04:37:10.156769
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    cfg = load_module_from_file_location(
        "/does/not/exists/example_config.py"
    )
    assert cfg.DEBUG is False
    assert cfg.TESTING is True



# Generated at 2022-06-24 04:37:17.667580
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from os import environ, remove
    from tempfile import mkstemp
    from shlex import split as shplit

    from typing import Any, Dict, List, Tuple

    def get_env_vars(variables: List[str]) -> Dict[str, str]:
        """Returns dict with specified environment variables."""
        return {variable: environ[variable] for variable in variables}

    def write_config_to_file(
        config_data: bytes, encoding: str
    ) -> Tuple[Any, str, Dict[str, str]]:
        temp_file, file_name = mkstemp()
        file_name += ".py"
        os.close(temp_file)
        enc_config_data = config_data.decode(encoding)

# Generated at 2022-06-24 04:37:24.824901
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")

    assert not str_to_bool("false")

    assert str_to_bool("1")

    assert not str_to_bool("0")

    assert str_to_bool("y")

    assert str_to_bool("yes")

    assert str_to_bool("yep")

    assert str_to_bool("yup")

    assert str_to_bool("t")

    assert str_to_bool("T")

    assert str_to_bool("Y")

    assert str_to_bool("YeP")

    assert not str_to_bool("b")

    assert not str_to_bool("not a valid string")

# Generated at 2022-06-24 04:37:31.116212
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("t")
    assert str_to_bool("y")
    assert str_to_bool("1")

    assert not str_to_bool("false")
    assert not str_to_bool("fals")
    assert not str_to_bool("f")
    assert not str_to_bool("n")
    assert not str_to_bool("0")

# Generated at 2022-06-24 04:37:39.796693
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # pylint: disable=protected-access
    # 1) Check if this function is able to load module properly.
    some_module = load_module_from_file_location("os")
    assert some_module is os
    assert some_module.sep == os.sep

    # 2) Check if this function can handle a full path.
    some_module = load_module_from_file_location(__file__)
    assert some_module is not None
    assert some_module._test_load_module_from_file_location.__name__ == "_test_load_module_from_file_location"

    # 3) Check if this function can handle environment variables in path.
    #    Mark that this test can erroneously succeed if you have set
    #    the environment variable TEMP to /tmp.
    assert os.environ

# Generated at 2022-06-24 04:37:50.138165
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SOME_ENV_VAR"] = "/some/env/path/"
    # Path
    path_module = load_module_from_file_location(
        Path("some_module_name"), Path("/some/path")
    )
    assert path_module.__file__ == "/some/path/some_module_name.py"
    # String
    string_module = load_module_from_file_location(
        "some_module_name", "/some/path/${SOME_ENV_VAR}"
    )
    assert string_module.__file__ == "/some/env/path/some_module_name.py"
    # Bytes

# Generated at 2022-06-24 04:38:01.211781
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import shutil
    import tempfile
    import os

    config = tempfile.NamedTemporaryFile(
        mode="w", prefix="config_", suffix=".py", delete=False
    ).name

    shutil.copyfile(
        "tests/test_configs/config_with_class.py", config
    )

    os.environ["TEST_ENV"] = "test_env"

    module = load_module_from_file_location(config)
    assert module.ConfigWithClass().stuff == "test_env"

    module = load_module_from_file_location(config.split("config_", 1)[1])
    assert module.ConfigWithClass().stuff == "test_env"

    module = load_module_from_file_location(config.encode())

# Generated at 2022-06-24 04:38:02.955587
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "config.py"
    module = load_module_from_file_location(location)
    assert module

# Generated at 2022-06-24 04:38:09.265661
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("1") is True
    assert str_to_bool("false") is False
    assert str_to_bool("False") is False
    assert str_to_bool("0") is False

# Generated at 2022-06-24 04:38:18.530333
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    # Absence of ${some_env_var} should raise ValueError
    with pytest.raises(LoadFileException):
        load_module_from_file_location("/some/path/${some_env_var}")

    # Any other environment variable should be processed properly.
    os_environ["some_env_var"] = "some_value"
    try:
        load_module_from_file_location("/some/path/${some_env_var}")
    except:
        pytest.fail("Cannot process any environment variable.")
    finally:
        del os_environ["some_env_var"]

    # Absence of ${some_env_var} should raise LoadFileException

# Generated at 2022-06-24 04:38:26.233699
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa

    # A) Define test config file 'config_test.py'
    config_test_file = Path("./config_test.py")

# Generated at 2022-06-24 04:38:36.831996
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    with pytest.raises(IOError) as e:
        load_module_from_file_location("./not_existing.py")
    assert "Unable to load configuration file" in str(e.value)

    with pytest.raises(LoadFileException) as e:
        load_module_from_file_location("${not_defined_env_var}/some.py")
    assert "environment variables are not set" in str(e.value)

    with pytest.raises(PyFileError) as e:
        load_module_from_file_location("./tests/fixtures/some_syntax_error.py")
    assert "some_syntax_error" in str(e.value)


# Generated at 2022-06-24 04:38:44.647577
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("YES") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("y") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("YUP") == True
    assert str_to_bool("YEP") == True
    assert str_to_bool("True") == True
    assert str_to_bool("true") == True
    assert str_to_bool("T") == True
    assert str_to_bool("t") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True


# Generated at 2022-06-24 04:38:47.569641
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True")
    assert not str_to_bool("False")
    assert str_to_bool("y")
    assert not str_to_bool("N")
    assert str_to_bool("On")
    assert not str_to_bool("oFf")
    assert str_to_bool("1")
    assert not str_to_bool("0")

# Generated at 2022-06-24 04:38:57.954107
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_name = "some_file_name"
    file_path = f"/some/path/{file_name}"
    expected_module_name = file_name
    expected_module_path = file_path

    os_environ["module_name"] = file_name
    os_environ["module_path"] = file_path

    # Test A)
    assert load_module_from_file_location(
        file_path
    ).__name__ == expected_module_name
    assert load_module_from_file_location(
        file_path
    ).__file__ == expected_module_path

    # Test B)
    assert load_module_from_file_location(
        f"${module_name}"
    ).__name__ == expected_module_name
    assert load_module_from_file_

# Generated at 2022-06-24 04:39:08.877492
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Some test variables
    ENV_VAR_NAME = "ENV_VAR_FOR_TESTS"
    PATH_TO_USER_CONFIG = os.path.join(
        os.path.dirname(__file__), "user_config.py"
    )
    PATH_TO_ANOTHER_CONFIG_FILE = os.path.join(
        os.path.dirname(__file__), "another_config.py"
    )
    PATH_TO_YAML = os.path.join(os.path.dirname(__file__), "config.yaml")
    PATH_TO_ANOTHER_YAML = os.path.join(
        os.path.dirname(__file__), "another_config.yaml"
    )

    # A) Test that variables in PATH_TO

# Generated at 2022-06-24 04:39:20.304730
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Returns loaded module provided as a file path.

    :param location:
        It has to be of a string or bytes type.
        You can also use here environment variables
        in format ${some_env_var}.
        Mark that $some_env_var will not be resolved as environment variable.
    :encoding:
        If location parameter is of a bytes type, then use this encoding
        to decode it into string.
    :param args:
        Coresponds to the rest of importlib.util.spec_from_file_location
        parameters.
    :param kwargs:
        Coresponds to the rest of importlib.util.spec_from_file_location
        parameters.
    """
    # Test 1: Use test.py file
    some_module = load_module_from_file_location("./test.py")
   

# Generated at 2022-06-24 04:39:29.815199
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from pathlib import Path
    from sanic.config import load_module_from_file_location
    from tempfile import NamedTemporaryFile


# Generated at 2022-06-24 04:39:34.798505
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function.
    """

    import tempfile

    test_data = {
        "bool_val": True,
        "list_val": [1, 2, 3, 4],
        "dict_val": {"a": 1, "b": 2},
    }

    # Create a temporary file
    with tempfile.NamedTemporaryFile(mode="w+") as config_file:
        for key, val in test_data.items():
            config_file.write(f"{key} = {val}\n")

        config_file.flush()

        config_module = load_module_from_file_location(config_file.name)

        for key, val in test_data.items():
            assert config_module.__dict__[key] == val

    # Create a temporary

# Generated at 2022-06-24 04:39:45.084345
# Unit test for function load_module_from_file_location

# Generated at 2022-06-24 04:39:49.355847
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 1:
    # Create a file inside a temporary directory.

    tmp_dir = Path(__file__).parent.parent
    Path(tmp_dir / "__test_file__.py").touch()
    try:
        module = load_module_from_file_location(tmp_dir / "__test_file__.py")
    finally:
        Path(tmp_dir / "__test_file__.py").unlink()

    assert module.__file__ == str(tmp_dir / "__test_file__.py")

    # Test 2:
    # Create a file inside a temporary directory and then load the file.

    with tempfile.TemporaryDirectory() as tmp_dir:
        Path(Path(tmp_dir) / "__test_file__.py").touch()

# Generated at 2022-06-24 04:39:58.427941
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True, "y is True"
    assert str_to_bool("Y") == True, "Y is True"
    assert str_to_bool("N") == False, "N is False"
    assert str_to_bool("t") == True, "t is True"
    assert str_to_bool("f") == False, "f is False"
    assert str_to_bool("true") == True, "true is True"
    assert str_to_bool("false") == False, "false is False"
    assert str_to_bool("on") == True, "on is True"
    assert str_to_bool("off") == False, "off is False"
    assert str_to_bool("yes") == True, "yes is True"

# Generated at 2022-06-24 04:40:04.419538
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from os import unsetenv

    # Check if it works with file as string argument.
    try:
        environ["SOME_ENV_VAR"] = "/some_env_var/value"
        (
            load_module_from_file_location(
                "tests/example_config.py.example",
                "/some_env_var/${SOME_ENV_VAR}",
            ).test
        ) == "test"
    finally:
        unsetenv("SOME_ENV_VAR")

    # Check if it works with file as pathlib.Path argument.
    # Check if it works with file as string argument.

# Generated at 2022-06-24 04:40:14.787978
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Case: setup conditions
    from os import environ as os_environ

    os_environ["TEST_ENV_VAR"] = "test_env_var"
    test_location = "/test/location/${TEST_ENV_VAR}/test${TEST_ENV_VAR}.py"
    test_location2 = "test_module"

    # Case: try to load the module
    module = load_module_from_file_location(test_location)
    module2 = load_module_from_file_location(test_location2)

    # Case: try to modify the module
    module2.test_attr = "test_attr"

    # Case: check the results
    from .test_module import test_var
    assert module.test_var == test_var
    assert module2.test

# Generated at 2022-06-24 04:40:19.455321
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("T") is True
    assert str_to_bool("1") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("F") is False
    assert str_to_bool("FALSE") is False
    assert str_to_bool("N") is False
    assert str_to_bool("NO") is False
    assert str_to_bool("0") is False
    assert str_to_bool("OFF") is False
    with pytest.raises(ValueError):
        str_to_bool("-1")
    with pytest.raises(ValueError):
        str_to_bool("x")
    with pytest.raises(ValueError):
        str_to_bool("42")

# Generated at 2022-06-24 04:40:30.637043
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Tests when location provided as a string.
    os_environ["CONFIG_ENV_VAR"] = "example_location"
    module = load_module_from_file_location(
        "my_config",
        "./example_location/${CONFIG_ENV_VAR}",
        follow_symlinks=False,
    )
    assert "__file__" in dir(module)
    assert module.__file__ == "./example_location/example_location"
    assert "qwerty" in dir(module)
    assert module.qwerty == "asdfgh"

    # B) Tests when location provided as a bytes.
    os_environ["CONFIG_ENV_VAR"] = "example_location"

# Generated at 2022-06-24 04:40:39.907017
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(
        "test/test_module"
    ).__name__ == "test.test_module"
    assert load_module_from_file_location(
        "test/test_module.py"
    ).__name__ == "test.test_module"
    assert load_module_from_file_location(
        "test/test_module.pyc"
    ).__name__ == "test.test_module"
    assert load_module_from_file_location(
        "test/test_module.pyo"
    ).__name__ == "test.test_module"

    assert load_module_from_file_location(
        Path("test/test_module")
    ).__name__ == "test.test_module"
    assert load_module_from_file_

# Generated at 2022-06-24 04:40:48.225499
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    file_location_as_bytes = b"sanic/__init__.py"
    file_location = "sanic/__init__.py"
    file_location_as_path = Path(file_location)
    another_file_location = "/root/sanic/__init__.py"

    assert load_module_from_file_location(
        file_location_as_bytes, encoding="utf8"
    ) == load_module_from_file_location(file_location) == load_module_from_file_location(  # noqa
        file_location_as_path
    ) == load_module_from_file_location(
        another_file_location
    )

    os_environ["some_env_var"] = "test"

# Generated at 2022-06-24 04:40:57.962629
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:41:07.468870
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("n") is False  # noqa
    assert str_to_bool("yes") is True  # noqa
    assert str_to_bool("y") is True  # noqa
    assert str_to_bool("True") is True  # noqa
    assert str_to_bool("on") is True  # noqa
    assert str_to_bool("0") is False  # noqa
    assert str_to_bool("false") is False  # noqa
    assert str_to_bool("1") is True  # noqa

# Generated at 2022-06-24 04:41:16.354970
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:41:27.685242
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ
    from pathlib import Path

    # Strings
    assert load_module_from_file_location("config")
    assert load_module_from_file_location("config.py")
    assert load_module_from_file_location("/home/user/somewhere/config.py")
    assert load_module_from_file_location(Path("/home/user/somewhere/config.py"))
    assert load_module_from_file_location(
        "${HOME}/somewhere/config.py", use_2to3=False
    )
    assert load_module_from_file_location(
        "${HOME}/somewhere/config.py", use_2to3=False
    )

# Generated at 2022-06-24 04:41:37.110961
# Unit test for function str_to_bool
def test_str_to_bool():
    from pytest import raises

    # Valid bool data
    bool_data_valids = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]


# Generated at 2022-06-24 04:41:44.771515
# Unit test for function str_to_bool
def test_str_to_bool():
    from pytest import raises
    from random import choice

    # Positive check.
    for value in [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]:
        assert str_to_bool(value) is True

    for value in [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]:
        assert str_to_bool(value) is False

    # Negative check.

# Generated at 2022-06-24 04:41:55.684198
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    os_environ["RANDOM_TEXT"] = "random_text"
    location = load_module_from_file_location(
        "tests.test_settings.test_module"
    )

# Generated at 2022-06-24 04:42:07.055333
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sanic.config

    def load_test_config():
        return load_module_from_file_location(
            "tests.unit.test_config.test_config", Path(__file__).parent.parent
        )

    # Case 1 - file path
    module = load_test_config()
    assert module
    assert module.TEST_VAL1
    assert module.TEST_VAL2 == "default"
    assert module.TEST_VAL2_DEPRECATED
    assert module.TEST_VAL3
    assert module.TEST_VAL4 == "default"
    assert module.TEST_VAL5

    # Case 2 - file path as bytes

# Generated at 2022-06-24 04:42:16.849883
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    
    # 1. Test that function load_module_from_file_location can import a module
    #    correctly over HTTP url.
    url = "https://raw.githubusercontent.com/samuel1/sanic-config-loader/master/sanic_config_loader/tests/test_sample_module.py"
    
    module = load_module_from_file_location(url)
    assert module.test_variable == "test_value"

    # 2. Test that function load_module_from_file_location can import a module
    #    correctly from local file system.
    module = load_module_from_file_location("tests/test_sample_module.py")
    assert module.test_variable == "test_value"

    # 3. Test that function load_module_from_file_location can import a module
   

# Generated at 2022-06-24 04:42:24.032316
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    from os import environ as os_environ
    from tempfile import mkstemp

    os_environ["TEST_VAR_ONE"] = "value_one"
    os_environ["TEST_VAR_TWO"] = "value_two"

    # A) Let's create a temporary file for testing.
    test_location, fd = mkstemp(prefix="test_", suffix=".py")
    with open(fd, "w") as f:
        f.write(
            """
            test_var_one = "WELLCOME_TO_TEST_ONE"
            test_var_two = "WELLCOME_TO_TEST_TWO"
        """
        )
    #

# Generated at 2022-06-24 04:42:33.999281
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    t1 = load_module_from_file_location(
        "tests/test_load_module_from_file_location.py"  # remove .py
    )
    assert t1.__name__ == "tests/test_config"
    assert t1.FOO == "bar"

    t2 = load_module_from_file_location(
        "./tests/test_load_module_from_file_location.py"  # remove .py
    )
    assert t2.__name__ == "tests/test_config"
    assert t2.FOO == "bar"

    t3 = load_module_from_file_location(
        "tests/test_load_module_from_file_location.py"  # remove .py
    )

# Generated at 2022-06-24 04:42:42.014037
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    tempdir = tempfile.TemporaryDirectory()
    tempdir_path = Path(tempdir.name)
    tempdir_path.mkdir()

    # Test case: file location is a pathlib.Path object
    file_path = Path(tempdir.name) / "config.py"
    with open(file_path, "w+") as f:
        f.write("VAR_1 = False")

    mod = load_module_from_file_location(file_path)
    assert mod.VAR_1 is False

    # Test case: file location is in format "${some_env_var}/config.py"
    # where "some_env_var" is an environment variable.
    file_name = "config.py"

# Generated at 2022-06-24 04:42:52.274694
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Testing if invalid input throws proper exceptions.
    with pytest.raises(ValueError):
        load_module_from_file_location("$some_env_var")
    with pytest.raises(ValueError):
        load_module_from_file_location("${some_env_var")
    with pytest.raises(ValueError):
        load_module_from_file_location("some_env_var}")
    with pytest.raises(IOError):
        load_module_from_file_location("/${some_env_var}")
    with pytest.raises(IOError):
        load_module_from_file_location("/usr/bin")

# Generated at 2022-06-24 04:42:59.518271
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("NO") == False
    assert str_to_bool("f") == False
    assert str_to_bool("FALSE") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:43:10.389944
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys

    location_str = "sanic/test_module.py"
    location_bytes = location_str.encode()
    location_path = Path(location_str)

    # 1) No arguments
    mod_by_str = load_module_from_file_location(location_str)
    mod_by_bytes = load_module_from_file_location(location_bytes)
    mod_by_path = load_module_from_file_location(location_path)

    assert mod_by_str.arg1 == 1
    assert mod_by_bytes.arg1 == 1
    assert mod_by_path.arg1 == 1

    # 2) With positional only arguments.
    #    "sanic.server" is the name of the module.
    mod_by_str = load_module_from_file_

# Generated at 2022-06-24 04:43:18.028643
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("TrUE") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("No") == False
    assert str_to_bool("oFF") == False
    assert str_to_bool("0") == False
    try:
        assert str_to_bool("foo")
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 04:43:28.382178
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:43:35.108492
# Unit test for function str_to_bool
def test_str_to_bool():

    assert str_to_bool("1")
    assert not str_to_bool("0")
    assert str_to_bool("on")
    assert str_to_bool("OFF")
    assert not str_to_bool("FALSE")
    assert str_to_bool("true")
    assert not str_to_bool("nOb")
    assert str_to_bool("Y")
    assert not str_to_bool("n")
    assert str_to_bool("yep")
    assert not str_to_bool("no")
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert str_to_bool("enable")
    assert not str_to_bool("Disable")
    assert str_to_bool("YES")
    assert not str_to_bool("f")

# Generated at 2022-06-24 04:43:43.331607
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa: D202
    assert str_to_bool("1") is True
    assert str_to_bool("y") is True
    assert str_to_bool("True") is True
    assert str_to_bool("0") is False
    assert str_to_bool("f") is False
    assert str_to_bool("FALSE") is False
    with pytest.raises(ValueError):
        str_to_bool("qwerty")

# Generated at 2022-06-24 04:43:50.225510
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False
    assert str

# Generated at 2022-06-24 04:43:52.232336
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa: D103

    from pytest import raises

    asser

# Generated at 2022-06-24 04:44:00.213570
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # No environment variable, pure file path.
    location = "/some/path/name.py"
    module = load_module_from_file_location(location)
    assert module.__file__ == location
    assert module.__name__ == "name"

    # No environment variable, pure file path without .py ending.
    location = "/some/path/name"
    module = load_module_from_file_location(location)
    assert module.__file__ == location
    assert module.__name__ == "config"

    # Environment variable with bytes path
    # (only for Python >= 3.5), encoding is utf8 by default.
    # For now we will skip this test for Python < 3.5.

# Generated at 2022-06-24 04:44:05.805796
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    """Unit test for function str_to_bool."""
    assert str_to_bool("ON") is True
    assert str_to_bool("t") is True
    assert str_to_bool("TRUE") is True

    assert str_to_bool("0") is False
    assert str_to_bool("n") is False
    assert str_to_bool("FALSE") is False

    try:
        str_to_bool("42")
    except ValueError:
        pass
    else:
        raise AssertionError("ValueError should be raised!")

# Generated at 2022-06-24 04:44:16.780460
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unittest for load_module_from_file_location method."""
    import os
    import shutil
    import tempfile

    # Prepare conf file with its own environment variables
    tmp_dir = tempfile.mkdtemp()
    conf_file_path = os.path.join(tmp_dir, "test.py")
    with open(conf_file_path, "w") as conf_file:
        conf_file.write("FOO = 'foo'\n")
        conf_file.write("BAR = 'bar'\n")

    # Create config module from conf file
    # (don't be confused with the name,
    # module_name is a python module).
    module_name = load_module_from_file_location(conf_file_path)

# Generated at 2022-06-24 04:44:28.485781
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from .test_module_in_file import MODULE_DATA

    # Testing for file that is in directory,
    # which is set in environment variable
    # variable VALUE does not exists in environment,
    # so the exception will be raised.
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "$VALUE/sanic/test/test_module_in_file.py"
        )

    # Setting VALUE as a path of tests directory
    os_environ["VALUE"] = str(
        Path(__file__).absolute().parent.parent.parent.absolute()
    )

    # Now we testing if module was succesfully loaded
    # via file path.

# Generated at 2022-06-24 04:44:37.221469
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ, remove
    from pathlib import Path
    from unittest.mock import patch

    from pytest import raises

    from app import app
    from sanic.utils import load_module_from_file_location

    SOME_ENV_VAR = "SOME_ENV_VAR"
    SOME_ENV_VAR_VALUE = "some_env_var_value"

    config_path = Path(__file__).parent / "config.py"
    config_path_with_env_var = (
        Path(__file__).parent / f"config_{SOME_ENV_VAR}.py"
    )

    # Assert that files don't exist.
    assert not config_path.exists()
    assert not config_path_with_env_var.exists()

    #

# Generated at 2022-06-24 04:44:44.992068
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic.config import Config
    from tempfile import TemporaryDirectory
    from types import ModuleType
    from os import environ as os_environ
    from os.path import expanduser

    tmp_dir = TemporaryDirectory(prefix="load_module_from_file_location")
    tmp_dir.cleanup()
    tmp_dir.__enter__()


# Generated at 2022-06-24 04:44:52.984458
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import pytest

    from tempfile import TemporaryDirectory

    from httpx import get, post

    from sanic import Sanic
    from sanic.request import Request
    from sanic.exceptions import PyFileError, LoadFileException

    def test_fn(request: Request):
        return "OK"

    # Test proper work with regular use cases: file name, file path and
    # environment variables substitution in file paths.
    with pytest.warns(None) as warning_list:

        # __main__ is a config file name.
        os_environ["config_file_path"] = "config.py"
        app = Sanic("test_app")
        app.config.from_envvar("config_file_path")
        app.add_route(test_fn, "/")

# Generated at 2022-06-24 04:44:58.848947
# Unit test for function str_to_bool
def test_str_to_bool():
    import pytest
    assert str_to_bool('on') == True
    assert str_to_bool('off') == False
    assert str_to_bool('enabled') == True
    assert str_to_bool('disabled') == False
    with pytest.raises(ValueError):
        str_to_bool('bla')

# Generated at 2022-06-24 04:45:07.248729
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from unittest import mock
    from types import ModuleType

    # Test B)
    with mock.patch.dict("os.environ", clear=True):
        with mock.patch("os.environ.keys") as environ_keys:
            environ_keys.return_value = []
            with mock.patch("sanic.utils.load_module_from_file_location") as load_module_from_file_location_mock:
                load_module_from_file_location_mock.side_effect = LoadFileException
                with pytest.raises(LoadFileException):
                    load_module_from_file_location("/tmp/${some_env_var}")

    # Test A) and C)