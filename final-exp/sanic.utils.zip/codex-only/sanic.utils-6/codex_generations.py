

# Generated at 2022-06-24 04:35:14.171615
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Check if module loading from string path works
    module = load_module_from_file_location("test_module", "tests/test_module")

    assert module is not None
    assert hasattr(module, "TEST_ATTR")
    assert module.TEST_ATTR == "TEST_VALUE"

    # Check if module loading with environ variables works
    os_environ["TEST_ENV_VAR"] = "test_module"
    module = load_module_from_file_location(
        "${TEST_ENV_VAR}", "tests/test_module"
    )

    assert module is not None
    assert hasattr(module, "TEST_ATTR")
    assert module.TEST_ATTR == "TEST_VALUE"

# Generated at 2022-06-24 04:35:22.669923
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    from unittest.mock import patch

    fake_path = "fake/path/"
    location = "fake.py"

    _os_environ = {}

    def _mocked_import_string(location):
        if location in ["fake1", "fake2"]:
            # If import string of a form `module.submodule`
            # then return module.
            return types.ModuleType("fake")
        else:
            raise ValueError(f"Invalid import string {location}")


# Generated at 2022-06-24 04:35:28.208858
# Unit test for function str_to_bool
def test_str_to_bool():
    test_sets = [('t', True), ('True', True),
                 ('tRuE', True), ('TRUE', True),
                 ('f', False), ('False', False),
                 ('fAlsE', False), ('FALSE', False)
                 ]
    for test_set in test_sets:
        assert str_to_bool(test_set[0]) == test_set[1]



# Generated at 2022-06-24 04:35:31.965532
# Unit test for function str_to_bool
def test_str_to_bool(): 
    assert str_to_bool("False") == False
    assert str_to_bool(0) == False
    assert str_to_bool(1) == True
    assert str_to_bool(True) == True
    assert str_to_bool(False) == False

# Generated at 2022-06-24 04:35:37.026147
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    class TestModule:
        """Test module"""

    test_module = load_module_from_file_location(TestModule)
    assert test_module.__name__ == "TestModule"
    assert test_module.__doc__ == "Test module"



# Generated at 2022-06-24 04:35:45.172964
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("t") is True
    assert str_to_bool("T") is True

    assert str_to_bool("false") is False
    assert str_to_bool("FALSE") is False
    assert str_to_bool("f") is False
    assert str_to_bool("F") is False

# Generated at 2022-06-24 04:35:54.988748
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:36:06.193001
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test 0:
    # Test for exception when trying to load module not from file location.
    with pytest.raises(ValueError, match="Unable to load configuration"):
        load_module_from_file_location(
            location="sanic", encoding="utf8"  # any encoding
        )

    # Test 1:
    # Test for exception when trying to load module from file location
    # and there is no such file.
    with pytest.raises(IOError, match="Unable to load configuration file"):
        load_module_from_file_location(location="I/am/sure/this/file/doesnt/exist")

    # Test 2:
    # Test for exception when trying to load module from file location
    # and there is some error in file.

# Generated at 2022-06-24 04:36:16.616534
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    """Should work as expected."""
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("Yes") == True
    assert str_to_bool("NO") == False
    assert str_to_bool("true") == True
    assert str_to_bool("false") == False
    assert str_to_bool("Y") == True
    assert str_to_bool("N") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("yup") == True
    assert str_to_bool("nope") == False
    assert str_to_bool("on") == True
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:36:27.026826
# Unit test for function str_to_bool
def test_str_to_bool():
    """Unit test for str_to_bool function"""
    assert str_to_bool("on") is True
    assert str_to_bool("off") is False
    assert str_to_bool("YUP") is True
    assert str_to_bool("nope") is False
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("yepp") is True
    assert str_to_bool("nop") is False
    assert str_to_bool("YES") is True
    assert str_to_bool("NO") is False
    assert str_to_bool("Yes") is True
    assert str_to_bool("No") is False


# Generated at 2022-06-24 04:36:36.502731
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:36:42.884749
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("N") is False
    assert str_to_bool("No") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str

# Generated at 2022-06-24 04:36:54.078217
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-24 04:37:05.587576
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from sanic.exceptions import LoadFileException, PyFileError

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    #    This test fails on windows due to wrong usage of it.
    #    But as this code is for Linux machines, it's not a problem.
    #    Feel free to add this code to your `pytest.ini` file:
    #
    #         [pytest]
    #         xfail_strict=True
    #
    with pytest.raises(LoadFileException) as exc:
        _ = load_module_from_file_location(
            "some_name", "${some_env_var}/some/path"
        )

# Generated at 2022-06-24 04:37:15.282237
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-24 04:37:25.019575
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unittest for function load_module_from_file_location"""
    # A) Check import of file as file path
    import_path_file = load_module_from_file_location(
        "test_configs/config_a.py"
    )
    assert hasattr(import_path_file, "a")
    assert import_path_file.a == 1

    # B) Check import of file as file name
    import_name_file = load_module_from_file_location("config_a.py")
    assert hasattr(import_name_file, "a")
    assert import_name_file.a == 1

    # C) Check import of file as file name with arguments

# Generated at 2022-06-24 04:37:34.905637
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa

    import tempfile
    import os

    os.environ["TEST_LOAD_MODULE_FROM_FILE_LOCATION_ENV_VAR"] = (
        "TEST_LOAD_MODULE_FROM_FILE_LOCATION_ENV_VAR_VAL"
    )

# Generated at 2022-06-24 04:37:42.213578
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('yes')
    assert str_to_bool('y')
    assert str_to_bool('yep')
    assert str_to_bool('yup')
    assert str_to_bool('t')
    assert str_to_bool('true')
    assert str_to_bool('on')
    assert str_to_bool('enable')
    assert str_to_bool('enabled')
    assert str_to_bool('1')

    assert not str_to_bool('no')
    assert not str_to_bool('n')
    assert not str_to_bool('f')
    assert not str_to_bool('false')
    assert not str_to_bool('off')
    assert not str_to_bool('disable')
    assert not str_to_bool('disabled')

# Generated at 2022-06-24 04:37:51.538345
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import random
    import string

    # Set up environment variables for next test
    # (for OS where $SOME_ENV_VAR is not set).
    tested_env_var = "SOME_ENV_VAR"
    test_env_var_value = "".join(
        random.choices(
            string.ascii_uppercase + string.ascii_lowercase, k=10
        )
    )
    os_environ[tested_env_var] = test_env_var_value

    # Create a module that have to be loaded
    # and write it to a temporary file.
    test_config_content = f"""
    
    test_config_content = {{"test_env_var": "{test_env_var_value}"}}
    """
    loaded_test_module = load

# Generated at 2022-06-24 04:37:58.029661
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Tests for load_module_from_file_location function.
    """

    # Not existing file
    os_environ["TEST_ENV_VAR"] = "not_exist"
    with pytest.raises(LoadFileException) as exception:
        load_module_from_file_location(
            "/some/path/to/${TEST_ENV_VAR}_file.py"
        )
    assert exception.match("The following environment variables are not set: "
                           "${TEST_ENV_VAR}")

    # Existing file
    os_environ["TEST_ENV_VAR"] = "test_files"

# Generated at 2022-06-24 04:38:09.280424
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") is True
    assert str_to_bool("YeS") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("YEP") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("YUP") is True
    assert str_to_bool("T") is True
    assert str_to_bool("true") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("On") is True
    assert str_to_bool("oN") is True
    assert str_to_bool("Enable") is True
    assert str_to_bool("Enabled") is True

# Generated at 2022-06-24 04:38:18.566087
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    def _assert_raise(exc_type, exc_msg, func):
        with pytest.raises(exc_type) as exc_info:
            func()
        assert str(exc_info.value) == exc_msg

    with NamedTemporaryFile() as local_file:
        local_file.write(b"key = 'value'")
        local_file.flush()

        # Test with path-like object
        assert (
            load_module_from_file_location(local_file.name)
            is load_module_from_file_location(Path(local_file.name))
        )

        # Test with file path
        module = load_module_from_file_location(local_file.name)

# Generated at 2022-06-24 04:38:26.261211
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:38:36.831674
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os
    import pathlib
    from tempfile import NamedTemporaryFile

    # Create temporary file, with custom content.
    with NamedTemporaryFile(mode="w+t", delete=False) as temp_file:
        temp_file.write("some_content = 42")

    # Create temporary folder, with custom content.
    temp_folder = pathlib.Path("/tmp/some_folder")
    temp_folder.mkdir()

    with NamedTemporaryFile(
        mode="w+t", delete=False, dir=temp_folder
    ) as temp_folder_file:
        temp_folder_file.write("some_file_content = '42'")

    with NamedTemporaryFile(
        mode="w+t", delete=False
    ) as temp_folder_file_py:
        temp_folder

# Generated at 2022-06-24 04:38:47.409211
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile

    location = tempfile.NamedTemporaryFile(mode="w", suffix=".py")
    location.write(
        """
import os
test = True
test_environ = os.environ['test_environ']
test_environ_value = os.environ['test_environ_value']
    """
    )
    location.flush()
    os_environ['test_environ'] = 'True'
    os_environ['test_environ_value'] = 'os.environ.get'

    module = load_module_from_file_location(location.name)
    assert module.__name__ == 'config'
    assert module.__file__ == location.name
    assert module.test
    assert module.test_environ.__name__ == 'str'

# Generated at 2022-06-24 04:38:56.316164
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import mkstemp
    from os import close, remove, environ
    from pathlib import Path

    # Create the config file
    file_handle, file_path = mkstemp(suffix=".py")
    with open(file_path, "w") as tmp_file:
        tmp_file.write("TEST_VAR1 = 1\nTEST_VAR2 = 2\n")
    close(file_handle)
    base_path = Path(file_path).parent

    # Test file_path
    test_module = load_module_from_file_location(file_path)
    assert test_module.TEST_VAR1 == 1
    assert test_module.TEST_VAR2 == 2

    # Test str(file_path)
    test_module = load_module_from_

# Generated at 2022-06-24 04:39:08.172906
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("Y")
    assert str_to_bool("YES")
    assert str_to_bool("yep")
    assert str_to_bool("Yep")
    assert str_to_bool("yup")
    assert str_to_bool("Yup")
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("on")
    assert str_to_bool("On")
    assert str_to_bool("enable")
    assert str_to_bool("Enable")
    assert str_to_bool("enabled")

# Generated at 2022-06-24 04:39:09.000542
# Unit test for function str_to_bool
def test_str_to_bool():
    # Tests for valid values
    asser

# Generated at 2022-06-24 04:39:20.405573
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Function tests if functions load_module_from_file_location works
    as it should:

    1) Checks if it throws an error if Path object is passed as a location.
    2) Checks if it throws an error if string without '/' is passed as a location.
    3) Checks if it throws an error if string with '/' is passed as a location.
    3) Checks if it throws an error if string with '/' is passed as a location.
    4) Checks if it works properly with a string.
    5) Checks if it works properly with a string and environment variables.
    """

    # 1) Checks if it throws an error if Path object is passed as a location.
    with pytest.raises(IOError):
        load_module_from_file_location(Path("some_module_name"))

    # 2) Checks if it throws

# Generated at 2022-06-24 04:39:29.034934
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test for the function load_module_from_file_location."""
    from os import remove
    from tempfile import mkstemp
    from textwrap import dedent

    path = mkstemp(suffix=".py")[1]
    try:
        with open(path, "w") as py_file_config:
            py_file_config.write(
                dedent(
                    """\
                A = 20
                B = 'some string'
                """
                )
            )
        cfg = load_module_from_file_location(path)
        assert cfg.A == 20
        assert cfg.B == "some string"
    finally:
        remove(path)

# Generated at 2022-06-24 04:39:35.795481
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Passing string absolute path to 'some_module' module.
    module = load_module_from_file_location("tests.files.some_module")
    assert module.some_value == 42
    assert module.__file__ == "tests/files/some_module.py"

    # Passing string relative path to 'some_module' module.
    module = load_module_from_file_location("files.some_module")
    assert module.some_value == 42
    assert module.__file__ == "tests/files/some_module.py"

    # Passing Path object to 'some_module' module.
    module = load_module_from_file_location(Path("tests") / "files" / "some_module.py")
    assert module.some_value == 42

# Generated at 2022-06-24 04:39:46.545308
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("t") == True
    assert str_to_bool("f") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("true") == True
    assert str_to_bool("false") == False
    assert str_to_bool("on") == True
    assert str_to_bool("off") == False
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("N") == False
    assert str_

# Generated at 2022-06-24 04:39:56.565733
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ

    environ["some_env_var"] = "some_new"
    some_module = load_module_from_file_location(
        "some_module_name", "/some/path/${some_env_var}"
    )
    assert some_module.__file__ == "/some/path/some_new"
    del environ["some_env_var"]

    assert str_to_bool("false") is False
    assert str_to_bool("true") is True

    with pytest.raises(ValueError):
        str_to_bool("not_bool_value")

# Generated at 2022-06-24 04:40:09.304643
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False

# Generated at 2022-06-24 04:40:13.397270
# Unit test for function str_to_bool
def test_str_to_bool():
    true_str = ["y", "yes", "t", "true", "on", "1"]
    false_str = ["n", "no", "f", "false", "off", "0"]
    for val in true_str:
        assert str_to_bool(val)
    for val in false_str:
        assert not str_to_bool(val)

# Generated at 2022-06-24 04:40:26.232239
# Unit test for function str_to_bool
def test_str_to_bool():
    from pytest import raises

    assert str_to_bool("") is False
    assert str_to_bool("off") is False
    assert str_to_bool("0") is False
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("on") is True
    assert str_to_bool("1") is True
    assert str_to_bool("y") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("T") is True
    assert str_to_bool("yesterday") is True
    assert str_to_bool("whatever") is True

# Generated at 2022-06-24 04:40:31.184803
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import mkstemp
    from os import fdopen

    fd, file_name = mkstemp()
    file = fdopen(fd, "w+")
    file.write('test_var = "some_val"')
    file.close()

    assert load_module_from_file_location(file_name).test_var == "some_val"

# Generated at 2022-06-24 04:40:36.529908
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    os_environ["PATH_TO_PYTHON_FILE"] = os.path.dirname(__file__)
    module = load_module_from_file_location(
        "sanic.exceptions.fixtures.custom_config",
        "${PATH_TO_PYTHON_FILE}/../exceptions/fixtures/custom_config.py",
    )
    assert module.KEY == "yep"

# Generated at 2022-06-24 04:40:42.247304
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("False") is False
    assert str_to_bool("false") is False
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("0") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False
    assert str_to_bool("disabled") is False
    assert str_to_bool("f") is False

    assert str_to_bool("True") is True
    assert str_to_bool("true") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True

# Generated at 2022-06-24 04:40:54.524025
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import random
    import string
    import os

    # Test with a non existing path
    # The path will be random
    not_existing_path = "".join([random.choice(string.ascii_letters) for _ in range(16)])
    with pytest.raises(LoadFileException):
        assert load_module_from_file_location(not_existing_path, "./")

    # Test with corrupted path
    # The path will be a path to a file that exists
    # But the path will be corrupted
    # So "." will be added at the end of the path
    with tempfile.NamedTemporaryFile() as tmp_file:
        corrupted_path = tmp_file.name + "."
        with pytest.raises(LoadFileException):
            assert load_module_from_file

# Generated at 2022-06-24 04:41:02.189932
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        os_environ["MY_ENV_VAR"] = "0"
        os_environ["MY_ENV_VAR2"] = "0"
    except Exception:
        pass  # environment variable MY_ENV_VAR used in tests is already defined

    print("Running tests for load_module_from_file_location...")


# Generated at 2022-06-24 04:41:10.883482
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location"""
    import sanic.config

    sanic.config.load_module_from_file_location = load_module_from_file_location

    import sys
    import inspect
    import os
    import tempfile
    import shutil
    import re
    import pytest
    import pathlib
    from pprint import pformat

  # A) Check if location contains any environment variables
  #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.

    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.

# Generated at 2022-06-24 04:41:17.536823
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile
    from pathlib import Path
    from copy import copy

    # 1) Test for valid file path
    # Create config file
    test_config_value = "test_value"
    test_file_location = os.path.join(
        tempfile.gettempdir(), "test_file_location.py"
    )
    with open(test_file_location, "w") as test_file:
        test_file.write(f"test_config_variable = '{test_config_value}'")

    # Get module from file location
    test_module = load_module_from_file_location(test_file_location)

    # Test if correct module was loaded

# Generated at 2022-06-24 04:41:25.034701
# Unit test for function load_module_from_file_location

# Generated at 2022-06-24 04:41:30.319947
# Unit test for function str_to_bool
def test_str_to_bool():

    assert str_to_bool("y") is True
    assert str_to_bool("F") is False

    assert str_to_bool("Y") is True
    assert str_to_bool("yES") is True
    assert str_to_bool("YeP") is True
    assert str_to_bool("yUp") is True
    assert str_to_bool("on") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("True") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("TRuE") is True
    assert str_to_bool("1") is True
    assert str_to_bool("yes") is True

    assert str_to_bool("n") is False

# Generated at 2022-06-24 04:41:38.243294
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test env variable resolution, that is:
    #    A.1) Check if environment variable substitution works
    #    A.2) Check if using environment variable that isn't set
    #         raises an exception.
    #    A.3) Check if using environment variable in format $some_var
    #         raises an exception.
    #    A.4) Check if using environment variable in format ${some_var}
    #         raises an exception, when some_var is not set.
    #    A.5) Check if using environment variable in format ${some_var}
    #         doesn't raise an exception, when some_var is set.
    os_environ["var_to_substitute"] = "var_to_substitute_value"

# Generated at 2022-06-24 04:41:42.681076
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # location can be str
    load_module_from_file_location('builtins')
    # location can be bytes
    load_module_from_file_location(b'builtins')
    # location can be Path
    from pathlib import Path
    load_module_from_file_location(Path('builtins'))

# Generated at 2022-06-24 04:41:48.615770
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("True") is True
    assert str_to_bool("False") is False
    assert str_to_bool("T") is True
    assert str_to_bool("F") is False

# Generated at 2022-06-24 04:41:56.925286
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    #

    # Check if function can handle bytes
    test_string_bytes: bytes = b"test_string_bytes"
    test_module = load_module_from_file_location(test_string_bytes)
    if not test_module.__file__ == test_string_bytes.decode("utf8"):
        raise IOError("Unable to handle bytes")

    # Check if function can handle str
    test_string_str: str = "test_string_str"
    test_module = load_module_from_file_location(test_string_str)
    if not test_module.__file__ == test_string_str:
        raise IOError("Unable to handle str")

    # Check if function can handle Path

# Generated at 2022-06-24 04:42:07.948332
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    tempdir = Path(tempfile.mkdtemp())
    empty_file_path: str = str(tempdir / "empty.py")
    with open(empty_file_path, "w") as empty_file:
        empty_file.write("")
    module = load_module_from_file_location(empty_file_path)
    assert module.__name__ == "empty"

    module = load_module_from_file_location(Path(empty_file_path))
    assert module.__name__ == "empty"

    with pytest.raises(IOError):
        load_module_from_file_location(empty_file_path[:-1])

    with pytest.raises(IOError):
        os_environ["DUMMY_ENV_VAR"] = "dummy_val"
        #

# Generated at 2022-06-24 04:42:17.014246
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # You need to run this test in the project root directory with:
    #
    #    pipenv run python tools/testing.py

    # Load module from a file in the project root directory
    # and check if it has correct name and __file__ attribute.
    module = load_module_from_file_location("./tests/modules/mod.py")
    assert module.__name__ == "tests.modules.mod"
    assert module.__file__ == "./tests/modules/mod.py"

    # Re-load module from the same file, but with different name
    #  and check if it has correct name and __file__ attribute.
    module_2 = load_module_from_file_location(
        "./tests/modules/mod.py", name="mod_2"
    )
    assert module_2.__name__

# Generated at 2022-06-24 04:42:26.851664
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # test_load_module_from_file_location_1
    # Test if function is able to load module from the file.
    sample_module = load_module_from_file_location("sanic.response")
    assert sample_module.__name__ == "sanic.response"

    # test_load_module_from_file_location_2
    # Test for step A) described in a documentation of the function.
    sample_module = load_module_from_file_location("sanic.${NOWHERE}")
    assert sample_module is None


# Unit tests for function str_to_bool

# Generated at 2022-06-24 04:42:34.192990
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    tmp_path = Path(__file__).parent
    location = (
        tmp_path
        .joinpath("utils.py")
        .relative_to(tmp_path.parent)
        .as_posix()
    )
    assert load_module_from_file_location(location).__name__ == "sanic.utils"
    location = (
        tmp_path
        .parent
        .joinpath("./test/test_testconfig.py")
        .relative_to(tmp_path.parent)
        .as_posix()
    )
    assert (
        load_module_from_file_location(location).__name__ == "sanic.test.test_testconfig"
    )

# Generated at 2022-06-24 04:42:44.421943
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    assert os.getcwd() == \
           load_module_from_file_location("./tests/test_load_module_from_file_location.py").__file__
    os.environ["test_load_module_from_file_location"] = "sanic"
    assert os.getcwd() + "/tests/test_load_module_from_file_location.py" == \
           load_module_from_file_location(
               "./tests/test_load_module_from_file_location.py").__file__

# Generated at 2022-06-24 04:42:53.348986
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    test_file_1_content = """
    test_variable_1 = 1
    test_variable_2 = 2
    """

    test_file_2_content = """
    test_variable_1 = 3
    test_variable_2 = 4
    """

    test_file_3_content = """
    test_variable_1 = 5
    __package__ = ''
    """

    # Create a test file with environment variables in it.
    # I'm using the tempfile.NamedTemporaryFile here instead of
    # simply open(foo_name, 'w') to ensure the file is properly
    # closed and cleaned up after the test.
    os.environ["test_env_var_1"] = "test_env_var_1_value"

# Generated at 2022-06-24 04:42:57.230183
# Unit test for function str_to_bool
def test_str_to_bool():
    # Test for negative result
    assert str_to_bool("n") == False

    # Test for positive result
    assert str_to_bool("yes") == True

    # Test for failure
    # Should raise ValueError exception
    try:
        str_to_bool("some")
    except ValueError:
        pass
    else:
        raise ValueError("Test failed")

# Generated at 2022-06-24 04:43:04.793103
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("tRuE") is True
    assert str_to_bool("yEst") is True
    assert str_to_bool("1") is True

    assert str_to_bool("False") is False
    assert str_to_bool("faLsE") is False
    assert str_to_bool("n0") is False
    assert str_to_bool("0") is False

    try:
        str_to_bool("2")
        assert False
    except ValueError:
        pass

# Generated at 2022-06-24 04:43:16.195774
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    fixture_location = Path(__file__).parent / "sanic_example_config.py"

    # Test loading module by file path with environment variable.
    os_environ["SANIC_EXAMPLE_CONFIG_PATH"] = str(fixture_location)
    config = load_module_from_file_location(
        "/some/path/to/${SANIC_EXAMPLE_CONFIG_PATH}"
    )

    assert config.DATABASE_URL == "some_value"
    assert config.DATABASE_PORT == 123
    assert config.NOT_A_CONFIG == "NOT_A_CONFIG"
    assert config.HOST == "127.0.0.1"
    assert config.PORT == 8080

    # If there is no environment variable associated with
    # ${SOMETHING_NOT

# Generated at 2022-06-24 04:43:27.235474
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool('true') == True
    assert str_to_bool('TRUE') == True
    assert str_to_bool('True') == True
    assert str_to_bool('t') == True
    assert str_to_bool('T') == True
    assert str_to_bool('1') == True
    assert str_to_bool('on') == True
    assert str_to_bool('ON') == True
    assert str_to_bool('On') == True
    assert str_to_bool('y') == True
    assert str_to_bool('yes') == True
    assert str_to_bool('Y') == True
    assert str_to_bool('Yes') == True
    assert str_to_bool('YES') == True
    assert str_to_bool('yep') == True

# Generated at 2022-06-24 04:43:36.736443
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("ON") is True
    assert str_to_bool("oFf") is False
    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("t") is True
    assert str_to_bool("f") is False
    assert str_to_bool("true") is True
    assert str_to_bool("false") is False
    assert str_to_bool("enable") is True
    assert str_to_bool("disable") is False
    assert str_to_bool("enabled") is True

# Generated at 2022-06-24 04:43:42.617474
# Unit test for function str_to_bool
def test_str_to_bool():
    test_data = {"y": True, "yes": True, "1": True, "n": False, "no": False}
    for val in test_data.keys():
        assert str_to_bool(val) == test_data[val]

# Generated at 2022-06-24 04:43:50.441470
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("0") == False
    assert str_to_bool("n") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("disabled") == False
    assert str_to_bool("1") == True
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("t") == True
    assert str_

# Generated at 2022-06-24 04:43:59.998075
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:44:07.306014
# Unit test for function str_to_bool
def test_str_to_bool():
    from pytest import raises

    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("Y")
    assert str_to_bool("YeS")
    assert str_to_bool("1")
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("TRUE")
    assert str_to_bool("f") is False
    assert str_to_bool("F") is False
    assert str_to_bool("False") is False
    assert str_to_bool("0") is False
    assert str_to_bool("no") is False
    assert str_to_bool("n") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:44:19.249723
# Unit test for function str_to_bool
def test_str_to_bool():
    truthy = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]
    falsy = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]
    for case in truthy:
        assert str_to_bool(case)
    for case in falsy:
        assert not str_to_bool(case)


if __name__ == "__main__":
    import pytest
    pytest.main(["-s", __file__])

# Generated at 2022-06-24 04:44:28.686435
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location"""
    import random
    import string

    import pytest

    from sanic.config import load_module_from_file_location

    # 1) Location as bytes
    random_string = "".join(
        random.choice(string.ascii_lowercase) for _ in range(10)
    )
    random_string_as_bytes = random_string.encode()
    random_string_as_bytes_with_env_vars = "${TEST_VARIABLE}".encode()
    TEST_VARIABLE = "some_value"

    # 1.1) location is just a string
    with pytest.raises(Exception):
        load_module_from_file_location(random_string_as_bytes)
    # 1.2) location

# Generated at 2022-06-24 04:44:38.715180
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-24 04:44:46.437274
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 1) For simple file location.
    module_1 = load_module_from_file_location("test_config1.py")
    assert module_1.some_test_var == "some_test_val"

    # 2) For file location with paths.
    module_2 = load_module_from_file_location("./test_config2.py")
    assert module_2.some_test_var == "some_test_val"

    # 3) For file location with paths containing environment variables
    os_environ["TEST_ENV_VAR"] = "."
    module_3 = load_module_from_file_location(
        "${TEST_ENV_VAR}/test_config3.py"
    )

# Generated at 2022-06-24 04:44:57.125108
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    _test_values = [
        "./sanic/test_utils/test_modules/test_module0",
        "./sanic/test_utils/test_modules/test_module1",
        "./sanic/test_utils/test_modules/test_module2",
        b"./sanic/test_utils/test_modules/test_module3",
        b"./sanic/test_utils/test_modules/test_module4",
    ]

    _test_encoding = "utf8"

    for _test_value in _test_values:
        assert load_module_from_file_location(
            _test_value, encoding=_test_encoding
        ).test_var == True  # noqa


# Generated at 2022-06-24 04:45:06.839301
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("t") == True
    assert str_to_bool("n") == False
    assert str_to_bool("false") == False
    assert str_to_bool("f") == False
    assert str_to_bool("yes") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("no") == False
    assert str_to_bool("off") == False
    assert str_to_bool("y") == True
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    try:
        str_to_bool("some_string")
        assert False
    except ValueError:
        assert True