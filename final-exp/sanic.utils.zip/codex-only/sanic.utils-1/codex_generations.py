

# Generated at 2022-06-24 04:35:04.872046
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import pathsep, environ
    from pathlib import Path
    from tempfile import TemporaryDirectory
    import textwrap

    pytestmark = pytest.mark.asyncio

    # A) Check if environment variables in location are resolved.
    #  If the location parameter is of a string type and
    #  contains environment variables in format ${some_env_var},
    #  then it should be resolved.
    #  B) Check if file location is resolved.
    #  If the location parameter is of a string type,
    #  then it should be resolved.

# Generated at 2022-06-24 04:35:11.883246
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("on") == True
    assert str_to_bool("n") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("y") == True
    assert str_to_bool("true") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("off") == False
    assert str_to_bool("f") == False
    assert str_to_bool("enable") == True
    assert str_to_bool("t") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("N") == False
    assert str_to_bool("YES") == True
    assert str_

# Generated at 2022-06-24 04:35:22.338342
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # The simplest module having 1 variable xyz = "some_value"
    path_to_module = (
        Path(__file__).parent.parent / "tests" / "fixtures" / "module.py"
    )
    loaded_module = load_module_from_file_location(
        path_to_module, encoding="utf8"
    )

    assert loaded_module.xyz == "some_value"

    #
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    #
    # B) Check these variables exists in environment.
    #
    # C) Substitute them in location.
    #

# Generated at 2022-06-24 04:35:30.559464
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Prepare test environment
    prepare_env = [
        "export some_var=some_value",
        "export PYTHON_PATH=/some/path/to/python/file",
        "export PYTHON_PATH2=/some/path/to/python/file2",
        "echo 'CONFIG_VALUE=True' > config",
    ]

    for cmd in prepare_env:
        subprocess.call(cmd, shell=True)

    # Test 1
    some_module = load_module_from_file_location("${PYTHON_PATH}")

    assert some_module.CONFIG_VALUE

    # Test 2
    some_module = load_module_from_file_location("${some_var}", "config")

    assert some_module.CONFIG_VALUE

    # Test 3
    some_

# Generated at 2022-06-24 04:35:44.702333
# Unit test for function str_to_bool
def test_str_to_bool():
    """Unit test for function str_to_bool"""
    # A. First test if True values will work
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("1")

    # B. Test if False values will work
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("0")

    # C. Test if ValueError will be raised
    try:
        str_to_bool("foo")
    except ValueError:
        # We expected ValueError, so it's alright
        pass
   

# Generated at 2022-06-24 04:35:50.540497
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile(mode="w", suffix=".py") as conf_file:
        conf_file.write("""test_var_1 = "test_1"\n""")
        conf_file.flush()
        assert load_module_from_file_location(
            conf_file.name
        ).test_var_1 == "test_1"

        conf_file.write("""\ntest_var_2 = "test_2"\n""")
        conf_file.flush()
        assert load_module_from_file_location(
            conf_file.name
        ).test_var_2 == "test_2"


# Generated at 2022-06-24 04:35:58.781365
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from os import environ
    from shutil import copyfile

    from tempfile import NamedTemporaryFile, TemporaryDirectory

    # A) Check if load_module_from_file_location can handle Path object.
    with TemporaryDirectory() as temp_dir:
        temp_file_path = Path(temp_dir) / "test_file.py"
        temp_file_path.touch()
        module = load_module_from_file_location(temp_file_path)
    assert hasattr(module, "__file__")

    # B) Check if load_module_from_file_location can handle
    #    environment variables in format ${some_env_var}.

# Generated at 2022-06-24 04:36:04.710521
# Unit test for function load_module_from_file_location

# Generated at 2022-06-24 04:36:16.468903
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("on") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("false") == False

# Generated at 2022-06-24 04:36:24.225527
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    os.environ["some_env_var"] = "some_value"
    location = "tests/test_configs/some_module.py"

    module_from_location = load_module_from_file_location(location)
    module_from_str = load_module_from_file_location(str(location))
    module_from_path = load_module_from_file_location(Path(location))
    module_from_bytes = load_module_from_file_location(bytes(location, "utf8"))

    module_from_wrong_path = load_module_from_file_location("some_wrong_path")
    module_from_env_variable = load_module_from_file_location(
        "${some_env_var}some_module.py"
    )

    assert module

# Generated at 2022-06-24 04:36:35.156382
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory

    # Test incorrect params
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "some_name", "/some/path/${some_env_var}"
        )

    # Test env vars
    config_name = "test_load_module_from_file_location"
    tmp_dir = TemporaryDirectory(prefix=config_name)

    with open(tmp_dir.name + "/" + config_name + ".py", "w") as f:
        f.write("some_var = 'some_value'")

    os_environ["some_env_var"] = tmp_dir.name


# Generated at 2022-06-24 04:36:44.340207
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("Yes")
    assert str_to_bool("YES")
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("TRUE")
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert str_to_bool("enable")
    assert str_to_bool("Enable")
    assert str_to_bool("ENABLE")
    assert str_to_bool("enabled")
    assert str_to_bool("Enabled")
    assert str_to_bool("ENABLED")
    assert str_to_bool("on")

# Generated at 2022-06-24 04:36:54.177954
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test for function load_module_from_file_location

    This function tests the function
    load_module_from_file_location for regular and
    exceptional situations.

   """
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = Path(temp_dir.name)

    with open(temp_dir_path / "some_config.py", "w") as f:
        f.write("a=1")


# Generated at 2022-06-24 04:37:00.288572
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os

    location = "tests/testdata/config_module.py"
    # A) If location is string returns loaded module.
    assert load_module_from_file_location(location).foo == 123

    location = b"tests/testdata/config_module.py"
    # B) If location is bytes returns loaded module.
    assert load_module_from_file_location(location).foo == 123

    location = Path("tests/testdata/config_module.py")
    # C) If location is Path returns loaded module.
    assert load_module_from_file_location(location).foo == 123

    location = "${BASEDIR}/tests/testdata/config_module.py"
    os.environ["BASEDIR"] = "."
    # D) If location contains any environment variables in format
    #   

# Generated at 2022-06-24 04:37:12.077391
# Unit test for function str_to_bool
def test_str_to_bool():
    try:
        str_to_bool("")
        assert False
    except ValueError:
        pass
    try:
        str_to_bool("somestring")
        assert False
    except ValueError:
        pass

    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_

# Generated at 2022-06-24 04:37:19.411522
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os.path import dirname

    module = load_module_from_file_location(
        "tests.functional/test_configs/test_config.py"
    )
    assert module.TEST_CONFIG_VAR == "test"
    assert module.__file__ == (
        dirname(dirname(__file__)) + "/test_configs/test_config.py"
    )


# we can't create a test for function str_to_bool
# because it's just a wrapper for bool builtin

# Generated at 2022-06-24 04:37:25.710745
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    module = load_module_from_file_location(
        "test_load_module_from_file_location",
        __file__,  # pylint: disable=no-value-for-parameter
    )
    assert module.__name__ == "test_load_module_from_file_location"
    assert module.__file__ == __file__

# Generated at 2022-06-24 04:37:35.415618
# Unit test for function str_to_bool
def test_str_to_bool():  # pragma: no cover
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool

# Generated at 2022-06-24 04:37:46.771950
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile
    from os import environ

    env_var_name = "some_env_var_4_test"
    file_content = "a=1\nb='string'\n"

    try:
        with NamedTemporaryFile() as temp_file:
            temp_file_name = temp_file.name
            temp_file.write(bytes(file_content, "utf-8"))
            temp_file.seek(0)
            module_a = load_module_from_file_location(temp_file_name)
            module_b = load_module_from_file_location(
                "${some_fake_env_var_4_test}/some/file.py"
            )
    except Exception as e:
        module_a = e
        module_b = e

   

# Generated at 2022-06-24 04:37:54.545337
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import subprocess

    # Trying to use variables that is not defined.
    try:
        load_module_from_file_location("/some/path/${some_env_var}")
    except LoadFileException as e:
        assert "Environment variable some_env_var is not defined" in e.args[0]

    # Trying to use variable defined in environment.
    p = subprocess.Popen(
        ["echo", "VAR=test_load_module_from_file_location"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    output, err = p.communicate()

# Generated at 2022-06-24 04:38:06.147889
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_file_path = Path(__file__)

    def test_module_loader(module_path, *args, **kwargs):
        some_module_as_module = load_module_from_file_location(
            module_path, *args, **kwargs
        )
        assert some_module_as_module.__name__ == "some_module"
        assert some_module_as_module.SOME_SOME == "some"

    # 1) Test with relative path with ".."
    test_module_loader(
        test_file_path.parent.parent / "utils" / "some_module.py"
    )

    # 2) Test with relative path without ".."
    os_environ["PYTHONPATH"] = str(test_file_path.parent.parent)
    test_module

# Generated at 2022-06-24 04:38:09.460658
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("on") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("1") is True

    assert str_to_bool("off") is False
    assert str_to_bool("no") is False
    assert str_to_bool("0") is False

# Generated at 2022-06-24 04:38:18.667800
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:38:29.202753
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("yes")
    assert str_to_bool("Yes")
    assert str_to_bool("YES")
    assert str_to_bool("Yep")
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("TRUE")
    assert str_to_bool("On")
    assert str_to_bool("Enable")
    assert str_to_bool("Enabled")
    assert str_to_bool("1")
    assert str_to_bool("ON")
    assert str_to_bool("ENABLE")

# Generated at 2022-06-24 04:38:40.622188
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """To run unit test for this function, execute:

    python -c "import asyncio; from sanic import helpers; loop = asyncio.get_event_loop(); loop.run_until_complete(helpers.test_load_module_from_file_location())"
    """

    import gc
    import shutil
    import tempfile

    from sanic.exceptions import LoadFileException

    class Dummy:
        pass

    def clean_up():
        gc.collect()

        # Cleaning up temporary dir
        shutil.rmtree(TEMP_DIR)

    async def load_module_from_file_location_test():

        with tempfile.TemporaryDirectory("test") as TEMP_DIR:
            clean_up()

            # Check for a source file
            source_location = Path(TEMP_DIR)

# Generated at 2022-06-24 04:38:48.470782
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:38:58.625026
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("os")
    assert load_module_from_file_location(__file__)
    assert load_module_from_file_location(Path(__file__))

    try:
        load_module_from_file_location("caca")
    except:
        pass
    else:
        assert False, "module doesn't exist, should raise exception"

    try:
        load_module_from_file_location(
            "/caca"
        )  # invalid path should raise exception
    except:
        pass
    else:
        assert False, "invalid path, should raise exception"

    # When you use path without .py suffix
    mod = load_module_from_file_location(__file__[:-1 - 3])
    assert mod.__file__ == __file__


# Generated at 2022-06-24 04:39:05.955123
# Unit test for function str_to_bool
def test_str_to_bool():
    """Assert function str_to_bool is working as intended."""

    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False

# Generated at 2022-06-24 04:39:14.580991
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("false") == False
    assert str_to_bool("False") == False
    assert str_to_bool("FALSE") == False
    assert str_to_bool("f") == False
    assert str_to_bool("F") == False
    assert str_to_bool("0") == False
    assert str_to_bool("no") == False
    assert str_to_bool("n") == False
    assert str_to_bool("N") == False

    assert str_to_bool("true") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("true") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Y") == True
    assert str

# Generated at 2022-06-24 04:39:24.938978
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("T") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("on") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("N") is False
    assert str_to_bool("NO") is False
    assert str

# Generated at 2022-06-24 04:39:33.414754
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("YUP") is True
    assert str_to_bool("on") is True
    assert str_to_bool("True") is True

    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("No") is False
    assert str_to_bool("F") is False
    assert str_to_bool("NO") is False
    assert str_to_bool("F") is False

    assert str_to_bool("off") is False
   

# Generated at 2022-06-24 04:39:36.311007
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    with pytest.raises(ValueError):
        str_to_bool("invalid")



# Generated at 2022-06-24 04:39:44.376480
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("Yep")
    assert str_to_bool("True")
    assert str_to_bool("1")
    assert str_to_bool("on")
    assert not str_to_bool("n")
    assert not str_to_bool("No")
    assert not str_to_bool("0")
    assert not str_to_bool("False")
    assert not str_to_bool("off")
    try:
        str_to_bool("maybe")
        assert False
    except ValueError:
        pass


# Generated at 2022-06-24 04:39:52.243159
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    from os.path import abspath, join
    from tempfile import TemporaryDirectory, NamedTemporaryFile
    from shutil import rmtree

    # sanity check
    assert os_environ["PATH"] != ".", "You can't run this test with current env"

    # A) Check environment variables substitute.
    with TemporaryDirectory() as d:
        path = abspath(join(d, "some_path"))
        os.makedirs(path)

        test_module_name = "test_module"
        test_module_path = abspath(join(path, f"{test_module_name}.py"))

        with open(test_module_path, "w") as f:
            f.write("some_test_var = 1")


# Generated at 2022-06-24 04:40:02.361262
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("YeP") is True
    assert str_to_bool("yEs") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("yUP") is True
    assert str_to_bool("t") is True
    assert str_to_bool("T") is True
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("tRuE") is True
    assert str_to_bool("TrUe") is True
    assert str_to_bool("oN") is True

# Generated at 2022-06-24 04:40:14.642452
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Correct usage.
    assert hasattr(
        load_module_from_file_location("test_utils.test_helpers"), "test_value"
    )

    # Using Path, without existing environment variables.
    assert hasattr(
        load_module_from_file_location(Path("test_utils/test_helpers.py")),
        "test_value",
    )

    # Using Path and existing environment variables.
    env_var = "TEST_ENV_VAR"
    os_environ[env_var] = "test_utils"
    assert hasattr(
        load_module_from_file_location("${TEST_ENV_VAR}/test_helpers"),
        "test_value",
    )
    del os_environ[env_var]

    # Using environment variables with

# Generated at 2022-06-24 04:40:27.610836
# Unit test for function str_to_bool
def test_str_to_bool():
    assert_equal(str_to_bool("on"), True)
    assert_equal(str_to_bool("enable"), True)
    assert_equal(str_to_bool("y"), True)
    assert_equal(str_to_bool("yep"), True)
    assert_equal(str_to_bool("yup"), True)
    assert_equal(str_to_bool("t"), True)
    assert_equal(str_to_bool("true"), True)
    assert_equal(str_to_bool("1"), True)
    assert_equal(str_to_bool("off"), False)
    assert_equal(str_to_bool("disable"), False)
    assert_equal(str_to_bool("n"), False)
    assert_equal(str_to_bool("no"), False)

# Generated at 2022-06-24 04:40:36.254199
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = Path(__file__).parent.joinpath("module_to_load.py").resolve()
    module = load_module_from_file_location(location)
    assert module.__file__ == str(location)
    assert module.var1 == 1
    assert module.var2 == "TEST"
    assert module.var3 is True
    assert module.var4 == "Test" * 2
    assert (
        str(module.var5)
        == "This is just an Example of Environment Variable: "
        + os_environ["TEST_ENV_VAR"]
    )

    os_environ["TEST_ENV_VAR"] = "test"
    location = str(location)

# Generated at 2022-06-24 04:40:42.202388
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import tempfile

    with tempfile.TemporaryDirectory() as temporary_directory:
        import shutil

        temporary_directory = Path(temporary_directory)

        # 1. Check if it is possible to load file by file location in format:
        #    file_path to file with file_name.py.
        # 2. Check if it is possible to load file by file location in format:
        #    file_path to directory.

        # Create testing modules.
        module_one = {
            "path": temporary_directory / "test_module.py",
            "content": """
                                 def test_module_one_func():
                                     pass
                            """,
        }

# Generated at 2022-06-24 04:40:46.118192
# Unit test for function str_to_bool
def test_str_to_bool():
    from pytest import raises

    assert str_to_bool("") is False
    assert str_to_bool(None) is False
    assert str_to_bool(False) is False

    for val in (
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
        True,
    ):
        assert str_to_bool(val) is True

    for val in (
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
        False,
    ):
        assert str_to_bool(val) is False

    with raises(ValueError):
        str

# Generated at 2022-06-24 04:40:58.935214
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import os.path as os_path

    import tempfile

    # A) Simple Path-like object test.
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)

    config_file = tmp_dir_path / "config.py"
    config_file.touch()

    config_module = load_module_from_file_location(config_file)
    assert os_path.dirname(config_module.__file__) == str(tmp_dir_path)
    assert os_path.basename(config_module.__file__) == "config.py"

    # B) Simple string path test.
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)

    config_file

# Generated at 2022-06-24 04:41:09.992935
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("true") == True
    # assert str_to_bool("True") == True
    assert str_to_bool("1") == True
    
    assert str_to_bool("no") == False
    assert str_to_bool("No") == False
    assert str_to_bool("NO") == False
    assert str_to_bool("false") == False
    # assert str_to_bool("False") == False
    assert str_to_bool("0") == False
    
    try:
        str_to_bool("blabla")
        raise Exception()
    except:
        pass
# test_str_to_bool()

# Generated at 2022-06-24 04:41:20.944848
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Testing non existing file
    try:
        load_module_from_file_location("some_file_name")
    except LoadFileException as e:
        assert str(e) == "Unable to load configuration file"
        assert str(e.__cause__) == "[Errno 2] No such file or directory"
    else:
        assert False, "Exception did not raised"

    # Testing existing file without env var
    _file = Path("tests/test_config.py")
    _module = load_module_from_file_location(_file.as_posix())
    assert os.fspath(_module.__file__) == _file.as_posix()
    assert _module.TEST_VAR1 == "test_var_value1"

# Generated at 2022-06-24 04:41:24.790379
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os
    import shutil
    import sys
    from pathlib import Path
    from tempfile import NamedTemporaryFile

    tmp_root = Path(NamedTemporaryFile().name)
    tmp_root.mkdir(parents=True)
    # write some files

# Generated at 2022-06-24 04:41:33.519104
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tests.test_utils import temp_path_with_content

    # A) Mark that $some_env_var will not be resolved as environment variable
    #    and will raise exception instead

    with temp_path_with_content(
        content=b'{"print_from_file": "$some_env_var"}'
    ) as tmp_path:
        with pytest.raises(LoadFileException) as excinfo:
            load_module_from_file_location(tmp_path)
    assert (
        str(excinfo.value)
        == "The following environment variables are not set: some_env_var"
    )

    # B) Check load_module_from_file_location.
    #    Load module configuration from json file,
    #    which contains in string value environment variable
    #    in format ${some_env

# Generated at 2022-06-24 04:41:44.418625
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tests.utils.test_config import load_module_from_file_location_test

    test_location = "tests/utils/test_config.py"
    module = load_module_from_file_location(test_location)

    assert module.TEST_CONFIG == load_module_from_file_location_test.TEST_CONFIG

    os_environ["SOME_TEST_ENV_VAR"] = "hello"

    test_location = "tests/${SOME_TEST_ENV_VAR}/test_config.py"
    module = load_module_from_file_location(test_location)

    assert (
        module.TEST_CONFIG == load_module_from_file_location_test.TEST_CONFIG
    )



# Generated at 2022-06-24 04:41:54.347618
# Unit test for function str_to_bool
def test_str_to_bool():
    for val in [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]:
        assert str_to_bool(val)

    for val in [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]:
        assert not str_to_bool(val)

    with pytest.raises(ValueError):
        str_to_bool("some_other_string")

# Generated at 2022-06-24 04:42:04.061385
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Runs unit-tests for function load_module_from_file_location."""
    # A) Check if we can load module from just a name of a module.
    assert load_module_from_file_location("os") is os
    # B) Check if we can load module from location,
    #    where environment variable is present.
    os_environ["SANIC_DEV"] = "True"
    assert (
        load_module_from_file_location(
            "test_utils", "/tmp/${SANIC_DEV}/test_file"
        ).__file__  # type: ignore
        == "/tmp/True/test_file.py"
    )

# Generated at 2022-06-24 04:42:11.419593
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Let's create some test file:
    test_file = Path(__file__).parent / "load_file_location_test.py"
    with open(test_file, mode="w") as fobj:
        fobj.write(
            """
        name = 'load_file_location_test'
        version = '1.0'
        """
        )

    # Now let's try to load it:
    loaded_module = load_module_from_file_location(test_file)
    assert loaded_module.name == "load_file_location_test"
    assert loaded_module.version == "1.0"
    test_file.unlink()

# Generated at 2022-06-24 04:42:18.989654
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") == True
    assert str_to_bool("true") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("no") == False
    assert str_to_bool("0") == False
    assert str_to_bool("yup") == True
    assert str_to_bool("nope") == False
    assert str_to_bool("off") == False
    with pytest.raises(ValueError):
        str_to_bool("abc")



# Generated at 2022-06-24 04:42:29.396608
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:42:40.188231
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit tests for function load_module_from_file_location"""
    # Loading module by string path
    mod = load_module_from_file_location(
        __file__, bail_on_import_errors=True
    )
    assert mod.__file__ == __file__

    # Loading module by Path object
    mod = load_module_from_file_location(Path(__file__))
    assert mod.__file__ == __file__

    # Loading module by bytes path
    mod = load_module_from_file_location(__file__.encode())
    assert mod.__file__ == __file__

    # Loading module by bytes path with using environment variables

# Generated at 2022-06-24 04:42:48.769267
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_ENV_VAR"] = "test_value"
    test_module = load_module_from_file_location(
        "tests.test_helpers",
        __file__,
        Path("test_config.py"),
        "/some/path/${TEST_ENV_VAR}/test_config.py",
    )
    assert test_module.test_config["test_key_4"] == "test_value"
    del os_environ["TEST_ENV_VAR"]

# Generated at 2022-06-24 04:42:58.443522
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_VAR_1"] = Path(".")
    os_environ["TEST_VAR_2"] = os_environ["TEST_VAR_1"].absolute().as_posix()

    # 1) Test with Path instance.
    test_file_path = Path(".") / "tests" / "fixtures" / "test_utils_loaders.py"
    assert (
        load_module_from_file_location("module_name", test_file_path).x
        == 1
    ), "Cannot load module from file path."
    assert (
        load_module_from_file_location("module_name", test_file_path).y
        == 2
    ), "Cannot load module from file path."

    # 2) Test with bytes.

# Generated at 2022-06-24 04:43:07.206216
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test using string
    module = load_module_from_file_location(
        "/home/user/Documents/${ENV_VAR}/${ENV_VAR_2}/config.py"
    )
    assert module.__name__ == "config"
    assert module.__file__ == (
        "/home/user/Documents/${ENV_VAR}/${ENV_VAR_2}/config.py"
    )

    # Test os.environ variables
    os_environ["ENV_VAR"] = "Folder name"
    os_environ["ENV_VAR_2"] = "Folder name 2"

# Generated at 2022-06-24 04:43:18.514876
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("no") == False
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("True") == True
    assert str_to_bool("False") == False
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("ON") == True
    assert str_to_bool("OFF") == False
    assert str_to_bool("yep") == True
    assert str_to_bool("nope") == False
    assert str_to_bool("yup") == True
    assert str_to_bool("nope") == False
    assert str_to_bool("enable") == True


# Generated at 2022-06-24 04:43:28.883074
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("1") == True
    assert str_to_bool("on") == True
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("YEP") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("yes") == True

    assert str_to_bool("false") == False
    assert str_to_bool("False") == False
   

# Generated at 2022-06-24 04:43:30.497309
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert not str_to_bool("n")

# Generated at 2022-06-24 04:43:34.099070
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys

    os.environ["SOME_TEST_ENV_VAR"] = "foo"

    test_dir = os.path.dirname(__file__)
    path_to_test_file = os.path.join(test_dir, "test_files_for_loaders", "env.py")
    return load_module_from_file_location(path_to_test_file)

# Generated at 2022-06-24 04:43:40.050706
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from unittest import TestCase, mock
    from unittest.mock import patch
    from sanic import Sanic
    from sanic.exceptions import SanicException
    import sys
    import random


# Generated at 2022-06-24 04:43:48.518461
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests for function load_module_from_file_location."""

    # A) Test with simple case when there are no environment variables
    # in location.
    module = load_module_from_file_location("test_configs/some_config.py")
    assert module.CONFIG_VALUE == "some_value"

    # B) Test with location as Path instance.
    module = load_module_from_file_location(Path("test_configs/some_config.py"))
    assert module.CONFIG_VALUE == "some_value"

    # C) Test that location can contain environment variables
    # in format ${some_env_var}.
    # Aliasing the function to assert the error in a readable way.
    load_module_from_file_location = (
        load_module_from_file_location
    )

# Generated at 2022-06-24 04:43:59.427064
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test successful import using string as path.
    class_from_file = load_module_from_file_location(
        "tests.utils.configuration.class_from_file"
    )
    assert class_from_file.some_parameter == "some_value"

    # Test successful import using pathlib.Path as path.
    class_from_file = load_module_from_file_location(
        Path(__file__).parent / "configuration/class_from_file.py"
    )
    assert class_from_file.some_parameter == "some_value"

    # Test unsuccessful import using bytes, for example from environment
    # variable, as path.
    import os


# Generated at 2022-06-24 04:44:07.023245
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("no") is False
    assert str_to_bool("false") is False
    assert str_to_bool("TRue") is True
    assert str_to_bool("FalSe") is False
    assert str_to_bool("YeS") is True
    assert str_to_bool("OFF") is False
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("f") is False
    assert str_to_bool("t") is True
    assert str_to_bool("oFF") is False
    assert str_to_bool("y") is True
    assert str_to_bool("on") is True
    assert str_to_bool("off") is False


# Generated at 2022-06-24 04:44:17.593521
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import sys
    import os
    import shutil
    import pytest
    import tempfile
    import subprocess

    # Prepare test data
    def _create_test_data(temp_dir: str) -> None:
        path = os.path.join(temp_dir, "test_data.py")
        with open(path, "w") as f:
            f.write("\n".join(["a = 42", "b = 43", "c = 44"]))

        path = os.path.join(temp_dir, "test.py")
        with open(path, "w") as f:
            f.write("\n".join(["b = 44", "c = 45", "d = 46"]))

        path = os.path.join(temp_dir, "test2.py")

# Generated at 2022-06-24 04:44:24.467055
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import tempfile

    with tempfile.TemporaryDirectory() as tmp_dir:
        module_name = "sample_module"
        module_path = tmp_dir + "/" + module_name + ".py"

# Generated at 2022-06-24 04:44:29.453391
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # 1)
    location = "sanic.config.Config"
    module = load_module_from_file_location(location)
    assert module.__name__ == "sanic.config.Config"

    # 2)
    location = "Tests/config.py"
    module = load_module_from_file_location(location)
    assert module.__name__ == "config"
    assert module.KEY == "VALUE"


if __name__ == "__main__":  # pragma: no cover
    test_load_module_from_file_location()

# Generated at 2022-06-24 04:44:36.167988
# Unit test for function str_to_bool
def test_str_to_bool():
    for val_true in ["y", "yes", "yep", "yup", "t", "true", "on", "enable", "enabled", "1"]:
        assert str_to_bool(val_true) == True

    for val_false in ["n", "no", "f", "false", "off", "disable", "disabled", "0"]:
        assert str_to_bool(val_false) == False

    raise_err = False
    try:
        str_to_bool("Hello World")
    except ValueError:
        raise_err = True
    assert raise_err == True

# Generated at 2022-06-24 04:44:46.456864
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("enable") == True
    assert str_to_bool("True") == True
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Enabled") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("True") == True
    assert str_to_bool("1") == True
    assert str_to_bool("disable") == False
    assert str_to_bool("False") == False
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("No") == False
    assert str_to_bool("NO") == False
    assert str_

# Generated at 2022-06-24 04:44:55.399459
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("0")