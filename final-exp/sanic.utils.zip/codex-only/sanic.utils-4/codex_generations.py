

# Generated at 2022-06-24 04:35:11.716810
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(1) == 1
    assert isinstance(
        load_module_from_file_location("pathlib"), types.ModuleType
    )
    assert "io" in dir(load_module_from_file_location("io"))
    assert load_module_from_file_location("io") == io

    # Unix-like system
    if platform.system() == "Darwin" or platform.system() == "Linux":
        assert "__file__" in dir(  # nosec
            load_module_from_file_location("/usr/lib/python3.6/io.py")
        )

    # Windows

# Generated at 2022-06-24 04:35:22.308995
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Unit test for function load_module_from_file_location."""
    import random

    random_number = random.randint(1, 10000)
    os_environ["SOME_VAR"] = str(random_number)
    from tempfile import mkdtemp

    from shutil import rmtree
    from os import listdir, remove
    from distutils.sysconfig import get_python_lib
    from os.path import isfile, join
    from os import getcwd

    # Find path for system site packages.
    # If not found try to find it with default system path.
    path_to_site_packages = get_python_lib()
    if not path_to_site_packages:
        import sys

        path_to_site_packages = sys.path[-1]

    # Create temporary dir to store some

# Generated at 2022-06-24 04:35:26.912333
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("1") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("n") == False
    assert str_to_bool("N") == False
    assert str_to_bool("0") == False
    assert str_to_bool("f") == False
    assert str_to_bool("F") == False
    assert str_to_bool("False") == False
    assert str_to_bool("false") == False
    assert str_to_bool("bla") == False

# Generated at 2022-06-24 04:35:33.653711
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Tests if load_module_from_file_location raises and loads file properly"""
    import tempfile
    import pytest
    import os

    # Just some random file contents.
    file_contents = """
    a:5
    b:6
    c: "some string"
    """

    with tempfile.NamedTemporaryFile(
        suffix=".yaml", mode="w", delete=False
    ) as file_object:
        file_object.write(file_contents)
        file_object.flush()

        # Make sure that we are not using this file from other tests.
        # Mark that it is as not expected, so we delete it at the end.
        assert os.path.isfile(file_object.name)

        # Test if loading is successful.
        module = load_module

# Generated at 2022-06-24 04:35:45.562409
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("Enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:35:54.988475
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location(
            "sanic.exceptions.LoadFileException",
            "./tests/test_load_module_from_file_location.py",
        )
    except PyFileError as e:
        assert "sanic.exceptions.LoadFileException" in str(
            e
        )  # should work in both Python 3.6 and 3.7
    else:
        raise PyFileError(
            "sanic.exceptions.LoadFileException",
            "./tests/test_load_module_from_file_location.py",
        )


# Generated at 2022-06-24 04:36:02.457418
# Unit test for function str_to_bool
def test_str_to_bool():
    assert (
        str_to_bool("y")
        is str_to_bool("yes")
        is str_to_bool("yep")
        is str_to_bool("yup")
        is str_to_bool("t")
        is str_to_bool("true")
        is str_to_bool("on")
        is str_to_bool("enable")
        is str_to_bool("enabled")
        is str_to_bool("1")
    )

# Generated at 2022-06-24 04:36:13.396064
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import mkdtemp, NamedTemporaryFile
    from shutil import rmtree
    from json import dumps
    from yaml import dump
    from os import environ
    from os.path import isfile

    # 1) Make a temporary directory for testing purposes.
    tmp_dir = Path(mkdtemp())

    # 1.1) Prepare a some json and yaml files with configs.
    json_str = '{"hello": "world"}'
    yaml_str = 'hello: world'
    json_file = tmp_dir / "config.json"
    yaml_file = tmp_dir / "config.yaml"
    with open(json_file, "w") as f:
        f.write(json_str)
    with open(yaml_file, "w") as f:
        f.write

# Generated at 2022-06-24 04:36:22.808594
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("1") == True
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("on") == True
    assert str_to_bool("On") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("enable") == True
    assert str

# Generated at 2022-06-24 04:36:30.621414
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yeS") == True
    assert str_to_bool("No") == False
    assert str_to_bool("faLse") == False
    assert str_to_bool("on") == True
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("t") == True
    assert str_to_bool("f") == False
    assert str_to_bool("yup") == True
    assert str_to_bool("nope") == False
    assert str_to_bool("enabled") == True
    assert str_to_bool("disabled") == False
    with pytest.raises(ValueError):
        assert str_to_bool("yEs") == None

# Generated at 2022-06-24 04:36:41.298234
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Since we are abusing internals of `import_string()`,
    # we need to make sure that everything is reset.
    import sys
    import_string.cache = {}
    if "foo_module" in sys.modules:
        del sys.modules["foo_module"]

    # Create a file first
    foo_module_file = Path(__file__).parent / "foo_module.py"
    with foo_module_file.open("w") as module_file:
        module_file.write("a = 1")

    assert len(import_string.cache) == 0

    foo_module = load_module_from_file_location(foo_module_file)
    assert foo_module.a == 1
    assert len(import_string.cache) == 1


# Generated at 2022-06-24 04:36:51.768118
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Test if function loads python module from file
    # with default parameters.
    from .test_helpers import __test_module__

    test_module = load_module_from_file_location(__test_module__)
    assert test_module.__name__ == "__test_module__"

    # B) Test if function loads python module from file
    # with specified parameters.
    test_module = load_module_from_file_location(
        __test_module__,
        "utf-8",
        True,
        "__test_module__",
    )
    assert test_module.__name__ == "__test_module__"

    # C) Test if function loads python module from bytes.

# Generated at 2022-06-24 04:36:59.021494
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-24 04:37:11.214800
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    module_name = "some_module_name"
    module_path = "/some/path/${SOME_ENV_VAR}"

    for some_env_var in (None, "", "value"):

        if some_env_var is not None:
            os_environ["SOME_ENV_VAR"] = some_env_var  

        module = load_module_from_file_location(module_name, module_path)

        assert module.__name__ == module_name

        assert module.__file__ == module_path.replace(
            "${SOME_ENV_VAR}", some_env_var
        ) if some_env_var is not None else module_path


# Generated at 2022-06-24 04:37:17.847205
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("no") is False
    assert str_to_bool("n") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False

# Generated at 2022-06-24 04:37:21.675736
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("False") is False
    assert str_to_bool("12123") == ValueError

# Generated at 2022-06-24 04:37:32.607567
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) test whether string gets parsed properly
    test_string = "Hello World"
    assert load_module_from_file_location(test_string) == test_string

    # B) test whether bytes with proper encoding gets parsed properly
    test_bytes = b"Hello World"
    assert (
        load_module_from_file_location(test_bytes, encoding="utf8")
        == test_bytes.decode("utf8")
    )

    # C) test whether environment variables gets parsed properly
    test_string_with_env_var = "Hello ${TEST_ENV_VAR}"
    os_environ["TEST_ENV_VAR"] = "World"
    assert load_module_from_file_location(
        test_string_with_env_var
    ) == "Hello World"
    del os

# Generated at 2022-06-24 04:37:40.876455
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # If location contains variable in format ${some_env_var} and this
    # variable is not in environment, we should raise LoadFileException.
    os_environ["test_env_var"] = "test_env_var_value"
    location = "${test_env_var}/location/to/some_file.py"
    expected_result = "test_env_var_value/location/to/some_file.py"
    assert (
        load_module_from_file_location(location).__file__ == expected_result
    )

    # If location doesn't contain variable in format ${some_env_var} but
    # some variable in format $some_env_var, we should not resolve it.
    location = "$test_env_var/location/to/some_file.py"
    expected

# Generated at 2022-06-24 04:37:50.804908
# Unit test for function str_to_bool
def test_str_to_bool(): # pragma: no cover
    pos_values_true = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]
    pos_values_false = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]

    assert all(str_to_bool(val) for val in pos_values_true)
    assert not any(str_to_bool(val) for val in pos_values_false)

    try:
        str_to_bool("WrongYes")
    except ValueError:
        pass
    else:
        raise Ass

# Generated at 2022-06-24 04:37:57.341802
# Unit test for function str_to_bool
def test_str_to_bool():
    result = str_to_bool("yEs")
    assert result is True, "`yEs` must turn into `True`"
    result = str_to_bool("True")
    assert result is True, "`True` must turn into `True`"
    result = str_to_bool("false")
    assert result is False, "`false` must turn into `False`"
    result = str_to_bool("1")
    assert result is True, "`1` must turn into `True`"
    result = str_to_bool("0")
    assert result is False, "`0` must turn into `False`"
    try:
        result = str_to_bool("true2")
        assert True, "ValueError must be raised"
    except ValueError:
        pass

# Generated at 2022-06-24 04:38:08.264401
# Unit test for function str_to_bool
def test_str_to_bool():
    """Tests str_to_bool"""

    assert str_to_bool("yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("Yep") == True
    assert str_to_bool("YUP") == True
    assert str_to_bool("T") == True
    assert str_to_bool("true") == True
    assert str_to_bool("ON") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("no") == False
    assert str_to_bool("NO") == False
    assert str_to_bool("F") == False
    assert str_to_bool("False") == False
    assert str_to

# Generated at 2022-06-24 04:38:18.310383
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys
    import tempfile
    from contextlib import contextmanager

    @contextmanager
    def temp_path(content=None):
        with tempfile.NamedTemporaryFile(delete=False) as fp:
            if content:
                fp.write(content)

        try:
            yield fp.name
        finally:
            os.remove(fp.name)

    tmp_path_str = "tmp_str.py"
    tmp_path_bytes = b"tmp_bytes.py"
    tmp_path_path = Path("tmp_path.py")
    tmp_path_os_environ = Path("${TMPDIR}") / "tmp_os_environ.py"

    tmp_path_spec = Path("tmp_spec") / "tmp_spec.py"
    tmp_path

# Generated at 2022-06-24 04:38:26.099418
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os.environ["SANIC_TEST_VAR1"] = "test_var1"
    os.environ["SANIC_TEST_VAR2"] = "/"

    location = load_module_from_file_location(
        __name__,
        os.path.join(os.path.dirname(__file__), "config_example.py"),
        "rt",
        True,
        True,
    )
    assert location.TEST_INT_VARIABLE == 5
    assert location.TEST_FLOAT_VARIABLE == 9.4
    assert location.TEST_STRING_VARIABLE == "test string"
    assert location.TEST_LIST_VARIABLE == [1, 3, 4, 5]
    assert location.TEST_TUPLE_VAR

# Generated at 2022-06-24 04:38:36.832007
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    def make_temp_config(config_py_content: str) -> str:
        with NamedTemporaryFile(
            suffix=".py", mode="w", encoding="utf8", delete=False
        ) as temp_config_py:
            temp_config_py.write(config_py_content)
            temp_config_py.flush()
            return temp_config_py.name

    temp_config_path = make_temp_config("FOO = 'bar'")

    module = load_module_from_file_location(temp_config_path)
    assert module.FOO == "bar"

    os_environ["SOME_ENV_VAR"] = "foo"
    temp_config_path = make_temp_config("FOO = 'bar'")

# Generated at 2022-06-24 04:38:45.039593
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    from os import environ
    assert load_module_from_file_location("os").path == os.path

    assert load_module_from_file_location("sanic.server").Server is not None
    assert load_module_from_file_location("test_helpers").test_load_module_from_file_location is not None

    # Using environment variables in location string
    some_env_var = "THIS_IS_A_TEST"
    os.environ[some_env_var] = "1"
    assert load_module_from_file_location("/some/path/${" + some_env_var + "}").version is not None

    # Not using environment variables, using file path instead
    assert load_module_from_file_location("/some/path/1").version is not None

   

# Generated at 2022-06-24 04:38:55.752526
# Unit test for function str_to_bool
def test_str_to_bool():

    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:39:07.679075
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("on") is True
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("1") is True

    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("no") is False
    assert str_to_bool("n") is False
    assert str_to_bool("N") is False
    assert str_to_bool("0") is False


# Generated at 2022-06-24 04:39:18.629445
# Unit test for function str_to_bool
def test_str_to_bool():  # pragma: no cover
    assert str_to_bool("y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("YEp") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("1") == True
    assert str_to_bool("t") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("Enabled") == True

    assert str_to_bool("n") == False
    assert str_to_bool("NO") == False
    assert str_to_bool("False") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:39:29.651081
# Unit test for function str_to_bool
def test_str_to_bool():

    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-24 04:39:36.186175
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    def equal_ignore_space(s1, s2):
        return s1.replace(" ", "") == s2.replace(" ", "")

    ##################################################################
    # Testing, that load_module_from_file_location can load a module #
    # from a relative path.                                          #
    ##################################################################
    # 1) Test, that relative path can be used, when it is the same
    #    as the location of a calling module.
    module_name = "some_module"
    module_location = f"{module_name}.py"

# Generated at 2022-06-24 04:39:46.544329
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Tests the function load_module_from_file_location()
    """
    import asyncio
    import contextlib
    import json
    import os
    import sys

    import tempfile

    tempdir_path = Path(tempfile.gettempdir())
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    # B) Check these variables exists in environment.
    # C) Substitute them in location.
    test_env_var = "test_env_var"
    os.environ[test_env_var] = str(tempdir_path)

# Generated at 2022-06-24 04:39:58.115147
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    test_data = {
        "test_bool_var": True,
        "test_str_var": "test_str_var",
        "test_int_var": 123,
        "test_float_var": 123.123,
        "test_list_var": [1, 2, 3],
        "test_tuple_var": (1, 2, 3, 4),
        "test_dict_var": {"dict": 1},
        "test_function_var": lambda x: x,
        "test_class_var": type,
    }
    location = Path(__file__).parent / "test_config.py"
    module = load_module_from_file_location(location)

    assert all(getattr(module, k) == v for k, v in test_data.items())


# Unit test

# Generated at 2022-06-24 04:40:06.241603
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Unit test for function load_module_from_file_location."""
    from tempfile import TemporaryDirectory

    from os import environ as os_environ
    from pathlib import Path

    config_path = Path("./test_conf.py")
    config_test_value = "Some test string config value"


# Generated at 2022-06-24 04:40:15.401016
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y")
    assert str_to_bool("Yes")
    assert str_to_bool("Yep")
    assert str_to_bool("Yup")
    assert str_to_bool("T")
    assert str_to_bool("True")
    assert str_to_bool("On")
    assert str_to_bool("Enable")
    assert str_to_bool("Enabled")
    assert str_to_bool("1")

    assert not str_to_bool("N")
    assert not str_to_bool("No")
    assert not str_to_bool("F")
    assert not str_to_bool("False")
    assert not str_to_bool("Off")
    assert not str_to_bool("Disable")
    assert not str_to_bool("Disabled")

# Generated at 2022-06-24 04:40:27.711562
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:40:38.654635
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def check_module_has_some_field(module, field_name):
        assert field_name in dir(module)

    a_file_path = "test_module/test_module.py"
    a_module = load_module_from_file_location(a_file_path)
    assert a_module.__name__ == "test_module"
    assert a_module.__file__ == a_file_path
    assert a_module.__package__ == ""

    check_module_has_some_field(a_module, "A_VAR")
    check_module_has_some_field(a_module, "A_FUNC")
    check_module_has_some_field(a_module, "A_CLASS")

    a_file_path = "test_module/test_module.json"


# Generated at 2022-06-24 04:40:47.346726
# Unit test for function str_to_bool
def test_str_to_bool():
    """
    Test function which checks if str_to_bool function works properly.
    """
    with pytest.raises(ValueError):
        str_to_bool("wrong")
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("N") is False
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("Yes") is True
    assert str_to_bool("false") is False
    assert str_to_bool("False") is False
    assert str_to_bool("enable") is True
    assert str_to_bool("Enabled") is True

# Generated at 2022-06-24 04:40:56.395492
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("t") == True
    assert str_to_bool("1") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("true") == True
    assert str_to_bool("n") == False
    assert str_to_bool("f") == False
    assert str_to_bool("0") == False
    assert str_to_bool("no") == False
    assert str_to_bool("false") == False

# Generated at 2022-06-24 04:41:04.181769
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("YES") == True
    assert str_to_bool("NO") == False
    assert str_to_bool("yup") == True
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False
    assert str_to_bool("t") == True
    assert str_to_bool("f") == False

    try:
        str_to_bool("Blabla")
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-24 04:41:16.097298
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sanic_envconfig

    os.environ["test1"] = "123"
    os.environ["test2"] = "321"

    # It should accept string path with environment variables
    # which are already defined in the environment
    script_dir = os.path.dirname(__file__)
    config = load_module_from_file_location(
        os.path.join(script_dir, "test_configs/env_vars_test_config.py")
    )
    assert config.some_env_var == os.environ["test1"]
    assert config.another_env_var == os.environ["test2"]
    assert config.regular_string == "regular string"

    # It should accept string with environment variables which are already
    # defined in the environment
    config = load

# Generated at 2022-06-24 04:41:23.908430
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("TRUE")
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("yes")
    assert str_to_bool("YeS")
    assert str_to_bool("yep")
    assert str_to_bool("YEP")
    assert str_to_bool("yup")
    assert str_to_bool("Yep")
    assert not str_to_bool("false")
    assert not str_to_bool("False")
    assert not str_to_bool("FaLse")
    assert not str_to_bool("n")
    assert not str_to_bool("N")
    assert not str_to_bool("no")

# Generated at 2022-06-24 04:41:33.218542
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:41:44.148981
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("sanic.helpers")
    assert load_module_from_file_location("sanic.helpers.import_string")
    assert load_module_from_file_location("sanic.helpers.load_module_from_file_location")

    # Since we have to have this module in our filesystem to test it
    # I had to add the path to it to PYTHON_PATH environment variable.
    os_environ["PYTHON_PATH"] = os.path.dirname(os.path.realpath(__file__))
    assert load_module_from_file_location("sanic_helpers.helpers")
    assert load_module_from_file_location("sanic_helpers.helpers.import_string")
    assert load_module_from_file_

# Generated at 2022-06-24 04:41:55.278041
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1") == True
    assert str_to_bool("0") == False
    assert str_to_bool("yes") == True
    assert str_to_bool("no") == False
    assert str_to_bool("y") == True
    assert str_to_bool("n") == False
    assert str_to_bool("YES") == True
    assert str_to_bool("NO") == False
    assert str_to_bool("Y") == True
    assert str_to_bool("N") == False
    assert str_to_bool("yep") == True
    assert str_to_bool("nope") == False
    assert str_to_bool("YEP") == True
    assert str_to_bool("NOPE") == False
    assert str_to_bool("YUP") == True

# Generated at 2022-06-24 04:42:06.634924
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import uuid
    from tempfile import mkstemp, TemporaryDirectory
    from os import close, remove
    from os.path import isfile, isdir

    import pytest

    filename_template = str(uuid.uuid4())
    temporary_directory_name = str(uuid.uuid4())

    # ========== Test when location is a Path to a file ==========
    with TemporaryDirectory() as tmp_dir:
        # A) Create temporary file.
        filepath = tmp_dir + "/" + filename_template + ".py"
        fd, _ = mkstemp(suffix=".py", dir=filepath)
        close(fd)
        # B) Create content to temporary file.
        dummy_config_value = str(uuid.uuid4())

# Generated at 2022-06-24 04:42:13.326436
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from random import randint
    from os import environ
    from os.path import join as path_join
    from tempfile import gettempdir

    # Make some temporary file
    tmp_dir = Path(gettempdir())
    file_name = hex(randint(0, 1 << 128))
    f = tmp_dir / path_join(file_name)
    # Put some python code in this file
    test_value = hex(randint(0, 1 << 128))
    with open(f, "w") as fh:
        fh.write(f"a = '{test_value}'\n")
    # Test it
    module = load_module_from_file_location(f)
    assert module.a == test_value

    # Test it again, but with bytes this time.
   

# Generated at 2022-06-24 04:42:22.608954
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("Yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("1")
    assert not str_to_bool("no")
    assert not str_to_bool("false")
    assert not str_to_bool("f")
    assert not str_to_bool("off")
    assert not str_to_bool("0")

    try:
        str_to_bool("")
    except ValueError as e:
        assert str(e) == "Invalid truth value "


# Generated at 2022-06-24 04:42:32.024695
# Unit test for function str_to_bool
def test_str_to_bool():
    with pytest.raises(ValueError):
        str_to_bool("incorrect_val")
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("TRUE")
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("yes")
    assert str_to_bool("Yes")
    assert str_to_bool("YES")
    assert str_to_bool("yep")
    assert str_to_bool("Yep")
    assert str_to_bool("YEP")
    assert str_to_bool("yup")
    assert str_to_bool("Yup")
    assert str_

# Generated at 2022-06-24 04:42:37.887220
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # I. Test loading from path without environment variables
    module_loaded = load_module_from_file_location(".tox/py36/lib/python3.6/site-packages/sanic/__init__.py",)
    assert module_loaded.__name__ == "sanic"

    # II. Test loading from path with resolved environment variable
    # A) Set environment variable
    os_environ["TEST_ENV_VAR"] = (
        ".tox/py36/lib/python3.6/site-packages/sanic/__init__.py"
    )

    # B) Load module
    module_loaded = load_module_from_file_location(
        "${TEST_ENV_VAR}",
    )
    assert module_loaded.__name__ == "sanic"

    #

# Generated at 2022-06-24 04:42:44.945216
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["some_var"] = "/some/path/"
    os_environ["some_var2"] = "some_file_name"

    test_cases = [
        ("/some/path/some_file_name/", "main"),
        ("/some/path/${some_var2}/", "main"),
        ("/some/path/${some_var}${some_var2}/", "main"),
        ("/some/path/${some_var}", "main"),
        ("/some/path/${some_var2}", "main"),
        ("/some/path/${some_var}${some_var2}", "main"),
        ("/some/path/some_file_name", "main"),
    ]

    for test_case in test_cases:
        location = test_

# Generated at 2022-06-24 04:42:54.226535
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ, remove
    from tempfile import mkstemp

    from location import load_module_from_file_location

    clean_env = environ.copy()

    # This function is just for testing purposes.

    def prepare_env_to_test(some_vars_dict: dict) -> None:
        """Clear environment, and set some_vars_dict variables in it."""
        environ.clear()
        environ.update(some_vars_dict.copy())

    def test_successful_load(
        location: Union[str, bytes, Path], **kw_args
    ) -> None:
        prepare_env_to_test({"var": "some_value"})

# Generated at 2022-06-24 04:43:06.476735
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    from shutil import copyfile

    from unittest import TestCase

    class TestLoadModuleFromFileLocation(TestCase):

        def setUp(self):
            self.test_folder = tempfile.TemporaryDirectory()
            self.test_folder_path = Path(self.test_folder.__enter__())
            self.test_file_name = "test_file"

            # Copy test file to test folder.
            test_file_name = "test.py"
            test_file_path = Path(__file__).parent.parent / "examples" / test_file_name
            self.test_file_path = self.test_folder_path / test_file_name
            copyfile(str(test_file_path), str(self.test_file_path))


# Generated at 2022-06-24 04:43:18.198533
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    env = os_environ
    env["some_env_var"] = "some_value"

    # This should not raise error
    load_module_from_file_location("${some_env_var}", env=env)

    # This should raise error, as $some_env_var is not defined in environment.
    with pytest.raises(LoadFileException):
        load_module_from_file_location("$some_env_var", env=env)

    # This should raise error, as the_env_var is not defined in environment.
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "some_${some_env_var}_some/${the_env_var}/${some_env_var}", env=env
        )

# Generated at 2022-06-24 04:43:28.526514
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location.__name__ == "load_module_from_file_location"

# Generated at 2022-06-24 04:43:31.230418
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("y")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert s

# Generated at 2022-06-24 04:43:41.382158
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import os
    import pytest

    from .server import Sanic

    class Helper:
        def __init__(self):
            self.tpl = "${some_env_var}/some/path"

    _config_template_path = (
        os.path.dirname(os.path.dirname(__file__)) + "/tests/config_template.py"
    )
    h = Helper()

    app = Sanic("test_load_module_from_file_location")
    app.some_key = "some_value"

    # 1) Location with environment variable "some_env_var" set.
    #    Should Load configuration file.
    some_env_var = "${some_env_var}/some/directory"

# Generated at 2022-06-24 04:43:43.514827
# Unit test for function str_to_bool
def test_str_to_bool():
    val = "Blah"
    try:
        str_to_bool(val)
    except ValueError:
        assert True


# Generated at 2022-06-24 04:43:50.311319
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import mkstemp
    import os

    from jinja2 import Template

    temp_file, temp_file_path = mkstemp()

# Generated at 2022-06-24 04:43:59.975936
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("YEP") == True
    assert str_to_bool("YuP") == True
    assert str_to_bool("t") == True
    assert str_to_bool("TruE") == True
    assert str_to_bool("on") == True
    assert str_to_bool("ENABLE") == True
    assert str_to_bool("Enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("NO") == False
    assert str_to_bool("f") == False
    assert str_to_bool("FALSE") == False

# Generated at 2022-06-24 04:44:07.286772
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Load module with relative path
    os.chdir(os.path.dirname(__file__))
    relative_path = "test_load_module/test_load_module_from_file_location.py"
    module = load_module_from_file_location(relative_path)
    assert module.__name__ == relative_path.split("/")[-1].split(".")[0]

    # B) Load module with full path.
    absolute_path = os.getcwd() + "/" + relative_path
    module = load_module_from_file_location(absolute_path)
    assert module.__name__ == relative_path.split("/")[-1].split(".")[0]

    # C) Load module with path that contains environment variable.

# Generated at 2022-06-24 04:44:19.542108
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sys import modules
    from sanic.config import load_module_from_file_location as LLFF
    from sanic.exceptions import ApplyExceptionWrapper
    with ApplyExceptionWrapper(lambda o: o):
        LLFF("", "")
    assert (
        'LLFF("", "")'
        in modules["__main__"].sanic.exceptions.ApplyExceptionWrapper.__call__.__wrapped__.__source__
    )

    # Test importing modules
    load_module_from_file_location("os")
    load_module_from_file_location("config")
    load_module_from_file_location("/some/path/some/config.py")

    # Test importing modules with module_from_spec

# Generated at 2022-06-24 04:44:28.803966
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test with bytes
    with pytest.raises(ValueError):
        load_module_from_file_location(b"", encoding="ascii")
    # Test with string
    with pytest.raises(ValueError):
        load_module_from_file_location("", encoding="ascii")

    # Test with Path
    # Set some environment variables
    os_environ["some_env_var"] = "some_env_var_value"
    with pytest.raises(ValueError):
        load_module_from_file_location(Path(""), encoding="ascii")

    os_environ["some_env_var"] = "some_env_var_value"

# Generated at 2022-06-24 04:44:38.242264
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False
    assert str_to_bool("no") == False
    assert str_to_bool("0") == False
    try:
        str_to_bool("wrong_str")
    except ValueError:
        pass
    else:
        assert False, "str_to_bool() did not raise ValueError"

# Generated at 2022-06-24 04:44:46.006906
# Unit test for function str_to_bool
def test_str_to_bool():
    """
    Test if true values are interpreted correct
    Test if false values are interpreted correct
    Test if exception is raised on invalid input
    """
    # Test if true values are interpreted correct
    true_values = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]
    for true_value in true_values:
        assert str_to_bool(true_value)

    # Test if false values are interpreted correct
    false_values = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]

# Generated at 2022-06-24 04:44:53.704190
# Unit test for function str_to_bool
def test_str_to_bool():
    """Tests for str_to_bool function"""

    _test_string = "yes"
    _test_string_2 = "no"

    assert str_to_bool(_test_string) is True
    assert str_to_bool(_test_string_2) is False
    assert str_to_bool(1) is True
    assert str_to_bool(0) is False

# Generated at 2022-06-24 04:45:05.085549
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("Yep") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("N") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_