

# Generated at 2022-06-24 04:35:07.491780
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    from .config import ConfigTest  # noqa

    from .locals import config  # noqa

    def _check_result(result: object, expected: object) -> None:
        for key in expected:
            assert key in result
            assert result[key] == expected[key]

    config1 = load_module_from_file_location("./test_config.conf")
    assert config1.__name__ == "config"
    assert config1.__file__.endswith("test_config.conf")

    # Since function load_module_from_file_location returns
    # module object. Here we check it's parameters.
    assert config1.one == 1
    assert config1.two == 2

    _check_result(config1.some_cfg, ConfigTest.some_cfg)
    assert config

# Generated at 2022-06-24 04:35:18.435277
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("1") == True
    assert str_to_bool("True") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("on") == True
    assert str_to_bool("t") == True
    assert str_to_bool("") == False
    assert str_to_bool(None) == False
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("0") == False
    assert str_to

# Generated at 2022-06-24 04:35:26.901424
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import tempfile

    temp_file = tempfile.NamedTemporaryFile(suffix=".py", delete=False)
    temp_file.write(b"some_var = 'some_var_value'")
    temp_file.close()

    os.environ["temp_file_env_var"] = temp_file.name

    module = load_module_from_file_location(
        f"/some/path/${{temp_file_env_var}}",
    )

    assert module.some_var == "some_var_value"



# Generated at 2022-06-24 04:35:33.629821
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("Yes")
    assert str_to_bool("Y")
    assert str_to_bool("Yes")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("TRUE")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")

    assert not str_to_bool("n")
    assert not str_to_bool

# Generated at 2022-06-24 04:35:45.562620
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("TRUE") is True
    assert str_to_bool("on") is True
    assert str_to_bool("ON") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True


# Generated at 2022-06-24 04:35:54.987874
# Unit test for function str_to_bool
def test_str_to_bool():

    true_values = [
        "Y",
        "yes",
        "YES",
        "y",
        "Yep",
        "1",
        "t",
        "True",
        "true",
        "TRUE",
        "T",
        "on",
        "ON",
        "On",
        "enable",
        "ENABLE",
        "Enabled",
    ]
    false_values = [
        "N",
        "no",
        "NO",
        "n",
        "Nope",
        "0",
        "f",
        "False",
        "false",
        "FALSE",
        "off",
        "OFF",
        "Off",
        "disable",
        "DISABLE",
        "Disabled",
    ]

# Generated at 2022-06-24 04:36:06.193680
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("true") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("t") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("false") is False
    assert str_to_bool("no") is False
    assert str_to_bool("False") is False
    assert str_to_bool("f") is False
    assert str_to_bool("off") is False
    assert str_

# Generated at 2022-06-24 04:36:13.490809
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y")
    assert str_to_bool("YES")
    assert str_to_bool("y")
    assert str_to_bool("yes")

    assert not str_to_bool("N")
    assert not str_to_bool("NO")
    assert not str_to_bool("False")
    assert not str_to_bool("FALSE")

    try:
        str_to_bool("maybe")
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-24 04:36:22.904793
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from sanic.config import DEFAULT_CONFIG

    assert load_module_from_file_location(
        "sanic.config"
    ).DEFAULT_CONFIG == DEFAULT_CONFIG

    assert load_module_from_file_location(__file__).DEFAULT_CONFIG == DEFAULT_CONFIG

    os_environ["SOME_TEST_VAR"] = "SOME_TEST_VALUE"
    assert (
        load_module_from_file_location(
            "${SOME_TEST_VAR}", __file__
        ).DEFAULT_CONFIG
        == DEFAULT_CONFIG
    )

# Generated at 2022-06-24 04:36:34.987245
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") == True, "Failed to convert string True to bool"
    assert str_to_bool("true") == True, "Failed to convert string true to bool"
    assert str_to_bool("YES") == True, "Failed to convert string YES to bool"
    assert str_to_bool("yes") == True, "Failed to convert string yes to bool"
    assert str_to_bool("n") == False, "Failed to convert string n to bool"
    assert str_to_bool("false") == False, "Failed to convert string false to bool"
    assert str_to_bool("f") == False, "Failed to convert string f to bool"
    assert str_to_bool("F") == False, "Failed to convert string F to bool"
    assert str_to_bool

# Generated at 2022-06-24 04:36:44.241006
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Set environment variable
    os_environ["PYTHONPATH"] = os.path.dirname(__file__)

    # Try to access Python file using relative path with environment variable
    module_1 = load_module_from_file_location(
        "tests/modules/valid_config_1.py"
    )
    assert module_1.PORT == 8000

    # Try to access Python file using absolute path with environment variable
    module_2 = load_module_from_file_location(
        "tests/modules/valid_config_2.py"
    )
    assert module_1.PORT == 8000

    # Try to access Python file with environment variable with wrong path

# Generated at 2022-06-24 04:36:54.155083
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")
    assert not str_to_bool("disabled")

# Generated at 2022-06-24 04:36:58.477620
# Unit test for function str_to_bool
def test_str_to_bool():
    """Unit test for function str_to_bool.

    Returns:
        bool: True if test passed successfully otherwise False.
    """
    assert str_to_bool("Y")
    assert str_to_bool("Yes")
    assert str_to_bool("YES")
    assert str_to_bool("YEP")
    assert str_to_bool("YUP")
    assert str_to_bool("T")
    assert str_to_bool("True")
    assert str_to_bool("On")
    assert str_to_bool("Enable")
    assert str_to_bool("Enabled")
    assert str_to_bool("1")
    assert str_to_bool("N")
    assert str_to_bool("No")
    assert str_to_bool("NO")
    assert str_to_bool("F")


# Generated at 2022-06-24 04:37:01.462608
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    try:
        load_module_from_file_location.__doc__
    except (ValueError, AttributeError):
        assert False

# Generated at 2022-06-24 04:37:09.619902
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # try to load the module
    os_environ["PWD"] = str(Path(__file__).parent)
    config = load_module_from_file_location(
        Path(__file__).parent / "some_config.py"
    )

    # try to load the module defined in env variable
    os_environ["some_env_var"] = str(Path(__file__).parent)
    config = load_module_from_file_location(
        "${some_env_var}" / "some_config.py"
    )



# Generated at 2022-06-24 04:37:20.680760
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from .base_configuration import BaseConfigurations

    def f():
        pass

    def g():
        pass

    test_configs = BaseConfigurations(g)
    test_configs.basedir = "some_basedir"
    test_configs.default_config = "some_default_config"
    test_configs.default_config_file_name = "some_default_config_file_name"
    test_configs.config_files = ["some_config_files"]
    test_configs.load_function = f
    test_configs.DictConfigurationClass = BaseConfigurations
    test_configs.ListConfigurationClass = BaseConfigurations
    test_configs.YamlConfigurationClass = BaseConfigurations
    test_configs.JsonConfigurationClass = BaseConfigurations

    assert load_module_from_file

# Generated at 2022-06-24 04:37:31.608128
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Empty location:
    try:
        load_module_from_file_location("")
    except LoadFileException:
        pass
    else:
        raise ValueError

    # None location:
    try:
        load_module_from_file_location(None)
    except LoadFileException:
        pass
    else:
        raise ValueError

    # Environment variable with name "HOME" exists
    # and it's set in test environment:
    # load_module_from_file_location("/home/${HOME}/config.py")
    # should pass without errors.

    # Environment variable with name "SOME_UNDEFINED_EV" is not set:

# Generated at 2022-06-24 04:37:40.167088
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def check_module_types(_module, _location):
        assert isinstance(_module, types.ModuleType)
        assert _location in _module.__file__
        assert _location.split("/")[-1].split(".")[0] == _module.__name__

    check_module_types(
        load_module_from_file_location("tests/fixtures/conf_a.py"),
        "tests/fixtures/conf_a.py",
    )
    check_module_types(
        load_module_from_file_location("tests/fixtures/conf_b.py"),
        "tests/fixtures/conf_b.py",
    )


# Generated at 2022-06-24 04:37:49.030986
# Unit test for function str_to_bool
def test_str_to_bool():
    """Tests function str_to_bool."""
    input_values = ["y", "yes", "yep", "yup", "t", "true", "on", "enable",
                    "enabled", "1", "n", "no", "f", "false", "off", "disable",
                    "disabled", "0"]
    output_values = [True, True, True, True, True, True, True, True, True,
                     True, False, False, False, False, False, False, False,
                     False]
    for idx, val in enumerate(input_values):
        assert str_to_bool(val) == output_values[idx]

# Generated at 2022-06-24 04:37:53.226481
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True")
    assert not str_to_bool("false")
    assert str_to_bool("1")
    assert not str_to_bool("0")
    assert str_to_bool("yes")
    assert not str_to_bool("no")
    assert str_to_bool("y")
    assert not str_to_bool("n")
    assert str_to_bool("t")
    assert not str_to_bool("f")
    assert str_to_bool("yup")
    assert not str_to_bool("nope")
    assert str_to_bool("yep")
    assert not str_to_bool("nope")
    assert str_to_bool("on")
    assert not str_to_bool("off")
    assert str_to_bool("enable")


# Generated at 2022-06-24 04:38:05.154121
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function."""
    # 1) Check if method works with bytes.
    module = load_module_from_file_location(
        b"tests/files/test_configs/basic.cfg"
    )
    assert module.DEBUG is True
    assert module.TESTING is False

    # 2) Check if method works with string.
    module = load_module_from_file_location(
        "tests/files/test_configs/basic.cfg"
    )
    assert module.DEBUG is True
    assert module.TESTING is False

    # 3) Check if method works with environment variables.

# Generated at 2022-06-24 04:38:15.245926
# Unit test for function str_to_bool
def test_str_to_bool():
    """Unit test for function str_to_bool."""

    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("YES") == True
    assert str_to_bool("YeS") == True
    assert str_to_bool("t") == True
    assert str_to_bool("T") == True
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("on") == True
    assert str_to_bool("On") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("Enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("Enabled") == True

# Generated at 2022-06-24 04:38:24.675951
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("tRUE") is True
    assert str_to_bool("on") is True
    assert str_to_bool("Enable") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("1") is True

    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("0") is False

    with pytest.raises(ValueError):
        str_to_bool("tru")
    with pytest.raises(ValueError):
        str

# Generated at 2022-06-24 04:38:31.744455
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:38:38.389753
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:38:45.997966
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes")
    assert str_to_bool("Yes")
    assert str_to_bool("YES")
    assert str_to_bool("true")
    assert str_to_bool("yep")
    assert str_to_bool("t")
    assert str_to_bool("on")
    assert str_to_bool("1")
    assert not str_to_bool("nope")
    assert not str_to_bool("False")
    assert not str_to_bool("f")
    assert not str_to_bool("0")
    with pytest.raises(ValueError) as err:
        str_to_bool("qwerty")
    assert str(err.value) == "Invalid truth value qwerty"

# Generated at 2022-06-24 04:38:51.346325
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test case for importing file as module."""

    # Test location as bytes type
    path = os.path.join(os.getcwd(), "tests/aio/data_files/sample.yaml")
    assert os.path.exists(path) is True
    module = load_module_from_file_location(
        path.encode("utf-8"),
        "utf-8",
        origin="tests/aio/data_files/sample.yaml",
    )

    assert module is not None
    assert module.__name__ == "sample"

    # Test location as Path object
    path = os.path.join(os.getcwd(), "tests/aio/data_files/sample.yaml")
    assert os.path.exists(path) is True
    module = load_module_from_

# Generated at 2022-06-24 04:38:58.988377
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import TemporaryDirectory
    from copy import deepcopy
    import json

    import os

    # Check a Path object is accepted
    path = Path("/tmp/tempfile.py")
    assert load_module_from_file_location(path).__file__ == path.absolute()
    path.unlink()

    # Check an environment variable is accepted and replaces the path
    os.putenv("TEST_ENV_VAR", "/tmp")
    assert (
        load_module_from_file_location("${TEST_ENV_VAR}/tempfile.py").__file__
        == f"/tmp/tempfile.py"
    )
    os.unsetenv("TEST_ENV_VAR")

    # Check that bytes are accepted

# Generated at 2022-06-24 04:39:07.231590
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    location = "tests/test_config.py"
    module = load_module_from_file_location(location)
    assert module.TEST_CONFIG == "Foo"

    # Test environment variables
    os_environ["SOME_ENV_VAR"] = "test_config"
    module = load_module_from_file_location(
        f"{Path.cwd()}/${SOME_ENV_VAR}.py"  # nosec
    )
    assert module.TEST_CONFIG == "Foo"
    del os_environ["SOME_ENV_VAR"]

# Generated at 2022-06-24 04:39:15.338978
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:39:25.903003
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from .fixtures import write_config_file
    from .fixtures import empty_config_filepath
    from .fixtures import config_with_var_filepath
    from .fixtures import config_var_name
    from .fixtures import config_var_value

    # Test1: Without variables
    # A) Write configuration file to path
    write_config_file(empty_config_filepath, config_var_name, config_var_value)

    # B) Load config from path
    config = load_module_from_file_location(
        empty_config_filepath,
        encoding="utf8",
        mode="r",
        is_package=False,
    )
    config_var = getattr(config, config_var_name)

    # C) Check that config was loaded correctly

# Generated at 2022-06-24 04:39:34.209104
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("y") is True
    assert str_to_bool("true") is True
    assert str_to_bool("1") is True
    assert str_to_bool("Enabled") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("on") is True

    assert str_to_bool("no") is False
    assert str_to_bool("n") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("disable") is False
    assert str_to_bool("disabled") is False
    assert str_

# Generated at 2022-06-24 04:39:42.349458
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("YeS") is True
    assert str_to_bool("true") is True
    assert str_to_bool("1") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enabled") is True

    assert str_to_bool("no") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False
    assert str_to_bool("0") is False
    assert str_to_bool("disable") is False

    try:
        str_to_bool("some_string")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-24 04:39:51.164983
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # test 1
    with pytest.raises(LoadFileException) as e:
        load_module_from_file_location("some_module_name", "/some/path/${some_env_var}")
    assert str(e.value) == "The following environment variables are not set: some_env_var"

    os_environ["some_env_var"] = "some_value"
    # test 2
    with pytest.raises(LoadFileException) as e:
        load_module_from_file_location("some_module_name", "/some/path/${")
    assert str(e.value) == "Invalid syntax"

    # test 3
    loaded_module = load_module_from_file_location("some_module_name", "/some/path/${some_env_var}")

# Generated at 2022-06-24 04:39:59.255004
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("on") is True
    assert str_to_bool("false") is False
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("off") is False
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("disable") is False
    assert str_to_bool("disabled") is False
    assert str_to_bool("1") is True

# Generated at 2022-06-24 04:40:10.386984
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location() function."""
    from .testing import _test_dir

    # Test valid locations
    location = "schemas"
    module = load_module_from_file_location(location)
    assert hasattr(module, "schema")

    location = "services.config"
    module = load_module_from_file_location(location)
    assert hasattr(module, "database")

    location = _test_dir("config/test_config_file.py")
    module = load_module_from_file_location(location)
    assert hasattr(module, "test_value")
    assert module.test_value == 1

    # Test invalid locations
    location = _test_dir("config/")

# Generated at 2022-06-24 04:40:16.399891
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:40:27.246774
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Loads module by a file path
    module = load_module_from_file_location(
        __file__, encoding="utf-8", is_package=False
    )
    assert module.__file__ == __file__

    # Loads module by a file path (with environment variables)
    os_environ["TEST_ENV_VAR"] = "${TEST_ENV_VAR}"

    module = load_module_from_file_location(
        "${TEST_ENV_VAR}", encoding="utf-8", is_package=False
    )
    assert module.__file__ == "${TEST_ENV_VAR}"

    del os_environ["TEST_ENV_VAR"]

# Generated at 2022-06-24 04:40:36.026716
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:40:44.105554
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("builtins") == builtins
    assert load_module_from_file_location("os.path") == os.path
    assert load_module_from_file_location("typing.Generic") == typing.Generic

    assert load_module_from_file_location("/os.path") == os.path

    os.environ["some_env_var"] = "os"
    assert load_module_from_file_location("/os.path/${some_env_var}") == os.path
    assert load_module_from_file_location("/os.path/${${some_env_var.upper()}}") == os.path
    del os.environ["some_env_var"]

# Generated at 2022-06-24 04:40:57.396536
# Unit test for function str_to_bool
def test_str_to_bool():
    """Unit test for function str_to_bool"""
    # pylint: disable=missing-function-docstring
    # pylint: disable=invalid-name
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yeP") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("true") is True
    assert str_to_bool("T") is True
    assert str_to_bool("On") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("No") is False
    assert str_to_bool("nope") is False
    assert str_to_bool("false") is False

# Generated at 2022-06-24 04:41:04.688188
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    class Test(object):
        pass

    with NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("TEST = True")
        temp_file.flush()
        module = load_module_from_file_location(temp_file.name)
        assert module.TEST

    with NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("TEST = False")
        temp_file.flush()
        module = load_module_from_file_location(temp_file.name)
        assert not module.TEST

    with NamedTemporaryFile(mode="w+") as temp_file:
        temp_file.write("TEST = Test()")
        temp_file.flush()
        module = load_module

# Generated at 2022-06-24 04:41:13.111581
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("TRUE")
    assert str_to_bool("True")
    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("yes")
    assert str_to_bool("1")
    assert not str_to_bool("false")
    assert not str_to_bool("n")



# Generated at 2022-06-24 04:41:22.587778
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest
    from pathlib import Path
    import os
    import shutil

    def test_with_empty_dict_as_configuration(tmp_path):
        some_name = "SomeName"
        path = tmp_path / some_name
        path.write_text("{}")

        some_module = load_module_from_file_location(
            path, encoding="utf-8", is_package=False
        )
        assert some_module.__file__ == str(path)

    def test_with_some_values_in_dict_as_configuration(tmp_path):
        some_name = "SomeName"
        path = tmp_path / some_name
        path.write_text("{\"some_key\": \"some_value\"}")

        some_module = load_

# Generated at 2022-06-24 04:41:29.110118
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SANIC_CONFIG_LOCATION"] = "sanic/config.py"
    location = "sanic/${SANIC_CONFIG_LOCATION}"
    module = load_module_from_file_location(location)
    assert module.__file__ == (
        Path(__file__).parent.parent / "config.py"
    ).resolve()

# Generated at 2022-06-24 04:41:37.308431
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("YES") is True
    assert str_to_bool("y") is True
    assert str_to_bool("YeS") is True
    assert str_to_bool("Yup") is True
    assert str_to_bool("1") is True
    assert str_to_bool("T") is True
    assert str_to_bool("true") is True
    assert str_to_bool("True") is True
    assert str_to_bool("No") is False
    assert str_to_bool("n") is False
    assert str_to_bool("F") is False
    assert str_to_bool("FALSE") is False
    assert str_to_bool("0") is False
   

# Generated at 2022-06-24 04:41:41.079260
# Unit test for function str_to_bool
def test_str_to_bool():
    # Check if str_to_bool works correctly with valid values
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("false") == False
    assert str_to_bool("False") == False

    # Check if str_to_bool works correctly with invalid values
    try:
        str_to_bool("invalid_value")
    except ValueError as e:
        assert str(e) == "Invalid truth value invalid_value"



# Generated at 2022-06-24 04:41:52.430264
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os
    import os.path

    # A
    location = "test"
    try:
        load_module_from_file_location(location)
    except LoadFileException:
        pass
    else:
        assert False

    # B
    location = "test"
    os.environ["test"] = "test"
    try:
        load_module_from_file_location(location)
    except LoadFileException:
        pass
    else:
        assert False

    # C
    location = "/${test}/test.py"
    try:
        load_module_from_file_location(location)
    except IOError:
        pass
    else:
        assert False

    # D
    location = "/tmp/test.py"

# Generated at 2022-06-24 04:42:02.285714
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: D202
    os_environ["TEST_MODULE_CONFIG"] = "test_module_config.yml"
    os_environ["TEST_MODULE_NAME"] = "test"
    os_environ["TEST_MODULE_PATH"] = "configs"
    assert load_module_from_file_location(
        "test_module_config.yml"
    ) is None
    assert load_module_from_file_location(
        "test_module_config.yml", encoding="utf8"
    ) is None
    assert load_module_from_file_location(
        b"test_module_config.yml", encoding="utf8"
    ) is None
    assert load_module_from_file_location(Path(__file__)) is None
    os_en

# Generated at 2022-06-24 04:42:04.749260
# Unit test for function str_to_bool
def test_str_to_bool():
    """
    >>> test_str_to_bool()
    """
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-24 04:42:16.720698
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import shutil
    import os
    from os.path import join as path_join

    # Create temporary dir with config files
    temporary_dir = tempfile.mkdtemp(prefix="sanic_load_module_file_location_")
    env_var_filename = "env_var_filename.py"
    env_var_filepath = os.path.join(temporary_dir, env_var_filename)
    env_var_text = "env_var_content = 'some text'"
    with open(env_var_filepath, "w") as env_var_file:
        env_var_file.write(env_var_text)

    env_var_name = "TEST_ENV_VAR_NAME"
    os.environ[env_var_name] = env_var_

# Generated at 2022-06-24 04:42:28.723353
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import json
    import tempfile

    cfg_file = tempfile.NamedTemporaryFile(delete=False)
    cfg_file.write(
        json.dumps(
            {"some_config_params": "some_config_values", "python_version": sys.version}  # noqa
        ).encode()
    )
    cfg_file.close()

    module = load_module_from_file_location(cfg_file.name)
    assert module.__name__ == "config"
    assert module.python_version == sys.version
    assert module.some_config_params == "some_config_values"

    module = load_module_from_file_location(cfg_file.name, "utf8")
    assert module.python_version == sys.version

    # Set environment variable

# Generated at 2022-06-24 04:42:35.631937
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("false") is False
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("on") is True
    assert str_to_bool("off") is False

    with pytest.raises(ValueError):
        str_to_bool("notbool")

# Generated at 2022-06-24 04:42:39.436013
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(
        "config.yml.dist"
    ).DATABASE_HOST == "some-default-host"
    assert load_module_from_file_location(
        "config.yml"
    ).DATABASE_HOST == "some-host"



# Generated at 2022-06-24 04:42:45.815314
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("1") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("no") == False
    assert str_to_bool("fals") == False
    assert str_to_bool("0") == False
    assert str_to_bool("off") == False
    assert str_to_bool("disable") == False
    assert str_to_bool("0.0") == False
    assert str_to_bool("1.0") == True
    assert str_to_bool("truee") == False
    assert str_to_bool("falsy") == False

# Generated at 2022-06-24 04:42:54.531437
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("YeP") == True
    assert str_to_bool("yEs") == True
    assert str_to_bool("Yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

# Generated at 2022-06-24 04:43:06.504529
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location(
        "/pyproject.toml"
    ) == import_string("/pyproject.toml")

    direct_trigger = load_module_from_file_location(
            "/direct_trigger.py"
        ).DIRECT_TRIGGER_TEST_STRING == "DIRECT_TRIGGER_TEST_STRING"

    trigger_by_module_name = load_module_from_file_location(
            "test_module_name"
        ).TEST_MODULE_NAME_TEST_STRING == "TEST_MODULE_NAME_TEST_STRING"


# Generated at 2022-06-24 04:43:13.590742
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    class Module:
        pass

    file_location = os.path.dirname(os.path.realpath(__file__))

    os_environ["some_env_var"] = "foo"
    Module.__file__ = "${some_env_var}"

    assert (
        load_module_from_file_location("${some_env_var}", file_location)
        == Module
    )

# Generated at 2022-06-24 04:43:21.274392
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # 1
    with pytest.raises(LoadFileException):
        load_module_from_file_location(
            "some", "/some/path/${some_env_var}"  # because there is no some_env_var
        )

    # 2
    with pytest.raises(ValueError):
        load_module_from_file_location(
            "some", "/some/path/${}/"  # because there is empty environment variable
        )

    # 3
    if "some_env_var" in os_environ:
        os_environ.pop("some_env_var")
    os_environ["some_env_var"] = "some_random_value"

# Generated at 2022-06-24 04:43:29.689732
# Unit test for function str_to_bool
def test_str_to_bool():
    print("")
    print("test_str_to_bool:")
    print("----------------")
    print("")
    print("test_str_to_bool:")
    print("----------------")
    print("")
    print("test_str_to_bool:")
    print("----------------")

    print(str_to_bool("y"))
    print(str_to_bool("yes"))
    print(str_to_bool("yep"))
    print(str_to_bool("yup"))
    print(str_to_bool("t"))
    print(str_to_bool("true"))
    print(str_to_bool("on"))
    print(str_to_bool("enable"))
    print(str_to_bool("enabled"))
    print(str_to_bool("1"))

# Generated at 2022-06-24 04:43:36.265519
# Unit test for function load_module_from_file_location

# Generated at 2022-06-24 04:43:47.871942
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest
    from os import unlink
    from os import environ

    from sanic.helpers import load_module_from_file_location

    example_conf_file_name = "example_conf.py"
    env_var = "MY_ENV_VAR"
    example_conf_file_text = """
    example_conf_text = 'example conf text'
    """
    environ[env_var] = ""

    example_conf_file_location = "${MY_ENV_VAR}/" + example_conf_file_name
    example_conf_file_content = example_conf_file_text
    example_conf_file_expected_output = "example conf text"

    # Test A) Read configuration file from path with environment variables
    #        (in format ${some_env_var})
   

# Generated at 2022-06-24 04:43:56.574762
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert (
        load_module_from_file_location("test_load_module_from_file_location")
        == test_load_module_from_file_location
    )

    assert (
        load_module_from_file_location("os") == os
    )

    assert (
        load_module_from_file_location("not_existing_module")
        == None  # noqa
    )

    assert (
        load_module_from_file_location(__file__)
        == test_load_module_from_file_location
    )



# Generated at 2022-06-24 04:44:04.821527
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Let's create some test file.
    test_file_path = Path(__file__).parent.absolute() / "module_location_file.py"

    with open(test_file_path, "w") as test_file:
        test_file.write("def dummy_function(): " "return 42")

    assert (
        load_module_from_file_location(test_file_path).dummy_function()
        == 42
    )

    # B) Let's do the same but with enviroment variables.
    assert (
        load_module_from_file_location(
            Path(__file__).parent.absolute() / "${TEST_FILE_LOCATION}"
        ).dummy_function()
        == 42
    )

    # C) Let's try with incorrect enviroment variables.


# Generated at 2022-06-24 04:44:16.234026
# Unit test for function str_to_bool
def test_str_to_bool():
    assert (
        str_to_bool("y")
        == str_to_bool("yes")
        == str_to_bool("yep")
        == str_to_bool("yup")
        == str_to_bool("t")
        == str_to_bool("true")
        == str_to_bool("on")
        == str_to_bool("enable")
        == str_to_bool("enabled")
        == str_to_bool("1")
        == True
    )

# Generated at 2022-06-24 04:44:28.453570
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    # Check default case
    path = "tests/fixtures/configs/basic/basic_config.py"

    assert load_module_from_file_location(path).name == "basic_config"

    # Check case with env vars
    path = "tests/${MY_PATH}/configs/${MY_FILE}"
    os_environ["MY_PATH"] = "tests/fixtures"
    os_environ["MY_FILE"] = "basic/basic_config.py"

    assert load_module_from_file_location(path).name == "basic_config"

    # Check case with Path
    path = Path("tests/fixtures/configs/basic/basic_config.py")

    assert load_module_from_file_location(path).name == "basic_config"
    assert load_

# Generated at 2022-06-24 04:44:32.384300
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    f = open("test_load_module.py", "w+")
    f.write("some_variable = 'test'")
    f.close()

    module = load_module_from_file_location("/test_load_module.py")
    assert module.some_variable == "test"

# Generated at 2022-06-24 04:44:42.036763
# Unit test for function str_to_bool
def test_str_to_bool():
    """Test all possible valid and invalid inputs."""
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("false") is False
    assert str_to_bool("f") is False
    assert str

# Generated at 2022-06-24 04:44:51.714021
# Unit test for function str_to_bool
def test_str_to_bool():
    for truth_val in (
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ):
        assert str_to_bool(truth_val)

    for false_val in (
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ):
        assert not str_to_bool(false_val)

    try:
        str_to_bool("test")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-24 04:45:00.014774
# Unit test for function str_to_bool
def test_str_to_bool():
    assert(str_to_bool("true") == True)
    assert(str_to_bool("t") == True)
    assert(str_to_bool("on") == True)
    assert(str_to_bool("1") == True)
    assert(str_to_bool("false") == False)
    assert(str_to_bool("f") == False)
    assert(str_to_bool("off") == False)
    assert(str_to_bool("0") == False)

# Generated at 2022-06-24 04:45:05.306596
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    test_path = Path(__file__).parent / "testing" / "testing_config"
    assert "testing_config" in dir(
        load_module_from_file_location(test_path)
    )
    assert "testing_config" in dir(
        load_module_from_file_location(test_path / "__init__.py")
    )
    with pytest.raises(PyFileError) as exc:
        load_module_from_file_location(test_path / "broken_config.py")
    assert str(exc.value) == "Unable to load configuration file (e.strerror)"
    with pytest.raises(PyFileError) as exc:
        load_module_from_file_location("testing_config")