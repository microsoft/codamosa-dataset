

# Generated at 2022-06-24 04:35:05.358812
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["env_var"] = "env_var_value"

    # Test 1:
    module = load_module_from_file_location("tests.test_helpers")
    assert module.__name__ == "tests.test_helpers"

    # Test 2:
    module = load_module_from_file_location("tests.test_helpers.py")
    assert module.__name__ == "tests.test_helpers"

    # Test 3:
    module = load_module_from_file_location("tests.test_helpers.py",)
    assert module.__name__ == "tests.test_helpers"

    # Test 4:
    module = load_module_from_file_location("tests/test_helpers.py",)

# Generated at 2022-06-24 04:35:12.120496
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sanic.config

    # A) load from string
    _dict = load_module_from_file_location(
        "sanic.config.TEST_DICT",
        __file__,
        "sanic.config",
        True,
        True,
        True,
        False,
    )
    assert _dict == sanic.config.TEST_DICT

    # B) load from Path
    path = Path(__file__)
    _dict = load_module_from_file_location(
        path,
        "sanic.config",
        True,
        True,
        True,
        False,
    )
    assert _dict == sanic.config

    # C) load from bytes

# Generated at 2022-06-24 04:35:16.552127
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("YES") == True
    assert str_to_bool("no") == False
    try:
        str_to_bool("Noo")
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-24 04:35:28.467508
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import sys
    import tempfile
    import pytest
    from os import environ
    from contextlib import contextmanager

    import pytest

    @contextmanager
    def system_environ(**env):
        """This context manager allows to override system environment
        variables in the scope of a single test.
        """
        old_env = dict(environ)
        environ.clear()
        environ.update(env)
        try:
            yield
        finally:
            environ.clear()
            environ.update(old_env)

    @pytest.fixture
    def example_config_file():
        """Example configuration file"""

# Generated at 2022-06-24 04:35:39.370902
# Unit test for function str_to_bool
def test_str_to_bool():
    for val, expected in [
        ("Y", True),
        ("yes", True),
        ("yep", True),
        ("yes", True),
        ("Yup", True),
        ("True", True),
        ("t", True),
        ("on", True),
        ("1", True),
        ("N", False),
        ("no", False),
        ("f", False),
        ("false", False),
        ("off", False),
        ("0", False),
    ]:
        result = str_to_bool(val)
        assert result == expected, f"{val} got {result} instead of {expected}"

    with pytest.raises(ValueError):
        str_to_bool("blah")



# Generated at 2022-06-24 04:35:47.093013
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("t")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("false")
    assert not str_to_bool("False")
    assert not str_to_bool("n")
    assert not str_to_bool("f")
    assert not str_to_bool("no")
    assert not str_to_bool("off")
    assert not str

# Generated at 2022-06-24 04:35:52.444774
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("1") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("true") is True
    assert str_to_bool("t") is True
    assert str_to_bool("f") is False
    assert str_to_bool("0") is False
    assert str_to_bool("false") is False
    assert str_to_bool("F") is False

# Generated at 2022-06-24 04:36:00.420275
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("1")
    assert str_to_bool("0")
    assert str_to_bool("True")
    assert str_to_bool("True")
    assert not str_to_bool("False")
    assert not str_to_bool("false")
    assert not str_to_bool("none")
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert not str_to_bool("n")
    assert not str_to_bool("no")



# Generated at 2022-06-24 04:36:09.427495
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Test 1
    # Check if this function returns a loaded module.
    # Test 2
    # Check if there isn't a problem when str_to_bool is in a module.
    # Test 3
    # Check if function raises an error when dependent module doesn't exist.
    # Test 4
    # Check if this function raises LoadFileException
    # when arguments are incorrect.

    # Test 1
    loaded_module = load_module_from_file_location(
        "tests/configs/config_with_str_to_bool.py"
    )
    assert type(loaded_module) == types.ModuleType

    # Test 2
    assert loaded_module.MY_TRUE == True  # noqa # pylint: disable=comparison-with-callable
    assert loaded_module.MY_FALSE == False  # noqa

# Generated at 2022-06-24 04:36:19.605342
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    from tempfile import TemporaryDirectory  # noqa

    with TemporaryDirectory() as tmp_dir:
        tmp_dir_path = Path(tmp_dir)
        # A) Check that we are able to load module without env variables
        #    in path.
        module_file = tmp_dir_path / "example_module.py"
        module_file.write_text(
            """\
            some_variable = 42
            """
        )

        module = load_module_from_file_location(module_file)

        assert module.some_variable == 42

        # B) Check that if module file path contains env variables
        #    in format ${some_env_var} they will be replaced
        #    by the value of this variables.

# Generated at 2022-06-24 04:36:30.097940
# Unit test for function str_to_bool
def test_str_to_bool():
    import pytest
    from os import environ

    # Set up environment variables.
    environ["TEST_ENV_VAR"] = "test_env_var_value"

    # *******************************
    # *** Check Invalid values.
    # *******************************

    # Check that function raise ValueError upon receiving invalid value.
    with pytest.raises(ValueError) as e:
        str_to_bool("invalid_val")

    # Check that message is correct.
    assert str(e.value).startswith("Invalid truth value invalid_val")

    # *******************************
    # *** Check True values.
    # *******************************

    assert str_to_bool("y")
    assert str_to_bool("Y")
    assert str_to_bool("YES")
    assert str_to_bool

# Generated at 2022-06-24 04:36:40.550976
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from sanic.exceptions import PyFileError

    try:
        from pathlib import Path

        assert isinstance(
            load_module_from_file_location(Path("__init__.py")), types.ModuleType
        )

    except ImportError:
        # pathlib import error not covered
        pass

    try:
        assert isinstance(
            load_module_from_file_location("path/to/config/file.py"),
            types.ModuleType,
        )
    except ImportError:
        pass

    try:
        assert isinstance(
            load_module_from_file_location(
                "${MANAGE_PY_LOCATION}/../conf/config.py"
            ),
            types.ModuleType,
        )
    except ImportError:
        pass

    assert load_module_from_

# Generated at 2022-06-24 04:36:47.087003
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """
    Unit test for function load_module_from_file_location
    """
    # If you want to test it, run:
    #
    # pip install pytest
    # pytest ./tests/helpers/test_load_module_from_file_location.py

    # File test_module.py contains:
    # X = 42
    #
    # # While test_module_2.py contains:
    # X = "1"
    # Y = 2
    #
    # Repeat with:
    # ../../tests/helpers/test_module.py

    test_path = Path(__file__).absolute().parent
    test_file = test_path / "test_module.py"
    assert load_module_from_file_location(test_file).X == 42

    # Repeat with:
   

# Generated at 2022-06-24 04:36:54.249348
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("y")
    assert not str_to_bool("false")
    assert not str_to_bool("n")
    assert not str_to_bool(False)
    assert str_to_bool(True)

    with pytest.raises(ValueError) as e:
        str_to_bool("123")

    assert str(e.value) == "Invalid truth value 123"

# Generated at 2022-06-24 04:37:00.324916
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("True") is True
    assert str_to_bool("1") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("on") is True
    assert str_to_bool("oN") is True
    assert str_to_bool("eNaBle") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("FALSE") is False
    assert str_to_bool("0") is False
    assert str_to_bool("NO") is False
    assert str_to_bool("n") is False

# Generated at 2022-06-24 04:37:12.115628
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    assert (
        load_module_from_file_location("/tmp/test.py")
        == load_module_from_file_location("/tmp/test.py", name="test")
    )
    import tempfile

    with tempfile.NamedTemporaryFile("w") as f:
        f.write("some code")
        f.seek(0)
        try: load_module_from_file_location(f.name)
        except PyFileError: pass
        else: assert False, "Exception should be raised in this case"

    with tempfile.NamedTemporaryFile("w") as f:
        f.write("some code")
        f.seek(0)
        try: load_module_from_file_location(f.name, name="test")
        except PyFileError: pass

# Generated at 2022-06-24 04:37:18.411077
# Unit test for function str_to_bool

# Generated at 2022-06-24 04:37:22.302840
# Unit test for function load_module_from_file_location

# Generated at 2022-06-24 04:37:33.190542
# Unit test for function str_to_bool
def test_str_to_bool():
    assert True == str_to_bool('1')
    assert True == str_to_bool('y')
    assert True == str_to_bool('Y')
    assert False == str_to_bool('0')
    assert False == str_to_bool('n')
    assert False == str_to_bool('N')
    assert False == str_to_bool('f')
    assert False == str_to_bool('F')
    assert True == str_to_bool('YES')
    assert True == str_to_bool('yes')
    assert False == str_to_bool('NO')
    assert False == str_to_bool('no')
    assert True == str_to_bool('yep')
    assert True == str_to_bool('true')
    assert True == str_to_bool('TRUE')

# Generated at 2022-06-24 04:37:41.250903
# Unit test for function str_to_bool
def test_str_to_bool():  # noqa
    assert str_to_bool("t")
    assert str_to_bool("T")
    assert str_to_bool("yes")
    assert str_to_bool("Yes")
    assert str_to_bool("YES")
    assert str_to_bool("yep")
    assert str_to_bool("Yep")
    assert str_to_bool("YEP")
    assert str_to_bool("yup")
    assert str_to_bool("YUP")
    assert str_to_bool("true")
    assert str_to_bool("True")
    assert str_to_bool("TRUE")
    assert str_to_bool("on")
    assert str_to_bool("On")
    assert str_to_bool("ON")
    assert str_to_bool("enable")
    assert str

# Generated at 2022-06-24 04:37:49.939394
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # A) Check if it can try to load file path containing some environent
    #    variables. 
    location = "./tests/somefile_${var_not_set}"
    env_var_name = "var_not_set"
    with pytest.raises(LoadFileException):
        load_module_from_file_location(location)
    os_environ[env_var_name] = "1"
    with pytest.raises(IOError):
        load_module_from_file_location(location)

# Generated at 2022-06-24 04:37:55.837186
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    def load_from_file(
        location: Union[bytes, str, Path], encoding: str = "utf8"
    ):
        return load_module_from_file_location(
            location, encoding=encoding, is_package=False
        )

    # A) Check if all valid paths are accepted and checked
    load_from_file("some_module_name", "/some/path/${some_env_var}")

    # B) Check if passing some absolute path is accepted too
    load_from_file(Path("/some/path/${some_env_var}"))

    # C) Check if passing some relative path is accepted too
    load_from_file("some_module_name", "./some/path/${some_env_var}")

    # D) Check if passing some relative path with current dir is
    #

# Generated at 2022-06-24 04:38:06.778927
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import pytest

    # 1. Test function with string parameters. (ok)
    # 2. Test function with bytes parameters
    #    and well known utf-8 encoding. (ok)
    # 3. Test function with bytes parameters
    #    and wrong utf-8 encoding. (ok)
    # 4. Test function with bytes parameters
    #    and well known utf-16 encoding. (ok)
    # 5. Test function with bytes parameters
    #    and well known utf-16-be encoding. (ok)
    # 6. Test function with bytes parameters
    #    and well known utf-16-le encoding. (ok)

    # 7. Test function with Path parameter. (ok)
    # 8. Test function with Path parameter without extension. (ok)

    # 9. Test function with location with environment variable. (

# Generated at 2022-06-24 04:38:16.687941
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    ###
    # A) Check if location contains any environment variables
    #    in format ${some_env_var}.
    env_vars_in_location = set(re_findall(r"\${(.+?)}", location))

    # B) Check these variables exists in environment.
    not_defined_env_vars = env_vars_in_location.difference(
        os_environ.keys()
    )
    if not_defined_env_vars:
        raise LoadFileException(
            "The following environment variables are not set: "
            f"{', '.join(not_defined_env_vars)}"
        )

    # C) Substitute them in location.

# Generated at 2022-06-24 04:38:25.527762
# Unit test for function str_to_bool
def test_str_to_bool():

    assert str_to_bool("yes") is True
    assert str_to_bool("no") is False
    assert str_to_bool("y") is True
    assert str_to_bool("n") is False
    assert str_to_bool("1") is True
    assert str_to_bool("0") is False
    assert str_to_bool("True") is True
    assert str_to_bool("False") is False
    assert str_to_bool("true") is True
    assert str_to_bool("false") is False
    assert str_to_bool("YEP") is True
    assert str_to_bool("NOPE") is False

    try:
        str_to_bool("asdf")
    except Exception as e:
        assert isinstance(e, ValueError)



# Generated at 2022-06-24 04:38:36.804466
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """https://github.com/huge-success/sanic/pull/1736"""
    import tempfile
    import importlib

    with tempfile.TemporaryDirectory() as dirname:
        conf_file_name = os_environ.get("CONF_FILE_NAME", "tmp_conf_file.py")
        conf_file_path = Path(dirname).joinpath(conf_file_name)
        conf_file_path.write_text("TEST_VAR='test_val'")

        conf_path = str(conf_file_path)
        module = load_module_from_file_location(conf_path)

        importlib.reload(module)
        assert module.TEST_VAR == "test_val"

        os_environ["TEST_VAR"] = "test_val_2"

# Generated at 2022-06-24 04:38:47.407703
# Unit test for function str_to_bool
def test_str_to_bool():
    """str_to_bool unit tests."""
    assert str_to_bool("y")
    assert str_to_bool("yes")
    assert str_to_bool("yep")
    assert str_to_bool("yup")
    assert str_to_bool("t")
    assert str_to_bool("true")
    assert str_to_bool("on")
    assert str_to_bool("enable")
    assert str_to_bool("enabled")
    assert str_to_bool("1")
    assert not str_to_bool("n")
    assert not str_to_bool("no")
    assert not str_to_bool("f")
    assert not str_to_bool("false")
    assert not str_to_bool("off")
    assert not str_to_bool("disable")

# Generated at 2022-06-24 04:38:56.316040
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import os.path
    import tempfile
    import pytest
    from os import environ as os_environ
    from textwrap import dedent

    from sanic.helpers import load_module_from_file_location

    # Create temp file and store its path to module variable
    tmp = tempfile.NamedTemporaryFile(suffix=".py", prefix="test_")
    path = tmp.name

    # Create some content for temp file
    content = dedent(
        """\
        class ClassClass:
            def __init__(self):
                self.c = 3
        """
    )
    tmp.write(bytes(content, encoding="utf-8"))
    tmp.flush()

    # Test if load_module_from_file_location returns the same
    # object as importlib.util.module

# Generated at 2022-06-24 04:39:08.173411
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true")
    assert str_to_bool("yes")
    assert str_to_bool("enable")
    assert str_to_bool("on")
    assert str_to_bool("y")
    assert str_to_bool("t")
    assert str_to_bool("1")

    assert not str_to_bool("false")
    assert not str_to_bool("no")
    assert not str_to_bool("disable")
    assert not str_to_bool("off")
    assert not str_to_bool("n")
    assert not str_to_bool("f")
    assert not str_to_bool("0")

    # If value is not in accepted values than function should
    # raise a ValueError.
    with pytest.raises(ValueError):
        str_to_

# Generated at 2022-06-24 04:39:19.406012
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:39:29.718241
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from os import environ

    class EmptyEnv:
        def __init__(self):
            pass

        def __contains__(self, item):
            return False

    # This is a object providing interface similar to os.environ.
    # It is used in a few unit tests to mock os.environ.
    empty_env = EmptyEnv()

    # A) Location without any env variables.

    # A.1) Location as pathlib.Path or string
    # A.1.a) Location as pathlib.Path
    #       It is correspond to the first usecase
    #       described in load_module_from_file_location docstring.

    location = "./sanic/helpers/unittest_config.py"
    location = Path(location)

# Generated at 2022-06-24 04:39:36.207565
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    import os
    import shutil

    from tempfile import mkdtemp

    def assert_import_error(loc):
        try:
            module = load_module_from_file_location(loc)
        except ImportError:
            return True
        except Exception as e:
            raise e
        raise AssertionError(
            f"{loc} is not a valid import string and yet it is not raising import error"
        )

    # Unit test:
    # Check that we can load modules from pathlib.Paths

# Generated at 2022-06-24 04:39:45.648802
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    '''
    This function should return module instance.
    If you pass in it file, which contain assignment my_var = 42,
    then it should have attribute "my_var" with value 42.
    '''
    import tempfile
    import shutil
    import os
    import re

    def test_func(arg_location, test_file_content, expected_result):
        tmpdirname = tempfile.mkdtemp()
        tmp_file_obj = tempfile.NamedTemporaryFile(
            dir=tmpdirname, suffix=".py", mode="w+", delete=False
        )
        tmp_file_name = tmp_file_obj.name


# Generated at 2022-06-24 04:39:57.446394
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import shutil
    from tempfile import mkdtemp
    from contextlib import suppress

    from sanic.testing import SanicTestClient
    from sanic.testing import SanicTestClientClosedConnection

    client = SanicTestClient(get_app, raise_server_exceptions=True)

    some_env_var = "SOME_ENV_VAR_FOR_TESTING_LOAD_MODULE_FROM_FILE"
    some_env_var_value = "some_env_var_value"
    some_env_var_value_as_path = Path(some_env_var_value)

    # Test 1
    os_environ[some_env_var] = some_env_var_value
    response = client.get("/index?load_module=" + some_env_var)


# Generated at 2022-06-24 04:40:05.897350
# Unit test for function str_to_bool
def test_str_to_bool():
    cases = [
        ("yes", True),
        ("enable", True),
        ("true", True),
        ("1", True),
        ("no", False),
        ("disable", False),
        ("false", False),
        ("0", False),
        ("", False),
    ]
    for test_input, expected in cases:
        result = str_to_bool(test_input)
        assert result == expected, f"{result} != {expected}"

# Generated at 2022-06-24 04:40:13.773932
# Unit test for function str_to_bool
def test_str_to_bool():
    val_to_test = ["y", "yes", "yep", "yup", "t", "true", "on", "enable",
                   "enabled", "1", "n", "no", "f", "false", "off", "disable",
                   "disabled", "0"]
    for value in val_to_test:
        if value in {"y", "yes", "yep", "yup", "t", "true", "on", "enable",
                     "enabled", "1"}:
            assert (str_to_bool(value)) == True
        else:
            assert (str_to_bool(value)) == False

# Generated at 2022-06-24 04:40:26.635552
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import tempfile
    import os

    test_module_name = "test_load_module_from_file_location"
    test_module_path = os.path.join(tempfile.gettempdir(), test_module_name)

    test_config_1 = "a: 1; b: 2; c: { d: 3 }"

    with open(test_module_path, "w") as file:
        file.write(test_config_1)

    test_module = load_module_from_file_location(test_module_path)

    a = test_module.a
    b = test_module.b
    c = test_module.c
    d = test_module.c["d"]

    assert a == 1
    assert b == 2
    assert c == {"d": 3}
    assert d == 3

# Generated at 2022-06-24 04:40:34.929276
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    assert load_module_from_file_location("/some/path/${some_env_var}")
    module = load_module_from_file_location("test/test_config.py")
    assert module.a == 1
    assert module.b == 2
    assert module.c
    assert module.d
    assert module.e == 2
    assert module.f is False
    assert module.g == 2
    assert module.h == 3
    assert module.i == 2
    assert module.j
    assert module.k is False
    assert module.l == "password"
    assert module.m == "password"
    assert module.n == "password"
    assert module.o == "password"



# Generated at 2022-06-24 04:40:43.624848
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import os
    import sys

    import pytest

    from common.utils import (
        gen_temp_file_path,
        load_module_from_file_location,
    )

    # For some reason test `temp_file.close()` not working, so I use this
    # variable to remember file path of temp file.
    temp_file_path = None

    with pytest.raises(LoadFileException):
        os.environ.pop("PATH", None)
        load_module_from_file_location("${PATH}/some_module.py")

    with pytest.raises(LoadFileException):
        os.environ["SOME_VAR"] = "/some/path"
        load_module_from_file_location("${SOME_VAR}/some_module.py")

    temp_file

# Generated at 2022-06-24 04:40:56.901292
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True
    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:41:04.209374
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("true") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("t") is True
    assert str_to_bool("on") is True
    assert str_to_bool("1") is True

    assert str_to_bool("false") is False
    assert str_to_bool("no") is False
    assert str_to_bool("off") is False
    assert str_to_bool("n") is False
    assert str_to_bool("f") is False
    assert str_to_bool("0") is False

    try:
        str_to_bool("random text")
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-24 04:41:16.097986
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sanic
    import os
    import shutil
    import tempfile

    # Check if it works when it is a file path.
    some_module = load_module_from_file_location(
        sanic.__file__, encoding="utf8", is_package=False
    )
    assert some_module.__name__ == "sanic"

    # Check if it works when it only contains file name and it's
    # in current working directory.
    os.chdir(os.path.dirname(sanic.__file__))
    some_module = load_module_from_file_location(
        os.path.basename(sanic.__file__), encoding="utf8", is_package=False
    )
    assert some_module.__name__ == "sanic"

    # Check if it works when it

# Generated at 2022-06-24 04:41:27.518142
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Test load_module_from_file_location function.

    It check if we can load module from location provided as file path
    with environment variables and without them.
    The directory with test module is created in the same place where
    test_config_helper.py file is located.
    You can run this test like this:

        python -m pytest test_config_helper.py

    """

    # Use real environment variables from test_config_helper.py.
    import test_config_helper

    # Create a test directory and save a path in envirenment variable.
    test_dir_path = Path(test_config_helper.__file__).parent.joinpath(
        "test_config_dir"
    )
    test_dir_path.mkdir()

# Generated at 2022-06-24 04:41:37.111473
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    import importlib
    import os
    import shutil
    import tempfile
    from os.path import abspath, dirname, join

    module_location = "test_module"

    # Test for some existing module
    module = load_module_from_file_location(module_location)
    assert module == importlib.import_module(module_location)

    # Test for some not existing module
    try:
        load_module_from_file_location(
            module_location + "_not_existing"
        )
    except LoadFileException:
        pass
    else:
        AssertionError("LoadFileException not raised")

    # Test for environment variables
    def test_env_variable(*args, **kwargs):
        os.environ["env_var_1"] = "env_var_1"


# Generated at 2022-06-24 04:41:44.637280
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # pylint: disable=bad-option-value,redefined-outer-name
    os_environ["SANIC_CONFIG_FILE"] = "/some/path/to/file.py"
    os_environ["SOME_OTHER_VAR"] = "some_value"

    # 1. Test with valid path
    assert (
        load_module_from_file_location("/some/path/${SANIC_CONFIG_FILE}")
        .__file__
        == os_environ["SANIC_CONFIG_FILE"]
    )

    # 2. Test with valid path, but environment variable does not exist.
    with pytest.raises(LoadFileException) as e:
        load_module_from_file_location("/some/path/${INVALID_VAR}")

# Generated at 2022-06-24 04:41:55.618132
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("yep") is True
    assert str_to_bool("yup") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("enabled") is True
    assert str_to_bool("1") is True

    assert str_to_bool("n") is False
    assert str_to_bool("no") is False
    assert str_to_bool("f") is False
    assert str_to_bool("false") is False
    assert str_to_bool("off") is False

# Generated at 2022-06-24 04:42:04.242343
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import pytest

    # Expected raising
    with pytest.raises(ValueError):
        load_module_from_file_location(
            "not_existing_env_var", "/some/path/${not_existing_env_var}"
        )

    with pytest.raises(FileNotFoundError):
        load_module_from_file_location("not_existing_file.py")

    with pytest.raises(PyFileError):
        load_module_from_file_location("/some/not_existing_file.py")

# Generated at 2022-06-24 04:42:11.395671
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    location = "some_file.py"
    module = load_module_from_file_location(
        location, "/some/path/${some_env_var}"
    )
    assert module is not None
    assert module.__spec__.name == "config"
    assert module.__spec__.submodule_search_locations == []
    assert module.__spec__.loader is not None
    assert module.__spec__.parent is None
    assert module.__spec__.cached == "some_file.py"
    assert module.__spec__.origin == "some_file.py"
    assert module.__spec__.has_location == True

# Generated at 2022-06-24 04:42:21.722866
# Unit test for function str_to_bool
def test_str_to_bool():
    for case in {
        "y": True,
        "yes": True,
        "yep": True,
        "yup": True,
        "t": True,
        "true": True,
        "on": True,
        "enable": True,
        "enabled": True,
        "1": True,
        "n": False,
        "no": False,
        "f": False,
        "false": False,
        "off": False,
        "disable": False,
        "disabled": False,
        "0": False,
    }:
        assert str_to_bool(case) == case
    assert str_to_bool("Y") == "y"
    assert str_to_bool("YES") == "yes"
    assert str_to_bool("True") == "true"

# Generated at 2022-06-24 04:42:31.469953
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True
    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:42:37.454167
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("T") == True
    assert str_to_bool("TRUE") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("True") == True
    assert str_to_bool("Yes") == True
    assert str_to_bool("Y") == True
    assert str_to_bool("YEP") == True
    assert str_to_bool(
        "yup"
    ) == True, "including uppercase does not work on 'yup'"
    assert str_to_bool(
        "ON"
    ) == True, "uppercase does not work with 'on'"

# Generated at 2022-06-24 04:42:40.726934
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Function load_module_from_file_location has to return
    # module object.
    module = load_module_from_file_location(
        "some_module_name", "/some/path/some_module_file.py"
    )
    assert isinstance(module, types.ModuleType)

# Generated at 2022-06-24 04:42:42.700167
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["TEST_ENV_VAR"] = "test_env_var"
    location = "./tests/test_configs/${TEST_ENV_VAR}"
    module = load_module_from_file_location(location)
    assert module.TEST_ENV_VAR == os_environ["TEST_ENV_VAR"]



# Generated at 2022-06-24 04:42:52.189174
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("yes") is True
    assert str_to_bool("t") is True
    assert str_to_bool("True") is True
    assert str_to_bool("1") is True
    assert str_to_bool("no") is False
    assert str_to_bool("FALSE") is False
    assert str_to_bool("off") is False
    assert str_to_bool("0") is False

    # Assert that function str_to_bool raises a ValueError if
    # input value is invalid
    try:
        str_to_bool("some_invalid_value")
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 04:42:55.570586
# Unit test for function str_to_bool
def test_str_to_bool():
    assert (str_to_bool("y") is True)
    assert (str_to_bool("yes") is True)
    assert (str_to_bool("f") is False)
    try:
        str_to_bool("foo")
        assert False
    except ValueError:
        pass


# Generated at 2022-06-24 04:43:06.588194
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """Tests that function load_module_from_file_location works correctly."""
    import sanic.config as config

    # Test A)
    # 1) Creation of location with env vars that are set in environment.
    env_var_name = "TEST_SANIC_ENV_VAR"
    env_var_value = os_environ[env_var_name] = "VAL"
    conf_location = os.path.join(
        "${" + env_var_name + "}", "test_file_name.py"
    )

    # 2) Configuration file creation
    conf_path = os.path.join(env_var_value, "test_file_name.py")

# Generated at 2022-06-24 04:43:18.232759
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from tempfile import NamedTemporaryFile

    # A) Prepare temporary file.
    with NamedTemporaryFile(mode="w") as f:

        # B) Write to our temp file
        f.write("""a = 0 \n""")
        f.write("""b = {"a": 1, "b": 2, "c": {"d": 3}} \n""")
        f.write("""c = [1, 2, 3] \n""")
        f.flush()

        # C) Load module
        mod = load_module_from_file_location(f.name)

        # D) Check if module contains everything what
        #    we've written to temp file.
        assert mod.a == 0
        assert mod.b == {"a": 1, "b": 2, "c": {"d": 3}}

# Generated at 2022-06-24 04:43:21.854123
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    assert load_module_from_file_location(
        "tests.test_utils_test_load_module_from_file_location"
    ) is globals()



# Generated at 2022-06-24 04:43:29.718584
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # TODO:
    # 1) Write more tests.
    # 2) To make this test more functional, let's also test
    #    if the module we try to load is properly populated.
    # 3) Let's also test this function against absolute and relative paths.

    from sanic_envconfig.config import Config
    from unittest.mock import patch
    from os import environ
    from tempfile import TemporaryDirectory

    # The function to test:
    from sanic_envconfig._utils import load_module_from_file_location

    # Environment variables we will try to put in the Config object:
    environ["ENVIRON_1"] = "ENVIRON_1"
    environ["ENVIRON_2"] = "ENVIRON_2"

# Generated at 2022-06-24 04:43:36.633046
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    tmp_dir = Path(tempfile.gettempdir())
    tmp_file = tmp_dir / "module_from_file.py"
    config = {"TEST": 1}
    with tmp_file.open("w") as f:
        f.write(
            f"from pathlib import Path\n"
            "TEST = Path('path_to_some_file')\n"
            "OTHER_CONFIG = {'test': 1}\n"
        )

    loaded_module = load_module_from_file_location(tmp_file)

    assert loaded_module.TEST == Path("path_to_some_file")
    assert loaded_module.OTHER_CONFIG == {'test': 1}

# Generated at 2022-06-24 04:43:41.844735
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa
    """Tests the load_module_from_file_location function"""

    assert str_to_bool("y") is True
    assert str_to_bool("n") is False

# Generated at 2022-06-24 04:43:50.389563
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    from . import utils  # noqa
    from itertools import product

    # Test cases for true value of boolean variables.
    var_true = [
        "y",
        "yes",
        "yep",
        "yup",
        "t",
        "true",
        "on",
        "enable",
        "enabled",
        "1",
    ]

    # Test cases for false value of boolean variables.
    var_false = [
        "n",
        "no",
        "f",
        "false",
        "off",
        "disable",
        "disabled",
        "0",
    ]

    # Test cases for environment variables.
    var = ["env_var_1", "env_var_2"]
    var_val = ["value_1", "value_2"]

   

# Generated at 2022-06-24 04:43:59.998074
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("y") == True
    assert str_to_bool("yes") == True
    assert str_to_bool("yep") == True
    assert str_to_bool("yup") == True
    assert str_to_bool("t") == True
    assert str_to_bool("true") == True
    assert str_to_bool("on") == True
    assert str_to_bool("enable") == True
    assert str_to_bool("enabled") == True
    assert str_to_bool("1") == True

    assert str_to_bool("n") == False
    assert str_to_bool("no") == False
    assert str_to_bool("f") == False
    assert str_to_bool("false") == False
    assert str_to_bool("off") == False

# Generated at 2022-06-24 04:44:08.639186
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    # Assume test_config.py file exist in this directory.

    # A) Try without environment variables.
    # B) Import string should not raise error.
    # C) File should return correct config.
    config = load_module_from_file_location(
        "tests.test_helpers.test_config",
        "tests/test_helpers/test_config.py"
    )
    assert config.TEST == 1234

    # A) Try with environment variables.
    # B) Import string should not raise error.
    # C) File should return correct config.
    config = load_module_from_file_location(
        "tests.test_helpers.test_config",
        "tests/test_helpers/${PWD}/test_config.py"
    )
    assert config.TEST == 12

# Generated at 2022-06-24 04:44:18.211502
# Unit test for function str_to_bool
def test_str_to_bool():
    assert str_to_bool("Yes") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("Y") is True
    assert str_to_bool("Yep") is True
    assert str_to_bool("True") is True
    assert str_to_bool("t") is True
    assert str_to_bool("true") is True
    assert str_to_bool("T") is True
    assert str_to_bool("on") is True
    assert str_to_bool("enable") is True
    assert str_to_bool("1") is True
    assert str_to_bool("No") is False
    assert str_to_bool("no") is False
    assert str_to_bool("n") is False
    assert str_

# Generated at 2022-06-24 04:44:28.606991
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    os_environ["SOME_ENV_CONFIG_VAR"] = "example"

    module = load_module_from_file_location(
        Path(__file__).parent.joinpath("config.py")
    )
    assert module.__file__ == str(Path(__file__).parent.joinpath("config.py"))
    assert module.NAME == "FOO"

    module = load_module_from_file_location(b"config.py", encoding="utf-8")
    assert module.__file__ == str(Path(__file__).parent.joinpath("config.py"))
    assert module.NAME == "FOO"

    module = load_module_from_file_location(
        "/var/www/foobar/config.py", encoding="utf-8"
    )
    assert module.__

# Generated at 2022-06-24 04:44:38.714635
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():

    # Test for passing full path directly
    location = Path(__file__).parent / "test_config.py"
    mod = load_module_from_file_location(location)
    assert mod.a == "a"
    assert mod.b == "b"
    assert mod.c.d == "d"

    # Test for passing location in way,
    # as in importlib.util.spec_from_file_location
    name = "test_config"
    location = Path(__file__).parent / "test_config.py"
    mod = load_module_from_file_location(name, location)
    assert mod.a == "a"
    assert mod.b == "b"
    assert mod.c.d == "d"

    # Test for passing location in way,
    # as in importlib.util

# Generated at 2022-06-24 04:44:46.441707
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    import sys
    from tempfile import TemporaryDirectory

    def check_module_structure(module, module_name, data):
        assert module.__name__ == module_name
        assert module.__file__.endswith(".py")
        assert module.__package__ is None
        assert module.__cached__.endswith(".pyc")
        assert module.__loader__.__name__.endswith("FileLoader")
        assert module.__spec__.name == module_name
        assert module.__spec__.loader.__name__.endswith("FileLoader")
        assert module.__spec__.origin.endswith(".py")
        assert module.__spec__.submodule_search_locations is None
        assert module.__spec__.cached.endswith(".pyc")
       

# Generated at 2022-06-24 04:44:57.127430
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():
    """

    Sanity check for load_module_from_file_location function.
    Performs some simple checks and
    then check if it can load file with environmental variables.

    """
    import os
    import tempfile

    # A) Some simple checks.

    # A1) Check if everything is fine with loading module
    #     which has been specified in the standard way.
    module1 = load_module_from_file_location("sanic.app")
    assert module1.__name__ == "sanic.app"

    # A2) Check if module can be specified as a file path.
    module2 = load_module_from_file_location(
        __file__, use_runtime_path=False
    )
    assert module2.__name__ == "sanic.helpers"  # Here __name__ is module name.

# Generated at 2022-06-24 04:45:03.845477
# Unit test for function load_module_from_file_location
def test_load_module_from_file_location():  # noqa: F811
    """Unit test of function
    :func:`sanic.config.load_module_from_file_location`.
    """
    from os import environ
    from os.path import dirname, join
    from tempfile import NamedTemporaryFile
    from unittest import TestCase
    from unittest.mock import patch

    from sanic.config import (
        load_module_from_file_location,
        str_to_bool,
    )

    # TODO: It is not functional test because it does not have any
    #       assertions.

    current_file_location = dirname(__file__)  # type: ignore
    configuration_file_location = join(
        current_file_location, "configuration-file-location.py"
    )
