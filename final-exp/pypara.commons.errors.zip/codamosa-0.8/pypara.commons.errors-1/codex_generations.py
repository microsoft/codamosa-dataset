

# Generated at 2022-06-12 05:59:51.988277
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        return
    else:
        assert False, "No exception was raised."



# Generated at 2022-06-12 05:59:54.848755
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is a programming error.")
    except Exception as e:
        pass
    else:
        raise RuntimeError("Programming error should have raised an exception.")

# Generated at 2022-06-12 05:59:56.679747
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:00:00.346581
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:00:01.349887
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test message")

# Generated at 2022-06-12 06:00:03.807745
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Error message")
    except ProgrammingError:
        pass
    else:
        assert False, "Failed to raise a ProgrammingError exception"


# Generated at 2022-06-12 06:00:05.698436
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(None)
    ProgrammingError("")
    ProgrammingError("abc")


# Generated at 2022-06-12 06:00:07.373215
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:00:11.019815
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Not just a warning")
    except ProgrammingError as ex:
        assert str(ex) == "Not just a warning"


# Generated at 2022-06-12 06:00:16.974070
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ttext = "This is a test message."
    # Instantiating the class:
    error = ProgrammingError(ttext)
    # Checking attributes of the instanced exception:
    assert error.args[0] == ttext
    assert str(error) == ttext
    assert repr(error) == f"ProgrammingError({ttext!r})"

# Generated at 2022-06-12 06:00:20.876729
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as e:
        assert e.args[0] == "A message"


# Generated at 2022-06-12 06:00:23.936406
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test of constructor")
    except ProgrammingError as err:
        assert err.args == ("Test of constructor",)

# Unit tests for method passert of class ProgrammingError

# Generated at 2022-06-12 06:00:25.551814
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-12 06:00:28.504016
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Programming error should be raised")
    except ProgrammingError as e:
        assert(e.message == "Programming error should be raised")
    else:
        assert(False)


# Generated at 2022-06-12 06:00:31.726890
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, 'error message')
    except ProgrammingError as e:
        assert e.args == ('error message',)

# Generated at 2022-06-12 06:00:34.749723
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    with ProgrammingError(message="A message"):
        assert False, "The message should be printed before"

    with ProgrammingError:
        assert False, "The message should be printed before"


# Generated at 2022-06-12 06:00:38.300295
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="Forced error")
    except ProgrammingError as e:
        assert e.args[0] == "Forced error"


# Generated at 2022-06-12 06:00:41.432608
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("OMG! It's a programming error!")
    except ProgrammingError as e:
        assert str(e) == "OMG! It's a programming error!"



# Generated at 2022-06-12 06:00:43.769365
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Testing."):
        pass
    with ProgrammingError.passert(False, "Testing."):
        pass

# Generated at 2022-06-12 06:00:46.271830
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:00:51.883760
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as err:
        ProgrammingError("This is a message")
    assert str(err.value) == "This is a message"


# Generated at 2022-06-12 06:00:55.687744
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "hello")
        assert False, "Assertion should have failed"
    except ProgrammingError as e:
        assert 'hello' == str(e)


# Generated at 2022-06-12 06:01:01.756193
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test default message
    try:
        ProgrammingError.passert(False, message="")
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    # Test provided message
    try:
        ProgrammingError.passert(False, message="My error message.")
    except ProgrammingError as e:
        assert e.args[0] == "My error message."

# Generated at 2022-06-12 06:01:08.696080
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert "Broken coherence. Check your code against domain logic to fix it." == ProgrammingError().args[0]
    assert "Broken coherence. Check your code against domain logic to fix it." == ProgrammingError(None).args[0]
    assert "My own message." == ProgrammingError("My own message.").args[0]



# Generated at 2022-06-12 06:01:11.700684
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as ex:
        assert str(ex) == "A message", "Message of exception not properly set."


# Generated at 2022-06-12 06:01:14.355692
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for the constructor of class :py:class:`ProgrammingError`."""
    exc = ProgrammingError("Unit test")
    assert exc.args == ("Unit test",)


# Generated at 2022-06-12 06:01:17.198070
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Broken condition.")
    except ProgrammingError:
        pass
    except Exception as e:
        raise AssertionError("Expected ProgrammingError but got {}".format(e))
    else:
        raise AssertionError("Expected ProgrammingError but got nothing.")

# Generated at 2022-06-12 06:01:22.257674
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Condition violated")
    except ProgrammingError as error:
        assert type(error) == ProgrammingError
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "The expected exception was not raised"

# Generated at 2022-06-12 06:01:23.640287
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("foo")
    assert error.args[0] == "foo"

# Generated at 2022-06-12 06:01:26.654246
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("Test.")
    assert err.args[0] == "Test."


# Generated at 2022-06-12 06:01:33.397018
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except Exception as e:
        assert e.__str__() == "Error message"


# Generated at 2022-06-12 06:01:35.975460
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "A message")
        assert False
    except ProgrammingError as e:
        assert str(e) == "A message"


# Generated at 2022-06-12 06:01:38.957780
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise Exception("Constructor of class ProgrammingError does not raise ProgrammingError.")


# Generated at 2022-06-12 06:01:42.453536
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given
    class ConvError(ProgrammingError):
        pass

    # When
    try:
        raise ConvError("Unit test")

    # Then
    except ConvError as e:
        assert str(e) == "Unit test"

# Generated at 2022-06-12 06:01:45.621174
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "Something bad happened"
    exc = ProgrammingError(msg)
    assert isinstance(exc, Exception)
    assert exc.__class__.__name__ == "ProgrammingError"
    assert exc.__str__() == msg


# Generated at 2022-06-12 06:01:47.367605
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass



# Generated at 2022-06-12 06:01:50.571108
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it.", "Invalid error message."


# Generated at 2022-06-12 06:01:51.648683
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("constructor")

# Generated at 2022-06-12 06:01:59.607769
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that passing an invalid condition to :py:meth:`ProgrammingError.passert <pypara.errors.ProgrammingError.passert>`
    raises a :py:class:`ProgrammingError <pypara.errors.ProgrammingError>` exception.
    """
    try:
        ProgrammingError.passert(False, "Some message")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError not raised")

# Generated at 2022-06-12 06:02:02.979452
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        assert 'Broken coherence. Check your code against domain logic to fix it.' == str(e)

# Generated at 2022-06-12 06:02:16.858786
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "An error has occured")
    except ProgrammingError as e:
        assert e.args[0] == "An error has occured"
    else:
        assert False


# Generated at 2022-06-12 06:02:19.177263
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Must raise an exception")
        raise RuntimeError("ProgrammingError.passert() didn't raise an expected exception.")
    except ProgrammingError:
        pass # Expected.

# Generated at 2022-06-12 06:02:27.604051
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "a message")
    except ProgrammingError:
        raise Exception("Unexpected exception raised.")
    try:
        ProgrammingError.passert(False, "a message")
    except ProgrammingError as ex:
        if str(ex) != "a message":
            raise Exception("Unexpected exception raised.")
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as ex:
        if str(ex) != "Broken coherence. Check your code against domain logic to fix it.":
            raise Exception("Unexpected exception raised.")

# Generated at 2022-06-12 06:02:30.069105
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Optional message")
    except ProgrammingError as exception:
        assert str(exception) == "Optional message"


# Generated at 2022-06-12 06:02:34.251096
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing a programming error.")
        raise AssertionError("There should be a programming error.")
    except ProgrammingError as e:
        assert str(e) == "Testing a programming error."
    ProgrammingError.passert(True, "Testing a programming error.")  # This should pass with no error.

# Generated at 2022-06-12 06:02:38.290116
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Test error.")
    except ProgrammingError as e:
        assert e.args == ("Test error.",)
    else:
        raise AssertionError("ProgrammingError was not raised.")

# Generated at 2022-06-12 06:02:40.911316
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Foo")
    except ProgrammingError as error:
        assert error.args == ("Foo",)


# Generated at 2022-06-12 06:02:47.990484
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from nose.tools import assert_raises

    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as pe:
        assert False, "Should not raise an error"
    except Exception as e:
        assert False, "Should not raise an error of different type"

    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError as pe:
        assert False, "Should not raise an error"
    except Exception as e:
        assert False, "Should not raise an error of different type"

    try:
        ProgrammingError.passert(True, "True")
    except ProgrammingError as pe:
        assert False, "Should not raise an error"
    except Exception as e:
        assert False, "Should not raise an error of different type"


# Generated at 2022-06-12 06:02:52.417481
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as error_snapshot:
        ProgrammingError(message=None)

    assert error_snapshot.value.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-12 06:02:55.672472
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "OK"):
        pass

    with ProgrammingError.passert(False, "Not OK"):
        assert 0

# This statement is used to check the coverage of the module
assert ProgrammingError()

# Generated at 2022-06-12 06:03:24.777985
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Tests constructor of class ProgrammingError. """
    from unittest import TestCase

    class TestProgrammingError(TestCase):
        """ Tests constructor of class ProgrammingError. """

        def test__init__(self):
            with self.assertRaises(ProgrammingError) as ctx:
                raise ProgrammingError("test programming error")

            self.assertIsInstance(ctx.exception, ProgrammingError)
            self.assertEqual("test programming error", str(ctx.exception))

    TestProgrammingError().test__init__()



# Generated at 2022-06-12 06:03:27.111785
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("An error message.")
    except ProgrammingError as pe:
        assert str(pe) == "An error message."
        pass


# Generated at 2022-06-12 06:03:28.941932
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    error = ProgrammingError("test")
    assert error.args[0] == "test"

# Generated at 2022-06-12 06:03:30.903355
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "This is a test message."
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert e.args == (message,)


# Generated at 2022-06-12 06:03:32.522388
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
        assert False
    except ProgrammingError:
        pass



# Generated at 2022-06-12 06:03:34.638397
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Test")

# Generated at 2022-06-12 06:03:45.683543
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the constructor of class :py:class:`ProgrammingError`.
    """
    # No message provided
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as ex:
        assert(ex.args[0] == "Broken coherence. Check your code against domain logic to fix it.")

    # Message provided
    try:
        ProgrammingError.passert(False, "Expected to be True")
    except ProgrammingError as ex:
        assert(ex.args[0] == "Expected to be True")

    # Condition met
    ProgrammingError.passert(True, None)


# Executing test
if __name__ == "__main__":
    test_ProgrammingError()
    print("All tests have passed successfully!")

# Generated at 2022-06-12 06:03:47.869477
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing")
    except ProgrammingError as e:
        assert(str(e) == "Testing")


# Generated at 2022-06-12 06:03:51.117823
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Raises a :py:class:`ProgrammingError` when the condition is ``False``.

    :raises ProgrammingError: In case that the condition is ``False``.
    """
    ProgrammingError.passert(True, None)
    ProgrammingError.passert(False, None)

# Generated at 2022-06-12 06:04:00.206453
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "")
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)
    if sys.version_info >= (3, 4):
        assert repr(ProgrammingError("Test", 1, 2)) == "ProgrammingError('Test', 1, 2)"
    else:
        assert repr(ProgrammingError("Test", 1, 2)) == "ProgrammingError('Test',)"
    with pytest.raises(ProgrammingError):
        raise ProgrammingError

# Generated at 2022-06-12 06:04:46.680231
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(None)

    with pytest.raises(ProgrammingError):
        ProgrammingError(1)


# Generated at 2022-06-12 06:04:50.732298
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:04:53.007847
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "exception message")
    assert excinfo.value.args == ("exception message",)

# Generated at 2022-06-12 06:05:04.033345
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # No exception is expected
    ProgrammingError.passert(True, None)
    ProgrammingError.passert(True, "")
    ProgrammingError.passert(True, "Bla")

    # Exception is expected
    passed = False
    try:
        ProgrammingError.passert(False, None)
        passed = True
    except ProgrammingError as e:
        # Expected exception
        assert e.message == "Broken coherence. Check your code against domain logic to fix it."
    assert not passed

    # Exception is expected
    passed = False
    try:
        ProgrammingError.passert(False, "")
        passed = True
    except ProgrammingError as e:
        # Expected exception
        assert e.message == "Broken coherence. Check your code against domain logic to fix it."
    assert not passed

    # Exception is expected


# Generated at 2022-06-12 06:05:06.096413
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:05:07.960826
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("message")
    except ProgrammingError as ex:
        assert ex.args[0] == "message"


# Generated at 2022-06-12 06:05:10.856188
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)

# Generated at 2022-06-12 06:05:13.602315
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("It failed")
    except Exception as e:
        assert e.args[0] == "It failed"

# Generated at 2022-06-12 06:05:17.730573
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, match="Broken coherence. Check your code against domain logic to fix it."):
        ProgrammingError.passert(False, None)
    ProgrammingError.passert(True, None)

# Generated at 2022-06-12 06:05:20.294501
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:07:03.092061
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    "Unit test for ProgrammingError"
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args is not None
        assert len(e.args) == 1
        assert isinstance(e.args[0], str)
        assert not e.args[0]


# Generated at 2022-06-12 06:07:06.046763
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.test import check_constructor_typeerror

    check_constructor_typeerror(ProgrammingError, "message", 1)

# Generated at 2022-06-12 06:07:06.729581
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_ProgrammingError_passert()



# Generated at 2022-06-12 06:07:14.607765
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Note: This will just raise a ProgrammingError because the condition is false
        ProgrammingError.passert(False, "Not a good day.")
    except ProgrammingError as e:
        # This is the expected outcome
        assert str(e) == "Not a good day."

    try:
        # Note: This will just raise a ProgrammingError because the condition is false
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        # This is the expected outcome
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    # Note: This will just raise a ProgrammingError because the condition is false
    ProgrammingError.passert(True, "Not a good day.")

# Generated at 2022-06-12 06:07:16.935243
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("broken")
    except ProgrammingError as e:
        assert str(e) == "broken"


# Generated at 2022-06-12 06:07:20.202339
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Error not raised"

    try:
        raise ProgrammingError("foo")
    except ProgrammingError:
        pass
    else:
        assert False, "Error not raised"



# Generated at 2022-06-12 06:07:22.787985
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Failed expectation")
    except ProgrammingError as e:
        assert str(e) == "Failed expectation"

# Generated at 2022-06-12 06:07:26.011218
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test constructor of class :py:class:`ProgrammingError`.
    """
    assert ProgrammingError(None)
    assert ProgrammingError("A")


# Generated at 2022-06-12 06:07:30.447335
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`'s constructor against the expected behaviour.
    """
    exception = ProgrammingError("Error message")

    assert isinstance(exception, ProgrammingError)
    assert exception.args == ("Error message",)  # Corectness of message.


# Generated at 2022-06-12 06:07:35.096253
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test case for class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "This should raise an exception")
    except ProgrammingError as error:
        assert error.args[0] == "This should raise an exception"
    else:
        assert False, "This statement should not be reached"