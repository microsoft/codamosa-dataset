

# Generated at 2022-06-12 05:59:58.095521
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` class.

    :return: ``None``
    """
    # We need something to be done, let it be the assertion of condition
    ProgrammingError.passert(True, "This assertion is always satisfied")

    # The following line should raise the error.
    ProgrammingError.passert(False, "This assertion is never satisfied")


# Generated at 2022-06-12 06:00:02.080132
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Checks constructor of class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError(message="Hello World!")
    except ProgrammingError as error:
        assert error.args[0] == "Hello World!"


# Generated at 2022-06-12 06:00:04.188316
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, message = "Test")
    except ProgrammingError:
        return
    assert False

# Generated at 2022-06-12 06:00:10.566304
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara import ProgrammingError

    # Case: without message
    with raises(ProgrammingError):
        ProgrammingError.passert(False, None)

    # Case: with message
    with raises(ProgrammingError) as ex:
        ProgrammingError.passert(False, "This is my message.")
    assert str(ex.value) == "This is my message."

# Generated at 2022-06-12 06:00:14.652286
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("a message")
    except ProgrammingError as ex:
        assert str(ex) == "a message"
        assert repr(ex) == "ProgrammingError(None, 'a message')"

# Generated at 2022-06-12 06:00:16.255506
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError:
        raise ProgrammingError("Testing exception")


# Generated at 2022-06-12 06:00:22.692597
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Verify the output of :py:func:`ProgrammingError`."""
    try:
        ProgrammingError("W8")
    except ProgrammingError:
        pass
    # Check that the error message is the one we want
    expected = "W8"
    raised_exc = ProgrammingError("W8")
    assert str(raised_exc) == expected
    try:
        ProgrammingError.passert(1 == 0, "W8")
    except ProgrammingError:
        pass
    # Check that the error message is the one we want
    expected = "W8"
    raised_exc = ProgrammingError("W8")
    assert str(raised_exc) == expected

# Generated at 2022-06-12 06:00:27.538760
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test ProgrammingError")
    except ProgrammingError as e:
        assert(e.args[0] == "Test ProgrammingError")
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert(e.args[0] != "Test ProgrammingError")

# Generated at 2022-06-12 06:00:30.015654
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Hello")
    assert error.args == ("Hello",)

# Generated at 2022-06-12 06:00:33.185415
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    cls = ProgrammingError
    error_message = "test"

    # WHEN
    error = cls(error_message)

    # THEN
    assert error.args == (error_message,)


# Generated at 2022-06-12 06:00:41.308885
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an expected error")
        assert False, "It should have raised ProgrammingError"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(True, "This is an expected error")
    except ProgrammingError:
        assert False, "It should not have raised ProgrammingError"

# Generated at 2022-06-12 06:00:44.578742
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, None):
        pass

    with ProgrammingError.passert(True, "Expected message"):
        pass

    with ProgrammingError.passert(False, None):
        pass

# Generated at 2022-06-12 06:00:46.462342
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "testing_message"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert message == str(e)

# Generated at 2022-06-12 06:00:51.252731
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    assert ProgrammingError is not None
    try:
        raise ProgrammingError("Something went wrong!")
    except ProgrammingError as exception:
        assert exception is not None
    else:
        assert False, "ProgrammingError not raised"


# Generated at 2022-06-12 06:00:53.583286
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor for :py:class:`ProgrammingError`.
    """

# Generated at 2022-06-12 06:00:55.737007
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "A programming error has been found."):
        pass

# Generated at 2022-06-12 06:00:58.702846
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Break coherence.")

    ProgrammingError.passert(True, "Do not break coherence.")

# Generated at 2022-06-12 06:00:59.490258
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert False
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-12 06:01:01.959355
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("some-message")
    except ProgrammingError as exception:
        assert exception.args[0] == "some-message"



# Generated at 2022-06-12 06:01:08.694020
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        first_exception = ProgrammingError(message='an error message')
        assert first_exception.args[0] == 'an error message'
        second_exception = ProgrammingError()
        assert second_exception.args is not None
    except:
        print('Error while testing function ProgrammingError')


# Generated at 2022-06-12 06:01:13.410253
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        from pytest import raises
    except ImportError:
        print("Warning: Cannot find module 'pytest'; skipping unit tests for this module.")
        return
    with raises(ProgrammingError):
        ProgrammingError("test message")


# Generated at 2022-06-12 06:01:24.982181
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
        raise AssertionError()
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"

    try:
        ProgrammingError.passert(False, None)
        raise AssertionError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(False, "")
        raise AssertionError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(True, "This is a test")
    except ProgrammingError as e:
        raise Ass

# Generated at 2022-06-12 06:01:35.075804
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        assert False, "Programming error should not raise an exception in case that the condition is met"

    try:
        ProgrammingError.passert(False, None)
        assert False, "Programming error should raise an exception in case that the condition is not met"
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)

    try:
        ProgrammingError.passert(False, "message")
        assert False, "Programming error should raise an exception in case that the condition is not met"
    except ProgrammingError as e:
        assert "message" == str(e)

# Generated at 2022-06-12 06:01:36.824853
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:01:38.875210
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"

# Generated at 2022-06-12 06:01:42.355409
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is a ProgrammingError")
    except Exception as err:
        import pytest
        pytest.fail("This should not fail: {} type:{}".format(err, type(err)))


# Generated at 2022-06-12 06:01:44.285154
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("This is a test")


# Generated at 2022-06-12 06:01:49.593271
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This must not be raised")
        assert False, "Should have raised exception before this line"
    except ProgrammingError as error:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:01:51.446298
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-12 06:01:54.374232
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing.")
    except ProgrammingError as err:
        assert str(err) == "Testing."


# Generated at 2022-06-12 06:02:00.023633
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError('test')
    except ProgrammingError as e:
        assert e.args[0] == 'test'

# Generated at 2022-06-12 06:02:01.180228
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("Error")


# Generated at 2022-06-12 06:02:07.949725
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError, match="coherence"):
        ProgrammingError.passert(False, None)

    with pytest.raises(ProgrammingError, match="coherence"):
        ProgrammingError.passert(False, "")

    with pytest.raises(ProgrammingError, match="broken"):
        ProgrammingError.passert(False, "broken")

    ProgrammingError.passert(True, None)
    ProgrammingError.passert(True, "")
    ProgrammingError.passert(True, "broken")


# Generated at 2022-06-12 06:02:19.434841
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Test that init correctly instantiates the exception instance
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"

    # Test that the static method passert works properly
    try:
        ProgrammingError.passert(True, "This is a test")
    except ProgrammingError:
        assert False

    try:
        ProgrammingError.passert(False, "This is a test")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Unit test

# Generated at 2022-06-12 06:02:22.531940
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as error:
        ProgramminError.passert(False, message="test")
    assert error.value.args[0] == "test"



# Generated at 2022-06-12 06:02:26.117864
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError:
        pass
    try:
        with ProgrammingError:
            assert False, "This is a failed assertion"
    except Exception as e:
        assert isinstance(e, AssertionError)

# Generated at 2022-06-12 06:02:28.067846
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as e:
        ProgrammingError(message="This error is expected for testing purposes")


# Generated at 2022-06-12 06:02:30.220329
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    :return: None
    """
    assert isinstance(ProgrammingError(), ProgrammingError)

# Generated at 2022-06-12 06:02:32.766179
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        assert False, "Programming error raised with a True assertion."



# Generated at 2022-06-12 06:02:36.100615
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        # We expected this exception to be raised
        pass
    else:
        assert False


# Generated at 2022-06-12 06:02:43.151440
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, message="You should see this message.")

# Generated at 2022-06-12 06:02:46.436335
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="test")
        assert False, "Expecting exception not raised"
    except ProgrammingError as e:
        assert e.message == "test", "Expecting [test]"


# Generated at 2022-06-12 06:02:50.866633
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, None)
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:02:53.053233
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-12 06:02:57.170900
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="This is an error.")
        raise ValueError("ProgrammingError.passert did not raise an error.")
    except ProgrammingError as e:
        msg = str(e)
        assert msg == "This is an error."


# Generated at 2022-06-12 06:03:04.115033
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from contextlib import ExitStack
    from unittest import TestCase

    class TestProgrammingError(TestCase):
        def test(self) -> None:
            with ExitStack() as stack:
                stack.enter_context(self.assertRaises(ProgrammingError))
                ProgrammingError()

    TestProgrammingError().test()


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-12 06:03:05.927550
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for constructor of class ProgrammingError
    """
    error = ProgrammingError("Error message")
    assert "Error message" in str(error)

# Generated at 2022-06-12 06:03:08.513211
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError not raised.")

# Generated at 2022-06-12 06:03:10.757565
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    a = ProgrammingError("Test")
    assert a.args[0] == "Test"
    assert a.args[1:] == ()  # noqa: E999


# Generated at 2022-06-12 06:03:13.208027
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("Test exception")
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Test exception")

# Generated at 2022-06-12 06:03:25.455624
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-12 06:03:28.235761
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the :py:class:`ProgrammingError` exception.
    """
    try:
        raise ProgrammingError("Expected error")
    except ProgrammingError as error:
        assert error.args[0] == "Expected error"

# Generated at 2022-06-12 06:03:29.708170
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test") as pe:
        pass
    assert "Test" in str(pe)


# Generated at 2022-06-12 06:03:33.063812
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    except Exception:
        assert False



# Generated at 2022-06-12 06:03:35.152619
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("foo!")
    except ProgrammingError as e:
        assert e.args[0] == "foo!"


# Generated at 2022-06-12 06:03:37.103186
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("message")
    assert e.args == ("message",)
    assert str(e) == "message"


# Generated at 2022-06-12 06:03:37.952744
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()
    pass

# Generated at 2022-06-12 06:03:45.879865
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "This is a message"
    e = ProgrammingError(msg)
    assert e.args[0] == msg

    def fun():
        msg = "This is another message"
        e = ProgrammingError(msg)
        assert e.args[0] == msg
        raise e

    try:
        fun()
        assert False, "Exception not raised"
    except ProgrammingError as e:
        assert e.args[0] == msg
    except:
        assert False, "Unexpected exception"


# Generated at 2022-06-12 06:03:49.734358
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as exception_info:
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")
    assert str(exception_info.value) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:03:52.672972
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("test")
    except Exception as ex:
        assert isinstance(ex, ProgrammingError)
        assert str(ex) == "test"


# Generated at 2022-06-12 06:04:18.335871
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except BaseException as e:
        assert isinstance(e, ProgrammingError)

    try:
        ProgrammingError.passert(False, "Test")
    except BaseException as e:
        assert isinstance(e, ProgrammingError)
        assert "Test" == str(e)

# Generated at 2022-06-12 06:04:22.402990
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "check")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:04:24.693045
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Test the :py:meth:`ProgrammingError.__init__` method.
    """
    ProgrammingError('Error message')

# Generated at 2022-06-12 06:04:28.325404
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert ex.args == ("Broken coherence. Check your code against domain logic to fix it.",) # pylint: disable=W0612


# Generated at 2022-06-12 06:04:34.665297
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # This test asserts that the constructor of ProgrammingError behaves as expected.
    try:
        # The constructor of ProgrammingError should accept both a message and no message.
        ProgrammingError("This is an error message.")
        ProgrammingError()
    except Exception as err:
        raise type(err)("Exception raised when creating an instance of ProgrammingError. Check the constructor "
                        "of ProgrammingError for more information.")
    assert True


# Generated at 2022-06-12 06:04:42.549328
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor and properties of class :py:class:`ProgrammingError`.

    This test provides also code coverage for :py:func:`ProgrammingError.passert`
    """
    # Coverage for the constructor
    pe = ProgrammingError()
    # 'cause' is always None for this case
    assert pe.__cause__ is None
    # Tests the class method passert
    ProgrammingError.passert(True, "")
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as exc:
        assert exc.args == ("Broken coherence. Check your code against domain logic to fix it.",)

# Generated at 2022-06-12 06:04:45.686622
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError) as e_info:
        ProgrammingError.passert(False, "")
    assert str(e_info.value) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:04:47.676203
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"



# Generated at 2022-06-12 06:04:57.911130
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase, TestSuite, TextTestRunner
    from pypara.common.error import ProgrammingError
    from pypara.common.error import ProgrammingError as PE

    # Test for class constructor
    class TestProgrammingError(TestCase):
        def test_constructor(self):
            # Invocation with error message
            e = PE("Error message")
            self.assertEqual(str(e), "Error message")

            # Invocation without error message
            e = PE()
            self.assertEqual(str(e), "Broken coherence. Check your code against domain logic to fix it.")

    # Test for method 'passert' of class ProgrammingError

# Generated at 2022-06-12 06:05:00.365828
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-12 06:05:51.745239
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` constructor.
    """
    error = ProgrammingError("test_ProgrammingError")
    assert isinstance(error, Exception)
    assert error.args == ("test_ProgrammingError",)


# Generated at 2022-06-12 06:06:00.573034
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    cls = ProgrammingError
    try:
        cls(None)
        assert False
    except TypeError:
        assert True
    try:
        cls("")
        assert False
    except TypeError:
        assert True
    try:
        cls("Test")
        assert False
    except TypeError:
        assert True
    try:
        cls("Test", 1)
        assert False
    except TypeError:
        assert True
    try:
        cls("Test", [])
        assert False
    except TypeError:
        assert True
    try:
        cls("Test", ())
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-12 06:06:03.657609
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    right = ProgrammingError("with message")
    assert right.args[0] == "with message"

    right = ProgrammingError()
    assert right.args[0] == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-12 06:06:07.485560
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Domain logic broken")
    except ProgrammingError as e:
        assert e.args[0] == "Domain logic broken"


# Generated at 2022-06-12 06:06:09.121799
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "This is a message"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as ex:
        assert message == str(ex)


# Generated at 2022-06-12 06:06:12.734803
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Act
        ProgrammingError.passert(False, "Should be.")
        # Assert
        assert False
    except ProgrammingError:
        # Assert
        assert True


# Generated at 2022-06-12 06:06:16.415683
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError) as ex:
        ProgrammingError()
    assert str(ex.value) == "Broken coherence. Check your code against domain logic to fix it."

# Unit tests for constructor of method passert in class ProgrammingError

# Generated at 2022-06-12 06:06:19.825168
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test :py:func:`ProgrammingError` constructor."""
    import pytest
    with pytest.raises(ProgrammingError):
        raise ProgrammingError(message="I am an error.")

# Generated at 2022-06-12 06:06:22.188688
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error.")
    except ProgrammingError as error:
        assert str(error) == "This is a programming error."


# Generated at 2022-06-12 06:06:24.303169
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:08:05.727680
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("ERROR"):
        pass

# Generated at 2022-06-12 06:08:09.663572
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test Message")
    except Exception as exc:
        TypingError.passert(str(exc) == "Test Message", "Unexpected error message. Check implementation.")


# Generated at 2022-06-12 06:08:13.147892
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("There's a problem with your code.")
    except ProgrammingError as error:
        assert str(error) == "There's a problem with your code."


# Generated at 2022-06-12 06:08:16.279492
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with expect(ProgrammingError, "Broken coherence. Check your code against domain logic to fix it."):
        ProgrammingError.passert(condition=False, message=None)

# Generated at 2022-06-12 06:08:26.202395
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from typing import Optional
    from pypara.exceptions import ProgrammingError

    with raises(ProgrammingError):
        ProgrammingError.passert(False, None)

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "")

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Programmer misses something!")

    try:
        ProgrammingError.passert(False, "Programmer misses something!")
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."

    with raises(ProgrammingError):
        ProgrammingError.passert(True, "Programmer misses something!")


# Generated at 2022-06-12 06:08:28.783782
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error test")
    except ProgrammingError as error:
        assert str(error) == "Programming error test"
        assert repr(error) == "ProgrammingError('Programming error test')"


# Generated at 2022-06-12 06:08:30.226850
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Must raise")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:08:33.540319
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "I'm not a good programmer")
    except ProgrammingError as e:
        assert str(e) == "I'm not a good programmer"
    ProgrammingError.passert(True, "I'm a good programmer")


# Generated at 2022-06-12 06:08:39.407762
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Passed False.")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Passed False."

    try:
        ProgrammingError.passert(True, "Passed True.")
        assert True
    except ProgrammingError as e:
        # noinspection PyUnreachableCode
        assert False

# Generated at 2022-06-12 06:08:43.826004
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
        raise AssertionError("No exception raised")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
