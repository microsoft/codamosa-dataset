

# Generated at 2022-06-12 05:59:54.023658
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("")
    except ProgrammingError:
        raise AssertionError("Failed to create instance of ProgrammingError")

# Generated at 2022-06-12 05:59:55.415229
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    pe = ProgrammingError()
    assert isinstance(pe, ProgrammingError)


# Generated at 2022-06-12 06:00:02.161897
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that instances of :py:class:`ProgrammingError` can be created.
    """

    # Error created with a message
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert "Error message" == e.args[0]

    # Error created without a message
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert 0 == len(e.args)


# Generated at 2022-06-12 06:00:14.150026
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the boolean assertion of the constructor.

    :raises AssertionError: In case the test fails.
    """
    try:
        ProgrammingError.passert(False, "Programming error raised.")
        assert False, "Programming error not raised."
    except ProgrammingError as error:
        assert error, "Programming error raised."
    try:
        ProgrammingError.passert(True, "Programming error not raised.")
    except ProgrammingError as error:
        assert error is None, "Programming error unexpectedly raised."
    try:
        ProgrammingError.passert(False, "")
        assert False, "Programming error not raised."
    except ProgrammingError as error:
        assert error and error.args[0] == "Broken coherence. Check your code against domain logic to fix it.", \
            "Programming error raised."


# Generated at 2022-06-12 06:00:19.191905
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test1")
    except ProgrammingError as e:
        assert e.args[0] == "test1"

    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-12 06:00:20.897824
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("The entity is not found")
    assert error.args[0] == "The entity is not found", "Message was passed to exception through constructor"

# Generated at 2022-06-12 06:00:26.165103
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise Exception("ProgrammingError constructor test failed: We expected a ProgrammingError")
    try:
        ProgrammingError("Test")
    except ProgrammingError:
        pass
    else:
        raise Exception("ProgrammingError constructor test failed: We expected a ProgrammingError")
    

# Unit test 

# Generated at 2022-06-12 06:00:28.309472
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Oh, snap!")
    except ProgrammingError as e:
        assert str(e) == "Oh, snap!"

# Generated at 2022-06-12 06:00:30.277686
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence." in e.args[0]


# Generated at 2022-06-12 06:00:32.754492
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # A simple test to guarantee that the constructor works and it may be removed at will
    try:
        ProgrammingError(message="Test")
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:00:41.641745
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from py.test import raises

    def fail(*args, **kwargs):
        raise ProgrammingError(*args, **kwargs)

    assert raises(ProgrammingError, fail)
    assert raises(ProgrammingError, fail, "My message")
    assert raises(ProgrammingError, fail, message="My message")
    assert raises(ProgrammingError, fail, message="My message", other=1)


# Generated at 2022-06-12 06:00:43.865621
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing.")
    except ProgrammingError as e:
        assert(str(e) == "Testing.")


# Generated at 2022-06-12 06:00:45.639335
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    ProgrammingError("This is a test")


# Generated at 2022-06-12 06:00:51.571226
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as err:
        assert str(err) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "The exception has not been raised."



# Generated at 2022-06-12 06:00:53.855180
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise RuntimeError("Unit test failed")


# Generated at 2022-06-12 06:00:57.320114
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This error has risen. It has been expected. Don't panic.")
    except ProgrammingError:
        pass
    else:
        raise Exception("ProgrammingError could not be raised!")
if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-12 06:00:59.414004
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Testing the constructor.")
    assert "Testing the constructor." == str(error)

# Generated at 2022-06-12 06:01:02.197419
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class :py:class:`ProgrammingError`.
    """

    with ProgrammingError:
        ProgrammingError(None)

    with ProgrammingError:
        ProgrammingError('This is a programming error.')

# Generated at 2022-06-12 06:01:06.936316
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        assert False, "Unwanted exception when the condition is true!"

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:01:09.896778
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """

    assert issubclass(ProgrammingError, Exception)


# Generated at 2022-06-12 06:01:14.740126
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Testing message")
    assert(error.args[0] == "Testing message")


# Generated at 2022-06-12 06:01:16.864972
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    try:
        ProgrammingError("Test")
    except Exception as ex:
        if not str(ex) == "Test":
            raise (ex)

# Generated at 2022-06-12 06:01:22.785773
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, match="Broken coherence. Check your code against domain logic to fix it."):
        ProgrammingError.passert(False, None)

    with pytest.raises(ProgrammingError, match="Check your code against domain logic to fix it."):
        ProgrammingError.passert(False, "Check your code against domain logic to fix it.")


# Generated at 2022-06-12 06:01:28.251739
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError()
    assert str(excinfo.value) == ""

    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError("foo")
    assert str(excinfo.value) == "foo"


# Generated at 2022-06-12 06:01:30.514049
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error")
    except ProgrammingError as e:
        assert str(e) == "Some error"

# Generated at 2022-06-12 06:01:33.218835
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("message")
    except ProgrammingError as e:
        assert e.args[0] == "message"

# Generated at 2022-06-12 06:01:35.813309
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except Exception as exc:
        assert exc.args and exc.args[0] == "This is a test"


# Generated at 2022-06-12 06:01:37.197380
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(ProgrammingError, "Test message")

# Generated at 2022-06-12 06:01:38.503268
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=unused-variable
    error = ProgrammingError("Example error")

# Generated at 2022-06-12 06:01:43.458111
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Should not raise an error")
    except ProgrammingError:
        assert False, "Condition was True, so this should not raise an error"

    try:
        ProgrammingError.passert(False, "Should raise an error")
        assert False, "This should have raised an error"
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:01:48.024721
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Incorrect number of records while processing migration")
    except ProgrammingError as e:
        pass

# Generated at 2022-06-12 06:01:51.146428
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Error has been generated for test purposes")
    except ProgrammingError as err:
        assert str(err) == "Error has been generated for test purposes"


# Generated at 2022-06-12 06:01:55.537070
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Makes sure that the constructor of :py:class:`ProgrammingError` does not fail.
    """
    error = ProgrammingError()
    assert(isinstance(error, Exception))

# Unit test to check the passert method of class ProgrammingError

# Generated at 2022-06-12 06:01:56.716724
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    raise ProgrammingError("test")


# Generated at 2022-06-12 06:01:58.416164
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError.passert(True, "")


# Generated at 2022-06-12 06:02:00.962471
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert e.args is not None

# Generated at 2022-06-12 06:02:03.419034
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyUnreachableCode
    if False:
        raise ProgrammingError()

# Generated at 2022-06-12 06:02:05.258726
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error")
    except ProgrammingError as e:
        assert str(e) == "Error"

# Generated at 2022-06-12 06:02:17.357484
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit tests of constructor of class ProgrammingError"""
    # Check that it raises a ProgrammingError
    try:
        ProgrammingError.passert(False, "My sample error message")
    except ProgrammingError as pe:
        # Check that the message is set properly
        assert pe.args[0] == "My sample error message"
    else:
        raise AssertionError("ProgrammingError.passert did not raise a ProgrammingError")
    # Check that it passes in case that the check is fulfilled
    ProgrammingError.passert(True, "Should not be raised")
    # Check that it raises a ProgrammingError in case that the check is not fulfilled (no message)

# Generated at 2022-06-12 06:02:20.466498
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        return True
    else:
        return False


# Generated at 2022-06-12 06:02:25.086051
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "error")

# Generated at 2022-06-12 06:02:27.750037
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True
    else:
        assert False, "ProgrammingError not raised"


# Generated at 2022-06-12 06:02:29.070951
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError()

# Generated at 2022-06-12 06:02:32.451829
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("This is an expected exception for testing purposes")
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:02:43.542233
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    # pylint: disable=unused-argument, protected-access

    class Tmp(ProgrammingError):
        """
        Provides a temporary class to test the constructor of :py:class:`ProgrammingError`.
        """

        def __init__(self, message: str) -> None:
            super().__init__(message)

    def create_exception(message: str) -> Tmp:
        """
        Creates a :py:class:`ProgrammingError` exception.

        :param message: Message to be provided to the exception.
        :return: Exception.
        """
        return Tmp(message)

    # Check against explicit typing
    exception: Tmp = create_exception("foo")

# Generated at 2022-06-12 06:02:46.032732
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("I am an error, hahaha")


# Generated at 2022-06-12 06:02:48.539308
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("programming error")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:02:51.114415
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("This is a test error.")


# Generated at 2022-06-12 06:02:52.956762
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "message")

# Generated at 2022-06-12 06:02:57.713712
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    with ImportInjector(ProgrammingError, "") as (ProgrammingError, _):
        with pytest.raises(ProgrammingError) as e:
            ProgrammingError.passert(False, "")

    with pytest.raises(ProgrammingError) as e:
        ProgrammingError.passert(False, "error")

    ProgrammingError.passert(True, "")

# Generated at 2022-06-12 06:03:10.355289
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.parsers.query import AqlParser
    from pypara.parsers.query import UnexpectedToken
    from pypara.parsers.query import UnexpectedEndOfStatement
    from pypara.parsers.query import AqlTokenizer

    tokenizer = AqlTokenizer()
    parser = AqlParser()
    with ProgrammingError.passert(False, message = None):
        parser = AqlParser()
        for token in tokenizer.tokenize("query="):
            parser.advance(token)

    with ProgrammingError.passert(False, message = None):
        parser = AqlParser()
        for token in tokenizer.tokenize("query={"):
            parser.advance(token)
        raise UnexpectedEndOfStatement


# Generated at 2022-06-12 06:03:10.848911
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError('test')

# Generated at 2022-06-12 06:03:12.384821
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert isinstance(e, Exception)

# Generated at 2022-06-12 06:03:14.932667
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # noinspection PyUnresolvedReferences
        ProgrammingError.passert(False, "Test")
        assert False, "Did not raise ProgrammingError"
    except ProgrammingError as ex:
        assert str(ex) == "Test", "Error message not as expected"

# Generated at 2022-06-12 06:03:16.864810
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("foobar")
    except ProgrammingError as e:
        assert str(e) == "foobar"


# Generated at 2022-06-12 06:03:19.829508
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Test error")
    except ProgrammingError:
        pass
    else:
        assert False, "Should have risen a ProgrammingError"

# Generated at 2022-06-12 06:03:23.297601
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert e is not None
        assert isinstance(e, ProgrammingError)



# Generated at 2022-06-12 06:03:26.873277
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if the constructor of :py:class:`ProgrammingError` works.
    """
    try:
        raise ProgrammingError("My error message")
    except ProgrammingError as err:
        assert err.args[0] == "My error message"


# Generated at 2022-06-12 06:03:28.652385
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(None)
    except ProgrammingError:
        assert False, 'Creating instance of ProgrammingError should not raise any exceptions'


# Generated at 2022-06-12 06:03:31.201589
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    err = ProgrammingError("Generic error")
    assert str(err) == "Generic error"

    try:
        raise ProgrammingError("Generic error")
    except ProgrammingError as err:
        assert str(err) == "Generic error"


# Generated at 2022-06-12 06:03:45.481478
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError()
    assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."
    exception = ProgrammingError("Custom message")
    assert str(exception) == "Custom message"

# Generated at 2022-06-12 06:03:47.696771
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Foo")
    except ProgrammingError as e:
        assert str(e) == "Foo"

# Generated at 2022-06-12 06:03:49.943487
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as error_info:
        raise ProgrammingError("foo")
    assert str(error_info.value) == "foo"


# Generated at 2022-06-12 06:03:53.265125
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test case for the constructor of :py:class:`ProgrammingError`.
    """
    # Type hinting
    message: Optional[str]
    exception: ProgrammingError

    message = "This is an error message."
    exception = ProgrammingError(message)
    assert isinstance(exception, ProgrammingError)
    assert str(exception) == message

# Generated at 2022-06-12 06:03:54.370567
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(None)
    except ProgrammingError as error:
        pass



# Generated at 2022-06-12 06:03:56.549751
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:03:58.781792
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:04:00.256774
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:04:04.601516
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Too easy!")
    except ProgrammingError as e:
        assert "Too easy!" == e.args[0]



# Generated at 2022-06-12 06:04:07.545412
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Assertion failed")
    except ProgrammingError as exception:
        print("test_ProgrammingError: ", exception)



# Generated at 2022-06-12 06:04:32.926424
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        with pytest.raises(ProgrammingError):
            ProgrammingError("test")
    except ProgrammingError as e:
        assert e.args == ("test",)
        assert str(e) == "test"

# Generated at 2022-06-12 06:04:35.646079
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "This is an error message"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert e.args[0] == message


# Generated at 2022-06-12 06:04:37.839997
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("error")
    except ProgrammingError as e:
        assert str(e) == "error"


# Generated at 2022-06-12 06:04:46.732392
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from random import choice

    messages = ["Something is wrong", "Oops!", "I must check my code"]
    for msg in messages:
        try:
            raise ProgrammingError(msg)
        except ProgrammingError as e:
            assert str(e) == msg

    for i in range(1000):
        try:
            raise ProgrammingError()
        except ProgrammingError as e:
            assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    msg = "Broken coherence. Check your code against domain logic to fix it."
    for i in range(1000):
        if choice([True, False]):
            try:
                ProgrammingError.passert(False, msg)
            except ProgrammingError as e:
                assert str(e) == msg

# Generated at 2022-06-12 06:04:51.928049
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except TypeError:
        pass  # Accept
    else:
        assert False, "ProgrammingError constructor does not raise a TypeError."


# Generated at 2022-06-12 06:04:54.179132
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-12 06:04:56.483504
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as pe:
        assert str(pe) == "This is a test"


# Generated at 2022-06-12 06:05:01.575289
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        msg = "Broken coherence. Check your code against domain logic to fix it."
        ProgrammingError.passert(False,msg)
    except ProgrammingError as err:
        assert err.args[0] == msg
    else:
        raise Exception("Did not raise error as it should.")

# Generated at 2022-06-12 06:05:02.562455
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="test")


# Generated at 2022-06-12 06:05:05.617649
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    msg = "An error"
    # WHEN
    exc = ProgrammingError(msg)
    # THEN
    assert exc.args == (msg,)



# Generated at 2022-06-12 06:05:58.733774
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "It doesn't work")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:06:00.621486
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("foo")
    except ProgrammingError as e:
        assert "foo" in str(e)

# Generated at 2022-06-12 06:06:02.747236
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("my message")
    except ProgrammingError as ex:
        assert ex.args == ("my message",)


# Generated at 2022-06-12 06:06:05.781374
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Due to invalid code")

# Generated at 2022-06-12 06:06:06.895637
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Test")
    assert str(error) == "Test"


# Generated at 2022-06-12 06:06:08.301818
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message.")
    except ProgrammingError as err:
        assert str(err) == "Test message.", "Wrong error message."

# Generated at 2022-06-12 06:06:12.942404
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Verifies that the constructor of the ProgrammingError class works as expected.
    """
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass

    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as e:
        assert(e.args[0] == "Some message")


# Generated at 2022-06-12 06:06:17.050102
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError` constructor.

    :return: ``None``
    """
    try:
        raise ProgrammingError(message="Message")
    except ProgrammingError as err:
        assert err.args == ("Message",)
    else:
        assert False


# Generated at 2022-06-12 06:06:20.012340
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error message")
    except ProgrammingError as e:
        assert e.args[0] == "Programming error message"


# Generated at 2022-06-12 06:06:22.347500
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def f():
        raise ProgrammingError(
            "Programming error has been thrown. There is no need to add any more tests.")
    assert raises(ProgrammingError, f)


# Generated at 2022-06-12 06:08:06.874352
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN an error message
    error_message = "The error message"

    # WHEN creating a ProgrammingError object
    exception = ProgrammingError(error_message)

    # THEN the message is set properly
    assert exception.args[0] == error_message


# Generated at 2022-06-12 06:08:08.672247
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, message=None)

# Generated at 2022-06-12 06:08:11.413686
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test the constructor of class ProgrammingError is working as expected."""
    error = ProgrammingError(message="Programming error occurred.")
    assert str(error) == "Programming error occurred."


# Generated at 2022-06-12 06:08:18.064766
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    def test_passert():
        try:
            ProgrammingError.passert(True, "Expected message")
        except ProgrammingError:
            assert False, "It should be Ok to use passert with True as condition"
        try:
            ProgrammingError.passert(False, "Expected message")
            assert False, "It should raise an error when false is the condition"
        except ProgrammingError:
            assert True

    test_passert()

# Generated at 2022-06-12 06:08:21.132330
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # This should pass
    ProgrammingError.passert(True, "My message")
    # This should fail
    ProgrammingError.passert(False, "My message")

# Generated at 2022-06-12 06:08:23.953536
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError was expected to be raised")



# Generated at 2022-06-12 06:08:27.048854
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check default message
    try:
        ProgrammingError()
        assert False, 'ProgrammingError has been raised'
    except ProgrammingError as exc:
        assert str(exc) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:08:29.546706
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is the message")
        assert False
    except Exception as e:
        assert type(e) is ProgrammingError
        assert str(e) == "This is the message"



# Generated at 2022-06-12 06:08:33.034351
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "")

    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:08:34.757421
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    from pypara.exceptions import ProgrammingError

    error = ProgrammingError()
    assert isinstance(error, Exception)
