

# Generated at 2022-06-12 05:59:52.903256
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("blah")
    except ProgrammingError as e:
        assert str(e) == "blah"


# Generated at 2022-06-12 05:59:57.017774
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert not e.args
    try:
        raise ProgrammingError("Hey, something went wrong!")
    except ProgrammingError as e:
        assert e.args == ("Hey, something went wrong!",)

# Generated at 2022-06-12 06:00:01.769459
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error")
    except ProgrammingError as error:
        assert error.args[0] and isinstance(error.args[0], str)
    else:
        raise Exception("ProgrammingError not raised")


# Generated at 2022-06-12 06:00:05.498184
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pyassert import assert_that
    try:
        with assert_that(ProgrammingError).raises(ProgrammingError):
            ProgrammingError.passert(False, "This is an error")
    finally:
        ProgrammingError.passert(True, "This is an error")

# Generated at 2022-06-12 06:00:11.955119
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="This is an error message.")
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError), "Programming error is not an instance of ProgrammingError"
        assert str(err) == "This is an error message.", "Message is not this one."
    else:
        raise Exception("No error has been thrown.")


# Generated at 2022-06-12 06:00:16.975779
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Does nothing more than constructing a :py:class:`ProgrammingError` instance.

    :raises ProgrammingError: In case that this exception can be constructed without problems.
    """


# Generated at 2022-06-12 06:00:19.508789
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an example")
    except ProgrammingError as e:
        assert str(e) == "This is an example"


# Generated at 2022-06-12 06:00:21.306039
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        pass


# Generated at 2022-06-12 06:00:23.205992
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("Something went wrong")
    assert str(err) == "Something went wrong"


# Generated at 2022-06-12 06:00:25.585643
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Raw message.")
    except ProgrammingError as e:
        assert str(e) == "Raw message."


# Generated at 2022-06-12 06:00:31.632101
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:func:`ProgrammingError` for correct behavior.
    """

    import unittest.mock

    _message = "Unit test"

    with unittest.mock.patch("pypara.error.ProgrammingError.__init__") as _constructor:
        ProgrammingError(message=_message)
        _constructor.assert_called_once_with(_message)

# Generated at 2022-06-12 06:00:32.931232
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # act-assert
    ProgrammingError.passert(True, "")



# Generated at 2022-06-12 06:00:35.207755
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-12 06:00:37.006652
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:00:43.127045
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "message")
        assert False, "ProgrammingError.passert() should have raised the error."
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(True, "message")
    except ProgrammingError:
        assert False, "ProgrammingError.passert() should not have raised the error."

# Generated at 2022-06-12 06:00:43.972316
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:00:46.422634
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    e = ProgrammingError("Hello world")

    # WHEN
    # THEN
    msg = str(e)
    assert msg == "Hello world"

# Generated at 2022-06-12 06:00:52.526056
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(condition=True, message=None):
        pass

    with ProgrammingError.passert(condition=False, message=None):
        pass

    try:
        with ProgrammingError.passert(condition=False, message="Custom message"):
            pass
        # pylint: disable=W0703
    except ProgrammingError as e:
        assert "Custom message" == e.args[0]

# Generated at 2022-06-12 06:00:58.240507
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "Reporting error")
    ProgrammingError.passert(True, "Reporting error")
    try:
        ProgrammingError.passert(False, "Reporting error")
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:01:00.457501
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError()
    assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:01:04.382748
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="Test")


# Generated at 2022-06-12 06:01:06.662748
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Base coherence of the domain logic is not met.")

# Generated at 2022-06-12 06:01:09.635500
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as err:
        assert str(err) == "Some message"


# Generated at 2022-06-12 06:01:12.745731
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Bad assertion")
        raise AssertionError("Shouldn't be here")
    except ProgrammingError as e:
        assert "Bad assertion" == str(e)

# Generated at 2022-06-12 06:01:19.312648
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        assert False, "Should not raise error"

    try:
        ProgrammingError.passert(False, None)
        assert False, "Should raise error"
    except ProgrammingError:
        assert True

    try:
        ProgrammingError.passert(False, "Testing error message")
    except ProgrammingError as e:
        assert "Testing error message" == str(e)

# Generated at 2022-06-12 06:01:21.868156
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("test")
    assert error.args == ("test",)


# Generated at 2022-06-12 06:01:25.671824
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "My test message")
    except ProgrammingError as pe:
        assert pe.args[0] == "My test message"


# Generated at 2022-06-12 06:01:27.826804
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Test")

# Generated at 2022-06-12 06:01:28.904495
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("test message")

# Generated at 2022-06-12 06:01:31.446315
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing a ProgrammingError")
        raise Exception("ProgrammingError not raised")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:01:36.778095
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, message="Expected error was not raised"):
        ProgrammingError.passert(False, "Expected error")

# Generated at 2022-06-12 06:01:40.389154
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        assert ProgrammingError.passert(
            False, "Only assert if false")
    except ProgrammingError as e:
        assert str(e) == "Only assert if false"
        return
    assert False, "ProgrammingError is not raised in function test_ProgrammingError"

# Generated at 2022-06-12 06:01:46.884841
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor for the :py:class:`ProgrammingError` class.
    """
    # Check if the constructor is initialized by the message
    try:
        raise ProgrammingError("test")
    except ProgrammingError as err:
        assert str(err) == "test"
    # Check if the constructor is initialized by the message when it is None
    try:
        raise ProgrammingError(None)
    except ProgrammingError as err:
        assert str(err) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:01:50.130308
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "Some error"


# Generated at 2022-06-12 06:01:53.505089
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error")
    except Exception as e:
        assert e.args[0] == "A programming error"
    else:
        raise Exception("Failed to raise ProgrammingError")


# Generated at 2022-06-12 06:01:56.324128
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something not right has happened")
    except ProgrammingError as ex:
        assert ex.args[0] == "Something not right has happened"


# Generated at 2022-06-12 06:01:58.074610
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test :py:class:`ProgrammingError`"""
    ProgrammingError()

# Generated at 2022-06-12 06:02:00.623021
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Failed")


# Generated at 2022-06-12 06:02:03.419632
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "My error message")
    except ProgrammingError as e:
        assert str(e) == "My error message"


# Generated at 2022-06-12 06:02:05.973996
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some test error.")
    except ProgrammingError as e:
        assert "Some test error." in str(e)


# Generated at 2022-06-12 06:02:12.804473
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Intentionally raised.")
    except ProgrammingError as err:
        assert len(err.args) == 1
        assert err.args[0] == "Intentionally raised."


# Generated at 2022-06-12 06:02:15.266120
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-12 06:02:17.878386
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, match="Broken coherence. Check your code against domain logic to fix it."):
        ProgrammingError.passert(False, None)

# Generated at 2022-06-12 06:02:27.967151
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for :py:class:`ProgrammingError`.
    """

    # Error message has not been passed.
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        assert True

    # Error message has been passed.
    try:
        ProgrammingError.passert(False, "Testing error message-")
        assert False
    except ProgrammingError as error:
        assert "Testing error message-" == error.args[0]

    # No error should be raised.
    try:
        ProgrammingError.passert(True, "Testing error message-")
        assert True
    except ProgrammingError:
        assert False


if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-12 06:02:31.237397
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        with ProgrammingError(message="Test."): pass
    except ProgrammingError as ex:
        assert ex.message == "Test."
    else:
        assert False, "No exception raised"


# Generated at 2022-06-12 06:02:34.070169
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test constructor of class ProgrammingError.

    :return: Nothing
    """
    with pytest.raises(ProgrammingError): raise ProgrammingError("Test message")


# Generated at 2022-06-12 06:02:39.323537
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the :py:class:`ProgrammingError` class.
    """
    error = ProgrammingError()
    assert not error.args
    assert error.__cause__ is None

    error = ProgrammingError("Custom error message")
    assert error.args == ("Custom error message",)
    assert error.__cause__ is None

# Generated at 2022-06-12 06:02:43.767389
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    try:
        raise ProgrammingError("Wrong operation.")
    except ProgrammingError as e:
        assert str(e) == "Wrong operation."


# Generated at 2022-06-12 06:02:45.287288
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Some message"):
        pass
    print("Test passed")

# Generated at 2022-06-12 06:02:48.883927
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as pe:
        assert str(pe) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:03:02.225568
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "This is a programming error."
    try:
        raise ProgrammingError(message)
    except ProgrammingError as error:
        assert error.args[0] == message


# Generated at 2022-06-12 06:03:07.490006
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert error.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    try:
        raise ProgrammingError("Some message about the error.")
    except ProgrammingError as error:
        assert error.args == ("Some message about the error.",)


# Generated at 2022-06-12 06:03:10.439009
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` class constructor.
    """
    try:
        raise ProgrammingError("Testing")
        assert False # pragma: nocover
    except ProgrammingError as _:
        assert True


# Generated at 2022-06-12 06:03:13.459381
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("Exception not raised")

# Unit test of method passert

# Generated at 2022-06-12 06:03:14.445908
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "boom"):
        pass

# Generated at 2022-06-12 06:03:18.669600
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    condition = False
    message = "This is the message"
    try:
        ProgrammingError.passert(condition, message)
        assert False, "Should have thrown a ProgrammingError exception"
    except ProgrammingError as ex:
        assert ex.args[0] == message, "The exception message should be the one provided in the constructor"


# Generated at 2022-06-12 06:03:24.901018
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    # noinspection PyProtectedMember
    assert ProgrammingError._get_message() == "Broken coherence. Check your code against domain logic to fix it."
    # noinspection PyProtectedMember
    assert ProgrammingError._get_message(message="Foo") == "Foo"

# Generated at 2022-06-12 06:03:29.744428
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    with ProgrammingError.passert as assert_err:
        assert_err(True, "")
        assert_err(True, None)
        assert_err(False, "")
        assert_err(False, None)

    try:
        with ProgrammingError.passert as assert_err:
            assert_err(False, "Not met")
    except ProgrammingError as e:
        assert e.args[0] == "Not met"

# Generated at 2022-06-12 06:03:30.646778
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("It is broken")

# Generated at 2022-06-12 06:03:33.738493
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("Test message")



# Generated at 2022-06-12 06:03:59.604793
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Ensures that :py:class:`ProgrammingError` class works as expected."""
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("I am an example of a message.")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:04:00.248607
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is an error")


# Generated at 2022-06-12 06:04:04.955000
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error raised while testing.")
    except Exception as error:
        assert issubclass(ProgrammingError, type(error)), "ProgrammingError must be a subclass of Exception."


# Generated at 2022-06-12 06:04:05.597082
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="Detta er ei test.")


# Generated at 2022-06-12 06:04:11.223288
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.errors import ProgrammingError

    errmsg = "Broken coherence. Check your code against domain logic to fix it."
    with raises(ProgrammingError) as e:
        ProgrammingError.passert(False, errmsg)
    assert str(e.value) == errmsg

    ProgrammingError.passert(True, errmsg)



# Generated at 2022-06-12 06:04:15.328692
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    e = ProgrammingError("foo bar")
    assert str(e) == "foo bar"


# Generated at 2022-06-12 06:04:22.957795
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError("Programming error message.")
    with raises(ProgrammingError):
        ProgrammingError()
    try:
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as exc:
        message = str(exc)
        assert "Broken coherence. Check your code against domain logic to fix it." == message, \
            "The message of the exception is not the expected one."

# Generated at 2022-06-12 06:04:25.400435
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    "Unit test for constructor of class ProgrammingError"
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:04:30.361966
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Unit tests for the constructor of class :py:class:`ProgrammingError` """
    try:
        ProgrammingError.passert(False, "Should break.")
    except ProgrammingError:
        return
    assert False, "ProgrammingError.passert(false, m) has not raised an exception"

# Generated at 2022-06-12 06:04:32.108100
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("MESSAGE"):
        raise ProgrammingError("MESSAGE")


# Generated at 2022-06-12 06:05:17.201607
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        raise ProgrammingError("This is an expected exception")
    assert "expected exception" in str(excinfo.value)


# Generated at 2022-06-12 06:05:20.507756
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError(None)
    assert "Broken coherence. Check your code against domain logic to fix it." == str(excinfo.value)


# Generated at 2022-06-12 06:05:26.261596
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # this test method is not intended to test the single method in ProgrammingError, but to test the
    # constructor, as this is not possible with the nose package
    try:
        raise ProgrammingError(None)
    except ProgrammingError as e:
        assert e.args[0] is None
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as e:
        assert e.args[0] == "Some message"

# Generated at 2022-06-12 06:05:34.216940
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # case of being a programming error
    try:
        ProgrammingError.passert(False, None)
        raise AssertionError("Exception expected")
    except ProgrammingError:
        pass

    # case of not being a programming error
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        raise AssertionError("No exception expected")

    # case of an expected exception
    try:
        ProgrammingError.passert(False, "foo")
    except ProgrammingError as e:
        assert e.args[0] == "foo"

# Generated at 2022-06-12 06:05:36.045807
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "message"):
        pass

# Generated at 2022-06-12 06:05:45.508088
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    # Case: condition is true
    try:
        ProgrammingError.passert(condition=True, message=None)
    except ProgrammingError:
        assert False, "Expected no exception to be raised."

    # Case: condition is false and no message is provided
    try:
        ProgrammingError.passert(condition=False, message=None)
        assert False, "Expected an exception to be raised."
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it.", "Wrong error message."

    # Case: condition is false and a message is provided

# Generated at 2022-06-12 06:05:47.723813
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is just a test")
    except ProgrammingError:
        pass
    else:
        assert False



# Generated at 2022-06-12 06:05:52.165362
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Failure test.")
    except ProgrammingError as error:
        assert isinstance(error, ProgrammingError)
        assert error.args[0] == "Failure test."
    else:
        raise AssertionError("An exception was expected.")

# Generated at 2022-06-12 06:05:55.953212
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test case for the constructor of class :py:class:`ProgrammingError`.

    This test case uses the assertion helper method :py:meth:`ProgrammingError.passert`.
    """
    try:
        # Works
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        assert False

    try:
        # Fails
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError:
        pass

    try:
        # Works
        ProgrammingError.passert(True, "Some message")
    except ProgrammingError:
        assert False

    try:
        # Fails
        ProgrammingError.passert(False, "Some message")
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:05:58.901506
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("An example of programming error")
    except Exception as e:
        assert e.args[0] == "An example of programming error"



# Generated at 2022-06-12 06:07:34.951186
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("Test error")

# Generated at 2022-06-12 06:07:38.242915
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as exception:
        assert True
        assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:07:40.695523
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:07:43.440602
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e


# Generated at 2022-06-12 06:07:45.615086
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    message = "some error"
    with raises(ProgrammingError, match=message):
        raise ProgrammingError(message)

# Generated at 2022-06-12 06:07:48.630516
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError

    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)



# Generated at 2022-06-12 06:07:54.543422
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    ProgrammingError.passert(3==3, "That's an easy one.")
    try:
        ProgrammingError.passert(2==3, "That's an easy one.")
    except ProgrammingError as e:
        print(e)
    try:
        ProgrammingError.passert(2==3, None)
    except ProgrammingError as e:
        print(e)

# Generated at 2022-06-12 06:07:56.238945
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError('My message.')
    assert str(e) == 'My message.'


# Generated at 2022-06-12 06:08:03.194168
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    "Unit test for constructor of class ProgrammingError."

    # Arrange ...
    try:
        # Act ...
        ProgrammingError.passert(False, None)
        # Assert ...
        assert False
    except ProgrammingError as e:
        # Assert ...
        assert isinstance(e, ProgrammingError)
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-12 06:08:07.949933
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Domain logic is broken!")
        assert False, "Should have raised ProgrammingError!"
    except ProgrammingError as e:
        assert str(e) == "Domain logic is broken!", "Unexpected error message!"
    try:
        ProgrammingError.passert(True, "Domain logic is broken!")
        assert True, "No error has been raised!"
    except ProgrammingError as e:
        assert False, "Unexpectedly raised error!"