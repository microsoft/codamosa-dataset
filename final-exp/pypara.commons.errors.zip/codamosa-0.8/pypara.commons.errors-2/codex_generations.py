

# Generated at 2022-06-12 05:59:52.467841
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()  # no exception raised

# Generated at 2022-06-12 05:59:56.139255
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("error")
    try:
        ProgrammingError.passert(False, "error")
        assert False
    except ProgrammingError as e:
        err = e
    assert err.__str__() == "error"

# Generated at 2022-06-12 06:00:02.726792
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    # Error message is given
    try:
        raise ProgrammingError("I should be totally fine.")
    except ProgrammingError:
        pass
    # Empty error message is given
    try:
        raise ProgrammingError('')
    except ProgrammingError:
        pass
    # No error message is given
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:00:08.002065
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Expectation failed")
    except Exception as ex:
        assert type(ex) is ProgrammingError

    try:
        ProgrammingError.passert(False, None)
    except Exception as ex:
        assert type(ex) is ProgrammingError
        assert "Broken coherence" in ex.__str__()

# Generated at 2022-06-12 06:00:18.504840
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    # Test with message
    try:
        raise ProgrammingError("ProgrammingError message")
    except Exception as error:
        assert isinstance(error, ProgrammingError)
        assert str(error) == "ProgrammingError message"
        assert error.args == ("ProgrammingError message",)

    # Test without message
    try:
        raise ProgrammingError()
    except Exception as error:
        assert isinstance(error, ProgrammingError)
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."
        assert error.args == ("Broken coherence. Check your code against domain logic to fix it.",)

# Generated at 2022-06-12 06:00:21.065561
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Provides the unit test for class :py:class:`ProgrammingError`."""

    with pytest.raises(ProgrammingError): ProgrammingError(message="This is the expected error.")



# Generated at 2022-06-12 06:00:22.447242
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)



# Generated at 2022-06-12 06:00:26.893090
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for ProgrammingError class.
    """
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError()

    with raises(ProgrammingError) as e:
        raise ProgrammingError("Error message.")

    assert str(e.value) == "Error message."


# Generated at 2022-06-12 06:00:29.727338
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError.passert(False, "condition is False")
    except ProgrammingError:
        pass  # OK
    else:
        raise AssertionError("ProgrammingError was expected.")

# Generated at 2022-06-12 06:00:30.983452
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    assert True



# Generated at 2022-06-12 06:00:35.410193
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    condition = True
    message = "Test message"
    ProgrammingError.passert(condition, message)

# Generated at 2022-06-12 06:00:38.534207
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("foo")
    except ProgrammingError as exception:
        assert str(exception) == "foo"


# Generated at 2022-06-12 06:00:48.151038
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-12 06:00:57.355139
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest.mock import MagicMock

    # Check if an exception is raised when the condition is not fulfilled
    with ProgrammingError.passert.assert_raises():
        ProgrammingError.passert(False, "This is an example of an error")

    # Check if an exception is not raised when the condition is fulfilled
    ProgrammingError.passert(True, "This is an example of an error")

    # Check if a TypeError is raised when the condition is a callable object
    with ProgrammingError.passert.assert_raises(TypeError):
        ProgrammingError.passert(MagicMock(), "This is an example of an error")

# Generated at 2022-06-12 06:01:03.767115
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError() did not raise an exception"

    msg = "This is my error message"
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as error:
        assert error.args[0] == msg, "ProgrammingError did not raise an exception with the given message"
    else:
        assert False, "ProgrammingError(\"{}\") did not raise an exception".format(msg)



# Generated at 2022-06-12 06:01:04.675395
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-12 06:01:07.637078
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        msg = "Something went wrong because my function was wrong"
        ProgrammingError(msg)
    except ProgrammingError as p:
        assert str(p) == msg


# Generated at 2022-06-12 06:01:09.017759
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message = "test")

# Generated at 2022-06-12 06:01:13.328436
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError("Message here.")
    except ProgrammingError as e:
        assert str(e) == "Message here."

# Generated at 2022-06-12 06:01:17.061876
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is an error")
    except ProgrammingError as error:
        assert error.args[0] == "This is an error"
        assert isinstance(error, Exception)

# Generated at 2022-06-12 06:01:23.442574
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        return
    else:
        raise AssertionError("Expected to fail!")


# Generated at 2022-06-12 06:01:25.725216
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError()
    assert type(e) == ProgrammingError


# Generated at 2022-06-12 06:01:26.603194
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ...

# Generated at 2022-06-12 06:01:29.501148
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My message")
    except ProgrammingError as pe:
        assert "my message" in str(pe).lower()


# Generated at 2022-06-12 06:01:32.479865
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError does not work properly"



# Generated at 2022-06-12 06:01:34.089345
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    ProgrammingError(message="Test ProgrammingError")



# Generated at 2022-06-12 06:01:37.837162
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Should not invoke this function")
        assert False, "Exception should have been raised"
    except ProgrammingError as e:
        assert str(e) == "Should not invoke this function"

# Generated at 2022-06-12 06:01:40.341204
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("lalala")
    except ProgrammingError as e:
        assert e.args[0] == "lalala"


# Generated at 2022-06-12 06:01:43.282145
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "message"):
        pass
    # Should not raise an error
    with ProgrammingError.passert(False, "message"):
        pass

# Generated at 2022-06-12 06:01:52.271441
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.exception import ProgrammingError
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert str(err) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError("Custom message")
    except ProgrammingError as err:
        assert str(err) == "Custom message"
    with raises(ProgrammingError):
        ProgrammingError.passert(False, None)
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Custom message")

# Generated at 2022-06-12 06:02:00.854717
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as pytest_wrapped_e:
        ProgrammingError.passert(False, "Something is wrong.")

    assert pytest_wrapped_e.type == ProgrammingError
    assert pytest_wrapped_e.value.args[0] == "Something is wrong."


# Generated at 2022-06-12 06:02:03.763076
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:02:05.648939
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error!")
    except ProgrammingError as e:
        assert e.args[0] == "Error!"


# Generated at 2022-06-12 06:02:10.042096
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert ex.args == ("Broken coherence. Check your code against domain logic to fix it.",)
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:02:12.279170
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except:
        pass



# Generated at 2022-06-12 06:02:16.944804
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    try:
        raise ProgrammingError("foo")
    except ProgrammingError as error:
        assert str(error) == "foo"

    with pytest.raises(type(ProgrammingError.passert.__func__), match="Broken coherence"):
        ProgrammingError.passert(False, None)

# Generated at 2022-06-12 06:02:23.120143
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert True, "Failure in ProgrammingError.passert(False,None)."
    except:
        assert False, "Failure in ProgrammingError.passert(False,None)."


if __name__ == '__main__':
    print("Invoking direct module execution.")
    test_ProgrammingError()
    print("Done.")

# Generated at 2022-06-12 06:02:28.638494
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): # type: ignore
    """
    Unit test for :py:class:`ProgrammingError`.
    """

    try:
        raise ProgrammingError("A message.")
    except ProgrammingError as e:
        assert e.args[0] == "A message."
        assert repr(e) == "ProgrammingError('A message.',)"
    else:
        raise AssertionError("Expected failure in unit test.")


# Generated at 2022-06-12 06:02:32.766921
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class MyProgrammingError(ProgrammingError):
        pass

    try:
        raise MyProgrammingError("Testing constructor of ProgrammingError")
    except ProgrammingError as e:
        assert str(e) == "Testing constructor of ProgrammingError"

# Unit tests for method of class ProgrammingError

# Generated at 2022-06-12 06:02:36.100144
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Test")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:02:42.913357
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert error is not None


# Generated at 2022-06-12 06:02:45.078488
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:02:50.276266
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(
            False,
            "This error is expected. Programmer has introduced a statement which breaks the coherence of the domain "
            "logic.")
    except ProgrammingError:
        pass



# Generated at 2022-06-12 06:02:51.676694
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test").passert(False, "Test programming error")


# Generated at 2022-06-12 06:02:53.885564
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except Exception as ex:
        assert str(ex) == "test"


# Generated at 2022-06-12 06:02:59.093866
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    expected = "Test message"

    # WHEN
    exception = ProgrammingError(expected)

    # THEN
    assert isinstance(exception, Exception)
    assert str(exception) == expected


# Generated at 2022-06-12 06:03:02.943391
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def raise_it(): raise ProgrammingError("Some message")
    try:
        raise_it()
        assert False
    except ProgrammingError as e:
        assert str(e) == "Some message"


# Generated at 2022-06-12 06:03:06.770488
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(condition=True, message="Message")
    try:
        ProgrammingError.passert(condition=False, message="Message")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Message"
    ProgrammingError.passert(condition=False, message=None)

# Generated at 2022-06-12 06:03:08.514782
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-12 06:03:11.259413
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError().args == ("Broken coherence. Check your code against domain logic to fix it.",)
    assert ProgrammingError(message="Test message").args == ("Test message",)


# Generated at 2022-06-12 06:03:24.753489
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the constructor of :py:class:`ProgrammingError` works as expected.
    """
    try:
        raise ProgrammingError("testing")
    except ProgrammingError as e:
        assert "testing" == str(e)


# Generated at 2022-06-12 06:03:26.792691
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-12 06:03:33.803782
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test that no exception is raised when condition is True and message is None
    ProgrammingError.passert(True, None)
    # Test that no exception is raised when condition is True and message is not None
    ProgrammingError.passert(True, "foo")
    # Test that exception is raised when condition is False and message is None
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    # Test that exception is raised when condition is False and message is not None
    try:
        ProgrammingError.passert(False, "foo")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:03:35.268814
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("error")


# Generated at 2022-06-12 06:03:39.838299
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test success condition
    ProgrammingError.passert(1 == 1, None)

    # Test failure condition and check the message
    try:
        ProgrammingError.passert(1 == 2, "This is an error message")
    except ProgrammingError as e:
        assert str(e) == "This is an error message"

# Generated at 2022-06-12 06:03:41.925042
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert str(e) == "Error message"


# Generated at 2022-06-12 06:03:45.232694
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Unit test.")
    except ProgrammingError as e:
        assert e.args[0] == "Unit test."


# Generated at 2022-06-12 06:03:52.392344
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Programming error")
        assert False, "We should not go there"
    except ProgrammingError as e:
        assert str(e) == "Programming error", "We should pass the message"
    try:
        ProgrammingError.passert(False, None)
        assert False, "We should not go there"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it.", "We should pass a default message"

# Generated at 2022-06-12 06:03:56.214254
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    err = ProgrammingError("Failed to passert it")

    # Assert
    assert err.args[0] == "Failed to passert it"

# Generated at 2022-06-12 06:04:01.221395
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert (type(e) is ProgrammingError)

    try:
        ProgrammingError("A message")
    except Exception as e:
        assert (type(e) is ProgrammingError)
        assert (str(e) == "A message")

# Unit tests for method passert of class ProgrammingError

# Generated at 2022-06-12 06:04:28.237311
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Error message")
        assert False, "ProgrammingError.passert() should've raised"
    except ProgrammingError as e:
        assert type(e) == ProgrammingError
        assert str(e) == "Error message"


# Generated at 2022-06-12 06:04:32.832076
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Testing the constructor of class ``ProgrammingError``.

    :raises AssertionError: In case that the constructor of class ``ProgrammingError`` fails.
    """
    assert str(ProgrammingError()) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:04:41.466687
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "The test has failed")
    except ProgrammingError as e:
        assert str(e) == "The test has failed"
    else:
        assert False, "No exception thrown"
    ProgrammingError.passert(True, "The test has failed")
    ProgrammingError.passert(True, None)
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "No exception thrown"

# Generated at 2022-06-12 06:04:47.602872
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test case is not implemented yet.")
    except ProgrammingError as e:
        if str(e) != "Test case is not implemented yet.":
            raise AssertionError("Expected string representation of error message to be equal to string with text '"
                                 "'Test case is not implemented yet.'. Although, found '{0}'".format(str(e)))
        if e.__cause__ is not None:
            raise AssertionError("Expected to not have associated exception to cause. Although, found {0!r}".format(e.__cause__))


# Generated at 2022-06-12 06:04:50.697063
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)

# Generated at 2022-06-12 06:04:52.020940
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except ProgrammingError as e:
        pass

# Generated at 2022-06-12 06:04:54.589419
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given
    error = ProgrammingError("Domain logic does not support this.")

    # When & Then
    assert str(error) == "Domain logic does not support this."


# Generated at 2022-06-12 06:04:57.769539
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "my message"

    try:
        raise ProgrammingError(msg)
    except ProgrammingError as ex:
        assert ex.args[0] == msg, "Programming error did not receive message"


# Generated at 2022-06-12 06:05:01.042124
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is a programming error")
    except Exception as exception:
        assert type(exception) == ProgrammingError
        assert "This is a programming error" in str(exception)



# Generated at 2022-06-12 06:05:03.096784
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:05:58.332391
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def check_init(exception: Exception, message: str) -> None:
        assert isinstance(exception, ProgrammingError)
        assert exception.args == (message,)

    check_init(ProgrammingError("message"), "message")
    check_init(ProgrammingError(), "Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-12 06:05:59.918415
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:06:01.696555
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test message")
    except ProgrammingError as e:
        assert e.args[0] == "Test message"


# Generated at 2022-06-12 06:06:05.345803
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Failed to raise exception ProgrammingError()"


# Generated at 2022-06-12 06:06:08.829891
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` exception.
    """
    try:
        raise ProgrammingError("Test")
    except Exception:
        return
    assert False, "Unable to raise `ProgrammingError` exception"

# Generated at 2022-06-12 06:06:13.837930
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("My Exception")
    except ProgrammingError as e:
        assert e.args == ("My Exception",)
    else:
        raise AssertionError("Expected the exception to be raised.")


# Generated at 2022-06-12 06:06:19.206784
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test with message
    try:
        ProgrammingError.passert(False, "message")
    except ProgrammingError as e:
        assert e.args[0] == "message"
    # Test without message
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:06:21.132472
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Some error message")

# Generated at 2022-06-12 06:06:22.969409
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as pe:
        assert str(pe) == "Message"


# Generated at 2022-06-12 06:06:25.018626
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the :py:class:`ProgrammingError` class.
    """

    ProgrammingError("The error message")
    ProgrammingError()

# Generated at 2022-06-12 06:08:14.899108
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Some message"):
        pass

# Generated at 2022-06-12 06:08:17.002542
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "" == str(e)


# Generated at 2022-06-12 06:08:22.188584
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test constructor of :py:class:`ProgrammingError`.
    """
    message = "This is an expected error message"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as error:
        assert isinstance(error, ProgrammingError)
        assert isinstance(error, Exception)
        assert error.args == (message, )


# Generated at 2022-06-12 06:08:27.302520
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    else:
        raise AssertionError("ProgrammingError didn't raise")
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        raise AssertionError("ProgrammingError raised in the correct case")

# Generated at 2022-06-12 06:08:29.535309
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Unit test")
        assert False, "No ProgrammingError"
    except ProgrammingError as e:
        assert str(e) == "Unit test"

# Generated at 2022-06-12 06:08:33.956183
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from nose.tools import assert_raises
    assert_raises(ProgrammingError, ProgrammingError.passert, False, "Message")
    with ProgrammingError.passert(False, "Message"):
        # The following line is never called.
        assert False
    with ProgrammingError.passert(True, "Message"):
        # The following line is called.
        assert True



# Generated at 2022-06-12 06:08:36.682426
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="test_ProgrammingError")
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:08:38.926757
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True


# Unit test method ProgrammingError.passert

# Generated at 2022-06-12 06:08:41.462921
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)


# Generated at 2022-06-12 06:08:47.891910
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check if a default message is raised when no description is given
    try:
        ProgrammingError.passert(condition=False, message=None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    # Check if a custom message is raised when a description is given
    try:
        ProgrammingError.passert(condition=False, message="Test")
    except ProgrammingError as e:
        assert str(e) == "Test"