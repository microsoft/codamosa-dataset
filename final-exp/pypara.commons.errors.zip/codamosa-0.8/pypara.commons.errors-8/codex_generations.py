

# Generated at 2022-06-12 05:59:56.338535
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    # Test condition
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Test message for ProgrammingError")

    # Test no condition
    with raises(ProgrammingError):
        ProgrammingError.passert(False, None)


# Generated at 2022-06-12 06:00:01.538910
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "The test should fail."
    try:
        raise ProgrammingError(message)
    except ProgrammingError:
        pass
    except Exception:
        raise AssertionError("ProgrammingError is not working properly")
    else:
        raise AssertionError("ProgrammingError is not working properly")


# Generated at 2022-06-12 06:00:05.254791
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class E(ProgrammingError):
        def __init__(self):
            super().__init__("test")

    e = E()
    assert str(e) == "test"
    assert repr(e) == """<ProgrammingError: test>"""


# Generated at 2022-06-12 06:00:12.593457
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # The following statement must not raise any exception
    ProgrammingError.passert(True, message="Shouldn't raise any exception")

    # The following statement must raise a ProgrammingError exception
    try:
        ProgrammingError.passert(False, message="Should raise a ProgrammingError")
    except ProgrammingError as e:
        assert "Should raise a ProgrammingError" == str(e), \
            "ProgrammingError's message must be that passed to the constructor"

# Generated at 2022-06-12 06:00:13.861469
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("message")
    except ProgrammingError as e:
        assert e.args == ("message", )


# Generated at 2022-06-12 06:00:18.504848
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("unit test")
    except ProgrammingError as err:
        # Check for error message
        assert(err.args[0] == "unit test")
    except Exception:
        # If not ProgrammingError, exception should not been raised
        assert(False)



# Generated at 2022-06-12 06:00:22.248929
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test!")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert e.args == ('This is a test!',)
    else:
        assert False


# Generated at 2022-06-12 06:00:31.096819
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "My custom message")
        assert False, "PyPara ProgrammingError not raised as expected."
    except ProgrammingError as e:
        assert "My custom message" == str(e), "Unexpected message for PyPara ProgrammingError."
    try:
        ProgrammingError.passert(False, None)
        assert False, "PyPara ProgrammingError not raised as expected."
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e), \
            "Unexpected message for PyPara ProgrammingError."

# Generated at 2022-06-12 06:00:31.605012
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    Programm

# Generated at 2022-06-12 06:00:35.923627
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("message")

    with pytest.raises(ProgrammingError):
        raise ProgrammingError()

    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, message="Expected condition.")

    ProgrammingError.passert(True, message="Condition is met.")

# Generated at 2022-06-12 06:00:40.526953
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-12 06:00:43.720452
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Some custom message")
        assert False, "ProgrammingError(""Some custom message"") must raise an error."
    except ProgrammingError:
        assert True


# Generated at 2022-06-12 06:00:46.177785
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Test case for ProgrammingError"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert str(e) == message


# Generated at 2022-06-12 06:00:47.593169
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is an error with message")
    assert str(error) == "This is an error with message"

# Generated at 2022-06-12 06:00:49.389162
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-12 06:00:52.474464
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-12 06:00:57.066361
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a dummy error to check the presence of the constructor of class ProgrammingError")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "This is a dummy error to check the presence of the constructor of class ProgrammingError"

# Generated at 2022-06-12 06:01:01.838083
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ('Broken coherence. Check your code against domain logic to fix it.', )
    try:
        raise ProgrammingError(message="something went wrong")
    except ProgrammingError as e:
        assert e.args == ('something went wrong', )


# Generated at 2022-06-12 06:01:05.163521
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:01:06.664718
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "foo")

# Generated at 2022-06-12 06:01:09.687966
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-12 06:01:13.452829
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Unit test for ProgrammingError")
        assert False  # This should never happen
    except ProgrammingError as e:
        assert isinstance(e, Exception)
        assert str(e) == "Unit test for ProgrammingError"

# Generated at 2022-06-12 06:01:17.193335
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test.")
    except ProgrammingError as error:
        if error.args[0] != "Test.":
            raise AssertionError("Wrong error message.")
        pass


# Generated at 2022-06-12 06:01:19.858666
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("An error occurred")
    except ProgrammingError as e:
        assert str(e) == "An error occurred"



# Generated at 2022-06-12 06:01:23.055799
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Foo!")
    except ProgrammingError as e:
        assert str(e) == "Foo!"


# Generated at 2022-06-12 06:01:26.817847
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert "This is a test" == str(e)

# Generated at 2022-06-12 06:01:28.308293
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "message-mock"):
        pass

# Generated at 2022-06-12 06:01:29.638031
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"


# Generated at 2022-06-12 06:01:31.542090
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        return
    raise Exception("The exception ProgrammingError has not been raised")


# Generated at 2022-06-12 06:01:37.389653
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Creating a ProgrammingError exception with no message
        raise ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    try:
        # Creating a ProgrammingError exception with a message
        raise ProgrammingError("Programming error has been raised.")
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert e.args[0] == "Programming error has been raised."


# Generated at 2022-06-12 06:01:41.807514
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        assert False
    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:01:45.135901
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
        assert False, "Expected exception"
    except Exception as e:
        assert type(e) == ProgrammingError, "Invalid exception: " + str(e)


# Generated at 2022-06-12 06:01:47.638966
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="test")
    except ProgrammingError:
        assert True
    else:
        assert False

# Generated at 2022-06-12 06:01:50.031064
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False



# Generated at 2022-06-12 06:01:51.099722
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message='ValueError')


# Generated at 2022-06-12 06:01:56.324502
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    message: str = "Message"

    # Act
    e = ProgrammingError(message)

    # Assert
    assert e.__class__ == ProgrammingError
    assert str(e) == message
    assert e.__cause__ is None
    assert e.__context__ is None


# Generated at 2022-06-12 06:01:59.906237
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Expected programming error to be raised"


# Generated at 2022-06-12 06:02:04.849424
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, match="Broken coherence"):
        ProgrammingError.passert(False, "Broken coherence")

    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        pytest.fail("ProgrammingError should not be raised if condition is True")



# Generated at 2022-06-12 06:02:07.306721
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    message = "message"

    # Act
    error = ProgrammingError(message)

    # Assert
    assert error.message == message


# Generated at 2022-06-12 06:02:12.758931
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` basic constructor.
    """
    err = ProgrammingError("We need a cup of coffee")
    assert str(err) == "We need a cup of coffee", "ProgrammingError: Basic constructor"


# Generated at 2022-06-12 06:02:17.959107
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "TEST: ProgrammingError")
    except ProgrammingError as e:
        assert str(e) == "TEST: ProgrammingError"

# Generated at 2022-06-12 06:02:23.790625
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check that the constructor works as expected
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    # Check that the constructor with message works as expected
    try:
        raise ProgrammingError("My particular message")
    except ProgrammingError as e:
        assert str(e) == "My particular message"

# Generated at 2022-06-12 06:02:27.561801
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "error")
        raise Exception("The exception has not been raised.")
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:02:30.811256
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.

    :return: ``None``.
    """
    with ProgrammingError("This is a programming error"):
        pass


# Generated at 2022-06-12 06:02:38.339861
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Verifies that :py:class:`ProgrammingError` raises a error with default message when created without parameters,
    and with the expected message when created with a custom message.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    try:
        raise ProgrammingError("Something is wrong")
    except ProgrammingError as e:
        assert str(e) == "Something is wrong"


# Generated at 2022-06-12 06:02:43.654899
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # if condition is True, no exceptions are raised
    ProgrammingError.passert(True, "")
    # if condition is False, a ProgrammingError is raised
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError.passert(False, \"\") should have raised a ProgrammingError.")

# Generated at 2022-06-12 06:02:46.032643
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest


    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Just for testing purposes")

# Generated at 2022-06-12 06:02:53.248901
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError:
        pass
    except Exception:
        assert False
    try:
        ProgrammingError.passert(False, "test")
    except ProgrammingError:
        pass
    except Exception:
        assert False
    try:
        ProgrammingError.passert(True, "test")
    except ProgrammingError:
        assert False
    except Exception:
        assert False

# Generated at 2022-06-12 06:02:57.068907
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Foo"):
        assert False
    try:
        with ProgrammingError("Foo"):
            assert False
    except Exception as e:
        assert isinstance(e, ProgrammingError)



# Generated at 2022-06-12 06:02:59.886188
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is a programming error!")
        assert True
    except ProgrammingError:
        assert False


# Generated at 2022-06-12 06:03:07.968408
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Expected message.")
    except ProgrammingError as e:
        pass
    assert e.args[0] == "Expected message."

# Unit tests for function passert of class ProgrammingError

# Generated at 2022-06-12 06:03:09.918059
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-12 06:03:13.686204
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the constructor of :py:class:`ProgrammingError`.
    """
    assert "Broken coherence" in str(ProgrammingError("Broken coherence"))
    assert repr(ProgrammingError("Broken coherence")) == "ProgrammingError('Broken coherence',)"


# Generated at 2022-06-12 06:03:15.079544
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    e = ProgrammingError('Error')
    assert e.args[0] == 'Error'

# Generated at 2022-06-12 06:03:16.925107
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-12 06:03:19.109264
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test the constructor
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:03:22.841461
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")
    except ProgrammingError as error:
        assert error.args[0] == "Test message"


# Generated at 2022-06-12 06:03:24.463825
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "A programming error")

# Generated at 2022-06-12 06:03:26.833044
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "Test message"
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as e:
        assert str(e) == msg


# Generated at 2022-06-12 06:03:28.613042
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, None):
        pass

    with ProgrammingError.passert(False, "Message"):
        pass

# Generated at 2022-06-12 06:03:40.924493
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("Programming error description.")
    assert err.args == ("Programming error description.",)


# Generated at 2022-06-12 06:03:42.311871
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test"):
        raise ProgrammingError("Test")

# Generated at 2022-06-12 06:03:45.232561
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "It's broken")
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:03:48.901203
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # noinspection PyTypeChecker
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
        return
    assert False

# Generated at 2022-06-12 06:03:51.629948
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Some problem!")
        assert False, "ProgrammingError did not raise exception"
    except ProgrammingError:
        assert True, "ProgrammingError raised exception"



# Generated at 2022-06-12 06:03:53.375293
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass



# Generated at 2022-06-12 06:03:56.068852
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("Test")
    assert str(e) == "Test"



# Generated at 2022-06-12 06:03:59.552961
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error")
    except ProgrammingError as e:
        assert isinstance(e, Exception)
        assert str(e) == "This is a programming error"


# Generated at 2022-06-12 06:04:01.119017
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of class :py:class:`ProgrammingError`.
    """
    ProgrammingError("Something is not right here!")

# Generated at 2022-06-12 06:04:06.335450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError("Foobar")

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Foobar")


# Generated at 2022-06-12 06:04:30.713413
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Any")


# Generated at 2022-06-12 06:04:32.062343
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("error")
    assert error.args[0] == "error"

# Generated at 2022-06-12 06:04:36.812104
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError()

    with raises(ProgrammingError):
        ProgrammingError("Foo.")

    with raises(ProgrammingError):
        ProgrammingError.passert(False, None)

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Bar.")


# Generated at 2022-06-12 06:04:40.966183
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest.mock import Mock

    def side_effect(cls):
        assert cls is ProgrammingError

    mock = Mock()
    mock.side_effect = side_effect
    ProgrammingError.__new__ = staticmethod(mock)
    ProgrammingError("test")
    assert mock.call_count == 1

# Generated at 2022-06-12 06:04:41.847661
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(condition=True, message="")

# Generated at 2022-06-12 06:04:44.106736
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    try:
        ProgrammingError("Programming error")
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:04:47.228119
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test invalid case
    try:
        raise ProgrammingError("error")
    except ProgrammingError as e:
        assert str(e) == "error"

    # Test valid case (no exception raised)
    ProgrammingError.passert(True, "")

# Generated at 2022-06-12 06:04:51.058859
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("You done goofed"):
        raise ProgrammingError("You done goofed")

# Generated at 2022-06-12 06:04:52.541071
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Testing"):
        raise ProgrammingError("Yo!")

# Generated at 2022-06-12 06:04:54.834321
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_message = "Test message"
    error = ProgrammingError(test_message)
    assert str(error) == test_message


# Generated at 2022-06-12 06:05:46.234121
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:05:51.033150
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "message")
    except ProgrammingError as e:
        assert "Broken coherence" in e.__str__()
        assert "message" in e.__str__()
        return
    finally:
        assert False, "Missing expected exception"


# Generated at 2022-06-12 06:05:55.073408
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, match=r".*Broken coherence.*"):
        ProgrammingError.passert(False, "Broken coherence.")
    ProgrammingError.passert(True, "")
    ProgrammingError.passert(True, None)

# Generated at 2022-06-12 06:05:57.781537
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message text")
    except ProgrammingError as error:
        assert str(error) == "Error message text"

# Generated at 2022-06-12 06:06:01.843339
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=protected-access
    from pypara.exceptions.testing import TestingError

    err = ProgrammingError("This is an error")
    assert isinstance(err, ProgrammingError)
    assert not isinstance(err, TestingError)
    assert err._msg == "This is an error"

# Generated at 2022-06-12 06:06:03.658069
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-12 06:06:08.584186
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.utils import assert_exception
    message = "test"
    assert_exception(ProgrammingError, lambda: ProgrammingError.passert(False, message))
    assert_exception(ProgrammingError, lambda: ProgrammingError.passert(False, None))

# Generated at 2022-06-12 06:06:15.379542
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("This is a plain error.")
    assert isinstance(err, ProgrammingError)
    assert err.__str__() == "This is a plain error."

    try:
        ProgrammingError.passert(False, "Error message")
        assert False, "Expected an exception to be raised"
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(True, "Error message")
        assert True
    except ProgrammingError:
        assert False, "Expected no exception to be raised"

# Generated at 2022-06-12 06:06:18.016618
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:06:20.917284
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        raise ProgrammingError()
    assert 'Broken coherence' in str(excinfo.value)

# Generated at 2022-06-12 06:08:06.608991
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is a test with a message")
    except ProgrammingError as e:
        assert (str(e) == "This is a test with a message")


# Generated at 2022-06-12 06:08:11.085579
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test to confirm that the constructor of class :py:class:`ProgrammingError` behaves as expected.
    """
    error_message = "Integer value equals to zero is not allowed."
    try:
        ProgrammingError.passert(False, error_message)
    except ProgrammingError:
        assert True
    else:
        assert False

# Generated at 2022-06-12 06:08:19.039693
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        assert False, "Never raise in this case."

    try:
        ProgrammingError.passert(False, "message")
    except ProgrammingError as e:
        assert e.args == ("message",), "Unexpected error message."

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",), "Unexpected error message."

# Generated at 2022-06-12 06:08:23.235216
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("ProgrammingError constructor has not raised a programming error.")


# Generated at 2022-06-12 06:08:26.573664
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("So long and thanks!")
    except ProgrammingError as pe:
        assert pe.args[0] == 'So long and thanks!'
    else:  # pragma: no cover
        raise RuntimeError("exception not raised")


# Generated at 2022-06-12 06:08:28.852621
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as error:
        assert error.args[0] == "Message"


# Unit tests for static method passert of class ProgrammingError

# Generated at 2022-06-12 06:08:30.276811
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()

# Generated at 2022-06-12 06:08:31.215251
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("message")


# Generated at 2022-06-12 06:08:33.397544
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass  # All is OK
    else:
        raise Exception("Unit test for constructor of class ProgrammingError has failed")


# Generated at 2022-06-12 06:08:37.187342
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, None)
    exc_raised = False
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        exc_raised = True
    assert exc_raised