

# Generated at 2022-06-12 05:59:54.945094
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class MyError(ProgrammingError):
        pass
    with pytest.raises(MyError) as error:
        raise MyError("Error")
    assert str(error.value) == "Error"


# Generated at 2022-06-12 05:59:59.242525
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError) as err:
        ProgrammingError.passert(False, "This is the message")
    assert "This is the message" in str(err)


# Generated at 2022-06-12 06:00:05.920813
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test 1: happy path
    try:
        ProgrammingError.passert(True, "message")
    except ProgrammingError:
        assert False, "Test 1 failed: Expect no exception to be raised"

    # Test 2: ensured failure
    try:
        ProgrammingError.passert(False, "message")
        assert False, "Test 2 failed: Expect exception to be raised"
    except ProgrammingError:
        pass

    # Test 3: ensured failure
    try:
        ProgrammingError.passert(False, None)
        assert False, "Test 3 failed: Expect exception to be raised"
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:00:09.228272
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    ProgrammingError("Some error message")


# Generated at 2022-06-12 06:00:13.221051
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    raise Exception("ProgrammingError not raised!")


# Generated at 2022-06-12 06:00:17.579113
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Should not be raised")
    except ProgrammingError as err:
        assert str(err) == "Should not be raised"


# Generated at 2022-06-12 06:00:20.618547
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Act
    try:
        ProgrammingError(message=None)

    # Assert
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:00:22.051125
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:00:30.940062
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest.mock import sentinel
    try:
        ProgrammingError("foo")
        raise RuntimeError("ProgrammingError.__init__() failed to raise an exception")
    except ProgrammingError as e:
        assert e.args == ("foo", )
    try:
        ProgrammingError()
        raise RuntimeError("ProgrammingError.__init__() failed to raise an exception")
    except ProgrammingError as e:
        assert e.args == ()
    try:
        ProgrammingError.passert(False, sentinel.msg)
    except ProgrammingError as e:
        assert e.args == (sentinel.msg, )
    ProgrammingError.passert(True, sentinel.msg)


# Generated at 2022-06-12 06:00:33.613494
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "")
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        return
    raise AssertionError("ProgrammingError was not raised")

# Generated at 2022-06-12 06:00:42.975669
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Test the constructor of ProgrammingError
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()

    with pytest.raises(ProgrammingError):
        raise ProgrammingError("This is a test")

    # Test the passert method
    try:
        ProgrammingError.passert(True, "Message with a condition True")
    except ProgrammingError:
        pytest.fail("ProgrammingError thrown when it was not expected")

    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Message with a condition False")

# Generated at 2022-06-12 06:00:44.638327
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "foo")
        raise Exception("Should have raised an exception")
    except ProgrammingError:
        pass
    ProgrammingError.passert(True, "foo")

# Generated at 2022-06-12 06:00:47.700952
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is always wrong.")
        raise AssertionError("The condition should be False and rise an error.")
    except ProgrammingError as e:
        assert 'This is always wrong.' == str(e), "Wrong message."


# Generated at 2022-06-12 06:00:51.151025
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Error message")
    except ProgrammingError as e:
        assert str(e) == "Error message"
    else:
        raise RuntimeError("No error raised")

# Generated at 2022-06-12 06:00:58.550273
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        with ProgrammingError.passert(True, "Error message"):
            raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert e.args[0] == "Error message"
    try:
        with ProgrammingError.passert(False, "Error message"):
            raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:01:02.157633
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Raises an exception to show that the constructor works as expected.
    """
    try:
        ProgrammingError(message='This should not be raised')
    except ProgrammingError:
        pass
    else:
        raise RuntimeError('Cannot raise an exception')


# Generated at 2022-06-12 06:01:05.968754
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "message")
    except ProgrammingError as err:
        assert str(err) == "message"


# Generated at 2022-06-12 06:01:08.429081
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True


# Generated at 2022-06-12 06:01:11.833236
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test the constructor of class ProgrammingError
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Test")
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:01:16.209047
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False


# Generated at 2022-06-12 06:01:19.574258
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-12 06:01:23.011004
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert "Broken coherence" in str(e)

# Generated at 2022-06-12 06:01:27.190110
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test error message")
    except ProgrammingError as ce:
        assert str(ce) == "Test error message"
        assert ce.__cause__ is None


# Generated at 2022-06-12 06:01:34.750966
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        from unittest.mock import MagicMock
        ProgrammingError.passert(False, "This is a programming error.")
        assert False, "Should have raised a ProgrammingError"
    except ProgrammingError as e:
        assert e.args[0] == "This is a programming error.", "Wrong message for ProgrammingError"
        with MagicMock() as mock:
            ProgrammingError.passert(False, mock)
            mock.assert_called_once()
        ProgrammingError.passert(False, None)


# Generated at 2022-06-12 06:01:35.848774
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:01:38.737189
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "message")
    except ProgrammingError as e:
        assert str(e) == "message"


# Generated at 2022-06-12 06:01:40.098521
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()

# Generated at 2022-06-12 06:01:41.957622
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()

# Generated at 2022-06-12 06:01:45.548928
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Message")
    except ProgrammingError as error:
        if error.args[0] != "Message":
            raise AssertionError("Wrong message")
    else:
        raise AssertionError("Exception not raised")

# Generated at 2022-06-12 06:01:49.883855
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test if a :py:class:`ProgrammingError` can be created.

    :raises AssertionError: In case that the assertion fails.
    """
    try:
        raise ProgrammingError("Foo Bar")
    except ProgrammingError:
        pass



# Generated at 2022-06-12 06:01:57.320055
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "This is expected")
    except ProgrammingError:
        assert True, "unexpected exception raised."

# Generated at 2022-06-12 06:02:01.817849
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("TestMessage")
    assert error.args[0] == "TestMessage"

    error = ProgrammingError()
    assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-12 06:02:05.620157
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given
    message = "Message from a test of constructor of class ProgrammingError"

    # When/Then
    try:
        raise ProgrammingError(message)
    except ProgrammingError as raised_error:
        assert raised_error.args[0] == message


# Generated at 2022-06-12 06:02:07.705263
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Call default constructor
    e = ProgrammingError()

    # Call constructor with message parameter
    e = ProgrammingError("test")



# Generated at 2022-06-12 06:02:12.491603
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as ex:
        assert ex.args[0] == "This is a test"


# Generated at 2022-06-12 06:02:13.841683
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except Exception as e:
        assert e.args[0] == "test"


# Generated at 2022-06-12 06:02:16.021714
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert True


# Generated at 2022-06-12 06:02:18.248210
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Test message"

# Generated at 2022-06-12 06:02:21.008164
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Meaningful error message")
    except ProgrammingError as e:
        assert str(e) == "Meaningful error message"

# Generated at 2022-06-12 06:02:23.940617
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:02:32.930519
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("Expected to catch ProgrammingError")


# Generated at 2022-06-12 06:02:35.901806
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(")(")
    except Exception as error:
        assert type(error) is ProgrammingError


# Generated at 2022-06-12 06:02:38.445049
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This should be raised")
    except ProgrammingError as ex:
        assert str(ex) == "This should be raised"

# Generated at 2022-06-12 06:02:41.397450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert ProgrammingError().args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-12 06:02:45.211350
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Assert that the following line of code is equivalent to the other one.
    # This is the equivalent of the constructor of the class.
    # ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")



# Generated at 2022-06-12 06:02:48.801606
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error has occurred.")
    except ProgrammingError as e:
        assert str(e) == "A programming error has occurred."


# Generated at 2022-06-12 06:02:58.212005
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "You shall not pass")
        raise Exception("ProgrammingError shall not be ignored!")
    except ProgrammingError as e:
        assert(str(e) == "You shall not pass")
    try:
        ProgrammingError.passert(False, None)
        raise Exception("ProgrammingError shall not be ignored!")
    except ProgrammingError as e:
        assert(str(e) == "Broken coherence. Check your code against domain logic to fix it.")
    try:
        ProgrammingError.passert(True, "This shall not be raised")
    except ProgrammingError:
        raise Exception("Assertion shall not cause ProgrammingError")
    assert(True)

# Generated at 2022-06-12 06:03:05.303229
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Trying with a message
    try:
        ProgrammingError("Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"
    else:
        raise AssertionError("Test failed")
    # Trying without a message
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("Test failed")

# Generated at 2022-06-12 06:03:09.235480
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the methods of :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "Some Message")
    except ProgrammingError as e:
        assert e.args[0] == "Some Message"
        return
    assert False


# Generated at 2022-06-12 06:03:14.292132
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the :py:class:`ProgrammingError` class.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError("My custom message")
    except ProgrammingError as e:
        assert str(e) == "My custom message"


# Generated at 2022-06-12 06:03:22.982741
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for the constructor of the class :py:class:`ProgrammingError`.
    """
    ProgrammingError("test")


# Generated at 2022-06-12 06:03:25.071042
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as e:
        assert(type(e) is ProgrammingError)

# Generated at 2022-06-12 06:03:27.355361
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as pe:
        assert str(pe) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:03:30.552338
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as e:
        raise ProgrammingError()

    assert "Broken coherence. Check your code against domain logic to fix it." in str(e.value)
    assert e.value.__class__ == ProgrammingError


# Generated at 2022-06-12 06:03:33.689009
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError("error")



# Generated at 2022-06-12 06:03:35.878066
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test exception")


# Unit tests for functionality of method ProgrammingError.passert

# Generated at 2022-06-12 06:03:40.458812
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Error message")
    except ProgrammingError as e:
        print(f"Error raised: {e}")
    else:
        raise RuntimeError("Test failed!")

if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-12 06:03:42.213983
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    p = ProgrammingError("Whatever")
    assert "Whatever" == p.args[0]


# Generated at 2022-06-12 06:03:43.160331
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test message")



# Generated at 2022-06-12 06:03:47.031541
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "This test is expected to fail.")
    ProgrammingError.passert(True, "This test is expected to pass.")

# Generated at 2022-06-12 06:03:57.809803
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given
    message = "It is expected that this message is exactly the same."

    # When
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        actual = e.args

    # Then
    assert actual == (message, )


# Generated at 2022-06-12 06:04:00.450417
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # No assertion is needed, it simply ensures that the object is constructed correctly
    error = ProgrammingError("Test error")
    assert error.args == ("Test error",)


# Generated at 2022-06-12 06:04:05.423039
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Testing constructor of class ProgrammingError."""
    try:
        raise ProgrammingError("Something went wrong")
    except ProgrammingError as e:
        assert e.args == ("Something went wrong",)


# Generated at 2022-06-12 06:04:09.147467
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    message = "Error message"

    # Act
    # Assert
    try:
        raise ProgrammingError(message)
    except Exception as e:
        assert str(e) == message


# Generated at 2022-06-12 06:04:15.870911
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def p1():
        try:
            ProgrammingError.passert(False, "Testing error message 1")
            assert False
        except ProgrammingError as err:
            assert str(err) == "Testing error message 1"

    def p2():
        try:
            ProgrammingError.passert(False, None)
            assert False
        except ProgrammingError as err:
            assert str(err) == "Broken coherence. Check your code against domain logic to fix it."

    def p3():
        try:
            ProgrammingError.passert(True, "Testing error message 3")
        except ProgrammingError as err:
            assert False

    p1()
    p2()
    p3()

# Generated at 2022-06-12 06:04:18.135231
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something was wrong")
    except ProgrammingError as e:
        assert str(e) == "Something was wrong"

# Generated at 2022-06-12 06:04:22.257633
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Should raise an exception
    raised = False
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        print(e)
        raised = True
    assert raised


# Generated at 2022-06-12 06:04:27.138036
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=expression-not-assigned
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        assert False

    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    # pylint: enable=expression-not-assigned

# Generated at 2022-06-12 06:04:30.564949
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:04:35.862823
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        try:
            ProgrammingError.passert(False, "We expect this exception to be raised")
        except ProgrammingError as ex:
            assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."
            raise Exception("Exception didn't contain an error message")
    except Exception as ex:
        assert str(ex) == "We expect this exception to be raised"

# Generated at 2022-06-12 06:04:56.146832
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert ProgrammingError.__module__ == "pypara.common"
    assert ProgrammingError.__init__ is Exception.__init__
    assert ProgrammingError.__doc__ is not None
    assert ProgrammingError.__doc__ == "Provides a programming error exception.\n\n    The rationale for this exception is to raise them whenever we rely on meta-programming and the programmer has\n    introduced a statement which breaks the coherence of the domain logic.\n    "
    assert ProgrammingError.__annotations__ == {"message": Optional[str]}


# Generated at 2022-06-12 06:04:58.782294
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError()
    assert e is not None
    assert str(e) != ''
    assert repr(e) != ''


# Generated at 2022-06-12 06:05:02.660326
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # This call should not raise an exception.
        ProgrammingError.passert(True, "")
        # This call should raise an exception.
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        return
    assert False

# Generated at 2022-06-12 06:05:04.914334
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)



# Generated at 2022-06-12 06:05:07.515288
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test exception")
    except ProgrammingError as e:
        assert "Test exception" in e.args
        assert e.args[0] == "Test exception"


# Generated at 2022-06-12 06:05:13.216711
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert(str(e) == "Broken coherence. Check your code against domain logic to fix it.")

    try:
        raise ProgrammingError("Coherence is broken; please, check your code.")
    except ProgrammingError as e:
        assert(str(e) == "Coherence is broken; please, check your code.")

# Generated at 2022-06-12 06:05:20.402893
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "message")
        assert True
    except ProgrammingError:
        assert False

    try:
        ProgrammingError.passert(False, "message")
        assert False
    except ProgrammingError:
        assert True

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." in str(e)

# Generated at 2022-06-12 06:05:22.831321
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error occurred")
    except ProgrammingError as err:
        assert str(err) == "Programming error occurred"

# Generated at 2022-06-12 06:05:25.212411
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-12 06:05:31.750073
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Uncomment this to see the error message
    #ProgrammingError(None)

    # This should not raise an error
    ProgrammingError.passert(True, "Any error")

    # This should raise an error
    try:
        ProgrammingError.passert(False, None)
        assert False, "Should have raised error"
    except ProgrammingError as e:
        assert len(str(e)) > 0, "Error message cannot be empty"

# Generated at 2022-06-12 06:05:48.106817
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    caught = False
    try:
        raise ProgrammingError("Foo")
    except ProgrammingError as e:
        assert str(e) == "Foo"
        caught = True
    assert caught

# Generated at 2022-06-12 06:05:50.922708
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert "Broken coherence" in ex.args[0]


# Generated at 2022-06-12 06:05:54.102778
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert e.__class__ == ProgrammingError
        assert e.__str__() == "test"



# Generated at 2022-06-12 06:06:01.221180
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test with no message
    try:
        ProgrammingError()
    except ProgrammingError as exc:
        assert str(exc) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "The constructor for class ProgrammingError does not work properly"
    # Test with message
    try:
        ProgrammingError("This is the message")
    except ProgrammingError as exc:
        assert str(exc) == "This is the message"
    else:
        assert False, "The constructor for class ProgrammingError does not work properly"


# Generated at 2022-06-12 06:06:02.747679
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("This is a test message.")


# Generated at 2022-06-12 06:06:06.874666
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("This is the error message.")
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:06:07.780499
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Message"):
        pass


# Generated at 2022-06-12 06:06:08.683612
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:06:14.776644
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import unittest

    class TestProgrammingError(unittest.TestCase):
        def test_init(self):
            subject = ProgrammingError()
            self.assertEqual(str(subject), "Broken coherence. Check your code against domain logic to fix it.")

            subject = ProgrammingError(message="Testing message")
            self.assertEqual(str(subject), "Testing message")

    unittest.main()


# Generated at 2022-06-12 06:06:18.162979
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Programming error")
    except ProgrammingError as e:
        assert e.__class__ is ProgrammingError, "Unexpected type."
        assert str(e) == "Programming error", "Unexpected message."



# Generated at 2022-06-12 06:06:33.649256
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc = ProgrammingError("42")
    assert str(exc) == "42"
    assert repr(exc) == "ProgrammingError('42',)"


# Generated at 2022-06-12 06:06:37.691096
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Test"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert str(e) == message


# Generated at 2022-06-12 06:06:40.010056
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "In case of a failed test")

# Generated at 2022-06-12 06:06:43.551537
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of class :py:class:`ProgrammingError`.
    """

    with pytest.raises(ProgrammingError):
        ProgrammingError("Failure").args


# Generated at 2022-06-12 06:06:46.072370
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:06:47.456210
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # This method does not make any sense, but it is needed to satisfy the coverage tool.
    ProgrammingError()

# Generated at 2022-06-12 06:06:51.750219
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    message = "This is my message"
    with raises(ProgrammingError, message=message) as ei:
        raise ProgrammingError(message)
    assert ei.value.args[0] == message


# Generated at 2022-06-12 06:06:53.536147
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class: `ProgrammingError`."""
    ProgrammingError()


# Generated at 2022-06-12 06:06:54.949781
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "test"):
        pass



# Generated at 2022-06-12 06:07:00.073006
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    except Exception:
        assert False
    else:
        assert False


# Generated at 2022-06-12 06:07:28.855234
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is just a test")
    except:
        pass


if __name__ == "__main__":
    import sys
    import doctest
    sys.exit(doctest.testmod()[0])  # pragma: no cover

# Generated at 2022-06-12 06:07:30.292357
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:07:40.696174
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyUnusedLocal
    def test_function(x: int, y: int) -> int:
        if x >= 0:
            if x == 0:
                ProgrammingError.passert(y > 0, "Expecting x > 0.")
        else:
            ProgrammingError.passert(y <= 0, "Expecting x > 0.")
        return x+y

    try:
        test_function(0, 0)
    except ProgrammingError:
        pass
    except Exception:
        raise RuntimeError("Unexpected exception raised!")
    else:
        raise RuntimeError("Expected to raise a ProgrammingError!")

    try:
        test_function(1, 2)
    except ProgrammingError:
        raise RuntimeError("Did not expect to raise a ProgrammingError!")

# Generated at 2022-06-12 06:07:44.593303
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This should raise an exception")
        assert False
    except ProgrammingError as e:
        assert str(e) == "This should raise an exception"



# Generated at 2022-06-12 06:07:49.954709
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the :py:class:`ProgrammingError` class.
    """
    try:
        assert False, "This should never happen"
    except AssertionError:
        exc = ProgrammingError.from_exception()
    assert isinstance(exc, ProgrammingError)
    assert str(exc) == "This should never happen"


# Generated at 2022-06-12 06:07:56.950986
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test case for the constructor of class :py:class:`ProgrammingError`.

    :return: ``None``
    """
    # When: Using the constructor without parameters
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    # When: Using the constructor with a message
    try:
        raise ProgrammingError("My message")
    except ProgrammingError as e:
        assert e.args == ("My message",)


# Generated at 2022-06-12 06:08:01.602048
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True
    try:
        raise ProgrammingError("Cannot be True")
    except ProgrammingError as error:
        assert str(error) == "Cannot be True"


# Generated at 2022-06-12 06:08:09.433093
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    class C:
        pass
    c = C()

    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)

    # Check if the constructor updates the message attribute correctly.
    e = ProgrammingError("Programming error exception message.")
    assert e.message == "Programming error exception message."

    # Check if the constructor updates the message attribute correctly.
    # Check if the constructor updates the message attribute correctly.
    e = ProgrammingError("Programming error exception message.", c)
    assert e.message == "Programming error exception message. +  <class '__main__.C'> object at 0x7f96cc0d7510>"

    # Check the alternative constructor:
    ProgrammingError.passert(False, None)

# Generated at 2022-06-12 06:08:11.705592
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:08:16.318140
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert e.message == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:09:18.527097
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(condition=False, message=None)

# Generated at 2022-06-12 06:09:20.690567
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("my message")
    except ProgrammingError as err:
        assert str(err) == "my message"


# Generated at 2022-06-12 06:09:29.738274
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Raises an exception of the expected type with the provided message or the default one. It shouldn't raise anything
    if the condition is ``True``.
    """
    msg = "Something went wrong"
    try:
        ProgrammingError.passert(False, msg)
        assert False  # should be unreachable
    except ProgrammingError as err:
        assert str(err) == msg

    try:
        ProgrammingError.passert(False, None)
        assert False  # should be unreachable
    except ProgrammingError as err:
        assert str(err) == "Broken coherence. Check your code against domain logic to fix it."
        assert err.args == ()

    try:
        ProgrammingError.passert(True, None)  # it shouldn't raise anything if the condition is True
    except ProgrammingError as err:
        assert False  #

# Generated at 2022-06-12 06:09:41.068757
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase, TestSuite, TextTestRunner
    import unittest
    import sys

    class ProgrammingErrorTester(TestCase):
        class Subclass(ProgrammingError):
            def __init__(self, message: str = None) -> None:
                super().__init__(message or "Error!")

        def test_raise(self) -> None:
            class Foo():
                def __eq__(self, other):
                    raise ProgrammingError()

            with self.assertRaises(ProgrammingError):
                _ = Foo() == 42

        def test_passert(self) -> None:
            with self.assertRaises(ProgrammingError):
                ProgrammingError.passert(condition=False, message="Error!")


# Generated at 2022-06-12 06:09:50.588365
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.test.throwable import assert_throwable
    from pypara.test.throwable import capture_throwable

    # pylint: disable=expression-not-assigned
    assert_throwable(ProgrammingError, "Broken coherence. Check your code against domain logic to fix it.")

    # pylint: disable=expression-not-assigned
    assert_throwable(ProgrammingError, None)

    with capture_throwable():
        ProgrammingError.passert(True, None)

    exception = capture_throwable(False, ProgrammingError.passert, False, None)
    assert isinstance(exception, ProgrammingError)
    assert exception.args == ("Broken coherence. Check your code against domain logic to fix it.",)
