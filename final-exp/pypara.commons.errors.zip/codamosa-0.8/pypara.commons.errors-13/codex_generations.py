

# Generated at 2022-06-12 05:59:54.070338
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error_message = "Something has failed"
    try:
        raise ProgrammingError(error_message)
    except ProgrammingError as exception:
        assert exception.args[0] == error_message


# Generated at 2022-06-12 06:00:01.003272
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as error:
        assert isinstance(error.args[0], str)
        assert len(error.args) == 1
    try:
        raise ProgrammingError("Descriptive message")
    except ProgrammingError as error:
        assert isinstance(error.args[0], str)
        assert len(error.args) == 1
        assert error.args[0] == "Descriptive message"


# Generated at 2022-06-12 06:00:03.949030
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-12 06:00:09.822490
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.error import ProgrammingError

    with raises(ProgrammingError):
        ProgrammingError.passert(condition=False, message="Test.")

    try:
        ProgrammingError.passert(condition=True, message="Test.")
    except ProgrammingError:
        raise AssertionError("Should not raise any exception.")

# Generated at 2022-06-12 06:00:11.901905
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with assert_raises(ProgrammingError):
        ProgrammingError.passert(False, "Hello")



# Generated at 2022-06-12 06:00:13.529082
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()

# Generated at 2022-06-12 06:00:16.208348
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        assert True

# Generated at 2022-06-12 06:00:19.299411
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('test')
    except ProgrammingError as exc:
        assert 'test' == str(exc)


# Generated at 2022-06-12 06:00:21.859846
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # This test is necessary to keep the `coverage` tool happy
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False

# Generated at 2022-06-12 06:00:24.106303
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert "Broken coherence" in str(ex)


# Generated at 2022-06-12 06:00:27.297758
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A fake programming error")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:00:30.699541
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError(message="")
    except TypeError:
        pass
    else:
        raise AssertionError("ProgrammingError constructor has signature compatible with Exception")



# Generated at 2022-06-12 06:00:32.109758
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Error message")
    assert error.args == ("Error message",)

# Generated at 2022-06-12 06:00:34.750024
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"

# Generated at 2022-06-12 06:00:41.642510
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Ensure that the expected :py:class:`ProgrammingError` exception is raised in case that the condition passed to the
    :py:meth:`passert` is ``False``
    """
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError.passert(False, message=None)
        ProgrammingError.passert(False, message="")
        ProgrammingError.passert(False, message="Foo")

# Generated at 2022-06-12 06:00:44.373217
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is a test error.")
    assert isinstance(error, Exception)
    assert str(error) == "This is a test error."


# Generated at 2022-06-12 06:00:46.934688
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test case for constructor of class ProgrammingError.
    """
    try:
        ProgrammingError('a message')
    except ProgrammingError as ex:
        assert str(ex) == 'a message'



# Generated at 2022-06-12 06:00:50.706555
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor for :py:class:`ProgrammingError`.

    :return: ``None``
    :rtype: None
    """
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:00:52.630879
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:00:56.817248
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError('test')
    except ProgrammingError as e:
        assert e.args[0] == 'test'


# Generated at 2022-06-12 06:01:00.411185
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert "test" in e.args[0]


# Generated at 2022-06-12 06:01:02.039468
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass



# Generated at 2022-06-12 06:01:07.379302
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an error")
        assert False
    except ProgrammingError as exception:
        assert isinstance(exception, ProgrammingError)
        assert str(exception) == "This is an error"


# Generated at 2022-06-12 06:01:10.557333
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hello")
    except ProgrammingError as error:
        assert error.args == ("Hello",)
    else:
        assert False


# Generated at 2022-06-12 06:01:13.819855
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(1==2, "1==2")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:01:16.154965
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:01:18.532637
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-12 06:01:19.200709
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Expected message")


# Generated at 2022-06-12 06:01:28.476802
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Unit test for constructor of class ProgrammingError. """
    # The constructor is automatically tested by `test_ProgrammingError.passert`
    # pylint: disable=unused-argument

    # The following assert does not raise an exception
    ProgrammingError.passert(True, "Some message")

    # The following assert raises an exception
    try:
        ProgrammingError.passert(False, "Some message")
    except ProgrammingError:
        pass
    else:
        assert False, "Expected an exception"

# Unit tests for methods of class ProgrammingError

# Generated at 2022-06-12 06:01:31.329327
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    assert ProgrammingError("Test")
    assert str(ProgrammingError("Test")) == "Test"


# Generated at 2022-06-12 06:01:36.054928
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-12 06:01:45.019637
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert True
    else:
        assert False
    try:
        ProgrammingError.passert(False, "MESSAGE")
    except ProgrammingError as e:
        assert e.args[0] == "MESSAGE"
    else:
        assert False
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        assert False
    else:
        assert True
    try:
        ProgrammingError.passert(True, "MESSAGE")
    except ProgrammingError as e:
        assert False
    else:
        assert True

# Generated at 2022-06-12 06:01:48.880619
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("some message")
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)
        assert str(err) == "some message"
        assert err.args[0] == "some message"

# Generated at 2022-06-12 06:01:51.597255
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Something is wrong.")
    except ProgrammingError as e:
        assert str(e) == "Something is wrong."

# Generated at 2022-06-12 06:01:56.271169
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from para_programming_error import ProgrammingError

    with raises(ProgrammingError):
        error = ProgrammingError("This is an error for testing purposes")
    with raises(ProgrammingError):
        error = ProgrammingError()


# Generated at 2022-06-12 06:01:59.847508
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except Exception as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:02:01.501003
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Hello")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:02:03.754793
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise Exception("Expected a ProgrammingError")


# Generated at 2022-06-12 06:02:07.544842
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is the expected error message")
    except Exception as e:
        assert "Broken coherence. Check your co" in str(e)
    try:
        ProgrammingError.passert(True, "This is an unexpected error message")
    except Exception:
        assert False

# Generated at 2022-06-12 06:02:13.962345
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Setup
    expected_message = "Error message"

    # Test and verify
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == ""

    try:
        raise ProgrammingError(expected_message)
    except ProgrammingError as e:
        assert str(e) == expected_message


# Generated at 2022-06-12 06:02:20.837252
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Pass message
    try:
        ProgrammingError.passert(False, "testing_message")
    except ProgrammingError as e:
        assert str(e) == "testing_message"
    else:
        assert False, "We should not arrive here"
    # Do not pass message
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "We should not arrive here"

# Generated at 2022-06-12 06:02:23.360725
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something went wrong.")
    except ProgrammingError as error:
        assert str(error) == "Something went wrong."


# Generated at 2022-06-12 06:02:26.540124
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a message")
    except ProgrammingError as e:
        assert str(e) == "This is a message"


# Generated at 2022-06-12 06:02:28.884789
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("")
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-12 06:02:31.048864
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Expected condition failed.")

# Generated at 2022-06-12 06:02:36.052897
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Any message")

    ProgrammingError.passert(True, None)
    ProgrammingError.passert(True, "Any message")

# Generated at 2022-06-12 06:02:38.182143
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-12 06:02:41.907052
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Condition not met")
    except ProgrammingError as e:
        assert str(e) == "Condition not met"
    else:
        assert False, "ProgrammingError expected"


# Generated at 2022-06-12 06:02:44.146291
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("my message")
    except ProgrammingError as e:
        assert "my message" == e.args[0]


# Generated at 2022-06-12 06:02:54.080366
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    from pypara.utils.ProgrammingError import ProgrammingError
    # If a message is provided, it should be the one provided
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "message")
    assert "message" == str(excinfo.value)
    # If not, it should be the default one
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, None)
    assert "Broken coherence. Check your code against domain logic to fix it." == str(excinfo.value)



# Generated at 2022-06-12 06:03:01.113988
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")
        assert False, "A ProgrammingError should have been raised"
    except ProgrammingError as e:
        assert str(e) == "Test message"


# Generated at 2022-06-12 06:03:04.392281
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # arrange
    expected = "broke the logic"
    # act
    actual = ProgrammingError(expected)
    # assert
    assert str(actual) == expected

# Module test for method passert of class ProgrammingError

# Generated at 2022-06-12 06:03:05.655123
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Rationale"):
        pass


# Generated at 2022-06-12 06:03:07.890118
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as pe:
        assert str(pe) == "Test"


# Generated at 2022-06-12 06:03:10.210437
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:03:19.223483
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "No error should be raised")
    except ProgrammingError:
        assert False, "Error has been raised despite being a true condition"

    try:
        ProgrammingError.passert(False, "Some error")
    except ProgrammingError as error:
        assert str(error) == "Some error", "Error has not been raised despite being a false condition"
    else:
        assert False, "Error has not been raised despite being a false condition"

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as error:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it.", "Error does not " \
                             "contain the default message"
    else:
        assert False, "Error has not been raised despite being a false condition"

# Generated at 2022-06-12 06:03:23.049341
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error raised")
    except ProgrammingError as e:
        assert str(e) == "Programming error raised"


# Generated at 2022-06-12 06:03:27.559074
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False, "passert should have rise a ProgrammingError"
    except ProgrammingError:
        pass
    # end try
    try:
        ProgrammingError.passert(False, "Test")
        assert False, "passert should have rise a ProgrammingError"
    except ProgrammingError:
        pass
    # end try

# Generated at 2022-06-12 06:03:34.513938
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test.")
        assert False, "ProgrammingError.passert() did not raise an exception with a message"
    except ProgrammingError as e:
        assert e.args[0] == "This is a test.", "ProgrammingError.passert() did not raise the correct message"

# Generated at 2022-06-12 06:03:39.300507
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    caught = False

    try:
        raise ProgrammingError("foo")
    except ProgrammingError as e:
        caught = True
    assert caught

    caught = False
    try:
        raise ProgrammingError(None)
    except ProgrammingError as e:
        caught = True
    assert caught


# Generated at 2022-06-12 06:03:49.443618
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.

    :returns: Always ``None``.

    The constructor is tested without raising any exception.
    """
    from pypara.error import ProgrammingError
    ProgrammingError(message="Some message")
    ProgrammingError(message=None)
    return None


# Generated at 2022-06-12 06:03:51.356953
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc = ProgrammingError()
    assert exc.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-12 06:03:55.590805
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test!")
    except ProgrammingError as e:
        assert str(e) == "This is a test!"
        return
    assert False


# Generated at 2022-06-12 06:03:58.636936
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error!")
    except ProgrammingError as exc:
        assert str(exc) == "This is a programming error!"


# Generated at 2022-06-12 06:04:01.490949
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected_message = "Expected message"
    try:
        raise ProgrammingError(expected_message)
    except ProgrammingError as e:
        assert e.args[0] == expected_message


# Generated at 2022-06-12 06:04:13.318828
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError.passert failed to raise through ProgrammingError when passed False condition"
    try:
        ProgrammingError.passert(True, "Test")
    except ProgrammingError:
        assert False, "ProgrammingError.passert raised a ProgrammingError, when passed True condition"
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError.passert failed to raise through ProgrammingError when passed False condition"
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        assert False, "ProgrammingError.passert raised a ProgrammingError when passed True condition and None message"

# Generated at 2022-06-12 06:04:16.244784
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some problem")
    except ProgrammingError as e:
        assert str(e) == "Some problem"

# Generated at 2022-06-12 06:04:18.054369
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(None)



# Generated at 2022-06-12 06:04:24.281760
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(0==1, "my message")
        assert(0)
    except ProgrammingError as e:
        assert("my message" == str(e))
    try:
        ProgrammingError.passert(0==1, None)
        assert(0)
    except ProgrammingError as e:
        assert("Broken coherence. Check your code against domain logic to fix it." == str(e))

# Generated at 2022-06-12 06:04:28.324706
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of class ProgrammingError."""
    try:
        ProgrammingError("Hello World")
    except ProgrammingError as error:
        assert str(error) == "Hello World"
    else:
        raise AssertionError("Test must have failed")


# Generated at 2022-06-12 06:04:42.976693
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Failing intention")
    except ProgrammingError as e:
        assert str(e) == "Failing intention"


# Generated at 2022-06-12 06:04:44.512067
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("")
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:04:47.272339
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "no no no")
    except ProgrammingError as ex:
        assert str(ex) == "no no no"
    else:
        assert False

# Generated at 2022-06-12 06:04:52.155666
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-12 06:05:02.216113
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for :py:class:`ProgrammingError`.
    """

    # Test for constructor of class ProgrammingError
    try:
        raise ProgrammingError("This is a test error message.")
    except ProgrammingError as e:
        assert str(e) == "This is a test error message."

    # Test for method ProgrammingError.passert
    try:
        ProgrammingError.passert(False, "This is a test error message.")
    except ProgrammingError as e:
        assert str(e) == "This is a test error message."
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:05:05.970045
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Check your code against domain logic to fix it.")
    except ProgrammingError as error:
        assert error.args[0] == "Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:05:08.157955
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("It was meant to be")
    except ProgrammingError as e:
        assert str(e) == "It was meant to be"


# Generated at 2022-06-12 06:05:15.573134
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError`.
    """

    try:
        ProgrammingError.passert(True, "Should not fire")
    except ProgrammingError:
        raise AssertionError("Literal assertion with True should not throw.")

    try:
        ProgrammingError.passert(False, "Should fire")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Literal assertion with False should throw.")



# Generated at 2022-06-12 06:05:19.193087
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something went wrong in the code")
    except ProgrammingError as err:
        assert str(err) == "Something went wrong in the code"
    else:
        assert False


# Generated at 2022-06-12 06:05:28.735183
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test case: check if the programming error is raised if the condition is not met
    try:
        ProgrammingError.passert(False, "foo")
    except ProgrammingError:
        # Ok, good!
        pass
    except:
        assert False, "Unexpected exception raised."
    else:
        assert False, "Expected exception not raised."

    # Test case: check if the programming error is not raised if the condition is met
    try:
        ProgrammingError.passert(True, "foo")
    except ProgrammingError:
        assert False, "Unexpected exception raised."
    except:
        assert False, "Unexpected exception raised."

# Generated at 2022-06-12 06:06:00.496628
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        # pylint: disable=no-member
        assert err.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:06:03.287033
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("error message")
    except ProgrammingError as e:
        assert e.args[0] == "error message"
    else:
        assert False, "Expected exception not raised."

# Generated at 2022-06-12 06:06:08.239589
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("I am a programmer")
    except ProgrammingError as e:
        assert e.__str__() == "I am a programmer"


# Generated at 2022-06-12 06:06:09.958676
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error.")
    except ProgrammingError as e:
        assert e.args[0] == "This is an error."


# Generated at 2022-06-12 06:06:13.886206
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Hi there!")
        assert False
    except ProgrammingError as ex:
        assert str(ex) == "Hi there!"


# Generated at 2022-06-12 06:06:18.410908
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "")
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


if __name__ == '__main__':
    test_ProgrammingError()

# Generated at 2022-06-12 06:06:24.335376
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError("Error")
    except ProgrammingError as ex:
        assert len(ex.args) == 1
        assert ex.args[0] == "Error"
    try:
        ProgrammingError(None)
    except ProgrammingError as ex:
        assert len(ex.args) == 1
        assert ex.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:06:28.436827
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(condition=True, message="error!"):
        pass

    with ProgrammingError.passert(condition=False, message="error!"):
        pass


# Generated at 2022-06-12 06:06:31.408887
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as ex:
        assert ex.args == ("Broken coherence. Check your code against domain logic to fix it.", )


# Generated at 2022-06-12 06:06:34.040369
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error detected.")
    except ProgrammingError as error:
        assert error.args[0] == "Programming error detected."


# Generated at 2022-06-12 06:07:26.857094
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError():
        ProgrammingError.passert(False, "Message")

# Generated at 2022-06-12 06:07:30.530833
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is a message")
    except Exception as err:
        assert(err.__class__.__name__ == "ProgrammingError")
        assert(str(err) == "This is a message")


# Generated at 2022-06-12 06:07:36.658799
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Broken coherence. Check your code against domain logic to fix it.")
    except Exception as e:
        assert isinstance(e, ProgrammingError), "Expected programming error, but got {}".format(e)
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise Exception("Expected programming error, but got none")

# Generated at 2022-06-12 06:07:38.880785
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-12 06:07:43.199021
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` constructor.
    """
    assert issubclass(ProgrammingError, Exception)
    message = "This is the message"
    with ProgrammingError(message):
        assert True


# Generated at 2022-06-12 06:07:51.614811
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test error message")
    except ProgrammingError as e:
        assert "Test error message" == str(e), "Invalid error message"
    else:
        assert False, "An error was expected to be raised, a None was returned instead"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e), "Invalid error message"
    else:
        assert False, "An error was expected to be raised, a None was returned instead"
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e), "Invalid error message"


# Generated at 2022-06-12 06:07:53.992850
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:07:56.155451
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"


# Generated at 2022-06-12 06:07:58.310705
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test"):
        ProgrammingError.passert(False, "Test")

# Generated at 2022-06-12 06:08:02.006196
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    from pytest import raises

    # Check the error is raised if ProgrammingError is called
    with raises(ProgrammingError):
        raise ProgrammingError("Testing constructor of ProgrammingError")
