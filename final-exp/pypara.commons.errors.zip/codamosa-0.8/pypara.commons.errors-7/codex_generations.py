

# Generated at 2022-06-12 05:59:56.338826
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()
    with pytest.raises(ProgrammingError):
        ProgrammingError(message="Message 1")
    with pytest.raises(ProgrammingError):
        ProgrammingError(message="Message 2")


# Generated at 2022-06-12 06:00:00.778924
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as e:
        ProgrammingError.passert(False, None)
    assert e.value.args == ("Broken coherence. Check your code against domain logic to fix it.",)

# Generated at 2022-06-12 06:00:03.379346
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "My message")
        assert False, "Should raise an exception"
    except ProgrammingError as e:
        assert "My message" == str(e)

# Generated at 2022-06-12 06:00:05.709671
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("problem")
    except ProgrammingError as ex:
        assert ex.args[0] == "problem"

# Generated at 2022-06-12 06:00:10.336282
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Asserts that the constructor of the :py:class:`ProgrammingError` obtains the message properly.
    """

    assert ProgrammingError("arbitrary message").args[0] == "arbitrary message"


# Generated at 2022-06-12 06:00:13.785965
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError:
        pass
    else:
        assert False, "The constructor of class ProgrammingError has failed its unit test."


# Generated at 2022-06-12 06:00:16.066346
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("This error should be thrown.")

# Generated at 2022-06-12 06:00:17.211408
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert callable(ProgrammingError)


# Generated at 2022-06-12 06:00:19.428188
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("error")
    except ProgrammingError as err:
        assert str(err) == "error"



# Generated at 2022-06-12 06:00:29.684976
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "foobar")
    except ProgrammingError as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(True, "foobar")
    except ProgrammingError:
        assert False


# Generated at 2022-06-12 06:00:35.609833
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that condition is not met and an error as expected is raised.
    """
    condition = False
    message = "Test error"
    try:
        ProgrammingError.passert(condition, message)
        assert False
    except ProgrammingError as error:
        assert error.__cause__ is None
        assert error.__context__ is None
        assert str(error) == message

# Generated at 2022-06-12 06:00:39.165243
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
    except ProgrammingError as err:
        assert "test" == err.args[0]



# Generated at 2022-06-12 06:00:43.671488
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert str(ProgrammingError("msg")) == "msg"
    try:
        raise ProgrammingError("msg")
    except ProgrammingError as e:
        assert str(e) == "msg"
    except BaseException as e:
        assert False


# Generated at 2022-06-12 06:00:45.810723
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    error = ProgrammingError("Some error")

    # THEN
    assert error.__str__() == "Some error"

# Generated at 2022-06-12 06:00:50.086570
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError
    """
    try:
        raise ProgrammingError
    except Exception as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:00:52.260211
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-12 06:00:57.354455
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.

    :return: ``None``
    """
    try:
        raise ProgrammingError("This is a programming error!")
    except ProgrammingError as e:
        assert str(e) == "This is a programming error!"

# Generated at 2022-06-12 06:01:00.595536
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Some error."):
        pass

    with ProgrammingError.passert(False, "Some error."):
        pass

    with ProgrammingError.passert(False, None):
        pass

# Generated at 2022-06-12 06:01:03.090275
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for :py:class:`ProgrammingError`."""
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Test for exception")

# Generated at 2022-06-12 06:01:04.579702
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("A ProgrammingError!")

# Generated at 2022-06-12 06:01:08.429719
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("a custom error")
    assert error.args == ("a custom error",)


# Generated at 2022-06-12 06:01:10.601430
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError.passert(False, "This is an error")
        raise Exception("This should have failed")
    except ProgrammingError:
        pass

    try:
        ProgrammingError("This is also an error")
        raise Exception("This should have failed")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:01:13.850390
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error")
    except ProgrammingError as e:
        assert(e.args == ("Programming error",))
    else:
        raise AssertionError("Expected ProgrammingError to be raised")


# Generated at 2022-06-12 06:01:15.644045
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of ProgrammingError.
    """
    assert ProgrammingError("Some error") is not None


# Generated at 2022-06-12 06:01:19.897739
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert True
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert True
    try:
        raise ProgrammingError(123)
    except ProgrammingError as e:
        assert True


# Generated at 2022-06-12 06:01:23.055828
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Some message")
    assert error.args == ("Some message",)
    assert str(error) == "Some message"


# Generated at 2022-06-12 06:01:27.242551
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Unit test")  # type: ignore
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Unit test"


# Generated at 2022-06-12 06:01:28.738361
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check whether a ProgrammingError can be instantiated
    ProgrammingError()


# Generated at 2022-06-12 06:01:30.863336
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Something went wrong")
    except ProgrammingError as e:
        assert(e.args[0] == "Something went wrong")

# Generated at 2022-06-12 06:01:35.604547
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected_error_message = "The expected error message."
    try:
        ProgrammingError.passert(False, expected_error_message)
    except ProgrammingError as e:
        assert(str(e) == expected_error_message)
    else:
        assert(False)



# Generated at 2022-06-12 06:01:42.203711
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        msg = "This is my message."
        exc = ProgrammingError(msg)
        assert msg == str(exc), "Actual message is {0}".format(str(exc))
    except Exception as e:
        assert False, "Unexpected exception: {0}".format(str(e))


# Generated at 2022-06-12 06:01:44.490444
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception:
        pass
    else:
        raise AssertionError("Expected an exception.")


# Generated at 2022-06-12 06:01:46.126901
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is a test")


# Generated at 2022-06-12 06:01:49.833552
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    ProgrammingError(message="Testing exception class")
    assert ProgrammingError.passert(True, None) is None
    assert ProgrammingError.passert(False, "Testing assert") is None

# Generated at 2022-06-12 06:01:52.050167
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Should have raised an exception"


# Generated at 2022-06-12 06:01:57.267852
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the ProgrammingError constructor.
    """
    expected_message = "test message"
    try:
        raise ProgrammingError(expected_message)
    except ProgrammingError as e:
        assert e.args[0] == expected_message
        assert str(e) == expected_message


# Generated at 2022-06-12 06:02:02.224610
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    message = "This is a test."
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert message in str(e)


# Generated at 2022-06-12 06:02:05.978336
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if the constructor of the exception works as expected.
    """
    try:
        raise ProgrammingError("Some error.")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError was not raised.")


# Generated at 2022-06-12 06:02:09.104741
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    
    try:
        raise ProgrammingError("a random error")
    except:
        pass # 
    else:
        raise AssertionError("We should not be here.")

# Generated at 2022-06-12 06:02:12.759074
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error exception")
    except ProgrammingError as e:
        assert "This is a programming error exception" == str(e)


# Generated at 2022-06-12 06:02:22.872562
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError` constructor.
    """
    try:
        ProgrammingError("This is not a programming error.")
        raise Exception("ProgrammingError: Test failed")
    except ProgrammingError as err:
        print("ProgrammingError: Test successful, message is: \"", err.args[0], "\"")


# Generated at 2022-06-12 06:02:24.417690
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("Test")
    assert(str(err) == "Test")

# Generated at 2022-06-12 06:02:28.195019
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e.args, tuple)
        assert len(e.args) == 0
    else:
        raise AssertionError("Expected a ProgrammingError exception.")


# Generated at 2022-06-12 06:02:29.969881
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("Assertion failed")


# Generated at 2022-06-12 06:02:31.383411
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()



# Generated at 2022-06-12 06:02:34.665394
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    try:
        raise ProgrammingError("Testing error")
    except ProgrammingError as e:
        assert str(e) == "Testing error"


# Generated at 2022-06-12 06:02:38.289421
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="Testing")
    except ProgrammingError as e:
        assert str(e) == "Testing"
    else:
        assert False, "ProgrammingError not raised!"


# Generated at 2022-06-12 06:02:40.076515
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert isinstance(error, Exception)


# Generated at 2022-06-12 06:02:42.549327
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "message")
    except ProgrammingError as exception:
        assert exception.args[0] == "message"


# Generated at 2022-06-12 06:02:45.456876
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test for constructor of class ProgrammingError"""
    import pytest
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()


# Generated at 2022-06-12 06:03:00.121579
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError(message="foo")
    except ProgrammingError as e:
        assert str(e) == "foo"


# Generated at 2022-06-12 06:03:03.690858
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "This should raise ProgrammingError.")
    ProgrammingError.passert(True, "This should raise ProgrammingError.")

# Generated at 2022-06-12 06:03:12.651758
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Expected ProgrammingError exception not raised"

    try:
        ProgrammingError.passert(False, "Test message")
    except ProgrammingError:
        pass
    else:
        assert False, "Expected ProgrammingError exception not raised"

    try:
        ProgrammingError.passert(True, "Test message")
    except ProgrammingError:
        assert False, "Expected ProgrammingError exception raised along with condition is True"

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass
    else:
        assert False, "Expected ProgrammingError exception not raised"


# Generated at 2022-06-12 06:03:21.573282
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    # Test with a message
    with pytest.raises(ProgrammingError) as err:
        ProgrammingError("Test message")
    assert err.value.args[0] == "Test message"

    # Test without a message
    with pytest.raises(ProgrammingError) as err:
        ProgrammingError()
    assert err.value.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    # Ok for no exception
    assert ProgrammingError.passert(True, None) is None

    # Raises an exception
    with pytest.raises(ProgrammingError) as err:
        ProgrammingError.passert(False, None)
    assert err.value.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:03:23.178989
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-12 06:03:25.787757
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Unit Test")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Unit Test"



# Generated at 2022-06-12 06:03:28.236394
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Suppress mypy check to avoid that the test fails
        ProgrammingError()  # type: ignore
    except Exception:
        assert False, "ProgrammingError() raises an exception"



# Generated at 2022-06-12 06:03:31.396667
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test a missing parameter
    try:
        ProgrammingError(None)
    except TypeError as e:
        assert e.args[0] == "__init__() missing 1 required positional argument: 'message'"
    else:
        raise AssertionError("Invalid behaviour, missing parameter should raise TypeError.")


# Generated at 2022-06-12 06:03:34.639089
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("this is a test")
    except ProgrammingError as e:
        assert str(e) == "this is a test"

# Generated at 2022-06-12 06:03:37.871741
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    try:
        ProgrammingError.passert(False, "TEST")
        pytest.fail("ProgrammingError.passert(False) should have raised a ProgrammingError.")
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:04:01.055170
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    actual = None
    try:
        ProgrammingError.passert(False, "Unit testing")
    except ProgrammingError as e:
        actual = e
    expected = ProgrammingError("Unit testing")

    assert str(actual) == str(expected)


# Generated at 2022-06-12 06:04:08.195988
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Checks if :py:class:`ProgrammingError` works fine."""
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == ""
    try:
        raise ProgrammingError("Error message.")
    except ProgrammingError as e:
        assert str(e) == "Error message."


# Generated at 2022-06-12 06:04:10.954256
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as error:
        assert (error.args[0] == "Error message")


# Generated at 2022-06-12 06:04:14.147184
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="Testing error message")
    except ProgrammingError:
        pass
    else:
        raise Exception("Test failed.")


# Generated at 2022-06-12 06:04:16.899072
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # When
        raise ProgrammingError("test")
    except ProgrammingError as e:
        # Then
        assert "test" == str(e)


# Generated at 2022-06-12 06:04:21.211119
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor of class ProgrammingError.
    """
    message = "Mock message"
    instance = ProgrammingError(message)
    err_msg = str(instance)
    assert message in err_msg


# Generated at 2022-06-12 06:04:23.050812
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "This message should be displayed.")

# Generated at 2022-06-12 06:04:26.746697
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert (e.args[0] == "Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-12 06:04:28.850971
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Good bye!")
    except ProgrammingError as e:
        assert str(e) == "Good bye!"

# Generated at 2022-06-12 06:04:36.158977
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class MyError(ProgrammingError):
        pass
    with pytest.raises(MyError) as error:
        MyError.passert(False, "Test error message")
    assert str(error.value) == "Test error message"

    # Unit test for passert method
    with pytest.raises(ProgrammingError) as error:
        ProgrammingError.passert(False, None)
    assert str(error.value) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:05:20.331715
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "There is a problem.")
    except ProgrammingError as e:
        assert e.args[0] == "There is a problem."
    assert ProgrammingError.passert(True, None) is None

# Generated at 2022-06-12 06:05:23.798239
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the programming error constructor behavior.
    """
    error = ProgrammingError("message")
    assert error.args == ("message",)
    assert str(error) == "message"


# Generated at 2022-06-12 06:05:25.164920
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Broken coherence."):
        pass

# Generated at 2022-06-12 06:05:28.239751
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Constructor of exception has failed")



# Generated at 2022-06-12 06:05:35.314093
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for :py:class:`ProgrammingError`"""
    try:
        ProgrammingError("This is an error")
    except ProgrammingError as error:
        assert error.args[0] == "This is an error"
    try:
        ProgrammingError.passert(False, "This is an error")
    except ProgrammingError as error:
        assert error.args[0] == "This is an error"
        assert ProgrammingError.passert(True, "This is an error") == None

# Generated at 2022-06-12 06:05:39.015190
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This error was raised on purpose in order to test it.")
    except ProgrammingError as pe:
        assert str(pe) == "This error was raised on purpose in order to test it."
    except Exception as e:
        assert False, "The exception which has been raised does not derive from ProgrammingError!"


# Generated at 2022-06-12 06:05:43.211395
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    # WHEN
    # THEN
    try:
        ProgrammingError("This message shall be shown if error is raised")
    except Exception as e:
        assert(str(e) == "This message shall be shown if error is raised")


# Generated at 2022-06-12 06:05:45.568933
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Cannot create ProgrammingError")


# Generated at 2022-06-12 06:05:48.069606
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Some error message.")
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:05:51.696664
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Your code broke coherence.")
    except ProgrammingError as e:
        assert isinstance(e, Exception)
        assert "coherence" in str(e)


# Generated at 2022-06-12 06:07:28.495910
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error = ProgrammingError("message")
    assert "message" in str(programming_error)


# Generated at 2022-06-12 06:07:29.493154
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:07:32.496204
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Creating a generic instance of this exception type
    exception = ProgrammingError()
    # If a constructor invocation is successful, then their objects should be an instance of the class type
    assert isinstance(exception, ProgrammingError)


# Generated at 2022-06-12 06:07:37.352296
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        assert ProgrammingError is not None
        raise AssertionError("ProgrammingError is not well defined")
    except Exception as e:
        raise AssertionError(
            "ProgrammingError is not well defined: I have got an exception {}".format(str(e)))


# Generated at 2022-06-12 06:07:39.909896
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing error")
    except ProgrammingError as e:
        assert e.args[0] == "Testing error"



# Generated at 2022-06-12 06:07:45.237539
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def _tassert(condition, message):
        try:
            ProgrammingError.passert(condition, message)
        except ProgrammingError as e:
            assert str(e) == message

    _tassert(True, "message")
    _tassert(False, "message")
    _tassert(True, None)
    _tassert(False, None)

# Generated at 2022-06-12 06:07:48.583971
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing")
        assert False
    except ProgrammingError as e:
        assert e.args == ("Testing",)

# Generated at 2022-06-12 06:07:53.390574
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara import Exception as BaseException

    with raises(ProgrammingError) as excinfo:
        ProgrammingError()
    assert str(excinfo.value) == "Broken coherence. Check your code against domain logic to fix it."
    assert isinstance(excinfo.value, BaseException)


# Generated at 2022-06-12 06:07:56.919419
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    try:
        ProgrammingError.passert(False, "Have you checked the domain logic?")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Have you checked the domain logic?"


# Generated at 2022-06-12 06:08:00.052083
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError(message="This is an error!") as error:
        assert error.args[0] == "This is an error!"

