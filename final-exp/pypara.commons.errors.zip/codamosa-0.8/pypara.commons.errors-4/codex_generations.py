

# Generated at 2022-06-12 05:59:53.098445
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 05:59:55.615698
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor of :py:class:`ProgrammingError`.
    """
    error = ProgrammingError("Error")
    assert error


# Generated at 2022-06-12 05:59:58.627347
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-12 06:00:01.446150
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
    except ProgrammingError as e:
        assert "test" in str(e)
        return
    assert False

# Generated at 2022-06-12 06:00:13.280157
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest.mock import ANY, call
    from unittest import TestCase

    class MockTestCase(TestCase):
        # noinspection PyUnusedLocal
        def assertRaises(self, expected_exception, callable_obj=None, *args, **kwargs):
            return callable_obj(*args, **kwargs)

        # noinspection PyUnusedLocal
        def assert_exception(self, expected_exception, callable_obj):
            """
            Wrapper around :py:meth:`unittest.TestCase.assertRaises` which verify that the exception type is the
            expected one.
            """
            with self.assertRaises(expected_exception) as cm:
                callable_obj()
            # noinspection PyUnresolvedReferences

# Generated at 2022-06-12 06:00:15.419633
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True


# Generated at 2022-06-12 06:00:21.198475
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Expecting assert to pass
        ProgrammingError.passert(True, "Should not raise anything")
    except ProgrammingError as e:
        assert False, "The assert should have passed instead of raising a ProgrammingError"
    # Expecting an assert to fail
    try:
        ProgrammingError.passert(False, "Should raise a ProgrammingError")
        assert False, "The assert should have failed because condition is false"
    except ProgrammingError as e:
        assert True

# Generated at 2022-06-12 06:00:23.890315
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as ex:
        assert ex.args[0] == "This is a test."



# Generated at 2022-06-12 06:00:27.094625
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as error:
        ProgrammingError.passert(False, message="Testing message.")

    assert str(error.value) == "Testing message."

# Generated at 2022-06-12 06:00:28.821236
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some random message")
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:00:34.515805
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit tests the constructor of class :py:class:`ProgrammingError`

    :return: ``None``.
    """

    # Testing the constructor of the class raises a valid exception
    try:
        raise ProgrammingError("This is a programming error")
    except ProgrammingError as error:
        # Checking the message of the error is valid.
        assert error.args[0] == "This is a programming error"
    except Exception as error:
        # Checking the raised exception is of the correct type
        assert type(error) == ProgrammingError



# Generated at 2022-06-12 06:00:36.491672
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("TEST")
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:00:39.810661
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError() did not raise")


# Generated at 2022-06-12 06:00:41.360480
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("error")
    assert error.message == "error"

# Generated at 2022-06-12 06:00:44.629503
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "I am a unit test exception"
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as e:
        assert e.__str__() == msg


# Generated at 2022-06-12 06:00:46.821351
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing a programming error")
    except ProgrammingError as e:
        assert "Testing a programming error" == e.args[0]


# Generated at 2022-06-12 06:00:48.552252
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    raise ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-12 06:00:56.469622
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    def make_exception() -> None:
        raise ProgrammingError("foobar")

    def check_instance_attribute(inst: ProgrammingError, attr: str) -> None:
        assert getattr(inst, attr) is not None
        assert getattr(inst, attr) == str(inst)

    exc = make_exception()
    check_instance_attribute(exc, "message")

    exc = make_exception()
    check_instance_attribute(exc, "args")


# Generated at 2022-06-12 06:00:59.813564
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError()
    assert isinstance(exception, Exception)
    assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:01:02.197446
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Foo")
    except ProgrammingError as exc:
        assert exc.args[0] == "Foo"

# Generated at 2022-06-12 06:01:08.801383
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an exceptional condition.")

    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert e.__str__() == "This is an exceptional condition."


# Generated at 2022-06-12 06:01:11.790482
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="This is a programming error")
    except Exception as ex:
        assert ex is not None

# Unit tests for function ProgrammingError.passert

# Generated at 2022-06-12 06:01:13.691929
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Failing:")
    except ProgrammingError as e:
        assert str(e) == "Failing:"

# Generated at 2022-06-12 06:01:16.904455
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error occurred")
    except ProgrammingError as e:
        assert e.args[0] == "A programming error occurred"



# Generated at 2022-06-12 06:01:19.540463
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:01:24.821821
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the default constructor works properly.
    """
    error = ProgrammingError()

    assert str(error) == "Broken coherence. Check your code against domain logic to fix it."
    assert repr(error) == "ProgrammingError(Broken coherence. Check your code against domain logic to fix it.)"


# Generated at 2022-06-12 06:01:27.296832
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Error message") as exc:
        assert str(exc) == "Error message"



# Generated at 2022-06-12 06:01:30.313108
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError` constructor.
    """
    # Testing constructors
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        assert False

    try:
        ProgrammingError.passert(False, "Test error")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:01:34.004618
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This message should be seen!")
    except ProgrammingError as e:
        assert e.args == ("This message should be seen!",)
    else:
        assert False, "ProgrammingError not raised!"

# Generated at 2022-06-12 06:01:38.710086
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    # pylint: disable=unused-variable
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(error)


# Generated at 2022-06-12 06:01:48.673659
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit-test for :py:class:`ProgrammingError`."""
    try:
        raise ProgrammingError("test")
    except ProgrammingError as exception:
        assert exception.args[0] == "test"


# Generated at 2022-06-12 06:01:50.994192
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Foo")
    except ProgrammingError as exc:
        assert str(exc) == "Foo"

# Generated at 2022-06-12 06:01:51.602229
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assertTrue(True)

# Generated at 2022-06-12 06:02:00.564247
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test :py:method:`pypara.error.ProgrammingError.__init__`
    """
    # Calling the default constructor
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    # Calling constructor with a custom message
    try:
        raise ProgrammingError("This is a unit test")
    except ProgrammingError as e:
        assert e.args == ("This is a unit test",)


# Generated at 2022-06-12 06:02:04.195008
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Some message")
    except ProgrammingError as e:
        assert e.args[0], "Some message"
    else:
        assert False, "ProgrammingError was not raised."


# Generated at 2022-06-12 06:02:06.542464
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing message")
    except ProgrammingError as e:
        assert e.args[0] == "Testing message"


# Generated at 2022-06-12 06:02:09.777802
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:02:12.112082
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:02:14.070529
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Some message")


# Generated at 2022-06-12 06:02:16.632795
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:02:28.757504
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test ProgramminError")
    except ProgrammingError as e:
        assert str(e) == "Test ProgramminError"


# Generated at 2022-06-12 06:02:31.335904
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Error message") as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "Error message"

# Generated at 2022-06-12 06:02:42.634047
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] is None
    else:
        raise AssertionError("ProgrammingError() has not raised an exception")

    try:
        with raises(ProgrammingError):
            ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] is None
    else:
        raise AssertionError("passert() has not raised an exception")

    try:
        with raises(ProgrammingError):
            ProgrammingError.passert(False, "")
    except ProgrammingError as e:
        assert e.args[0] == ""
    else:
        raise AssertionError("passert() has not raised an exception")


# Generated at 2022-06-12 06:02:45.851696
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyBroadException
    try:
        raise ProgrammingError("Test error")
    except ProgrammingError:
        pass
    else:
        assert False, "Does not raise ProgrammingError"


# Generated at 2022-06-12 06:02:49.882293
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert str(e) == "Error message"


# Generated at 2022-06-12 06:02:52.511391
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Foo is not bar")
    except ProgrammingError as e:
        assert e.args == ("Foo is not bar",)


# Generated at 2022-06-12 06:02:53.101772
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError

# Generated at 2022-06-12 06:02:54.862449
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "foo")

# Generated at 2022-06-12 06:02:59.093075
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an assertion error.")
    except ProgrammingError as e:
        assert e.args[0] == "This is an assertion error."



# Generated at 2022-06-12 06:03:03.786062
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:func:`ProgrammingError` constructor.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert error.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-12 06:03:26.067369
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as error:
        assert error.args[0] == "Error message"


# Generated at 2022-06-12 06:03:28.196418
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error")
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:03:30.469720
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("sample")
    except ProgrammingError:
        pass



# Generated at 2022-06-12 06:03:33.596195
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except ProgrammingError:
        return
    assert False


# Generated at 2022-06-12 06:03:36.465724
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Can you see me?")
    except ProgrammingError as e:
        assert str(e) == "Can you see me?"



# Generated at 2022-06-12 06:03:39.103177
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-12 06:03:41.254562
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-12 06:03:43.838894
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Custom error message.")
    except ProgrammingError as e:
        assert str(e) == "Custom error message."



# Generated at 2022-06-12 06:03:51.624505
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an expected error.")
    except ProgrammingError as e:
        assert str(e) == "This is an expected error."
    else:
        assert False
    try:
        ProgrammingError.passert(True, "This is an expected error.")
    except ProgrammingError:
        assert False
    else:
        assert True
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False

# Generated at 2022-06-12 06:03:53.375527
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def raises():
        raise ProgrammingError()
    raises()


# Generated at 2022-06-12 06:04:36.685445
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # noinspection PyTypeChecker
        ProgrammingError(None)
    except TypeError:
        pass

# Generated at 2022-06-12 06:04:39.931121
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    try:
        raise ProgrammingError('test')
    except ProgrammingError:
        pass
    else:
        assert False, 'No exception was raised'


# Generated at 2022-06-12 06:04:42.401003
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "sample error")
    except ProgrammingError as e:
        assert str(e) == "sample error"
    else:
        assert False

# Generated at 2022-06-12 06:04:44.631980
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A message.")
    except ProgrammingError as error:
        assert error.args[0] == "A message."


# Generated at 2022-06-12 06:04:46.631224
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    except:
        assert False, 'Unexpected exception raised'


# Generated at 2022-06-12 06:04:51.895579
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests :py:class:`ProgrammingError`.
    """
    from pyassert import assert_that
    from pypara.common.exceptions import ProgrammingError

    try:
        ProgrammingError.passert(None, "Oops")
    except ProgrammingError as error:
        assert_that(str(error)).is_equal_to("Oops")

    try:
        ProgrammingError.passert(None, None)
    except ProgrammingError as error:
        assert_that(str(error)).is_equal_to("Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-12 06:04:53.601021
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Test")

# Generated at 2022-06-12 06:04:55.736576
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Incorrect message")
    except Exception as ex:
        assert str(ex) == "Incorrect message"


# Generated at 2022-06-12 06:04:57.448671
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:05:00.732569
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(ProgrammingError(), ProgrammingError)
    assert isinstance(ProgrammingError(''), ProgrammingError)
    assert isinstance(ProgrammingError('test message'), ProgrammingError)


# Generated at 2022-06-12 06:06:40.942478
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "This is a test"
    else:
        raise Exception("expecting exception of class ProgrammingError")


# Generated at 2022-06-12 06:06:42.776727
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Just testing this condition")

# Generated at 2022-06-12 06:06:50.998651
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as e:
        assert e.args[0] == "Message"
    assert ProgrammingError.passert(True, "Message") == None
    try:
        ProgrammingError.passert(False, "Message")
    except ProgrammingError as e:
        assert e.args[0] == "Message"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:07:01.120648
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from .python_nat.seqs import List
    from .python_nat.bools import True_, False_
    with raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False_, "This is an exception.")
    assert "This is an exception." in str(excinfo.value)
    with raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False_, None)
    assert "Broken coherence. Check your code against domain logic to fix it." in str(excinfo.value)
    with raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False_, "")
    assert "Broken coherence. Check your code against domain logic to fix it." in str(excinfo.value)

# Generated at 2022-06-12 06:07:10.659588
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Correct instantiation
    passert = ProgrammingError.passert
    passert(True, None)
    # Incorrect instantiation
    # noinspection PyTypeChecker
    try:
        passert(False, None)
    except ProgrammingError as e:
        print(f"Passed: {e!r}")
    else:
        raise RuntimeError
    try:
        passert(False, "Error message.")
    except ProgrammingError as e:
        print(f"Passed: {e!r}")
    else:
        raise RuntimeError
    try:
        passert(False, 42)
    except TypeError as e:
        print(f"Passed: {e!r}")
    else:
        raise RuntimeError

# Generated at 2022-06-12 06:07:13.519725
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("foo")
    except ProgrammingError as e:
        assert e.__str__() == "foo"


# Generated at 2022-06-12 06:07:16.490890
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:07:19.391007
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, match=r"Broken coherence. Check your code against domain logic to fix it."):
        ProgrammingError.passert(False, None)
    ProgrammingError.passert(True, None)

# Generated at 2022-06-12 06:07:23.163197
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor of class ProgrammingError.
    """
    error: ProgrammingError = ProgrammingError()
    assert str(error) == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-12 06:07:26.266371
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as ex:
        assert ex.args[0] == "This is a test"
