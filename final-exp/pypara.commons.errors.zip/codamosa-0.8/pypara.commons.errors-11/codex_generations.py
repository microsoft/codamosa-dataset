

# Generated at 2022-06-12 05:59:49.829391
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("Test exception message")
    assert "Test exception message" in str(exception)


# Generated at 2022-06-12 05:59:54.412193
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "An error message")
    except ProgrammingError as error:
        assert str(error) == "An error message"


# Generated at 2022-06-12 05:59:58.202161
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error. End of story.")
    except ProgrammingError as e:
        assert str(e) == "This is an error. End of story."


# Generated at 2022-06-12 06:00:01.445501
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test for :py:class:`ProgrammingError`."""
    try:
        ProgrammingError(message="message")
    except ProgrammingError as error:
        assert str(error) == "message"

# Generated at 2022-06-12 06:00:02.761839
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:00:06.624546
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Discarded coherence")
        assert False, "This code shouldn't have been reached"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:00:11.848782
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except Exception as error:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:00:15.018756
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Dummy message.")
    except ProgrammingError as e:
        pass
    assert e.args == ("Dummy message.",)

# Generated at 2022-06-12 06:00:19.154701
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Some message")
        ProgrammingError.passert(False, "Some message")
        assert False # We shouldn't reach here
    except ProgrammingError:
        assert True
    except Exception:
        assert False
    else:
        assert False

# Generated at 2022-06-12 06:00:22.692132
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    with ProgrammingError("This is a programming error!"):
        pass

    with ProgrammingError() as e:
        assert isinstance(e, ProgrammingError)

    with ProgrammingError() as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:00:32.010069
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Exercises the constructor of class ProgrammingError"""

    class Programmer:
        def __init__(self):
            this.message = None

        def foo(self):
            ProgrammingError.passert(True, self.message)

    ok = Programmer()
    ok.message = None
    ok.foo()

    nok = Programmer()
    nok.message = "I am broken"
    try:
        nok.foo()
        assert False, "ProgrammingError was not raised"
    except ProgrammingError as e:
        assert e.message == "I am broken"

if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-12 06:00:35.001859
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("Test exception.")
    assert exception is not None
    str_exception = ProgrammingError("Test exception.")
    assert exception.__str__() == str_exception.__str__()

# Generated at 2022-06-12 06:00:38.771144
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("this is a test")
        assert False
    except ProgrammingError as e:
        assert e.args and e.args[0] == "this is a test"


# Generated at 2022-06-12 06:00:39.812720
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError:
        pass

# Generated at 2022-06-12 06:00:43.126875
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("message")
        assert False, "ProgrammingError should not raise exceptions"
    except ProgrammingError as e:
        assert str(e) == "message"


# Generated at 2022-06-12 06:00:47.016166
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test error.")
        assert False, "ProgrammingError not raised"
    except ProgrammingError as ex:
        assert str(ex) == "This is a test error."
    assert ProgrammingError.passert(True, "This is a test error.") == None

# Generated at 2022-06-12 06:00:51.202156
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    try:
        ProgrammingError.passert(False, "You cannot instantiate a ProgrammingError on purpose!")
    except ProgrammingError:
        pass
    else:
        assert False, "You cannot instantiate a ProgrammingError on purpose!"

# Generated at 2022-06-12 06:01:00.987368
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.

    The test consists on checking that the constructor fails when it is expected and it is not failing if the condition
    is met.
    """

    # Arrange
    failed_message = "Expected error message"
    exception: Optional[ProgrammingError] = None

    # Act
    try:
        ProgrammingError.passert(False, failed_message)
    except ProgrammingError as error:
        exception = error

    # Assert
    assert exception
    assert failed_message in str(exception)

    # Act
    ProgrammingError.passert(True, "Unexpected error message")

    # Assert
    assert True

# Generated at 2022-06-12 06:01:01.918446
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("some message")

# Generated at 2022-06-12 06:01:05.547563
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence." in str(e)


# Generated at 2022-06-12 06:01:12.618804
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Program errors should provide a default message.
    """
    exception = ProgrammingError()
    assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."

    exception = ProgrammingError("Test")
    assert str(exception) == "Test"


# Generated at 2022-06-12 06:01:14.681333
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        ProgrammingError("hello")

# Generated at 2022-06-12 06:01:16.316968
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error.")
    except ProgrammingError as ex:
        assert ex.args == ("This is a programming error.",)

# Generated at 2022-06-12 06:01:21.612968
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Any message")
    except ProgrammingError as e:
        assert "Any message" == str(e)
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)

# Generated at 2022-06-12 06:01:25.411350
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "foo")
        assert False, "This should have raised an exception"
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:01:29.747006
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the functionality of the :py:class:`ProgrammingError` class.
    """
    from pypara.test.testing import assert_message
    assert_message(ProgrammingError, "ProgrammingError", ProgrammingError("ProgrammingError"))


# Generated at 2022-06-12 06:01:35.853404
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check that the exception is raised when the condition is false
    condition = False
    message = "Example message"
    try:
        ProgrammingError.passert(condition, message)
    except ProgrammingError as ex:
        assert str(ex) == message
    else:
        assert False, "The exception should have been raised."
    # Check that the exception is not raised when the condition is true
    condition = True
    ProgrammingError.passert(condition, message)

# Generated at 2022-06-12 06:01:38.826701
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)
        assert len(str(e)) == 0


# Generated at 2022-06-12 06:01:42.303286
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, None)
    assert str(excinfo.value) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:01:45.889284
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the construction of :py:class:`ProgrammingError` to ensure that it is working properly.
    """
    # Given

    # When
    with ProgrammingError(message="Test message"):
        pass

    # Then
    assert True


# Generated at 2022-06-12 06:01:52.959537
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        print(e)


# Generated at 2022-06-12 06:01:55.746749
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error message.")
    except ProgrammingError as e:
        assert e.args[0] == "This is an error message."


# Generated at 2022-06-12 06:01:59.786509
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Hello World")
        assert False, "The ProgrammingError should have been raised"
    except ProgrammingError as e:
        assert str(e) == "Hello World"

# Generated at 2022-06-12 06:02:02.714901
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing main constructor")
    except ProgrammingError as e:
        assert str(e) == "Testing main constructor"


# Generated at 2022-06-12 06:02:04.574781
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class :py:class:`ProgrammingError`.
    """
    ProgrammingError()

# Generated at 2022-06-12 06:02:07.178779
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Mocked error message")
    except ProgrammingError as error:
        assert isinstance(error, Exception)
        assert error.args[0] == "Mocked error message"



# Generated at 2022-06-12 06:02:10.642436
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something wrong")
    except ProgrammingError as ex:
        assert ex.args[0] == "Something wrong"


# Generated at 2022-06-12 06:02:12.158698
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error")
    except ProgrammingError:
        pass
    else:
        assert False, "Programming error not raised"


# Generated at 2022-06-12 06:02:15.422531
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Just Testing")
    except ProgrammingError as e:
        assert e.args[0] == "Just Testing"
    else:
        assert False, "Exception not raised"



# Generated at 2022-06-12 06:02:16.946342
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"



# Generated at 2022-06-12 06:02:28.654234
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Your program is broken.")
    except ProgrammingError as error:
        assert error.args == ("Your program is broken.",)

# Generated at 2022-06-12 06:02:37.147774
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Asserts that :py:class:`ProgrammingError` can be instantiated and that ``passert`` works properly.

    :raises AssertionError: In case that the test fails.
    """
    try:
        ProgrammingError.passert(condition=True, message="")
    except ProgrammingError:
        raise AssertionError("Unexpected instantiation of exception.")

    try:
        ProgrammingError.passert(condition=False, message="")
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(condition=True, message=None)
    except ProgrammingError:
        raise AssertionError("Unexpected instantiation of exception.")

    try:
        ProgrammingError.passert(condition=False, message=None)
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:02:46.417441
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Try to raise a ProgrammingError
    raised = False
    try:
        raise ProgrammingError("Condition 'not 1 == 2' not fulfilled")
    except ProgrammingError as e:
        # Check exception type
        assert isinstance(e, ProgrammingError)
        # Check exception message
        assert str(e) == "Condition 'not 1 == 2' not fulfilled"
        raised = True

    # Try to raise a ProgrammingError with passert
    raised = False
    try:
        ProgrammingError.passert(1 == 2, "Condition 'not 1 == 2' not fulfilled")
    except ProgrammingError as e:
        # Check exception type
        assert isinstance(e, ProgrammingError)
        # Check exception message
        assert str(e) == "Condition 'not 1 == 2' not fulfilled"
        raised = True

    # Check that it is not raised
    Programming

# Generated at 2022-06-12 06:02:50.866163
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the :py:class:`ProgrammingError` class.
    """
    assert ProgrammingError("error message").args == ("error message",)

# Generated at 2022-06-12 06:02:53.885419
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    except Exception as ex:
        raise AssertionError("Type of raised error is incorrect") from ex


# Generated at 2022-06-12 06:02:57.254573
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("Test")
    assert e.args[0] == "Test"



# Generated at 2022-06-12 06:03:00.403632
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something is wrong")
    except ProgrammingError as e:
        assert e.args[0] == "Something is wrong"


# Generated at 2022-06-12 06:03:07.101595
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # We expect a ProgrammingError to be raised when the condition is False
    failed = False
    try:
        ProgrammingError.passert(1==0, "Expected failure by raising ProgrammingError")
    except ProgrammingError:
        failed = True
    assert failed

    # We expect no ProgrammingError to be raised when the condition is True
    failed = False
    try:
        ProgrammingError.passert(1==1, "Expected a correct condition")
    except ProgrammingError:
        failed = True
    assert not failed

# Generated at 2022-06-12 06:03:09.645492
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara import ProgrammingError
    p = ProgrammingError()
    assert(p.args[0] == "Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-12 06:03:12.610710
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class MyError(ProgrammingError):
        pass

    try:
        raise MyError("foo")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError() not raised.")



# Generated at 2022-06-12 06:03:35.921594
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "This is a test")
    assert excinfo.value.args[0] == "This is a test"


# Generated at 2022-06-12 06:03:36.828470
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError: pass


# Generated at 2022-06-12 06:03:40.362059
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"
    else:
        raise AssertionError("Could not create ProgrammingError")


# Generated at 2022-06-12 06:03:42.455630
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara import ProgrammingError
    with raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-12 06:03:45.400917
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("error")
    except Exception as e:
        pass
    assert isinstance(e, ProgrammingError)


# Generated at 2022-06-12 06:03:47.652752
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message.")
    except ProgrammingError as e:
        assert str(e) == "Error message."


# Generated at 2022-06-12 06:03:50.578761
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    error_msg = "I am an error"

    # Act and assert
    try:
        raise ProgrammingError(error_msg)
    except ProgrammingError as ex:
        assert ex.__str__() == error_msg


# Generated at 2022-06-12 06:03:51.901855
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError:
        assert True

# Generated at 2022-06-12 06:03:56.502683
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hello World!")
    except ProgrammingError as err:
        assert str(err) == "Hello World!"
        assert not err.__cause__
        assert not err.__context__


# Generated at 2022-06-12 06:03:59.604470
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    raised = False
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError:
        raised = True
    assert raised, "Error not raised when trying to instantiate ProgrammingError."

# Generated at 2022-06-12 06:04:43.613531
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as _:
        pass
    else:
        raise AssertionError("No exception raised for empty instantiation")

# Generated at 2022-06-12 06:04:46.311888
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as error:
        raise ProgrammingError("Something bad happened.")
    assert error.value.args[0] == "Something bad happened."


# Generated at 2022-06-12 06:04:54.231053
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from hypothesis import given, strategies as st

    @given(st.booleans(), st.text())
    def test_passert(condition: bool, message: str) -> None:
        try:
            ProgrammingError.passert(condition, message)
        except ProgrammingError:
            if condition:
                raise
        else:
            if not condition:
                raise ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")

    test_passert()

# Generated at 2022-06-12 06:04:57.768833
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My error message")
    except ProgrammingError as e:
        assert e.args[0] == "My error message"
        assert isinstance(e, Exception)
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-12 06:05:00.628482
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-12 06:05:02.264213
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    _ = ProgrammingError("a", "b", "c")



# Generated at 2022-06-12 06:05:07.020576
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    from unittest import TestCase, main
    from random import sample

    class ProgrammingErrorTest(TestCase):

        def test_constructor(self):
            """Unit test for constructor of class ProgrammingError"""
            with self.assertRaises(ProgrammingError):
                ProgrammingError(message=None)

    main()

# Generated at 2022-06-12 06:05:10.858090
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error.")
    except ProgrammingError as e:
        assert str(e) == "This is a programming error."
        assert repr(e) == "ProgrammingError('This is a programming error.')"


# Generated at 2022-06-12 06:05:14.423904
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Test")
    except ProgrammingError as e:
        assert str(e) == "Test"
    else:
        assert False


# Generated at 2022-06-12 06:05:18.078469
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("this is a test")
    except ProgrammingError as e:
        assert str(e) == "this is a test"



# Generated at 2022-06-12 06:06:56.536626
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("message")
    assert error.args == ("message",)


# Generated at 2022-06-12 06:07:00.965858
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Type check
    type_check = lambda: ProgrammingError(message="Foo")
    # No parameter
    none_parameter = lambda: ProgrammingError()
    # Raises and checks exceptions
    assert raises(ProgrammingError, type_check) is True
    assert raises(TypeError, none_parameter) is True


# Generated at 2022-06-12 06:07:06.196923
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for :py:class:`ProgrammingError`.
    """
    from pypara.testing import TestCase

    class Testing(TestCase):
        def test_ProgrammingError(self):
            with self.assertRaises(ProgrammingError):
                raise ProgrammingError("This is a test")
    
    Testing().run()


# Generated at 2022-06-12 06:07:09.290876
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("This is a programming error!")
    assert isinstance(exception, ProgrammingError)
    assert str(exception) == "This is a programming error!"
    try:
        raise ProgrammingError("This is another programming error!")
    except ProgrammingError as exception:
        assert str(exception) == "This is another programming error!"


# Generated at 2022-06-12 06:07:18.190727
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the error is raised when expected.
    """
    # no error raised when condition is met
    ProgrammingError.passert(True, "This should not raise an error")

    # error raised when condition is not met
    try:
        ProgrammingError.passert(False, "This should raise an error")
    except ProgrammingError as pe:
        pass

    # error is raised with the message provided by the developer
    try:
        ProgrammingError.passert(False, "This should raise the error with my custom message")
    except ProgrammingError as pe:
        assert pe.args[0] == "This should raise the error with my custom message"

# Generated at 2022-06-12 06:07:22.104580
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Expectation is not met.")
    except ProgrammingError as e:
        assert str(e) == "Expectation is not met."

# Generated at 2022-06-12 06:07:24.564529
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("testing")
    except ProgrammingError as e:
        assert "testing" == str(e)


# Generated at 2022-06-12 06:07:28.587786
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected, actual = "Expected message", None
    try:
        raise ProgrammingError(expected)
    except ProgrammingError as e:
        actual = e.args[0]
    assert expected == actual


# Generated at 2022-06-12 06:07:29.051438
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    pass

# Generated at 2022-06-12 06:07:32.859068
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError("Custom message")
    except ProgrammingError as e:
        assert e.args[0] == "Custom message"
