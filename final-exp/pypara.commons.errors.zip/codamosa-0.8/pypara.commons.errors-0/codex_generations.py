

# Generated at 2022-06-12 05:59:54.070463
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("unit test message")
    except ProgrammingError as exc:
        assert str(exc) == "unit test message"


# Generated at 2022-06-12 05:59:58.257125
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests :py:class:`ProgrammingError` class."""
    try:
        ProgrammingError.passert(False, "A test message")
    except ProgrammingError as ex:
        assert ex.args == ("A test message",)

# Generated at 2022-06-12 06:00:00.345566
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Error!")
    except ProgrammingError:
        pass



# Generated at 2022-06-12 06:00:02.688773
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error message")
    except ProgrammingError as ex:
        assert str(ex) == "This is an error message"


# Generated at 2022-06-12 06:00:05.302098
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error.args is not None
    error = ProgrammingError("test")
    assert error.args[0] == "test"


# Generated at 2022-06-12 06:00:07.420471
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("foo")
    except ProgrammingError as e:
        assert str(e) == "foo"

# Generated at 2022-06-12 06:00:09.224837
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("foo")

# Generated at 2022-06-12 06:00:12.221826
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test")
    except ProgrammingError:
        pass
    else:
        raise RuntimeError("Did not catch ProgrammingError")


# Generated at 2022-06-12 06:00:14.912739
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Default message")
    except ProgrammingError as e:
        assert e.message == "Default message"


# Generated at 2022-06-12 06:00:16.641189
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()

# Generated at 2022-06-12 06:00:20.360692
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:00:22.540426
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError(message="This is an error")


# Generated at 2022-06-12 06:00:25.828238
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:00:31.741117
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    "Unit test for module :py:mod:`pypara.core.error`."
    cls = ProgrammingError
    try:
        cls.passert(False, "Some message.")
    except cls:
        pass
    else:
        raise Exception("Should have raised exception, but didn't.")
    try:
        cls.passert(True, "A message.")
    except cls:
        raise Exception("Shouldn't have raised exception, but did.")
    else:
        pass

# Generated at 2022-06-12 06:00:34.379163
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    except:
        raise AssertionError("Expected a ProgrammingError")



# Generated at 2022-06-12 06:00:40.360714
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    flag = True

    try:
        raise ProgrammingError()
    except Exception as e:
        if "Broken coherence" not in str(e):
            flag = False

    try:
        raise ProgrammingError("Testing this!")
    except Exception as e:
        if "Testing this!" not in str(e):
            flag = False

    assert flag


# Generated at 2022-06-12 06:00:42.369116
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "message"
    err = ProgrammingError(message)
    assert err.args[0] == message

# Generated at 2022-06-12 06:00:52.154979
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given
    cls = ProgrammingError
    # When
    exception1 = cls("Test")
    exception2 = cls("Test")
    exception3 = cls("Test 1")
    exception4 = cls("Test 2")
    # Then
    assert exception1.__repr__() == exception2.__repr__()
    assert exception1.__repr__() == exception3.__repr__()
    assert exception3.__repr__() != exception4.__repr__()
    assert repr(exception1) == repr(exception2)
    assert repr(exception1) == repr(exception3)
    assert repr(exception3) != repr(exception4)
    assert str(exception1) == str(exception2)

# Generated at 2022-06-12 06:01:00.314677
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Test simple constructor
    try:
        raise ProgrammingError("My message")
    except ProgrammingError as error:
        assert error.args[0] == "My message"
        assert str(error) == "My message"

    # Test passert
    try:
        ProgrammingError.passert(True, "My message")
    except ProgrammingError:
        assert False

    try:
        ProgrammingError.passert(False, "My message")
        assert False
    except ProgrammingError as error:
        assert error.args[0] == "My message"

# Generated at 2022-06-12 06:01:03.163099
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "Test error.")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Test error."

# Generated at 2022-06-12 06:01:08.693927
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"
    else:
        assert False, "ProgrammingError should have been thrown"

# Generated at 2022-06-12 06:01:09.868754
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Hello world")

# Generated at 2022-06-12 06:01:12.956303
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.

    :return: ``None``.
    """
    ProgrammingError(None)
    ProgrammingError(1)



# Generated at 2022-06-12 06:01:19.173953
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor of class :py:class:`ProgrammingError`.
    """
    # There's no need to test something more. The constructor only sets the message of the Exception class.
    # The class is just a decorator to the Exception class.
    try:
        raise ProgrammingError("test")
    except Exception as exc:
        assert exc.args[0] == "test"


# Generated at 2022-06-12 06:01:21.197825
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:01:27.349032
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error.")
    except Exception as e:
        if not isinstance(e, ProgrammingError):
            raise AssertionError("ProgrammingError should have raised.")
        if str(e) != "Some error.":
            raise AssertionError("ProgrammingError should have provided the correct error message.")


# Generated at 2022-06-12 06:01:30.087184
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing an error.")
    except ProgrammingError as pe:
        assert pe.args[0] == "Testing an error."

# Generated at 2022-06-12 06:01:32.745349
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-12 06:01:40.292851
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    exc = ProgrammingError("Test error message")
    assert str(exc) == "Test error message"
    assert repr(exc) == "<ProgrammingError: ProgrammingError('Test error message',)>"
    assert repr(ProgrammingError(ProgrammingError("Outer error"))) == "<ProgrammingError: ProgrammingError(" \
                                                                       "ProgrammingError('Outer error',),)>"

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Error message")
    ProgrammingError.passert(True, "Error message")
    ProgrammingError.passert(True, None)
    ProgrammingError.passert(False, None)

# Generated at 2022-06-12 06:01:42.154889
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("Testing!")

# Generated at 2022-06-12 06:01:48.275411
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        1 / 0
        raise AssertionError("This must not happen")
    except ProgrammingError as e:
        assert "1 / 0" in str(e)


# Generated at 2022-06-12 06:01:51.854195
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    try:
        raise ProgrammingError("XXX")
    except ProgrammingError as e:
        assert isinstance(e, Exception)
        assert e.args == ("XXX",)


# Generated at 2022-06-12 06:01:54.615340
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error.")
    except ProgrammingError as e:
        assert str(e) == "This is an error."

# Generated at 2022-06-12 06:01:57.212059
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message.")
    except ProgrammingError as error:
        assert "Test message." == error.message

# Generated at 2022-06-12 06:02:00.805999
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test Error Message")
    except ProgrammingError as e:
        assert e.args[0] == "Test Error Message"


# Generated at 2022-06-12 06:02:05.531139
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Try a condition that is not fulfilled (should raise the exception)
    try:
        ProgrammingError.passert(False, "Exception message.")
    except ProgrammingError as error:
        assert error.args == ("Exception message.",)

    # Try a condition that is fulfilled (should not raise the exception)
    ProgrammingError.passert(True, "Exception message.")



# Generated at 2022-06-12 06:02:07.970497
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError
    with raises(ProgrammingError):
        raise ProgrammingError("Bla")


# Generated at 2022-06-12 06:02:12.223995
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(None)
    except ProgrammingError as e:
        # TODO: Check the error message to assert that it is the default one.
        pass



# Generated at 2022-06-12 06:02:18.175579
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    # pylint: disable=unused-variable

    with ProgrammingError(None):
        pass

    with ProgrammingError("A message."):
        pass

    try:
        with ProgrammingError(None):
            raise ValueError("An error.")
    except ProgrammingError:
        pass
    except ValueError:
        assert False, "Wrong exception raised."

test_ProgrammingError()

# Generated at 2022-06-12 06:02:20.909649
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Fail")
        assert False
    except ProgrammingError as _:
        pass

# Generated at 2022-06-12 06:02:24.369328
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("the error message"):
        raise ProgrammingError("the error message")


# Generated at 2022-06-12 06:02:34.407042
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pyknow import Fact
    from pyknow.matchers import (
        W, P, T, K
    )
    # Domain logic
    class PriceCalculator:
        def calculate_price(self, customer_type, amount):
            return amount * (2 if self.has_discount(customer_type) else 1)
        def has_discount(self, customer_type):
            return customer_type == 'VIP'
    # Meta-programming
    test_calculator = PriceCalculator()
    test_fact = Fact(customer_type='VIP', amount=1)
    # to test:
    # ProgrammingError.passert(test_calculator.has_discount(test_fact.customer_type),
    #                          "Method has_discount should be provided with a fact about a customer

# Generated at 2022-06-12 06:02:37.283706
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something wrong")
    except ProgrammingError as e:
        assert "Something wrong", "Message does not match"


# Generated at 2022-06-12 06:02:40.276743
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is a message")
    except ProgrammingError as e:
        assert e.args == ("This is a message",)


# Generated at 2022-06-12 06:02:43.073507
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    # WHEN
    try:
        raise ProgrammingError("error message")
    # THEN
    except ProgrammingError as ex:
        assert (str(ex) == "error message")


# Generated at 2022-06-12 06:02:45.264879
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.api.exceptions import ProgrammingError

    ProgrammingError.passert(None, None)

# Generated at 2022-06-12 06:02:48.883728
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError.passert(False, "This is a test.")
    except ProgrammingError as e:
        assert str(e) == "This is a test."

# Generated at 2022-06-12 06:02:53.836673
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "MESSAGE")
        assert False
    except ProgrammingError as pe:
        assert repr(pe) == "ProgrammingError('MESSAGE')"
    except Exception:
        assert False
    else:
        assert False


# Generated at 2022-06-12 06:02:58.303156
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN-WHEN-THEN
    try:
        ProgrammingError.passert(True, None)
    except Exception:
        assert False, "Exception raised!"

# Generated at 2022-06-12 06:03:03.786314
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Asserts the behaviour of :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, None)
        raise AssertionError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:03:09.959049
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert "This is a test" == str(e)
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] is None
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)


# Generated at 2022-06-12 06:03:13.262215
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for :py:meth:`ProgrammingError.__init__`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert err.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:03:15.176161
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Something is wrong")
    assert error.args == ("Something is wrong",)

# Generated at 2022-06-12 06:03:17.663523
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError does not raise a ProgrammingError when instantiated"



# Generated at 2022-06-12 06:03:21.301240
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # when
    try:
        ProgrammingError("this is an error")  # pragma: no cover
    except ProgrammingError as error:
        # then
        assert error.args == ("this is an error",)

# Generated at 2022-06-12 06:03:22.946508
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    # Act
    err = ProgrammingError()
    # Assert
    assert isinstance(err, ProgrammingError)


# Generated at 2022-06-12 06:03:26.146415
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an error!")
    except ProgrammingError as e:
        assert str(e) == "This is an error!"
        return
    assert False, "No exception thrown!"


# Generated at 2022-06-12 06:03:27.316784
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        asse

# Generated at 2022-06-12 06:03:30.630810
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the constructor of the class :py:class:`ProgrammingError` works as expected.
    """
    assert str(ProgrammingError()) == "Broken coherence. Check your code against domain logic to fix it."
    assert str(ProgrammingError("Custom message")) == "Custom message"

# Generated at 2022-06-12 06:03:36.486319
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.testing import assert_exception_and_message

    # Check that our exception triggers an exception
    assert_exception_and_message(lambda: ProgrammingError.passert(False, "A message"), ProgrammingError, "A message")

    # Check that the method does not trigger an exception
    assert ProgrammingError.passert(True, "Another message") is None

# Generated at 2022-06-12 06:03:39.641628
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError(None):
        assert False

# Generated at 2022-06-12 06:03:42.119679
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test error")
        assert False
    except ProgrammingError as err:
        assert err.args[0] == "Test error"


# Generated at 2022-06-12 06:03:46.243838
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, match="Broken coherence. Check your code against domain logic to fix it."):
        raise ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-12 06:03:48.316449
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error has occurred.")
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:03:49.619990
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:03:56.409221
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test the passert method
    try:
        ProgrammingError.passert(True, None)
        assert True
    except ProgrammingError:
        assert False
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        assert True
    try:
        ProgrammingError.passert(False, "Message")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Message"

# Generated at 2022-06-12 06:03:59.096114
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "message")
    ProgrammingError.passert(True, "message")

# Generated at 2022-06-12 06:04:00.930411
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("msg")
    assert isinstance(error, ProgrammingError)
    print(error)


# Generated at 2022-06-12 06:04:05.004203
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        return
    assert False, "test_ProgrammingError() failed"


# Generated at 2022-06-12 06:04:09.203524
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="This is an error")
        raise Exception("The exception should have been raised")
    except ProgrammingError as e:
        assert str(e) == "This is an error"

# Generated at 2022-06-12 06:04:13.857590
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, message="it should rise an exception"):
        ProgrammingError.passert(False, "It is expected to rise an exception")

# Generated at 2022-06-12 06:04:19.935276
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # First, we try to raise it without message
        raise ProgrammingError()
    except ProgrammingError as pe:
        assert pe.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    try:
        # Second, we try to raise it with a message
        raise ProgrammingError("This is an error!")
    except ProgrammingError as pe:
        assert pe.args[0] == "This is an error!"


# Generated at 2022-06-12 06:04:22.594830
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error has occurred")
    except ProgrammingError as error:
        assert error.args[0] == "Some error has occurred"


# Generated at 2022-06-12 06:04:24.945177
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except BaseException as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-12 06:04:29.230861
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "This is an error.")
    assert excinfo.value.args == ("This is an error.",)
    assert str(excinfo.value) == "This is an error."

# Generated at 2022-06-12 06:04:33.243199
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ('Broken coherence. Check your code against domain logic to fix it.',)
        return
    assert False # The program should have raised an ProgrammingError.


# Generated at 2022-06-12 06:04:34.524712
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error

# Generated at 2022-06-12 06:04:37.074249
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)


# Generated at 2022-06-12 06:04:41.216324
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("TEST")
    assert error.args == ("TEST", )
    try:
        raise ProgrammingError("TEST")
    except Exception as e:
        assert type(e) is ProgrammingError
        assert e.args == ("TEST", )
    ProgrammingError.passert(False, "TEST")

# Generated at 2022-06-12 06:04:43.485772
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as ex:
        assert str(ex) == "Test"


# Generated at 2022-06-12 06:04:50.921552
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except Exception as e:
        assert(isinstance(e, ProgrammingError))


# Generated at 2022-06-12 06:04:53.008336
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert "This is a test." in e.args


# Generated at 2022-06-12 06:04:57.344616
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the error handling in case of an erroneous parameter type."""
    from pytest import raises
    from pypara.exceptions import ProgrammingError

    # Test 1: Object is not of type ProgrammingError
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Broken coherence")

# Generated at 2022-06-12 06:04:59.259487
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("test")
    assert error is not None
    assert str(error) == "test"

# Generated at 2022-06-12 06:05:00.471486
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is an error!")

# Generated at 2022-06-12 06:05:03.792610
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check that it raises a ProgrammingError
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as pe:
        assert pe.args[0] == "Some message"


# Generated at 2022-06-12 06:05:06.223371
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    _ = ProgrammingError("This is a programming error")
    pass


# Generated at 2022-06-12 06:05:08.387413
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This should be caught.")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError raised no exception.")

# Generated at 2022-06-12 06:05:11.889742
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as ex:
        assert str(ex) == "Message", "String representation of exception is not correct."


# Generated at 2022-06-12 06:05:16.023757
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    try:
        ProgrammingError.passert(False, "Hello, World!")
        raise AssertionError("An exception should have been raised previously.")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:05:25.172860
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Boo!")
    except ProgrammingError as e:
        assert str(e) == "Boo!"

# Generated at 2022-06-12 06:05:28.999677
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor of :py:mod:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("A programming error has occurred!")
    except ProgrammingError as err:
        print(err)


# Generated at 2022-06-12 06:05:31.897053
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    with ProgrammingError("Some message"):
        ProgrammingError("Some other message")

# Generated at 2022-06-12 06:05:36.008491
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("An exception just for testing purposes.")
    except ProgrammingError as e:
        if str(e) != "An exception just for testing purposes.":
            raise AssertionError("Unexpected error message.")


# Generated at 2022-06-12 06:05:37.093569
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("test")
    assert exception.message == "test"

# Generated at 2022-06-12 06:05:38.249492
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Just for testing purposes"):
        pass

# Generated at 2022-06-12 06:05:41.272546
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError("Exception raised")
    assert("Exception raised" in excinfo.value.args[0])

# Generated at 2022-06-12 06:05:45.448487
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    # Arrange
    msg = "A programming error occurred"

    # Act
    error = ProgrammingError(msg)

    # Assert
    assert error.args == (msg,)

# Test method passert in class ProgrammingError

# Generated at 2022-06-12 06:05:47.182332
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        return
    raise AssertionError()


# Generated at 2022-06-12 06:05:49.182597
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("The exception should be raised.")

# Generated at 2022-06-12 06:06:07.249211
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert type(e) == ProgrammingError


# Generated at 2022-06-12 06:06:08.683852
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence" in str(e)


# Generated at 2022-06-12 06:06:09.923141
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-12 06:06:12.267025
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Incoherence detected. Fix it!"):
        pass


# Generated at 2022-06-12 06:06:13.542024
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    ProgrammingError("A message")


# Generated at 2022-06-12 06:06:16.040325
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError() didn't raise a ProgrammingError.")


# Generated at 2022-06-12 06:06:17.916935
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "message"
    error = ProgrammingError(msg)
    assert error.args == (msg,)

# Generated at 2022-06-12 06:06:20.818127
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is the message")
    except ProgrammingError as e:
        assert str(e) == "This is the message"


# Generated at 2022-06-12 06:06:22.961167
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except Exception as e:
        assert e.args[0] == "This is an error"


# Generated at 2022-06-12 06:06:34.853046
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="foobar")
    except ProgrammingError as e:
        assert str(e) == "foobar"
    try:
        ProgrammingError.passert(condition=False, message="")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(condition=False, message=None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(condition=True, message="foobar")
    except ProgrammingError:
        assert False

# Generated at 2022-06-12 06:07:02.687288
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:07:08.271598
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError` class.
    """
    try:
        raise ProgrammingError("A programming error!")
    except ProgrammingError as err:
        assert str(err) == "A programming error!"
        assert isinstance(err, ProgrammingError)
        assert isinstance(err, Exception)


# Generated at 2022-06-12 06:07:09.643333
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Custom message")
    except ProgrammingError as e:
        assert str(e) == "Custom message"


# Generated at 2022-06-12 06:07:12.881735
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Error raised")
        assert False, "programming error did not raise"
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:07:15.053112
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
        assert False
    except ProgrammingError:
        assert True

# Generated at 2022-06-12 06:07:17.600245
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:07:22.679174
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Message")
    except ProgrammingError as e:
        assert False, "Should not raise a ProgrammingError."
    try:
        ProgrammingError.passert(False, "Message")
    except ProgrammingError as e:
        assert str(e) == "Message", "Should raise a ProgrammingError with the given message."
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it.",\
            "Should raise a ProgrammingError with the default message."

# Generated at 2022-06-12 06:07:23.949956
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-12 06:07:25.331378
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "Just a testing error")
    ProgrammingError.passert(1 == 2, "Just a testing error")
    ProgrammingError.passert(False, None)

# Generated at 2022-06-12 06:07:28.728030
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "This is a dummy error message"
    error = ProgrammingError(message)
    assert error.args[0] == message


# Unit tests for method passert of class ProgrammingError

# Generated at 2022-06-12 06:08:40.579069
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for class :py:class:`ProgrammingError`.

    :raise AssertionError: In case that the test fails.
    """
    try:
        ProgrammingError.passert(False, "failed")
    except ProgrammingError as e:
        assert str(e) == "failed"
    try:
        ProgrammingError.passert(True, "failed")
    except ProgrammingError as _e:
        assert False

# Generated at 2022-06-12 06:08:44.493795
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as e:
        ProgrammingError()
    assert e.type == ProgrammingError
    assert str(e.value) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:08:46.707218
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "Foo"
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as err:
        assert msg == err.args[0]


# Generated at 2022-06-12 06:08:48.545352
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "")
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "")

# Generated at 2022-06-12 06:08:50.191732
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:08:52.608475
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Ooops, I did it again.")
    assert error.args == ("Ooops, I did it again.",)


# Generated at 2022-06-12 06:08:58.935384
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Some message."
    ProgrammingError(message)
    with pytest.raises(ProgrammingError, message=message):
        ProgrammingError.passert(condition=False, message=message)
    ProgrammingError.passert(condition=True, message=None)
    with pytest.raises(ProgrammingError, message=None):
        ProgrammingError.passert(condition=False, message=None)

# Generated at 2022-06-12 06:09:02.749761
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # This is not a real unit test. The intention is to verify the error message.
    try:
        ProgrammingError(None)
        assert False, 'The exception should be raised.'
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it.", "Wrong message."


# Generated at 2022-06-12 06:09:05.547581
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except:
        assert False, "'ProgrammingError' failed."


# Generated at 2022-06-12 06:09:09.616488
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Testing the constructor of class ProgrammingError"""
    try:
        raise ProgrammingError() #pylint: disable=W0107
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
