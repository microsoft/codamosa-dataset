

# Generated at 2022-06-12 05:59:55.304436
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Assertion failed")
        assert False, "Exception has not been raised"
    except ProgrammingError as e:
        assert True, "Expected exception raised"
        assert e.args[0] == "Assertion failed", "Unexpected error message"
    finally:
        ProgrammingError.passert(True, "Assertion failed")

# Generated at 2022-06-12 05:59:58.311209
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "test"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert e.args == (message,)

# Generated at 2022-06-12 06:00:03.495086
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        assert True

    try:
        ProgrammingError.passert(False, "Hello")
        assert False
    except ProgrammingError as exc:
        assert str(exc) == "Hello"
        assert True

    ProgrammingError.passert(True, None)
    ProgrammingError.passert(True, "Hello")

# Generated at 2022-06-12 06:00:09.761178
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-12 06:00:13.273113
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Hello World")
    except ProgrammingError as e:
        assert e.args[0] == "Hello World"


# Generated at 2022-06-12 06:00:18.025777
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    try:
        # pylint: disable=unreachable
        ProgrammingError.passert(False, "This is a ProgrammingError")
        assert False, "Should have raised a ProgrammingError!"
    except ProgrammingError:
        assert True


# Generated at 2022-06-12 06:00:20.398260
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hello world")
    except ProgrammingError as e:
        assert "Hello world" in e.args[0]


# Generated at 2022-06-12 06:00:23.105458
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except Exception as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-12 06:00:31.632428
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(None)
    with pytest.raises(ProgrammingError):
        ProgrammingError("")
    with pytest.raises(ProgrammingError):
        ProgrammingError(" ")
    with pytest.raises(ProgrammingError):
        ProgrammingError(" a ")
    with pytest.raises(ProgrammingError):
        ProgrammingError("a")
    with pytest.raises(ProgrammingError):
        ProgrammingError("a ")
    with pytest.raises(ProgrammingError):
        ProgrammingError(" a")
    exception = ProgrammingError("  a  ")
    assert "a" == str(exception)


# Generated at 2022-06-12 06:00:34.657508
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Fail!")
    except ProgrammingError as err:
        assert str(err) == "Fail!"
    else:
        assert False


# Generated at 2022-06-12 06:00:38.918861
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-12 06:00:42.624322
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""

    class Test(ProgrammingError):
        """Test class for unit test."""

    with Test(None):
        pass
    with Test("testing") as e:
        assert str(e) == "testing"

# Generated at 2022-06-12 06:00:47.408668
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        raise ProgrammingError("For testing purposes")
    assert "For testing purposes" == str(excinfo.value)
    with pytest.raises(ProgrammingError) as excinfo:
        raise ProgrammingError()
    assert "Broken coherence. Check your code against domain logic to fix it." == str(excinfo.value)


# Generated at 2022-06-12 06:00:50.767228
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:00:59.068573
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
Proves that :py:class:`ProgrammingError` provides a meaningful exception with proper initialization.
    :return: ``None``
    """

    def _test(which, expected):
        try:
            raise ProgrammingError(which)
        except ProgrammingError as failed:
            actual = failed.args[0]
            assert actual == expected, f"Unexpected message for {which}. Found {actual} instead."

    _test("something went wrong", "something went wrong")
    _test("something else went wrong", "something else went wrong")



# Generated at 2022-06-12 06:01:01.032696
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        er = ProgrammingError()
        assert False, "Should not reach this point"
    except ProgrammingError as e:
        assert isinstance(e, Exception)
        assert isinstance(e, ProgrammingError)
        assert not isinstance(e, str)
        assert not isinstance(e, int)

# Unit tests for method passert of class ProgrammingError

# Generated at 2022-06-12 06:01:04.726008
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing the class")
    except ProgrammingError as error:
        assert error.args == ("Testing the class",)


# Generated at 2022-06-12 06:01:07.686704
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-12 06:01:11.187177
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except Exception as e:
        assert isinstance(e,ProgrammingError), "ProgrammingError constructor does not work"


# Generated at 2022-06-12 06:01:14.824909
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError, message="Should raise an exception"):
        raise ProgrammingError("Should raise an exception")

# Generated at 2022-06-12 06:01:19.971294
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("It is not working")
    except ProgrammingError as error:
        assert error.args == ("It is not working",)


# Generated at 2022-06-12 06:01:29.376245
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check that the standard constructor of the exception works properly
    assert issubclass(ProgrammingError, Exception)
    error = ProgrammingError()
    assert error.__cause__ is None
    assert error.__context__ is None
    assert error.__str__() == ""
    # Check that the constructor of the exception with a custom message works properly
    error = ProgrammingError(message="Bad mojo")
    assert error.__cause__ is None
    assert error.__context__ is None
    assert error.__str__() == "Bad mojo"

# Generated at 2022-06-12 06:01:33.091579
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the constructor of :py:class:`ProgrammingError` behaves as expected.
    """
    try:
        ProgrammingError("my message")
    except ProgrammingError as err:
        assert "my message" == str(err)

# Generated at 2022-06-12 06:01:33.962467
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "Failure")

# Generated at 2022-06-12 06:01:35.893970
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Unit test for constructor of class ProgrammingError. """
    assert ProgrammingError(message="error message")


# Generated at 2022-06-12 06:01:41.201271
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "It is not True")
        assert False, "Should not go here."
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, None)
        assert False, "Should not go here."
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(True, "It is True")
    except ProgrammingError:
        assert False, "Should not go here."

# Generated at 2022-06-12 06:01:49.768296
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` constructor.
    """
    from pypara.internal.testing import suite_parametrized, parametrize

    @suite_parametrized
    @parametrize(condition=True, message=None)
    @parametrize(condition=False, message=None)
    @parametrize(condition=True, message="foo")
    @parametrize(condition=False, message="foo")
    def _test(condition, message):
        """
        A parametrized test.
        """
        import pytest


# Generated at 2022-06-12 06:01:51.652121
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with assert_raises(ProgrammingError):
        ProgrammingError("some message")



# Generated at 2022-06-12 06:01:54.042668
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:02:02.127272
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test constructor of class ProgrammingError."""
    # Test a ProgrammingError
    try:
        ProgrammingError()
        assert False, "A ProgrammingError should have been raised"
    except ProgrammingError:
        pass

    # Test a ProgrammingError with a message
    try:
        ProgrammingError("Any message")
        assert False, "A ProgrammingError should have been raised"
    except ProgrammingError as error:
        assert error.args[0] == "Any message", "A ProgrammingError was raised with a wrong message"


# Generated at 2022-06-12 06:02:05.621056
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as err:
        assert str(err) == "Test"


# Generated at 2022-06-12 06:02:07.705183
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as ex:
        assert type(ex) is ProgrammingError
        assert not ex.args


# Generated at 2022-06-12 06:02:15.472433
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(1 == 1, "unit testing ProgrammingError")  # OK
    except ProgrammingError as error:
        assert False, f"unexpected programming error: {error}"
    try:
        ProgrammingError.passert(1 == 2, "unit testing ProgrammingError")  # Broken coherence
        assert False, "programming error was not raised"
    except ProgrammingError as error:
        assert True, f"expected programming error: {error}"

# Generated at 2022-06-12 06:02:16.562330
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:02:18.354712
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-12 06:02:21.009086
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError: #pylint: disable=C0103,W0703
        pass


# Generated at 2022-06-12 06:02:22.727227
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test if the constructor raises exception."""
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("")

# Generated at 2022-06-12 06:02:24.677667
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:02:28.194258
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of class ProgrammingError."""
    try:
        raise ProgrammingError("Mock ProgrammingError")
    except ProgrammingError as e:
        assert "Mock ProgrammingError" == e.args[0]


# Generated at 2022-06-12 06:02:30.761745
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): # type:ignore
    try:
        raise ProgrammingError("message")
    except ProgrammingError as error:
        assert error.args[0] == "message"

# Generated at 2022-06-12 06:02:37.101291
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Verifies that we can instantiate an instance.
    """
    error = ProgrammingError("Just a message for the error")

    assert error.args == ("Just a message for the error",)


# Generated at 2022-06-12 06:02:38.546194
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError._ProgrammingError__init__("test")


# Generated at 2022-06-12 06:02:41.137401
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.
    """
    assert ProgrammingError



# Generated at 2022-06-12 06:02:42.466280
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Expectation not met."):
        return 0

# Generated at 2022-06-12 06:02:44.989883
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("this is a test")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)



# Generated at 2022-06-12 06:02:50.180053
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, match="Broken coherence"):
        ProgrammingError()
    with pytest.raises(ProgrammingError, match="Message"):
        ProgrammingError("Message")


# Generated at 2022-06-12 06:02:52.757265
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Did not raise a ProgrammingError")


# Generated at 2022-06-12 06:02:55.591270
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if :py:class:`ProgrammingError` can be instantiated without errors.
    """
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:03:03.197726
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for class :py:class:`ProgrammingError`.
    """
    # Test constructor with no message
    with assert_raises(ProgrammingError):
        ProgrammingError()
    # Test constructor with message
    with assert_raises(ProgrammingError) as ctx:
        ProgrammingError("Incompatible with domain logic")
    assert_equal(str(ctx.exception), "Incompatible with domain logic")


# Generated at 2022-06-12 06:03:05.021645
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except Exception as e:
        assert e.__class__ is ProgrammingError


# Generated at 2022-06-12 06:03:09.402483
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert "test" in str(e)


# Generated at 2022-06-12 06:03:11.465515
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My programming error")
    except ProgrammingError as ex:
        assert str(ex) == "My programming error"

# Generated at 2022-06-12 06:03:14.961887
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Should fail.")
        assert(False and "We should never be here.")
    except ProgrammingError:
        pass
    ProgrammingError.passert(True, "Should pass.")
    try:
        ProgrammingError.passert(False, None)
        assert(False and "We should never be here.")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:03:17.474308
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert False, "The assertion should have happened"
    except ProgrammingError as error:
        assert True, "The assertion must happen"


# Generated at 2022-06-12 06:03:19.640792
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="Some error occurs.")
        assert True
    except ProgrammingError:
        assert False


# Generated at 2022-06-12 06:03:23.542383
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test_ProgrammingError")
    except ProgrammingError as e:
        assert e.args[0] == "test_ProgrammingError"


# Generated at 2022-06-12 06:03:30.005377
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        assert False, "ProgrammingError raised when it shouldn't"
    try:
        ProgrammingError.passert(False, None)
        assert False, "ProgrammingError not raised when it should"
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, "Not good")
        assert False, "ProgrammingError not raised when it should"
    except ProgrammingError as e:
        assert str(e) == "Not good", "ProgrammingError didn't return the expected message"

# Generated at 2022-06-12 06:03:32.256261
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if :py:meth:`test_ProgrammingError` works as expected.

    .. note:: An exception must be raised.
    """
    ProgrammingError.passert(False, "Test")

# Generated at 2022-06-12 06:03:35.599593
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError` for coverage purposes.

    :raises ProgrammingError: When the constructor is used to raise an exception.
    """
    raise ProgrammingError()


# Generated at 2022-06-12 06:03:40.121332
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)
    try:
        raise ProgrammingError("Ooops")
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "Ooops"


# Generated at 2022-06-12 06:03:53.863260
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=unused-variable
    try:
        ProgrammingError.passert(False, "A.B")
    except ProgrammingError as e:
        assert e.args[0] == "A.B"
    else:
        assert False
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False
    try:
        ProgrammingError.passert(True, "A.B")
    except ProgrammingError as e:
        assert False
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        assert False
    # pylint: enable=unused-variable

# Generated at 2022-06-12 06:03:55.732050
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()

# Generated at 2022-06-12 06:04:00.449388
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    # Expected behaviour
    ProgrammingError.passert(True, "")

    # Unexpected behaviour
    with raises(ProgrammingError):
        ProgrammingError.passert(False, None)

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "")

# Generated at 2022-06-12 06:04:12.133218
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test with the basic constructor
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    # Test with argument 'message', using the basic constructor
    message = "This is the message provided by the programmer."
    try:
        raise ProgrammingError(message)
    except ProgrammingError as ex:
        assert str(ex) == message
    # Test class method 'passert' with a bad condition
    message = "This is the message provided by the programmer."
    try:
        ProgrammingError.passert(False, message)
    except ProgrammingError as ex:
        assert ex is not None
        assert str(ex) == message
    # Test class method 'passert' with a good condition
    ProgrammingError.passert(True, None)

# Generated at 2022-06-12 06:04:16.818424
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # This code should not raise an exception
    ProgrammingError.passert(True, "nothing")

    # This code should raise an exception
    try:
        ProgrammingError.passert(False, "something")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Unreachable code")

# Generated at 2022-06-12 06:04:20.295579
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test case for :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    else:
        assert False

# Generated at 2022-06-12 06:04:23.631248
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError( "foo is not bar" )
    except ProgrammingError as pe:
        assert pe.msg == "foo is not bar"
    else:
        assert False, "Should have gotten here."


# Generated at 2022-06-12 06:04:28.099048
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    :py:class:`ProgrammingError` constructor test.
    """
    try:
        raise ProgrammingError("foo")
    except ProgrammingError as pe:
        assert str(pe) == "foo", "Actual: {}".format(str(pe))


# Generated at 2022-06-12 06:04:31.201596
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()

    assert error is not None
    assert error.args == ("Broken coherence. Check your code against domain logic to fix it.",)

# Generated at 2022-06-12 06:04:33.290748
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Just a test")
    except ProgrammingError as e:
        assert str(e) == "Just a test"

# Generated at 2022-06-12 06:04:45.905381
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("The condition is not met.")



# Generated at 2022-06-12 06:04:48.188793
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError
    """
    err_msg = "This is the error msg"
    error = ProgrammingError(err_msg)
    assert error.args[0] == err_msg


# Generated at 2022-06-12 06:04:52.578319
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "foo")
    except ProgrammingError as e:
        assert str(e) == "foo"


# Generated at 2022-06-12 06:04:55.521907
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as expected:
        assert isinstance(expected, ProgrammingError)
        assert str(expected) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:04:58.073774
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="Test")
    except ProgrammingError:
        return True
    assert False


# Generated at 2022-06-12 06:05:01.972684
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test.")
        raise Exception("Testing ProgrammingError failed.")
    except ProgrammingError as err:
        assert str(err) == "This is a test."



# Generated at 2022-06-12 06:05:06.096482
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # arrange
    actual_message = "Coherence error"

    # act
    try:
        raise ProgrammingError(actual_message)
    except ProgrammingError as err:
        actual = str(err)

    # assert
    assert actual == actual_message


# Generated at 2022-06-12 06:05:07.962499
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as error:
        assert isinstance(error, ProgrammingError)



# Generated at 2022-06-12 06:05:10.898817
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as error:
        assert isinstance(error, ProgrammingError)
        assert isinstance(error, Exception)


# Generated at 2022-06-12 06:05:13.605550
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("I am an invalid exception")
        assert False
    except TypeError:
        pass


# Generated at 2022-06-12 06:05:43.657006
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError("my message")
    except ProgrammingError as e:
        assert str(e) == "my message"


# Generated at 2022-06-12 06:05:46.005972
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError constructor test failed!"


# Generated at 2022-06-12 06:05:47.801361
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("this is an error")
    assert str(err) == "this is an error"

# Generated at 2022-06-12 06:05:52.599666
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor of :py:class:`ProgrammingError` class.
    """
    try:
        raise ProgrammingError("Something went wrong.")
    except ProgrammingError as e:
        assert str(e) == "Something went wrong."

# Unit tests for method ProgrammingError.passert

# Generated at 2022-06-12 06:05:55.270151
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from datetime import date

    date_today = date.today()
    ProgrammingError.passert(date_today.day < 31, "Date should be at most 1st of April.")

    try:
        ProgrammingError.passert(date_today.day > 7, "Date should be between 1st and 7th April.")
    except ProgrammingError as e:
        assert str(e) == "Date should be between 1st and 7th April."
    else:
        assert False, "No exception has been raised."

# Generated at 2022-06-12 06:05:57.012621
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    with ProgrammingError("Error") as exc:
        exc.__str__()

# Generated at 2022-06-12 06:06:03.589085
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test parameter 'condition' with True value
    ProgrammingError.passert(True, 'test')

    # Test parameter 'condition' with False value
    try:
        ProgrammingError.passert(False, 'test')
        assert False, 'An exception should have been raised'
    except ProgrammingError as e:
        assert e.args[0] == 'test', 'Wrong exception message'

    # Test parameter 'message' with None value
    try:
        ProgrammingError.passert(False, None)
        assert False, 'An exception should have been raised'
    except ProgrammingError as e:
        assert e.args[0] == 'Broken coherence. Check your code against domain logic to fix it.', 'Wrong exception message'

# Generated at 2022-06-12 06:06:12.856709
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Testing for instantiation
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise RuntimeError("Raising ProgrammingError during construction did not work")

    # Testing for instantiation
    try:
        ProgrammingError("Custom message")
    except ProgrammingError:
        pass
    else:
        raise RuntimeError("Raising ProgrammingError with custom message did not work")

    # Testing for passert without message
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    else:
        raise RuntimeError("Passertion with condition False and empty message does not raise an exception")

    # Testing for passert with message
    try:
        ProgrammingError.passert(False, "Custom message")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:06:15.803923
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Foo")
    except ProgrammingError as exception:
        assert str(exception) == "Foo"
    else:
        raise RuntimeError("Foo")

# Generated at 2022-06-12 06:06:18.795149
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Verify default message.
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:07:09.643908
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pickle
    try:
        raise ProgrammingError("This is a message.")
    except ProgrammingError as e:
        assert e.args[0] == "This is a message."
        assert type(e) == ProgrammingError
        assert pickle.loads(pickle.dumps(e)).args[0] == "This is a message."


# Generated at 2022-06-12 06:07:14.310840
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert type(e) is ProgrammingError
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "Exception not raised"


# Generated at 2022-06-12 06:07:15.451891
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="error message")


# Generated at 2022-06-12 06:07:17.999556
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except TypeError:
        return
    raise AssertionError("Empty constructor of class ProgrammingError must fail")



# Generated at 2022-06-12 06:07:18.491329
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test")

# Generated at 2022-06-12 06:07:24.308854
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test.")
        raise Exception("ProgrammingError not raised at all.")
    except ProgrammingError as e:
        if str(e) != "This is a test.":
            raise Exception("ProgrammingError raised but with an unexpected message.")



# Generated at 2022-06-12 06:07:28.354804
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test constructor of class ProgrammingError."""
    try:
        ProgrammingError.passert(False, "Hello")
    except ProgrammingError as e:
        assert str(e) == "Hello"


# Generated at 2022-06-12 06:07:32.161499
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected_message = "Broken coherence. Check your code against domain logic to fix it."
    error_raised = False
    try:
        ProgrammingError.passert(condition = False, message = None)
    except ProgrammingError as error:
        error_raised = True
        assert error.args[0] == expected_message
    assert error_raised

# Generated at 2022-06-12 06:07:34.673916
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)



# Generated at 2022-06-12 06:07:36.001590
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-12 06:09:34.757682
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "condition not met")
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError.passert does not raise the expected exception"

# Generated at 2022-06-12 06:09:38.267666
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of :py:class:`ProgrammingError`.

    :return: ``None``.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError("Some other error")
    except ProgrammingError as e:
        assert str(e) == "Some other error"



# Generated at 2022-06-12 06:09:45.315129
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for :py:class:`ProgrammingError`.

    :return: ``None``
    """

    from pytest import mark, raises

    @mark.parametrize("condition, message", [
        (True, None), (False, "message")
    ])
    def test_passert(condition, message):
        if condition:
            # Should not raise
            ProgrammingError.passert(condition, message)
        else:
            with raises(ProgrammingError):
                # Should raise
                ProgrammingError.passert(condition, message)

    test_passert()

# Generated at 2022-06-12 06:09:47.495873
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    assert ProgrammingError("foo") is not None
