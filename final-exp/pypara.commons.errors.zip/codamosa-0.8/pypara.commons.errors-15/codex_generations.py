

# Generated at 2022-06-12 05:59:49.599958
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError()
    assert type(e) == ProgrammingError
    assert e.args == ()
    assert str(e) == "<ProgrammingError: Broken coherence. Check your code against domain logic to fix it.>"

# Generated at 2022-06-12 05:59:54.508444
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test")
        assert False, "NaN"
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert e.args == ("Test",)


# Generated at 2022-06-12 05:59:57.532425
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error")
    except ProgrammingError as e:
        assert e.args[0] == "This is a programming error"


# Generated at 2022-06-12 05:59:58.046488
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("ProgrammingError Constructor and message")


# Generated at 2022-06-12 06:00:00.912500
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Verify that we can create an instance of ProgrammingError
    exception = ProgrammingError("test")
    assert exception.args[0] == "test"



# Generated at 2022-06-12 06:00:02.243290
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError:
        raise ProgrammingError("test")


# Generated at 2022-06-12 06:00:05.255219
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        assert value > 10
    except AssertionError:
        ProgrammingError.passert(False, "Any message")
    else:
        ProgrammingError.passert(True, "Any message")

# Generated at 2022-06-12 06:00:08.409752
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "The condition was not met")

# Generated at 2022-06-12 06:00:14.392485
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as error:
        assert str(error) == "test"
    ProgrammingError.passert(True, "test")
    try:
        ProgrammingError.passert(False, "test")
        assert False, "Should have raised an error above"
    except ProgrammingError as error:
        assert str(error) == "test"

# Generated at 2022-06-12 06:00:20.546212
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if the constructor behaves as expected.
    """
    # Check if the constructor works without arguments
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    # Check if the constructor works with arguments
    try:
        raise ProgrammingError("message")
    except ProgrammingError as e:
        assert str(e) == "message"



# Generated at 2022-06-12 06:00:25.204414
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError("TestMe")
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-12 06:00:31.841098
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hello world!")
    except ProgrammingError as e:
        assert str(e) == "Hello world!"
    assert ProgrammingError.passert(True, "Negative test case") is None
    try:
        ProgrammingError.passert(False, "Positive test case")
    except ProgrammingError as e:
        assert str(e) == "Positive test case"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:00:34.518967
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc = ProgrammingError()
    assert exc
    assert exc.args == ("Broken coherence. Check your code against domain logic to fix it.",)



# Generated at 2022-06-12 06:00:40.472704
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        assert False, "ProgrammingError.passert should not raise any exception when the condition was met."

    try:
        ProgrammingError.passert(False, "Condition was not met")
    except ProgrammingError as error:
        assert error.args == ("Condition was not met",), "Error has not the expected message"

# Generated at 2022-06-12 06:00:44.578819
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "Non-empty message not passed to exception."


# Generated at 2022-06-12 06:00:47.379602
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
        assert e.args[1:] == ()


# Generated at 2022-06-12 06:00:48.748013
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:00:52.260445
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    msg = "Programming error message"

    # Act
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as error:
        # Assert
        assert error.args[0] == msg

# Generated at 2022-06-12 06:00:54.817629
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-12 06:00:59.413675
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError
    """
    error = ProgrammingError()
    assert error.__str__() == "Broken coherence. Check your code against domain logic to fix it."
    error = ProgrammingError("message")
    assert error.__str__() == "message"


# Generated at 2022-06-12 06:01:04.490007
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class :py:class:`ProgrammingError`.
    """

    # Given
    condition = False

    # When
    try:
        ProgrammingError.passert(condition, 'Invalid parameters for configuration')
    except ProgrammingError as exception:
        # Then
        assert str(exception) == 'Broken coherence. Check your code against domain logic to fix it.'

# Generated at 2022-06-12 06:01:06.399626
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(message="test")


# Generated at 2022-06-12 06:01:10.201029
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Should raise")
        assert False, "Should have raised"
    except ProgrammingError:
        assert True
    # Nothing to test for the constructor without parameters.

# Generated at 2022-06-12 06:01:14.279104
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False, "An exception should have been raised with message 'Broken coherence'"
    except ProgrammingError as exc:
        assert str(exc) == "Broken coherence. Check your code against domain logic to fix it.", \
            "Exception raised but with wrong message"

# Generated at 2022-06-12 06:01:14.759587
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): ProgrammingError('test message')

# Generated at 2022-06-12 06:01:17.473066
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests function :py:func:`~pypara.common.errors.ProgrammingError.__init__`
    """
    ProgrammingError("Not met expectation")



# Generated at 2022-06-12 06:01:20.950811
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        msg = "Hello World!"
        ProgrammingError(msg)
        assert False
    except ProgrammingError as e:
        str(e)
        assert e.args[0] == msg


# Generated at 2022-06-12 06:01:24.225726
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an _exception_ test.")
    except ProgrammingError as error:
        assert str(error) == "This is an _exception_ test."


# Generated at 2022-06-12 06:01:32.993986
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(False, "foo")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "foo"

# Generated at 2022-06-12 06:01:41.799203
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test that ProgrammingError constructor with default message included works correctly.
    """
    from pytest import raises

    caught = None
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        caught = err
    assert caught is not None
    assert str(caught) == "Broken coherence. Check your code against domain logic to fix it."

    caught = None
    try:
        raise ProgrammingError("message")
    except ProgrammingError as err:
        caught = err
    assert caught is not None
    assert str(caught) == "message"

    caught = None
    try:
        ProgrammingError.passert(False, "message")
    except ProgrammingError as err:
        caught = err
    assert caught is not None
    assert str(caught) == "message"

    caught = None

# Generated at 2022-06-12 06:01:48.377592
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """This test checks that the constructor of :py:class:`ProgrammingError` works as expected."""
    pe1 = ProgrammingError("This is a test.")
    assert str(pe1) == "This is a test."

# Generated at 2022-06-12 06:01:50.620592
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError, match="some error message"):
        raise ProgrammingError("some error message")


# Generated at 2022-06-12 06:01:55.080685
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    This test verifies that the constructor of :py:class:`ProgrammingError` fulfils its contract.

    :return: ``None`` if the test is successful.
    """

    # Verify that we can construct an exception with no message
    _ = ProgrammingError()

    # Verify that we can construct an exception with a message
    _ = ProgrammingError("This is a test message.")

# Generated at 2022-06-12 06:01:59.194497
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(None)
        assert False, "Exception not raised."
    except ProgrammingError as e:
        assert True, "Exception raised."


# Run the unit test for class ProgrammingError

# Generated at 2022-06-12 06:02:02.176199
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="This is the error message")
        assert False
    except ProgrammingError:
        pass
    assert True

# Generated at 2022-06-12 06:02:04.051783
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)

# Generated at 2022-06-12 06:02:07.856896
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")
        assert False, "An exception should have been raised."
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:02:13.525470
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise Exception("Test has not failed as expected")

# Generated at 2022-06-12 06:02:17.558951
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError("Test error")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Did not raise expected ProgrammingError")


# Generated at 2022-06-12 06:02:20.467167
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("I'm an exception")

    assert err.args[0] == "I'm an exception"


# Generated at 2022-06-12 06:02:27.497379
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-12 06:02:32.216953
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test error message")
    except ProgrammingError as e:
        if e.args[0] != "Test error message":
            raise AssertionError("ProgrammingError constructor was not properly initialized.")
        else:
            print("Test succeeded.")
if __name__ == '__main__':
    test_ProgrammingError()

# Generated at 2022-06-12 06:02:34.532385
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Foo")
    except Exception:
        assert True
    else:
        assert False

# Generated at 2022-06-12 06:02:41.719246
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    cls = ProgrammingError
    # Assert
    assert cls.passert(True, None) is None
    assert cls.passert(False, None) is None
    assert cls.passert(True, "") is None
    assert cls.passert(False, "") is None
    assert cls.passert(True, "abc") is None
    assert cls.passert(False, "abc") is None


# Generated at 2022-06-12 06:02:43.841830
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-12 06:02:46.417132
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    :return:
    """
    try:
        raise ProgrammingError("TEST")
    except Exception as e:
        if isinstance(e, ProgrammingError):
            print("Success!")

# Generated at 2022-06-12 06:02:48.884773
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test error")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:02:51.405305
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("error message")
    assert str(exception) == "error message"



# Generated at 2022-06-12 06:02:58.806035
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Unit test for constructor of class ProgrammingError. """
    try:
        ProgrammingError.passert(True, "")
    except Exception:
        raise AssertionError("ProgrammingError.passert() should be silent when condition is True")

    try:
        ProgrammingError.passert(False, "Incorrect number of arguments")
        raise AssertionError("ProgrammingError.passert() hasn't raised an exception when condition is False")
    except ProgrammingError as ex:
        if str(ex) == "Broken coherence. Check your code against domain logic to fix it.":
            rai

# Generated at 2022-06-12 06:03:04.304539
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the exception class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Test exception.")
    except Exception as exc:
        assert isinstance(exc, ProgrammingError)
        assert "ProgrammingError" in str(exc)
        assert "Test exception." in str(exc)


# Generated at 2022-06-12 06:03:16.591959
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert error


# Generated at 2022-06-12 06:03:19.783008
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")
    except ProgrammingError as ex:
        assert ex.args[0] == "Test message"


# Generated at 2022-06-12 06:03:21.524407
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "Message")

# Generated at 2022-06-12 06:03:23.148372
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Foo")
    except ProgrammingError as e:
        assert str(e) == "Foo"

# Generated at 2022-06-12 06:03:28.327473
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    try:
        ProgrammingError.passert(False, "message")
        assert False, "Exception should have been raised."
    except ProgrammingError as ex:
        assert str(ex) == "message", "Unexpected exception message."
    except Exception as ex:
        assert False, "Unexpected exception of type {}.".format(ex.__class__.__name__)



# Generated at 2022-06-12 06:03:30.115601
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("New exception")
    except ProgrammingError as e:
        assert str(e) == "New exception"

# Generated at 2022-06-12 06:03:35.948851
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "This is an expected error")
    except ProgrammingError:
        assert False, "My custom exception does not work at all!"

    try:
        ProgrammingError.passert(False, "This is an expected error")
        assert False, "My custom exception does not work at all!"

    except ProgrammingError as ex:
        assert str(ex) == "This is an expected error", \
            "my custom exception does not have the expected message"

    try:
        ProgrammingError.passert(False, None)
        assert False, "My custom exception does not work at all!"

    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it.", \
            "my custom exception does not have the default message"

# Generated at 2022-06-12 06:03:36.874431
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    raise ProgrammingError("Testing")

# Generated at 2022-06-12 06:03:39.640785
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing...")
    except ProgrammingError as e:
        assert str(e) == "Testing..."


# Generated at 2022-06-12 06:03:40.971336
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is a simple test")


# Generated at 2022-06-12 06:04:04.386448
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test for error")

# Generated at 2022-06-12 06:04:07.350283
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)


# Generated at 2022-06-12 06:04:11.111312
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    # WHEN
    # THEN
    exception = ProgrammingError("My message")

    # GIVEN
    # WHEN
    # THEN
    assert str(exception) == "My message"



# Generated at 2022-06-12 06:04:15.328468
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Not important.")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:04:20.153573
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:04:22.452110
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert "Test message" == str(e)


# Generated at 2022-06-12 06:04:23.446899
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is the error message")


# Generated at 2022-06-12 06:04:26.525320
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the exception class.

    :return: ``None``.
    """

    ProgrammingError("This is a test.")

# Generated at 2022-06-12 06:04:34.801460
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class AnyProgrammingError(ProgrammingError):
        pass

    # Should not raise exception
    ProgrammingError.passert(True, "This is an assertion")

    # Should raise exception
    try:
        ProgrammingError.passert(False, "This is an assertion")
        assert (False)
    except ProgrammingError:
        pass
    else:
        assert (False)

    try:
        AnyProgrammingError.passert(False, "This is an assertion")
        assert (False)
    except ProgrammingError:
        pass
    else:
        assert (False)

# Generated at 2022-06-12 06:04:40.928440
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
        assert False, "Should have raised an Exception"
    except ProgrammingError:
        assert True
    try:
        ProgrammingError.passert(False, "test")
        assert False, "Should have raised an Exception"
    except ProgrammingError:
        assert True
    try:
        ProgrammingError.passert(True, "")
        assert True
    except ProgrammingError:
        assert False, "Should have not raised an Exception"

# Generated at 2022-06-12 06:05:34.215549
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Let's check the base constructor
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False

    # Let's check the constructor with a message
    try:
        ProgrammingError("foo")
    except ProgrammingError as ex:
        assert ex.args[0] == "foo"
    else:
        assert False

    # We are finally going to use the passert() method
    try:
        ProgrammingError.passert(True, "foo")
        ProgrammingError.passert(False, "bar")
    except ProgrammingError as ex:
        assert ex.args[0] == "bar"
    else:
        assert False

# Generated at 2022-06-12 06:05:36.354907
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)

# Generated at 2022-06-12 06:05:38.383681
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("I cannot do that, Dave.")
    except ProgrammingError as e:
        assert str(e) == "I cannot do that, Dave."

# Generated at 2022-06-12 06:05:41.039231
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, 'Testing exception')
        assert False
    except ProgrammingError:
        assert True

# Generated at 2022-06-12 06:05:42.494645
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Message")
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:05:44.952333
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Exception not raised"


# Generated at 2022-06-12 06:05:50.941988
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Case: Right usage
    try:
        ProgrammingError.passert(False, "Error message")
        assert False, "Should not reach this code because an exception should be raised"
    except ProgrammingError as e:
        assert str(e) == "Error message"

    # Case: Invalid usage (1)
    try:
        ProgrammingError.passert(True, "Error message")
        assert False, "Should not reach this code because an exception should be raised"
    except ProgrammingError as e:
        assert False, f"Should not raise an exception but it did:\n{str(e)}"

    # Case: Invalid usage (2)

# Generated at 2022-06-12 06:05:53.548951
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-12 06:05:55.617860
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError) as e:
        raise ProgrammingError()


# Generated at 2022-06-12 06:05:58.607243
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test message")
        assert False
    except ProgrammingError as e:
        assert str(e) == "test message"



# Generated at 2022-06-12 06:07:38.392632
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "This test is failing on purpose")

# Generated at 2022-06-12 06:07:47.609923
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Define test cases
    test_cases = [
        (None, "Broken coherence. Check your code against domain logic to fix it."),
        ("algo", "algo"),
        ("", "Broken coherence. Check your code against domain logic to fix it."),
    ]

    # Iterate over test cases
    for test_case in test_cases:
        # Invoke function
        try:
            raise ProgrammingError(test_case[0])
        except ProgrammingError as e:
            # Check if the exception is properly propagated
            assert str(e) == test_case[1]

# Generated at 2022-06-12 06:07:49.922411
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("test message")
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-12 06:07:52.237650
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:07:53.158654
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("") is not None


# Generated at 2022-06-12 06:07:55.665535
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test exception") # type: ignore
    except ProgrammingError as e:
        assert str(e) == "Test exception"


# Generated at 2022-06-12 06:08:00.137138
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test suite for the constructor of class ProgrammingError.
    """
    try:
        ProgrammingError('foobar')
        assert(False)
    except ProgrammingError as err:
        assert(err.args[0] == 'foobar')


# Generated at 2022-06-12 06:08:04.746618
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test error")
    except ProgrammingError as e:
        assert str(e) == "Test error", f"{str(e)} != 'Test error'"
    else:
        raise ValueError("ProgrammingError should have been raised.")

# Generated at 2022-06-12 06:08:07.091346
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if :py:class:`ProgrammingError` is correctly defined.
    """
    assert issubclass(ProgrammingError, Exception)

# Unit tests for passert class method of class ProgrammingError

# Generated at 2022-06-12 06:08:11.166626
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert ex.args[0] == "Broken coherence. Check your code against domain logic to fix it."
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."

test_ProgrammingError()
