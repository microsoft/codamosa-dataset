

# Generated at 2022-06-12 05:59:50.425128
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Some message")
    except ProgrammingError as pe:
        assert pe.args[0] == "Some message"
    try:
        raise ProgrammingError()
    except ProgrammingError as pe:
        assert pe.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 05:59:56.039782
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Check this")
        assert False, "ProgrammingError not raised"
    except ProgrammingError as pe:
        assert pe.args[0] == "Check this", "Sending a message to the class constructor does not behave as expected"


# Generated at 2022-06-12 05:59:59.036315
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message.")
    except ProgrammingError as e:
        assert str(e) == "Error message."


# Generated at 2022-06-12 06:00:00.681919
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    x = ProgrammingError("Message")
    assert x.args == ("Message", )

# Generated at 2022-06-12 06:00:03.265320
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    assert "You should not see this" != ProgrammingError("You should not see this").args[0]


# Generated at 2022-06-12 06:00:04.235476
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("An example of a ProgrammingError")


# Generated at 2022-06-12 06:00:09.226071
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Some error message")
        assert False
    except ProgrammingError as e:
        assert e.args == ("Some error message",)
        assert str(e) == "Some error message"
    else:
        assert False

# Generated at 2022-06-12 06:00:11.305784
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(condition=False,message="Programming error in unit test"):
        pass
    pass

# Generated at 2022-06-12 06:00:16.305279
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert type(e) is ProgrammingError
        assert not e.__traceback__

    try:
        ProgrammingError("message")
    except Exception as e:
        assert type(e) is ProgrammingError
        assert not e.__traceback__



# Generated at 2022-06-12 06:00:19.671010
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(None)
        ProgrammingError("")
        ProgrammingError(" ")
        ProgrammingError("a")
        ProgrammingError("a b")
        ProgrammingError("a b c")
    except:
        assert False

# Generated at 2022-06-12 06:00:24.682101
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error; this is only a test.")
    except ProgrammingError as exception:
        assert isinstance(exception, ProgrammingError)
        assert exception.args[0] == "This is an error; this is only a test."

# Generated at 2022-06-12 06:00:26.122601
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Boo!")

# Generated at 2022-06-12 06:00:27.314410
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-12 06:00:30.358335
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    ProgrammingError("Test")


# Generated at 2022-06-12 06:00:35.207549
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Case 1: Check non-existence of error
    try:
        ProgrammingError.passert(True, "Foo")
    except ProgrammingError:
        assert False

    # Case 2: Check existence of error
    try:
        ProgrammingError.passert(False, "Foo")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Foo"

# Generated at 2022-06-12 06:00:38.256089
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc = ProgrammingError("This is a message")
    assert exc.args[0] == "This is a message"


# Generated at 2022-06-12 06:00:39.608626
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Not really a programming error"):
        pass

# Generated at 2022-06-12 06:00:42.114908
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Act
    test_err = ProgrammingError("Test error")

    # Assert
    assert test_err.message == "Test error"

# Generated at 2022-06-12 06:00:43.682017
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:00:48.207264
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        assert False, "This code should never execute."
    try:
        ProgrammingError.passert(False, None)
        assert False, "This code should never execute."
    except ProgrammingError as e:
        assert None is e.args[0], "An error was raised but the message is not correct."



# Generated at 2022-06-12 06:00:58.958188
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase, main as unitTest

    class _ProgrammingErrorTest(TestCase):

        def test_passert(self):
            with self.assertRaisesRegex(ProgrammingError, "Check your code against domain logic to fix it."):
                ProgrammingError.passert(False, None)
            with self.assertRaisesRegex(ProgrammingError, "My message."):
                ProgrammingError.passert(False, "My message.")

    unitTest()

if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-12 06:01:02.759785
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of class ProgrammingError.

    :return: ``None``.
    """
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as err:
        assert str(err) == "A message"
        return
    assert False


# Generated at 2022-06-12 06:01:05.641096
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the constructor of class :py:class:`ProgrammingError`.
    """
    assert ProgrammingError("Something is wrong")


# Generated at 2022-06-12 06:01:09.011217
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError()

    with raises(ProgrammingError):
        raise ProgrammingError('error message')


# Generated at 2022-06-12 06:01:11.592309
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try :
        ProgrammingError("Test message")
    except ProgrammingError as e:
        assert(str(e) == "Test message")


# Generated at 2022-06-12 06:01:13.163551
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    raises(ProgrammingError, lambda: ProgrammingError(None))


# Generated at 2022-06-12 06:01:14.823580
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test")


# Generated at 2022-06-12 06:01:16.179392
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("error")
    except ProgrammingError as e:
        assert str(e) == "error"

# Generated at 2022-06-12 06:01:19.577224
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exp_msg = "Expectation not met: oops!"
    try:
        raise ProgrammingError(exp_msg)
    except ProgrammingError as e:
        assert e.args[0] == exp_msg


# Generated at 2022-06-12 06:01:22.620608
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    p = ProgrammingError("An error message")
    assert p.args[0] == "An error message"


# Generated at 2022-06-12 06:01:29.559512
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing ProgrammingError with message=Testing ProgrammingError with message.")
    except ProgrammingError as e:
        assert e.args[0] == "Testing ProgrammingError with message=Testing ProgrammingError with message."


# Generated at 2022-06-12 06:01:31.515212
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence" in str(e)


# Generated at 2022-06-12 06:01:32.861958
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("message")
    assert exception.args[0] == "message"


# Generated at 2022-06-12 06:01:33.423044
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test")

# Generated at 2022-06-12 06:01:36.016715
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # noinspection PyStatementEffect
        ProgrammingError()
        raise RuntimeError("ProgrammingError() was not supposed to pass")
    except TypeError:
        pass

# Generated at 2022-06-12 06:01:38.598346
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as ex:
        assert (ex.args == ("",))


# Generated at 2022-06-12 06:01:41.266483
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Hello, World!")
    except ProgrammingError as e:
        assert e.args[0] == "Hello, World!"


# Generated at 2022-06-12 06:01:42.635746
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(condition=False, message="This is a test.")

# Generated at 2022-06-12 06:01:46.714000
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # GIVEN a non empty message
    message = "An error message"

    # WHEN we run the constructor
    error = ProgrammingError(message)

    # THEN the message is properly returned
    assert error.message == message

# Generated at 2022-06-12 06:01:50.031418
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError.__init__ should have raised a ProgrammingError without arguments.")


# Generated at 2022-06-12 06:02:03.224952
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # We test that the message is correctly set
    try:
        raise ProgrammingError("My message")
    except ProgrammingError as error:
        assert error.args[0] == "My message"


# Generated at 2022-06-12 06:02:07.065203
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="foo")
    except ProgrammingError as e:
        assert str(e) == "foo"
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:02:13.803276
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for class :py:class:`ProgrammingError`.

    :return: ``None``.
    """
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError("Error message.")

    with raises(ProgrammingError):
        raise ProgrammingError()

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Hi!")

# Generated at 2022-06-12 06:02:16.376848
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-12 06:02:19.823764
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase
    from unittest.mock import Mock
    from typing import Optional

    class ProgrammingErrorTest(TestCase):
        def test_constructor(self):
            # Programmer error!
            ProgrammingError.passert(False, "Unit test message")

    # Execute the test
    ProgrammingErrorTest().test_constructor()

# Generated at 2022-06-12 06:02:22.726436
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("passert is broken")
    except ProgrammingError:
        pass  # This is OK
    else:
        assert False, "Strange. ProgrammingError constructor does not raise error."


# Generated at 2022-06-12 06:02:26.303607
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Check that no exception is raised by the :py:func:`passert` method if the condition is ``True``.
    """
    ProgrammingError.passert(True, "Should not fail")


# Generated at 2022-06-12 06:02:26.845352
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-12 06:02:28.789742
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for :py:class:`ProgrammingError`.
    """
    ProgrammingError("This is a programming error!")

# Generated at 2022-06-12 06:02:31.724795
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("test")
    assert exception.args[0] == exception.__str__() == "test"
    assert exception.__doc__ is not None

# Generated at 2022-06-12 06:02:54.629717
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programmer, check your code.")
    except ProgrammingError as pe:
        assert str(pe) == "Programmer, check your code."


# Generated at 2022-06-12 06:02:58.664324
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "error 1")
    except ProgrammingError as e:
        assert str(e) == "error 1"


# Generated at 2022-06-12 06:03:05.343918
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError
    """
    # Test default message
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."
    # Test explicit message
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as ex:
        assert str(ex) == "Message"

# Generated at 2022-06-12 06:03:07.257420
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test message") as error:
        assert error.__str__() == "Test message"

# Generated at 2022-06-12 06:03:08.085407
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test error")



# Generated at 2022-06-12 06:03:10.226096
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="Some error message")
    except ProgrammingError as e:
        assert str(e) == "Some error message"
    else:
        raise AssertionError("ProgrammingError should raise exception given the wrong message")


# Generated at 2022-06-12 06:03:12.383381
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as error:
        assert error.args[0] == "Some message"


# Generated at 2022-06-12 06:03:15.360673
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test constructs correctly with given message
    expected_message = "This is an expected error"
    given_error = ProgrammingError(expected_message)
    assert given_error.args[0] == expected_message
    # Test constructs correctly with no arguments
    given_error = ProgrammingError()
    assert given_error.args is None


# Generated at 2022-06-12 06:03:17.052872
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("This is a test error")
    assert exception.args == ("This is a test error",)

# Generated at 2022-06-12 06:03:19.545300
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("test message")
    assert isinstance(error, Exception)
    assert str(error) == "test message"


# Generated at 2022-06-12 06:04:05.051844
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as prog_error:
        TestingError.passert(False, "Testing reason")
    assert str(prog_error.value) == "Testing reason"

# Generated at 2022-06-12 06:04:08.243451
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is a message.")
    assert(isinstance(error, Exception))
    assert(str(error) == "This is a message.")


# Generated at 2022-06-12 06:04:09.449599
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="Test")


# Generated at 2022-06-12 06:04:12.086161
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class.
    """
    # Act
    error = ProgrammingError()

    # Assert
    assert isinstance(error, Exception)
    assert error.args == tuple()


# Generated at 2022-06-12 06:04:13.332739
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:04:15.128444
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("hello world")


# Generated at 2022-06-12 06:04:21.070723
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e.args[0], str)
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    except Exception:
        raise
    else:
        raise Exception("test_ProgrammingError: did not raise ProgrammingError")


# Generated at 2022-06-12 06:04:23.631889
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test failure")
    except ProgrammingError as e:
        assert e.args == ('Test failure',)



# Generated at 2022-06-12 06:04:25.032764
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("Just a message")


# Generated at 2022-06-12 06:04:27.957256
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("It's a programming error")
    except ProgrammingError as e:
        assert "It's a programming error" == str(e)


# Generated at 2022-06-12 06:06:05.249621
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        # noinspection PyUnresolvedReferences
        assert e.args[0] is None


# Generated at 2022-06-12 06:06:07.674973
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message.")
    except ProgrammingError as ex:
        assert str(ex) == "Error message."


# Generated at 2022-06-12 06:06:09.922743
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Raise ProgrammingError
    try:
        ProgrammingError.passert(False, "test")
        assert False
    except ProgrammingError:
        assert True
    # Do not raise ProgrammingError
    ProgrammingError.passert(True, "test")

# Generated at 2022-06-12 06:06:16.133583
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, "Broken coherency")
        assert False
    except ProgrammingError:
        pass



# Generated at 2022-06-12 06:06:21.779243
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test constructor of class :py:class:`ProgrammingError`."""
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("I don't know what has happened.")
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("I don't know how it has happened.")
    except ProgrammingError:
        pass


# Generated at 2022-06-12 06:06:24.096027
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    p = ProgrammingError("test_method", "test_message", "test_details")
    assert str(p) == "msg: test_message, details: test_details, method: test_method"



# Generated at 2022-06-12 06:06:31.356355
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, None)

    assert str(excinfo.value) == "Broken coherence. Check your code against domain logic to fix it."

    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "Not OK!")

    assert str(excinfo.value) == "Not OK!"

# Generated at 2022-06-12 06:06:35.553748
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        assert False, "Unexpected ProgrammingError raised when condition is met."

    try:
        ProgrammingError.passert(False, None)
        assert False, "Unexpected ProgrammingError not raised when condition is false."
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:06:38.460554
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError("Test message.")
    except ProgrammingError as ex:
        assert ex.args[0] == "Test message."

# Generated at 2022-06-12 06:06:40.407418
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("foo")
    assert e.args == ("foo",)
