

# Generated at 2022-06-12 05:59:50.343282
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for the constructor of class ProgrammingError."""
    p1 = ProgrammingError("error message")
    assert p1.__class__.__name__ == "ProgrammingError"
    assert p1.__str__() == "error message"


# Generated at 2022-06-12 05:59:54.031607
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Just some error message")



# Generated at 2022-06-12 05:59:55.850405
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Error message"):
        pass  # pragma: no cover

# Generated at 2022-06-12 05:59:59.958391
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    expected_message = "Everything is wrong."
    try:
        raise ProgrammingError(expected_message)
    except ProgrammingError as e:
        assert (e.args[0] == expected_message)


# Generated at 2022-06-12 06:00:02.687893
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("this is an error")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:00:07.625448
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor and the :py:func:`~passert` method.
    """
    ProgrammingError.passert(True, "this should not raise an exception")
    try:
        ProgrammingError.passert(False, "this should raise an exception")
    except ProgrammingError as e:
        assert str(e) == "this should raise an exception"

# Generated at 2022-06-12 06:00:11.189728
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("You should not see this error!")
    except ProgrammingError as e:
        assert "You should not see this error!" in str(e)


# Generated at 2022-06-12 06:00:19.791029
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of `ProgrammingError`.
    """

    try:
        ProgrammingError.passert(True, "This assertion should not fail")
    except ProgrammingError:
        assert False

    try:
        ProgrammingError.passert(False, "This assertion should fail")
        assert False
    except ProgrammingError as e:
        assert str(e) == "This assertion should fail"

    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:00:21.208791
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc = ProgrammingError()
    assert(isinstance(exc, Exception))

# Generated at 2022-06-12 06:00:21.810521
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-12 06:00:26.600341
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with assert_raises(ProgrammingError) as exc_context:
        ProgrammingError.passert(False, "This is a testing exception.")
    assert_equal(str(exc_context.exception), "This is a testing exception.")


# Generated at 2022-06-12 06:00:30.149130
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    with pytest.raises(ProgrammingError):
        ProgrammingError(None)

    with pytest.raises(ProgrammingError):
        ProgrammingError("")

    with pytest.raises(ProgrammingError):
        ProgrammingError("Error message")



# Generated at 2022-06-12 06:00:32.612303
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-12 06:00:38.408355
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Wrong type for condition
    try:
        ProgrammingError.passert("True", "Error message.")
        assert False, "Expected type error."
    except TypeError:
        pass

    # Wrong type for message
    try:
        ProgrammingError.passert(False, False)
        assert False, "Expected type error."
    except TypeError:
        pass

    # Now everything is fine
    try:
        ProgrammingError.passert(True, "")
    except Exception:
        assert False, "Unexpected exception"


# Generated at 2022-06-12 06:00:40.740965
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise Exception("Nobody raised a ProgrammingError")



# Generated at 2022-06-12 06:00:41.908119
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("")


# Generated at 2022-06-12 06:00:44.206124
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Case 1"):
        pass

    try:
        with ProgrammingError.passert(False, "Case 2"):
            pass
    except ProgrammingError:
        pass
    else:
        raise Exception("Error not thrown!")

# Generated at 2022-06-12 06:00:46.504312
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error in your code.")
    except ProgrammingError as e:
        assert str(e) == "Programming error in your code."


# Generated at 2022-06-12 06:00:48.408766
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Something wrong in my code.")
    except ProgrammingError as e:
        assert e

# Generated at 2022-06-12 06:00:54.121537
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("test_ProgrammingError")
    except ProgrammingError:
        pass
    ProgrammingError.passert(True, "test_ProgrammingError")
    try:
        ProgrammingError.passert(False, "test_ProgrammingError")
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:01:00.019521
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error!")
    except ProgrammingError as e:
        if str(e) != "This is a programming error!":
            raise


# Generated at 2022-06-12 06:01:01.656680
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ``ProgrammingError``.
    """

    try:
        ProgrammingError("Test")
    except ProgrammingError:
        raise AssertionError("The constructor of class ``ProgrammingError`` has a bug.")

# Generated at 2022-06-12 06:01:06.451954
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error happened.")
    except ProgrammingError as ex:
        assert ex.__class__ == ProgrammingError
        assert str(ex) == "A programming error happened."


# Generated at 2022-06-12 06:01:11.019939
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception1 = ProgrammingError("message1")
    assert str(exception1) == "message1"
    exception2 = ProgrammingError()
    assert exception2.__class__ == ProgrammingError
    assert not hasattr(exception2, "message")


# Generated at 2022-06-12 06:01:14.089875
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("test")


# Generated at 2022-06-12 06:01:17.960109
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Case where an error should be detected by the assertion method
    try:
        ProgrammingError.passert(False, "Should raise an exception.")
        assert False, "Exception should have been raised."
    except ProgrammingError:
        assert True
    # Case where an error shouldn't be detected by the assertion method
    try:
        ProgrammingError.passert(True, "Shouldn't raise an exception.")
        assert True
    except ProgrammingError:
        assert False, "Exception should have been raised."

# Generated at 2022-06-12 06:01:19.229616
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is an error message")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:01:22.867595
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something bad happens")
    except ProgrammingError as err:
        assert err.args[0] == "Something bad happens"


# Generated at 2022-06-12 06:01:30.688800
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for class :py:class:`ProgrammingError`.
    """

    # Assert that ProgrammingError is raised
    raised = False
    try:
        ProgrammingError.passert(False, "test_ProgrammingError")
    except ProgrammingError:
        raised = True
    assert raised

    # Assert that ProgrammingError is not raised
    raised = False
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        raised = True
    assert not raised

# Generated at 2022-06-12 06:01:32.683510
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hallo")
    except ProgrammingError as e:
        assert str(e) == "Hallo"


# Generated at 2022-06-12 06:01:39.423005
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "kaboom!")

# Generated at 2022-06-12 06:01:43.872569
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a message.")
    except Exception as e:
        assert isinstance(e, ProgrammingError), "Not raised as a ProgrammingError."
        assert "This is a message." in str(e), "Doesn't contain the provided message."



# Generated at 2022-06-12 06:01:47.367324
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('message')
    except ProgrammingError as e:
        assert str(e) == 'message'


# Generated at 2022-06-12 06:01:50.571290
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as error:
        assert error.__class__ == ProgrammingError
        assert error.args[0] == "Test"


# Generated at 2022-06-12 06:01:53.233597
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:02:01.282266
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for constructor of :py:class:`ProgrammingError`.
    """
    def testme():
        """
        Very basic function used for testing the constructor.

        :return: Nothing, the function just raises a :py:class:`ProgrammingError`.
        """
        raise ProgrammingError("This is a test")

    try:
        testme()
    except ProgrammingError as ex:
        print("EXCEPTION:", ex)
        assert ex.args[0] == "This is a test"


# Generated at 2022-06-12 06:02:04.343161
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert str(e) == "Error message"

if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-12 06:02:06.352060
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("It has to raise a ProgrammingError")


# Generated at 2022-06-12 06:02:09.526615
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Test exception"
    programming_error = ProgrammingError(message)
    assert programming_error.args == (message,)
    assert programming_error.__str__() == message

# Generated at 2022-06-12 06:02:12.279570
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError('Test error')
    assert e.args[0] == 'Test error'


# Generated at 2022-06-12 06:02:23.839408
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError()

# Generated at 2022-06-12 06:02:29.145289
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    passert = ProgrammingError.passert
    try:
        passert(False, "test")
        assert False
    except ProgrammingError as ex:
        assert ex.args[0] == "test"
    try:
        passert(False, None)
        assert False
    except ProgrammingError as ex:
        assert ex.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:02:32.061215
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as error:
        assert error.args[0] == "This is a test."


# Generated at 2022-06-12 06:02:38.433691
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test case for constructor of class :py:class:`ProgrammingError`."""
    err = ProgrammingError('This is the reason.')
    assert err.args == ('This is the reason.',)
    assert err.args[0] == 'This is the reason.'
    assert str(err) == 'This is the reason.'
    # Test case for method passert
    count = 0
    try:
        ProgrammingError.passert(False, "Boo!")
    except ProgrammingError as err:
        count += 1
        assert err.args == ('Boo!',)
        assert err.args[0] == 'Boo!'
        assert str(err) == 'Boo!'
    assert count == 1
    ProgrammingError.passert(True, "Boo!")
    ProgrammingError.passert(True, None)

# Generated at 2022-06-12 06:02:47.077444
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests functionality for constructor of class [[ProgrammingError]].
    """
    try:
        raise ProgrammingError("This is an error message.")
    except ProgrammingError as e:
        assert e.args[0] == "This is an error message."
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    # Suppress Python 3.8 warning about ProgrammingError.__init__ being called
    # noinspection PyArgumentList
    try:
        raise ProgrammingError("Another error message", "and another error message")
    except ProgrammingError as e:
        assert e.args[0] == "Another error message"
        assert e.args[1] == "and another error message"


# Generated at 2022-06-12 06:02:51.114346
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError), "Constructor of ProgrammingError failed"



# Generated at 2022-06-12 06:02:54.862708
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the :py:class:`ProgrammingError` class.
    """
    try:
        ProgrammingError.passert(False, "Message")
        assert False
    except ProgrammingError as error:
        assert error.args[0] == "Message"

# Generated at 2022-06-12 06:02:58.348946
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing")
    except ProgrammingError as e:
        assert str(e) == "Testing"


# Generated at 2022-06-12 06:03:00.453312
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
  try:
    raise ProgrammingError("Message")
  except ProgrammingError as e:
    assert str(e) == "Message"

# Generated at 2022-06-12 06:03:05.580636
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given
    code = "import os; import sys; print(os.path.abspath(sys.argv[0]))"
    error = None

    # When
    try:
        exec(code)
    except Exception as e:
        error = e

    # Then
    assert type(error) is ProgrammingError



# Generated at 2022-06-12 06:03:29.173559
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error.__str__().endswith("Check your code against domain logic to fix it.")
    error = ProgrammingError(message="MESSAGE")
    assert error.__str__().endswith("MESSAGE")

# Generated at 2022-06-12 06:03:31.105559
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test message.")
    except ProgrammingError as e:
        assert str(e) == "This is a test message."



# Generated at 2022-06-12 06:03:36.645985
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Checks if the exception is correctly raised and if the default message is correctly set.
    """
    try:
        raise ProgrammingError
    except ProgrammingError as exception:
        assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("Exception was not raised.")



# Generated at 2022-06-12 06:03:39.299498
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Testing.")

# Unit tests for class method passert of class ProgrammingError

# Generated at 2022-06-12 06:03:41.831138
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "foo"
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as e:
        assert str(e) == msg


# Generated at 2022-06-12 06:03:44.034903
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():  # NoQa
    from pytest import raises
    with raises(ProgrammingError):
        raise ProgrammingError("Something is wrong")


# Generated at 2022-06-12 06:03:48.819911
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "message")
        assert False, "should have raised"
    except ProgrammingError as e:
        assert str(e) == "message", "invalid message"


if __name__ == '__main__':
    import nose2
    nose2.main()

# Generated at 2022-06-12 06:03:50.064948
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError()
    assert (err is not None)


# Generated at 2022-06-12 06:03:53.345135
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for class :py:class:`.ProgrammingError`.
    """

    try:
        error = ProgrammingError("This is a unit test.")
    except Exception as e:
        error = e

    assert isinstance(error, ProgrammingError)
    assert str(error) == "This is a unit test."



# Generated at 2022-06-12 06:03:57.319891
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("error")
    except ProgrammingError:
        pass

# Generated at 2022-06-12 06:04:43.404148
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",), e.args


# Generated at 2022-06-12 06:04:48.219023
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test that the :py:class:`ProgrammingError` is an :py:class:`Exception` and it is properly initialized in case that no
    message is provided.
    """
    # Arrange
    programming_error: ProgrammingError = None
    # Act
    programming_error = ProgrammingError()
    # Assert
    assert issubclass(ProgrammingError, Exception)
    assert programming_error.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-12 06:04:58.117308
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test of ProgrammingError")
    except ProgrammingError as e:
        assert str(e) == "Test of ProgrammingError"
    try:
        ProgrammingError.passert(False, "Test of ProgrammingError.passert")
    except ProgrammingError as e:
        assert str(e) == "Test of ProgrammingError.passert"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-12 06:05:00.994453
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    message = "my message"
    # Act
    error = ProgrammingError(message)
    # Assert
    assert str(error) == message


# Generated at 2022-06-12 06:05:05.099671
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Invalid operator in the expression: '!='")
    except ProgrammingError as e:
        assert "Invalid operator" in str(e)
        assert "!=" in str(e)


# Generated at 2022-06-12 06:05:07.683411
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something went wrong.")
    except ProgrammingError as e:
        assert e.args[0] == "Something went wrong."
    except Exception:
        raise RuntimeError("The wrong exception was raised.")


# Generated at 2022-06-12 06:05:13.027350
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit testing for :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-12 06:05:17.935481
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Verifies that the constructor of :py:class:`ProgrammingError` functions properly.
    """
    try:
        raise ProgrammingError("Unit test only")
    except ProgrammingError as e:
        assert str(e) == "Unit test only"


# Generated at 2022-06-12 06:05:21.474528
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("message")
    except ProgrammingError as ex:
        assert ex.args[0] == "message"
    try:
        ProgrammingError.passert(False, "message")
        assert False
    except ProgrammingError as ex:
        assert ex.args[0] == "message"

# Generated at 2022-06-12 06:05:25.117565
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # This exception should never be risen.
    try:
        ProgrammingError()
    except ProgrammingError:
        # That is the expected behaviour
        pass
    else:
        assert False, "No exception was risen."


# Generated at 2022-06-12 06:07:04.947477
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test")


# Generated at 2022-06-12 06:07:08.986660
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as ex:
        assert ex.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("ProgrammingError hasn't been raised for a False condition")


# Generated at 2022-06-12 06:07:12.534641
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import unittest

    class TestProgrammingError(unittest.TestCase):
        def test_missing_message(self):
            with self.assertRaises(TypeError):
                ProgrammingError()

    unittest.main()


# Generated at 2022-06-12 06:07:20.137786
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase
    from .mixins import FilterableTestCaseMixin

    class TestProgrammingError(FilterableTestCaseMixin, TestCase):
        class TestError(Exception):
            pass

        def test_passert(self):
            with self.assertRaises(ProgrammingError):
                ProgrammingError.passert(False, None)

            with self.assertRaises(ProgrammingError):
                ProgrammingError.passert(False, "MESSAGE")

            ProgrammingError.passert(True, "MESSAGE")
            ProgrammingError.passert(True, None)

    TestProgrammingError.run()

# Generated at 2022-06-12 06:07:23.564104
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check an error is raised when the condition is not met
    try:
        ProgrammingError.passert(False, "Dummy message")
        assert False, "ProgrammingError must be raised because condition was met"
    except ProgrammingError:
        pass

    # Check no error is raised when the condition is met
    try:
        ProgrammingError.passert(True, "Dummy message")
    except ProgrammingError:
        assert False, "ProgrammingError must NOT be raised because condition was met"

# Generated at 2022-06-12 06:07:28.814308
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "message")
    ProgrammingError.passert(True, None)
    ProgrammingError.passert(True, "message")

# Generated at 2022-06-12 06:07:31.231131
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given a message
    message = "This is a message"

    # When a ProgrammingError is created
    error = ProgrammingError(message)

    # Then the message is set in the error
    assert error.args == (message,)

# Generated at 2022-06-12 06:07:32.254125
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="This is a message")

# Generated at 2022-06-12 06:07:35.506447
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Failed to program. The algorithm was not generated.")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Expected to rise ProgrammingError.")


# Generated at 2022-06-12 06:07:37.921302
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.

    :return: ``None``
    """
    ProgrammingError.passert(False, None)