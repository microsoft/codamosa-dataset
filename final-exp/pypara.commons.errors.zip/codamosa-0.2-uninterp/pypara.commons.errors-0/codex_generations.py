

# Generated at 2022-06-18 02:30:54.264666
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        assert False, "ProgrammingError not raised"

# Generated at 2022-06-18 02:30:57.799360
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        raise AssertionError("ProgrammingError not raised")

# Generated at 2022-06-18 02:31:01.011411
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:31:03.404756
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:31:06.213436
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:31:08.713407
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:31:11.597409
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:31:14.403825
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:31:18.165957
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
        assert False, "ProgrammingError.passert() should have raised an exception"
    except ProgrammingError as e:
        assert str(e) == "Test", "ProgrammingError.passert() should have raised an exception with the given message"


# Generated at 2022-06-18 02:31:21.042141
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        assert False, "Should have raised an exception"

# Generated at 2022-06-18 02:31:25.084146
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:31:27.544861
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:31:31.309473
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"
    else:
        assert False, "ProgrammingError not raised"


# Generated at 2022-06-18 02:31:34.106869
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:31:36.567361
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:31:40.542722
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"
    else:
        assert False, "ProgrammingError not raised"

# Generated at 2022-06-18 02:31:42.668246
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:31:44.984473
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:31:47.078300
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:31:49.137116
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-18 02:31:54.934350
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"
    else:
        assert False, "ProgrammingError was not raised"

# Generated at 2022-06-18 02:31:57.724028
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:32:00.320456
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:32:02.201820
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-18 02:32:04.890077
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        assert False, "ProgrammingError not raised"

# Generated at 2022-06-18 02:32:08.069345
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:32:10.693893
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert str(e) == "This is a test."


# Generated at 2022-06-18 02:32:13.068455
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:32:15.315746
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:32:17.889722
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:32:26.089609
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:32:28.934488
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-18 02:32:33.394674
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-18 02:32:35.558247
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error occurred.")
    except ProgrammingError as e:
        assert str(e) == "A programming error occurred."


# Generated at 2022-06-18 02:32:38.339333
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert str(e) == "This is a test."


# Generated at 2022-06-18 02:32:40.858942
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"
    else:
        assert False, "ProgrammingError not raised"

# Generated at 2022-06-18 02:32:43.225394
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:32:46.569545
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"
    else:
        assert False, "ProgrammingError not raised"

# Generated at 2022-06-18 02:32:48.693243
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError:
        assert True

# Generated at 2022-06-18 02:32:50.453998
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:32:58.002148
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:33:00.463897
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:33:02.910603
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-18 02:33:05.726982
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-18 02:33:07.793535
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:33:09.916425
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:33:11.486553
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-18 02:33:13.677987
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:33:17.095540
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-18 02:33:20.447095
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"
    else:
        assert False, "ProgrammingError.passert() did not raise an exception"


# Generated at 2022-06-18 02:33:32.794201
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test."


# Generated at 2022-06-18 02:33:34.604512
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:33:36.843788
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"

# Generated at 2022-06-18 02:33:40.024221
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:33:42.467935
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:33:44.401703
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:33:47.957197
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:33:50.217845
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "This is a test")

# Generated at 2022-06-18 02:33:52.152160
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:33:53.719724
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:34:16.394390
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:34:19.449022
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:34:22.845193
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"
    else:
        assert False, "ProgrammingError not raised"

# Generated at 2022-06-18 02:34:24.770830
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-18 02:34:27.812186
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-18 02:34:30.781501
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        assert False, "Expected exception"

# Generated at 2022-06-18 02:34:33.150779
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:34:36.064813
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-18 02:34:37.559185
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:34:40.755380
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:35:26.790104
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:35:28.827946
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:35:31.614879
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-18 02:35:34.698613
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:35:37.381360
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
        assert False, "This statement should not be reached"
    except ProgrammingError as e:
        assert str(e) == "This is a test"

# Generated at 2022-06-18 02:35:39.525750
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:35:41.398816
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:35:44.784563
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:35:47.830153
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:35:50.065550
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:37:32.095506
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"
    else:
        raise AssertionError("ProgrammingError not raised")

# Generated at 2022-06-18 02:37:35.056526
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:37:37.280892
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-18 02:37:39.404367
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"
    else:
        assert False, "Expected exception not raised"

# Generated at 2022-06-18 02:37:43.136178
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"
    else:
        assert False, "ProgrammingError not raised"


# Generated at 2022-06-18 02:37:45.606057
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert str(e) == "This is a test."

# Generated at 2022-06-18 02:37:48.223862
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:37:50.780401
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-18 02:37:53.097590
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-18 02:37:54.161047
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"
