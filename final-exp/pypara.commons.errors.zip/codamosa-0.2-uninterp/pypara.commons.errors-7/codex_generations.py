

# Generated at 2022-06-18 02:31:00.320531
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"
    else:
        assert False, "ProgrammingError not raised"


# Generated at 2022-06-18 02:31:01.449440
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-18 02:31:05.292417
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        assert False, "ProgrammingError not raised"


# Generated at 2022-06-18 02:31:08.932259
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"
    else:
        raise AssertionError("ProgrammingError.passert did not raise an exception")

# Generated at 2022-06-18 02:31:11.941730
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:31:14.898830
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:31:17.898123
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"
    else:
        assert False, "ProgrammingError not raised"


# Generated at 2022-06-18 02:31:20.743704
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"
    else:
        assert False, "ProgrammingError not raised"


# Generated at 2022-06-18 02:31:23.387887
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-18 02:31:25.601953
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-18 02:31:29.202729
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"
    else:
        assert False, "ProgrammingError not raised"

# Generated at 2022-06-18 02:31:31.617737
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:31:34.220465
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:31:36.744962
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:31:39.544563
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-18 02:31:41.479802
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-18 02:31:43.574390
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:31:45.337852
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:31:47.420168
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-18 02:31:49.476176
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:31:53.940950
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:31:55.806357
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:31:58.594359
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:32:00.827412
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:32:03.827553
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        assert False, "ProgrammingError not raised"

# Generated at 2022-06-18 02:32:06.759612
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:32:09.752384
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:32:12.559225
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:32:14.887238
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert str(e) == "This is a test."


# Generated at 2022-06-18 02:32:17.343235
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test."


# Generated at 2022-06-18 02:32:25.236871
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
        assert False
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-18 02:32:27.441855
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:32:31.197559
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"
    else:
        assert False, "ProgrammingError.passert() did not raise an exception"

# Generated at 2022-06-18 02:32:32.985179
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:32:35.480897
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"
    else:
        assert False


# Generated at 2022-06-18 02:32:37.615202
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:32:39.952759
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"

# Generated at 2022-06-18 02:32:42.998605
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        raise AssertionError("ProgrammingError not raised")

# Generated at 2022-06-18 02:32:46.077056
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert str(e) == "This is a test."


# Generated at 2022-06-18 02:32:48.874389
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:32:55.298462
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert str(e) == "This is a test."


# Generated at 2022-06-18 02:32:58.001124
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:33:00.464365
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as e:
        assert str(e) == "This is an error"


# Generated at 2022-06-18 02:33:02.921899
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert str(e) == "This is a test."


# Generated at 2022-06-18 02:33:06.861759
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        assert False, "ProgrammingError not raised"

# Generated at 2022-06-18 02:33:08.825873
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-18 02:33:10.840266
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-18 02:33:12.388289
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-18 02:33:14.448163
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:33:16.653232
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:33:23.351333
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-18 02:33:26.006506
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-18 02:33:28.974457
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"
    else:
        assert False, "ProgrammingError not raised"


# Generated at 2022-06-18 02:33:31.918405
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"
    else:
        assert False, "ProgrammingError not raised"

# Generated at 2022-06-18 02:33:33.878061
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as e:
        assert str(e) == "This is an error"


# Generated at 2022-06-18 02:33:35.960935
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-18 02:33:38.369932
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-18 02:33:39.494052
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:33:42.648984
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        assert False, "ProgrammingError not raised"

# Generated at 2022-06-18 02:33:46.505529
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:33:58.682859
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:34:02.337184
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"
    else:
        raise AssertionError("ProgrammingError not raised")

# Generated at 2022-06-18 02:34:04.802316
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:34:06.156003
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:34:08.792784
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:34:09.923482
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-18 02:34:12.785727
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError() should raise an exception"


# Generated at 2022-06-18 02:34:15.799401
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:34:18.531397
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:34:21.373499
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:34:44.307500
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-18 02:34:46.809344
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-18 02:34:49.404862
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-18 02:34:52.508332
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert str(e) == "This is a test."


# Generated at 2022-06-18 02:34:55.687229
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:34:57.963808
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:35:02.360511
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        assert False, "ProgrammingError.passert() did not raise an exception"

# Generated at 2022-06-18 02:35:06.982378
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"
    else:
        assert False, "ProgrammingError not raised"


# Generated at 2022-06-18 02:35:09.113350
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:35:12.629509
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-18 02:36:00.767328
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:36:03.905906
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:36:05.896461
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-18 02:36:08.012851
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:36:09.960198
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:36:12.366497
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:36:13.305427
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:36:15.203383
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-18 02:36:19.434931
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        assert False, "ProgrammingError not raised"

# Generated at 2022-06-18 02:36:22.276755
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
        assert False, "Should have raised an exception"
    except ProgrammingError as e:
        assert str(e) == "This is a test"

# Generated at 2022-06-18 02:38:06.601086
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:38:09.970434
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"
    else:
        assert False, "ProgrammingError was not raised"

# Generated at 2022-06-18 02:38:16.905596
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
        assert False, "ProgrammingError.passert() should have raised an exception"
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    try:
        ProgrammingError.passert(False, None)
        assert False, "ProgrammingError.passert() should have raised an exception"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    ProgrammingError.passert(True, "This is a test")

# Generated at 2022-06-18 02:38:21.169355
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:38:24.149829
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-18 02:38:26.154363
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:38:29.032458
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:38:31.098658
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-18 02:38:35.230334
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-18 02:38:38.112445
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        assert False, "ProgrammingError not raised"
