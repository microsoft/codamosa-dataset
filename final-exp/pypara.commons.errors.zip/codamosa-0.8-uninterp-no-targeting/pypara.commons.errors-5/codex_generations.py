

# Generated at 2022-06-21 20:11:35.993204
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "")

# Generated at 2022-06-21 20:11:39.102630
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ProgrammingError.__init__"""
    # Test basic exception class
    with pytest.raises(TypeError):
        ProgrammingError()

    # Test custom message
    with pytest.raises(ProgrammingError) as e:
        ProgrammingError("This is a message")
    assert str(e.value) == "This is a message"

# Generated at 2022-06-21 20:11:45.496580
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class MyClass:
        def __init__(self, condition: bool, message: str) -> None:
            try:
                ProgrammingError.passert(condition, message)
            except ProgrammingError as e:
                self.message = e.args[0]

    my_class = MyClass(False, "foo")
    assert my_class.message == "foo"

# Generated at 2022-06-21 20:11:51.674665
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "foo")
    except ProgrammingError as e:
        assert str(e) == "foo"
    else:
        assert False, "Should be raised"

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "Should be raised"

    try:
        ProgrammingError.passert(True, "foo")
    except ProgrammingError:
        assert False, "Should not be raised"
    else:
        assert True

# Generated at 2022-06-21 20:11:53.238153
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)

# Generated at 2022-06-21 20:12:00.035843
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import unittest
    import unittest.mock as mock

    class TestProgrammingError_(unittest.TestCase):
        def test_passert(self):
            with mock.patch('exceptions.ProgrammingError') as mock_programming_error:
                ProgrammingError.passert(True, "Test message")
                mock_programming_error.assert_not_called()
                ProgrammingError.passert(False, "Test message")
                mock_programming_error.assert_called_once_with("Test message")

    unittest.main()

# Generated at 2022-06-21 20:12:11.202028
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest_mock import MockerFixture
    from unittest import TestCase
    from hamcrest import has_properties, has_entry, matches_regexp, contains_string
    from hamcrest.core.base_matcher import BaseMatcher
    from hamcrest.core.core.isequal import equal_to

    class ContainsString(BaseMatcher):
        def __init__(self, pattern: str) -> None:
            self.pattern = pattern

        def _matches(self, item: str) -> bool:
            return self.pattern in item

        def describe_to(self, description):
            description.append_text("a str containing string '{}'".format(self.pattern)).append_text(" (but was: ")
            description.append_value(self.pattern)
            description.append_text

# Generated at 2022-06-21 20:12:14.987416
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as ex:
        assert ex.args[0] == "Error message"
        assert str(ex) == "Error message"
    else:
        assert False


# Generated at 2022-06-21 20:12:18.443083
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError:
        pass
    with ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    with ProgrammingError("test") as e:
        assert e.args[0] == "test"

# Generated at 2022-06-21 20:12:21.311060
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-21 20:12:26.141440
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as error:
        assert error.args[0] == "Error message"
    finally:
        pass


# Generated at 2022-06-21 20:12:26.744388
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test")

# Generated at 2022-06-21 20:12:30.923951
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "Expected exception to be raised"


# Generated at 2022-06-21 20:12:35.897053
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class ``ProgrammingError``.
    """
    try:
        ProgrammingError("Error testing.")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("The error did not happen, yet it should.")


# Generated at 2022-06-21 20:12:39.719306
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Fail")
        assert False
    except ProgrammingError as ex:
        assert str(ex) == "Fail"
    except Exception:
        assert False
    else:
        assert False


# Generated at 2022-06-21 20:12:42.909034
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as error:
        assert str(error) == "This is a test"

# Generated at 2022-06-21 20:12:46.077034
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception:
        assert False, "Constructor of ProgrammingError should not raise any exception."


# Generated at 2022-06-21 20:12:49.295615
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Unit testing for class ProgrammingError. """

    try:
        raise ProgrammingError("Sample error message.")
    except ProgrammingError as error:
        assert str(error) == "Sample error message."


# Generated at 2022-06-21 20:12:57.022871
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    # Case of a valid condition
    ProgrammingError.passert(True, None)

    # Case of a invalid condition
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)

    # Case of a invalid condition and defined message
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "message")
    assert "message" == str(excinfo.value)

# Generated at 2022-06-21 20:13:00.361044
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as exception_info:
        raise ProgrammingError("Check your code!")
    assert str(exception_info) == "Check your code!"


# Generated at 2022-06-21 20:13:09.282792
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError(None)
    with raises(ProgrammingError):
        ProgrammingError("")
    with raises(ProgrammingError):
        ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-21 20:13:14.603448
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    condition = False
    message = "This is a test message"
    try:
        ProgrammingError.passert(condition, message)
    except ProgrammingError as err:
        assert err.args[0] == message
    else:
        assert False, "Should have raised ProgrammingError"


if __name__ == "__main__":
    import pytest

    pytest.main(["-l", "--capture=no", "test_error.py"])

# Generated at 2022-06-21 20:13:17.529911
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # test if the constructor works correctly
    with ProgrammingError("A message.") as e:
        assert str(e) == "A message."


# Generated at 2022-06-21 20:13:21.406036
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test ProgrammingError")
    except ProgrammingError as e:
        assert str(e) == "Test ProgrammingError"

# Generated at 2022-06-21 20:13:28.719884
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(condition=False, message="This error must be always raised")
    try:
        ProgrammingError.passert(condition=True, message="This error must not be raised")
    except ProgrammingError:
        pytest.fail("ProgrammingError must not be raised when the condition is True")
    try:
        ProgrammingError.passert(condition=True, message=None)
    except ProgrammingError:
        pytest.fail("ProgrammingError must not be raised when the condition is True and message is None")

# Generated at 2022-06-21 20:13:39.333497
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test with invalid message
    try:
        ProgrammingError(None)
        assert False, "ProgrammingError has not been raised as expected."
    except TypeError:
        pass
    try:
        ProgrammingError(1)
        assert False, "ProgrammingError has not been raised as expected."
    except TypeError:
        pass
    # Test with valid message
    try:
        ProgrammingError("")
    except TypeError:
        assert False, "ProgrammingError has been raised and it should not have."
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it.", \
            "ProgrammingError has a wrong message. It should have been 'Broken coherence. Check your code against " \
            "domain logic to fix it.'"

# Generated at 2022-06-21 20:13:42.541542
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError()
    with raises(ProgrammingError):
        raise ProgrammingError("Custom message")


# Generated at 2022-06-21 20:13:46.364191
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing")
    except ProgrammingError as e:
        assert "Testing" in str(e)
    else:
        assert False # Should never get here!

# Generated at 2022-06-21 20:13:50.420424
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:exc:`ProgrammingError`.
    """
    try:
        ProgrammingError("This is a test")
    except ProgrammingError as exc:
        assert str(exc) == "This is a test"


# Generated at 2022-06-21 20:13:51.944519
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:14:00.238584
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test failed")
        assert False, "passert failed to raise a ProgrammingError"
    except ProgrammingError:
        assert True, "Test succeeded"

# Generated at 2022-06-21 20:14:01.307604
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("A message")

# Generated at 2022-06-21 20:14:04.782360
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(expected_exception=ProgrammingError, message="Broken coherence. Check your code against "
                                                             "domain logic to fix it."):
        ProgrammingError.passert(False, None)


# Generated at 2022-06-21 20:14:06.664018
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "test")


# Generated at 2022-06-21 20:14:10.178761
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"

# Generated at 2022-06-21 20:14:13.753765
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test case for constructor of class :py:class:`pypara.error.ProgrammingError`.
    """
    cut = ProgrammingError("A test error")
    assert str(cut) == "A test error"


# Generated at 2022-06-21 20:14:16.473302
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error.")
    except ProgrammingError as e:
        if str(e) != "This is an error.":
            raise AssertionError()


# Generated at 2022-06-21 20:14:17.828645
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as error:
        raise ProgrammingError("Test")
    assert error.value.args[0] == "Test"


# Generated at 2022-06-21 20:14:25.209975
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Verify that this exception is raised with an empty message
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    # Verify that this exception is raised with a not-empty message
    try:
        raise ProgrammingError("Programming error")
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:14:27.452867
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as e:
        assert str(e) == "A message"

# Generated at 2022-06-21 20:14:42.951152
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN: A message for a ProgrammingError
    message = "This is a ProgrammingError."
    # WHEN: We create a ProgrammingError with the message
    error = ProgrammingError(message)
    # THEN: The message of the error is the desired one.
    assert error.message == message


# Generated at 2022-06-21 20:14:47.037234
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test case for :py:func:`pypara.errors.ProgrammingError.__init__`
    """
    try:
        raise ProgrammingError("Just a test.")
    except ProgrammingError as e:
        assert "Just a test." in str(e)


# Generated at 2022-06-21 20:14:49.756664
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="Hello World!")
    except:
        raise AssertionError("The constructor of the class ProgrammingError does not work properly.")


# Generated at 2022-06-21 20:14:55.008742
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test case for the constructor of class :class:`ProgrammingError`."""
    try:
        raise ProgrammingError('something went wrong')
    except ProgrammingError as e:
        assert str(e) == 'something went wrong'
        assert e.__cause__ is None


# Generated at 2022-06-21 20:15:01.195535
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()
    ProgrammingError("hey")
    try:
        ProgrammingError.passert(True, "ok")
    except ProgrammingError as e:
        assert False, repr(e)
    except Exception as e:
        assert False, repr(e)
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert True
    except Exception as e:
        assert False, repr(e)

# Generated at 2022-06-21 20:15:05.921546
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"
    else:
        assert False, "Expected a ProgrammingError"

# Generated at 2022-06-21 20:15:09.665166
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    def condition_function():
        error = ProgrammingError("Parameter variable not set", "This is a cool explanation")
        assert error.args == ("Parameter variable not set", "This is a cool explanation")

        error = ProgrammingError("Parameter variable not set")
        assert error.args == ("Parameter variable not set",)

        error = ProgrammingError()
        assert error.args == tuple()

    condition_function()


# Generated at 2022-06-21 20:15:11.401969
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    exc = ProgrammingError("Hello world!")

    assert exc.args == ("Hello world!",)


# Generated at 2022-06-21 20:15:13.210133
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("TEST")
    assert error is not None


# Generated at 2022-06-21 20:15:15.290849
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error")
    except ProgrammingError as e:
        assert str(e) == "Programming error"


# Generated at 2022-06-21 20:15:40.924597
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "A message"):
        pass

    try:
        with ProgrammingError.passert(False, "A message"):
            pass
    except ProgrammingError as e:
        assert str(e) == "A message"
    else:
        assert False


# Generated at 2022-06-21 20:15:46.496276
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyTypeChecker
    try:
        ProgrammingError.passert(False, "Cannot continue")
    except ProgrammingError as e:
        assert "Broken coherence" not in str(e)
        assert "Cannot continue" in str(e)

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert "Broken coherence" in str(e)

# Generated at 2022-06-21 20:15:55.994976
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "An error happened")
        raise AssertionError("Test failed")
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(True, "An error happened")
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        raise AssertionError("Test failed")
    except Exception as ex:
        raise AssertionError("Unexpected exception: {}".format(ex))

#Execute unit test
if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-21 20:15:57.896547
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Hello world!")


# Generated at 2022-06-21 20:16:00.935668
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Some message")
    except ProgrammingError as e:
        assert str(e) == "Some message"

# Generated at 2022-06-21 20:16:03.027278
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "A programming error happened")


# Generated at 2022-06-21 20:16:07.184316
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of the class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("This is an error message!")
    except ProgrammingError as error:
        assert str(error) == "This is an error message!"


# Generated at 2022-06-21 20:16:10.526692
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Programming error") as e:
        assert str(e) == "Programming error"
    with ProgrammingError("") as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:16:12.181207
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(condition=False, message="Message passed to the exception"):
        pass

# Generated at 2022-06-21 20:16:15.979459
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError
    ProgrammingError.passert(True, None)
    ProgrammingError.passert(True, "msg")


# Generated at 2022-06-21 20:17:01.061529
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:17:04.951544
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the ProgrammingError class.
    """
    try:
        raise ProgrammingError("Something bad happened")
    except ProgrammingError as error:
        assert error.args[0] == "Something bad happened"


# Generated at 2022-06-21 20:17:06.914122
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError("This is a programming error!")


# Generated at 2022-06-21 20:17:11.331307
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("ProgrammingError message")
    except ProgrammingError as e:
        assert e.message == "ProgrammingError message"
    else:
        assert False, "ProgrammingError not raised"


# Generated at 2022-06-21 20:17:13.820386
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test error")
    except ProgrammingError as e:
        assert str(e) == "This is a test error"

# Generated at 2022-06-21 20:17:16.138190
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error ought to be raised.")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)



# Generated at 2022-06-21 20:17:18.441303
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="I am testing an error")
        assert False, "Exception ProgrammingError: I am testing an error expected, but not raised."
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:17:24.576860
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def test_passert_true():
        ProgrammingError.passert(True, "")

    def test_passert_false_message_none():
        try:
            ProgrammingError.passert(False, None)
        except ProgrammingError as ex:
            assert ex.args == ("Broken coherence. Check your code against domain logic to fix it.",)
        else:
            assert False

    def test_passert_false_message_non_empty():
        try:
            ProgrammingError.passert(False, "Error message")
        except ProgrammingError as ex:
            assert ex.args == ("Error message",)
        else:
            assert False

    test_passert_true()
    test_passert_false_message_none()
    test_passert_false_message_non_empty()



# Generated at 2022-06-21 20:17:27.605783
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange

    # Act
    error = ProgrammingError("this is a test")

    # Assert
    assert str(error) == "this is a test"


# Generated at 2022-06-21 20:17:30.333388
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args == ("This is a test",)
    else:
        raise Exception("The constructor of class ProgrammingError does not work properly")


# Generated at 2022-06-21 20:19:26.606825
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"
        return
    assert False

# Generated at 2022-06-21 20:19:29.197247
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as e:
        assert str(e) == "This is an error"

# Generated at 2022-06-21 20:19:35.466998
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class Test:
        def __init__(self, successful: bool = True):
            self.successful = successful

        @property
        def failure(self) -> bool:
            return not self.successful

    successful = Test()
    assert not successful.failure

    ProgrammingError.passert(successful.successful, "The object is expected to be successful.")

    failure = Test(False)
    assert failure.failure

    try:
        ProgrammingError.passert(failure.failure, "The object is expected to be successful.")
    except ProgrammingError:
        pass
    else:
        assert False, "'failure' must raise an ProgrammingError exception."

# Generated at 2022-06-21 20:19:39.624343
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Failing test")
    except ProgrammingError as e:
        assert e.args[0] == "Failing test"


# Generated at 2022-06-21 20:19:46.110626
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Asserts that the constructor of class :py:class:`ProgrammingError` works as expected.
    """
    # Assert that no error is raised when given a message
    try:
        raise ProgrammingError("This is a message")
    except ProgrammingError as e:
        assert e.args[0] == "This is a message"
    # Assert that no error is raised when not given a message
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:19:49.770314
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError`.
    """

    with ProgrammingError.passert(True, "This message should never be shown"):
        pass

    with ProgrammingError.passert(False, "This message should be shown"):
        assert False

    try:
        with ProgrammingError.passert(False, None):
            assert False
    except ProgrammingError as e:
        assert "Broken coherence" in str(e)

# Generated at 2022-06-21 20:19:53.018978
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with base_utils.TestAssertRaise(ProgrammingError):
        ProgrammingError.passert(False, "Test error")

    ProgrammingError.passert(True, "Test error")

# Generated at 2022-06-21 20:20:01.604446
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def _test_passert(c: bool, m: Optional[str]) -> None:
        try:
            ProgrammingError.passert(c, m)
        except ProgrammingError as e:
            assert e.args == (m or "Broken coherence. Check your code against domain logic to fix it.",)
            return
        raise ProgrammingError("Expected exception did not occur")

    _test_passert(True, None)
    _test_passert(True, "")
    _test_passert(True, "A")
    _test_passert(False, None)
    _test_passert(False, "")
    _test_passert(False, "A")

# Generated at 2022-06-21 20:20:05.612447
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        assert 1 == 0
    except AssertionError as ex:
        pass

    assert '1 == 0' in ex.args[0]
    assert 'Check' in ProgrammingError.passert.__doc__


# Generated at 2022-06-21 20:20:09.092374
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.message == "Broken coherence. Check your code against domain logic to fix it."