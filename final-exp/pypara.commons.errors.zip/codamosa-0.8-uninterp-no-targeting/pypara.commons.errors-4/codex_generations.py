

# Generated at 2022-06-21 20:11:36.698475
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("ProgrammingError not raised.")


# Generated at 2022-06-21 20:11:38.757093
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        with ProgrammingError.passert(False, "Oops!"):
            pass
    except ProgrammingError as e:
        assert "Oops!" in str(e)


# Generated at 2022-06-21 20:11:42.710449
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
        assert False
    except ProgrammingError as e:
        assert str(e)

# Generated at 2022-06-21 20:11:47.430183
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Check domain logic."):
        pass  # pragma: no cover
    try:
        with ProgrammingError.passert(False, "Check domain logic."):
            pass
    except ProgrammingError as e:
        assert e.args == ("Check domain logic.",)
    else:
        assert False  # pragma: no cover



# Generated at 2022-06-21 20:11:49.374971
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-21 20:11:53.356684
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "Post-condition failed because whatever reason"
    try:
        ProgrammingError.passert(False, msg)
        raise AssertionError("Post-condition should have failed")
    except ProgrammingError as er:
        assert er.msg == msg

# Generated at 2022-06-21 20:11:54.455437
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()

# Generated at 2022-06-21 20:11:56.856993
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Wrong")
    assert error.args[0] == "Wrong"


# Generated at 2022-06-21 20:11:59.963248
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Expected condition was not fulfilled.")
    assert error.args == ("Expected condition was not fulfilled.",)
    assert error.args[0] == "Expected condition was not fulfilled."
    assert isinstance(error, Exception)


# Generated at 2022-06-21 20:12:01.374462
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError):
        ProgrammingError("Hello world")


# Generated at 2022-06-21 20:12:05.841020
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a message")
    except ProgrammingError as error:
        assert error.__str__() == "This is a message"


# Generated at 2022-06-21 20:12:08.322932
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("My message")
    assert error.args == ("My message",)


# Generated at 2022-06-21 20:12:10.156002
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"

# Generated at 2022-06-21 20:12:13.059799
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("ProgrammingError message")
    except ProgrammingError as error:
        assert str(error) == "ProgrammingError message"


# Generated at 2022-06-21 20:12:17.907475
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(True, "My message")  # Should not raise
        ProgrammingError.passert(False, None)  # Should raise
        assert False
    except ProgrammingError as e:
        assert isinstance(e.args[0], str)


# Generated at 2022-06-21 20:12:19.766978
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raised(ProgrammingError):
        ProgrammingError()

# Generated at 2022-06-21 20:12:26.010098
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=missing-docstring,too-few-public-methods
    class TestError(ProgrammingError):
        pass

    try:
        TestError("Did not expect any error.")
        assert False, "Should have raised"
    except TestError as err:
        assert str(err) == "Did not expect any error.", "Unexpected error message"

# Generated at 2022-06-21 20:12:27.621889
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()



# Generated at 2022-06-21 20:12:34.981842
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("The exception must be raised")

    try:
        ProgrammingError.passert(False, "testing")
    except ProgrammingError as e:
        assert e.args[0] == "testing"
    else:
        raise AssertionError("The exception must be raised")

# Generated at 2022-06-21 20:12:39.445430
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Wooow")
        assert False
    except ProgrammingError as ex:
        assert ex.args[0] == "Wooow"

    try:
        ProgrammingError.passert(True, "Wooow")
        assert True
    except ProgrammingError:
        assert False

# Generated at 2022-06-21 20:12:47.035423
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test the constructor of class :py:class:`ProgrammingError`."""
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

    try:
        raise ProgrammingError("Bye bye")
    except ProgrammingError:
        pass



# Generated at 2022-06-21 20:12:57.749043
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Condition fulfilled
    ProgrammingError.passert(condition=True, message="a")

    # Condition is not fulfilled
    try:
        ProgrammingError.passert(condition=False, message="a")
        assert False # pragma: no cover
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert e.args[0] == "a"

    # Message not provided
    try:
        ProgrammingError.passert(condition=False, message=None)
        assert False # pragma: no cover
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:13:01.405310
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test for :py:class:`ProgrammingError`."""
    from pytest import raises
    from .exceptions import ProgrammingError
    with raises(ProgrammingError):
        ProgrammingError(message='error message')


# Generated at 2022-06-21 20:13:03.772548
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("test")
    except ProgrammingError:
        pass



# Generated at 2022-06-21 20:13:06.647908
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error message")
    except ProgrammingError as e:
        assert str(e) == "This is an error message"
    else:
        raise RuntimeError("Expecting an exception to be raised")


# Generated at 2022-06-21 20:13:07.211599
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-21 20:13:10.900770
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Expression")
        assert False
    except ProgrammingError as ex:
        assert ex.args[0] == "Expression"

# Generated at 2022-06-21 20:13:13.732890
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-21 20:13:17.694697
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="This is a test")
    except ProgrammingError:
        pass
    else:
        assert False, "Expected exception not raised."

# Generated at 2022-06-21 20:13:21.610872
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as e:
        print(e)


# Generated at 2022-06-21 20:13:28.873280
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        raise ProgrammingError

    assert str(excinfo.value) == ""


# Generated at 2022-06-21 20:13:32.498559
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as error:
        assert error.__str__() == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:13:34.654675
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as e:
        assert(isinstance(e, ProgrammingError))


# Generated at 2022-06-21 20:13:37.584936
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("message")
    except ProgrammingError as instance:
        assert str(instance) == "message"


# Generated at 2022-06-21 20:13:40.743020
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception:
        pass
    else:
        raise AssertionError("Impossible to raise ProgrammingError.")


# Generated at 2022-06-21 20:13:41.866693
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("some message")


# Generated at 2022-06-21 20:13:45.835407
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-21 20:13:48.954687
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    # Simple construction of an exception
    try:
        raise ProgrammingError("Hello world!")
    except ProgrammingError as ex:
        assert str(ex) == "Hello world!"

    # No message given
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:13:50.894084
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('test')
    except ProgrammingError as pe:
        assert str(pe) == 'test'


# Generated at 2022-06-21 20:13:57.593457
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if the class :py:class:`ProgrammingError` is working.
    """
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("test")
    except ProgrammingError as error:
        assert error.args[0] == "test"


# Generated at 2022-06-21 20:14:11.967170
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("How could it be possible?")
    except ProgrammingError as e:
        assert(e.args[0] == "How could it be possible?")

# Generated at 2022-06-21 20:14:17.847883
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("foo")
    except ProgrammingError as ex:
        assert str(ex) == "foo"
    with ProgrammingError.passert(False, "bar"):
        raise ProgrammingError("Unexpected error")
    with ProgrammingError.passert(True, "bar"):
        return
    with ProgrammingError.passert(False, None):
        raise ProgrammingError("Unexpected error")
    with ProgrammingError.passert(True, None):
        return

# Generated at 2022-06-21 20:14:23.538657
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:14:27.271875
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    try:
        raise ProgrammingError("Something wrong in the model.")
    except ProgrammingError as error:
        assert "Something wrong in the model." == error.args[0]
    else:
        raise RuntimeError("Test failed.")


# Generated at 2022-06-21 20:14:32.135375
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from nose.tools import assert_raises

    # Case where the condition is met
    ProgrammingError.passert(True, "")

    # Case where the condition is not met
    assert_raises(ProgrammingError, ProgrammingError.passert, False, "")

# Generated at 2022-06-21 20:14:34.355756
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert e.args == ("Test message",)


# Generated at 2022-06-21 20:14:36.343372
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError("Test ProgrammerError")


# Generated at 2022-06-21 20:14:41.711762
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    :py:class:`ProgrammingError` unit test.
    """
    try:
        ProgrammingError.passert(True, "message")
    except ProgrammingError as ex:
        assert False, "Expected ProgrammingError not raised."
    try:
        ProgrammingError.passert(False, "message")
        assert False, "Expected ProgrammingError raised."
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it.", "Expected message mismatch."

# Generated at 2022-06-21 20:14:45.149823
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, __name__)
    except ProgrammingError as e:
        pass
    else:
        raise AssertionError("Should have raised an error.")


# Generated at 2022-06-21 20:14:49.197337
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    exception: Exception = None
    try:
        # WHEN
        ProgrammingError.passert(False, "Test exception.")
    except Exception as e:
        # THEN
        exception = e
    assert isinstance(exception, ProgrammingError)

# Generated at 2022-06-21 20:15:13.611547
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Some bad thing happened.")
        raise Exception("Some bad thing happened but it was not detected.")
    except ProgrammingError as error:
        assert str(error) == "Some bad thing happened."


# Generated at 2022-06-21 20:15:16.036286
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error message")
    except Exception as ex:
        assert ex.args[0] == "This is an error message"


# Generated at 2022-06-21 20:15:20.349857
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error which breaks domain logic")
    except ProgrammingError as e:
        assert "Programming error which breaks domain logic" in str(e)


# Generated at 2022-06-21 20:15:22.382038
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Foo!")
    except ProgrammingError as e:
        assert str(e) == "Foo!"

# Generated at 2022-06-21 20:15:24.944450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Incorrect behaviour.")
    except ProgrammingError as e:
        assert str(e) == "Incorrect behaviour."

# Generated at 2022-06-21 20:15:27.749407
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Test message"


# Generated at 2022-06-21 20:15:29.895418
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:15:33.307944
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        if e.__str__() == "Broken coherence. Check your code against domain logic to fix it.":
            pass
        else:
            raise AssertionError()


# Generated at 2022-06-21 20:15:41.299592
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = ""
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        message = str(e)
    assert message == "Broken coherence. Check your code against domain logic to fix it."

    message = ""
    try:
        raise ProgrammingError(message="My custom error.")
    except ProgrammingError as e:
        message = str(e)
    assert message == "My custom error."


# Generated at 2022-06-21 20:15:46.988491
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the ProgramminError class.
    """
    clazz = ProgrammingError
    try:
        clazz("Hello World")
    except clazz as e:
        assert str(e) == "Hello World"

    try:
        clazz("Hello %s" % "world")
    except clazz as e:
        assert str(e) == "Hello world"


# Generated at 2022-06-21 20:16:45.734800
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == 'Broken coherence. Check your code against domain logic to fix it.'
    else:
        assert False


# Generated at 2022-06-21 20:16:49.433717
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, 'Condition violated')

# Generated at 2022-06-21 20:16:53.190571
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing")
        raise AssertionError("ProgrammingError.passert() should raise an exception")
    except ProgrammingError as e:
        assert str(e) == "Testing", "ProgrammingError.passert() error message should be propagated"


# Generated at 2022-06-21 20:16:57.726536
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(None)
    except ProgrammingError as err:
        assert str(err) == "Broken coherence. Check your code against domain logic to fix it."

    try:
        raise ProgrammingError("Test")
    except ProgrammingError as err:
        assert str(err) == "Test"



# Generated at 2022-06-21 20:17:09.629708
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` exception.

    :return: ``None``
    """
    try:
        ProgrammingError()
        assert False, "ProgrammingError has to raise an exception"
    except:
        pass
    try:
        ProgrammingError().passert(True, "")
        ProgrammingError().passert(False, "")
    except:
        assert False, "ProgrammingError.passert() has to raise an exception when condition is False"
    try:
        ProgrammingError.passert(True, "")
        ProgrammingError.passert(False, "")
        assert False, "ProgrammingError.passert() has to raise an exception when condition is False"
    except:
        pass

# Generated at 2022-06-21 20:17:12.486218
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.error import ProgrammingError

    with raises(ProgrammingError):
        ProgrammingError()



# Generated at 2022-06-21 20:17:14.344655
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing")
    except ProgrammingError as p:
        assert p.args[0] == "Testing"

# Generated at 2022-06-21 20:17:15.523295
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError as e:
        raise ProgrammingError("Unit test")

# Generated at 2022-06-21 20:17:19.428406
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        message = "Test"
        ProgrammingError(message)
        assert False, "ProgrammingError is raising an exception."
    except Exception as error:
        assert isinstance(error, ProgrammingError), "ProgrammingError is not raising a ProgrammingError instance."
        assert message in str(error), "The message of the error is not the one expected."


# Generated at 2022-06-21 20:17:24.405402
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(None)
    except ProgrammingError:
        raise AssertionError("ProgrammingError can not be raised without explicit message")
    try:
        ProgrammingError("")
    except ProgrammingError:
        raise AssertionError("ProgrammingError can not be raised with empty string as message")


# Generated at 2022-06-21 20:19:29.968420
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args == ("Test",)


# Generated at 2022-06-21 20:19:31.149655
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(1 == 1, "")

# Generated at 2022-06-21 20:19:32.901208
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as err:
        assert isinstance(err, Exception)



# Generated at 2022-06-21 20:19:42.420156
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        assert False, "An assertion error is expected"
    except AssertionError as an_error:
        an_exception = ProgrammingError(an_error)
        assert isinstance(an_exception, ProgrammingError)
        assert isinstance(an_exception, AssertionError)
        assert str(an_exception) == "An assertion error is expected"


# Generated at 2022-06-21 20:19:45.935718
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        with open("/dev/daaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasdasd") as f:
            print(f)
        assert False
    except Exception as ex:
        print(ex)
        assert True


# Generated at 2022-06-21 20:19:48.842996
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if :py:class:`ProgrammingError` fulfills its contract.

    :return: ``None`` if success.
    """

    ProgrammingError.passert(True, "")
    ProgrammingError.passert(False, "error")

# Generated at 2022-06-21 20:19:54.745183
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError
    try:
        raise ProgrammingError("Test error.")
    except ProgrammingError as e:
        assert "Test error." == e.args[0]
        return
    raise AssertionError('Expected a ProgrammingError to be raised.')


# Generated at 2022-06-21 20:19:55.803585
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test error message")
    except ProgrammingError as e:
        assert str(e) == "Test error message"


# Generated at 2022-06-21 20:20:03.365466
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Positive test cases
    try:
        ProgrammingError.passert(False, "test")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    # Negative test cases
    try:
        ProgrammingError.passert(True, "test")
    except ProgrammingError as e:
        assert False

# Generated at 2022-06-21 20:20:04.372456
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("some_text")