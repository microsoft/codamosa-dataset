

# Generated at 2022-06-21 20:11:36.369385
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the behavior of the constructor of :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:11:38.727520
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given a message for a ProgrammingError
    message = "This is a ProgrammingError"

    # When the constructor is called
    error = ProgrammingError(message)

    # Then the error message is the expected
    assert error.args[0] == message

# Generated at 2022-06-21 20:11:42.239225
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:11:44.512955
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    # WHEN
    error = ProgrammingError()
    # THEN
    assert error is not None


# Generated at 2022-06-21 20:11:47.597753
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as exc:
        assert exc.__cause__ is None
        assert exc.__context__ is None
        assert exc.__suppress_context__ is False


# Generated at 2022-06-21 20:11:49.239820
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("Error message")


# Generated at 2022-06-21 20:11:53.393323
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        actual_message = str(e)
    expected_message = "Broken coherence. Check your code against domain logic to fix it."
    assert actual_message == expected_message


# Generated at 2022-06-21 20:12:00.938175
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as e:
        assert(str(e) == "This is an error")
    assert(ProgrammingError.passert(True, "This is an error"))
    try:
        ProgrammingError.passert(False, "This is an error")
        assert False
    except ProgrammingError as e:
        assert(str(e) == "This is an error")
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert(str(e) == "Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-21 20:12:06.482196
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError() must raise"
    try:
        ProgrammingError("Msg")
    except ProgrammingError as err:
        assert str(err) == "Msg"
    else:
        assert False, "ProgrammingError('Msg') must raise"

# Generated at 2022-06-21 20:12:08.179328
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test") as exc:
        raise exc


# Generated at 2022-06-21 20:12:19.420713
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-21 20:12:23.475327
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test if class ProgrammingError has the expected default behaviour.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
        assert repr(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "Expected ProgrammingError"



# Generated at 2022-06-21 20:12:27.967838
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError(message="Here is an error.")
    assert "Here is an error." in str(excinfo.value)


# Generated at 2022-06-21 20:12:31.421980
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    was_raised = False
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as e:
        was_raised = e
    assert isinstance(was_raised, ProgrammingError)
    assert was_raised.args[0] == "A message"


# Generated at 2022-06-21 20:12:33.001344
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert str(error) == "None"

# Generated at 2022-06-21 20:12:34.436570
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Foo bar.")


# Generated at 2022-06-21 20:12:37.101994
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 20:12:39.696444
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Asserts the initialization of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args == ("Test",)


# Generated at 2022-06-21 20:12:42.861830
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a message")
    except ProgrammingError as ex:
        assert ex.args[0]=="This is a message"

# Generated at 2022-06-21 20:12:54.233608
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError('message')
    assert e.args[0] == 'message'
    assert isinstance(e, Exception)
    assert isinstance(e, ProgrammingError)

    ProgrammingError.passert(True, '')
    ProgrammingError.passert(True, 'any message')

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == 'Broken coherence. Check your code against domain logic to fix it.'

    try:
        ProgrammingError.passert(False, 'any message')
    except ProgrammingError as e:
        assert e.args[0] == 'any message'


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 20:12:59.399063
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as error:
        pass
    assert isinstance(error, ProgrammingError)


# Generated at 2022-06-21 20:13:01.554691
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class :py:class:`ProgrammingError`.
    """
    ProgrammingError("Testing constructor")


# Generated at 2022-06-21 20:13:03.896525
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:13:09.733106
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "test")
    except ProgrammingError as e:
        assert False, "ProgrammingError should not raise exception if condition is True"
    try:
        ProgrammingError.passert(False, "test")
        assert False, "ProgrammingError should raise exception if condition is False"
    except ProgrammingError as e:
        assert True, "ProgrammingError should raise exception if condition is False"
        assert e.args[0] == "test", "ProgrammingError should raise exception with message test if condition is False"

# Generated at 2022-06-21 20:13:15.139269
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, None)
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as error:
        assert error.args[0] == "This is a test"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:13:21.876949
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Raises ProgrammingError when testing condition is not met
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "unexpected condition is met")

    # Only a warning is issued when the condition is met
    ProgrammingError.passert(True, "expected condition is not met")

# Generated at 2022-06-21 20:13:23.933389
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)

# Generated at 2022-06-21 20:13:27.766246
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Boo!")
    except ProgrammingError as e:
        assert str(e) == "Boo!"
    else:
        raise AssertionError("Expected 'ProgrammingError' to be raised.")


# Generated at 2022-06-21 20:13:30.253071
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="Testing")
    except ProgrammingError as e:
        assert e.message == "Testing"


# Generated at 2022-06-21 20:13:32.864389
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        assert True
    except AssertionError:
        raise ProgrammingError("Incorrect test case.")

# Generated at 2022-06-21 20:13:43.581760
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of class ProgrammingError.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."

    try:
        raise ProgrammingError("My specific error message")
    except ProgrammingError as error:
        assert str(error) == "My specific error message"



# Generated at 2022-06-21 20:13:49.511276
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Something is not right.")
    except ProgrammingError as err:
        assert err.args[0] == "Something is not right."
    else:
        raise AssertionError("Missing exception.")


# Generated at 2022-06-21 20:13:50.769060
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:13:54.354568
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error message.")
    except Exception as ex:
        assert ex.args == ("This is an error message.",)



# Generated at 2022-06-21 20:14:05.800924
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Check this")
    except ProgrammingError as err:
        assert err.args[0] == "Check this"

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as err:
        assert err.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as err:
        assert err.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(False, "        ")
    except ProgrammingError as err:
        assert err.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:14:09.830593
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, None)
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert True

# Generated at 2022-06-21 20:14:11.481524
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:14:15.049427
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an error")
        assert False, "ProgrammingError was not raised"
    except ProgrammingError as e:
        assert "This is an error" in e.args[0]

# Generated at 2022-06-21 20:14:18.605834
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Testing behavior of constructor with valid input, should be fine.
    ProgrammingError.passert(True, "Should not trigger")
    # Testing behavior of constructor with invalid input, should raise error.
    try:
        ProgrammingError.passert(False, "Should raise exception")
        assert False
    except ProgrammingError:
        assert True

# Generated at 2022-06-21 20:14:22.635827
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("This is a programming error")



# Generated at 2022-06-21 20:14:35.511270
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error de programación")
    except ProgrammingError as e:
        assert "Error de programación" == str(e)


# Generated at 2022-06-21 20:14:37.938485
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error")
    except ProgrammingError as ex:
        assert ex.args == ("Error",)


# Generated at 2022-06-21 20:14:40.437842
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError:
        pass
    except Exception:
        raise AssertionError("ProgrammingError should have been raised.")

# Generated at 2022-06-21 20:14:42.660753
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        assert False
    except AssertionError:
        try:
            raise ProgrammingError()
        except ProgrammingError as e:
            assert "Broken coherence. Check your code against domain logic to fix it." == str(e)

# Generated at 2022-06-21 20:14:46.320252
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.util.logging import set_log_level

    # Test that the constructor works as expected
    set_log_level("WARNING")
    with raises(ProgrammingError):
        ProgrammingError("This is a programming error")



# Generated at 2022-06-21 20:14:48.598503
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("")
    except ProgrammingError:
        pass  # Expected

# Generated at 2022-06-21 20:14:51.106505
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "This is the error message")


# Generated at 2022-06-21 20:14:56.116792
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Programming error message text.")
    except ProgrammingError as e:
        assert(e.args[0] == "Programming error message text.")
    else:
        raise AssertionError("ProgrammingError() does not work.")



# Generated at 2022-06-21 20:14:57.568000
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(condition=False, message="Check your code"):
        pass

# Generated at 2022-06-21 20:15:00.120169
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError().args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:15:24.635948
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    This method tests the constructor of class :py:class:`ProgrammingError`.
    """
    error = ProgrammingError("test")
    assert isinstance(error, ProgrammingError)
    assert str(error) == "test"
    assert repr(error) == "ProgrammingError('test',)"


# Generated at 2022-06-21 20:15:25.451887
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "")

# Generated at 2022-06-21 20:15:27.173629
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of class ProgrammingError."""
    e = ProgrammingError("Hello")
    assert str(e) == "Hello"


# Generated at 2022-06-21 20:15:30.342086
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(Exception) as e:
        raise ProgrammingError("Test")
    assert str(e.value) == "Test"
    assert isinstance(e.value, ProgrammingError)


# Generated at 2022-06-21 20:15:32.731980
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something is wrong")
    except ProgrammingError as e:
        assert e.args[0] == "Something is wrong"

# Generated at 2022-06-21 20:15:36.642553
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("error message")
    except ProgrammingError as error:
        assert error.args[0] == "error message"


# Generated at 2022-06-21 20:15:42.530708
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for :py:class:`ProgrammingError`.
    """
    try:
        from pypara.asserts import Asserts

        Asserts.passert(True, "Message")
    except ProgrammingError as e:
        raise AssertionError("ProgrammingError expected to be raised") from e

# Generated at 2022-06-21 20:15:45.635021
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Verifies that the constructor of :py:class:`ProgrammingError` class does not fail.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:15:47.888979
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Because the constructor is trivial, we only check the module docstring
    assert ProgrammingError.__doc__ is not None


# Generated at 2022-06-21 20:15:50.108329
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="Test message")


# Generated at 2022-06-21 20:16:45.016267
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, message = None)

# Generated at 2022-06-21 20:16:46.900153
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
        assert False
    except ProgrammingError:
        assert True


# Generated at 2022-06-21 20:16:52.164259
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Expect to fail without exception
    try:
        ProgrammingError.passert(False, "Median cannot be computed on an empty array")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Programming error should have been raised")
    # Expect to succeed without exception
    ProgrammingError.passert(True, "Median cannot be computed on an empty array")

# Generated at 2022-06-21 20:16:54.245401
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("something went wrong")
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:16:56.303256
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:17:00.338938
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("foo")
    except ProgrammingError as e:
        assert str(e) == "foo"
    else:
        assert False, "This point must not have been reached."


# Generated at 2022-06-21 20:17:03.152091
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something is wrong!")
    except ProgrammingError as err:
        assert str(err) == "Something is wrong!"


# Generated at 2022-06-21 20:17:06.561389
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "error")
    except ProgrammingError as error:
        assert str(error) == "error"

# Generated at 2022-06-21 20:17:08.530955
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Broken coherence."):
        pass

# Generated at 2022-06-21 20:17:14.847509
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "Foo")
    assert "Foo" in str(excinfo.value)
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, None)
    assert "Broken coherence" in str(excinfo.value)
    assert "Check your code against domain logic to fix it." in str(excinfo.value)

# Generated at 2022-06-21 20:19:18.329989
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("A programming error")

# Generated at 2022-06-21 20:19:21.302107
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:19:21.904276
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test")

# Generated at 2022-06-21 20:19:24.872000
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError

    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:19:27.859507
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as error:
        assert error.__str__() == "test", "Expected 'test' but got {}".format(error.__str__())


# Generated at 2022-06-21 20:19:31.446374
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.testing import assert_raises
    assert_raises(ProgrammingError, ProgrammingError.passert, False, "test")
    # no error should be raised in case that the condition is true
    ProgrammingError.passert(True, "test")

# Generated at 2022-06-21 20:19:33.202367
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        err = ProgrammingError("A")
        assert err.args == ("A",)
    except:
        assert False


# Generated at 2022-06-21 20:19:36.664635
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-21 20:19:38.571529
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError(message=""):
        ProgrammingError.passert(False, "")

# Generated at 2022-06-21 20:19:40.811173
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError('This is a test error')
    assert str(err) == 'This is a test error'
