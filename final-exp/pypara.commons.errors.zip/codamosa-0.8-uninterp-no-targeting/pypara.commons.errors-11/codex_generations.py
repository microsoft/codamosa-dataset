

# Generated at 2022-06-21 20:11:34.535052
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an error")
    except ProgrammingError as exc:
        assert isinstance(exc.args, tuple)
        assert len(exc.args) == 1
        assert "This is an error" in exc.args[0]
    else:
        raise AssertionError("Test should have failed")

# Generated at 2022-06-21 20:11:36.892828
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        if not e.args:
            raise AssertionError("ProgrammingError exception throws no message by default.")


# Generated at 2022-06-21 20:11:38.425676
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert "test" == str(e)


# Generated at 2022-06-21 20:11:42.239542
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:11:44.512973
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    err = ProgrammingError("Testing")
    assert str(err) == "Testing"

# Generated at 2022-06-21 20:11:48.197133
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of class :py:class:`ProgrammingError`.

    :raises AssertionError: if the unit test fails.
    """
    assert isinstance(ProgrammingError(), ProgrammingError)
    assert isinstance(ProgrammingError("Error"), ProgrammingError)


# Generated at 2022-06-21 20:11:49.238274
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error.args == ()

# Generated at 2022-06-21 20:11:52.739860
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is the message defined for it.")
    except ProgrammingError as err:
        print(err)
        assert err.args[0] == "This is the message defined for it."


# Generated at 2022-06-21 20:11:54.528151
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("{test}")
    except ProgrammingError as e:
        assert str(e) == "{test}"


# Generated at 2022-06-21 20:11:59.531782
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Not Implemented")
    except ProgrammingError as p:
        assert str(p) == "Not Implemented"
    else:
        assert False
    add_two = lambda x: x + 2
    ProgrammingError.passert(add_two(2) == 4, "Conditions have not been met")

# Generated at 2022-06-21 20:12:03.733609
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given:
    message = "This is my message."
    # When:
    error = ProgrammingError(message)
    # Then:
    assert error.args == (message,)



# Generated at 2022-06-21 20:12:09.015942
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Failed")
    except ProgrammingError as e:
        assert str(e) == "Failed"
    else:
        raise AssertionError("ProgrammingError.passert didn't raise ProgrammingError when condition is not met")

# Generated at 2022-06-21 20:12:11.597310
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Foo")
    except ProgrammingError as e:
        assert(e.args[0] == "Foo")


# Generated at 2022-06-21 20:12:15.347371
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:12:17.566528
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests if subclass :py:class:`ProgrammingError` raises working."""
    from pytest import raises
    with raises(ProgrammingError):
        raise ProgrammingError


# Generated at 2022-06-21 20:12:20.969171
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError` constructor.
    """

    try:
        raise ProgrammingError("Test error.")
    except ProgrammingError as ex:
        assert str(ex) == "Test error."



# Generated at 2022-06-21 20:12:23.405852
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "This is an example."
    exception = ProgrammingError(message)
    assert exception.args == (message,)


# Generated at 2022-06-21 20:12:27.929768
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "Expected to fail")

    assert str(excinfo.value) == "Expected to fail"


# Generated at 2022-06-21 20:12:32.785706
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    from unittest import TestCase
    from pypara import ProgrammingError

    with TestCase.assertRaises(TestCase, ProgrammingError):
        ProgrammingError()

    with TestCase.assertRaises(TestCase, ProgrammingError):
        ProgrammingError.passert(False, "Test message")

    ProgrammingError.passert(True, "Test message")


# Generated at 2022-06-21 20:12:36.662317
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test of ProgrammingError.")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test of ProgrammingError."
        return
    raise Exception("Expected ProgrammingError to be raised")



# Generated at 2022-06-21 20:12:39.155932
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("test")
    assert error.message == "test"

# Generated at 2022-06-21 20:12:40.932858
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("Anything")


# Generated at 2022-06-21 20:12:53.125675
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    This function tests the behavior of the ProgrammingError constructor for:

    * The condition is met
    * The condition is not met and the message is None
    * The condition is not met and the message is not None.
    """
    # Act
    try:
        ProgrammingError.passert(condition=True, message=None)

        support = True
    except:
        support = False

    try:
        ProgrammingError.passert(condition=False, message=None)

        assert False, "Should have failed"
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(condition=False, message="My message")

        assert False, "Should have failed"
    except ProgrammingError as e:
        assert "My message" == str(e)

    # Assert

# Generated at 2022-06-21 20:12:57.646057
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:12:58.950567
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test message")

# Generated at 2022-06-21 20:13:04.986123
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Expected message")
        assert False, "Exception ProgrammingError not thrown"
    except ProgrammingError as e:
        assert str(e) == "Expected message", "Unexpected message"
    try:
        ProgrammingError.passert(False, None)
        assert False, "Exception ProgrammingError not thrown"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it.", "Unexpected message"

# Generated at 2022-06-21 20:13:09.378795
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Expected ProgrammingError"


# Generated at 2022-06-21 20:13:13.777288
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the class :py:class:`ProgrammingError`.
    """

    # Asserts that a ProgrammingError is raised when the condition is not met.
    exception_raised = False
    try:
        ProgrammingError.passert(False, "Bad usage")
    except ProgrammingError:
        exception_raised = True
    assert exception_raised

# Generated at 2022-06-21 20:13:15.910686
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    pass

# Generated at 2022-06-21 20:13:20.289993
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "It fails, as expected")
        ProgrammingError.passert(True, "It should not be raised")
    ProgrammingError.passert(True, None)

# Generated at 2022-06-21 20:13:23.933331
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Message"):
        pass

    with ProgrammingError.passert(False, "Message"):
        pass

# Generated at 2022-06-21 20:13:28.079497
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a custom error message")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert e.args[0] == "This is a custom error message"
    else:
        raise RuntimeError("Command not processed")


# Generated at 2022-06-21 20:13:37.413158
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        from unittest.mock import call

        ProgrammingError.passert(True, "Only appears when it goes bad.")
        assert False, "Check condition was True, it should not have raised a ProgrammingError."
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    try:
        from unittest.mock import call

        ProgrammingError.passert(False, "Only appears when it goes bad.")
        assert False, "Check condition was False, it should have raised a ProgrammingError."
    except ProgrammingError as e:
        assert str(e) == "Only appears when it goes bad."

# Generated at 2022-06-21 20:13:41.477701
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    from pypara import ProgrammingError
    from pyassert import that
    
    with that(ProgrammingError).raises(ProgrammingError, "Broken coherence. Check your code against domain logic to fix it."):
        ProgrammingError()


# Generated at 2022-06-21 20:13:44.204290
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Testing exception"):
        pass

# Generated at 2022-06-21 20:13:48.976287
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check that the base class is Exception
    assert issubclass(ProgrammingError, Exception)
    # Check that the message is stored correctly
    assert str(ProgrammingError("This is a test message")) == "This is a test message"


# Generated at 2022-06-21 20:13:50.817135
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as exception:
        # Verify the message
        assert str(exception) == "Test"



# Generated at 2022-06-21 20:13:55.855255
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as exception:
        raise ProgrammingError()
    assert str(exception.value) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:13:58.081139
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-21 20:14:03.325354
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`
    """
    assert issubclass(ProgrammingError, Exception)
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    try:
        ProgrammingError("foo")
    except ProgrammingError as e:
        assert str(e) == "foo"


# Generated at 2022-06-21 20:14:10.309361
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Unit test case")
    except ProgrammingError as e:
        assert str(e) == "Unit test case"


# Generated at 2022-06-21 20:14:16.382472
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Something went wrong")
        assert False, "ProgrammingError.passert(False, ...) should have raised ProgrammingError"
    except ProgrammingError as e:
        assert str(e) == "Something went wrong"
    try:
        ProgrammingError.passert(True, "Something went wrong")
    except ProgrammingError:
        assert False, "ProgrammingError.passert(True, ...) should not have raised ProgrammingError"

# Generated at 2022-06-21 20:14:18.532443
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Test")
    except ProgrammingError as error:
        assert str(error) == "Test", "Wrong message in exception."


# Generated at 2022-06-21 20:14:24.837972
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    This test checks the constructor of class ProgrammingError
    """

    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as err:
        print("Expected exception: {0}".format(err))



# Generated at 2022-06-21 20:14:27.351960
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of :py:class:`ProgrammingError`."""
    try:
        raise ProgrammingError("A programming error has arisen.")
    except ProgrammingError as ex:
        print(ex)


# Generated at 2022-06-21 20:14:32.189550
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message = None)
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-21 20:14:33.916088
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    assert ProgrammingError(message="This is the message")


# Generated at 2022-06-21 20:14:37.790633
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    bad_condition = False
    good_condition = True
    message = "Expectation not met."
    try:
        ProgrammingError.passert(bad_condition, message)
    except ProgrammingError as pe:
        assert pe.args[0] == message
    ProgrammingError.passert(good_condition, message)

# Generated at 2022-06-21 20:14:42.173012
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("This is an error.")
    except ProgrammingError as e:
        assert str(e) == "This is an error."
    try:
        ProgrammingError.passert(False, "Forcing an error.")
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:14:44.424479
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Foo")
    except Exception as error:
        assert error.args[0] == "Foo"


# Generated at 2022-06-21 20:14:53.924450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("error description")
    except ProgrammingError as e:
        assert "error description" == e.args[0]


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-21 20:14:54.713994
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    pass

# Generated at 2022-06-21 20:14:57.932298
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.
    """
    assert ProgrammingError("Programming error is shown").args[0] == "Programming error is shown"

# Generated at 2022-06-21 20:15:00.444838
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("MESSAGE")
    assert isinstance(err, ProgrammingError)
    assert str(err) == "MESSAGE"

# Generated at 2022-06-21 20:15:04.117143
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something went wrong in your domain logic.")
    except ProgrammingError as e:
        assert "Something went wrong" in str(e)


# Generated at 2022-06-21 20:15:08.172748
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test error message")
    except ProgrammingError as err:
        assert str(err) == "Test error message"
    else:
        raise Exception("Should have thrown an exception")


# Generated at 2022-06-21 20:15:10.054483
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "foo bar"):
        pass


# Generated at 2022-06-21 20:15:12.612123
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    exception = ProgrammingError("A message")

    assert str(exception) == "A message"


# Generated at 2022-06-21 20:15:15.127097
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests successful initialization of :py:class:`ProgrammingError` class.
    """
    ProgrammingError("Mensaje de error")


# Generated at 2022-06-21 20:15:18.887561
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)

# Generated at 2022-06-21 20:15:33.899543
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Pass
    try:
        ProgrammingError.passert(True, "Pass")
    except ProgrammingError:
        assert False, "Programming error has been raised"

    # Fail
    try:
        ProgrammingError.passert(False, "Fail")
        assert False, "Programming error has not been raised"
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:15:36.572381
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
  try:
    raise ProgrammingError("It has failed!")
  except ProgrammingError as e:
    assert str(e) == "It has failed!"


# Generated at 2022-06-21 20:15:38.933270
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message = "Error")

# Generated at 2022-06-21 20:15:42.230924
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("testing a simple constructor")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError should raise an exception when called")


# Generated at 2022-06-21 20:15:46.153220
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Act
    try:
        ProgrammingError(None)
    except ProgrammingError as exception:
        # Assert
        assert "Broken coherence. Check your code against domain logic to fix it." == exception.args[0]
    else:
        raise Exception("ProgrammingError was not raised.")

# Generated at 2022-06-21 20:15:50.642022
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for the constructor of class :py:class:`ProgrammingError`.
    """

    # Test for invoking the constructor
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

    # Test for invoking the constructor with a message
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:15:52.913508
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some message.")

    except ProgrammingError as e:
        assert str(e) == "Some message."


# Generated at 2022-06-21 20:15:55.007849
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.testing.wisdom import has_message

    has_message(ProgrammingError(), "Broken coherence. Check your code against domain logic to fix it.")
    has_message(ProgrammingError("message"), "message")



# Generated at 2022-06-21 20:15:56.537071
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError):
        ProgrammingError("test message")

# Generated at 2022-06-21 20:15:58.741934
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as e:
        assert(e.__class__ == ProgrammingError)


# Generated at 2022-06-21 20:16:29.187368
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
        assert False, "Unexpected success"
    except ProgrammingError as e:
        assert e.args[0] == "Test"

# Generated at 2022-06-21 20:16:34.664667
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Raise a programming error
    try:
        ProgrammingError.passert(False, "Test the assertion of a programming error")
        assert True, "Should not have reached this point"
    except ProgrammingError:
        pass
    # Do not raise a programming error
    try:
        ProgrammingError.passert(True, "Test the assertion of a programming error")
        assert True, "Should have reached this point"
    except ProgrammingError:
        assert True, "Should not have reached this point"

# Generated at 2022-06-21 20:16:37.991217
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests instantiation of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError(message="Dummy error")
    except ProgrammingError as error:
        assert isinstance(error, ProgrammingError)
        assert str(error) == "Dummy error"


# Generated at 2022-06-21 20:16:40.145815
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.flow.exceptions import ProgrammingError
    try:
        ProgrammingError.passert(False, "This is a test. All is well.")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test. All is well."


# Generated at 2022-06-21 20:16:42.944765
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as ex:
        assert isinstance(ex, ProgrammingError)


# Generated at 2022-06-21 20:16:47.293087
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("This is a test.")
    assert exception.args[0] == "This is a test."

    # Ensure that exceptions are catchable
    try:
        raise exception
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:16:52.123750
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Failure case
    try:
        ProgrammingError.passert(False, "")
        assert False, "Expected an exception to have been raised"
    except ProgrammingError:
        pass

    # Success case
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        assert False, "Did not expected an exception"

# Generated at 2022-06-21 20:16:55.129820
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error message.")
    except ProgrammingError as exc:
        assert exc.args[0] == "Some error message."
        return
    assert False

# Generated at 2022-06-21 20:17:00.286874
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test case for the constructor of class :py:class:`ProgrammingError`.
    """

    try:
        ProgrammingError("This is a test")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Constructor of class ProgrammingError must raise an error")



# Generated at 2022-06-21 20:17:07.668042
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Instantiate an instance, but must fail due to lack of message
    try:
        ProgrammingError()
    except TypeError:
        pass # This is the expected behavior
    else:
        raise AssertionError("This test must pass because it must fail due to TypeError exception.")
    # Instantiate an instance
    try:
        ProgrammingError("This is a valid error message.")
    except ProgrammingError:
        pass # This is the expected behavior
    else:
        raise AssertionError("This test must pass because it must fail due to ProgrammingError exception.")

# Generated at 2022-06-21 20:18:05.990210
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test error message")
    except ProgrammingError as e:
        assert str(e) == "Test error message"

# Generated at 2022-06-21 20:18:08.108568
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error_msg="test msg"
    try:
        raise ProgrammingError(error_msg)
    except ProgrammingError as e:
        assert e.args[0] == error_msg


# Generated at 2022-06-21 20:18:09.385370
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Error message")
    except ProgrammingError as ignore:
        pass


# Generated at 2022-06-21 20:18:11.532929
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Message")
    assert str(error) == "Message"


# Generated at 2022-06-21 20:18:21.115934
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError` by testing the :py:meth:`ProgrammingError.passert` method.
    """
    try:
        ProgrammingError.passert(True, "Expected error message.")
    except ProgrammingError as pe:
        # Check exception message
        assert(str(pe) == "Expected error message.")
        # Check exception object
        assert(isinstance(pe, ProgrammingError))
        # Check exception type
        assert(type(pe) is ProgrammingError)
    else:
        raise Exception("ProgrammingError.passert works as an assertion when a condition is not met.")


# Generated at 2022-06-21 20:18:25.846497
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if :py:func:`ProgrammingError.__init__` raises a ``ProgrammingError``.
    """
    # Test
    try:
        raise ProgrammingError("Forced exception.")
    except ProgrammingError as e:
        assert str(e) == "Forced exception."


# Generated at 2022-06-21 20:18:27.302257
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError is not None

# Generated at 2022-06-21 20:18:30.321792
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is an error.")
    except ProgrammingError as e:
        assert str(e) == "This is an error."


# Generated at 2022-06-21 20:18:31.782211
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:18:36.322854
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    from pypara.common.errors import ProgrammingError

    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "Test error")
    assert "Test error" in str(excinfo.value)


# Generated at 2022-06-21 20:20:30.493845
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-21 20:20:32.483304
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as error:
        assert error.message == "This is an error"

# Generated at 2022-06-21 20:20:34.271950
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:20:36.053085
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"

if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-21 20:20:39.590672
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert True
    else:
        assert False



# Generated at 2022-06-21 20:20:41.653563
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message for unit test")
    except ProgrammingError as e:
        assert str(e) == "Error message for unit test"


# Generated at 2022-06-21 20:20:44.967334
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    with ProgrammingError.passert(False, "This is the message") as ctx:
        ProgrammingError.passert(True, "This message is not important as we always follow with a raise.")
        raise ValueError("This exception should never be called")

# Generated at 2022-06-21 20:20:48.881443
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "foo")
    except ProgrammingError as error:
        assert str(error) == "foo"


# Generated at 2022-06-21 20:20:51.244564
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("message")



# Generated at 2022-06-21 20:20:55.760695
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "message")
    except ProgrammingError:  # pragma: no cover
        assert False
    try:
        ProgrammingError.passert(False, "message")
        assert False
    except ProgrammingError as e:
        assert isinstance(e.args[0], str)