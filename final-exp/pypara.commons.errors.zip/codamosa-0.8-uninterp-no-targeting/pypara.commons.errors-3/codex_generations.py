

# Generated at 2022-06-21 20:11:31.162085
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("something wrong!")


# Generated at 2022-06-21 20:11:34.415841
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Expected error message.")
    except ProgrammingError as e:
        assert str(e) == "Expected error message."


# Generated at 2022-06-21 20:11:36.478875
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a message")
    except Exception as e:
        assert e.message == "This is a message"
        raise


# Generated at 2022-06-21 20:11:39.621092
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Bar")
    except ProgrammingError as error:
        assert error.args[0] == "Bar"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:11:43.706570
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Hello world!")
        assert False # pragma: no cover
    except ProgrammingError as e:
        assert e.args[0] == "Hello world!"


# Generated at 2022-06-21 20:11:45.814379
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Oops!")
    except ProgrammingError as error:
        assert error.args == ("Oops!",)

# Generated at 2022-06-21 20:11:53.629682
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.utilities.helper import validate_type_decorator
    from pypara.utilities.helper import validate_values_decorator

    @validate_type_decorator(message="Invalid exception message")
    def my_test_method(message: str) -> None:
        raise ProgrammingError(message)

    @validate_values_decorator(values=[True, False], message="Invalid condition")
    def my_test_method2(condition: bool) -> None:
        ProgrammingError.passert(condition, "Assertion failed.")

    # The following statements will not raise any exceptions
    my_test_method("Test exception")
    my_test_method2(True)

    # The following statements will raise exception

# Generated at 2022-06-21 20:11:56.895419
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Pokus")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Pokus"


# Generated at 2022-06-21 20:11:59.409772
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something went wrong")
    except ProgrammingError as e:
        assert e.args[0] == "Something went wrong"


# Generated at 2022-06-21 20:12:01.148272
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is an error")
    except Exception as e:
        assert str(e) == "This is an error"

# Generated at 2022-06-21 20:12:04.940761
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Message for test"):
        pass

# Generated at 2022-06-21 20:12:11.764706
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Oops!")
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(True, "Oops!")
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(True, None)

# Generated at 2022-06-21 20:12:14.040355
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyProtectedMember
    assert ProgrammingError._ProgrammingError__passert
    assert ProgrammingError.passert

# Generated at 2022-06-21 20:12:15.688438
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e)


# Generated at 2022-06-21 20:12:17.566040
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("The following code has been marked as erroneous")
    except Exception as e:
        assert type(e) == ProgrammingError

# Generated at 2022-06-21 20:12:22.531112
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class ProgrammingErrorTest(ProgrammingError):
        """
        Sample subclass for testing the constructor of the base class :py:class:`ProgrammingError`.
        """
    pe = ProgrammingErrorTest("Sample test error")
    assert isinstance(pe, ProgrammingError)
    assert pe.args == ("Sample test error",)

# Generated at 2022-06-21 20:12:23.672543
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError('foo')


# Generated at 2022-06-21 20:12:29.264792
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    This unit test checks the correctness of the ProgrammingError constructor.

    :return: Pass if the constructor works.
    """
    try:
        ProgrammingError("Testing ProgrammingError")
    except ProgrammingError:
        return
    else:
        raise ProgrammingError("The ProgrammingError constructor is not working.")


# Generated at 2022-06-21 20:12:31.163585
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        # noinspection PyStatementEffect
        ProgrammingError("not really a programming error")


# Generated at 2022-06-21 20:12:36.277517
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as e:
        raise ProgrammingError()
    assert str(e.value) is None

    with pytest.raises(ProgrammingError) as e:
        raise ProgrammingError("message")
    assert str(e.value) is "message"


# Generated at 2022-06-21 20:12:39.720271
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

test_ProgrammingError()


# Generated at 2022-06-21 20:12:42.907942
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("msg")
    except ProgrammingError as e:
        assert e.args[0] == "msg"


# Generated at 2022-06-21 20:12:46.502182
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as ex:
        assert(isinstance(ex, ProgrammingError)), "The exception is not of type 'ProgrammingError'."


# Generated at 2022-06-21 20:12:50.086642
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests whether the constructor of :py:class:`ProgrammingError` works as expected.
    """
    exc = ProgrammingError()
    assert exc.args == ("Broken coherence. Check your code against domain logic to fix it.", )

# Generated at 2022-06-21 20:12:52.194270
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as exc:
        assert exc.__cause__ is None
        assert exc.__traceback__ is None
        pass



# Generated at 2022-06-21 20:12:54.707939
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error



# Generated at 2022-06-21 20:13:00.744534
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Test should not raise")
    except Exception as e:  # E722; pylint: disable=bare-except
        pass

    try:
        ProgrammingError.passert(False, "Test should raise")
        assert False, "Should not reach this point"
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:13:03.170589
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("What a question!")
    assert e.args[0] == "What a question!"
    assert str(e) == "What a question!"


# Generated at 2022-06-21 20:13:11.131981
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Error")
    except ProgrammingError as ex:
        assert False, "Test should not execute this point."
    try:
        ProgrammingError.passert(False, "Error message")
    except ProgrammingError as ex:
        assert ex.args[0] == "Error message"
    except Exception as ex:
        assert False, "Test should not execute this point. Expected ProgrammingError not {}".format(type(ex))
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as ex:
        assert ex.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    except Exception as ex:
        assert False, "Test should not execute this point. Expected ProgrammingError not {}".format(type(ex))

# Generated at 2022-06-21 20:13:13.609865
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:13:20.289173
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test the constructor of :py:class:`ProgrammingError`."""
    e = ProgrammingError("Something bad happened.")
    assert e.args == ("Something bad happened.",)


# Generated at 2022-06-21 20:13:23.486643
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as exception:
        assert str(exception) == "Test message"


# Generated at 2022-06-21 20:13:24.233062
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    getattr(ProgrammingError, '__init__')

# Generated at 2022-06-21 20:13:27.311314
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError()
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError("Test exception.")


# Generated at 2022-06-21 20:13:31.046784
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "fake message"):
        pass
    try:
        with ProgrammingError.passert(False, None):
            pass
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:13:33.256407
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError):
        # noinspection PyTypeChecker
        ProgrammingError()

# Generated at 2022-06-21 20:13:34.236641
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()


# Generated at 2022-06-21 20:13:37.501356
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(message="Just testing")
        ProgrammingError.passert(condition=False, message="Just testing")

# Generated at 2022-06-21 20:13:39.114592
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("Broken coherence")


# Generated at 2022-06-21 20:13:39.927158
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    pass

# Generated at 2022-06-21 20:13:49.337438
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Broken coherence")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert e.args[0] == "Broken coherence"


# Generated at 2022-06-21 20:13:51.904072
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Expected to fail.")
    except ProgrammingError as err:
        assert err.args == ("Expected to fail.",)

test_ProgrammingError()

# Generated at 2022-06-21 20:13:56.966489
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Check your program for coherence!")
    except ProgrammingError as error:
        assert error.args[0] == "Check your program for coherence!"


# Generated at 2022-06-21 20:14:00.473593
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as error:
        assert error.args[0] == "Test"


# Generated at 2022-06-21 20:14:03.166349
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "Some sample message"
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as pe:
        assert pe.args[0] == msg



# Generated at 2022-06-21 20:14:06.953066
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Error message")
    except ProgrammingError as e:
        assert str(e) == "Error message"
        assert e.args[0] == "Error message"
        print("The constructor of the class ProgrammingError works")


# Generated at 2022-06-21 20:14:12.802397
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Just for testing.")
        raise Exception("Failed to catch ProgrammingError.")
    except ProgrammingError:
        pass
    else:
        raise Exception("Failed to catch ProgrammingError.")


from .paradoc import *
from .paradoc_oracles import *
from .paradoc_utils import *

# Generated at 2022-06-21 20:14:15.471792
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Computer says no.")
    except ProgrammingError as err:
        assert err.args[0] == "Computer says no."


# Generated at 2022-06-21 20:14:17.690562
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error message")
    except ProgrammingError as e:
        assert str(e) == "Some error message"


# Generated at 2022-06-21 20:14:18.810535
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(condition=False, message="Fake error. Delete it!")

# Generated at 2022-06-21 20:14:34.853673
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check with a broken condition
    try:
        ProgrammingError.passert(False, "This is a message")
        assert False, "An error should be raised"
    except ProgrammingError as ex:
        assert ex.args[0] == "This is a message", "The message does not match"
    # Check with a fulfilled condition
    ProgrammingError.passert(True, "This is a message")

# Generated at 2022-06-21 20:14:38.665579
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test constructor.
    """

    # GIVEN a message
    message = "This should be raised."

    # WHEN calling the constructor
    programming_error = ProgrammingError(message)

    # THEN it should be returned the same message
    assert programming_error.args[0] == message


# Generated at 2022-06-21 20:14:39.503218
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(1==1, "Message")

# Generated at 2022-06-21 20:14:44.501387
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("There is a bug in your code")  # TODO: Write more useful exception
    assert exception.message == "There is a bug in your code"
    assert str(exception) == "ProgrammingError: There is a bug in your code"


# Generated at 2022-06-21 20:14:50.424829
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Success case
    try:
        ProgrammingError.passert(True, "Hello world!")
    except ProgrammingError:
        assert False

    # Failure cases
    try:
        ProgrammingError.passert(False, "Hello world!")
        assert False
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:14:53.203317
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest.mock import Mock

    # GIVEN
    fake_condition = True
    fake_message = "Oops!"

    # WHEN
    try:
        ProgrammingError.passert(fake_condition, fake_message)
    except:
        fake_exception = Mock()
        raise fake_exception

    # THEN
    fake_exception.assert_not_called()



# Generated at 2022-06-21 20:14:56.640449
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an error")
    except ProgrammingError as e:
        assert str(e) == "This is an error"

# Generated at 2022-06-21 20:15:01.452211
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pyhocon import ConfigFactory

    try:
        ProgrammingError.passert(ConfigFactory.parse_string("").get_bool("a.b.c.d"),
                                 "no bool value here, then fail")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "no bool value here, then fail"

# Generated at 2022-06-21 20:15:06.281413
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error.args == ()
    assert error.__class__.__name__ == "ProgrammingError"
    error = ProgrammingError("test message")
    assert error.args == ("test message",)


# Generated at 2022-06-21 20:15:09.557962
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a ProgrammingError.")
    except ProgrammingError as error:
        assert error.args[0] == "This is a ProgrammingError."

# Generated at 2022-06-21 20:15:33.038340
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something is wrong!")
    except ProgrammingError as e:
        assert str(e) == "Something is wrong!"


# Generated at 2022-06-21 20:15:35.597555
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("")
    except ProgrammingError as e:
        pass



# Generated at 2022-06-21 20:15:40.182409
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError constructor hasn't raised an error")
test_ProgrammingError.__test__ = False


# Generated at 2022-06-21 20:15:43.083204
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e)=="Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:15:46.606522
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, match='Broken coherence'):
        ProgrammingError()
    with pytest.raises(ProgrammingError, match='Test message'):
        ProgrammingError(message='Test message')



# Generated at 2022-06-21 20:15:49.668194
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(None)
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:15:55.113841
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as error:
        assert error.args[0] == "A message"


# Generated at 2022-06-21 20:15:58.022428
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    # noinspection PyProtectedMember
    assert issubclass(ProgrammingError, Exception)
    message = "Test message"
    assert str(ProgrammingError(message)) == message

# Generated at 2022-06-21 20:16:01.044900
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as error:
        assert isinstance(error, ProgrammingError)


# Generated at 2022-06-21 20:16:03.493602
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of class `ProgrammingError`.
    """
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Custom message")

# Generated at 2022-06-21 20:16:56.124651
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        raise AssertionError("ProgrammingError.passert(False, None) did not raise an exception")
    except ProgrammingError as e:
        if str(e) != "Broken coherence. Check your code against domain logic to fix it.":
            raise AssertionError("Wrong message raised by ProgrammingError.passert(False, None)")


# Generated at 2022-06-21 20:17:01.008781
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition = False, message = "Backup error")
    except ProgrammingError as err:
        assert str(err) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False


# Generated at 2022-06-21 20:17:04.046186
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "Mismatch of expectations."
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as e:
        assert e.args[0] == msg


# Generated at 2022-06-21 20:17:06.800923
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something broke. Runtime check has failed")
    except ProgrammingError as e:
        assert "Something broke. Runtime check has failed" == str(e)


# Generated at 2022-06-21 20:17:17.229721
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` class.

    .. hint:
        To run the unit test execute :command:`unittest pypara.errors.ProgrammingError` from the root directory of the repository.
    """

    assert issubclass(ProgrammingError, Exception)

    try:
        ProgrammingError.passert(False, "Test")
        assert False, "ProgrammingError.passert() did not raise an exception"
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(True, "Test")
    except ProgrammingError:
        assert False, "ProgrammingError.passert() raised an exception as the condition is True"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass

    error = ProgrammingError("Test")

# Generated at 2022-06-21 20:17:19.737610
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing")
    except ProgrammingError as e:
        assert e.args[0] == "Testing"


# Generated at 2022-06-21 20:17:25.639325
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This should raise an error")
    except ProgrammingError:
        assert True
    try:
        ProgrammingError.passert(True, "This should raise an error")
    except ProgrammingError:
        assert False
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        assert True

# Generated at 2022-06-21 20:17:30.368877
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that exception ``ProgrammingError`` can be instantiated with a message and without one.
    """
    e1 = ProgrammingError("Message for error 1.")
    assert str(e1) == "Message for error 1."
    e2 = ProgrammingError()
    assert str(e2) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:17:33.356974
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "condition not met")
        assert False
    except ProgrammingError as err:
        assert str(err) == "condition not met"


# Generated at 2022-06-21 20:17:36.188422
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Test of exception")
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:19:41.792259
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Case 1: Test if the constructor and passert method work as expected
    try:
        ProgrammingError.passert(condition=False, message="Expected to fail.")
    except ProgrammingError as e:
        assert str(e) == "Expected to fail."
    else:
        assert False, "Assertion should have been raised."

# Generated at 2022-06-21 20:19:47.101908
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "My condition is not met")
        assert False
    except ProgrammingError as e:
        assert str(e) == "My condition is not met"
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:19:48.502672
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception:
        pass
    else:
        assert False, "ProgrammingError was not raised"


# Generated at 2022-06-21 20:19:55.296385
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Should raise an exception
        ProgrammingError.passert(False, "A message")

        # If we reach this point, the test has failed
        raise AssertionError("Broken coherence in assertion")
    except ProgrammingError:
        pass
    else:
        # If we reach this point, the test has failed
        raise AssertionError("Broken coherence in assertion")

# Generated at 2022-06-21 20:19:57.470269
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error message")
    except ProgrammingError as e:
        assert e.args == ("This is an error message",)
    else:
        assert False

# Generated at 2022-06-21 20:19:59.947465
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:20:01.327796
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(None)
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:20:11.700062
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError
    except ProgrammingError:
        pass

    try:
        raise ProgrammingError("Hello!")
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(True, "Hello!")
    except ProgrammingError:
        assert False, "ProgrammingError.passert() should not fail when condition is met."

    try:
        ProgrammingError.passert(False, None)
        assert False, "ProgrammingError.passert() should fail when condition is not met."
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(False, "Hello!")
        assert False, "ProgrammingError.passert() should fail when condition is not met."
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:20:17.958749
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert ex.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError("Wrong dimension.")
    except ProgrammingError as ex:
        assert ex.args[0] == "Wrong dimension."

# Generated at 2022-06-21 20:20:19.847937
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()
