

# Generated at 2022-06-21 20:11:35.532565
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing the error")
    except ProgrammingError as pe:
        print("Got the following exception: {}".format(pe))


# Generated at 2022-06-21 20:11:37.778092
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test", "message")
    except ProgrammingError as ex:
        assert ex.args == ("message",)
        return
    assert 0, "Expected exception to be raise"


# Generated at 2022-06-21 20:11:42.911547
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError should raise a ProgrammingError")


# Generated at 2022-06-21 20:11:45.540596
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "something")
        assert False
    except ProgrammingError as e:
        assert str(e) == "something"

# Generated at 2022-06-21 20:11:50.033971
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from nose.tools import assert_raises
    from nose.tools import assert_true, assert_false

    assert_raises(ProgrammingError, ProgrammingError.passert, False, None)
    assert_raises(ProgrammingError, ProgrammingError.passert, False, "Fake error")
    assert_true(ProgrammingError.passert(True, None))
    assert_true(ProgrammingError.passert(True, "Fake error"))

# Generated at 2022-06-21 20:11:51.966527
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Error description")

# Generated at 2022-06-21 20:11:54.127980
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message.")
    except ProgrammingError as e:
        assert "Error message." == e.args[0]


# Generated at 2022-06-21 20:11:58.034967
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test that the class behaves as expected
    with ProgrammingError.passert(False, None):
        pass
    try:
        ProgrammingError.passert(True, "FOO")
    except ProgrammingError:
        pass
    else:
        raise Exception("ProgrammingError was not raised as expected.")

# Generated at 2022-06-21 20:11:59.808959
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("unittest")


# Generated at 2022-06-21 20:12:00.923402
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "message"):
        pass

# Generated at 2022-06-21 20:12:03.880769
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor.
    """
    assert ProgrammingError("m") is not None


# Generated at 2022-06-21 20:12:06.731135
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert hasattr(e, "__init__")
        assert hasattr(e, "__str__")
        assert e.__str__() == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:12:17.230257
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check that a ProgrammingError cause is logged
    problem = ProgrammingError()
    assert problem.cause is None
    # Check that a ProgrammingError cause is logged
    problem = ProgrammingError(causation=ProgrammingError())
    assert problem.cause == "Broken coherence. Check your code against domain logic to fix it."
    # Check that a ProgrammingError cause is logged
    problem = ProgrammingError(causation=ProgrammingError(causation=ProgrammingError()))
    assert problem.cause == "Broken coherence. Check your code against domain logic to fix it."
    # Check that a ProgrammingError cause is logged
    problem = ProgrammingError(causation=ProgrammingError(causation=ProgrammingError(causation=ProgrammingError())))
    assert problem.cause == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-21 20:12:18.959478
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(message="Some message")
    

# Generated at 2022-06-21 20:12:21.096264
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is an error")
    assert error.args == ("This is an error",)


# Generated at 2022-06-21 20:12:26.421124
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # missing message
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert "check your code against domain logic" in e.args[0].lower()
        assert "to fix it" in e.args[0].lower()


# Generated at 2022-06-21 20:12:29.615816
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-21 20:12:30.515880
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()


# Generated at 2022-06-21 20:12:34.616106
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from .errors import ProgrammingError
    message = "This is a message."
    with raises(ProgrammingError, match=message):
        ProgrammingError(message)

# Generated at 2022-06-21 20:12:37.644837
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test exception")
    except ProgrammingError:
        pass
    else:
        assert False, "Expected exception not raised"


# Generated at 2022-06-21 20:12:42.318092
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyTypeChecker
    ProgrammingError(message="This is a test!")

# Generated at 2022-06-21 20:12:44.852399
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Expected
    expected = "This is a error reason."

    # Tested
    Programm

# Generated at 2022-06-21 20:12:46.059115
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import warns

    with warns(UserWarning):
        ProgrammingError.passert(False, "Error Message")

# Generated at 2022-06-21 20:12:48.898216
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError()

    e = ProgrammingError("Test message.")
    assert isinstance(e, ProgrammingError)



# Generated at 2022-06-21 20:12:54.727065
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as pe:
        assert str(pe) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("The statement 'ProgrammingError.passert(False, None)' should raise a ProgrammingError.")

# Generated at 2022-06-21 20:12:59.146899
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()

    with pytest.raises(ProgrammingError, match="Error message"):
        raise ProgrammingError(message="Error message")

# Generated at 2022-06-21 20:13:02.822779
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Condition was not met")
        raise Exception("ProgrammingError.passert should raise a ProgrammingError")
    except ProgrammingError:
        pass
    assert ProgrammingError.passert(True, "Condition was met") == None

# Generated at 2022-06-21 20:13:05.025604
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a message")
    except ProgrammingError as e:
        assert e.args[0] == "This is a message"


# Generated at 2022-06-21 20:13:06.648285
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        print(e)


# Generated at 2022-06-21 20:13:09.958159
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Unexpected situation")
        assert False # Should not reach this point
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:13:18.072130
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        return
    assert False, "ProgrammingError constructor does not raise exception when no argument is provided."



# Generated at 2022-06-21 20:13:25.523343
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Fails if the message is not in the exception
    try:
        raise ProgrammingError(message="Something wrong.")
    except ProgrammingError as exc:
        assert "Something wrong." in str(exc)

    # Fails if the message is not in the exception
    try:
        raise ProgrammingError(message="Something wrong.")
    except ProgrammingError as exc:
        assert "Something wrong." in str(exc)



# Generated at 2022-06-21 20:13:28.954137
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an expected error.")
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)
        assert isinstance(err, Exception)
        assert str(err) == "This is an expected error."


# Generated at 2022-06-21 20:13:33.435346
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(condition=True, message="")
    try:
        ProgrammingError.passert(condition=False, message="")
        raise Exception("ProgrammingError must be raised.")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:13:36.913606
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Programmer's error")
    except ProgrammingError as e:
        assert e.__str__() == "Programmer's error"
        print("<ProgrammingError> Test passed")
    else:
        raise AssertionError()


# Generated at 2022-06-21 20:13:38.210203
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-21 20:13:41.908148
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "error_message")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "error_message"


# Generated at 2022-06-21 20:13:53.299784
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import logging
    import unittest

    logger = logging.getLogger(__name__)
    logger.addHandler(logging.NullHandler())

    err = ProgrammingError("This is a programming error")

    logger.debug(err)
    assert str(err) == "This is a programming error"
    try:
        raise err
    except ProgrammingError as ex:
        logger.debug(ex)
        assert ex.args[0] is err.args[0]
    else:
        assert False, "Did not raise a ProgrammingError"

    ProgrammingError.passert(True, "Assumption fulfilled.")

    try:
        ProgrammingError.passert(False, "Assumption not fulfilled.")
    except ProgrammingError as ex:
        logger.debug(ex)
        assert str(ex) == "Assumption not fulfilled."

# Generated at 2022-06-21 20:13:57.735143
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Expectation failed.")
        assert(False)
    except ProgrammingError:
        pass
    ProgrammingError.passert(True, "All right.")


# Generated at 2022-06-21 20:14:02.578535
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Expected argument for function A is not provided by the user.")
    except ProgrammingError as e:
        assert str(e) == "Expected argument for function A is not provided by the user."
        assert repr(e) == "ProgrammingError('Expected argument for function A is not provided by the user.')"


# Generated at 2022-06-21 20:14:15.336881
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Expected ProgrammingError exception."


# Generated at 2022-06-21 20:14:18.793796
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "MESSAGE"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert message == str(e)
    except Exception as e:
        assert False, "ProgrammingError expected, but got {}".format(type(e))


# Generated at 2022-06-21 20:14:24.076017
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()

    # The exception should be a ProgrammingError (and not a RuntimeError or something alike)
    assert isinstance(error, ProgrammingError)


# Generated at 2022-06-21 20:14:26.088006
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('test')
    except ProgrammingError as e:
        assert e.args[0] == 'test'


# Generated at 2022-06-21 20:14:31.009748
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence" in str(e)
    try:
        ProgrammingError("message")
    except ProgrammingError as e:
        assert "message" in str(e)


# Generated at 2022-06-21 20:14:34.052245
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
    except ProgrammingError as e:
        assert(e.args[0] == "test")


# Generated at 2022-06-21 20:14:37.891485
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError(None)
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)
        assert isinstance(e, BaseException)


# Generated at 2022-06-21 20:14:42.902489
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Met a broken coherence.")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert e.args[0] == "Met a broken coherence."


# Generated at 2022-06-21 20:14:46.119047
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        raise Exception("Failed to raise an exception.")

# Generated at 2022-06-21 20:14:49.618276
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    passert(ProgrammingError)
    passert(ProgrammingError(None))
    passert(ProgrammingError(""))
    passert(ProgrammingError("Test" * 100))


# Generated at 2022-06-21 20:15:10.896302
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError()

# Generated at 2022-06-21 20:15:13.893321
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError.passert(True, None) == None
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        assert True



# Generated at 2022-06-21 20:15:15.214655
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for the constructor of class ProgrammingError."""
    ProgrammingError("An error message.")

# Generated at 2022-06-21 20:15:17.138868
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "message")
    except ProgrammingError as e:
        assert type(e) is ProgrammingError
        assert str(e) == "message"


# Generated at 2022-06-21 20:15:18.792606
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test"):
        pass

# Generated at 2022-06-21 20:15:21.431072
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert "Test" == e.args[0]
        return True
    return False


# Generated at 2022-06-21 20:15:22.370135
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(None)

# Generated at 2022-06-21 20:15:23.971242
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:15:25.836608
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as _:
        ProgrammingError.passert(False, message="Test the error handling of the constructor.")

# Generated at 2022-06-21 20:15:29.196540
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for initializing a :py:class:`ProgrammingError` exception.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert err.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise Exception("This exception should have been raised")


# Generated at 2022-06-21 20:16:22.071338
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

    with pytest.raises(ProgrammingError):
        raise ProgrammingError("This is an error with message")



# Generated at 2022-06-21 20:16:26.585782
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "This is an error message"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as err:
        assert err.args == (message,)
__test__ = {
    "test_ProgrammingError": test_ProgrammingError,
}


# Generated at 2022-06-21 20:16:29.321056
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("foo")
    except ProgrammingError as e:
        assert "foo" == str(e)


# Generated at 2022-06-21 20:16:31.849090
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something is really really wrong.")
    except ProgrammingError as ex:
        assert ex.args[0] == "Something is really really wrong."


# Generated at 2022-06-21 20:16:33.652389
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("foobar")
    except ProgrammingError as err:
        assert(err.args == ("foobar", ))


# Generated at 2022-06-21 20:16:35.215291
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError('')


# Generated at 2022-06-21 20:16:38.485873
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("You can't call this method with a None as argument.")
    except ProgrammingError as error:
        assert error.args[0] == "You can't call this method with a None as argument."
    else:
        raise Exception("ProgrammingError not raised.")



# Generated at 2022-06-21 20:16:39.791337
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise(ProgrammingError)
        assert 0
    except ProgrammingError:
        pass
    except Exception:
        assert 0


# Generated at 2022-06-21 20:16:42.804604
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "This raises an error!")


# Generated at 2022-06-21 20:16:46.313255
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Bad luck")
    except ProgrammingError as e:
        assert(e.args[0] == "Bad luck")


# Generated at 2022-06-21 20:18:32.407377
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, match="The index should be positive"):
        ProgrammingError.passert(condition=False, message="The index should be positive")

# Generated at 2022-06-21 20:18:36.277472
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError(message="Message")
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:18:39.695812
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, None)
    try:
        ProgrammingError.passert(False, "some message")
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:18:42.026199
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)


# Generated at 2022-06-21 20:18:44.332929
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error")
    except ProgrammingError as error:
        print(error)


# Generated at 2022-06-21 20:18:49.271518
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    condition_true = True
    condition_false = False
    message_true = "Should not raise an exception."
    message_false = "Should raise an exception."

    # Act
    try:
        ProgrammingError.passert(condition_true, message_true)
    except:
        assert False, message_true

    try:
        ProgrammingError.passert(condition_false, message_false)
        assert False, message_false
    except ProgrammingError:
        assert True

# Generated at 2022-06-21 20:18:50.914379
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError must raise itself")


# Generated at 2022-06-21 20:18:54.126799
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:meth:`~pypara.error.ProgrammingError.__init__`.
    """
    class MockProgrammingError(ProgrammingError):
        pass

    assert isinstance(MockProgrammingError(), ProgrammingError)


# Generated at 2022-06-21 20:18:56.060430
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test exception.")
    except ProgrammingError as e:
        assert str(e) == "Test exception."


# Generated at 2022-06-21 20:18:58.734855
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Cannot find the logic!")
    except ProgrammingError as e:
        assert str(e) == "Cannot find the logic!"