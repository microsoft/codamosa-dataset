

# Generated at 2022-06-21 20:11:35.193074
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError
    """
    error = ProgrammingError("My error")
    assert error.args[0] == "My error"



# Generated at 2022-06-21 20:11:36.925337
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.__str__() is not None


# Generated at 2022-06-21 20:11:38.198657
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("test")
    assert isinstance(error, Exception)


# Generated at 2022-06-21 20:11:45.814139
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # The purpose of this test is to check the constructor of ProgrammingError
    from pyassert import assert_that
    try:
        raise ProgrammingError("Foo!")
    except ProgrammingError as e:
        assert_that(e).is_instance_of(ProgrammingError)
        assert_that(e.message).is_equal_to("Foo!")
        assert_that(e).is_equal_to("Foo!")

# Generated at 2022-06-21 20:11:48.051269
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert e.args[0] == "Test message"


# Generated at 2022-06-21 20:11:50.898448
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    else:
        assert False, "No exception was raised"


# Generated at 2022-06-21 20:11:53.244363
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError()

    with raises(ProgrammingError):
        ProgrammingError("Foo")



# Generated at 2022-06-21 20:11:59.752724
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from .message import Message
    from .text import Text

    with raises(ProgrammingError):
        raise ProgrammingError(message=Text(message=Message.of(template="{name}")))

    try:
        raise ProgrammingError(message=Text(message=Message.of(template="{name}")))
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:12:02.355009
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Expected message")
    except ProgrammingError as err:
        assert str(err) == "Expected message"


# Generated at 2022-06-21 20:12:04.294732
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(None)
    except ProgrammingError as error:
        assert isinstance(error, ProgrammingError)
        return
    assert False

# Generated at 2022-06-21 20:12:09.117547
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Could not raise a ProgrammingError.")


# Generated at 2022-06-21 20:12:12.459637
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    if __debug__:
        try:
            ProgrammingError("hello")
        except ProgrammingError:
            pass
        else:
            raise AssertionError("ProgrammingError constructor does not throw")

# Unit test of the assertion function

# Generated at 2022-06-21 20:12:14.539298
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # No further unit test required as the module does not expose behavior and has no side-effects
    pass

# Generated at 2022-06-21 20:12:16.573395
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test")
    except:
        raise AssertionError("ProgrammingError not defined properly.")


# Generated at 2022-06-21 20:12:18.630419
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"

# Generated at 2022-06-21 20:12:19.660388
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError():
        raise ProgrammingError()


# Generated at 2022-06-21 20:12:22.585787
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:12:28.729089
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    condition = False
    message = "Any message"
    try:
        ProgrammingError.passert(condition, message)
    except ProgrammingError as e:
        assert (
            e.args == (
                message or "Broken coherence. Check your code against domain logic to fix it.",
            )
        )
    else:
        assert False

# Generated at 2022-06-21 20:12:33.171831
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test that the class can be instatiated
    try:
        ProgrammingError()
    except Exception as e:
        assert False, "Error creating object AssignmentError: {}".format(e)
    try:
        ProgrammingError("Testing constructor of class ProgrammingError")
    except Exception as e:
        assert False, "Error creating object AssignmentError with params: {}".format(e)

# Generated at 2022-06-21 20:12:36.894705
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, Exception)
        assert isinstance(e, ProgrammingError)
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:12:41.745247
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError()
    assert issubclass(exception.__class__, Exception)

# Generated at 2022-06-21 20:12:50.504447
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # TypeError: not enough arguments
    try:
        ProgrammingError()
    except TypeError:
        pass
    else:
        raise AssertionError("Expected TypeError")

    # TypeError: message is not a string
    try:
        ProgrammingError(1)
    except TypeError:
        pass
    else:
        raise AssertionError("Expected TypeError")

    # ProgrammerError: message is empty
    try:
        ProgrammingError("")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Expected ProgrammingError")


# Generated at 2022-06-21 20:12:57.850281
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:  # pragma: no cover
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ()
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:  # pragma: no cover
        raise ProgrammingError("message")
    except ProgrammingError as e:
        assert e.args == ("message",)
        assert str(e) == "message"


# Generated at 2022-06-21 20:12:59.954019
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        a = ProgrammingError()
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-21 20:13:02.453460
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:13:05.491908
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): # pylint: disable=unused-variable
    """
    This module has no production code, therefore the naming of functions is not going to be changed.
    """
    message = "Expected non-empty message"
    ProgrammingError(message)

# Generated at 2022-06-21 20:13:07.115499
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("foo")


# Generated at 2022-06-21 20:13:11.958186
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for the constructor of class :py:class:`ProgrammingError`."""
    try:
        raise ProgrammingError("My custom message")
    except ProgrammingError as e:
        assert e.args[0] == "My custom message"


# Generated at 2022-06-21 20:13:14.780602
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Unit test for class ProgrammingError. """
    try:
        ProgrammingError().passert(False, "test")
        raise Exception("Should have raised an exception")
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:13:22.945359
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if the constructor correctly handles the given input.
    """
    # Test if the constructor works correctly
    try:
        raise ProgrammingError("foo")
    except ProgrammingError as err:
        assert str(err) == "foo"
    except Exception:
        assert False, "Something went wrong."

    # Test if the constructor works correctly
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert str(err) == "Broken coherence. Check your code against domain logic to fix it."
    except Exception:
        assert False, "Something went wrong."

# Generated at 2022-06-21 20:13:31.490376
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as exception:
        assert exception.args == tuple()
        assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:13:35.112829
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hey, C++ coder! Stop using pointers if you can, please.")
    except ProgrammingError as e:
        assert(str(e) == "Hey, C++ coder! Stop using pointers if you can, please.")


# Generated at 2022-06-21 20:13:38.424978
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the constructor of the class :py:class:`ProgrammingError` behaves as expected.
    """
    raise ProgrammingError("Testing the error")



# Generated at 2022-06-21 20:13:42.425731
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as e:
        ProgrammingError.passert(False, "Foo")

    assert e.value.__cause__ is None
    assert e.value.__context__ is None



# Generated at 2022-06-21 20:13:45.950647
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError` constructor.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:13:48.065537
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "error")

# Generated at 2022-06-21 20:13:51.060499
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error_message = "Domain logic is broken."
    try:
        raise ProgrammingError(error_message)
    except ProgrammingError as e:
        assert len(e.args) == 1
        assert e.args[0] == error_message


# Generated at 2022-06-21 20:13:54.307864
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("message")
    except ProgrammingError as e:
        assert e.args == ("message",)


# Generated at 2022-06-21 20:13:57.252531
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(None)


# Generated at 2022-06-21 20:13:59.577192
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("The programmer is not correct.")
    except ProgrammingError as e:
        assert str(e) == "The programmer is not correct."

# Generated at 2022-06-21 20:14:12.578670
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError:
        return True
    return False


# Generated at 2022-06-21 20:14:14.806854
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(condition=False, message="my message")
    ProgrammingError.passert(condition=True, message="my message")

# Generated at 2022-06-21 20:14:19.827540
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor :py:func:`ProgrammingError.__init__` of :py:class:`ProgrammingError`.

    The method :py:meth:`ProgrammingError.__init__` needs to receive a string and store it.

    :raises AssertionError: If the testing fails.
    """
    error_message = "Hello world"
    error = ProgrammingError(error_message)
    assert error.args[0] == error_message


# Generated at 2022-06-21 20:14:22.941314
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Expected message"):
        pass



# Generated at 2022-06-21 20:14:31.098125
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, None)
    try:
        ProgrammingError.passert(False, "Just a test")
    except ProgrammingError as e: assert str(e) == "Just a test"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e: assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:14:32.921824
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()

# Generated at 2022-06-21 20:14:33.522640
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    pass

# Generated at 2022-06-21 20:14:35.300383
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Some error in your code.")

# Generated at 2022-06-21 20:14:36.940730
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("This is an error.")
    assert e.args == ("This is an error.",)

# Generated at 2022-06-21 20:14:41.357942
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase

    with TestCase.assertRaisesRegexp(TestCase, r"^Broken coherence. Check your code against domain logic to fix it.$"):
        ProgrammingError.passert(False, None)
    with TestCase.assertRaisesRegexp(TestCase, r"^It is not possible to pass a null message.$"):
        ProgrammingError.passert(False, "")

# Generated at 2022-06-21 20:15:07.293947
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a unit test!")
    except ProgrammingError as e:
        assert e.args[0] == "This is a unit test!"
    except Exception as e:
        raise RuntimeError(f"Expecting ProgrammingError but {type(e)} has been raised instead.")

# Generated at 2022-06-21 20:15:10.103769
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
        assert False, "ProgrammingError was not raised"
    except ProgrammingError:
        assert True, "ProgrammingError was raised"

# Generated at 2022-06-21 20:15:13.067749
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test!")
    except ProgrammingError as ex:
        assert str(ex) == "This is a test!"
    else:
        assert False

# Generated at 2022-06-21 20:15:18.005928
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:func:`.ProgrammingError`.

    :return: ``None``.
    """
    try:
        ProgrammingError.passert(False, "If this message is shown, the unit test fails!")
    except ProgrammingError as e:
        message = e.args[0]
        assert message == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(True, "If this message is shown, the unit test fails!")
    except ProgrammingError as e:
        pass
    else:
        assert False

# Generated at 2022-06-21 20:15:21.299716
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("message")
    except ProgrammingError:
        pass
    assert True


# Generated at 2022-06-21 20:15:25.309653
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Checks the constructor of class ProgrammingError.
    """
    assert str(ProgrammingError(None)) == "<Invalid message. It should not be None or empty>"
    assert str(ProgrammingError("")) == "<Invalid message. It should not be None or empty>"
    assert str(ProgrammingError("Test")) == "Test"


# Generated at 2022-06-21 20:15:28.357161
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as expected:
        assert str(expected) == "Broken coherence. Check your code against domain logic to fix it." and True
    except Exception as unexpected:
        assert False and str(unexpected)
    else:
        assert False


# Generated at 2022-06-21 20:15:32.016261
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError) as excinfo:
        ProgrammingError("not satisfied!")
    assert excinfo.value.args == ("not satisfied!",)

    ProgrammingError.passert(False, "not satisfied!")

# Generated at 2022-06-21 20:15:36.292394
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("This is the message"):
        raise ProgrammingError("This is the message")
    try:
        raise ProgrammingError("This is the message")
    except ProgrammingError as exc:
        assert str(exc) == 'This is the message'



# Generated at 2022-06-21 20:15:39.859022
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hi!")
    except ProgrammingError as error:
        assert error.args[0] == "Hi!"

# Generated at 2022-06-21 20:16:35.398994
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Verifies the constructor of :py:class:`ProgrammingError`."""
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:16:38.345052
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")
    except ProgrammingError as e:
        assert e.args[0] == "Test message"
    else:
        assert False, "ProgrammingError does not have been raised"


# Generated at 2022-06-21 20:16:41.549015
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the ``ProgrammingError`` class.
    """
    p_error = ProgrammingError()
    assert p_error is not None


# Generated at 2022-06-21 20:16:43.533350
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("should raise"):
        raise ProgrammingError("should raise")


# Generated at 2022-06-21 20:16:50.117169
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test that the message is correct
    with assertRaisesRegex(ProgrammingError, "Error"):
        raise ProgrammingError("Error")
    # Test that the message is correct and the cause is caught
    with assertRaisesRegex(ProgrammingError, "Error2"):
        try:
            raise ValueError("Error1")
        except ValueError:
            raise ProgrammingError("Error2")


# Generated at 2022-06-21 20:16:53.660653
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception) is True
    assert ProgrammingError.__doc__ is not None
    assert ProgrammingError.__init__ is not None
    assert ProgrammingError("message").args == ("message",)
    assert str(ProgrammingError("message")) == "message"


# Generated at 2022-06-21 20:16:56.625812
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN only a basic error
    error = ProgrammingError()
    # WHEN retrieving the result
    # THEN the result is an empty exception
    assert error is not None
    assert not error.args


# Generated at 2022-06-21 20:16:58.090879
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:17:00.958735
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(None)
    except ProgrammingError as e:
        print(e)

# Generated at 2022-06-21 20:17:05.250705
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Basic usage
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass

    # Error message
    try:
        raise ProgrammingError("Foo")
    except ProgrammingError as e:
        assert str(e) == "Foo"



# Generated at 2022-06-21 20:18:59.201775
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("dummy message")
    except ProgrammingError as pe:
        assert str(pe) == "dummy message"

# Generated at 2022-06-21 20:19:03.589175
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Should raise a ProgrammingError")

    try:
        ProgrammingError.passert(True, "Should not raise a ProgrammingError")
    except ProgrammingError:
        pytest.fail("Should not raise a ProgrammingError")

# Generated at 2022-06-21 20:19:07.069452
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Broken coherence")


if __name__ == '__main__':
    from pypara.test.test_module import test

    test(__file__)

# Generated at 2022-06-21 20:19:09.541745
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        assert ProgrammingError("Some message")
        assert ProgrammingError()
    except ProgrammingError:
        p

# Generated at 2022-06-21 20:19:11.702734
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Provided description of programming error")
    except ProgrammingError as ex:
        assert ex.__str__() == "Provided description of programming error"

# Generated at 2022-06-21 20:19:13.809350
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "hello world")
        raise AssertionError("Expectation not met")
    except ProgrammingError as e:
        assert str(e) == "hello world"

# Generated at 2022-06-21 20:19:24.444051
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    cls = ProgrammingError
    assert issubclass(cls, Exception)
    assert cls().__class__ is cls
    assert cls().__context__ is None
    assert cls().__cause__ is None
    assert cls(None).__context__ is None
    assert cls(None).__cause__ is None
    msg = "Foo"
    assert cls(msg).__context__ is None
    assert cls(msg).__cause__ is None
    assert cls(None, None).__context__ is None
    assert cls(None, None).__cause__ is None
    assert cls(None, msg).__context__ is None
    assert cls(None, msg).__cause__ is None
    with raises(ProgrammingError) as excinfo:
        raise ProgrammingError
   

# Generated at 2022-06-21 20:19:26.467573
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("")
    except ProgrammingError as e:
        assert e.args[0] == ""


# Generated at 2022-06-21 20:19:33.204602
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # We may invoke the constructor of class ProgrammingError directly
    try:
        raise ProgrammingError("arbitrary error")
    except ProgrammingError as e:
        assert str(e) == "arbitrary error"

    # Or we can use the static method passert for short-circuit evaluation
    try:
        ProgrammingError.passert(False, "incorrect assertion")
    except ProgrammingError as e:
        assert str(e) == "incorrect assertion"

    # The static method passert raises the ProgrammingError only if the condition is False
    ProgrammingError.passert(True, "correct assertion")

# Generated at 2022-06-21 20:19:38.472854
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("It's broken.")
    except ProgrammingError as ex:
        assert str(ex) == "It's broken."