

# Generated at 2022-06-21 20:11:33.779708
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:11:36.515332
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` constructor.
    """
    try:
        raise ProgrammingError("We are testing")
    except ProgrammingError as exc:
        assert str(exc) == "We are testing"

# Generated at 2022-06-21 20:11:38.612854
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with assert_raises(ProgrammingError) as error:
        raise ProgrammingError('This is a test exception')
    assert_true('This is a test exception' in str(error.value))


# Generated at 2022-06-21 20:11:40.272656
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    Programmin

# Generated at 2022-06-21 20:11:42.810961
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:11:46.510045
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as e:
        assert e.args[0] == "PyPara ProgrammingError: A message"
    ProgrammingError.passert(False, "A message")
    ProgrammingError.passert(True, "A message")

# Generated at 2022-06-21 20:11:48.507066
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("dummy message").args[0] == "dummy message"
    assert ProgrammingError().args[0] is None
    ProgrammingError.passert(False, "dummy message")

# Generated at 2022-06-21 20:11:58.549235
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert len(e.args) == 0
    try:
        raise ProgrammingError(None)
    except ProgrammingError as e:
        assert len(e.args) == 0
    try:
        raise ProgrammingError(1)
    except ProgrammingError as e:
        assert len(e.args) == 1
        assert e.args[0] == 1
    try:
        raise ProgrammingError(None, 1)
    except ProgrammingError as e:
        assert len(e.args) == 1
        assert e.args[0] == 1
    try:
        raise ProgrammingError(1, 2)
    except ProgrammingError as e:
        assert len(e.args) == 2
        assert e.args[0] == 1

# Generated at 2022-06-21 20:12:02.281895
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test case for the class :py:class:`ProgrammingError`."""
    error = ProgrammingError("Test Error")
    assert error.__repr__() == "Test Error"
    assert error.__str__() == "Test Error"


# Generated at 2022-06-21 20:12:05.752434
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")  # type: ignore
    except ProgrammingError as error:
        assert str(error) == "Test message"
    else:
        raise Exception("Expected an exception.")


# Generated at 2022-06-21 20:12:16.489858
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(condition=False, message=None)
    assert excinfo.value.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(condition=False, message="Don't just do it.")
    assert excinfo.value.args[0] == "Don't just do it."

    # Ideal scenario
    ProgrammingError.passert(condition=True, message="Don't just do it.")

# Generated at 2022-06-21 20:12:18.520996
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError("Testing")
    assert excinfo.type == ProgrammingError

# Generated at 2022-06-21 20:12:21.785626
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from nose.tools import assert_raises
    assert_raises(ProgrammingError, ProgrammingError)
    assert_raises(ProgrammingError, ProgrammingError, "test")


# Generated at 2022-06-21 20:12:25.202964
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-21 20:12:28.601377
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Sample message for error.")
    except ProgrammingError as e:
        assert e.args == ("Sample message for error.",)


# Generated at 2022-06-21 20:12:31.042945
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Some message")
    assert ProgrammingError("Some message").args[0] == "Some message"


# Generated at 2022-06-21 20:12:34.733149
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for :py:class:`ProgrammingError`"""
    ProgrammingError("test", "test")


if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-21 20:12:38.199691
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    for message in ["OK", "", None]:
        with pytest.raises(ProgrammingError):
            ProgrammingError.passert(False, message)
        ProgrammingError.passert(True, message)


# Generated at 2022-06-21 20:12:41.587314
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error.")
    except ProgrammingError as e:
        assert(str(e) == "This is a programming error.")

# Generated at 2022-06-21 20:12:48.744674
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError
    """
    assert ProgrammingError.passert(True, "Expected assertion to pass")
    try:
        ProgrammingError.passert(False, "Expected assertion to fail")
        assert False
    except ProgrammingError:
        pass
    try:
        # noinspection PyTypeChecker
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:12:52.084055
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert not ProgrammingError



# Generated at 2022-06-21 20:12:55.963855
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for :py:class:`ProgrammingError`.
    """

    error = ProgrammingError("This is a programming error!")
    assert repr(error) == "ProgrammingError('This is a programming error!')"



# Generated at 2022-06-21 20:12:59.066716
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Passed")
        ProgrammingError.passert(False, "Failed")
    except Exception as error:
        assert isinstance(error, ProgrammingError)
        assert error.args == ("Failed",)

# Generated at 2022-06-21 20:13:02.774543
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test :py:class:`ProgrammingError` constructor."""
    expected = "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError()
    except ProgrammingError as exception:
        actual = exception.args[0]
    assert expected == actual

# Generated at 2022-06-21 20:13:04.985499
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests of class ProgrammingError
    """
    assert issubclass(ProgrammingError, Exception)
    assert ProgrammingError.__doc__ is not None


# Generated at 2022-06-21 20:13:06.866131
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message.")
    except ProgrammingError as e:
        assert str(e) == "Error message."


# Generated at 2022-06-21 20:13:10.208329
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Programming error not raised"

# Generated at 2022-06-21 20:13:13.568908
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-21 20:13:18.906106
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        errors = ["Test"]
        if e.args != errors:
            raise AttributeError(f"ProgrammingError.args should be '{errors}'' but is '{e.args}'")


# Generated at 2022-06-21 20:13:22.028089
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def raise_it():
        raise ProgrammingError()
    assert ProgrammingError
    assert raise_it


# Generated at 2022-06-21 20:13:33.695218
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        assert False, "Expected no exception to be raised"

    try:
        ProgrammingError.passert(False, "it is false")
    except ProgrammingError as e:
        assert e.args[0] == "it is false"
    else:
        assert False, "Expected ProgrammingError exception to be raised"

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "Expected ProgrammingError exception to be raised"

# Generated at 2022-06-21 20:13:35.611591
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Unit test"
    try:
        raise ProgrammingError(message)
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:13:41.381802
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.
    """

    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        assert False  # Impossible


# Generated at 2022-06-21 20:13:42.871415
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:13:50.378036
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        pytest.fail('No exception expected. But the following exception was raised: ' + str(e))
    try:
        ProgrammingError.passert(False, 'Test exception')
    except ProgrammingError as e:
        assert str(e) == 'Test exception', 'Expected exception: "Test exception", but got exception: "' + str(e) + '"'

# Generated at 2022-06-21 20:13:52.793535
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as exc:
        assert "This is a test" == str(exc)


# Generated at 2022-06-21 20:13:57.256978
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error message.")
    except ProgrammingError as pe:
        assert pe.args[0] == "Some error message."


# Generated at 2022-06-21 20:13:59.576279
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase

    with TestCase.assertRaises(TestCase, ProgrammingError):
        ProgrammingError.passert(False, None)

# Generated at 2022-06-21 20:14:00.701137
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    ex = ProgrammingError("Some message")
    assert ex.args == ("Some message",)

# Generated at 2022-06-21 20:14:03.419203
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError

    with raises(ProgrammingError):
        raise ProgrammingError("This is a programming error.")


# Generated at 2022-06-21 20:14:17.019995
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(False, "Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"
    try:
        ProgrammingError("Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"
    ProgrammingError.passert(True, None)
    ProgrammingError.passert(True, "Test message")


# Generated at 2022-06-21 20:14:19.142128
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Message")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError could not be raised.")

# Generated at 2022-06-21 20:14:23.235676
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("Programming error message")
    assert str(err) == "Programming error message"


# Generated at 2022-06-21 20:14:26.445555
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error!")
    except ProgrammingError as e:
        assert str(e) == "This is an error!"
        assert repr(e) == "<ProgrammingError: This is an error!>"


# Generated at 2022-06-21 20:14:31.229356
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:14:40.802967
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=unused-argument
    def test_condition(message):
        test_condition.called = True
        return False
    test_condition.called = False

    try:
        ProgrammingError.passert(test_condition, "message")
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."
        assert test_condition.called
    else:
        assert False, "Should have raised ProgrammingError"

    assert test_condition.called == True

    try:
        ProgrammingError.passert(test_condition, None)
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."
        assert test_condition.called

# Generated at 2022-06-21 20:14:46.474348
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test case: Positive
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        assert False, "Positive test case failed"
    # Test case: Negative
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        assert True
    else:
        assert False, "Negative test case failed"

# Generated at 2022-06-21 20:14:48.818244
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "")
    ProgrammingError.passert(False, "Message")

# Generated at 2022-06-21 20:15:00.847051
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert not e.args, "Expected a programming error without arguments but got: %r" % e.args
    else:
        raise AssertionError("Expected a raised programming error as no message was provided")

    try:
        raise ProgrammingError("Broken coherence")
    except ProgrammingError as e:
        assert len(e.args) == 1, "Expected a programming error with one argument but got: %r" % e.args
        assert e.args[0] == "Broken coherence", "Expected a programming error with message 'Broken coherence' but got: %s" % repr(e.args[0])
    else:
        raise AssertionError

# Generated at 2022-06-21 20:15:12.907889
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest.mock import MagicMock

    exception_constructor = MagicMock()
    exception_constructor.__name__ = "my_exception"

    try:
        ProgrammingError.passert(False, "message")
    except ProgrammingError as ex:
        assert ex.args[0] != "message"
        exception_constructor("message")
        exception_constructor.assert_called_once()

    try:
        ProgrammingError.passert(True, "message")
    except ProgrammingError as ex:
        assert False, ex

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as ex:
        assert ex.args[0] != "message"
        exception_constructor("message")
        exception_constructor.assert_called_once()


# Generated at 2022-06-21 20:15:25.473349
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("An error has occurred")
    except ProgrammingError as e:
        assert e.args == ("An error has occurred",)


# Generated at 2022-06-21 20:15:26.969777
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()
    ProgrammingError(".")


# Generated at 2022-06-21 20:15:27.872212
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("foo")


# Generated at 2022-06-21 20:15:32.173351
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "This should raise an exception")

    try:
        ProgrammingError.passert(True, "This should not raise an exception")
    except ProgrammingError:
        pytest.fail("This should not raise an exception")

# Generated at 2022-06-21 20:15:41.651267
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyTypeChecker
    ProgrammingError(None)
    with ProgrammingError.passert(False, "Test failed"):
        1+1
    with ProgrammingError.passert(True, "Test passed"):
        1+1
    try:
        with ProgrammingError.passert(False, "Test failed"):
            1 + 1
            raise ProgrammingError
    except ProgrammingError:
        pass
    with ProgrammingError.passert(True, "Test passed"):
        with ProgrammingError.passert(False, "Test failed"):
            1 + 1
            raise ProgrammingError

# Generated at 2022-06-21 20:15:49.411946
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # The simplest case
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    # Case with a message
    try:
        ProgrammingError("Something is broken.")
    except ProgrammingError as e:
        assert str(e) == "Something is broken."
    # Case with a None message
    try:
        ProgrammingError(None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:15:56.749357
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, match="Check your code against domain logic to fix it."):
        ProgrammingError.passert(False, None)

    with pytest.raises(ProgrammingError, match="Check your code against domain logic to fix it."):
        ProgrammingError.passert(True, None)

    with pytest.raises(ProgrammingError, match="Check your code for uniformity."):
        ProgrammingError.passert(False, "Check your code for uniformity.")

# Generated at 2022-06-21 20:15:57.938063
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)



# Generated at 2022-06-21 20:16:01.375919
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-21 20:16:07.727747
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
        raise AssertionError("Expected an exception.")
    except ProgrammingError as e:
        assert e.args[0] == "Test"
    try:
        ProgrammingError.passert(False, None)
        raise AssertionError("Expected an exception.")
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:16:35.478331
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:16:37.494926
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert e.args[0] == "Test message"


# Generated at 2022-06-21 20:16:48.906757
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test 1: When the message is not set
    try:
        ProgrammingError.passert(False, None)
        assert False, "Should not reach this statement"  # pragma: no cover
    except ProgrammingError as ex:
        assert ex.args[0] == "Broken coherence. Check your code against domain logic to fix it.", \
            "Error message is wrong"

    # Test 2: When the message is set
    try:
        ProgrammingError.passert(False, "This is a test")
        assert False, "Should not reach this statement"  # pragma: no cover
    except ProgrammingError as ex:
        assert ex.args[0] == "This is a test", "Error message is wrong"

    # Test 3: When the condition is True
    ProgrammingError.passert(True, None)  # pragma: no cover

# Generated at 2022-06-21 20:16:51.253535
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Unit test")
        assert False
    except Exception as e:
        assert isinstance(e, ProgrammingError)



# Generated at 2022-06-21 20:16:54.099397
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Assertion failed")
    except ProgrammingError as e:
        assert str(e) == "Assertion failed"



# Generated at 2022-06-21 20:16:55.877648
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as e:
        assert e.args[0] == "Message"


# Generated at 2022-06-21 20:17:00.613581
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="test error message")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(condition=True, message="test error message")
    except ProgrammingError as e:
        assert False

    try:
        raise ProgrammingError("test error message")
    except ProgrammingError as e:
        assert str(e) == "test error message"

test_ProgrammingError()

# Generated at 2022-06-21 20:17:03.049265
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as e:
        assert str(e) == "Message"


# Generated at 2022-06-21 20:17:06.672255
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.
    """
    exc = ProgrammingError("foo")
    assert str(exc) == "foo"


# Generated at 2022-06-21 20:17:12.758683
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Some message")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Some message"

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:18:17.117890
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    This method verifies that the :py:class:`ProgrammingError` is correctly initialized.

    :raises ProgrammingError: If it fails.
    """
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "This error is expected for this unit test only!")


# Generated at 2022-06-21 20:18:21.666782
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): #pylint: disable=missing-function-docstring
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert error.args == ("Broken coherence. Check your code against domain logic to fix it.", )
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as error:
        assert error.args == ("Test", )


# Generated at 2022-06-21 20:18:26.176250
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from py import test

    try:
        ProgrammingError.passert(True, "Message")
    except ProgrammingError:
        test.fail("ProgrammingError.passert() raised ProgrammingError unexpectedly!")

    with test.raises(ProgrammingError):
        ProgrammingError.passert(False, "Message")

# Generated at 2022-06-21 20:18:29.929739
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("TEST ProgrammingError")
    except ProgrammingError as e:
        assert "TEST ProgrammingError" in e.args
        assert e.args[0] == "TEST ProgrammingError"

# Generated at 2022-06-21 20:18:31.389373
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error occurred")
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:18:34.312268
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the construction of a :py:class:`ProgrammingError` object.
    """
    error = ProgrammingError("")
    assert error


# Generated at 2022-06-21 20:18:36.403420
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "It's broken")

# Generated at 2022-06-21 20:18:42.817548
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    error = ProgrammingError("What's your problem?...")
    assert str(error) == "What's your problem?..."
    assert repr(error) == "ProgrammingError('What\\'s your problem?...',)"
    assert isinstance(error, Exception)
    assert isinstance(error, BaseException)
    assert raises(ProgrammingError, ProgrammingError, "This will raise an error")


# Generated at 2022-06-21 20:18:45.951768
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Message"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert message == str(e)
    except Exception:
        assert False


# Generated at 2022-06-21 20:18:52.456479
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.

    :return: ``True`` if the constructor is correct, ``False`` otherwise.
    """
    # We check if the exception is being raised when the condition is False
    try:
        ProgrammingError.passert(True, "Message")
    except ProgrammingError:
        return False
    # We check if the exception is being raised when the condition is False and the message is None
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        return False
    # We check if the right exception message is being returned
    try:
        ProgrammingError.passert(False, "Message")
    except ProgrammingError as e:
        return "Message" == str(e)
    # We check if the right exception message is being returned if None is passed
   

# Generated at 2022-06-21 20:20:51.245660
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:20:54.132581
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Nobody expects the Spanish inquisition!")
    except ProgrammingError as e:
        assert str(e) == "Nobody expects the Spanish inquisition!"


# Generated at 2022-06-21 20:21:00.695198
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError
    """
    try:
        ProgrammingError.passert(False, 'This should trigger an assertion')
        assert False, 'No AssertionError triggered'
    except ProgrammingError as exception:
        assert str(exception) == 'Broken coherence. Check your code against domain logic to fix it.'

    # Test that passing the assertion does not raise an exception
    ProgrammingError.passert(True, 'This should NOT trigger an assertion')

# Generated at 2022-06-21 20:21:03.461705
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-21 20:21:04.840162
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(1 == 0, "This is a sample error"):
        pass

# Generated at 2022-06-21 20:21:07.206296
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("The moon is blue")
    except ProgrammingError as e:
        assert e.args[0] == "The moon is blue"



# Generated at 2022-06-21 20:21:08.946134
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Foo")
    except Exception as e:
        assert e.args == ("Foo",)

# Generated at 2022-06-21 20:21:09.810422
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test")


# Generated at 2022-06-21 20:21:16.041806
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
        raise AssertionError("ProgrammingError is missing protection")
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(False, "Test")
        raise AssertionError("ProgrammingError is missing protection")
    except ProgrammingError as e:
        assert e.args[0] == "Test"

    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        raise AssertionError("ProgrammingError is missing protection")

    try:
        ProgrammingError.passert(True, "Test")
    except ProgrammingError:
        raise AssertionError("ProgrammingError is missing protection")

# Generated at 2022-06-21 20:21:19.996372
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    message = "Programming error!"

    # Act
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        actual_message = e.args[0]

    # Assert
    assert actual_message == message

