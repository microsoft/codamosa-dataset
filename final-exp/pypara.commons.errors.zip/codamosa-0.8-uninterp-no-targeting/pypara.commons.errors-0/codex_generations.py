

# Generated at 2022-06-21 20:11:29.888933
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("my message")


# Generated at 2022-06-21 20:11:33.868434
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Some short description of invalid domain logic")
    except ProgrammingError as exception:
        assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:11:36.296460
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "Testing constructor")
    excinfo.match(r"Testing constructor")


# Generated at 2022-06-21 20:11:39.311093
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the behaviour of the constructor of :py:class:`ProgrammingError`.
    """

    try:
        ProgrammingError("This is the message")
    except ProgrammingError as exception:
        assert str(exception) == "This is the message"
    else:
        assert False, "Expected to catch an exception."


# Generated at 2022-06-21 20:11:43.142764
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    else:
        print("test_ProgrammingError: ERROR: ProgrammingError not raised.")


# Generated at 2022-06-21 20:11:46.510646
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "Expected ProgrammingError exception."


# Generated at 2022-06-21 20:11:47.590187
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        ProgrammingError("error message")


# Generated at 2022-06-21 20:11:57.771781
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:cls:`ProgrammingError`.
    """
    try:
        ProgrammingError(message="message_1")
    except ProgrammingError as e:
        assert e.args[0] == "message_1"
    else:
        assert False
    try:
        ProgrammingError("message_2")
    except ProgrammingError as e:
        assert e.args[0] == "message_2"
    else:
        assert False
    try:
        ProgrammingError(None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False

# Generated at 2022-06-21 20:12:00.080447
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("message")
    except ProgrammingError as e:
        assert e.args[0] == "message"


# Generated at 2022-06-21 20:12:02.641249
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError(message="Hello World")
    assert excinfo.value.args == ("Hello World",)

# Generated at 2022-06-21 20:12:09.074732
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("message")
    except ProgrammingError as err:
        assert err.args == ("message",)


# Generated at 2022-06-21 20:12:10.704995
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("foo")


# Generated at 2022-06-21 20:12:14.235253
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    msg = "This is the message passed to the constructor."
    e = ProgrammingError(msg)
    assert e.args[0] == msg


# Generated at 2022-06-21 20:12:21.847155
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` class constructor.
    """
    try:
        1 / 0
    except ZeroDivisionError as exc:
        assert issubclass(type(exc), Exception)
        assert isinstance(exc, ZeroDivisionError)
        assert not isinstance(exc, ProgrammingError)
    else:
        assert False, "ZeroDivisionError not raised"
    try:
        raise ProgrammingError("Raising on purpose.")
    except ProgrammingError as exc:
        assert isinstance(exc, ProgrammingError)
        assert not isinstance(exc, ZeroDivisionError)
    else:
        assert False, "ProgrammingError not raised"

# Generated at 2022-06-21 20:12:24.840611
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-21 20:12:28.295000
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as e:
        assert e.__str__() == "Some message"


# Generated at 2022-06-21 20:12:33.084950
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.constants import PRINT_BASIC_INFO

    with raises(ProgrammingError, match="Broken coherence. Check your code against domain logic to fix it."):
        ProgrammingError.passert(False, "Coherence is broken!")

    assert ProgrammingError.passert(PRINT_BASIC_INFO, "Coherence is broken!") is None

# Generated at 2022-06-21 20:12:35.704261
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Message")
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:12:37.035188
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:12:38.818725
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError(None)
    assert ProgrammingError("foo")



# Generated at 2022-06-21 20:12:41.900226
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError()


# Generated at 2022-06-21 20:12:46.022736
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Does nothing. It is a unit test for the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:12:48.851774
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Some message")
    ProgrammingError.passert(True, "Some message")

# Generated at 2022-06-21 20:12:49.443250
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-21 20:12:51.272071
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing")
    except ProgrammingError as exception:
        assert str(exception) == "Testing"


# Generated at 2022-06-21 20:12:53.779402
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-21 20:12:58.652129
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    This test is for the constructor of class ProgrammingError.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:13:00.839444
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Error message")
    except ProgrammingError as e:
        assert str(e) == "Error message"

# Generated at 2022-06-21 20:13:03.300867
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc = ProgrammingError("hi", "there")
    assert isinstance(exc, Exception)
    assert exc.args == ("hi", "there")
    assert str(exc) == "hi"

# Generated at 2022-06-21 20:13:05.604997
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something went wrong.")
    except ProgrammingError as e:
        assert(e.args[0] == "Something went wrong.")


# Generated at 2022-06-21 20:13:10.722471
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test case for constructor of class `ProgrammingError`."""
    cls = ProgrammingError
    message = "Nothing to say"
    cls(message)


# Generated at 2022-06-21 20:13:12.354924
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True


# Generated at 2022-06-21 20:13:17.179471
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected_message = "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as error:
        assert error.args[0] == expected_message
    else:
        assert False, "The expected ProgrammingError exception has not been raised."


# Generated at 2022-06-21 20:13:22.216368
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    cls = ProgrammingError
    try:
        cls.passert(True, None)
    except cls as e:
        raise AssertionError("An unexpected exception has been thrown") from e

# Generated at 2022-06-21 20:13:24.942520
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert error.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-21 20:13:27.311485
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("error message")
    except Exception as e:
        assert e.args[0] == "error message"

# Generated at 2022-06-21 20:13:28.967169
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Foo"):
        assert True

# Generated at 2022-06-21 20:13:30.734310
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something is wrong")
    except ProgrammingError as error:
        assert error.args[0] == "Something is wrong"

# Generated at 2022-06-21 20:13:42.074765
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Assertions
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError("")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError("error message")
    except ProgrammingError as e:
        assert str(e) == "error message"
    try:
        ProgrammingError.passert(True, "message")
    except ProgrammingError:
        assert False is True
    try:
        ProgrammingError.passert(False, "message")
        assert False is True
    except ProgrammingError as e:
        assert str(e) == "message"

# Generated at 2022-06-21 20:13:45.846966
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as ex:
        assert isinstance(ex, ProgrammingError)
        assert ex.args[0]


# Generated at 2022-06-21 20:13:50.160611
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Oops!")
    except ProgrammingError as err:
        assert err.args[0] == "Oops!"


# Generated at 2022-06-21 20:13:52.021438
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:13:54.350184
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Nothing is expected."):
        pass

# Generated at 2022-06-21 20:14:03.481813
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    passert = ProgrammingError.passert

    try:
        ProgrammingError("Test message")
    except Exception as e:
        assert(isinstance(e, ProgrammingError))

    try:
        ProgrammingError("Test message", object())
    except Exception as e:
        assert(isinstance(e, ProgrammingError))

    try:
        passert(True, None)
        passert(False, "Message")
    except Exception as e:
        assert(isinstance(e, ProgrammingError))

    try:
        passert(False, None)
    except Exception as e:
        assert(isinstance(e, ProgrammingError))

# Generated at 2022-06-21 20:14:07.246068
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor of class :py:class:`ProgrammingError`.

    :return: ``None``
    """
    assert ProgrammingError()
    assert ProgrammingError(None)
    assert ProgrammingError("")
    assert ProgrammingError("Some message")



# Generated at 2022-06-21 20:14:10.267481
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError(message="Testing")
    assert error.args[0] == "Testing"

# Generated at 2022-06-21 20:14:12.843068
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:14:15.517691
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    message = "some error"

    # WHEN
    error = ProgrammingError(message)

    # THEN
    assert error.__str__() == message


# Generated at 2022-06-21 20:14:18.381978
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, None)
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:14:24.737860
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    print("ProgrammingError")
    try:
        ProgrammingError.passert(False, "crash")
        assert False, "Expected ProgrammingError"
    except ProgrammingError:
        pass

    ProgrammingError.passert(True, "crash")

# Generated at 2022-06-21 20:14:30.735280
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing exception functionality.")
    except Exception as ex:
        assert str(ex) == "Testing exception functionality."

# Generated at 2022-06-21 20:14:33.318638
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="foo")
    except ProgrammingError as e:
        assert str(e) == "foo"


# Generated at 2022-06-21 20:14:36.514957
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Programming error")
    assert str(error) == "Programming error"
    assert error.args == ("Programming error",)
    assert error.__str__() == "Programming error"


# Generated at 2022-06-21 20:14:40.138430
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the generic constructor of the exception :py:class:`ProgrammingError`.
    """
    error = ProgrammingError("Mala comprension de la logica de dominio")
    assert error.args[0] == "Mala comprension de la logica de dominio"


# Generated at 2022-06-21 20:14:42.766497
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():  # pragma: no cover
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:14:49.766181
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check that an exception is raised
    try:
        raise ProgrammingError()
    except ProgrammingError as exc:
        assert exc
    else:
        assert False, "Failed to raise a ProgrammingError"

    # Check that the message is being set
    try:
        raise ProgrammingError("You have done it wrong")
    except ProgrammingError as exc:
        assert exc.args == ("You have done it wrong",)
    else:
        assert False, "Failed to set message while raising a ProgrammingError"


# Generated at 2022-06-21 20:14:55.017522
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is bad")
    except ProgrammingError as err:
        print(err.args)
        print(err.__cause__)
        print(err.__context__)
        print(err.__traceback__)

# Generated at 2022-06-21 20:14:57.824130
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("message")
    except ProgrammingError as ex:
        assert ex.args[0] == "message"

# Test the passert method

# Generated at 2022-06-21 20:14:59.984220
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        pass


# Generated at 2022-06-21 20:15:03.893773
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as exc_info:
        ProgrammingError.passert(condition=False, message="Expectation")
    assert str(exc_info.value) == "Expectation"

# Generated at 2022-06-21 20:15:15.550055
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e1:
        assert True
    try:
        ProgrammingError.passert(False, "Custom Message")
        assert False
    except ProgrammingError as e2:
        assert e2.args[0] == "Custom Message"
    try:
        ProgrammingError.passert(True, "Custom Message")
        assert True
    except ProgrammingError as e3:
        assert False, e3

# Generated at 2022-06-21 20:15:19.257390
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error")
    except ProgrammingError as e:
        assert str(e) == "Some error"


# Generated at 2022-06-21 20:15:22.713043
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test", "Unexpected error message."
    except Exception as e:
        assert False, "Unexpected exception: {}".format(e)


# Generated at 2022-06-21 20:15:24.978949
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Test")
    except ProgrammingError as ex:
        assert ex.args[0] == "Test"


# Generated at 2022-06-21 20:15:35.597620
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase, mock

    class ProgrammingErrorTestCase(TestCase):
        """
        Unittest for the class :py:class:`ProgrammingError`.
        """

        def test_msg_not_none(self):
            """
            Tests that when the message is not ``None``, it is used in the exception message.
            """
            with self.assertRaises(ProgrammingError) as cm:
                ProgrammingError("This is the message.")
            self.assertEqual("This is the message.", cm.exception.__str__())

        def test_msg_none(self):
            """
            Tests that when the message is ``None``, a default message is used in the exception message.
            """
            with self.assertRaises(ProgrammingError) as cm:
                ProgrammingError(None)

# Generated at 2022-06-21 20:15:38.992720
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="error")
    except ProgrammingError as error:
        assert error.args[0] == "error"


# Generated at 2022-06-21 20:15:45.590043
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` class constructor.
    """
    import unittest

    with unittest.TestCase.assertRaises(unittest.TestCase, ProgrammingError):
        ProgrammingError("Test message")

    try:
        ProgrammingError("Test message")
    except ProgrammingError:
        ProgrammingError.assertTrue(True)
    else:  # pragma: no cover
        ProgrammingError.assertTrue(False)


# Generated at 2022-06-21 20:15:50.218554
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Message")
    except ProgrammingError as e:
        assert e.args[0] == "Message"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:15:52.718228
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as error:
        assert error.args == ("Test message", )


# Generated at 2022-06-21 20:15:57.118242
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():   # pylint: disable=no-member
    """
    The constructor of `ProgrammingError` must allow to catch ProgrammingError.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        return

    raise AssertionError("It should not be possible to reach this point.")


# Generated at 2022-06-21 20:16:14.857638
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass



# Generated at 2022-06-21 20:16:21.130881
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from typing import get_type_hints
    from pypro.para import ProgrammingError

    def test_cons():
        p = ProgrammingError()
        assert isinstance(p, ProgrammingError)

    def test_get_type_hints():
        assert get_type_hints(ProgrammingError) == {}

    test_cons()
    test_get_type_hints()


# Generated at 2022-06-21 20:16:26.150558
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Expected error")
    except ProgrammingError as ex:
        assert str(ex) == "Expected error"
    else:
        raise Exception("This point must not be reached")
    assert ProgrammingError.passert(True, "Expected error") is None

# Generated at 2022-06-21 20:16:30.343280
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test error")
        assert False, "Previous line should raise an exception"
    except ProgrammingError as e:
        assert str(e) == "Test error", "Unexpected exception"

    try:
        ProgrammingError.passert(True, "Test error")
        assert True, "Previous line should not raise an exception"
    except ProgrammingError as e:
        assert False, "Unexpected exception"

# Generated at 2022-06-21 20:16:31.849832
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("This is an error message.")


# Generated at 2022-06-21 20:16:37.433006
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit tests the :py:class:`pypara.errors.ProgrammingError` class.

    :return: ``None``
    """

    try:
        raise ProgrammingError
    except ProgrammingError as e:
        pass

    assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    try:
        raise ProgrammingError
    except ProgrammingError as e:
        pass

    assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Units tests for passert() method

# Generated at 2022-06-21 20:16:43.981808
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the contructor of class ProgrammingError.
    """

    to_test = lambda: None

    try:
        to_test()
    except:
        expected_error = ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
        actual_error = ProgrammingError()
        assert str(actual_error) == str(expected_error)
    else:
        assert False, "Expected a 'ProgrammingError' exception to be raised"



# Generated at 2022-06-21 20:16:46.608370
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Test")


# Generated at 2022-06-21 20:16:53.370448
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`.
    """
    # pylint: disable=unused-variable
    @ProgrammingError.passert(condition=True, message=None)
    def dummy_method():
        pass
    message = "ERROR"
    try:
        @ProgrammingError.passert(condition=False, message=message)
        def broken_method():
            pass
        assert False  # pragma: no cover
    except ProgrammingError as error:
        assert error.args[0] == message

# Generated at 2022-06-21 20:16:54.720197
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except Exception as e:
        assert type(e) == ProgrammingError


# Generated at 2022-06-21 20:17:19.591941
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        pass # OK
    except BaseException:
        assert False



# Generated at 2022-06-21 20:17:21.188737
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Programming error test")
    except ProgrammingError:
        pass
    else:
        raise Exception("Test failed because expected ProgrammingError to be raised")


# Generated at 2022-06-21 20:17:23.831438
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message.")
    except ProgrammingError as e:
        assert "Test message." in str(e)


# Generated at 2022-06-21 20:17:26.509839
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise ValueError("Raising ProgrammingError should not fail.")

# Generated at 2022-06-21 20:17:28.459454
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    lst = []
    ProgrammingError.passert(len(lst) == 0, "lst should be empty")
    assert True


# Generated at 2022-06-21 20:17:30.224188
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-21 20:17:35.198576
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected_error_message = 'Broken coherence. Check your code against domain logic to fix it.'
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert (e.args[0] == expected_error_message)
        assert e.__class__.__name__ == 'ProgrammingError'


# Generated at 2022-06-21 20:17:42.034516
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)

    assert ProgrammingError.__doc__ == "Provides a programming error exception.\n\n    The rationale for this exception " \
                                      "is to raise them whenever we rely on meta-programming and the programmer " \
                                      "has introduced a statement which breaks the coherence of the domain logic.\n    "

    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == ""

    try:
        raise ProgrammingError("foobar")
    except ProgrammingError as e:
        assert str(e) == "foobar"


# Generated at 2022-06-21 20:17:42.458967
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-21 20:17:43.922260
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Bad programmer!")
    except ProgrammingError as e:
        assert str(e) == "Bad programmer!"

# Generated at 2022-06-21 20:18:48.484545
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-21 20:18:49.999440
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-21 20:18:53.202944
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    # Test the default constructor
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    # Test the message constructor
    try:
        raise ProgrammingError("This is a test message")
    except ProgrammingError as e:
        assert str(e) == "This is a test message"


# Generated at 2022-06-21 20:18:55.992549
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error.")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "This is a programming error."


# Generated at 2022-06-21 20:18:58.657581
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    with ProgrammingError("Message"):
        pass

    with ProgrammingError("Error message", cause=RuntimeError("This is a good cause!")):
        pass


# Generated at 2022-06-21 20:19:02.429571
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "This is the message for test_ProgrammingError"
    try:
        ProgrammingError(message)
        assert False
    except ProgrammingError as e:
        assert message==str(e)

# Unit tests for passert method of class ProgrammingError

# Generated at 2022-06-21 20:19:06.802906
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(Exception):
        ProgrammingError.passert(False, "A")

    with pytest.raises(Exception):
        ProgrammingError.passert(False, None)

    # No exception if condition is true
    ProgrammingError.passert(True, None)
    ProgrammingError.passert(True, "A")

# Generated at 2022-06-21 20:19:08.089294
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # type: () -> None
    try:
        raise ProgrammingError("Some error.")
    except ProgrammingError as pe:
        assert pe.message == "Some error."


# Generated at 2022-06-21 20:19:09.582407
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("test")


# Generated at 2022-06-21 20:19:11.397121
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("a message")
    except ProgrammingError as e:
        assert e.args == ("a message",)


# Generated at 2022-06-21 20:21:12.687565
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as e:
        assert str(e) == "This is an error"


# Generated at 2022-06-21 20:21:14.442895
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("hello")
    except ProgrammingError as e:
        assert str(e) == "hello"


# Generated at 2022-06-21 20:21:16.800670
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.error import ProgrammingError

    with raises(ProgrammingError):
        ProgrammingError("This is a programming error.")



# Generated at 2022-06-21 20:21:19.269805
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is the message")
    except ProgrammingError as e:
        assert "This is the message" == e.args[0]


# Generated at 2022-06-21 20:21:23.530166
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Oh, this is an expected exception!")
    except ProgrammingError as err:
        assert str(err) == "Oh, this is an expected exception!"


# Generated at 2022-06-21 20:21:26.066864
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Nice message."
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert str(e) == message

# Generated at 2022-06-21 20:21:27.719426
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        exception = ProgrammingError("Broken coherence")
        assert exception.args == ("Broken coherence",)
    except Exception as error:
        assert False, "ProgrammingError constructor not as expected: {}".format(str(error))
