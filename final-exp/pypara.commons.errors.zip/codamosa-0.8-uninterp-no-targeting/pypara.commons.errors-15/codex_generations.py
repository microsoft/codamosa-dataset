

# Generated at 2022-06-21 20:11:33.796111
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test for the ProgrammingError constructor.")
    except ProgrammingError as ex:
        assert ex.args == ("This is a test for the ProgrammingError constructor.", )

# Generated at 2022-06-21 20:11:36.516372
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the class :py:class:`ProgrammingError`.
    """

    try:
        raise ProgrammingError("Test case.")
    except ProgrammingError as e:
        assert "Test case." == str(e)



# Generated at 2022-06-21 20:11:39.643622
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Due to the fact that we are not using the error message parameter of the passert method, we raise
        # the exception without any message.
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert "coherence" in e.message
        assert "domain" in e.message
        assert "code" in e.message

# Generated at 2022-06-21 20:11:43.706997
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert (str(e) == "Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-21 20:11:46.185558
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as err:
        assert err.args[0] == "This is a test"


# Generated at 2022-06-21 20:11:48.776898
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="This is a test.")
        raise AssertionError("Expected ProgrammingError not raised.")
    except ProgrammingError as e:
        assert "This is a test." == e.args[0]


# Generated at 2022-06-21 20:11:49.466196
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert True

# Generated at 2022-06-21 20:11:51.920749
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Error message"):
        with ProgrammingError("Different message"):
            pass


# Generated at 2022-06-21 20:11:53.469538
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Calling the constructor should work in any case")
    except:
        pass

# Generated at 2022-06-21 20:11:56.362449
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, message = "test")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-21 20:12:00.731236
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing...")
    except ProgrammingError as e:
        assert str(e) == "Testing..."
    else:
        assert False, "Testing..."



# Generated at 2022-06-21 20:12:03.840337
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(None)
    except ProgrammingError as e:
        raise AssertionError(e.args[0] != "Broken coherence. Check your code against domain logic to fix it.")\
            from e



# Generated at 2022-06-21 20:12:06.481112
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception:
        assert True


# Generated at 2022-06-21 20:12:08.178923
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test") as exc:
        exc.args[0] == "Test"

# Generated at 2022-06-21 20:12:10.368975
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Test")
        assert True
    except ProgrammingError:
        assert True

# Generated at 2022-06-21 20:12:11.847260
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-21 20:12:13.752773
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # It should work.
    ProgrammingError()


# Generated at 2022-06-21 20:12:15.816691
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # When
    error = ProgrammingError("An error has happened")

    # Then
    assert str(error) == "An error has happened"

# Generated at 2022-06-21 20:12:18.580412
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    e = ProgrammingError("This is an error message")
    assert str(e) == "This is an error message"

# Generated at 2022-06-21 20:12:23.529800
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError.passert(False, "An error")
        assert False
    except ProgrammingError as err:
        assert str(err) == "An error"

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as err:
        assert str(err) == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(True, "An error")
        assert True
    except ProgrammingError as err:
        assert False

# Generated at 2022-06-21 20:12:28.895989
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hello World!")
    except ProgrammingError as exception:
        assert "Hello World!" == exception.args[0]
    else:
        raise Exception("Expected ProgrammingError!")


# Generated at 2022-06-21 20:12:35.041237
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("")
    except ProgrammingError as ex:
        assert str(ex) == ""
    try:
        raise ProgrammingError("Not empty")
    except ProgrammingError as ex:
        assert str(ex) == "Not empty"


# Generated at 2022-06-21 20:12:37.705604
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert str(error) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:12:43.587762
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")
        assert False, "An exception should be raised"
    except ProgrammingError as err:
        assert str(err) == "Test message"

    try:
        ProgrammingError.passert(True, "Test message")
    except ProgrammingError:
        assert False, "Exception should not be raised"

# Generated at 2022-06-21 20:12:44.857366
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("Error message.")


# Generated at 2022-06-21 20:12:48.950965
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False and "Unit test passed"  # Unit test failed
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." in str(e)
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:12:51.091782
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as e:
        assert "Message" in str(e)


# Generated at 2022-06-21 20:12:52.562865
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError is not None

# Generated at 2022-06-21 20:12:57.899191
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pyassert import assert_that
    from pyhamcrest import equal_to
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert_that(str(e), equal_to("Broken coherence. Check your code against domain logic to fix it."))



# Generated at 2022-06-21 20:13:00.004079
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("Testing error")
    assert isinstance(exception, ProgrammingError)


# Generated at 2022-06-21 20:13:08.627685
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as error:
        assert error.args[0] == "This is a test"


# Generated at 2022-06-21 20:13:16.849186
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        with pytest.raises(ProgrammingError):
            ProgrammingError.passert(False, "Condition description")
    except:
        assert False
        pass

    try:
        with pytest.raises(ProgrammingError):
            ProgrammingError.passert(False, None)
    except:
        assert False
        pass

    try:
        ProgrammingError.passert(True, "Condition description")
    except:
        assert False
        pass

    try:
        ProgrammingError.passert(True, None)
    except:
        assert False
        pass

# Generated at 2022-06-21 20:13:21.509317
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    assert ProgrammingError().args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-21 20:13:24.305975
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError('test')
    except Exception as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-21 20:13:26.312566
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        raise ProgrammingError("error message")


# Generated at 2022-06-21 20:13:33.977709
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyUnusedLocal
    def constructor(message: str) -> None:
        try:
            raise ProgrammingError(message)
        except ProgrammingError:
            pass

    # noinspection PyUnusedLocal
    def passert(condition: bool, message: str) -> None:
        try:
            ProgrammingError.passert(condition, message)
        except ProgrammingError:
            pass

    message = "Error message"
    constructor(message)
    passert(True, message)
    try:
        passert(False, message)
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:13:35.195472
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    cls = ProgrammingError()
    assert isinstance(cls, ProgrammingError)

# Generated at 2022-06-21 20:13:39.197124
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    This function instantiates the :py:class:`ProgrammingError` class.

    :return: None
    """
    # Instantiate the class
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:13:42.190510
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-21 20:13:44.770673
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError:
        assert True

# Generated at 2022-06-21 20:13:59.427772
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # assert condition = True
    ProgrammingError.passert(True, "")
    # assert condition = False
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    # assert without message
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:14:01.649302
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Just testing!"):
        pass
    with ProgrammingError.passert(False, "Just testing!"):
        pass

# Generated at 2022-06-21 20:14:04.678073
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Act - Assert
    try:
        ProgrammingError("a")
    except Exception as ex:
        assert isinstance(ex, ProgrammingError) and ex.__class__ is ProgrammingError


# Generated at 2022-06-21 20:14:08.131211
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test that the constructor of the exception class :py:class:`ProgrammingError` does what it is expected to do.
    """
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Test")

# Generated at 2022-06-21 20:14:14.806715
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`.
    """
    # Test default message
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    # Test non-default message
    try:
        raise ProgrammingError("My message")
    except ProgrammingError as e:
        assert str(e) == "My message"

# Generated at 2022-06-21 20:14:19.564464
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.testing import assert_raises, intercepts
    with intercepts(ProgrammingError):
        ProgrammingError.passert(False, "Unit test failed.")
    assert_raises(ProgrammingError, lambda: ProgrammingError.passert(False, "Unit test failed.")); del assert_raises
    assert_raises(ProgrammingError, lambda: ProgrammingError.passert(False, None)); del assert_raises


# Generated at 2022-06-21 20:14:23.433290
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test.")
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:14:28.055033
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # We expect a ProgrammingError when we instantiate the class with a message
    try:
        raise ProgrammingError("This is an error.") # pylint: disable=unused-variable
    except ProgrammingError as e:
        assert e.args[0] == "This is an error." # pylint: disable=unsupported-membership-test
    # We expect a ProgrammingError when we run the passert function with false condition
    try:
        ProgrammingError.passert(condition=False, message="This is an error.") # pylint: disable=unused-variable
    except ProgrammingError as e:
        assert e.args[0] == "This is an error." # pylint: disable=unsupported-membership-test

# Generated at 2022-06-21 20:14:33.173292
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`.
    """
    assert issubclass(ProgrammingError, Exception)
    assert isinstance(ProgrammingError(), ProgrammingError)
    assert isinstance(ProgrammingError("Some message"), ProgrammingError)


# Generated at 2022-06-21 20:14:38.241789
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # arrange
    from pypara.asserts import Assert
    from pypara.asserts import AssertionError

    message = "test message"

    # act
    try:
        ProgrammingError(message)
    except ProgrammingError as ex:
        # assert
        Assert.assert_equal(ex.__str__(), message)
    else:
        Assert.fail(AssertionError)


# Generated at 2022-06-21 20:15:00.380247
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Ooops")
    except ProgrammingError as exception:
        assert str(exception) == "Ooops"



# Generated at 2022-06-21 20:15:09.510030
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Test message"):
        pass

    try:
        with ProgrammingError.passert(False, "Test message"):
            pass
    except ProgrammingError as pe:
        assert pe.args == ("Test message",)
    else:
        assert False

    try:
        with ProgrammingError.passert(False, None):
            pass
    except ProgrammingError as pe:
        assert pe.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    else:
        assert False

# Generated at 2022-06-21 20:15:10.886285
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)


# Generated at 2022-06-21 20:15:14.628368
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")
    ProgrammingError.passert(True, "Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-21 20:15:18.112853
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(True, "Programming error")
    ProgrammingError.passert(False, "Programming error")

# Generated at 2022-06-21 20:15:22.370468
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Should not raise an error
        ProgrammingError.passert(True, "This is the message in case of error")
        # Should raise an error
        ProgrammingError.passert(False, "This is the message in case of error")
    except ProgrammingError as ex:
        print(ex)

# Generated at 2022-06-21 20:15:24.316049
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is an exception of class ProgrammingError")
    except:
        assert False
    assert True


# Generated at 2022-06-21 20:15:26.768644
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "Test message"


# Generated at 2022-06-21 20:15:32.471246
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected = "test_ProgrammingError"

    try:
        ProgrammingError(expected)
    except ProgrammingError as ex:
        actual = str(ex)
        message = f"Unexpected message. - Expected = {expected} | Actual = {actual}"
        assert actual == expected, message
    else:
        message = f"Exception {type(ProgrammingError).__qualname__} not raised."
        assert False, message


# Generated at 2022-06-21 20:15:41.978703
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of :py:class:`ProgrammingError`."""
    expected = "Broken coherence. Check your code against domain logic to fix this."
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == expected
    else:
        raise AssertionError("Did not raise ProgrammingError")

    try:
        ProgrammingError("User-given message")
    except ProgrammingError as e:
        assert str(e) == "User-given message"
    else:
        raise AssertionError("Did not raise ProgrammingError")


# Generated at 2022-06-21 20:16:36.557110
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # type: () -> None
    try:
        ProgrammingError()
    except:
        pass

# Generated at 2022-06-21 20:16:39.181997
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN

    # WHEN
    actual_exception = ProgrammingError("condition not met")

    # THEN
    assert isinstance(actual_exception, ProgrammingError)
    assert actual_exception.args == ("condition not met",)


# Generated at 2022-06-21 20:16:42.171624
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("TEST")
    except Exception as ex:
        assert str(ex) == "TEST"


# Generated at 2022-06-21 20:16:46.458308
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("I'm a coherence error")
    except ProgrammingError as e:
        assert str(e) == "I'm a coherence error"
        assert e.args == ("I'm a coherence error",)


# Generated at 2022-06-21 20:16:48.617073
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "SOME"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as raised:
        assert raised.args == (message,)

# Generated at 2022-06-21 20:16:51.971372
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        raise AssertionError("Should have failed!")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Should have failed!")

# Generated at 2022-06-21 20:16:53.622334
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert True
    else:
        assert False


# Generated at 2022-06-21 20:16:54.388518
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("error message")

# Generated at 2022-06-21 20:16:56.409549
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)

    error = ProgrammingError("testing")
    assert error.args[0] == "testing"


# Generated at 2022-06-21 20:17:00.920830
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
  """ProgrammingError.__init__(...)"""
  msg = "Test message"
  try:
    raise ProgrammingError(msg)
  except ProgrammingError as e:
    assert(e.args[0] == msg)


# Generated at 2022-06-21 20:18:55.205543
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("a programming error")


# Generated at 2022-06-21 20:19:05.335432
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test :py:meth:`ProgrammingError.__init__`.

    :return: A test result object.
    """
    import unittest

    class ProgrammingErrorTest(unittest.TestCase):
        """
        Test class of :py:class:`ProgrammingError`.
        """

        def test(self):
            """
            Test :py:func:`test_ProgrammingError`.

            :return: ``None``
            """

            class MyError(ProgrammingError):
                """
                An error class extending :py:class:`ProgrammingError`.
                """

                pass

            with self.assertRaises(ProgrammingError):
                ProgrammingError.passert(False, "error")

            with self.assertRaises(ProgrammingError):
                ProgrammingError.passert(False, "")


# Generated at 2022-06-21 20:19:08.818356
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as error:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("ProgrammingError() not working.")



# Generated at 2022-06-21 20:19:11.665823
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test constructor of class :py:class:`ProgrammingError`."""
    error = ProgrammingError("This is a message")
    assert isinstance(error, Exception)
    assert str(error) == "This is a message"


# Generated at 2022-06-21 20:19:16.152870
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class TestError(ProgrammingError):
        pass
    try:
        ProgrammingError.passert(False, "This message must be displayed when the exception is raised.")
        raise AssertionError("This shouldn't have happened.")
    except ProgrammingError as e:
        assert str(e) == "This message must be displayed when the exception is raised."

    try:
        ProgrammingError.passert(False, None)
        raise AssertionError("This shouldn't have happened.")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:19:18.289162
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("msg1")
    except Exception as e:
        assert str(e) == "msg1"


# Generated at 2022-06-21 20:19:19.921214
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "test"):
        pass


# Generated at 2022-06-21 20:19:27.485533
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyProtectedMember
    assert issubclass(ProgrammingError, Exception)
    assert ProgrammingError.__doc__ is not None
    assert ProgrammingError.__init__.__doc__ is not None
    assert ProgrammingError().__str__() != ""
    try:
        # noinspection PyStatementEffect
        ProgrammingError()
        ProgrammingError.passert(condition=True, message=None)
        ProgrammingError.passert(condition=False, message=None)
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError did not happen."

# Generated at 2022-06-21 20:19:32.901768
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.lang.error import ProgrammingError

    with raises(ProgrammingError):
        raise ProgrammingError()

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Failed assertion")

    try:
        ProgrammingError.passert(True, "Failed assertion")
    except ProgrammingError:
        raise AssertionError("ProgrammingError is not supposed to be raised in that case")


# Generated at 2022-06-21 20:19:39.803558
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def f() -> None:
        try:
            raise ProgrammingError
        except ProgrammingError as e:
            assert strings.to_str(e) == "Broken coherence. Check your code against domain logic to fix it."

    f()
