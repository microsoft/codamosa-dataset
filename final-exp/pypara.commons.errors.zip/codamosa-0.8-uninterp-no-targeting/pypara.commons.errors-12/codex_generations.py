

# Generated at 2022-06-21 20:11:34.330603
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert(isinstance(e, ProgrammingError))
        assert((e.__str__()) == 'Broken coherence. Check your code against domain logic to fix it.')


# Generated at 2022-06-21 20:11:36.108968
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("broke")
    except ProgrammingError as e:
        assert str(e) == "broke"


# Generated at 2022-06-21 20:11:37.745184
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test error")
    except ProgrammingError as e:
        assert "Test error" == str(e)


# Generated at 2022-06-21 20:11:43.812239
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My error message")
    except ProgrammingError as err:
        assert "My error message" in repr(err) and "My error message" in str(err)
    except Exception as err:
        raise err


# Generated at 2022-06-21 20:11:45.540970
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ex = ProgrammingError("My message")
    assert ex.args == ("My message",)


# Generated at 2022-06-21 20:11:47.185029
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:11:48.583189
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(Exception("Test"))
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:11:51.874275
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class :py:class:`ProgrammingError`.

    :return: ``None``.
    """
    ProgrammingError(message="Test message.")

# Generated at 2022-06-21 20:11:53.356664
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()

# Generated at 2022-06-21 20:11:56.548819
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as value:
        assert value.args[0] == "Test"
    else:
        assert False, "The exception was not raised"


# Generated at 2022-06-21 20:12:00.120683
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-21 20:12:04.116391
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "message")
    except ProgrammingError as e:
        assert e.args == ("message", )
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.", )

# Generated at 2022-06-21 20:12:08.324740
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Intended message")
    except ProgrammingError as e:
        assert str(e) == "Intended message"


# Generated at 2022-06-21 20:12:12.166828
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError.passert(False, "This is an error")
        assert 0, "We should not get here"
    except ProgrammingError as e:
        assert e.args[0] == "This is an error"

    assert ProgrammingError.passert(True, None) is None

# Generated at 2022-06-21 20:12:14.362453
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:12:16.733060
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('test')
    except ProgrammingError as e:
        assert str(e) == 'test', "ProgrammingError does not correctly construct the message."


# Generated at 2022-06-21 20:12:19.349902
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    except Exception as exc:
        assert False, "Default constructor should raise ProgrammingError, not {}".format(type(exc))


# Generated at 2022-06-21 20:12:22.269992
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-21 20:12:22.900206
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-21 20:12:25.459929
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except Exception as e:
        assert str(e) == ""


# Generated at 2022-06-21 20:12:28.969478
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test_ProgrammingError")
    except ProgrammingError as exc:
        assert exc.args[0] == "test_ProgrammingError"

# Generated at 2022-06-21 20:12:30.046928
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "Some message")

# Generated at 2022-06-21 20:12:32.641652
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-21 20:12:39.130599
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Test for empty message parameter
        ProgrammingError.passert(False, "")
        assert False, "ProgrammingError not raised"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it.", "Wrong message."

    try:
        # Test for non-empty message parameter
        ProgrammingError.passert(False, "test")
        assert False, "ProgrammingError not raised"
    except ProgrammingError as e:
        assert str(e) == "test", "Wrong message."

# Generated at 2022-06-21 20:12:41.850101
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Testing message")
    assert error.message == "Testing message"


# Generated at 2022-06-21 20:12:45.325805
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor of class ProgrammingError.
    """

    # Executes the test
    error_message = "This is an error message"
    try:
        raise ProgrammingError(error_message)
    except ProgrammingError as e:
        assert error_message == str(e)


# Generated at 2022-06-21 20:12:47.243388
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError("Any message.")



# Generated at 2022-06-21 20:12:53.990628
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Test passing a falsy condition
        ProgrammingError.passert(False, "A falsy condition")
    except ProgrammingError as e:
        assert "A falsy condition" == e.args[0]

    try:
        # Test passing a falsy condition with no additional information
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == e.args[0]

# Generated at 2022-06-21 20:12:56.919205
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError("")
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:13:00.259986
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"
        assert e.args[0] == "Test message"


# Generated at 2022-06-21 20:13:14.860053
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from nose.tools import assert_raises
    from nose.tools import assert_true
    from unittest.mock import call
    from unittest.mock import MagicMock

    # We simulate a programming error
    assert_raises(ProgrammingError, ProgrammingError, "Test")
    assert_raises(ProgrammingError, ProgrammingError.passert, False, "Test")

    # We mock the error to test the message
    mock_err = MagicMock(side_effect = ProgrammingError)
    assert_raises(ProgrammingError, mock_err, "Test")
    mock_err.assert_called_once_with('Test')

    # We ensure that the condition is working properly
    mock_err = MagicMock(side_effect = ProgrammingError)
    assert_true(ProgrammingError.passert(True, "Test"))

# Generated at 2022-06-21 20:13:17.500049
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as e:
        print(e)

# Generated at 2022-06-21 20:13:26.168573
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`pypara.errors.ProgrammingError`.
    """
    from pypara._function_utils import fn_args

    ProgrammingError.passert(True, None)

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as error:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("No ProgrammingError raised.")


# Generated at 2022-06-21 20:13:28.913787
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Oops!")
    except ProgrammingError as e:
        assert str(e) == "Oops!"
    else:
        raise RuntimeError("ProgrammingError was not raised")

# Generated at 2022-06-21 20:13:33.620335
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError("This is a message")
    except ProgrammingError as e:
        assert e.args[0] == "This is a message"
    else:
        raise Exception("ProgrammingError not raised")


# Generated at 2022-06-21 20:13:36.503716
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Check that that it contains the message sent to constructor
    message = "test"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert str(e) == message


# Generated at 2022-06-21 20:13:41.658333
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, "Expect error to be raised")
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:13:46.800041
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    success = False
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."
        success = True
    assert success


# Generated at 2022-06-21 20:13:52.357141
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test method for the constructor of the :py:class:`ProgrammingError` class.
    """
    try:
        ProgrammingError()
    except ProgrammingError as error:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError("Fail")
    except ProgrammingError as error:
        assert str(error) == "Fail"


# Generated at 2022-06-21 20:13:56.731085
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Some error")
        assert False
    except Exception as e:
        assert "Some error" == e.args[0]

# Generated at 2022-06-21 20:14:05.390399
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert(str(e) == "Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-21 20:14:08.129561
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Test passed"):
        pass

    with ProgrammingError.passert(False, "Test failed"):
        pass

# Generated at 2022-06-21 20:14:11.481075
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Invalid coherence.")
    except ProgrammingError as e:
        assert (str(e) == "Invalid coherence.")


# Generated at 2022-06-21 20:14:13.378238
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some domain problem")
    except ProgrammingError as ex:
        print(ex)

# Generated at 2022-06-21 20:14:16.693563
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`.

    :return: ``None``
    """
    try:
        ProgrammingError("Custom message")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Expected exception of type: ProgrammingError")



# Generated at 2022-06-21 20:14:18.632728
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as exc:
        assert exc is not None
        assert str(exc) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError()


# Generated at 2022-06-21 20:14:25.556316
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Checks the proper behavior of the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:14:27.500654
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test of a programming error.")
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:14:30.824934
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "Error message"
    err = ProgrammingError(msg)
    assert err.args[0] == msg


# Generated at 2022-06-21 20:14:40.139186
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from nose.tools import assert_raises_regexp  # type: ignore

    # Unit tests for the constructor of ProgrammingError
    class Test:
        def test_programming_error_with_message(self):
            try:
                raise ProgrammingError("Message")
            except ProgrammingError as error:
                assert error.args[0] == "Message"

        def test_programming_error_without_message(self):
            try:
                raise ProgrammingError()
            except ProgrammingError as error:
                assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    # Executing the tests
    test = Test()
    test.test_programming_error_with_message()
    test.test_programming_error_without_message()

# Generated at 2022-06-21 20:14:53.491088
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert False
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-21 20:14:55.059694
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    raise ProgrammingError(message="Test message")

# Generated at 2022-06-21 20:14:59.784676
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test default programming error
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert not err.args

    # Test custom programming error
    try:
        raise ProgrammingError("Custom Error")
    except ProgrammingError as err:
        assert err.args[0] == "Custom Error"


# Generated at 2022-06-21 20:15:03.156916
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:15:06.186518
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert e.args == ("This is a test.",)


# Generated at 2022-06-21 20:15:08.643227
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Unit test for constructor of class ProgrammingError. """
    assert ProgrammingError("This is a test.")



# Generated at 2022-06-21 20:15:12.856434
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`.
    """
    # pylint: disable=invalid-name
    try:
        raise ProgrammingError("A programming error happened.")
    except ProgrammingError as e:
        assert "A programming error happened." == str(e)
        raise


# Generated at 2022-06-21 20:15:14.214005
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("oops!"):
        raise ProgrammingError("oops")

# Generated at 2022-06-21 20:15:16.488130
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the instantiation and description of Error objects."""
    p = ProgrammingError()
    assert str(p) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:15:21.208730
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing")
        assert False, "Error not raised by ProgrammingError"
    except ProgrammingError as err:
        assert err.args[0] == "Testing"



# Generated at 2022-06-21 20:15:45.192128
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("hi")
    except ProgrammingError as e:
        assert e.args[0] == "hi"


# Generated at 2022-06-21 20:15:48.255935
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(None, "")
    try:
        ProgrammingError.passert(None, None)
        assert False, "ProgrammingError has not been raised."
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:15:52.235101
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    # WHEN
    # THEN
    ProgrammingError.passert(True, "this is a message")
    pass  # and then nothing happens



# Generated at 2022-06-21 20:15:56.033917
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Programmer error is raised when a program is not compliant with predefined rules.
    """
    try:
        raise ProgrammingError("test")
    except ProgrammingError as error:
        assert str(error) == "test"


# Generated at 2022-06-21 20:15:57.609908
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("My custom error message.")

# Generated at 2022-06-21 20:16:00.965007
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Foo")
    except Exception as exc:
        assert exc.args == ("Foo",)

# Unit tests for the passert method

# Generated at 2022-06-21 20:16:02.574349
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:16:04.470580
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass



# Generated at 2022-06-21 20:16:08.260890
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for :py:class:`ProgrammingError`."""

    try:
        raise ProgrammingError("Oh no! The sky is falling down!.")
    except ProgrammingError as e:
        assert "Oh no! The sky is falling down!." in str(e)


# Generated at 2022-06-21 20:16:10.558554
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Just for testing")
    except ProgrammingError as ex:
        assert ex.args[0] == "Just for testing"



# Generated at 2022-06-21 20:17:01.345285
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a message")
    except ProgrammingError as exc:
        assert exc.args[0] == "This is a message"



# Generated at 2022-06-21 20:17:03.557212
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("This is a test.")


# Generated at 2022-06-21 20:17:07.307757
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of class ProgrammingError."""
    ProgrammingError(message="OK")
    ProgrammingError(message="OK").passert(condition=True, message="OK")
    ProgrammingError(message="OK").passert(condition=False, message="OK")  # Expect an exception

# Generated at 2022-06-21 20:17:10.225974
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as e:
        assert str(e) == "This is an error"


# Generated at 2022-06-21 20:17:13.624038
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.assertRaises(AssertionError):
        ProgrammingError.passert(True, "")
    with ProgrammingError.assertRaises():
        ProgrammingError.passert(False, "")

# Generated at 2022-06-21 20:17:16.930370
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Runs a unit test to check the constructor of class ProgrammingError.
    """
    try:
        raise ProgrammingError("")
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("foo")
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:17:22.823471
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test to check that the constructor of `ProgrammingError` works fine.
    """
    with raises(ProgrammingError) as context:
        ProgrammingError("This is the reason why the error was raised")
    err = context.value
    assert isinstance(err, ProgrammingError)
    assert err.args[0] == "This is the reason why the error was raised"


# Generated at 2022-06-21 20:17:25.107503
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of class ProgrammingError"""
    exc = ProgrammingError("Failure")
    assert str(exc) == "Failure"


# Generated at 2022-06-21 20:17:28.657738
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Expected assertion")
        assert False, "Should never reach this point"
    except ProgrammingError as e:
        assert e.args[0] == "Expected assertion", "Expected message"

# Generated at 2022-06-21 20:17:30.405925
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error")
    except ProgrammingError as e:
        assert str(e) == "Error"


# Generated at 2022-06-21 20:19:33.742399
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("error")
    except ProgrammingError as error:
        assert str(error) == "error"

    try:
        ProgrammingError()
    except ProgrammingError as error:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-21 20:19:38.897219
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "This is a test"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert message == str(e)


# Generated at 2022-06-21 20:19:40.767289
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyStatementEffect
    ProgrammingError("Message to describe the error")


# Generated at 2022-06-21 20:19:43.988156
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "valid")
    try:
        ProgrammingError.passert(False, "invalid")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:19:45.666752
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("error")
    assert str(e) == "error"

# Generated at 2022-06-21 20:19:48.657118
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert str(error) == "Broken coherence. Check your code against domain logic to fix it."
    error = ProgrammingError("Error")
    assert str(error) == "Error"



# Generated at 2022-06-21 20:19:53.417683
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "It's a bad, bad world"
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as e:
        assert e.__str__() == msg
    else:
        assert False, "The above call to raise should trigger an exception"


# Generated at 2022-06-21 20:19:56.593948
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except:
        pass
    else:
        raise AssertionError("ProgrammingError constructor did not raise exception")


# Generated at 2022-06-21 20:20:00.018351
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Domain Logic")
    except Exception as err:
        #
        # Test constructor to ensure that it raises the expected exception
        #
        assert isinstance(err, ProgrammingError)
        assert "Domain Logic" in str(err)


# Generated at 2022-06-21 20:20:00.792464
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="you shall not pass")