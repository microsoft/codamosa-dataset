

# Generated at 2022-06-21 20:11:40.419744
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test suite for testing the constructor of class :py:class:`ProgrammingError`.
    """
    # Should raise exception.
    try:
        raise ProgrammingError()
    except:
        pass
    # Should not raise exception.
    try:
        ProgrammingError.passert(True, "Some message.")
    except:
        assert False, "ProgrammingError exception was raised but it should not."
    # Should raise exception.
    try:
        ProgrammingError.passert(False, "Some message.")
        assert False, "ProgrammingError exception should have been raised, but it was not."
    except:
        pass
    # Generic exception should be raised.

# Generated at 2022-06-21 20:11:42.863075
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "This should be raised because condition is not met."):
        pass



# Generated at 2022-06-21 20:11:48.742465
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="This is a test")
    except ProgrammingError as e:
        assert e.message == "This is a test"
    try:
        ProgrammingError.passert(condition=False, message=None)
    except ProgrammingError as e:
        assert e.message == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(condition=True)
    except ProgrammingError:
        assert False

# Generated at 2022-06-21 20:11:52.361252
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.

    This test requires that no exception is raised.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass



# Generated at 2022-06-21 20:11:56.549159
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "Should not raise error")
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Should raise error")
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)

# Generated at 2022-06-21 20:12:01.002821
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test case for the constructor of class ProgrammingError.
    """
    # noinspection PyTypeChecker
    ProgrammingError.passert(True, "")
    try:
        # noinspection PyTypeChecker
        ProgrammingError.passert(False, "")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:12:03.877313
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    msg = "Error description."

    # WHEN
    exception = ProgrammingError(msg)

    # THEN
    assert f"{msg}" == f"{exception}"



# Generated at 2022-06-21 20:12:06.908945
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        return
    assert False


# Generated at 2022-06-21 20:12:08.644684
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass



# Generated at 2022-06-21 20:12:11.282128
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error.args == ()
    error = ProgrammingError("My message.")
    assert error.args == ("My message.",)


# Generated at 2022-06-21 20:12:15.304240
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError('Error message')
    except Exception as ex:
        assert isinstance(ex, ProgrammingError)
        assert str(ex) == 'Error message'


# Generated at 2022-06-21 20:12:18.739163
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert e.__str__() == "Error message"
        assert e.args == ("Error message",)
    else:
        raise AssertionError("No Error has been raised.")


# Generated at 2022-06-21 20:12:21.282845
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "The condition is not met")
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-21 20:12:29.087740
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Boo!")
    except ProgrammingError as e:
        assert str(e) == "Boo!"
    else:
        assert False

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False

    ProgrammingError.passert(True, "Boo!")

# Generated at 2022-06-21 20:12:31.123341
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError()
    except Exception as error:
        assert isinstance(error, ProgrammingError)


# Generated at 2022-06-21 20:12:33.543864
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-21 20:12:35.314555
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "oops!")
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:12:43.581034
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the programming error class. See :py:meth:`ProgrammingError.passert`.
    """
    e = None
    try:
        ProgrammingError.passert(False, "foo")
    except ProgrammingError as exception:
        e = exception

    assert isinstance(e, ProgrammingError)
    assert e.args[0] == "foo"

    e = None
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as exception:
        e = exception

    assert isinstance(e, ProgrammingError)
    assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    e = None
    try:
        ProgrammingError.passert(True, "foo")
    except ProgrammingError:
        e = True


# Generated at 2022-06-21 20:12:50.602314
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Call test method passert to raise an exception
        ProgrammingError.passert(False, "This is a message for the raised exception")
        # Should not get here.
        assert False
    except ProgrammingError as e:
        assert (
            e.__str__() == "This is a message for the raised exception"
        )  # Test message
        assert e.args[0] == "This is a message for the raised exception"  # Test field args

# Generated at 2022-06-21 20:12:53.654917
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Code is broken.")
    except ProgrammingError as err:
        assert err.args == ("Code is broken.",)


# Generated at 2022-06-21 20:12:58.040914
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("hello")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "hello"


# Generated at 2022-06-21 20:13:00.932297
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, 'test')
        assert False, "Exception not raised"
    except ProgrammingError as e:
        assert str(e) == 'test'

# Generated at 2022-06-21 20:13:03.729734
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("I am a message")
    except ProgrammingError as e:
        assert str(e) == "I am a message", "Wrong message for ProgrammingError."


# Generated at 2022-06-21 20:13:07.728287
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=True, message=None)
    except ProgrammingError as error:
        assert False, error

    try:
        ProgrammingError.passert(condition=False, message="Expected")
        assert False, "Must have risen ProgrammingError"
    except ProgrammingError as error:
        assert repr(error) == "ProgrammingError(\"Expected\")"

# Generated at 2022-06-21 20:13:08.913918
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyTypeChecker
    ProgrammingError()
    ProgrammingError("Dummy")


# Generated at 2022-06-21 20:13:11.776785
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "A simple example")
    except ProgrammingError as e:
        assert e.__cause__ is None
        assert str(e) == "A simple example"


# Generated at 2022-06-21 20:13:17.732564
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    with ProgrammingError.passert(condition=True, message="It always passes!"):
        print("This code is executed!")

    try:
        with ProgrammingError.passert(condition=False, message="It always fails!"):
            print("This code is NOT executed!")
    except ProgrammingError as e:
        print("The error is: " + str(e))

if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-21 20:13:20.911293
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(message='message')


# Generated at 2022-06-21 20:13:25.757534
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    expected_message = "this is the expected error message."

    # Act
    try:
        raise ProgrammingError(expected_message)
    except ProgrammingError as e:
        actual_message = e.args[0]

    # Assert
    assert (expected_message == actual_message)


# Generated at 2022-06-21 20:13:33.470060
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Verifies the proper initialization of the class :py:class:`ProgrammingError`.
    """

    # Check that the exception is properly initialized
    try:
        raise ProgrammingError("Please fix your code!")
    except ProgrammingError as ex:
        assert ex
        assert str(ex) == "Please fix your code!"

    # Check that the method passert() works properly
    try:
        ProgrammingError.passert(False, "Please fix your code!")
        assert False, "Should not be here"
    except ProgrammingError as ex:
        assert ex
        assert str(ex) == "Please fix your code!"

# Generated at 2022-06-21 20:13:39.926147
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("")
    assert error.args == ("",)


# Generated at 2022-06-21 20:13:42.501851
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error occurred.")
    except ProgrammingError as e:
        assert "A programming error occurred." == str(e)

# Generated at 2022-06-21 20:13:45.951161
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=I0011, W0612
    ProgrammingError.passert(True, None)
    ProgrammingError.passert(False, "my message")

# Generated at 2022-06-21 20:13:54.667896
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for class ProgrammingError"""
    class MyClass:
        """Dummy class"""

        def __repr__(self):
            """Dummy representation"""
            return "Dummy representation"

    # Test condition true
    ProgrammingError.passert(True, "Test message")

    # Test condition false
    try:
        ProgrammingError.passert(False, "Test message")
    except ProgrammingError as error:
        assert error.args[0] == "Test message"

    # Test condition false with no message
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    # Test condition false with non string message

# Generated at 2022-06-21 20:14:01.587832
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`.ProgrammingError`.
    """
    with ProgrammingError("This is an expected error!"):
        raise ProgrammingError("This is an expected error!")
    try:
        raise ProgrammingError("This is an unexpected error!")
    except ProgrammingError:
        pass # Expected error
    try:
        raise ProgrammingError("This is an unexpected error!")
    except Exception:
        pass # Expected error
    try:
        raise ProgrammingError("This is an unexpected error!")
    except ValueError:
        pass # Expected error

# Generated at 2022-06-21 20:14:04.252855
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError must be raiseable.")


# Generated at 2022-06-21 20:14:06.907568
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something went wrong")
    except ProgrammingError as e:
        assert str(e) == "Something went wrong"


# Generated at 2022-06-21 20:14:10.798375
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Programming error occurred.")
    except ProgrammingError:
        assert True
    else:
        raise RuntimeError("Test failed.")


# Generated at 2022-06-21 20:14:14.677176
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("this")
    except ProgrammingError as e:
        assert str(e) == "this"
    try:
        raise ProgrammingError("that")
    except ProgrammingError as e:
        assert str(e) == "that"


# Generated at 2022-06-21 20:14:16.680336
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hey there")
    except ProgrammingError as error:
        assert str(error) == "Hey there"



# Generated at 2022-06-21 20:14:29.803992
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test error."):
        pass
    ProgrammingError.passert(False, "Test error.")

# Generated at 2022-06-21 20:14:31.983866
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        assert True


# Generated at 2022-06-21 20:14:33.794470
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "")
    ProgrammingError.passert(False, "")

# Generated at 2022-06-21 20:14:38.024012
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    try:
        ProgrammingError.passert(False, "Because there was an error")
    except ProgrammingError as e:
        assert e.args[0] == "Because there was an error"
    else:
        raise AssertionError("Programming error was not raised")



# Generated at 2022-06-21 20:14:48.151247
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of class :py:class:`ProgrammingError`.
    """

    # This should not fail
    ProgrammingError.passert(False, "foo")

    # This should fail, since it breaks the contract
    try:
        ProgrammingError.passert(True, "foo")
        raise Exception("This should fail, since it breaks the contract")
    except ProgrammingError:
        # expected
        pass

    # This should fail, since it breaks the contract
    try:
        ProgrammingError.passert(True, None)
        raise Exception("This should fail, since it breaks the contract")
    except ProgrammingError:
        # expected
        pass

# Generated at 2022-06-21 20:14:49.946556
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(condition=False, message="Programming error while testing"):
        pass

# Generated at 2022-06-21 20:14:53.336915
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message=None)
        assert False, "Expected an exception"
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:15:02.636936
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        assert False, "ProgrammingError.passert did raise an exception while it shouldn't"

    try:
        ProgrammingError.passert(False, "")
        assert False, "ProgrammingError.passert did not raise an exception while it should"
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(False, "My message")
        assert False, "ProgrammingError.passert did not raise an exception while it should"
    except ProgrammingError as error:
        assert error.args[0] == "My message", "ProgrammingError.passert returned the wrong exception message"

# Generated at 2022-06-21 20:15:06.712249
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This exception is used for testing purposes.")
    except ProgrammingError as exception:
        assert isinstance(exception, ProgrammingError)
        assert str(exception) == "This exception is used for testing purposes."


# Generated at 2022-06-21 20:15:11.564045
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert e.args == ("Test message",)

# Generated at 2022-06-21 20:15:39.711063
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:func:`ProgrammingError`.

    This test is based on a statement covering all the possible uses of the exception.
    """
    try:
        ProgrammingError(None)
    except ProgrammingError:
        pass
    else:
        assert False
    try:
        ProgrammingError("foo")
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-21 20:15:42.581401
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a message")
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-21 20:15:44.891067
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError()
    assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:15:47.177234
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try: raise ProgrammingError("Message")
    except ProgrammingError: pass
    try: raise ProgrammingError()
    except ProgrammingError: pass


# Generated at 2022-06-21 20:15:48.856465
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-21 20:15:52.284344
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("message")
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert "message" == str(e)


# Generated at 2022-06-21 20:15:54.242597
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-21 20:15:57.012996
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as error:
        raise ProgrammingError("Something is wrong.")
    assert error.value.args[0] == "Something is wrong."


# Generated at 2022-06-21 20:16:01.004901
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:16:03.444360
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Trying to instantiate it.
        ProgrammingError()
    except ProgrammingError as error:
        assert isinstance(error, ProgrammingError)
        return



# Generated at 2022-06-21 20:16:53.709444
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Just to exercise the constructor
    ProgrammingError()

    # Exercise the constructor with a message
    ProgrammingError("Testing")



# Generated at 2022-06-21 20:16:56.310697
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    error = ProgrammingError("error message")
    assert str(error) == "error message"



# Generated at 2022-06-21 20:17:00.822723
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error!")
    except ProgrammingError as e:
        assert str(e) == "Programming error!"
        assert type(e) is ProgrammingError

# Unit tests for ProgrammingError.passert method.

# Generated at 2022-06-21 20:17:03.896984
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something went horribly wrong.")
    except ProgrammingError as error:
        assert str(error) == "Something went horribly wrong."


# Generated at 2022-06-21 20:17:06.695571
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    correct = True
    try:
        ProgrammingError.passert(False, "Some message")
        correct = False
    except ProgrammingError:
        pass
    error = "The exception was not raised"
    assert correct, error

# Generated at 2022-06-21 20:17:17.194860
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of :py:class:`ProgrammingError` class.

    :return: ``None``
    """
    try:
        ProgrammingError.passert(False, "Expectation is not met")
    except ProgrammingError as ex:
        if str(ex) != "Expectation is not met":
            raise AssertionError("Failed testing ProgrammingError with custom message")

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as ex:
        if str(ex) != "Broken coherence. Check your code against domain logic to fix it.":
            raise AssertionError("Failed testing ProgrammingError with default message")


# Generated at 2022-06-21 20:17:18.830689
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:17:23.144816
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "Expected an exception when constructing a ProgrammingError"


# Generated at 2022-06-21 20:17:27.436969
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from mock import patch

    with patch.object(ProgrammingError, "__init__", return_value=None) as mocked_init:
        ProgrammingError(message="Custom message")
        mocked_init.assert_called_once_with(message="Custom message")


# Generated at 2022-06-21 20:17:35.274486
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Performs a unit test for the :py:class:`ProgrammingError` class constructor.
    """
    # In case that the message is not provided, the constructor must raise an exception
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "This point must not be reached"
    # A message must be provided in the constructor
    try:
        raise ProgrammingError("This is a message")
    except ProgrammingError as e:
        assert e.args[0] == "This is a message"
    else:
        assert False, "This point must not be reached"


# Generated at 2022-06-21 20:19:40.460857
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an intentionally raised exception")
    except ProgrammingError as exc:
        assert str(exc) == "This is an intentionally raised exception"
    else:
        raise AssertionError("There should have been an exception thrown")


# Generated at 2022-06-21 20:19:42.595768
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-21 20:19:46.111057
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Boooo")
        assert False, "No exception thrown"
    except ProgrammingError as e:
        assert e.args[0] == "Boooo", "Error message is not properly set"



# Generated at 2022-06-21 20:19:49.225421
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test message.")
        assert False, "ProgrammingError.passert should raise an exception in this case."
    except ProgrammingError as err:
        assert str(err) == "This is a test message."

# Generated at 2022-06-21 20:19:54.996325
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise RuntimeError("Unexpected error")

# Unit tests for method passert of class ProgrammingError

# Generated at 2022-06-21 20:19:57.146702
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is my message!")
    except ProgrammingError as error:
        assert error.args == ("This is my message!",)


# Generated at 2022-06-21 20:19:59.694007
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the class :py:class:`ProgrammingError` for proper instantiation and exception handling.
    """
    ProgrammingError.passert(False, "message")

# Generated at 2022-06-21 20:20:03.964218
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    expected_message = "Test message"

    # Act
    try:
        raise ProgrammingError(expected_message)
    # Assert
    except ProgrammingError as e:
        assert isinstance(e, Exception)
        assert str(e) == expected_message


# Generated at 2022-06-21 20:20:05.387334
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("test")
    assert str(error) == "test"

# Generated at 2022-06-21 20:20:08.233953
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert "test" in str(e)
