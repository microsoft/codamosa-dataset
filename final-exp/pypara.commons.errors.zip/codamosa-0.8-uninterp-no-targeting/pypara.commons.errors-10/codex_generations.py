

# Generated at 2022-06-21 20:11:34.290644
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()  # to make sure that we can instantiate the class



# Generated at 2022-06-21 20:11:36.661293
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error.")
    except ProgrammingError as exception:
        assert exception.__class__ == ProgrammingError
        assert exception.args == ("This is a programming error.",)


# Generated at 2022-06-21 20:11:38.727295
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test message")
    except ProgrammingError as e:
        assert str(e) == "test message"
        assert repr(e) == "ProgrammingError(test message)"


# Generated at 2022-06-21 20:11:42.295552
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError()



# Generated at 2022-06-21 20:11:46.777818
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "This is a test")
        assert False, "Should raise a ProgrammingError"  # pragma: no cover
    except ProgrammingError:
        pass
    assert ProgrammingError.passert(True, "This is a test") is None

# Generated at 2022-06-21 20:11:49.633852
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("programming error")
    except ProgrammingError as error:
        assert str(error) == "programming error", "ProgrammingError must have proper message."

# Unit test routine for `ProgrammingError.passert`

# Generated at 2022-06-21 20:11:52.763984
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Failed")

# Generated at 2022-06-21 20:11:59.639747
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Default message in case that none is provided
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    # Custom message for error
    try:
        ProgrammingError.passert(False, "Something went wrong!")
    except ProgrammingError as e:
        assert str(e) == "Something went wrong!"

    # Condition is True, no error is expected
    ProgrammingError.passert(True, None)

# Generated at 2022-06-21 20:12:01.372178
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-21 20:12:07.412147
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "TEST_MESSAGE")
    except ProgrammingError as e:
        assert str(e) == "TEST_MESSAGE"
        assert e.__cause__ is None
        assert e.__context__ is None
    else:
        raise Exception("ProgrammingError not raised")


# Generated at 2022-06-21 20:12:13.157187
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert True
        assert "Broken coherence" in repr(e)
    try:
        raise ProgrammingError("Test case")
    except ProgrammingError as e:
        assert True
        assert "Test case" in repr(e)


# Generated at 2022-06-21 20:12:16.070493
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the class :py:class:`ProgrammingError`."""
    try:
        ProgrammingError("test")
    except Exception as ex:
        assert ex.args[0] == "test"

# Generated at 2022-06-21 20:12:21.144434
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.
    """
    from pytest import raises
    with raises(ProgrammingError) as error:
        raise ProgrammingError()
    assert error.value.args == ("",)
    with raises(ProgrammingError) as error:
        raise ProgrammingError("message")
    assert error.value.args == ("message",)


# Generated at 2022-06-21 20:12:24.992110
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error exception raised.")
    except ProgrammingError as err:
        assert str(err) == "Programming error exception raised."
        assert isinstance(err, Exception)


# Generated at 2022-06-21 20:12:28.426455
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:12:30.557422
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing.")
    except ProgrammingError as e:
        assert e.args == ("Testing.",)


# Generated at 2022-06-21 20:12:33.098170
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Something is wrong")



# Generated at 2022-06-21 20:12:35.708530
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Just a test")
    except ProgrammingError as e:
        assert e.args[0] == "Just a test"
    else:
        assert False

# Generated at 2022-06-21 20:12:38.212305
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    hit = False
    try:
        raise ProgrammingError("message")
    except ProgrammingError as e:
        assert e.args == ("message",)
        hit = True  # pragma: no cover
    assert hit


# Generated at 2022-06-21 20:12:39.445202
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("message")
    assert "message" == error.args[0]

# Generated at 2022-06-21 20:12:42.371851
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        _ = ProgrammingError("error 1")

# Generated at 2022-06-21 20:12:46.929319
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("With message")
    except ProgrammingError as err:
        assert err.__class__ == ProgrammingError
        assert err.__str__() == "With message"
        assert err.args == ("With message",)


# Generated at 2022-06-21 20:12:50.086457
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Hello, world!")
    except Exception as e:
        assert type(e) is ProgrammingError
        assert str(e) == "Hello, world!"


# Generated at 2022-06-21 20:12:51.097681
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Something went wrong")



# Generated at 2022-06-21 20:12:57.326732
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the :py:class:`ProgrammingError` class.
    """
    # Check for message only
    try:
        ProgrammingError(message = "Test message")
    except ProgrammingError as error:
        assert error.args[0] == "Test message"
    else:
        assert False


# Generated at 2022-06-21 20:13:00.652198
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an example for a programming error")
    except ProgrammingError as e:
        assert(str(e) == "This is an example for a programming error")


# Generated at 2022-06-21 20:13:03.127800
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert "Test" == str(e)
    else:
        assert False


# Generated at 2022-06-21 20:13:06.185730
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "hello")
    ProgrammingError.passert(True, "hello")

# Generated at 2022-06-21 20:13:10.259414
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Test message", "The message is wrong."

# Generated at 2022-06-21 20:13:12.888554
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # When
    try:
        raise ProgrammingError("Error")
    except ProgrammingError as e:
        # Then
        assert str(e) == "Error"


# Generated at 2022-06-21 20:13:18.097501
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test the constructor of class ProgrammingError."""
    try:
        # Call SUT
        ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence" in str(e)


# Generated at 2022-06-21 20:13:22.562947
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Test message.")
    assert ProgrammingError("Test message.").__str__() == "Test message."


# Generated at 2022-06-21 20:13:26.074621
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="test message")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
    else:
        assert False, "test_ProgrammingError()"

# Generated at 2022-06-21 20:13:29.516091
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    '''
    Tests the constructor of class ProgrammingError
    '''
    try:
        raise ProgrammingError()
    except ProgrammingError as exception:
        assert exception.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:13:31.732093
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as ex:
        assert str(ex) == "Error message"


# Generated at 2022-06-21 20:13:41.619448
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This error message is expected. Do not worry.")
        assert False, "The previous statement should have raised a ProgrammingError."
    except ProgrammingError as e:
        assert str(e) == "This error message is expected. Do not worry."
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)
    try:
        ProgrammingError()
        assert False, "The previous statement should have raised a ProgrammingError."
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)

# Generated at 2022-06-21 20:13:43.346084
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`~pypara.error.ProgrammingError` class.
    """
    ProgrammingError("")

# Generated at 2022-06-21 20:13:48.629550
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as e:
        assert isinstance(e.args[0], str)
    else:
        assert False, "Did not raise ProgrammingError."



# Generated at 2022-06-21 20:13:50.935590
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        assert False
    else:
        assert True


# Generated at 2022-06-21 20:13:51.408558
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert False

# Generated at 2022-06-21 20:13:56.476992
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Should not occur")
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:13:59.173492
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with assert_raises(ProgrammingError) as exception_info:
        ProgrammingError("Message")
    assert exception_info.value.args == ("Message",)


# Generated at 2022-06-21 20:14:00.237007
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test error")


# Generated at 2022-06-21 20:14:10.266330
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from nose.tools import assert_true, assert_false, assert_raises

    try:
        ProgrammingError()
    except Exception as exc:
        assert_true(isinstance(exc, ProgrammingError))

    try:
        ProgrammingError("Programming error.")
    except Exception as exc:
        assert_true(isinstance(exc, ProgrammingError))

    try:
        ProgrammingError.passert(False, None)
    except Exception as exc:
        assert_true(isinstance(exc, ProgrammingError))

    assert_raises(ProgrammingError, ProgrammingError.passert, False, "Boo-yeah!")
    ProgrammingError.passert(True, "Boo-yeah!")



# Generated at 2022-06-21 20:14:11.966651
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()



# Generated at 2022-06-21 20:14:14.374531
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("message")
    except ProgrammingError as exc:
        assert str(exc) == "message"


# Generated at 2022-06-21 20:14:18.343824
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): #pylint: disable=invalid-name
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "Fake. Error is expected.")
    except ProgrammingError as exc:
        assert exc.message == "Fake. Error is expected."


# Generated at 2022-06-21 20:14:23.915011
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    raised = False

    try:
        raise ProgrammingError()
    except ProgrammingError:
        raised = True

    assert raised, "Error definition is not working as expected."


# Generated at 2022-06-21 20:14:30.317675
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test for constructor of class ProgrammingError."""
    # Test the no-message case
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass # We expect this exception to be raised...
    else:
        assert False # ...so, this assertion should not be reached.

    # Test the message case
    try:
        ProgrammingError.passert(False, "some message")
    except ProgrammingError as error:
        assert str(error) == "some message"
    else:
        assert False # This assertion should not be reached.

# Generated at 2022-06-21 20:14:34.104432
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    error = ProgrammingError("Unit test.")
    assert error.args == ("Unit test.",)
    assert error.__cause__ == None
    assert error.__traceback__ == None


# Generated at 2022-06-21 20:14:39.031049
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is for testing purposes.")
    except ProgrammingError as e:
        assert e.args[0] == "This is for testing purposes."



# Generated at 2022-06-21 20:14:44.719402
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test that ensures that the constructor of class :py:class:`ProgrammingError` is correct.
    """
    import pytest

    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError()
    assert excinfo.value.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "Expected to find something")
    assert excinfo.value.args[0] == "Expected to find something"

    # This call should not raise an exception
    assert ProgrammingError.passert(True, None) is None


# Generated at 2022-06-21 20:14:46.621988
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    ProgrammingError constructor
    """
    assert bool(ProgrammingError("whatever"))


# Generated at 2022-06-21 20:14:49.245366
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("ERROR")
    except ProgrammingError as e:
        assert str(e) == "ERROR"


# Generated at 2022-06-21 20:14:54.438563
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """

    # Prepare
    msg = "foo"

    # Perform
    err = ProgrammingError(msg)

    # Check
    assert err.args[0] == msg


# Generated at 2022-06-21 20:14:58.431900
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.testing import assert_raises

    # Failure when the condition is False
    assert_raises(ProgrammingError, lambda: ProgrammingError.passert(False, None))

    # Success when the condition is True
    ProgrammingError.passert(True, None)

# Generated at 2022-06-21 20:14:59.930833
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    # GIVEN

    # WHEN
    ProgrammingError()



# Generated at 2022-06-21 20:15:00.417249
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    pass

# Generated at 2022-06-21 20:15:04.117595
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.errors import ProgrammingError

    with raises(ProgrammingError):
        raise ProgrammingError("The error message")



# Generated at 2022-06-21 20:15:07.708755
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)


# Generated at 2022-06-21 20:15:15.116742
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Checks that it is possible to instantiate a :py:class:`ProgrammingError` object
    """
    ProgrammingError("This is a programming error")

# Generated at 2022-06-21 20:15:18.891499
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:15:22.546972
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests if the constructor works as expected."""
    try:
        raise ProgrammingError("A test")
    except ProgrammingError as e:
        assert str(e) == "A test"
        return
    assert False, "Resources.ProgrammingError constructor not working as expected"


# Generated at 2022-06-21 20:15:25.475658
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()

    with pytest.raises(ProgrammingError):
        ProgrammingError(message="Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-21 20:15:27.482916
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("The sky is falling")
    except ProgrammingError as e:
        assert(e.args == ("The sky is falling",))

# Generated at 2022-06-21 20:15:31.005934
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
        assert False
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)
        assert str(e) == ""


# Generated at 2022-06-21 20:15:32.655391
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    a = ProgrammingError("msg")
    assert a.__str__() == "msg"



# Generated at 2022-06-21 20:15:38.251431
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError()

    with raises(ProgrammingError):
        ProgrammingError("Boom!")


# Generated at 2022-06-21 20:15:43.945612
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError) as e:
        ProgrammingError.passert(False, "Something is broken. Fix it!")
    assert e.value.args[0] == "Something is broken. Fix it!"

    # Test method assert
    try:
        ProgrammingError.passert(True, None)
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        fail("No exception should be raised")

# Generated at 2022-06-21 20:15:45.443743
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:16:00.917999
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("Whatever")

# Generated at 2022-06-21 20:16:03.031028
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyStatementEffect
    ProgrammingError("")
    # noinspection PyStatementEffect
    ProgrammingError("", "")

# Generated at 2022-06-21 20:16:05.787452
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error")
    except ProgrammingError as pe:
        assert "This is a programming error" in str(pe)


# Generated at 2022-06-21 20:16:09.496462
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase, main

    class TestProgrammingError(TestCase):
        def test_constructor(self):
            with self.assertRaises(ProgrammingError):
                raise ProgrammingError("This exception is raised as expected.")

    main()


# Generated at 2022-06-21 20:16:11.577411
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('hi')
    except ProgrammingError as e:
        assert e.args[0] == 'hi'



# Generated at 2022-06-21 20:16:14.270572
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-21 20:16:17.696238
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as pe:
        assert str(pe) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:16:20.461315
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "test"


# Generated at 2022-06-21 20:16:24.995776
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as err:
        assert str(err) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("No exception has been raised")

# Generated at 2022-06-21 20:16:29.756678
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Test passert
        ProgrammingError.passert(True, "test message")
    except ProgrammingError as e:
        assert False, f"ProgrammingError.passert raised an exception."
    try:
        # Test passert with invalid condition
        ProgrammingError.passert(False, "test message")
        assert False, f"ProgrammingError.passert did not raise an exception."
    except ProgrammingError as e:
        pass

# Generated at 2022-06-21 20:16:56.217191
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Oops!")
    except ProgrammingError as e:
        assert str(e) == "Oops!"
    else:
        raise AssertionError("ProgrammingError was not raised")


# Generated at 2022-06-21 20:17:01.108366
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)

    with pytest.raises(ProgrammingError, match=r'Broken coherence'):
        ProgrammingError.passert(False, 'Broken coherence')

# Generated at 2022-06-21 20:17:04.995231
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class Test(ProgrammingError):
        pass

    with pytest.raises_regex(ProgrammingError, 'Broken coherence. Check your code against domain logic to fix it.'):
        ProgrammingError.passert(False, None)

# Generated at 2022-06-21 20:17:07.158066
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    message = "test message"
    with ProgrammingError(message) as e:
        assert str(e) == message, "Wrong error message in ProgrammingError constructor."
        raise


# Generated at 2022-06-21 20:17:09.590289
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing.")
    except ProgrammingError as error:
        assert str(error) == "Testing."


# Generated at 2022-06-21 20:17:12.480919
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as error:
        assert error.args[0] == "Test"


# Generated at 2022-06-21 20:17:14.022347
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:17:17.266886
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Broken coherence")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence"
    ProgrammingError.passert(condition=True, message="Broken coherence")

# Generated at 2022-06-21 20:17:21.301711
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as error_info:
        ProgrammingError.passert(condition=False, message="Test")
    assert error_info.value.args[0] == "Test"
    assert str(error_info.value) == "Test"

# Generated at 2022-06-21 20:17:23.047208
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("test"):
        raise ProgrammingError("test")
    try:
        raise ProgrammingError("test")
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:18:31.585898
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "Invalid state of the object")
        raise AssertionError("Should have raised the exception")
    except ProgrammingError as ex:
        assert ex.args[0] == "Invalid state of the object"

# Generated at 2022-06-21 20:18:34.543854
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=unused-variable
    ProgrammingError()
    ProgrammingError("custom error message")
    # pylint: enable=unused-variable

# Generated at 2022-06-21 20:18:39.867501
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    passert = ProgrammingError.passert
    # The following line should be free of errors
    passert(True, None)
    # The following line should raise a ProgrammingError
    try:
        passert(False, None)
    except ProgrammingError:
        return
    raise Exception("ProgrammingError not raised!")

# Generated at 2022-06-21 20:18:43.376856
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is a programming error.")
    ProgrammingError.passert(False, "A programming error was raised.")
    try:
        ProgrammingError.passert(False, "Another programming error was raised.")
        assert False, "This assertion should fail"
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:18:46.117851
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something is wrong because of...")
    except ProgrammingError as err:
        assert str(err) == "Something is wrong because of..."



# Generated at 2022-06-21 20:18:50.802523
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the constructor of :py:class:`ProgrammingError` behaves properly.
    """

    # The following line raises a syntax error due to the missing opening parenthesis.
    # ProgrammingError()

    # The following line works.
    ProgrammingError("")

    # The following line works and raises a :py:class:`ProgrammingError` instance.
    try:
        ProgrammingError.passert(False, "")
        assert False, "The programming error has not been raised."
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:18:52.975601
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as ex:
        assert str(ex) == "This is a test"


# Generated at 2022-06-21 20:18:55.128162
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests creation of a ProgrammingError."""
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass



# Generated at 2022-06-21 20:18:58.038436
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an example")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "This is an example"


# Generated at 2022-06-21 20:19:01.289330
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the constructor of class :py:class:`ProgrammingError` works as expected.
    """
    _ = ProgrammingError()
    _ = ProgrammingError("SOME ERROR MESSAGE")



# Generated at 2022-06-21 20:21:05.055848
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    message = "Expected this error message"
    try:
        raise ProgrammingError(message)
    except Exception as e:
        assert message in str(e)



# Generated at 2022-06-21 20:21:06.821113
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    ProgrammingError("Some error")


# Generated at 2022-06-21 20:21:09.475565
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as error:
        ProgrammingError.passert(False, "This is an error")
    assert str(error.value) == "This is an error"

# Generated at 2022-06-21 20:21:10.590136
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyTypeChecker
    ProgrammingError(condition=False, message="test")

# Generated at 2022-06-21 20:21:12.375859
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Expect the constructor of class ProgrammingError to raise when called
    assertRaises(ProgrammingError, ProgrammingError)


# Generated at 2022-06-21 20:21:16.765682
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from hypothesis import given
    from tests.strategies import valid_messages

    @given(valid_messages)
    def test_ProgrammingError_constructor(message: str) -> None:
        #
        actual_Programming_error = ProgrammingError(message=message)
        assert actual_Programming_error.args[0] == message
    test_ProgrammingError_constructor()


# Generated at 2022-06-21 20:21:20.032561
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""

    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        raise AssertionError(f"Unexpected exception: {e}")

# Generated at 2022-06-21 20:21:25.885000
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Everything is fine.")
    except:
        assert False, "Condition is met but an exception was raised."

    try:
        ProgrammingError.passert(False, "Everything is fine.")
        assert False, "Condition is not met but no exception was raised."
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:21:27.538544
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """

    try:
        raise ProgrammingError("Hello world!")
    except ProgrammingError as e:
        assert str(e) == "Hello world!"

# Generated at 2022-06-21 20:21:30.793392
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test message.")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test message."
    else:
        assert False
