

# Generated at 2022-06-21 20:11:35.878812
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("My Custom Message")


# Generated at 2022-06-21 20:11:38.611749
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert True
    else:
        assert False
    try:
        ProgrammingError("foo")
    except ProgrammingError as e:
        assert True
    else:
        assert False


# Generated at 2022-06-21 20:11:42.660660
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for the constructor of class ProgrammingError."""
    assert isinstance(ProgrammingError(), ProgrammingError)


# Generated at 2022-06-21 20:11:45.260026
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from .programming_error import ProgrammingError
    with raises(ProgrammingError):
        raise ProgrammingError("Error")


# Generated at 2022-06-21 20:11:47.903195
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert e.__class__ == ProgrammingError
        assert e.args[0] == "Test message"


# Generated at 2022-06-21 20:11:51.461868
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as err:
        assert str(err) == "Broken coherence. Check your code against domain logic to fix it."
        return

    assert False


# Generated at 2022-06-21 20:11:53.701271
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('error here')
    except ProgrammingError as e:
        assert e.args[0] == 'error here'


# Generated at 2022-06-21 20:11:56.323486
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
        assert False
    except ProgrammingError as err:
        assert str(err) == "test"


# Generated at 2022-06-21 20:12:05.671635
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from typing import Callable
    from pytest import raises

    # Invokes ProgrammingError.passert
    def assert_method(condition: bool, message: Optional[str]) -> Callable[[], None]:
        def _assert() -> None:
            ProgrammingError.passert(condition, message)
        return _assert

    # When condition is True, then no ProgrammingError is raised
    method = assert_method(True, None)
    method()
    method = assert_method(True, "")
    method()
    method = assert_method(True, "message")
    method()

    # When condition is False, then a ProgrammingError is raised
    method = assert_method(False, None)
    with raises(ProgrammingError) as exc_info:
        method()

# Generated at 2022-06-21 20:12:10.621414
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`~pypara.error.ProgrammingError`.

    :raises AssertionError: In case an assertion has failed.
    """
    progerror = ProgrammingError("test message")
    assert progerror.args == ("test message",)


# Generated at 2022-06-21 20:12:14.136086
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError()



# Generated at 2022-06-21 20:12:18.955164
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the constructor of :py:class:`ProgrammingError` works as expected.
    """

    try:
        ProgrammingError("Is not None.")
        raise AssertionError("Raise condition failed.")
    except ProgrammingError:
        pass

    try:
        ProgrammingError()
        raise AssertionError("Raise condition failed.")
    except ProgrammingError:
        pass



# Generated at 2022-06-21 20:12:22.794230
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e1 = ProgrammingError()
    assert e1.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    e2 = ProgrammingError("Bad programmer!")
    assert e2.args == ("Bad programmer!",)



# Generated at 2022-06-21 20:12:26.823784
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Hello")
    except ProgrammingError as e:
        assert "Hello" == e.args[0]
    else:
        assert False, "Programming error exception not raised"


# Generated at 2022-06-21 20:12:31.277590
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as e:
        assert "This is an error" in str(e)
        assert e.args[0] == "This is an error"
        assert e.args == ("This is an error",)


# Generated at 2022-06-21 20:12:34.141620
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "should not be raised")
    caught = False
    try:
        ProgrammingError.passert(False, "should be raised")
    except ProgrammingError:
        caught = True
    assert caught


# Generated at 2022-06-21 20:12:35.510307
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyStatementEffect
    ProgrammingError()


# Generated at 2022-06-21 20:12:38.499697
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something's broken")
    except ProgrammingError as e:
        assert e.args[0] == "Something's broken"



# Generated at 2022-06-21 20:12:42.371775
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.core import _core as core

    try:
        core.ProgrammingError()
    except Exception as ex:
        assert type(ex) is core.ProgrammingError


# Generated at 2022-06-21 20:12:46.502872
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Should fail always")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:12:49.637888
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the base functionality of class :py:class:`ProgrammingError`.
    """
    ProgrammingError()

# Generated at 2022-06-21 20:12:51.753383
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        return
    assert False # We should always land here


# Generated at 2022-06-21 20:13:01.455519
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if the constructor of :py:class:`ProgrammingError` raises the error with a default message when no message
    is provided. It also verifies that no exception is raised when calling
    :py:meth:`ProgrammingError.passert <pypara.core.errors.ProgrammingError.passert>` with a condition which is
    ``True``.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert ex.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    ProgrammingError.passert(True, None)

# Generated at 2022-06-21 20:13:03.813819
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError( "MESSAGE" )
    except Exception:
        assert False, "ProgrammingError instance raising exception in constructor"



# Generated at 2022-06-21 20:13:06.272614
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    assert str(ProgrammingError("Message")) == "Message"

# Generated at 2022-06-21 20:13:09.913741
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if the constructor of :py:class:`ProgrammingError` works as expected.
    """
    ProgrammingError(message="error message")


# Generated at 2022-06-21 20:13:12.402553
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError()

    with raises(ProgrammingError, match="Message"):
        ProgrammingError("Message")


# Generated at 2022-06-21 20:13:21.584004
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """This test asserts that we really need the update_docstring decorator"""
    from pypara.utils import UpdateDocstring

    def test_decorator(func):
        def wrapper(*args, **kwargs):
            # We don't actually want to update the docstring.
            return func(*args, **kwargs)

        return UpdateDocstring(func)(wrapper)

    @test_decorator
    def f(x):
        """
        :param x: this parameter has a docstring
        """

    assert ProgrammingError.passert(x=1)

# Generated at 2022-06-21 20:13:22.876067
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "")

# Generated at 2022-06-21 20:13:25.616663
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This should be raised.")
        assert False, "This should not be reached."
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:13:29.970115
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test assertion")
        assert False
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)
        assert err.args == ("Test assertion",)


# Generated at 2022-06-21 20:13:32.116252
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test.")
        assert False
    except ProgrammingError:
        assert True

# Generated at 2022-06-21 20:13:42.230499
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    passert = ProgrammingError.passert

    def wrap(func):
        def wrapper():
            try:
                func()
            except ProgrammingError as e:
                assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
                return
            assert False
        return wrapper

    @wrap
    def nomessage():
        passert(condition=False, message=None)

    @wrap
    def message():
        passert(condition=False, message="This is a message")

    @wrap
    def nonotmessage():
        passert(condition=True, message="This is a message")

    @wrap
    def nonotnomessage():
        passert(condition=True, message=None)

# Generated at 2022-06-21 20:13:46.363599
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error.")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert "This is a programming error." in str(e)


# Generated at 2022-06-21 20:13:49.388171
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("error message")
    except ProgrammingError as e:
        assert str(e) == "error message"


# Generated at 2022-06-21 20:13:52.828481
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test constructor of class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "The error message")
        assert False, "Code must never reach here."
    except ProgrammingError as err:
        assert str(err) == "The error message"



# Generated at 2022-06-21 20:13:58.850540
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    # Test constructor
    with pytest.raises(ProgrammingError) as _:
        raise ProgrammingError("Error!")

    # Test syntactic sugar
    with pytest.raises(ProgrammingError) as _:
        ProgrammingError.passert(False, "Error!")

# Generated at 2022-06-21 20:13:59.996511
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("test")

test_ProgrammingError()

# Generated at 2022-06-21 20:14:03.073486
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as err:
        assert isinstance(err, ProgrammingError)
    else:
        assert False, "ProgrammingError should have raised an exception"


# Generated at 2022-06-21 20:14:05.968022
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:14:10.607017
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError()
    err = ProgrammingError("My custom error")
    assert err.args[0] == "My custom error"

# Generated at 2022-06-21 20:14:13.798546
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Unit tests for ProgrammingError.passert

# Generated at 2022-06-21 20:14:18.150022
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")
        assert False
    except ProgrammingError as e:
        assert e.message == "Test message"

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert e.message == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-21 20:14:23.753291
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == e._message


# Generated at 2022-06-21 20:14:25.515813
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("this is an error")
    except ProgrammingError as e:
        assert e

# Generated at 2022-06-21 20:14:28.339510
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Just a test")
    except ProgrammingError as e:
        assert str(e) == "Just a test"


# Generated at 2022-06-21 20:14:33.177654
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # --Given
    condition = True
    message = None
    # --When
    try:
        ProgrammingError.passert(condition, message)
    except ProgrammingError:
        assert False
    # --Then



# Generated at 2022-06-21 20:14:36.085391
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("I am an error which should not happen.")
    except ProgrammingError as e:
        assert e.args[0] == "I am an error which should not happen."


# Generated at 2022-06-21 20:14:38.494994
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("hello!")
    except ProgrammingError as e:
        assert e.args[0] == "hello!"
    else:
        assert False

# Generated at 2022-06-21 20:14:44.339467
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of :py:class:`ProgrammingError`
    """
    # Build-up
    expected_message = "Message"
    # Exercise
    try:
        raise ProgrammingError(expected_message)
    except Exception as e:
        assert str(e) == expected_message


# Generated at 2022-06-21 20:14:59.286718
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from unittest.mock import ANY
    with raises(ProgrammingError) as e:
        ProgrammingError()
    assert e.value.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    with raises(ProgrammingError) as e:
        ProgrammingError("This is an error message.")
    assert e.value.args[0] == "This is an error message."
    with raises(ProgrammingError) as e:
        ProgrammingError.passert(False, "This is an error message.")
    assert e.value.args[0] == "This is an error message."
    assert ProgrammingError.passert(True, "This is an error message.") is None
    with raises(ProgrammingError) as e:
        ProgrammingError.passert(False, "")

# Generated at 2022-06-21 20:15:03.636069
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        try:
            ProgrammingError.passert(False, "I'm not satisfied")
        except ProgrammingError as error:
            assert error.args[0] == "I'm not satisfied"
            raise RuntimeError
        assert False
    except RuntimeError:
        assert True

# Generated at 2022-06-21 20:15:06.186509
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except Exception as exception:
        assert isinstance(exception, ProgrammingError)

# Generated at 2022-06-21 20:15:08.642948
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Hello world")

# Generated at 2022-06-21 20:15:11.257809
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A non-trivial message")
    except ProgrammingError as e:
        assert str(e) == "A non-trivial message"

# Generated at 2022-06-21 20:15:12.659174
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Programming error message."):
        pass



# Generated at 2022-06-21 20:15:15.172582
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:15:17.609095
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with test.raises(ProgrammingError):
        ProgrammingError.passert(False, "The programmer broke something")

# Generated at 2022-06-21 20:15:21.253988
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of class ProgrammingError."""
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as exception:
        assert exception.args == ("Error message",)


# Generated at 2022-06-21 20:15:23.239484
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()

    except ProgrammingError as ex:
        assert True, "The constructor of ProgrammingError raises exceptions as expected."



# Generated at 2022-06-21 20:15:31.007576
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(None)
    except ProgrammingError as e:
        assert e.args[0] is None

# Generated at 2022-06-21 20:15:34.644263
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(None)
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("This is a programming error.")
    except ProgrammingError:
        pass # Expected


# Generated at 2022-06-21 20:15:38.694986
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Raises a :py:class:`ProgrammingError` when the condition is not met.
    """
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Broken coherence.")

# Generated at 2022-06-21 20:15:40.133542
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="Useful message")


# Generated at 2022-06-21 20:15:43.440305
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as prgr:
        assert prgr.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:15:47.423656
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class MyProgrammingError(ProgrammingError):
        """
        Sample exception for test.
        """

    try:
        raise MyProgrammingError('sample error')
    except MyProgrammingError as e:
        assert str(e) == 'sample error'


# Generated at 2022-06-21 20:15:54.121469
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "ProgrammingError should be raised."

# Generated at 2022-06-21 20:15:56.499126
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as error:
        assert error.args[0] == "Error message"



# Generated at 2022-06-21 20:15:58.650421
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError()
    assert e.args == ('Broken coherence. Check your code against domain logic to fix it.',)


# Generated at 2022-06-21 20:16:01.425130
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "test1") as e:
        pass
    ProgrammingError.passert(False, None)

# Generated at 2022-06-21 20:16:18.863300
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError(None)

    exc_message = str(excinfo.value)
    assert "Broken coherence" in exc_message

# Generated at 2022-06-21 20:16:20.513509
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="This is a message.")

# Generated at 2022-06-21 20:16:22.393019
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("This is a programming error").args[0] == "This is a programming error"


# Generated at 2022-06-21 20:16:25.247398
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing")
    except Exception as e:
        assert str(e) == "Testing"


# Generated at 2022-06-21 20:16:26.808207
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Test error message")

# Generated at 2022-06-21 20:16:29.787936
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test Error")
    except ProgrammingError as exception:
        assert isinstance(exception, ProgrammingError)
        assert str(exception) == "Test Error"
    else:
        raise AssertionError("ProgrammingError constructor did not raise a ProgrammingError exception")


# Generated at 2022-06-21 20:16:31.117974
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, 'Some related message'):
        pass

# Generated at 2022-06-21 20:16:33.884665
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError()
    assert issubclass(ProgrammingError, Exception)
    assert issubclass(ProgrammingError, e.__class__)
    assert isinstance(e, ProgrammingError)
    assert isinstance(e, Exception)


# Generated at 2022-06-21 20:16:36.150219
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("some error")
    except Exception as err:
        assert isinstance(err, ProgrammingError)
        assert "some error" in str(err)


# Generated at 2022-06-21 20:16:37.620376
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert(isinstance(e, ProgrammingError))


# Generated at 2022-06-21 20:17:02.720476
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(condition=True, message=None)
    ProgrammingError.passert(condition=True, message="N/A")
    try:
        ProgrammingError.passert(condition=False, message=None)
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:17:06.660379
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test constructor of class ProgrammingError."""
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:17:10.125203
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming is not working")
    except ProgrammingError as error:
        assert str(error) == "Programming is not working"

# Unit test ProgrammingError.passert

# Generated at 2022-06-21 20:17:12.920073
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert "Test" in str(e)


# Generated at 2022-06-21 20:17:15.117711
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Tests the constructor of the ProgrammingError class. """
    p = ProgrammingError("Test message")
    assert p.args[0] == "Test message"


# Generated at 2022-06-21 20:17:18.549692
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError
    """
    with pytest.raises(ProgrammingError):
        ProgrammingError()
    with pytest.raises(ProgrammingError, match=r'An error has been produced.'):
        raise ProgrammingError('An error has been produced.')


# Generated at 2022-06-21 20:17:20.319601
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Message")
    except ProgrammingError as e:
        assert e.args[0] == "Message"


# Generated at 2022-06-21 20:17:24.075160
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Message")
    except ProgrammingError as e:
        assert e.args[0] == "Message"
    else:
        assert False, "Must raise error"


# Generated at 2022-06-21 20:17:27.196005
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Ouch!")
    except ProgrammingError as error:
        assert error.args[0] == "Ouch!"


# Generated at 2022-06-21 20:17:29.008424
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert e.args[0] == "Error message"

# Generated at 2022-06-21 20:18:36.618353
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as e:
        assert "A message" in str(e)
        assert "A message" == e.args[0]
        return
    assert False

# Generated at 2022-06-21 20:18:40.857228
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

    try:
        raise ProgrammingError('this is an error')
    except ProgrammingError as e:
        assert e.args == ('this is an error',)



# Generated at 2022-06-21 20:18:44.479340
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    error = ProgrammingError("You can tell all your friends that I'm back in town.")
    assert str(error) == "You can tell all your friends that I'm back in town."


# Generated at 2022-06-21 20:18:45.464325
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="A")


# Generated at 2022-06-21 20:18:46.620146
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        pass

# Generated at 2022-06-21 20:18:48.129317
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Check your code!")
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:18:51.320132
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError` with the default message.
    """
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert(str(e) == "Broken coherence. Check your code against domain logic to fix it.")
    assert(True)


# Generated at 2022-06-21 20:18:53.191769
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    testee = ProgrammingError
    msg = "msg"

    # Act / Assert
    testee(msg)


# Generated at 2022-06-21 20:18:55.012561
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:18:57.932380
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert type(e) is ProgrammingError
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:20:57.530936
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-21 20:21:00.138289
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test exception")
    except ProgrammingError as msg:
        assert msg.__str__() == "Test exception"


# Generated at 2022-06-21 20:21:01.455298
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "No error")



# Generated at 2022-06-21 20:21:03.706466
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError() could not be raised.")


# Generated at 2022-06-21 20:21:06.701481
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.
    """
    from pytest import raises

    with raises(ProgrammingError):
        # Should raise an exception
        ProgrammingError("This is an error!")

# Generated at 2022-06-21 20:21:07.695564
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is a Programming Error.")

# Generated at 2022-06-21 20:21:09.510593
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing")
    except ProgrammingError as e:
        assert str(e) == "Testing"


# Generated at 2022-06-21 20:21:11.411267
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-21 20:21:13.705013
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
        assert False, "An exception was expected"
    except Exception as ex:
        assert isinstance(ex, ProgrammingError)
        assert str(ex) == "test"

# Generated at 2022-06-21 20:21:16.137226
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "The condition has been not met.")
        assert False, "ProgrammingError has not been raised"
    except ProgrammingError:
        pass
