

# Generated at 2022-06-21 20:11:31.402266
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "Test message")


# Generated at 2022-06-21 20:11:34.372353
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        assert True
    # end try
# end def

# Generated at 2022-06-21 20:11:37.062898
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as exception:
        assert exception.args[0] == "Test message"
    else:
        raise AssertionError("ProgrammingError constructor test failed")



# Generated at 2022-06-21 20:11:39.235931
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "It does not work")
        raise ValueError("Should have raised a ProgrammingError")
    except ProgrammingError as e:
        assert "It does not work" in str(e)



# Generated at 2022-06-21 20:11:43.143458
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError) as context:
        raise ProgrammingError("test message")
    assert "test message" in context.exconly()


# Generated at 2022-06-21 20:11:45.401096
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"


# Generated at 2022-06-21 20:11:47.022059
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:11:48.737415
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, None):
        pass

    with ProgrammingError.passert(False, None):
        pass

# Generated at 2022-06-21 20:11:52.012439
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert type(e) is ProgrammingError
        assert str(e) == "Test"


# Generated at 2022-06-21 20:11:53.243339
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)


# Generated at 2022-06-21 20:11:57.006924
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except:
        assert False


# Generated at 2022-06-21 20:12:00.391584
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # No error
        ProgrammingError.passert(True, "Testing error")

        # Error
        ProgrammingError.passert(False, "Testing error")
    except ProgrammingError as e:
        assert str(e) == "Testing error"


# Generated at 2022-06-21 20:12:06.570508
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert e.args == ('',)
    
    try:
        raise ProgrammingError("")
    except ProgrammingError as e:
        assert e.args == ('',)
    
    try:
        raise ProgrammingError("A message!")
    except ProgrammingError as e:
        assert e.args == ('A message!',)


# Generated at 2022-06-21 20:12:10.242376
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc = ProgrammingError()
    assert isinstance(exc, Exception)
    assert exc.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    assert str(exc) == exc.args[0]


# Generated at 2022-06-21 20:12:14.136550
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "An error")
        assert False
    except Exception as ex:
        assert isinstance(ex, ProgrammingError)
        assert ex.args[0] == "An error"


# Generated at 2022-06-21 20:12:15.073141
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "Testing ProgrammingError")

# Generated at 2022-06-21 20:12:17.656577
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("A custom message goes here.")
    except ProgrammingError:
        pass



# Generated at 2022-06-21 20:12:20.463874
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('test')
    except ProgrammingError as e:
        assert str(e) == 'test'


# Generated at 2022-06-21 20:12:22.373785
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Failed")

# Generated at 2022-06-21 20:12:32.821341
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # it should pass when the condition is true
    err = None
    try:
        ProgrammingError.passert(True, None)
    except Exception as e:
        err = e
    assert err is None

    # it should fail when the condition is false
    err = None
    try:
        ProgrammingError.passert(False, None)
    except Exception as e:
        err = e
    assert isinstance(err, ProgrammingError)

    # it should fail when the condition is false and message is not None
    err = None
    try:
        ProgrammingError.passert(False, 'Some message')
    except Exception as e:
        err = e
    assert isinstance(err, ProgrammingError) and str(err) == 'Some message'

# Generated at 2022-06-21 20:12:38.668879
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN

    # WHEN
    err = ProgrammingError("test")

    # THEN
    assert len(err.args) == 1
    assert err.args[0] == "test"



# Generated at 2022-06-21 20:12:42.161867
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("message").args == ("message",)
    assert ProgrammingError("message",).args == ("message",)
    assert ProgrammingError().args == ()


# Generated at 2022-06-21 20:12:54.084984
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Unit test A: Check that an exception is raised when the ``passert`` method is invoked
    def inner_unit_test_A():
        ProgrammingError.passert(False, "Test message")
    # Unit test A: Execution part
    try:
        inner_unit_test_A()
    except ProgrammingError as e:
        assert str(e) == "Test message"
    # Unit test B: Check that an exception is raised when the ``passert`` method is invoked and no message is provided
    def inner_unit_test_B():
        ProgrammingError.passert(False, None)
    # Unit test B: Execution part
    try:
        inner_unit_test_B()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    # Unit test

# Generated at 2022-06-21 20:12:57.022303
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:12:59.551513
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for the constructor of class :py:class:`ProgrammingError`.
    """
    assert True



# Generated at 2022-06-21 20:13:00.932348
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Custom message"):
        pass


# Generated at 2022-06-21 20:13:04.061332
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == e.args[0]
    except:
        assert False

# Generated at 2022-06-21 20:13:07.728291
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)
    try:
        ProgrammingError.passert(False, "Message")
    except ProgrammingError as e:
        assert e.args == ("Message",)
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "")

# Generated at 2022-06-21 20:13:11.693897
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is the message of the error")
        assert False, "This line should not be executed, an exception should be raised"
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert "This is the message of the error" == str(e)

    assert ProgrammingError.passert(True, "This is the message of the error") is None

# Generated at 2022-06-21 20:13:13.484764
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert False
    except TypeError:
        pass


# Generated at 2022-06-21 20:13:20.288807
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError as ex:
        pass

# Generated at 2022-06-21 20:13:28.212845
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an assertion message.")
    except ProgrammingError as e:
        if e.args[0] != "This is an assertion message.":
            raise Exception("Failed to create a new ProgrammingError object!")
    else:
        raise Exception("Failed to raise a ProgrammingError!")
    try:
        ProgrammingError.passert(True, "This is an assertion message.")
    except ProgrammingError:
        raise Exception("Failed to raise a ProgrammingError object!")


# Generated at 2022-06-21 20:13:30.948405
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:13:33.568852
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as error:
        assert error.args[0] == "This is a test."


# Generated at 2022-06-21 20:13:38.589786
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error occurred")
    except ProgrammingError as pe:
        assert isinstance(pe, Exception)
        assert isinstance(pe, ProgrammingError)
        assert pe.__str__() == "A programming error occurred"
    else:
        AssertionError("exception was not raised")


# Generated at 2022-06-21 20:13:42.579699
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError()
    assert isinstance(exception, ProgrammingError)
    assert isinstance(exception, Exception)
    assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:13:44.820832
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        raise ProgrammingError


# Generated at 2022-06-21 20:13:48.803802
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        print(type(e))

# test for constructor of class ProgrammingError
test_ProgrammingError()

# Generated at 2022-06-21 20:13:51.101400
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test call")
    except ProgrammingError as e:
        assert e.args[0] == "Test call"


# Generated at 2022-06-21 20:13:54.447364
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error!")
    except ProgrammingError as e:
        assert str(e) == "Error!"


# Generated at 2022-06-21 20:14:09.983258
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the exception.
    """
    try:
        raise ProgrammingError("test")
    except ProgrammingError as err:
        assert str(err) == "test"


# Generated at 2022-06-21 20:14:11.649894
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "This is a message for testing purposes.")

# Generated at 2022-06-21 20:14:14.461458
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Should not happen")
    except ProgrammingError as e:
        assert "Should not happen" in str(e)


# Generated at 2022-06-21 20:14:16.468489
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Hello World")
    except ProgrammingError as e:
        assert(str(e) == "Hello World")


# Generated at 2022-06-21 20:14:19.462515
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("an error for testing")
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "an error for testing"
        print("[info] %s" % (e))


# Generated at 2022-06-21 20:14:25.340753
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Basic test")

    ProgrammingError.passert(True, message="Should not be raised")
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, message="Should be raised")

# Generated at 2022-06-21 20:14:27.192355
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    assert isinstance(ProgrammingError(), ProgrammingError)


# Generated at 2022-06-21 20:14:31.342067
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    # GIVEN
    expected_message = "expected_message"
    # WHEN
    ProgrammingError(expected_message)



# Generated at 2022-06-21 20:14:34.807781
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Trying to satisfy the linter
    ProgrammingError("Some message")
    ProgrammingError.passert(True, "Some message")
    ProgrammingError.passert(False, "Some message")



# Generated at 2022-06-21 20:14:38.951372
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if the constructor of the class :py:class:`ProgrammingError` works as expected.
    """
    try:
        ProgrammingError("foo")
    except Exception as e:
        assert isinstance(e, ProgrammingError)
    else:
        raise AssertionError("Should have raised a ProgrammingError")


# Generated at 2022-06-21 20:15:00.415270
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError, match=r".*Check your code against domain logic to fix it.*"):
        ProgrammingError()


# Generated at 2022-06-21 20:15:04.118334
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "asdfgh")
    except ProgrammingError as e:
        assert e.args[0] == "asdfgh"

# Generated at 2022-06-21 20:15:07.709009
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check if the constructor works as intended
    try:
        raise ProgrammingError()
    except ProgrammingError:
        # The expected exception has been raised
        pass


# Generated at 2022-06-21 20:15:12.317436
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError("Programming error detected.")
    except ProgrammingError as e:
        assert str(e) == "Programming error detected."

    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:15:14.805056
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as pe:
        assert pe.args[0] == "A message"



# Generated at 2022-06-21 20:15:17.030037
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    try:
        raise ProgrammingError("Test error")
    except ProgrammingError as e:
        assert type(e) == ProgrammingError
        assert str(e) == "Test error"

# Generated at 2022-06-21 20:15:21.298679
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        class TestError(ProgrammingError):
            pass
        try:
            TestError()
        except TypeError as e:
            pass
        else:
            assert False
    except Exception as e:
        assert False


# Generated at 2022-06-21 20:15:24.802741
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase

    class ProgrammingErrorTests(TestCase):
        def test_instantiation(self):
            self.assertRaises(ProgrammingError, lambda: ProgrammingError(None))

    import unittest
    unittest.main()

# Generated at 2022-06-21 20:15:26.853669
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc = ProgrammingError()
    assert exc.args == (
        "Broken coherence. Check your code against domain logic to fix it.",
    )

# Generated at 2022-06-21 20:15:31.814036
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "It raises a `ProgrammingError`")
    except ProgrammingError:
        pass
    except Exception as e:
        raise AssertionError(f"Incorrect exception raised: {e.__class__.__name__}")

# Generated at 2022-06-21 20:16:25.677484
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def f():
        ProgrammingError.passert(False, "Foo")
    def g():
        ProgrammingError.passert(True, "Bar")
    for fun in [f, g]:
        try:
            fun()
        except ProgrammingError as e:
            if fun == f:
                assert str(e) == "Foo"
            elif fun == g:
                assert str(e) == "Bar"
            else:
                assert False

# Generated at 2022-06-21 20:16:27.092025
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:16:31.773090
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("my message")
    except ProgrammingError as ex:
        try:
            assert ex.args[0] == "my message"
        except AssertionError:
            raise ex
    except Exception:
        raise AssertionError("Exception must have been raised and have the message.")



# Generated at 2022-06-21 20:16:33.958994
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass

    try:
        raise ProgrammingError("Custom message")
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:16:37.022777
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    exception = ProgrammingError()
    assert exception.args == tuple()

    exception = ProgrammingError("error message")
    assert exception.args == ("error message",)

    exception = ProgrammingError("error message", "another message")
    assert exception.args == ("error message", "another message")



# Generated at 2022-06-21 20:16:39.787052
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class DomainError(ProgrammingError): pass
    try:
        raise DomainError("Somethings gone wrong")
    except DomainError as e:
        assert str(e) == "Somethings gone wrong"


# Generated at 2022-06-21 20:16:46.107530
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Check that ProgrammingError is indeed an 'Exception'
    assert issubclass(ProgrammingError, Exception)
    assert issubclass(ProgrammingError, BaseException)
    assert issubclass(ProgrammingError, object)

    # Check that ProgrammingError.__init__ works correctly
    error = ProgrammingError("Test")
    assert error.message == "Test"

# Generated at 2022-06-21 20:16:50.215925
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it.", "Bad message"
    else:
        raise AssertionError("Expected ProgrammingError to be raised")


# Generated at 2022-06-21 20:16:55.081730
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    # A standard usage
    with raises(ProgrammingError):
        ProgrammingError()

    # A standard usage with a message
    with raises(ProgrammingError) as ex:
        ProgrammingError("An error message")
    assert(ex.value.args[0] == "An error message")


# Generated at 2022-06-21 20:16:55.999110
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="This is a programmer error")

# Generated at 2022-06-21 20:18:47.450237
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """

    try:
        raise ProgrammingError("Test")
    except ProgrammingError as error:
        assert str(error) == "Test"
        return

    assert 0, "Shouldn't have reached this point"


# Generated at 2022-06-21 20:18:48.655684
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError('test_message')

# Generated at 2022-06-21 20:18:49.745229
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-21 20:18:53.744892
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Testing with message
    try:
        raise ProgrammingError("Ouch!")
    except ProgrammingError as e:
        assert e.args == ("Ouch!",)
    # Testing without message
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-21 20:18:55.608569
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:18:58.543616
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A message")
    except Exception as e:
        assert str(e) == "A message"
        assert e.args == ("A message", )


# Generated at 2022-06-21 20:19:03.375346
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Hello")
    except ProgrammingError as err:
        assert err.args[0] == "Hello"
    try:
        ProgrammingError()
    except ProgrammingError as err:
        assert err.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:19:05.534454
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()

# Unit tests for method passert() of class ProgrammingError

# Generated at 2022-06-21 20:19:09.282574
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert hasattr(e, "message")
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise ValueError("ProgrammingError is not raised.")

# Generated at 2022-06-21 20:19:15.721878
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Message") as result:
        pass
    assert result is None
    try:
        with ProgrammingError.passert(False, "Message") as result:
            pass
        assert False
    except ProgrammingError as ex:
        assert isinstance(ex, ProgrammingError)
        assert str(ex) == "Message"
    try:
        with ProgrammingError.passert(False, None) as result:
            pass
        assert False
    except ProgrammingError as ex:
        assert isinstance(ex, ProgrammingError)
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."
    print("OK")


if __name__ == "__main__":
    test_ProgrammingError()