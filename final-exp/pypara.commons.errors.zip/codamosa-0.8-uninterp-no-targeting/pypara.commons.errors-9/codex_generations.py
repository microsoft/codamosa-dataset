

# Generated at 2022-06-21 20:11:36.293281
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Custom message")
    except ProgrammingError as e:
        assert e.args[0] == "Custom message"


# Generated at 2022-06-21 20:11:38.198629
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.guard import Guarded
    try:
        with Guarded(__name__):
            raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:11:43.053808
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "Error at initialization of a :py:class:`ProgrammingError`."
    e = ProgrammingError(msg)
    assert e.args[0] == msg


# Generated at 2022-06-21 20:11:48.629141
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=unused-import
    from io import StringIO
    from unittest.mock import patch

    with patch('sys.stderr', new=StringIO()) as stderr, patch('sys.stdout', new=StringIO()) as stdout:
        err = ProgrammingError("A dummy error to test.")
        print(err)
        assert stderr.getvalue() == ""
        assert stdout.getvalue() == "A dummy error to test.\n"

# Generated at 2022-06-21 20:11:51.598465
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert(e.__str__() == "Test")


# Generated at 2022-06-21 20:11:53.511982
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("message")
    except ProgrammingError as error:
        assert error.args[0] == "message"


# Generated at 2022-06-21 20:11:57.981611
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`
    """
    cls = ProgrammingError
    e = cls("My error message")
    assert isinstance(e, Exception)
    assert e.args[0] == "My error message"
    assert e.args[1:] == ()


# Generated at 2022-06-21 20:12:01.335951
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error_message = "This is my error message"
    try:
        ProgrammingError.passert(False, error_message)
    except ProgrammingError as e:
        assert str(e) == error_message
        return
    assert False, "Expected exception to be raised"


# Generated at 2022-06-21 20:12:03.233301
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    expected = "Expected text"

    error = ProgrammingError(expected)

    assert error.__str__() == expected

# Generated at 2022-06-21 20:12:09.062213
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Case 1
    try:
        ProgrammingError.passert(condition=False, message="Condition is False")
    except Exception as exc:
        assert type(exc) is ProgrammingError
        assert exc.args[0] == "Condition is False"

    # Case 2
    try:
        ProgrammingError.passert(condition=True, message="Condition is True")
    except Exception as exc:
        assert exc is None

# Generated at 2022-06-21 20:12:16.805969
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    cls = ProgrammingError
    for c, m in (True, None), (False, "some message"):
        try:
            cls(message=m)
            if not c:
                assert False, "Expected ProgrammingError to be raised."
        except ProgrammingError as e:
            if c:
                assert False, "Did not expect {} to be raised.".format(e)
            assert e.args[0] == m, "Unexpected message: {}".format(e.args[0])

# Generated at 2022-06-21 20:12:19.138113
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something has gone wrong.")
    except ProgrammingError as e:
        assert e.args[0] == "Something has gone wrong."



# Generated at 2022-06-21 20:12:21.626015
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # noinspection PyStatementEffect
        ProgrammingError("Test")
        assert False
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:12:26.010058
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the constructor of :py:class:`ProgrammingError` works as expected.
    """
    try:
        raise ProgrammingError("Foo.")
    except ProgrammingError as exception:
        assert str(exception) == "Foo."

# Generated at 2022-06-21 20:12:33.148918
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError()
        assert False, "Shouldn't reach here"
    except ProgrammingError:
        pass

    try:
        raise ProgrammingError("Test message")
        assert False, "Shouldn't reach here"
    except ProgrammingError as e:
        assert e.args[0] == "Test message", "Message '%s' does not match" % e.args[0]



# Generated at 2022-06-21 20:12:38.592879
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    programing_error = None  # type: Optional[ProgrammingError]

    # WHEN
    try:
        raise ProgrammingError("broken coherence")
    except ProgrammingError as err:
        programing_error = err

    # THEN
    assert type(programing_error) is type(ProgrammingError(""))
    assert "broken coherence" in str(programing_error)
    assert "Traceback" in str(programing_error)



# Generated at 2022-06-21 20:12:43.395758
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """

    try:
        raise ProgrammingError("Arbitrary error message")
    except ProgrammingError as e:
        assert str(e) == "Arbitrary error message"


# Generated at 2022-06-21 20:12:47.033630
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Code is broken.")
    except ProgrammingError as e:
        assert repr(e) == "ProgrammingError(Code is broken.)"


# Generated at 2022-06-21 20:12:49.000067
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass



# Generated at 2022-06-21 20:12:51.528726
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError: pass
    try:
        raise ProgrammingError("Foo bar")
    except ProgrammingError: pass


# Generated at 2022-06-21 20:12:56.971123
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test message")
    except ProgrammingError as e:
        assert e.args[0] == "test message"
        assert isinstance(e, ProgrammingError)

# Generated at 2022-06-21 20:12:59.096805
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, message="A custom message"):
        print("hi!")

# Generated at 2022-06-21 20:13:01.649488
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Hi")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Hi"

# Generated at 2022-06-21 20:13:04.947399
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    e = ProgrammingError("Test")
    # pylint: disable=protected-access
    assert str(e) == "Test"
    assert e.__dict__ == {'args': ("Test",)}


# Generated at 2022-06-21 20:13:06.865962
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of class :py:class:`ProgrammingError`.
    """
    ProgrammingError()


# Generated at 2022-06-21 20:13:10.677144
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-21 20:13:14.898836
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    try:
        raise ProgrammingError("This is a ProgrammingError")
    except ProgrammingError as e:
        if str(e) != "This is a ProgrammingError":
            raise AssertionError("Unexpected exception message: " + str(e))


# Generated at 2022-06-21 20:13:17.179367
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Unit test code
    with ProgrammingError("Check your code against domain logic to fix it."):
        pass


# Generated at 2022-06-21 20:13:20.293450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as ex:
        assert (ex.args[0] == "test")


# Generated at 2022-06-21 20:13:24.258936
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test constructor of class ProgrammingError."""
    try:
        raise ProgrammingError("A problem has happened.")
    except ProgrammingError as error:
        assert str(error) == "A problem has happened."



# Generated at 2022-06-21 20:13:28.700791
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Verifies that construction of :py:class:`ProgrammingError` works as expected.
    """
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as err:
        assert str(err) == "Test"


# Generated at 2022-06-21 20:13:30.599126
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("some message"):
        raise ProgrammingError("some message")


# Generated at 2022-06-21 20:13:35.695258
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Raises an exception with message
    try:
        raise ProgrammingError("Foo Bar")
    except ProgrammingError as exception:
        assert exception.args[0] == "Foo Bar"

    # Raises an exception without message

# Generated at 2022-06-21 20:13:42.763237
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "should pass")
    except ProgrammingError:
        assert False
    try:
        ProgrammingError.passert(False, "should fail")
        assert False
    except ProgrammingError:
        pass  # should fail but in a controlled manner
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        pass  # should fail but in a controlled manner

# Generated at 2022-06-21 20:13:44.008887
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-21 20:13:48.143350
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("It should not be done")
    except ProgrammingError as e:
        assert str(e) == "It should not be done"



# Generated at 2022-06-21 20:13:51.466500
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for the constructor :py:meth:`ProgrammingError`."""
    try:
        ProgrammingError(message="Hello", other="World")
        raise Exception("Constructor of ProgrammingError should have rejected additional parameters")
    except TypeError:
        pass


# Generated at 2022-06-21 20:13:57.398180
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    # Act
    # Assert
    error_message = "This is an error message"
    try:
        raise ProgrammingError(error_message)
    except ProgrammingError as error:
        assert str(error) == error_message


# Generated at 2022-06-21 20:14:01.355234
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("I am testing raise a ProgrammingError")
    except ProgrammingError as e:
        if str(e) != "I am testing raise a ProgrammingError":
            raise AssertionError("Expected message is not the raised one")


# Generated at 2022-06-21 20:14:04.394019
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Some error message.")
    except ProgrammingError as pr:
        assert isinstance(pr, Exception)
        assert str(pr) == "Some error message."


# Generated at 2022-06-21 20:14:11.691277
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class Test(ProgrammingError):
        pass
    try:
        Test(message="Something went wrong.")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Something went wrong."


# Generated at 2022-06-21 20:14:14.152156
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error")
    except ProgrammingError as e:
        assert str(e) == "This is a programming error"

# Generated at 2022-06-21 20:14:15.808227
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError()
    assert(isinstance(err, ProgrammingError))



# Generated at 2022-06-21 20:14:16.723790
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("message")



# Generated at 2022-06-21 20:14:19.915283
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Try to raise the error
    try:
        raise ProgrammingError()

    # Catch the expected error
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    # Raise an unexpected error
    else:
        raise



# Generated at 2022-06-21 20:14:25.069398
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "123")
    except ProgrammingError as e:
        assert str(e) == "123"
    else:
        raise AssertionError("ProgrammingError.passert is not working as expected")

# Generated at 2022-06-21 20:14:26.856403
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        print(e)


# Generated at 2022-06-21 20:14:28.002303
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="Programming error message.")

# Generated at 2022-06-21 20:14:33.522076
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if the constructor of class :py:class:`ProgrammingError` raises it correctly.
    """
    try:
        ProgrammingError.passert(False, "This is a test")
        assert False, "It should have raised an exception"
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:14:35.649393
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)



# Generated at 2022-06-21 20:14:43.784016
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as err:
        assert str(err) == "test"


# Generated at 2022-06-21 20:14:47.179303
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert type(e) == ProgrammingError
    else:
        assert False, "ProgrammingError raised no exception"


# Generated at 2022-06-21 20:14:52.199475
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Just a test")
    except ProgrammingError as e:
        print(e)

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        print(e)

    ProgrammingError.passert(True, "Just a test")

# Generated at 2022-06-21 20:14:55.111733
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Should not fail.")
    except ProgrammingError:
        return True
    return False



# Generated at 2022-06-21 20:14:57.878162
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("ProgrammingError message")
        assert False
    except ProgrammingError as err:
        assert err.args == ("ProgrammingError message",)

# Generated at 2022-06-21 20:14:59.632459
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-21 20:15:04.917075
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    err_0 = ProgrammingError()
    err_1 = ProgrammingError("Something went wrong")

    assert str(err_0) == str(err_1) == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-21 20:15:08.202690
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except BaseException:
        raise AssertionError(
            "Default constructor of class ProgrammingError should not raise any exception."
        )


# Generated at 2022-06-21 20:15:10.441817
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "A message")
        assert False
    except ProgrammingError:
        pass
    except:
        assert False

# Generated at 2022-06-21 20:15:13.026450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a custom message")
    except ProgrammingError as e:
        assert(e.args == ("This is a custom message",))


# Generated at 2022-06-21 20:15:25.517695
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        print(e)      # pylint: disable=superfluous-parens


# Generated at 2022-06-21 20:15:28.314186
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError) as excinfo:
        raise ProgrammingError("Some error occurred.")
    assert "Some error occurred" in str(excinfo.value)


# Generated at 2022-06-21 20:15:30.920313
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, match="Broken coherence. Check your code against domain logic to fix it."):
        ProgrammingError()

# Generated at 2022-06-21 20:15:32.558172
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    p_error = ProgrammingError('A message')
    assert p_error.args[0] == 'A message'

# Generated at 2022-06-21 20:15:41.652400
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert ProgrammingError.__doc__ == "Provides a programming error exception."
    assert ProgrammingError.__init__.__doc__ == "x.__init__(...) initializes x; see help(type(x)) for signature"
    assert ProgrammingError.__module__ == "pypara.error"
    assert ProgrammingError.__qualname__ == "ProgrammingError"
    assert ProgrammingError("message").args == ("message",)
    assert ProgrammingError("message").__str__() == "message"


# Generated at 2022-06-21 20:15:43.174847
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
        ProgrammingError.passert(True, "")
        ProgrammingError.passert(False, "My message")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Expected to raise a ProgrammingError")


# Generated at 2022-06-21 20:15:51.722714
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError.__doc__
    assert ProgrammingError.passert.__doc__
    try:
        ProgrammingError()
    except TypeError:
        pass
    else:
        raise AssertionError
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        raise AssertionError
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass
    else:
        raise AssertionError
    try:
        ProgrammingError.passert(True, "test")
    except ProgrammingError as exc:
        raise AssertionError from exc
    try:
        ProgrammingError.passert(False, "test")
    except ProgrammingError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-21 20:15:54.116942
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError("This is just a test.")

# Generated at 2022-06-21 20:15:56.908348
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Should fail")
        assert False, "Should fail"
    except ProgrammingError as e:
        assert type(e) == ProgrammingError, "Should be ProgrammingError"

# Generated at 2022-06-21 20:16:01.323234
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`.

    :raises AssertionError: If any of the tests fails.
    """
    try:
        ProgrammingError("error")
    except ProgrammingError as ex:
        assert ex.args[0] == "error"

# Generated at 2022-06-21 20:16:35.326957
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Foo")
    except ProgrammingError as pe:
        assert pe.args[0] == "Foo"

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as pe:
        assert pe.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    ProgrammingError.passert(True, None)


if __name__ == '__main__':
    test_ProgrammingError()

# Generated at 2022-06-21 20:16:37.140770
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-21 20:16:38.775818
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "code should never be here")
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-21 20:16:42.121915
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:16:43.573891
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is an example message for an error")


# Generated at 2022-06-21 20:16:46.661151
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("Test message")
    assert isinstance(err, Exception)
    assert err.args == ("Test message",)

# Generated at 2022-06-21 20:16:50.372380
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True

    try:
        raise ProgrammingError("Error")
    except ProgrammingError as e:
        assert str(e) == "Error"



# Generated at 2022-06-21 20:16:57.101785
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase, main

    class Test(TestCase):
        def test_constructor_default(self):
            self.assertRaises(ProgrammingError, ProgrammingError)
            self.assertRaises(ProgrammingError, ProgrammingError, "")

        def test_constructor_expectation_fulfilled(self):
            ProgrammingError.passert(True, "")

        def test_constructor_expectation_not_fulfilled(self):
            self.assertRaises(ProgrammingError, ProgrammingError.passert, False, "")

    main()


if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-21 20:17:02.145948
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test if an error is thrown when passing an invalid argument. If not the test will fail.
    """
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert(e.args[0] == "Test")


# Generated at 2022-06-21 20:17:05.501443
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError()
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "message")

# Generated at 2022-06-21 20:18:05.668250
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError()
    assert len(e.args) == 0

    e = ProgrammingError("This is a test!")
    assert len(e.args) == 1
    assert e.args[0] == "This is a test!"

# Generated at 2022-06-21 20:18:07.388665
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    condition = False
    message = "Broken coherence."
    assert ProgrammingError.passert(condition, message) is None



# Generated at 2022-06-21 20:18:10.720798
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError
    """

    assert ProgrammingError.passert(True, None) is None
    
    try:
        ProgrammingError.passert(False, "This is a programming error")
        assert False, "Excepcion not raised in the first case"
    except ProgrammingError as e:
        assert str(e) == "This is a programming error"

# Generated at 2022-06-21 20:18:12.425098
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as e:
        ProgrammingError()

    assert e.value.args[0] is None


# Generated at 2022-06-21 20:18:20.021322
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Case: a generic error message is shown when the message is not set
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert "Check your code against domain logic to fix it." in str(e)

    # Case: the provided message is shown when set
    try:
        ProgrammingError.passert(False, "Some error message")
    except ProgrammingError as e:
        assert "Some error message" in str(e)

    # Case: no exception is raised when the condition is met
    ProgrammingError.passert(True, "Some error message")

# Generated at 2022-06-21 20:18:20.990902
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()

# Generated at 2022-06-21 20:18:25.032671
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "Hello, World!")
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Hello, World!")

# Generated at 2022-06-21 20:18:29.494450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("Check your code against domain logic to fix it.")
    assert str(e) == "Check your code against domain logic to fix it."


# Generated at 2022-06-21 20:18:33.544917
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError.passert(False, "I am an error")
    except ProgrammingError as e:
        assert str(e) == "I am an error"
    try:
        ProgrammingError.passert(True, "I am an error")
    except ProgrammingError:
        assert False

# Generated at 2022-06-21 20:18:39.994101
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        msg = "Simple example of ProgrammingError"
        raise ProgrammingError(msg)
    except ProgrammingError as e:
        assert e.args[0] == msg

    msg = "Simple example of ProgrammingError"
    try:
        # noinspection PyStatementEffect
        1/0
    except ZeroDivisionError:
        raise ProgrammingError(msg) from None
    assert False


# Generated at 2022-06-21 20:20:39.370220
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("Cool story bro.")
    assert "Cool story bro." == err.args[0]


# Generated at 2022-06-21 20:20:47.084642
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for the constructor of :py:class:`ProgrammingError`.
    """
    #
    # Test the constructor with all input values
    #
    exception = ProgrammingError()
    assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."
    #
    # Test the constructor with an additional message
    #
    exception = ProgrammingError(message="Testing error message")
    assert str(exception) == "Testing error message"
    #
    # Test that the constructor raises an exception if the condition is not met
    #
    try:
        ProgrammingError.passert(condition=False, message=None)
        assert False, "ProgrammingError.passert should have raised a ProgrammingError"
    except ProgrammingError as e:
        pass
    #
    # Test that the constructor does nothing if the

# Generated at 2022-06-21 20:20:49.604592
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()


# Generated at 2022-06-21 20:20:50.731383
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Testing class ProgrammingError")

# Generated at 2022-06-21 20:20:53.068308
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-21 20:20:56.101873
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(1==2, "1 is not 2")
        assert False
    except ProgrammingError as e:
        assert str(e) == "1 is not 2"


# Generated at 2022-06-21 20:21:00.328580
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="This is a test message")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test message"
    else:
        raise AssertionError("The exception was not raised.")

# Generated at 2022-06-21 20:21:02.580682
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test error.")
    except ProgrammingError as e:
        assert str(e) == "This is a test error."


# Generated at 2022-06-21 20:21:05.997910
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class ProgrammingError.
    """
    # Arrange
    message = "This is a message"

    # Act
    ex = ProgrammingError(message)

    # Assert
    assert str(ex) == message


# Generated at 2022-06-21 20:21:07.965652
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Mock message.")
    except ProgrammingError as e:
        assert str(e) == "Mock message."
