

# Generated at 2022-06-24 01:08:18.808872
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Performs a unit test for the :py:class:`ProgrammingError` class.

    This unit test uses the `unittest` module.
    """

    import unittest
    from contextlib import contextmanager

    from io import StringIO

    from tests.util import utils
    from pypara.error import ProgrammingError

    class ProgrammingErrorTestSuite(unittest.TestCase):
        """Provides the test suite for the :py:class:`ProgrammingError` class."""

        def test_passert_true(self):
            """Tests the :py:meth:`ProgrammingError.passert` method with true condition."""
            with utils.ConsoleRedirect(stream=StringIO()) as c:
                c.assert_not_written()

# Generated at 2022-06-24 01:08:20.446119
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(True, "Invalid value")
    except Exception as ex:
        assert type(ex) is ProgrammingError



# Generated at 2022-06-24 01:08:22.440730
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "A problem has arisen"):
        pass
    with ProgrammingError.passert(True, "A problem has arisen"):
        pass

# Generated at 2022-06-24 01:08:27.852775
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_exception = ProgrammingError("Here is an exception")
    assert test_exception.args[0] == "Here is an exception"

# Generated at 2022-06-24 01:08:31.146335
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.

    This is a test for :py:class:`ProgrammingError` constructor.

    .. todo:: Provide a unit test for :py:func:`ProgrammingError.passert` method.
    """
    try:
        raise ProgrammingError("Test for ProgrammingError")
    except ProgrammingError as instance:
        assert str(instance) == "Test for ProgrammingError"

# Generated at 2022-06-24 01:08:37.749703
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test assumes passert() method
    try:
        ProgrammingError.passert(False, "Testing")
    except ProgrammingError as exc:
        assert str(exc) == "Testing"
    else:
        assert False, "ProgrammingError should have been raised"
    ProgrammingError.passert(True, None)

# Generated at 2022-06-24 01:08:39.440099
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        pass


# Generated at 2022-06-24 01:08:41.562754
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error")
    except ProgrammingError as e:
        assert str(e) == "Error"


# Generated at 2022-06-24 01:08:44.060616
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is a Programming Error.")
    except ProgrammingError as e:
        assert str(e) == "This is a Programming Error."


# Generated at 2022-06-24 01:08:45.405186
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        assert 1



# Generated at 2022-06-24 01:08:49.861069
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    __tracebackhide__ = True
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-24 01:08:51.878555
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:08:55.056697
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Testing")
    assert error.args[0] == "Testing"


# Generated at 2022-06-24 01:08:56.361726
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        print(str(e))



# Generated at 2022-06-24 01:08:57.361117
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Should raise an exception with message as expected
    assertRaises(ProgrammingError, ProgrammingError, "test")

# Generated at 2022-06-24 01:08:59.513767
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Act
    try:
        ProgrammingError.passert(condition=False, message="I am a moth")

        # Assert
        assert False, "An exception was expected to be raised"
    except ProgrammingError as exception:
        assert str(exception) == "I am a moth"


# Generated at 2022-06-24 01:09:08.447285
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase

    class _Test(TestCase):
        def test_constructor_with_message(self):
            with self.assertRaises(ProgrammingError) as ex:
                raise ProgrammingError("This is a test for ProgrammingError")
            self.assertEqual("This is a test for ProgrammingError", str(ex.exception))

    import unittest
    tests = unittest.TestLoader().loadTestsFromTestCase(_Test)
    unittest.TextTestRunner(verbosity=2).run(tests)


# Generated at 2022-06-24 01:09:12.048267
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test that the exception is raised.
    try:
        ProgrammingError.passert(False, "Broken coherence")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence"


# Generated at 2022-06-24 01:09:18.242801
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "Didn't raise ProgrammingError as expected"


# Generated at 2022-06-24 01:09:20.732288
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    p_error = ProgrammingError()
    assert p_error is not None
    assert p_error.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:09:25.090704
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Incorrect ProgrammingError instantiation."


# Generated at 2022-06-24 01:09:27.367819
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("An error message")
    except ProgrammingError as e:
        assert e.args[0] == "An error message"


# Generated at 2022-06-24 01:09:29.097068
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Hello World!"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert message == str(e)



# Generated at 2022-06-24 01:09:31.637736
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def condition():
        ProgrammingError(None)
        ProgrammingError("")
        ProgrammingError("foo")
        return True
    assert condition()



# Generated at 2022-06-24 01:09:40.126719
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Should not be raised")
        assert True, "Condition was True"
    except ProgrammingError as e:
        assert False, "Condition was True, but exception was raised"

    try:
        ProgrammingError.passert(False, "Should be raised")
        assert False, "Condition was False, but no exception was raised"
    except ProgrammingError as e:
        assert True, "Condition was False, and exception was raised"

    try:
        ProgrammingError.passert(False, None)
        assert False, "Condition was False, but no exception was raised"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:09:42.760780
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Failure")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "Failure"


# Generated at 2022-06-24 01:09:46.969073
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
  try:
      ProgrammingError.passert(False, "Broken coherence")
      assert False, "Expected exception not raised"
  except Exception as e:
      assert isinstance(e, ProgrammingError), "Expected ProgrammingError instead of %r" % (e.__class__.__name__,)

# Generated at 2022-06-24 01:09:48.445130
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("foo")
    except ProgrammingError as error:
        assert error.args[0] == "foo"
        return
    raise AssertionError("Should have raised ProgrammingError by construction")



# Generated at 2022-06-24 01:09:57.202962
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "This is not a message.")
    except Exception as ex:
        raise AssertionError("This exception should not have been raised.")
    try:
        ProgrammingError.passert(False, "This is a message.")
        raise AssertionError("An exception should have been raised, but it has not been.")
    except ProgrammingError as ex:
        assert ex.args[0] == "This is a message."
    try:
        ProgrammingError.passert(False, None)
        raise AssertionError("An exception should have been raised, but it has not been.")
    except ProgrammingError as ex:
        assert ex.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    print("Unit test for ProgrammingError has been successfully accomplished!")

# Generated at 2022-06-24 01:10:00.387782
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test constructor for class :py:class:`ProgrammingError`"""
    # test assert
    ProgrammingError.passert(True, "")
    # test exception
    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError:
        assert True

# Generated at 2022-06-24 01:10:04.624082
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Something is wrong in my code!")
    except ProgrammingError as e:
        assert "Something is wrong" in str(e)
    else:
        assert False



# Generated at 2022-06-24 01:10:07.507290
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("The default constructor of class 'ProgrammingError' did not raise an "
                             "exception as expected.")


# Generated at 2022-06-24 01:10:08.206678
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, 'Foo')

# Generated at 2022-06-24 01:10:09.856784
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error message")
    except ProgrammingError as error:
        assert error.__str__() == "Programming error message"


# Generated at 2022-06-24 01:10:11.147015
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert True
    else:
        assert False

# Generated at 2022-06-24 01:10:17.045322
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(None).passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:10:22.547951
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    except Exception:
        assert False, f"This exception type must be ProgrammingError."


# Generated at 2022-06-24 01:10:30.632432
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for `pypara.core.errors.ProgrammingError`."""
    assert issubclass(ProgrammingError, Exception)
    assert ProgrammingError.__doc__ is not None
    assert ProgrammingError.__init__.__doc__ is not None
    assert ProgrammingError.__init__.__annotations__ == {'self': 'ProgrammingError',
                                                         'message': 'Optional[str]'}
    assert ProgrammingError.passert.__doc__ is not None
    assert ProgrammingError.passert.__annotations__ == {'cls': 'Type[ProgrammingError]',
                                                        'condition': 'bool',
                                                        'message': 'Optional[str]'}
    assert ProgrammingError.passert.__dict__["__wrapped__"].__name__ == "passert"
    # Test passert

# Generated at 2022-06-24 01:10:34.008551
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Won't raise exception")
        ProgrammingError.passert(False, "Programming error")
    except ProgrammingError as e:
        assert str(e) == "Programming error"



# Generated at 2022-06-24 01:10:39.025028
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with_message = ProgrammingError("Somme error message")
    assert str(with_message) == "Somme error message"
    assert with_message.message == "Somme error message"

    with_no_message = ProgrammingError()
    assert str(with_no_message) == "Broken coherence. Check your code against domain logic to fix it."
    assert with_no_message.message == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:10:41.626275
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Ensures that :py:class:`ProgrammingError` is raised (that is, an exception object is generated).
    """
    try:
        assert False, "This test should pass an assertion to ProgrammingError.passert"
    except ProgrammingError:
        # It is ok
        pass
    else:
        # It is NOT ok
        raise AssertionError("ProgrammingError was not raised.")


# Generated at 2022-06-24 01:10:46.918197
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test to check the constructor of class :py:class:`ProgrammingError`.
    """
    pr = ProgrammingError("test")
    assert str(pr) == repr(pr) == "test", "Message is not properly set."

# Generated at 2022-06-24 01:10:56.051362
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Testing that a ProgrammingError is raised when passing a condition is false
    try:
        ProgrammingError.passert(False, "It is broken")
        assert False, "ProgrammingError.passert did not raise an exception"
    except ProgrammingError as e:
        assert str(e) == "It is broken", "Unexpected error message: " + str(e)

    # Testing that no exception is raised when passing a condition is true
    ProgrammingError.passert(True, "It is broken")

# Generated at 2022-06-24 01:11:01.899416
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # These are not supposed to raise exceptions
    ProgrammingError.passert(True, "Should not raise any exception")
    ProgrammingError.passert(True, None)
    # These are intended to raise exceptions
    caught = False
    try:
        ProgrammingError.passert(False, "Should raise exception")
    except ProgrammingError:
        caught = True
    assert caught
    caught = False
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        caught = True
    assert caught

# Generated at 2022-06-24 01:11:05.204826
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "Everything's fine")
    exception = None
    try:
        ProgrammingError.passert(False, "Something went wrong")
    except ProgrammingError as e:
        exception = str(e)
    assert exception == "Something went wrong"

# Generated at 2022-06-24 01:11:07.379879
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False # should not reach here


# Generated at 2022-06-24 01:11:12.607322
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("1")
        assert False
    except ProgrammingError as e: assert str(e) == "1"


# Generated at 2022-06-24 01:11:18.092714
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test singleton
    assert ProgrammingError.passert(True, "This should pass") is None
    try:
        ProgrammingError.passert(False, "This should fail")
    except ProgrammingError as e:
        assert "Check your code against domain logic to fix it." in str(e)

# Generated at 2022-06-24 01:11:21.918958
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.

    :raises AssertionError: In case that the assertion fails.
    """
    try:
        raise ProgrammingError("An error happened")
    except ProgrammingError as e:
        assert e.args[0] == "An error happened"

# Generated at 2022-06-24 01:11:25.799158
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests that the constructor of :py:class:`ProgrammingError` behaves as expected."""

    try:
        raise ProgrammingError("Foo")
    except ProgrammingError as e:
        assert e.args[0] == "Foo"


# Generated at 2022-06-24 01:11:27.122718
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-24 01:11:28.050955
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-24 01:11:29.422560
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError("Mocked expected exception for unit test purposes.")

# Generated at 2022-06-24 01:11:32.633840
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("...")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Instantiation of class `ProgrammingError` should raise an error.")


# Generated at 2022-06-24 01:11:35.625323
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError(None)

# Generated at 2022-06-24 01:11:38.768909
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing error")
    except ProgrammingError as e:
        assert str(e) == "Testing error"

# Generated at 2022-06-24 01:11:42.974060
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # noinspection PyTypeChecker
        ProgrammingError(True)
        raise RuntimeError
    except ProgrammingError:
        pass
    except:
        raise RuntimeError



# Generated at 2022-06-24 01:11:44.731158
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:11:45.694619
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is a test")

# Generated at 2022-06-24 01:11:49.047186
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("NO_REASON")
    except ProgrammingError as ex:
        assert str(ex) == "NO_REASON"


# Generated at 2022-06-24 01:11:51.577835
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("error message")


# Generated at 2022-06-24 01:11:53.259147
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError("Testing")
    assert str(excinfo.value) == "Testing"

# Generated at 2022-06-24 01:11:54.880577
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # We expect that this raises an exception
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:11:59.580334
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""

    # "Default" test, no args passed
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Failed to raise ProgrammingError when no args passed")

    # Args passed
    try:
        raise ProgrammingError("Hello")
    except ProgrammingError as exc:
        assert str(exc) == "Hello"
    else:
        raise AssertionError("Failed to raise ProgrammingError when args passed")

# Generated at 2022-06-24 01:12:02.824595
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    # Take a look at the project intro
    # WHEN
    # The following exception is raised
    try:
        raise ProgrammingError("A test message")
    # THEN
    # The following exception is received
    except ProgrammingError as error:
        assert error.args == ("A test message",)


# Generated at 2022-06-24 01:12:04.740525
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"



# Generated at 2022-06-24 01:12:07.062884
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "This is an error message."
    exception = ProgrammingError(message)
    assert exception.args[0] == message


# Generated at 2022-06-24 01:12:09.754849
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as pe:
        assert pe.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-24 01:12:13.415102
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for :py:class:`pypara.ProgrammingError`"""
    try:
        ProgrammingError.passert(False, "My error message")
    except ProgrammingError as err:
        assert err.args[0] == "My error message"

# Generated at 2022-06-24 01:12:19.596200
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
        assert False, "Error was not raised"
    except ProgrammingError:
        # Error was raised as expected
        pass
    else:
        assert False, "Error was expected but not raised"

    try:
        ProgrammingError.passert(True, "Test")
        # Error was not raised as expected
        pass
    except ProgrammingError:
        assert False, "Error was raised but not expected"
    else:
        pass

# Generated at 2022-06-24 01:12:24.722627
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError` and the :py:meth:`passert` helper method.
    """
    for condition in [True, False]:
        try:
            ProgrammingError.passert(condition, "test")
        except ProgrammingError:
            if condition:
                raise

    condition = False
    message = "test"
    try:
        ProgrammingError.passert(condition, message)
    except ProgrammingError as e:
        assert e.args[0] == message

# Generated at 2022-06-24 01:12:30.953361
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This must be raised.")
        assert False
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(True, "This must not be raised.")
    except ProgrammingError:
        assert False

# Generated at 2022-06-24 01:12:33.102467
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A sample error")
    except ProgrammingError as err:
        assert str(err) == "A sample error"


# Generated at 2022-06-24 01:12:34.912960
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert "test" == e.args[0]

# Generated at 2022-06-24 01:12:36.174003
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=pointless-statement
    ProgrammingError


# Generated at 2022-06-24 01:12:38.044815
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("This is a ProgrammingError for the unit test"):
        pass


# Generated at 2022-06-24 01:12:48.609461
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # If the condition is true, then no exception is raised
    ProgrammingError.passert(True, "Message")

    # If the condition is false, then the exception is raised with the message
    try:
        ProgrammingError.passert(False, "Message")
        assert False
    except ProgrammingError as error:
        pass
    finally:
        assert str(error) == "Message"

    # If the condition is false and no message is provided, then the exception is raised with a generic message
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as error:
        pass
    finally:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:12:51.372874
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test_ProgrammingError")
    except ProgrammingError as ex:
        assert str(ex) == "test_ProgrammingError"
    else:
        assert False, "ProgrammingError not raised!"  # pragma: no cover


# Generated at 2022-06-24 01:12:58.577684
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Ensures that the constructor of class :py:class:`ProgrammingError` works as expected.
    """
    # Assertions
    try:
        raise ProgrammingError("Message")
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert "Message" == str(e)


# Generated at 2022-06-24 01:13:01.720563
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "condition was not met")
        assert False, 'Error should have been raised.'
    except ProgrammingError as exp:
        assert "condition was not met" == str(exp)


# Generated at 2022-06-24 01:13:03.594285
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as e:
        assert "This is an error" == str(e)


# Generated at 2022-06-24 01:13:04.949497
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError(message="This is a programming error")
    assert error.args == ("This is a programming error",)

# Generated at 2022-06-24 01:13:09.991714
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Arf!")
        assert False
    except ProgrammingError as e:
        assert e.__class__ == ProgrammingError
        assert str(e) == "Arf!"

# Generated at 2022-06-24 01:13:12.783329
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test that asserts the correct behavior of the constructor of class ProgrammingError.
    """
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    finally:
        ProgrammingError("Test error")


# Generated at 2022-06-24 01:13:18.070213
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN a message
    message = "message"
    
    # WHEN raising
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        # THEN the message can be recovered by str(e)
        assert str(e) == message


# Generated at 2022-06-24 01:13:22.479185
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Creates a :py:class:`ProgrammingError` and validates its correctness.
    """
    try:
        raise ProgrammingError("Something has been wrong")
    except ProgrammingError as e:
        assert str(e) == "Something has been wrong"


# Generated at 2022-06-24 01:13:23.820397
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert "This is a test" == e.args[0]

# Generated at 2022-06-24 01:13:24.798574
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test message")



# Generated at 2022-06-24 01:13:27.832144
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=W0612
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:13:29.729712
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Test message")
    assert str(error) == "Test message"

# Generated at 2022-06-24 01:13:34.814670
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("test"):
        pass
    try:
        with ProgrammingError("test"):
            pass
        try:
            raise ProgrammingError("test")
        except ProgrammingError as e:
            assert "test" == e.__str__()
    except ProgrammingError as e:
        assert "test" == e.__str__()


# Generated at 2022-06-24 01:13:36.782291
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("This is a test")
    assert e.args[0] == "This is a test"


# Generated at 2022-06-24 01:13:42.359899
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # First check that ProgrammingError raises an exception
    test_ok = False
    try:
        raise ProgrammingError("test")
    except ProgrammingError:
        test_ok = True
    assert test_ok
    # Second check that ProgrammingError can be caught
    test_ok = True
    try:
        ProgrammingError.passert(False, "test")
    except ProgrammingError:
        test_ok = False
    assert test_ok

# Generated at 2022-06-24 01:13:52.084451
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "")
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    except OSError:
        raise Exception("Wrong exception.")
    else:
        raise Exception("Wrong exception.")
    try:
        raise ProgrammingError("")
    except ProgrammingError as x:
        assert x.args[0] == ""
    else:
        raise Exception("Wrong exception.")
    try:
        raise ProgrammingError()
    except ProgrammingError as x:
        assert x.args == ()
    else:
        raise Exception("Wrong exception.")
    try:
        raise ProgrammingError("", "")
    except ProgrammingError as x:
        assert x.args == ("", "")
    else:
        raise Exception("Wrong exception.")

# Generated at 2022-06-24 01:13:54.205846
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Dummy")
    except ProgrammingError as e:
        assert str(e) == "Dummy"
    else:
        assert False

# Generated at 2022-06-24 01:13:57.709649
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()



# Generated at 2022-06-24 01:13:58.975701
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    ProgrammingError()



# Generated at 2022-06-24 01:14:01.389654
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    try:
        ProgrammingError("Exception test")
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-24 01:14:03.023330
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert e.args == ("test",)


# Generated at 2022-06-24 01:14:07.326540
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "Test")
    assert "Test" == str(excinfo.value)
    assert "Check your code against domain logic to fix it." == excinfo.value.__cause__
    assert excinfo.value.__cause__.__traceback__ is None

    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, None)
    assert "Broken coherence. Check your code against domain logic to fix it." == str(excinfo.value)

# Generated at 2022-06-24 01:14:14.332423
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of class :py:class:`ProgrammingError`."""

    # When creating the exception with a message, it must pass it on
    try:
        exc = ProgrammingError("Some text")
        assert exc.args == ("Some text",)
    except Exception as e:
        assert False, "Unexpected exception raised: " + str(e)

    # When creating the exception with a empty message, it must not raise an exception
    try:
        ProgrammingError()
    except Exception as e:
        assert False, "Unexpected exception raised: " + str(e)


# Generated at 2022-06-24 01:14:17.357832
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError for correct output.
    """
    err = ProgrammingError()
    assert isinstance(err, ProgrammingError) and isinstance(err, Exception)
    err = ProgrammingError("test")
    assert isinstance(err, ProgrammingError) and isinstance(err, Exception)


# Generated at 2022-06-24 01:14:23.149501
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ This is a unit test for the constructor of class ProgrammingError """
    try:
        ProgrammingError("Error")
    except:
        assert False
    # Successful case
    assert True

# Generated at 2022-06-24 01:14:25.190323
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True


# Generated at 2022-06-24 01:14:28.042285
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Error")
    except ProgrammingError as e:
        assert str(e) == "Error"

# Generated at 2022-06-24 01:14:33.588358
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`.ProgrammingError`.
    """
    try:
        raise ProgrammingError("")
    except ProgrammingError as exc:
        assert exc.args[0] == ""



# Generated at 2022-06-24 01:14:36.897199
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test message.")
    except ProgrammingError as e:
        assert str(e) == "This is a test message."


# Generated at 2022-06-24 01:14:38.720571
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of class ProgrammingError"""
    assert ProgrammingError("Expected error")


# Generated at 2022-06-24 01:14:40.565289
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as ex:
        assert ex


# Generated at 2022-06-24 01:14:44.469645
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # When call to constructor of class ProgrammingError
    # Then an exception is raised with the expected error message
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:14:50.481542
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = None
    try:
        ProgrammingError.passert(True, None)
        ProgrammingError.passert(False, "This is an error message")
    except ProgrammingError as e:
        exception = e
    assert exception is not None
    assert str(exception) == "This is an error message"

# Generated at 2022-06-24 01:14:53.123419
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()
    with pytest.raises(ProgrammingError):
        ProgrammingError("Programming error")


# Generated at 2022-06-24 01:14:57.544762
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def test_programming_error_init():
        try:
            raise ProgrammingError("Test message")
        except ProgrammingError as ex:
            assert ex.args[0] == "Test message"

    # test_ProgrammingError_init
    test_programming_error_init()

# Generated at 2022-06-24 01:15:01.435540
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "No error should be raised.")
    try:
        ProgrammingError.passert(False, "Error should be raised because condition is false.")
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert "Broken coherence." in e.args[0]
        assert "domain logic" in e.args[0]

# Generated at 2022-06-24 01:15:06.239373
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hello World!")
    except ProgrammingError as e:
        assert str(e) == "Hello World!"



# Generated at 2022-06-24 01:15:07.343462
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Some message")



# Generated at 2022-06-24 01:15:14.626292
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for constructor and method passert.

    :return: ``None``
    """
    try:
        ProgrammingError("This is an error")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("The constructor works incorrectly.")
    try:
        ProgrammingError.passert(True, "This is a message")
    except ProgrammingError:
        raise AssertionError("The method passert works incorrectly.")
    try:
        ProgrammingError.passert(False, "This is a message")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("The method passert works incorrectly.")

# Generated at 2022-06-24 01:15:24.269338
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Should not happen")
    except ProgrammingError as e:
        assert False, "Inconclusive exception. It should be never happening."
    try:
        ProgrammingError.passert(False, "Inconclusive")
    except ProgrammingError as e:
        assert str(e) == "Inconclusive"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    print(":: test_ProgrammingError :: OK")
test_ProgrammingError()

# Generated at 2022-06-24 01:15:26.513873
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # act
    error = ProgrammingError("Test message.")

    # assert
    assert error.args[0] == "Test message."



# Generated at 2022-06-24 01:15:32.382674
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    condition = False
    message = "Testing"
    error = None
    try:
        ProgrammingError.passert(condition, message)
    except ProgrammingError as e:
        error = e
    assert isinstance(error, ProgrammingError)
    assert (error.args[0] == message) or (error.args[0] == "Broken coherence. Check your code against domain logic to fix it.")
    assert error.args[1:] == ()

# Generated at 2022-06-24 01:15:35.672164
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test for the unit test function.")
    except ProgrammingError as e:
        assert str(e) == "This is a test for the unit test function."

# Generated at 2022-06-24 01:15:39.129658
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Check the constructor of :py:class:`.ProgrammingError`.
    """
    err = ProgrammingError("Expected this.")
    assert str(err) == "Expected this."


# Generated at 2022-06-24 01:15:40.732914
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Verifies the basic class constructor.
    """
    exception = ProgrammingError("Message.")
    assert exception.args[0] == "Message."

# Generated at 2022-06-24 01:15:45.951868
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Verify that broken coherence is detected
    try:
        ProgrammingError.passert(False, "My message")
    except ProgrammingError as err:
        assert err.args[0] == "My message"

# Generated at 2022-06-24 01:15:50.355633
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc = ProgrammingError("message")
    assert isinstance(exc, Exception)
    assert str(exc) == "message"


# Generated at 2022-06-24 01:15:54.695089
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "This is just a test")


# Generated at 2022-06-24 01:16:01.202051
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""

    # Test default message
    try:
        ProgrammingError()
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."
    except Exception:
        assert False

    # Test message with arguments
    try:
        ProgrammingError("Some {} problem with {}", "syntax", "templates")
    except ProgrammingError as ex:
        assert str(ex) == "Some syntax problem with templates"
    except Exception:
        assert False

# Generated at 2022-06-24 01:16:03.527539
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with assertRaises(ProgrammingError) as ar:
        ProgrammingError.passert(False, "This is a test")

# Generated at 2022-06-24 01:16:08.204185
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Some message")
    except Exception as e:
        assert(isinstance(e, ProgrammingError))
        assert(str(e) == "Some message")


# Generated at 2022-06-24 01:16:11.218645
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("lo que sea")


# Generated at 2022-06-24 01:16:14.720328
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:16:19.750530
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        print(e)
    # Unit test for method passert
    try:
        ProgrammingError.passert(False, "This error is expected.")
        ProgrammingError.passert(True,  "This error is expected.")
    except ProgrammingError as e:
        print(e)

# Generated at 2022-06-24 01:16:25.990966
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        raise RuntimeError("Expected exception was not raised")


# Generated at 2022-06-24 01:16:32.466496
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Something that went horribly wrong.")
        raise AssertionError("ProgrammingError.passert() did not raised!")
    except ProgrammingError as e:
        assert e.args[0] == "Something that went horribly wrong."

# Generated at 2022-06-24 01:16:34.164656
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("Test exception")
    assert exception.__str__() == "Test exception"



# Generated at 2022-06-24 01:16:35.558598
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:16:38.323449
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the explicit constructor of the :py:class:`ProgrammingError` exception class.

    :return: ``None``
    """
    error: ProgrammingError = ProgrammingError("Foo")
    error = ProgrammingError("")
    error = ProgrammingError()


# Generated at 2022-06-24 01:16:44.881360
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Some message.")
    except ProgrammingError as e:
        assert str(e) == "Some message."


# Generated at 2022-06-24 01:16:48.194554
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    class Failing(ProgrammingError):
        pass

    try:
        raise Failing("this is a test")
    except Failing as e:
        assert str(e) == "this is a test"


# Generated at 2022-06-24 01:16:53.044764
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the constructor of class :py:class:`ProgrammingError`.

    :return: None.
    """
    # noinspection PyTypeChecker
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert error.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    else:
        raise AssertionError("Expected ProgrammingError to be raised.")


# Generated at 2022-06-24 01:16:55.925543
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as ex:
        assert ex.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:16:58.647737
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Testing error message")
    except ProgrammingError as e:
        assert str(e) == "Testing error message"


# Generated at 2022-06-24 01:17:00.079129
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("This is a test!")


# Generated at 2022-06-24 01:17:08.363952
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()
    with pytest.raises(ProgrammingError) as pex:
        raise ProgrammingError()
    assert str(pex.value) == ""
    with pytest.raises(ProgrammingError) as pex:
        raise ProgrammingError("My message")
    assert str(pex.value) == "My message"


# Generated at 2022-06-24 01:17:13.121676
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as err:
        assert err.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "ProgrammingError not raised"
    ProgrammingError.passert(True, "Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-24 01:17:24.652862
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for class :py:class:`ProgrammingError`.
    """
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError()

    with raises(ProgrammingError):
        ProgrammingError("This is a test.")

    with raises(ProgrammingError):
        ProgrammingError("")

    with raises(ProgrammingError):
        ProgrammingError(None)

    # Unit test for method ProgrammingError.passert()
    with raises(ProgrammingError):
        ProgrammingError.passert(False, None)

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "")

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "This is a programming error test.")


# This module is supposed to be safe so that we can import it whenever we need.
test_ProgrammingError

# Generated at 2022-06-24 01:17:31.907832
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """

    # Call the function with a successful case
    try:
        ProgrammingError.passert(True, "OK")
    except ProgrammingError as error:
        assert False

    # Call the function with an unsuccessful case
    try:
        ProgrammingError.passert(False, "KO")
        assert False
    except ProgrammingError as error:
        assert True

# Generated at 2022-06-24 01:17:34.441102
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("error")
    assert error.args == ("error", )


# Generated at 2022-06-24 01:17:36.338538
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        print(e)


# Generated at 2022-06-24 01:17:40.546123
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Provide a message
    assert str(ProgrammingError("Needed message")) == "Needed message"
    # Omit a message
    assert str(ProgrammingError()) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:17:42.623308
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("Test exception")
    assert e.args == ("Test exception",)
    assert str(e) == "Test exception"


# Generated at 2022-06-24 01:17:43.562360
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ex = ProgrammingError("Some error message")
    assert isinstance(ex, Exception)

# Generated at 2022-06-24 01:17:46.143551
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError('test')
    except ProgrammingError as e:
        assert str(e) == 'test'


# Generated at 2022-06-24 01:17:48.622738
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Message")
        raise AssertionError("ProgrammingError did not raise an exception as expected.")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError did not raise an exception as expected.")



# Generated at 2022-06-24 01:17:53.473239
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as err:
        assert isinstance(err, ProgrammingError)


# Generated at 2022-06-24 01:17:54.918412
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    No unit test. This is a dummy function to please the unit testing framework.
    """


# Generated at 2022-06-24 01:18:03.639902
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    # Test that a message is always present
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert("Broken coherence. Check your code against domain logic to fix it." == str(e))
    # Test that a custom message is visible
    try:
        raise ProgrammingError("My message")
    except ProgrammingError as e:
        assert("My message" == str(e))


# Generated at 2022-06-24 01:18:06.130183
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error")
    except ProgrammingError as e:
        assert "This is a programming error" in str(e)


# Generated at 2022-06-24 01:18:10.955242
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    except BaseException as e:
        assert False, "Unexpected exception {0} raised.".format(type(e))
