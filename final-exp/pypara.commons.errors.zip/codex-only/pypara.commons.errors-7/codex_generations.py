

# Generated at 2022-06-24 01:08:09.912675
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "")
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    else:
        assert False

# Generated at 2022-06-24 01:08:11.965606
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Fail the assertion condition.")
    except ProgrammingError as e:
        assert "Fail the assertion condition." == e.args[0]

# Generated at 2022-06-24 01:08:19.129385
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.test.test_base.common import assert_with_message, CustomException
    try:
        ProgrammingError.passert(False, "Message")
        assert False, "It should have raised a ProgrammingError!"
    except ProgrammingError as e:
        assert_with_message(e.args[0], "Message")
    except CustomException:
        assert False, "It should have raised a ProgrammingError!"
    # In case that the message is None, we provide a general one.
    try:
        ProgrammingError.passert(False, None)
        assert False, "It should have raised a ProgrammingError!"
    except ProgrammingError as e:
        assert_with_message(e.args[0], "Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-24 01:08:29.821634
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.expr.types import String, Expression, Environment
    from pypara.core import Interpreter
    from pypara.core.execution_context import ExecutionContext
    from pypara.expr.expr_parser import parse, ast_to_expr

    s = String("\"foo\"")
    expr, _ = parse("class A { def foo(); }")
    assert (isinstance(expr, Expression))
    expr.eval(ExecutionContext(Interpreter(Environment()), Environment()))

    expr, _ = parse("class A { def foo() { } }")
    assert (isinstance(expr, Expression))
    expr.eval(ExecutionContext(Interpreter(Environment()), Environment()))

    expr, _ = parse("class A { def foo() { bar(); } }")

# Generated at 2022-06-24 01:08:31.525788
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): # type: ignore
    try:
        raise ProgrammingError("Programming error")
    except ProgrammingError as e:
        assert str(e) == "Programming error"
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-24 01:08:36.906745
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        try:
            raise ProgrammingError("Testing the constructor")
        except ProgrammingError as e:
            assert str(e) == "Testing the constructor"

# Generated at 2022-06-24 01:08:38.958408
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Some additional context.")
        assert False, "ProgrammingError constructor should raise an exception"
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:08:44.492482
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test message.")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "This is a test message."

    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:08:48.495025
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Error example.")


# Generated at 2022-06-24 01:08:51.027547
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Unit test")
    except ProgrammingError as e:
        assert e.args[0] == "Unit test"
    else:
        raise Exception("ProgrammingError unit test failed")


# Generated at 2022-06-24 01:08:56.586118
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "My error message")
    except ProgrammingError as e:
        assert str(e) == "My error message"

# Generated at 2022-06-24 01:09:01.146172
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "this is a test")
    except ProgrammingError as e:
        assert e.args[0] == "this is a test"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert  e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    ProgrammingError.passert(True, "this is a test")

# Generated at 2022-06-24 01:09:03.179557
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test default constructor
    assert ProgrammingError
    assert issubclass(ProgrammingError, Exception)

    # Test constructor with message
    e = ProgrammingError("my message")
    assert str(e) == "my message"


# Generated at 2022-06-24 01:09:06.911419
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        assert isinstance(ProgrammingError(), ProgrammingError)
    except Exception:
        assert False, "Error at the constructor of ProgrammingError"


# Generated at 2022-06-24 01:09:08.354901
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == 'Broken coherence. Check your code against domain logic to fix it.'


# Generated at 2022-06-24 01:09:10.287304
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    message = "This is a test of class __ProgrammingError__"

    # WHEN
    with pytest.raises(ProgrammingError) as exception_info:
        ProgrammingError.passert(False, message)

    # THEN
    assert exception_info.match(message)

# Generated at 2022-06-24 01:09:11.329467
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is an exception message")
    assert (error.args[0] == "This is an exception message")


# Generated at 2022-06-24 01:09:13.010346
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as exception_info:
        ProgrammingError.passert(False, 'Broken coherence')
    assert exception_info.type is ProgrammingError
    assert str(exception_info.value) == 'Broken coherence'

# Generated at 2022-06-24 01:09:18.307090
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError) as exc_info:
        ProgrammingError("test")
    assert exc_info.type is ProgrammingError
    assert str(exc_info.value).startswith("test")



# Generated at 2022-06-24 01:09:20.577800
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError()

# Integration test for function passert - using mock to intercept calls to constructor of class ProgrammingError

# Generated at 2022-06-24 01:09:24.203394
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # No assertion here as the function raises an error.
    ProgrammingError.passert(False, "message")


# Generated at 2022-06-24 01:09:27.857310
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as e:
        assert str(e) == "Message"


# Generated at 2022-06-24 01:09:31.784264
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    message = "Error Message"
    error = ProgrammingError(message)
    assert error.args == (message,)


# Generated at 2022-06-24 01:09:37.235487
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message=None)
        ProgrammingError.passert(condition=False, message="Monkey")
    except ProgrammingError as e:
        assert True, e  # Pass
    else:
        assert False, "Should have raised ProgrammingError"

# Generated at 2022-06-24 01:09:40.362704
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "msg"):
        raise AssertionError("should not happen")
    ProgrammingError("msg")

# Generated at 2022-06-24 01:09:47.343703
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "pass")
    except ProgrammingError:
        assert False

    try:
        ProgrammingError.passert(False, "fail")
        assert False
    except ProgrammingError as error:
        assert error.args[0] == "fail"

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-24 01:09:54.053692
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
        assert True == False, "ProgrammingError.passert() did not throw the expected exception."
    except ProgrammingError:
        pass
    try:
        ProgrammingError("test")
        assert True == False, "ProgrammingError() did not throw the expected exception."
    except ProgrammingError:
        pass
    ProgrammingError.passert(True, "test")

# Generated at 2022-06-24 01:09:55.862479
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Hello World!")
    ProgrammingError.passert(False, "Hello World!")

# Generated at 2022-06-24 01:09:58.621248
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("bla")
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)
        assert str(err) == "bla"


# Generated at 2022-06-24 01:10:00.437381
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

# Unit tests on method ProgrammingError.passert

# Generated at 2022-06-24 01:10:04.309576
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Error message")
    except ProgrammingError as e:
        assert str(e) == "Error message"


# Generated at 2022-06-24 01:10:06.515621
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a message")
    except ProgrammingError as ex:
        assert str(ex) == "This is a message"

# Generated at 2022-06-24 01:10:08.510723
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert ProgrammingError.__module__ == __name__


# Generated at 2022-06-24 01:10:11.925277
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc: ProgrammingError = ProgrammingError("hello")
    assert "hello" == exc.args[0]

# Generated at 2022-06-24 01:10:17.454968
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert str(e) == "Error message"
    else:
        raise AssertionError("Exception ProgrammingError was not raised.")


# Generated at 2022-06-24 01:10:22.850280
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programmer error.")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert e.args[0] == "This is a programmer error."

# Generated at 2022-06-24 01:10:25.780388
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    class SomeError(ProgrammingError):
        pass
    expected = "Some error"

    # WHEN
    exc = SomeError(expected)

    # THEN
    assert str(exc) == expected


# Generated at 2022-06-24 01:10:30.011988
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as ec:
        raise ProgrammingError
    assert ec.value.__str__() == "Broken coherence. Check your code against domain logic to fix it."
    with pytest.raises(ProgrammingError) as ec:
        raise ProgrammingError("You broke the coherence!")
    assert ec.value.__str__() == "You broke the coherence!"


# Generated at 2022-06-24 01:10:32.877071
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "error")
        assert False
    except ProgrammingError as e:
        assert str(e) == "error"

# Generated at 2022-06-24 01:10:35.683793
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("The sky is falling down!")
    except Exception as exception:
        assert(isinstance(exception, ProgrammingError))
        assert(exception.__str__() == "The sky is falling down!")

# Generated at 2022-06-24 01:10:37.494620
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    ProgrammingError.passert(False, "This is a test message")



# Generated at 2022-06-24 01:10:38.551701
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()
    ProgrammingError("test")


# Generated at 2022-06-24 01:10:39.387467
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(None)

# Generated at 2022-06-24 01:10:41.157965
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Ensures that :py:class:`ProgrammingError` is correctly formed."""

    try:
        ProgrammingError("Test message.")
    except ProgrammingError:
        assert True

# Generated at 2022-06-24 01:10:45.887539
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given
    message = "This is the error message"

    # When
    actual = ProgrammingError(message)

    # Then
    assert message == actual.args[0]

# Generated at 2022-06-24 01:10:49.357409
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("test")
    assert e.args[0] == "test"


# Generated at 2022-06-24 01:10:54.909716
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    error_message = "My custom error message."
    with raises(ProgrammingError) as context:
        raise ProgrammingError(error_message)
    assert error_message in context.value.args[0]

# Generated at 2022-06-24 01:11:02.071093
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if the constructor of :py:class:`ProgrammingError` works properly.

    :raises AssertionError: If the test fails.
    """
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
        assert repr(e) == '<ProgrammingError: "Broken coherence. Check your code against domain logic to fix it.">'
        assert str(ProgrammingError("@todo")) == "@todo"
        assert repr(ProgrammingError("@todo")) == '<ProgrammingError: "@todo">'
        assert isinstance(e, Exception)

# Generated at 2022-06-24 01:11:03.681479
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # type: () -> None
    ProgrammingError(message="Expected condition is always met.")


# Generated at 2022-06-24 01:11:04.891598
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Hello!"):
        pass


# Generated at 2022-06-24 01:11:09.105871
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "OK")
        assert False
    except ProgrammingError as e:
        assert str(e) == "OK"
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:11:13.852983
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message = "Something went wrong")
    except Exception as error:
        assert isinstance(error, ProgrammingError)
        assert str(error) == "Something went wrong"


# Generated at 2022-06-24 01:11:18.093630
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as ex:
        ProgrammingError(message="This is the message")
    assert ex.value.args[0] == "This is the message"



# Generated at 2022-06-24 01:11:22.541455
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor :py:class:`ProgrammingError` and its method :py:meth:`ProgrammingError.passert`
    """
    from unittest import TestCase, main

    class TestProgrammingError(TestCase):
        """
        Tests the constructor :py:class:`ProgrammingError` and its method :py:meth:`ProgrammingError.passert`
        """

        def test_constructor(self):
            """
            Tests the constructor :py:meth:`ProgrammingError.__init__`
            """
            with self.assertRaises(ProgrammingError):
                ProgrammingError("Testing")

        def test_passert(self):
            """
            Tests the method :py:meth:`ProgrammingError.passert`
            """

# Generated at 2022-06-24 01:11:24.511838
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as e:
        assert e.message == "Some message"


# Generated at 2022-06-24 01:11:33.853120
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from typing import NoReturn
    from pypara.utils.exception import ProgrammingError
    def test_method(num: int) -> NoReturn:
        ProgrammingError.passert(num > 0, "Input value must be positive.")

    try:
        test_method(num=-2)
    except ProgrammingError as err:
        assert err.args[0] == "Input value must be positive."
    else:
        raise AssertionError("Expected a ProgrammingError exception to be raised.")



# Generated at 2022-06-24 01:11:46.137165
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test constructor of class ProgrammingError
    """
    from pyassert import assert_that
    from pypara.testing.exception_test_helper import assert_exception_message_equals

    # Test passert
    assert_throws(ProgrammingError, lambda: ProgrammingError.passert(False, None))
    assert_exception_message_equals(
        ProgrammingError,
        lambda: ProgrammingError.passert(False, None),
        "Broken coherence. Check your code against domain logic to fix it."
    )
    assert_throws(ProgrammingError, lambda: ProgrammingError.passert(False, "Error!"))
    assert_exception_message_equals(
        ProgrammingError,
        lambda: ProgrammingError.passert(False, "Error!"),
        "Error!"
    )
    assert_

# Generated at 2022-06-24 01:11:52.816911
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test with a message
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as err:
        assert err.args[0] == "Some message"
    # Test without a message
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert err.args[0] == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-24 01:12:00.312889
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=unused-variable
    # noinspection PyUnusedLocal
    def test_factory(message: Optional[str] = None) -> None:
        return ProgrammingError(message)

    # Testing if a message is actually optional.
    test_factory("t")
    test_factory()

# Generated at 2022-06-24 01:12:03.712696
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert type(e) is ProgrammingError
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:12:08.886444
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"


# Generated at 2022-06-24 01:12:11.774265
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Unit test for constructor of class ProgrammingError. """
    message = "A message"
    error = ProgrammingError(message)
    assert error.args == message


# Generated at 2022-06-24 01:12:17.489735
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a bad test")
        assert False, "ProgrammingError should have been raised"
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:12:21.094256
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for :py:class:`ProgrammingError`.
    """
    TEXT = "Something has failed"
    try:
        raise ProgrammingError("Something has failed")
    except ProgrammingError as ex:
        assert ex.args[0] == TEXT


# Generated at 2022-06-24 01:12:25.238150
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("done!")
    except ProgrammingError as ex:
        assert str(ex) == "done!"


# Generated at 2022-06-24 01:12:28.387852
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError):
        raise ProgrammingError("TEST_MESSAGE")

# Generated at 2022-06-24 01:12:31.875960
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("foo")
    except ProgrammingError as e:
        assert e.args == ("foo",)
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ()


# Generated at 2022-06-24 01:12:32.698244
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError:
        pass

# Generated at 2022-06-24 01:12:41.678648
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of the class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError("Some message")
        assert False, "Should raise ProgrammingError with message 'Some message', but it does not"

    except ProgrammingError as exception:
        assert str(exception) == "Some message", \
            "When instantiating ProgrammingError with message 'Some message', it does not set the correct message"

    try:
        ProgrammingError()
        assert False, "Should raise ProgrammingError without any message, but it does not"

    except ProgrammingError as exception:
        assert str(exception) == "Broken coherence. Check your code against domain logic to fix it.", \
            "When instantiating ProgrammingError with no message, it does not set the default message"


# Generated at 2022-06-24 01:12:45.180143
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test for constructor of class :py:class:`ProgrammingError`."""
    with ProgrammingError.passert(False, "Message of expected exception."):
        pass

# Generated at 2022-06-24 01:12:46.951791
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-24 01:12:49.908890
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)
        assert isinstance(e, BaseException)


# Generated at 2022-06-24 01:12:53.520488
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("This is a test")

# Generated at 2022-06-24 01:12:58.533126
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error")
    except ProgrammingError as exception:
        assert str(exception) == "Programming error"


# Generated at 2022-06-24 01:13:02.349136
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("It is working.")
    except ProgrammingError as e:
        assert e.args[0] == "It is working."
        assert len(e.args) == 1
    else:
        assert False, "Constructor of class ProgrammingError is not working properly."


# Generated at 2022-06-24 01:13:04.180450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    except Exception:
        assert False, "ProgrammingError() should raise a ProgrammingError"



# Generated at 2022-06-24 01:13:05.857364
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error.")
    except ProgrammingError as error:
        assert error.args == ("This is a programming error.", )


# Generated at 2022-06-24 01:13:10.153334
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Testing exceptions...")
    except ProgrammingError:
        return True

    return False


# Generated at 2022-06-24 01:13:13.517915
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:13:17.463844
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Nope!")
    ProgrammingError.passert(True, "Nope!")

# Generated at 2022-06-24 01:13:19.781133
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except BaseException:
        return False
    return True


# Generated at 2022-06-24 01:13:22.478915
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    er = ProgrammingError("Test")
    assert er.__class__.__name__ == "ProgrammingError"
    assert str(er) == "Test"


# Generated at 2022-06-24 01:13:23.820131
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-24 01:13:25.089236
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()

    assert error.args == ()


# Generated at 2022-06-24 01:13:29.114439
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "My message")
    except ProgrammingError as e:
        assert e.args[0] == "My message"


# Generated at 2022-06-24 01:13:31.193780
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert "Test" in str(e)


# Generated at 2022-06-24 01:13:34.615269
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Test of ProgrammingError constructor failed."


# Generated at 2022-06-24 01:13:37.544235
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit tests for class ProgrammingError.
    """
    with ProgrammingError.passert(True, "This is a dummy message"):
        pass
    with ProgrammingError.passert(False, "This is a dummy message"):
        pass

# Generated at 2022-06-24 01:13:42.763638
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Unit test for the constructor of class ProgrammingError"""
    import sys
    import pytest

    err = ProgrammingError("A programming error")

    assert err.args[0] == "A programming error"

# Generated at 2022-06-24 01:13:46.110852
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("message")
    except ProgrammingError as e:
        assert e.args == ("message",)


# Generated at 2022-06-24 01:13:53.699288
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for class ProgrammingError
    """
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        assert True
    try:
        ProgrammingError.passert(False, "test")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "test"

if __name__ == '__main__':
    print("Running the unit test for module " + __file__)
    print(__doc__)

    print("Running unit test for class ProgrammingError")
    test_ProgrammingError()
    print("All tests for class ProgrammingError passed.")

# Generated at 2022-06-24 01:13:56.548831
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        assert ProgrammingError
    except NameError:
        raise AssertionError("ProgrammingError not loaded.")
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Error in Interface: you must raise a ProgrammingError.")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:14:01.814527
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    import os
    from pypara.common import ProgrammingError

    with raises(ProgrammingError) as exc:
        # The os module does not have a method named 'makdir'
        os.makdir("tmp")
    assert str(exc.value) == "Broken coherence. Check your code against domain logic to fix it."

# Unit tests for the class method passert of class ProgrammingError

# Generated at 2022-06-24 01:14:06.057463
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()

# Generated at 2022-06-24 01:14:08.871301
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor for class :py:class:`ProgrammingError`.
    """
    import pytest
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("test message")

# Generated at 2022-06-24 01:14:10.904002
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert True
    else:
        assert False



# Generated at 2022-06-24 01:14:15.142180
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "1 + 1 != 3")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("Expected an exception of type ProgrammingError")

# Generated at 2022-06-24 01:14:16.379681
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, None)
    ProgrammingError.passert(condition=True, message=None)



# Generated at 2022-06-24 01:14:19.105971
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as error:
        assert error.args is not None and str(error.args[0]).endswith("Error message")


# Generated at 2022-06-24 01:14:23.898770
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests that the constructor of the Python class `ProgrammingError` is working as expected."""
    try:
        raise ProgrammingError("Hello, World!")
    except ProgrammingError as e:
        assert str(e) == "Hello, World!"


# Generated at 2022-06-24 01:14:25.398796
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:14:34.944614
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class AClass:
        @staticmethod
        def static_method():
            ProgrammingError("This is a static method")

    class BClass(AClass):
        def __init__(self):
            self.error = ProgrammingError("Constructor method")

        def instance_method(self):
            ProgrammingError("This is an instance method")

    a_class = AClass()
    assert a_class.static_method() == True
    b_class = BClass()
    assert b_class.__init__() == True
    assert b_class.instance_method() == True

    # Unit test for assert(condition, message) of class ProgrammingError
    assert ProgrammingError.passert(1 == 1, "True") == None

# Generated at 2022-06-24 01:14:37.254162
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something is broken. Fix it!")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:14:39.942093
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Invalid args")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("No error was raised")


# Generated at 2022-06-24 01:14:41.885904
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor of class :py:class:`ProgrammingError`.
    """
    ProgrammingError("Some message")

# Generated at 2022-06-24 01:14:44.138266
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except Exception:
        raise AssertionError("Fail to instantiate ProgrammingError()")



# Generated at 2022-06-24 01:14:46.055570
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError not raised"


# Generated at 2022-06-24 01:14:50.621402
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Test"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert e.args[0] == message


# Generated at 2022-06-24 01:14:52.845957
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    from pypara.errors import ProgrammingError

    with pytest.raises(ProgrammingError):
        raise ProgrammingError()

# Generated at 2022-06-24 01:14:56.874049
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)


# Generated at 2022-06-24 01:14:59.365888
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Wrong!")
    except ProgrammingError as exception:
        assert str(exception) == "Wrong!"


# Generated at 2022-06-24 01:15:01.381551
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Bad things happened")
    except Exception as error:
        assert error.__class__ == ProgrammingError

# Generated at 2022-06-24 01:15:13.876206
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    try:
        raise ProgrammingError("This is a custom message.")
    except ProgrammingError as e:
        assert str(e) == "This is a custom message."

    try:
        ProgrammingError.passert(condition=True, message=None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(condition=False, message=None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:15:18.026171
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    This function tests the constructor of class ProgrammingError.
    """
    try:
        raise ProgrammingError("The error message.")
    except ProgrammingError as e:
        assert str(e) == "The error message.", \
            "Error message: {0}".format(str(e))


# Generated at 2022-06-24 01:15:25.265786
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): # pragma: no cover
    try:
        ProgrammingError.passert(False, 'message')
    except ProgrammingError as e:
        assert e.args[0] == 'message', 'Should have raised exception with message "message"'

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it.", \
            'Should have raised exception with default message'

# Generated at 2022-06-24 01:15:31.112479
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara import ProgrammingError
    try:
        ProgrammingError.passert(False, "Testing purposes")
    except ProgrammingError as ex:
        assert ex.args[0] == "Testing purposes"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as ex:
        assert ex.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:15:36.222929
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test
    cls = ProgrammingError
    cls.passert(True, "Should NOT raise an exception.")
    try:
        cls.passert(False, "Should raise an exception!")
        # Expectation
        raise Exception("Unit test failure!")
    except cls:
        # Expectation
        assert True
        pass

# Generated at 2022-06-24 01:15:39.102576
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    sut = ProgrammingError(message="My custom error message.")
    assert str(sut) == "My custom error message."


# Generated at 2022-06-24 01:15:42.271362
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Error message.")
        assert False
    except ProgrammingError as e:
        assert e.args == ("Error message.",)
    except Exception as e:
        assert False

# Generated at 2022-06-24 01:15:46.365908
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Checks that the constructor of class :py:class:`ProgrammingError` works as expected.
    """
    p_error = ProgrammingError("message")
    assert p_error.args[0] == "message"



# Generated at 2022-06-24 01:15:50.609892
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "This is not an error"):
        pass
    with ProgrammingError.passert(False, "This is an error"):
        pass

# Generated at 2022-06-24 01:15:55.602219
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert(e.args[0] == "This is a test")

# Generated at 2022-06-24 01:15:59.827816
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "This condition passes.")
    except ProgrammingError:
        raise AssertionError("This should not have raised a programming error.")
    try:
        ProgrammingError.passert(False, "This condition raises an error.")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:16:01.408565
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc = ProgrammingError("Test")
    assert exc.args[0] == "Test"


# Generated at 2022-06-24 01:16:04.934755
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError, match="Broken coherence"):
        ProgrammingError()

# Unit test passert routine

# Generated at 2022-06-24 01:16:11.719292
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError()
    except ProgrammingError as ex:
        assert ex.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    else:
        raise AssertionError("Expected exception ProgrammingError to be raised.")

    try:
        ProgrammingError.passert(False, "A message")
    except ProgrammingError as ex:
        assert ex.args == ("A message",)
    else:
        raise AssertionError("Expected exception ProgrammingError to be raised.")

    ProgrammingError.passert(True, "A message")
    ProgrammingError.passert(True, None)
    ProgrammingError.passert(True, "")
    ProgrammingError.passert(True, " ")

# Generated at 2022-06-24 01:16:14.552202
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("hello world")
    except ProgrammingError as e:
        if e.args[0] != "hello world":
            raise AssertionError("Error in test_ProgrammingError: Message did not match the constructor argument.")


# Generated at 2022-06-24 01:16:18.040699
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # This will raise an error by design
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert "This is a test." == e.args[0]


# Generated at 2022-06-24 01:16:19.595868
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"

# Generated at 2022-06-24 01:16:25.104283
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, 'Dummy exception message')
    except ProgrammingError as e:
        assert e.args[0] == 'Dummy exception message'
    else:
        assert False

# Generated at 2022-06-24 01:16:27.001406
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "This is the message")

# Generated at 2022-06-24 01:16:30.724276
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "foo")

    ProgrammingError.passert(True, "foo")

# Generated at 2022-06-24 01:16:38.309909
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as err:
        assert(err.args[0] == "Test message")
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert(err.args[0] == "Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-24 01:16:47.556593
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")
    except ProgrammingError as ex:
        assert(ex.args[0] == "Test message")
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as ex:
        assert(ex.args[0] == "Broken coherence. Check your code against domain logic to fix it.")
    try:
        ProgrammingError.passert(True, "Test message")
    except ProgrammingError as ex:
        assert(False)
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as ex:
        assert(False)

if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-24 01:16:49.783253
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError constructor doesn't work")


# Generated at 2022-06-24 01:16:53.268916
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "Expected exception 'ProgrammingError' not thrown."


# Generated at 2022-06-24 01:16:53.999724
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    raise ProgrammingError("A programming error happened")



# Generated at 2022-06-24 01:16:56.156250
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "This is a test"
    err = ProgrammingError(message)
    assert isinstance(err, Exception)
    assert err.__str__() == message



# Generated at 2022-06-24 01:16:57.882464
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test of the exception")
    except ProgrammingError:
        assert True


# Generated at 2022-06-24 01:16:58.966693
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    else:
        assert False, "An exception should have been raised!"


# Generated at 2022-06-24 01:17:03.568033
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test that an instance of :py:class:`ProgrammingError` can be created.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:  # pragma: no cover
        pass

# Generated at 2022-06-24 01:17:08.352735
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as exc_info:
        raise ProgrammingError("some message")
    assert str(exc_info.value) == "some message"



# Generated at 2022-06-24 01:17:10.014015
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('Test exception')
    except ProgrammingError:
        assert True


# Generated at 2022-06-24 01:17:14.697047
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "Should raise ProgrammingError"

    def should_raise_Programming_Error():
        raise ProgrammingError(msg)

    import pytest
    with pytest.raises(ProgrammingError) as e:
        should_raise_Programming_Error()
    assert msg in str(e.value)


# Generated at 2022-06-24 01:17:18.237948
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "condition")
    assert isinstance(ProgrammingError("message"), ProgrammingError)

# Generated at 2022-06-24 01:17:21.654731
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    assert issubclass(ProgrammingError, Exception)
    assert isinstance(ProgrammingError("Test"), ProgrammingError)
    assert "Test" in str(ProgrammingError("Test"))

# Generated at 2022-06-24 01:17:23.396608
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Foo")


# Generated at 2022-06-24 01:17:23.904775
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-24 01:17:27.402822
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Custom message")


# Generated at 2022-06-24 01:17:31.190475
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "message")
        raise Exception("Failed to raise the expected ProgrammingError exception.")
    except ProgrammingError as err:
        assert str(err) == "message"
    except Exception as err:
        raise err

test_ProgrammingError()

# Generated at 2022-06-24 01:17:35.254535
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc = ProgrammingError()
    assert exc.args == tuple()
    assert exc.__repr__() == "ProgrammingError()"
    assert exc.__str__() == ""

# Generated at 2022-06-24 01:17:38.981369
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test error")
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "Test error"


# Generated at 2022-06-24 01:17:41.944926
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pyparadigm import ProgrammingError

    try:
        ProgrammingError()
    except TypeError:
        assert True
    else:
        assert False

# Test for method ProgrammingError.passert

# Generated at 2022-06-24 01:17:44.600259
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Ouch!")
    except ProgrammingError as e:
        assert "Ouch!" == e.args[0]

# Unit tests for class method passert

# Generated at 2022-06-24 01:17:46.933997
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Test error.")
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()


# Generated at 2022-06-24 01:17:51.201615
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=C0111
    # Test constructor without arguments
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    # Test constructor with message
    try:
        ProgrammingError("Just a message")
    except ProgrammingError:
        pass
    # Test constructor with message and one extra argument
    try:
        ProgrammingError("Just a message", "Some argument")
    except ProgrammingError:
        pass
    # Test constructor with message and two extra arguments
    try:
        ProgrammingError("Just a message", "The first argument", "The second argument")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:17:52.222674
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError

    except ProgrammingError:
        pass



# Generated at 2022-06-24 01:17:55.309806
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message='I\'m an error')
    except ProgrammingError as e:
        assert hasattr(e, 'message')


# Generated at 2022-06-24 01:18:01.048041
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert (e.args[0] == "Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-24 01:18:03.548809
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing passert")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Testing passert"

# Generated at 2022-06-24 01:18:07.186218
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for the constructor of class ProgrammingError."""
    error = ProgrammingError("Error message")
    assert error.args == ("Error message",)
    print("Test of class ProgrammingError: OK")
