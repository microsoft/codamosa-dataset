

# Generated at 2022-06-24 01:08:07.858789
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("this text should be in the exception message")
    except ProgrammingError as e:
        assert "this text should be in the exception message" == str(e)

# Generated at 2022-06-24 01:08:09.773646
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Call to delete when object does not exist.")
    except ProgrammingError as e:
        assert str(e) == "Call to delete when object does not exist."

# Generated at 2022-06-24 01:08:11.521792
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Other test")
    except ProgrammingError as e:
        assert str(e) == "Other test"

# Generated at 2022-06-24 01:08:15.179002
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    assert issubclass(ProgrammingError, Exception)
    assert ProgrammingError.__name__ == "ProgrammingError"
    assert [str(ProgrammingError())] == ["Broken coherence. Check your code against domain logic to fix it."]


# Generated at 2022-06-24 01:08:21.740574
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    # Allowed cases
    try:
        ProgrammingError("Hello, world!")
    except ProgrammingError as e:
        pytest.fail("Programming error has not been raised correctly.")

    # Raising error
    should_fail = lambda: ProgrammingError.passert(condition=False, message="Hello, world!")
    with pytest.raises(ProgrammingError) as e:
        should_fail()
    assert e.value.args[0] == "Hello, world!"

    # Not raising error
    should_pass = lambda: ProgrammingError.passert(condition=True, message="Hello, world!")
    with pytest.raises(ProgrammingError) as e:
        should_pass()
    assert e.value.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:08:31.149653
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as exc:
        assert str(exc) == "Broken coherence. Check your code against domain logic to fix it."

    try:
        raise ProgrammingError("custom message")
    except ProgrammingError as exc:
        assert str(exc) == "custom message"

    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "custom message")
    try:
        ProgrammingError.passert(True, "custom message")
    except ProgrammingError as exc:
        assert str(exc) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:08:39.020515
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Should not fail."):
        ...
    try:
        with ProgrammingError.passert(False, "Should fail."):
            ...
    except ProgrammingError as exception:
        assert str(exception) == 'Should fail.'
    try:
        with ProgrammingError.passert(False, None):
            ...
    except ProgrammingError as exception:
        assert str(exception) == 'Broken coherence. Check your code against domain logic to fix it.'

# Generated at 2022-06-24 01:08:40.720345
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        assert True


# Generated at 2022-06-24 01:08:42.811228
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error message")
    except ProgrammingError as e:
        assert e.args[0] == "Some error message"

# Generated at 2022-06-24 01:08:45.172243
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error has been raised")
    except ProgrammingError as ex:
        print(ex.args[0])


# Generated at 2022-06-24 01:08:48.534067
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error, "Did not create exception instance."


# Generated at 2022-06-24 01:08:52.012232
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Bla")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:08:53.686714
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Foo"):
        pass

if __name__ == "__main__":
    import unittest
    unittest.main(module="pypara.errors.error_definitions")

# Generated at 2022-06-24 01:08:58.312885
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for :py:class:`ProgrammingError` constructor.
    """

    try:

        # this is a coverage improvement for the class definition
        # noinspection PyCallingNonCallable
        ProgrammingError()()

    except TypeError:
        pass

# Generated at 2022-06-24 01:08:59.090175
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "")

# Generated at 2022-06-24 01:09:01.552885
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert(str(e) == 'Broken coherence. Check your code against domain logic to fix it.')
        return True
    return False
assert(test_ProgrammingError())

# Generated at 2022-06-24 01:09:03.146858
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as e:
        ProgrammingError.passert(False, "Condition is not met.")
    assert e.value.args[0] == "Condition is not met."

# Generated at 2022-06-24 01:09:10.292485
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Test message"

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    ProgrammingError.passert(True, None)

# Generated at 2022-06-24 01:09:19.088781
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError()
    assert str(excinfo.value) == "Broken coherence. Check your code against domain logic to fix it."
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError(message="Bad coherence")
    assert str(excinfo.value) == "Bad coherence"
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, message="Bad coherence")
    assert str(excinfo.value) == "Bad coherence"

# Generated at 2022-06-24 01:09:26.145142
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Should not raise any error
    ProgrammingError.passert(1 > 0, "Something went wrong.")

    # Should raise an error
    try:
        ProgrammingError.passert(1 < 0, "Something went wrong.")
    except ProgrammingError:
        pass
    except TypeError:
        raise TypeError("Constructor of class ProgrammingError is broken.")

# Generated at 2022-06-24 01:09:28.295186
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test error message")
    except ProgrammingError as error:
        assert error.__str__() == "Test error message"

# Generated at 2022-06-24 01:09:31.223300
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "The message")
    except ProgrammingError as exception:
        assert str(exception) == "The message", \
            "Message must be the same that was passed to the constructor of class ProgrammingError"
    else:
        assert False, "Error exception not raised"

# Generated at 2022-06-24 01:09:32.729729
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This bothers me")
    except ProgrammingError as ex:
        assert ex.args[0] == "This bothers me"


# Generated at 2022-06-24 01:09:37.031597
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    :py:class:`ProgrammingError` must be able to be created without parameters.
    """
    ProgrammingError()



# Generated at 2022-06-24 01:09:39.950949
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is an error")
    assert error.args[0] == "This is an error"

# Generated at 2022-06-24 01:09:42.177197
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except ProgrammingError as e:
        assert e.args == ("test",)


# Generated at 2022-06-24 01:09:42.756502
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    Programmi

# Generated at 2022-06-24 01:09:45.642291
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for :py:class:`ProgrammingError` constructor.
    """
    error = ProgrammingError("message")
    assert error.args[0] == "message"

# Generated at 2022-06-24 01:09:49.328916
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as exception:
        assert exception.args == ("test",)


# Generated at 2022-06-24 01:09:50.539591
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Test"): pass

# Generated at 2022-06-24 01:09:52.290958
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error in your program")
    except ProgrammingError:
        assert True


# Generated at 2022-06-24 01:09:55.648325
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    passert = ProgrammingError.passert
    try:
        passert(False, "This is a test")
    except Exception:
        assert True
    # It should not do anything when the condition is True
    ProgrammingError.passert(True, "This is a test")

# Generated at 2022-06-24 01:10:00.576838
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test the passert method
    ProgrammingError.passert(True, "")
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    # Test the constructor
    try:
        raise ProgrammingError("Oops")
    except ProgrammingError as e:
        assert str(e) == "Oops"

# Generated at 2022-06-24 01:10:08.629891
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given a sequence of conditions and messages
    conditions = [False, True, False]
    messages = [None, None, "test"]
    # When constructing ProgrammingError
    for condition, message in zip(conditions, messages):
        try:
            # When raising exception
            ProgrammingError.passert(condition, message)
        except ProgrammingError as e:
            # Then expected error is received
            assert e.args[0] == message or "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:10:13.284514
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    try:
        raise ProgrammingError("test message")
    except ProgrammingError as error:
        assert error.args[0] == "test message", "Message not saved"

# Unit test of classmethod passert of class ProgrammingError

# Generated at 2022-06-24 01:10:18.979488
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    def evaluate_ProgrammingError_constructor(message: str) -> None:
        return ProgrammingError(message)

    message = "test"

    # Check that an exception is thrown with a message
    try:
        evaluate_ProgrammingError_constructor(message)
        assert False
    except ProgrammingError as expected:
        assert expected.args[0] == message


# Generated at 2022-06-24 01:10:22.949198
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as error:
        assert error.args[0] == "A message"


# Generated at 2022-06-24 01:10:26.222716
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a ProgrammingError")
    except ProgrammingError as e:
        assert str(e) == "This is a ProgrammingError"

if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-24 01:10:28.524734
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    exc = ProgrammingError("1 + 0 != 2")
    assert "1 + 0 != 2" in str(exc)


# Generated at 2022-06-24 01:10:31.195913
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("programming error")
    except Exception as error:
        assert isinstance(error, ProgrammingError)
        assert error.args[0] == "programming error"
    else:
        raise Exception("expecting an exception")


# Generated at 2022-06-24 01:10:34.408522
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.errors import ProgrammingError

    with raises(ProgrammingError) as exception:
        raise ProgrammingError("test")

    assert str(exception.value) == "test"


# Generated at 2022-06-24 01:10:38.191508
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert any(isinstance(exception, ProgrammingError) for exception in (
        ProgrammingError("It doesn't work!"),
        ProgrammingError(),))
    assert not any(isinstance(exception, ProgrammingError) for exception in (
        Exception("Everything will work!"),
        Exception(),))

# Unit tests for method ProgrammingError.passert()

# Generated at 2022-06-24 01:10:40.386096
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.testing import assert_exception_raised

    assert_exception_raised(lambda: ProgrammingError("message"), error_class=ProgrammingError, error_message="message")


# Generated at 2022-06-24 01:10:43.401327
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("message")
    assert error.args == ("message",)


# Generated at 2022-06-24 01:10:44.117341
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("blah")

# Generated at 2022-06-24 01:10:47.240998
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:10:52.717348
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    ProgrammingError(message="My message")

# Generated at 2022-06-24 01:10:54.227698
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-24 01:10:59.136581
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    # Test standard constructor
    error = ProgrammingError("test")
    assert error.args[0] == "test"

    # Test raise function
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    ProgrammingError.passert(True, None)

# Generated at 2022-06-24 01:11:01.542470
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Oops, programmer error!")
    except ProgrammingError as error:
        assert str(error) == "Oops, programmer error!"



# Generated at 2022-06-24 01:11:03.104384
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    ProgrammingError("test message")


# Generated at 2022-06-24 01:11:05.413688
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "the condition has failed")
    except ProgrammingError as e:
        assert str(e) == "the condition has failed"


# Generated at 2022-06-24 01:11:12.426624
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # This should not raise any exception
    ProgrammingError(None)
    ProgrammingError("")
    ProgrammingError(" ")
    ProgrammingError("_")
    ProgrammingError("_ _")
    # This should raise a ProgrammingError exception
    try:
        ProgrammingError()
        assert False, "The function call above should raise a ProgrammingError exception"
    except ProgrammingError as error:
        assert isinstance(error, ProgrammingError)
        assert str(error) == ""
    # This should raise a ProgrammingError exception
    try:
        ProgrammingError("")
        assert False, "The function call above should raise a ProgrammingError exception"
    except ProgrammingError as error:
        assert isinstance(error, ProgrammingError)
        assert str(error) == ""


# Generated at 2022-06-24 01:11:14.279720
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("test").args[0] == "test"



# Generated at 2022-06-24 01:11:16.572730
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("")
    except:
        pass


# Generated at 2022-06-24 01:11:18.818777
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert str(e) == "Error message"


# Generated at 2022-06-24 01:11:23.721628
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the error on non-string message

    :return: ``None``
    """
    try:
        ProgrammingError(1)
    except ProgrammingError as exception:
        assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("Expected an exception to be raised")

# Generated at 2022-06-24 01:11:29.301688
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert True, "Raising exception did not work."


# Generated at 2022-06-24 01:11:32.194323
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "message")
        assert False
    except ProgrammingError as e:
        assert str(e) == "message"

# Generated at 2022-06-24 01:11:38.315727
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=True, message="")
    except ProgrammingError as e:  # pragma: no cover
        raise AssertionError() from e

    try:
        ProgrammingError.passert(condition=False, message="")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError()

# Generated at 2022-06-24 01:11:39.786251
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()
    with pytest.raises(ProgrammingError):
        ProgrammingError("An error")


# Generated at 2022-06-24 01:11:43.028515
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hello world!")
    except ProgrammingError as e:
        assert e.args[0] == "Hello world!"


# Generated at 2022-06-24 01:11:45.249250
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        assert True
    except AssertionError:
        raise ProgrammingError("some err")

# Generated at 2022-06-24 01:11:56.285156
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase
    from unittest.mock import patch

    class ProgrammingErrorTest(TestCase):
        def test_ProgrammingError(self):
            with patch("pypara.error.ProgrammingError.passert") as mock:
                mock.return_value = None
                try:
                    ProgrammingError.passert(True, "message")
                except ProgrammingError as e:
                    self.fail(msg=f"{e}")

                try:
                    ProgrammingError.passert(False, "message")
                    self.fail(msg="ProgrammingError should have been raised.")
                except ProgrammingError as e:
                    self.assertEqual(e.msg, "message")


# Generated at 2022-06-24 01:11:57.371457
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)


# Generated at 2022-06-24 01:11:59.330678
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test constructor of class ProgrammingError.
    """
    e = ProgrammingError("Test error")
    assert str(e) == "Test error"



# Generated at 2022-06-24 01:12:01.306545
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:12:03.500316
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        return True
    return False

# Test f

# Generated at 2022-06-24 01:12:05.726866
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("testmsg")
    except Exception as e:
        assert str(e) == "testmsg"


# Generated at 2022-06-24 01:12:09.274712
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="A message")
    except ProgrammingError as e:
        assert str(e) == "A message", "Expected: 'A message', but got '{0}'".format(str(e))


# Generated at 2022-06-24 01:12:12.129390
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Custom message")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:12:14.801403
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    error = ProgrammingError("Message")
    assert str(error) == "Message"


# Generated at 2022-06-24 01:12:20.096158
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test ProgrammingError")
    except ProgrammingError as e:
        assert str(e) == "Test ProgrammingError"

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        print(str(e))
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:12:25.155163
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Case 1: Message is empty
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert error.args == ("Broken coherence. Check your code against domain logic to fix it.",)
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."

    # Case 2: Message is not empty
    try:
        raise ProgrammingError("Hi!")
    except ProgrammingError as error:
        assert error.args == ("Hi!",)
        assert str(error) == "Hi!"


# Generated at 2022-06-24 01:12:30.602101
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if :py:class:`ProgrammingError` is raised as expected.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Failed to raise a :py:class:`ProgrammingError`")


# Generated at 2022-06-24 01:12:33.269537
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("Hello")
    assert str(e) == "Hello"

# Generated at 2022-06-24 01:12:35.796112
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    assert issubclass(ProgrammingError, Exception)
    try:
        raise ProgrammingError("test")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:12:42.376937
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    class BrokenCoherence(Exception):
        pass

    def test_function(condition, error):
        ProgrammingError.passert(condition, error)

    # We assume that our test is OK if no exception is thrown.
    test_function(condition=True, error="Dummy")

    # We expect that a ProgrammingError exception is thrown when the condition is False.
    has_raised_exception = False
    try:
        test_function(condition=False, error="Dummy")
    except ProgrammingError:
        has_raised_exception = True

    assert has_raised_exception

# Generated at 2022-06-24 01:12:45.548622
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.", )


# Generated at 2022-06-24 01:12:47.968957
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-24 01:12:49.681139
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert ProgrammingError.__doc__.startswith("Provides a programming error exception")


# Generated at 2022-06-24 01:12:54.813120
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as e:
        assert e.args[0] == "Some message"


# Generated at 2022-06-24 01:13:01.209624
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def test(condition, msg):
        try:
            ProgrammingError.passert(condition, msg)
            assert(False)
        except ProgrammingError:
            # We expect an exception to be raised
            assert(True)

    test(True, "Foo")
    test(False, "Foo")
    test(False, None)
    test(True, None)

# Generated at 2022-06-24 01:13:03.624908
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, None)
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:13:06.166982
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("I am a programming error.")
    except ProgrammingError as e:
        assert str(e) == "I am a programming error."


# Generated at 2022-06-24 01:13:07.304362
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError()
    assert isinstance(err, Exception)


# Generated at 2022-06-24 01:13:14.251886
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    ProgrammingError.passert(True, None)
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as err:
        assert err.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(False, "My error")
    except ProgrammingError as err:
        assert err.args[0] == "My error"

# Generated at 2022-06-24 01:13:17.463690
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError
        assert False, "Expected error"
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:13:21.095295
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Assertion failed.")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert e.args[0] == "Assertion failed."


# Generated at 2022-06-24 01:13:22.828410
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-24 01:13:27.052395
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Error message")
    except ProgrammingError as e:
        assert str(e) == "Error message"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:13:31.147745
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Foobar")
        assert False, "Should have raised an exception"
    except ProgrammingError as e:
        assert str(e) == "Foobar", "Should have raised an exception because the condition is False"

# Generated at 2022-06-24 01:13:33.857317
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError): ProgrammingError(
        "This is an error message")

# Generated at 2022-06-24 01:13:36.234196
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="Hello World")
    except Exception as e:
        assert e.args[0] == "Hello World"


# Generated at 2022-06-24 01:13:40.238506
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Test message")

# Generated at 2022-06-24 01:13:43.660319
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(2*2 == 4, "2*2 is not 4"):
        ...

# Generated at 2022-06-24 01:13:49.813523
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "foo")
    except Exception as e:
        assert(isinstance(e, ProgrammingError))
        assert(str(e) == "foo")
    else:
        assert(False)
    try:
        ProgrammingError.passert(True, "foo")
    except Exception as e:
        assert(False)

# Generated at 2022-06-24 01:13:58.423921
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "message")
        assert False, "Should have raised exception"
    except ProgrammingError as err:
        assert err.args[0] == "message", "Should have provided message for exception"
    try:
        ProgrammingError.passert(False, None)
        assert False, "Should have raised exception"
    except ProgrammingError as err:
        assert err.args[0] == "Broken coherence. Check your code against domain logic to fix it.", \
            "Should have provided default message for exception"
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        assert False, "Should not have raised exception"

# Generated at 2022-06-24 01:14:02.733977
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("This is a test message.")
    except Exception as e:
        assert "This is a test message." == str(e)


# Generated at 2022-06-24 01:14:03.642315
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Should have a string constructor")

# Generated at 2022-06-24 01:14:09.965219
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a message")
        assert False, "Exception expected"
    except ProgrammingError as e:
        assert str(e) == "This is a message", e.args
    try:
        ProgrammingError.passert(False, None)
        assert False, "Exception expected"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it.", e.args

# Generated at 2022-06-24 01:14:12.507468
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except ProgrammingError as error:
        assert error.args[0] == "test"



# Generated at 2022-06-24 01:14:16.774872
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test"


# Generated at 2022-06-24 01:14:23.082115
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("An error message!")
    except ProgrammingError as ex:
        assert ex.message == "An error message!"


# Generated at 2022-06-24 01:14:24.672902
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Testing")


# Generated at 2022-06-24 01:14:26.933889
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:func:`ProgrammingError.passert` function.
    """
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        assert False

# Generated at 2022-06-24 01:14:28.983480
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert False
    except ProgrammingError as e:
        str(e)
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-24 01:14:33.366812
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected_message = str()
    try:
        raise ProgrammingError(expected_message)
    except ProgrammingError as e:
        assert e.args[0] == expected_message
    

# Generated at 2022-06-24 01:14:40.477766
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Expectation message.")
    except ProgrammingError as exc:
        assert False, "ProgrammingError should not be raised when the condition is satisfied."

    try:
        ProgrammingError.passert(False, "Expectation message.")
        assert False, "ProgrammingError should be raised when the condition is not satisfied."
    except ProgrammingError as exc:
        assert str(exc) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:14:46.546213
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "")
        ProgrammingError.passert(True, "OK!")
    except ProgrammingError:
        assert False
    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError:
        assert True
    try:
        ProgrammingError.passert(False, "This is a custom message.")
        assert False
    except ProgrammingError as e:
        assert str(e) == "This is a custom message."

# Generated at 2022-06-24 01:14:56.831307
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test constructor of :py:class:`ProgrammingError`.
    """

    # Raises an error without message
    met = False
    try:
        ProgrammingError.passert(False, "My message")
    except ProgrammingError:
        met = True
    assert met

    # Raises an error with message
    met = False
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
        met = True
    assert met

    # No error is raised
    ProgrammingError.passert(True, None)

# Generated at 2022-06-24 01:15:00.798037
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "TEST")
        assert False, "Exception should have been raised"
    except ProgrammingError as e:
        assert e.args[0] == "TEST", "Unexpected error message"
    assert ProgrammingError("TEST1")
    assert ProgrammingError("TEST2", "TEST3")

# Generated at 2022-06-24 01:15:02.059986
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:15:06.531387
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        return
    raise RuntimeError("Failed to raise an instance of ProgrammingError")

# Generated at 2022-06-24 01:15:11.672177
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.utils import log_exception, log_critical

    # Test of constructor
    exception = ProgrammingError("Testing ProgrammingError 1")
    log_exception(exception)

    try:
        exception = ProgrammingError()
        raise exception
    except ProgrammingError as ex:
        log_critical("Raised ProgrammingError: Identifying message: {0}".format(ex))

# Generated at 2022-06-24 01:15:14.332912
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError._init_(None) is ProgrammingError
    assert ProgrammingError._new_(None) is not ProgrammingError



# Generated at 2022-06-24 01:15:16.943495
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as ex:
        assert "Broken coherence. Check your code against domain logic to fix it." in str(ex)


# Generated at 2022-06-24 01:15:20.497820
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected = "Broken coherence. Check your code against domain logic to fix it."
    got = ProgrammingError.passert(False, None).__str__()
    assert expected == got

# Generated at 2022-06-24 01:15:23.738290
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:15:27.982404
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """

    import pytest

    with pytest.raises(ProgrammingError):
        ProgrammingError()

    with pytest.raises(ProgrammingError, match=r"some message"):
        ProgrammingError("some message")



# Generated at 2022-06-24 01:15:30.805405
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Some message.")
    except ProgrammingError as error:
        assert str(error) == "Some message."

# Generated at 2022-06-24 01:15:34.536460
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Message"):
        pass
    try:
        with ProgrammingError.passert(False, "Message"):
            pass
    except ProgrammingError:
        pass
    else:
        assert False, "Error not raised"


# Generated at 2022-06-24 01:15:37.245099
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A test message")
    except ProgrammingError as e:
        assert e.args[0] == "A test message"



# Generated at 2022-06-24 01:15:40.749818
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "foo")
        raise AssertionError("No exception raised")
    except ProgrammingError as ex:
        assert ex.message == "foo"


# Generated at 2022-06-24 01:15:44.898440
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the class :py:class:`ProgrammingError`.
    """
    ProgrammingError("Test")

# Generated at 2022-06-24 01:15:47.136661
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        return
    assert False, "ProgrammingError did not raise"


if __name__ == "__main__":
    import pytest
    pytest.main([str(__file__.replace("\\", "/")), "-v", "-s"])

# Generated at 2022-06-24 01:15:51.149951
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    # WHEN
    error = ProgrammingError()
    # THEN
    assert isinstance(error, ProgrammingError)
    assert isinstance(error, Exception)


# Generated at 2022-06-24 01:15:54.747450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        ProgrammingError()



# Generated at 2022-06-24 01:15:57.479162
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError.passert(False, 'test') failed")

# Generated at 2022-06-24 01:16:00.292536
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an expected error for testing purposes")
    except ProgrammingError as e:
        assert e.args[0] == "This is an expected error for testing purposes"


# Generated at 2022-06-24 01:16:02.667801
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False

# Generated at 2022-06-24 01:16:07.764309
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:meth:`ProgrammingError.__init__`.
    """
    try:
        raise ProgrammingError("Blah")
    except ProgrammingError as ex:
        assert str(ex) == "Blah"


# Generated at 2022-06-24 01:16:11.999786
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as exception:
        raise ProgrammingError("test")
    assert str(exception.value) == "test"


# Generated at 2022-06-24 01:16:17.307914
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError().args[0] == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(True, "Test ProgrammingError.passert.")
    except Exception as e:
        assert False

    try:
        ProgrammingError.passert(False, "Test ProgrammingError.passert.")
    except ProgrammingError as e:
        assert True
    else:
        assert False

# Generated at 2022-06-24 01:16:18.829749
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    ProgrammingError("This is a ProgrammingError.")


# Generated at 2022-06-24 01:16:20.974257
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Foo")
    except ProgrammingError as e:
        assert e.args[0] == "Foo"


# Generated at 2022-06-24 01:16:25.328607
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    error = ProgrammingError("foo")
    assert str(error) == "foo"



# Generated at 2022-06-24 01:16:27.154461
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Mocked error")
    except ProgrammingError as err:
        assert str(err) == "Mocked error"


# Generated at 2022-06-24 01:16:29.778568
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError) as excinfo:
        ProgrammingError("sample")
    assert excinfo.value.args == ("sample",)


# Generated at 2022-06-24 01:16:33.491631
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError();
    except ProgrammingError as e:
        assert( e.args[0] == "Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-24 01:16:35.268801
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
    

# Generated at 2022-06-24 01:16:37.777785
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error.args == ('Broken coherence. Check your code against domain logic to fix it.',)
    error = ProgrammingError('test')
    assert error.args == ('test',)


# Generated at 2022-06-24 01:16:47.228664
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it.", "ProgrammingError failed"
    else:
        assert False, "ProgrammingError failed"

    try:
        ProgrammingError("Some message")
    except ProgrammingError as e:
        assert str(e) == "Some message", "ProgrammingError failed"
    else:
        assert False, "ProgrammingError failed"

    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        assert False, "ProgrammingError failed"


# Generated at 2022-06-24 01:16:47.726343
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError:
        pass

# Generated at 2022-06-24 01:16:54.908273
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def test_error_message_passert_without_message():
        with pytest.raises(ProgrammingError) as excinfo:
            ProgrammingError.passert(False, '')
        assert str(excinfo.value) == "Broken coherence. Check your code against domain logic to fix it."

    def test_error_message_passert_with_message():
        with pytest.raises(ProgrammingError) as excinfo:
            ProgrammingError.passert(False, 'Error message')
        assert str(excinfo.value) == "Error message"

    test_error_message_passert_without_message()
    test_error_message_passert_with_message()

# Generated at 2022-06-24 01:16:56.118490
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ValueError:
        pass


# Generated at 2022-06-24 01:16:57.847555
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Forced error.")
    except Exception as e:
        assert str(e) == "Forced error."


# Generated at 2022-06-24 01:17:00.534188
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from typing import Callable

    def error_check(check_condition: Callable[[bool, Optional[str]], None],
                    true_result: str, false_result: str) -> None:
        """Asserts that the expected error is raised."""
        check_condition(True, true_result)

        with raises(ProgrammingError, match=false_result):
            check_condition(False, false_result)

    error_check(ProgrammingError.passert, "message", "Broken coherence")

# Generated at 2022-06-24 01:17:04.417137
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError

    except ProgrammingError as e:
        assert "Broken coherence" in str(e)

testProgrammingError = lambda : test_ProgrammingError()


# Generated at 2022-06-24 01:17:09.063754
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:17:11.416096
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is an error")
    except ProgrammingError as e:
        assert "This is an error" in str(e)


# Generated at 2022-06-24 01:17:21.580793
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test to check that the constructor of :py:class:`ProgrammingError` works as expected.

    :raises AssertionError: If the test fails.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        if str(e) != "Broken coherence. Check your code against domain logic to fix it.":
            raise AssertionError("Unexpected error message.")
    ProgrammingError.passert(True, '')
    try:
        ProgrammingError.passert(False, 'This is not a bug.')
        raise AssertionError("ProgrammingError.passert(False, 'This is not a bug.') did not fail.")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:17:23.103077
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except Exception as e:
        assert e.__class__ == ProgrammingError

# Generated at 2022-06-24 01:17:31.057424
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # no message
        ProgrammingError.passert(condition=False, message=None)
        assert False, "ProgrammingError expected but not raised"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    try:
        # with message
        ProgrammingError.passert(condition=False, message="Hello world!")
        assert False, "ProgrammingError expected but not raised"
    except ProgrammingError as e:
        assert str(e) == "Hello world!"

# Generated at 2022-06-24 01:17:34.274330
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "condition not met")

# Generated at 2022-06-24 01:17:37.444851
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a unit test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a unit test"


# Generated at 2022-06-24 01:17:40.033877
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as e:
        assert e.args[0] == "A message"

# Generated at 2022-06-24 01:17:46.787567
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError() has not thrown exception."

    try:
        ProgrammingError("p0")
    except ProgrammingError as ex:
        assert ex.args == ("p0",), "Unexpected arguments in exception."
    else:
        assert False, "ProgrammingError('p0') has not thrown exception."


# Generated at 2022-06-24 01:17:51.128856
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except Exception as ex:
        assert isinstance(ex, ProgrammingError)
        assert str(ex) == "This is a test"


# Generated at 2022-06-24 01:17:52.687757
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as ex:
        assert isinstance(ex, ProgrammingError)


# Generated at 2022-06-24 01:17:55.658553
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN: A message
    msg = "This is my message"

    # THEN: The exception should be raised with that message
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as e:
        assert msg == str(e)


# Generated at 2022-06-24 01:18:02.132470
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for :py:class:`ProgrammingError`.

    The purpose is just to check that the exception is raised properly.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError should be raised"


# Generated at 2022-06-24 01:18:06.584974
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class :py:class:`ProgrammingError`.
    """
    exception = ProgrammingError()
  