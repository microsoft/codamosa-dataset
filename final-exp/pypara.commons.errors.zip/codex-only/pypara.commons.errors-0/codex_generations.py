

# Generated at 2022-06-24 01:08:09.880908
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "error")
        raise Exception("The previous ProgrammingError wasn't raised")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:08:11.927969
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test_ProgrammingError")
    except ProgrammingError as e:
        assert str(e) == "test_ProgrammingError"


# Generated at 2022-06-24 01:08:14.999220
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the constructor of class ProgrammingError does not raise an error.
    """
    try:
        raise ProgrammingError(message="Error message.")
    except ProgrammingError:
        pass
    except:
        assert False, "Unexpected exception"


# Generated at 2022-06-24 01:08:23.857991
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Tests for :py:class:`ProgrammingError` """

    # Normal operation
    try:
        # noinspection PyTypeChecker
        ProgrammingError.passert(False, message="Error message")
        raise Exception("`ProgrammingError.passert` returned without error")
    except ProgrammingError as e:
        assert str(e) == "Error message"

    # Ensure that the message is correctly modified
    try:
        # noinspection PyTypeChecker
        ProgrammingError.passert(False, None)
        raise Exception("`ProgrammingError.passert` returned without error")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:08:29.584427
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, Exception)
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
        assert repr(e) == "<ProgrammingError: 'Broken coherence. Check your code against domain logic to fix it.'>"


# Generated at 2022-06-24 01:08:31.081159
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some random error")
    except ProgrammingError as e:
        assert str(e) == "Some random error"


# Generated at 2022-06-24 01:08:33.804193
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:08:36.468351
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Error")
    except ProgrammingError as e:
        assert str(e) == "Error"
    else:
        assert False, "The exception was not raised."

# Generated at 2022-06-24 01:08:39.621585
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Bad code")
        raise Exception("The previous statement should have failed but ended normally.")
    except ProgrammingError as e:
        assert str(e) == "Bad code"


# Generated at 2022-06-24 01:08:41.758958
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error")
    except ProgrammingError as e:
        assert str(e) == "Some error"

# Generated at 2022-06-24 01:08:43.097917
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("test")

# Generated at 2022-06-24 01:08:44.791769
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)

# Generated at 2022-06-24 01:08:56.399713
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # We expect a ProgrammingError exception
    try:
        raise ProgrammingError(message="A message")
    except ProgrammingError as e:
        assert e.args[0] == "A message", "We expect the message passed to the constructor"

    # No exception expected
    ProgrammingError.passert(True, None)
    try:
        ProgrammingError.passert(True, "A message")
    except ProgrammingError as e:
        assert False, "No exception expected"

    # We expect a ProgrammingError exception
    try:
        ProgrammingError.passert(False, "A message")
        assert False, "Expected a ProgrammingError exception"
    except ProgrammingError as e:
        assert e.args[0] == "A message", "We expect the message passed to the constructor"

    # We expect a ProgrammingError exception

# Generated at 2022-06-24 01:08:57.539879
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)


# Generated at 2022-06-24 01:09:03.884198
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Bad luck!")
    except ProgrammingError as e:
        assert e.args[0] == "Bad luck!"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert "Broken coherence" in e.args[0]
        assert "domain logic" in e.args[0]
        assert "Check your code" in e.args[0]

# Generated at 2022-06-24 01:09:04.871488
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "This is an error message"):
        pass

# Generated at 2022-06-24 01:09:05.863780
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception:
        pass


# Generated at 2022-06-24 01:09:07.888607
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit-test for the constructor of :py:class:`ProgrammingError`.

    :return: ``None``.
    """
    error = ProgrammingError("Believe me")
    assert str(error) == "Believe me"


# Generated at 2022-06-24 01:09:10.781997
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:09:12.502070
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        pass
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("ProgrammingError was not raised.")


# Generated at 2022-06-24 01:09:16.048758
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        pass

# Generated at 2022-06-24 01:09:20.642543
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError` constructor.
    """
    try:
        raise ProgrammingError("test")
    except ProgrammingError as exception:
        assert str(exception) == "test"

    try:
        raise ProgrammingError()
    except ProgrammingError as exception:
        assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-24 01:09:25.349526
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence" in str(e)
        assert "domain logic" in str(e)


# Generated at 2022-06-24 01:09:27.286599
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hello world!")
    except ProgrammingError as e:
        assert str(e) == "Hello world!"


# Generated at 2022-06-24 01:09:29.886543
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    expected = "This is the message."

    # Act
    try:
        raise ProgrammingError(expected)
    except ProgrammingError as error:
        actual = error.args[0]

    # Assert
    assert actual == expected



# Generated at 2022-06-24 01:09:31.193464
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("the message")
    except ProgrammingError as e:
        assert str(e) == "the message"

# Generated at 2022-06-24 01:09:32.747458
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:09:38.387181
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class :py:class:`ProgrammingError`.
    """

    try:
        ProgrammingError()
        assert False
    except ProgrammingError as e:
        assert True
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:09:39.681189
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Kaboom")
    except ProgrammingError as e:
        assert str(e) == "Kaboom"



# Generated at 2022-06-24 01:09:41.922462
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:09:45.262669
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()
    ProgrammingError("bad message")
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("bad message")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:09:49.553828
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    except:
        raise Exception("Failed to recognize a ProgrammingError.")


# Generated at 2022-06-24 01:09:53.025066
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    '''Test: ProgrammingError constructor.'''
    try:
        raise ProgrammingError("message")
    except ProgrammingError as error:
        assert(str(error) == "message")
        assert(error.args == ("message",))
    else:
        assert(False)


# Generated at 2022-06-24 01:09:55.686362
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    "Unit test for constructor of class ProgrammingError"
    err = ProgrammingError(None)
    assert None is err.args
    err = ProgrammingError('foo')
    assert 'foo' is err.args


# Generated at 2022-06-24 01:09:57.681667
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error_message = "My test has failed."
    try:
        raise ProgrammingError(error_message)
    except ProgrammingError as exc:
        assert str(exc) == error_message
    else:
        assert False


# Generated at 2022-06-24 01:09:59.383939
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test message.")
    except ProgrammingError as e:
        print(e)


# Generated at 2022-06-24 01:10:01.101723
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Hello")
    assert error.args == ("Hello",)
    assert str(error) == "Hello"


# Generated at 2022-06-24 01:10:02.994412
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert e.args == ()


# Generated at 2022-06-24 01:10:08.784384
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as exc:
        ProgrammingError.passert(False, "It has been broken")
    assert "It has been broken" in str(exc)
    # Test with no message
    with pytest.raises(ProgrammingError) as exc:
        ProgrammingError.passert(False, None)
    assert "Broken coherence" in str(exc)

# Generated at 2022-06-24 01:10:10.500427
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Test")
    except ProgrammingError:
        pass



# Generated at 2022-06-24 01:10:12.860896
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("GOTCHA!")
    except ProgrammingError as e:
        assert "GOTCHA!" == e.args[0]


# Generated at 2022-06-24 01:10:15.597093
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # To test that things are indeed working as expected.
    ProgrammingError.passert(1 == 2, message="This is a dummy test message")

# Generated at 2022-06-24 01:10:17.415890
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "Something wrong.")

# Generated at 2022-06-24 01:10:18.710821
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-24 01:10:23.595412
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Unit test for constructor of class ProgrammingError """
    error = ProgrammingError("Test error")
    assert error.args and isinstance(error.args, tuple) and len(error.args) and isinstance(error.args[0], str)


# Generated at 2022-06-24 01:10:26.535931
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error message.")
    except ProgrammingError as e:
        assert isinstance(e, Exception)
        assert e.args[0] == "This is a programming error message."



# Generated at 2022-06-24 01:10:29.097763
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, None):
        pass
    try:
        with ProgrammingError.passert(False, "test"):
            pass
    except ProgrammingError as e:
        assert str(e) == "test"

# Generated at 2022-06-24 01:10:34.154103
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def test_passert(condition, message):
        try:
            ProgrammingError.passert(condition, message)
        except ProgrammingError as e:
            assert str(e) == message

    test_passert(True, "This is an error")
    test_passert(False, "This is an error")
    test_passert(False, None)

# Generated at 2022-06-24 01:10:36.321939
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(["foo", "bar"])
        raise AssertionError("ProgrammingError should take strings")
    except TypeError:
        pass


# Generated at 2022-06-24 01:10:39.062666
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test of :py:class:`ProgrammingError`"""
    try:
        raise ProgrammingError("Test")
    except ProgrammingError:
        return
    raise Exception("Expected exception ProgrammingError was not raised.")


# Generated at 2022-06-24 01:10:43.078359
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test without arguments
    try:
        raise ProgrammingError()
    except ProgrammingError:
        # OK
        pass
    else:
        assert False

    # Test with a message
    try:
        raise ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as error:
        assert error.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    else:
        assert False


# Generated at 2022-06-24 01:10:44.502653
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-24 01:10:47.871051
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert(error.args[0] == "Broken coherence. Check your code against domain logic to fix it.")



# Generated at 2022-06-24 01:10:52.500135
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)

# Generated at 2022-06-24 01:10:53.556133
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("Hello")
    assert str(e) == "Hello"

# Generated at 2022-06-24 01:10:55.633953
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "message")
    except ProgrammingError as err:
        assert str(err) == "message"



# Generated at 2022-06-24 01:10:57.914795
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for the constructor of the class `ProgrammingError`.
    """
    try:
        ProgrammingError()
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:11:00.543583
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="This is an exception")
    except ProgrammingError:
        assert True
    else:
        assert False, "ProgrammingError was not raised"


# Generated at 2022-06-24 01:11:02.349797
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-24 01:11:05.660792
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    # Specific message
    try:
        raise ProgrammingError("testing failure")
    except ProgrammingError as e:
        assert e.args[0] == "testing failure"


# Generated at 2022-06-24 01:11:07.316370
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="This is a sample exception")
    except ProgrammingError as e:
        assert e.args[0] == "This is a sample exception"

# Generated at 2022-06-24 01:11:12.364983
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test constructor of class ProgrammingError."""
    try:
        ProgrammingError.passert(False, "foo")
        assert False
    except ProgrammingError as ex:
        assert ex.args[0] == "foo"

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as ex:
        assert ex.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(True, None)
    except:
        assert False

# Generated at 2022-06-24 01:11:21.700704
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if :py:class:`ProgrammingError` behaves as documented.
    """
    try:
        ProgrammingError.passert(False, "It failed.")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(False, None)  # This is the same.
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    ProgrammingError.passert(True, "It failed.") # This is OK.

# Generated at 2022-06-24 01:11:27.117645
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "this should not be fulfilled")
        assert False, "ProgrammingError.passert should have been raised"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:11:28.803397
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-24 01:11:33.553994
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        with ProgrammingError.passert(True, None):
            pass
    except ProgrammingError:
        assert False
    try:
        with ProgrammingError.passert(False, "This is an error!"):
            pass
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "This is an error!"

# Generated at 2022-06-24 01:11:35.412521
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()
    ProgrammingError(None)
    ProgrammingError('')
    ProgrammingError('something')
    

# Generated at 2022-06-24 01:11:39.883270
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-24 01:11:42.480972
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except Exception as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-24 01:11:46.355760
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as pe:
        assert pe.args == ("Test message",)
    else:
        assert False, "ProgrammingError should have been raised"


# Generated at 2022-06-24 01:11:55.854842
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError("test")
    except Exception as e:
        assert str(e) == "test"
    try:
        ProgrammingError.passert(False, "test")
    except Exception as e:
        assert str(e) == "test"
    try:
        ProgrammingError.passert(False, None)
    except Exception as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(True, None)
    except Exception as e:
        assert False

# Generated at 2022-06-24 01:11:56.583741
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test")


# Generated at 2022-06-24 01:11:57.938603
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    n = ProgrammingError("some error")
    assert str(n) == "some error"


# Generated at 2022-06-24 01:12:00.431153
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        1 / 0
    except ZeroDivisionError:
        ProgrammingError.passert(False, "Division by zero")
    try:
        1 / 0
    except ZeroDivisionError:
        ProgrammingError.passert(True, "Division by zero")

# Generated at 2022-06-24 01:12:06.335320
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """

    """
    try:
        # Ensure that we raise the error when condition is not met
        ProgrammingError.passert(False, "test")
    except ProgrammingError as ex:
        # Make sure that we pass the message properly
        assert str(ex) == "test"
    else:
        assert False

    # Ensure that we do not raise the error when condition is met
    ProgrammingError.passert(True, "test")

# Generated at 2022-06-24 01:12:12.482694
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Should not be raised.")
    except:
        raise AssertionError()
    try:
        ProgrammingError.passert(False, "Should be raised.")
    except:
        pass
    else:
        raise AssertionError()
    try:
        ProgrammingError.passert(False, None)
    except:
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-24 01:12:14.344045
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Forced error by unit test")

# Generated at 2022-06-24 01:12:16.840367
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="message")
        assert True
    except ProgrammingError as e:
        assert False, "ProgrammingError raised when it should not have been"
    except Exception as e:
        assert False, "ProgrammingError raised when it should not have been"


# Generated at 2022-06-24 01:12:24.164546
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Type checking for class constructor
    assert issubclass(ProgrammingError, Exception)
    assert len(ProgrammingError.__init__.__code__.co_varnames) == 2
    assert len(ProgrammingError.__init__.__code__.co_argcount) == 2
    assert issubclass(ProgrammingError.__init__.__annotations__["condition"], bool)
    assert type(ProgrammingError.__init__.__annotations__["message"]) is type and issubclass(ProgrammingError.__init__.__annotations__["message"], str) and issubclass(ProgrammingError.__init__.__annotations__["message"], object)

# Generated at 2022-06-24 01:12:26.442002
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Message")


# Generated at 2022-06-24 01:12:30.377277
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as exc:
        assert exc.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-24 01:12:33.845419
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-24 01:12:37.787219
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert callable(ProgrammingError)
    assert callable(ProgrammingError.passert)
    try:
        ProgrammingError.passert(False, "This assertion must fail")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:12:40.039121
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something is wrong")
    except ProgrammingError as e:
        assert(e.args[0] == "Something is wrong")


# Generated at 2022-06-24 01:12:42.147060
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "This is a message."
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as err:
        assert msg == str(err)

# Generated at 2022-06-24 01:12:45.001735
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        assert True
    try:
        ProgrammingError.passert(False, "My message")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "My message"

# Generated at 2022-06-24 01:12:48.815417
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Not met"):
        pass


# Generated at 2022-06-24 01:12:49.674910
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test message")

# Generated at 2022-06-24 01:12:54.032482
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "This is an error message")

# Generated at 2022-06-24 01:12:56.972807
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    assert ProgrammingError("msg1").__str__() == "msg1"
    assert ProgrammingError("msg2").__repr__() == "msg2"
    assert ProgrammingError(" ").__repr__() == " "
    assert ProgrammingError("").__repr__() == ""
    assert ProgrammingError("\\n").__repr__() == "\\n"


# Generated at 2022-06-24 01:12:59.250064
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-24 01:13:05.209406
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the :py:class:`ProgrammingError` constructor and the :py:meth:`ProgrammingError.passert` method.
    """

    # Test constructor
    try:
        raise ProgrammingError(
            "This is a custom error exception raised because of a programming error.")
    except ProgrammingError as e:
        assert str(e) == "This is a custom error exception raised because of a programming error."

    # Test passert
    try:
        ProgrammingError.passert(False, "Error Message")
    except ProgrammingError as e:
        assert str(e) == "Error Message"


test_ProgrammingError()

# Generated at 2022-06-24 01:13:06.560698
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "test")

# Generated at 2022-06-24 01:13:10.151328
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("error message")
    except ProgrammingError as e:
        assert str(e) == "error message"

# Generated at 2022-06-24 01:13:11.682817
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Foo")
    except ProgrammingError as e:
        assert e.args[0] == "Foo"


# Generated at 2022-06-24 01:13:14.218544
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message")
    except Exception as e:
        assert(isinstance(e, ProgrammingError))
        assert(type(e) == ProgrammingError)
        assert(str(e) == "Message")


# Generated at 2022-06-24 01:13:20.950188
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert isinstance(ex, Exception)
        assert str(ex) == ""
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as ex:
        assert isinstance(ex, Exception)
        assert str(ex) == "This is a test"


# Generated at 2022-06-24 01:13:23.420472
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Something has gone wrong!")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Something has gone wrong!"

# Generated at 2022-06-24 01:13:27.099264
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, None):
        pass
    try:
        with ProgrammingError.passert(False, None):
            pass
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:13:29.684924
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("A random message")
    except ProgrammingError as e:
        assert str(e) == "A random message"

# Generated at 2022-06-24 01:13:33.251262
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    try:
        ProgrammingError.passert(False, "Test error")
    except ProgrammingError as err:
        assert(err.args[0] == "Test error")

# Generated at 2022-06-24 01:13:36.060092
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("Message")
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Message")


# Generated at 2022-06-24 01:13:37.839623
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('Testing exception')
    except ProgrammingError as e:
        assert str(e) == 'Testing exception'


# Generated at 2022-06-24 01:13:41.232370
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:13:46.567501
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from .Debug import assert_tested

    with raises(ProgrammingError):
        raise ProgrammingError("Cannot have this")

    assert_tested(__name__, "ProgrammingError")

# Generated at 2022-06-24 01:13:50.395205
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # test class constructor
    error = ProgrammingError()
    assert error.args == ('Broken coherence. Check your code against domain logic to fix it.',)
    assert str(error) == 'Broken coherence. Check your code against domain logic to fix it.'


# Generated at 2022-06-24 01:13:54.250267
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"

# Generated at 2022-06-24 01:14:01.891485
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error.__doc__ == "Provides a programming error exception.\n\n    The rationale for this exception is to raise them whenever we rely on meta-programming and the programmer has\n    introduced a statement which breaks the coherence of the domain logic.\n    "
    assert error.__cause__ is None
    assert error.__context__ is None
    assert error.__traceback__ is None
    assert str(error) == ""


# Generated at 2022-06-24 01:14:08.956045
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Testing this error by assertion")
        assert False
    except ProgrammingError:
        assert True
    except Exception:
        assert False
    try:
        ProgrammingError.passert(condition=True, message="Testing this error by assertion")
        assert True
    except Exception:
        assert False
    try:
        ProgrammingError.passert(condition=True, message=None)
        assert True
    except Exception:
        assert False

# Generated at 2022-06-24 01:14:15.279562
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test constructor of class ProgrammingError.
    """
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "Test assumption 1")
    assert str(excinfo.value) == "Test assumption 1"

    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "Test assumption 2")
    assert str(excinfo.value) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:14:16.507817
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Any meaningful message you want here")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:14:18.542196
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("")
    except Exception as ex:
        assert ex.args == ("", )


# Generated at 2022-06-24 01:14:22.557001
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as err:
        assert(str(err) == "Error message")



# Generated at 2022-06-24 01:14:27.429167
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a message.")
    except ProgrammingError as e:
        assert e.args[0] == "This is a message."


# Generated at 2022-06-24 01:14:29.797629
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test exception raised."):
        pass

# Generated at 2022-06-24 01:14:32.917577
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args == ("Test",)


# Generated at 2022-06-24 01:14:36.758577
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        raise AssertionError("ProgrammingError constructor should raise TypeError in default constructor")
    except TypeError:
        pass


# Generated at 2022-06-24 01:14:41.494370
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("any")
    except ProgrammingError:
        pass

    try:
        raise ProgrammingError("any", "value")
    except ProgrammingError:
        pass

    try:
        raise ProgrammingError("any", "value", "as", "tuple")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:14:47.432578
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the functionality and functionality of the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"

    # Test default message
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:14:51.995915
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert False
    except ProgrammingError as e:
        assert str(e) == 'Broken coherence. Check your code against domain logic to fix it.'


# Generated at 2022-06-24 01:14:54.994871
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the constructor of :py:class:`ProgrammingError`.
    """
    error = ProgrammingError("message")

    assert error.args == ("message", )

# Generated at 2022-06-24 01:14:59.440276
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError("This is a programming error.")

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "This is a programming error.")

    # Testing that it works when the condition is true
    ProgrammingError.passert(True, "This is a programming error.")

# Generated at 2022-06-24 01:15:01.824894
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "x")
    except ProgrammingError as pe:
        assert str(pe) == "x"
        return
    except Exception:
        assert False

# Generated at 2022-06-24 01:15:13.044951
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    passert = ProgrammingError.passert
    #
    passert(True, "")  # Just to check that true conditions are ok
    #
    try:
        passert(False, "")  # Just to check that false conditions raise ProgrammingError without message
        assert False
    except ProgrammingError:
        pass
    #
    message = "Test message"
    try:
        passert(False, message)  # Just to check that false conditions raise ProgrammingError with message
        assert False
    except ProgrammingError as e:
        assert e.args[0] == message
    try:
        passert(False, "")  # Just to check that false conditions raise ProgrammingError without message
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:15:16.695216
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # ProgramError is subtype of Exception
    assert issubclass(ProgrammingError, Exception)
    # ProgramError instance is subtype of Exception
    e = ProgrammingError("foo")
    assert isinstance(e, Exception)


# Generated at 2022-06-24 01:15:21.694756
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something went wrong. Check the message for details.")
    except ProgrammingError as e:
        assert str(e) == "Something went wrong. Check the message for details."
        assert repr(e) == "ProgrammingError(Something went wrong. Check the message for details.)"


# Generated at 2022-06-24 01:15:24.182381
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-24 01:15:27.972420
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False
    finally:
        pass


# Generated at 2022-06-24 01:15:30.805255
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as e:
        assert str(e) == "Some message", "ProgrammingError.__init__() is broken."

# Generated at 2022-06-24 01:15:33.376935
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises    # type: ignore

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "This is a fake error")



# Generated at 2022-06-24 01:15:44.735871
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    programming_error_message = "Broken coherence. Check your code against domain logic to fix it."

    # Act & Assert
    try:
        raise ProgrammingError("Hard-coded message")
    except ProgrammingError as ex:
        assert str(ex) == "Hard-coded message"

    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert str(ex) == programming_error_message

    try:
        ProgrammingError.passert(False, "Message from condition")
    except ProgrammingError as ex:
        assert str(ex) == "Message from condition"

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as ex:
        assert str(ex) == programming_error_message


# Generated at 2022-06-24 01:15:50.932849
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    message = "This is a message"

    # Act & Assert
    try:
        raise ProgrammingError(message)
    except ProgrammingError as ex:
        assert str(ex) == message


# Generated at 2022-06-24 01:15:54.695124
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Some message"):
        pass


# Generated at 2022-06-24 01:16:00.509710
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): # type: (...) -> None
    """
    Unit test for class :py:class:`ProgrammingError`.
    """
    try:
        # Test assertion with wrong condition
        ProgrammingError.passert(condition=False, message="wrong condition")
        assert False
    except ProgrammingError:
        pass

    try:
        # Test assertion with correct condition
        ProgrammingError.passert(condition=True, message="correct condition")
        pass
    except ProgrammingError:
        assert False

# Generated at 2022-06-24 01:16:03.214283
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error")
        assert False
    except ProgrammingError:
        assert True


# Generated at 2022-06-24 01:16:06.298057
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("Test error")
    assert str(exception) == "ProgrammingError: Test error"



# Generated at 2022-06-24 01:16:09.745382
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an expected exception!")
    except ProgrammingError as ex:
        assert isinstance(ex, ProgrammingError)


# Generated at 2022-06-24 01:16:14.185607
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Asserts that the constructor of :py:class:`ProgrammingError` raises an assertion error."""
    from contextlib import suppress

    with suppress(ProgrammingError):
        ProgrammingError.passert(False, "Expected failure")
    with suppress(ProgrammingError):
        ProgrammingError.passert(True, "Not expected failure")

# Generated at 2022-06-24 01:16:20.049556
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=unused-variable, expression-not-assigned, pointless-statement
    try:
        raise ProgrammingError("This is a programming error.")
    except ProgrammingError as e:
        assert "This is a programming error." == str(e)

# Generated at 2022-06-24 01:16:24.416614
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert isinstance(ex, Exception)


# Generated at 2022-06-24 01:16:28.952482
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "Some coherence problem")

    assert "Some coherence problem" in str(excinfo.value)

    with raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, None)

    assert "Broken coherence" in str(excinfo.value)

# Generated at 2022-06-24 01:16:34.164254
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        err = ProgrammingError()
    except ProgrammingError as ex:
        assert ex.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    try:
        err = ProgrammingError("test message")
    except ProgrammingError as ex:
        assert ex.args[0] == "test message"


# Generated at 2022-06-24 01:16:37.065310
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    ProgrammingError.passert(condition=True, message="")

# Generated at 2022-06-24 01:16:42.483531
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error message")
    except ProgrammingError as e:
        assert str(e) == "Programming error message"
        assert type(e) == ProgrammingError


# Generated at 2022-06-24 01:16:45.248995
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Failed to raise ProgrammingError"


# Generated at 2022-06-24 01:16:47.807510
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert "Test" == str(e)


# Generated at 2022-06-24 01:16:51.158740
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    # Act
    with ProgrammingError as e:
        # Assert
        assert hasattr(e, "args"), "Exception should have attribute 'args'."
        assert len(e.args) == 0, "Exception should not have arguments."


# Generated at 2022-06-24 01:16:55.973058
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert.assert_raises(ProgrammingError):
        ProgrammingError.passert(False, "This message is not expected to be raised.")

# Generated at 2022-06-24 01:16:58.573077
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "my message")
    except ProgrammingError as error:
        assert error.args[0] == "my message", "An error with a message should be raised."


# Generated at 2022-06-24 01:17:00.305416
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test error")
    except ProgrammingError as e:
        assert str(e) == "Test error"


# Generated at 2022-06-24 01:17:02.490266
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("The test succeeds")


# Generated at 2022-06-24 01:17:08.933278
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Should not throw any error
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        assert False

    try:
        # Should throw a Programming Error
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError:
        assert True


# Generated at 2022-06-24 01:17:11.287490
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("my message")
        assert True
    except ProgrammingError as e:
        assert False
        assert e.message == "my message"



# Generated at 2022-06-24 01:17:18.228271
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Error message")
    except ProgrammingError as ex:
        # Check exception message
        assert ex.args[0] == "Error message"
    else:
        raise AssertionError("Expected exception ProgrammingError not raised")
    try:
        ProgrammingError.passert(True, "Error message")
    except ProgrammingError:
        raise AssertionError("Unexpected exception ProgrammingError raised")

# Generated at 2022-06-24 01:17:20.958449
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Expected exception ProgrammingError to be raised")


# Generated at 2022-06-24 01:17:24.671475
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # If we don't pass a message, we will get a generic one.
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence" in str(e)
    # If we pass a message, we will get the specific one.
    try:
        raise ProgrammingError("Hello")
    except ProgrammingError as e:
        assert str(e) == "Hello"

# Generated at 2022-06-24 01:17:30.092542
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`.
    """
    message = "This is an error message"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as ex:
        assert ex.args[0] == message


# Generated at 2022-06-24 01:17:34.147896
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara import ProgrammingError
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "The condition is not met.")

# Generated at 2022-06-24 01:17:39.178053
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        # Test that the exception is raised.
        assert True
        # Test that the error message is correctly set by the constructor.
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)


# Generated at 2022-06-24 01:17:40.265689
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(None)


# Generated at 2022-06-24 01:17:41.944771
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        pass


# Generated at 2022-06-24 01:17:45.575276
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("My error message")
    assert exception.args == ("My error message",)


# Generated at 2022-06-24 01:17:50.729160
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.errors import ProgrammingError
    with raises(ProgrammingError):
        raise ProgrammingError("Some error message")


# Generated at 2022-06-24 01:17:54.844271
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:17:57.244854
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except Exception as e:
        assert str(e) == "test"


# Generated at 2022-06-24 01:18:01.089809
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()


# Generated at 2022-06-24 01:18:03.208293
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expect_error = ProgrammingError("foo")
    assert str(expect_error) == "<ProgrammingError: 'foo'>"


# Generated at 2022-06-24 01:18:06.654349
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError()
    assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."
