

# Generated at 2022-06-24 01:08:09.635186
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError) as e:
        ProgrammingError("Unit test")
    assert 'Unit test' in str(e.value)


# Generated at 2022-06-24 01:08:16.146054
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "this test is expected to fail")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "this test must fail"
    ProgrammingError.passert(True, "this test is not expected to fail")

# Generated at 2022-06-24 01:08:17.861509
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an error.")
    except ProgrammingError as ex:
        assert str(ex) == "This is an error."



# Generated at 2022-06-24 01:08:19.035866
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        assert True


# Generated at 2022-06-24 01:08:19.935620
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Testing that the description can be included")


# Generated at 2022-06-24 01:08:23.137120
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Just a testing error")
    except ProgrammingError as e:
        assert e.args[0] == "Just a testing error"
    try:
        raise ProgrammingError(message="Just a testing error")
    except ProgrammingError as e:
        assert e.args[0] == "Just a testing error"


# Generated at 2022-06-24 01:08:27.927053
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 01:08:30.019313
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("error")

    assert error.args[0] == "error"

    error = ProgrammingError()

    assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-24 01:08:32.381944
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("error")
        assert False
    except ProgrammingError as ex:
        assert str(ex) == "error"


# Generated at 2022-06-24 01:08:36.675159
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "You shall not pass!")
        assert False
    except ProgrammingError as e:
        assert str(e) == "You shall not pass!"

# Generated at 2022-06-24 01:08:39.049605
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is a messaging test")
    except ProgrammingError as e:
        assert e.args[0] == "This is a messaging test"
    else:
        assert False, "Expected a ProgrammingError exception!"


# Generated at 2022-06-24 01:08:41.513346
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Impossible")
    except ProgrammingError as e:
        assert str(e) == "Impossible"


# Generated at 2022-06-24 01:08:45.360720
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert "Broken coherence. Check your code against domain logic to fix it." in str(e)
    else:
        assert False, "ProgrammingError not raised"


# Generated at 2022-06-24 01:08:48.576892
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "message"
    error = ProgrammingError(message)
    assert (message == error.message)



# Generated at 2022-06-24 01:08:53.303329
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("my message")
    except Exception as ex:
        err = ex
    assert err.__class__.__name__ == "ProgrammingError"
    assert err.args[0] == "my message"

# Generated at 2022-06-24 01:08:56.499376
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("test")
    assert str(err) == "test"


# Generated at 2022-06-24 01:08:58.759807
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.

    :return: ``None``
    """
    ProgrammingError("")
    ProgrammingError(None)

# Generated at 2022-06-24 01:09:02.028863
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as err:
        assert str(err) == "A message"
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert str(err) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:09:06.177235
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error!")
    except ProgrammingError as pe:
        pass # Normal execution
    assert(True)

# Generated at 2022-06-24 01:09:07.510010
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("any message")
    except ProgrammingError as e:
        assert str(e) == "any message"



# Generated at 2022-06-24 01:09:08.733311
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test message")
    except ProgrammingError as ex:
        assert str(ex) == "test message"



# Generated at 2022-06-24 01:09:09.920572
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert repr(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:09:11.329360
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:09:14.523860
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming errors are expected here")
    except ProgrammingError as e:
        assert e.args == ("Programming errors are expected here",)


# Generated at 2022-06-24 01:09:19.520273
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.

    The test verifies that an instance of this exception can be created with custom messages.

    :return: ``None``
    """
    error = ProgrammingError("Test case message.")
    assert error.args == ("Test case message.",)

# Generated at 2022-06-24 01:09:20.648133
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("test")

# Generated at 2022-06-24 01:09:26.743370
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    condition = True
    message = "Just a message"
    try:
        ProgrammingError.passert(condition, message)
    except ProgrammingError as e:
        assert str(e) == message
        assert isinstance(e, Exception)
        assert isinstance(e, ProgrammingError)
    else:
        assert not condition


# Generated at 2022-06-24 01:09:27.573037
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)


# Generated at 2022-06-24 01:09:29.939068
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test the constructor of class :py:class:`ProgrammingError`."""
    error = ProgrammingError("Foo")
    assert isinstance(error, ProgrammingError)
    assert "Foo" in str(error)


# Generated at 2022-06-24 01:09:30.331394
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-24 01:09:31.163931
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Programming error"):
        pass

# Generated at 2022-06-24 01:09:32.704509
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "a message"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as err:
        assert message == err.args[0]


# Generated at 2022-06-24 01:09:36.480166
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("Expected value must be non-negative.")



# Generated at 2022-06-24 01:09:39.756654
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        raise ProgrammingError("Testing.")

# Generated at 2022-06-24 01:09:42.807781
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:09:45.694797
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Just a test")
    except ProgrammingError as e:
        assert str(e) == "Just a test"



# Generated at 2022-06-24 01:09:56.307396
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # region test constructor
    # test if the constructor works with no arguments
    # this is not a good test because the derived class is not tested
    ProgrammingError()

    # test if the constructor raises an exception
    # this is not a good test because the derived class is not tested
    # noinspection PyTypeChecker
    try:
        # noinspection PyTypeChecker
        ProgrammingError(1.0, 2.0)
        assert False, "ProgrammingError must raise TypeError if constructor parameters are invalid, but no error was raised"
    except TypeError:
        pass
    # endregion

    # region test passert
    # test if the condition is False and the message is None, so ProgrammingError raises

# Generated at 2022-06-24 01:09:58.743219
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:10:01.101214
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for the constructor of class :py:class:`ProgrammingError`."""
    error = ProgrammingError("Foo bar")
    assert str(error) == "Foo bar"


# Generated at 2022-06-24 01:10:04.797998
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-24 01:10:06.683669
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("Programming error")



# Generated at 2022-06-24 01:10:11.156031
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test ProgrammingError constructor"):
        assert False


# Generated at 2022-06-24 01:10:15.116930
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Broken coherence!")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:10:19.285101
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
        assert False, "No exception raised"
    except ProgrammingError as e:
        assert "Broken coherence" in e.args[0], "Raised an exception but the message does not contain 'broken coherence'"


# Generated at 2022-06-24 01:10:20.985452
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError



# Generated at 2022-06-24 01:10:25.584366
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Verifies that a :py:class:`ProgrammingError` is properly instantiated.
    """
    try:
        raise ProgrammingError("Something went wrong")
    except ProgrammingError as e:
        assert e.args is not None
        assert len(e.args) == 1
        assert e.args[0] == "Something went wrong"

# Generated at 2022-06-24 01:10:27.951203
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pyassert import that

    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        that(e).has_message("Test message")
        that(e).is_instance_of(ProgrammingError)
        that(e).is_instance_of(Exception)


# Generated at 2022-06-24 01:10:32.089139
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():  # pragma: no cover
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:10:36.639664
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass



# Generated at 2022-06-24 01:10:40.217283
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "input")
        assert False  # Should not be reached
    except ProgrammingError as e:
        assert e.__str__() == "input"

    try:
        ProgrammingError.passert(True, "input")
    except ProgrammingError:
        assert False  # Should not be reached

# Generated at 2022-06-24 01:10:45.439363
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    error = ProgrammingError("some message")
    assert str(error) == "some message"



# Generated at 2022-06-24 01:10:49.322971
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise Exception


# Generated at 2022-06-24 01:10:52.862482
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-24 01:10:55.595540
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some test message")
    except ProgrammingError as err:
        assert str(err) == "Some test message"
        assert repr(err) == "ProgrammingError(Some test message)"


# Generated at 2022-06-24 01:11:04.241658
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.core.exceptions import ProgrammingError
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert issubclass(ProgrammingError, Exception), \
            "The raised error is not of the expected type"
        assert err.__cause__ is None, "The __cause__ attribute is not properly initialized"
        assert err.__context__ is None, "The __context__ attribute is not properly initialized"
        assert len(err.args) == 0, "The init signature is not properly initialized"
        assert err.__str__() == "", "The __str__() method is not properly working"
        assert not err.__suppress_context__, "The __suppress_context__ attribute is not properly initialized"
        assert err.__traceback__ is not None, "The __traceback__ attribute is not properly initialized"

# Generated at 2022-06-24 01:11:07.096250
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an expected error")
    except ProgrammingError as err:
        assert str(err) == "This is an expected error"
    else:
        raise AssertionError("Expected exception not raised")


# Generated at 2022-06-24 01:11:08.247185
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Boo")

# Generated at 2022-06-24 01:11:14.528501
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyBroadException
    try:
        ProgrammingError("")
        ProgrammingError(None)
        ProgrammingError(1)
        ProgrammingError(1.0)
        ProgrammingError({"a": "b"})
    except:
        raise AssertionError("Expected that no exception would be raised.")

# Generated at 2022-06-24 01:11:17.815769
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True


# Generated at 2022-06-24 01:11:19.939182
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Any message")
    except Exception as ex:
        assert ProgrammingError.__name__ in str(ex)

# Generated at 2022-06-24 01:11:22.273307
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hello world")
    except ProgrammingError as e:
        assert isinstance(e, AssertionError)



# Generated at 2022-06-24 01:11:22.909099
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Yo")

# Generated at 2022-06-24 01:11:24.210566
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("test")
    assert str(error) == "test"

# Generated at 2022-06-24 01:11:30.390323
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit testing for :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Something bad happened...")
    except ProgrammingError as e:
        assert str(e) == "Something bad happened..."

# Generated at 2022-06-24 01:11:33.168095
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check that the error can be raised
    try:
        raise ProgrammingError("This is the message")
    except ProgrammingError as err:
        assert str(err) == "This is the message"

# Generated at 2022-06-24 01:11:36.646915
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Tests the behavior of the constructor of class ProgrammingError. """
    with pytest.raises(ProgrammingError):
        ProgrammingError()
    with pytest.raises(ProgrammingError, match="Test message"):
        ProgrammingError("Test message")
    with pytest.raises(ProgrammingError, match="Test message"):
        ProgrammingError(message="Test message")
    with pytest.raises(ProgrammingError, match="Test message"):
        ProgrammingError(description="Test message")


# Generated at 2022-06-24 01:11:38.824433
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        return
    assert False


# Generated at 2022-06-24 01:11:42.381022
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("Arbitrary message.")
    assert exception.args == ("Arbitrary message.",)
    assert str(exception) == "Arbitrary message."

# Generated at 2022-06-24 01:11:44.779110
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Expectation not met.")

# Generated at 2022-06-24 01:11:46.785753
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"


# Generated at 2022-06-24 01:11:52.889581
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # This test serves as documentation on how to use the exception.
    # noinspection PyUnusedLocal
    try:
        ProgrammingError.passert(False, "This is wrong")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    # noinspection PyStatementEffect
    ProgrammingError.passert(True, "This is wrong")

# Generated at 2022-06-24 01:11:55.655992
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(condition=False, message="")

    # To pass the test, just don't raise.
    ProgrammingError.passert(condition=True, message="")

# Generated at 2022-06-24 01:12:00.737576
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True


# Generated at 2022-06-24 01:12:06.909231
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` constructor and :py:class:`ProgrammingError.passert`.
    """

    def dummy_method() -> None:
        raise ProgrammingError("Must not happen.")

    try:
        ProgrammingError.passert(False, "Testing the exception.")
    except ProgrammingError as err:
        assert err.args[0] == "Testing the exception."
    else:
        raise

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as err:
        assert err.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise

    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        raise


# Generated at 2022-06-24 01:12:08.021266
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError:
        raise ProgrammingError
    with ProgrammingError:
        raise ProgrammingError("Ooops!")


# Generated at 2022-06-24 01:12:11.493505
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for the constructor of class ProgrammingError"""
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Foo")

# Generated at 2022-06-24 01:12:16.979859
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is a test")
    assert str(error) == "This is a test"
    error.passert(True, "This is a test")
    try:
        error.passert(False, "This is a test")
        assert False  # pragma: no cover
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:12:20.613676
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    else:
        assert False, "Constructor of class ProgrammingError does not work"


# Generated at 2022-06-24 01:12:22.912935
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expect = "Broken coherence. Check your code against domain logic to fix it."
    actual = ProgrammingError.passert(False, None)
    assert actual.__str__() == expect

# Generated at 2022-06-24 01:12:25.699455
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error_message = "An error message."
    error = ProgrammingError(error_message)

    assert repr(error) == f"ProgrammingError({error_message})"


# Generated at 2022-06-24 01:12:30.377147
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit-test for the constructor of :py:class:`ProgrammingError`
    """
    err = ProgrammingError()

    assert isinstance(err, ProgrammingError)
    assert isinstance(err, Exception)


# Generated at 2022-06-24 01:12:33.566472
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-24 01:12:38.172987
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as ex:
        assert(ex.args[0] == "Broken coherence. Check your code against domain logic to fix it.")
        assert(isinstance(ex, Exception))
    else:
        assert(False)

# Generated at 2022-06-24 01:12:43.769416
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # We do not need to test that it can be instantiated, due to its simple nature.
    # We just need to test that it receives the message properly.
    try:
        raise ProgrammingError("It's broken.")
    except ProgrammingError as e:
        assert e.args[0] == "It's broken."


# Generated at 2022-06-24 01:12:50.747879
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error1 = ProgrammingError("message")
    error2 = ProgrammingError(None)
    assert str(error1) == "Broken coherence. Check your code against domain logic to fix it. Particular message: message"
    assert str(error2) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:12:58.820724
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    success = False
    try:
        raise ProgrammingError("Programmer, check your code against domain logic!")
    except ProgrammingError as e:
        if not str(e) == "Programmer, check your code against domain logic!":
            raise
    else:
        raise
    try:
        ProgrammingError.passert(False, "Programmer, check your code against domain logic!")
    except ProgrammingError as e:
        if not str(e) == "Programmer, check your code against domain logic!":
            raise
    else:
        raise
    try:
        ProgrammingError.passert(True, "Programmer, check your code against domain logic!")
    except ProgrammingError:
        raise
    ProgrammingError.passert(True, None)

# Generated at 2022-06-24 01:13:01.150436
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except ProgrammingError as exception:
        assert isinstance(exception, ProgrammingError)
        assert exception.args[0] == "test"


# Generated at 2022-06-24 01:13:03.016137
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:13:13.317837
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Check that a ProgrammingError is raised with the given message when the condition is not met.

    :return: None.
    """
    # Verify that no exception is raised if the condition is met.
    ProgrammingError.passert(True, None)
    ProgrammingError.passert(True, "")
    ProgrammingError.passert(True, " ")

    # Verify that a ProgrammingError is raised if the condition is not met.
    try:
        ProgrammingError.passert(False, None)
        assert(False)
    except ProgrammingError as e:
        assert(str(e) == "Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-24 01:13:16.051854
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError()
    assert isinstance(e, Exception)

# Generated at 2022-06-24 01:13:18.731013
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert(e.args[0] == "This is a test.")


# Generated at 2022-06-24 01:13:22.343560
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("some message")
    except ProgrammingError as ex:
        if ex.args[0] != "some message":
            raise Exception("Failed to construct a ProgrammingError: " + str(ex))

# Generated at 2022-06-24 01:13:26.554407
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        print(e)
    try:
        raise ProgrammingError("error message")
    except ProgrammingError as e:
        print(e)


# Generated at 2022-06-24 01:13:33.014573
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
        assert False
    except ProgrammingError as pe:
        assert str(pe) == "This is a test"

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as pe:
        assert str(pe) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:13:35.125267
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError.passert(False, "Some error message.")
    except ProgrammingError as e:
        print(e)

# Generated at 2022-06-24 01:13:41.269919
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # type: () -> None
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError("garbage")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Failed to raise exception after calling constructor of class ProgrammingError")


# Generated at 2022-06-24 01:13:46.995468
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    error = ProgrammingError("A message")
    assert error.args[0] == "A message"
    with raises(ProgrammingError):
        raise ProgrammingError()
    with raises(ProgrammingError):
        raise ProgrammingError("A message")


# Generated at 2022-06-24 01:13:49.210004
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-24 01:13:53.899108
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara import py2to3
    condition1 = True
    assert ProgrammingError.passert(condition1, None) is None
    condition2 = False
    with py2to3.assert_raises(ProgrammingError):
        ProgrammingError.passert(condition2, "")
    with py2to3.assert_raises(ProgrammingError):
        ProgrammingError.passert(condition2, None)

# Generated at 2022-06-24 01:13:56.215553
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test of class :py:class:`ProgrammingError`.
    """
    msg = "Message of the error."
    err = ProgrammingError(msg)
    assert msg == err.args[0]

# Generated at 2022-06-24 01:13:59.264068
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing")
    except ProgrammingError as err:
        assert str(err) == "Testing"



# Generated at 2022-06-24 01:14:01.351129
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert e.args[0] == "Error message"


# Generated at 2022-06-24 01:14:02.720961
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as error:
        assert type(error) is ProgrammingError


# Generated at 2022-06-24 01:14:06.105669
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-24 01:14:09.715664
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error.args == ("Broken coherence. Check your code against domain logic to fix it.",)

    error = ProgrammingError("This is a mock error.")
    assert error.args == ("This is a mock error.",)


# Generated at 2022-06-24 01:14:12.979963
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "A message")
    # no exception shall be raised
    ProgrammingError.passert(True, "Does not matter")

# Generated at 2022-06-24 01:14:16.636938
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Dummy message")
        assert True
    except ProgrammingError as e:
        assert False, e


# Generated at 2022-06-24 01:14:21.763124
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for constructor of class ProgrammingError.
    """
    try:
        raise ProgrammingError("Error 1")
    except ProgrammingError as exception:
        assert str(exception) == "Error 1"
    try:
        raise ProgrammingError()
    except ProgrammingError as exception:
        assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:14:29.414746
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    passert = ProgrammingError.passert
    try:
        passert(True, "This should not raise an exception")
    except ProgrammingError:
        assert False
    try:
        passert(False, "This should raise an exception")
        assert False
    except ProgrammingError:
        assert True
    try:
        passert(False, None)
        assert False
    except ProgrammingError as e:
        assert e.__str__() == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:14:33.429907
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        new_programming_error = ProgrammingError()
        if new_programming_error is None:
            return False
        else:
            return True
    except:
        return False


# Generated at 2022-06-24 01:14:44.510265
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Raises a :py:class:`ProgrammingError` as expected.
    """
    try:
        ProgrammingError.passert(False, "i am broken")
    except ProgrammingError as e:
        assert e.args[0] == "i am broken"

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(False, "hi")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "hi"

    # Check that the class ProgrammingError does not raise anything
    ProgrammingError.passert(True, "i am broken")



# Generated at 2022-06-24 01:14:52.556830
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.

    :raises AssertionError: In case that the constructor does not satisfy its contract.
    """
    try:
        msg = "brok!"
        err = ProgrammingError(msg)
    except Exception as e:
        raise AssertionError("Constructor of class ProgrammingError failed") from e
    assert msg == str(err), "Constructor of class ProgrammingError failed"



# Generated at 2022-06-24 01:14:56.636407
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Foo")
    except ProgrammingError as e:
        assert e.message == "Foo"


# Generated at 2022-06-24 01:15:02.315428
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for the constructor of the class :py:class:`ProgrammingError`.
    """
    # Create an exception using its parameterized constructor
    exception = ProgrammingError("test")

    # Check that the exception has the proper message
    assert str(exception) == "test"


# Generated at 2022-06-24 01:15:04.845518
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is an error.")

# Generated at 2022-06-24 01:15:06.882339
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Foo"):
        pass



# Generated at 2022-06-24 01:15:12.215475
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("my message")
        raise Exception("Error, this should not raise")
    except ProgrammingError as pe1:
        try:
            raise ProgrammingError("my message") from pe1
        except ProgrammingError as pe2:
            if pe1.args != pe2.args:
                raise Exception(
                    f"Error, the error message should be {pe1.args}, but it is {pe2.args}.")

# Generated at 2022-06-24 01:15:24.431275
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.common.errors import ProgrammingError
    from pypara.common.errors import PassertRequired, PassertCondition

    # Test for the initial state of the class
    assert ProgrammingError._type_error is None
    assert isinstance(ProgrammingError._programming_errors, list) is True
    assert len(ProgrammingError._programming_errors) == 0

    # Test for the correct behavior of the class
    with raises(ProgrammingError) as e:
        raise ProgrammingError("Unknown error")
    assert isinstance(e.value, ProgrammingError) is True
    assert e.value.args[0] == "Unknown error"
    assert e.value.args[1] == ()
    assert isinstance(e.value.args[2], list) is True

# Generated at 2022-06-24 01:15:28.322528
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.validation import ProgrammingError
    try:
        ProgrammingError.passert(False, None)
    except (ProgrammingError) as exc:
        assert exc.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:15:31.154588
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error")
    except ProgrammingError:
        assert True
    else:
        assert False, "We were expecting a ProgrammingError"


# Generated at 2022-06-24 01:15:38.440514
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "")
    try:
        ProgrammingError.passert(False, "")
        assert False
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


if __name__ == "__main__":
    from pytest import main as test_me
    test_me([__file__])

# Generated at 2022-06-24 01:15:40.404536
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("a message")
    except ProgrammingError as e:
        pass
    else:
        assert False, "ProgrammingError was not raised"


# Generated at 2022-06-24 01:15:42.271568
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    x = ProgrammingError("This is a message")
    assert x.args[0] == "This is a message"

# Generated at 2022-06-24 01:15:45.654214
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test case for :py:class:`ProgrammingError`.

    :return: ``None``
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
       assert isinstance(e, ProgrammingError)


# Generated at 2022-06-24 01:15:54.174826
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error.")
    except ProgrammingError as exc:
        assert "This is an error." == str(exc)

    # Unit test for function passert of class ProgrammingError
    def test_passert():
        try:
            ProgrammingError.passert(True, "This is an error.")
        except ProgrammingError:
            assert False, "This function should not have raised an error."
        try:
            ProgrammingError.passert(False, "This is an error.")
            assert False, "This function should have raised an error."
        except ProgrammingError as exc:
            assert "This is an error." == str(exc)

# Generated at 2022-06-24 01:15:56.837025
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class A: pass
    class B: pass
    try:
        ProgrammingError.passert(isinstance(A, B), "Should raise exception.")
    except ProgrammingError:
        return
    raise RuntimeError("Unit test for ProgrammingError failed.")

# Generated at 2022-06-24 01:15:59.555616
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as e:
        assert str(e) == "Some message"


# Generated at 2022-06-24 01:16:01.449599
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert ProgrammingError.__name__ == "ProgrammingError"


# Generated at 2022-06-24 01:16:04.978782
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        error = ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError constructor was unable to raise an error"


# Generated at 2022-06-24 01:16:11.249700
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Expected use
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as error:
        print(error)
        raise error

    # False condition
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as error:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."

    # False condition with message
    message = "This is the message"
    try:
        ProgrammingError.passert(False, message)
    except ProgrammingError as error:
        assert str(error) == message

# Generated at 2022-06-24 01:16:12.144301
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:16:14.297201
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Expected error.")
    except ProgrammingError:
        pass
    except Exception as e:
        assert False, "Expected error not raised."


# Generated at 2022-06-24 01:16:20.755678
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as ex:
        assert str(ex) == "test"
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:16:25.965301
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Checks the :py:class:`ProgrammingError` class constructor.
    """
    error = ProgrammingError()
    assert isinstance(error, Exception)

    error = ProgrammingError("Some error")
    assert isinstance(error, Exception)


# Generated at 2022-06-24 01:16:30.616633
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing constructor")
    except ProgrammingError as err:
        assert str(err) == "Testing constructor"


# Generated at 2022-06-24 01:16:38.351909
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase
    import unittest

    class MyTestCase(TestCase):
        def test_ProgrammingError(self):
            msg1 = "Lorem Ipsum"
            msg2 = "Dolor Sit Amet"
            try:
                ProgrammingError(msg1)
            except ProgrammingError as error:
                self.assertEqual(error.__str__(), msg1)
            try:
                ProgrammingError.passert(False, msg2)
            except ProgrammingError as error:
                self.assertEqual(error.__str__(), msg2)

    # Run unit tests
    unittest.main()


if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-24 01:16:45.649817
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError()
    assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."
    assert exception.args == tuple()
    exception = ProgrammingError("invalid message")
    assert str(exception) == "invalid message"
    assert exception.args == ("invalid message",)

# Generated at 2022-06-24 01:16:51.572609
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"



# Generated at 2022-06-24 01:16:56.305177
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError()
    with raises(ProgrammingError):
        ProgrammingError("This is an error.")


# Generated at 2022-06-24 01:17:02.298220
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    # A message can be provided
    try:
        raise ProgrammingError(message="A test exception")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError) and isinstance(e, AssertionError)
        assert e.args[0] == "A test exception"

    # noinspection PyBroadException
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError) and isinstance(e, AssertionError)
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:17:04.720759
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:17:11.776766
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from .context import PROGRAMMING_ERROR_MESSAGE

    with raises(ProgrammingError) as excinfo:
        raise ProgrammingError("")
    assert PROGRAMMING_ERROR_MESSAGE in str(excinfo.value)

    with raises(ProgrammingError) as excinfo:
        raise ProgrammingError()
    assert PROGRAMMING_ERROR_MESSAGE in str(excinfo.value)


# Generated at 2022-06-24 01:17:16.305999
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Bad coherence")
    except ProgrammingError as e:
        assert(e.args == ("Bad coherence",))


# Generated at 2022-06-24 01:17:17.992100
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test programming error message.")
    except ProgrammingError as e:
        assert str(e) == "Test programming error message."


# Generated at 2022-06-24 01:17:20.432412
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test message")
    except Exception as exc:
        assert str(exc) == "test message"


# Generated at 2022-06-24 01:17:21.865374
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="This is a message")
    except ProgrammingError as e:
        assert e.message == "This is a message"


# Generated at 2022-06-24 01:17:25.947711
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "This message must never be seen.")
    except ProgrammingError:
        assert False
    try:
        ProgrammingError.passert(False, "This message must be seen.")
        assert False
    except ProgrammingError:
        assert True
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        assert True

# Generated at 2022-06-24 01:17:28.263450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Some message"):
        pass


# Generated at 2022-06-24 01:17:28.857540
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-24 01:17:33.004544
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "The code broke coherence avoid the world explodes")

    try:
        ProgrammingError.passert(True, "The code broke coherence avoid the world explodes")
    except ProgrammingError:
        pytest.fail("ProgrammingError was raised and it should not happen")

# Generated at 2022-06-24 01:17:35.975665
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of class ProgrammingError.
    """
    error = ProgrammingError("Message of the error")
    assert error.args == ("Message of the error",)



# Generated at 2022-06-24 01:17:37.908863
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:17:40.452312
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    # Act
    # Assert
    ProgrammingError(None)
    ProgrammingError("")
    ProgrammingError("test")


# Generated at 2022-06-24 01:17:42.946967
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Act
        ProgrammingError.passert(False, "message")
    except ProgrammingError as pe:
        assert "message" == str(pe)

# Generated at 2022-06-24 01:17:45.402635
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of :py:class:`ProgrammingError`.
    """
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Some error")


# Generated at 2022-06-24 01:17:50.690567
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This message should be raised.")
    except ProgrammingError as e:
        assert e.args[0] == "This message should be raised."


# Generated at 2022-06-24 01:17:54.843903
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as e:
        assert "A message" == str(e)



# Generated at 2022-06-24 01:17:57.564892
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:18:02.885771
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an expected condition")
    except ProgrammingError as e:
        assert str(e) == "This is an expected condition"
    else:
        assert False and "Exception not raised"

# Generated at 2022-06-24 01:18:06.885150
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Hello World")
    except ProgrammingError as e:
        assert str(e) == "Hello World"


# Generated at 2022-06-24 01:18:12.185289
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.

    :return: ``None``
    """
    try:
        ProgrammingError.passert(False, "Broken coherence")
    except ProgrammingError as error:
        assert str(error) == "Broken coherence"