

# Generated at 2022-06-24 01:08:06.504977
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Done!")


# Generated at 2022-06-24 01:08:08.401469
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is the test message")
    assert(error.args[0] == "This is the test message")

# Generated at 2022-06-24 01:08:09.740588
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()


# Generated at 2022-06-24 01:08:13.478076
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from programming_error import ProgrammingError

    with raises(ProgrammingError):
        ProgrammingError.passert(False, None)

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "")

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Check your code against domain logic to fix it.")


# Generated at 2022-06-24 01:08:15.722429
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("")
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)


# Generated at 2022-06-24 01:08:20.411297
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    errmsg = "Foobar"
    try:
        ProgrammingError.passert(False, errmsg)
    except ProgrammingError as e:
        if errmsg != e.args[0]:
            raise Exception("Unexpected error message: '{}'".format(e.args[0]))

# Generated at 2022-06-24 01:08:22.650061
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as exception:
        assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:08:33.048816
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN: A programming error
    message = "Custom error message"
    err = ProgrammingError(message)

    # THEN: The error message is the provided message
    assert isinstance(err, ProgrammingError)
    assert str(err) == message

    # GIVEN: A condition
    condition = True

    # THEN: The error is not raised if the condition is met
    ProgrammingError.passert(condition, message)

    # GIVEN: An error condition and a message
    condition = False

    # THEN: The error is raised if the condition is not met
    try:
        ProgrammingError.passert(condition, message)
    except ProgrammingError as err:
        assert str(err) == message

    # GIVEN: An error condition
    condition = False
    message = None

    # THEN: The error is raised if the condition is

# Generated at 2022-06-24 01:08:35.004066
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("This error was created for testing purposes.")


# Generated at 2022-06-24 01:08:40.569384
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "My message")
        assert False
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "My message"

# Generated at 2022-06-24 01:08:45.133850
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    err = ProgrammingError("Expected unit test for constructor of class ProgrammingError.")
    assert isinstance(err, ProgrammingError)



# Generated at 2022-06-24 01:08:49.229984
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test")
    except Exception as e:
        assert str(e) == "Test"


# Generated at 2022-06-24 01:08:51.082681
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except:
        assert False, "Expected no exception."

# Generated at 2022-06-24 01:08:57.578688
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Test of error message")
    except ProgrammingError as error:
        assert error.args == ("Test of error message",)


# Generated at 2022-06-24 01:09:02.125656
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyUnusedLocal
    try:
        # noinspection PyStatementEffect
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)

# Generated at 2022-06-24 01:09:06.267347
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        pass
    assert True

# Generated at 2022-06-24 01:09:07.883156
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Testing to raise a ProgrammingError exception."):
        pass

# Generated at 2022-06-24 01:09:09.009777
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Something is wrong") as e:
        assert e.args[0] == "Something is wrong"
    assert e is not None

# Generated at 2022-06-24 01:09:10.871458
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError("Testing")



# Generated at 2022-06-24 01:09:13.105868
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("message")
        assert False
    except ProgrammingError as ex:
        assert ex.args == ("message",)


# Generated at 2022-06-24 01:09:18.624218
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("This is an arbitrary message")
    assert isinstance(e, ProgrammingError)
    assert e.args == ("This is an arbitrary message",)
    assert isinstance(str(e), str)
    assert str(e) == "This is an arbitrary message"


# Generated at 2022-06-24 01:09:19.508837
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Asserts the correct construction of :py:class:`ProgrammingError`.
    """
    assert ProgrammingError("This is an error")

# Generated at 2022-06-24 01:09:27.247203
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.utils.testing import assert_exception_and_message

    # Test constructor with message
    assert_exception_and_message(ProgrammingError, "This is the message", lambda: ProgrammingError("This is the message"))

    # Test constructor with no message
    assert_exception_and_message(ProgrammingError, "Broken coherence. Check your code against domain logic to fix it.",
                                 lambda: ProgrammingError())


# Generated at 2022-06-24 01:09:28.715140
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Oops!")
    except ProgrammingError as ex:
        assert str(ex) == "Oops!"

# Generated at 2022-06-24 01:09:30.444850
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "foo")
        assert False
    except ProgrammingError as error:
        assert str(error) == "foo"


# Generated at 2022-06-24 01:09:31.720115
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "This is my personal error message.")

# Generated at 2022-06-24 01:09:36.010699
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Dummy message")
    assert error.args == ("Dummy message",)


# Generated at 2022-06-24 01:09:42.223932
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Asserting the constructor
    try:
        ProgrammingError.passert(True, "Test")
    except ProgrammingError:
        assert False, "Error: This test should never raise an exception"
    try:
        ProgrammingError.passert(False, "Test")
        assert False, "Error: This test should raise an ProgrammingError"
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:09:49.893528
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Some error"):
        pass
    try:
        with ProgrammingError.passert(False, "Some error"):
            pass
    except ProgrammingError as e:
        assert e.args[0] == "Some error"
    try:
        with ProgrammingError.passert(False, None):
            pass
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:09:55.564996
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError() should raise an exception"
    try:
        ProgrammingError("foo")
    except ProgrammingError as e:
        assert str(e) == "foo", "ProgrammingError(\"foo\") should have a message \"foo\""
    else:
        assert False, "ProgrammingError(\"foo\") should raise an exception"

# Generated at 2022-06-24 01:09:57.551364
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as pe:
        assert str(pe) == "This is an error"

# Generated at 2022-06-24 01:09:59.772029
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:10:04.356866
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Expectation not met.")
        assert False, "Should have raised an exception."
    except ProgrammingError as error:
        assert "Expectation not met." in str(error)


# Generated at 2022-06-24 01:10:05.949996
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Test error for class ProgrammingError.")
    assert error.message == "Test error for class ProgrammingError."


# Generated at 2022-06-24 01:10:10.115232
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:10:12.334806
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("There is a fault in your code regarding domain logic.")
    except ProgrammingError as e:
        assert str(e) == "There is a fault in your code regarding domain logic."


# Generated at 2022-06-24 01:10:17.183363
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class TestClass(ProgrammingError):
        pass
    try:
        raise TestClass("foo")
    except TestClass as e:
        assert e.args == ("foo",)


# Generated at 2022-06-24 01:10:22.548358
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as e:
        assert e.args[0] == "Some message"


# Generated at 2022-06-24 01:10:24.365577
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError` constructor
    """
    with ProgrammingError("Test error"):
        raise ProgrammingError("Test error")

# Generated at 2022-06-24 01:10:26.952788
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a ProgrammingError!")
    except ProgrammingError as err:
        assert str(err) == "This is a ProgrammingError!", "Wrong exception message raised."


# Generated at 2022-06-24 01:10:28.633344
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError()
    assert str(exception) == 'Broken coherence. Check your code against domain logic to fix it.'


# Generated at 2022-06-24 01:10:33.691848
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=unused-variable,unused-argument

    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError()
        ProgrammingError("Test message")
        ProgrammingError(message="Test message")

# Generated at 2022-06-24 01:10:35.191977
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        assert(True)



# Generated at 2022-06-24 01:10:36.546753
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert not ((ProgrammingError() is None) and (ProgrammingError("hola") is None))


# Generated at 2022-06-24 01:10:38.997893
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for :py:class:`ProgrammingError`."""
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence" in str(e)


# Generated at 2022-06-24 01:10:40.835330
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        return True
    raise AssertionError("ProgrammingError should be raised.")


# Generated at 2022-06-24 01:10:46.200394
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("XXX")
    except ProgrammingError as e:
        assert isinstance(e, Exception)
    else:
        raise RuntimeError("ProgrammingError constructor failed")


# Generated at 2022-06-24 01:10:49.391359
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:10:52.576781
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("test")
    assert repr(exception) == "test"


# Generated at 2022-06-24 01:10:55.847510
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as exception:
        assert exception.args[0] == "A message"
    try:
        raise ProgrammingError(None)
    except ProgrammingError as exception:
        assert exception.args[0] is None


# Generated at 2022-06-24 01:10:58.995796
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert e.args[0] == "Error message"


# Generated at 2022-06-24 01:11:00.543297
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:11:02.863619
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Expected error message")
        assert False  # This line should be unreachable
    except ProgrammingError as ex:
        assert str(ex) == "Expected error message"

# Generated at 2022-06-24 01:11:04.804701
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error")
    except ProgrammingError as e:
        assert str(e) == "Some error"


# Generated at 2022-06-24 01:11:07.014689
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Beep boop.")
    except Exception as e:  # pylint: disable=broad-except
        assert type(e) == ProgrammingError



# Generated at 2022-06-24 01:11:08.798799
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Empty object.")
    except ProgrammingError as e:
        assert str(e) == "Empty object."

# Generated at 2022-06-24 01:11:14.075419
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)


# Generated at 2022-06-24 01:11:17.267143
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test error message.")
    except ProgrammingError as err:
        assert str(err) == "Test error message."

# Generated at 2022-06-24 01:11:19.052550
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="")
    except ProgrammingError as e:
        pass


# Generated at 2022-06-24 01:11:20.593953
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = Exception("This is a test.")
    try:
        raise error
    except Exception as caught:
        assert error == caught
        assert "This is a test." == caught.args[0]

# Generated at 2022-06-24 01:11:22.963602
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, Exception)


# Generated at 2022-06-24 01:11:26.176456
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test error")
    except Exception as exc:
        assert isinstance(exc, ProgrammingError)
        assert str(exc) == "Test error"


# Generated at 2022-06-24 01:11:28.852217
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyUnusedLocal
    try:
        ProgrammingError(message="unit test")
        raise AssertionError("Expected exception to be thrown")
    except ProgrammingError as e:
        assert e.message == "unit test"


# Generated at 2022-06-24 01:11:32.752567
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that :py:class:`ProgrammingError` is a-ok.
    """
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert e.args == ("Error message",)

test_ProgrammingError()

# Generated at 2022-06-24 01:11:36.708773
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the default constructor of class ProgrammingError.
    """
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-24 01:11:39.829220
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError()
    assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:11:42.435257
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This should not be raised")
    except ProgrammingError as e:
        assert str(e) == "This should not be raised"

# Generated at 2022-06-24 01:11:47.326769
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    msg = "This is some error message"
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as e:
        assert msg in str(e)

    msg = None
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as e:
        assert "unknown programming error" in str(e)


# Generated at 2022-06-24 01:11:51.721868
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    This unit test verifies that the constructor of class :py:class:`ProgrammingError` works as expected.
    """
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"

# Generated at 2022-06-24 01:11:55.140958
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # The following line raises a ProgrammingError
        ProgrammingError.passert(False, "4.4")
        # This assertion should never be raised
        assert False
    except ProgrammingError as e:
        # The exception message should be "4.4" in case of success
        assert str(e) == "4.4"

# Generated at 2022-06-24 01:11:57.371746
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error has occurred.")
    except ProgrammingError as e:
        print(e)
        assert(e.args[0] == "A programming error has occurred.")


# Generated at 2022-06-24 01:11:59.841869
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for constructor of class ProgrammingError
    """

    try:
        raise ProgrammingError("This is a test")
    except Exception as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-24 01:12:01.047162
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "This is the error message."):
        pass

# Generated at 2022-06-24 01:12:02.761591
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error message")
    except ProgrammingError as e:
        assert "This is an error message" in str(e)


# Generated at 2022-06-24 01:12:04.413437
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:12:10.366020
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError.passert(False, "Test message...")
    except ProgrammingError as exc:
        print(str(exc))

if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-24 01:12:11.748716
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("message").args[0] == "message"
    assert ProgrammingError().args[0] == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-24 01:12:19.560549
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test error")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Test error"

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:12:21.319354
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
        assert False
    except ProgrammingError as error:
        assert error.args[0] == "test"

# Generated at 2022-06-24 01:12:26.328672
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert isinstance(e, Exception)
        assert str(e) == "Test"


# Generated at 2022-06-24 01:12:30.646532
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:12:34.405621
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Dummy message")
    except ProgrammingError as ex:
        assert ex.args[0] == "Dummy message", "Message is not correctly passed."


# Generated at 2022-06-24 01:12:38.733538
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    try:
        raise ProgrammingError("Foobar")
    except ProgrammingError as pe:
        assert "Foobar" in str(pe)
    try:
        raise ProgrammingError(None)
    except ProgrammingError as pe:
        assert "broke" in str(pe).lower()


# Generated at 2022-06-24 01:12:45.680092
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError() should raise an exception."

    # Unit test for class method ProgrammingError.passert
    try:
        ProgrammingError.passert(True, "should not raise")
    except ProgrammingError:
        assert False, "ProgrammingError.passert() should not raise an exception when True is passed."

    try:
        ProgrammingError.passert(False, "should raise")
    except ProgrammingError as e:
        assert False, f"ProgrammingError.passert() should raise a ProgrammingError exception when False is passed, " \
                      f"but it raises {type(e)}."


if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-24 01:12:50.130489
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Unit test of ProgrammingError.passert()

# Generated at 2022-06-24 01:12:54.039855
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError() is not raising any exception when called."


# Generated at 2022-06-24 01:12:55.542265
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hello world!")
    except ProgrammingError as e:
        assert e.args[0] == "Hello world!"


# Generated at 2022-06-24 01:12:58.710564
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Unit test")
    except ProgrammingError as error:
        assert str(error) == "Unit test"


# Generated at 2022-06-24 01:13:02.180477
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is an unusual message")
        # Unreachable code
        assert False, "Raising ProgrammingError with a message does no influence unit test."
    except ProgrammingError as e:
        assert e.args == ("This is an unusual message",)


# Generated at 2022-06-24 01:13:04.573142
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Message of error")
    except ProgrammingError as e:
        assert str(e) == "Message of error"



# Generated at 2022-06-24 01:13:06.268770
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)


# Generated at 2022-06-24 01:13:11.509692
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")  # This must raise a ProgrammingError
    except ProgrammingError as error:
        assert error.args == ("Test message",)  # Check that exception message is properly passed
    else:
        assert False  # Check the exception was not raised if control flow reaches here

# Generated at 2022-06-24 01:13:17.118399
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`.
    """
    test_message = "Testing the exceptional message of ProgrammingError"
    try:
        raise ProgrammingError(test_message)
    except ProgrammingError as e:
        assert str(e) == test_message


# Generated at 2022-06-24 01:13:18.987215
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        p = ProgrammingError("abc")


# Generated at 2022-06-24 01:13:20.521283
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    raise ProgrammingError("Test")

# Generated at 2022-06-24 01:13:23.379799
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"
    else:
        raise RuntimeError("Exception not raised.")


# Generated at 2022-06-24 01:13:24.352680
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("error")

# Generated at 2022-06-24 01:13:29.590770
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """

    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as e:
        assert e.args[0] == "This is an error"


# Generated at 2022-06-24 01:13:39.115227
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    try:
        raise ProgrammingError("Hello world!")
    except ProgrammingError as e:
        assert str(e) == "Hello world!"
    try:
        ProgrammingError.passert(False, "Hello world!")
    except ProgrammingError as e:
        assert str(e) == "Hello world!"
    try:
        ProgrammingError.passert(True, "Hello world!")
    except ProgrammingError as e:
        pytest.fail("Wrong exception: {0} at (1)".format(str(e), "1"))
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:13:42.265479
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message for exception")
    except ProgrammingError as e:
        assert str(e) == "Message for exception"

# Generated at 2022-06-24 01:13:49.381386
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        assert False, "Failed to raise the exception ProgrammingError."
    try:
        ProgrammingError.passert(False, "test")
    except ProgrammingError as e:
        assert str(e) == "test", "Failed to raise the exception ProgrammingError with message 'test'."

# Generated at 2022-06-24 01:13:54.710268
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="This is a test.")
    except ProgrammingError as e:
        assert str(e) == "This is a test."


# Generated at 2022-06-24 01:13:57.741148
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-24 01:14:00.876725
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class :py:class:`ProgrammingError`
    """
    try:
        raise ProgrammingError("this is a test")
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-24 01:14:02.580624
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, Exception), "Failed ProgrammingError"

# Generated at 2022-06-24 01:14:07.387779
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hopefully, you won't see me.")
    except ProgrammingError as e:
        assert type(e) == ProgrammingError
        assert str(e) == "Hopefully, you won't see me."


# Generated at 2022-06-24 01:14:08.846090
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as ex:
        assert str(ex) == "This is a test"


# Generated at 2022-06-24 01:14:09.695094
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("test")
    assert exception.args[0] == "test"

# Generated at 2022-06-24 01:14:10.566199
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:14:14.062583
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Checks the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as err:
        assert err.args[0] == "Test"


# Generated at 2022-06-24 01:14:17.786535
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "failure")
    except ProgrammingError as e:
        assert str(e) == "failure"



# Generated at 2022-06-24 01:14:21.384662
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Error")

# Generated at 2022-06-24 01:14:22.209902
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="This is a programming error")

# Generated at 2022-06-24 01:14:23.256976
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-24 01:14:29.151101
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def assert_constructor(message):
        try:
            raise ProgrammingError(message=message)
        except ProgrammingError as err:
            assert str(err) == message  # Validates the message

    assert_constructor("foo")
    assert_constructor("")
    assert_constructor("   ")
    assert_constructor(None)  # pragma: no cover



# Generated at 2022-06-24 01:14:32.292422
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:14:44.182533
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Performs a unit test for the constructor of :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(True, "Conditional error")
    except ProgrammingError:
        # This is an expected error.
        pass
    else:
        raise Exception("Construction of ProgrammingError resulted in unexpected behavior.")
    try:
        ProgrammingError.passert(False, "Conditional error")
    except ProgrammingError as error:
        # This is an expected error.
        assert error.args[0] == "Conditional error", "Error message is not expected."
    else:
        raise Exception("Construction of ProgrammingError resulted in unexpected behavior.")
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as error:
        # This is an expected error.
        assert error.args[0]

# Generated at 2022-06-24 01:14:50.824897
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "message") as cm:
        pass
    assert cm.exception is None
    try:
        with ProgrammingError.passert(False, "message") as cm:
            raise NotImplementedError()
    except ProgrammingError as ex:
        assert ex.args == ("Broken coherence. Check your code against domain logic to fix it.", )

# Generated at 2022-06-24 01:14:52.657313
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("foo") as e:
        assert e.args[0] == "foo"

# Generated at 2022-06-24 01:14:56.636424
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is a test error")
    assert "This is a test error" == error.args[0]



# Generated at 2022-06-24 01:14:58.905754
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("test")

# Generated at 2022-06-24 01:15:00.698734
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError():
        ProgrammingError.passert(True, "")
        ProgrammingError.passert(False, "custom message")

# Generated at 2022-06-24 01:15:02.162052
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # WHEN
    exception = ProgrammingError("Error message.")
    # THEN
    assert exception.args[0] == "Error message."


# Generated at 2022-06-24 01:15:07.343563
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError:
        pass
    else:
        print("ERROR: test_ProgrammingError: did not raise ProgrammingError")



# Generated at 2022-06-24 01:15:15.107010
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase
    from pytest import raises
    from pytest_mock import mocker

    class Test1(TestCase):

        def test_passert(self):
            with raises((ProgrammingError, AssertionError)):
                ProgrammingError.passert(False, "Test message")

            with mocker.patch.object(ProgrammingError, "__init__") as m:
                with mocker.patch.object(m, "__call__", side_effect=ProgrammingError("Test message")):
                    with raises(ProgrammingError) as e:
                        ProgrammingError.passert(False, "Test message")
                        self.assertEqual("Test message", e.message)



# Generated at 2022-06-24 01:15:16.994116
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("test message")
    assert error.args == ("test message",)


# Generated at 2022-06-24 01:15:21.954565
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(2 + 2 == 4, "I was wrong, Jarvis"):
        pass
    try:
        with ProgrammingError.passert(2 + 2 == 5, "You are wrong, Jarvis"):
            pass
    except ProgrammingError:
        return
    assert False, "Exception was expected but not raised"

# Generated at 2022-06-24 01:15:26.158688
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Mock error")
        assert False
    except ProgrammingError as pe:
        assert pe.args[0] == "Mock error"

    try:
        ProgrammingError.passert(True, "Mock error")
    except ProgrammingError as pe:
        assert False

# Generated at 2022-06-24 01:15:31.286737
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Dummy message")
    except ProgrammingError as e:
        assert e.args[0] == "Dummy message"

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:15:33.890759
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError() does not raise a ProgrammingError.")


# Generated at 2022-06-24 01:15:39.024803
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("some message", 1)
    except ProgrammingError as exception:
        assert exception.args[0] == "some message", "Error message is not set properly"
        assert exception.args[1] == 1, "Unexpected error argument"



# Generated at 2022-06-24 01:15:40.625432
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Checks that the :py:class:`ProgrammingError` class works as expected.
    """
    assert False


# Generated at 2022-06-24 01:15:44.898671
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("My message")
    assert error.args[0] == "My message"

# Generated at 2022-06-24 01:15:50.897977
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from nose.tools import assert_raises

    try:
        with assert_raises(ProgrammingError):
            ProgrammingError.passert(False, "")
    except ProgrammingError as e:
        pass
    else:
        raise AssertionError("ProgrammingError with message '' expected.")

    try:
        with assert_raises(ProgrammingError):
            ProgrammingError.passert(False, "hoi")
    except ProgrammingError as e:
        assert e.args[0] == "hoi"
    else:
        raise AssertionError("ProgrammingError with message 'hoi' expected.")

# Generated at 2022-06-24 01:15:55.910784
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an 'assert' test")
    except ProgrammingError as e:
        assert e.args[0] == "This is an 'assert' test"


# Generated at 2022-06-24 01:15:58.716447
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Prog error")
    except ProgrammingError as exc:
        assert exc.args[0] == "Prog error"


# Generated at 2022-06-24 01:16:01.066816
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("The message of this error")
    except ProgrammingError as e:
        assert e.args[0] == "The message of this error"


# Generated at 2022-06-24 01:16:05.507535
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # A wrong condition should raise an exception
        ProgrammingError.passert(False, "This is a test")
        # We should not reach this point
        assert False
    except ProgrammingError:
        # We should reach this point
        pass

# Generated at 2022-06-24 01:16:08.094203
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is a test")
    except Exception as e:
        assert False, "ProgrammingError could not be raised"


# Generated at 2022-06-24 01:16:09.680400
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    message = "Message for error"
    with pytest.raises(ProgrammingError, match=message):
        raise ProgrammingError(message)

# Generated at 2022-06-24 01:16:12.109059
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert(str(e) is not None)


# Generated at 2022-06-24 01:16:13.704055
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:16:18.863982
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error")
    except ProgrammingError as error:
        assert error.args == ("Some error",)
    else:
        assert False

# Generated at 2022-06-24 01:16:20.388573
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from py.test import raises
    with raises(ProgrammingError):
        raise ProgrammingError('')

# Generated at 2022-06-24 01:16:23.268317
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is a valid error message.")



# Generated at 2022-06-24 01:16:29.777751
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises as assert_raises

    # Should assert by default
    with assert_raises(ProgrammingError):
        ProgrammingError.passert(False, None)

    # Should assert if not explicitly suppressed
    with assert_raises(ProgrammingError):
        ProgrammingError.passert(False, "Expectation failed!")

    # Should not assert at all if explicitly suppressed
    ProgrammingError.passert(True, None)
    ProgrammingError.passert(True, "Expectation failed!")

# Generated at 2022-06-24 01:16:35.961153
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit tests for ProgrammingError class."""
    from pytest import raises
    # Testing empty constructor
    with raises(ProgrammingError) as context:
        ProgrammingError()
    assert str(context.value) == "Broken coherence. Check your code against domain logic to fix it."
    # Testing constructor with 'message'
    with raises(ProgrammingError) as context:
        ProgrammingError("Ooops!")
    assert str(context.value) == "Ooops!"



# Generated at 2022-06-24 01:16:39.761557
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pyassert import assert_that

    with assert_that(ProgrammingError):
        assert_that(ProgrammingError).raises(lambda: ProgrammingError(None)).message_is(None)
        assert_that(ProgrammingError).raises(lambda: ProgrammingError("Some error message.")).message_is(
            "Some error message.")
        assert_that(ProgrammingError).raises(lambda: ProgrammingError()).message_is(None)


# Generated at 2022-06-24 01:16:44.712432
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-24 01:16:46.798031
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()


# Generated at 2022-06-24 01:16:53.126078
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
        assert False
    except ProgrammingError as e:
        assert str(e) == "test"
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    assert ProgrammingError.passert(True, "test") is None

# Generated at 2022-06-24 01:16:56.316119
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Method passert
    ProgrammingError.passert(True, "Test true assertion")
    try:
        ProgrammingError.passert(False, "Test false assertion")
        assert False, "Exception should have been raised"
    except ProgrammingError:
        assert True, "Exception was raised"

# Generated at 2022-06-24 01:16:59.581458
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a message.")
        assert 0, "An error should have been raised"
    except ProgrammingError as e:
        assert e.args[0] == "This is a message."
        assert type(e) is ProgrammingError

# Generated at 2022-06-24 01:17:01.484660
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Foo Bar")
    except ProgrammingError as e:
        assert e.args[0] == "Foo Bar"


# Generated at 2022-06-24 01:17:04.670711
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Something wrong")
        raise Exception("Shouldn't get here")
    except ProgrammingError:
        pass  # It's OK

# Generated at 2022-06-24 01:17:08.576569
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("This is a test message")
    assert isinstance(err, ProgrammingError)
    assert str(err) == "This is a test message"

# Generated at 2022-06-24 01:17:11.288432
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as error:
        assert error.args[0] == "test"
    else:
        raise Exception("Should have raised an exception")


# Generated at 2022-06-24 01:17:16.500843
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "The condition is not met")

    assert ProgrammingError.passert(True, "The condition is not met") is None

# Generated at 2022-06-24 01:17:20.345003
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as error:
        assert error.message == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("An error should have been raised.")


# Generated at 2022-06-24 01:17:22.613449
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.test.test_unit._test_exceptions import test_ProgrammingError
    test_ProgrammingError.test_constructor()


# Generated at 2022-06-24 01:17:28.107721
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests ProgrammingError class contructor."""
    # Arrange
    error = None
    # Act
    try:
        raise ProgrammingError("Programming error found!")
    except ProgrammingError as ex:
        error = ex
    # Assert
    assert str(error) == "Programming error found!"


# Generated at 2022-06-24 01:17:29.913306
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:17:33.228698
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        raise AssertionError
    except TypeError:
        pass



# Generated at 2022-06-24 01:17:35.835447
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("this is a message")
    except ProgrammingError as ex:
        assert str(ex) == "this is a message"


# Generated at 2022-06-24 01:17:39.177106
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hello world!")
    except ProgrammingError as e:
        assert e.args[0] == "Hello world!"


# Generated at 2022-06-24 01:17:41.762621
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Debugging is not the same as programming")
    except ProgrammingError as exc:
        assert str(exc) == "Debugging is not the same as programming"

# Generated at 2022-06-24 01:17:45.895451
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert(str(e) == "This is a test")

# Generated at 2022-06-24 01:17:50.768450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("An error occurred.")
    except ProgrammingError as error:
        assert str(error) == "An error occurred."


# Generated at 2022-06-24 01:17:55.457035
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected_message = "Expected error message"
    try:
        raise ProgrammingError(expected_message)
    except ProgrammingError as error:
        assert error.args == (expected_message,)


# Generated at 2022-06-24 01:17:57.524930
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()


# Generated at 2022-06-24 01:18:01.728155
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert e.args[0] == "Test message"
        return

# Generated at 2022-06-24 01:18:06.441427
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        raise Exception("ProgrammingError was raised and it shouldn't have been.")

    try:
        ProgrammingError.passert(False, "Test")
        raise Exception("ProgrammingError wasn't raised and it should have been.")
    except ProgrammingError as ex:
        assert str(ex) == "Test"