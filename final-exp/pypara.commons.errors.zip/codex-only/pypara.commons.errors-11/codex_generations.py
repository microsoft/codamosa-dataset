

# Generated at 2022-06-24 01:08:07.077597
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hello!")
    except ProgrammingError as e:
        assert e.args[0] == "Hello!"

# Generated at 2022-06-24 01:08:08.745805
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Ensures that the constructor of class ProgrammingError works as expected.
    """
    assert ProgrammingError("Test")

# Generated at 2022-06-24 01:08:14.805345
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError('Programming error')
    except ProgrammingError:
        pass



# Generated at 2022-06-24 01:08:20.902965
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Message")
    except ProgrammingError:
        pass
    ProgrammingError.passert(True, "message")
    try:
        ProgrammingError.passert(False, "Message")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:08:23.938659
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:08:27.722107
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as error:
        # If the exception is raised, then the message must be equal to its original message
        assert error.message == "This is a test"


# Generated at 2022-06-24 01:08:30.438503
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:08:36.017249
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with (lambda: ProgrammingError.passert(condition=True, message=None)) as e:
        assert not e
    with (lambda: ProgrammingError.passert(condition=False, message=None)) as e:
        assert e
    exception = None
    try:
        ProgrammingError.passert(condition=False, message=None)
    except Exception as e:
        exception = e
    assert exception
    assert isinstance(exception, ProgrammingError)

# Generated at 2022-06-24 01:08:39.258787
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Oops :(")
    except ProgrammingError as pe:
        assert pe.args == ("Oops :(",)

# Generated at 2022-06-24 01:08:42.142310
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("this is the message")
    except Exception as error:
        assert isinstance(error, ProgrammingError)
        assert str(error) == "this is the message"



# Generated at 2022-06-24 01:08:46.666546
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert ProgrammingError("A") == ProgrammingError("A")
    error = ProgrammingError("B")
    assert error.args == ("B",)
    assert len(error.args) == 1
    assert repr(error) == "pypara.errors.ProgrammingError('B',)"
    assert str(error) == "B"



# Generated at 2022-06-24 01:08:51.425374
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit testing for class ProgrammingError."""
    try:
        ProgrammingError()
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:08:54.017767
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError()
    print(err)

# Generated at 2022-06-24 01:08:59.383204
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # No exception to be thrown
    ProgrammingError.passert(True, "message")

    # Exception to be thrown
    try:
        ProgrammingError.passert(False, None)
        assert False, "Should not reach this line"
    except ProgrammingError as e:
        # Validate error message
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:09:00.576558
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('Exception message')
    except ProgrammingError as ex:
        assert(ex.args[0] == 'Exception message')

# Generated at 2022-06-24 01:09:04.934836
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("Oops!")
    assert str(exception) == "Oops!"

# Generated at 2022-06-24 01:09:06.213744
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something was wrong")
    except ProgrammingError:
        pass # ok

# Generated at 2022-06-24 01:09:09.799071
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        if e.args[0] != "Broken coherence. Check your code against domain logic to fix it.":
            raise Exception("The default error message has been changed.")


# Generated at 2022-06-24 01:09:10.687756
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    except:
        assert False


# Generated at 2022-06-24 01:09:11.373708
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Some error")
    assert isinstance(error, Exception) is True

# Generated at 2022-06-24 01:09:17.064677
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Act & Assert
    try:
        ProgrammingError(message="OK")
    except ProgrammingError as exc:
        assert exc.args[0] == "OK"
    else:
        assert False, "The exception should have been thrown"


# Generated at 2022-06-24 01:09:19.268236
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:09:22.258410
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:09:26.058203
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error")
    except ProgrammingError as e:
        assert str(e) == "A programming error"


# Generated at 2022-06-24 01:09:29.750141
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Parameter must be greater than zero")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert e.args == ("Parameter must be greater than zero",)
    else:
        assert False, "ProgrammingError was not raised"


# Generated at 2022-06-24 01:09:32.592050
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert repr(ProgrammingError("Something went wrong!")) == "ProgrammingError('Something went wrong!',)"

# Generated at 2022-06-24 01:09:38.633130
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("msg")
    except ProgrammingError as e:
        assert e.args == ("msg",)
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == tuple()


# Generated at 2022-06-24 01:09:41.214537
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():  # pragma: no cover
    """
    Unit test for class ProgrammingError.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        # expected
        pass
    try:
        raise ProgrammingError("expected")
    except ProgrammingError as e:
        # expected
        assert e.args[0] == "expected"


# Generated at 2022-06-24 01:09:41.877008
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-24 01:09:42.671398
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is the message")
    ProgrammingError()

# Generated at 2022-06-24 01:09:45.261529
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"

# Generated at 2022-06-24 01:09:49.798719
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False


# Generated at 2022-06-24 01:09:51.054051
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, None)


# Generated at 2022-06-24 01:09:53.144217
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert(str(e) == "Test")


# Generated at 2022-06-24 01:09:55.137607
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-24 01:09:58.783169
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("Expected exception for testing purposes.")



# Generated at 2022-06-24 01:10:01.136352
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    assert ProgrammingError("some error")
    assert str(ProgrammingError("some error")) == "some error"


# Generated at 2022-06-24 01:10:02.473536
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert isinstance(ProgrammingError(), ProgrammingError)


# Generated at 2022-06-24 01:10:06.316029
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as e:
        assert e.args[0] == "A message"


# Generated at 2022-06-24 01:10:08.932916
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "error")
    except ProgrammingError:
        return
    raise AssertionError("ProgrammingError not raised on broken assertion")

# Generated at 2022-06-24 01:10:10.391916
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-24 01:10:13.641471
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :class:`ProgrammingError`
    """
    class TestError(ProgrammingError):
        pass
    try:
        raise TestError("This is a test!")
    except TestError as err:
        assert "This is a test!" in str(err)


# Generated at 2022-06-24 01:10:15.034106
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except:
        assert False


# Generated at 2022-06-24 01:10:18.901179
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit tests for the :py:class:`ProgrammingError` exception.
    """
    try:
        ProgrammingError.passert(False, "Check your code. It breaks domain logic.")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:10:23.273383
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as pe:
        assert str(pe) == "Some message"  # (str(pe) == "Some message") should not fail

# Generated at 2022-06-24 01:10:25.536692
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is the message.")
    except ProgrammingError as e:
        assert e.args[0] == "This is the message."


# Generated at 2022-06-24 01:10:27.032629
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:10:29.702074
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for the constructor of class ProgrammingError.
    """
    ProgrammingError("error")
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "error")
    ProgrammingError.passert(True, "error")

# Generated at 2022-06-24 01:10:30.670543
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:10:33.361883
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hello, world!")
    except ProgrammingError:
        pass  # Expected
    else:
        assert False  # Exception was not raised

# Generated at 2022-06-24 01:10:34.858363
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    assert ProgrammingError("my error")


# Generated at 2022-06-24 01:10:35.724182
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError:
        pass


# Generated at 2022-06-24 01:10:37.893399
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """test_ProgrammingError"""
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == 'test'


# Generated at 2022-06-24 01:10:40.434191
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Broken coherence")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence"
        assert repr(e) == "ProgrammingError(Broken coherence)"


# Generated at 2022-06-24 01:10:43.796126
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert err


# Generated at 2022-06-24 01:10:46.670389
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"



# Generated at 2022-06-24 01:10:52.275024
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    if True:
        try:
            raise ProgrammingError()
        except ProgrammingError:
            pass

    if True:
        try:
            raise ProgrammingError("Message")
        except ProgrammingError as e:
            assert str(e) == "Message"

    if True:
        try:
            ProgrammingError.passert(True, None)
        except ProgrammingError:
            assert False

    if True:
        try:
            ProgrammingError.passert(False, None)
            assert False
        except ProgrammingError:
            pass

# Generated at 2022-06-24 01:10:55.369739
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test message")
    except ProgrammingError as e:
        assert str(e) == "This is a test message"

# Unit tests for the classmethod passert of class ProgrammingError

# Generated at 2022-06-24 01:10:56.490865
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("test")
    assert error.args == ("test",)

# Generated at 2022-06-24 01:10:58.301141
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("Check your code against domain logic to fix it.")

# Generated at 2022-06-24 01:11:00.667824
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something went wrong.")
    except ProgrammingError as error:
        assert str(error) == "Something went wrong."


# Generated at 2022-06-24 01:11:03.980933
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """

    def do_test():
        raise ProgrammingError("Testing")

    try:
        do_test()
    except ProgrammingError as err:
        assert "Testing" == str(err)
    else:
        assert False



# Generated at 2022-06-24 01:11:05.205746
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError()

# Generated at 2022-06-24 01:11:07.375385
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("It is a programming error.")
    except ProgrammingError as ex:
        assert str(ex) == "It is a programming error."


# Generated at 2022-06-24 01:11:08.524201
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-24 01:11:12.625191
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert True


# Generated at 2022-06-24 01:11:15.495996
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as err:
        assert isinstance(err, ProgrammingError)

# Generated at 2022-06-24 01:11:19.798931
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        assert False
        assert False

    except AssertionError as e:
        try:
            raise ProgrammingError(e)

        except ProgrammingError as e:
            assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:11:20.349761
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("msg")

# Generated at 2022-06-24 01:11:24.167327
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Expected to raise ProgrammingError")
        assert False, "Expected to raise ProgrammingError"
    except ProgrammingError as e:
        assert "Expected to raise ProgrammingError" in str(e)


# Generated at 2022-06-24 01:11:30.714322
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test of the constructor of the class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "This is an error")
        assert False, "This should not happen"
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:11:35.472815
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Some error")
    except ProgrammingError as e:
        assert e.args[0] == "Some error"


# Generated at 2022-06-24 01:11:38.122252
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:11:46.572749
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg_err="Broken coherence. Check your code against domain logic to fix it."
    msg_danger="Danger Will Robinson!!"
    try:
        raise ProgrammingError(msg_danger)
    except ProgrammingError as pr:
        assert str(pr) == msg_danger
    try:
        raise ProgrammingError()
    except ProgrammingError as pr:
        assert str(pr) == msg_err
    try:
        raise ProgrammingError(None)
    except ProgrammingError as pr:
        assert str(pr) == msg_err


# Generated at 2022-06-24 01:11:48.009368
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as exception:
        assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-24 01:11:51.544063
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("just for testing")
    except ProgrammingError as exception:
        assert (exception.args[0] == "just for testing")


# Generated at 2022-06-24 01:11:53.789958
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ``ProgrammingError``."""
    try:
        raise ProgrammingError("error message")
    except ProgrammingError as obj:
        assert str(obj) == "error message"


# Generated at 2022-06-24 01:11:55.419926
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    except:
        raise Exception("ProgrammingError doesn't work")

# Generated at 2022-06-24 01:11:56.355483
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Error message"):
        pass

# Generated at 2022-06-24 01:11:57.755485
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        assert True


# Generated at 2022-06-24 01:12:00.434266
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        ProgrammingError.passert(False, "Unexpected value found. Expected: {}. Actual found: {}")
    except ProgrammingError:
        pass
    else:
        assert False, "There should be a ProgrammingError"

# Generated at 2022-06-24 01:12:03.467398
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as e:
        assert(str(e)=="This is an error")


# Generated at 2022-06-24 01:12:06.542368
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("My error message.")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:12:09.220972
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Oops! There was an error")
    except ProgrammingError as error:
        assert error.args[0] == "Oops! There was an error"

# Generated at 2022-06-24 01:12:13.294613
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message=None)
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-24 01:12:15.937691
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Did not raise ProgrammingError"



# Generated at 2022-06-24 01:12:18.875348
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "fail")
    except ProgrammingError as e:
        assert "fail" == e.args[0]
    else:
        raise AssertionError("Expected exception ProgrammingError")

# Generated at 2022-06-24 01:12:20.520828
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.common import ProgrammingError

    with raises(ProgrammingError):
        ProgrammingError("Test")


# Generated at 2022-06-24 01:12:27.644509
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` class.
    """
    try:
        raise ProgrammingError("Error message 1")
    except ProgrammingError as e:
        assert str(e) == "Error message 1"
    try:
        raise ProgrammingError(None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:12:31.915924
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except Exception as ex:
        assert isinstance(ex, ProgrammingError)
    try:
        raise ProgrammingError("Some message")
    except Exception as ex:
        assert isinstance(ex, ProgrammingError)
        assert ex.args == ("Some message",)


# Generated at 2022-06-24 01:12:33.697689
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    # Act
    # Assert
    ProgrammingError.passert(True, "Error message")


# Generated at 2022-06-24 01:12:36.921991
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    result = None

    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        result = e

    assert isinstance(result, ProgrammingError) and result.args[0] == "This is a test"



# Generated at 2022-06-24 01:12:40.525819
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given
    expected_exception = ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    # When
    ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")
    # Then
    assert False, "Unreachable code"


# Generated at 2022-06-24 01:12:42.970781
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "this should not happen")
    except ProgrammingError as exception:
        assert exception.args[0] == "this should not happen"
    else:
        assert False

# Generated at 2022-06-24 01:12:45.065729
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-24 01:12:49.115333
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-24 01:12:55.304226
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Broken coherence.")
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence."
    else:
        assert False, "Test failed to raise an exception"


# Generated at 2022-06-24 01:12:59.017921
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Here is a message."
    try:
        raise ProgrammingError(message)
    except ProgrammingError as error:
        assert error.args[0] == message


# Generated at 2022-06-24 01:12:59.793712
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("foo")


# Generated at 2022-06-24 01:13:03.983541
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Test the default construction which should fail without a message.
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Default construction didn't fail.")

    # Test construction with a given message.
    try:
        ProgrammingError("Some error message")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Default construction didn't fail.")


# Generated at 2022-06-24 01:13:05.397020
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for the constructor of class ProgrammingError.
    """
    ProgrammingError("A message")


# Generated at 2022-06-24 01:13:09.315702
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.core.errors import ProgrammingError

    with raises(ProgrammingError):
        raise ProgrammingError()


# Generated at 2022-06-24 01:13:12.161373
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
        assert False
    except ProgrammingError as e:
        assert "This is a test" == e.args[0]

# Generated at 2022-06-24 01:13:18.432392
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("No error.")
    except ProgrammingError as ex:
        assert str(ex) == "No error."
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:13:20.845298
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("test")


# Generated at 2022-06-24 01:13:24.781969
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    This method tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError()
        raise Exception("Test failed because no exception was raised.")
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:13:28.194146
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Call the constructor
    assert isinstance(ProgrammingError(), ProgrammingError)
    assert isinstance(ProgrammingError("my error message"), ProgrammingError)


# Generated at 2022-06-24 01:13:32.956160
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given
    message = "This exception is being unit tested..."

    # When
    with raises(ProgrammingError) as context_manager:
        raise ProgrammingError(message)

    # Then
    exception = context_manager.value
    assert exception.args[0] == message


# Generated at 2022-06-24 01:13:36.103952
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # If there is an error, the message is printed
    try:
        raise ProgrammingError("This is an error.")
    except ProgrammingError as e:
        assert e.args[0] == "This is an error."



# Generated at 2022-06-24 01:13:37.884182
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as ex:
        assert ex.args[0] == "Message"


# Generated at 2022-06-24 01:13:42.763954
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("This is not a bug in your code, this is a bug in the documentation")


# Generated at 2022-06-24 01:13:46.103795
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Message")
        assert False
    except ProgrammingError as e:
        assert "Message" == str(e)

# Generated at 2022-06-24 01:13:49.772502
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test suite for class ProgrammingError constructs."""

    assert ProgrammingError().__str__() == 'Broken coherence. Check your code against domain logic to fix it.'
    assert ProgrammingError('Not really').__str__() == 'Not really'

# Generated at 2022-06-24 01:13:55.493386
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the constructor of class ``ProgrammingError``.
    """
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as error:
        assert error.args[0] == "A message"

# Generated at 2022-06-24 01:13:57.479393
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    # Act
    exception = ProgrammingE

# Generated at 2022-06-24 01:14:00.018241
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("failure")
    except ProgrammingError as e:
        assert e.args[0] == "failure"


# Generated at 2022-06-24 01:14:02.077906
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError()
    assert "Broken coherence" in str(excinfo.value)


# Generated at 2022-06-24 01:14:06.823803
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    except Exception:
        assert False, "Exception raised is not a ProgrammingError."


# Generated at 2022-06-24 01:14:08.876878
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError.passert(False, "Test Message")
    except ProgrammingError as err:
        assert str(err) == "Test Message", "Unexpected error message when checking the message parameter."
    else:
        raise AssertionError("ProgrammingError was not thrown as expected.")

# Generated at 2022-06-24 01:14:10.188171
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "I am a test!")

# Generated at 2022-06-24 01:14:13.398318
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of this class.
    """
    error = ProgrammingError("This is an error message.")
    assert str(error) == "This is an error message."


# Generated at 2022-06-24 01:14:17.558827
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:14:25.616186
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        with ProgrammingError.passert(False, None):
            pass
    except ProgrammingError as e:
        assert str(e) == 'Broken coherence. Check your code against domain logic to fix it.'
    try:
        with ProgrammingError.passert(False, 'test'):
            pass
    except ProgrammingError as e:
        assert str(e) == 'test'
    try:
        with ProgrammingError.passert(False, '1'), ProgrammingError.passert(False, '2'):
            pass
    except ProgrammingError as e:
        assert str(e) == '1'

# Generated at 2022-06-24 01:14:30.686058
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Expected ProgrammingError to be raised.")


# Generated at 2022-06-24 01:14:33.502011
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("foo")
    except ProgrammingError as err:
        assert str(err) == "foo"
    else:
        raise Exception("The exception has not been raised")


# Generated at 2022-06-24 01:14:34.072391
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()


# Generated at 2022-06-24 01:14:43.646506
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # noinspection PyUnreachableCode
        ProgrammingError.passert(False, "Check your code against domain logic to fix it.")
    except ProgrammingError:
        assert(True)

    try:
        # noinspection PyUnreachableCode
        ProgrammingError.passert(True, "Check your code against domain logic to fix it.")
    except ProgrammingError:
        assert(False)

    try:
        # noinspection PyUnreachableCode
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        assert(False)

    try:
        # noinspection PyUnreachableCode
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        assert(False)

# Generated at 2022-06-24 01:14:49.342104
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError
    """

    # Test of constructor
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as err:
        assert err.args == ("Test",)
    else:
        raise AssertionError("No exception raised")


# Generated at 2022-06-24 01:14:53.716569
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e.args, tuple)
        assert len(e.args) == 1
        assert e.args[0] == 'Broken coherence. Check your code against domain logic to fix it.'
        return
    assert False


# Generated at 2022-06-24 01:14:56.476938
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # noinspection PyUnusedLocal
    def _TestProgrammingError():
        error = ProgrammingError("my message")

    assert _TestProgrammingError.__name__ == "test_ProgrammingError.<locals>._TestProgrammingError"
    assert _TestProgrammingError.__qualname__ == "_TestProgrammingError"
    _TestProgrammingError()

# Generated at 2022-06-24 01:15:02.287324
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error message.")
    except ProgrammingError as e:
        assert e.args[0] == "Some error message."
    else:
        raise AssertionError("The assertion did not raise as expected.")


# Generated at 2022-06-24 01:15:07.700590
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test")
    except Exception as ae:
        assert isinstance(ae, ProgrammingError) is True
        expected = "Test"
        actual = str(ae)
        assert expected == actual


# Generated at 2022-06-24 01:15:13.555004
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert str(ProgrammingError) == "pypara.programming_error.ProgrammingError"
    assert str(ProgrammingError()) == ""
    assert str(ProgrammingError("Test")) == "Test"
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as err:
        assert "Test" == err.args[0]
    assert None is ProgrammingError.passert(True, "Test")
    assert None is ProgrammingError.passert(True, None)

# Generated at 2022-06-24 01:15:16.894327
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("The programmer screws up")
    except ProgrammingError as e:
        assert str(e) == "The programmer screws up"
    else:
        assert False, "ProgrammingError has not been raised"


# Generated at 2022-06-24 01:15:24.436229
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass

    try:
        ProgrammingError("Hello")
    except ProgrammingError:
        pass

    # Empty conditions are not allowed
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass

    # True conditions are not allowed
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:15:26.365806
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(None)


# Generated at 2022-06-24 01:15:27.696282
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for :py:class:`ProgrammingError`."""

    # Test constructor
    assert ProgrammingError("foo") is not None

# Generated at 2022-06-24 01:15:33.662346
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest.mock import call
    from pytest import raises
    with raises(ProgrammingError) as pytest_event:
        ProgrammingError(message="test_ProgrammingError")
    assert pytest_event.value.args == ("test_ProgrammingError",)
    assert str(pytest_event.value) == "test_ProgrammingError"
    # end with
# end test_ProgrammingError



# Generated at 2022-06-24 01:15:37.581643
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(condition=True, message="Ok."):
        pass
    with ProgrammingError.passert(condition=False, message="Failing due to a system failure."):
        pass

# Unit tests for passert

# Generated at 2022-06-24 01:15:40.232569
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Fail!")
    except ProgrammingError as err:
        assert str(err) == "Fail!"



# Generated at 2022-06-24 01:15:45.914854
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError.passert(True, "")
        assert False, "Expected ProgrammingError excepted but not raised"
    except ProgrammingError:
        assert True, "Expected ProgrammingError raised"


# Generated at 2022-06-24 01:15:50.355079
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("A ProgrammingError")
    except ProgrammingError as ex:
        assert ex.args == ("A ProgrammingError",)


# Generated at 2022-06-24 01:15:55.019783
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, 'check this')

# Generated at 2022-06-24 01:15:57.474165
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:16:00.291912
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("whatever message")
    except ProgrammingError as e:
        assert str(e) == "whatever message"
    else:
        assert False, "not raised"


# Generated at 2022-06-24 01:16:03.013194
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test case for ProgrammingError class."""
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass



# Generated at 2022-06-24 01:16:08.058493
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """"
    Tests the constructor of class ProgrammingError
    """
    assert issubclass(ProgrammingError, Exception)
    assert ProgrammingError("Oops").args[0] == "Oops"
    assert ProgrammingError("Oops").__cause__ is None


# Generated at 2022-06-24 01:16:09.887483
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a ProgrammingError")
    except ProgrammingError as e:
        assert str(e) == "This is a ProgrammingError"


# Generated at 2022-06-24 01:16:12.018535
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "This is a programming error."
    pe = ProgrammingError(msg)
    assert pe.args == (msg,)

# Generated at 2022-06-24 01:16:13.623472
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Whatever")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:16:18.862977
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as e:
        ProgrammingError("Test.")
    assert str(e.value) == "Test."


# Generated at 2022-06-24 01:16:21.629015
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Sample programming error message"
    expected = "pypara.ProgrammingError: %s" % message
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        result = str(e)
        assert result == expected

# Generated at 2022-06-24 01:16:24.331228
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check that the constructor doesn't raise any exception
    ProgrammingError("Test")


# Generated at 2022-06-24 01:16:29.253228
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test to check the constructor of class.

    :return: None.
    """
    try:
        raise ProgrammingError(None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError("dummy")
    except ProgrammingError as e:
        assert str(e) == "dummy"

# Generated at 2022-06-24 01:16:32.981817
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Some error.")
    except Exception as ex:
        pass
    assert isinstance(ex, ProgrammingError)
    assert str(ex) == "Some error."


# Generated at 2022-06-24 01:16:37.830479
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Should raise a ProgrammingError.")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Should have raised a ProgrammingError.")


# Generated at 2022-06-24 01:16:43.057987
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    class Fake:
        """
        Provides a fake class.
        """

    try:
        ProgrammingError.passert(False, "A message.")
    except ProgrammingError as ex:
        assert ex.args[0] == "A message."


# Generated at 2022-06-24 01:16:45.649538
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="My error message")
    except ProgrammingError as exc:
        assert str(exc) == "Broken coherence. My error message"


# Generated at 2022-06-24 01:16:51.790997
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Expected condition not met")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)
        assert str(e) == "Expected condition not met"


# Generated at 2022-06-24 01:16:56.904767
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "unit test")
        assert False, "ProgrammingError should have been raised"
    except ProgrammingError as exc:
        assert str(exc) == "unit test", "Error message should be as intended"

# Generated at 2022-06-24 01:16:57.748186
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is an error message")

# Generated at 2022-06-24 01:17:00.117611
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as error:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:17:02.034095
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Hello"):
        raise ProgrammingError("World!")

# Generated at 2022-06-24 01:17:08.886735
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.

    :return: ``None``
    """
    expected_msg = "My custom message"
    try:
        raise ProgrammingError(expected_msg)
    except ProgrammingError as exception:
        assert expected_msg in str(exception)


# Generated at 2022-06-24 01:17:09.835862
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyTypeChecker
    ProgrammingError()

# Generated at 2022-06-24 01:17:14.696875
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError) as excinfo:
        raise ProgrammingError("Initialize me!")
    assert excinfo.value.args[0] == "Initialize me!"
    # The following statement raises an exception
    ProgrammingError.passert(False, "Initialize me!")

# Generated at 2022-06-24 01:17:20.782435
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("error")
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(False, "error")
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(True, "error")
    except ProgrammingError as e:
        raise e

# Generated at 2022-06-24 01:17:28.615140
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert ProgrammingError.__str__ is not Exception.__str__
    assert ProgrammingError.__init__ is not Exception.__init__
    assert ProgrammingError.__init__(ProgrammingError(), "message") is None
    assert ProgrammingError.__str__(ProgrammingError("message")) == "message"
    assert ProgrammingError(None).__str__() == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError("message")
    except ProgrammingError as e:
        assert ProgrammingError.__str__(e) == "message"
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert ProgrammingError.__str__(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:17:30.747355
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Unit Test")
    except ProgrammingError as error:
        assert str(error) == "Unit Test"


# Generated at 2022-06-24 01:17:37.603734
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a message")
    except ProgrammingError as error:
        assert error.args[0] == "This is a message"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:17:38.850316
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)

# Generated at 2022-06-24 01:17:45.550066
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "This should not raise an exception")
    except ProgrammingError as e:
        assert False

    try:
        ProgrammingError.passert(False, "This should raise an exception")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:17:50.729441
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Just a test.")
    except ProgrammingError as e:
        assert str(e) == "Just a test."


# Generated at 2022-06-24 01:17:56.502064
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected_message = "message"
    try:
        raise ProgrammingError(expected_message)
    except ProgrammingError as e:
        actual_message = e.args[0]
    assert actual_message == expected_message

# Unit tests for function ProgrammingError.passert

# Generated at 2022-06-24 01:17:58.361353
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-24 01:18:03.547142
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except:
        assert False, "Unexpected ProgrammingError()"
    try:
        ProgrammingError("Foo")
    except:
        assert False, "Unexpected ProgrammingError(\"Foo\")"
