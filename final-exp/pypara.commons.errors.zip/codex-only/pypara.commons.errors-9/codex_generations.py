

# Generated at 2022-06-24 01:08:06.776273
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"

# Generated at 2022-06-24 01:08:09.872504
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Some error here for testing.")
    except ProgrammingError:
        pass

# Unit tests for classmethod passert of class ProgrammingError

# Generated at 2022-06-24 01:08:11.633931
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Something is not working")
        assert False
    except ProgrammingError:
        assert True

# Generated at 2022-06-24 01:08:13.510711
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing the error constructor.")
    except ProgrammingError as _:
        assert True
    else:
        assert False

# Generated at 2022-06-24 01:08:15.215067
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "abc")

# Generated at 2022-06-24 01:08:19.232142
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of :py:class:`ProgrammingError`."""
    error = ProgrammingError("mocked")
    assert error.args == ("mocked",)


# Generated at 2022-06-24 01:08:21.274926
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "test")
    try:
        ProgrammingError.passert(False, "test")
        raise Exception("ProgrammingError not raised")
    except ProgrammingError as e:
        assert "test" == e.args[0]

# Generated at 2022-06-24 01:08:22.907015
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("my message")
    except ProgrammingError as e:
        assert str(e) == "my message"


# Generated at 2022-06-24 01:08:28.180545
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert error.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-24 01:08:28.844257
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()



# Generated at 2022-06-24 01:08:31.428609
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Should not raise any exception
    ProgrammingError.passert(True, None)
    # Should not raise any exception
    ProgrammingError.passert(True, "")
    # Should raise the exception
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:08:35.725243
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:08:40.036573
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(condition=True, message=None):
        pass

    with ProgrammingError.passert(condition=False, message=""):
        assert False, "This is expected to raise an exception."

    with ProgrammingError.passert(condition=False, message=None):
        assert False, "This is expected to raise an exception."


# Generated at 2022-06-24 01:08:42.573325
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the ProgrammingError
    """
    error = ProgrammingError("Test")
    # Test type of exception
    assert isinstance(error, Exception)


# Generated at 2022-06-24 01:08:44.673980
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")



# Generated at 2022-06-24 01:08:49.824408
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("TEST")
    except ProgrammingError as err:
        assert err.args[0] == "TEST"
    else:
        raise Exception("Exception was not raised")


# Generated at 2022-06-24 01:08:54.287558
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == ""
        assert repr(e) == "ProgrammingError()"

    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
        assert repr(e) == "ProgrammingError('This is a test')"

# Generated at 2022-06-24 01:08:56.499363
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:08:59.051970
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test error.")
    except ProgrammingError as e:
        assert type(e) is ProgrammingError
        assert str(e) == "This is a test error."

# Generated at 2022-06-24 01:09:06.055387
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Act
    try:
        ProgrammingError.passert(False, "message")

        # Assert
        assert False, "Should never reach here"
    except ProgrammingError as e:
        # Assert
        assert e.args[0] == "message"

    # Act
    try:
        ProgrammingError.passert(False, None)

        # Assert
        assert False, "Should never reach here"
    except ProgrammingError as e:
        # Assert
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    # Act
    ProgrammingError.passert(True, None)
    ProgrammingError.passert(True, "message")

# Generated at 2022-06-24 01:09:08.826731
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`. The reason to test the constructor is to ensure that
    the constant :py:class:`ProgrammingError.passert` is properly initialized.
    """
    raised = False
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        raised = True
    finally:
        assert raised

# Generated at 2022-06-24 01:09:09.859974
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an intentional failure")
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:09:11.090975
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error")
    except ProgrammingError as e:
        assert e.args[0] == "This is a programming error"


# Generated at 2022-06-24 01:09:13.837979
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "foo")
    ProgrammingError.passert(False, None)
    try:
        ProgrammingError.passert(False, "foo")
    except Exception as e:
        assert type(e) is ProgrammingError and e.args == ("foo",)
    try:
        ProgrammingError.passert(False, None)
    except Exception as e:
        assert type(e) is ProgrammingError and e.args == ("Broken coherence. Check your code against domain logic to fix it.",)

# Generated at 2022-06-24 01:09:14.749025
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This should raise an error.")
        assert False
    except ProgrammingError:
        assert True

# Generated at 2022-06-24 01:09:15.793072
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
        assert False
    except ProgrammingError as error:
         assert error.args[0] == "Test"

# Generated at 2022-06-24 01:09:16.233243
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Something is wrong")

# Generated at 2022-06-24 01:09:20.625947
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Something is wrong")
        assert False
    except ProgrammingError as error:
        assert str(error) == "Something is wrong"

# Generated at 2022-06-24 01:09:25.008396
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing programming error")
    except ProgrammingError as error:
        assert error.args == ("Testing programming error",)


# Generated at 2022-06-24 01:09:29.452005
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        assert False
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        assert True
    try:
        ProgrammingError.passert(False, "Error")
    except ProgrammingError as e:
        assert str(e) == "Error"

# Generated at 2022-06-24 01:09:37.526045
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase, main
    from unittest.mock import patch, Mock

    class TestProgrammingError(TestCase):
        def test_constructor_with_message(self):
            ProgrammingError("This is a message")

        @patch("sys.stdout", new_callable=Mock)
        def test_assert(self, stdout):
            ProgrammingError.passert(True, "This is a message")
            stdout.write.assert_not_called()

        @patch("sys.stdout", new_callable=Mock)
        def test_assert_with_fail(self, stdout):
            with self.assertRaises(ProgrammingError):
                ProgrammingError.passert(False, "This is a message")
            stdout.write.assert_not_called()


# Generated at 2022-06-24 01:09:41.487563
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    def test_constructor_message_not_valid_asserts_false():
        assert False == ( lambda: ProgrammingError(message='A message') ).__bool__()
        # We cannot use the assert statement directly in the lambda expression because we define an attribute
        # with the same name which should not be shadowed.
        
    try:
        ProgrammingError(message='A message')
    except ProgrammingError:
        test_constructor_message_not_valid_asserts_false()
        pass
    else:
        assert False



# Generated at 2022-06-24 01:09:45.217512
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(condition=False, message="")
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(condition=False, message="foobar")

# Generated at 2022-06-24 01:09:48.378426
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyTypeChecker
    ProgrammingError(None)


# Generated at 2022-06-24 01:09:50.627279
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.error import ProgrammingError

    with raises(ProgrammingError, match=r"Barf"):
        ProgrammingError("Barf")

# Generated at 2022-06-24 01:09:54.261074
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        raise ProgrammingError()
    with raises(ProgrammingError):
        raise ProgrammingError("Test error message")
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Test error message")

# Generated at 2022-06-24 01:09:56.410966
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert issubclass(ProgrammingError, BaseException)


# Generated at 2022-06-24 01:09:59.498379
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "This will never execute")
    try:
        ProgrammingError.passert(False, "This is a message")
        assert False
    except ProgrammingError as e:
        assert str(e) == "This is a message"

# Generated at 2022-06-24 01:10:00.914120
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Testing 1") as e:
        raise e
    pass

# Generated at 2022-06-24 01:10:01.989053
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test"):
        raise ProgrammingError("Test")

# Generated at 2022-06-24 01:10:02.990626
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:10:05.351026
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "A message")

# Generated at 2022-06-24 01:10:10.308377
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # WHEN creating an instance of ProgrammingError as PYPI provides
    # THEN the message matches the default message provided by the constructor
    example = ProgrammingError()
    assert example.args == ["Broken coherence. Check your code against domain logic to fix it."]
    # THEN the error is the same for any other message provided
    example2 = ProgrammingError("testing context")
    assert example2.args == example.args


# Generated at 2022-06-24 01:10:13.556053
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Great! Keep going."):
        pass
    try:
        with ProgrammingError.passert(False, "The sky is falling!"):
            raise Exception()
    finally:
        # The exception is not raised here
        pass
    assert True


# Generated at 2022-06-24 01:10:17.609676
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("ProgrammingError test")
    except ProgrammingError as e:
        assert e.args[0] == "ProgrammingError test"
    else:
        assert False, "Exception not raised"


# Generated at 2022-06-24 01:10:23.551612
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)
        assert ProgrammingError == type(e)


# Generated at 2022-06-24 01:10:25.072857
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-24 01:10:28.197468
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the :py:class:`ProgrammingError`.
    """
    import pytest
    try:
        ProgrammingError("test")
    except Exception as e:
        pytest.fail("Unexpected error: " + str(e))


# Generated at 2022-06-24 01:10:33.323071
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.

    :return: ``None``
    """
    with ProgrammingError("message"):
        raise ProgrammingError("message")


# Generated at 2022-06-24 01:10:37.108522
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "some message")
    except ProgrammingError as e:
        assert str(e) == "some message"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:10:42.394491
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as info:
        raise ProgrammingError("Wrong message.")
    assert "Wrong message." == str(info.value)


# Generated at 2022-06-24 01:10:46.456927
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My message")
    except ProgrammingError as ex:
        assert str(ex) == "My message"


# Generated at 2022-06-24 01:10:49.894864
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:10:52.415862
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the programming error constructor.

    :return: ``None``
    """
    assert ProgrammingError is ProgrammingError, "Constructor is identity."
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it.", "Empty constructor"
    try:
        ProgrammingError.passert(False, "No error here")
    except ProgrammingError as e:
        assert str(e) == "No error here", "Customized constructor"

# Generated at 2022-06-24 01:10:58.415009
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pyassert import assert_that
    from pypara.errors import ProgrammingError

    try:
        ProgrammingError()
        raise AssertionError("ProgrammingError() expected to throw an exception")
    except TypeError:
        pass
    try:
        ProgrammingError.passert(False, "Some message")
        raise AssertionError("ProgrammingError.passert(False, 'Some message') expected to throw an exception")
    except ProgrammingError:
        pass
    ProgrammingError.passert(True, "Some message")
    assert_that(True).is_equal_to(True)

# Generated at 2022-06-24 01:11:01.631242
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Raises an exception with the provided message.
    """
    try:
        raise ProgrammingError("EXCEPTION")
    except ProgrammingError as err:
        assert str(err) == "EXCEPTION"


# Generated at 2022-06-24 01:11:03.186447
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("Error message")


# Generated at 2022-06-24 01:11:07.453995
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=unused-argument
    def create():
        ProgrammingError()
    try:
        create()
    except ProgrammingError as error:
        assert "Broken coherence" in str(error)
        try:
            create()
        except ProgrammingError as error:
            assert "Broken coherence" in str(error)


# Generated at 2022-06-24 01:11:13.288426
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is just a test.")
        assert False
    except ProgrammingError as e:
        assert str(e) == "This is just a test."

# Generated at 2022-06-24 01:11:24.555888
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError.passert(True, "A message defining the error")
    assert ProgrammingError.passert(True, None)
    try:
        ProgrammingError.passert(False, "A message defining the error")
        assert False, "Should have raised a ProgrammingError"
    except ProgrammingError as e:
        assert "Broken coherence." in str(e)
    try:
        ProgrammingError.passert(False, None)
        assert False, "Should have raised a ProgrammingError"
    except ProgrammingError as e:
        assert "Broken coherence." in str(e)
    try:
        raise ProgrammingError("A message defining the error")
    except ProgrammingError as e:
        assert "A message defining the error" in str(e)

# Generated at 2022-06-24 01:11:29.064422
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    ProgrammingError("A custom error message")


# Generated at 2022-06-24 01:11:33.742184
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Empty constructor
    pe1 = ProgrammingError()
    assert pe1
    assert str(pe1) == "Broken coherence. Check your code against domain logic to fix it."

    # Parametrized constructor
    pe2 = ProgrammingError("Custom Message")
    assert pe2
    assert str(pe2) == "Custom Message"

# Generated at 2022-06-24 01:11:40.862533
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == 'Broken coherence. Check your code against domain logic to fix it.'
    else:
        assert False, 'ProgrammingError was not raised'

    # Unit test for passert method of class ProgrammingError
    try:
        ProgrammingError.passert(False, 'Should raise a ProgrammingError')
    except ProgrammingError as e:
        assert str(e) == 'Should raise a ProgrammingError'
    else:
        assert False, 'ProgrammingError was not raised'

    try:
        ProgrammingError.passert(True, 'Should not raise a ProgrammingError')
    except ProgrammingError as e:
        assert False, 'ProgrammingError was raised'
    else:
        assert True

# Generated at 2022-06-24 01:11:45.145929
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the constructor of the class :py:class:`ProgrammingError` raises the exception as expected.
    """
    error = ProgrammingError("Message")
    assert error.args == ("Message",)


# Generated at 2022-06-24 01:11:49.969668
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():  # pragma: no cover
    #
    # Raise an error to make sure that the caller has the opportunity to catch ProgrammingError
    #
    try:
        ProgrammingError.passert(condition=False, message="")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:11:53.965252
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected_message = "Test message"
    with pytest.raises(ProgrammingError) as e:
        ProgrammingError(expected_message)
    assert e.value.args[0] == expected_message, f"Expected message '{expected_message}', got '{e.value.args[0]}'"



# Generated at 2022-06-24 01:11:55.817695
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError("Just for testing purposes.")
    except ProgrammingError as e:
        assert e.args[0] == "Just for testing purposes."


# Generated at 2022-06-24 01:11:57.407012
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Expect condition to fail")
    except ProgrammingError:
        assert True
        return
    assert False

# Generated at 2022-06-24 01:11:58.481800
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("This is a test error.")
    assert e


# Generated at 2022-06-24 01:12:03.422070
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "M")
        raise AssertionError("Code did not raise ProgrammingError")
    except ProgrammingError as e:
        assert e.args == ("M",)
    assert not ProgrammingError.passert(True, "M")


# Generated at 2022-06-24 01:12:10.327624
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    try:
        raise ProgrammingError("Error")
    except ProgrammingError as err:
        assert str(err) == "Error"
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Error")


# Generated at 2022-06-24 01:12:13.142062
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected = "Broken coherence. Check your code against domain logic to fix it."
    actual = ProgrammingError().args[0]
    assert actual == expected



# Generated at 2022-06-24 01:12:15.043375
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        raise ProgrammingError('boom!')

    assert str(excinfo.value) == 'boom!'


# Generated at 2022-06-24 01:12:16.461685
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as error:
        assert str(error) == "Error message"


# Generated at 2022-06-24 01:12:20.462242
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Something went wrong!")
    except ProgrammingError as e:
        assert str(e) == "Something went wrong!"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:12:24.474574
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, None)
        ProgrammingError.passert(False, "")
        ProgrammingError.passert(False, "This is a message")
    except ProgrammingError as exc:
        assert str(exc) in ("Broken coherence. Check your code against domain logic to fix it.",
                            "This is a message")


# Check if the test fails
if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-24 01:12:30.196822
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError` for basic operation.

    :return: ``None``.
    """
    error = ProgrammingError("Message of an error")
    assert isinstance(error, Exception)
    assert error.args == ("Message of an error",)


# Generated at 2022-06-24 01:12:34.338797
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:12:36.922270
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:12:41.261543
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Not met condition.")
    except ProgrammingError as e:
        assert "Not met condition." == str(e)

# Generated at 2022-06-24 01:12:47.486097
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    assert_message = "Expected"  # type: str

    # THEN
    assert_message_exception = assert_message
    try:
        # WHEN
        ProgrammingError(assert_message_exception)
        assert False, "Expected a ProgrammingError"
    except ProgrammingError as e:
        # THEN
        assert e.args == (assert_message_exception,)


# Generated at 2022-06-24 01:12:49.159142
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    # Act
    # Assert
    ProgrammingError(None)
    ProgrammingError("")
    ProgrammingError("message")


# Generated at 2022-06-24 01:12:55.304149
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    message = "This is just a test."

    # Act & Assert
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert str(e) == message



# Generated at 2022-06-24 01:12:59.427443
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as exc:
        ProgrammingError.passert(False, "Test for attribute message")
    assert str(exc.value) == "Test for attribute message"

# Generated at 2022-06-24 01:13:02.531333
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of the :py:class:`ProgrammingError` class."""
    try:
        raise ProgrammingError("Error message.")
    except ProgrammingError as e:
        assert str(e) == "Error message."
    else:
        raise AssertionError("Expected exception ProgrammingError.")


# Generated at 2022-06-24 01:13:10.541771
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # This should not raise a ProgrammingError
    ProgrammingError.passert(True, "")

    try:
        # This should raise a ProgrammingError
        ProgrammingError.passert(False, "The function __eq__ is not behaving as expected.")
    except ProgrammingError as e:
        assert str(e) == "The function __eq__ is not behaving as expected."

    try:
        # This should raise a ProgrammingError
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:13:13.264103
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for class ProgrammingError."""
    # Create a new exception
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        # Test that the exception has been created
        assert isinstance(ex, ProgrammingError)


# Generated at 2022-06-24 01:13:17.660420
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("something went wrong")
    except ProgrammingError:
        pass



# Generated at 2022-06-24 01:13:19.445894
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("message")

# Generated at 2022-06-24 01:13:22.204762
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test: it works")  # pragma: no cover
    except ProgrammingError as e:
        assert e.args[0] == "Test: it works"

# Generated at 2022-06-24 01:13:26.884943
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error has occurred")
    except ProgrammingError as e:
        assert e.args[0] == "A programming error has occurred"
        assert len(e.args) == 1
        assert e.args == ("A programming error has occurred",)


# Generated at 2022-06-24 01:13:29.496031
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"

# Generated at 2022-06-24 01:13:35.260279
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Invoke constructor without message
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "broken coherence. check your code against domain logic to fix it."
    # Invoke constructor with message
    try:
        raise ProgrammingError("This is the message")
    except ProgrammingError as e:
        assert str(e) == "This is the message"


# Generated at 2022-06-24 01:13:42.800221
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.

    :raises AssertionError: In case that the constructor does not behave as expected.
    """
    try:
        raise ProgrammingError("broke")
    except ProgrammingError as e:
        assert e.args == ("broke",)
    else:
        raise AssertionError("Unable to raise ProgrammingError.")


# Generated at 2022-06-24 01:13:46.102995
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except Exception as e:
        assert e.args[0] == "test"


# Generated at 2022-06-24 01:13:48.747682
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError constructor should work."


# Generated at 2022-06-24 01:13:52.973026
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Oops! There must be something wrong with our code, because I just raised this error.")
    except ProgrammingError:
        assert True
    else:
        assert False, "It seems that the constructor of ProgrammingError class is broken."
    # This assertion (and the subsequent "gotcha") will be removed once we switch to pytest
    assert not ProgrammingError.passert(False, "This error has been raised on purpose, so don't panic!")



# Generated at 2022-06-24 01:13:56.544241
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as error:
        assert error.args == ("This is an error",)


# Generated at 2022-06-24 01:14:00.251934
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        with ProgrammingError.passert(True, "Foo"):
            pass
    except ProgrammingError as e:
        print("ProgrammingError.passert() raised '" + e.args[0] + "' when it should not.")  # pragma: no cover


# Generated at 2022-06-24 01:14:02.003932
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.__str__() == "Test"


# Generated at 2022-06-24 01:14:06.824870
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is the message.")
    except ProgrammingError as e:
        assert str(e) == "This is the message."


# Generated at 2022-06-24 01:14:10.331985
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("test") as exc:
        assert exc.args[0] == "test"
        assert exc.msg == "test"
    with ProgrammingError(None) as exc:
        assert exc.args[0] == None
        assert exc.msg == None


# Generated at 2022-06-24 01:14:12.892762
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="test")
    except Exception as ex:
        assert ex.args[0] == "test"


# Generated at 2022-06-24 01:14:16.538194
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test the constructor of class ProgrammingError."""
    error = ProgrammingError(message="No message.")
    assert error.args == ("No message.",)

# Generated at 2022-06-24 01:14:20.013906
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Just a test")
    except ProgrammingError as e:
        assert e.args[0] == "Just a test"
    else:
        raise Exception("ProgrammingError has not been raised")


# Generated at 2022-06-24 01:14:28.418611
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def tester(condition, message, thrown):
        try:
            ProgrammingError.passert(condition, message)
        except ProgrammingError as e:
            assert e.args[0] == thrown or message, 'Error message does not match expected value: %s' % thrown
            return
        assert False, 'Provided condition should raise an exception, but nothing was raised'

    # Testing nominal path
    try:
        ProgrammingError.passert(True, "Test message")
    except ProgrammingError:
        assert False, 'A closed condition should not raise an exception'

    # Testing error code with empty message
    tester(False, None, 'Broken coherence. Check your code against domain logic to fix it.')

    # Testing error code with filled message
    tester(False, 'Test message', 'Test message')

# Generated at 2022-06-24 01:14:31.902874
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)

# Generated at 2022-06-24 01:14:38.720102
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        assert False

    try:
        ProgrammingError.passert(False, "message")
    except ProgrammingError as ex:
        assert "message" == ex.args[0]
    else:
        assert False

# Generated at 2022-06-24 01:14:41.834705
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Message")
        assert False, "Exception shall be raised"
    except ProgrammingError as e:
        assert str(e) is not None, "Error message shall not be empty"

# Generated at 2022-06-24 01:14:45.594870
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # <editor-fold desc="Arrange & Act">
    PE = ProgrammingError("This is a test")
    # </editor-fold>

    # <editor-fold desc="Assert"></editor-fold>
    assert PE.args[0] == "This is a test"

# Generated at 2022-06-24 01:14:50.482466
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of class ProgrammingError"""
    try:
        raise ProgrammingError("Something is wrong")
    except ProgrammingError as pe:
        assert pe.args == ("Something is wrong",)


# Generated at 2022-06-24 01:14:58.290891
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "This is True") # Should not raise an error
        ProgrammingError.passert(False, "This is False")
    except ProgrammingError as exception:
        assert str(exception) == "This is False"
    else:
        assert False # ProgrammingError was not raised

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as exception:
        assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False # ProgrammingError was not raised

# Generated at 2022-06-24 01:15:03.371855
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class Dummy:
        def __init__(self):
            ProgrammingError.passert(True, "This is wrong!")
            try:
                ProgrammingError()
            except ProgrammingError as e:
                assert e.args[0] == "Can't instantiate abstract class ProgrammingError with abstract methods passert"
                assert str(e) == "Can't instantiate abstract class ProgrammingError with abstract methods passert"
            else:
                assert False, "ProgrammingError class should not be instantiable!"
    Dummy()

# Generated at 2022-06-24 01:15:06.740499
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-24 01:15:12.410320
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError
    """
    # Should raise ProgrammingError
    try:
        ProgrammingError.passert(False, "ProgrammingErrors must be raised.")
        assert False, "ProgrammingError should have been raised."
    except ProgrammingError as e:
        assert str(e) == "ProgrammingErrors must be raised.", "Wrong message: " + str(e)
error_classes = [ProgrammingError]

# Generated at 2022-06-24 01:15:16.026637
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("I'm the message")
    except ProgrammingError as e:
        assert str(e) == "I'm the message"
    except Exception:
        assert False, "Should not be caught by this handler"


# Generated at 2022-06-24 01:15:17.841150
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("I am programming error")
    assert str(error) == "I am programming error"


# Generated at 2022-06-24 01:15:21.005510
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Error message")
    except Exception as e:
        assert str(e) == "Error message"


# Generated at 2022-06-24 01:15:22.078074
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('This is a test')
    except ProgrammingError as e:
        assert str(e) == 'This is a test'


# Generated at 2022-06-24 01:15:27.017627
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    from pytest import raises

    with raises(ProgrammingError) as e:
        ProgrammingError.passert(False, "Some message")

    assert "Some message" == str(e.value)

    with raises(ProgrammingError) as e:
        ProgrammingError.passert(False, None)

    assert "Broken coherence. Check your code against domain logic to fix it." == str(e.value)

# Generated at 2022-06-24 01:15:28.759124
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Condition isn't met")
    except ProgrammingError as e:
        assert e.args[0] == "Condition isn't met"
    else:
        raise Exception("ProgrammingError wasn't raised")


# Generated at 2022-06-24 01:15:37.333508
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "No error expected")
    try:
        ProgrammingError.passert(False, "Error expected")
        raise Exception("Exception was not raised!")
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, None)
        raise Exception("Exception was not raised!")
    except ProgrammingError:
        pass



# Unit tests for this module.
if __name__ == "__main__":
    import __main__
    import inspect
    import sys


# Generated at 2022-06-24 01:15:39.542468
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError()



# Generated at 2022-06-24 01:15:43.504061
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="This is an error message")
    except ProgrammingError as pe:
        assert pe.args[0] == "This is an error message"
    else:
        raise AssertionError("No exception raised")


# Generated at 2022-06-24 01:15:46.095314
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test error.")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Test failed.")


# Generated at 2022-06-24 01:15:48.632159
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError


# Generated at 2022-06-24 01:15:51.834043
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected_str = "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert expected_str == str(e)


# Generated at 2022-06-24 01:16:00.377482
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # The aim of the test is to get a ProgrammingError from the fundamental constructor
    # noinspection PyTypeChecker
    try:
        raise ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)
        assert issubclass(ProgrammingError, Exception)
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    else:
        assert False, "Should have raised a ProgrammingError"



# Generated at 2022-06-24 01:16:03.720798
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Testing the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("This is an error for testing.")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:16:08.436518
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    The constructor of :py:class:`ProgrammingError` must have no effect.
    """
    try:
        ProgrammingError()
    except ProgrammingError as exception:
        assert False, f"An exception has been raised while none was expected: {str(exception)}"


# Generated at 2022-06-24 01:16:14.265335
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Error 1")

    ProgrammingError.passert(True, "Correct, nothing should happen")
    ProgrammingError.passert(True, None)

# Generated at 2022-06-24 01:16:21.293320
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == e.args[0]
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:16:24.578748
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a message")
    except ProgrammingError as e:
        assert str(e) == "This is a message"

# Generated at 2022-06-24 01:16:33.402977
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit tests for the constructor of :py:class:`ProgrammingError`.
    """
    try:
        # First just test that the error is raised
        ProgrammingError("")
        assert(False), "Must raise an exception"
    except ProgrammingError:
        # Do nothing, that's the expected result
        pass

    # Now test that the error is raised with the correct message
    try:
        ProgrammingError("MESSAGE")
        assert(False), "Must raise an exception"
    except ProgrammingError as err:
        assert(str(err) == "MESSAGE"), "Wrong exception message"

# unit test for passert() method of class ProgrammingError

# Generated at 2022-06-24 01:16:35.197655
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected = "Testing message for this programming error."
    error = ProgrammingError(expected)
    assert str(error) == expected


# Generated at 2022-06-24 01:16:38.258185
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        pass  # Do nothing
    assert str(ex) == ""
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as ex:
        pass  # Do nothing
    assert str(ex) == "Message"


# Generated at 2022-06-24 01:16:46.415014
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Test message"
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:16:50.807317
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-24 01:16:58.959676
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check that the error reflects the message provided
    try:
        raise ProgrammingError("Some bug in the programming")
    except ProgrammingError as e:
        assert "Some bug in the programming" in str(e)

    # Check that it has a default message
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." in str(e)


# Generated at 2022-06-24 01:17:00.715417
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('Oh, no!')
    except ProgrammingError as err:
        assert str(err) == 'Oh, no!'


# Generated at 2022-06-24 01:17:04.670671
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message of the error")
    except ProgrammingError as error:
        assert error.args[0] == "Message of the error"


# pylint: disable=protected-access

# Generated at 2022-06-24 01:17:10.722051
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Everything is fine."):
        pass

    try:
        with ProgrammingError.passert(False, "Everything is not fine."):
            pass
    except ProgrammingError as error:
        assert str(error) == "Everything is not fine."
    else:
        assert False, "Expected ProgrammingError"

# Generated at 2022-06-24 01:17:16.198232
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if the constructor of class ProgrammingError raises an exception with a given message.
    """
    with ProgrammingError(message="Any message") as exception:
        raise exception

# Generated at 2022-06-24 01:17:17.558908
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="x")
        assert False
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "x"


# Generated at 2022-06-24 01:17:19.577951
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Some error")

# Generated at 2022-06-24 01:17:21.910325
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("You have a bug")
    except ProgrammingError as ex:
        assert ex.message == "You have a bug"


# Generated at 2022-06-24 01:17:24.299179
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError("Programming Error")
    except ProgrammingError as err:
        assert str(err) == "Programming Error"
        assert isinstance(err, Exception)


# Generated at 2022-06-24 01:17:28.411793
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Custom message")
    except ProgrammingError as e:
        assert e.args[0] == "Custom message"


# Generated at 2022-06-24 01:17:31.658130
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # When
    try:
        ProgrammingError(None)
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:17:34.779092
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        assert True


# Generated at 2022-06-24 01:17:38.298705
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Checks that the ProgrammingError class initializes properly.

    :return: Nothing.
    """
    with ProgrammingError("Test message"):
        pass



# Generated at 2022-06-24 01:17:40.219048
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:17:41.536860
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except:
        assert True

# Generated at 2022-06-24 01:17:47.788427
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Unit-test message")
    except ProgrammingError as error:
        assert error is not None, "Error should not be empty."
        assert str(error) == "Unit-test message", "Error message does not match expected."
    else:
        raise AssertionError("A ProgrammingError should have been raised.")

# Generated at 2022-06-24 01:17:49.764951
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(None)
    ProgrammingError("")
    ProgrammingError("Hello World")

# Generated at 2022-06-24 01:17:53.884634
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError('')
    except ProgrammingError as e:
        assert not e.args
    else:
        assert False, 'ProgrammingError() should raise ProgrammingError exception'

    try:
        ProgrammingError('Some error message')
    except ProgrammingError as e:
        assert e.args == ('Some error message',)
    else:
        assert False, 'ProgrammingError() should raise ProgrammingError exception'

# Generated at 2022-06-24 01:18:02.422617
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Coherence broken.") # Should raise!
    except ProgrammingError as e:
        assert str(e) == "Coherence broken."
    # Should not raise!
    ProgrammingError.passert(True, "Coherence broken.")
    # Should not raise!
    ProgrammingError.passert(True, None)
    # Should not raise!
    ProgrammingError.passert(False, None)

if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-24 01:18:06.312446
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert str(ex)
