

# Generated at 2022-06-24 01:08:06.505032
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()


# Generated at 2022-06-24 01:08:10.193266
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""

    e = ProgrammingError("foo")

    assert e.args[0] == "foo"


# Generated at 2022-06-24 01:08:15.174428
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): #pylint: disable=no-self-use
    try:
        # pylint: disable=no-member
        raise ProgrammingError("Some message")
    except ProgrammingError as err:
        assert err.args == ("Some message",)


# Generated at 2022-06-24 01:08:17.704407
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    error = "My error"
    # WHEN
    try:
        ProgrammingError(error)
        # THEN
        assert False, "Should not allow to create a ProgrammingError with a message"
    except:
        # THEN
        pass


# Generated at 2022-06-24 01:08:18.927823
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:08:22.010826
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("A test")
    except ProgrammingError as error:
        assert str(error) == "A test"


# Generated at 2022-06-24 01:08:24.118529
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except ProgrammingError as e:
        if str(e) != "test":  # pylint: disable=C0103; # noqa
            raise e


# Generated at 2022-06-24 01:08:27.735231
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Some message.")
    assert error.args[0] == "Some message."


# Generated at 2022-06-24 01:08:31.314137
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # This is a valid test.
    try:
        raise ProgrammingError("Testing...")
    except ProgrammingError as e:
        assert str(e) == "Testing..."


# Generated at 2022-06-24 01:08:37.164449
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert str(e) == "Error message"


# Generated at 2022-06-24 01:08:40.245198
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "We should not be here")
    except ProgrammingError as e:
        if not str(e) == "We should not be here":
            raise ValueError("Expected message: 'We should not be here'. Actual message: '{}'".format(str(e)))
    else:
        raise AssertionError("Expected exception not raised")

# Generated at 2022-06-24 01:08:41.228304
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("message"):
        pass

# Generated at 2022-06-24 01:08:44.476162
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as err:
        assert err.args[0] == "Message"


# Generated at 2022-06-24 01:08:49.498196
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class A(Exception):
        def __init__(self):
            pass
    a = A()
    assert type(a) == A
    assert isinstance(a, Exception)

# Generated at 2022-06-24 01:08:52.700097
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    expected_msg = "Something is terribly wrong."

    # THEN
    try:
        raise ProgrammingError(expected_msg)
    except ProgrammingError as e:
        # THEN
        assert e.args == (expected_msg,)

# Generated at 2022-06-24 01:08:55.180827
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:08:56.974850
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def test_case():
        raise ProgrammingError("This is a test")
    try:
        test_case()
    except ProgrammingError as ex:
        assert str(ex) == "This is a test"

# Generated at 2022-06-24 01:08:57.362595
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("test")

# Generated at 2022-06-24 01:08:59.487622
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.unittest.default_test_case import DefaultTestCase

    class MyTestCase(DefaultTestCase):

        def test_passert(self):
            self.assertRaises(ProgrammingError, ProgrammingError.passert, True, "a message")

    MyTestCase.run_tests()

# Generated at 2022-06-24 01:09:01.480023
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()


# Generated at 2022-06-24 01:09:07.225831
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # noinspection PyTypeChecker
        ProgrammingError(None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False


# Generated at 2022-06-24 01:09:16.322962
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "error_a")
        assert False, "No ProgrammingError raised error_a"
    except ProgrammingError as e:
        assert str(e) == "error_a", "Expected error message error_a"

    try:
        ProgrammingError.passert(False, None)
        assert False, "No ProgrammingError raised error_b"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it.", \
               "Expected error message error_b"

    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        assert False, "ProgrammingError raised"

# Generated at 2022-06-24 01:09:21.835136
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Bye bye!")
    except ProgrammingError as err:
        assert err.args == ("Bye bye!",)
        return err
    assert False, "Exception not raised"


# Generated at 2022-06-24 01:09:26.014496
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the error has the given message.
    """
    message = "The program you've written is wrong!"
    error = ProgrammingError(message)
    assert error.args[0] == message



# Generated at 2022-06-24 01:09:27.555169
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        raise ProgrammingError()


# Generated at 2022-06-24 01:09:29.940145
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error message.")
    except ProgrammingError as e:
        assert str(e) == "This is an error message."
    else:
        raise AssertionError("Did not catch programming error.")


# Generated at 2022-06-24 01:09:34.025120
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected_error_message = "Broken coherence. Check your code against domain logic to fix it."
    with pytest.raises(ProgrammingError) as e:
        ProgrammingError(expected_error_message)

    assert expected_error_message in str(e.value)

# Generated at 2022-06-24 01:09:37.391764
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as e:
        assert str(e) == "This is an error"


# Generated at 2022-06-24 01:09:38.703681
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert str(e) == "This is a test."


# Generated at 2022-06-24 01:09:40.530025
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as err:
        assert type(err) == ProgrammingError
        assert str(err) == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-24 01:09:42.368814
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:09:45.346641
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error.args == ("Broken coherence. Check your code against domain logic to fix it.",)

# Unit tests for passert method of class ProgrammingError

# Generated at 2022-06-24 01:09:49.879809
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError("Intentional error!")
    assert "Intentional error!" in str(excinfo.value)


# Generated at 2022-06-24 01:09:53.534642
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    try:
        ProgrammingError.passert(False, "This is an error")
        raise AssertionError("False condition should raise an exception")
    except ProgrammingError:
        return


# Generated at 2022-06-24 01:09:54.381762
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError()


# Generated at 2022-06-24 01:09:56.708731
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Errei: X = 2")
    except ProgrammingError as e:
        assert str(e) == "Errei: X = 2"


# Generated at 2022-06-24 01:09:58.824433
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-24 01:10:00.269564
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        assert True


# Generated at 2022-06-24 01:10:04.798377
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Expected!")
    except ProgrammingError as e:
        assert str(e) == "Expected!"
    else:
        assert False, "The exception was not raised for an expected error."


# Generated at 2022-06-24 01:10:06.551589
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing")
    except ProgrammingError as e:
        assert e.args[0] == "Testing"


# Generated at 2022-06-24 01:10:08.859139
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-24 01:10:13.949553
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    # Raise an error and test if the message is the expected one
    with pytest.raises(ProgrammingError) as exception_raised:
        ProgrammingError("error message")
    assert exception_raised.value.args[0] == "error message"
    # Raise an error and test if the message is the expected one in case there is no message
    with pytest.raises(ProgrammingError) as exception_raised:
        ProgrammingError()
    assert exception_raised.value.args[0] == "Error without message."


# Generated at 2022-06-24 01:10:17.454445
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Foo")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Constructor of class ProgrammingError does not work as expected.")


# Generated at 2022-06-24 01:10:21.016118
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("This is not a valid Python code")

# Generated at 2022-06-24 01:10:23.836485
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    with raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-24 01:10:25.826055
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("No no... Why are you doing this?!")
    assert error.args[0] == "No no... Why are you doing this?!"

# Generated at 2022-06-24 01:10:30.046414
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check if the exception is successfully thrown
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert(isinstance(e, ProgrammingError))

    # Check if the exception is successfully thrown
    try:
        raise ProgrammingError("Error")
    except ProgrammingError as e:
        assert(isinstance(e, ProgrammingError) and str(e) == "Error")



# Generated at 2022-06-24 01:10:35.184944
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    try:
        ProgrammingError("This is a testing error")
    except ProgrammingError as e:
        assert e.args[0] == "This is a testing error", "Wrong error message."
    except BaseException as e:
        assert False, "Wrong exception was raised: {0}".format(str(e))
    else:
        assert False, "Exception was not raised."


# Generated at 2022-06-24 01:10:36.656454
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Whatever condition"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert str(e) == message

# Generated at 2022-06-24 01:10:39.062886
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError), 'ProgrammingError is expected.'

# unit test for passert method of class ProgrammingError

# Generated at 2022-06-24 01:10:40.917836
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError() # Should not raise
    except ProgrammingError:
        raise AssertionError("ProgrammingError should be raised.")


# Generated at 2022-06-24 01:10:44.691547
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("programming error")
    except ProgrammingError as e:
        assert e.args[0] == "programming error"

# Generated at 2022-06-24 01:10:47.621341
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is the error message.")
    except ProgrammingError as e:
        assert e.args[0] == "This is the error message."

# Generated at 2022-06-24 01:10:53.080338
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as error:
        assert error.args[0] == "This is a test"

# Generated at 2022-06-24 01:10:56.440119
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "This should never rise")
    try:
        ProgrammingError.passert(False, "This is the error message.")
        assert False
    except ProgrammingError as e:
        assert str(e) == "This is the error message."
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:10:59.383293
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:11:04.177425
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, None):
        with ProgrammingError.passert(True, "Custom message"):
            pass

    with ProgrammingError.passert(False, None):
        pass

    with ProgrammingError.passert(False, "Custom message"):
        pass

if __name__ == "__main__":
    # TODO: uncomment for testing
    # test_ProgrammingError()
    pass

# Generated at 2022-06-24 01:11:07.066657
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from assertpy import assert_that

    try:
        raise ProgrammingError()
    except ProgrammingError as exc:
        assert_that(str(exc)).is_equal_to("Broken coherence. Check your code against domain logic to fix it.")



# Generated at 2022-06-24 01:11:11.403742
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Makes sure that an exception is thrown if calling the :py:func:`ProgrammingError.passert` with a ``False``
    condition.
    """
    # noinspection PyBroadException
    try:
        ProgrammingError.passert(False, "This should always raise an exception")
    except ProgrammingError:
        pass
    except:
        raise AssertionError("The exception which was raised does not derive from ProgrammingError.")


# Generated at 2022-06-24 01:11:13.525643
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=protected-access
    error = ProgrammingError("Test message")
    assert error._str == "Test message"

# Generated at 2022-06-24 01:11:17.414613
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Test message 1"):
        pass
    with ProgrammingError.passert(False, "Test message 2"):
        pass  # pragma: no cover

# Generated at 2022-06-24 01:11:19.940385
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Something went wrong...")
    except ProgrammingError:
        pass
    except Exception as e:
        assert False, e


# Generated at 2022-06-24 01:11:23.721087
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        with ProgrammingError.passert(condition=True, message="This is a test for exception."):
            pass
    except ProgrammingError as e:
        assert "This is a test for exception." == e.args[0]
    else:
        raise Exception("Expected exception not found.")

# Generated at 2022-06-24 01:11:28.938451
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "This is the exception message"):
        raise ValueError()

# Generated at 2022-06-24 01:11:31.158417
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is a test of ProgrammingError")
    except ProgrammingError as e:
        assert "This is a test of ProgrammingError" == str(e)


# Generated at 2022-06-24 01:11:35.813065
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.

    :return: ``None``.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

    try:
        raise ProgrammingError("Some error message")
    except ProgrammingError:
        pass


test_ProgrammingError()

# Generated at 2022-06-24 01:11:39.993151
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test exception")
    except ProgrammingError as err:
        assert str(err) == "This is a test exception"


# Generated at 2022-06-24 01:11:44.725531
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Programming error")
    except ProgrammingError as err:
        assert str(err) == "Programming error"


# Generated at 2022-06-24 01:11:46.400171
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("Something horrible happened.")
    assert str(exception) == "Something horrible happened."

# Generated at 2022-06-24 01:11:51.404686
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:meth:`ProgrammingError.passert` by passing and failing conditions.
    """
    try:
        ProgrammingError.passert(True, "Message")
    except ProgrammingError:
        assert False
    try:
        ProgrammingError.passert(False, "Message")
        assert False
    except ProgrammingError:
        assert True
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        assert True

# Generated at 2022-06-24 01:11:52.752684
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Testing constructor of class ProgrammingError")

# Generated at 2022-06-24 01:11:54.951771
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is the error message")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:11:56.194826
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test")
    except ProgrammingError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 01:11:58.153359
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:12:04.497981
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Text")
        raise AssertionError("Class ProgrammingError should not be raiseable with a string argument.")
    except TypeError:
        pass

    try:
        ProgrammingError(1)
        raise AssertionError("Class ProgrammingError should not be raiseable with a numerical argument.")
    except TypeError:
        pass
    pass



# Generated at 2022-06-24 01:12:07.217156
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error")
    except ProgrammingError as e:
        assert str(e) == "This is a programming error"


# Generated at 2022-06-24 01:12:08.322265
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError()
    assert isinstance(err, Exception)


# Generated at 2022-06-24 01:12:11.531353
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test :py:class:`ProgrammingError`."""

    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Message")

# Generated at 2022-06-24 01:12:13.549492
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:12:18.541519
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=missing-docstring
    try:
        ProgrammingError()
    except ProgrammingError as exc:
        assert isinstance(exc, ProgrammingError)
        assert isinstance(exc, Exception)
        assert exc.args == ()


# Generated at 2022-06-24 01:12:21.089327
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given
    condition = False
    message = "test_message"

    # When/Then
    try:
        ProgrammingError.passert(condition, message)
        assert False, "Should raise ProgrammingError"
    except ProgrammingError as err:
        assert err.args[0] == message

# Generated at 2022-06-24 01:12:26.783815
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Expects that the error is raised
    try:
        ProgrammingError.passert(False, "some message")
    except ProgrammingError as e:
        assert str(e) == "some message"
    # Expects that the error is not raised
    ProgrammingError.passert(True, "some message")

# Generated at 2022-06-24 01:12:29.216049
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("An error!")

# Generated at 2022-06-24 01:12:36.315542
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except TypeError as e:
        assert e.args[0] == "__init__() missing 1 required positional argument: 'args'"
    else:
        assert False, "TypeError expected for ProgrammingError"

    try:
        ProgrammingError(object())
    except TypeError as e:
        assert e.args[0] == "object() takes no parameters"
    else:
        assert False, "TypeError expected for ProgrammingError"


# Generated at 2022-06-24 01:12:41.143814
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Verifies the :py:class:`ProgrammingError` constructor.

    :return: ``None``
    """
    assert ProgrammingError("My message")


# Generated at 2022-06-24 01:12:46.511325
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # No exception
    ProgrammingError.passert(True, "No exception")

    # An exception
    try:
        ProgrammingError.passert(False, "An exception")
        raise AssertionError("An exception was expected")
    except ProgrammingError:
        pass


if __name__ == "__main__":
    from pytest import main
    main([__file__])

# Generated at 2022-06-24 01:12:49.870939
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "")
    try:
        ProgrammingError.passert(False, "test message")
    except ProgrammingError as e:
        assert str(e) == "test message"



# Generated at 2022-06-24 01:12:53.519500
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:12:57.760829
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("This is an error raised in order to test it"):
        raise ProgrammingError("Testing the exception")

# Generated at 2022-06-24 01:13:01.635557
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.

    :param self: Reference to the object itself.
    """

    # Create a dummy instance
    obj = ProgrammingError()

    # The error should be an instance of ProgrammingError and should therefore have the attribute message
    assert hasattr(obj, "message")

# Generated at 2022-06-24 01:13:02.669239
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert isinstance(error, ProgrammingError)


# Generated at 2022-06-24 01:13:05.123963
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as error:
        assert error.args[0] == "This is a test"
    else:
        raise AssertionError("assertion failed")


# Generated at 2022-06-24 01:13:06.798454
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test message"):
        assert False


# Generated at 2022-06-24 01:13:10.041963
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        assert True


# Generated at 2022-06-24 01:13:17.967477
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.exc import ProgrammingError

    mapping = {
        "": "Broken coherence. Check your code against domain logic to fix it.",
        "hola": "hola"
    }

    for message, expected in mapping.items():
        with ProgrammingError(message):
            pass
        error = None
        try:
            with ProgrammingError(message):
                raise Exception()
        except ProgrammingError as ex:
            assert ex.message == expected
            error = ex
        assert isinstance(error, ProgrammingError)


# Generated at 2022-06-24 01:13:19.884113
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:13:24.313497
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Something went wrong")
    assert str(error) == "Something went wrong"



# Generated at 2022-06-24 01:13:27.917196
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test_ProgrammingError")
    except ProgrammingError as error:
        assert str(error) == "test_ProgrammingError"


# Generated at 2022-06-24 01:13:31.494454
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # expect no exception
    ProgrammingError.passert(True, None)

    # expect ProgrammingError
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:13:33.523544
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("some message")
    assert error.args == ("some message", )

# Generated at 2022-06-24 01:13:35.572304
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("error message")
    assert str(error) == "error message", "The message should be the one passed by constructor."

# Generated at 2022-06-24 01:13:39.560591
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert error.__str__() == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-24 01:13:43.359004
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError
    :return:
    """
    try:
        raise ProgrammingError("unit test")
    except ProgrammingError as e:
        assert "unit test" in e.args


# Generated at 2022-06-24 01:13:46.924351
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError:
        pass

# Unit tests for passert classmethod in class ProgrammingError

# Generated at 2022-06-24 01:13:50.669299
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Performs tests for constructor of class ProgrammingError.
    """
    # Check if the constructor works
    try:
        raise ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == ""


# Generated at 2022-06-24 01:13:51.956158
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from .error import ProgrammingError
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "message")

# Generated at 2022-06-24 01:13:53.107966
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:13:55.301793
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=unused-variable
    error: ProgrammingError = ProgrammingError()
    error: ProgrammingError = ProgrammingError(message="An error has been raised")



# Generated at 2022-06-24 01:13:57.063944
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()

# Generated at 2022-06-24 01:14:01.932283
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): #pylint: disable=missing-docstring
    try:
        ProgrammingError.passert(False, "Should raise an error")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Should raise an error"


# Generated at 2022-06-24 01:14:07.325176
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A test exception")
    except ProgrammingError as ex:
        assert ex.args[0] == "A test exception"
    else:
        raise AssertionError("ProgrammingError has not been raised")


# Generated at 2022-06-24 01:14:07.898806
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    Programmin

# Generated at 2022-06-24 01:14:09.674881
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:14:10.862466
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("foo")
    assert str(error) == "foo"

# Generated at 2022-06-24 01:14:13.117413
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with __import__('pytest').raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-24 01:14:16.642668
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-24 01:14:20.998064
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError` to raise an :py:class:`ProgrammingError`.

    """
    def raise_exception(): raise ProgrammingError("Test_ProgrammingError")
    try: raise_exception()
    except ProgrammingError as error: assert True
    else: assert False


# Generated at 2022-06-24 01:14:28.005460
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests correctness of the :py:class:`ProgrammingError`.

    It tests the assertion method when assertion is ``False``.
    """
    try:
        ProgrammingError.passert(False, "Test message")
        assert False, "Wrong assertions."
    except ProgrammingError as e:
        assert str(e) == "Test message"
    # Check that no message is raised when assertion is True
    ProgrammingError.passert(True, "")

# Generated at 2022-06-24 01:14:31.528450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-24 01:14:36.686821
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError` class.
    """
    try:
        raise ProgrammingError("Some error")
    except ProgrammingError as e:
        assert e.message == "Some error"



# Generated at 2022-06-24 01:14:38.871243
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as ex:
        assert isinstance(ex, ProgrammingError)


# Generated at 2022-06-24 01:14:40.701714
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:14:41.835036
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is an error message.")

# Generated at 2022-06-24 01:14:43.747090
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test if the constructor of ProgrammingError returns an instance of ProgrammingError
    assert isinstance(ProgrammingError(), ProgrammingError)

    # Test if the constructor of ProgrammingError returns an instance of ProgrammingError and
    # ProgrammingError returns an error message
    assert not isinstance(ProgrammingError("error message"), ProgrammingError)

# Generated at 2022-06-24 01:14:46.136807
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    else:
        assert(False, "The constructor of class ProgrammingError did not raise an exception.")


# Generated at 2022-06-24 01:14:52.260542
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        prog_error = ProgrammingError()
        raise AssertionError()
    except ProgrammingError as e:
        assert True
    try:
        prog_error = ProgrammingError("message")
        raise AssertionError()
    except ProgrammingError as e:
        assert str(e) == "message"

# Generated at 2022-06-24 01:14:57.304595
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert e.args == ("Test message",)


# Generated at 2022-06-24 01:15:01.874221
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected = "This is an error"
    try:
        raise ProgrammingError(expected)
    except ProgrammingError as e:
        assert e.args[0] == expected


# Generated at 2022-06-24 01:15:07.298756
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="Test error")
    except ProgrammingError as ex:
        assert ex.args[0] == "Test error"
        return True
    assert False


# Generated at 2022-06-24 01:15:10.308718
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True
    else:
        assert False

# Unit tests for method ProgrammingError.passert()

# Generated at 2022-06-24 01:15:16.181111
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError("Test")

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Test")

    try:
        ProgrammingError.passert(True, "Test")
    except ProgrammingError:
        raise Exception("This code should not be reached.")

# Generated at 2022-06-24 01:15:17.191381
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Hello World")


# Generated at 2022-06-24 01:15:23.737985
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test that the exception is actually raised
    try:
        raise ProgrammingError("Expected")
    except ProgrammingError as err:
        assert str(err) == "Expected"

    # Test that the assertion is done
    try:
        ProgrammingError.passert(False, "Expected")
    except ProgrammingError as err:
        assert str(err) == "Expected"

# Generated at 2022-06-24 01:15:27.556050
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some kind of coherence broken")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)
        assert "Some kind of coherence broken" == e.args[0]


# Generated at 2022-06-24 01:15:30.596768
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Ensures the functionality of :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        raise AssertionError
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass

ProgrammingError.passert(issubclass(ProgrammingError, Exception), "ProgrammingError should be a subclass of Exception.")

# Generated at 2022-06-24 01:15:41.103001
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test error message.")
    except ProgrammingError as ex:
        assert str(ex) == "This is a test error message."
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(True, "This is a test error message.")
    except ProgrammingError as ex:
        assert False, "ProgrammingError.passert(True, message) raised an exception."

# Generated at 2022-06-24 01:15:44.198937
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test!")
        assert False
    except ProgrammingError as ex:
        assert str(ex) == "This is a test!"


# Generated at 2022-06-24 01:15:45.815560
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError()

# Generated at 2022-06-24 01:15:48.348224
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert e.args[0] == "test", "Not the expected error message"

# Generated at 2022-06-24 01:15:50.557881
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()



# Generated at 2022-06-24 01:15:55.305200
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My error")
    except ProgrammingError as e:
        assert str(e) == "My error"


# Generated at 2022-06-24 01:15:57.954516
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Should not raise any error
    ProgrammingError.passert(True, "")
    # Expected exception ProgrammingError
    ProgrammingError.passert(False, "")

# Generated at 2022-06-24 01:16:03.214851
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    def _test(message: Optional[str]) -> None:
        try:
            raise ProgrammingError(message)
            assert False
        except ProgrammingError as e:
            assert e is not None
            assert e.args[0] == message

    _test(None)
    _test("Some message")


# Generated at 2022-06-24 01:16:05.986225
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:16:09.422135
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for the exception :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("message")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:16:14.972741
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the class :py:class:`ProgrammingError`.
    """
    error = ProgrammingError("test message")
    assert isinstance(error, Exception)
    assert str(error) == "test message"


# Generated at 2022-06-24 01:16:19.750247
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error has occurred.")
    except ProgrammingError as e:
        assert e.args == ("A programming error has occurred.", )
        assert str(e) == "A programming error has occurred."
    else:
        assert False, "Unexpected non-raised exception"


# Generated at 2022-06-24 01:16:25.609329
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Check that Programming Errors are raised when they should"""
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError not raised"

# Generated at 2022-06-24 01:16:33.114535
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the ProgrammingError constructor.

    :return: ``None``
    :raises AssertionError: If any of the tests fails.
    """
    try:
        ProgrammingError.passert(False, "Message")
        raise AssertionError("An exception was expected.")
    except ProgrammingError:
        pass
    ProgrammingError.passert(True, "Message")

# Generated at 2022-06-24 01:16:37.386596
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "provided message"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as error:
        assert str(error) == message

# Generated at 2022-06-24 01:16:42.483983
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class :py:class:`ProgrammingError`.

    :return: ``None``
    """
    ProgrammingError(message="Hello, world!")


# Generated at 2022-06-24 01:16:43.916790
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Unit test.")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:16:47.675715
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    except Exception as ex:
        assert False, "An exception of type ProgrammingError was expected but it was {}".format(ex.__class__.__name__)



# Generated at 2022-06-24 01:16:51.235838
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Boom!")
    assert ProgrammingError.passert(True, "Boom!") is None

# Generated at 2022-06-24 01:16:54.777733
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Nothing to worry about"):
        pass


# Generated at 2022-06-24 01:16:56.623675
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Act
    exception = ProgrammingError("This is an error message")

    # Assert
    assert str(exception) == "This is an error message"

# Generated at 2022-06-24 01:16:57.489595
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError


# Generated at 2022-06-24 01:16:59.582215
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:17:05.412734
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # pylint: disable=unused-variable
        # Make variable "x" visible to pyflakes and mypy.
        x = ProgrammingError()
    except TypeError:
        pass
    except KeyboardInterrupt:
        raise
    except Exception:
        raise AssertionError("Programming error constructor did not work.")


# Generated at 2022-06-24 01:17:11.074083
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as instance:
        assert isinstance(instance, ProgrammingError)
        assert str(instance) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:17:16.234909
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing `ProgrammingError`")
    except ProgrammingError as e:
        assert str(e) == "Testing `ProgrammingError`"


# Generated at 2022-06-24 01:17:18.169777
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    success = False
    try:
        raise ProgrammingError("Unit test")
    except ProgrammingError as e:
        assert str(e) == "Unit test"
        success = True
    assert success


# Generated at 2022-06-24 01:17:20.527258
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("ProgrammingError test")


# Generated at 2022-06-24 01:17:22.541368
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` class.
    """
    success = False
    try:
        ProgrammingError()
    except ProgrammingError:
        success = True
    assert success

# Generated at 2022-06-24 01:17:24.453118
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # If a message is given at construction time, then the same message is returned by str()
    error = ProgrammingError("Hello world!")
    assert str(error) == "Hello world!"

# Generated at 2022-06-24 01:17:29.466791
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "A programming error has been triggered")
        assert False # pragma: no cover
    except ProgrammingError as ex:
        assert str(ex) == "A programming error has been triggered"

# Generated at 2022-06-24 01:17:33.134850
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError
    """
    e = ProgrammingError()  # noqa: WPS421
    assert isinstance(e, ProgrammingError)



# Generated at 2022-06-24 01:17:36.064153
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected_message = "There is an error here!"
    try:
        raise ProgrammingError(expected_message)
    except ProgrammingError as e:
        assert e.args[0] == expected_message


# Generated at 2022-06-24 01:17:37.053258
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError('Error')

# Generated at 2022-06-24 01:17:39.796375
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit testing for constructor of class :py:class:`ProgrammingError`."""
    assert ProgrammingError("Test error")


# Generated at 2022-06-24 01:17:41.853896
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error raised on purpose for test.")
    except Exception as exception:
        assert isinstance(exception, ProgrammingError)

# Generated at 2022-06-24 01:17:43.210709
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(ProgrammingError(None), Exception)



# Generated at 2022-06-24 01:17:48.205476
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Should not be raised")
    except ProgrammingError:
        assert False

    try:
        ProgrammingError.passert(False, "Should be raised")
        assert False
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:17:49.409191
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)



# Generated at 2022-06-24 01:17:55.041188
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Ensures that we can raise a :py:class:`ProgrammingError` exception.
    """
    try:
        raise ProgrammingError("Some error due to programmer's error.")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:18:00.450921
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Hello World")
    except ProgrammingError as ex:
        assert str(ex) == "Hello World"
    else:
        raise RuntimeError("Failed to raise ProgrammingError")


# Generated at 2022-06-24 01:18:03.550292
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"
    else:
        assert False, "ProgrammingError not raised."
