

# Generated at 2022-06-24 01:08:11.112540
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # The following code must not raise an assertion error:
    ProgrammingError.passert(True, "Thank you!")

    try:
        # The following code must raise a ProgrammingError:
        ProgrammingError.passert(False, "Thank you!")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Thank you!"

# Generated at 2022-06-24 01:08:13.035270
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
    except ProgrammingError as e:
        pass
    else:
        raise ValueError("Failed to raise ProgrammingError")

# Generated at 2022-06-24 01:08:17.861851
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error.args == tuple()
    assert str(error) == "Broken coherence. Check your code against domain logic to fix it."

    error = ProgrammingError(message="Hello world!")
    assert error.args == tuple()
    assert str(error) == "Hello world!"

    error = ProgrammingError(message=None)
    assert error.args == tuple()
    assert str(error) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:08:19.939490
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert issubclass(e.__class__, Exception)
        assert isinstance(e, Exception)

# Generated at 2022-06-24 01:08:20.800436
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("some message")
    assert str(e) == "some message"

# Generated at 2022-06-24 01:08:26.375340
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "This is an expected exception.")
        assert False, "This is an expected exception."
    except Exception as e:
        assert e.__class__ is ProgrammingError
        assert e.args[0] == "This is an expected exception."
    try:
        ProgrammingError.passert(False, None)
        assert False, "This is an expected exception."
    except Exception as e:
        assert e.__class__ is ProgrammingError
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    return

# Generated at 2022-06-24 01:08:29.756360
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyTypeChecker
    with pytest.raises(ProgrammingError):
        ProgrammingError(None)

# Generated at 2022-06-24 01:08:32.815845
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error_message = "This is a simple programming error"
    try:
        raise ProgrammingError(error_message)
    except ProgrammingError as e:
        assert e.args[0] == error_message


# Generated at 2022-06-24 01:08:39.899181
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for the :py:class:`ProgrammingError` class.
    """

    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

    try:
        raise ProgrammingError("Test message 1")
    except ProgrammingError as e:
        assert str(e) == "Test message 1"

    try:
        raise ProgrammingError(None)
    except ProgrammingError as e:
        assert str(e) == "None"

    try:
        raise ProgrammingError(0)
    except ProgrammingError as e:
        assert str(e) == "0"


# Generated at 2022-06-24 01:08:42.047063
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, message="error")

# Generated at 2022-06-24 01:08:44.553140
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "My message")
    except ProgrammingError as e:
        assert "My message" == str(e)


# Generated at 2022-06-24 01:08:50.060743
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("The message")
    except ProgrammingError as e:
        assert str(e) == "The message"


# Generated at 2022-06-24 01:08:56.164577
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
        raise AssertionError("Expected exception is not raised")
    except Exception as e:
        assert isinstance(e, ProgrammingError)

    try:
        ProgrammingError.passert(False, None)
        raise AssertionError("Expected exception is not raised")
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert "Broken coherence. Check your code against domain logic to fix it." in str(e)

    assert ProgrammingError.passert(True, None) is None

# Generated at 2022-06-24 01:08:57.543525
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="Hello, world!")
    except ProgrammingError as e:
        assert(e.args[0] == "Hello, world!")


# Generated at 2022-06-24 01:08:58.683404
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): ProgrammingError(message="Test")

# Generated at 2022-06-24 01:09:01.452337
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Bohemian Rhapsody")
        assert False, "We should have raised an exception."
    except ProgrammingError as e:
        assert e.args[0] == "Bohemian Rhapsody"

# Generated at 2022-06-24 01:09:11.960884
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    # Should raise a ProgrammingError by default
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    # Should raise a ProgrammingError with the specified message
    try:
        raise ProgrammingError("Should raise a ProgrammingError with the specified message")
    except ProgrammingError as err:
        assert str(err) == "Should raise a ProgrammingError with the specified message"
    # Should raise a ProgrammingError with the specified message
    try:
        raise ProgrammingError("Should raise a ProgrammingError with the specified message")
    except ProgrammingError as err:
        assert str(err) == "Should raise a ProgrammingError with the specified message"


# Generated at 2022-06-24 01:09:19.489645
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the :py:class:`ProgrammingError` class.

    :raises AssertionError: In case any of the checks fails.
    """

    msg = "Test message"
    err = None

    try:
        raise ProgrammingError(msg)
    except ProgrammingError as e:
        err = e

    assert err is not None
    assert err.args[0] == msg

    ProgrammingError.passert(False, "test")

# Generated at 2022-06-24 01:09:24.824361
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        assert False, "It should always fail"
    except AssertionError as e:
        assert isinstance(e, ProgrammingError) is True, "It should be allowed to instantiate the exception"



# Generated at 2022-06-24 01:09:26.787051
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as error:
        assert isinstance(error, ProgrammingError)



# Generated at 2022-06-24 01:09:28.926698
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests if the ProgrammingError class is working."""
    try:
        ProgrammingError.passert(False, "This is a test")
        raise Exception("The ProgrammingError.passert method should have raised an exception.")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:09:30.633147
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise Exception("Construction of class ProgrammingError should raise a ProgrammingError.")


# Generated at 2022-06-24 01:09:32.484641
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as ex:
        assert(isinstance(ex, ProgrammingError))
        assert(str(ex) == "Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-24 01:09:37.031857
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:09:39.533821
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:09:50.420401
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(condition=True, message="This is a message."):
        pass
    try:
        with ProgrammingError.passert(condition=False, message="This is a message."):
            pass
    except ProgrammingError as e:
        assert str(e) == "This is a message."
    try:
        with ProgrammingError.passert(condition=False, message=None):
            pass
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        with ProgrammingError.passert(condition=False, message=5):
            pass
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:09:52.864026
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.error import ProgrammingError
    with raises(ProgrammingError):
        raise ProgrammingError('Programming error has caused this exception')

# Generated at 2022-06-24 01:09:55.217295
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as exc:
        assert str(exc) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:09:56.646756
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """A test for the class ProgrammingError."""
    with ProgrammingError("Test"):
        raise ProgrammingError("Test")

# Generated at 2022-06-24 01:10:00.349755
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Testing that an instance of :py:class:`ProgrammingError` is created when :py:meth:`passert` is called with a
    ``False`` condition.
    """
    try:
        ProgrammingError.passert(False, "Testing")
        assert False
    except ProgrammingError:
        assert True

# Generated at 2022-06-24 01:10:06.005608
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase, main
    from parameterized import parameterized

    class TestProgrammingError(TestCase):
        @parameterized.expand([
            (True, None),
        ])
        def test_passert_pass(self, condition, message):
            ProgrammingError.passert(condition, message)

        @parameterized.expand([
            (False, None,),
            (False, "message"),
        ])
        def test_passert_fail(self, condition, message):
            with self.assertRaises(ProgrammingError):
                ProgrammingError.passert(condition, message)

    main()

# Generated at 2022-06-24 01:10:07.022852
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()


# Generated at 2022-06-24 01:10:08.746152
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as exception:
        ProgrammingError.passert(condition=False, message="message")
    assert "message" == str(exception.value)

# Generated at 2022-06-24 01:10:16.337370
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the functionality of the constructor of the :py:class:`ProgrammingError` exception.
    """
    try:
        # noinspection PyTypeChecker
        err = ProgrammingError(1.1)
    except TypeError:
        pass
    except Exception as e:
        assert False, "ProgrammingError did not raise a TypeError with a single argument of type {}.".format(
            type(e).__name__
        )

    try:
        err = ProgrammingError("This is an error message.")
        assert err.args == ("This is an error message.", ), "ProgrammingError did not wrap the exception message."
    except Exception:
        assert False, "ProgrammingError did not work properly."



# Generated at 2022-06-24 01:10:22.166738
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("PlayStation is better than Xbox")
    except ProgrammingError as e:
        assert str(e) == "PlayStation is better than Xbox"


# Generated at 2022-06-24 01:10:24.001091
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except Exception as e:
        assert e.args[0] == "Test message"



# Generated at 2022-06-24 01:10:25.984869
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error")
    except ProgrammingError as exc:
        assert str(exc) == "Error"

# Generated at 2022-06-24 01:10:28.009068
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="This is an example of a programming error")
    except ProgrammingError:
        pass
    else:
        assert False, "Exception ProgrammingError expected"

# Generated at 2022-06-24 01:10:33.603265
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-24 01:10:35.766525
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something went wrong")
    except ProgrammingError as e:
        assert str(e) == "Something went wrong"


# Generated at 2022-06-24 01:10:42.993996
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert not e.args
    except:
        assert False

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    except:
        assert False

    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        assert False
    except:
        assert False

    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    except:
        assert False


# Generated at 2022-06-24 01:10:46.605999
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("ProgrammingError")
    except Exception as e:
        assert str(e) == "ProgrammingError"



# Generated at 2022-06-24 01:10:49.895404
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as e:
        raise ProgrammingError("error_msg")

    assert str(e.value) == "error_msg"

# Generated at 2022-06-24 01:10:51.000329
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test")
    except ProgrammingError as exception:
        assert str(exception) == "Test"


# Generated at 2022-06-24 01:10:52.529164
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True
    except Exception:
        assert False
    else:
        assert False


# Generated at 2022-06-24 01:10:53.863172
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("the error")
    assert error.args == ("the error",)



# Generated at 2022-06-24 01:10:56.259807
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "You're doing it wrong")
        assert False
    except ProgrammingError as e:
        assert "You're doing it wrong" == str(e)

# Generated at 2022-06-24 01:10:59.615970
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test unit for :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError("This is a testing message")
        assert False, "Should not get here!"
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:11:01.673207
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("my message")
    except ProgrammingError as e:
        assert str(e) == "my message"

# Generated at 2022-06-24 01:11:05.341442
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-24 01:11:07.178957
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"

# Generated at 2022-06-24 01:11:12.969499
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test exception")
    except ProgrammingError as error:
        assert error.args[0] == "This is a test exception"
    else:
        assert False

# Generated at 2022-06-24 01:11:15.439101
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()



# Generated at 2022-06-24 01:11:18.633455
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        raise ProgrammingError("Uncoherent domain logic")
    assert "Uncoherent domain logic" in str(excinfo.value)


# Generated at 2022-06-24 01:11:20.347301
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for class ProgrammingError.
    """
    ProgrammingError.passert(False, "test")

# Generated at 2022-06-24 01:11:25.042261
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Some error message")

# Generated at 2022-06-24 01:11:29.419764
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("error message")
    except ProgrammingError as e:
        assert str(e) == 'error message'


# Generated at 2022-06-24 01:11:32.766143
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError(message="The sky is falling down.")
    except ProgrammingError as e:
        assert e.args[0] == "The sky is falling down."


# Generated at 2022-06-24 01:11:35.625938
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError()
    assert exception.args == ()



# Generated at 2022-06-24 01:11:44.725179
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check that it raises the correct exception
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Programming error is not raised"

    # Check that it reports the correct error message
    message = "test message"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert message in str(e), "Programming error does not report correct error message"
    else:
        assert False, "Programming error is not raised"


# Generated at 2022-06-24 01:11:48.061211
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # A programmer can raise this exception to indicate that he has violated a syntax rule
    try:
        raise ProgrammingError("This is a syntax error.")
    except ProgrammingError as e:
        assert e.args[0] == "This is a syntax error."


# Generated at 2022-06-24 01:11:53.649210
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    try:
        ProgrammingError.passert(False, "Foooo")
    except ProgrammingError as exc:
        assert exc.args[0] == "Foooo"
    else:
        assert False, "Foooo"
    try:
        ProgrammingError.passert(True, "Foooo")
    except ProgrammingError as exc:
        assert False, str(exc)

# Generated at 2022-06-24 01:11:57.341551
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as error:
        assert error.args[0] == "Test"

# Generated at 2022-06-24 01:11:59.808252
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "programming error")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Failed to raise exception")
    ProgrammingError.passert(True, "programming error")

# Generated at 2022-06-24 01:12:02.286489
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # noinspection PyTypeChecker
        ProgrammingError()
    except TypeError:
        pass
    except Exception as e:
        assert False, "Unexpected exception {}: {}".format(e, type(e))


# Generated at 2022-06-24 01:12:03.473986
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`
    """
    ProgrammingError()


# Generated at 2022-06-24 01:12:08.543586
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error.")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:12:11.824655
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("You cannot access this variable in this context.")
    except ProgrammingError as err:
        assert err.args[0] == "You cannot access this variable in this context."


# Generated at 2022-06-24 01:12:15.931477
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("msg")


# Generated at 2022-06-24 01:12:19.318097
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Hello world!")
    except ProgrammingError as err:
        assert err.args == ("Hello world!", )


# Generated at 2022-06-24 01:12:20.772623
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test exception")
    except ProgrammingError as e:
        assert str(e) == "Test exception"

# Generated at 2022-06-24 01:12:22.143345
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as error:
        assert error.args[0] == "Test"


# Generated at 2022-06-24 01:12:26.866756
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.

    :return: ``None``
    """
    try:
        raise ProgrammingError(message="This should not throw an exception")
    except Exception as e:
        assert False, "It should not throw an exception."


# Generated at 2022-06-24 01:12:32.739260
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.test.utils import raises
    # Test constructor
    with raises(ProgrammingError):
        ProgrammingError(message="A message")
    # Test class method passert
    with raises(ProgrammingError):
        ProgrammingError.passert(condition=False, message="A message")
    ProgrammingError.passert(condition=True, message="A message")
    ProgrammingError.passert(condition=True, message=None)

# Generated at 2022-06-24 01:12:37.273209
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Message")
        assert False, "ProgrammingError was not raised"
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, None)
        assert False, "ProgrammingError was not raised"
    except ProgrammingError:
        pass
    ProgrammingError.passert(True, None)

# Generated at 2022-06-24 01:12:45.123180
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit-tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "I am an error")
        raise RuntimeError("ProgrammingError.passert should have raised the ProgrammingError exception")
    except ProgrammingError as e:
        assert str(e) == "I am an error", "ProgrammingError.passert should have raised the proper error message"
    try:
        ProgrammingError.passert(False, None)
        raise RuntimeError("ProgrammingError.passert should have raised the ProgrammingError exception")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it.", \
            "ProgrammingError.passert should have raised the proper error message when it is None"

# Generated at 2022-06-24 01:12:49.115897
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError(message="You did it wrong.")
    assert excinfo.type is ProgrammingError

# Generated at 2022-06-24 01:12:53.449090
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    cause = ProgrammingError("It should work!")
    assert "It should work!" == str(cause)

# Generated at 2022-06-24 01:12:57.667152
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Broken coherence.")


# Generated at 2022-06-24 01:13:00.093513
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()

    with pytest.raises(ProgrammingError):
        ProgrammingError("foo")

# Generated at 2022-06-24 01:13:01.554696
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Custom error.")


# Generated at 2022-06-24 01:13:03.399270
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message should be set")
    except ProgrammingError as ex:
        assert ex.args[0] == "Message should be set"


# Generated at 2022-06-24 01:13:06.836862
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is my message")
    except ProgrammingError as exce:
        assert str(exce) == "This is my message"
    else:
        raise AssertionError("Expected ProgrammingError exception.")



# Generated at 2022-06-24 01:13:14.384004
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from exceptions import Exception
    from typing import Union

    assert issubclass(ProgrammingError, Exception)
    assert isinstance(ProgrammingError(message="Dummy error message."), Exception)
    assert isinstance(ProgrammingError.passert(condition=True, message=None), None.__class__)
    assert isinstance(ProgrammingError.passert(condition=False, message=None), ProgrammingError)
    from pybberas.core.errors import ProgrammingError
    assert isinstance(ProgrammingError.passert(condition=False, message=None), Union[ProgrammingError, None.__class__])

# Generated at 2022-06-24 01:13:15.865402
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "message")
        assert False
    except ProgrammingError as error:
        assert error.args[0] == "message"



# Generated at 2022-06-24 01:13:20.791424
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Custom error message.")
    except ProgrammingError as pe:
        assert str(pe) == "Custom error message."
    try:
        ProgrammingError()
    except ProgrammingError as pe:
        assert str(pe) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:13:25.262469
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Checks constructor of :py:class:`ProgrammingError`.

    :return: ``None``
    """
    try:
        ProgrammingError("Exception messages.")
    except ProgrammingError as pe:
        assert pe.args[0] == "Exception messages."
    except:
        assert False, "A ProgrammingError exception was expected."
    else:
        assert False, "A ProgrammingError exception was expected."


# Generated at 2022-06-24 01:13:27.691119
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("message"):
        pass



# Generated at 2022-06-24 01:13:29.957594
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        e = ProgrammingError("")
        assert e

    except:
        assert False


# Generated at 2022-06-24 01:13:30.513164
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-24 01:13:35.170513
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "")


# Unit test suite for class ProgrammingError
test_suite = {
    "repr": repr(ProgrammingError),
    "str": str(ProgrammingError),
}

# Unit tests

# Generated at 2022-06-24 01:13:37.157000
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:13:42.692579
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of class ProgrammingError."""
    try:
        raise ProgrammingError("Something is wrong.")
    except ProgrammingError as err:
        assert type(err) == ProgrammingError
        assert str(err) == "Something is wrong."


# Generated at 2022-06-24 01:13:46.103743
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as pe:
        assert str(pe) == "Some message"


# Generated at 2022-06-24 01:13:48.747944
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:13:51.642008
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test instantiation
    with ProgrammingError("message"):
        raise ProgrammingError("message")

# Generated at 2022-06-24 01:13:55.430752
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "Error"
    e = ProgrammingError(msg)

    assert e.__class__.__name__ == "ProgrammingError"
    assert e.args[0] == msg

# Generated at 2022-06-24 01:13:59.183612
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError constructor should have raised exception")


# Generated at 2022-06-24 01:14:02.189874
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)
        assert isinstance(err, Exception)
        assert str(err) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:14:06.341888
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:14:07.586105
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError): ProgrammingError()


# Generated at 2022-06-24 01:14:08.525949
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    bool(ProgrammingError)


# Generated at 2022-06-24 01:14:11.285367
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something bad happened")
    except ProgrammingError as exception:
        assert type(exception) == ProgrammingError
        assert str(exception) == "Something bad happened"


# Generated at 2022-06-24 01:14:17.239153
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "should not be raised")
    except ProgrammingError as e:
        raise AssertionError("Should have been suppressed")
    try:
        ProgrammingError.passert(False, "message")
        raise AssertionError("Should have raised ProgrammingError")
    except ProgrammingError as e:
        assert str(e) == "message"

# Generated at 2022-06-24 01:14:25.282417
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError as pe:
        assert False, "Error raised when condition was met."
    except Exception as e:
        assert False, "Unexpected exception was raised: %s" % str(e)
    try:
        ProgrammingError.passert(False, "Error")
    except ProgrammingError as pe:
        assert True, "No error raised when condition was not met."
    except Exception as e:
        assert False, "Unexpected exception was raised: %s" % str(e)

# Generated at 2022-06-24 01:14:27.510859
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    raise ProgrammingError("Testing")

# Generated at 2022-06-24 01:14:32.200448
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:14:36.397858
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test message")
        assert False
    except Exception as e:
        assert "test message" == e.args[0]


# Generated at 2022-06-24 01:14:38.970399
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:14:41.316543
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as err:
        assert err.args[0] == "This is a test"

# Generated at 2022-06-24 01:14:43.047559
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("A programming error has occurred.")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:14:44.182434
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test message"):
        pass

# Generated at 2022-06-24 01:14:47.305743
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something is wrong...")
    except ProgrammingError as e:
        assert str(e) == "Something is wrong..."


# Generated at 2022-06-24 01:14:50.926244
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something bad happened.")
    except ProgrammingError as e:
        assert e.args[0] == "Something bad happened."


# Generated at 2022-06-24 01:14:54.206669
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    class_to_test = ProgrammingError
    given_message = "some message"
    # WHEN
    error = class_to_test(given_message)
    # THEN
    assert given_message in error.args



# Generated at 2022-06-24 01:14:56.262802
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:meth:`ProgrammingError.__init__` method.
    """
    error = ProgrammingError("A programming error has occurred")
    assert str(error) == "A programming error has occurred"


# Generated at 2022-06-24 01:15:01.622507
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test for ProgrammingError")
    except ProgrammingError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 01:15:05.054789
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="Oops! Something is wrong...")


# Generated at 2022-06-24 01:15:09.520960
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """

    try:
        raise ProgrammingError("Test")
    except ProgrammingError as ex:
        assert str(ex) == "Test"


# Generated at 2022-06-24 01:15:13.384609
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Basic instance
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False

    # Instance with message
    try:
        raise ProgrammingError("Testing message.")
    except ProgrammingError as err:
        assert str(err) == "Testing message."
    else:
        assert False



# Generated at 2022-06-24 01:15:15.540083
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyBroadException
    try:
        ProgrammingError.passert(False, "test")
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:15:20.729054
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import inspect
    try:
        raise  ProgrammingError("a")
    except ProgrammingError as e:
        assert str(e) == "a"
        assert "test_ProgrammingError" in inspect.stack()[1].function
    else:
        raise AssertionError("Expected exception not raised.")


# Generated at 2022-06-24 01:15:21.855800
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message = "This message")
    except Exception as exc:
        assert str(exc) == "This message"

# Test for method ProgrammingError.passert

# Generated at 2022-06-24 01:15:26.087168
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert isinstance(ProgrammingError(''), Exception)
    assert str(ProgrammingError('')) == ''
    assert isinstance(ProgrammingError('my message'), Exception)
    assert str(ProgrammingError('my message')) == 'my message'


# Generated at 2022-06-24 01:15:27.458733
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:15:29.481130
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of class ProgrammingError."""
    try:
        raise ProgrammingError("a message")
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)
        assert err.args == ("a message",)
    # noinspection PyUnusedLocal
    finally:
        pass


# Generated at 2022-06-24 01:15:33.178471
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Test"):
        value = 1

    with ProgrammingError.passert(True, "Test"):
        value = 2

    assert value == 2

    with ProgrammingError.passert(False, None):
        pass


# Generated at 2022-06-24 01:15:36.382497
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    assert "Broken coherence. Check your code against domain logic to fix it." == ProgrammingError().args[0]



# Generated at 2022-06-24 01:15:39.786325
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an error")
        assert False
    except ProgrammingError as e:
        assert str(e) == "This is an error"


# Generated at 2022-06-24 01:15:42.122638
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("error message")
    except ProgrammingError as e:
        assert str(e) == "error message"



# Generated at 2022-06-24 01:15:43.953151
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Broken invariant")

# Generated at 2022-06-24 01:15:46.557785
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "message")
        assert False
    except ProgrammingError as e:
        assert str(e) == "message"


# Generated at 2022-06-24 01:15:52.418633
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Try with the default message.
    try:
        ProgrammingError().passert(False, None)
    except ProgrammingError as err:
        print(err)
    # Try with the no message.
    try:
        ProgrammingError().passert(False, "My new error")
    except ProgrammingError as err:
        print(err)

# Generated at 2022-06-24 01:15:56.635445
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN a programming error message
    expected_message = "something is wrong"

    # WHEN using the constructor
    error = ProgrammingError(expected_message)

    # THEN the message is properly set
    assert error.args[0] == expected_message



# Generated at 2022-06-24 01:15:59.241059
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("TEST")
    except ProgrammingError as e:
        assert e.args[0] == "TEST"

# Generated at 2022-06-24 01:16:01.489616
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "This is a test error."
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as e:
        assert str(e) == msg


# Generated at 2022-06-24 01:16:03.793663
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError.passert(True, "Hello")
    assert not error


# Generated at 2022-06-24 01:16:08.962079
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is a message")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)

    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-24 01:16:15.023938
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    from pytest import raises

    with raises(ProgrammingError) as error:
        ProgrammingError("Invalid usage of my code.")
    assert "Invalid usage of my code." in str(error)


# Generated at 2022-06-24 01:16:16.982819
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("This is a programming error"):
        pass



# Generated at 2022-06-24 01:16:21.221703
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from .. import ProgrammingError

    try:
        # noinspection PyStatementEffect
        ProgrammingError.passert(False, "Unit-test")
    except ProgrammingError as e:
        assert e.args[0] == "Unit-test"
    else:
        assert False, "We should not be here"

# Generated at 2022-06-24 01:16:24.540470
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.message == "Test"


# Generated at 2022-06-24 01:16:25.841183
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:16:30.616630
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Assertion error") as err:
        assert err.args[0] == "Assertion error"


# Generated at 2022-06-24 01:16:38.311262
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # In case we call the constructor without arguments
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

    # In case we call the constructor with a single argument
    try:
        raise ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError:
        pass



# Generated at 2022-06-24 01:16:43.857768
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("test")


# Generated at 2022-06-24 01:16:46.202715
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError) as ctx:
        ProgrammingError.passert(False, None)
    assert ctx.type == ProgrammingError

# Generated at 2022-06-24 01:16:49.541031
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test")

# Generated at 2022-06-24 01:16:52.129130
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit testing for the constructor of class ProgrammingError.
    """
    error = ProgrammingError
    assert error(None) is not None
    assert error("Testing this error") is not None


# Generated at 2022-06-24 01:16:56.342368
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Failed to raise exception")


# Generated at 2022-06-24 01:16:57.477461
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Coverage only
    ProgrammingError(message="test")


# Generated at 2022-06-24 01:17:01.026977
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of the class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "Testing error.")
        assert False, "Incorrect exception is raised."
    except ProgrammingError as e:
        assert "Testing error." == e.args[0], "Incorrect error message."

# Generated at 2022-06-24 01:17:08.354257
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with  pytest.raises(ProgrammingError) as exception:
        ProgrammingError()
    assert str(exception.value) == ""
    with pytest.raises(ProgrammingError) as exception:
        ProgrammingError("Some error occurred.")
    assert str(exception.value) == "Some error occurred."



# Generated at 2022-06-24 01:17:11.074800
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an error.")
    except ProgrammingError as e:
        assert e.args[0] == "This is an error."


# Generated at 2022-06-24 01:17:17.019073
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "invalid domain logic")
        assert False, "expected an error to be raised"
    except ProgrammingError as e:
        assert str(e) == "invalid domain logic"

    ProgrammingError("valid domain logic")  # no exception

# Generated at 2022-06-24 01:17:20.871314
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert "Check your code against domain logic to fix it." == e.args[0]
    else:
        raise AssertionError("D'oh! Expected ProgrammingError")

# Generated at 2022-06-24 01:17:22.779631
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Not met expectation")
    except ProgrammingError as e:
        assert e.args == ("Not met expectation",)

# Generated at 2022-06-24 01:17:25.040394
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError._ProgrammingError__init__(ProgrammingError, "test_ProgrammingError")
    except TypeError:
        print("test_ProgrammingError OK")


# Generated at 2022-06-24 01:17:28.856666
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test one with message
    try:
        raise ProgrammingError("foo")
    except ProgrammingError as ex:
        assert str(ex) == "foo"

# Generated at 2022-06-24 01:17:32.404860
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is just a test")
    except ProgrammingError as err:
        assert err.args == ("This is just a test",)
    else:
        raise ProgrammingError("Expected an exception from ProgrammingError")


# Generated at 2022-06-24 01:17:35.403037
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("The message of my error")
    except ProgrammingError as e:
        assert str(e) == "The message of my error"


# Generated at 2022-06-24 01:17:36.388257
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("some message")


# Generated at 2022-06-24 01:17:39.842903
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
    else:
        assert False, "Expected exception"


# Generated at 2022-06-24 01:17:42.254412
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error!")
    except ProgrammingError as e:
        assert str(e) == "This is an error!"


# Generated at 2022-06-24 01:17:43.922823
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e



# Generated at 2022-06-24 01:17:45.942859
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Check the domain logic.")
    except ProgrammingError as e:
        assert e.args == ("Check the domain logic.",)


# Generated at 2022-06-24 01:17:51.626751
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This error message should be read.")
        assert False, "An exception must be raised."
    except ProgrammingError as e:
        assert str(e) == "This error message should be read."
        assert isinstance(e, BaseException)


# Generated at 2022-06-24 01:17:54.279253
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError.passert(False, "")
    assert error is None

# Generated at 2022-06-24 01:17:55.441870
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        pass

# Generated at 2022-06-24 01:18:02.374565
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    try:
        raise ProgrammingError("Broken coherence!")
    except ProgrammingError as e:
        assert e.args == ("Broken coherence!",)


# Generated at 2022-06-24 01:18:07.338320
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError()
    assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    e = ProgrammingError("error")
    assert str(e) == "error"


# Generated at 2022-06-24 01:18:11.609674
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error")
        assert False
    except ProgrammingError:
        pass

    try:
        raise ProgrammingError()
        assert False
    except ProgrammingError:
        pass

