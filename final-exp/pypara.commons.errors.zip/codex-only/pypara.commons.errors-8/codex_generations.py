

# Generated at 2022-06-24 01:08:07.902937
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an expected error.")
    except ProgrammingError as e:
        # Check type of exception
        assert type(e) == ProgrammingError
        # Check message of exception
        assert str(e) == "This is an expected error."


# Generated at 2022-06-24 01:08:15.691117
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructors and methods of class :py:class:`ProgrammingError`.
    """
    from pyaux.base import call_n_times_and_catch_exceptions
    from pyaux.base.exceptions import MultipleExceptions
    from pyaux.base.types import T
    from pyaux.base.types import is_instance

    try:
        # Try to raise it directly
        raise ProgrammingError
    except ProgrammingError:
        pass

    try:
        # Try to raise it with a message
        raise ProgrammingError("Error!")
    except ProgrammingError as e:
        assert str(e) == "Error!"

    # Define a message and test it
    message = "Test test."
    assert ProgrammingError.passert(True, message) is None

# Generated at 2022-06-24 01:08:19.870910
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    errmsg = "Some message to be passed in the error"
    try:
        raise ProgrammingError(errmsg)
    except ProgrammingError as exc:
        assert exc.args == (errmsg,)


# Generated at 2022-06-24 01:08:22.785450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("A non-empty message")
    assert issubclass(ProgrammingError, Exception)
    assert isinstance(error, ProgrammingError)
    assert error.args == ("A non-empty message",)
    assert str(error) == "A non-empty message"


# Generated at 2022-06-24 01:08:28.719135
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given
    message = "The expected behavior is not met."

    # When
    e = ProgrammingError(message)

    # Then
    assert isinstance(e, Exception)
    assert str(e) == message


# Generated at 2022-06-24 01:08:30.812907
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class ProgrammingError.
    """
    err = ProgrammingError("This is my message")
    assert err.args == ("This is my message",)
    assert str(err) == "This is my message"

# Generated at 2022-06-24 01:08:32.526503
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("some message")
    assert error.args == ("some message",)

# Generated at 2022-06-24 01:08:37.275501
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("this is an error message")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert e.args[0] == "this is an error message"


# Generated at 2022-06-24 01:08:39.717543
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError('This is a test')
    except ProgrammingError as e:
        assert str(e) == 'This is a test'


# Generated at 2022-06-24 01:08:45.173902
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` class.

    :raises AssertionError: In case that a test fails.
    :raises ProgrammingError: In case that the constructor of class :py:class:`ProgrammingError` fails.
    """
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Error message")

    ProgrammingError.passert(False, "Check your code against domain logic to fix it.")

# Generated at 2022-06-24 01:08:50.627290
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Validates the constructor of class ProgrammingError."""

    try:
        ProgrammingError.passert(False, "Check this.")

        raise AssertionError("An exception should had been raised.")

    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:08:53.172284
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("A programming error has occurred.")

# Generated at 2022-06-24 01:08:58.869521
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e)=="Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(False, "some message")
    except ProgrammingError as e:
        assert str(e)=="some message"

# Generated at 2022-06-24 01:09:01.074974
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This should be here.")
    except ProgrammingError as e:
        assert "This should be here." == e.args[0]

# Unit tests for the method passert

# Generated at 2022-06-24 01:09:05.040267
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError:
        assert True


# Generated at 2022-06-24 01:09:07.888203
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit testing for constructor of class :py:class:`ProgrammingError`
    """
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as err:
        assert str(err) == "Error message"
    else:
        raise AssertionError("Failed unit test for constructor of class ProgrammingError")



# Generated at 2022-06-24 01:09:11.284248
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for package pypara:
    - :py:class:`pypara.errors.ProgrammingError`
    """
    from pypara import ProgrammingError
    try:
        ProgrammingError.passert(False, "Error message")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Error message"

# Generated at 2022-06-24 01:09:12.480714
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as e:
        assert str(e) == "Message"

# Unit tess for classmethod ProgrammingError.passert

# Generated at 2022-06-24 01:09:12.966823
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert callable(ProgrammingError.passert)

# Generated at 2022-06-24 01:09:22.255092
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` constructor.
    """

    # pylint: disable=I0011,W0613
    def condition():
        """"
        Raises a :py:class:`ProgrammingError` if the assertion is not met.
        """
        ProgrammingError.passert(1 == 1, "This is a message")

    try:
        condition()
    except ProgrammingError as ex:
        assert False and str(ex)

    try:
        ProgrammingError.passert(1 == 0, "This is a message")
        assert False
    except ProgrammingError as ex:
        assert str(ex) == "This is a message"

    try:
        ProgrammingError.passert(1 == 0, None)
        assert False
    except ProgrammingError as ex:
        assert str(ex)

# Generated at 2022-06-24 01:09:26.399507
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        print("Constructor of ProgrammingError: PASS")
    else:
        print("Constructor of ProgrammingError: FAIL")


# Generated at 2022-06-24 01:09:30.695425
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of the class :py:class:`ProgrammingError`."""
    with pytest.raises(ProgrammingError) as err:
        raise ProgrammingError()
    assert str(err.value) == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-24 01:09:33.152393
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    def to_exception(message):
        try:
            ProgrammingError(message)
        except ProgrammingError as ex:
            return ex

    # Test empty message
    assert not to_exception(None).message

    # Test non-empty message
    assert to_exception("hello").message == "hello"


# Generated at 2022-06-24 01:09:37.333860
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("The case is not met.")
    except ProgrammingError as e:
        assert(str(e) == "The case is not met.")


# Generated at 2022-06-24 01:09:41.019121
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # __init__
    e = ProgrammingError("Some error")
    assert str(e) == "Some error"

    try:
        ProgrammingError.passert(True, "Some error")
    except ProgrammingError:
        assert False

    try:
        ProgrammingError.passert(False, "Some error")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Some error"

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:09:44.024028
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming has occurred.")
    except ProgrammingError as e:
        assert (str(e) == "A programming has occurred.")


# Generated at 2022-06-24 01:09:50.020988
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test that :py:class:`ProgrammingError` is constructed properly.
    """
    malformed_condition_test = "Broken coherence. Check your code against domain logic to fix it."
    malformed_condition_exception = ProgrammingError(message=malformed_condition_test)
    assert str(malformed_condition_exception) == malformed_condition_test

# Generated at 2022-06-24 01:09:52.821790
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit tests for module ProgrammingError."""
    try:
        ProgrammingError("A programming error.")
    except ProgrammingError as e:
        assert str(e) == "A programming error."


# Generated at 2022-06-24 01:09:53.835294
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("Message")
    assert repr(e) == "ProgrammingError(\"Message\")"


# Generated at 2022-06-24 01:09:55.789013
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error exception")
    except ProgrammingError as e:
        assert str(e) == "Programming error exception"



# Generated at 2022-06-24 01:09:58.143685
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    except Exception:
        assert False
    else:
        assert True



# Generated at 2022-06-24 01:10:03.012317
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from hypothesis import strategies as st, given
    from .hypothesis import declared_mutations

    @given(st.text().filter(lambda s: not s))
    def test_none(message: str) -> None:
        try:
            raise ProgrammingError(message)
        except ProgrammingError as error:
            assert str(error) == message

    @given(mutations=st.integers(min_value=0, max_value=4))
    def test_mutations(mutations: int) -> None:
        assert declared_mutations(ProgrammingError, ignore_missing=False) == mutations

# Generated at 2022-06-24 01:10:06.684354
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
        assert False, "Expected ProgrammingError"
    except ProgrammingError as ex:
        assert ex.args[0] == "This is a test"


# Generated at 2022-06-24 01:10:13.919893
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Exercise inputs
    message = "condition is not met"

    # Expected results
    expected_message = message

    # Setup / Exercise and Verify
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert str(e) == expected_message
    else:
        raise AssertionError("ProgrammingError was not raised.")



# Generated at 2022-06-24 01:10:17.418475
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error occurred.")
    except ProgrammingError as err:
        assert err.args[0] == "Some error occurred."


# Unit tests for classmethod passert of class ProgrammingError

# Generated at 2022-06-24 01:10:19.899094
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as ex:
        ProgrammingError.passert(False, "This is an error message.")
    assert ex.value.args[0] == "This is an error message."

# Generated at 2022-06-24 01:10:22.503253
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as errinfo:
        ProgrammingError.passert(False, "This is just a test")
    assert "This is just a test" == str(errinfo.value)

# Generated at 2022-06-24 01:10:26.737019
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase, main
    from pytest import raises

    class ProgrammingErrorTest(TestCase):
        def test(self):
            with raises(ProgrammingError, match="Broken coherence. Check your code against"):
                ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")
    main(verbosity=2)

# Generated at 2022-06-24 01:10:30.277432
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError(message)
    except ProgrammingError:
        try:
            raise ProgrammingError()
        except ProgrammingError:
            try:
                raise ProgrammingError(None)
            except ProgrammingError:
                pass


# Generated at 2022-06-24 01:10:33.840073
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
        return
    raise AssertionError()


# Generated at 2022-06-24 01:10:35.685397
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Error")
    except Exception as e:
        assert str(e) == "Error"


# Generated at 2022-06-24 01:10:37.855679
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("It raises.")
    except ProgrammingError as e:
        assert e.args[0] == "It raises."


# Generated at 2022-06-24 01:10:41.551517
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error_string = "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError()
    except ProgrammingError as error:
        assert str(error) == error_string
    else:
        assert False, "ProgrammingError() does not raise ProgrammingError."


# Generated at 2022-06-24 01:10:46.543145
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        1 / 0
    except:
        err = ProgrammingError("Testing 1/0")
        assert type(err) is ProgrammingError
        assert err.args == ("Testing 1/0",)



# Generated at 2022-06-24 01:10:48.873352
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("test1")


# Generated at 2022-06-24 01:10:57.997603
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert ProgrammingError
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    try:
        ProgrammingError(None)
    except ProgrammingError:
        pass
    try:
        ProgrammingError(0)
    except ProgrammingError:
        pass
    try:
        ProgrammingError(1)
    except ProgrammingError:
        pass
    try:
        ProgrammingError(False)
    except ProgrammingError:
        pass
    try:
        ProgrammingError(True)
    except ProgrammingError:
        pass
    try:
        ProgrammingError(0.0)
    except ProgrammingError:
        pass
    try:
        ProgrammingError(1.0)
    except ProgrammingError:
        pass



# Generated at 2022-06-24 01:11:01.145848
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    from pytest import raises
    from pypara import ProgrammingError
    with raises(ProgrammingError):
        ProgrammingError("This is an error formatting {}", 'whatever')


# Generated at 2022-06-24 01:11:09.635096
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`.
    """
    from contextlib import redirect_stdout
    from io import StringIO

    with StringIO() as buffer, redirect_stdout(buffer):
        error = ProgrammingError("An error message.")
        assert error.__str__() == "An error message.", "Unexpected error message."
        assert error.__repr__() == "An error message.", "Unexpected error message."
        try:
            raise error
        except ProgrammingError as e:
            pass

    # Expected:
    # Traceback (most recent call last):
    #   File "/home/daberto/code/pypara/pypara/errors.py", line 56, in test_ProgrammingError
    #     raise error
    # pypara.errors.ProgrammingError: An error message.

# Generated at 2022-06-24 01:11:12.400128
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Should not be True!")
    except ProgrammingError as err:
        assert str(err) == "Should not be True!"

# Generated at 2022-06-24 01:11:16.765807
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error message.")
    except ProgrammingError as e:
        assert str(e) == "Some error message."
        assert e.args[0] == "Some error message."


# Generated at 2022-06-24 01:11:18.633290
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        ProgrammingError(message="This is a programming error")



# Generated at 2022-06-24 01:11:27.521172
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError as e:
        assert False, "ProgrammingError must not be raised when the condition is True."
    try:
        ProgrammingError.passert(False, "")
        assert False, "ProgrammingError must be raised when the condition is False."
    except ProgrammingError as e:
        assert True, "ProgrammingError raised because the condition is False."
    try:
        ProgrammingError.passert(False, "Unexpected situation")
        assert False, "ProgrammingError must be raised when the condition is False."
    except ProgrammingError as e:
        assert e.args[0] == "Unexpected situation", "ProgrammingError raised with expected message."

# Generated at 2022-06-24 01:11:32.791352
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError.passert(condition=True, message="")
    except ProgrammingError:
        assert False

    try:
        raise ProgrammingError.passert(condition=False, message="")
    except ProgrammingError:
        assert True

    try:
        raise ProgrammingError.passert(condition=False, message=None)
    except ProgrammingError:
        assert True

# Generated at 2022-06-24 01:11:35.625167
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-24 01:11:37.273540
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Error message")

# Generated at 2022-06-24 01:11:40.338244
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor of class :py:class:`ProgrammingError`.
    """
    # noinspection PyTypeChecker
    ProgrammingError(None)

# Generated at 2022-06-24 01:11:45.046729
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This error is expected during unit tests")
    except ProgrammingError as e:
        assert e.args[0] == "This error is expected during unit tests"
        assert str(e) == "This error is expected during unit tests"

# Generated at 2022-06-24 01:11:48.197491
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except ProgrammingError as err:
        assert str(err) == "test"

# Generated at 2022-06-24 01:11:51.010083
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    ProgrammingError(message="It works")

# Generated at 2022-06-24 01:11:52.934490
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")
    except ProgrammingError as e:
        assert "Test message" == str(e)
    else:
        assert False

# Generated at 2022-06-24 01:11:55.422479
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Message of the error")
        assert False, "An exception was expected but not raised"
    except ProgrammingError as e:
        assert e.args[0] == "Message of the error"


# Generated at 2022-06-24 01:11:58.444102
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Positive case
    try:
        ProgrammingError.passert(True, "All Ok")
        assert True
    except ProgrammingError:
        assert False

    # Negative case
    try:
        ProgrammingError.passert(False, "All Ok")
        assert False
    except ProgrammingError:
        assert True

# Generated at 2022-06-24 01:12:00.613940
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-24 01:12:06.906766
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`.

    :raises AssertionError: In case that something is wrong.
    """
    # Test constructor
    try:
        pe = ProgrammingError("Testing a ProgrammingError.")
        assert pe.args[0] == "Testing a ProgrammingError."
    except Exception:
        raise AssertionError("ProgrammingError constructor does not work.")

# Test for the passert method.

# Generated at 2022-06-24 01:12:09.594268
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Message")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:12:12.837019
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message=None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:12:17.525633
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase, main

    class ProgrammingErrorTest(TestCase):
        def test_ProgrammingError(self):
            with self.assertRaises(ProgrammingError):
                ProgrammingError.passert(False, "")
            with self.assertRaises(ProgrammingError):
                ProgrammingError.passert(False, "foo")

    main()

# Generated at 2022-06-24 01:12:22.889636
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Should not be printed")
    except ProgrammingError as err:
        assert False, "Should not raise error"
    try:
        ProgrammingError.passert(False, "Should be printed")
    except ProgrammingError as err:
        assert err.args[0] == "Should be printed", "Message should have been 'Should be printed'"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as err:
        assert err.args[0] == "Broken coherence. Check your code against domain logic to fix it.", \
            "Message should have been 'Broken coherence. Check your code against domain logic to fix it.'"
    print("\n[ProgrammingError]: Unit test passed.")

# Generated at 2022-06-24 01:12:28.421242
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Verifies that the constructor of :py:class:`ProgrammingError` throws a simple error.
    """
    from pypara.test.test_error import ProgrammingError as TProgrammingError
    if not hasattr(TProgrammingError, "__init_subclass__"):
        raise AssertionError(
            "Use Python 3.6+ for testing Python 3.6+ features.")
    with TProgrammingError.assertRaises(TProgrammingError):
        raise TProgrammingError


# Generated at 2022-06-24 01:12:31.914713
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Any message")
    except ProgrammingError as err:
        assert(str(err) == "Any message")

    assert(str(ProgrammingError("Any message")) == "Any message")

# Generated at 2022-06-24 01:12:38.776758
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "message")
    try:
        ProgrammingError.passert(False, "message")
        raise AssertionError("ProgrammingError.passert should have raised an exception for condition=False")
    except ProgrammingError as e:
        assert e.args[0] == "message"
    try:
        ProgrammingError.passert(False, None)
        raise AssertionError("ProgrammingError.passert should have raised an exception for condition=False")
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:12:41.753074
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test error")
    except ProgrammingError as e:
        assert e.args == ("test error",)


# Generated at 2022-06-24 01:12:45.764405
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        assert False, "abcdefghijklmnopqrstuvwxyz"
    except:
        raise ProgrammingError(message="Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-24 01:12:51.225216
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    try:
        ProgrammingError.passert(False, "some message")
    except ProgrammingError as pe:
        assert pe.args[0] == "some message"
    # Test this branch to show that the assertion is not raised if the condition is True
    ProgrammingError.passert(True, "some message")

# Generated at 2022-06-24 01:12:56.517331
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        from unittest import mock
        from parachute import ProgrammingError

        with mock.patch("parachute.ProgrammingError.passert") as passert:
            ProgrammingError.passert(False, "Hello World!")
    except ImportError:
        pass
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError did not raise an exception as expected")

# Generated at 2022-06-24 01:12:59.558898
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something is wrong within the domain logic.")
    except ProgrammingError as e:
        assert e.args == ("Something is wrong within the domain logic.",)


# Generated at 2022-06-24 01:13:00.801001
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    assert ProgrammingError("Should be raised")


# Generated at 2022-06-24 01:13:03.852829
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "test")
    try:
        ProgrammingError.passert(True, "test")
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pytest.fail("ProgrammingError not expected")

# Generated at 2022-06-24 01:13:04.949060
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError()

# Generated at 2022-06-24 01:13:06.952389
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A testing message")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:13:12.201547
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :class:`ProgrammingError` constructor.
    """
    try:
        ProgrammingError.passert(False, "")
        assert(False)
    except ProgrammingError as e:
        assert(e.msg == "Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-24 01:13:16.775205
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except:
        assert False
    try:
        ProgrammingError("")
    except:
        assert False
    try:
        ProgrammingError("foo")
    except:
        assert False

# Generated at 2022-06-24 01:13:21.401101
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Condition is not true")
    except ProgrammingError as e:
        assert e.args[0] == "Condition is not true"
    else:
        assert False, "ProgrammingError.passert does not raise ProgrammingError"


# Generated at 2022-06-24 01:13:27.550250
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Case 1: No arguments
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
        assert not e.args

    # Case 2: With arguments
    try:
        ProgrammingError.passert(False, "A message")
    except ProgrammingError as e:
        assert str(e) == "A message"
        assert e.args == ("A message",)

# Generated at 2022-06-24 01:13:30.916619
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the constructor of :py:class:`ProgrammingError` works fine.
    """
    try:
        raise ProgrammingError("test")
    except ProgrammingError as ex:
        pass


# Generated at 2022-06-24 01:13:34.091432
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert str(err) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:13:36.446860
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "some message")
    except ProgrammingError as e:
        assert str(e) == "some message"


# Generated at 2022-06-24 01:13:37.524208
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("some error")
    except ProgrammingError as e:
        assert str(e) == "some error"


# Generated at 2022-06-24 01:13:40.643079
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError()

# Generated at 2022-06-24 01:13:46.762631
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "This is a bad error")
    assert excinfo.type == ProgrammingError
    assert str(excinfo.value) == "This is a bad error"

# Generated at 2022-06-24 01:13:54.171904
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        raise ProgrammingError()
    assert excinfo.type is ProgrammingError
    assert str(excinfo.value) == ""
    assert excinfo.value.__cause__ is None
    assert excinfo.value.__context__ is None
    with pytest.raises(ProgrammingError) as excinfo:
        raise ProgrammingError("A cause")
    assert excinfo.type is ProgrammingError
    assert str(excinfo.value) == "A cause"
    assert str(excinfo.value.__cause__) == "A cause"
    assert excinfo.value.__context__ is None


# Generated at 2022-06-24 01:14:00.329278
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test code.
    test_condition = False
    test_message = "This is a test."
    # Test.
    try:
        ProgrammingError.passert(test_condition, test_message)
    except ProgrammingError as e:
        assert e.args[0] == test_message
    else:
        assert False

# Generated at 2022-06-24 01:14:01.541653
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("some error")


# Generated at 2022-06-24 01:14:03.288494
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Something bad happened")
    except ProgrammingError as e:
        assert str(e) == "Something bad happened"

# Generated at 2022-06-24 01:14:06.116210
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): #pragma: no cover
    try:
        ProgrammingError("Test")
    except Exception as e:
        assert str(e) == "Test"


# Generated at 2022-06-24 01:14:07.243968
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:14:08.525849
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyTypeChecker
    ProgrammingError.passert(False, 'error')

# Generated at 2022-06-24 01:14:13.277654
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(1 == 1, "")
        ProgrammingError.passert(1 == 1, "This passes")
        ProgrammingError.passert(1 != 1, "This fails")
        assert False, "Should not pass."
    except ProgrammingError as e:
        assert "This fails" in (str(e))

# Generated at 2022-06-24 01:14:17.111776
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:14:26.513166
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Assert that :py:class:`ProgrammingError` works as expected.
    """
    try:
        raise ProgrammingError()  # Raising a ProgrammingError() shouldn't be possible.
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("A custom message")  # Raising a ProgrammingError() with custom message shouldn't be possible.
    except ProgrammingError:
        pass
    # Test static method passert()
    ProgrammingError.passert(True, None)  # No exception should be thrown.
    ProgrammingError.passert(True, "")  # No exception should be thrown.
    ProgrammingError.passert(False, None)  # An exception should be thrown.
    ProgrammingError.passert(False, "")  # An exception should be thrown.

# Generated at 2022-06-24 01:14:30.189469
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "should have failed"


# Generated at 2022-06-24 01:14:33.768472
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError()
    assert err.args == ("Broken coherence. Check your code against domain logic to fix it.", )
    err = ProgrammingError("Something horrible happened")
    assert err.args == ("Something horrible happened", )

# Unit test which verifies the static method ProgrammingError.assert

# Generated at 2022-06-24 01:14:38.971424
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    This method tests the constructor of the class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError("Some text")
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert e.args == ("Some text",)
        assert str(e) == "Some text"



# Generated at 2022-06-24 01:14:42.452645
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("fail")
    except ProgrammingError as e:
        assert e.args[0] == "fail"


# Generated at 2022-06-24 01:14:45.510943
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as exception:
        assert(str(exception) == "Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-24 01:14:50.370751
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="message")
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError should be raised when using the constructor."


# Generated at 2022-06-24 01:14:52.606597
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert str(e) == "Error message"


# Generated at 2022-06-24 01:14:56.636135
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-24 01:15:03.975722
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.exceptions import ProgrammingError
    try:
        e = ProgrammingError("internal error")
        raise Exception("ProgrammingError did not throw a ProgrammingError")
    except ProgrammingError as e:
        assert "internal error" == e.args[0]
    try:
        e = ProgrammingError()
        raise Exception("ProgrammingError did not throw a ProgrammingError")
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == e.args[0]


# Generated at 2022-06-24 01:15:06.784413
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("my error")
    except ProgrammingError as e:
        assert str(e) == "my error"


# Generated at 2022-06-24 01:15:08.058992
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "test"):
        pass

# Generated at 2022-06-24 01:15:11.040358
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as pe:
        assert str(pe) == "This is a test"


# Generated at 2022-06-24 01:15:14.330963
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ProgrammingError: Test the constructor of class ProgrammingError."""
    e = ProgrammingError("This is the error message.")
    assert str(e) == "This is the error message."

# Generated at 2022-06-24 01:15:16.130834
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is a programming exception")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:15:26.223681
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "I am testing if this check works as expected")
        assert False
    except ProgrammingError as e:
        assert str(e) == "I am testing if this check works as expected"

    try:
        ProgrammingError.passert(True, "This should not raise")
        assert True
    except ProgrammingError as e:
        assert False

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(True, None)
        assert True
    except ProgrammingError as e:
        assert False

# Generated at 2022-06-24 01:15:27.386382
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("Dummy")
    assert(str(exception) == "Dummy")


# Generated at 2022-06-24 01:15:28.104651
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    ProgrammingError("Test")

# Generated at 2022-06-24 01:15:30.578827
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Boo!")
    except ProgrammingError as e:
        assert str(e) == "Boo!"


# Generated at 2022-06-24 01:15:32.671527
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Some message!")
        assert(False)
    except ProgrammingError as e:
        assert(e.args[0] == "Some message!")

# Generated at 2022-06-24 01:15:35.585761
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-24 01:15:37.032072
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        raise ProgrammingError("Test message")


# Generated at 2022-06-24 01:15:43.807474
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Call to passert() with an incorrect condition
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError.passert() not raised.")

    # Call to passert() with a correct condition
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        raise AssertionError("ProgrammingError.passert() raises an exception when not expected.")

# Generated at 2022-06-24 01:15:45.805442
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
assert True  # No exception raised, all good.


# Generated at 2022-06-24 01:15:50.084267
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        raise ProgrammingError("Test")

# Generated at 2022-06-24 01:15:55.603806
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test_ProgrammingError")
    except ProgrammingError as exception:
        assert str(exception) == "test_ProgrammingError"


# Generated at 2022-06-24 01:16:06.235326
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for the class :py:class:`ProgrammingError`.

    :return: ``None``
    """
    def test_constructor_fails_without_message():

        try:
            raise ProgrammingError()
        except ProgrammingError as e:
            if e.args != ("Broken coherence. Check your code against domain logic to fix it.", ):
                raise AssertionError("Wrong message: %s" % e)
        else:
            raise AssertionError("No exception raised by the constructor")
        # END-IF-ELSE

        return

    def test_constructor_message():

        try:
            raise ProgrammingError("Test message")
        except ProgrammingError as e:
            if e.args != ("Test message", ):
                raise AssertionError("Wrong message: %s" % e)

# Generated at 2022-06-24 01:16:09.712784
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("this message")
    except ProgrammingError as e:
        assert e.args[0] == "this message"


# Generated at 2022-06-24 01:16:12.864012
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Simple test")
    except ProgrammingError as e:
        assert str(e) == "Simple test"
    else:
        assert False

# Generated at 2022-06-24 01:16:14.332419
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("Test exception")
    assert str(exception) == "Test exception"


# Generated at 2022-06-24 01:16:20.201602
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass

    try:
        raise ProgrammingError("Assertion")
    except ProgrammingError as e:
        assert str(e) == "Assertion"



# Generated at 2022-06-24 01:16:24.988510
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("test")
    assert str(e) == "test"


# Generated at 2022-06-24 01:16:26.884087
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except Exception as exc:
        assert isinstance(exc, ProgrammingError)


# Generated at 2022-06-24 01:16:33.618814
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Should not raise assertion
    ret = ProgrammingError.passert(True, "")
    assert ret is None

    # Should raise assertion
    try:
        ret = ProgrammingError.passert(False, "")
        assert ret is None
        assert False, "Previous line should have raised exception"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:16:37.733316
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.assertRaises(ProgrammingError, "Broken coherence. Check your code against domain logic to fix it."):
        raise ProgrammingError()


# Generated at 2022-06-24 01:16:42.241378
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError("This works")
    except ProgrammingError:
        pass
    else:
        assert False, "Programming error instance should have been raised"


# Generated at 2022-06-24 01:16:47.035272
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:16:53.391891
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check that it works and the message is the one passed
    try:
        raise ProgrammingError(message="Error message")
    except ProgrammingError as e:
        assert e.args[0] == "Error message"

    # Check that it works and the message is the default one
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-24 01:16:56.316493
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, match="Broken coherence. Check your code against domain logic to fix it."):
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")



# Generated at 2022-06-24 01:16:57.437248
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Booom!") as exc:
        pass

# Generated at 2022-06-24 01:17:00.747746
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This should fail but it does not.")
    except ProgrammingError as pe:
        assert str(pe) == "This should fail but it does not."
    else:
        assert "This should fail but it does not." != "This should fail but it does not."


# Generated at 2022-06-24 01:17:02.540138
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError:
        ProgrammingError.passert(False, "Test")

# Generated at 2022-06-24 01:17:05.318176
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-24 01:17:08.798328
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, message="Some message")



# Generated at 2022-06-24 01:17:11.501374
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, message="This is a test!")
    except ProgrammingError as e:
        assert e.args == ("This is a test!",)


# Generated at 2022-06-24 01:17:15.700180
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "")
    except Exception as e:
        raise e

# Generated at 2022-06-24 01:17:19.093824
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e1:
        assert e1.args == ()


# Generated at 2022-06-24 01:17:20.739253
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("some message")
        assert True
    except Exception:
        assert False

# Generated at 2022-06-24 01:17:28.589674
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase, main
    from unittest.mock import MagicMock

    class UnitTest(TestCase):

        def test_ProgrammingError_passert(self):
            condition = True
            message = "error message."
            programmingError = ProgrammingError.passert(condition, message)

            self.assertIsNone(programmingError)

            condition = False
            message = "error message."
            with self.assertRaises(ProgrammingError) as context:
                ProgrammingError.passert(condition, message)

            self.assertIsInstance(context.exception, ProgrammingError)
            self.assertEqual(str(context.exception), message)

            condition = True
            message = None
            programmingError = ProgrammingError.passert(condition, message)

            self.assertIsNone(programmingError)

           

# Generated at 2022-06-24 01:17:31.055367
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A dummy error occurred.")
    except ProgrammingError as exc:
        assert str(exc) == "A dummy error occurred.", "Unexpected error message."

# Generated at 2022-06-24 01:17:34.274415
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass



# Generated at 2022-06-24 01:17:37.447662
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        ProgrammingError()
    with raises(ProgrammingError):
        ProgrammingError("TEST_MESSAGE")


# Generated at 2022-06-24 01:17:42.622838
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Come on, you can do it.")
    except ProgrammingError as err:
        if str(err) != "Come on, you can do it.":
            raise AssertionError("The message of the exception should be 'Come on, you can do it.'")
    else:
        raise AssertionError("The exception should have been raised.")


# Generated at 2022-06-24 01:17:45.402665
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error has occurred")
    except ProgrammingError as err:
        assert str(err) == "A programming error has occurred"
    else:
        raise Exception("Cannot reach here")


# Generated at 2022-06-24 01:17:51.555766
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Detailed information about the problem.")
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)
        assert isinstance(err, ValueError)
        assert err.args == ("Detailed information about the problem.",)


# Generated at 2022-06-24 01:17:54.924035
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert "Broken coherence" in str(ProgrammingError())
    assert "my message" in str(ProgrammingError("my message"))


# Generated at 2022-06-24 01:17:57.894799
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as pe:
        assert pe.args == ("Broken coherence. Check your code against domain logic to fix it.", )


# Generated at 2022-06-24 01:18:01.928622
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError()

    assert(str(exception) == "Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-24 01:18:05.907261
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    assert issubclass(ProgrammingError, Exception)

    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Failed to invoke ProgrammingError's constructor"

    exc = ProgrammingError('some message')
    assert str(exc) == 'some message'