

# Generated at 2022-06-24 01:08:14.147682
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as exception:
        assert(isinstance(exception, ProgrammingError))


# Generated at 2022-06-24 01:08:15.621639
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError): ProgrammingError.passert(False, None)

# Generated at 2022-06-24 01:08:19.586616
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        raise ProgrammingError("Wrong!")

    assert "Wrong!" in str(excinfo.value)


# Generated at 2022-06-24 01:08:22.518420
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for :py:class:`ProgrammingError`.
    """
    import pytest

    with pytest.raises(ProgrammingError) as exception:
        ProgrammingError("Test message")

    assert exception.value.args == ("Test message",)

# Generated at 2022-06-24 01:08:30.680158
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    # noinspection PyUnresolvedReferences
    assert ProgrammingError.passert(True, "message") is None  # lgtm [py/call/wrong-arguments]
    try:
        # noinspection PyUnresolvedReferences
        ProgrammingError.passert(False, "message")
        assert False, "The previous line should have raised an exception"
    except ProgrammingError as pe:
        assert str(pe) == "message"

# Generated at 2022-06-24 01:08:34.229167
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, 'You must raise error')
        assert(False) # Should not reach here
    except ProgrammingError as e:
        assert(str(e) == 'You must raise error')


# Generated at 2022-06-24 01:08:36.942005
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This works.")
    except ProgrammingError:
        pass
    else:
        raise Exception("Should not reach here, as the `ProgrammingError` exception is expected.")


# Generated at 2022-06-24 01:08:44.042309
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase
    from unittest.mock import patch

    class TCContext(TestCase):

        def test_constructs_error(self):
            with patch('sys.stderr', new=None):
                ProgrammingError(None)

        def test_passert_raises_error_if_condition_is_false_and_message_is_not_given(self):
            with self.assertRaises(ProgrammingError):
                ProgrammingError.passert(False, None)

        def test_passert_raises_error_if_condition_is_false_and_message_is_given(self):
            with self.assertRaises(ProgrammingError):
                ProgrammingError.passert(False, "Some message")


# Generated at 2022-06-24 01:08:46.410275
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing the constructor of a ProgrammingError")
        assert False, "ProgrammingError is expected to raise an error"
    except ProgrammingError as pe:
        assert isinstance(pe, ProgrammingError)
    else:
        assert True

# Generated at 2022-06-24 01:08:51.689480
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as error:
        assert error.args[0] == "Test"

# Generated at 2022-06-24 01:09:02.335376
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    # ... A condition
    condition = True
    # ... And a message
    message = "Broken coherence. Check your code against domain logic to fix it."

    # WHEN
    # ... We assert the condition (which is true)
    try:
        ProgrammingError.passert(condition, message)
    except ProgrammingError as e:
        # THEN
        # ... We should not reach this point
        assert False, f"We should not reach this point (e = {e})."

    # WHEN
    # ... We assert the condition (which is true)
    try:
        ProgrammingError.passert(not condition, message)
    except ProgrammingError as e:
        # THEN
        # ... We should not reach this point
        assert True, f"We should reach this point (e = {e})."

test_Programming

# Generated at 2022-06-24 01:09:06.484704
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as e:
        pass
    assert isinstance(e, ProgrammingError)


# Generated at 2022-06-24 01:09:08.447026
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error occurred")
    except ProgrammingError as e:
        assert e.message == "Error occurred"



# Generated at 2022-06-24 01:09:11.349939
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Broken model")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError was not raised.")

# Generated at 2022-06-24 01:09:13.219985
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Act
    error = ProgrammingError("test")

    # Assert
    assert "test" == error.args[0]


# Generated at 2022-06-24 01:09:13.981589
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:09:15.042093
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("")
    except ProgrammingError:
        pass
    else:
        raise RuntimeError("Failed to raise an exception")


# Generated at 2022-06-24 01:09:19.734187
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("This is a ProgrammingError!")
    except ProgrammingError as e:
        assert e.args[0] == "This is a ProgrammingError!"


# Generated at 2022-06-24 01:09:22.085905
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Error message.")
    except ProgrammingError as e:
        assert(e.args[0] == "Error message.")


# Generated at 2022-06-24 01:09:32.430078
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    # No exception should be raised
    ProgrammingError.passert(True, None)
    ProgrammingError.passert(True, "")
    ProgrammingError.passert(True, "my message")

    # A ProgrammingError should be raised
    with raises(ProgrammingError):
        _ = ProgrammingError(None)
    with raises(ProgrammingError):
        _ = ProgrammingError("")
    with raises(ProgrammingError):
        _ = ProgrammingError("my message")

    # No exception should be raised
    ProgrammingError.passert(False, None)
    ProgrammingError.passert(False, "")
    ProgrammingError.passert(False, "my message")


# Generated at 2022-06-24 01:09:36.033519
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-24 01:09:40.312785
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:09:42.173645
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    err = ProgrammingError("error")
    assert err.args == ("error",)
    err = ProgrammingError()
    assert err.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-24 01:09:50.104275
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    msg = "Expected True but got False"
    failed = False
    try:
        ProgrammingError.passert(False, msg)
    except ProgrammingError as e:
        assert msg == str(e)
        failed = True
    if not failed:
        assert "Condition is True instead of False" == msg

if __name__ == "__main__":
    # Unit test for class ProgrammingError
    test_ProgrammingError()
    print("Test for class ProgrammingError passed!")

# Generated at 2022-06-24 01:09:51.481875
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass



# Generated at 2022-06-24 01:09:53.103195
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Some domain logic is broken.")


# Generated at 2022-06-24 01:10:00.363328
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyMissingOrEmptyDocstring
    class A(object):
        def __repr__(self):
            return "Hi"

    try:
        ProgrammingError.passert(False, "Error")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Error"

    try:
        ProgrammingError.passert(False, A())
        assert False
    except ProgrammingError as e:
        assert str(e) == "Hi"

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    ProgrammingError.passert(True, "OK")

# Generated at 2022-06-24 01:10:03.958911
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("A programming error message.")
    except ProgrammingError as prg_err:
        assert str(prg_err) == "A programming error message."
        assert repr(prg_err) == "ProgrammingError(A programming error message.)"


# Generated at 2022-06-24 01:10:08.011899
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected_message = 'test'

    try:
        raise ProgrammingError(expected_message)
    except ProgrammingError as e:
        assert e.args[0] == expected_message, "Actual message was '{0}', expected '{1}'".format(e.args[0], expected_message)


# Generated at 2022-06-24 01:10:09.914845
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test message")
    except Exception as e:
        assert "Test message" == e.args[0]

# Unit tests for method passert of class ProgrammingError

# Generated at 2022-06-24 01:10:11.874753
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    condition = False
    message = "Some message"
    error = None

    try:
        ProgrammingError.passert(condition, message)
    except ProgrammingError as error:
        pass

    assert error is not None
    assert message in error.args

# Generated at 2022-06-24 01:10:15.200101
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the constructor of the class.
    """
    ProgrammingError("MESSAGE")

# Generated at 2022-06-24 01:10:19.056246
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error!")
    except ProgrammingError as pe:
        assert pe.args[0] == "This is a programming error!"
    else:
        assert False, "ProgrammingError not raised"


# Generated at 2022-06-24 01:10:22.625714
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"

# Generated at 2022-06-24 01:10:25.112684
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert False, "An exception should be raised."
    except AssertionError as e:
        raise e
    except Exception:
        pass


# Generated at 2022-06-24 01:10:30.839890
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test with error message
    try:
        ProgrammingError.passert(condition=False, message="Bug here.")
    except ProgrammingError as e:
        assert str(e) == "Bug here."
    # Test without error message
    try:
        ProgrammingError.passert(condition=False, message=None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    # Test that it does not raise anything when the condition is true
    ProgrammingError.passert(condition=True, message="Bug here.")

# Generated at 2022-06-24 01:10:35.438950
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This raises an exception")
    except ProgrammingError as e:
        assert(e.args[0] == "This raises an exception")

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert(e.args[0].startswith("Broken coherence. Check your code against domain logic"))

# Generated at 2022-06-24 01:10:37.933335
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My programming error")
    except ProgrammingError as e:
        assert str(e) == "My programming error"
        assert e.__cause__ is None


# Generated at 2022-06-24 01:10:48.246772
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Everything OK")  # pylint: disable=no-value-for-parameter
    except ProgrammingError as error:
        assert False, "Not expecting this to happen!"

    try:
        ProgrammingError.passert(False, "Everything OK")  # pylint: disable=no-value-for-parameter
    except ProgrammingError as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(False, "Everything OK")  # pylint: disable=no-value-for-parameter
    except ProgrammingError as error:
        assert error.args[0] == "Everything OK"

# Generated at 2022-06-24 01:10:55.654069
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError() did not raise ProgrammingError"
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert e.args[0] == 'Error message'
    else:
        assert False, "ProgrammingError('Error message') did not raise ProgrammingError"

# Generated at 2022-06-24 01:10:58.759341
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "msg"
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as e:
        assert str(e) == msg


# Generated at 2022-06-24 01:11:01.630423
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as error:
        assert isinstance(error, ProgrammingError)
    else:
        raise AssertionError("No exception raised.")


# Generated at 2022-06-24 01:11:03.925361
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError()
    with raises(ProgrammingError):
        raise ProgrammingError("Some message")



# Generated at 2022-06-24 01:11:05.827965
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
        assert "Invalid exception not raised"
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:11:10.306436
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert(isinstance(e, Exception))
        assert(isinstance(e, ProgrammingError))
        assert(str(e) == "Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-24 01:11:12.544195
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Bad code!")
    except ProgrammingError as e:
        assert e.args[0] == "Bad code!"


# Generated at 2022-06-24 01:11:19.239940
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
        assert False, "#1"
    except ProgrammingError as e:
        assert e.args[0], "#2"

    try:
        ProgrammingError.passert(False, "foo")
        assert False, "#3"
    except ProgrammingError as e:
        assert e.args[0] == "foo", "#4"


# Generated at 2022-06-24 01:11:21.290558
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    except Exception:
        assert(False)


# Generated at 2022-06-24 01:11:24.641900
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error_message = "Something went wrong when parsing the input."
    try:
        raise ProgrammingError(error_message)
    except ProgrammingError as exception:
        assert error_message == str(exception), "This message is not the expected one."


# Generated at 2022-06-24 01:11:29.380362
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    error = ProgrammingError("test")
    assert str(error) == "test"

# Generated at 2022-06-24 01:11:31.188267
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from copy import copy

    message = "The message"
    error_type = copy(ProgrammingError)

    raises(ProgrammingError, error_type, message)

# Generated at 2022-06-24 01:11:36.836516
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class.
    """
    msg = "This is an error message."
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as e:
        assert e.args[0] == msg

# Generated at 2022-06-24 01:11:40.452707
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"
    finally:
        pass


# Generated at 2022-06-24 01:11:42.535367
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:11:45.339819
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert issubclass(ProgrammingError, type(e))



# Generated at 2022-06-24 01:11:56.320526
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # The following is not expected to raise anything
    ProgrammingError.passert(True, "message")

    # The following is expected to raise a ProgrammingError with the message "message"
    try:
        ProgrammingError.passert(False, "message")
    except ProgrammingError as e:
        if str(e) != "message":
            raise Exception("Unexpected ProgrammingError message: %s" % str(e))

    # The following is expected to raise a ProgrammingError with the message "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        if str(e) != "Broken coherence. Check your code against domain logic to fix it.":
            raise Exception("Unexpected ProgrammingError message: %s" % str(e))


# Generated at 2022-06-24 01:11:57.406827
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(condition=False, message="BAAAAD"):
        pass

# Generated at 2022-06-24 01:11:58.481068
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc = ProgrammingError("test")
    assert str(exc) == "test"

# Generated at 2022-06-24 01:12:04.200744
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Test")
    except ProgrammingError as exc:
        assert (str(exc) == "Test")
    else:
        assert False

    try:
        ProgrammingError.passert(condition=True, message="Test")
    except ProgrammingError as exc:
        assert False
    else:
        pass

# Generated at 2022-06-24 01:12:07.316984
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "This is a programming error"


# Generated at 2022-06-24 01:12:09.598580
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("My error message.")
    except ProgrammingError as e:
        assert e.args == ("My error message.",)

# Generated at 2022-06-24 01:12:11.219566
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "Message of the error")


# Generated at 2022-06-24 01:12:14.294029
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:12:15.308623
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    print(ProgrammingError)


# Generated at 2022-06-24 01:12:17.502273
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError:
        assert True
        return
    assert False


# Generated at 2022-06-24 01:12:18.348520
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:12:22.004560
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, """Should have raised ProgrammingError (without message)."""

    try:
        raise ProgrammingError("My message")
    except ProgrammingError as ex:
        assert ex.args[0] == "My message", "Should have raised ProgrammingError (with message)."""
    else:
        assert False, """Should have raised ProgrammingError (with message)."""


# Generated at 2022-06-24 01:12:25.321560
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Message"):
        pass

    with ProgrammingError.passert(False, "Message"):
        pass

# Generated at 2022-06-24 01:12:29.671972
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError() should raise a ProgrammingError error when no message is passed.")


# Generated at 2022-06-24 01:12:34.318219
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "msg")
    except ProgrammingError as e:
        assert str(e) == "msg"
        return
    assert False


# Generated at 2022-06-24 01:12:36.921990
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-24 01:12:38.547635
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Hello"):
        pass

# Generated at 2022-06-24 01:12:45.837631
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="test message")
    except ProgrammingError as e:
        assert e.args == ("test message",)
    try:
        ProgrammingError.passert(condition=False, message=None)
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    ProgrammingError.passert(condition=True, message="test message")

# Generated at 2022-06-24 01:12:49.228073
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert True


# Generated at 2022-06-24 01:12:52.082807
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("foo")
    assert "foo" in err.args


# Generated at 2022-06-24 01:12:53.802319
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Unit test for class ProgrammingError """

    with raises(ProgrammingError):
        raise ProgrammingError("Expected exception")


# Generated at 2022-06-24 01:12:58.156142
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "Some message"
    e = ProgrammingError(msg)
    assert str(e) == msg



# Generated at 2022-06-24 01:13:00.991467
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Some message.")
    except ProgrammingError as e:
        assert str(e) == "Some message."
        return
    assert False, "We should not reach this!"



# Generated at 2022-06-24 01:13:04.546776
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError.passert(False, "Assertion message")
    except ProgrammingError as e:
        assert str(e) == "Assertion message"

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:13:09.889730
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as exception:
        assert "Broken coherence. Check your code against domain logic to fix it." == exception.args[0]
    else:
        raise AssertionError("A programming error exception must be raised.")


# Generated at 2022-06-24 01:13:12.082224
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My error message.")
    except ProgrammingError as err:
        assert str(err) == "My error message."


# Generated at 2022-06-24 01:13:19.730345
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test with custom message
    msg = "test message"
    pe1 = ProgrammingError(msg)
    assert msg == pe1.args[0]

    # Test with None
    pe2 = ProgrammingError(None)
    assert None == pe2.args[0]

    # Test with no arguments
    pe3 = ProgrammingError()
    assert None == pe3.args[0]


# Generated at 2022-06-24 01:13:25.311017
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == ""
    try:
        raise ProgrammingError("My message")
    except ProgrammingError as e:
        assert str(e) == "My message"


# Generated at 2022-06-24 01:13:31.719736
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if :py:class:`ProgrammingError` is working as defined.
    """
    from pytest import raises
    from pypara import ProgrammingError
    _ = ProgrammingError()
    _ = ProgrammingError("An error has arisen")
    with raises(ProgrammingError, match="An error has arisen"):
        raise ProgrammingError("An error has arisen")


# Generated at 2022-06-24 01:13:34.520615
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("error message")
    except ProgrammingError as e:
        assert str(e) == "error message"

# Generated at 2022-06-24 01:13:36.489210
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-24 01:13:37.566638
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-24 01:13:40.680360
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test")  # Just check if it can be created without crashing


# Generated at 2022-06-24 01:13:46.537532
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Unit tests for method ProgrammingError.passert

# Generated at 2022-06-24 01:13:49.813553
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Will not raise!")
    except ProgrammingError as pe:
        print("Oops. Expected 'Will not raise!' but got '%s'" % pe)
    ProgrammingError.passert(False, None)

# Generated at 2022-06-24 01:13:54.148321
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as ex:
        assert str(ex) == "This is a test"

# Generated at 2022-06-24 01:13:59.058769
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error.")
    except ProgrammingError as error:
        assert str(error) == "This is an error."


# Generated at 2022-06-24 01:14:01.467865
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except Exception as exception:
        assert isinstance(exception, ProgrammingError)
        assert str(exception) == "Test"


# Generated at 2022-06-24 01:14:02.858831
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as e:
        assert e.args[0] == "This is an error"


# Generated at 2022-06-24 01:14:10.250012
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test assertion
    ProgrammingError.passert(True, "passert(True, message)")
    ProgrammingError.passert(False, "passert(True, message)")
    try:
        ProgrammingError.passert(False, "passert(True, message)")
        assert False, "This point should never be reached"
    except ProgrammingError as ex:
        pass
    try:
        ProgrammingError.passert(False, None)
        assert False, "This point should never be reached"
    except ProgrammingError as ex:
        assert "domain" in str(ex)

# Generated at 2022-06-24 01:14:13.484069
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError) and str(e) == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-24 01:14:16.923322
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Example error")
    except ProgrammingError as e:
        assert str(e) == "Example error"

# Generated at 2022-06-24 01:14:25.081107
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    from pypara.utilities.error_handling import ProgrammingError
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Expected")
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)
    try:
        ProgrammingError.passert(True, "Expected")
    except ProgrammingError as pe:
        pytest.fail(f"ProgrammingError raised with payload: {pe}")

# Generated at 2022-06-24 01:14:28.260210
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=W0212
    message = "This is the message"
    e = ProgrammingError(message)
    assert e.message == message

# Generated at 2022-06-24 01:14:33.080645
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
    except Exception as e:
        assert False


# Generated at 2022-06-24 01:14:39.579394
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=no-value-for-parameter
    try:
        ProgrammingError(None)
        raise AssertionError("Did not raise an exception")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    # pylint: enable=no-value-for-parameter


# Generated at 2022-06-24 01:14:42.636973
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    message = "A dummy message"

    # Act / Assert
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert message == str(e)


# Generated at 2022-06-24 01:14:45.340815
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "this is a test error")
    except ProgrammingError as e:
        assert "this is a test error" == str(e)

# Generated at 2022-06-24 01:14:48.782197
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check that the condition is met
    ProgrammingError.passert(1==1, "1 is not equal to 1")

# Generated at 2022-06-24 01:14:52.006847
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    message = "test_ProgrammingError"

    # WHEN
    error = ProgrammingError(message)

    # THEN
    assert message in str(error)


# Generated at 2022-06-24 01:14:52.985897
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-24 01:14:55.866833
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Your code is broken.")
    except Exception as ex:  # pylint: disable=broad-except, unused-variable
        assert True


# Generated at 2022-06-24 01:15:01.580781
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)



# Generated at 2022-06-24 01:15:11.082951
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the method ``ProgrammingError.__init__`` creates exceptions properly.
    """
    test_cases = [
        ("hello", "hello"),
        (1, "1"),
        (object(), ""),
    ]
    for test_case, expected in test_cases:
        try:
            raise ProgrammingError(test_case)
        except ProgrammingError as e:
            assert str(e) == expected, "Testcase '%s' failed" % str(test_case)


# Generated at 2022-06-24 01:15:13.964321
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of class ProgrammingError."""
    error = ProgrammingError("Testing")
    assert str(error) == "Testing"


# Generated at 2022-06-24 01:15:24.917433
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Test method "passert"
    def test_passert(condition: bool, msg: str, should_raise: bool):
        try:
            ProgrammingError.passert(condition, msg)
        except (ProgrammingError, Exception) as error:
            if should_raise:
                assert isinstance(error, ProgrammingError)
                assert error.args[0] == msg
            else:
                assert error is None, "Unexpected error raised unexpectedly"

    test_passert(True, None, False)
    test_passert(True, "", False)
    test_passert(True, "A", False)
    test_passert(False, None, True)
    test_passert(False, "", True)
    test_passert(False, "A", True)

# Generated at 2022-06-24 01:15:27.266303
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("foobar")
    except ProgrammingError as error:
        assert error.args == ("foobar",)

# Generated at 2022-06-24 01:15:30.534282
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert(e.args[0] == "Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-24 01:15:34.617033
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error = ProgrammingError()
    assert isinstance(programming_error, ProgrammingError)

    programming_error = ProgrammingError("Programming error message")
    assert isinstance(programming_error, ProgrammingError)
    assert str(programming_error) == "Programming error message"


# Generated at 2022-06-24 01:15:39.286812
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that :py:class:`ProgrammingError` is properly initialized by default.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-24 01:15:45.013944
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "TEST.1")
    except ProgrammingError as e:
        assert str(e) == "TEST.1"



# Generated at 2022-06-24 01:15:50.184542
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Hello"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert message == str(e)
        assert message == repr(e)
        assert e.__cause__ is None

# Generated at 2022-06-24 01:15:55.910456
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:15:58.716676
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(True, "We cannot reach this point")
    ProgrammingError.passert(False, "We cannot reach this point")

# Generated at 2022-06-24 01:16:00.751182
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    ProgrammingError(message="Message.")



# Generated at 2022-06-24 01:16:04.934732
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Test purpose")
    except ProgrammingError as test_error:
        assert str(test_error) == "Test purpose"


# Generated at 2022-06-24 01:16:05.853537
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-24 01:16:08.471476
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test error message")
    except ProgrammingError as e:
        assert e.__str__() == "Test error message"


# Generated at 2022-06-24 01:16:09.601454
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError():
        raise ProgrammingError()


# Generated at 2022-06-24 01:16:14.869744
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check that the ProgrammingError constructor works properly
    try:
        raise ProgrammingError("This is a test message.")
    except ProgrammingError as e:
        assert "This is a test message." in str(e)

# Generated at 2022-06-24 01:16:17.807778
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-24 01:16:21.115850
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert str(error) == ""

    ProgrammingError.passert(False, "this is an error")
    ProgrammingError.passert(True, "this is not an error")

# Generated at 2022-06-24 01:16:26.648293
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the unit test for :py:class:`ProgrammingError`.

    :raises ProgrammingError: In case of an error in the test.
    """
    try:
        ProgrammingError.passert(False, "Test")
        raise ProgrammingError("Test assertion does not work as expected.")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:16:31.748604
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing ProgrammingError")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Testing ProgrammingError"

# Generated at 2022-06-24 01:16:37.314916
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test.")
    except ProgrammingError:
        pass
    except AssertionError as e:
        raise AssertionError("ProgrammingError cannot be instantiated.") from e

# Generated at 2022-06-24 01:16:41.919302
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def raise_exception():
        raise ProgrammingError()
    assert_raises(ProgrammingError, raise_exception)


# Generated at 2022-06-24 01:16:45.276032
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert True


# Generated at 2022-06-24 01:16:46.633965
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError
    try:
        ProgrammingError()
    except Exception as ex:
        assert False, 'Exception should not have been raised. Details: {}'.format(ex)


# Generated at 2022-06-24 01:16:50.257548
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:16:57.774934
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""

    # case: condition is not fulfilled with a custom message
    try:
        ProgrammingError.passert(False, "some message")
    except ProgrammingError as e:
        assert str(e) == "some message"
    else:
        assert False

    # case: condition is not fulfilled with a default message
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False

    # case: condition is fulfilled
    try:
        ProgrammingError.passert(True, "some message")
    except ProgrammingError:
        assert False

# Generated at 2022-06-24 01:16:58.926734
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except TypeError:
        pass


# Generated at 2022-06-24 01:17:00.635599
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-24 01:17:03.747408
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "An applicable message explaining what went wrong.")

# Generated at 2022-06-24 01:17:08.161877
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError exception not thrown"

# Generated at 2022-06-24 01:17:13.117253
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    passert = ProgrammingError.passert
    passert(True, "")
    try:
        passert(False, None)
    except ProgrammingError as e:
        assert "Broken coherence" in str(e)
    else:
        assert False
    try:
        passert(False, "My message")
    except ProgrammingError as e:
        assert "My message" == str(e)
    else:
        assert False

# Generated at 2022-06-24 01:17:18.241085
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error!")
    except ProgrammingError:
        pass # It's ok, it's our intention
    else:
        assert False, "An exception was expected!"


# Generated at 2022-06-24 01:17:23.612514
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)
    try:
        ProgrammingError.passert(False, "broken")
    except ProgrammingError as e:
        assert "broken" == str(e)

if __name__ == '__main__':
    test_ProgrammingError()

# Generated at 2022-06-24 01:17:27.514087
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Testing constructor of class ProgrammingError."
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert str(e) == message


# Generated at 2022-06-24 01:17:30.137469
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError did not raise when instantiated"


# Generated at 2022-06-24 01:17:36.949881
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    :return:
    """
    # GIVEN
    message = "This is a message"

    # WHEN
    err = ProgrammingError(message)

    # THEN
    assert isinstance(err, ProgrammingError)
    assert isinstance(err, Exception)
    assert err.args[0] == message



# Generated at 2022-06-24 01:17:40.453459
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    a = "a"
    b = "b"
    try:
        ProgrammingError.passert(a == b, "Oh no!")
    except ProgrammingError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 01:17:44.242450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        pass
    assert str(error) == "Broken coherence. Check your code against domain logic to fix it."
    assert repr(error) == "ProgrammingError('Broken coherence. Check your code against domain logic to fix it.')"



# Generated at 2022-06-24 01:17:46.970127
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test if the constructor of class ProgrammingError works.
    """

    from pypara.bl_package.programming_error import ProgrammingError

    ProgrammingError.passert(False, "Test message")


# Generated at 2022-06-24 01:17:47.870752
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("This is the message"):
        pass


# Generated at 2022-06-24 01:17:52.624938
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False, "ProgrammingError not raised"
    except ProgrammingError as e:
        assert True
    try:
        ProgrammingError.passert(False, "abc")
        assert False, "ProgrammingError not raised"
    except ProgrammingError as e:
        assert e.args[0] == "abc"

# Generated at 2022-06-24 01:17:54.273661
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My message")
    except ProgrammingError as err:
        assert(str(err) == "My message")



# Generated at 2022-06-24 01:17:58.308541
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests whether creating an instance of :py:class:`ProgrammingError` succeeds when the message is ``None``.
    """
    try:
        raise ProgrammingError(None)
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError raising failed."

# Generated at 2022-06-24 01:18:03.819619
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, 'Testing')
        assert False, 'ProgrammingError must have been raised'
    except ProgrammingError as ex:
        assert str(ex) == 'Testing', 'ProgrammingError must have raised proper message'


# Generated at 2022-06-24 01:18:06.720806
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except Exception as exc:
        assert isinstance(exc, ProgrammingError)


# Generated at 2022-06-24 01:18:11.409262
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test of the constructor of :py:class:`ProgrammingError`.
    """
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Test")
