

# Generated at 2022-06-24 01:08:09.882694
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("This is a programming error.")
    assert exception.args[0] == "This is a programming error."

# Generated at 2022-06-24 01:08:12.216503
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "The no-flying bird may not be able to fly"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as ex:
        assert message == ex.args[0]


# Generated at 2022-06-24 01:08:13.929880
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is a message")
    assert isinstance(error, Exception)
    assert str(error) == "This is a message"


# Generated at 2022-06-24 01:08:15.913030
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("this is the error to throw")
    assert error.args == ("this is the error to throw",)


# Generated at 2022-06-24 01:08:17.379061
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError() as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:08:18.324427
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:08:19.732926
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My error")
    except ProgrammingError as e:
        assert str(e) == "My error"


# Generated at 2022-06-24 01:08:20.569546
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError.__init__.__doc__ is not None



# Generated at 2022-06-24 01:08:22.855577
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test assertion.")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test assertion."


# Generated at 2022-06-24 01:08:28.981860
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest.mock import patch

    # Given
    with patch('pypara.error.ProgrammingError') as mock_error:
        # When
        ProgrammingError.passert(False, "Any message")
        # Then
        assert mock_error.called_with("Any message")

# Generated at 2022-06-24 01:08:31.052570
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit-testing class :py:class:`ProgrammingError`."""
    try:
        ProgrammingError.passert(False, "Something is wrong here.")
    except ProgrammingError as e:
        assert "Something is wrong here." in e.args


# EOF

# Generated at 2022-06-24 01:08:40.720919
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError` class.
    """
    # Valid cases
    try:
        raise ProgrammingError("Unit test")
    except ProgrammingError as e:
        assert e.args[0] == "Unit test"

    # Invalid cases
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, None)
    assert excinfo.type == ProgrammingError
    assert str(excinfo.value) == "Broken coherence. Check your code against domain logic to fix it."

    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "Unit test")
    assert excinfo.type == ProgrammingError
    assert str(excinfo.value) == "Unit test"


# Generated at 2022-06-24 01:08:47.274878
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for class :py:class:`ProgrammingError`.
    """
    # Arrange
    # Act
    # Assert
    try:
        ProgrammingError.passert(condition=False, message="Expected condition is broken")
        assert False, "ProgrammingError should have been raised"
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, "Expected condition is broken")
        assert False, "ProgrammingError should have been raised"
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, None)
        assert False, "ProgrammingError should have been raised"
    except ProgrammingError:
        pass
    ProgrammingError.passert(True, "Expected condition is broken")

# Generated at 2022-06-24 01:08:50.661089
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-24 01:08:54.669001
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    This test just verifies that the constructor works.
    """
    try :
        raise ProgrammingError("test")
    except ProgrammingError as e:
        if str(e) != "test":
            raise AssertionError("Unexpected exception message: " + str(e))


# Generated at 2022-06-24 01:08:57.500574
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing")
    except ProgrammingError as e:
        assert e.args == ("Testing",)


# Generated at 2022-06-24 01:08:59.226761
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    message = "Broken coherence. Check your code against domain logic to fix it."

    # Act
    try:
        raise ProgrammingError
    except ProgrammingError as exc:
        assert str(exc) == message



# Generated at 2022-06-24 01:09:00.807369
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Exercise: test ProgrammingError.__init__
    # and ProgrammingError.passert
    pass

# Generated at 2022-06-24 01:09:12.991217
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytypes import typeassert
    from pytest import raises

    with raises(ProgrammingError) as excinfo:
        raises(ProgrammingError)

    assert excinfo.type is ProgrammingError
    assert issubclass(excinfo.type, Exception)
    assert excinfo.value is not None
    assert issubclass(type(excinfo.value), Exception)
    assert str(excinfo.value).endswith("Coherence")
    assert str(excinfo.value) == "Broken coherence. Check your code against domain logic to fix it."

    with raises(ProgrammingError) as excinfo:
        raises(ProgrammingError)

    assert excinfo.type is ProgrammingError
    assert issubclass(excinfo.type, Exception)
    assert excinfo.value is not None

# Generated at 2022-06-24 01:09:17.709246
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True
    else:
        assert False, "Programming Error not raised"


# Generated at 2022-06-24 01:09:18.470777
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError("Pass")


# Generated at 2022-06-24 01:09:22.214435
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        raise ProgrammingError("This is only a test")


# Generated at 2022-06-24 01:09:26.014679
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("mocked error")
    except ProgrammingError as e:
        assert str(e) == "mocked error"


# Generated at 2022-06-24 01:09:28.500298
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This expectation is not met.")
    except ProgrammingError as e:
        assert str(e) == "This expectation is not met."

# Generated at 2022-06-24 01:09:30.472617
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.common import ProgrammingError
    try:
        ProgrammingError.passert(False, "test")
    except ProgrammingError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-24 01:09:32.343608
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Programming error")
    except ProgrammingError as error:
        message = str(error)
        assert message == "Programming error"
        print("Test method ProgrammingError.__init__(self,message: str) - OK")

# Generated at 2022-06-24 01:09:36.453851
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, message="Message")

# Generated at 2022-06-24 01:09:40.105054
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:09:42.321579
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message 1")
    except ProgrammingError as e:
        assert str(e) == "Message 1"


# Generated at 2022-06-24 01:09:44.906566
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a message")
    except ProgrammingError as e:
        assert str(e) == "This is a message"

# Generated at 2022-06-24 01:09:49.003428
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Implementation error.")
    except ProgrammingError as e:
        assert isinstance(e, Exception)
        assert str(e) == "Implementation error."

# Generated at 2022-06-24 01:09:50.539126
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception) and isinstance(ProgrammingError(), Exception)


# Generated at 2022-06-24 01:09:52.301806
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Failed expectation.")


# Generated at 2022-06-24 01:09:53.183609
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "HOLA")

# Generated at 2022-06-24 01:09:54.179739
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError
    """
    assert ProgrammingError("Hola")


# Generated at 2022-06-24 01:09:57.673782
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == ""

    try:
        raise ProgrammingError("Hello")
    except ProgrammingError as e:
        assert str(e) == "Hello"



# Generated at 2022-06-24 01:10:00.197008
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("I am an instance of ProgrammingError.")
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError was not created properly."


# Generated at 2022-06-24 01:10:02.990848
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for the behaviour of :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError should have been raised"

# Generated at 2022-06-24 01:10:04.800167
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    except:
        assert False, "Construction of ProgrammingError failed!"


# Generated at 2022-06-24 01:10:07.590028
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Expected error message.")
    except ProgrammingError as e:
        assert str(e) == "Expected error message."


# Generated at 2022-06-24 01:10:09.538929
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # pylint: disable=unused-variable
        e = ProgrammingError()
    except Exception as e:
        pass
    assert type(e) == ProgrammingError


# Generated at 2022-06-24 01:10:11.492360
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-24 01:10:15.159910
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Because of this ...")

# Generated at 2022-06-24 01:10:17.610098
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:10:20.737112
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test error")
    except ProgrammingError:
        return

# Generated at 2022-06-24 01:10:25.678420
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Raises a :py:class:`ProgrammingError` when the constructor is invoked.
    """
    try:
        raise ProgrammingError(message="Custom message for unit test")
    except ProgrammingError as raised:
        assert raised.args[0] == "Custom message for unit test"
    else:
        raise AssertionError("Custom test failed")


# Generated at 2022-06-24 01:10:26.801391
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Should raise an error"):
        pass


# Generated at 2022-06-24 01:10:28.775557
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:10:32.716808
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("a test error")
    except ProgrammingError as ex:
        assert str(ex) == "a test error"

# Generated at 2022-06-24 01:10:36.877588
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Invalid parameter.")
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:10:39.472318
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:meth:`ProgrammingError.__init__` method.
    """
    try:
        raise ProgrammingError("Error")
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert "Error" in str(e)


# Generated at 2022-06-24 01:10:40.720381
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError

    :return:
    """
    assert ProgrammingError("Test")


# Generated at 2022-06-24 01:10:45.841330
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("error message.")
    except ProgrammingError as got:
        assert got.args[0] == "error message."


# Generated at 2022-06-24 01:10:49.608981
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, match="Broken coherence"):
        ProgrammingError.passert(False, None)

# Generated at 2022-06-24 01:10:55.800417
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("this is an error")
    except ProgrammingError as e:
        assert str(e) == "this is an error"
        assert repr(e) == "programming error: this is an error"
    else:
        raise AssertionError("Did not raise ProgrammingError")


# Generated at 2022-06-24 01:10:57.192155
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert(isinstance(e, ProgrammingError))

# Generated at 2022-06-24 01:10:58.618595
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message='Foobar')


# Generated at 2022-06-24 01:11:01.893143
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Bla bla")
        assert False, "It should have raised ProgrammingError"
    except ProgrammingError:
        pass

if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-24 01:11:03.842325
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is a user test.")
    assert str(error) == "This is a user test."



# Generated at 2022-06-24 01:11:06.405530
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    
    message = "Broken coherence. Check your code against domain logic to fix it."
    error = ProgrammingError(message)
    assert error.args[0] == message
    
    

# Generated at 2022-06-24 01:11:08.835167
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert error.args == ('Broken coherence. Check your code against domain logic to fix it.', )


# Generated at 2022-06-24 01:11:14.350676
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(None)
    except ProgrammingError as e:
        print(e)
    try:
        ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as e:
        print(e)


# Generated at 2022-06-24 01:11:16.964998
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test the constructor of class ProgrammingError."""
    ProgrammingError("ProgrammingError test")


# Generated at 2022-06-24 01:11:20.663210
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, None)
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)
    with pytest.raises(ProgrammingError, match="message"):
        ProgrammingError.passert(False, "message")

# Generated at 2022-06-24 01:11:23.000052
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-24 01:11:25.756044
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as e:
        e.args[0] == "Some message"

# Unit testing for static method passert

# Generated at 2022-06-24 01:11:28.875802
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError as e:
        assert True
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert True

# Generated at 2022-06-24 01:11:30.471149
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "")

# Generated at 2022-06-24 01:11:34.788201
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('This test must fail')
    except ProgrammingError as e:
        assert type(e) is ProgrammingError
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)
        assert str(e) == 'This test must fail'


# Generated at 2022-06-24 01:11:37.052640
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing")
    except ProgrammingError as e:
        pass


# Generated at 2022-06-24 01:11:40.221769
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-24 01:11:42.974123
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """

    ProgrammingError(message="Test")


# Generated at 2022-06-24 01:11:44.724801
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass



# Generated at 2022-06-24 01:11:48.639476
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError` to prove that the exception raises what is expected.
    """
    error_message = "Foo bar"
    try:
        raise ProgrammingError(error_message)
    except ProgrammingError as error:
        assert error.args == (error_message,)


# Generated at 2022-06-24 01:11:51.904092
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        # Test passed
        pass
    except Exception:
        raise AssertionError()


# Generated at 2022-06-24 01:11:53.544299
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("You have a bug in your code.")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:11:56.274714
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("a")
    assert repr(e) == "ProgrammingError: a"
    assert str(e) == "a"
    assert e.__context__ is None
    assert e.__cause__ is None
    assert e.args == ("a",)


# Generated at 2022-06-24 01:11:57.941924
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test"""
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as err:
        assert str(err) == "Test"

# Generated at 2022-06-24 01:11:59.176796
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Blah")

# Generated at 2022-06-24 01:12:02.388230
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Test message"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as pe:
        assert str(pe) == message


# Generated at 2022-06-24 01:12:04.851033
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from .types import ErrorMessage
    with raises(ProgrammingError, match=str(ErrorMessage)):
        raise ProgrammingError(ErrorMessage)

# Generated at 2022-06-24 01:12:07.168802
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert "Test" == str(e)

# Generated at 2022-06-24 01:12:08.580428
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:12:11.472117
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-24 01:12:13.728503
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "A programming error")


# Generated at 2022-06-24 01:12:15.943208
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message.")
    except ProgrammingError as e:
        assert str(e) == "Test message."

# Generated at 2022-06-24 01:12:18.324059
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is a test!")
    assert error.args == ("This is a test!",)
    assert str(error) == "This is a test!"


# Generated at 2022-06-24 01:12:19.688198
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert isinstance(error, ProgrammingError)



# Generated at 2022-06-24 01:12:25.300530
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Exception")
    except ProgrammingError as exception:
        assert str(exception) == "Exception"
        assert isinstance(exception, Exception)
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as exception:
        assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."
        assert isinstance(exception, Exception)
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as exception:
        assert False, "Test method ProgrammingError.passert failed"

# Generated at 2022-06-24 01:12:29.215725
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test exception.")
    except ProgrammingError as error:
        assert error.args[0] == "Test exception."


# Generated at 2022-06-24 01:12:33.457972
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with assert_raises(ProgrammingError):
        ProgrammingError.passert(False, 'This is a test')

# Generated at 2022-06-24 01:12:34.621645
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)


# Generated at 2022-06-24 01:12:37.229823
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "foo")
        assert False
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)



# Generated at 2022-06-24 01:12:39.829370
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Raise exception and test it
    try:
        raise ProgrammingError("Programming error message")
    except ProgrammingError as e:
        assert str(e) == "Programming error message"



# Generated at 2022-06-24 01:12:44.756880
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, None)
    try:
        ProgrammingError.passert(False, "A message.")
        assert False, 'Expected a ProgrammingError.'
    except ProgrammingError as e:
        assert str(e) == "A message.", 'Unexpected ProgrammingError message.'
    try:
        ProgrammingError.passert(False, None)
        assert False, 'Expected a ProgrammingError.'
    except ProgrammingError as e:
        assert bool(str(e)), 'Expected a ProgrammingError non empty message.'

# Generated at 2022-06-24 01:12:50.844906
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.

    :return: ``None``
    """
    try:
        raise ProgrammingError("Hi there!")
    except ProgrammingError as e:
        assert e.args[0] == "Hi there!"
    else:
        assert False, "An exception should have been raised"

# Generated at 2022-06-24 01:12:55.187754
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(condition=False, message="foo")

    assert "foo" in str(excinfo.value)

# Generated at 2022-06-24 01:12:59.018803
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert error.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-24 01:13:01.316318
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError.passert(False, message="This is an error")
    ProgrammingError.passert(True, message="This is an error")

# Generated at 2022-06-24 01:13:03.190782
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:13:04.500054
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    assert isinstance(ProgrammingError(), ProgrammingError)


# Generated at 2022-06-24 01:13:09.711875
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as ex:
        assert str(ex) == "Test message"
        assert ex.args[0] == "Test message"
        assert ex.args == ("Test message",)


# Generated at 2022-06-24 01:13:11.311159
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("The message")
    assert exception.args == ("The message",)
    return


# Generated at 2022-06-24 01:13:12.783253
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("An error")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:13:15.572450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "error"):
        pass

# Generated at 2022-06-24 01:13:17.412909
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:13:21.048958
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:13:25.332487
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with assert_raises(ProgrammingError):
        ProgrammingError.passert(False, None)
    with assert_raises(ProgrammingError):
        ProgrammingError.passert(False, "The code is working as expected")

# Generated at 2022-06-24 01:13:30.193673
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as error:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False

# Generated at 2022-06-24 01:13:32.955040
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Check your code against domain logic to fix it.")
    except ProgrammingError as e:
        assert(str(e))

# Generated at 2022-06-24 01:13:35.394821
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`
    """
    raise ProgrammingError("Deliberate error for unit test")


# Generated at 2022-06-24 01:13:38.179459
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Condition not met.")
    try:
        ProgrammingError.passert(True, "Condition met.")
    except ProgrammingError as e:
        fail(e)

# Generated at 2022-06-24 01:13:40.630626
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # type: () -> None
    """
    Provides a unit test for the :py:class:`ProgrammingError`.
    """
    expected = ProgrammingError("test")
    assert expected.message == "test", "The message is not properly set."

# Generated at 2022-06-24 01:13:46.295934
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(None)
    try:
        ProgrammingError.passert(False, None)
        assert False, "Expected a ProgrammingError."
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:13:48.896582
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Some description")
    except Exception as e:
        assert type(e) == ProgrammingError
        assert e.__str__() == "Some description"

# Generated at 2022-06-24 01:13:52.390351
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # This exception is going to be caught by the test runner and it's not going to be propagated until the end
        # of the module or the caller.
        raise ProgrammingError("The programmer inisisted in doing something wrong...")
    except ProgrammingError:
        pass



# Generated at 2022-06-24 01:13:54.166214
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message.")
    except ProgrammingError as e:
        assert str(e) == "Test message."


# Generated at 2022-06-24 01:13:58.693700
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    ProgrammingError("This is a programming error")

# Generated at 2022-06-24 01:14:01.428357
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as exc:
        assert str(exc) == "This is a test"
    else:
        assert False, "ProgrammingError not raised"


# Generated at 2022-06-24 01:14:03.508560
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error.")
    except ProgrammingError as e:
        assert str(e) == 'This is a programming error.'


# Generated at 2022-06-24 01:14:04.648893
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("Some message").args == ("Some message",)


# Generated at 2022-06-24 01:14:07.823846
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-24 01:14:10.574682
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    from pytest import raises
    with raises(ProgrammingError):
        raise ProgrammingError("Expected!")

# Generated at 2022-06-24 01:14:13.149666
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Dummy message")
    except ProgrammingError as e:
        assert e.args[0] == "Dummy message"

# Generated at 2022-06-24 01:14:16.644033
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-24 01:14:18.181311
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error occurred.")
    except ProgrammingError as e:
        assert(str(e) == "Programming error occurred.")


# Generated at 2022-06-24 01:14:23.657083
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():  # noqa
    error = ProgrammingError("This is the expected message.")
    assert isinstance(error, ProgrammingError)
    assert isinstance(error, Exception)
    assert str(error) == "This is the expected message."


# Generated at 2022-06-24 01:14:27.856032
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("We are testing error throwing.")
    except ProgrammingError as e:
        assert str(e) == "We are testing error throwing."


# Generated at 2022-06-24 01:14:36.583835
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Lorem ipsum")
    except ProgrammingError as e:
        assert e.args == ("Lorem ipsum",)
    ProgrammingError.passert(True, "Lorem ipsum")
    try:
        ProgrammingError.passert(False, "Lorem ipsum")
    except ProgrammingError as e:
        assert e.args == ("Lorem ipsum",)


# Generated at 2022-06-24 01:14:40.793399
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # When
    try:
        ProgrammingError()
    except ProgrammingError as error:
        # Then
        assert isinstance(error, Exception)
        assert issubclass(error.__class__, Exception)
        assert error.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-24 01:14:44.008754
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Test if the constructor of class ProgrammingError is working as expected
    try:
        raise ProgrammingError("Testing raise of ProgrammingError")
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:14:46.447529
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("My message")
    except ProgrammingError as e:
        assert e.args[0].startswith("My message")



# Generated at 2022-06-24 01:14:52.007745
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "This is an error"
    try:
        ProgrammingError("This is an error")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == msg

if __name__ == '__main__':
    test_ProgrammingError()

# Generated at 2022-06-24 01:14:58.096632
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase

    class TestProgrammingError(TestCase):

        def test_passert(self):
            try:
                ProgrammingError.passert(True, "This is not to be raised.")
            except ProgrammingError:
                self.fail("ProgrammingError was not to be raised!")

# Generated at 2022-06-24 01:15:00.725537
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    expected = "This is the error message"

    # WHEN
    error = ProgrammingError(expected)

    # THEN
    assert expected == error.args[0]


# Generated at 2022-06-24 01:15:06.964501
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError("")

    try:
        ProgrammingError("")
    except ProgrammingError as e:
        assert str(e) == ""

    with raises(ProgrammingError):
        ProgrammingError("Hola mundo")

    try:
        ProgrammingError("Hola mundo")
    except ProgrammingError as e:
        assert str(e) == "Hola mundo"

    with raises(ProgrammingError):
        ProgrammingError.passert(False, None)

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Hola mundo")

   

# Generated at 2022-06-24 01:15:07.877684
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    raise ProgrammingError("Something went wrong")


# Generated at 2022-06-24 01:15:10.165625
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "test error message")

# Generated at 2022-06-24 01:15:14.152032
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        raise AssertionError("ProgrammingError must be raised")
    except ProgrammingError as e:
        print(e)

# Generated at 2022-06-24 01:15:19.435548
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the constructor of class ProgrammingError.
    """
    import unittest.mock

    # Given
    error_message = "The universe is broken."
    expected_error_message = error_message

    # When
    actual_error = ProgrammingError(error_message)

    # Then
    assert actual_error.args[0] == expected_error_message


# Generated at 2022-06-24 01:15:24.744965
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.

    :return: ``None``
    """
    # Check that the constructor works properly
    try:
        raise ProgrammingError("foo")
    except ProgrammingError as e:
        assert str(e) == "foo"
    else:
        raise RuntimeError("ProgrammingError constructor does not work properly.")

# Generated at 2022-06-24 01:15:25.539823
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(None)



# Generated at 2022-06-24 01:15:27.554775
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` constructor.

    :return: ``None``.
    """
    assert ProgrammingError().args == ("Broken coherence. Check your code against domain logic to fix it.",)



# Generated at 2022-06-24 01:15:29.704465
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 01:15:40.471896
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    try:
        raise ProgrammingError("You have broken something!")
    except ProgrammingError as ex:
        assert str(ex) == "You have broken something!"
        assert repr(ex) == "You have broken something!"

    with pytest.raises(ProgrammingError):
        raise ProgrammingError("You have broken something!")

    with pytest.raises(ProgrammingError) as ex:
        raise ProgrammingError("You have broken something!")
        assert str(ex) == "You have broken something!"
        assert repr(ex) == "You have broken something!"

    with pytest.raises(ProgrammingError):
        raise ProgrammingError()
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("")
    with pytest.raises(ProgrammingError):
        raise ProgrammingError(" ")

   

# Generated at 2022-06-24 01:15:42.800118
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Unit testing")
    except ProgrammingError as err:
        assert str(err) == "Unit testing"


# Generated at 2022-06-24 01:15:46.584614
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`
    """
    try:
        raise ProgrammingError("This error is raised by unit test")
    except ProgrammingError as ex:
        assert str(ex) == "This error is raised by unit test"


# Generated at 2022-06-24 01:15:51.939451
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    condition = False
    message = "Sample error"
    try:
        ProgrammingError.passert(condition, message)
    except ProgrammingError as exc:
        assert str(exc) == message
    else:
        assert False, "ProgrammingError not raised"


# Generated at 2022-06-24 01:15:55.084762
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        ProgrammingError.passert(condition=False, message="None")


# Generated at 2022-06-24 01:15:58.424809
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("Error")

    # Check that it works uniformly
    assert err.args[0] == "Error"
    assert err.message == "Error"
    assert err.args == ("Error",)
    assert str(err) == "Error"

# Generated at 2022-06-24 01:16:06.149996
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test constructor of class ProgrammingError."""
    msg = "Test message"
    try:
        ProgrammingError.passert(condition=False, message=msg)
    except ProgrammingError as err:
        assert err.__class__.__name__ == "ProgrammingError"
        assert str(err) == msg
    else:
        assert False, "No exception was raised!"
    try:
        ProgrammingError.passert(condition=True, message=msg)
    except ProgrammingError:
        assert False, "An exception was raised!"
    else:
        assert True

# Generated at 2022-06-24 01:16:09.288209
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor for class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-24 01:16:13.883542
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        raise ProgrammingError("test")



# Generated at 2022-06-24 01:16:18.425484
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("")
    except ProgrammingError as e:
        pass


# Generated at 2022-06-24 01:16:20.574175
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a message")
    except ProgrammingError as e:
        assert str(e) == 'This is a message'


# Generated at 2022-06-24 01:16:25.406928
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Unexpected error")
    except ProgrammingError as err:
        assert str(err) == "Unexpected error"


# Generated at 2022-06-24 01:16:31.543206
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Boo")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Boo"

# Generated at 2022-06-24 01:16:36.844389
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    # Positive cases
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as err:
        assert err.args[0]=="A message"
    # Negative cases
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert err.args[0]=="Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:16:43.032840
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Mocked message")
    except ProgrammingError as e:
        assert isinstance(e, Exception)
        assert str(e) == "Mocked message"
        assert repr(e) == "ProgrammingError: Mocked message"


# Generated at 2022-06-24 01:16:44.874181
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("ProgrammingError test")

# Generated at 2022-06-24 01:16:49.862803
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the class constructor of :py:class:`ProgrammingError`
    """

    try:
        raise ProgrammingError("My Error Message")
    except ProgrammingError as e:
        assert e.args[0] == "My Error Message"
        assert e.args[0] != "Some random string"
    else:
        assert False



# Generated at 2022-06-24 01:16:53.639876
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("asdf")
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert e.__class__.__name__ == "ProgrammingError"
        assert str(e) == "asdf"
        assert repr(e) == "ProgrammingError('asdf',)"


# Generated at 2022-06-24 01:16:56.347239
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor and the class-level method of :py:class:`ProgrammingError`.
    """
    # This should not raise an exception
    ProgrammingError.passert(True, "Some message")

    # This should raise an exception
    try:
        ProgrammingError.passert(False, "Some message")
        assert False, "ProgrammingError not raised."
    except ProgrammingError as e:
        assert str(e) == "Some message"

# Generated at 2022-06-24 01:16:59.269560
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a dummy error.")
    except ProgrammingError as error:
        assert error.args[0] == "This is a dummy error."
    else:
        assert False, "This point should not be reached."

# Generated at 2022-06-24 01:17:01.737842
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Wrong coherence. Restore it.")
    except ProgrammingError as e:
        assert str(e) == "Wrong coherence. Restore it."
    else:
        assert False


# Generated at 2022-06-24 01:17:11.776714
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=missing-function-docstring
    # pylint: disable=no-member

    try:
        ProgrammingError.passert(False, 'Test message')
    except ProgrammingError as err:
        assert str(err) == 'Test message'
    else:
        assert False, 'Should not get here'

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as err:
        assert str(err) == 'Broken coherence. Check your code against domain logic to fix it.'
    else:
        assert False, 'Should not get here'

    ProgrammingError.passert(True, 'Test message')

# Generated at 2022-06-24 01:17:16.305612
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test has run successfully.")
    except ProgrammingError as e:
        assert str(e) == "Test has run successfully."



# Generated at 2022-06-24 01:17:20.236413
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    try:
        ProgrammingError.passert(False, "")
        assert False  # pragma: no cover
    except ProgrammingError:
        assert True
    else:
        assert False  # pragma: no cover

# Generated at 2022-06-24 01:17:23.142358
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        assert True

    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as e:
        assert str(e) == "Some message"



# Generated at 2022-06-24 01:17:25.441967
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:17:27.736605
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("I am a message")


# Generated at 2022-06-24 01:17:29.958711
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, None)

# Generated at 2022-06-24 01:17:34.016039
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Programming error message")
    except ProgrammingError as p:
        assert p.message == "Programming error message"

# Generated at 2022-06-24 01:17:37.000022
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Custom message")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:17:41.989480
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with Expectation(ProgrammingError()):
        # The exception is raised because we expect a non-empty message.
        ProgrammingError.passert(False, "")
    with Expectation(ProgrammingError("Expected behavior")):
        # The exception is raised because we expect a non-empty message.
        ProgrammingError.passert(False, "Expected behavior")

# Generated at 2022-06-24 01:17:44.321941
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("I am an error")
    except ProgrammingError as exc:
        assert str(exc) == "I am an error"


# Generated at 2022-06-24 01:17:46.013519
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass
    else:
        assert False

# Generated at 2022-06-24 01:17:52.458676
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # It should raise a ProgrammingError
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False
    # It should raise a ProgrammingError with msg
    try:
        ProgrammingError("Blah blah blah")
    except ProgrammingError as e:
        assert str(e) == "Blah blah blah"
    else:
        assert False


# Generated at 2022-06-24 01:18:01.471449
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:meth:`ProgrammingError.__init__`.
    """
    # pylint: disable=protected-access
    try:
        assert ProgrammingError()
    except ProgrammingError as exception:
        assert issubclass(ProgrammingError, Exception)
        assert issubclass(ProgrammingError, exception.__class__)
        assert issubclass(Exception, Exception)
        assert issubclass(Exception, exception.__class__)
        assert issubclass(Exception, Exception)
        assert issubclass(Exception, exception.__class__)
        assert issubclass(ProgrammingError, Exception)
        assert issubclass(ProgrammingError, exception.__class__)
        assert issubclass(ProgrammingError, ProgrammingError)
        assert issubclass(ProgrammingError, exception.__class__)

# Generated at 2022-06-24 01:18:09.902446
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        error = ProgrammingError.passert(False, "An expected error for the unit test")
        assert False, "ProgrammingError.passert must raise an error"
    except ProgrammingError as error:
        assert True, "ProgrammingError.passert has raised an error as expected"
        assert error.args[0] == "An expected error for the unit test", "ProgrammingError.passert has raised an unexpected error"
    try:
        error = ProgrammingError.passert(True, "An expected error for the unit test")
        assert True, "ProgrammingError.passert has worked as expected"
    except ProgrammingError as error:
        assert False, "ProgrammingError.passert must not raise an error"