

# Generated at 2022-06-24 01:08:09.059940
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a message")
    except ProgrammingError as pe:
        assert pe.args[0] == "This is a message"

# Generated at 2022-06-24 01:08:14.179383
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "This is a message"
    ex = ProgrammingError(msg)
    assert str(ex) == msg


# Generated at 2022-06-24 01:08:15.881708
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError()



# Generated at 2022-06-24 01:08:17.605369
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('Not Yet Implemented.')
    except ProgrammingError as e:
        assert(str(e) == 'Not Yet Implemented.')

# Generated at 2022-06-24 01:08:19.281809
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="This is going to be raised")
    except ProgrammingError as e:
        assert str(e) == "This is going to be raised"


# Generated at 2022-06-24 01:08:21.613262
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Not a problem")
    except ProgrammingError as e:
        assert(str(e) == "Not a problem")


# Generated at 2022-06-24 01:08:24.622251
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError("potato")
    except ProgrammingError as e:
        assert str(e) == "potato"


# Generated at 2022-06-24 01:08:27.154355
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("My message")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:08:30.560954
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "This is a message."
    try:
        raise ProgrammingError(message)
    except ProgrammingError as err:
        assert err.args == (message, )


# Generated at 2022-06-24 01:08:40.265311
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test assertion with satisfied condition
    try:
        ProgrammingError.passert(True, "Test message")
    except ProgrammingError as e:
        assert False, "ProgrammingError.passert(True, 'Test message') should have not failed: " + str(e)
    # Test assertion with unsatisfied condition
    try:
        ProgrammingError.passert(False, "Test message")
        assert False, "ProgrammingError.passert(False, 'Test message') should have failed"
    except ProgrammingError as e:
        assert str(e) == "Test message", "Wrong error message. Expected 'Test message' but got '" + str(e) + "'"
    # Test assertion with unsatisfied condition and no message

# Generated at 2022-06-24 01:08:42.275014
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "This must not raise an exception.")
    try:
        ProgrammingError.passert(False, "This must raise an exception.")
    except ProgrammingError:
        return True
    return False

# Generated at 2022-06-24 01:08:43.726118
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as ex:
        assert str(ex) == "Test message"


# Generated at 2022-06-24 01:08:46.167023
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing error")
        assert False
    except ProgrammingError as error:
        assert str(error) == "Testing error"


# Generated at 2022-06-24 01:08:49.540712
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("m")


# Generated at 2022-06-24 01:08:51.878229
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message: str = "Error message"
    error: ProgrammingError = ProgrammingError(message)
    assert error.args[0] == message

# Generated at 2022-06-24 01:08:57.033365
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error occurred")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "A programming error occurred"


# Generated at 2022-06-24 01:09:06.631497
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    error = Exception(message="Hello")
    try:
        raise ProgrammingError()
    except ProgrammingError as internal_error:
        assert internal_error is not None
        assert str(internal_error) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError(error)
    except ProgrammingError as internal_error:
        assert internal_error is not None
        assert str(internal_error) == str(error)
    try:
        raise ProgrammingError(message="Hello")
    except ProgrammingError as internal_error:
        assert internal_error is not None
        assert str(internal_error) == "Hello"
    try:
        raise ProgrammingError(error, message="Hello")
    except ProgrammingError as internal_error:
        assert internal_

# Generated at 2022-06-24 01:09:07.888730
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Exercise the class constructor of ProgrammingError
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:09:10.782160
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("")
    except ProgrammingError as err:
        assert str(err) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:09:21.634740
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Test that the error message is None
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "ProgrammingError exception was not raised"

    # Test that the error message is not None
    try:
        ProgrammingError.passert(False, "error message")
    except ProgrammingError as e:
        assert str(e) == "error message"
    else:
        assert False, "ProgrammingError exception was not raised"

    # Test that the condition is met and the exception is not raised
    ProgrammingError.passert(True, "error message")
    ProgrammingError.passert(True, None)
    assert True

# Generated at 2022-06-24 01:09:26.871711
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` class constructor.
    """

    # Test standard constructor
    ex = ProgrammingError("Expected result not found")
    assert ex.args == ("Expected result not found", )

    # Test empty constructor
    ex = ProgrammingError()
    assert ex.args == tuple()

# Generated at 2022-06-24 01:09:28.245091
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert False
    except ProgrammingError as e:
        assert "Broken coherence" in str(e)

# Generated at 2022-06-24 01:09:30.913318
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Not broken."):
        pass
    try:
        with ProgrammingError.passert(False, "Broken."):
            pass
    except ProgrammingError as ex:
        assert ex.args[0] == 'Broken.'
    else:
        assert False


# Generated at 2022-06-24 01:09:32.321285
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Not met.")
    except ProgrammingError as e:
        assert str(e) == "Not met."


# Generated at 2022-06-24 01:09:37.545414
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:09:39.766148
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        with ProgrammingError.passert(False, "test_ProgrammingError"):
            raise ProgrammingError("test_ProgrammingError")
    except ProgrammingError as e:
        assert e.args[0] == "test_ProgrammingError"

# Generated at 2022-06-24 01:09:42.806457
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class B:
        pass

    try:
        B.passert(False, "This is a test")
        assert False
    except ProgrammingError:
        pass
    else:
        assert False

# Generated at 2022-06-24 01:09:44.624372
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('')
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:09:49.249764
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert ex.args == ()
    try:
        raise ProgrammingError("broken")
    except ProgrammingError as ex:
        assert ex.args == ("broken",)


# Generated at 2022-06-24 01:09:52.335728
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing constructor")
    except ProgrammingError as e:
        assert e.args[0] == "Testing constructor"
    else:
        assert False, "Did not catch ProgrammingError exception"


# Generated at 2022-06-24 01:09:53.787137
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-24 01:09:55.257289
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    exc = ProgrammingError("",)

    assert exc.args == ("",)

# Generated at 2022-06-24 01:09:56.687185
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("This is an intentional error.")


# Generated at 2022-06-24 01:10:04.607537
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # In this case, we are not going to test the behavior of the constructor, but the behavior of the class method
    # passert.
    # First, we define a variable to capture the error raised by the class method passert.
    error: Optional[ProgrammingError] = None
    # The expected message is the one of the exception raised in that case.
    expected_message = "Broken coherence. Check your code against domain logic to fix it."
    try:
        # We invoke the class method passert with a condition that is not fulfilled.
        ProgrammingError.passert(False, "")
    except ProgrammingError as e:
        # The exception is handled and saved in the error variable.
        error = e
    assert error is not None
    assert error.args[0] == expected_message
    assert str(error) == expected_message

# Generated at 2022-06-24 01:10:07.484066
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError) as exc:
        raise ProgrammingError("This is a test")

    exc.match("This is a test")



# Generated at 2022-06-24 01:10:12.696827
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError()
    with pytest.raises(ProgrammingError):
        ProgrammingError("This is supposed to break!")


# Generated at 2022-06-24 01:10:18.620639
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.

    :return: ``None``
    """
    with pytest.raises(ProgrammingError) as error:
        raise ProgrammingError("Something is wrong with the code")

    assert error.value.args == ("Something is wrong with the code",)


# Generated at 2022-06-24 01:10:22.909361
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("message")
        assert False, "ProgrammingError is not able to handle a message passed to the constructor"
    except TypeError:
        pass

# Generated at 2022-06-24 01:10:24.413580
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("This is a test message")
    assert e.args[0] == "This is a test message"

# Generated at 2022-06-24 01:10:25.725785
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("This is a test."):
        assert False


# Generated at 2022-06-24 01:10:26.841525
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:10:29.148114
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-24 01:10:35.154469
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test failed")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Test failed"
    ProgrammingError.passert(True, "Test failed")
    ProgrammingError.passert(True, "")
    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:10:37.970044
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected_msg = "Test message"
    try:
        raise ProgrammingError(expected_msg)
    except ProgrammingError as e:
        assert str(e) == expected_msg, "Unexpected default message for ProgrammingError"


# Generated at 2022-06-24 01:10:41.221568
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "")
        ProgrammingError.passert(True, None)
        ProgrammingError.passert(False, "")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise ValueError()

# Generated at 2022-06-24 01:10:46.586916
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is the error message!")
    assert error.args == ("This is the error message!",)
    assert isinstance(error.args, tuple)
    assert str(error) == "This is the error message!"


# Generated at 2022-06-24 01:10:51.361669
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for :py:class:`ProgrammingError` constructor and :py:meth:`ProgrammingError.passert`.
    """
    ProgrammingError.passert(True, None)

    try:
        ProgrammingError.passert(False, "This is a test error")
    except ProgrammingError as e:
        assert e.args[0] == "This is a test error"

# Generated at 2022-06-24 01:10:54.686875
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something is wrong")
    except ProgrammingError as e:
        assert str(e) == "Something is wrong"


# Generated at 2022-06-24 01:10:56.139744
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "message")
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:11:00.591031
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Some message")
    except ProgrammingError as e:
        assert e.args[0] == "Some message"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:11:01.990288
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    passert = ProgrammingError.passert
    assert ProgrammingError
    assert passert

# Generated at 2022-06-24 01:11:05.620545
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "ProgrammingError does not work")
        raise AssertionError("ProgrammingError does not work")
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)
        assert str(err) == "ProgrammingError does not work"

# Generated at 2022-06-24 01:11:08.720956
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Expectation to be fulfilled
        ProgrammingError.passert(True, "test")
        # Raise error on unfulfilled expectation
        ProgrammingError.passert(False, "test")
        assert False, "ProgrammingError not raised as expected"
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:11:14.774513
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError.passert(False, "Foo")
    except ProgrammingError as e:
        assert "Foo" == str(e)

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)

# Generated at 2022-06-24 01:11:18.681215
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def _raiser():
        raise ProgrammingError("Raised by test")

    try:
        _raiser()
        assert False
    except ProgrammingError as e:
        assert str(e) == "Raised by test"


# Generated at 2022-06-24 01:11:20.394396
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("Something is wrong")


# Unit tests for function ProgrammingError.passert

# Generated at 2022-06-24 01:11:28.610738
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError(message="This is a message.")
    except ProgrammingError as e:
        assert str(e) == "This is a message."
    try:
        ProgrammingError(message=None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError(message="This is a message.", other="This is other.")
    except ProgrammingError as e:
        assert str(e) == "This is a message."


# Generated at 2022-06-24 01:11:30.228930
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:11:32.397446
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        assert True


# Generated at 2022-06-24 01:11:36.422740
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        with ProgrammingError.passert(condition = False, message = "Testing"):
            pass
    except ProgrammingError as e:
        assert e.args[0] == "Testing"

# Generated at 2022-06-24 01:11:48.140243
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # This should pass
    try:
        ProgrammingError.passert(False, "Expected message")
    except ProgrammingError as e:
        assert e.args[0] == "Expected message"
    except Exception:
        assert False, "This is not the right exception for false condition and filled message"
    else:
        assert False, "No exception raised for false condition and filled message"

    # This should pass
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    except Exception:
        assert False, "This is not the right exception for false condition and no message"
    else:
        assert False, "No exception raised for false condition and no message"

    # This should pass
   

# Generated at 2022-06-24 01:11:52.356147
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Test programming error raised")
    # No exception should be raised for this assertion
    ProgrammingError.passert(True, "Test programming error not raised")


# Generated at 2022-06-24 01:11:55.420250
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as ex:
        assert ex.args[0] == "Test"

    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert ex.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:11:57.933808
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as exc:
        ProgrammingError()

    assert exc.type is ProgrammingError
    assert str(exc.value) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:11:59.807914
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Test message"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert(str(e) == message)


# Generated at 2022-06-24 01:12:01.532818
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Initializes the class and makes sure that it behaves as expected."""
    error = ProgrammingError("test")
    assert error.args == ("test",)

# Generated at 2022-06-24 01:12:03.227893
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(1==0, "Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"


# Generated at 2022-06-24 01:12:05.039534
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err_message = "You have broken a very important contract"
    try:
        raise ProgrammingError(err_message)
    except ProgrammingError as e:
        assert str(e) == err_message

# Generated at 2022-06-24 01:12:08.579413
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    (msg, exc) = None, None
    try:
        raise ProgrammingError(msg)
    except Exception as e:
        exc = e
    assert exc is not None and exc.args[0] == msg



# Generated at 2022-06-24 01:12:11.062220
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("This is the message")
    assert err.args[0] == "This is the message"



# Generated at 2022-06-24 01:12:15.742139
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Forced error for testing.")
    except ProgrammingError as e:
        assert str(e) == "Forced error for testing."
    else:
        assert False, "ProgrammingError raised. Test should stop here."


if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-24 01:12:18.322267
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError expected!")

# Generated at 2022-06-24 01:12:21.279985
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "foo")
    except ProgrammingError as e:
        assert e.args == ("foo",)
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)

# Generated at 2022-06-24 01:12:24.659860
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False,"Expected error"):
        pass

# Generated at 2022-06-24 01:12:26.486800
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        pass


# Generated at 2022-06-24 01:12:30.013235
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert type(e) == ProgrammingError


# Generated at 2022-06-24 01:12:34.589602
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as err:
        assert err.__str__() == "This is a test"
    else:
        assert False, "Teste failed"



# Generated at 2022-06-24 01:12:37.532711
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc = ProgrammingError()
    assert(isinstance(exc, Exception))
    assert(str(exc) == "Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-24 01:12:45.836937
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message=None)
        assert False, "We should be raising an exception here!"
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(condition=False, message="This is the message.")
        assert False, "We should be raising an exception here!"
    except ProgrammingError as exception:
        assert exception.args[0] == "This is the message."

    ProgrammingError.passert(condition=True, message=None)

# Generated at 2022-06-24 01:12:49.560734
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test message.")
    except ProgrammingError as e:
        assert str(e) == "This is a test message."


# Generated at 2022-06-24 01:12:53.201435
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-24 01:12:54.992063
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "Hello, world!")

# Generated at 2022-06-24 01:12:59.426689
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raise_warnings(record=True) as raised_warnings:
        ProgrammingError.passert(False, "TEST")
        assert "TEST" == raised_warnings[0].message.args[0]

# Generated at 2022-06-24 01:13:01.151990
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as e:
        assert e.args == ("Message",)

# Generated at 2022-06-24 01:13:03.559283
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, None)
    try:
        ProgrammingError.passert(False, "Error")
        assert False, "Expected ProgrammingError not thrown"
    except ProgrammingError as e:
        assert str(e) == "Error"

# Generated at 2022-06-24 01:13:07.349643
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Negative test for the ProgrammingError class")
    except ProgrammingError as ex:
        assert ex.args[0] == "Negative test for the ProgrammingError class"
    except:
        raise AssertionError("Unable to raise a ProgrammingError as expected")

# Generated at 2022-06-24 01:13:10.992697
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Expected exception not raised"

# Generated at 2022-06-24 01:13:12.784876
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as error:
        assert error.args[0] == "Test"


# Generated at 2022-06-24 01:13:16.824885
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Error message")
    except ProgrammingError as exc:
        assert str(exc) == "Error message"

# Unit tests for classmethod ProgrammingError.passert

# Generated at 2022-06-24 01:13:19.445314
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-24 01:13:23.254600
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "Test")

    try:
        ProgrammingError.passert(False, None)
        raise AssertionError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:13:24.745132
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test"):
        pass

# Unit tests for passert (static method) of class ProgrammingError

# Generated at 2022-06-24 01:13:29.064213
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
        raise Exception("Bad exception raised.")
    except ProgrammingError as e:
        assert str(e) == "test", "Bad exception raised."


# Generated at 2022-06-24 01:13:31.603454
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests constructor of the class :py:class:`ProgrammingError`."""
    err = ProgrammingError("Testing")
    assert str(err) == "Testing"



# Generated at 2022-06-24 01:13:38.634405
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from random import randint
    from tpv.exceptions import ProgrammingError
    success = 0
    for _ in range(50):
        condition = randint(0, 1)
        message = str(randint(0,99999999))
        try:
            ProgrammingError.passert(condition, message)
        except ProgrammingError as raised_error:
            if condition:
                raise Exception("ProgrammingError was raised although condition == True")
            else:
                success += 1
                assert raised_error.__str__() == message
    assert success == 50


# Generated at 2022-06-24 01:13:43.302680
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as exc:
        assert str(exc) == "Test message"


# Generated at 2022-06-24 01:13:50.542234
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "The test should fail")
    try:
        ProgrammingError.passert(False, "The test should fail")
    except ProgrammingError as e:
        assert str(e) == "The test should fail"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    ProgrammingError.passert(True, None)

# Generated at 2022-06-24 01:13:52.470057
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    except:
        assert False


# Generated at 2022-06-24 01:13:55.956678
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(Exception, match="Broken coherence. Check your code against domain logic to fix it."):
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-24 01:13:59.543798
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Something wrong happened in the domain logic!"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert e.args[0] == message


# Generated at 2022-06-24 01:14:08.396684
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    ProgrammingError.passert(True, "This is a test")
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:14:10.453990
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-24 01:14:16.611897
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "You should not see this.")
    except ProgrammingError as e:
        assert e.args[0] == "You should not see this."
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as e:
        assert e.args[0] == ""
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:14:19.326660
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as e:
        assert isinstance(e, Exception)
        assert e.args[0] == "Some message"



# Generated at 2022-06-24 01:14:22.360139
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "The condition is False.")
        assert False, "Expect an exception."
    except ProgrammingError:
        pass  # This is the expected behavior.

# Generated at 2022-06-24 01:14:25.326035
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("a message")
    except ProgrammingError as error:
        assert error.args == ("a message", )
        

# Generated at 2022-06-24 01:14:28.692778
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "This is a test"
    try:
        raise ProgrammingError(msg)
    except Exception as err:
        assert err.args[0] == msg

# Generated at 2022-06-24 01:14:32.282820
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError("")

# Generated at 2022-06-24 01:14:36.849330
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Expect an error.")
    except ProgrammingError:
        # Expected case
        return
    raise RuntimeError("ProgrammingError has failed unit test.")

# Generated at 2022-06-24 01:14:38.675572
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:14:41.835055
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Some message")
    except ProgrammingError as e:
        assert e.args == ("Some message",)
    else:
        assert False, "Expected ProgrammingError exception"

# Generated at 2022-06-24 01:14:51.298690
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=unused-argument
    def programming_error_callable(a_callable: callable, a_bool: bool, a_str: str):
        return ProgrammingError.passert(a_bool, a_str)
    # pylint: enable=unused-argument
    programming_error_callable(lambda: 1, True, "")
    try:
        programming_error_callable(None, None, "")
        assert False
    except ProgrammingError:
        assert True
    try:
        programming_error_callable(None, False, "")
        assert False
    except ProgrammingError:
        assert True

# Generated at 2022-06-24 01:14:52.310805
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("Something is not right")

# Generated at 2022-06-24 01:14:55.596229
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    assert "Broken coherence. Check your code against domain logic to fix it." in str(exception)


# Generated at 2022-06-24 01:14:56.758471
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is just a test")

# Generated at 2022-06-24 01:15:03.281785
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as pe:
        assert pe.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    try:
        raise ProgrammingError("custom message")
    except ProgrammingError as pe:
        assert pe.args[0] == "custom message"


# Generated at 2022-06-24 01:15:07.832907
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` class.
    """
    try:
        raise ProgrammingError("an_error")
    except ProgrammingError as e:
        assert e.args[0] == "an_error"

# Generated at 2022-06-24 01:15:10.119948
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        raise ProgrammingError("test")

# Generated at 2022-06-24 01:15:14.141723
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except Exception as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-24 01:15:16.696219
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert type(e) is ProgrammingError
        assert e.args == ()


# Generated at 2022-06-24 01:15:18.906784
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pyassert import assert_that

    assert_that(str(ProgrammingError("Abc"))).is_equal_to("Abc")


# Generated at 2022-06-24 01:15:22.406785
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Foo")
    except ProgrammingError as e:
        assert str(e) == "Foo"

# Generated at 2022-06-24 01:15:23.866356
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("this is a test message")
    except ProgrammingError as e:
        assert e.args[0] == "this is a test message"

# Generated at 2022-06-24 01:15:24.657634
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="Unit test");

# Generated at 2022-06-24 01:15:26.990732
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as ex:
        assert str(ex) == "Test"


# Generated at 2022-06-24 01:15:29.331248
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test error")
    except ProgrammingError as err:
        assert str(err) == "test error"


# Generated at 2022-06-24 01:15:31.183888
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.errors import ProgrammingError
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError exception does not raise."


# Generated at 2022-06-24 01:15:40.235448
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    :func:`ProgrammingError.__init__()`
    """

    try:
        ProgrammingError.passert(False, "A message")
    except ProgrammingError as exception:
        assert str(exception) == "A message"
    else:
        raise AssertionError("ProgrammingError expected")

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as exception:
        assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("ProgrammingError expected")

    ProgrammingError.passert(True, None)

# Generated at 2022-06-24 01:15:45.617918
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert "This is a test" == e.args[0]


# Generated at 2022-06-24 01:15:50.773388
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as pe:
        assert(str(pe) == "Broken coherence. Check your code against domain logic to fix it.")


# Generated at 2022-06-24 01:15:59.608839
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from inspect import getfullargspec

    # Check that the constructor has no arguments
    assert (getfullargspec(ProgrammingError.__init__).args ==
            ["self", "args", "kwargs"])

    # Check that the constructor raises the exception with the given message
    with ProgrammingError.passert(False, "test"):
        pass

    # Check that the constructor has no arguments
    assert (getfullargspec(ProgrammingError.passert).args ==
            ["cls", "condition", "message"])

# Generated at 2022-06-24 01:16:03.013045
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    :py:class:`ProgrammingError` must be defined.
    """
    error = ProgrammingError("")  # type: ProgrammingError
    assert error is not None


# Generated at 2022-06-24 01:16:07.150561
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == 'Broken coherence. Check your code against domain logic to fix it.'


# Generated at 2022-06-24 01:16:09.634303
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    msg = "A message for this error..."
    # Act
    try:
        raise ProgrammingError(msg)
    # Assert
    except ProgrammingError as e:
        assert e.args[0] == msg


# Generated at 2022-06-24 01:16:13.847080
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Check your code against domain logic to fix it")
        raise AssertionError("An exception was expected")
    except ProgrammingError as ex:
        assert ex.args[0] == "Check your code against domain logic to fix it"


# Generated at 2022-06-24 01:16:20.049547
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    with ProgrammingError.passert(True, "Hello true"):
        pass

    try:
        with ProgrammingError.passert(False, "Hello false"):
            pass
    except ProgrammingError as ex:
        assert str(ex) == "Hello false"
        return True

    assert False

# Generated at 2022-06-24 01:16:26.208259
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit testing for class :py:class:`ProgrammingError`."""

    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as exception:
        if str(exception) != "Error message":
            raise Exception("Unit test for class ProgrammingError failed. It should raise the given error message.")


# Generated at 2022-06-24 01:16:31.991339
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing...")
    except ProgrammingError:
        print("pass")
    else:
        raise AssertionError("ProgrammingError not raised")

# Generated at 2022-06-24 01:16:41.031763
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.exceptions import ProgrammingError

    try:
        # Run method with a wrong condition
        ProgrammingError.passert(False, "Your condition is wrong")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError.passert with wrong condition did not raise an exception.")
    with raises(ProgrammingError) as ex:
        ProgrammingError.passert(False, None)
    assert ex.value.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:16:44.491449
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyTypeChecker
    exception = ProgrammingError(None)


# Generated at 2022-06-24 01:16:48.194567
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        print(f"This line is expected to be printed, because an exception is expected. Exception: {e}")
    else:
        print("This line should not be printed")


# Generated at 2022-06-24 01:16:51.198394
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Ensures the correct initialization of the class.
    """
    try:
        raise ProgrammingError("TEST")
    except ProgrammingError as error:
        assert error.args[0] == "TEST"


# Generated at 2022-06-24 01:16:58.689136
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with assert_raises(ProgrammingError) as cm:
        ProgrammingError()
    assert_true("Broken coherence. Check your code against domain logic to fix it." in str(cm.exception))

    with assert_raises(ProgrammingError) as cm:
        ProgrammingError("This is a message.")
    assert_true("This is a message." in str(cm.exception))


# Generated at 2022-06-24 01:17:00.224660
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Test message")
    assert error.args == ("Test message",)
    assert str(error) == "Test message"


# Generated at 2022-06-24 01:17:04.215708
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "fail")
        assert False, "We should never be here."
    except ProgrammingError as e:
        assert str(e) == "fail"

# Generated at 2022-06-24 01:17:08.530633
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Programming error")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Failed ProgrammingError exception constructor test")


# Generated at 2022-06-24 01:17:10.898852
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test error")
    except ProgrammingError as error:
        assert str(error) == "This is a test error"


# Generated at 2022-06-24 01:17:17.509057
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    print("Testing ProgrammingError...")
    try:
        ProgrammingError()
    except Exception as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    # No exception raised, so we accept it.
    print("Tests passed.")


# Unit test of method passert

# Generated at 2022-06-24 01:17:22.655912
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class SomeProgrammingError(ProgrammingError):
        pass

    message = "Broken coherence. Check your code against domain logic to fix it."

    def assertion():
        return SomeProgrammingError.passert(False, message)

    try:
        assertion()
    except SomeProgrammingError as e:
        assert e.args[0] == message
    else:
        raise AssertionError("Error not raised")

# Generated at 2022-06-24 01:17:23.396849
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("a message")

# Generated at 2022-06-24 01:17:25.390381
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This message.")
    except ProgrammingError as e:
        assert "This message." in str(e)


# Generated at 2022-06-24 01:17:30.483200
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as exception:
        assert str(exception) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:17:35.206853
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def _test():
        raise ProgrammingError('Test')
    try:
        _test()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError not raised when it should")


# Generated at 2022-06-24 01:17:36.899357
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Something broke."):
        pass

# Generated at 2022-06-24 01:17:40.033587
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "Assertion passed")
    assert "Assertion passed" in str(ProgrammingError.passert(False, "Assertion passed"))

# Generated at 2022-06-24 01:17:42.902604
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "This is a message") as context:
        pass # Do nothing
    assert str(context.exception) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:17:45.941808
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        assert False, "An exception was expected but not raised"


# Generated at 2022-06-24 01:17:49.917449
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:17:58.137772
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "Condition is not met")
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError did not raise an exception while one was expected."
    try:
        ProgrammingError.passert(True, "Condition is not met")
    except ProgrammingError:
        assert False, "ProgrammingError raised an exception while one was not expected."

# Generated at 2022-06-24 01:18:02.191497
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("My message")
    except ProgrammingError as e:
        assert e.args[0] == "My message"



# Generated at 2022-06-24 01:18:06.853865
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    exception = ProgrammingError()

    # THEN
    assert exception.args == ("Broken coherence. Check your code against domain logic to fix it.",)



# Generated at 2022-06-24 01:18:11.523628
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("condition not met")
    except ProgrammingError as pgm_error:
        assert pgm_error.args[0] == "condition not met"

