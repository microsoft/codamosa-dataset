

# Generated at 2022-06-24 01:08:08.654516
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the exception.
    """
    error = ProgrammingError("TestMessage")
    assert error.args == ("TestMessage",)
    assert str(error) == "TestMessage"


# Generated at 2022-06-24 01:08:15.810433
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` class.
    """
    from unittest.mock import patch

    # We mock the sys.exit method to avoid an actual system exit
    with patch('sys.exit'):
        ProgrammingError.passert(True, "Our message")
        ProgrammingError.passert(False, "Our message")

# Generated at 2022-06-24 01:08:20.936243
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="Test error")
    except ProgrammingError as e:
        assert str(e) == "Test error"
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:08:23.231429
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error message")
    except ProgrammingError as e:
        assert str(e) == "Some error message"

# Unit tests for method ProgrammingError.passert

# Generated at 2022-06-24 01:08:30.280734
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    print("Testing ProgrammingError...")
    try:
        ProgrammingError.passert(True, "This is not bad")
    except ProgrammingError:
        raise Exception("It should NOT have thrown an exception")

    try:
        ProgrammingError.passert(False, "This is bad")
        raise Exception("It should have thrown an exception")
    except ProgrammingError:
        print("Test OK.")

# Test for class ProgrammingError
test_ProgrammingError()

# Generated at 2022-06-24 01:08:31.500086
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError



# Generated at 2022-06-24 01:08:36.598532
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error message")
    except ProgrammingError as err:
        assert str(err) == "Some error message"


# Generated at 2022-06-24 01:08:37.966608
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ex = ProgrammingError("Test message.")
    assert ex.args == ("Test message.",)

# Generated at 2022-06-24 01:08:40.423295
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Always failing test.")
    ProgrammingError.passert(True, "Always successful assertion test.")

# Generated at 2022-06-24 01:08:44.384568
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("dummy")
    except ProgrammingError as e:
        assert e.args == ("dummy",)


# Generated at 2022-06-24 01:08:50.028749
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): # type: ignore
    """Tests the constructor of the class :py:class:`ProgrammingError`."""
    mex = "This is an error message"
    error = ProgrammingError(mex)
    assert error.args[0] == mex


# Generated at 2022-06-24 01:08:52.024721
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("...")
    except ProgrammingError as _:
        pass


# Generated at 2022-06-24 01:08:56.713837
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Tests always pass"):
        pass

    with ProgrammingError.passert(False, "This test fails"):
        pass

# Generated at 2022-06-24 01:09:03.264424
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    from pyclaim.domain.assertions.programming_error import ProgrammingError

    try:
        ProgrammingError.passert(False, "Expected message.")
        assert False
    except Exception as error:
        assert isinstance(error, ProgrammingError)
        assert str(error) == "Expected message."
    ProgrammingError.passert(True, "Expected message.")


# Generated at 2022-06-24 01:09:06.221971
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Condition was not met")

# Generated at 2022-06-24 01:09:12.642474
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Just a test")
    except ProgrammingError as e:
        assert False
    try:
        ProgrammingError.passert(False, "Just a test")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Just a test"
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:09:17.374016
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-24 01:09:20.447122
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My Message")
    except ProgrammingError as e:
        assert str(e) == "My Message"


# Generated at 2022-06-24 01:09:27.246087
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    from hamcrest import assert_that, calling, is_, raises

    assert_that(calling(ProgrammingError.passert).with_args(1 == 1, None), is_('None'), "No error expected")
    assert_that(calling(ProgrammingError.passert).with_args(1 == 2, None), raises(ProgrammingError),
                "Error expected")

# Generated at 2022-06-24 01:09:28.715030
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        ProgrammingError()
    with raises(ProgrammingError):
        ProgrammingError("custom message")


# Generated at 2022-06-24 01:09:31.843019
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # We expect a ProgrammingError to be raised in case of broken coherence.
    ProgrammingError.passert(False, "Broken coherence")

# Generated at 2022-06-24 01:09:37.418357
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as ex:
        ProgrammingError.passert(False, "Testing the error...")
    assert ex.value.args[0] == "Testing the error..."


# Generated at 2022-06-24 01:09:40.530034
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Verifies the correct functionality of the constructor.
    """

    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "abc")

    try:
        ProgrammingError.passert(True, "abc")
    except ProgrammingError:
        pytest.fail("ProgrammingError should not have been raised for condition True")


# Generated at 2022-06-24 01:09:42.368892
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Something is wrong!")

# Generated at 2022-06-24 01:09:45.000030
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("This is just a test")
    assert e.args[0] == "This is just a test"



# Generated at 2022-06-24 01:09:52.674201
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    # Check if it works with a message
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as exc:
        assert exc.args[0] == "Test message"

    # Check if it works without a message
    try:
        raise ProgrammingError()
    except ProgrammingError as exc:
        assert exc.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:09:55.336754
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    try:
        raise ProgrammingError("Runtime error.")
    except ProgrammingError as e:
        assert str(e) == "Runtime error."


# Generated at 2022-06-24 01:09:58.702343
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error.__str__() == "Broken coherence. Check your code against domain logic to fix it."
    error = ProgrammingError(message="Any arbitrary message.")
    assert error.__str__() == "Any arbitrary message."


# Generated at 2022-06-24 01:10:01.659672
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    expected_message = "This is an expected message"
    expected_exception = raises(ProgrammingError, lambda: ProgrammingError.passert(False, expected_message))
    assert expected_message in str(expected_exception.value)



# Generated at 2022-06-24 01:10:04.494858
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()


# Generated at 2022-06-24 01:10:06.726259
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("This is a message.")
    assert e.args[0] == "This is a message."



# Generated at 2022-06-24 01:10:07.885730
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:10:16.835689
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.
    """

    # noinspection PyUnusedLocal
    def check_coherence(condition, expected_error_message):
        actual_error_message: Optional[str] = None
        try:
            # noinspection PyTypeChecker
            ProgrammingError.passert(condition, expected_error_message)
        except ProgrammingError as e:
            actual_error_message = str(e)
        assert actual_error_message == expected_error_message, \
            "Error message should be '%s' but it is '%s'" % (expected_error_message, actual_error_message)

    check_coherence(True, None)
    check_coherence(False, "Broken coherence. Check your code against domain logic to fix it.")
   

# Generated at 2022-06-24 01:10:19.397181
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My message")
    except ProgrammingError as e:
        assert e.__str__() == "My message"
    else:
        assert False, "Should raise an exception"


# Generated at 2022-06-24 01:10:22.379356
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "This is a dummy test"
    error = ProgrammingError(message)
    assert error.args == (message,)

# Generated at 2022-06-24 01:10:26.299564
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Always true"):
        pass

    try:
        with ProgrammingError.passert(False, "Always false"):
            pass
    except ProgrammingError as e:
        assert e.args[0] == "Always false"
    else:
        raise AssertionError("The expectation was not raised.")

# Generated at 2022-06-24 01:10:28.549058
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError) as excinfo:
        raise ProgrammingError("This is an error message.")
    assert str(excinfo.value) == "This is an error message."


# Generated at 2022-06-24 01:10:31.436190
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as error:
        assert isinstance(error, ProgrammingError)
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("Wrong implementation.")


# Generated at 2022-06-24 01:10:34.905703
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Error message")
    except ProgrammingError as e:
        assert(str(e) == "Error message")

    try:
        ProgrammingError("")
    except ProgrammingError as e:
        assert(str(e) == "")


# Generated at 2022-06-24 01:10:37.206050
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "It must not fail if the condition is met")
    except ProgrammingError:
        assert False

    try:
        ProgrammingError.passert(False, "It must fail if the condition is not met")
    except ProgrammingError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 01:10:42.450792
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error")
    except ProgrammingError as err:
        assert str(err) == "Programming error"



# Generated at 2022-06-24 01:10:48.045066
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    caught_exception = None
    try:
        raise ProgrammingError("For unit testing only string parameter.")
    except ProgrammingError as exception:
        caught_exception = exception

    assert caught_exception
    assert caught_exception.args[0] == "For unit testing only string parameter."



# Generated at 2022-06-24 01:10:53.077822
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:10:54.834217
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert e.message == "test"


# Generated at 2022-06-24 01:10:59.097462
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the constructor of class ProgrammingError
    """
    ex = ProgrammingError()

    assert isinstance(ex, ProgrammingError)
    assert isinstance(ex, Exception)
    assert ex.args == ("Broken coherence. Check your code against domain logic to fix it.", )

    assert ProgrammingError.passert(True, "A message") is None
    assert ProgrammingError.passert(False, "A message") is None

# Generated at 2022-06-24 01:11:01.851152
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError
    """
    try:
        raise ProgrammingError("Test")
    except Exception as e:
        assert isinstance(e, ProgrammingError)



# Generated at 2022-06-24 01:11:07.137270
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as error_info:
        ProgrammingError.passert(condition=True, message=None)
    assert str(error_info.value) == "Broken coherence. Check your code against domain logic to fix it."
    with pytest.raises(ProgrammingError) as error_info:
        ProgrammingError.passert(condition=False, message="This is a message")
    assert str(error_info.value) == "This is a message"

# Generated at 2022-06-24 01:11:12.897367
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as error:
        assert error.args == ("Error message", )
    else:
        assert False, "Unexpected error. ProgrammingError constructor has failed."

# Generated at 2022-06-24 01:11:15.749342
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(message="Test")


# Generated at 2022-06-24 01:11:18.540790
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a testing error!")
    except ProgrammingError as e:
        assert e.args[0] == "This is a testing error!"


# Generated at 2022-06-24 01:11:21.291588
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.errors.error import ProgrammingError

    with raises(ProgrammingError):
        ProgrammingError.passert(True, "Error")
        ProgrammingError.passert(False, "Error")

# Generated at 2022-06-24 01:11:26.223460
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Instantiates a ProgrammingError exception.
    """
    exc = ProgrammingError("Test")

    assert(str(exc) == "Test")

# Generated at 2022-06-24 01:11:29.461369
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "")
    try:
        ProgrammingError.passert(False, "")
        raise AssertionError("Failed to raise ProgrammingError")
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:11:35.452400
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)
    ProgrammingError.passert(True, "OK")
    try:
        ProgrammingError.passert(False, "Bad")
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)

# Generated at 2022-06-24 01:11:38.979369
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Unit test")
        assert(False)
    except ProgrammingError:
        pass



# Generated at 2022-06-24 01:11:41.012757
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("foobar")
    assert error.args == ("foobar",)

# Generated at 2022-06-24 01:11:42.636159
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, None)


# Generated at 2022-06-24 01:11:44.999255
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert e.args is None


# Generated at 2022-06-24 01:11:48.112413
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # These should not raise an exception
    ProgrammingError()
    ProgrammingError("Some message")



# Generated at 2022-06-24 01:11:55.754893
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of class :py:class:`ProgrammingError`.

    The following cases are tested:
    
    * Raises a :py:class:`ProgrammingError` if the condition is ``False``.
    """
    
    # Test case: Raises a ProgrammingError if the condition is False
    try:
        ProgrammingError.passert(False, message="Expected error message.")
    except ProgrammingError as ex:
        assert str(ex) == "Expected error message."
    else:
        raise AssertionError("Expected ProgrammingError not raised.")

if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-24 01:12:06.020647
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for class :py:class:`ProgrammingError`.
    """

    # Test for constructor of class ProgrammingError
    def test_constructor(message: str) -> None:
        """
        Tests the constructor of class :py:class:`ProgrammingError`.
        """
        # Instance the exception
        exception = ProgrammingError(message)
        assert exception.args[0] == message

    test_constructor("This is a test of ProgrammingError exception.")

    # Test for passert method of class ProgrammingError
    def test_passert() -> None:
        """
        Tests the :py:meth:`~ProgrammingError.passert()` method of class :py:class:`ProgrammingError`.
        """
        # Tests
        ProgrammingError.passert(True, "This is a test of ProgrammingError exception.")
       

# Generated at 2022-06-24 01:12:07.805083
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test case for constructor of class ProgrammingError."""
    error_message = "check your code"
    try:
        raise ProgrammingError(error_message)
    except ProgrammingError as e:
        assert error_message == str(e)


# Generated at 2022-06-24 01:12:08.983967
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message for constructor")
    except ProgrammingError as e:
        assert e.args[0] == "Test message for constructor"


# Generated at 2022-06-24 01:12:11.876085
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Must be strongly consistent with domain logic")
    except ProgrammingError as e:
        assert str(e) == "Must be strongly consistent with domain logic"

# Generated at 2022-06-24 01:12:21.080226
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the :py:class:`ProgrammingError` class.
    """

    # Assert that a ProgrammingError is raised for a broken assertion
    try:
        ProgrammingError.passert(False, "Testing")
        raise Exception("ProgrammingError was not raised.")
    except ProgrammingError as error:
        assert error.args[0] == "Testing"
    finally:
        try:
            # Assert that no ProgrammingError is raised for a fulfilled assertion
            ProgrammingError.passert(True, "Testing")
        except ProgrammingError:
            raise Exception("ProgrammingError was raised.")

# Generated at 2022-06-24 01:12:26.050753
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        err = ProgrammingError()
        raise Exception("ProgrammingError exception constructor did not raise!")
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)
        assert isinstance(err, Exception)


# Generated at 2022-06-24 01:12:30.735100
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(1 == 3, "Simulated error message")
    except ProgrammingError as error:
        assert error.args == ("Simulated error message", )
    ProgrammingError.passert(1 == 1, "Simulated error message")

# Generated at 2022-06-24 01:12:34.403475
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert e.args == ("This is a test.",), "ProgrammingError constructor didn't work correctly."


# Generated at 2022-06-24 01:12:35.669379
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except Exception as ex:
        print(ex)

# Generated at 2022-06-24 01:12:37.230173
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except:
        pass

# Generated at 2022-06-24 01:12:38.476229
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:12:42.554432
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Hello world!")

    assert isinstance(error, ProgrammingError)
    assert isinstance(error, Exception)
    assert error.__str__() == "Hello world!"


# Generated at 2022-06-24 01:12:48.394607
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit tests for class ProgrammingError."""
    # Test no raise
    ProgrammingError.passert(True, "Message")
    # Test raising
    try:
        ProgrammingError.passert(False, "Message")
        assert False, "ProgrammingError was not raised."
    except ProgrammingError as err:
        assert str(err) == "Message", "Unexpected message for raised ProgrammingError."

# Generated at 2022-06-24 01:12:50.419395
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except:
        assert True
    else:
        assert False, "Expected exception was not raised"


# Generated at 2022-06-24 01:12:56.463281
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Run tests for ProgrammingError class. """
    import unittest

    class ProgrammingErrorTests(unittest.TestCase):
        """ Tests for ProgrammingError class. """

        def test_creation(self):
            """ Test that you can instantiate an error. """

# Generated at 2022-06-24 01:13:00.653933
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Check this statement against the API documentation.")
        assert False, "Should not reach this line"
    except ProgrammingError as ex:
        assert str(ex) == "Check this statement against the API documentation."


# Unit tests for the condition is true

# Generated at 2022-06-24 01:13:02.703613
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is just a message")
    except ProgrammingError as e:
        assert e.args[0] == "This is just a message"


# Generated at 2022-06-24 01:13:04.871910
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError as e:
        pytest.fail(f"The test has failed. Exception message: {str(e)}")



# Generated at 2022-06-24 01:13:13.154670
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Testing that error does not rise in case of True
        ProgrammingError.passert(True, "Useless message for the case that condition is True.")
        # Testing that error does rise with an error message in case of False
        ProgrammingError.passert(False, "Condition is False and message is present (Error should rise).")
    except ProgrammingError as e:
        pass
    except Exception as e:
        raise e
    # Testing that error rise without error message in case of False
    ProgrammingError.passert(False, None)

__all__.append("test_ProgrammingError")

# Generated at 2022-06-24 01:13:17.067262
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of class ProgrammingError"""
    # When
    error = ProgrammingError("Some message")

    # Then
    assert error.args == ("Some message",)

# Generated at 2022-06-24 01:13:20.741349
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a mock")
    except ProgrammingError:
        pass
    else:
        assert False, "Failed to raise a ProgrammingError"


# Generated at 2022-06-24 01:13:23.211016
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError not raised")


# Generated at 2022-06-24 01:13:29.542965
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    succeeded = False
    try:
        ProgrammingError.passert(False, "Test message")
    except ProgrammingError:
        succeeded = True
    assert succeeded, "ProgrammingError exception has not been raised"
    succeeded = False
    try:
        ProgrammingError.passert(True, "Test message")
    except ProgrammingError:
        succeeded = True
    assert not succeeded, "ProgrammingError exception has been raised"

# Generated at 2022-06-24 01:13:33.429461
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    ProgrammingError.passert(False, "This should raise a ProgrammingError")


# Generated at 2022-06-24 01:13:34.755717
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError is ProgrammingError("test")



# Generated at 2022-06-24 01:13:36.058968
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        ProgrammingError("A programming error.")


# Generated at 2022-06-24 01:13:39.921629
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except Exception as e:
        assert type(e) is ProgrammingError
        assert str(e) == "Test"


# Generated at 2022-06-24 01:13:44.218260
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test message")
    except ProgrammingError as pe:
        assert str(pe) == "This is a test message"



# Generated at 2022-06-24 01:13:48.052509
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error!")
    except ProgrammingError as e:
        assert str(e) == "Programming error!"

# Generated at 2022-06-24 01:13:50.232473
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('Error')
    except Exception as exc:
        assert str(exc) == 'Error'


# Generated at 2022-06-24 01:13:53.110764
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="message")
        assert False, "Should have raised ProgrammingError"
    except ProgrammingError as e:
        assert e.args[0] == "message"


# Generated at 2022-06-24 01:13:55.214869
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        raise ProgrammingError("Test error")

# Generated at 2022-06-24 01:13:59.506511
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test error", "Test solution")
    except ProgrammingError as error:
        assert error.message == "Test error"
        assert error.solution == "Test solution"


# Generated at 2022-06-24 01:14:01.583449
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test error message")
    except ProgrammingError as error:
        assert error.args[0] == "Test error message"


# Generated at 2022-06-24 01:14:05.714320
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("a")


# Generated at 2022-06-24 01:14:09.965256
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        "Every ProgrammingError constructor raises an exception."

    try:
        ProgrammingError("")
    except ProgrammingError:
        pass
    else:
        "Every ProgrammingError constructor raises an exception."



# Generated at 2022-06-24 01:14:13.192778
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    "Provides unit test for class ProgrammingError"
    msg = "Testing..."
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as pe:
        assert str(pe) == msg



# Generated at 2022-06-24 01:14:15.838290
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("Nothing")

# Generated at 2022-06-24 01:14:18.275707
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    except Exception:
        assert False, "ProgrammingError expected"


# Generated at 2022-06-24 01:14:23.668696
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Invalid error message")
    except ProgrammingError as e:
        assert e.args is not None
        assert len(e.args) == 1
        assert e.args[0] == "Invalid error message"

# Generated at 2022-06-24 01:14:29.547072
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    if not __debug__:
        return  # pragma: no cover
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert e.__class__ == ProgrammingError
        assert str(e) == "This is a test"
    else:
        assert False  # pragma: no cover

# Test of method passert

# Generated at 2022-06-24 01:14:33.429801
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        raise ProgrammingError()

    with raises(ProgrammingError):
        raise ProgrammingError("This is a programming error.")


# Generated at 2022-06-24 01:14:36.849417
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as exception:
        ProgrammingError.passert(False, "foo")
    assert str(exception.value) == "foo"

# Generated at 2022-06-24 01:14:43.094004
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    with ProgrammingError.passert(False, "Testing ProgrammingError"):
        pass
    try:
        with ProgrammingError.passert(True, "Should not raise"):
            pass
    except ProgrammingError:
        raise AssertionError("ProgrammingError should not been raised")
    try:
        with ProgrammingError.passert(False, None):
            pass
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError should been raised")

# Generated at 2022-06-24 01:14:45.763365
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "The sky is blue"
    with raises(ProgrammingError, match=message):
        ProgrammingError.passert(False, message)
    ProgrammingError.passert(True, None)

# Generated at 2022-06-24 01:14:50.269726
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("asdkfjh")
    except ProgrammingError as e:
        assert e.args[0] == "asdkfjh"


# Generated at 2022-06-24 01:14:52.773450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    exc = ProgrammingError("Programming error!")
    assert str(exc) == "Programming error!"
    assert repr(exc) == "ProgrammingError('Programming error!')"


# Generated at 2022-06-24 01:14:57.623561
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError) as ex:
        ProgrammingError.passert(False, "Just a test")

    assert str(ex.value) == "Just a test"



# Generated at 2022-06-24 01:14:59.799614
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass # Everything is ok.

# Generated at 2022-06-24 01:15:00.832805
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    with pytest.raises(ProgrammingError):
        ProgrammingError("error")

# Generated at 2022-06-24 01:15:03.446043
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Error 1")
    try:
        raise ProgrammingError("Error 2")
    except ProgrammingError as e:
        assert "Error 2" in str(e)


# Generated at 2022-06-24 01:15:07.476834
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as _:
        pass
    except Exception as error:
        raise AssertionError("Unexpected exception occurred: {0}".format(error))


# Generated at 2022-06-24 01:15:12.133759
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("message")
    assert e.args == ("message",)
    assert str(e) == "message"

    e2 = ProgrammingError("message", "message2")
    assert e2.args == ("message", "message2")
    assert str(e2) == "message\nmessage2"



# Generated at 2022-06-24 01:15:14.189712
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as e:
        assert str(e) == "Message"

# Generated at 2022-06-24 01:15:17.549480
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError


# Generated at 2022-06-24 01:15:18.944092
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test"):
        assert False, "Broken coherence"

# Generated at 2022-06-24 01:15:22.405914
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error!")
    except ProgrammingError as e:
        assert str(e) == "Error!"


# Generated at 2022-06-24 01:15:25.617702
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): #pylint: disable=redefined-outer-name
    try:
        raise ProgrammingError("Test error message")
    except ProgrammingError as error:
        assert 'Test error message' in str(error)

# Generated at 2022-06-24 01:15:28.195077
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Foo")
    except ProgrammingError as e:
        assert e.args == ("Foo",)


# Generated at 2022-06-24 01:15:39.370037
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Performs unit test for the class :py:class:`ProgrammingError`.
    """
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Expected a condition.")

    try:
        ProgrammingError.passert(True, "Expected a condition.")
    except ProgrammingError:
        pytest.fail("Unexpected error")

    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        pytest.fail("Unexpected error")

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        return
    pytest.fail("Expected an error")


if __name__ == '__main__':
    pytest.main(["-v", __file__])

# Generated at 2022-06-24 01:15:45.243854
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "message"
    error = ProgrammingError(msg)
    assert str(error) == f"{ProgrammingError.__name__}:\n{msg}"

# Generated at 2022-06-24 01:15:51.355906
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError("ABC")
    except ProgrammingError as e:
        assert str(e) == "ABC"

    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:15:55.010811
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test case for :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "A message")
    except ProgrammingError as e:
        assert "A message" == str(e)
    # end try
# end func test_ProgrammingError

# Generated at 2022-06-24 01:15:58.715784
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "New message.")
    except ProgrammingError as ex:
        assert ex.args[0] == "New message."
    else:
        assert False

# Generated at 2022-06-24 01:16:03.487582
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # We don't know the message
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()

    # We know the message
    with pytest.raises(ProgrammingError) as ex:
        raise ProgrammingError("Something was wrong")
    assert str(ex.value) == "Something was wrong"


# Generated at 2022-06-24 01:16:07.191542
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('test_ProgrammingError')
    except ProgrammingError as e:
        assert(e.args[0] == 'test_ProgrammingError')


# Generated at 2022-06-24 01:16:09.412376
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(1 == 2, None)
    except ProgrammingError as error:
        print(error)
    else:
        print("ProgrammingError.passert succeeded.")

# Generated at 2022-06-24 01:16:14.970412
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as error:
        ProgrammingError.passert(str(error) == "This is an error", "The error message is not the expected")


# Generated at 2022-06-24 01:16:18.184570
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing ProgrammingError class")
    except ProgrammingError as exception:
        assert exception.message == "Testing ProgrammingError class"


# Generated at 2022-06-24 01:16:20.906232
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise  ProgrammingError("ciao")
    except ProgrammingError as err:
        assert err.args[0] == "ciao"

# Generated at 2022-06-24 01:16:25.328524
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is a programming error!")
        assert False
    except ProgrammingError as e:
        assert True
        assert e.args[0] == "This is a programming error!"


# Generated at 2022-06-24 01:16:27.441260
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My message")
    except ProgrammingError as e:
        assert e.args[0] == "My message"
    else:
        raise AssertionError("ProgrammingError constructor not working")


# Generated at 2022-06-24 01:16:32.811363
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Error message") as _:
        pass

    try:
        with ProgrammingError.passert(False, "Error message") as _:
            pass
    except ProgrammingError:
        return

    raise AssertionError("ProgrammingError.passert does not raise ProgrammingError when failed.")

# Generated at 2022-06-24 01:16:35.632551
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    except:
        pass


# Generated at 2022-06-24 01:16:39.056635
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Message to indicate that the code is broken.")
    except ProgrammingError as error:
        assert(error.args == ("Message to indicate that the code is broken.",))

    try:
        ProgrammingError.passert(True, "Message to indicate that the code is broken.")
    except ProgrammingError as error:
        assert(False)

# Generated at 2022-06-24 01:16:46.601751
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=missing-function-docstring, missing-class-docstring, no-self-use
    try:
        raise ProgrammingError("test")
    except ProgrammingError as ex:
        assert str(ex) == "test"

    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-24 01:16:51.410664
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    This test validates that the constructor of :py:class:`ProgrammingError` raises
    this exception as expected.
    """
    with ProgrammingError.passert(False, "Checking you!"):
        pass

# Generated at 2022-06-24 01:16:54.840069
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    try:
        ProgrammingError.passert(False, "my message")  # noqa
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "my message"
        return


# Test case for method ProgrammingError.passert()

# Generated at 2022-06-24 01:16:57.284828
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "I was expecting a False value")
    except ProgrammingError as err:
        assert "I was expecting a False value" == err.args[0]



# Generated at 2022-06-24 01:17:00.596751
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    except Exception as e:
        raise e
    else:
        assert False


# Generated at 2022-06-24 01:17:10.058393
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Error in domain logic detected.")  # pylint: disable=no-value-for-parameter
    except ProgrammingError as programming_error:
        assert programming_error.message == "Error in domain logic detected."
    with pytest.raises(ProgrammingError) as exception_info:
        ProgrammingError.passert(False)  # pylint: disable=no-value-for-parameter
    assert exception_info.value.message == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:17:14.834168
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert str(ProgrammingError) == "<class 'pypara.error.ProgrammingError'>"
    assert str(ProgrammingError()) == "Broken coherence. Check your code against domain logic to fix it."
    assert str(ProgrammingError("FOOBAR")) == "FOOBAR"


# Generated at 2022-06-24 01:17:20.078805
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Foo")
    except ProgrammingError as e:
        assert str(e) == "Foo"
        assert isinstance(e, Exception)
    else:
        assert False


# Generated at 2022-06-24 01:17:22.696382
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:17:24.344121
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My message")
    except ProgrammingError as e:
        assert str(e) == "My message"


# Generated at 2022-06-24 01:17:28.056134
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "message"):
        pass
    with ProgrammingError.passert(False, "message"):
        pass

# Generated at 2022-06-24 01:17:31.365562
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.

    :return: ``None``.
    """
    # pylint: disable=pointless-statement
    ProgrammingError("A message")



# Generated at 2022-06-24 01:17:39.223016
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Assert exception has not been raised
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        # TODO: get rid of this "fail" because we're testing for exception but it is considered an error to raise
        # one from a test case!
        pytest.fail()
    # Assert exception has been raised
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)

# Generated at 2022-06-24 01:17:43.962972
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the constructor of class :py:class:`ProgrammingError` works as expected.
    """
    ProgrammingError("Test")
    try:
        ProgrammingError.passert(False, "Test")
        assert False
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(True, "Test")
        pass
    except ProgrammingError:
        assert False

# Generated at 2022-06-24 01:17:45.817253
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert not e.args


# Generated at 2022-06-24 01:17:51.056462
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:17:52.624793
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    assert ProgrammingError("test")


# Generated at 2022-06-24 01:17:56.798451
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    with ProgrammingError as e:
        ProgrammingError.passert(True, "Fails." )

    with ProgrammingError as e:
        ProgrammingError.passert(False, "Fails." )

    with ProgrammingError as e:
        ProgrammingError.passert(False, None )

    with ProgrammingError as e:
        ProgrammingError.passert(True, None )

# Generated at 2022-06-24 01:18:01.726433
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False

# Generated at 2022-06-24 01:18:02.699525
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert "message" in str(ProgrammingError("message"))

# Generated at 2022-06-24 01:18:08.175007
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("This is a message")
    except ProgrammingError as exc:
        assert isinstance(exc.message, str)

# For unit test of the passert() method:
# pylint: disable=too-few-public-methods