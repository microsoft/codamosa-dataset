

# Generated at 2022-06-24 01:08:09.493202
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing")
    except ProgrammingError as error:
        assert str(error) == "Testing"

# Generated at 2022-06-24 01:08:14.457929
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
        assert False
    except ProgrammingError as e:
        assert str(e) == "test"

# Generated at 2022-06-24 01:08:22.976730
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.common.exceptions import ProgrammingError
    sut = ProgrammingError("A message")
    assert str(sut) == "A message"
    assert sut.args == ("A message",)
    sut = ProgrammingError()
    assert str(sut) == "Broken coherence. Check your code against domain logic to fix it."
    assert sut.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    with raises(ProgrammingError):
        raise ProgrammingError("An error")
    sut = ProgrammingError("An error")
    with raises(ProgrammingError):
        raise sut

# Generated at 2022-06-24 01:08:31.532213
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests class :py:class:`ProgrammingError`.
    """

    # Test constructor
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)
        assert str(e) == "test"

    # Test class method passert
    try:
        ProgrammingError.passert(True, "test")
    except ProgrammingError:
        raise AssertionError("ProgrammingError should not have raised")

# Test cases for module __init__.py

# Generated at 2022-06-24 01:08:37.203136
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert str(error) == "Broken coherence. Check your code against domain logic to fix it."
    error = ProgrammingError("We have a problem.")
    assert str(error) == "We have a problem."


# Generated at 2022-06-24 01:08:38.988521
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:08:40.720715
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("my message")
    assert error.args[0] == "my message"



# Generated at 2022-06-24 01:08:44.012597
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Anything")
    except ProgrammingError as error:
        assert error.args[0] == "Anything"
        return
    assert False, "ProgrammingError has not been instantiated"


# Generated at 2022-06-24 01:08:45.506353
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "TEST")

# Generated at 2022-06-24 01:08:48.575882
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc = ProgrammingError("Programming error message")
    assert exc.args == ("Programming error message",)


# Generated at 2022-06-24 01:08:50.478590
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:08:55.187188
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the :py:class:`ProgrammingError` class.

    :raises Exception: If the test fails.
    """
    try:
        raise ProgrammingError("Programming error detected!")
    except ProgrammingError as exception_raised:
        assert str(exception_raised) == "Programming error detected!"
    else:
        raise Exception("This exception should have been raised.")


# Generated at 2022-06-24 01:09:01.044002
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Some error message")
    except ProgrammingError as error:
        assert isinstance(error, Exception)
        assert error.args[0] == "Some error message"

    try:
        ProgrammingError.passert(False)
    except ProgrammingError as error:
        assert isinstance(error, Exception)
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:09:07.622446
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.common.exceptions import ProgrammingError as PE

    expected_message = "foo bar baz"
    with raises(PE) as actual_exception:
        PE.passert(condition=False, message=expected_message)

    assert expected_message == actual_exception.value.args[0]

# Generated at 2022-06-24 01:09:19.376115
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Executes a simple unit test for the :py:class:`ProgrammingError` constructor.

    :raises AssertionError: In case that the test does not pass.
    """
    from parameterized import parameterized

    from pypara.error import ProgrammingError

    @parameterized.expand([
        (False, None),
        (False, ""),
        (False, "a"),
        (True, None),
        (True, ""),
        (True, "a"),
    ])
    def _test(condition: bool, message: Optional[str]) -> None:
        if condition:
            try:
                ProgrammingError.passert(condition, message)
            except ProgrammingError as e:
                assert False, "The condition is met but it is raising an error."

# Generated at 2022-06-24 01:09:24.779304
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError()
    assert 'Broken coherence. Check your code against domain logic to fix it.' in str(excinfo.value)


# Generated at 2022-06-24 01:09:26.743034
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("hello")
    except ProgrammingError as e:
        assert e.args[0] == "hello"

# Generated at 2022-06-24 01:09:27.889197
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "")

# Generated at 2022-06-24 01:09:32.440827
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("exception in the test")  # pylint: disable=unused-variable
    except ProgrammingError as ex:
        assert str(ex) == "exception in the test"



# Generated at 2022-06-24 01:09:35.452886
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="Test")


# Generated at 2022-06-24 01:09:46.899614
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    error_message = "Broken coherence. Check your code against domain logic to fix it."
    # Act & Assert
    try:
        # Passing assertion
        ProgrammingError.passert(True, error_message)
    except ProgrammingError:
        assert False, "Expected no error!"
    try:
        # Failing assertion
        ProgrammingError.passert(False, error_message)
        assert False, "Expected an error!"
    except ProgrammingError as e:
        assert e.args[0] == error_message
    try:
        # Failing assertion without message
        ProgrammingError.passert(False, None)
        assert False, "Expected an error!"
    except ProgrammingError as e:
        assert e.args[0] == error_message

# Generated at 2022-06-24 01:09:52.821494
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class A:
        def __init__(self, x: bool) -> None:
            ProgrammingError.passert(x, "Message")

    err = None
    try:
        A(False)
    except ProgrammingError as exc:
        err = exc
    assert err is not None
    assert str(err) == "Broken coherence. Check your code against domain logic to fix it."
    A(True)

# Generated at 2022-06-24 01:09:55.493381
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Ooops! This is not expected to happen.")
    except ProgrammingError:  # pragma: no cover
        pass
    else:  # pragma: no cover
        assert False

# Generated at 2022-06-24 01:09:57.803411
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Syntax Error: This is a test")
    except ProgrammingError as e:
        assert str(e) == "Syntax Error: This is a test"

# Generated at 2022-06-24 01:09:59.695073
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "fake")
    except ProgrammingError as e:
        assert "fake" == str(e)

# Generated at 2022-06-24 01:10:01.101243
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming error.")
    except ProgrammingError:
        pass # OK.


# Generated at 2022-06-24 01:10:03.590874
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("some error")

    assert error.args == ("some error",)

# Generated at 2022-06-24 01:10:07.360339
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "It was False!")
    except ProgrammingError as ex:
        assert ex.args == ("It was False!",)
    else:
        assert False, "failure expected"


# Generated at 2022-06-24 01:10:10.797664
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    raise ProgrammingError("Test message")

# Generated at 2022-06-24 01:10:13.208755
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)

# Generated at 2022-06-24 01:10:20.391254
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def __check__(condition: bool, msg: Optional[str]):
        try:
            ProgrammingError.passert(condition, msg)
        except ProgrammingError as e:
            assert (not condition) and (str(e) == (msg or "Broken coherence. Check your code against domain logic to fix it."))
    __check__(True, None)
    __check__(True, "whatever")
    __check__(False, None)
    __check__(False, "")
    __check__(False, "whatever")

# Generated at 2022-06-24 01:10:26.837623
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as error:
        ProgrammingError.passert(True, "")
    with pytest.raises(ProgrammingError) as error:
        ProgrammingError.passert(False, "")
    assert str(error.value) == "Broken coherence. Check your code against domain logic to fix it."
    with pytest.raises(ProgrammingError) as error:
        ProgrammingError.passert(False, "My message")
    assert str(error.value) == "My message"

# Generated at 2022-06-24 01:10:29.839759
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, message="Foo")
    with pytest.raises(ProgrammingError) as error:
        ProgrammingError.passert(True, None)
    assert error.value.message == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-24 01:10:31.945002
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): assert issubclass(ProgrammingError, Exception)


# Generated at 2022-06-24 01:10:36.226255
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("test message"):
        assert False

# Generated at 2022-06-24 01:10:39.270321
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from common import check, test

    # Unit test for method passert
    def test_assert():
        try:
            ProgrammingError.passert(False, "test")
        except ProgrammingError as e:
            assert check(e.args[0], "test")

    test(test_assert)

# Generated at 2022-06-24 01:10:40.546771
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    ProgrammingError.passert(False, "Passert test")

# Generated at 2022-06-24 01:10:42.207704
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert False, "The constructor of ProgrammingError must raise an exception if no argument is passed"
    except TypeError:
        pass

# Generated at 2022-06-24 01:10:48.249291
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")
        assert False, "Exception not raised"
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(False, None)
        assert False, "Exception not raised"
    except ProgrammingError:
        pass

    ProgrammingError.passert(True, "Test message")

# Generated at 2022-06-24 01:10:52.825885
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Break!")
    except ProgrammingError as e:
        assert str(e) == "Break!"

# Generated at 2022-06-24 01:10:54.610260
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A")
    except ProgrammingError as e:
        assert str(e) == "A"



# Generated at 2022-06-24 01:11:01.054698
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    null_message = None
    text_message = "This is a programming error message."
    try:
        ProgrammingError.passert(False, null_message)
        assert False, "Should have raised an error here."
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, text_message)
        assert False, "Should have raised an error here."
    except ProgrammingError as e:
        assert text_message in str(e)
    assert ProgrammingError.passert(True, null_message) is None
    assert ProgrammingError.passert(True, text_message) is None

# Generated at 2022-06-24 01:11:03.311057
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something has gone very wrong.")
    except ProgrammingError:
        assert True
    else:
        assert False, "The exception did not happen."


# Generated at 2022-06-24 01:11:05.953826
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Expected exception to be thrown.")
    except ProgrammingError as ex:
        assert "Expected exception to be thrown." == ex.args[0]

# Generated at 2022-06-24 01:11:06.815673
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error

# Generated at 2022-06-24 01:11:08.908594
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Hi there")
        assert False
    except ProgrammingError as pe:
        assert str(pe) == "Hi there"


# Generated at 2022-06-24 01:11:13.045948
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    condition = False

    try:
        ProgrammingError.passert(condition, "Custom error message.")
        assert False, "Should not have reached line."
    except ProgrammingError as e:
        assert "Custom error message" == str(e)

    try:
        ProgrammingError.passert(condition, None)
        assert False, "Should not have reached line."
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)

# Generated at 2022-06-24 01:11:20.032191
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.

    The test is to "abuse" the class in order to run the test, thus the line-number of the traceback must be in the
    constructor.
    """
    try:
        raise ProgrammingError("test_ProgrammingError")
    except ProgrammingError:
        raise AssertionError(f"test_ProgrammingError is raised in line {__line__}")


# Generated at 2022-06-24 01:11:22.009064
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

# Unit test assert of class ProgrammingError

# Generated at 2022-06-24 01:11:25.880711
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    message = "Arbitrary message"

    # WHEN
    error = ProgrammingError(message)

    # THEN
    assert error.args == (message, )
    assert error.with_traceback is not None
    assert str(error) == message


# Generated at 2022-06-24 01:11:27.825889
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "This is a test message.")

# Generated at 2022-06-24 01:11:29.698538
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as ex:
        assert isinstance(ex, ProgrammingError)

# Generated at 2022-06-24 01:11:33.011761
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError()

    with raises(ProgrammingError):
        ProgrammingError("Hello World")


# Generated at 2022-06-24 01:11:37.461342
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from .exceptions import ProgrammingError

    with raises(ProgrammingError, match=r".* coherence .*"):
        ProgrammingError()

    with raises(ProgrammingError, match=r".* coherence .*"):
        ProgrammingError.passert(False, None)


# Generated at 2022-06-24 01:11:42.329122
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        err = e
    assert isinstance(err, ProgrammingError), "Expected a subclass of ProgrammingError."
    assert str(err) == "Test", "Expected 'Test' as message."


# Generated at 2022-06-24 01:11:45.148403
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test exception")
    except Exception as error:
        assert isinstance(error, ProgrammingError)


# Generated at 2022-06-24 01:11:49.291396
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    assert issubclass(ProgrammingError, Exception)
    assert ProgrammingError.__doc__ is not None


# Generated at 2022-06-24 01:11:55.525532
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing!")
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(False, "Testing!")
    except ProgrammingError as ex:
        assert str(ex) == "Testing!"

# Generated at 2022-06-24 01:11:56.600338
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error.args == tuple()


# Generated at 2022-06-24 01:11:59.409448
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor of class ProgrammingError.
    """
    try:
        raise ProgrammingError("This is an error raised by unit testing.")
    except ProgrammingError as err:
        assert str(err) == "This is an error raised by unit testing."


# Generated at 2022-06-24 01:12:02.857256
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    instance = ProgrammingError()
    assert isinstance(instance, ProgrammingError)  # type: ignore
    assert isinstance(instance, Exception)


# Generated at 2022-06-24 01:12:04.533387
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        pass


# Generated at 2022-06-24 01:12:05.959629
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Some message"):
        pass


# Generated at 2022-06-24 01:12:09.062042
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
    except ProgrammingError as over:
        assert str(over) == "test"
    else:
        assert False, "Failure in assert."

# Generated at 2022-06-24 01:12:11.524489
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('Illegal argument!')
    except ProgrammingError as e:
        assert str(e) == 'Illegal argument!'


# Generated at 2022-06-24 01:12:13.009300
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Cannot do that")
    finally:
        assert Exception("Cannot do that")


# Generated at 2022-06-24 01:12:14.088587
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test")



# Generated at 2022-06-24 01:12:19.071974
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class DerivedError(ProgrammingError):
        pass

    with raises(ProgrammingError) as exception_info:
        raise ProgrammingError("test")

    assert "test" in exception_info.value

    with raises(DerivedError) as exception_info:
        raise DerivedError("test")

    assert "test" in exception_info.value


# Generated at 2022-06-24 01:12:20.805328
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("this is a message")
    except ProgrammingError as ex:
        assert str(ex) == "this is a message"


# Generated at 2022-06-24 01:12:22.389748
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "foo")
        assert False
    except ProgrammingError as ex:
        assert str(ex) == "foo"

# Generated at 2022-06-24 01:12:26.041081
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, ""):
        pass

    try:
        with ProgrammingError.passert(False, ""):
            pass
    except ProgrammingError:
        pass



# Generated at 2022-06-24 01:12:31.752275
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor for :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Sample error message.")
    except ProgrammingError as e:
        assert str(e) == "Sample error message."


# Generated at 2022-06-24 01:12:33.900363
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:12:37.489361
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test that tests the constructor of :py:class:`ProgrammingError`
    """
    try:
        raise ProgrammingError(message="This is an error")
    except ProgrammingError as ex:
        assert ex.args[0] == "This is an error"


# Generated at 2022-06-24 01:12:38.388729
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("error message")


# Generated at 2022-06-24 01:12:43.422348
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError.passert(False, "The condition is not met")
    except ProgrammingError as e:
        print(e.args)
        assert str(e) == "('The condition is not met',)"
    
    try:
        ProgrammingError.passert(True, "This should be skipped")
    except ProgrammingError as e:
        print(e.args)
        assert str(e) == "('This should be skipped',)"


# Generated at 2022-06-24 01:12:47.656872
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "sample")
        assert False, "Should have raised an exception"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:12:53.791908
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # This should raise an exception
        ProgrammingError.passert(condition=False, message="We have a problem!")
    except ProgrammingError as e:
        assert e.args[0] == "We have a problem!"
    else:
        raise RuntimeError("ProgrammingError exception should have been raised")
    # This should not raise exception
    ProgrammingError.passert(condition=True, message="We don't have a problem!")

# Generated at 2022-06-24 01:13:03.724353
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        raise AssertionError("Should not raise a ProgrammingError")
    try:
        ProgrammingError.passert(False, None)
        raise AssertionError("Should raise a ProgrammingError")
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(False, "Custom message")
        raise AssertionError("Should raise a ProgrammingError")
    except ProgrammingError as e:
        assert e.args[0] == "Custom message"

# Generated at 2022-06-24 01:13:05.087574
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:13:07.069414
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:13:10.756977
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence" in e.args[0]


# Generated at 2022-06-24 01:13:12.554546
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("An unexpected error occurred.")
    assert exception.args[0] == "An unexpected error occurred."



# Generated at 2022-06-24 01:13:16.568837
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert str(e) == "This is a test."



# Generated at 2022-06-24 01:13:18.834509
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-24 01:13:21.694036
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError()
    assert str(err) == 'Broken coherence. Check your code against domain logic to fix it.'


# Generated at 2022-06-24 01:13:25.148893
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e: # pylint: disable=unused-variable
        pass


# Generated at 2022-06-24 01:13:29.218858
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:13:31.720437
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError failed to raise an exception"


# Generated at 2022-06-24 01:13:33.761402
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # The constructor is not supposed to throw an exception
    ProgrammingError(None)

# Generated at 2022-06-24 01:13:35.794532
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-24 01:13:40.760794
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Makes sure that :py:class:`ProgrammingError` works as defined.
    """
    try:
        raise ProgrammingError(message="Some message")
    except ProgrammingError as error:
        assert error.__str__() == "Some message"



# Generated at 2022-06-24 01:13:46.538241
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "some message")
    try:
        ProgrammingError.passert(False, "some message")
        assert False, "ProgrammingError should have been raised"
    except ProgrammingError:
        pass

# Generated at 2022-06-24 01:13:54.795135
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for the constructor of class ProgrammingError."""
    # Test with arguments to the constructor
    try:
        raise ProgrammingError("This is a test exception")
    except ProgrammingError as raise_expected:
        assert str(raise_expected) == "This is a test exception", "Got invalid error message"
    else:
        assert False, "Should raise ProgrammingError, but did not."
    # Test with no arguments to the constructor
    try:
        raise ProgrammingError()
    except ProgrammingError as raise_expected:
        assert str(raise_expected) == "Broken coherence. Check your code against domain logic to fix it.", \
            "Got invalid error message"
    else:
        assert False, "Should raise ProgrammingError, but did not."

# Generated at 2022-06-24 01:13:59.428308
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test message")
    except ProgrammingError as error:
        assert error.args[0] == "This is a test message"


# Generated at 2022-06-24 01:14:00.251549
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError:
        assert False


# Generated at 2022-06-24 01:14:02.889999
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as err:
        assert(err.args[0] == "Broken coherence. Check your code against domain logic to fix it.")
        assert(len(err.args) == 1)


# Generated at 2022-06-24 01:14:07.362940
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as e:
        assert str(e) == "Message"



# Generated at 2022-06-24 01:14:09.839878
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("I am an error")
    except Exception as e:
        assert(str(e) == "I am an error")


# Generated at 2022-06-24 01:14:11.927911
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a test")
        assert(False)
    except ProgrammingError as ex:
        assert(ex.args[0] == "This is a test")


# Generated at 2022-06-24 01:14:13.773721
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("foo")
    except ProgrammingError as e:
        assert str(e) == "foo"


# Generated at 2022-06-24 01:14:17.558743
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("this is the message")
    except ProgrammingError as e:
        assert e.args[0] == "this is the message"


# Generated at 2022-06-24 01:14:23.605058
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Empty message")
    assert error.args == ("Empty message",)

    error = ProgrammingError()
    assert error.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-24 01:14:25.808185
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="Hello World!")


# Generated at 2022-06-24 01:14:32.206520
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My error message")
    except ProgrammingError as error:
        assert str(error) == "My error message", "Error message is not the expected"


# Generated at 2022-06-24 01:14:36.397820
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError` class constructor.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:14:38.970360
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a unit test.")
    except ProgrammingError as e:
        assert str(e) == "This is a unit test."



# Generated at 2022-06-24 01:14:46.917927
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Assertion failed")
        raise AssertionError('ProgrammingError.passert(False, "Assertion failed") should have raised a ProgrammingError')
    except Exception as ex:
        if not isinstance(ex, ProgrammingError):
            raise AssertionError(
                'ProgrammingError.passert(False, "Assertion failed") raised an unexpected exception %s' % str(ex))

    # If we get here, then the exception was raised, so let's reset the exception flag
    ex = None
    ProgrammingError.passert(True, "Assertion failed")


# Generated at 2022-06-24 01:14:51.013043
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for :py:class:`ProgrammingError` constructor
    """
    assert ProgrammingError("error message")


# Generated at 2022-06-24 01:14:56.218519
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    assert isinstance(ProgrammingError(), ProgrammingError)  # type: ignore
    assert isinstance(ProgrammingError("message"), ProgrammingError)  # type: ignore


# Generated at 2022-06-24 01:15:01.578954
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-24 01:15:08.317945
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` class constructor.
    """
    # Check constructor
    try:
        raise ProgrammingError("Testing")
    except ProgrammingError as err:
        assert isinstance(err.message, str)
        assert err.message == "Testing"


# Generated at 2022-06-24 01:15:10.911039
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert hasattr(ProgrammingError, "__init__")

# Generated at 2022-06-24 01:15:13.242682
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as ex:
        assert type(ex) == ProgrammingError



# Generated at 2022-06-24 01:15:21.260271
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        pass
    except ProgrammingError:
        pass
    except:
        assert False, "Unexpected exception raised while checking constructors of class ProgrammingError"
    try:
        ProgrammingError.passert(False, "Test")
        pass
    except ProgrammingError:
        pass
    except:
        assert False, "Unexpected exception raised while checking constructors of class ProgrammingError"
    assert ProgrammingError.passert(True, None) is None
    assert ProgrammingError.passert(True, "Test") is None

# Generated at 2022-06-24 01:15:25.557824
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    # No message specified
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    # Message specified
    try:
        raise ProgrammingError("some message")
    except ProgrammingError as e:
        assert e.args[0] == "some message"


# Generated at 2022-06-24 01:15:27.979015
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("The test message.")
    except ProgrammingError as e:
        assert e.args[0] == "The test message."
    except Exception as e:
        raise Exception("Unexpected exception was raised: " + str(e))


# Generated at 2022-06-24 01:15:34.660925
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    passert = lambda condition, message=None: ProgrammingError.passert(condition, message)

    assert(not hasattr(ProgrammingError, '__slots__'))

    assert(passert(True, "ProgrammingError constructor failed"))
    try:
        passert(False, "ProgrammingError constructor failed")
    except ProgrammingError as ex:
        assert(str(ex) == "Broken coherence. Check your code against domain logic to fix it.")
    else:
        raise AssertionError("ProgrammingError constructor failed")

# Generated at 2022-06-24 01:15:38.440792
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except Exception as e:
        assert isinstance(e, ProgrammingError)



# Generated at 2022-06-24 01:15:43.249547
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        # Test with a false condition, then the assert will raise a ProgrammingError
        ProgrammingError.passert(condition=False, message="Failed condition")

    # Test with a true condition, then the assert will not raise a ProgrammingError
    ProgrammingError.passert(condition=True, message="Failed condition")

# Generated at 2022-06-24 01:15:45.852458
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Create an instance of class ProgrammingError
    try:
        raise ProgrammingError("This is a message")
    except ProgrammingError as e:
        assert str(e) == "This is a message"

# Generated at 2022-06-24 01:15:50.548171
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as exc:
        assert exc.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-24 01:15:56.211973
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Some message")
    except ProgrammingError as ex:
        assert str(ex) == "Some message"
    else:
        raise AssertionError("ProgrammingError.passert() should have raised an exception")

# Generated at 2022-06-24 01:16:02.668515
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Case 1: Constructing ProgrammingError with a message
    try:
        raise ProgrammingError("This is a message")
    except ProgrammingError as e:
        assert str(e) == "This is a message"

    # Case 2: Constructing ProgrammingError without a message
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:16:09.745263
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.testing import assert_raises

    with assert_raises(ProgrammingError, "Broken coherence. Check your code against domain logic to fix it."):
        ProgrammingError(None)
    
    with assert_raises(ProgrammingError, "Broken coherence. Check your code against domain logic to fix it."):
        ProgrammingError("")

    with assert_raises(ProgrammingError, "Unknown error."):
        ProgrammingError("Unknown error.")


# Generated at 2022-06-24 01:16:18.074752
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    a = ProgrammingError("Error message")

    # Unit test for function passert of class ProgrammingError
    def test_ProgrammingError_passert():
        try:
            ProgrammingError.passert(True, "Should not raise")
        except ProgrammingError:
            assert False, "Should not raise"
        try:
            ProgrammingError.passert(False, "Should raise")
            assert False, "Should raise"
        except ProgrammingError:
            pass
        try:
            ProgrammingError.passert(False, None)
            assert False, "Should raise"
        except ProgrammingError as e:
            assert "Broken coherence" in str(e), "Should raise default message"

# Generated at 2022-06-24 01:16:22.847433
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    # In case that the condition is not met, a ProgrammingError must be raised with the provided message
    with raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "Error message")
    assert "Error message" == str(excinfo.value)

    # In case that the condition is met, no exception shall be raised
    ProgrammingError.passert(True, "Error message")

# Generated at 2022-06-24 01:16:28.054508
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase

    class _Unittest(TestCase):
        def __init__(self):
            TestCase.__init__(self, methodName = "__run_test__")
        def __run_test__(self):
            self.assertRaises(ProgrammingError, lambda: ProgrammingError())
    _Unittest().__run_test__()


# Generated at 2022-06-24 01:16:32.891158
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Creates an exception and raises it.
    """
    ProgrammingError.passert(True, "")
    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError:
        assert True


# Unit testing for class ProgrammingError

# Generated at 2022-06-24 01:16:35.123492
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Something went wrong.")
    except ProgrammingError as e:
        assert "Something went wrong." == str(e)


# Generated at 2022-06-24 01:16:37.098590
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-24 01:16:42.206134
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("error message")
    except ProgrammingError as e:
        assert e.args[0] == "error message"


# Generated at 2022-06-24 01:16:44.780536
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is a test")

# Generated at 2022-06-24 01:16:47.718927
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except Exception as e:
        assert str(e) == "This is a test."


# Generated at 2022-06-24 01:16:51.077210
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Testing is a good practice")
    except ProgrammingError as e:
        assert e.args[0] == "Testing is a good practice"



# Generated at 2022-06-24 01:16:53.715370
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def _test():
        raise ProgrammingError("error message")

    import pytest
    with pytest.raises(ProgrammingError) as ex:
        _test()
    assert str(ex.value) == "error message"



# Generated at 2022-06-24 01:16:55.412879
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-24 01:16:58.538283
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an expected problem")
    except ProgrammingError as ex:
        assert ex.args[0] == "This is an expected problem"
    else:
        raise AssertionError("ProgrammingError should be raised")

# Generated at 2022-06-24 01:16:59.348203
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-24 01:17:01.983231
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "This is a test")

# Generated at 2022-06-24 01:17:09.565220
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase, main

    class ProgrammingErrorTestCase(TestCase):
        def test_exception_message(self):
            with self.assertRaises(ProgrammingError) as exception:
                raise ProgrammingError()
            self.assertEqual("Broken coherence. Check your code against domain logic to fix it.",
                             exception.exception.args[0])

    main()



# Generated at 2022-06-24 01:17:13.660381
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("This exception is raised for the sake of testing.")


# Generated at 2022-06-24 01:17:16.433500
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("My message")
    except:
        assert False, "Exception raised"
    else:
        assert True, "Exception not raised"


# Generated at 2022-06-24 01:17:24.831620
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.
    """
    # First test with a given message
    message = "Check your code against domain logic to fix it."
    err = ProgrammingError(message)
    assert str(err) == message, "Expected the message specified in the constructor to be the same as its representation"
    # Second test without message
    err2 = ProgrammingError()
    assert str(err2) == "Broken coherence. Check your code against domain logic to fix it.", \
           "Expected this to be the default message if no message is given at the constructor"
    assert str(err) != str(err2), "Expected the messages from both errors to be different"


# Generated at 2022-06-24 01:17:29.114553
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error.")
    except ProgrammingError as e:
        assert str(e) == "This is a programming error."


# Generated at 2022-06-24 01:17:32.634910
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Invalid use of a method.")
    except ProgrammingError as e:  # type: ignore
        assert e.args[0] == "Invalid use of a method."
    else:
        raise RuntimeError("Did not raise any exception.")



# Generated at 2022-06-24 01:17:35.446889
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "TestMessage")
    except ProgrammingError as e:
        assert e.args[0] == "TestMessage"


# Generated at 2022-06-24 01:17:39.689403
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test the ProgrammingError constructor"""
    try:
        raise ProgrammingError("")
    except ProgrammingError as exc:
        assert exc.args == ("",)
        assert str(exc) == "", "The exception must contain the message"

# Generated at 2022-06-24 01:17:45.416401
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Testing a programming error")
    except Exception as error:
        if isinstance(error, ProgrammingError):
            print("Constructor of class ProgrammingError is working.")
        else:
            raise AssertionError("ProgrammingError is not raised. An exception of a different class was raised.")


# Generated at 2022-06-24 01:17:52.655757
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("any message")
    except ProgrammingError as e:
        assert e.args[0] == "any message"
    try:
        ProgrammingError.passert(False, "any message")
    except ProgrammingError as e:
        assert e.args[0] == "any message"


# Generated at 2022-06-24 01:17:53.652093
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error.__class__ == ProgrammingError


# Generated at 2022-06-24 01:17:57.031012
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("my error")
    except ProgrammingError as e:
        assert str(e) == "my error"
    except:
        assert False

# Generated at 2022-06-24 01:18:08.661611
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert str(ex) == ""
    try:
        raise ProgrammingError("123")
    except ProgrammingError as ex:
        assert str(ex) == "123"
    try:
        ProgrammingError.passert(False, "456")
    except ProgrammingError as ex:
        assert str(ex) == "456"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(True, None)
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        assert False
    except:
        assert True
    else:
        assert True