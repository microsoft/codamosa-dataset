

# Generated at 2022-06-26 00:41:21.457028
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except Exception as e:
        assert isinstance(e, ProgrammingError)
    else:
        assert False
    finally:
        pass


# Generated at 2022-06-26 00:41:22.807128
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:41:24.876840
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        print("ProgrammingError is working")


# Generated at 2022-06-26 00:41:25.790208
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:27.420391
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Check the creation of a ProgrammingError instance.
    programming_error_0 = ProgrammingError()
    assert programming_error_0 is not None



# Generated at 2022-06-26 00:41:30.202093
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as error:
        assert error.args == ()
        assert error.__cause__ is None
        assert error.__context__ is None
        assert error.__traceback__ is None
    else:
        assert False



# Generated at 2022-06-26 00:41:30.975342
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:32.081564
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        test_case_0()

# Generated at 2022-06-26 00:41:33.041369
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)



# Generated at 2022-06-26 00:41:39.537826
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Programming Error!")
    except ProgrammingError as e:
        assert e.args[0] == "Programming Error!"
    try:
        raise ProgrammingError("Programming Error!", "ARG1")
    except ProgrammingError as e:
        assert e.args[0] == "Programming Error!"
        assert e.args[1] == "ARG1"
    try:
        raise ProgrammingError(programming_error_0=1, programming_error_1=2)
    except ProgrammingError as e:
        assert e.args[0] == "programming_error_0=1, programming_error_1=2"
        assert e.programming_error_0 == 1
        assert e.programming_error_1 == 2
    assert repr(ProgrammingError()) == "<ProgrammingError()>"

# Generated at 2022-06-26 00:41:45.458690
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        assert True
    else:
        assert False



# Generated at 2022-06-26 00:41:48.148679
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        assert True
    except:
        pass
    try:
        test_case_0()
        assert False
    except ProgrammingError:
        assert True


# Generated at 2022-06-26 00:41:50.328910
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except Exception as e:
        assert type(e) == ProgrammingError


# Generated at 2022-06-26 00:41:51.207456
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:53.425603
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the constructor of class :py:class:`ProgrammingError`
    """
    try:
        ProgrammingError()
    except Exception:
        assert False



# Generated at 2022-06-26 00:41:55.082358
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
        assert False
    except ProgrammingError:
        assert True


# Generated at 2022-06-26 00:41:59.702638
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except ProgrammingError as error:
        print(error)
        assert False

    try:
        programming_error_1 = ProgrammingError("Check your code against requirements to fix it.")
    except ProgrammingError as error:
        print(error)
        assert False

    try:
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as error:
        print(error)
        assert error != None

# Generated at 2022-06-26 00:42:03.304493
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except Exception as e:
        print("test 1 is failed")
        raise
    try:
        programming_error_0 = ProgrammingError("error 1")
    except Exception as e:
        print("test 2 is failed")
        raise


# Generated at 2022-06-26 00:42:04.149601
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert test_case_0() is None

# Generated at 2022-06-26 00:42:14.668627
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test constructor of class ProgrammingError."""
    # Case 0
    # Case 0.1
    programming_error_0 = ProgrammingError()

    assert programming_error_0.__cause__ is None
    assert programming_error_0.args == ()
    assert type(programming_error_0).__name__ == "ProgrammingError"
    assert programming_error_0.__traceback__ is None
    assert programming_error_0.__context__ is None

    # Case 0.2
    programming_error_1 = ProgrammingError("Parameter 1")

    assert programming_error_1.__cause__ is None
    assert programming_error_1.args[0] == "Parameter 1"
    assert type(programming_error_1).__name__ == "ProgrammingError"
    assert programming_error_1.__traceback__ is None


# Generated at 2022-06-26 00:42:21.194229
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
        assert True
    except ProgrammingError:
        assert False



# Generated at 2022-06-26 00:42:22.699573
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError()

test_case_0()
test_ProgrammingError()

# Generated at 2022-06-26 00:42:24.379339
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()


# Generated at 2022-06-26 00:42:25.325055
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()


# Generated at 2022-06-26 00:42:26.265246
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:42:27.211584
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:42:32.616687
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    assert programming_error_0.args == tuple()
    #assert programming_error_0.__context__ is None
    #assert programming_error_0.__cause__ is None
    #assert programming_error_0.__cause__ == __context__
    assert programming_error_0.__traceback__ is None


# Generated at 2022-06-26 00:42:34.329992
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert str(ProgrammingError())


# Generated at 2022-06-26 00:42:35.308562
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(test_case_0(), ProgrammingError)

# Generated at 2022-06-26 00:42:37.205477
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    assert programming_error_0 != None, 'programming_error_0 is None'


# Generated at 2022-06-26 00:42:49.321835
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        assert False


# Generated at 2022-06-26 00:42:55.314299
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert True
    else:
        assert False


# Generated at 2022-06-26 00:42:58.524365
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # test 0
    try:
        test_case_0()
    except ProgrammingError as e:
        assert 'Exception' in str(e)

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-26 00:43:00.588885
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == 'Broken coherence. Check your code against domain logic to fix it.'


# Generated at 2022-06-26 00:43:04.410275
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    # Condition for instance of class ProgrammingError
    try:
        assert isinstance(programming_error_0, ProgrammingError)
    except AssertionError as e:
        if str(e) == "'desc_0' is not defined":
            prog_er_0 = ProgrammingError("Error message")
        else:
            raise e

# Generated at 2022-06-26 00:43:06.447605
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert test_case_0() == None


# Generated at 2022-06-26 00:43:07.345615
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:43:09.824557
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-26 00:43:10.458290
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)


# Generated at 2022-06-26 00:43:11.249470
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except:
        print('test case 0 failed')



# Generated at 2022-06-26 00:43:37.582291
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError
    test_case_0()

# Generated at 2022-06-26 00:43:38.237233
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError()

# Generated at 2022-06-26 00:43:41.108703
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:43:42.609888
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Unit test for constructor of class ProgrammingError
    test_case_0()

test_ProgrammingError()

# Generated at 2022-06-26 00:43:44.285375
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except:
        pass
    else:
        assert False


# Generated at 2022-06-26 00:43:45.838480
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test 0
    assert programming_error_0.args == ("",)

# Generated at 2022-06-26 00:43:48.618265
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from .error import ProgrammingError
    with raises(ProgrammingError):
        test_case_0()


# Generated at 2022-06-26 00:43:49.449393
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:43:50.869284
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass



# Generated at 2022-06-26 00:43:51.874965
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:44:15.033516
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except:
        pass
    else:
        assert False, "No exception was raised."

# Generated at 2022-06-26 00:44:23.393449
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase
    from unittest.mock import MagicMock

    class Test(TestCase):
        def test_constructor(self):
            # noinspection PyTypeChecker
            exc = ProgrammingError()

            self.assertIsInstance(exc, Exception)
            self.assertIsInstance(exc, ProgrammingError)

            mock_exst = MagicMock()
            mock_exst.__name__ = "Exception"
            self.assertIn(mock_exst, exception_mro(exc))

            mock_exst = MagicMock()
            mock_exst.__name__ = "ProgrammingError"
            self.assertIn(mock_exst, exception_mro(exc))

    def exception_mro(exc):
        mro = []

        # noinspection PyTypeChecker

# Generated at 2022-06-26 00:44:25.186098
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hello!")
    except ProgrammingError as e:
        assert e.args[0] == "Hello!"


# Generated at 2022-06-26 00:44:27.235444
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error_message = "Error message"
    try:
        ProgrammingError(error_message)
    except ProgrammingError as e:
        assert str(e) == error_message


# Generated at 2022-06-26 00:44:28.902990
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert isinstance(error, ProgrammingError)
    assert isinstance(error, Exception)


# Generated at 2022-06-26 00:44:30.192236
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert False
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:44:32.643066
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("something went wrong")
    except ProgrammingError as e:
        if str(e) != "something went wrong":
            raise AssertionError("Constructor failing")


# Generated at 2022-06-26 00:44:33.984601
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("Testing this exception.")
    assert exception.args == ("Testing this exception.",)


# Generated at 2022-06-26 00:44:36.223780
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Something was wrong.")
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:44:39.534319
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.error import ProgrammingError
    err = ProgrammingError("some message")
    assert str(err) == "some message"


# Generated at 2022-06-26 00:45:27.041232
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Oops!")
        assert False, "Oops!"
    except ProgrammingError as e:
        assert e.args[0] == "Oops!"


# Generated at 2022-06-26 00:45:28.559724
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    obj = ProgrammingError("test")
    assert isinstance(obj, ProgrammingError)
    assert str(obj) == "test"


# Generated at 2022-06-26 00:45:30.950014
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test_message")
    except ProgrammingError as e:
        assert e.args[0] == "test_message"


# Generated at 2022-06-26 00:45:34.379365
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(
            "This is a programmer error. Check the domain logic of your code against the specification to fix it.")
    except ProgrammingError as error:
        assert error.args[0] == "This is a programmer error. Check the domain logic of your code against the " \
            "specification to fix it."


# Generated at 2022-06-26 00:45:35.978280
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:45:38.645880
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "My message")
        assert False, "Should have raised an ProgrammingError"
    except ProgrammingError as error:
        assert error.args == ("My message",)

# Generated at 2022-06-26 00:45:41.004653
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Does not meet expectation")
    except ProgrammingError as e:
        assert str(e) == "Does not meet expectation"
        assert e.args == ("Does not meet expectation",)

# Generated at 2022-06-26 00:45:43.466955
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert False
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:45:46.455252
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the constructor of class :py:class:`ProgrammingError`.
    """
    assertion = False
    try:
        ProgrammingError(None)
    except Exception:
        assertion = True
    assert assertion

# Generated at 2022-06-26 00:45:49.455165
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    allowed_messages = "Message allowed as message is optional"
    error = ProgrammingError(allowed_messages)
    assert error.msg == allowed_messages
    error = ProgrammingError()
    assert error.msg is None
    assert error.message is None


# Generated at 2022-06-26 00:47:47.219429
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor for class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-26 00:47:48.284653
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-26 00:47:52.488828
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Foo bar")
    except ProgrammingError as err:
        assert str(err) == "Foo bar"
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert str(err) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:48:00.718940
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase, main
    from mock import MagicMock

    class TestingProgrammingError(ProgrammingError):
        def __init__(self, message):
            super(ProgrammingError, self).__init__(message)

    class TestingClass(TestCase):
        def test_assert_False(self):
            self.assertRaises(ProgrammingError, lambda: TestingProgrammingError.passert(False, "Message"))

        def test_assert_True(self):
            try:
                TestingProgrammingError.passert(True, "Message")
            except ProgrammingError:
                self.fail("Must not raise ProgrammingError")


# Generated at 2022-06-26 00:48:04.311878
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('my message')
    except ProgrammingError as e:
        assert 'my message' == e.args[0], "ProgrammingError constructor accepts message."
    except Exception as e: # noqa
        assert False, "ProgrammingError is not caught."
    else:
        assert False, "ProgrammingError is not raised."


# Generated at 2022-06-26 00:48:06.662625
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    ProgrammingError('Programming error message.')


# Generated at 2022-06-26 00:48:10.664489
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Check constructor of ProgrammingError."""
    try:
        ProgrammingError(message="test1")
    except ProgrammingError as ex:
        assert ex.args[0] == "test1"

    try:
        ProgrammingError.passert(condition=False, message="test2")
    except ProgrammingError as ex:
        assert ex.args[0] == "test2"

    ProgrammingError.passert(condition=True, message="test3")

# Generated at 2022-06-26 00:48:13.401644
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error.")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-26 00:48:17.167731
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    from pypara.testing import Assertions

    Assertions.context(ProgrammingError(), ProgrammingError, "Broken coherence. Check your code against domain logic to fix it.")
    Assertions.context(ProgrammingError("Failure message"), ProgrammingError, "Failure message")



# Generated at 2022-06-26 00:48:18.406644
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(False, "A error message")
    ProgrammingError.passert(True, "A error message")