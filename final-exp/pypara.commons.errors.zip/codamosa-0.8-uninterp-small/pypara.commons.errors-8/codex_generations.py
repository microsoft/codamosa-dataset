

# Generated at 2022-06-26 00:41:17.001124
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Case 0
    try:
        test_case_0()
    except ProgrammingError:
        pass
    else:
        assert False



# Generated at 2022-06-26 00:41:19.039819
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        test_case_0()

# Generated at 2022-06-26 00:41:19.913250
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:21.529088
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except Exception as e:
        assert False
    else:
        assert True


# Generated at 2022-06-26 00:41:25.402070
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test if it can be instantiated
    try:
        test_case_0()
        assert True
    except:
        assert False

    # Test if it is a type of Exception
    try:
        assert issubclass(ProgrammingError, Exception)
        assert True
    except:
        assert False


# Generated at 2022-06-26 00:41:28.880995
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError.__doc__ is not None
    assert ProgrammingError.__init__.__doc__ is not None
    assert ProgrammingError.passert.__doc__ is not None
    assert ProgrammingError.__module__ == "pypara.error"
    assert ProgrammingError.__name__ == "ProgrammingError"



# Generated at 2022-06-26 00:41:30.842355
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except TypeError:
        print("error")
    except Exception as e:
        print("error")

# Generated at 2022-06-26 00:41:34.874167
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Case 0: no message
    try:
        # Run test
        test_case_0()
    # ProgrammingError must be raised, otherwise the test is failed
    except ProgrammingError:
        pass
    except Exception as e:
        raise Exception("Unexpected exception: {}".format(e))
    else:
        raise Exception("ProgrammingError must be raised.")

if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-26 00:41:36.464774
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:37.220252
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert str(ProgrammingError()) == ""

# Generated at 2022-06-26 00:41:42.763267
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Yo Ho Ho and a bottle of rum")
    except ProgrammingError as error:
        # Check if expects exception message
        assert error.args[0] == "Yo Ho Ho and a bottle of rum"
    else:
        assert False, "Did not raise except as expected"


# Generated at 2022-06-26 00:41:44.490655
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError()
    assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:41:48.106262
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Broken coherence.")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence."
    else:
        raise AssertionError("")


# Generated at 2022-06-26 00:41:53.343948
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Testing with a True condition
    ProgrammingError.passert(True, "")

    # Testing with a False condition
    try:
        ProgrammingError.passert(False, "")
        raise AssertionError("test_ProgrammingError() FAILED: The assertion error was not raised.")
    except ProgrammingError as exception_:
        assert str(exception_) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:41:54.997980
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of ProgrammingError."""
    with ProgrammingError("Foo"):
        pass

# Generated at 2022-06-26 00:41:56.345117
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        pass
    else:
        raise ValueError

# Generated at 2022-06-26 00:42:00.492875
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")
        assert False
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:42:02.844046
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:42:07.466292
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Try actual values
        e = ProgrammingError("bla")
        assert isinstance(e, Exception) and str(e) == 'bla'
    except Exception as e:
        # Fail and print error
        print(f"While testing ProgrammingError.__init__: {type(e)} {e}")
        raise


# Generated at 2022-06-26 00:42:08.409764
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Error message"):
        pass

# Generated at 2022-06-26 00:42:13.234043
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "")

# Generated at 2022-06-26 00:42:17.205338
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "")
    ProgrammingError.passert(True, "")


# Unit tests for the unit test

# Generated at 2022-06-26 00:42:18.983299
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("message")
    except ProgrammingError as exception:
        assert exception.args == ("message",)


# Generated at 2022-06-26 00:42:22.690730
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for class :py:class:`ProgrammingError`.
    """
    from pytest import raises
    with raises(ProgrammingError) as err:
        raise ProgrammingError()
    assert str(err.value) == "Broken coherence. Check your code against domain logic to fix it."
    with raises(ProgrammingError) as err:
        raise ProgrammingError("Some message")
    assert str(err.value) == "Some message"


# Generated at 2022-06-26 00:42:25.886253
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)


# Generated at 2022-06-26 00:42:32.528812
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    # Test error with no message
    error = ProgrammingError()
    assert isinstance(error, Exception)
    assert str(error) == "Broken coherence. Check your code against domain logic to fix it."
    # Test error with message
    error = ProgrammingError("Test message")
    assert isinstance(error, Exception)
    assert str(error) == "Test message"


# Generated at 2022-06-26 00:42:34.597731
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Foo"):
        assert False



# Generated at 2022-06-26 00:42:38.153525
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Test error")
    except ProgrammingError as e:
        assert (isinstance(e, Exception) and str(e) == "Test error")



# Generated at 2022-06-26 00:42:40.438301
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Failing.")

# Generated at 2022-06-26 00:42:41.938095
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(None)
    except Exception as e:
        assert(False)


# Generated at 2022-06-26 00:42:47.901601
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()


# Generated at 2022-06-26 00:42:50.503146
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError.__name__ == "ProgrammingError"
    assert ProgrammingError.__doc__ == "Provides a programming error exception."



# Generated at 2022-06-26 00:42:52.711367
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message.")
    except ProgrammingError as e:
        assert str(e) == "Message."



# Generated at 2022-06-26 00:42:54.177519
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError(message="Just an example.")

# Generated at 2022-06-26 00:42:55.781958
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except ProgrammingError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-26 00:42:56.817912
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # ACT & ASSERT #
    ProgrammingError.passert(False, "A test message")

# Generated at 2022-06-26 00:43:00.192686
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "test"
    else:
        assert False, "The code should have raised a ProgrammingError"


# Generated at 2022-06-26 00:43:02.891308
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        print("\nUnit test for ProgrammingError")
        err = ProgrammingError("This is a test.")
        print(f"ProgrammingError message:\n{err}")
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:43:05.219827
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Broken logic due to lack of coffee"
    with pytest.raises(ProgrammingError) as excinfo:
        raise ProgrammingError(message)
    assert excinfo.value.args[0] == message



# Generated at 2022-06-26 00:43:07.256616
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test case for :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"


# Generated at 2022-06-26 00:43:18.824699
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test message")
    except ProgrammingError as err:
        assert str(err) == "test message"

# Generated at 2022-06-26 00:43:21.494613
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, None)
    caught = False
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e).find("broken coherence") != -1
        caught = True
    assert caught

# Generated at 2022-06-26 00:43:26.862835
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.common import ProgrammingError

    with raises(ProgrammingError):
        raise ProgrammingError()

    with raises(ProgrammingError):
        raise ProgrammingError("Test message")

    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Test message")

# Generated at 2022-06-26 00:43:31.051004
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for ProgrammingError class."""
    import pytest

    some_bool_condition = False
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(condition=some_bool_condition, message="a message")

    some_bool_condition = True
    ProgrammingError.passert(condition=some_bool_condition, message="a message")

# Generated at 2022-06-26 00:43:31.956845
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        assert ProgrammingError()


# Generated at 2022-06-26 00:43:37.699245
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:43:42.302548
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("test")
    except ProgrammingError as ex:
        assert str(ex) == "test"


# Generated at 2022-06-26 00:43:46.718779
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Try to raise the exception by passing a message
        ProgrammingError("This error message has been raised on purpose.")
        assert False, "Exception not raised when expected"
    except ProgrammingError as e:
        assert "This error message has been raised on purpose." == e.args[0], \
            "Message is not the one passed to constructor"


# Generated at 2022-06-26 00:43:50.065901
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError) as p:
        ProgrammingError.passert(False, "Foo")
    assert str(p.value) == "Foo"
# END unit test for constructor of class ProgrammingError

# Generated at 2022-06-26 00:43:51.123125
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError(message="Intentional"):
        pass

# Generated at 2022-06-26 00:44:18.751854
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # This should not raise an exception  
    ProgrammingError.passert(False, "Error message 1")
    # This should raise an exception since the message is not provided
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    # Raises an exception
    try:
        ProgrammingError.passert(False, "Error message 2")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Error message 2"

# Generated at 2022-06-26 00:44:20.972460
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Broken coherence")
    except ProgrammingError as err:
        assert str(err) == "Broken coherence"


# Generated at 2022-06-26 00:44:23.250435
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "Testing")
    assert "Testing" in str(excinfo.value)



# Generated at 2022-06-26 00:44:25.496559
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests ``ProgrammingError`` class.
    """
    # Expected use case

# Generated at 2022-06-26 00:44:28.149285
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "I want to fail.")
    except ProgrammingError:
        pass
    else:
        raise Exception("Failure expected.")

    ProgrammingError.passert(True, "I want to fail.")

# Generated at 2022-06-26 00:44:30.514344
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Checks the correct operation of the constructor of :py:class:`ProgrammingError`.
    """

    try:
        raise ProgrammingError("Message")
    except ProgrammingError as ex:
        assert str(ex) == "Message"



# Generated at 2022-06-26 00:44:32.025404
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:44:33.912620
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:44:36.472649
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:meth:`ProgrammingError.__init__`.
    """
    error = ProgrammingError("Error message")
    assert str(error) == "Error message"



# Generated at 2022-06-26 00:44:40.039006
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Test")
    assert error.__cause__ is None
    assert error.__class__.__name__ == "ProgrammingError"
    assert str(error) == "Test"


# Generated at 2022-06-26 00:45:25.577606
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Test"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert str(e) == message


# Generated at 2022-06-26 00:45:27.396761
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error_raised = False
    try:
        raise ProgrammingError("Programming error")
    except:
        error_raised = True
    assert error_raised is True

# Generated at 2022-06-26 00:45:31.747205
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test passing the message when raising
    try:
        raise ProgrammingError("The condition is not met")
    except ProgrammingError as e:
        assert "The condition is not met" == str(e)

    # Test passing no message when raising
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)


# Generated at 2022-06-26 00:45:33.618176
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from expecter import expect

    try:
        raise ProgrammingError("Mau!")
    except ProgrammingError as e:
        expect(e.args[0]).to.contain("Mau")

# Generated at 2022-06-26 00:45:35.155110
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("message")
    except Exception as e:
        assert "message" in str(e)

# Generated at 2022-06-26 00:45:37.645203
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    error = ProgrammingError("test")
    assert "test" == str(error)



# Generated at 2022-06-26 00:45:39.287965
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something went wrong")
    except ProgrammingError as e:
        print(e)


# Generated at 2022-06-26 00:45:41.110644
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("foo")
    except ProgrammingError as e:
        assert e.args[0] == "foo"


# Generated at 2022-06-26 00:45:42.738790
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error!!")
    except ProgrammingError as error:
        assert str(error) == "Error!!"


# Generated at 2022-06-26 00:45:43.811849
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error=ProgrammingError("message")
    assert error.args[0]=="message"

# Generated at 2022-06-26 00:47:44.348320
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except ProgrammingError as ex:
        assert ex.__class__ is ProgrammingError
        assert ex.__module__ == "pypara.core"
        assert ex.__doc__ is ProgrammingError.__doc__
        assert ex.args == ("test",)


# Generated at 2022-06-26 00:47:44.888906
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("test")

# Generated at 2022-06-26 00:47:50.514457
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.common.errors import ProgrammingError

    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    try:
        raise ProgrammingError("foo")
    except ProgrammingError as error:
        assert str(error) == "foo"

    with raises(ProgrammingError):
        raise ProgrammingError("foo")

# Generated at 2022-06-26 00:47:51.936119
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("Some error occurs.")
    assert str(err) == "Some error occurs."



# Generated at 2022-06-26 00:47:54.778343
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "hello world"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert message == str(e)
        assert message == e.args[0]
    else:
        assert False, "should not be reached"


# Generated at 2022-06-26 00:48:02.936282
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Test without message
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        # As the assertion must always raise the exception, we should never reach this point
        assert False, "Broken coherence. Check your code against domain logic to fix it."

    try:
        # Test with message
        ProgrammingError.passert(False, "It should be True")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        # As the assertion must always raise the exception, we should never reach this point
        assert False, "Broken coherence. Check your code against domain logic to fix it."

   

# Generated at 2022-06-26 00:48:04.805760
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="A problem has been detected.")
    except ProgrammingError as e:
        assert str(e) == "A problem has been detected."

# Generated at 2022-06-26 00:48:06.249410
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    print("ProgrammingError passed!")

# Generated at 2022-06-26 00:48:08.898200
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
        assert False
    except Exception:
        assert False
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        assert True

# Unit test the class name

# Generated at 2022-06-26 00:48:10.454382
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        assert True
    except:
        assert False
