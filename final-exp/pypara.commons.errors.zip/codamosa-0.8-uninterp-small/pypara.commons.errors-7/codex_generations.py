

# Generated at 2022-06-26 00:41:18.601714
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:22.583107
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except Exception as e:
        if str(type(e)) != "<class 'pypara.error.ProgrammingError'>":
            raise AssertionError("Excepted <class 'pypara.error.ProgrammingError'>, but got {}".format(str(type(e))))
        return 0
    raise AssertionError("Excepted to raise ProgrammingError")

# Generated at 2022-06-26 00:41:30.975550
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    assert isinstance(programming_error_0, Exception)
    assert isinstance(programming_error_0, ProgrammingError)
    assert not programming_error_0
    assert str(programming_error_0) == "Unknown error."
    assert repr(programming_error_0) == "<ProgrammingError: Unknown error.>"
    assert programming_error_0.args == ("Unknown error.",)
    programming_error_0.args == ("Unknown error.",)
    programming_error_0.__cause__ is None
    programming_error_0.__context__ is None
    programming_error_1 = ProgrammingError("error description")
    assert isinstance(programming_error_1, Exception)
    assert isinstance(programming_error_1, ProgrammingError)
    assert not programming_error_

# Generated at 2022-06-26 00:41:31.818751
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()


# Generated at 2022-06-26 00:41:33.551968
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    print("Running test_ProgrammingError")
    try:
        test_case_0()
        assert False
    except ProgrammingError as error:
        assert True


# Generated at 2022-06-26 00:41:35.324746
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
        print('Test case 0: Pass')
    except:
        print('Test case 0: Fail')
    pass


# Generated at 2022-06-26 00:41:37.600975
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Check if the class :py:class:`ProgrammingError` behaves as expected.
    """
    test_case_0()

# Generated at 2022-06-26 00:41:38.883121
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError().args == ()
    assert ProgrammingError("dummy").args == ("dummy",)

# Generated at 2022-06-26 00:41:39.912499
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        test_case_0()


# Generated at 2022-06-26 00:41:41.952982
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as exception:
        assert isinstance(exception, Exception)


# Generated at 2022-06-26 00:41:44.656494
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()


# Generated at 2022-06-26 00:41:48.148540
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
        assert False
    except ProgrammingError:
        pass
    except BaseException as e:
        print(e)
        assert False


# Generated at 2022-06-26 00:41:48.843149
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-26 00:41:50.583680
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass



# Generated at 2022-06-26 00:41:54.623016
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.testcommon.fixtures import ProgrammingErrorFixture

    programming_error_0 = ProgrammingErrorFixture.create_valid_0()

    try:
        programming_error_0.passert(False, "Error!")
        assert False
    except ProgrammingError:
        pass
    else:
        assert False

# Generated at 2022-06-26 00:41:55.403439
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()

# Generated at 2022-06-26 00:41:56.181554
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:59.273660
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error = ProgrammingError()
    assert programming_error



# Generated at 2022-06-26 00:42:00.073510
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:42:00.918460
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()


# Generated at 2022-06-26 00:42:04.954106
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        test_case_0()



# Generated at 2022-06-26 00:42:08.213535
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(ProgrammingError(), ProgrammingError)
    assert isinstance(ProgrammingError(), Exception)
    assert isinstance(ProgrammingError(), BaseException)


# Generated at 2022-06-26 00:42:09.044273
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:42:11.031506
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-26 00:42:12.690413
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_1 = ProgrammingError()

# Generated at 2022-06-26 00:42:13.592316
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error = ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise Exception("Expecting exception")


# Generated at 2022-06-26 00:42:14.891384
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError.__name__ == "ProgrammingError"
    test_case_0()

# Generated at 2022-06-26 00:42:16.348528
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert programming_error_0.args == ()


# Generated at 2022-06-26 00:42:18.264156
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError` constructor.
    """
    test_case_0()


# Generated at 2022-06-26 00:42:19.628747
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()

    except ProgrammingError:
        pass



# Generated at 2022-06-26 00:42:25.373910
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My exception message.")
    except ProgrammingError as e:
        assert e.args[0] == "My exception message."


# Generated at 2022-06-26 00:42:28.522923
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is a programming error")
    assert error.msg == "This is a programming error"
    assert error.__str__() == "Programming error: This is a programming error"

# Generated at 2022-06-26 00:42:31.862894
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest_fixtures as fixtures

    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "")
        ProgrammingError.passert(False, "foo")

# Generated at 2022-06-26 00:42:35.087947
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError should be declared abstract")



# Generated at 2022-06-26 00:42:37.980642
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():  # pragma: no cover
    """Unit test for exception ProgrammingError."""
    error = ProgrammingError("This is a programming error")
    assert error.args == ("This is a programming error",)

# Generated at 2022-06-26 00:42:41.505762
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test message")
        raise RuntimeError("Shouldn't reach this point.")
    except ProgrammingError as exc:
        print(exc.args)
        assert "Test message" in exc.args

# Generated at 2022-06-26 00:42:45.044425
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given
    error = "This is an error"
    # When
    subject = ProgrammingError.passert(True, error)
    # Then
    assert subject is None
    # When
    subject = ProgrammingError.passert(False, error)
    # Then
    assert error in str(subject)

# Generated at 2022-06-26 00:42:47.401805
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error.")
    except ProgrammingError as e:
        assert e.args[0] == "This is a programming error."


# Generated at 2022-06-26 00:42:54.287417
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Test if we can instantiate an error without message
    error = ProgrammingError()
    assert error is not None
    assert str(error) == ""
    assert repr(error) == "<ProgrammingError: ProgrammingError()>"

    # Test if we can instantiate an error with a message
    message = "Some message"
    error = ProgrammingError(message)
    assert error is not None
    assert str(error) == message
    assert repr(error) == "<ProgrammingError: ProgrammingError('{}')>".format(message)



# Generated at 2022-06-26 00:42:56.729983
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="Hello World")
    except:
        assert False, "Exception was not caught!"
    else:
        assert True, "Normal behavior is working!"

# Generated at 2022-06-26 00:43:05.342976
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:43:08.793005
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    # Testing standard constructor
    pe = ProgrammingError("Some message")
    assert pe.args == ("Some message",)



# Generated at 2022-06-26 00:43:11.403297
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError()
    assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-26 00:43:15.527192
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def testit_message():
        try:
            raise ProgrammingError()
        except ProgrammingError as e:
            assert "" == str(e)
    testit_message()

    def testit_message2():
        try:
            raise ProgrammingError("Error message.")
        except ProgrammingError as e:
            assert "Error message." == str(e)
    testit_message2()

# Generated at 2022-06-26 00:43:17.123751
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:43:18.546489
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
        assert False
    except ProgrammingError:
        assert True

# Generated at 2022-06-26 00:43:20.581250
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test exception")
    except ProgrammingError as e:
        assert "This is a test exception" == str(e)


# Generated at 2022-06-26 00:43:23.169061
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert isinstance(ProgrammingError(), ProgrammingError)


# Generated at 2022-06-26 00:43:27.424659
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error message.")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)
        assert str(e) == "This is an error message."


# Generated at 2022-06-26 00:43:29.710138
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "test"):
        pass
    try:
        with ProgrammingError.passert(False, None):
            pass
    except ProgrammingError:
        pass
    else:
        assert False

# Generated at 2022-06-26 00:43:44.720340
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "This should raise a ProgrammingError")


# Generated at 2022-06-26 00:43:49.436042
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    from pypara import __pkg__, __version__
    import re

    # Act
    e = ProgrammingError()

    # Assert
    msg = "Broken coherence. Check your code against domain logic to fix it."
    assert e.args[0] == msg
    assert re.match(r"^pypara\s{}\({}\):\s".format(__version__, __pkg__), e.args[1])
    assert e.args[2] == msg


# Generated at 2022-06-26 00:43:50.579501
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("test_ProgrammingError"):
        pass


# Generated at 2022-06-26 00:43:52.481902
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Foo")
    except ProgrammingError as e:
        assert e.args == ("Foo", )


# Generated at 2022-06-26 00:43:55.285261
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message"
        return
    raise Exception("Should have raised exception")


# Generated at 2022-06-26 00:43:58.905443
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    error = "Test error"
    with raises(ProgrammingError) as error_raised:
        raise ProgrammingError(error)

    # Check correct error is raised
    assert error_raised.type is ProgrammingError
    assert error_raised.value.args[0] == error



# Generated at 2022-06-26 00:44:04.602731
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Expectation wasn't fulfilled")
    except ProgrammingError as e:
        assert e.args == ("Expectation wasn't fulfilled",)

# Generated at 2022-06-26 00:44:08.329986
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Testing constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:44:09.502607
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Error message")
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:44:11.298753
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("No such file or directory")
    assert str(e) == "No such file or directory"


# Generated at 2022-06-26 00:44:35.026068
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError(message="Test")
    except ProgrammingError as error:
        assert error.args[0] == "Test"
    else:
        assert False


# Generated at 2022-06-26 00:44:38.562257
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Should have caused an error to be raised"

# Unit tests for the passert method

# Generated at 2022-06-26 00:44:40.727411
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as exc:
        assert str(exc) == "Error message"


# Generated at 2022-06-26 00:44:43.609957
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        assert True
        raise ProgrammingError("If this exception is raised, there is a problem in our code!")
    except ProgrammingError:
        assert True


# Generated at 2022-06-26 00:44:44.894015
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:44:47.276423
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("something went wrong")
    except ProgrammingError as e:
        assert str(e) == "something went wrong"


# Generated at 2022-06-26 00:44:48.096266
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Programming error detected")

# Generated at 2022-06-26 00:44:50.511402
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of :py:class:`ProgrammingError`.
    """
    error = ProgrammingError("Testing")

    assert error.__str__() == "Testing"

# Generated at 2022-06-26 00:44:51.439268
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError()

# Generated at 2022-06-26 00:45:00.000769
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Should pass without raising an exception
    ProgrammingError.passert(True, None)
    ProgrammingError.passert(True, "")
    ProgrammingError.passert(True, "blah")

    # Should raise an exception with right error message
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(False, "something wrong")
        assert False
    except ProgrammingError as e:
        assert e

# Generated at 2022-06-26 00:45:53.809385
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing exception message")
        assert False
    except ProgrammingError as pe:
        assert pe.args[0] == "Testing exception message"

# Generated at 2022-06-26 00:45:55.858299
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test programming error")
    except ProgrammingError as pe:
        assert str(pe) == "Test programming error"


# Generated at 2022-06-26 00:45:56.865899
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Message"):
        pass


# Generated at 2022-06-26 00:45:58.847559
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("my custom error message")
    except ProgrammingError as e:
        assert e.args[0] == "my custom error message"
    return True

# Generated at 2022-06-26 00:45:59.287596
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError

# Generated at 2022-06-26 00:46:04.624011
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Should not raise assertion error
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError as e:
        assert False, "This assertion is not supposed to raise an exception and it did.".format(e)
    # Should raise assertion error
    caught = False
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        caught = True
    assert caught, "ProgrammingError.passert should have raised an exception but it did not."

# Generated at 2022-06-26 00:46:09.084780
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "OK"):
        pass
    try:
        with ProgrammingError.passert(False, "Expected error"):
            pass
        assert False, "The programming error was not raised"
    except ProgrammingError as e:
        assert str(e)=="Expected error", "The error message is not the expected one"

# Generated at 2022-06-26 00:46:16.135802
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test that the constructor of class :py:class:`ProgrammingError` raises the appropriate exception."""

    # Test for no message
    try:
        raise ProgrammingError()
    except ProgrammingError as exc:
        assert exc.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "Expected ProgrammingError exception to be raised"

    # Test for message
    message = "Some message"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as exc:
        assert exc.args[0] == message
    else:
        assert False, "Expected ProgrammingError exception to be raised"


# Generated at 2022-06-26 00:46:23.476891
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyUnusedLocal
    def dummy_function(x: int, y: int) -> int:
        raise ProgrammingError("Oops, something is wrong with this function")

    # noinspection PyUnusedLocal
    def passert_function(x: int, y: int) -> int:
        ProgrammingError.passert(False, "Oops, something is wrong with this function")

    # noinspection PyUnresolvedReferences
    from cmd2 import Cmd
    from pypara import Console, console_app

    # Verify that the programming error does not interfere on the normal flow of the console application

# Generated at 2022-06-26 00:46:32.077611
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # This should not raise an exception
        ProgrammingError.passert(True, "This is a test message")
    except ProgrammingError:
        assert False, 'ProgrammingError.passert should not have raised an exception.'
    try:
        # This should raise an exception
        ProgrammingError.passert(False, "This is a test message")
        assert False, 'ProgrammingError.passert should have raised an exception.'
    except ProgrammingError:
        pass
    try:
        # This should not raise an exception (no message)
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        assert False, 'ProgrammingError.passert should not have raised an exception.'

# Generated at 2022-06-26 00:48:31.658630
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test suite for :py:class:`ProgrammingError` constructor.
    """
    try:
        ProgrammingError(message="Expected exception")
    except ProgrammingError:
        pass
    else:
        assert False, "ValueError exception not raised. Test failed."

# Generated at 2022-06-26 00:48:32.101065
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-26 00:48:33.401709
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)


# Generated at 2022-06-26 00:48:35.385243
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for the constructor of class ProgrammingError.
    """
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Test")


# Generated at 2022-06-26 00:48:36.978472
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence" in str(e)


# Generated at 2022-06-26 00:48:38.367162
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-26 00:48:40.566737
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("You have a bug!")
    except ProgrammingError as pe:
        assert str(pe) == "You have a bug!"
    else:
        assert False, "ProgrammingError should have been raised"


# Generated at 2022-06-26 00:48:42.818338
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test exception")
    except ProgrammingError as ex:
        assert str(ex) == "Test exception"


# Generated at 2022-06-26 00:48:51.342603
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "error")
    except ProgrammingError as x:
        assert "error" == str(x)
    except Exception as x:
        throw_away = str(x)
        assert False, "Wrong exception"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as x:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(x)
    except Exception as x:
        throw_away = str(x)
        assert False, "Wrong exception"
    try:
        ProgrammingError.passert(True, None)
    except Exception as x:
        throw_away = str(x)
        assert False, "Wrong exception"

# Generated at 2022-06-26 00:48:53.671981
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("foobar")
    except ProgrammingError as e:
        assert "foobar" in str(e), "Expected string not in exception message"
    else:
        assert False, "Exception expected"