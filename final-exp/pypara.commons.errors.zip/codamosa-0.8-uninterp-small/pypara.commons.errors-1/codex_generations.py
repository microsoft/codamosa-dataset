

# Generated at 2022-06-26 00:41:20.115806
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(ProgrammingError(), ProgrammingError)

# Generated at 2022-06-26 00:41:24.052542
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase
    try:
        test_case_0()
        assert False, "No exception raised."
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)
        assert str(e) == ""
    else:
        assert False, "No exception raised."


# Generated at 2022-06-26 00:41:25.828752
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert str(ProgrammingError()) == 'Broken coherence. Check your code against domain logic to fix it.'


# Generated at 2022-06-26 00:41:28.146063
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except Exception as exception:
        assert False, "The constructor of ProgrammingError threw an exception: " + str(exception)


# Generated at 2022-06-26 00:41:28.919758
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError



# Generated at 2022-06-26 00:41:30.300751
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest  # type: ignore
    with pytest.raises(ProgrammingError):
        test_case_0()

# Generated at 2022-06-26 00:41:31.538247
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()


# Generated at 2022-06-26 00:41:32.499933
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(ProgrammingError(), ProgrammingError)



# Generated at 2022-06-26 00:41:33.708743
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except Exception as exception:
        assert False



# Generated at 2022-06-26 00:41:35.229289
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except ProgrammingError as e:
        assert True


# Generated at 2022-06-26 00:41:39.485246
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Foo bar baz")
    except ProgrammingError as e:
        assert e.__cause__ is None
        assert e.__traceback__ is not None
        assert str(e) == "Foo bar baz"


# Generated at 2022-06-26 00:41:41.798413
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    message = "My message"
    # Act
    exception = ProgrammingError(message)
    # Assert
    assert exception.args[0] == message


# Generated at 2022-06-26 00:41:44.043044
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("message")
    except ProgrammingError as e:
        assert str(e) == "message", f"Expected 'message', got {str(e)}"



# Generated at 2022-06-26 00:41:52.987968
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Check constructor and class attributes.
    for message in ["This is an error with a given message.", "And this is another.", "", None]:
        error = ProgrammingError(message)
        assert error.args == (message,)

    # Check class method 'passert'.
    for condition, message in [(False, "This is an error message."),
                               (False, ""),
                               (False, None),
                               (True, "Nothing happens if the condition is true.")]:
        if condition:
            ProgrammingError.passert(condition, message)
        else:
            try:
                ProgrammingError.passert(condition, message)
            except ProgrammingError as ex:
                assert ex.args == (message,)

# Generated at 2022-06-26 00:41:55.293557
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "foo")
    except ProgrammingError as e:
        assert e.args[0] == "foo"


# Generated at 2022-06-26 00:42:01.268746
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    expected_message = "Broken coherence. Check your code against domain logic to fix it."

    # Act
    try:
        ProgrammingError(expected_message)
    except ProgrammingError as exception:
        actual_message = str(exception)

    # Assert
    assert expected_message == actual_message

# Generated at 2022-06-26 00:42:03.306171
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Mock error")


# Generated at 2022-06-26 00:42:04.385468
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError("A programming error occurred")

# Generated at 2022-06-26 00:42:06.331569
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from nose.tools import assert_raises

    with assert_raises(ProgrammingError):
        raise ProgrammingError("Bad code")



# Generated at 2022-06-26 00:42:09.243934
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Terrible things happen.")
    except ProgrammingError:
        return
    assert False


# Generated at 2022-06-26 00:42:14.533815
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Boom")
    except ProgrammingError as error:
        assert error.args[0] == "Boom"


# Generated at 2022-06-26 00:42:18.380449
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("foo")
        assert False, "ProgrammingError constructor did not raise exception."
    except ProgrammingError:
        pass

    try:
        raise ProgrammingError
        assert False, "ProgrammingError constructor did not raise exception."
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:42:20.773385
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the constructor of :py:class:`ProgrammingError` raises the expected exception.
    """
    try:
        raise ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-26 00:42:23.667491
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Check that :py:class:`ProgrammingError` is raising the assertion_error."""
    ProgrammingError.passert(False, None)

# Generated at 2022-06-26 00:42:26.551756
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test :py:class:`ProgrammingError` constructor.
    """
    msg = "msg"
    err = ProgrammingError(msg)
    assert err.args == (msg,)


# Generated at 2022-06-26 00:42:30.582196
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class :py:class:`ProgrammingError`.
    """

    try:
        raise ProgrammingError("test message")
    except ProgrammingError as error:
        assert error.args == ("test message",)


# Generated at 2022-06-26 00:42:31.548103
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("This is a message")

# Generated at 2022-06-26 00:42:34.740645
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "This is the error message"
    try:
        ProgrammingError(message)
    except ProgrammingError as ex:
        assert ex.args[0] == message

# Generated at 2022-06-26 00:42:38.615082
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of class ProgrammingError.
    :return: Nothing
    """
    # Arrange
    message = "Test message"

    # Act and assert
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert message == str(e)

# Generated at 2022-06-26 00:42:44.225122
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class B:

        @classmethod
        def test_1(cls):
            try:
                raise ProgrammingError()
            except ProgrammingError:
                pass

        @classmethod
        def test_2(cls):
            try:
                raise ProgrammingError("Nah")
            except ProgrammingError as e:
                assert(e.args[0] == "Nah")

    B.test_1()
    B.test_2()



# Generated at 2022-06-26 00:42:55.707453
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError()
    assert isinstance(exception, Exception)
    assert issubclass(ProgrammingError, Exception)
    assert exception.args == tuple()


# Generated at 2022-06-26 00:42:57.034174
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "test message")

# Generated at 2022-06-26 00:42:59.431815
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error just for testing purposes.")
    except ProgrammingError as error:
        assert error.message == "Error just for testing purposes."


# Generated at 2022-06-26 00:43:01.541443
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-26 00:43:03.519802
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError("Wrong class definition because...")
    except ProgrammingError:
        pass



# Generated at 2022-06-26 00:43:05.038684
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing purpose.")
    except ProgrammingError as e:
        assert "Testing purpose." == str(e)


# Generated at 2022-06-26 00:43:07.540026
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError"""
    try:
        ProgrammingError("A dummy message")
    except ProgrammingError as e:
        assert "A dummy message" == str(e)
    else:
        raise AssertionError("The exception ProgrammingError should have been raised")


# Generated at 2022-06-26 00:43:10.463549
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, Exception)
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-26 00:43:12.967963
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e
        assert issubclass(type(e), ProgrammingError)
        assert issubclass(type(e), Exception)


# Generated at 2022-06-26 00:43:14.267319
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("test")
    assert str(error) == "test"

# Generated at 2022-06-26 00:43:30.591168
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "It should fail")
    except Exception as exception:
        assert isinstance(exception, ProgrammingError)
        assert exception.__doc__.endswith("to fix it.")
        assert str(exception).startswith("Broken coherence")
    else:
        raise AssertionError



# Generated at 2022-06-26 00:43:31.621160
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Test-message"):
        pass

# Generated at 2022-06-26 00:43:32.210327
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("message")


# Generated at 2022-06-26 00:43:40.299735
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Testing ProgrammingError")
    except ProgrammingError:
        pass
    else:
        assert False, "Did not raise expected exception"



# Generated at 2022-06-26 00:43:42.418104
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError, match="broken"):
        ProgrammingError("broken")


# Generated at 2022-06-26 00:43:44.899555
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(condition=True, message=None)
    ProgrammingError.passert(condition=False, message=None)
    ProgrammingError.passert(condition=False, message='msg')

# Generated at 2022-06-26 00:43:47.593387
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Unit test")
    except ProgrammingError as e:
        assert e.args == ("Unit test", )
    else:
        raise Exception("Test failed.")


# Generated at 2022-06-26 00:43:49.955134
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-26 00:43:55.666416
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit tests for constructor of class :py:class:`ProgrammingError`.

    :return: ``None``
    """
    try:
        ProgrammingError.passert(False, "Not condition")
    except ProgrammingError as ex:
        assert ex.args[0] == "Not condition"
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as ex:
        assert ex.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:43:58.037060
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:44:21.869059
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.

    :return: ``None``
    """
    ProgrammingError(message="This is an expected exception")


# Generated at 2022-06-26 00:44:24.096421
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError, match=".*coherence.*"):
        ProgrammingError.passert(False, None)



# Generated at 2022-06-26 00:44:25.848397
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-26 00:44:28.749865
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError` class.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError('ProgrammingError constructor did not work.')


# Generated at 2022-06-26 00:44:30.671856
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as exception:
        raise ProgrammingError("A programming error")
    assert str(exception.value) == "A programming error"


# Generated at 2022-06-26 00:44:36.629581
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # TypeError
    try:
        raise ProgrammingError(None)
    except TypeError:
        pass
    # TypeError
    try:
        raise ProgrammingError(1)
    except TypeError:
        pass
    # TypeError
    try:
        raise ProgrammingError(1.0)
    except TypeError:
        pass
    # TypeError
    try:
        raise ProgrammingError([])
    except TypeError:
        pass
    # TypeError
    try:
        raise ProgrammingError({})
    except TypeError:
        pass
    # TypeError
    try:
        raise ProgrammingError(("a", "b"))
    except TypeError:
        pass
    # TypeError
    try:
        raise ProgrammingError("")
    except TypeError:
        pass
    # TypeError

# Generated at 2022-06-26 00:44:38.437751
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()

# Generated at 2022-06-26 00:44:40.947839
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class A(ProgrammingError):
        pass
    try:
        A.passert(False, "Failed.")
        assert False
    except A:
        assert True

# Generated at 2022-06-26 00:44:41.867855
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("test")

# Generated at 2022-06-26 00:44:49.753901
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test if a ProgrammingError is raised with a custom message
    try:
        raise ProgrammingError("custom message")
    except ProgrammingError as error:
        assert error.args[0] == "custom message"
    # Test if a ProgrammingError is raised by programmer error
    try:
        raise ProgrammingError.passert(False, "custom message")
    except ProgrammingError as error:
        assert error.args[0] == "custom message"
    # Test if a ProgrammingError is not raised by programmer error
    try:
        raise ProgrammingError.passert(True, "custom message")
    except ProgrammingError as error:
        raise AssertionError(f"ProgrammingError was not expected here: {error}")

# Generated at 2022-06-26 00:45:41.778143
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given
    message = "Foo"

    # When
    error = ProgrammingError(message)

    # Then
    assert error.args[0] == message


# Generated at 2022-06-26 00:45:46.166462
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("error message")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)

    try:
        raise ProgrammingError("error message")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert e.args is not None
        assert "error message" in e.args


# Generated at 2022-06-26 00:45:48.910552
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError()
    assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    e = ProgrammingError("Test message.")
    assert str(e) == "Test message."



# Generated at 2022-06-26 00:45:51.471322
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    message = "hello"

    # Act
    error = ProgrammingError(message)

    # Assert
    assert message == error.args[0]


# Generated at 2022-06-26 00:45:54.980478
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    expected_msg = "Broken coherence. Check your code against domain logic to fix it."

    # Act
    try:
        raise ProgrammingError()

    # Assert
    except ProgrammingError as exc:
        assert expected_msg == str(exc)
    else:
        assert False, "Expected exception not raised"


# Generated at 2022-06-26 00:45:56.876712
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError has not been raised"


# Generated at 2022-06-26 00:45:59.118925
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        msg = "Programming error message"
        ProgrammingError.passert(False, msg)
        assert False
    except ProgrammingError as e:
        assert e.args == (msg,)

# Generated at 2022-06-26 00:46:01.545101
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given
    expected_message = "Just some test"

    # When
    exception = ProgrammingError(expected_message)

    # Then
    assert exception.args == (expected_message,)


# Generated at 2022-06-26 00:46:03.544571
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Constructor of class ProgrammingError must raise an exception"

# Generated at 2022-06-26 00:46:07.478116
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if the default constructor of :py:class:`ProgrammingError` sets the default error message.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-26 00:48:06.274086
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
       assert True


# Generated at 2022-06-26 00:48:07.788496
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Test")


# Generated at 2022-06-26 00:48:09.709917
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("this is a test")
    except ProgrammingError as e:
        assert str(e) == "this is a test"


# Generated at 2022-06-26 00:48:10.945088
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(None)


# Generated at 2022-06-26 00:48:13.753341
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "broken")
    except ProgrammingError as e:  # type: ignore
        assert e.args == ("broken",)


# Generated at 2022-06-26 00:48:15.224836
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-26 00:48:17.233062
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("TEST")
    except ProgrammingError as e:
        assert str(e) == "TEST"

# Generated at 2022-06-26 00:48:19.129764
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    error = ProgrammingError()
    assert error.args[0] == 'Broken coherence. Check your code against domain logic to fix it.'


# Generated at 2022-06-26 00:48:22.276401
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for method :py:meth:`ProgrammingError.__init__`.
    """
    try:
        raise ProgrammingError("Error message.")
    except ProgrammingError as exception:
        assert str(exception) == "Error message."


# Generated at 2022-06-26 00:48:22.948832
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="Error message")