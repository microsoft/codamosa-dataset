

# Generated at 2022-06-26 00:41:23.028259
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
        assert True
    except:
        assert False


# Generated at 2022-06-26 00:41:24.224583
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:26.568781
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."



# Generated at 2022-06-26 00:41:28.782213
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert err.args == ()
    else:
        assert False, "ProgrammingError constructor should have raised an exception"


# Generated at 2022-06-26 00:41:30.167899
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:41:31.927953
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert test_case_0() is None

if __name__ == "__main__":
    test_ProgrammingError()
    print("Everything passed")

# Generated at 2022-06-26 00:41:33.137966
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as programming_error:
        pass


# Generated at 2022-06-26 00:41:34.906089
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Error: Expected Exception did not occur.")

# Generated at 2022-06-26 00:41:40.477832
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pyhpeimc.auth import IMCAuth
    #invalid_url = "http://100.100.100.100"   # bad url
    #pysimple = IMCAuth(url=invalid_url)
    #imc_cred = {'username': 'admin', 'password' : 'admin'}
    #invalid_auth = pysimple.login(imc_cred)
    #invalid_uri = "http://localhost/imcrs/plat/res/type/server/status?resPrivilegeFilter=false&ip=1.1.1.1"
    #monitor = PySimpleGUI(url=invalid_url, auth=invalid_auth)
    #out = monitor.get_server_status(uri=invalid_uri)
    #if out is False:
    #

# Generated at 2022-06-26 00:41:42.334313
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(1 == 2, message="Undefined error message")
    except ProgrammingError:
        print("ProgrammingError: Undefined error message")

# Generated at 2022-06-26 00:41:47.972911
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # noinspection PyStatementEffect
        ProgrammingError("Should not have been be called")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Should not have been be called"


# Generated at 2022-06-26 00:41:50.879746
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert type(e) is ProgrammingError
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:41:54.622163
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Success
    try:
        ProgrammingError.passert(True, "Success")
    except ProgrammingError as exc:
        raise AssertionError(exc)
    # Failure
    try:
        ProgrammingError.passert(False, "Failure")
        raise AssertionError()
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:41:56.280009
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error.message == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:41:59.274667
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Test"):
        pass

# Generated at 2022-06-26 00:42:00.377305
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(condition=False, message="Test message")

# Generated at 2022-06-26 00:42:02.398325
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit tests for the constructor of class `ProgrammingError`."""
    error = ProgrammingError("test")
    assert error.args == ("test",)

# Generated at 2022-06-26 00:42:08.463397
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError` and its :py:meth:`ProgrammingError.passert <passert>`
    static method.
    """
    try:
        raise ProgrammingError("Testing the constructor.")
    except ProgrammingError as e:
        assert (
            str(e) == "Testing the constructor." and
            e.__cause__ is None
        ), "ProgrammingError has to keep the message and not to have a cause."


# Generated at 2022-06-26 00:42:16.619451
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara.testing.tools import assert_exception_message, assert_same_type

    assert_exception_message(ProgrammingError, None, "Default message")
    assert_exception_message(ProgrammingError, "User message", "User message")

    assert_same_type(ProgrammingError, ProgrammingError.passert(True, None), None)
    assert_exception_message(ProgrammingError, ProgrammingError.passert(False, None),
                             "Broken coherence. Check your code against domain logic to fix it.")
    assert_exception_message(ProgrammingError, ProgrammingError.passert(False, "User message"), "User message")

# Generated at 2022-06-26 00:42:18.757624
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something bad happened.")
    except ProgrammingError as error:
        assert error.args[0] == "Something bad happened."


# Generated at 2022-06-26 00:42:25.745583
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pyassert import assert_that
    from pyassert.exception_matchers import has_message

    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert_that(e, has_message("Broken coherence. Check your code against domain logic to fix it."))

# Generated at 2022-06-26 00:42:27.712053
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True


# Generated at 2022-06-26 00:42:31.091716
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("There was an error.")
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == "There was an error."


# Generated at 2022-06-26 00:42:35.398744
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError, match="^Broken coherence"):
        ProgrammingError.passert(False, None)
    with pytest.raises(ProgrammingError, match="^The message"):
        ProgrammingError.passert(False, "The message")

# Generated at 2022-06-26 00:42:38.381073
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("example text of error")
    except ProgrammingError as e:
        assert e.args[0] == "example text of error"


# Generated at 2022-06-26 00:42:40.712698
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False,None)

# Generated at 2022-06-26 00:42:43.858005
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(None)

    with pytest.raises(ProgrammingError):
        ProgrammingError("")

    with pytest.raises(ProgrammingError):
        ProgrammingError("A message")



# Generated at 2022-06-26 00:42:49.229892
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the functionality of :py:class:`ProgrammingError`.
    """
    ProgrammingError(None)
    ProgrammingError("")
    ProgrammingError("Something")
    with assertRaises(ProgrammingError):
        raise ProgrammingError("Something")
    with assertRaises(ProgrammingError):
        ProgrammingError.passert(False, "Something")
    ProgrammingError.passert(True, "Something")


# Generated at 2022-06-26 00:42:56.980749
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert "test" == str(e)
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)


# Generated at 2022-06-26 00:42:59.741170
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN
    # WHEN
    error = ProgrammingError()

    # THEN
    assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:43:06.164186
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("failing intentionally by unit test")
    except ProgrammingError as e:
        assert str(e) == "failing intentionally by unit test"


# Generated at 2022-06-26 00:43:08.541638
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "It failed")
        assert False, "ProgrammingError did not fail as expected"
    except ProgrammingError as exception:
        assert str(exception) == "It failed", \
               "Wrong error message: " + str(exception)


# Generated at 2022-06-26 00:43:09.351918
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:43:16.881932
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        return

assert test_ProgrammingError


# Generated at 2022-06-26 00:43:19.341259
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError()
    assert exception.args[0] == "Broken coherence. Check your code against domain logic to fix it."

    exception = ProgrammingError("Something is wrong!")
    assert exception.args[0] == "Something is wrong!"

# Generated at 2022-06-26 00:43:27.534563
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""

    # Testing error message
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert str(
            err) == "Broken coherence. Check your code against domain logic to fix it."

    # Testing error message with a custom message
    try:
        raise ProgrammingError("My custom message.")
    except ProgrammingError as err:
        assert str(
            err) == "My custom message."



# Generated at 2022-06-26 00:43:29.952753
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(2 == 3, "Should fail")
        assert False, "Should not reach this point"
    except ProgrammingError as e:
        assert e.args[0] == "Should fail"

# Generated at 2022-06-26 00:43:31.985957
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Message")
    except ProgrammingError as e:
        assert e.__str__() == "Message"


# Generated at 2022-06-26 00:43:40.777704
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "OK"):
        pass
    try:
        with ProgrammingError.passert(False, "OK"):
            pass
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)

# Generated at 2022-06-26 00:43:45.469065
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    err = ProgrammingError()
    assert isinstance(err, Exception)
    assert isinstance(err, ProgrammingError)
    assert issubclass(ProgrammingError, Exception)
    assert issubclass(ProgrammingError, Exception)
    assert str(err) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:43:59.119733
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    assert str(ProgrammingError()) == ""
    assert str(ProgrammingError("test")) == "test"
    ProgrammingError.passert(False, "test")

# Generated at 2022-06-26 00:44:04.734366
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "TEST")
    except ProgrammingError as e:
        assert str(e) == "TEST"
    else:
        assert False

# Generated at 2022-06-26 00:44:06.984875
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError):
        ProgrammingError("It is an error")

# Generated at 2022-06-26 00:44:11.109987
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Programming error for unit testing class ProgrammingError")
    except Exception as exc:
        assert isinstance(exc, ProgrammingError) and str(exc) == "Programming error for unit testing class ProgrammingError"
    except:
        assert False


# Generated at 2022-06-26 00:44:12.578164
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ()


# Generated at 2022-06-26 00:44:17.827979
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test error without message
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    else:
        raise AssertionError("'ProgrammingError()' did not raise an exception.")

    # Test error conditional with assertion
    try:
        ProgrammingError.passert(False, "foo")
    except ProgrammingError as e:
        assert e.args == ("foo",)
    else:
        raise AssertionError("'ProgrammingError.passert(False, \"foo\")' did not raise an exception.")

    # Test that the assertion works as expected
    ProgrammingError.passert(True, "foo")

# Generated at 2022-06-26 00:44:20.095216
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise Exception("Test failed: Expected exception to be raised.")


# Generated at 2022-06-26 00:44:21.200776
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("message")
    assert err.args[0] == "message"

# Generated at 2022-06-26 00:44:22.910618
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-26 00:44:26.395222
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error message")
    except ProgrammingError as e:
        assert str(e) == "This is an error message", "Failed to instantiate a ProgrammingError class"
    else:
        assert False, "Failed to raise a ProgrammingError class"

# Generated at 2022-06-26 00:44:47.782197
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`.
    """
    assert str(ProgrammingError("foo")) == "foo"

# Generated at 2022-06-26 00:44:48.612854
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-26 00:44:53.006106
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "TestMe")
        assert False
    except ProgrammingError as e:
        assert str(e) == "TestMe"
    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:44:55.459732
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "Throw dummy error.")

# Generated at 2022-06-26 00:44:57.544980
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the :py:class:`ProgrammingError` class.
    """
    e = ProgrammingError("error")
    assert e.args[0] == "error"

# Generated at 2022-06-26 00:44:59.596121
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`
    """
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError("MESSAGE")


# Generated at 2022-06-26 00:45:02.269283
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError(): # TODO: Tests for ProgrammingError.passert
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:45:04.946018
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with assert_raises_regex(ProgrammingError, "Check your code against domain logic to fix it."):
        ProgrammingError.passert(condition=False, message=None)

# Generated at 2022-06-26 00:45:13.547964
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Executes some test cases for the :py:class:`ProgrammingError` class.
    """
    from pytest import raises
    from ..logging import get_logger

    logger = get_logger(__name__)
    logger.info("Starting tests for the ProgrammingError class...")
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args == ("Domain logic error. Check your code against domain logic to fix it.",)


# Generated at 2022-06-26 00:45:15.049502
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "This is a programming error")

# Generated at 2022-06-26 00:46:12.455120
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error.")
    except ProgrammingError as e:
        assert str(e) == "This is an error."


# Generated at 2022-06-26 00:46:13.880813
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Programming error")
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:46:15.672400
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "This is an error"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert e.args[0] == message


# Generated at 2022-06-26 00:46:17.884450
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some error message")
    except ProgrammingError as e:
        assert e.args[0] == "Some error message"
    else:
        assert False, "Did not trigger exception"


# Generated at 2022-06-26 00:46:19.737453
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("N/A")
    except ProgrammingError as e:
        assert(e.__str__() == "N/A")

# Generated at 2022-06-26 00:46:21.306030
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-26 00:46:22.839745
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        ...
    finally:
        ...


# Generated at 2022-06-26 00:46:24.405338
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError.passert(condition=False, message="Broken coherence.")

# Generated at 2022-06-26 00:46:28.337612
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(None)

    with pytest.raises(ProgrammingError):
        ProgrammingError("")

    with pytest.raises(ProgrammingError):
        ProgrammingError("Message")

    try:
        ProgrammingError("Message")
    except ProgrammingError as e:
        assert str(e) == "Message"


# Generated at 2022-06-26 00:46:32.653960
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is the test message to raise an error")
    except ProgrammingError as e:
        assert e.args[0] == "This is the test message to raise an error"
        print("ProgrammingError is working as expected")
    else:
        raise AssertionError("No ProgrammingError raised.")

# Generated at 2022-06-26 00:48:27.500146
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as e:
        assert str(e) == "Error message"


# Generated at 2022-06-26 00:48:29.002815
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error message")
    except ProgrammingError as error:
        assert str(error) == "Error message"


# Generated at 2022-06-26 00:48:32.305791
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert e.args[0] == "Test message"
        assert str(e) == "Test message"
    except Exception:
        assert False, "Raised an exception other than ProgrammingError"


# Generated at 2022-06-26 00:48:34.640795
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("my message")
    except ProgrammingError as error:
        assert error.args[0] == "my message"
    else:
        assert False



# Generated at 2022-06-26 00:48:36.979424
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.error import ProgrammingError

    with raises(ProgrammingError):
        ProgrammingError.passert(condition=False, message="Boom!")
    ProgrammingError.passert(condition=True, message="Boom!")

# Generated at 2022-06-26 00:48:38.814694
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "This is a test")
    assert ProgrammingError.passert(True, "This is a test") is None

# Generated at 2022-06-26 00:48:39.633424
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Allowed instantiation
    Programm

# Generated at 2022-06-26 00:48:40.780797
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, None)

# Generated at 2022-06-26 00:48:42.620112
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except TypeError:
        pass
    except:
        raise



# Generated at 2022-06-26 00:48:45.567239
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Broken coherence.")
    except ProgrammingError as err:
        assert str(err) == "Broken coherence."
    else:
        assert False, "Expected to raise a ProgrammingError."
