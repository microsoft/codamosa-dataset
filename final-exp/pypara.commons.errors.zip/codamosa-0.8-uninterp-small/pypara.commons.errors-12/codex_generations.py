

# Generated at 2022-06-26 00:41:20.046178
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as e:
        assert str(e) == "", "the exception message does not correspond to the expected value"


# Generated at 2022-06-26 00:41:22.382404
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except Exception as e:
        if not isinstance(e, ProgrammingError):
            raise RuntimeError("Expected ProgrammingError") from e
    else:
        raise RuntimeError("Expected an exception")


# Generated at 2022-06-26 00:41:25.857047
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import time, sys
    print("\nTesting Construction of ProgrammingError object - start time: " + time.ctime())
    test_case_0()
    print("Testing Construction of ProgrammingError object - end time: " + time.ctime())


# Generated at 2022-06-26 00:41:27.889369
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)


# Unit tests for function ProgrammingError.passert

# Generated at 2022-06-26 00:41:28.613449
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert test_case_0() is None


# Generated at 2022-06-26 00:41:31.301105
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        # We shouldn't reach this point
        print("test_ProgrammingError - 1 failed")
    except ProgrammingError as e:
        print("test_ProgrammingError - 1 passed")


# Generated at 2022-06-26 00:41:32.532958
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Call constructor
    try:
        test_case_0()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:41:33.997345
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except Exception as e:
        assert False
    assert True



# Generated at 2022-06-26 00:41:34.783731
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError()



# Generated at 2022-06-26 00:41:40.170320
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError() as programming_error_1:
        print(f"programming_error_1 = {programming_error_1}")
        assert programming_error_1

        try:
            # noinspection PyTypeChecker
            ProgrammingError.passert(False, "")
        except ProgrammingError as programming_error_2:
            print(f"programming_error_2 = {programming_error_2}")
            assert programming_error_2

            try:
                raise programming_error_2
            except ProgrammingError as programming_error_3:
                print(f"programming_error_3 = {programming_error_3}")
                assert programming_error_3

# Test for __init__ of class ProgrammingError

# Generated at 2022-06-26 00:41:45.534035
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:46.864237
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:50.797332
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_1 = ProgrammingError()
    assert programming_error_1.__str__() == '' # TODO: correct?
    programming_error_2 = ProgrammingError("pc error msg")
    assert programming_error_2.__str__() == 'pc error msg' # TODO: correct?


# Generated at 2022-06-26 00:41:51.644457
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:53.855841
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as e:
        assert str(e) == ""
    else:
        raise Exception("Error not raised")



# Generated at 2022-06-26 00:41:54.885730
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:59.612771
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == ""


# Generated at 2022-06-26 00:42:01.383565
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()


if __name__ == "__main__":
    test_ProgrammingError()
    print("All tests passed!")

# Generated at 2022-06-26 00:42:08.061082
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # constructor test - 0
    try:
        programming_error_0 = ProgrammingError()
    except:
        programming_error_0 = None
    assert (programming_error_0 != None)
    # constructor test - 1
    try:
        programming_error_1_message = "dummy argument"
        programming_error_1 = ProgrammingError(programming_error_1_message)
    except:
        programming_error_1 = None
    assert (programming_error_1 != None)


# Generated at 2022-06-26 00:42:09.207254
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except:
        pass

# Generated at 2022-06-26 00:42:17.455708
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()
    ProgrammingError("test")
    ProgrammingError.passert(True, "test")
    try:
        ProgrammingError.passert(False, "test")
    except ProgrammingError as e:
        assert str(e) == "test"

# Generated at 2022-06-26 00:42:19.761875
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    with assert_raises(ProgrammingError):
        test_case_0()


# Generated at 2022-06-26 00:42:20.309079
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError()

# Generated at 2022-06-26 00:42:21.974481
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    assert programming_error_0.__str__() == ''


# Generated at 2022-06-26 00:42:26.312549
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError("Expectation error")

    ProgrammingError.passert(True, "")

    try:
        ProgrammingError.passert(False, "")
        raise AssertionError("Should not get here")
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:42:32.210850
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError('test_message_0')
    except Exception:
        assert False

    try:
        ProgrammingError.passert(False, 'test_message_1')
        assert False
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(True, 'test_message_1')
        pass
    except ProgrammingError:
        assert False

# Generated at 2022-06-26 00:42:35.399218
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass
    else:
        raise Exception("ProgrammingError not raised")


# Generated at 2022-06-26 00:42:39.420733
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, "TEST")
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:42:40.950162
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(ProgrammingError(), ProgrammingError)


# Generated at 2022-06-26 00:42:41.812181
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert programming_error_0

# Generated at 2022-06-26 00:42:49.869518
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hola mundo")
    except ProgrammingError as e:
        assert str(e) == "Hola mundo"


# Generated at 2022-06-26 00:42:52.395135
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error")
    except ProgrammingError as e:
        assert str(e) == "This is an error"



# Generated at 2022-06-26 00:42:54.588766
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "This is a test."
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as e:
        assert str(e) == msg


# Generated at 2022-06-26 00:42:56.656115
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("message")
    except ProgrammingError as error:
        assert error.args[0] == 'message'


# Generated at 2022-06-26 00:42:59.079883
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test")
    except ProgrammingError as e:
        assert str(e) == "Test"
        
test_ProgrammingError()

# Generated at 2022-06-26 00:43:01.300563
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, 'Test')
    except ProgrammingError as e:
        assert str(e)=='Test'

# Generated at 2022-06-26 00:43:03.579236
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected = "my message"
    try:
        ProgrammingError(expected)
    except ProgrammingError as err:
        assert expected == str(err)
    else:
        raise ProgrammingError(None)


# Generated at 2022-06-26 00:43:06.357367
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=unused-variable
    assert ProgrammingError



# Generated at 2022-06-26 00:43:08.317888
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing message")
    except ProgrammingError as err:
        assert str(err) == "Testing message"


# Generated at 2022-06-26 00:43:11.282347
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)
        assert isinstance(err, Exception)


# Generated at 2022-06-26 00:43:26.160524
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    error = ProgrammingError("Some error!")
    assert str(error) == "Some error!"


# Generated at 2022-06-26 00:43:29.769375
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # pylint: disable=unused-variable,unnecessary-lambda
        dummy = ProgrammingError(message="Message")
    except ProgrammingError:
        # pylint: disable=bare-except,broad-except
        raise AssertionError("ProgrammingError exception not raised")



# Generated at 2022-06-26 00:43:39.895815
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest.mock import patch

    # Test setup
    message = "test error"

    # Test constructor
    try:
        raise ProgrammingError(message)
    except ProgrammingError as error:
        # Test retrieval of message
        assert error.args == (message,)
        assert str(error) == message

        # Test retrieval of exception message
        with patch("pypara.error.Error.message", new=message):
            assert ProgrammingError.message == message

# Generated at 2022-06-26 00:43:41.426192
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Raised by test function.")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError constructor failed.")
    try:
        ProgrammingError(None)
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError constructor failed.")


# Generated at 2022-06-26 00:43:43.503263
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a message.")
    except ProgrammingError as e:
        assert str(e) == "This is a message."


# Generated at 2022-06-26 00:43:45.072331
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        raise ProgrammingError("Some variable was None.")

# Generated at 2022-06-26 00:43:46.120815
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exception = ProgrammingError("Testing")

# Generated at 2022-06-26 00:43:48.657500
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Test a programming error by raising it
        raise ProgrammingError()
        assert False
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:43:51.342014
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert str(e) == "This is a test"
    else:
        assert False, "Exception raised for test."


# Generated at 2022-06-26 00:43:52.385159
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError


# Generated at 2022-06-26 00:44:16.085612
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # We expect no exception to be raised
    ProgrammingError(ProgrammingError.__module__, ProgrammingError.__name__, "")


# Generated at 2022-06-26 00:44:18.001581
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("message")
    assert e.args == ("message",)
    assert str(e) == "message"


# Generated at 2022-06-26 00:44:20.562081
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, message="Test message!")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Test message!"


# Generated at 2022-06-26 00:44:22.217956
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error message")
    except ProgrammingError as err:
        assert str(err) == "This is an error message"

# Generated at 2022-06-26 00:44:25.999356
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        ProgrammingError("Hello!")
        ProgrammingError.passert(False, "Hello!")
    except ProgrammingError as e:
        assert str(e) == "Hello!"
    try:
        ProgrammingError.passert(False)
        raise RuntimeError("Should raise a ProgrammingError")
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:44:28.022982
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "This is not a problem")
    try:
        ProgrammingError.passert(False, "Failed test")
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:44:29.628461
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a message.")
    except ProgrammingError as e:
        assert "This is a message." == str(e)

# Generated at 2022-06-26 00:44:31.498586
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is a programming error.")
    except ProgrammingError as e:
        assert True
    else:
        assert False


# Generated at 2022-06-26 00:44:33.068366
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase

    assert issubclass(ProgrammingError, Exception)



# Generated at 2022-06-26 00:44:33.970240
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "This is a ProgrammingError."):
        pass

# Generated at 2022-06-26 00:45:19.394470
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "We see this message.")
        assert False, "We should not reach this line."
    except ProgrammingError as e:
        assert e.args[0] == "We see this message."

# Generated at 2022-06-26 00:45:20.370572
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is an exception")

# Generated at 2022-06-26 00:45:21.694167
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "My problem")

# Generated at 2022-06-26 00:45:25.724438
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the constructor of the class :py:class:`ProgrammingError`.
    """

    def _test_case(message: str):
        try:
            raise ProgrammingError(message)
        except ProgrammingError as error:
            assert error.args == (message,)

    # Test case
    _test_case("")
    _test_case("_")
    _test_case("Hello World")


# Generated at 2022-06-26 00:45:27.523191
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a message.")
    except ProgrammingError as e:
        assert str(e) == "This is a message."


# Generated at 2022-06-26 00:45:30.025892
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError, match = "Broken coherence. Check your code against domain logic to fix it."):
        ProgrammingError.passert(False, None)

# Generated at 2022-06-26 00:45:31.565396
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test that the constructor works
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass



# Generated at 2022-06-26 00:45:31.993802
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    pass

# Generated at 2022-06-26 00:45:33.975507
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error")
    except ProgrammingError as e:
        assert e.args[0] == "A programming error"


# Generated at 2022-06-26 00:45:41.963293
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the passert routine.
    """
    ProgrammingError.passert(True, None)
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError was not raised")

    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError was not raised")

    try:
        ProgrammingError.passert(False, "foo")
    except ProgrammingError as error:
        if error.args[0] != "foo":
            raise AssertionError("ProgrammingError was not raised with the correct message")
    else:
        raise AssertionError("ProgrammingError was not raised")

# Generated at 2022-06-26 00:47:41.958170
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(message="Fake message for test.")


# Generated at 2022-06-26 00:47:46.628924
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Does the constructor work as expected?"""
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert(str(e) == "Broken coherence. Check your code against domain logic to fix it.")

    try:
        raise ProgrammingError("Hello World!")
    except ProgrammingError as e:
        assert(str(e) == "Hello World!")


# Generated at 2022-06-26 00:47:48.303590
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("some error message")
    except ProgrammingError as e:
        assert str(e) == "some error message"


# Generated at 2022-06-26 00:47:50.661397
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-26 00:47:52.666745
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    try:
        ProgrammingError("This is a programming error.")
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:47:54.420584
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test error!")
    except ProgrammingError as exc:
        assert str(exc) == "Test error!"



# Generated at 2022-06-26 00:47:56.208089
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("foo")
    assert str(error) == "foo"

# Unit test implemented according to the template approach of UnitTests.rst

# Generated at 2022-06-26 00:47:59.110528
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError()

# Unit tests for method passert

# Generated at 2022-06-26 00:48:00.212694
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError(message="Testing"):
        pass


# Generated at 2022-06-26 00:48:02.303325
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError not raised")
