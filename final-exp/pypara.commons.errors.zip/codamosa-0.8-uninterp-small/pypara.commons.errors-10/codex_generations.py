

# Generated at 2022-06-26 00:41:18.653499
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError() is not None

# Generated at 2022-06-26 00:41:19.598775
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-26 00:41:21.742327
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert type(programming_error_0) == ProgrammingError
    assert programming_error_0.args == ()
    assert programming_error_0.__class__.__name__ == "ProgrammingError"

# Generated at 2022-06-26 00:41:30.134878
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        print("obj name: " + str(e.__class__.__name__))
        print("obj args: " + str(e.args))
        print("obj msg: " + str(e.__class__.__qualname__))
        print("obj msg: " + str(e.__doc__))
        print("obj msg: " + str(e.__module__))
        print("obj msg: " + str(repr(e)))
        print("obj msg: " + str(e))
        print("obj msg: " + str(e.message))


test_case_0()
test_ProgrammingError()

# Generated at 2022-06-26 00:41:32.662674
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test instantiation of class ProgrammingError
    try:
        instance_programming_error = ProgrammingError()
        assert(instance_programming_error)
    except:
        print("Instantiation of class ProgrammingError failed")



# Generated at 2022-06-26 00:41:33.357052
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:34.060938
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()


# Generated at 2022-06-26 00:41:35.067433
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(ProgrammingError(), ProgrammingError)


# Generated at 2022-06-26 00:41:37.680060
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert False
    except ProgrammingError as e:
        assert str(e) == ""
test_ProgrammingError()


# Generated at 2022-06-26 00:41:38.698946
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(programming_error_0, ProgrammingError)


# Generated at 2022-06-26 00:41:46.548629
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    from pypara.errors import ProgrammingError
    from pypara.common import test_module

    test_module(ProgrammingError)
    with pytest.raises(ProgrammingError.__class__) as exception:
        test_case_0()


# Generated at 2022-06-26 00:41:47.328008
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()


# Generated at 2022-06-26 00:41:50.711276
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
        assert False, "No exception raised"
    except ProgrammingError:
        # Success message
        pass
    except Exception:
        assert False, "Wrong exception raised"


# Generated at 2022-06-26 00:41:51.564133
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:56.110612
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Create instance of class ProgrammingError:
    programming_error_0 = ProgrammingError()
    # Check attribute 'message' of class ProgrammingError
    assert programming_error_0.message == ""
    # Create instance of class ProgrammingError:
    programming_error_1 = ProgrammingError("Hello world!")
    # Check attribute 'message' of class ProgrammingError
    assert programming_error_1.message == "Hello world!"

# Generated at 2022-06-26 00:41:59.575107
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert True
    except:
        assert False


# Generated at 2022-06-26 00:42:03.819379
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")

        # Should have raised ProgrammingError
        assert False
    except ProgrammingError:
        pass
    except:
        assert False

if __name__ == "__main__":
    # Run the unit tests
    test_ProgrammingError()

# Generated at 2022-06-26 00:42:05.776173
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        return
    raise AssertionError("ProgrammingError constructor failed")

# Generated at 2022-06-26 00:42:07.750622
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()



# Generated at 2022-06-26 00:42:09.201185
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    ProgrammingError.passert(True, None)


# Generated at 2022-06-26 00:42:15.551189
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass



# Generated at 2022-06-26 00:42:19.165234
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert str(ProgrammingError()) == "Broken coherence. Check your code against domain logic to fix it."
    assert str(ProgrammingError("error_0")) == "error_0"
    assert isinstance(ProgrammingError(), Exception)
    assert isinstance(ProgrammingError(), ProgrammingError)



# Generated at 2022-06-26 00:42:30.077430
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Case 0: construction ProgrammingError with no parameters
    try:
        test_case_0()
        assert 0 # Asserting this line should never be reached,
    except ProgrammingError:
        assert 1 # Check that an exception is raised
    with pytest.raises(ProgrammingError):
        test_case_0()

# Generated at 2022-06-26 00:42:32.528157
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert type(e) == ProgrammingError

# Unit Test for assert method of class ProgrammingError

# Generated at 2022-06-26 00:42:36.061114
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as e:
        assert str(e) == 'Broken coherence. Check your code against domain logic to fix it.'
    else:
        assert False


# Generated at 2022-06-26 00:42:38.117293
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:42:38.864906
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()


# Generated at 2022-06-26 00:42:44.102292
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError as pe:
        print(type(pe))
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as pe:
        print(type(pe))


# Unit test entry point
if __name__ == "__main__":
    test_case_0()
    test_ProgrammingError()

# Generated at 2022-06-26 00:42:45.043584
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError()



# Generated at 2022-06-26 00:42:52.126034
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:exc:`ProgrammingError`.
    """
    programming_error_1 = ProgrammingError()
    assert programming_error_1.args == ()

    programming_error_2 = ProgrammingError("Some message")
    assert programming_error_2.args == ("Some message",)

    assert str(programming_error_1) == "Broken coherence. Check your code against domain logic to fix it."
    assert str(programming_error_2) == "Some message"



# Generated at 2022-06-26 00:43:02.296784
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()


# Generated at 2022-06-26 00:43:05.706260
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import unittest

    class MyTestCase(unittest.TestCase):
        def test_constructor(self):
            try:
                test_case_0()
            except ProgrammingError as e:
                self.assertIsInstance(e, ProgrammingError)
                self.assertEqual(e.message, None)

    unittest.main(verbosity=2)

# Generated at 2022-06-26 00:43:07.761483
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # CASE 0:
    test_case_0()


# Run the tests
test_ProgrammingError()

# Generated at 2022-06-26 00:43:11.730859
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    programming_error_0 = ProgrammingError()
    assert isinstance(programming_error_0, ProgrammingError)
    assert str(programming_error_0) == 'Broken coherence. Check your code against domain logic to fix it.'

# Generated at 2022-06-26 00:43:13.528992
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-26 00:43:15.996367
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Case 0: Default constructor
    programming_error_0 = ProgrammingError()
    # Case 1: Constructor with message
    programming_error_1 = ProgrammingError("Error message")


# Generated at 2022-06-26 00:43:18.050922
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        print('ProgrammingError() FAILED')


# Generated at 2022-06-26 00:43:19.485448
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    assert isinstance(programming_error_0, ProgrammingError)


# Generated at 2022-06-26 00:43:21.338369
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:43:26.738577
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given some value
    e = None

    # When I create an exception
    try:
        test_case_0()
    except Exception as excep:
        e = excep

    # Then I expect a specific class of exception to be raised
    assert isinstance(e, ProgrammingError)


# Generated at 2022-06-26 00:43:40.884892
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:43:41.767998
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError()



# Generated at 2022-06-26 00:43:43.191271
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert str(ProgrammingError()) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:43:43.984934
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()


# Generated at 2022-06-26 00:43:45.885947
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from .exceptions import ProgrammingError

    with raises(ProgrammingError):
        ProgrammingError()

# Generated at 2022-06-26 00:43:48.622582
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except Exception:
        pass
    else:
        assert False, "Should raise exception"


# Generated at 2022-06-26 00:43:51.306275
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert (ProgrammingError) is not (Exception)
    programming_error_0 = None
    try:
        programming_error_0 = ProgrammingError()
    except:
        assert False
    assert programming_error_0 is not None


# Generated at 2022-06-26 00:44:03.600942
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError.__name__ == "ProgrammingError"
    assert ProgrammingError.__module__ == "pypara.core.common"
    assert ProgrammingError.__qualname__ == "ProgrammingError"
    assert ProgrammingError.__doc__ == "Provides a programming error exception.\n\nThe rationale for this " \
                                       "exception is to raise them whenever we rely on meta-programming and " \
                                       "the programmer has\nintroduced a statement which breaks the coherence of " \
                                       "the domain logic."
    assert ProgrammingError.__init__.__qualname__ == "ProgrammingError.__init__"
    assert ProgrammingError.__bases__ == (Exception,)
    assert isinstance(ProgrammingError(), Exception)
    assert isinstance(ProgrammingError.__init__, type)
    # this is a

# Generated at 2022-06-26 00:44:12.073448
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError(None)
        assert False
    except ProgrammingError as e:
        assert type(e) == ProgrammingError
    try:
        programming_error_0 = ProgrammingError("")
        assert False
    except ProgrammingError as e:
        assert type(e) == ProgrammingError
    try:
        programming_error_0 = ProgrammingError("a")
        assert False
    except ProgrammingError as e:
        assert type(e) == ProgrammingError
    try:
        programming_error_0 = ProgrammingError("abc")
        assert False
    except ProgrammingError as e:
        assert type(e) == ProgrammingError


# Generated at 2022-06-26 00:44:13.215165
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()


# Generated at 2022-06-26 00:44:33.498451
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:44:34.915598
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass
    assert True


# Generated at 2022-06-26 00:44:38.426131
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:44:42.000137
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except Exception as e:
        print("Exception while creating ProgrammingError instance: " + str(e))
    else:
        print("Successfully created ProgrammingError instance")


# Generated at 2022-06-26 00:44:43.854828
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        test_case_0()


# Generated at 2022-06-26 00:44:46.899564
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as err:
        assert err.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    else:
        assert False, "Exception not raised"

# Generated at 2022-06-26 00:44:47.871777
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:44:50.650212
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    assert "Broken coherence" in str(programming_error_0)
    assert "Check your code against" in str(programming_error_0)

# Generated at 2022-06-26 00:44:53.081268
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert str(ProgrammingError("Expected an empty string.")) == "Expected an empty string."
    assert str(ProgrammingError("Expected a None.")) == "Expected a None."



# Generated at 2022-06-26 00:44:54.990726
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as e:
        pass

# Generated at 2022-06-26 00:45:46.126116
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        return
    except:
        assert False, "Unexpected exception thrown."
    assert False, "ProgrammingError not raised as expected."

# Generated at 2022-06-26 00:45:48.294865
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = first_programming_error()
    programming_error_1 = ProgrammingError(programming_error_0)
    programming_error_2 = ProgrammingError("Second Error")

# Generated at 2022-06-26 00:45:50.914871
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "" == e.args[0]
        assert e.args[0] is str(e)

# Generated at 2022-06-26 00:45:51.892303
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()


# Generated at 2022-06-26 00:45:53.313328
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except:
        assert False


# Generated at 2022-06-26 00:45:54.980402
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        assert 1
    else:
        assert 0


# Generated at 2022-06-26 00:45:56.895476
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()
    ProgrammingError("foo")
    try:
        ProgrammingError.passert(False, "foo")
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:45:58.626066
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-26 00:45:59.873551
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert str(ProgrammingError()) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:46:01.980024
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
        assert False, "Python did not raise a ProgrammingError Exception as expected"
    except ProgrammingError as ex:
        assert True


# Generated at 2022-06-26 00:47:53.026460
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as programming_error_0:
        assert True



# Generated at 2022-06-26 00:48:01.236760
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Check exception is raised with no message
    try:
        ProgrammingError.passert(False, None)
        raise Exception("Parameter 'message' not taken into account in assert clause")
    except ProgrammingError as e:
        pass

    # Check exception is raised with message
    try:
        ProgrammingError.passert(False, "Broken coherence")
        raise Exception("Parameter 'message' not taken into account in assert clause")
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence"

    # Check exception is not raised with True condition
    try:
        ProgrammingError.passert(True, "Broken coherence")
    except ProgrammingError as e:
        raise Exception("Parameter 'message' not taken into account in assert clause")


test_ProgrammingError()

# Generated at 2022-06-26 00:48:02.661226
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as e:
        print(e)



# Generated at 2022-06-26 00:48:03.987476
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert str(ProgrammingError()) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:48:06.068130
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except:
        ProgrammingError()


# Generated at 2022-06-26 00:48:08.112085
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    implementation = ProgrammingError()
    assert implementation is not None
    assert type(implementation) is ProgrammingError
    assert isinstance(implementation, ProgrammingError)
    assert issubclass(ProgrammingError, Exception)

# Generated at 2022-06-26 00:48:09.776520
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as e:
        assert str(e) == ""


# Generated at 2022-06-26 00:48:10.477039
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()



# Generated at 2022-06-26 00:48:13.449513
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass
    else:
        __msg = "Cannot instantiate an empty ProgrammingError."
        assert False, __msg


# Generated at 2022-06-26 00:48:15.450879
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        test_case_0()


# Generated at 2022-06-26 00:50:20.939332
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pypara import ProgrammingError

    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)

# Generated at 2022-06-26 00:50:22.433260
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-26 00:50:25.540979
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as e:
        assert e is not None
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:50:27.412053
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:50:29.457490
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()


# Generated at 2022-06-26 00:50:33.350107
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    assert isinstance(programming_error_0, ProgrammingError)
    assert issubclass(programming_error_0.__class__, ProgrammingError)
    assert issubclass(programming_error_0.__class__, Exception)


programming_error_1 = ProgrammingError.passert(False, "The message")


# Generated at 2022-06-26 00:50:35.164970
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Define a ProgrammingError object
    programming_error_0 = ProgrammingError()
    # Assert that the error message is empty
    assert programming_error_0.args[0] == ""


# Generated at 2022-06-26 00:50:36.000916
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(ProgrammingError(), ProgrammingError)


# Generated at 2022-06-26 00:50:37.184090
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        return
    raise AssertionError("ProgrammingError() didn't raise the ProgrammingError exception.")

# Generated at 2022-06-26 00:50:38.657948
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test case 0
    try:
        test_case_0()
    except Exception as e:
        assert isinstance(e, ProgrammingError)

