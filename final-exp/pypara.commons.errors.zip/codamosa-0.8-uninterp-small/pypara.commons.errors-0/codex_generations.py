

# Generated at 2022-06-26 00:41:18.994912
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert len(str(programming_error_0)) > 0


# Generated at 2022-06-26 00:41:20.788349
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except:
        pass
    else:
        raise Exception("Expected exception")


# Generated at 2022-06-26 00:41:22.507895
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert repr(ProgrammingError()) == '<ProgrammingError>'
    assert repr(ProgrammingError('Error msg')) == "'Error msg'"



# Generated at 2022-06-26 00:41:23.091840
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-26 00:41:25.492677
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except AttributeError:
        assert False
    else:
        assert True


# Generated at 2022-06-26 00:41:26.008962
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-26 00:41:27.090923
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(ProgrammingError(), ProgrammingError)


# Generated at 2022-06-26 00:41:29.046874
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert str(e) == ""



# Generated at 2022-06-26 00:41:30.699719
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    print("Testing ProgrammingError constructor...")
    # Create an instance of a ProgrammingError
    test_case_0()


# Generated at 2022-06-26 00:41:31.626198
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError()


# Generated at 2022-06-26 00:41:37.894235
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()

    except ProgrammingError:
        pass

if __name__ == "__main__":
    print(ProgrammingError.__doc__)
    test_ProgrammingError()
    test_case_0()

# Generated at 2022-06-26 00:41:39.384028
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except Exception as err:
        print(err)
    else:
        raise Exception("Exception expected.")



# Generated at 2022-06-26 00:41:40.954059
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    call_ProgrammingError()



# Generated at 2022-06-26 00:41:43.631691
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Case 0: default message
        test_case_0()
    except ProgrammingError as e:
        assert e.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    else:
        raise Exception("it should raise ProgrammingError")



# Generated at 2022-06-26 00:41:46.864258
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_1 = ProgrammingError()
    assert str(programming_error_1) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:41:48.105180
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()


# Generated at 2022-06-26 00:41:49.130391
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()



# Generated at 2022-06-26 00:41:51.799954
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import sys
    try:
        test_case_0()
    except:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        assert exc_type == ProgrammingError



# Generated at 2022-06-26 00:41:54.008295
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # class constructor without arguments
    test_case_0()
    # class constructor with arguments
    programming_error_1 = ProgrammingError(message="Broken coherence.")


# Generated at 2022-06-26 00:41:55.649891
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except Exception as e:
        print(str(e))

# Generated at 2022-06-26 00:42:03.079020
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except ProgrammingError:
        pass
    else:
        print("Failed test case 0")
        assert False


# Generated at 2022-06-26 00:42:03.905264
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError()
    assert str(e) == ''


# Generated at 2022-06-26 00:42:04.558817
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:42:05.361108
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()

# Generated at 2022-06-26 00:42:06.234414
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()



# Generated at 2022-06-26 00:42:10.650729
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert "test" in e.args[0]
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence" in e.args[0]

# Generated at 2022-06-26 00:42:11.925877
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert(ProgrammingError())



# Generated at 2022-06-26 00:42:13.097862
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()


# Generated at 2022-06-26 00:42:15.506125
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # case 0:
        test_case_0()
        assert False

    except:
        # case 1:
        assert True

    else:
        assert False

# Generated at 2022-06-26 00:42:17.590486
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError"


# Generated at 2022-06-26 00:42:30.732979
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Sample message")
    except ProgrammingError as e:
        assert e.args[0] == "Sample message"


# Generated at 2022-06-26 00:42:32.070484
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(ProgrammingError(), ProgrammingError)


# Generated at 2022-06-26 00:42:35.218081
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:42:39.567609
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test1_result = []
    test2_result = []
    try:
        raise ProgrammingError()
    except ProgrammingError:
        test1_result.append("pass")
    try:
        raise ProgrammingError("ramdon message")
    except ProgrammingError:
        test2_result.append("pass")
    assert test1_result == ["pass"]
    assert test2_result == ["pass"]


# Generated at 2022-06-26 00:42:40.995792
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Unit tests for method ProgrammingError.passert

# Generated at 2022-06-26 00:42:43.112011
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as err:
        pass
    else:
        assert False, "An exception should have been raised."


# Generated at 2022-06-26 00:42:45.399307
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
	try:
		ProgrammingError()
	except Exception as e:
		assert(False)
	else:
		assert(True)


# Generated at 2022-06-26 00:42:48.127120
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        print("Unit test for constructor of class ProgrammingError was successful.")


# Unit tests for public static methods of class ProgrammingError

# Generated at 2022-06-26 00:42:49.224993
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError()

# Generated at 2022-06-26 00:42:54.442675
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert hasattr(ProgrammingError,'__init__')


# Generated at 2022-06-26 00:43:15.997875
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(test_case_0(), ProgrammingError)
    print("Unit test for constructor of class ProgrammingError done.")


# Generated at 2022-06-26 00:43:17.010042
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:43:17.941415
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()


# Generated at 2022-06-26 00:43:19.128895
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    assert True


# Generated at 2022-06-26 00:43:21.547901
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def test_method():
        ProgrammingError()

    try:
        test_method()
    except ProgrammingError as ex:
        assert True
    else:
        assert False, "Failed when no exception was thrown."



# Generated at 2022-06-26 00:43:24.790461
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert False, "Should have raised a programming error"
    except ProgrammingError as ex:
        assert isinstance(ex, ProgrammingError), "Expected instance of ProgrammingError"


# Generated at 2022-06-26 00:43:31.762390
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(ProgrammingError, type)
    assert issubclass(ProgrammingError, Exception)
    assert hasattr(ProgrammingError, "__init__")
    assert hasattr(ProgrammingError, "passert")
    assert callable(ProgrammingError.__init__)
    assert callable(ProgrammingError.passert)
    assert isinstance(ProgrammingError.__init__, type)
    assert isinstance(ProgrammingError.passert, type)
    test_case_0()


# Generated at 2022-06-26 00:43:32.372215
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:43:42.044180
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError("Missing argument.")
    assert programming_error_0.__class__.__name__ == 'ProgrammingError'
    assert repr(programming_error_0) == 'Missing argument.'
    assert programming_error_0.__cause__ is None


# Generated at 2022-06-26 00:43:43.414575
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert str(ProgrammingError()) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:44:28.335753
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Create a dummy programming error
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass



# Generated at 2022-06-26 00:44:30.598177
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(ProgrammingError(), ProgrammingError)
    assert isinstance(ProgrammingError(""), ProgrammingError)
    assert isinstance(ProgrammingError("hello world"), ProgrammingError)


# Generated at 2022-06-26 00:44:32.507831
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "Error in case of true")

test_case_0()
test_ProgrammingError()

# Generated at 2022-06-26 00:44:33.715116
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as e:
        print(e)

# Generated at 2022-06-26 00:44:38.472201
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test 1 - instance created without message
    try:
        programming_error_1 = ProgrammingError()
    except ProgrammingError:
        assert(False)

    # Test 2 - instance created with message
    try:
        programming_error_2 = ProgrammingError("Test message")
    except ProgrammingError:
        assert(False)



# Generated at 2022-06-26 00:44:40.287836
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:44:41.562241
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()



# Generated at 2022-06-26 00:44:45.659257
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    print("Start testing")
    try:
        test_case_0()
        print("Passed test case 0")
    except:
        print("Failed test case 0")
    print("Stop testing")

# if __name__ == "__main__":
#     test_ProgrammingError()

# Generated at 2022-06-26 00:44:47.234356
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:44:48.695178
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    assert isinstance(programming_error_0, ProgrammingError)

# Generated at 2022-06-26 00:46:34.976578
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        raise Exception("ProgrammingError()")


# Generated at 2022-06-26 00:46:36.359592
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)


# Generated at 2022-06-26 00:46:36.915330
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert 1 == 1

# Generated at 2022-06-26 00:46:38.323408
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except Exception as e:
        print(e)

# Generated at 2022-06-26 00:46:38.957341
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-26 00:46:40.881570
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        """
        Programming error constructor is working as expected
        """
        test_case_0()
    except:
        assert False
    assert True


# Generated at 2022-06-26 00:46:42.306165
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert test_case_0()

# Generated at 2022-06-26 00:46:44.298888
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:46:45.723962
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(programming_error_0, ProgrammingError)



# Generated at 2022-06-26 00:46:46.457721
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()



# Generated at 2022-06-26 00:48:42.087876
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is a test")
    assert error is not None

# Generated at 2022-06-26 00:48:44.170048
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError, match="Broken coherence"):
        ProgrammingError("Broken coherence")


# Generated at 2022-06-26 00:48:51.238693
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class Test(ProgrammingError):
        @classmethod
        def passert(cls, condition: bool, message: Optional[str]) -> None:
            if not condition:
                raise cls(message or "Default message")

    try:
        Test.passert(condition=False, message=None)
        Test.passert(condition=False, message="")
        Test.passert(condition=False, message="Test message")
    except Test as e:
        assert "Default message" in str(e)
        assert "Test message" in str(e)

# Generated at 2022-06-26 00:48:56.137429
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for ProgrammingError class."""
    error = ProgrammingError("my message")
    assert error.__class__ == ProgrammingError
    assert error.args == ("my message",)
    assert error.__str__() == "my message"

    error = ProgrammingError()
    assert error.__class__ == ProgrammingError
    assert error.args == ("Broken coherence. Check your code against domain logic to fix it.",)
    assert error.__str__() == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:48:56.988467
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Test message")

# Generated at 2022-06-26 00:49:00.365505
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # If a message is not provided, a default one should be used
    assert ProgrammingError().args[0] == "Broken coherence. Check your code against domain logic to fix it."

    # When the message is provided, it's used only the provided one
    assert ProgrammingError("Error message").args[0] == "Error message"



# Generated at 2022-06-26 00:49:01.512717
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Unsolvable problem."):
        pass

    with ProgrammingError:
        pass

# Generated at 2022-06-26 00:49:03.426673
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)
        assert isinstance(e, Exception)


# Generated at 2022-06-26 00:49:06.438483
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "irrelevant")
    except ProgrammingError as e:
        assert "irrelevant" == str(e)
        assert None == e.__cause__
        assert None == e.__context__
    else:
        assert False


# Generated at 2022-06-26 00:49:07.972468
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Example message")
    except ProgrammingError as exc:
        assert str(exc) == "Example message"
