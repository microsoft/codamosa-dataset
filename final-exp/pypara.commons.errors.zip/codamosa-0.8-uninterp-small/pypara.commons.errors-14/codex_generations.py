

# Generated at 2022-06-26 00:41:20.876735
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    assert str(programming_error_0) == ""
    assert repr(programming_error_0) == "ProgrammingError()"
    assert type(programming_error_0) == ProgrammingError


# Generated at 2022-06-26 00:41:22.130021
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except Exception as err:
        pass



# Generated at 2022-06-26 00:41:22.962678
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError()



# Generated at 2022-06-26 00:41:31.044456
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    #All its constructors are empty.
    try:
        test_case_0()
    except Exception as e:
        print("ERROR")
        print(e)

    #The only thing that we can assert is that it has the correct type.
    assert ProgrammingError.__name__ == "ProgrammingError"
    assert type(ProgrammingError.__annotations__) is dict
    assert ProgrammingError.__doc__ is not None

    # In order to test programming_error_0, we have to check if it was created with the correct constructor
    # and that it has the correct type.
    try:
        programming_error_0
    except NameError:
        print("ERROR")
    else:
        assert type(programming_error_0) is ProgrammingError


# Generated at 2022-06-26 00:41:32.077715
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError
    assert not ProgrammingError


# Generated at 2022-06-26 00:41:32.781346
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()



# Generated at 2022-06-26 00:41:34.809829
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # When we call the constructor of class ProgrammingError
    try:
        programming_error_0 = ProgrammingError()
    # Then no exception is raised
    except ProgrammingError:
        assert False


# Generated at 2022-06-26 00:41:37.455531
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError and
    """
    prog_error = ProgrammingError()
    assert(prog_error.args == ())



# Generated at 2022-06-26 00:41:38.777989
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # If a ProgrammingError object is created, it should not raise any exception
    ProgrammingError()


# Generated at 2022-06-26 00:41:40.090168
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as e:
        pass
    else:
        assert False



# Generated at 2022-06-26 00:41:44.043744
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(1 == 0, "Reality sucks, sorry")
    except ProgrammingError as e:
        assert str(e) == "Reality sucks, sorry"
    else:
        assert False

# Generated at 2022-06-26 00:41:49.515555
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """
    try:
        ProgrammingError.passert(True, "This assertion should not raise an exception")
    except ProgrammingError:
        assert False
    try:
        ProgrammingError.passert(False, "This assertion should raise an exception")
        assert False
    except ProgrammingError:
        assert True


# Generated at 2022-06-26 00:41:51.838468
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Something bad happened."
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert message in str(e)



# Generated at 2022-06-26 00:41:53.071539
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError:
        ProgrammingError.passert(False, "It should rise an error.")

# Generated at 2022-06-26 00:41:55.933435
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # You may not construct this exception explicitly
        ProgrammingError("Test raised.")
    except ProgrammingError:
        pass
    else:
        raise RuntimeError("The constructor must raise a ProgrammingError in all cases")


# Generated at 2022-06-26 00:41:59.499126
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(
            condition=False,
            message="This is a sample message"
    ):
        pass

# Generated at 2022-06-26 00:42:01.267962
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError, match=r"Message"):
        raise ProgrammingError("Message")


# Generated at 2022-06-26 00:42:03.305504
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(False, "Test error"):
        # This exception should be raised
        raise RuntimeError("Error")

# Generated at 2022-06-26 00:42:06.594526
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test error")
    except ProgrammingError as e:
        if e.args[0] != "Test error":
            raise AssertionError("Failed to raise ProgrammingError.")  # pragma: no cover
        return
    raise AssertionError("Failed to raise ProgrammingError.")  # pragma: no cover


# Generated at 2022-06-26 00:42:10.691197
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "message")
    try:
        ProgrammingError.passert(False, "message")
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:42:15.595971
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("")
        assert False
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:42:17.947975
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error.")
    except ProgrammingError as e:
        assert isinstance(e, ProgrammingError)
        assert e.args == ("Error.",)


# Generated at 2022-06-26 00:42:19.911494
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Testing that the constructor of :py:class:`ProgrammingError` does not raise other exceptions.
    """

    ProgrammingError()


# Testing method ProgrammingError.passert

# Generated at 2022-06-26 00:42:29.842127
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Given
    valid_message = "Error."
    invalid_condition = False
    invalid_message = "Error."

    # When / Then
    try:
        ProgrammingError.passert(True, valid_message)
    except ProgrammingError:
        assert False, "Assertion of True condition must not raise any exception."

    try:
        ProgrammingError.passert(invalid_condition, invalid_message)
        assert False, "Assertion of an invalid condition must raise an exception."
    except ProgrammingError:
        assert True

    try:
        ProgrammingError.passert(invalid_condition, None)
        assert False, "Assertion of an invalid condition must raise an exception."
    except ProgrammingError:
        assert True

# Generated at 2022-06-26 00:42:32.256567
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("This is an error")
    assert err.args == ("This is an error",)

# Unit test to check ProgrammingError.passert method

# Generated at 2022-06-26 00:42:41.197203
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor of class :py:class:`ProgrammingError` and the associated helper routine
    :py:meth:`ProgrammingError.passert`.

    :raises AssertionError: In case that something was wrong during the test.
    """
    try:
        ProgrammingError.passert(True, "Should not raise")
    except ProgrammingError:
        raise AssertionError("ProgrammingError.passert() raised an error but should not.")

# Generated at 2022-06-26 00:42:44.717892
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class MyProgrammingError(ProgrammingError): pass
    exception = MyProgrammingError("This is a programming error.")
    assert "This is a programming error" in exception.__str__()

    ProgrammingError.passert(True, "This is not an error.")
    try:
        ProgrammingError.passert(False, "This is an error.")
        assert False
    except ProgrammingError as e:
        assert "error" in e.__str__()

# Generated at 2022-06-26 00:42:45.917446
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is a programming error.")


# Generated at 2022-06-26 00:42:47.904084
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    assert ProgrammingError("An error message")



# Generated at 2022-06-26 00:42:50.147693
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:42:57.077072
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # create an object of type ProgrammingError
        obj = ProgrammingError(message="a message")
    except TypeError:
        pass  # it is ok, your class is valid

# Generated at 2022-06-26 00:42:59.120222
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("Message")
    assert isinstance(err, Exception)
    assert err.args == ("Message",)


# Generated at 2022-06-26 00:43:03.754935
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for :py:class:`ProgrammingError`.

    :raises AssertionError: In case that the unit test does not pass.
    """
    expected_msg = "This is a message"
    e = ProgrammingError(expected_msg)
    assert e.args[0] == expected_msg


# Generated at 2022-06-26 00:43:07.635773
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        ProgrammingError.passert(condition=False, message="I'm broken")
        assert False
    except ProgrammingError:
        assert True



# Generated at 2022-06-26 00:43:10.603248
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:43:18.132882
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    __doc__ = """
    Unit test for the constructor of the class ProgrammingError.
    Raises the ProgrammingError when it is supposed to, i.e., when the condition is false.
    """
    # Arrange
    message = "test"
    # Act
    try:
        ProgrammingError.passert(False, "test")
    except ProgrammingError as e:
        # Assert
        assert(isinstance(e, ProgrammingError))
        assert(e.args[0] == message)
    # Act
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        # Assert
        assert(isinstance(e, ProgrammingError))
        assert(e.args[0] == "Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-26 00:43:20.684026
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("some error")
    except ProgrammingError as e:
        assert str(e) == "some error"


# Generated at 2022-06-26 00:43:21.913285
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except Exception as ex:
        assert ex.args[0] == "test"


# Generated at 2022-06-26 00:43:24.750899
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    assert ProgrammingError("Test").args[0] == "Test"



# Generated at 2022-06-26 00:43:27.638061
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="Testing ProgrammingError")


# Generated at 2022-06-26 00:43:43.910932
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    try:
        ProgrammingError()
        assert False, "Should have failed"
    except TypeError:
        pass
    try:
        ProgrammingError("")
    except TypeError:
        assert False, "Should not have failed"


# Generated at 2022-06-26 00:43:46.510630
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "The exception should be raised."


# Generated at 2022-06-26 00:43:49.222633
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Hello.", 5)
    except ProgrammingError as e:
        assert str(e) == "Hello. [5]"


# Generated at 2022-06-26 00:43:50.724699
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True  # OK


# Generated at 2022-06-26 00:43:52.339218
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)

# Unit tests for ProgrammingError.passert()

# Generated at 2022-06-26 00:43:54.837957
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something bad happened")
    except ProgrammingError as raised_exception:
        assert "Something bad happened" in str(raised_exception)


# Generated at 2022-06-26 00:43:58.422059
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    not_expected_message = "not expected message"

    try:
        ProgrammingError(not_expected_message)
    except ProgrammingError as raised:
        assert raised.args[0] == not_expected_message
    else:
        assert False, "ProgrammingError constructor not working"


# Generated at 2022-06-26 00:44:06.994188
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for the constructor of class ProgrammingError"""

    e = ProgrammingError('Test message')
    assert type(e) == ProgrammingError, 'Failed to create ProgrammingError'
    error_message = 'Test message'
    assert str(e) == error_message, 'Failed to create ProgrammingError'
    try:
        raise e
    except ProgrammingError as exc:
        message = str(exc)
        assert message == error_message, 'Failed to create ProgrammingError'


# Generated at 2022-06-26 00:44:11.134477
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test to check that :py:class:`ProgrammingError` is raised in case of failure.
    """
    try:
        ProgrammingError.passert(False, "condition failed")
        assert False, "The exception was not raised"
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:44:14.766382
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check default values
    try:
        ProgrammingError(None)
        raise AssertionError("Expected ProgrammingError exception.")
    except ProgrammingError:
        pass
    # Check not null error message
    try:
        ProgrammingError("")
        raise AssertionError("Expected ProgrammingError exception.")
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:44:37.828739
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="bla")
    except ProgrammingError:
        pass
    else:
        assert False, "ProgrammingError() did not raise exception when called without parameters."


# Generated at 2022-06-26 00:44:47.627155
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase, main
    from json import loads

    class TestProgrammingError(TestCase):
        """
        Test for :py:class:`ProgrammingError` class constructor.
        """

        def test__constructor__none(self):
            """
            Tests the constructor with a ``None`` message.
            """
            error = ProgrammingError(None)
            self.assertEqual("Broken coherence. Check your code against domain logic to fix it.", error.args[0])

        def test__constructor__empty(self):
            """
            Tests the constructor with an empty message.
            """
            error = ProgrammingError("")
            self.assertEqual("Broken coherence. Check your code against domain logic to fix it.", error.args[0])


# Generated at 2022-06-26 00:44:48.773600
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:44:50.425513
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
   try:
       ProgrammingError('Testing')
   except ProgrammingError as e:
       assert str(e) == 'Testing'

# Generated at 2022-06-26 00:44:52.929161
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expect_error = ProgrammingError.passert(False, "Message")
    expect_ok = ProgrammingError.passert(True, "Message")
    assert expect_error is None
    assert expect_ok is None

# Generated at 2022-06-26 00:44:55.697772
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-26 00:44:57.755174
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My message")
    except ProgrammingError as programming_error:
        assert programming_error.args[0] == "My message"


# Generated at 2022-06-26 00:45:00.027445
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as error:
        assert error.args[0] == "Test"
    else:
        raise AssertionError("ProgrammingError exception not raised!")


# Generated at 2022-06-26 00:45:02.856642
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as err:
        assert str(err) == "test"
        return
    assert False, "Expected ProgrammingError, but none raised"


# Generated at 2022-06-26 00:45:07.301715
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "True is True"):
        pass

    with ProgrammingError.passert(False, "False is False"):
        pass

    try:
        with ProgrammingError.passert(False, "False is False"):
            pass
        assert False, "The above line should have failed"
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:46:00.058362
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("Message").args[0] == "Message"


# Generated at 2022-06-26 00:46:02.387220
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("message")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Calling constructor of ProgrammingError didn't raise and exception.")


# Generated at 2022-06-26 00:46:04.517756
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    try:
        raise ProgrammingError("Something went wrong")
    except ProgrammingError as error:
        assert error.args[0] == "Something went wrong"


# Generated at 2022-06-26 00:46:06.005065
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Something is wrong. Please check your program.")
    ProgrammingError()

# Generated at 2022-06-26 00:46:08.023229
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Should have raised exception"


# Generated at 2022-06-26 00:46:09.960995
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Expected condition is not met")
    except ProgrammingError as e:
        assert e.args[0] == "Expected condition is not met"
        return

# Generated at 2022-06-26 00:46:13.006548
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test for assert_
    try:
        ProgrammingError.passert(False, "message")
        assert False, "A ProgrammingError should be raised."
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:46:15.918632
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "Some message")
    assert str(excinfo.value) == "Some message"
    ProgrammingError.passert(True, "Some message")
    ProgrammingError.passert(True, None)

# Generated at 2022-06-26 00:46:17.874993
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
         raise ProgrammingError(message = "Expected")
    except ProgrammingError as e:
        assert str(e) == "Expected"
    else:
         assert False


# Generated at 2022-06-26 00:46:20.308751
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError
    :return:
    """

    # Test the constructor of ProgrammingError
    p = ProgrammingError('My error message')
    assert isinstance(p, Exception)

# Generated at 2022-06-26 00:48:12.177788
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of class :py:class:`ProgrammingError`.

    :return: ``None``
    """
    ProgrammingError("Test")


# Generated at 2022-06-26 00:48:15.451476
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Expectation not met")
        raise Exception("Should not reach this point")
    except ProgrammingError as e:
        assert str(e) == "Expectation not met"

# Generated at 2022-06-26 00:48:18.427882
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError("test")
    except ProgrammingError as ex:  # noqa
        assert str(ex) == "test"



# Generated at 2022-06-26 00:48:19.087687
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("some text")

# Generated at 2022-06-26 00:48:21.383966
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "Bogus message"
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as pe:
        assert pe.args[0] == msg


# Generated at 2022-06-26 00:48:22.125443
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This is a test.")


# Generated at 2022-06-26 00:48:23.838456
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with raises(ProgrammingError):
        raise ProgrammingError()
    with raises(ProgrammingError):
        raise ProgrammingError("Broken coherence. Fix it.")


# Generated at 2022-06-26 00:48:32.245792
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Case: no message
    try:
        raise ProgrammingError()
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False  # pragma: no cover

    # Case: no message
    try:
        raise ProgrammingError("sdfsdfs")
    except ProgrammingError as ex:
        assert str(ex) == "sdfsdfs"
    else:
        assert False  # pragma: no cover

    # Case: No error
    ProgrammingError.passert(True, "asdasd")

    # Case: Error

# Generated at 2022-06-26 00:48:35.120551
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.

    :return: ``True`` if the test succeeds, ``False`` otherwise.
    :rtype: bool
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        return True
    return False


# Generated at 2022-06-26 00:48:36.947583
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class MyError(ProgrammingError):
        pass
    try:
        MyError()
        assert(False)
    except:
        assert(True)
