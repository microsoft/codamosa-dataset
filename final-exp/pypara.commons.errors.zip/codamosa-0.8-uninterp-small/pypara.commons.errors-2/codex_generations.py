

# Generated at 2022-06-26 00:41:19.394990
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:20.541712
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError
    assert ProgrammingError()


# Generated at 2022-06-26 00:41:21.262156
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:21.971817
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:23.524917
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass



# Generated at 2022-06-26 00:41:31.785805
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for class :py:class:`ProgrammingError`.

    :return:
    """
    programming_error_0 = ProgrammingError()

    assert "None" == str(programming_error_0)

    # No exception
    ProgrammingError.passert(True, None)
    ProgrammingError.passert(True, "")
    ProgrammingError.passert(True, "Expecting true")

    # Expected exception
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(False, "Expecting true")
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:41:32.751267
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()

# Generated at 2022-06-26 00:41:34.774170
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except Exception as e:
        if "pass" in str(e):
            print("Error raised: " + str(e))


# Generated at 2022-06-26 00:41:36.944722
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass



# Generated at 2022-06-26 00:41:37.673301
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()


# Generated at 2022-06-26 00:41:41.892482
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert type(ProgrammingError()) is ProgrammingError


# Generated at 2022-06-26 00:41:42.799009
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:43.560969
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:46.513751
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    assert isinstance(programming_error_0, ProgrammingError)


# Generated at 2022-06-26 00:41:49.610773
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_1 = ProgrammingError("error message")
    assert programming_error_1.args[0] == "error message"
    assert (False, "error message 2") == ProgrammingError.passert(False, "error message 2")

# Generated at 2022-06-26 00:41:52.902018
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.
    """
    programming_error = ProgrammingError()
    assert isinstance(programming_error, Exception)
    assert isinstance(programming_error, ProgrammingError)


# Generated at 2022-06-26 00:41:53.778695
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    print(ProgrammingError())

# Generated at 2022-06-26 00:41:57.021780
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert str(programming_error_0) == ''
    assert repr(programming_error_0) == 'ProgrammingError()'
    assert repr(programming_error_0) == 'ProgrammingError()'
    assert repr(programming_error_0) == 'ProgrammingError()'


# Generated at 2022-06-26 00:42:00.111237
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except Exception as exception:
        assert isinstance(exception, ProgrammingError)


# Generated at 2022-06-26 00:42:03.430499
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    case = 0
    try:
        test_case_0()
    except ProgrammingError:
        case = 1
    if case == 0:
        print("ProgrammingError() constructor doesn't work")
    else:
        print("ProgrammingError() constructor works")


# Generated at 2022-06-26 00:42:10.546552
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Valid cases
    try:
        test_case_0()
    except ProgrammingError:
        assert False
    # Invalid cases
    # N/A



# Generated at 2022-06-26 00:42:12.873788
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    assert isinstance(programming_error_0, ProgrammingError)

# Generated at 2022-06-26 00:42:14.176528
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()
    programming_error = ProgrammingError()


# Generated at 2022-06-26 00:42:16.667945
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as exc:
        pass
    else:
        assert False, "Not excepted"


# Generated at 2022-06-26 00:42:18.227371
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert str(ProgrammingError()) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:42:19.950849
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass
    else:
        assert False



# Generated at 2022-06-26 00:42:25.699120
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    assert programming_error_0.args == tuple()
    assert programming_error_0.__cause__ is None
    assert programming_error_0.__context__ is None
    assert issubclass(ProgrammingError, Exception)
    assert isinstance(ProgrammingError.passert, staticmethod)
    assert ProgrammingError.__name__ == "ProgrammingError"


# Generated at 2022-06-26 00:42:26.692699
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:42:27.952723
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:42:30.641421
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Constructor of class ProgrammingError
    try:
        test_case_0()
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-26 00:42:41.661880
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as excinfo:
        test_case_0()
    assert excinfo.type is ProgrammingError



# Generated at 2022-06-26 00:42:42.833948
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)



# Generated at 2022-06-26 00:42:43.690941
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError()


# Generated at 2022-06-26 00:42:45.664094
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except Exception as e:
        assert False
    else:
        assert True


# Generated at 2022-06-26 00:42:48.365834
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError.__name__ == 'ProgrammingError'
    assert issubclass(ProgrammingError, Exception)
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:42:55.216473
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        assert True
    else:
        assert False



# Generated at 2022-06-26 00:42:57.113222
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except NotImplementedError:
        pass
    except:
        programming_error_0 = TranslationError()


# Generated at 2022-06-26 00:43:00.950566
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Call the constructor to see if it works
    with pytest.raises(ProgrammingError):
        ProgrammingError()

    # Verify the name of the exception
    with pytest.raises(ProgrammingError) as e:
        raise ProgrammingError("An error message")
    assert str(e.value) == "An error message"


# Generated at 2022-06-26 00:43:02.360258
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error = ProgrammingError()
    assert isinstance(programming_error, Exception)


# Generated at 2022-06-26 00:43:06.449250
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == ""


# Generated at 2022-06-26 00:43:28.478840
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programmin_error_0 = ProgrammingError()
    assert repr(programmin_error_0) == "()"


# Generated at 2022-06-26 00:43:30.196271
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-26 00:43:31.402333
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert test_case_0
    return


# Generated at 2022-06-26 00:43:32.061433
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()



# Generated at 2022-06-26 00:43:36.988816
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()


# Generated at 2022-06-26 00:43:38.139566
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:43:42.342399
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Negative test case
    # Testing that the constructor raises a ProgrammingError
    with pytest.raises(ProgrammingError) as excinfo:
        test_case_0()
    assert excinfo.type == ProgrammingError

# Generated at 2022-06-26 00:43:43.721787
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    assert programming_error_0.args == ()



# Generated at 2022-06-26 00:43:45.040528
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError is type(ProgrammingError())


# Generated at 2022-06-26 00:43:48.990634
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        from io import StringIO
        from contextlib import redirect_stdout
        f = StringIO()
        with redirect_stdout(f):
            test_case_0()
        s = f.getvalue()
        assert s.strip().startswith("Traceback (most recent call last):")
        assert s.strip().endswith("ProgrammingError()")
    except:
        raise

# Generated at 2022-06-26 00:44:11.670552
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Test")
    assert "Test" == error.args[0]


# Generated at 2022-06-26 00:44:14.082122
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is the message")
    except ProgrammingError as e:
        assert "This is the message" == e.args[0]
        return
    raise RuntimeError()

# Generated at 2022-06-26 00:44:15.972313
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence" in str(e)


# Generated at 2022-06-26 00:44:19.938378
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the constructor of class ProgrammingError.
    """

    # Valid statement, no exception is expected
    ProgrammingError.passert(True, None)

    # Invalid statement, exception is expected
    try:
        ProgrammingError.passert(False, "This is an invalid statement")
        assert False
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:44:27.664336
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("programming error")
    except ProgrammingError as e:
        assert(str(e) == "programming error")
    from nose2.tools import params
    @params(True, "...")
    def test_ProgrammingError_passert(condition, message):
        ProgrammingError.passert(condition, message)
    test_ProgrammingError_passert()
    try:
        ProgrammingError.passert(False, "programming error")
        assert False
    except ProgrammingError as e:
        assert str(e) == "programming error"
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:44:29.106575
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError):
        ProgrammingError("A ProgrammingError is raised...")

# Generated at 2022-06-26 00:44:32.316058
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is the error message for the exception raised by condition failure")
    except ProgrammingError as e:
        assert "This is the error message for the exception raised by condition failure" == str(e)
    else:
        raise AssertionError("An exception should have been raised while none has been")

# Generated at 2022-06-26 00:44:34.242429
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Test ProgrammingError")
    except ProgrammingError as e:
        assert e.args == ("Test ProgrammingError",)

# Generated at 2022-06-26 00:44:44.806904
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase, mock

    class TestProgrammingError(TestCase):
        def test_ProgrammingError(self):
            with self.assertRaises(ProgrammingError):
                ProgrammingError()

        def test_ProgrammingErrorWithMessage(self):
            with self.assertRaises(ProgrammingError):
                ProgrammingError("Error message.")

        @mock.patch.object(__name__ + ".ProgrammingError", "__init__")
        def test_passert(self, init):
            ProgrammingError.passert(True, None)
            init.assert_not_called()

            with self.assertRaises(ProgrammingError):
                ProgrammingError.passert(False, None)
                init.assert_called_once()
                init.assert_called_with(None)


# Generated at 2022-06-26 00:44:46.464617
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()


# Generated at 2022-06-26 00:45:38.645728
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Region : Basic tests
    message = "This is a message."
    exc = ProgrammingError(message)
    assert exc.args == (message, )

    exc = ProgrammingError()
    assert exc.args == ("Broken coherence. Check your code against domain logic to fix it.", )

    # Test the class method passert
    message = "This is a message."
    try:
        ProgrammingError.passert(False, message)
    except ProgrammingError as e:
        assert e.args == (message, )
    else:
        raise Exception("Programming error exception not raised.")
    # End region

# Set the test suite.
from . import TestSuite
TestSuite(__name__)

# Generated at 2022-06-26 00:45:40.019388
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:45:41.742980
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True
    else:
        assert False


# Generated at 2022-06-26 00:45:43.033571
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        raise ProgrammingError("Test")



# Generated at 2022-06-26 00:45:44.745754
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('Test')
    except ProgrammingError as e:
        assert e.args[0] == 'Test'


# Generated at 2022-06-26 00:45:47.354274
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Message of error")


# Generated at 2022-06-26 00:45:49.020517
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Message")
    except ProgrammingError as e:
        assert False


# Generated at 2022-06-26 00:45:51.579408
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("You shall not pass")
    except ProgrammingError as error:
        assert error.args[0] == "You shall not pass"


# Generated at 2022-06-26 00:45:54.161439
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Message")
        assert False, "ProgrammingError.passert should raise an exception if the condition is False"
    except ProgrammingError:
        # OK
        pass



# Generated at 2022-06-26 00:45:56.184098
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as error:
        ProgrammingError("Dummy message.")
    assert str(error.value) == "Dummy message."


# Generated at 2022-06-26 00:47:49.226857
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"  # We're expecting a string
        assert type(e) is ProgrammingError  # The type should be correct



# Generated at 2022-06-26 00:47:52.709598
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Message")
    except Exception as e:
        assert(str(e) == "Message")

    try:
        ProgrammingError.passert(False, None)
    except Exception as e:
        assert(str(e) == "Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-26 00:47:54.972925
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "We expect this test to fail")
    ProgrammingError.passert(True, "This test should not raise the exception")

# Generated at 2022-06-26 00:47:57.134511
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This should be an error")
    except ProgrammingError:
        pass
    else:
        assert False and "Fail: ProgrammingError constructor"


# Generated at 2022-06-26 00:48:01.098644
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError` constructor.
    """
    try:
        ProgrammingError("Some message")
    except ProgrammingError as pe:
        assert pe.args[0] == "Some message"
    else:
        raise AssertionError("ProgrammingError constructor works as expected")


# Generated at 2022-06-26 00:48:03.503010
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Every rose has its thorn")
    except ProgrammingError as error:
        assert issubclass(error.__class__, Exception)
        assert error.args[0] == "Every rose has its thorn"


# Generated at 2022-06-26 00:48:04.613022
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError()

# Generated at 2022-06-26 00:48:07.260431
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=unused-variable
    ex = ProgrammingError()
    ex = ProgrammingError("Message")
    ex = ProgrammingError(message="Message")


# Generated at 2022-06-26 00:48:09.157665
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Expected to raise a ProgrammingError but didn't")


# Generated at 2022-06-26 00:48:10.943120
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from numpy import array

    with raises(ProgrammingError):
        array([1, 2], dtype=int)
