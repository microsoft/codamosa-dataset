

# Generated at 2022-06-26 00:41:21.785665
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except:
        pass
    try:
        raise ProgrammingError('test')
    except:
        pass


# Generated at 2022-06-26 00:41:23.191345
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_1 = ProgrammingError()
    assert programming_error_1



# Generated at 2022-06-26 00:41:25.893785
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test 0
    try:
        test_case_0()
    except ProgrammingError:
        pass
    else:
        raise Exception("Unit test failed")


# Generated at 2022-06-26 00:41:26.718352
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()



# Generated at 2022-06-26 00:41:29.872585
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert len(e.args) == 1
        assert isinstance(e.args[0], str)
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:41:31.627767
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
        assert False
    except ProgrammingError:
        pass
    except Exception:
        assert False


# Generated at 2022-06-26 00:41:33.107736
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert type(e) == ProgrammingError



# Generated at 2022-06-26 00:41:35.133699
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except ProgrammingError:
        print("Passed Unit Test")
    else:
        print("Failed Unit Test")


# Generated at 2022-06-26 00:41:36.754935
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:38.671052
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_1 = ProgrammingError()
    programming_error_2 = ProgrammingError("Testing...")
    programming_error_3 = ProgrammingError(ProgrammingError("Testing..."))

# Generated at 2022-06-26 00:41:43.523930
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(ProgrammingError(), ProgrammingError)



# Generated at 2022-06-26 00:41:46.241091
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as err:
        print(err.args)
        raise AssertionError()


# Generated at 2022-06-26 00:41:47.114103
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()


# Generated at 2022-06-26 00:41:50.753898
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        print("Exception of type ProgrammingError has been raised")
        pass
    else:
        raise Exception("Unit test has failed")


if __name__ == '__main__':
    test_ProgrammingError()

# Generated at 2022-06-26 00:41:55.685189
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test with no arguments
    programming_error_0 = ProgrammingError()

    # Test with arguments
    programming_error_1 = ProgrammingError(1)
    programming_error_2 = ProgrammingError("2")
    programming_error_3 = ProgrammingError(3, "3")
    programming_error_4 = ProgrammingError(4, "4", 5)
    programming_error_5 = ProgrammingError(6, "6", 5, "7")



# Generated at 2022-06-26 00:41:56.407117
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()


# Generated at 2022-06-26 00:42:00.835109
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as error:
        assert type(error) is ProgrammingError
    else:
        raise AssertionError("Constructor of class ProgrammingError did not raise an error, but it should.")


# Generated at 2022-06-26 00:42:03.819235
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("some value")
    except ProgrammingError as err:
        assert str(err) == "some value"

if __name__ == '__main__':
    test_case_0()
    test_ProgrammingError()

# Generated at 2022-06-26 00:42:05.776676
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Case 0: Default invocation
    test_case_0()


if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-26 00:42:07.751018
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()



# Generated at 2022-06-26 00:42:13.008840
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as exception:
        assert type(exception) is ProgrammingError


# Generated at 2022-06-26 00:42:15.025613
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
        assert False
    except ProgrammingError:
        assert True


# Generated at 2022-06-26 00:42:17.868748
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    assert programming_error_0 is not None
    programming_error_1 = ProgrammingError.passert(False, "message")
    assert programming_error_1 is None

# Generated at 2022-06-26 00:42:20.711396
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except Exception as e:
        assert isinstance(e, ProgrammingError)
    else:
        raise AssertionError("Cannot create an instance of exception ProgrammingError")


# Generated at 2022-06-26 00:42:22.168097
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:42:25.043076
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as e:
        assert type(e) == type(ProgrammingError())


# Generated at 2022-06-26 00:42:26.741643
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:42:29.655680
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    assert isinstance(programming_error_0, ProgrammingError), 'unexpected class'



# Generated at 2022-06-26 00:42:30.958942
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:42:35.623859
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError().__class__ == ProgrammingError
    assert ProgrammingError().__class__.__name__ == "ProgrammingError"
    assert ProgrammingError().__class__.__module__ == __name__
    assert ProgrammingError().__class__.__doc__ == "Provides a programming error exception."



# Generated at 2022-06-26 00:42:40.318551
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This class is so simple that it does not need to be tested")

# Generated at 2022-06-26 00:42:42.476832
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check that the message has been set when calling the constructor
    err = ProgrammingError("Check your code")
    assert str(err) == "Check your code"



# Generated at 2022-06-26 00:42:49.916923
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Message of the error to be raised")
    except ProgrammingError as e:
        print(e)
        assert str(e) == "Message of the error to be raised"
        assert repr(e) == "ProgrammingError()"

    # Unit test for passert method of class ProgrammingError
    try:
        ProgrammingError.passert(condition=False, message="Message of the error to be raised")
    except ProgrammingError as e:
        print(e)
        assert str(e) == "Message of the error to be raised"
        assert repr(e) == "ProgrammingError()"

# Generated at 2022-06-26 00:42:51.634159
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Test :func:`pypara.error.test_ProgrammingError`."""
    Programm

# Generated at 2022-06-26 00:42:56.054911
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Check your code!")
    except ProgrammingError as error:
        assert error.args[0] == "Check your code!"



# Generated at 2022-06-26 00:42:58.088361
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is the message of the error")
    assert(error.args == ("This is the message of the error",))

# Generated at 2022-06-26 00:43:01.451810
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
        raise Exception("ProgrammingError is not working properly")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    ProgrammingError.passert(True, "")

# Generated at 2022-06-26 00:43:03.435709
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:43:07.297327
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.common.errors import ProgrammingError
    with raises(ProgrammingError):
        ProgrammingError(message='Broken coherence!')


# Generated at 2022-06-26 00:43:10.197464
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # We expect the python interpreter to raise an ProgrammingError exception if we execute the next line
    raise ProgrammingError("This is a test for the constructor of class ProgrammingError")


# Generated at 2022-06-26 00:43:17.417534
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing constructor.")
    except ProgrammingError as error:
        assert error.__str__() == "Testing constructor."


# Generated at 2022-06-26 00:43:19.592022
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Foo")
    except ProgrammingError as e:
        assert e.args[0] == "Foo"
    else:
        assert False

# Generated at 2022-06-26 00:43:22.836125
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        pass


# Generated at 2022-06-26 00:43:26.064046
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    str(ProgrammingError())
    str(ProgrammingError("some message"))
    str(ProgrammingError("some message", "some file", 0))


# Generated at 2022-06-26 00:43:28.974911
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Testing...")
    except Exception as ex:
        assert isinstance(ex, ProgrammingError)
        assert ex.args[0] == "Testing..."


# Generated at 2022-06-26 00:43:37.289347
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as e:
        ProgrammingError.passert(False, None)
    assert str(e.value) == "Broken coherence. Check your code against domain logic to fix it."
    with pytest.raises(ProgrammingError) as e:
        ProgrammingError.passert(False, "oops")
    assert str(e.value) == "oops"

# Generated at 2022-06-26 00:43:41.013023
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "This is an error message"
    test_exception = ProgrammingError(msg)
    assert test_exception.args[0] == msg

# Generated at 2022-06-26 00:43:42.531145
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("Testing ProgrammingError class")
    assert str(e) == "Testing ProgrammingError class"


# Generated at 2022-06-26 00:43:43.750560
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "Test passed.")
    try:
        ProgrammingError.passert(False, "Test failed.")
    except ProgrammingError as e:
        assert "Test failed." in str(e)
        return
    assert False, "Exception expected."

# Generated at 2022-06-26 00:43:46.339820
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Act
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False, "Expected ProgrammingError exception."


# Generated at 2022-06-26 00:44:04.076647
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Bohemian Rhapsody")
        assert False, "ProgrammingError not raised"
    except ProgrammingError as err:
        assert err.args == ("Bohemian Rhapsody",)

# Generated at 2022-06-26 00:44:05.769759
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError()
    assert error is not None
    assert error.__class__ == ProgrammingError


# Generated at 2022-06-26 00:44:08.614241
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is a Programming Error")
    assert error.args[0] == "This is a Programming Error"


# Generated at 2022-06-26 00:44:10.702473
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class ProgrammingError.
    """
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError(None)



# Generated at 2022-06-26 00:44:13.405983
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)
    else:
        assert False, "ProgrammingError() did not raise."

# Unit tests for method ProgrammingError.passert

# Generated at 2022-06-26 00:44:15.152757
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "This is a test")

# Generated at 2022-06-26 00:44:18.424100
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from .testing import assert_exception_matches
    with raises(ProgrammingError) as captured:
        raise ProgrammingError("This is a programming error")
    assert_exception_matches(captured, ProgrammingError, "This is a programming error")


# Generated at 2022-06-26 00:44:20.365584
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Tests the constructor of class :py:class:`ProgrammingError`. """
    with raises(ProgrammingError):
        ProgrammingError("Expectations failed!")

# Generated at 2022-06-26 00:44:21.164609
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Error message")


# Generated at 2022-06-26 00:44:24.255870
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message='This should cause a ProgrammingError to be raised')
        assert False
    except ProgrammingError as e:
        assert type(e) is ProgrammingError
        assert str(e) == 'This should cause a ProgrammingError to be raised'


# Generated at 2022-06-26 00:44:50.511320
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Check that calling it raises the expected exception
    try:
        raise ProgrammingError()
    except ProgrammingError:
        assert True
    except Exception:
        assert False # ProgrammingErrors should be compatible with the built-in Exception class.
    else:
        assert False

    # Test that the message is propagated correctly
    try:
        raise ProgrammingError("Expected message.")
    except ProgrammingError as e:
        assert e, "Expected message."
    else:
        assert False


# Generated at 2022-06-26 00:44:52.692258
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Whatever", "Whatever")
    except TypeError:
        pass
    except:
        assert False, "Inconsistent constructor of class ProgrammingError"


# Generated at 2022-06-26 00:44:58.775111
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Test for exception with message
    try:
        raise ProgrammingError("Some message")
    except ProgrammingError as ex:
        assert str(ex) == "Some message"
    else:
        raise AssertionError("ProgrammingError not raised")

    # Test for exception with no message
    try:
        raise ProgrammingError
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("ProgrammingError not raised")

# Generated at 2022-06-26 00:45:00.561594
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-26 00:45:10.259308
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "The condition is not met.")
    except ProgrammingError as e:
        assert "The condition is not met." == str(e)
    else:
        raise Exception("Should have raised a ProgrammingError.")
    try:
        ProgrammingError.passert(True, "The condition is not met.")
    except ProgrammingError:
        raise Exception("Should not have raised a ProgrammingError.")
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)
    else:
        raise Exception("Should have raised a ProgrammingError.")

# Generated at 2022-06-26 00:45:12.336109
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "This is a test"
    try:
        ProgrammingError.passert(False, message)
    except ProgrammingError as ex:
        assert ex.args[0] == message

# Generated at 2022-06-26 00:45:15.521150
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Message")
    except ProgrammingError as e:
        assert e.args[0] == "Message"
    except Exception as e:
        assert False, f"Unexpected exception raised: {e.__class__.__name__}"

test_ProgrammingError()


# Generated at 2022-06-26 00:45:17.306945
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("An error has occurred")
    except ProgrammingError as e:
        assert str(e) == "An error has occurred"


# Generated at 2022-06-26 00:45:18.763880
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Protocol violation.")
    except ProgrammingError as e:
        assert str(e) == "Protocol violation."

# Generated at 2022-06-26 00:45:22.489170
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # This test is expected to fail
    try:
        ProgrammingError.passert(False, "test message")
        assert False
    except ProgrammingError as e:
        assert e.__str__() == "test message"
    # This test is expected to succeed
    try:
        ProgrammingError.passert(True, "test message")
    except ProgrammingError as e:
        assert False

# Generated at 2022-06-26 00:46:23.885206
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert e.args[0] == "Test message"
    try:
        ProgrammingError.passert(False, "Test message")
    except ProgrammingError as e:
        assert e.args[0] == "Test message"
test_ProgrammingError()

# Generated at 2022-06-26 00:46:25.467489
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-26 00:46:26.844318
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-26 00:46:32.951572
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """ Unit test for class ProgrammingError. """

    # Check that the error is raised
    try:
        ProgrammingError.passert(False, "This is a test")
        raise AssertionError("Check that the error is raised when the condition is 'False'")
    except ProgrammingError as error:
        if not error.args[0] == ("This is a test"):
            raise AssertionError("Check if the error message is properly retrieved")

# Execute tests
if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-26 00:46:35.044224
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as ex:
        assert str(ex) == "Test"
        return
    assert False, "Error not raised"


# Generated at 2022-06-26 00:46:37.390335
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except:
        pass
    else:
        raise AssertionError("Expected an exception!")


# Generated at 2022-06-26 00:46:39.504202
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("I am a unit test")
    except ProgrammingError as e:
        assert e.args[0] == "I am a unit test"


# Generated at 2022-06-26 00:46:42.332692
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This tests shows the error message.")
    except ProgrammingError as e:
        assert e.args == ("This tests shows the error message.",)


# Generated at 2022-06-26 00:46:45.523635
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test message")
        assert False, "This line should never be reached"
    except ProgrammingError as e:
        assert e.message == "Test message"


# Generated at 2022-06-26 00:46:47.053791
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError('Hello World!')
    except ProgrammingError as e:
        assert str(e) == 'Hello World!'


# Generated at 2022-06-26 00:48:46.937908
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Fail as expected.")
        assert False, "Exception expected"
    except ProgrammingError as e:
        assert str(e) == "Fail as expected."

# Generated at 2022-06-26 00:48:50.172050
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == ""


# Generated at 2022-06-26 00:48:52.337130
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "The message."
    try:
        raise ProgrammingError(message)
    except ProgrammingError as error:
        assert str(error) == message


# Generated at 2022-06-26 00:48:55.591716
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError):
        ProgrammingError(None)

    with raises(ProgrammingError):
        ProgrammingError("")

    with raises(ProgrammingError):
        ProgrammingError("An error has happened.")

    with raises(ProgrammingError):
        ProgrammingError(message="An error has happened.")


# Generated at 2022-06-26 00:48:57.990650
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as ex:
        assert ex.__str__() == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:48:59.322215
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:49:00.473609
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Foo")
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:49:01.864933
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Some message")
    except ProgrammingError as e:
        assert str(e) == "Some message"

# Generated at 2022-06-26 00:49:04.956659
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "just a test")
    except ProgrammingError as e:
        # check if the exception was raised with the proper message
        assert str(e) == "just a test"
    else:
        assert False, "expected exception ProgrammingError not raised"

# Generated at 2022-06-26 00:49:11.381506
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.error import ProgrammingError
    # test that the error is raised
    with raises(ProgrammingError) as e:
        ProgrammingError.passert(condition=False, message="This is an error.")
    assert "This is an error." == str(e.value)
    # test that the error is not raised
    ProgrammingError.passert(condition=True, message="This is an error.")
    # test the shortcuts
    with raises(ProgrammingError) as e:
        ProgrammingError.passert(condition=False, message=None)
    with raises(ProgrammingError) as e:
        ProgrammingError.passert(condition=False)
    with raises(ProgrammingError) as e:
        ProgrammingError()