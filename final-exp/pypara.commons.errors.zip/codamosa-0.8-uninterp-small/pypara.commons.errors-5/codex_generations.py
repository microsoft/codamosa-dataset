

# Generated at 2022-06-26 00:41:21.101872
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:22.574396
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as pe:
        pass
    else:
        assert False


# Generated at 2022-06-26 00:41:24.974210
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
        print("Test case 0 - passed")
    except:
        print("Test case 0 - failed")


# Generated at 2022-06-26 00:41:26.494539
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as e:
        pass



# Generated at 2022-06-26 00:41:28.146361
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Mock the parameters
    programming_error_0 = ProgrammingError()
    print(programming_error_0)
    pass


# Generated at 2022-06-26 00:41:35.293307
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    test_case_0()
    with pytest.raises(TypeError) as excinfo0:
        programming_error_1 = ProgrammingError("Example error!")
    excinfo0.match(r"too many arguments")
    with pytest.raises(TypeError) as excinfo1:
        programming_error_2 = ProgrammingError(None)
    excinfo1.match(r"too many arguments")
    with pytest.raises(TypeError) as excinfo2:
        programming_error_3 = ProgrammingError(1)
    excinfo2.match(r"too many arguments")
    with pytest.raises(TypeError) as excinfo3:
        programming_error_4 = ProgrammingError(1.0)
    excinfo3.match(r"too many arguments")

# Generated at 2022-06-26 00:41:37.098011
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    assert True


# Generated at 2022-06-26 00:41:38.021561
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:39.084556
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
        assert False
    except ProgrammingError:
        assert True



# Generated at 2022-06-26 00:41:41.550261
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError.passert(True, "broken")
    try:
        programming_error_0 = ProgrammingError.passert(False, "broken")
    except ProgrammingError as e:
        assert True

# Generated at 2022-06-26 00:41:45.644476
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    pass

# Generated at 2022-06-26 00:41:48.795164
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except Exception as ex:
        assert type(ex) == ProgrammingError
    else:
        assert False, "ProgrammingError not raised."



# Generated at 2022-06-26 00:41:51.525925
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        print("Test constructor of class ProgrammingError")
        test_case_0()
    except ProgrammingError:
        print("Test passed")
    else:
        print("Test failed")



# Generated at 2022-06-26 00:41:53.122323
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        test_case_0()

# Generated at 2022-06-26 00:41:55.076621
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except Exception as e:
        assert(isinstance(e, ProgrammingError))


# Generated at 2022-06-26 00:41:57.141288
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    print('== Testing constructor of class ProgrammingError ==')
    test_case_0()
    print('    Class ProgrammingError: OK')


if __name__ == "__main__":
    test_ProgrammingError()

# Generated at 2022-06-26 00:42:00.415846
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    except Exception as e:
        assert False, "Wrong exception type"


# Generated at 2022-06-26 00:42:02.437707
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Testing the constructor
    programming_error = ProgrammingError()

    # Testing the constructor with passing a message
    programming_error = ProgrammingError("message")

# Generated at 2022-06-26 00:42:03.629531
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Case 0
    programming_error_0 = ProgrammingError()
    assert isinstance(programming_error_0, ProgrammingError)



# Generated at 2022-06-26 00:42:05.806885
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test default constructor
    try:
        ProgrammingError()
        assert True
    except ProgrammingError as e:
        assert False
    except Exception as e:
        assert False


# Generated at 2022-06-26 00:42:10.988280
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if the exception works as expected.
    """
    try:
        raise ProgrammingError("Ooops!")
        assert(False)
    except ProgrammingError as e:
        assert(str(e) == "Ooops!")


# Generated at 2022-06-26 00:42:14.084830
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Unit test for constructor of class ProgrammingError."""
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)

# Generated at 2022-06-26 00:42:16.180271
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as pe:
        assert pe.args[0] == "Test"


# Generated at 2022-06-26 00:42:18.418287
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Error")
    except ProgrammingError as e:
        assert str(e) == "Error"


# Generated at 2022-06-26 00:42:19.773783
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except Exception as e:
        assert str(e) == ""


# Generated at 2022-06-26 00:42:26.218434
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.error import ProgrammingError

    # Is the exception class available?
    assert isinstance(ProgrammingError, type)

    # Can an exception be raised?
    with raises(ProgrammingError):
        ProgrammingError()

    # Does the message parameter work?
    with raises(ProgrammingError) as excinfo:
        ProgrammingError("Testing")

    assert str(excinfo.value) == "Testing"


# Unit test class ProgrammingError.passert()

# Generated at 2022-06-26 00:42:34.687033
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for :py:class:`ProgrammingError`.

    :raises AssertionError: In case that any of the test scenarios is not as expected.
    """

    # Test 1: Test an assertion which succeeds
    ProgrammingError.passert(True, "Testing a valid assertion")

    # Test 2: Test an assertion which fails
    try:
        ProgrammingError.passert(False, "Testing an invalid assertion")
        assert False, "The assertion must have raised a ProgrammingError"
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)

# Generated at 2022-06-26 00:42:35.627293
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("It worked")

# Generated at 2022-06-26 00:42:41.229214
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError.passert(False, "Expected failure")
        raise AssertionError("Expected failure")
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(True, "Unexpected failure")
        raise AssertionError("Unexpected failure")
    except ProgrammingError:
        pass

    try:
        ProgrammingError.passert(False, None)
        raise AssertionError("Expected failure")
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:42:43.510217
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, message="This is a test")
        assert False, "This should have raised"
    except ProgrammingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-26 00:42:50.634709
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("error message")
    except ProgrammingError as error:
        assert error.__str__() == "error message"



# Generated at 2022-06-26 00:42:54.515551
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("Testing...")
    assert isinstance(error, ProgrammingError)
    assert repr(error) == "ProgrammingError: Testing..."
    error = ProgrammingError()
    assert repr(error) == "ProgrammingError: Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:42:56.874180
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Error message")
        assert False
    except ProgrammingError as e:
        assert str(e) == "Error message"


# Generated at 2022-06-26 00:42:58.045150
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("message")


# Generated at 2022-06-26 00:42:59.818997
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        assert False, "Unxpected exception raised."

# Generated at 2022-06-26 00:43:11.066862
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class TestException(Exception):
        pass

    def test():
        try:
            ProgrammingError.passert(False, "BOOM")
            ProgrammingError.passert(False, None)
        except ProgrammingError as ex:
            # The default message is used if none is explicitly passed
            assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."
            # We must pass a string
            ProgrammingError.passert(False, "BOOM")
        else:
            assert False

    # No assertion error is raised
    test()
    try:
        # Now we raise an exception which does NOT inherit from ProgrammingError
        ProgrammingError.passert(False, "BOOM")
    except TestException:
        pass  # The test passed!
    else:
        assert False

# Generated at 2022-06-26 00:43:12.571346
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:43:14.185468
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"

# Generated at 2022-06-26 00:43:15.886921
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("My message")
    assert error.args == ("My message",)
    assert error.__str__() == "My message"

# Generated at 2022-06-26 00:43:17.975863
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise Exception("Exception was expected!")


# Generated at 2022-06-26 00:43:28.633949
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(ProgrammingError)


# Generated at 2022-06-26 00:43:29.353880
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "Message of error")

# Generated at 2022-06-26 00:43:31.621737
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert "Test" in str(e)

# Unit tests for passert

# Generated at 2022-06-26 00:43:37.021291
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except:
        assert False


# Generated at 2022-06-26 00:43:42.752004
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Check if a ProgrammingError is raised an handled.
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.message == "Broken coherence. Check your code against domain logic to fix it."
    except Exception as e:
        assert False, "Wrong exception raised: " + str(e)


# Generated at 2022-06-26 00:43:43.539519
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-26 00:43:45.349465
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError():
        pass

    with ProgrammingError("Test message"):
        pass


# Generated at 2022-06-26 00:43:47.229724
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("This is a programming error.")
    assert str(e) == "This is a programming error."


# Generated at 2022-06-26 00:43:49.696568
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    with raises(ProgrammingError) as excinfo:
        raise ProgrammingError("Something went wrong.")

    assert "" != str(excinfo.value)



# Generated at 2022-06-26 00:43:51.378552
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test does not assert anything: it's for coverage
    try:
        raise ProgrammingError("Error")
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:44:13.598140
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    expected_message = "Test Message"

    # Act
    try:
        raise ProgrammingError(expected_message)
    except ProgrammingError as actual:
        # Assert
        assert actual.__str__() == expected_message

# Generated at 2022-06-26 00:44:16.427131
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError(None)
    with raises(ProgrammingError):
        ProgrammingError("")
    with raises(ProgrammingError):
        ProgrammingError("This is a programming error.")


# Generated at 2022-06-26 00:44:16.975527
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-26 00:44:21.276604
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class TestError(ProgrammingError):
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return repr(self.value)

    try:
        raise TestError(2*2)
    except TestError as e:
        assert e.value == 4
    else:
        pass


# Generated at 2022-06-26 00:44:22.327327
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError()


# Generated at 2022-06-26 00:44:24.565747
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("testing error message")
    except ProgrammingError as error:
        assert str(error) == "testing error message"



# Generated at 2022-06-26 00:44:32.334598
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Testing with a true condition
    try:
        ProgrammingError.passert(True, "This is a valid condition")
    except ProgrammingError:
        assert False, """An assertion that is True should not raise an exception"""

    # Testing with a false condition
    try:
        ProgrammingError.passert(False, "This is an invalid condition")
    except ProgrammingError as e:
        assert True, f"""The assertion condition is False and thus the exception should be raised"""
        assert str(e) == "This is an invalid condition"
    else:
        assert False, f"""The assertion condition is False and thus the exception should be raised"""

    # Testing with a false condition and no message

# Generated at 2022-06-26 00:44:33.091377
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError('Expected error')



# Generated at 2022-06-26 00:44:37.618238
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    expected_message = "Message of the error"

    # Act
    error = ProgrammingError(expected_message)

    # Assert
    assert isinstance(error, Exception)
    assert isinstance(error, ProgrammingError)
    assert error.args == (expected_message, )
    assert str(error) == expected_message


# Generated at 2022-06-26 00:44:39.443731
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("Test")
    assert ProgrammingError("Test").args[0] == "Test"


# Generated at 2022-06-26 00:45:23.395606
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test the :py:class:`ProgrammingError` constructor.

    :raises AssertionError: In case of any failure.
    """
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)
    else:
        raise AssertionError("ProgrammingError() should raise an exception.")


# Generated at 2022-06-26 00:45:25.423155
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except Exception as e:
        assert str(e) == "test"


# Generated at 2022-06-26 00:45:26.718245
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        assert True


# Generated at 2022-06-26 00:45:31.596237
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "Test message")
    try:
        ProgrammingError.passert(False, "Test message")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:45:33.081815
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    message = "Test"
    try:
        raise ProgrammingError(message)
    except ProgrammingError as e:
        assert message == str(e)

# Generated at 2022-06-26 00:45:40.160562
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test for :py:func:`ProgrammingError.__init__`.
    """
    # Test default values
    try:
        ProgrammingError()
    except ProgrammingError as error:
        assert error.__str__() == "Broken coherence. Check your code against domain logic to fix it."

    # Test explicit message
    try:
        ProgrammingError("Boom!")
    except ProgrammingError as error:
        assert error.__str__() == "Boom!"

    # Test assertion
    try:
        ProgrammingError.passert(False, "Boom!")
    except ProgrammingError as error:
        assert error.__str__() == "Boom!"


# Generated at 2022-06-26 00:45:43.873716
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError.__bases__ == (Exception,)
    assert ProgrammingError.__qualname__ == "ProgrammingError"
    assert ProgrammingError.__module__ == __name__
    assert issubclass(ProgrammingError, Exception)
    assert not issubclass(ProgrammingError, TypeError)
    assert not issubclass(ProgrammingError, BaseException)


# Generated at 2022-06-26 00:45:46.310906
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Example message")
    except ProgrammingError as e:
        assert str(e) == "Example message"


# Generated at 2022-06-26 00:45:50.947288
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests if the constructor of class :py:class:`ProgrammingError` works properly.

    :raises AssertionError: If the class does not work properly.
    """
    try:
        raise ProgrammingError("Test error")
    except ProgrammingError as ex:
        assert ex.args
        assert ex.args[0] == "Test error"


# Generated at 2022-06-26 00:45:53.454248
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Failing")
    except Exception as e:
        raise AssertionError(e)
    try:
        ProgrammingError.passert(False, "Failing")
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:47:44.783474
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(Exception) as e_info:
        raise ProgrammingError()
    assert e_info.value.__class__ == ProgrammingError

    with pytest.raises(Exception) as e_info:
        raise ProgrammingError("A message")
    assert e_info.value.__class__ == ProgrammingError


# Generated at 2022-06-26 00:47:46.324779
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Exception")
    except ProgrammingError as e:
        assert str(e) == "Exception"

# Generated at 2022-06-26 00:47:52.090531
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    try:
        raise ProgrammingError("message")
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, "message")
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(True, "message")
    except ProgrammingError:
        raise AssertionError("Should not raise ProgrammingError")

# Generated at 2022-06-26 00:47:52.864277
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    return



# Generated at 2022-06-26 00:47:54.854676
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert str(e) == "This is a test."


# Generated at 2022-06-26 00:47:56.371839
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert False, "Programming Error should not be raised"
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:47:59.145421
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("a programming error"):
        pass
    with ProgrammingError.passert(True, "error"):
        pass
    with ProgrammingError.passert(False, "error"):
        pass

# Generated at 2022-06-26 00:48:03.921841
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        assert False, "An exception was raised when it shouldn't: " + str(e)

    try:
        ProgrammingError.passert(False, None)
        assert False, "An exception should have been raised."
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it.", str(e)

# Generated at 2022-06-26 00:48:05.668753
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(None)

# Generated at 2022-06-26 00:48:07.556639
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, None):
        pass

    with ProgrammingError.passert(False, None):
        assert False, "The previous step should have thrown an error."