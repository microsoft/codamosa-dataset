

# Generated at 2022-06-26 00:41:21.840043
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        # Unit test for constructor
        test_case_0()
    except Exception as e:
        print('ProgrammingError() raised exception:', e)

test_ProgrammingError()

# Generated at 2022-06-26 00:41:24.280989
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == 'Broken coherence. Check your code against domain logic to fix it.'


# Generated at 2022-06-26 00:41:26.606478
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    expected_string = "Broken coherence. Check your code against domain logic to fix it."
    assert ProgrammingError().__str__() == expected_string



# Generated at 2022-06-26 00:41:27.996855
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    assert isinstance(ProgrammingError(), Exception)
    assert isinstance(ProgrammingError(), ProgrammingError)

# Generated at 2022-06-26 00:41:29.938703
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as ex:
        assert ex
        assert True
    except Exception as ex:
        assert False



# Generated at 2022-06-26 00:41:31.690162
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass
    else:
        assert False



# Generated at 2022-06-26 00:41:32.401926
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()


# Generated at 2022-06-26 00:41:34.128629
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    
    assert programming_error_0.args == ('',)
    assert programming_error_0.with_traceback is None

# Generated at 2022-06-26 00:41:37.100513
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    expected_message = "Broken coherence. Check your code against domain logic to fix it."
    assert str(programming_error_0) == expected_message


# Generated at 2022-06-26 00:41:38.934219
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Use assert statements to ensure expected behaviour
    try:
        test_case_0()
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-26 00:41:44.418068
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as e:
        print("Programming error catched : '{0}'".format(e.args[0]))


# Generated at 2022-06-26 00:41:45.790269
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert True



# Generated at 2022-06-26 00:41:48.495865
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    from pypara.errors import ProgrammingError

    with raises(ProgrammingError):
        programming_error_0 = ProgrammingError()


# Generated at 2022-06-26 00:41:51.288004
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test case 0 in constructor of class ProgrammingError
    test_case_0()

if __name__ == '__main__':
    # Test constructor of class ProgrammingError
    test_ProgrammingError()

# Generated at 2022-06-26 00:41:52.818408
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        return True
    return False


# Generated at 2022-06-26 00:41:54.311934
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except TypeError:
        print("Testing case #0 passes")



# Generated at 2022-06-26 00:41:57.567548
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()
    programming_error_1 = ProgrammingError("Broken coherence.")
    assert programming_error_0.args == tuple()
    assert programming_error_1.args == ("Broken coherence.",)
    assert programming_error_1.message == "Broken coherence."



# Generated at 2022-06-26 00:41:59.274762
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()


# Generated at 2022-06-26 00:42:01.654256
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Broken coherence. Check your code against domain logic to fix it.")



# Generated at 2022-06-26 00:42:04.954287
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the proper construction of an instance of :py:class:`ProgrammingError`.
    """
    try:
        # Arrange
        programming_error_1 = ProgrammingError()

    except Exception:
        # Act
        return False

    # Assert
    return True



# Generated at 2022-06-26 00:42:09.362770
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Error")
    except ProgrammingError as e:
        assert "Error" in str(e)
        raise


# Generated at 2022-06-26 00:42:13.543851
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that the constructor of :py:class:`ProgrammingError` works.
    """
    try:
        raise ProgrammingError("This is a test.")
    except ProgrammingError as ex:
        assert str(ex) == "This is a test."


# Generated at 2022-06-26 00:42:19.343668
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Good case
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        pass
    except Exception as err: # pragma: no cover
        raise AssertionError(f"Assertion failed: {err}")

    # Bad case
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    except Exception as err: # pragma: no cover
        raise AssertionError(f"Assertion failed: {err}")

# Generated at 2022-06-26 00:42:21.081102
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        "A string".split(".")
        ProgrammingError.passert(False, "Constructor of Programming error failed")
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:42:27.117132
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is just a unit test")
        assert False
    except ProgrammingError as e:
        assert e.args == ("This is just a unit test", )


# Generated at 2022-06-26 00:42:31.135702
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is just a test")
    except ProgrammingError as e:
        assert "This is just a test" == str(e)
        return
    assert False  # We expect an exception to reach this point!

# Generated at 2022-06-26 00:42:33.938515
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-26 00:42:36.648116
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=missing-docstring
    try:
        raise ProgrammingError("Hello world!")
    except ProgrammingError as err:
        assert str(err) == "Hello world!"


# Generated at 2022-06-26 00:42:38.425123
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test ProgrammingError")
    except ProgrammingError as e:
        assert str(e) == "Test ProgrammingError"

# Generated at 2022-06-26 00:42:43.357439
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "The name of the author is missing.")
    except ProgrammingError as e:  # pragma: no cover
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError:  # pragma: no cover
        assert True

# Generated at 2022-06-26 00:43:00.932400
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    The python interpreter does not allow the definition of unit tests within classes. Hence, we have to do it this way.
    """
    ex1 = ProgrammingError("My message 1")
    ex1.passert(False, "My message 2")
    try:
        ex1.passert(False, None)
        assert False, "Cannot assert"
    except ProgrammingError as ex2:
        assert str(ex2) == "Broken coherence. Check your code against domain logic to fix it.", "Cannot assert"
    try:
        ex1.passert(True, None)
        assert True, "Can assert"
    except ProgrammingError:
        assert False, "Cannot assert"

# Generated at 2022-06-26 00:43:02.669412
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My error")
    except ProgrammingError as e:
        assert e.args[0] == "My error"

# Generated at 2022-06-26 00:43:04.572002
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("Error of programming.")
    assert err.args == ("Error of programming.",)

# Unit Test for the method passert of the class ProgrammingError

# Generated at 2022-06-26 00:43:07.132300
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError): # type: ignore
        ProgrammingError()


# Generated at 2022-06-26 00:43:09.593157
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    with pytest.raises(ProgrammingError):
        ProgrammingError()
    with pytest.raises(ProgrammingError):
        ProgrammingError("")
    with pytest.raises(ProgrammingError):
        ProgrammingError("Something went wrong")


# Generated at 2022-06-26 00:43:16.072184
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)


# Generated at 2022-06-26 00:43:18.332638
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as error:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:43:20.617362
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="Broken coherence.")
        assert False, "ProgrammingError.passert should raise exception"
    except ProgrammingError:
        assert True


# Generated at 2022-06-26 00:43:21.846332
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an exception.")
    except ProgrammingError as e:
        assert str(e) == "This is an exception."

# Generated at 2022-06-26 00:43:24.714108
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError should have been raised")


# Generated at 2022-06-26 00:43:39.747908
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    p = ProgrammingError("message")
    assert(str(p)) == "message"

# Generated at 2022-06-26 00:43:48.500833
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Broken coherence. We should not be here!!!")
        assert False
    except ProgrammingError as err:
        assert err.args[0]=="Broken coherence. We should not be here!!!"
    try:
        ProgrammingError.passert(False, "")
        assert False
    except ProgrammingError as err:
        assert err.args[0]=="Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as err:
        assert err.args[0]=="Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:43:50.904245
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Message")
    except ProgrammingError as e:
        assert(e.args[0] == "Message")
    else:
        assert(False)


# Generated at 2022-06-26 00:43:55.135807
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError, match="Broken coherence. Check your code against domain logic to fix it."):
        ProgrammingError.passert(False, None)
    with pytest.raises(ProgrammingError, match="Invalid argument."):
        ProgrammingError.passert(False, "Invalid argument.")

# Generated at 2022-06-26 00:43:57.397179
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message="My message")
    except ProgrammingError as e:
        assert str(e) == "My message"


# Generated at 2022-06-26 00:44:03.012815
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "some message"):
        pass
    try:
        with ProgrammingError.passert(False, "some message"):
            pass
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:44:04.861507
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        assert True


# Generated at 2022-06-26 00:44:08.224090
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test Message")
    except ProgrammingError as e:
        assert e.__str__() == "Test Message"


# Generated at 2022-06-26 00:44:16.344652
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.
    """

    # If the condition is ``True`` an exception should not be raised
    ProgrammingError.passert(True, "Expected message")

    # If the condition is ``False`` and there is a message an exception should be raised
    thrown = False
    try:
        ProgrammingError.passert(False, "Expected message")
    except ProgrammingError as programmingError:
        assert programmingError.__str__() == "Broken coherence. Check your code against domain logic to fix it."
        thrown = True
    assert thrown

    # If the condition is ``False`` and there is not a message an exception should be raised
    thrown = False

# Generated at 2022-06-26 00:44:17.450033
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:44:39.915114
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as e:
        assert "This is a test" in str(e)

# Generated at 2022-06-26 00:44:41.865939
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("Message")


# Generated at 2022-06-26 00:44:45.616133
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    assert isinstance(ProgrammingError(), ProgrammingError)
    assert isinstance(ProgrammingError(''), ProgrammingError)
    assert isinstance(ProgrammingError('test'), ProgrammingError)


# Generated at 2022-06-26 00:44:47.509857
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("error message")
    except ProgrammingError as ex:
        assert str(ex) == "error message"


# Generated at 2022-06-26 00:44:49.481910
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-26 00:44:55.966054
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert_true(isinstance(e, Exception))
        assert_true(isinstance(e, ProgrammingError))
        assert_equal(str(e), "")
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert_true(isinstance(e, Exception))
        assert_true(isinstance(e, ProgrammingError))
        assert_equal(str(e), "test")


# Generated at 2022-06-26 00:44:58.577983
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, "Failed to fulfill condition."):
        pass

    with ProgrammingError.passert(False, "Failed to fulfill condition."):
        raise AssertionError("Expected exception to be raised.")

# Generated at 2022-06-26 00:45:00.960594
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as error:
        assert error.args is not None and len(error.args) == 1 and error.args[0] == "test"


# Generated at 2022-06-26 00:45:07.502007
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Broken code")
        assert False
    except ProgrammingError as e:
        assert "Broken code" == str(e)
    try:
        ProgrammingError.passert(True, "Broken code")
    except ProgrammingError as e:
        assert False
    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as e:
        assert "Broken coherence. Check your code against domain logic to fix it." == str(e)

# Generated at 2022-06-26 00:45:10.302572
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-26 00:46:08.285952
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Check your premises.")

    except ProgrammingError as error:
        assert str(error) == "Check your premises."


# Generated at 2022-06-26 00:46:09.203287
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    error = ProgrammingError("This is a test error")
    assert error


# Generated at 2022-06-26 00:46:12.667096
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Testing ProgrammingError.")
        assert False
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(True, "Testing ProgrammingError.")
    except ProgrammingError:
        assert False

# Generated at 2022-06-26 00:46:15.427476
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="foo")
        ProgrammingError(message=None)
        ProgrammingError()
    except Exception as e:
        assert False, f"Should not raise {e.__class__.__name__!r}. Reason: {e!r}."


# Generated at 2022-06-26 00:46:16.348432
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert (str(ProgrammingError("Error message.")) == "Error message.")

# Generated at 2022-06-26 00:46:18.026626
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Asserts that the constructor of class ProgrammingError works as expected."""

    error = ProgrammingError("This is a simple message")
    assert error.args == ("This is a simple message",)

# Generated at 2022-06-26 00:46:21.041297
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    # The constructor gets only called when the condition is not met.
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "This is a test")
    assert ProgrammingError.passert(True, "This is a test") is None

# Generated at 2022-06-26 00:46:22.528768
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    e = ProgrammingError("this is a test")

    assert e.args == ("this is a test",)


# Generated at 2022-06-26 00:46:23.813080
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
        assert False
    except ProgrammingError:
        assert True


# Generated at 2022-06-26 00:46:24.545453
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("message")


# Generated at 2022-06-26 00:48:19.728469
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError
    """
    ProgrammingError("Hello, World!")

# Generated at 2022-06-26 00:48:23.946958
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test with message
    try:
        ProgrammingError.passert(False, "Failure")
    except ProgrammingError as e:
        assert e.args[0] == "Failure"

    # Test without message
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:48:26.338068
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as e:
        assert str(e) == "Test"


# Generated at 2022-06-26 00:48:28.153207
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My message")
    except ProgrammingError as e:
        assert str(e) == "My message"


# Generated at 2022-06-26 00:48:28.846987
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()


# Generated at 2022-06-26 00:48:30.833336
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError(None).args == (None,)
    assert ProgrammingError("Problematic").args == ("Problematic",)


# Generated at 2022-06-26 00:48:33.695545
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError` constructor.
    """

    assert "Broken coherence. Check your code against domain logic to fix it." == ProgrammingError().args[0]
    assert "test" == ProgrammingError("test").args[0]


# Generated at 2022-06-26 00:48:35.170297
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test")
    except ProgrammingError as error:
        assert str(error) == "Test"


# Generated at 2022-06-26 00:48:37.247798
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:48:38.886045
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some kind of error.")
    except ProgrammingError as e:
        assert e.args[0] == "Some kind of error."
