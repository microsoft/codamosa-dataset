

# Generated at 2022-06-26 00:41:26.298320
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase, main
    from pickle import dumps, loads
    from types import TracebackType
    from copy import deepcopy
    from io import StringIO

    class TestProgrammingError(TestCase):
        def setUp(self) -> None:
            self.programming_error_0 = ProgrammingError()
            self.programming_error_1 = ProgrammingError("programming error message")
            self.programming_error_2 = ProgrammingError(None, "programming error error")
            self.programming_error_3 = ProgrammingError("programming error message", "programming error error")
            self.programming_error_4 = ProgrammingError("programming error message", "programming error error",
                                                         "programming error text")

        # Test the constructor.

# Generated at 2022-06-26 00:41:32.600526
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Test 1
    try:
        test_case_0()
    except ProgrammingError as e:
        # Check that the exception message is correct
        assert isinstance(e, ProgrammingError)

    # Test 2
    try:
        ProgrammingError.passert(False, "MASSAGE")
    except ProgrammingError as e:
        # Check that the exception message is correct
        assert e.args[0] == "MASSAGE"

    # Test 3
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        # Check that the exception message is correct
        assert e.args[0].startswith("Broken coherence. ")

# Generated at 2022-06-26 00:41:33.043721
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-26 00:41:34.512402
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
try:
    raise ProgrammingError()
except ProgrammingError:
    pass


# Generated at 2022-06-26 00:41:38.573849
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError().__class__.__name__ == "ProgrammingError"
    assert ProgrammingError.__code__.co_varnames == ("message",)
    assert ProgrammingError().__doc__ == "Provides a programming error exception.\n\n    The rationale for this exception is to raise them whenever we rely on meta-programming and the programmer has\n    introduced a statement which breaks the coherence of the domain logic."

# Generated at 2022-06-26 00:41:40.088097
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except Exception as e:
        print("The message of the exception is: {}".format(e))


# Generated at 2022-06-26 00:41:44.113633
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError().__class__ == ProgrammingError
    assert ProgrammingError().__class__ == ProgrammingError()

# Generated at 2022-06-26 00:41:45.497410
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()



# Generated at 2022-06-26 00:41:48.541472
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(programming_error_0, ProgrammingError)
    assert str(programming_error_0) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:41:51.001639
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert ProgrammingError.__doc__ is not None
    assert ProgrammingError.__init__ is not object.__init__

# Generated at 2022-06-26 00:41:56.838660
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # noinspection PyTypeChecker
    err = ProgrammingError(None)
    assert err.__str__() == "Broken coherence. Check your code against domain logic to fix it."
    assert err.__str__() == str(err)
    err = ProgrammingError("Error message")
    assert err.__str__() == "Error message"
    assert err.__str__() == str(err)


# Generated at 2022-06-26 00:42:00.377330
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("123")
    except Exception as e:
        assert(isinstance(e, ProgrammingError))

# Unit test of the passert method of class ProgrammingError

# Generated at 2022-06-26 00:42:02.724758
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as exception:
        assert exception.args[0] == "Test message"


# Generated at 2022-06-26 00:42:04.186353
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Hello, world!")
    except ProgrammingError as ex:
        assert ex.args[0] == "Hello, world!"


# Generated at 2022-06-26 00:42:06.359463
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Foo")
        assert False, "Expected ProgrammingError exception"
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:42:14.266222
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # A programming error must be raised when no coherence is met.
    with ProgrammingError.passert(False, "Any error message."):
        pass

    # The error message can be optional.
    with ProgrammingError.passert(False, None):
        pass

    # A programming error must not be raised when coherence is met.
    with ProgrammingError.passert(True, "Any error message."):
        pass

    # A programming error must not be raised when coherence is met.
    with ProgrammingError.passert(True, None):
        pass

# Generated at 2022-06-26 00:42:16.439026
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("The message")
    except ProgrammingError as ex:
        assert str(ex) == "The message"


# Generated at 2022-06-26 00:42:18.945774
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test unit for class :py:class:`ProgrammingError`.
    """
    error = ProgrammingError("There is something wrong!")
    assert error.args == ("There is something wrong!",)


# Generated at 2022-06-26 00:42:20.522405
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "foo")
    ProgrammingError.passert(True, "foo")

# Generated at 2022-06-26 00:42:22.254832
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:42:27.995615
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("What went wrong here?")
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)
        assert str(err) == "What went wrong here?"


# Generated at 2022-06-26 00:42:31.369001
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False


# Generated at 2022-06-26 00:42:36.016888
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as exc:
        assert exc.args == ("Broken coherence. Check your code against domain logic to fix it.", )
    try:
        raise ProgrammingError("A test message")
    except ProgrammingError as exc:
        assert exc.args == ("A test message", )

# Generated at 2022-06-26 00:42:39.059293
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    with assert_raises(ProgrammingError) as err:
        raise ProgrammingError("Foo!")
    assert_equal(err.exception.args[0], "Foo!")

# Generated at 2022-06-26 00:42:41.899283
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, ""):
        assert True
    with ProgrammingError.passert(False, "msg"):
        assert False
        assert False

# Generated at 2022-06-26 00:42:46.213385
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises

    # Call without any arguments
    with raises(ProgrammingError):
        ProgrammingError()

    # Call with an argument
    with raises(ProgrammingError) as excinfo:
        raise ProgrammingError("Hello world")

    # Check argument of exception
    exc: ProgrammingError = excinfo.value
    assert str(exc) == "Hello world"


# Generated at 2022-06-26 00:42:46.792389
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-26 00:42:48.079177
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:42:49.523527
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("This should not raise")

# Generated at 2022-06-26 00:42:52.440880
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Expected instantiation")
    except ProgrammingError as err:
        assert isinstance(err, ProgrammingError)
        assert str(err) == "Expected instantiation"


# Generated at 2022-06-26 00:42:59.696268
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as ex:
        ProgrammingError.passert(condition=False, message="Hi!")
    assert "Hi!" == str(ex.value)

# Generated at 2022-06-26 00:43:01.735038
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as e:
        assert(e.args[0] == "A message")

# Generated at 2022-06-26 00:43:12.492333
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "")
    except Exception as e:
        assert False, "ProgrammingError.passert() raised exception {0} despite of valid condition: {1}".format(
            type(e), str(e))
    try:
        ProgrammingError.passert(False, "")
        assert False, "ProgrammingError.passert() failed to raise exception despite of invalid condition."
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, "Test message")
    except ProgrammingError as e:
        assert str(e) == "Test message", "Unexpected error message found in exception."
        return
    assert False, "ProgrammingError.passert() failed to raise exception despite of invalid condition."

# Generated at 2022-06-26 00:43:15.053467
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as ex:
        assert isinstance(ex, ProgrammingError)
        assert ex.args[0] == "This is a test"


# Generated at 2022-06-26 00:43:17.802912
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A message")
    except ProgrammingError as e:
        assert str(e) == "A message"

# Generated at 2022-06-26 00:43:20.854293
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the :py:class:`ProgrammingError` class.

    :raises AssertionError: In case that any of the tests failed.
    """

    with ProgrammingError.passert(False, "Test Message"):
        assert False, "Shouldn't get here"

# Generated at 2022-06-26 00:43:22.046520
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        assert True
    else:
        assert False

# Generated at 2022-06-26 00:43:24.752653
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    try:
        ProgrammingError(message="A Programming Error")
    except ProgrammingError:
        pass
    else:
        pytest.fail("ProgrammingError not raised")

# Generated at 2022-06-26 00:43:28.411980
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="test message")
    except ProgrammingError as e:
        assert e.message == "test message"


# Generated at 2022-06-26 00:43:30.875338
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("asdf")
    except Exception as ex:
        assert isinstance(ex, ProgrammingError)
        assert str(ex) == "asdf"


# Generated at 2022-06-26 00:43:44.448273
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("some message")



# Generated at 2022-06-26 00:43:47.014627
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        raise AssertionError("ProgrammingError must raise ProgrammingError")


# Generated at 2022-06-26 00:43:49.397292
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something is wrong here")
    except ProgrammingError as e:
        assert str(e) == "Something is wrong here"



# Generated at 2022-06-26 00:43:52.013177
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the functionality of the constructor of :py:class:`ProgrammingError`.
    """

    # Constructor should not raise an error if no message is provided
    ProgrammingError()
    ProgrammingError("Test")

# Generated at 2022-06-26 00:43:55.703244
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as py_err:
        assert py_err.args[0] == "Test message"
        assert py_err.__str__() == "Test message"
        assert py_err.__repr__() == "ProgrammingError('Test message',)"

# Generated at 2022-06-26 00:43:57.372359
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc = ProgrammingError("This is an error.")
    assert str(exc) == "This is an error."



# Generated at 2022-06-26 00:44:07.212359
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:class:`ProgrammingError` and :py:class:`ProgrammingError.passert`.
    """
    try:
        ProgrammingError.passert(False, "Broken coherence")
        assert False, "Should fail"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence"
        pass

    try:
        ProgrammingError.passert(False, None)
        assert False, "Should fail"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
        pass

# Generated at 2022-06-26 00:44:10.849451
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is a unit test.")
    except ProgrammingError:
        # Expected
        pass
    else:
        raise AssertionError("The condition is false, so it is expected to raise a ProgrammingError.")



# Generated at 2022-06-26 00:44:13.865727
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Failed to check if function x() is different to y()??")
    except ProgrammingError as e:
        assert str(e) == "Failed to check if function x() is different to y()??"

# Unit tests for assert() method

# Generated at 2022-06-26 00:44:16.059494
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an error")
        raise Exception("ProgrammingError did not raise!")
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:44:43.808922
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        assert True
    else:
        # There are lots of misunderstandings between `assert` and `assert ... else`:
        # https://stackoverflow.com/questions/3749979/why-does-python-assert-raise-an-exception-if-a
        # https://stackoverflow.com/questions/483666/python-reverse-inverse-a-mapping
        assert False, "Programming error not raised"


# Generated at 2022-06-26 00:44:52.730829
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of the class :py:class:`ProgrammingError`.

    This function is meant to be run by :py:mod:`run_test.py <test.run_test>`.
    """
    from typing import List
    from pypara.exceptions import ProgrammingError

    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        raise AssertionError("Programming error has been raised in case that it should not: {}".format(e))

    try:
        ProgrammingError.passert(False, None)
        raise AssertionError("Programming error has not been raised in case that it should")
    except ProgrammingError as e:
        print("Programming error has been raised: {}".format(e))


# Generated at 2022-06-26 00:44:56.789430
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Should be catched by the try-except clause")
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, "Should be catched by the try-except clause")
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:45:05.346839
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for constructor of class ProgrammingError.

    This also tests :py:meth:`ProgrammingError.passert`.

    :raises AssertionError: In case that the assertions fail.
    """
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as pe:
        assert pe.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("ProgrammingError.passert does not raise error when condition is False")
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError:
        raise AssertionError("ProgrammingError.passert raises error when condition is True")


# Generated at 2022-06-26 00:45:10.601422
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Act and assert
    try:
        ProgrammingError.passert(True, "Not raised")
        ProgrammingError.passert(False, "Message")
        assert False, "Should have raised"
    except ProgrammingError as e:
        assert e.args[0] == "Message"
    try:
        ProgrammingError.passert(False, None)
        assert False, "Should have raised with default message"
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:45:13.190388
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the functionality of constructor of :py:class:`ProgrammingError`.
    """
    with ProgrammingError.passert(True, ''):
        pass
    with ProgrammingError.passert(False, ''):
        pass

# Generated at 2022-06-26 00:45:15.285581
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Should raise the exception
    try:
        raise ProgrammingError("Foo bar")
    except ProgrammingError as e:
        assert str(e) == "Foo bar"


# Generated at 2022-06-26 00:45:16.524434
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("foobar")
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:45:18.223866
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Condition is not fulfilled.")
    except ProgrammingError as exception:
        assert exception.args[0] == "Condition is not fulfilled."


# Generated at 2022-06-26 00:45:22.170972
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for class :py:class:`ProgrammingError`
    """
    try:
        raise ProgrammingError("Something wrong with your code. Check the requirements against domain logic.")
    except ProgrammingError as e:
        assert str(e) == "Something wrong with your code. Check the requirements against domain logic."
        return
    assert False, "Should have raised a ProgrammingError exception."


# Generated at 2022-06-26 00:46:20.942323
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("My error message")
    except ProgrammingError as e:
        assert e.args[0] == "My error message"


# Generated at 2022-06-26 00:46:22.424282
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "Some message")

# Generated at 2022-06-26 00:46:27.679952
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def test(expected: str, message: Optional[str]):
        error = ProgrammingError(message)
        assert str(error) == expected, "ProgrammingError: unexpected error message: '{}'".format(error)

    # Test null message
    test("Broken coherence. Check your code against domain logic to fix it.", None)

    # Test empty message
    test("Broken coherence. Check your code against domain logic to fix it.", "")

    # Test message with chars
    test("This is a message", "This is a message")


# Generated at 2022-06-26 00:46:29.471415
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing")
    except ProgrammingError as err:
        assert err.args[0] == "Testing"



# Generated at 2022-06-26 00:46:30.288641
# Unit test for constructor of class ProgrammingError

# Generated at 2022-06-26 00:46:32.983531
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as error:
        assert isinstance(error, ProgrammingError)
    else:
        raise RuntimeError


# Generated at 2022-06-26 00:46:35.511211
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as error:
        assert str(error) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False

# Generated at 2022-06-26 00:46:40.568787
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a programming error")
    except ProgrammingError as error:
        assert error.__class__.__name__ == 'ProgrammingError', \
            "class should have been ProgrammingError, instead is %s" % error.__class__.__name__
        assert "This is a programming error" in str(error), \
            "Message should be 'This is a programming error', instead is '%s'" % str(error)


# Generated at 2022-06-26 00:46:49.261422
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the :py:class:`ProgrammingError` class.
    """
    def error_constructor_null():
        """
        Tests the :py:class:`ProgrammingError` constructor with null parameters.
        """
        ProgrammingError()
    def error_constructor_message_null():
        """
        Tests the :py:class:`ProgrammingError` constructor with null message parameter.
        """
        ProgrammingError(None)
    def error_constructor_message():
        """
        Tests the :py:class:`ProgrammingError` constructor with non-null message parameter.
        """
        ProgrammingError("TEST")
    def error_constructor_message_and_cause():
        """
        Tests the :py:class:`ProgrammingError` constructor with both message and cause parameters.
        """

# Generated at 2022-06-26 00:46:51.960178
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # GIVEN: Instance of ProgrammingError
    error = ProgrammingError()

    # WHEN: Inspect message
    # THEN: Correct message
    assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:48:50.672584
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:48:52.087578
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        raise ProgrammingError("Foo")


# Generated at 2022-06-26 00:48:53.826611
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("broken")
    except ProgrammingError as e:
        assert str(e) == "broken"


# Generated at 2022-06-26 00:48:58.902427
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "It works!")
    except ProgrammingError:
        raise AssertionError("Failed to check a true condition!")

    try:
        ProgrammingError.passert(False, "It works!")
    except ProgrammingError as e:
        assert str(e) == "It works!"

    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:49:00.749608
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing the exception...")
    except ProgrammingError as e:
        # We expect the following sequence to be true
        assert e.args[0] == "Testing the exception..."


# Generated at 2022-06-26 00:49:03.137921
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        msg = "hello"
        ProgrammingError.passert(False, msg)
        assert False
    except ProgrammingError as e:
        assert str(e) == msg
    except:
        assert False



# Generated at 2022-06-26 00:49:05.275115
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests that the constructor of :py:class:`ProgrammingError` works as expected."""
    assert issubclass(ProgrammingError, Exception)


# Generated at 2022-06-26 00:49:06.872389
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-26 00:49:12.450763
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Condition is True
    try:
        ProgrammingError.passert(True, "Expected True to be True")
    except ProgrammingError:
        assert False, "Unexpected error"
    # Condition is False
    try:
        ProgrammingError.passert(False, "Expected False to be True")
    except ProgrammingError as e:
        assert str(e) == "Expected False to be True"
    # Condition is False and no message is provided
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:49:13.654916
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test error")
    except ProgrammingError:
        pass
