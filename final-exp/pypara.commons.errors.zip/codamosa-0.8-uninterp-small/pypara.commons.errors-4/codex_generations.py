

# Generated at 2022-06-26 00:41:21.005445
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)
    assert isinstance(ProgrammingError(), Exception)
    assert ProgrammingError.__name__ == "ProgrammingError"


# Generated at 2022-06-26 00:41:21.973032
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except Exception:
        pass



# Generated at 2022-06-26 00:41:22.808049
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()



# Generated at 2022-06-26 00:41:28.881054
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # test_case_0
    try:
        test_case_0()
    except ProgrammingError as e:
        print("Test case 0 successful")

    # test_case_1
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        print("Test case 1 failed")
    else:
        print("Test case 1 successful")

    # test_case_2
    try:
        ProgrammingError.passert(False, None)
    except ProgrammingError as e:
        print("Test case 2 successful")

# Generated at 2022-06-26 00:41:29.739051
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:30.469245
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()

# Generated at 2022-06-26 00:41:31.441277
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:32.910138
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass
    else:
        raise Exception('Error!')

# Generated at 2022-06-26 00:41:35.230689
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert issubclass(ProgrammingError, Exception)

    expected = ProgrammingError()

    assert isinstance(expected, ProgrammingError)
    assert isinstance(expected, Exception)
    assert issubclass(ProgrammingError, Exception)



# Generated at 2022-06-26 00:41:37.581544
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()

    # Class assertion
    assert isinstance(programming_error_0, Exception)


# Generated at 2022-06-26 00:41:42.905111
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
        assert False
    except ProgrammingError as e:
        assert True
        assert e.args == ()


# Generated at 2022-06-26 00:41:44.621563
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError as e_0:
        assert e_0
    else:
        assert False



# Generated at 2022-06-26 00:41:46.512578
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()



# Generated at 2022-06-26 00:41:47.538892
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert isinstance(ProgrammingError(), ProgrammingError), "Type mismatch"


# Generated at 2022-06-26 00:41:49.467579
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass
    else:
        assert False

# Generated at 2022-06-26 00:41:50.437937
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError() is not None



# Generated at 2022-06-26 00:41:52.990720
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # Initialize a programming error
    error = ProgrammingError()

    # Check the message of the error
    assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:41:55.293796
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        programming_error_0 = ProgrammingError()
    except ProgrammingError as e:
        print(e)
        raise AssertionError()

# Generated at 2022-06-26 00:41:58.772258
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:59.881109
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert repr(ProgrammingError()) == 'ProgrammingError()'



# Generated at 2022-06-26 00:42:04.839670
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of the class :py:class:`ProgrammingError`.
    """
    err = ProgrammingError("Message")
    assert err.args[0] == "Message"


# Generated at 2022-06-26 00:42:08.098589
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="Test error message")
    except ProgrammingError as error:
        assert error.args[0] == "Test error message"


# Generated at 2022-06-26 00:42:09.874808
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as exp:
        assert isinstance(exp, ProgrammingError)


# Generated at 2022-06-26 00:42:13.636675
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test cast for ProgrammingError constructor.
    :raises AssertionError: In case that the test fails.
    """
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)

# Generated at 2022-06-26 00:42:16.091049
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "Oops! An error!"
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as e:
        assert str(e) == msg


# Generated at 2022-06-26 00:42:18.683209
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:42:21.253261
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test.")
    except ProgrammingError as e:
        assert str(e) == "Test."
        assert e.args == ("Test.",)
    except Exception as e:
        raise e
    else:
        raise Exception("Expected exception.")


# Generated at 2022-06-26 00:42:24.667864
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("An error has occurred")
    except ProgrammingError as e:
        assert str(e) == "An error has occurred"


# Generated at 2022-06-26 00:42:26.740929
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        return
    raise AssertionError("ProgrammingError should be raised")



# Generated at 2022-06-26 00:42:30.398863
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Asserts that the constructor of class :py:class:`ProgrammingError` does not raise an exception with the default
    argument.
    """
    ProgrammingError()


# Generated at 2022-06-26 00:42:38.448378
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is a test")
    except:
        pass
    else:
        raise AssertionError("Failure")


# Generated at 2022-06-26 00:42:42.751752
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("There is a problem here...")
    except ProgrammingError as e:
        assert e.__doc__ == ProgrammingError.__doc__
        assert e.args[0] == "There is a problem here..."
    else:
        assert False, "The error was not raised!"


# Generated at 2022-06-26 00:42:45.354789
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Act
    e = ProgrammingError("Hello, world!")
    # Assert
    assert isinstance(e, ProgrammingError)
    assert e.args == ("Hello, world!",)


# Generated at 2022-06-26 00:42:47.359077
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    try:
        raise ProgrammingError()
    except ProgrammingError:
        pytest.fail("ProgrammingError raises itself")



# Generated at 2022-06-26 00:42:48.305015
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("Works")

# Generated at 2022-06-26 00:42:55.970567
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "foo")
    except ProgrammingError as e:
        assert str(e) == "foo"
    else:
        raise ProgrammingError("Unit test failed.")



# Generated at 2022-06-26 00:43:00.193786
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests for constructor of :py:class:`ProgrammingError`.

    This is a very strange unit test because it is expected to **fail**.
    If not, the program has a bug.
    """
    try:
        ProgrammingError(message="My very own error!")
        assert False, "Unreachable code."
    except TypeError:
        assert True


# Generated at 2022-06-26 00:43:03.471937
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pyassert import assert_that, equals_to

    class MyError(ProgrammingError):
        pass

    error = MyError("Some Message")
    assert_that(error.__class__, equals_to(MyError))
    assert_that(error.args, equals_to(("Some Message",)))


# Generated at 2022-06-26 00:43:07.339975
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("this is a programming error")
    except ProgrammingError as e:
        assert str(e) == "this is a programming error"


# Generated at 2022-06-26 00:43:11.019567
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def f(param):
        ProgrammingError.passert(param, 'Hi!')

    f(True)
    try:
        f(False)
        raise AssertionError('fail')
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:43:28.032126
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    try:
        ProgrammingError.passert(True, None)
    except ProgrammingError as e:
        pass
    else:
        assert False

# Generated at 2022-06-26 00:43:29.295248
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError as e:
        pass


# Generated at 2022-06-26 00:43:32.036602
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is from a test")
    except ProgrammingError as e:
        assert str(e) == "This is from a test"
    else:
        raise Exception("Expected exception")


# Generated at 2022-06-26 00:43:40.345514
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    def tst(condition):
        if condition:
            return
        raise ProgrammingError()

    from pytest import raises
    with raises(ProgrammingError):
        tst(False)



# Generated at 2022-06-26 00:43:42.418029
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as pe:
        assert str(pe) == "Test message"


# Generated at 2022-06-26 00:43:44.898920
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This error is expected in unit tests.")
    except ProgrammingError as pe:
        assert pe.args[0] == "This error is expected in unit tests."


# Generated at 2022-06-26 00:43:47.847630
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests construction of :py:class:`ProgrammingError`
    """
    try:
        raise ProgrammingError("test")
    except ProgrammingError as e:
        assert str(e) == "test"


# Generated at 2022-06-26 00:43:50.114068
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError, message="Expecting to raise an ProgrammingError"):
        ProgrammingError.passert(condition=False, message="Programming Error")

# Generated at 2022-06-26 00:43:52.339417
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Exercise
    try:
        raise ProgrammingError("an error")
    except ProgrammingError as pe:
        assert pe.args == ("an error", )


# Generated at 2022-06-26 00:43:56.712112
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests that the constructor and message of :py:class:`ProgrammingError` works as expected."""
    message = "This is a message"
    error = ProgrammingError(message)
    assert isinstance(error, Exception) and issubclass(ProgrammingError, Exception)
    assert error.args[0] == message
    assert str(error) == message


# Generated at 2022-06-26 00:44:18.698128
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()

# Generated at 2022-06-26 00:44:20.637260
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "Broken coherence."
    pe = ProgrammingError(msg)
    assert pe.args[0] == msg


# Generated at 2022-06-26 00:44:23.214496
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """Tests the constructor of class :py:class:`ProgrammingError`."""
    try:
        raise ProgrammingError("This is a test")
    except ProgrammingError as ex:
        assert ex.args == ("This is a test",)


# Generated at 2022-06-26 00:44:27.911482
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # pylint: disable=missing-function-docstring
    # pylint: disable=no-else-return
    # pylint: disable=no-else-raise

    ProgrammingError()

    exception = ProgrammingError("No message expected")
    assert str(exception) == "No message expected"

    exception = ProgrammingError(message="No message expected")
    assert str(exception) == "No message expected"



# Generated at 2022-06-26 00:44:30.526912
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test exception.")
    except ProgrammingError as exception:
        assert str(exception) == "Test exception."
        assert repr(exception) == "ProgrammingError(Test exception.)"


# Generated at 2022-06-26 00:44:32.025409
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError.passert(True, None) as err:
        pass


# Generated at 2022-06-26 00:44:34.841098
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    expected_message = "A test message"
    # Act
    error = ProgrammingError(expected_message)
    # Assert
    assert error.args == (expected_message,)
    assert str(error) == expected_message


# Generated at 2022-06-26 00:44:36.084484
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:44:41.866774
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Act
    try:
        ProgrammingError()
    except ProgrammingError as error:
        # Assert
        expected_error_message = "Broken coherence. Check your code against domain logic to fix it."
        assert error.__str__() == expected_error_message, "Unexpected error message."
    else:
        assert False, "Unexpected lack of exception."


# Generated at 2022-06-26 00:44:46.898909
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Some message")
    except Exception as err:
        assert type(err) is ProgrammingError
        assert err.args == ("Some message",)
    try:
        raise ProgrammingError()
    except Exception as err:
        assert type(err) is ProgrammingError
        assert err.args == ("Broken coherence. Check your code against domain logic to fix it.",)


# Generated at 2022-06-26 00:45:38.749255
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as dut:
        assert repr(dut) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        raise AssertionError("test should have raised an exception")


# Generated at 2022-06-26 00:45:39.809730
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:45:41.860888
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as exception:
        ProgrammingError(message="Test message")
    assert str(exception.value) == "Test message"



# Generated at 2022-06-26 00:45:43.164086
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(False, "This is a message.")

# Generated at 2022-06-26 00:45:47.251869
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Failed assertion")
        assert False, "Exception not raised"
    except ProgrammingError as e:
        assert str(e) == "Failed assertion"
    except Exception:
        assert False, "Wrong exception raised"


test_ProgrammingError()

# Generated at 2022-06-26 00:45:49.214096
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("test")
    except ProgrammingError:
        pass
    else:
        raise Exception("Class ProgrammingError did not catch exception")


# Generated at 2022-06-26 00:45:51.500671
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Silent constructor
    ProgrammingError()
    # Silent constructor with message
    ProgrammingError(message="Something went wrong.")


# Generated at 2022-06-26 00:45:56.182694
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():

    # No message
    try:
        ProgrammingError()
        assert False, "Should not get here"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    # Message
    try:
        ProgrammingError("This is the message")
        assert False, "Should not get here"
    except ProgrammingError as e:
        assert str(e) == "This is the message"


# Generated at 2022-06-26 00:45:57.862743
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("message")
    except ProgrammingError as error:
        assert str(error) == "message"


# Generated at 2022-06-26 00:46:00.359175
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest

    with pytest.raises(ProgrammingError) as excinfo:
        ProgrammingError.passert(False, "Nothing wrong")

    assert "Nothing wrong" in str(excinfo.value)

# Unit tests for constructor of class ProgrammingError

# Generated at 2022-06-26 00:47:58.420358
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("assertion failed")
    except ProgrammingError as e:
        assert e.args[0] == "assertion failed"



# Generated at 2022-06-26 00:48:00.068953
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is an error.")
    except ProgrammingError as e:
        assert str(e) == "This is an error."

# Generated at 2022-06-26 00:48:02.524568
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest.case import TestCase

    exception = ProgrammingError("This is a custom message")
    TestCase().assertEqual("This is a custom message", exception.message)


# Generated at 2022-06-26 00:48:04.648268
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():  # pylint: disable=unused-argument
    err = ProgrammingError()
    assert "Broken coherence. Check your code against domain logic to fix it." == err.args[0]


# Generated at 2022-06-26 00:48:07.259888
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("This is supposed to happen.")
    except ProgrammingError as error:
        assert error.args[0] == "This is supposed to happen."

# Generated at 2022-06-26 00:48:10.725475
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Verifies the constructor of :py:class:`ProgrammingError`.
    """
    error = ProgrammingError("Programming error detected. ")
    assert error.__class__.__name__ == "ProgrammingError"
    assert str(error) == "Programming error detected. "
    assert error.__cause__ is None
    assert error.__context__ is None



# Generated at 2022-06-26 00:48:15.605060
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(condition=True, message="")
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(condition=False, message="")
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(condition=False, message=None)

# Generated at 2022-06-26 00:48:17.746103
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Something is wrong")
    except ProgrammingError as e:
        assert str(e) == "Something is wrong"


# Generated at 2022-06-26 00:48:19.606505
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Internal error: Calling an undefined function.")
    except Exception as error:
        assert error.args[0] == "Internal error: Calling an undefined function."


# Generated at 2022-06-26 00:48:21.715706
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Testing.")
    except ProgrammingError as e:
        assert e.__str__() == "Testing."