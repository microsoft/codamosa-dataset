

# Generated at 2022-06-26 00:41:27.636668
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError as e:
        assert ProgrammingError.__name__ == "ProgrammingError"
        assert str(e) == ''
        
    try:
        ProgrammingError('')
    except ProgrammingError as e:
        assert ProgrammingError.__name__ == "ProgrammingError"
        assert str(e) == ''
        
    try:
        ProgrammingError('testing')
    except ProgrammingError as e:
        assert ProgrammingError.__name__ == "ProgrammingError"
        assert str(e) == 'testing'


# Generated at 2022-06-26 00:41:28.613618
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()
    print("Passed unit test for class ProgrammingError")

# Generated at 2022-06-26 00:41:30.268087
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError()


if __name__ == '__main__':
    test_ProgrammingError()
    test_case_0()

# Generated at 2022-06-26 00:41:31.054244
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()

# Generated at 2022-06-26 00:41:32.601641
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    test_case_0()
    assert True


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 00:41:33.292932
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    programming_error_0 = ProgrammingError()

# Generated at 2022-06-26 00:41:34.255548
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:41:36.966336
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    msg = "Test"
    try:
        raise ProgrammingError(msg)
    except ProgrammingError as e:
        assert e.args[0] == msg



# Generated at 2022-06-26 00:41:38.587628
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert programming_error_0.msg == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:41:39.584582
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        test_case_0()
    except ProgrammingError:
        assert True


# Generated at 2022-06-26 00:41:43.348543
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor of class :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:41:44.490359
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:41:51.124466
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "Message")
    except ProgrammingError:
        assert False, "ProgrammingError must not be raised."
    try:
        ProgrammingError.passert(False, "Message")
        assert False, "ProgrammingError must be raised."
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, None)
        assert False, "ProgrammingError must be raised."
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:41:52.651530
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False


# Generated at 2022-06-26 00:41:55.616120
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This test is successful")
        assert False
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(True, "This test is successful")
    except ProgrammingError:
        assert False

# Generated at 2022-06-26 00:41:58.009354
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Some message")
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False, "ProgrammingError was expected to be raised."

# Generated at 2022-06-26 00:42:00.878998
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test programming error")
    except ProgrammingError as e:
        assert "Test programming error" == e.args[0]
    except Exception:
        assert False


# Generated at 2022-06-26 00:42:03.547250
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Act & Assert
    try:
        ProgrammingError.passert(condition=False, message="An error")
    except ProgrammingError as ex:
        assert "An error" == ex.args[0]

# Generated at 2022-06-26 00:42:05.975678
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Hello world")
    except Exception as exception:
        assert isinstance(exception, ProgrammingError)
        assert str(exception) == "Hello world"


# Generated at 2022-06-26 00:42:16.894270
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from unittest import TestCase
    from unittest.mock import MagicMock

    class TestProgrammingError(TestCase):
        def test_passert(self):
            captured_exception = ""
            try:
                ProgrammingError.passert(False, "You done goofed!")
            except ProgrammingError as programming_error:
                captured_exception = programming_error

            self.assertEqual(captured_exception, "You done goofed!")

            ProgrammingError.passert(True, "I did not do anything wrong!")

            function = MagicMock(return_value=False)
            ProgrammingError.passert(function, "I did not do anything wrong!")

            function.assert_called()
            self.assertRaises(ProgrammingError, ProgrammingError.passert, False, error_message)

    test

# Generated at 2022-06-26 00:42:22.018458
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Arrange
    expected = "Broken coherence. Check your code against domain logic to fix it."

    # Act
    e = ProgrammingError()

    # Assert
    assert str(e) == expected


# Generated at 2022-06-26 00:42:25.981478
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Should raise programming error")
    except ProgrammingError:
        pass
    else:
        raise AssertionError("Should have raised ProgrammingError")
    ProgrammingError.passert(True, "Should raise programming error")

# Generated at 2022-06-26 00:42:27.494354
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except:
        pass


# Generated at 2022-06-26 00:42:28.841813
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError(message="Broken coherence. Check your code against domain logic to fix it.")

# Generated at 2022-06-26 00:42:32.482325
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert e.value is None
    try:
        raise ProgrammingError("A message.")
    except ProgrammingError as e:
        assert e.value == "A message."


# Generated at 2022-06-26 00:42:36.685903
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(condition=False, message=None)
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."
    else:
        assert False


# Generated at 2022-06-26 00:42:39.107917
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError.passert(False, "")

# Generated at 2022-06-26 00:42:40.913302
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    exc = ProgrammingError("Test exception")
    assert str(exc) == "Test exception"

# Generated at 2022-06-26 00:42:42.751522
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    import pytest
    with pytest.raises(ProgrammingError):
        ProgrammingError.passert(condition=False, message="I do not like this error")

# Generated at 2022-06-26 00:42:49.869979
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert not ProgrammingError.passert(condition=False, message="This is the expected message")
    try:
        assert not ProgrammingError.passert(condition=False, message="This is the expected message")
    except ProgrammingError as assert_e:
        assert assert_e.args[0] == "This is the expected message"
    try:
        assert not ProgrammingError.passert(condition=False, message=None)
    except ProgrammingError as assert_e:
        assert assert_e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:42:56.979841
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "test")
        assert False, "Expected to raise a ProgrammingError"
    except ProgrammingError:
        pass



# Generated at 2022-06-26 00:42:59.122239
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("Test")
    except Exception as e:
        assert str(e) == "Test"


# Generated at 2022-06-26 00:43:07.422695
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("An error message.")
    except ProgrammingError as e:
        assert str(e) == "An error message."

    try:
        raise ProgrammingError()
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it."

    try:
        ProgrammingError.passert(True, "another message.")
        ProgrammingError.passert(False, "another message.")
    except ProgrammingError as e:
        assert str(e) == "another message."

# Generated at 2022-06-26 00:43:09.930818
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("test")
    except ProgrammingError as error:
        assert error.args[0] == "test"

# Generated at 2022-06-26 00:43:16.692173
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of class :py:class:`ProgrammingError`.
    """
    try:
        ProgrammingError(None)
    except ProgrammingError as e:
        assert not e.args
    try:
        ProgrammingError("")
    except ProgrammingError as e:
        assert not e.args
    try:
        ProgrammingError("Test")
    except ProgrammingError as e:
        assert e.args[0] == "Test"
    try:
        ProgrammingError("Test", "Message")
    except ProgrammingError as e:
        assert e.args[0] == "Test"
        assert e.args[1] == "Message"


# Generated at 2022-06-26 00:43:18.239333
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError(message="Just testing...")


# Generated at 2022-06-26 00:43:20.507423
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message")
    except ProgrammingError as e:
        assert e.args == ("Test message",)
    else:
        raise Exception("No exception raised")


# Generated at 2022-06-26 00:43:23.134940
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests that a ProgrammingError can be constructed with a message.
    """
    ProgrammingError("This is a test message.")

# Generated at 2022-06-26 00:43:24.013938
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("message")


# Generated at 2022-06-26 00:43:27.271852
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests the constructor of :py:class:`ProgrammingError`.
    """
    e = ProgrammingError("")
    assert str(e) == ""


# Generated at 2022-06-26 00:43:41.442507
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert ProgrammingError("Test message").args[0]=="Test message"

# Generated at 2022-06-26 00:43:43.797532
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from .testing import assert_raises
    with assert_raises(ProgrammingError, "Broken coherence. Check your code against domain logic to fix it."):
        ProgrammingError.passert(False, None)

# Generated at 2022-06-26 00:43:47.816616
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class TestProgrammingError(ProgrammingError):
        """
        Test of class ProgrammingError.
        """

    TestProgrammingError("This is a test")  # Without errors
    TestProgrammingError.passert(True, "This is a test")  # Without errors
    TestProgrammingError.passert(False, "This is a test")  # With errors

# Generated at 2022-06-26 00:43:50.101838
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests :py:func:`ProgrammingError.__init__`
    """
    ProgrammingError("foo")

# Unit tests for class ProgrammingError

# Generated at 2022-06-26 00:43:52.051483
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Error.")
    except ProgrammingError as e:
        assert e.args[0] == "Error."


# Generated at 2022-06-26 00:43:58.532041
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(True, "any message")
    except ProgrammingError:
        raise Exception("Shouldn't happen.")
    try:
        ProgrammingError.passert(False, "any message")
        raise Exception("Shouldn't happen.")
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, None)
        raise Exception("Shouldn't happen.")
    except ProgrammingError:
        pass
    try:
        ProgrammingError.passert(False, "")
        raise Exception("Shouldn't happen.")
    except ProgrammingError:
        pass

# Generated at 2022-06-26 00:44:04.512250
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)
    else:
        assert False, "ProgrammingError should have been raised"


# Generated at 2022-06-26 00:44:09.534536
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Tests constructor and passert in ProgrammingError.
    """
    ProgrammingError.passert(True, "OK")
    try:
        ProgrammingError.passert(False, "Should be raised and caught.")
        assert False
    except ProgrammingError as ex:
        assert str(ex) == "Should be raised and caught."

    try:
        ProgrammingError.passert(False, None)
        assert False
    except ProgrammingError as ex:
        assert str(ex) == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:44:13.254755
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(None)
    except ProgrammingError as error:
        assert error.args[0] == "Broken coherence. Check your code against domain logic to fix it."
    try:
        raise ProgrammingError("foo")
    except ProgrammingError as error:
        assert error.args[0] == "foo"



# Generated at 2022-06-26 00:44:16.059503
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Tested message")
    except ProgrammingError as e:
        print(e)
        assert str(e) == "Tested message"
        assert e.__cause__ is None


# Generated at 2022-06-26 00:44:38.471897
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError):
        ProgrammingError("An error happened")


# Generated at 2022-06-26 00:44:40.991304
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Should raise")
    except ProgrammingError as e:
        assert str(e) == "Should raise"


# Generated at 2022-06-26 00:44:43.454112
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass
    else:
        assert False



# Generated at 2022-06-26 00:44:50.429994
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Unit test for the constructor of :py:class:`ProgrammingError`.
    """
    try:
        raise ProgrammingError(None)
    except Exception as error:
        if error.args[0] != "Broken coherence. Check your code against domain logic to fix it.":
            raise AssertionError("Fail to create a ProgrammingError exception with None message.")
    try:
        raise ProgrammingError("Custom message")
    except Exception as error:
        if error.args[0] != "Custom message":
            raise AssertionError("Fail to create a ProgrammingError exception with custom message.")



# Generated at 2022-06-26 00:44:52.313671
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with pytest.raises(ProgrammingError) as _:
        ProgrammingError.passert(False, "This is a test error")

# Generated at 2022-06-26 00:44:57.863729
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError(message="A non-empty message")
    except ProgrammingError as e:
        assert str(e) == "A non-empty message"

    try:
        raise ProgrammingError(message="")
    except ProgrammingError as e:
        assert str(e) == ""

    try:
        raise ProgrammingError(message=None)
    except ProgrammingError as e:
        assert str(e) == ""



# Generated at 2022-06-26 00:45:00.997242
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Broken coherence. Check your code against domain logic to fix it.")
    except ProgrammingError as e:
        assert e.args[0] == "Broken coherence. Check your code against domain logic to fix it."

# Generated at 2022-06-26 00:45:03.962823
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "Something not true!")
        raise True
    except ProgrammingError:
        pass

test_ProgrammingError()

# Generated at 2022-06-26 00:45:07.381994
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("A programming error.")
    except ProgrammingError as e:
        assert e.__cause__ is None
        assert e.__context__ is None
        assert e.__traceback__ is None
        assert e.args == ("A programming error.",)


# Generated at 2022-06-26 00:45:09.441088
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError.passert(True, "This is an error")
    ProgrammingError.passert(False, "This is an error")

# Generated at 2022-06-26 00:46:13.386332
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    class TestException(ProgrammingError): pass

    try:
        ProgrammingError.passert(False, "Test message")
        assert False, "This should not happen"
    except ProgrammingError as e:
        assert str(e) == "Test message", "The message must match"
    try:
        TestException.passert(False, "Test message")
        assert False, "This should not happen"
    except TestException as e:
        assert str(e) == "Test message", "The message must match"
    try:
        ProgrammingError.passert(False, None)
        assert False, "This should not happen"
    except ProgrammingError as e:
        assert str(e) == "Broken coherence. Check your code against domain logic to fix it.", "The message must match"

# Generated at 2022-06-26 00:46:15.237317
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    for msg in ("", "asdf"):
        e = ProgrammingError(msg)
        assert type(e) == ProgrammingError
        assert str(e) == msg

# Generated at 2022-06-26 00:46:16.657531
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    err = ProgrammingError("This is a test")
    assert err.args[0] == "This is a test"



# Generated at 2022-06-26 00:46:21.142899
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Raises an exception
    try:
        ProgrammingError.passert(False, "Some error")
        assert False, "ProgrammingError.passert does not raise an exception"
    except ProgrammingError:
        pass
    # Does not raise an exception
    try:
        ProgrammingError.passert(True, "Some error")
        assert True, "ProgrammingError.passert raises an exception"
    except ProgrammingError:
        assert False, "ProgrammingError.passert raises an exception"

# Generated at 2022-06-26 00:46:22.898418
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("An error.")
    except ProgrammingError as e:
        assert str(e) == "An error."


# Generated at 2022-06-26 00:46:25.037819
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    """
    Test that a :py:class:`ProgrammingError` is raised by the constructor
    """
    try:
        raise ProgrammingError()
    except ProgrammingError:
        pass


# Generated at 2022-06-26 00:46:27.836663
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError(message="Hey, there was an error.")
    except ProgrammingError as programmError:
        assert programmError.args[0] == "Hey, there was an error."
    else:
        assert False

# Generated at 2022-06-26 00:46:29.970988
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError("This is a test.")
    except ProgrammingError as e:
        assert str(e) == "This is a test."


# Generated at 2022-06-26 00:46:30.468496
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    ProgrammingError("test")

# Generated at 2022-06-26 00:46:32.851402
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert isinstance(e, ProgrammingError)


# Generated at 2022-06-26 00:48:27.743166
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "This is an error.")
    except ProgrammingError as e:
        assert str(e) == "This is an error."

# Generated at 2022-06-26 00:48:29.218431
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    from pytest import raises
    with raises(ProgrammingError):
        ProgrammingError(message="This is a test.",)

# Generated at 2022-06-26 00:48:31.453361
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError()
    except Exception as e:
        assert e.__str__() == "Broken coherence. Check your code against domain logic to fix it."


# Generated at 2022-06-26 00:48:33.790364
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    def test_case_false():
        ProgrammingError.passert(False, "expected error")
    try:
        test_case_false()
    except ProgrammingError as pe:
        pass


# Generated at 2022-06-26 00:48:35.303410
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test message.") as err:
        assert type(err) == ProgrammingError
        assert "Test message" in err.args

# Generated at 2022-06-26 00:48:36.695799
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        raise ProgrammingError("Test message.")
    except ProgrammingError as e:
        assert str(e) == "Test message."



# Generated at 2022-06-26 00:48:38.384616
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        pass
    else:
        raise Exception("Programming error was not raised")

# Generated at 2022-06-26 00:48:39.231793
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    with ProgrammingError("Test error"):
        pass  # noqa: WPS420

# Generated at 2022-06-26 00:48:43.042659
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    assert "should not raise an exception" == str(ProgrammingError.passert(True, "should not raise an exception"))
    try:
        assert "should raise an exception" == str(ProgrammingError.passert(False, "should raise an exception"))
    except ProgrammingError as e:
        assert "should raise an exception" == str(e)


# Generated at 2022-06-26 00:48:45.888026
# Unit test for constructor of class ProgrammingError
def test_ProgrammingError():
    # Happy path
    try:
        ProgrammingError.passert(True, "")
    except ProgrammingError:
        assert False
    # When exception is raised
    try:
        ProgrammingError.passert(False, "")
    except ProgrammingError:
        assert True