

# Generated at 2022-06-25 18:26:51.647477
# Unit test for function program
def test_program():
    assert program() == 'program'

# Generated at 2022-06-25 18:26:54.123413
# Unit test for function program
def test_program():
    # TODO: implement test for program
    pass


if __name__ == '__main__':
    exit_status = main()
    sys.exit(exit_status.value)

# Generated at 2022-06-25 18:26:58.386994
# Unit test for function program
def test_program():
    args = argparse.Namespace
    args.output_options = ["--output_options"]
    args.follow = False
    args.check_status = False
    args.download = False
    exit_status = program(args, Environment())
    # Check for the exit status
    assert exit_status == ExitStatus.SUCCESS 
    assert program.__name__ == 'program'
    

# Generated at 2022-06-25 18:27:09.010579
# Unit test for function program
def test_program():
    class Ns():
        download = False
        output_options = []
        follow = False
        headers = {}
        download_resume = False
        output_file = None
        quiet = False
        check_status = False

    class Args():
        def __init__(self):
            self.download = False
            self.output_options = []
            self.follow = False
            self.headers = {}
            self.download_resume = False
            self.output_file = None
            self.quiet = False
            self.check_status = False

    env = Environment()
    args = Args()
    args.download = False
    args.output_options = []
    args.follow = False
    args.headers = {}
    args.download_resume = False
    args.output_file = None
    args

# Generated at 2022-06-25 18:27:09.884551
# Unit test for function program
def test_program():
    assert program([], []) != None


# Generated at 2022-06-25 18:27:19.987222
# Unit test for function main
def test_main():
    exit_status = main(['http', 'www.google.com', '-v'])
    assert exit_status == ExitStatus.SUCCESS
    exit_status = main(['http', 'www.google.com', '-o', 'hello.txt', '-v'])
    assert exit_status == ExitStatus.SUCCESS
    exit_status = main(['http', 'https://api.github.com/user/emails', '-v', '-a', 'jawahar273:*****', 'GET'])
    assert exit_status == ExitStatus.SUCCESS
    exit_status = main(['http', 'https://api.github.com/user/emails', '-v', '-a', 'jawahar273:*****', '--follow'])
    assert exit_status == ExitStatus.SUCCESS
   

# Generated at 2022-06-25 18:27:31.068113
# Unit test for function program
def test_program():
    from httpie.output.streams import StdoutStderrBytesIO
    from httpie.cli.definition import parser
    args = parser.parse_args(
        args=['-h']
    )
    env = Environment()
    env.stdout = StdoutStderrBytesIO()
    env.stderr = StdoutStderrBytesIO()
    request_body_read_callback = lambda chunk: print(f'chunk: {chunk}')
    messages = collect_messages(args=args, config_dir=env.config.directory,
                                    request_body_read_callback=request_body_read_callback)
    # Process messages as they're generated
    for message in messages:
        is_request = isinstance(message, requests.PreparedRequest)

# Generated at 2022-06-25 18:27:33.105482
# Unit test for function main
def test_main():
    assert main(['http', 'http://httpbin.org/get']) == ExitStatus.SUCCESS

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:27:44.527458
# Unit test for function program
def test_program():
    class test_env(Environment):
        def __init__(self):
            self.config = test_config()
            self.log_error = 1
            self.log_warning = 1
            self.stderr = 1

    class test_config:
        def __init__(self):
            self.directory = 1

    class test_argparse:
        def __init__(self):
            self.follow = True
            self.headers = 1
            self.output_file = 1
            self.check_status = True
            self.quiet = True
            self.output_options = [1, 2, 3]

    exit_status = program(test_argparse(), test_env())

if __name__ == '__main__':
    test_case_0()
    test_program()

# Generated at 2022-06-25 18:27:50.947710
# Unit test for function program
def test_program():
    class MockEnvironment:
        def __init__(self):
            self.program_name = 'http'

    # Pre-process args, handle some special types of invocations,
    # and run the main program with error handling.

    # Return exit status code.
    with open('examples/sample.json', 'rb') as f:
        binary_data = f.read()

    # TODO: Refactor and drastically simplify, especially so that the separator logic is elsewhere.
    # exit_status = 0
    downloader = None
    initial_request: Optional[requests.PreparedRequest] = None
    final_response: Optional[requests.Response] = None

    # def separate():
    #     getattr(env.stdout, 'buffer', env.stdout).write(MESSAGE_SEPARATOR_BYTES)



# Generated at 2022-06-25 18:28:32.506819
# Unit test for function main
def test_main():
    from io import open
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie import output

    env = Environment()
    args = ['http', 'https://httpbin.org/get']

    # Test case 1
    exit_status_1 = main(args, env=env)
    assert exit_status_1 == ExitStatus.SUCCESS
    
    # Test case 2
    args.append('--debug')
    exit_status_2 = main(args, env=env)
    assert exit_status_2 == ExitStatus.SUCCESS

    # Test case 3
    args.append('--traceback')
    if is_windows:
        # FIXME: Windows tests fail. Either figure out why they fail or remove them.
        import pytest
        pytest.skip()
    exit

# Generated at 2022-06-25 18:28:40.221727
# Unit test for function program

# Generated at 2022-06-25 18:28:49.496026
# Unit test for function main
def test_main():
    from io import StringIO
    from contextlib import redirect_stdout

    args = ['http']
    env = Environment(stdin=StringIO(),
                      stdin_isatty=False,
                      stdout=StringIO(),
                      stdout_isatty=True,
                      stderr=StringIO())


# Generated at 2022-06-25 18:28:52.755452
# Unit test for function program
def test_program():
    from httpie.cli.parser import parser

    args = parser.parse_args([
        '--method', 'GET',
        'http://httpbin.org/headers'
    ])

    program(args)

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:28:54.462572
# Unit test for function program
def test_program():
    #
    # TODO: write test cases
    #
    raise Exception('not implemented')


# Generated at 2022-06-25 18:28:57.917757
# Unit test for function main
def test_main():
    args = ['./httpie.py', 'httpbin.org']
    assert main(args) == 0


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-25 18:29:06.266224
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    # The interface for program is a little strange, so I made the test for it.
    # The parser arguments must have been set beforehand, because the program is to call the parse_args() method.
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', action='store_true')
    parsed_args = parser.parse_args(args=['--a', '--b'])
    program()
    class Temp():
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
    main(args=['python', 'http', '-a', '-b', 'www.baidu.com'])
    # The program() function does not check whether args

# Generated at 2022-06-25 18:29:07.931724
# Unit test for function main
def test_main():

    # Case 0
    exit_status_0 = main()
    assert exit_status_0 == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:29:14.661282
# Unit test for function program
def test_program():
    import argparse

# Generated at 2022-06-25 18:29:18.742090
# Unit test for function main
def test_main():
    import importlib
    importlib.reload(sys)
    # saved_stdout = sys.stdout
    saved_argv = sys.argv
    sys.argv = ['http']
    try:
        test_case_0()
    finally:
        sys.argv = saved_argv
        # sys.stdout = saved_stdout


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 18:29:48.455304
# Unit test for function main
def test_main():
    assert main(['http', 'google.com']) == ExitStatus.SUCCESS
    assert main(['http', 'httpbin.me']) == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:29:49.811183
# Unit test for function program
def test_program():
    program(['url'], Environment())


# Generated at 2022-06-25 18:29:53.074500
# Unit test for function main
def test_main():
    sys.argv = ['http', '--follow', '--output', 'tfile', 'http://localhost:8000/echo']
    main()
    print(sys.argv)

# Generated at 2022-06-25 18:29:55.642886
# Unit test for function program
def test_program():
    exit_status = main(['http', '--json', 'https://example.com', '(', '(', '(', '(', ')'])
    assert exit_status == ExitStatus.ERROR_JSON_PARSE

# Generated at 2022-06-25 18:29:58.299507
# Unit test for function program
def test_program():
    try:
        exit_status = program(args='-v', env='Envrionment')
    except ValueError as e:
        print(e)


# Generated at 2022-06-25 18:29:59.780617
# Unit test for function main
def test_main():
    assert test_case_0() == ExitStatus.ERROR

# Generated at 2022-06-25 18:30:04.071325
# Unit test for function main
def test_main():
    print()
    test_case_0()
    # test_case_1()
    # test_case_2()
    # test_case_3()
    # test_case_4()
    # test_case_5()
    # test_case_6()
    # test_case_7()
    # test_case_8()
    # test_cas

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 18:30:11.035625
# Unit test for function program
def test_program():
    from httpie.cli.args import parse_args
    from httpie.input import (
        _build_input_stream,
        _get_input_data,
        SEP_CREDENTIALS, SEP_GROUP, SEP_HEADERS, SEP_DATA, SEP_DATA_RAW_JSON,
        SEP_FILES, SEP_QUERYSTRING,
        DEFAULT_FORM_CONTENT_TYPE,
        DataDict
    )
    from httpie.plugins import builtin

    # This is a function test for program
    argv = ['http', '-v', 'http://httpbin.org/get']
    args = parse_args(args=argv, env=Environment())
    ############ test initial_vars ############

# Generated at 2022-06-25 18:30:18.318917
# Unit test for function main
def test_main():
    from collections import namedtuple
    import pytest
    from httpie.client import collect_messages
    from mock import patch
    from requests import PreparedRequest
    from httpie.context import Environment
    from httpie.output.writer import MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager

    # set the default exit status
    exit_status = ExitStatus.SUCCESS

    # mock the requests messages
    request = PreparedRequest()
    request.method = 'GET'
    request.url = 'https://httpie.org'

    # mock the parsed arguments
    Args = namedtuple('Args', ['output_options', 'follow'])
    args = Args(
        output_options=['b', 'h'],
        follow=False,
    )

   

# Generated at 2022-06-25 18:30:19.400000
# Unit test for function main
def test_main():
    assert ExitStatus.SUCCESS == main()

# Generated at 2022-06-25 18:31:05.233445
# Unit test for function main
def test_main():
    sys.argv = ['http', '--debug', 'https://api.github.com/user', '-a', 'invalid-token']
    # Sets exit_status_0 based on sys.argv
    exit_status_0 = main()
    # Sets exit_status_1 based on sys.argv
    exit_status_1 = main(['http', '--debug', '"https://httpbin.org/get"', '"Authorization: Bearer invalid-token"'])
    # Sets exit_status_2 based on sys.argv
    exit_status_2 = main(['http', '--debug', 'https://httpbin.org/get', 'Authorization:Bearer invalid-token'])

    # Unit test for function program

# Generated at 2022-06-25 18:31:13.710869
# Unit test for function program
def test_program():
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.client import collect_messages
    from httpie.config import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.context import Environment
    from httpie import __version__ as httpie_version
    from httpie.status import ExitStatus, http_status_to_exit_status

    class RequestsMessage_01:
        def __init__(self):
            self.headers = None
            self.body = None
            self.is_

# Generated at 2022-06-25 18:31:15.966706
# Unit test for function program
def test_program():
    exit_status_0 = main()
    print(f'Exit status: {exit_status_0}')


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 18:31:19.488509
# Unit test for function program
def test_program():
    args = ['httpie.py', 'http://httpbin.org/get']
    program(args=args, env=Environment())


# Generated at 2022-06-25 18:31:28.600222
# Unit test for function main
def test_main():
    argv0 = ['/home/venv/bin/http', '--debug', '-method','GET','https://www.baidu.com/','User-Agent:','Mozilla/5.0','Accept-Language:','en-US,en;q=0.5','Accept-Encoding:','gzip, deflate','Connection:','keep-alive','Upgrade-Insecure-Requests:','1','Pragma:','no-cache','Cache-Control:','no-cache']
    program_name, *args = argv0
    env = Environment()
    env.program_name = os.path.basename(program_name)
    args = decode_raw_args(args, env.stdin_encoding)
    plugin_manager.load_installed_plugins()

    from httpie.cli.definition import parser


# Generated at 2022-06-25 18:31:33.869728
# Unit test for function main
def test_main():
    assert main() == 0
    assert main(['-v']) == 0
    assert main(['-j']) == 0
    assert main(['-b']) == 0
    assert main(['-h']) == 0
    assert main(['-v']) == 0
    assert main(['-c']) == 0
    assert main(['-f']) == 0
    assert main(['-p']) == 0
    assert main(['-v']) == 0
    assert main(['-i']) == 0
    assert main(['-s']) == 0
    assert main(['-A']) == 0
    assert main(['-v']) == 0
    assert main(['-H']) == 0
    assert main(['-I']) == 0
    assert main(['-S']) == 0


# Generated at 2022-06-25 18:31:40.259357
# Unit test for function program
def test_program():
    from argparse import Namespace
    from httpie.cli.definition import parser
    from httpie.status import ExitStatus
    input_args = ["--help"]
    parsed_args = parser.parse_args(args=input_args)
    assert isinstance(parsed_args, Namespace)
    exit_status = program(parsed_args, None)
    assert isinstance(exit_status, ExitStatus)
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:31:41.711540
# Unit test for function main
def test_main():
    exit_status_0 = main()
    assert exit_status_0 == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:31:51.545027
# Unit test for function main
def test_main():
    # Test case 0
    with patch('sys.argv', ['http'], autospec=True) as mock_argv:
        with patch('sys.stdout', new=StringIO()) as mock_stdout:
            test_case_0()
            assert mock_stdout.getvalue() == 'test_main'
    # Test case 1
    with patch('sys.argv', ['http'], autospec=True) as mock_argv:
        with patch('sys.stdout', new=StringIO()) as mock_stdout:
            test_case_0()
            assert mock_stdout.getvalue() == 'test_main'
    # Test case 2

# Generated at 2022-06-25 18:31:53.066549
# Unit test for function main
def test_main():
    params = ['httpie.py', '--debug', '--traceback', '--follow']
    main(params)

# Generated at 2022-06-25 18:32:31.731987
# Unit test for function main
def test_main():
    # call the main function
    exitStatus = main()
    assert exitStatus == 1

# Generated at 2022-06-25 18:32:38.534216
# Unit test for function main
def test_main():
    """
    On 2020-05-25T09:47:39.378067+08:00, run the following command:
    python3 -m pytest -vs -q ~/workspace/httpbin-integration-test/bin/httpie/httpie_main.py::test_main
    """
    cmd = ['httpie', 'httpbin.org/get', 'X-Foo:bar']
    test_case_0_main_result = main(args=cmd)


# Generated at 2022-06-25 18:32:39.898543
# Unit test for function main
def test_main():
    exit_status = main(args=[])
    assert exit_status == ExitStatus.ERROR

# Generated at 2022-06-25 18:32:49.136056
# Unit test for function main
def test_main():
    import pytest

    with pytest.raises(SystemExit):
        main([])
    with pytest.raises(requests.Timeout):
        main(['--timeout', '0.0001'])
    with pytest.raises(requests.TooManyRedirects):
        main(['--max-redirects', '0'])
    with pytest.raises(requests.HTTPError):
        main(['--check-status', 'http://httpbin.org/status/404'])
    with pytest.raises(requests.HTTPError):
        main(['--check-status', 'http://httpbin.org/status/405'])
    with pytest.raises(requests.HTTPError):
        main(['--check-status', 'http://httpbin.org/status/500'])
   

# Generated at 2022-06-25 18:32:52.177413
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser()
    parser.add_argument('-v', dest='verbose', action='store_true')
    args = parser.parse_args(['-v'])
    environment = Environment()
    program(args=args, env=environment)

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 18:32:56.529115
# Unit test for function program
def test_program():
    exit_status = program(args=['--debug', '--prompt-for-password=mypassword', 'https://myserver/myendpoint'],
                          env=Environment())
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:32:59.209823
# Unit test for function program
def test_program():
    assert program([1,2,3], exit_status_0) == (1,2,3)

# Generated at 2022-06-25 18:33:07.263398
# Unit test for function main
def test_main():
    from . import env, output
    from .config import Config
    from .constants import DEFAULT_ENV, DEFAULT_OUTPUT_OPTIONS
    from .models import Environment

    class SubEnv(Environment):

        def __init__(self, **kwargs):
            super().__init__(
                config=Config(**kwargs),
                **kwargs
            )

    def program(args: argparse.Namespace, env: SubEnv) -> ExitStatus:
        exit_status = code = ExitStatus.SUCCESS
        messages = collect_messages(args=args,
                                    config_dir=env.config.directory)
        for message in messages:
            with_headers, with_body = get_output_options(args=args, message=message)

# Generated at 2022-06-25 18:33:09.809983
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--help'])
    env = Environment()
    program(args, env)


# Generated at 2022-06-25 18:33:19.214083
# Unit test for function program
def test_program():
    from contextlib import redirect_stdout
    from io import StringIO
    import requests
    from httpie.cli.argtypes import KeyValueArg
    from httpie.compat import urlsplit
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.registry import plugin_manager
    plugin_manager.unregister_all()
    plugin_manager.register(HTTPBasicAuth)
    plugin_manager.register(HTTPTokenAuth)
    env = Environment()
    args = ["GET", "http://httpbin.org/get"]
    result = StringIO()
    with redirect_stdout(result):
        program(args=args, env=env)
    content = result.getvalue()

# Generated at 2022-06-25 18:34:46.232450
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit as e:
        assert e.code == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:34:54.037746
# Unit test for function program
def test_program():
    # Test args
    test_args = argparse.Namespace()
    test_args.output_options = ""
    test_args.download = False
    test_args.output_file_specified = False
    test_args.check_status = False
    test_args.follow = False
    test_args.download_resume = False
    test_args.quiet = False
    test_args.headers = ""

    # Test env
    test_env = Environment()
    test_env.stdout_isatty = True
    test_env.stderr_isatty = True

    # Test messages
    message_1 = requests.PreparedRequest()
    message_1.is_body_upload_chunk = True
    message_1.body = b"abcdefghijklmnopqrstuvwxyz"

# Generated at 2022-06-25 18:35:00.746413
# Unit test for function main
def test_main():
    args_0: List[str] = ['http', '--verbose', '--json', 'https://httpbin.org/get']
    env_0: Environment = Environment()
    # Call the main function with the arguments and environment variables in the "args_0" and "env_0" variables.
    exit_status_0 = main(args_0, env_0)
    # The expected exit status is ExitStatus.SUCCESS.
    assert exit_status_0 == ExitStatus.SUCCESS
test_main()


# Generated at 2022-06-25 18:35:01.485345
# Unit test for function program
def test_program():
    assert program([1], [2]) == 2

# Generated at 2022-06-25 18:35:02.715940
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 18:35:09.999049
# Unit test for function main
def test_main():
    from httpie import cli
    import urllib3
    import requests
    import pygments
    import platform
    import sys
    import os
    import threading
    import sys

    import unittest

    # Testing
    class N(threading.Thread):
        def __init__(self):
            threading.Thread.__init__(self)
    
        def run(self):
            main()
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                

# Generated at 2022-06-25 18:35:12.080920
# Unit test for function main
def test_main():
    exit_status = main(['httpie', 'https://httpbin.org/get'])
    assert exit_status == 0


# Generated at 2022-06-25 18:35:14.522416
# Unit test for function main
def test_main():
    exit_status = main(args = ['./http', '--debug'])
    print(exit_status)


if __name__ == '__main__':
    # test_main()
    main()

# Generated at 2022-06-25 18:35:17.259150
# Unit test for function main
def test_main():
    assert main([]) == ExitStatus.SUCCESS
    assert main(['--debug']) == ExitStatus.SUCCESS
    assert main(['--debug', 'GET', 'http://www.google.com']) == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:35:18.493996
# Unit test for function program
def test_program():
    pass


if __name__ == '__main__':
    test_case_0()