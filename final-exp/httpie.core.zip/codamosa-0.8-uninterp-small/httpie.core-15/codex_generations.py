

# Generated at 2022-06-25 18:27:04.221535
# Unit test for function main
def test_main():
    import sys
    sys.argv[1:] = [
        '--debug',
    ]
    status = main(sys.argv[1:])
    assert status == 0

test_main()

# Generated at 2022-06-25 18:27:16.893503
# Unit test for function main
def test_main():
    """Test cases for main"""
    from httpie.context import Environment
    from httpie.cli import parser
    args = parser.parse_args(['GET', 'https://httpbin.org/headers'])
    env = Environment()
    exit_status = main(args=[], env=env)
    assert exit_status == ExitStatus.SUCCESS
    exit_status = main(args=['GET', 'https://httpbin.org/headers'], env=env)
    assert exit_status == ExitStatus.SUCCESS
    exit_status = main(args=['GET', 'https://httpbin.org/status/201'], env=env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:27:17.974845
# Unit test for function main
def test_main():
    assert main([]) == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:27:27.302975
# Unit test for function main

# Generated at 2022-06-25 18:27:28.716858
# Unit test for function main
def test_main():
    test_case_0()

# Compiled version of test_main

# Generated at 2022-06-25 18:27:33.963767
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    import pytest
    import tempfile
    
    args_0 = ['http', '--help']
    code_obj_0 = main(args=args_0)
    assert code_obj_0 == 0
    args_1 = ['http', '--debug']
    code_obj_1 = main(args=args_1)
    assert code_obj_1 == 0


# Generated at 2022-06-25 18:27:38.285879
# Unit test for function program
def test_program():
    program_0 = program(args=argparse.Namespace, env=Environment())
    assert program_0 == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:27:46.927454
# Unit test for function program
def test_program():
    env = Environment(
        config_dir=None,
        env=None,
        defaults=None,
        stdin=None,
        stdin_isatty=None,
        stdin_encoding=None,
        stdout=None,
        stdout_isatty=False,
        stderr=None,
        stdout_binary=None,
        stdout_is_redirected=None,
        stderr_isatty=None,
    )

# Generated at 2022-06-25 18:27:52.303776
# Unit test for function main
def test_main():
    exit_status_1 = main(args=['http'])
    exit_status_2 = main(args=['http', '--help'])
    exit_status_3 = main(args=['http', '--debug'])
    exit_status_4 = main(args=['http', '--output=tmp.txt', '--json', 'https://www.google.com'])
    exit_status_5 = main(args=['http', '--version'])
    assert exit_status_1 == ExitStatus.ERROR
    assert exit_status_2 == ExitStatus.SUCCESS
    assert exit_status_3 == ExitStatus.SUCCESS
    assert exit_status_4 == ExitStatus.SUCCESS
    assert exit_status_5 == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:27:54.556769
# Unit test for function program
def test_program():
    #1. normal test
    #TODO

    #2. exception test
    #TODO

    test_program()



# Generated at 2022-06-25 18:28:24.654912
# Unit test for function program
def test_program():
    exit_status = program(args=main(), env=Environment())
    assert exit_status == 0


# Generated at 2022-06-25 18:28:25.928152
# Unit test for function main
def test_main():
    exit_status = main()
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:28:26.743320
# Unit test for function program
def test_program():
    exit_status_0 = program()


# Generated at 2022-06-25 18:28:34.643314
# Unit test for function program
def test_program():
    # ExitStatus.SUCCESS
    assert program(argparse.Namespace(
        check_status=True,
        combined_output_format=None,
        config_dir=None,
        debug=False,
        download=True,
        download_resume=False,
        default_options=None,
        output_file=None,
        output_file_specified=False,
        output_options={},
        output_to_stdout=True,
        output_to_stderr=True,
        pretty_print=True,
        styles=None,
        stdin_encoding='utf8',
        traceback=False,
        verbose=True,
        verify=True,
    ), Environment()) == ExitStatus.SUCCESS



# Generated at 2022-06-25 18:28:36.962971
# Unit test for function main
def test_main():
    args = [
        '/Users/shiv/Bin/bin/http',
        'https://google.com'
    ]
    env = Environment()
    exit_status = main(args, env)
    assert exit_status == ExitStatus.SUCCESS

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 18:28:43.876855
# Unit test for function program
def test_program():
    from argparse import Namespace
    from httpie.cli.definition import parser

    args = parser.parse_args(['httpbin.org', '-H', 'foo:bar'])
    program(args, None)
    args = parser.parse_args(['-H', 'foo:bar', 'httpbin.org'])
    program(args, None)
    args = parser.parse_args(['--download', '-o', 'out.bin', 'httpbin.org/get'])
    program(args, None)
    args = parser.parse_args(['-H', 'foo:bar', 'httpbin.org'])
    program(args, None)

    exit_status_0 = main()
    assert exit_status_0.value == 1

    args = Namespace()

# Generated at 2022-06-25 18:28:46.915030
# Unit test for function main
def test_main():
    exit_status = main(['--version'])
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:28:57.130541
# Unit test for function program
def test_program():
    from mock import patch
    from requests.models import Response
    from httpie.cli.parser import parse_args
    from httpie.cli.constants import DEFAULT_UA
    from httpie.output.streams import write

    # Tests for None output
    with patch('httpie.client.collect_messages') as collect_messages:
        with patch('httpie.output.streams.write_message') as write_message:
            fake_response = Response()
            fake_response.url = 'https://www.google.com/'
            fake_response.status_code = 200
            fake_response.raw = Response()
            fake_response.raw.status = '200'
            fake_response.raw.reason = 'OK'
            fake_response.raw.version = 1.1

# Generated at 2022-06-25 18:28:58.068168
# Unit test for function program
def test_program():
    assert callable(program)


# Generated at 2022-06-25 18:29:01.682644
# Unit test for function program
def test_program():
    from httpie.cli.args import ConfigArgType
    from httpie.cli.parser import parse_args
    args = parse_args([])
    config_dir = os.getcwd() + '/httpie-config'
    return program(args, Environment(config_dir))



# Generated at 2022-06-25 18:29:32.334352
# Unit test for function program

# Generated at 2022-06-25 18:29:33.564135
# Unit test for function program
def test_program():
    exit_status_1 = program()

# Generated at 2022-06-25 18:29:36.538508
# Unit test for function program
def test_program():
    program(
        args=parser.parse_args(
            args=['--version'],
            env=Environment(),
        ),
        env=Environment(),
    )


# Generated at 2022-06-25 18:29:42.988931
# Unit test for function program
def test_program():
    class TestProgramException(Exception):
        pass
    with pytest.raises(TestProgramException):
        def _mock_collect_messages(args, config_dir, request_body_read_callback):
            yield requests.PreparedRequest()
            raise TestProgramException()
        with mock.patch(
            'httpie.client.collect_messages',
            _mock_collect_messages,
        ):
            program(args=argparse.Namespace(), env=Environment())

# Generated at 2022-06-25 18:29:52.917087
# Unit test for function main

# Generated at 2022-06-25 18:30:01.423394
# Unit test for function main
def test_main():
    # Test case for failure
    sys.argv = ['C:\\Python37\\python.exe', '\\Users\\tcheksumtsong\\PycharmProjects\\httpie-testing\\httpie\\cli\\__main__.py']

    # Test case for success
    sys.argv = ['C:\\Python37\\python.exe', '\\Users\\tcheksumtsong\\PycharmProjects\\httpie-testing\\httpie\\cli\\__main__.py']
    exit_status = main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:30:07.601128
# Unit test for function program
def test_program():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-file', type=str)
    parser.add_argument('--output-file-specified', type=str)
    args = parser.parse_args()
    print(type(args))

    main(args=args)
    main(args=['http://localhost:8080'])
    main(args=['http://localhost:8080', 'test_file', 'no_exist_file'])


if __name__ == '__main__':
    main(args=['http://localhost:8080', 'test_file', 'no_exist_file'])
    # test_case_0()
    # test_program()

# Generated at 2022-06-25 18:30:11.980288
# Unit test for function program
def test_program():
    a = program('httpie.exe http://httpbin.org/get')
    assert a == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:30:18.793003
# Unit test for function main
def test_main():
    import httpie
    import os
    import shutil
    import sys

    # Create temporary directory
    temp_dir = 'test_temp_dir'
    os.makedirs(temp_dir)

    # Create temporary config file
    temp_config_file = temp_dir + '/test_temp_config'
    text_file = open(temp_config_file, 'w')
    text_file.write('--form')
    text_file.close()


# Generated at 2022-06-25 18:30:28.916180
# Unit test for function program
def test_program():
    def error_function(message):
        print(message)
    def log_error_function(message, level):
        print(message, level)

    import argparse
    args = argparse.Namespace()
    args.headers = []
    args.output_options = []
    args.quiet = False
    args.download = False
    args.download_resume = False
    args.follow = False
    args.output_file = None
    args.output_file_specified = False
    env = Environment()
    env.stderr = sys.stderr
    env.stdout = sys.stdout
    env.stdout_isatty = True
    env.log_error = log_error_function
    env.error = error_function
    exit_status = program(args, env)
    assert exit_status

# Generated at 2022-06-25 18:30:53.357359
# Unit test for function main
def test_main():
    """
    Example of unit test for function main

    """
    import pytest
    import sys
    args = sys.argv
    # TODO: Mock environment setup
    env = Environment()
    exit_status = main(args, env)
    # TODO: Validate exit_status
    assert exit_status == ExitStatus.SUCCESS


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 18:31:04.999730
# Unit test for function main
def test_main():
    # Test Case 0
    from httpie.context import Environment
    from httpie.cli.environment import override_environment
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from unittest import mock
    import os


# Generated at 2022-06-25 18:31:06.086956
# Unit test for function main
def test_main():
    assert isinstance(test_case_0(),int)

# Generated at 2022-06-25 18:31:07.901933
# Unit test for function program
def test_program():
    class A:
        def __init__(self):
            self.max_redirects = 5

    args, env = A(), A()
    program(args, env)


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:31:08.788276
# Unit test for function program
def test_program():
    pass


# Generated at 2022-06-25 18:31:15.389653
# Unit test for function program
def test_program():
    import argparse
    import json
    import os
    import re
    import requests
    import tempfile
    import traceback

    import pytest
    from pygments.token import Token
    from pygments.token import is_token_subtype

    from httpie import __version__
    from httpie.compat import is_py26
    from httpie.compat import str
    from httpie.config import Config
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.headers import HeadersFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.plugins import plugin_manager as pm
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.downloads import Downloader
    from httpie.context import Environment
   

# Generated at 2022-06-25 18:31:27.133052
# Unit test for function program

# Generated at 2022-06-25 18:31:32.828986
# Unit test for function main
def test_main():
    import sys
    import platform
    import pygments
    import requests

    # assert that HTTPie version is 0.9.9
    assert __version__ == '0.9.9'
    # assert that version of Python  interpreter is 3.7.3
    assert sys.version == '3.7.3 (default, Apr 24 2019, 15:29:51) [MSC v.1915 64 bit (AMD64)]'

    if platform.system() == 'Windows':
        print('Windows OS detected')
        # assert taht interpreter executable is C:\Program Files\Python37\python.exe
        assert sys.executable == 'C:\\Program Files\\Python37\\python.exe'
    else:
        print('Linux OS detected')
        # assert taht interpreter executable is /usr/bin/python3.7
        assert sys.exec

# Generated at 2022-06-25 18:31:33.808637
# Unit test for function program
def test_program():
    # TODO
    pass

# Generated at 2022-06-25 18:31:44.015243
# Unit test for function main
def test_main():
    main(['http', '--debug'])
    main(['http', '--help'])
    main(['http', '--version'])
    main(['http', 'https://httpbin.org/get'])
    main(['http', 'https://httpbin.org/post', '--form'])
    main(['http', 'https://httpbin.org/get', '--json'])
    main(['http', 'https://httpbin.org/post', '--json'])
    main(['http', 'https://httpbin.org/get', '--print-b'])
    main(['http', 'https://httpbin.org/get', '--print-h'])
    main(['http', 'https://httpbin.org/post', '--print-hb'])

# Generated at 2022-06-25 18:32:07.548589
# Unit test for function main
def test_main():
    args = sys.argv
    env = Environment()
    assert main(args, env) == ExitStatus.SUCCESS
    assert args[1] == 'www.google.com'
    assert env.config.directory == os.getcwd()


# Generated at 2022-06-25 18:32:10.875848
# Unit test for function program
def test_program():
    # assert program(arg, env) == expected
    assert True # TODO: implement your test here


# Generated at 2022-06-25 18:32:12.169409
# Unit test for function main
def test_main():
    # test_case_0()
    pass

# Compiled version of test_main

# Generated at 2022-06-25 18:32:18.713345
# Unit test for function program
def test_program():
    config = configparser.ConfigParser()
    config.read('httpie/config.ini')
    home_dir = os.path.abspath(os.path.expanduser('~'))
    config_dir = os.path.join(home_dir, '.config', 'httpie')
    env = Environment(config=config, config_dir=config_dir)
    args = parser.parse_args(
        args=sys.argv,
        env=env,
    )
    program(args, env)

if __name__ == '__main__':
    test_case_0()
    test_program()

# Generated at 2022-06-25 18:32:23.767166
# Unit test for function main
def test_main():
    class TestingEnvironment:
        stdin = StringIO(u'{}'.format(''))
        stdin_encoding = None
        stdout = StringIO(u'{}'.format(''))
        stderr = StringIO('{}'.format(''))
        stdout_isatty = False
        stderr_isatty = False
        config = TestingConfig()

    exit_status_0 = main(env=TestingEnvironment())



# Generated at 2022-06-25 18:32:25.185104
# Unit test for function program
def test_program():
    try:
        program()
    except TypeError:
        assert True


# Generated at 2022-06-25 18:32:26.547416
# Unit test for function main
def test_main():
    # TODO: Add tests.
    pass



# Generated at 2022-06-25 18:32:37.490927
# Unit test for function main
def test_main():
    # test case 0
    try:
        main(['http'], Environment())
    except SystemExit as e:
        assert e.code == ExitStatus.SUCCESS, \
            'http: exit status is not ExitStatus.SUCCESS'

    # test case 1
    try:
        main(['http', '--version'], Environment())
    except SystemExit as e:
        assert e.code == ExitStatus.SUCCESS, \
            'http --version: exit status is not ExitStatus.SUCCESS'

    # test case 2
    try:
        main(['http', '--help'], Environment())
    except SystemExit as e:
        assert e.code == ExitStatus.SUCCESS, \
            'http --help: exit status is not ExitStatus.SUCCESS'

    # test case 3

# Generated at 2022-06-25 18:32:39.855059
# Unit test for function program
def test_program():
    class mock_argparse:
        class Namespace:
            pass
    mock_args = mock_argparse.Namespace()
    test_program_1(mock_args)


# Generated at 2022-06-25 18:32:42.470129
# Unit test for function main
def test_main():
    import pytest
    with pytest.raises(Exception) as excinfo:
        main()
    assert 'SystemExit' not in str(excinfo.value)


# Generated at 2022-06-25 18:33:49.048082
# Unit test for function main
def test_main():
    # case 0
    test_case_0()
    pass


if __name__ == '__main__':
    # Unit tests: Run `python -m httpie.main`
    test_main()

# Generated at 2022-06-25 18:33:50.958863
# Unit test for function program
def test_program():
    # TODO: implement
    raise NotImplementedError("Not implemented")



# Generated at 2022-06-25 18:33:54.595283
# Unit test for function program
def test_program():
    test_args_0 = ["test"]
    test_env_0 = Environment()
    test_program_0 = program(test_args_0, test_env_0)
    assert test_program_0 == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:33:58.315444
# Unit test for function main
def test_main():
    import sys
    import io
    sys.stdin = io.StringIO('xyz')
    sys.stdout = io.StringIO()
    sys.argv = ['http', 'https://www.zhihu.com']
    main()
    assert sys.stdout.getvalue() == 'https://www.zhihu.com:443'


# Generated at 2022-06-25 18:34:02.012242
# Unit test for function program
def test_program():
    env_0 = Environment()
    env_0.stdin_encoding = 'utf-8'
    args_0 = parser.parse_args(['https://httpbin.org/get'], env_0)
    program(args_0, env_0)


# Generated at 2022-06-25 18:34:11.699369
# Unit test for function program
def test_program():
    # case 1
    # try:
    #     program(args=None, env=None)
    # except Exception as e:
    #     print(f'test_program(1) failed with {e}')
    #     pass
    # case 2
    try:
        program(args=list(), env=None)
    except Exception as e:
        print(f'test_program(2) failed with {e}')
        pass
    # case 3
    try:
        program(args=None, env=list())
    except Exception as e:
        print(f'test_program(3) failed with {e}')
        pass



if __name__ == '__main__':
    # test_case_0()
    test_program()

# Generated at 2022-06-25 18:34:12.304956
# Unit test for function program
def test_program():
    program()

# Generated at 2022-06-25 18:34:15.324898
# Unit test for function program
def test_program():
    args = ['--headers', 'x:y', 'https://ifconfig.me/all.json']
    env = Environment()

    output_file = io.BytesIO()
    program(args=args, env=env)
    output_file.close()

# Generated at 2022-06-25 18:34:17.519843
# Unit test for function program
def test_program():
    args = ['-b']
    env = Environment()
    exit_status = program(args, env)
    # TODO


# Generated at 2022-06-25 18:34:25.255573
# Unit test for function program
def test_program():
    def args_to_str(args: argparse.Namespace) -> str:
        return str(args)
    exit_status_1 = program(['--form'], args_to_str)
    exit_status_2 = program(['--json'], args_to_str)
    exit_status_3 = program(['--output-file', '-'], args_to_str)
    exit_status_4 = program(['--output-file', '~/'], args_to_str)
    exit_status_5 = program(['--output-file', '~/test.txt'], args_to_str)
    exit_status_6 = program(['--session', 'test'], args_to_str)

# Generated at 2022-06-25 18:35:18.378304
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser()
    parser.add_argument("echo")
    parser.add_argument("--output-options", default=None)
    parser.add_argument("--download", default=False)
    parser.add_argument("--output-file", default=None)
    parser.add_argument("--output-file-specified", default=None)
    parser.add_argument("--follow", default=False)
    parser.add_argument("--download-resume", default=False)
    parser.add_argument("--check-status", default=False)
    parser.add_argument("--quiet", default=False)
    parser.add_argument("headers", default=None)


# Generated at 2022-06-25 18:35:29.459968
# Unit test for function main
def test_main():
    from httpie.context import Environment
    from httpie.cli.definition import parser
    from unittest.mock import MagicMock
    env = Environment()
    # Test case 0
    # test_case_0()
    # Test case 1
    args = parser.parse_args([])
    env = Environment()
    env.stderr = MagicMock()
    env.exit_status = ExitStatus.SUCCESS
    # Test case 2
    msg = 'The following arguments are required: url'
    args = parser.parse_args(['-ppp'])
    env = Environment()
    env.stderr = MagicMock()
    env.exit_status = ExitStatus.SUCCESS
    # Test case 3
    args = parser.parse_args(['-v'])
    env = Environment()
    env

# Generated at 2022-06-25 18:35:34.546880
# Unit test for function program
def test_program():
    # httpie https://raw.githubusercontent.com/jakubroztocil/httpie/master/httpie/__main__.py > /tmp/httpie.py
    args = ['https://raw.githubusercontent.com/jakubroztocil/httpie/master/httpie/__main__.py', '-v']
    func_args = parser.parse_args(args=args)
    exit_status = program(args=func_args, env=Environment())
    with open('/tmp/httpie.py', 'r') as f:
        content = f.readlines()

# Generated at 2022-06-25 18:35:36.171212
# Unit test for function program
def test_program():
    args = ['GET', 'http://www.google.com']
    program(args, Environment())


# Generated at 2022-06-25 18:35:37.892167
# Unit test for function program
def test_program():
    exit_status_0 = program(args=["http", "localhost"], env=Environment())



# Generated at 2022-06-25 18:35:45.689741
# Unit test for function program
def test_program():
    class ARGS:
        def __init__(self):
            self.output_options = OUT_RESP_HEAD
            self.output_file_specified = False
    class ENV:
        def __init__(self):
            self.stderr = sys.stderr
            self.stdout = sys.stdout
            self.stdin = sys.stdin
            self.stdout_isatty = sys.stdout.isatty()
    args = ARGS()
    env = ENV()
    exit_status = program(args=args, env=env)
    print(f"exit_status = {exit_status}")

if __name__ == '__main__':
    # execute only if run as the entry point into the program
    # test_case_0()
    test_program()

# Generated at 2022-06-25 18:35:47.896563
# Unit test for function program
def test_program():
    exit_status = program(
        args=['--traceback'],
        env=Environment()
    )
    return exit_status

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:35:54.913293
# Unit test for function program
def test_program():

    def mock_parsed_args(args: List[str]) -> argparse.Namespace:
        parsed_args = argparse.Namespace()
        if args[0] == "--output":
            parsed_args.output_file = args[1]
        elif args[0] == "--upload-file":
            parsed_args.request_body = args[:2]
            parsed_args.columns = args[2]
        elif args[0] == "--o":
            parsed_args.output_options = args[1:]
        else:
            parsed_args.method = args[0]
            parsed_args.url = args[1]
        return parsed_args
