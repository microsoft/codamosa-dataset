

# Generated at 2022-06-25 18:26:40.471776
# Unit test for function main
def test_main():

    args = ['--debug', '--default-options=--method=get', 'https://httpbin.org/get?aa=bb&cc=dd', 'echo', 'Foo:Bar']
    env = Environment()
    program_name, *args = args
    env.program_name = os.path.basename(program_name)
    decoded_args = decode_raw_args(args, env.stdin_encoding)
    plugin_manager.load_installed_plugins()
    from httpie.cli.definition import parser
    if env.config.default_options:
        decoded_args = env.config.default_options + decoded_args
    exit_status = ExitStatus.SUCCESS

# Generated at 2022-06-25 18:26:43.612885
# Unit test for function program
def test_program():
    arguments_0 = argparse.Namespace()
    environment_0 = module_0.Environment()
    var_0 = program(arguments_0, environment_0)

import httpie.plugins.builtin as module_1


# Generated at 2022-06-25 18:26:54.753802
# Unit test for function program
def test_program():
    environment_0 = module_0.Environment()
    var_1 = ("response", "--form", "--headers")
    var_2 = argparse.Namespace()
    var_2.output_file = None
    var_2.output_file_specified = None
    var_2.output_options = ("headers",)
    var_2.method = "POST"
    var_2.url = "http://httpbin.org/post"
    var_2.body = ""
    var_2.form = {}
    var_2.headers = {}
    var_2.auth = None
    var_2.ignore_stdin = False
    var_2.download = False
    var_2.output_file_specified = None
    var_2.output_file = None

# Generated at 2022-06-25 18:26:56.917633
# Unit test for function program
def test_program():
    environment = Environment()
    test = "--help"
    args = decode_raw_args(test.split(" "), environment.stdin_encoding)
    from httpie.cli.definition import parser
    parsed_args = parser.parse_args(
        args=args,
        env=environment,
    )
    program(args=parsed_args, env=environment)


# Generated at 2022-06-25 18:27:03.246766
# Unit test for function program
def test_program():
    # From file test_curl.py
    args = mock.MagicMock()
    args.config = 'httpie'
    args.method = 'GET'
    args.headers = 'Accept: application/json'
    args.output_options = 'hb'
    args.output_options = []
    args.output_options = []
    args.check_status = False
    args.download = False
    args.download_resume = False
    args.follow = False
    args.max_redirects = 10
    args.output_file = None
    args.output_file_specified = False
    args.timeout = 30
    args.verbose = False
    args.verify = False
    args.allow_redirects = True
    args.auth = tuple()
    args.auth_type = 'basic'

# Generated at 2022-06-25 18:27:04.649146
# Unit test for function program
def test_program():
    assert True


# Generated at 2022-06-25 18:27:16.920178
# Unit test for function main
def test_main():
    import sys
    import argparse
    import httpie.cli.definition as cli_definition

    def f_0(*args, **kwargs):
        return main(args=args, env=kwargs.get("env"))

    def f_1(*args, **kwargs):
        return program(args=args, env=kwargs.get("env"))

    namespace_0 = argparse.Namespace()
    namespace_0.check_status = True
    namespace_0.download = False
    namespace_0.follow = False
    namespace_0.max_redirects = 10
    namespace_0.output_file_specified = False
    namespace_0.outpute_options = frozenset([])
    namespace_0.pretty = False
    namespace_0.quiet = False
    namespace_0.style = ""
    namespace_

# Generated at 2022-06-25 18:27:18.375457
# Unit test for function program
def test_program():
    # Assert function1 == function2
    assert program == program

# Generated at 2022-06-25 18:27:20.402994
# Unit test for function main
def test_main():
    environment_0 = Environment()
    var_0 = main(sys.argv, environment_0)


# Generated at 2022-06-25 18:27:24.168599
# Unit test for function main
def test_main():
    environment_0 = module_0.Environment()
    arg_0 = ['http']
    var_0 = main(arg_0, environment_0)
    assert var_0 == ExitStatus.ERROR


# Generated at 2022-06-25 18:27:55.146218
# Unit test for function program
def test_program():
    exit_status_1 = program(args=['http', 'GET', 'http://localhost/'], env='Environment1')
    exit_status_2 = program(args=['http', 'POST', 'http://localhost/'], env='Environment2')

# Generated at 2022-06-25 18:28:02.059913
# Unit test for function main
def test_main():
    env = Environment()
    assert main(['--debug'], env) == ExitStatus.SUCCESS
    assert main(['--help'], env) == ExitStatus.SUCCESS
    assert main(['--version'], env) == ExitStatus.SUCCESS
    assert main(['get', 'test'], env) != ExitStatus.SUCCESS
    assert main(['get', 'https://httpbin.org/get'], env) != ExitStatus.SUCCESS
    assert main(['get', 'https://httpbin.org/get', '-b'], env) != ExitStatus.SUCCESS

if __name__ == '__main__':
    exit_status = main()
    sys.exit(exit_status)

# Generated at 2022-06-25 18:28:05.325928
# Unit test for function program
def test_program():
    assert ( program(['GET', 'http://jsonplaceholder.typicode.com/posts/1'], Environment()) == 0 )   
    assert ( program(['GET', 'https://httpbin.org/get'], Environment()) == 0 )


# Generated at 2022-06-25 18:28:18.275417
# Unit test for function main
def test_main():
    program_name_0 = "http"
    program_name_1 = "https"
    args_0 = [program_name_0, '-p', 'https://httpbin.org/get']
    args_1 = [program_name_1, '-p', 'https://httpbin.org/get']
    env_0 = Environment(
        stdin_isatty=False,
        stdout_isatty=True,
        stdin=b'text',
        stdout=b'out text',
        stderr=sys.stderr,
        stdin_encoding=None,
        config_dir='/home/parker/.config/httpie',
        config_file=None,
        default_options=[],
    )

# Generated at 2022-06-25 18:28:19.165181
# Unit test for function main
def test_main():
    # TODO
    return


# Generated at 2022-06-25 18:28:25.966971
# Unit test for function program
def test_program():
    from httpie.cli import arguments

    class TestArgs(arguments.Namespace):
        def __init__(self):
            self.headers = ['Content-Length: 0']
    args = TestArgs()
    environment = Environment()
    exit_status = program(args, environment)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:28:34.046855
# Unit test for function program
def test_program():
    args_token = ['https://httpie.org', 'token', 'Authorization', 'Bearer', 'abcdefghijklmno']
    env_token = Environment(config_dir=None, stdin_isatty=False, stdout_isatty=False)
    exit_status_token = program(args_token, env_token)
    assert exit_status_token == 0

    args_download = ['https://httpie.org', '-d', 'output_file=test.txt']
    env_download = Environment(config_dir=None, stdin_isatty=False, stdout_isatty=False)
    exit_status_download = program(args_download, env_download)
    assert exit_status_download == 0

# Generated at 2022-06-25 18:28:41.275287
# Unit test for function main
def test_main():
    import io
    import sys
    from httpie.cli.constants import OutputOptions
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    b''
    # Define environment
    env = Environment()
    env.program_name = 'http'
    env.config.directory = '.'
    env.config.default_options = []
    env.config.colors = 8
    env.config.implicit_content_type = 'json'
    env.config.implicit_headers = {}
    env.config.max_implicit_redirects = 10
    env.config.max_redirects = 10
    env.config.output_options = OutputOptions.all()
    env.config.style = ''
    env.config.verbose = 1
    env.config.verify = True

# Generated at 2022-06-25 18:28:47.231496
# Unit test for function program
def test_program():
    raw_args = [
        "-v",
        "https://172.21.0.1/api/v1/quickstart/api/v1/login",
        "username=admin",
        "password=admin123"
    ]
    args = sys.argv[1:]
    program(args=raw_args, env=Environment())
    print('test_program finished')

if __name__ == '__main__':
    test_case_0()
    test_program()

# Generated at 2022-06-25 18:28:48.474792
# Unit test for function main
def test_main():
    assert test_case_0() == 0


# Generated at 2022-06-25 18:30:01.862211
# Unit test for function program
def test_program():
    import pytest
    import argparse
    class MockEnv():
        pass

    class MockArgs():
        pass

    mock_env = MockEnv()
    mock_env.stdin = open('./test_data/test.txt', 'rb')
    mock_args = MockArgs()
    mock_args.headers = ['Content-Type: application/json', 'Accept: application/json']
    mock_args.output_format = 'json'
    mock_args.output_options = ['body', 'headers']
    mock_args.method = 'GET'
    mock_args.ignore_stdin = True
    mock_args.timeout = 60
    mock_args.max_redirects = 30
    mock_args.check_status = False
    mock_args.follow = True
    mock_args.follow_redirect

# Generated at 2022-06-25 18:30:08.955603
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_OPTIONS
    from httpie.environment import Environment
    from httpie.config import Config
    from httpie.cli.definition import parser
    from httpie import __version__ as httpie_version

    env = Environment()
    new_env = Environment(cwd='/home/user', config=Config())
    original_parser = parser

# Generated at 2022-06-25 18:30:12.265973
# Unit test for function main
def test_main():
    exit_status_1 = main(args=['--check-status', 'http://localhost:5000/api/'])
    assert exit_status_1 == ExitStatus.SUCCESS



# Generated at 2022-06-25 18:30:15.344463
# Unit test for function program
def test_program():
    with patch('builtins.print') as mock_stdout:
        main(args=['https://httpbin.org/get', '--headers'])
        mock_stdout.assert_called()


# Generated at 2022-06-25 18:30:16.943998
# Unit test for function program
def test_program():
    exit_status_0 = program()

# Generated at 2022-06-25 18:30:20.060853
# Unit test for function program
def test_program():
    args = parser.parse_args('--debug'.split())
    env = Environment()
    exit_status_1 = program(args, env)
    assert exit_status_1 == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:30:29.726636
# Unit test for function program
def test_program():
    import builtins
    exit_status = ExitStatus.SUCCESS
    args = argparse.Namespace()
    args.follow = True
    args.output_options = [OUT_RESP_BODY]

    env = Environment()
    env.stdout = builtins.print
    env.stderr = builtins.print

    def separate():
        builtins.print("SEPARATOR")

    def request_body_read_callback(chunk: bytes):
        builtins.print("Requesting body")

    def write_message(requests_message, env, args, with_headers, with_body):
        if with_headers is True:
            builtins.print("Writing headers")
        if with_body is True:
            builtins.print("Writing body")


# Generated at 2022-06-25 18:30:31.498989
# Unit test for function program
def test_program():
    class Env(Environment):
        stderr = sys.stdout
        def __repr__(self):
            return ''


# Generated at 2022-06-25 18:30:34.627078
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

    parsed_args = parser.parse_args(args=['--follow', 'http://google.com'])
    env = Environment()
    program(args=parsed_args, env=env)


if __name__ == '__main__':
    test_case_0()
    test_program()

# Generated at 2022-06-25 18:30:39.084522
# Unit test for function main
def test_main():
    # Case 0
    sys.argv = ['test_case_0']
    test_case_0()
    # Case 1
    sys.argv = ['test_case_1']
    test_case_1()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 18:31:38.265371
# Unit test for function program
def test_program():
    program(namespace,environment)


# Generated at 2022-06-25 18:31:41.257333
# Unit test for function program
def test_program():
    test_argv = ['httpie', 'http://httpbin.org/get']
    test_env = Environment()
    test_args = parser.parse_args(test_argv, test_env)
    assert program(test_args, test_env) == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:31:51.274720
# Unit test for function program
def test_program():
    import unittest
    from httpie.cli.argtypes import KeyValue
    from httpie.cli.definition import parser
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.output.writer import write_message


# Generated at 2022-06-25 18:32:02.668107
# Unit test for function program
def test_program():
    exit_status_expect = 0
    arg_name_0 = "command"
    arg_name_1 = "-v"
    arg_name_2 = "-h"
    arg_name_3 = "key"
    arg_name_4 = "value"
    arg_name_5 = "https://httpbin.org/get"
    args = [arg_name_0]
    args.append(arg_name_5)
    args.append(arg_name_1)
    args.append(arg_name_2)
    args.append(arg_name_3)
    args.append(arg_name_4)
    env_name = Environment(program_name=arg_name_0, env=None)
    exit_status_actual = main(args=args, env=env_name)

# Generated at 2022-06-25 18:32:04.607158
# Unit test for function main
def test_main():
    res_0 = test_case_0()
    assert res_0 == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:32:08.714913
# Unit test for function main
def test_main():
    input_0 = ['--help', '--man', '--output-file', '/dev/null', '--json-pp', '--json-s']
    expected_0 = 0
    actual_0 = main(input_0)
    assert actual_0 == expected_0

# Generated at 2022-06-25 18:32:15.155411
# Unit test for function main
def test_main():
    args = ['test.py', '--debug']
    exit_status = main(args, Environment())
    args = ['test.py', '--traceback']
    exit_status = main(args, Environment())
    args = ['test.py', '--help']
    exit_status = main(args, Environment())
    args = ['test.py', '--version']
    exit_status = main(args, Environment())
    args = ['test.py', '-v']
    exit_status = main(args, Environment())
    args = ['test.py', '-h']
    exit_status = main(args, Environment())
    args = ['test.py', 'https://jsonplaceholder.typicode.com/posts/1']
    exit_status = main(args, Environment())

# Generated at 2022-06-25 18:32:23.733656
# Unit test for function program
def test_program():
    main('--help'.split())
    main('--headers'.split())
    main('--output-options'.split())
    main('--traceback'.split())
    main('--debug'.split())
    main('--indent auto --form JSON'.split())
    main('--session test_session'.split())
    main('--check-status --follow'.split())
    main('--ignore-stdin --session test_session'.split())
    main('--auth-type basic --auth test:test'.split())
    main('--auth-type digest --auth test:test'.split())
    main('--ignore-stdin --auth-type basic --auth test:test'.split())
    main('--ignore-stdin --auth-type digest --auth test:test'.split())

# Generated at 2022-06-25 18:32:25.960431
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args()
    env = Environment()
    program(args, env)

# Generated at 2022-06-25 18:32:27.833524
# Unit test for function main
def test_main():
    exit_status_0 = main()
    assert exit_status_0 == ExitStatus.SUCCESS



# Generated at 2022-06-25 18:33:36.071239
# Unit test for function main
def test_main():
    exit_status_0 = main(['http', '--traceback', 'https://httpbin.org/get'])
    exit_status_1 = main(['http', '--traceback', '--debug', 'https://httpbin.org/get'])
    exit_status_2 = main(['http', '--debug'])
    exit_status_3 = main(['http', '--help'])
    exit_status_4 = main(['http', '--traceback', '--debug', 'https://httpbin.org/status/500'])
    exit_status_5 = main(['http', '--traceback', '--debug', '--download', '--output=./test/test_download', 'https://httpbin.org/image/png'])

# Generated at 2022-06-25 18:33:38.642692
# Unit test for function program
def test_program():
    test_case_0(program)


if __name__ == '__main__':
    exit_status = main()
    sys.exit(exit_status)

# Generated at 2022-06-25 18:33:46.913662
# Unit test for function program
def test_program():
    import requests;
    from httpie.client import collect_messages;
    from httpie.output.writer import write_message;
    from httpie.cli.definition import parser;
    from httpie.context import Environment;
    import argparse;
    env = Environment();
    messages = collect_messages(args=[], config_dir=env.config.directory);
    status_code = 0;
    for message in messages:
        write_message(requests_message=message, env=env);
        status_code = status_code + message.status_code;
    assert(status_code == 482);


# Generated at 2022-06-25 18:33:56.797693
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace()
    args.output_options = ('h', 'b')
    args.output_options += ('q',)
    messages = []
    while len(messages) < 4:
        messages.append(collect_messages(args=args, config_dir=env.config.directory))
    # Check number of messages
    assert len(messages) == 4
    assert messages[0].url != messages[1].url and messages[1].url != messages[2].url and messages[0].url != messages[2].url
    # Check if the messages are requests and responses
    for i in range(4):
        assert isinstance(messages[i], (requests.PreparedRequest, requests.Response))
    exit_status = program(args=args, env=env)
    #

# Generated at 2022-06-25 18:34:01.240243
# Unit test for function main
def test_main():
    """
    Test code for main program
    """
    # A test case for main program
    main(args=["httpie", "--version"], env=Environment())


if __name__ == '__main__':
    #test_case_0()
    test_main()

# Generated at 2022-06-25 18:34:05.575042
# Unit test for function program
def test_program():
    exit_status_1 = program(argparse.Namespace(
    check_status=False
    ), Environment())
    assert exit_status_1 == 1, 'Failed to test http client - program()'
    print("Passed test_program()")

# Generated at 2022-06-25 18:34:08.710503
# Unit test for function program
def test_program():
    args = parser.parse_args([
        '--method', 'get', '--auth=user:pass', 'httpbin.org/headers'
    ])
    assert program(args, Environment()) == ExitStatus.SUCCESS



# Generated at 2022-06-25 18:34:18.215634
# Unit test for function program
def test_program():
    import os
    import sys
    import textwrap
    from tempfile import NamedTemporaryFile

    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.output.writers.file import FileWriter

    def _get_plug_in(args:argparse.Namespace)->HTTPBasicAuth:# basic-auth as example, edit this if necessary
        return HTTPBasicAuth()


# Generated at 2022-06-25 18:34:19.742360
# Unit test for function program
def test_program():
    import subprocess
    subprocess.run(["http", "--help"],shell=True, check=True)

# Generated at 2022-06-25 18:34:20.707925
# Unit test for function program
def test_program():
    pass
