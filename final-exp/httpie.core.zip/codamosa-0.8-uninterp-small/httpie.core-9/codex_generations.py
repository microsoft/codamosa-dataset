

# Generated at 2022-06-25 18:26:18.756131
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-25 18:26:21.454056
# Unit test for function main
def test_main():
    test_case_0()

# Compiled version of test_main

# Generated at 2022-06-25 18:26:29.363466
# Unit test for function program
def test_program():
    from unittest.mock import patch
    import os
    import requests
    import httpie
    # import env
    # From http://stackoverflow.com/questions/2135206/python-mocking-imports-with-patch-dict
    class MockRequest(requests.PreparedRequest):
        pass
    with patch('requests.PreparedRequest', MockRequest, create=True):
        from httpie.cli.definition import parser
        try:
            args = parser.parse_args(
                args=['http', '--help'],
                env=Environment(),
            )
        finally:
            pass
    assert args is not None
    try:
        exit_status = program(
            args=args,
            env=Environment(),
        )
    finally:
        pass

# Generated at 2022-06-25 18:26:30.233079
# Unit test for function program
def test_program():
    """
    Unit test for function program
    """
    assert program() == 0


# Generated at 2022-06-25 18:26:34.870463
# Unit test for function main
def test_main():
    import sys
    import os

    # Test case 0
    sys.argv = ["http", "--help"]
    assert main() == ExitStatus.SUCCESS

    # Test case 1
    sys.argv = ["http", "GET", "--help"]
    assert main() == ExitStatus.SUCCESS

    # Test case 2
    sys.argv = ["http", "GET", "https://example.com"]
    assert main() == ExitStatus.SUCCESS



# Generated at 2022-06-25 18:26:36.119170
# Unit test for function main
def test_main():
    assert test_case_0() == ExitStatus.SUCCESS

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 18:26:39.709255
# Unit test for function program
def test_program():
    args=['requests.get', 'httpbin.org/get']
    env=Environment()
    try:
        program(args, env)
    except:
        assert False

# Generated at 2022-06-25 18:26:50.973174
# Unit test for function program

# Generated at 2022-06-25 18:26:59.264501
# Unit test for function main
def test_main():
    os.environ['HTTPIE_CONFIG_DIR'] = 'httpie/tests/test_config_dir'
    os.environ['HOME'] = 'httpie/tests/test_config_dir'
    exit_status_1 = main(args=['http', '--debug','localhost:8888/test_json'])
    assert exit_status_1 == 0
    exit_status_2 = main(args=['http', 'www.baidu.com/test_json'])
    assert exit_status_2 == 0
    exit_status_3 = main(args=['http', '-j', '127.0.0.1:8888/test_json'])
    assert exit_status_3 == 0

# Generated at 2022-06-25 18:27:09.610340
# Unit test for function program
def test_program():
    import inspect
    import os
    import tempfile
    import shutil


# Generated at 2022-06-25 18:31:55.933442
# Unit test for function main
def test_main():
    assert main(['https://httpbin.org/get']) == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:32:08.073652
# Unit test for function program
def test_program():
    class TempEnv:
        config = None
        log_error = None
        stdout = None
        stdout_isatty = None
        program_name = None

        def __init__(self, config, log_error, stdout, stdout_isatty, program_name):
            self.config = config
            self.log_error = log_error
            self.stdout = stdout
            self.stdout_isatty = stdout_isatty
            self.program_name = program_name

    class TempConfig:
        config_dir = None
        default_options = None

        def __init__(self, config_dir, default_options):
            self.config_dir = config_dir
            self.default_options = default_options

    class TempSys:
        exceptions = None


# Generated at 2022-06-25 18:32:08.968327
# Unit test for function program
def test_program():
    pass


# Generated at 2022-06-25 18:32:15.285102
# Unit test for function program
def test_program():
    import sys
    import pytest
    from httpie.status import ExitStatus
    from unittest.mock import Mock
    from io import StringIO
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES

    args = Mock()
    env = Mock()
    env.config.directory = "."
    env.stdin_encoding = 'utf-8'
    args.output_options = []
    args.method = 'GET'
    args.url = 'http://localhost:8080/'
    args.download = False
    args.download_resume = False
    args.output_file = sys.stdout
    args.headers = None
    args.auth = None
    args.timeout = None
    args.max_redirects = 30
   

# Generated at 2022-06-25 18:32:23.861097
# Unit test for function main
def test_main():
    """
    Test case:
    1. Make a request to a local URL
    2. The response should be 200 OK
    3. The response content-type should be html
    """
    secret_key = os.environ.get('TEST_SECRET_KEY', '')
    url = f'http://127.0.0.1:5000/test/{secret_key}/'
    # Make a request
    req = requests.get(url)
    # Get the response content
    response_json = req.json()
    # Get the content-type for the response
    content_type = req.headers['Content-Type']

    assert req.status_code == 200
    assert content_type == 'application/json'
    assert response_json['result'] == 'success'



# Generated at 2022-06-25 18:32:28.027992
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except NameError as error_0:
        print("Name Error:", error_0)
        raise(error_0)
    except TypeError as error_1:
        raise(error_1)

# Unit Test for function decode_raw_args

# Generated at 2022-06-25 18:32:38.807097
# Unit test for function main
def test_main():
    # Set arguments
    argv = ["http", "--debug", "httpbin.org/post", "-d", "key1=value1", "-d", "key2=value2", "-H", "header1:value1", "-H", "header2:value2"]
    env = Environment(config=None, colors=None, stdin=None, stdout=sys.stdout, stderr=sys.stderr)
    # Execute the script
    exit_status_1 = main(argv)
    # Test the results
    assert exit_status_1 == ExitStatus.SUCCESS
    # Test stdout
    assert sys.stdout.getvalue() == ""

    # Set arguments

# Generated at 2022-06-25 18:32:46.450056
# Unit test for function program
def test_program():
    args = argparse.Namespace(
        debug=False,
        default_options=[],
        follow=False,
        form=[],
        headers=[],
        ignore_stdin=False,
        output_file=None,
        output_file_specified=False,
        output_options=[],
        output_options_specified=False,
        pretty='all',
        traceback=False,
        url='https://httpbin.org/get',
        verify=True,
    )
    env = Environment()
    exit_status = program(args = args, env = env)
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:32:48.108218
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    env = Environment()
    program(args, env)

# Generated at 2022-06-25 18:32:57.447768
# Unit test for function program
def test_program():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.definition import parser
    from httpie.client.request import Request
    from httpie.client.response import Response

    args = parser.parse_args(args=['-H', 'User-Agent: Chrome', 'http://example.org'])

    # unit test case 1:
    # Program execution without error
    test_case_1 = program(args=args, env=Environment())
    assert test_case_1 == ExitStatus.SUCCESS

    # unit test case 2:
    # Program execution with error
    args.output_options = ['invalid']
    test_case_2 = program(args=args, env=Environment())
    assert test_case_2 == ExitStatus.ERROR

    # unit test case 3:
    # Program execution with error
