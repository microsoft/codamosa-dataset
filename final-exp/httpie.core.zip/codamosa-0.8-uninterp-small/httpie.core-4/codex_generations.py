

# Generated at 2022-06-25 18:26:46.924976
# Unit test for function program
def test_program():
    class args:
        download_resume = False
        follow = True
        headers = None
        output_file = None
        output_file_specified = None
        output_options = ['hB']
        quiet = False
        download = True

    print("test program:")
    print("test 0:")
    class env:
        program_name = 'test.py'
        config = None
        stdin = None
        stdin_isatty = None
        stdout = None
        stdout_isatty = None
        stderr = None
        stderr_isatty = None
        encoding = None
        is_windows = None
        is_aix = None
        runtime_environ = None
        config_dir = None
        env = None
        stdin_encoding = None

    exit_status

# Generated at 2022-06-25 18:26:56.412111
# Unit test for function program

# Generated at 2022-06-25 18:27:02.882212
# Unit test for function program
def test_program():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tempdir:
        with open(tempdir+'/data.txt','w') as data:
            data.write('Hello world\nI am a file')
        args = argparse.Namespace()
        args.output_options = [b'H']
        args.headers = ['Content-Type: text/plain']
        args.ignore_stdin = False
        args.verbose = b'INFO'
        args.timeout = None
        args.max_redirects = 30
        args.check_status = False
        args.download = False
        args.download_resume = False
        args.follow = False
        args.output_file = None
        args.output_file_specified = False
        env: Environment = Environment()

# Generated at 2022-06-25 18:27:14.056991
# Unit test for function program
def test_program():
    # If a request doesn't support body piping and it doesn't have a body (e.g. HEAD)
    # then the final `separator` is not needed.
    from io import StringIO
    from unittest import mock
    from httpie.cli.constants import DEFAULT_OPTIONS
    from httpie.cli.parser import parser
    from httpie.config import Environment
    from httpie.downloads import Downloader
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.output.formatters import JSONFormatter
    from httpie.context import Environment
    args = parser.parse_args(args=['--headers'], env=Environment())
    assert not args.output_options

# Generated at 2022-06-25 18:27:15.027590
# Unit test for function program
def test_program():
    program(None, None)

# Generated at 2022-06-25 18:27:24.810051
# Unit test for function program
def test_program():
    # Test with an empty argument.
    assert program(args=[], env=Environment()) == ExitStatus.ERROR
    # Test with a string argument.
    assert program(args=['hello'], env=Environment()) == ExitStatus.SUCCESS
    # Test with a set of arguments.
    assert program(args=[
        '--method', 'POST',
        '--body', 'name=Foo Bar&lang=Python',
        'https://httpbin.org/post'
    ], env=Environment()) == ExitStatus.SUCCESS
    # Test with a file argument.
    assert program(args=['https://httpbin.org/post'], env=Environment()) == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:27:25.872783
# Unit test for function program
def test_program():
    exit_status_1 = program()

# Generated at 2022-06-25 18:27:30.445378
# Unit test for function program
def test_program():
    import sys
    # Testing first usecase
    sys.argv = ['http','--json','{"foo": "bar"}','--verbose','https://httpbin.org/get']
    main()
    sys.argv = ['http','--json','{"foo": "bar"}','https://httpbin.org/get']
    main()



# Generated at 2022-06-25 18:27:37.203263
# Unit test for function main
def test_main():
    # Unit: default case, argv = ['http']
    test_case_0()
    # Unit: argv = ['http', '-o', 'file.txt']
    # Unit: argv = ['http']
    # Unit: argv = ['http', '-o', 'file.txt']
    # TODO: Implement more test cases.
    # ...

if __name__ == '__main__':
    import pytest

    pytest.main(["-s", "-x"] + sys.argv)

# Generated at 2022-06-25 18:27:46.237127
# Unit test for function main
def test_main():
    try:
        assert main() == ExitStatus.SUCCESS
    except Exception as e:
        print(e)
        assert False
    try:
        assert main() == ExitStatus.SUCCESS
    except Exception as e:
        print(e)
        assert False
    try:
        assert main() == ExitStatus.SUCCESS
    except Exception as e:
        print(e)
        assert False
    try:
        assert main() == ExitStatus.SUCCESS
    except Exception as e:
        print(e)
        assert False
    try:
        assert main() == ExitStatus.SUCCESS
    except Exception as e:
        print(e)
        assert False
    try:
        assert main() == ExitStatus.SUCCESS
    except Exception as e:
        print(e)
        assert False
   

# Generated at 2022-06-25 18:28:17.921151
# Unit test for function main
def test_main():
    args = ['--debug']
    exit_status = main(args)
    assert(exit_status == ExitStatus.SUCCESS)

# Generated at 2022-06-25 18:28:18.654475
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:28:23.319355
# Unit test for function program
def test_program():
    try:
        exit_status = program()
        assert exit_status == ExitStatus.SUCCESS
    except KeyboardInterrupt:
        print('\n')

# Generated at 2022-06-25 18:28:26.316162
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as exc:
        main(['-v', 'httpbin.org'])
    assert exc.value.code != 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:28:28.258050
# Unit test for function main
def test_main():
    import httpie.cli

    args = sys.argv
    httpie.cli.main(args)

# Generated at 2022-06-25 18:28:36.431447
# Unit test for function main
def test_main():
    program_name = os.path.basename(__file__)
    program_name = 'http'
    args = [program_name, 'get', '--help']
    env = Environment()
    env.program_name = os.path.basename(program_name)
    args = decode_raw_args(args, env.stdin_encoding)
    plugin_manager.load_installed_plugins()

    from httpie.cli.definition import parser
    parsed_args = parser.parse_args(
        args=args,
        env=env,
    )
    run_code = program(
        args=parsed_args,
        env=env,
    )
    print("run_code", run_code)
    print("env.config.directory", env.config.directory)


# Generated at 2022-06-25 18:28:47.450963
# Unit test for function main

# Generated at 2022-06-25 18:28:48.388093
# Unit test for function main
def test_main():
    
    print(main())

# Generated at 2022-06-25 18:28:49.201712
# Unit test for function program
def test_program():
    program()

# Generated at 2022-06-25 18:28:50.930999
# Unit test for function program
def test_program():
    assert (program(args=['httpie-test'], env=Environment())) == 'Program is working'


# Generated at 2022-06-25 18:30:07.361575
# Unit test for function program
def test_program():
    # Unit tests for function main
    args = argparse.Namespace(check_status=False, follow=False, max_redirects=30,
                              output_file=None, output_file_specified=False, output_options=['h', 'b'],
                              output_to_devnull=False, pretty=None, quiet=False, verify=True,
                              download=False, download_resume=False, timeout=None)
    env = Environment()
    assert ExitStatus.SUCCESS == program(args, env)

# Generated at 2022-06-25 18:30:12.889334
# Unit test for function main
def test_main():
    sys.argv = [
        'http',
        '--traceback',
        '--max-redirects=1',
        'ijkl',
    ]
    exit_status = main()
    assert exit_status == ExitStatus.ERROR

# Generated at 2022-06-25 18:30:14.081514
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-25 18:30:20.435607
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit as e:
        assert e.code == ExitStatus.SUCCESS, 'unexpect SystemExit code %r' % e.code
    except Exception as e:
        print('Ignore uncaught exception', repr(e), file=sys.stderr)
        raise e
    else:
        print('TEST SUCEED')


# Test if main() actually exits with given exit code.

# Generated at 2022-06-25 18:30:22.855747
# Unit test for function main
def test_main():
    test_case_0()


# Compiled version of test_main

# Generated at 2022-06-25 18:30:28.631801
# Unit test for function program
def test_program():
    args = [
        '--headers',
        '--auth-type=basic',
        '--auth=user:passwd',
        '--check-status',
        '--download',
        '--download-resume',
    ]
    exit_status = program(args, Env())
    assert exit_status == ExitStatus.SUCCESS



# Generated at 2022-06-25 18:30:29.454298
# Unit test for function program
def test_program():
    exit_status_program = program()


# Generated at 2022-06-25 18:30:38.955219
# Unit test for function program
def test_program():
    import os

    env = Environment()
    os.mkdir(env.config.directory)


# Generated at 2022-06-25 18:30:48.359746
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.config_dir = '/home/travis/.config/httpie'
    args.follow = False
    args.headers = ['Content-Type: application/json; charset=UTF-8']
    args.max_redirects = 30
    args.output_options = ['Hhb']
    args.output_file_specified = False
    args.quiet = True
    args.timeout = 30
    args.verify = True
    args.download = False
    args.download_resume = True
    args.check_status = True
    args.force_output_stream = True
    args.form = False
    args.json = False
    args.mime = False
    args.print_headers = True
    args.pretty = 'all'

# Generated at 2022-06-25 18:30:49.060899
# Unit test for function program
def test_program():
    import pytest
    main()

# Generated at 2022-06-25 18:31:53.829821
# Unit test for function program

# Generated at 2022-06-25 18:31:55.703071
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 18:31:58.803430
# Unit test for function main
def test_main():
    # Output expected:
    expected_0 = ExitStatus.ERROR
    # Obtained output:
    exit_status_0 = main()
    # Comparison
    assert exit_status_0 == expected_0


# Generated at 2022-06-25 18:32:10.254171
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from httpie import __version__ as httpie_version
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus, http_status_to_exit_status
    import httpie

    # case 1
    args = ["http", "GET", "http://localhost/get"]
    env = Environment()
    result = main(args, env)
    assert type(result) == int
    assert result == ExitStatus.SUCCESS
    assert env.config.default_options == []
    assert env.log_headers

   

# Generated at 2022-06-25 18:32:12.378238
# Unit test for function main
def test_main():

    print('')
    print('unit test for main')
    print('by calling main() with empty argument list, we get to the interactive shell')


# Generated at 2022-06-25 18:32:14.508094
# Unit test for function program
def test_program():
    args = ['https://www.baidu.com']
    exit_status_0 = program(args=args, env=Environment())

    assert exit_status_0 == 0



# Generated at 2022-06-25 18:32:21.595695
# Unit test for function main
def test_main():
    def test_input_0() -> List[Union[str, bytes]]:
        return [
            b'C:\\Users\\kcarl\\Anaconda3\\envs\\py38\\lib\\site-packages\\ipykernel_launcher.py',
            b'-f',
            b'C:\\Users\\kcarl\\AppData\\Roaming\\jupyter\\runtime\\kernel-0d93a847-a92f-4523-80f3-b2808e921c6a.json',
        ]

    result_0 = main(test_input_0())
    assert result_0 == 0


# Generated at 2022-06-25 18:32:23.071027
# Unit test for function main
def test_main():
    exit_status = main(["--debug"])
    assert exit_status == ExitStatus.SUCCESS



# Generated at 2022-06-25 18:32:28.683955
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    env = Environment()
    args = parser.parse_args(
        args=['https://httpie.org'],
        env=env,
    )
    assert type(args) is argparse.Namespace
    assert type(env) is Environment
    program(args,env)

# Generated at 2022-06-25 18:32:39.077743
# Unit test for function main
def test_main():
    assert main() == ExitStatus.ERROR
    assert main(["-h"]) == ExitStatus.SUCCESS
    assert main(["--help"]) == ExitStatus.SUCCESS
    assert main(["--version"]) == ExitStatus.SUCCESS
    assert main(["-c", "key1: val1", "key2:val2", "key3:val3"]) == ExitStatus.SUCCESS
    assert main(["-t", "4"]) == ExitStatus.SUCCESS
    assert main(["--output", "INVALID_FILE_PATH"]) == ExitStatus.ERROR
    assert main(["--download", "INVALID_FILE_PATH"]) == ExitStatus.ERROR
    assert main(["--download-resume", "INVALID_FILE_PATH"]) == ExitStatus.ERROR

# Generated at 2022-06-25 18:35:42.645016
# Unit test for function program
def test_program():
    args = ["http://httpbin.org/ip"]
    exit_status = program(args, env)


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:35:51.509992
# Unit test for function program
def test_program():
    from httpie import httpie
    from httpie.output.streams import MockStdoutStream
    
    args = ['--debug']
    
    mock_stdout_stream = MockStdoutStream()
    old_stdout = sys.stdout
    sys.stdout = mock_stdout_stream

    
    main(args=args)
    
    sys.stdout = old_stdout
    assert(mock_stdout_stream.getvalue())
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

if __name__ == '__main__':
    from optparse import OptionParser

    parser = OptionParser()
    parser.add_option("-t", "--test", dest="test")

    (options, args) = parser.parse