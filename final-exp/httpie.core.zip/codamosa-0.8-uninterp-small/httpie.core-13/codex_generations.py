

# Generated at 2022-06-25 18:26:46.948512
# Unit test for function program

# Generated at 2022-06-25 18:26:57.639911
# Unit test for function program
def test_program():
    import httpie.cli.parser
    import httpie.plugins.builtin
    import httpie.output.streams
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.colors import no_style
    from httpie.status import ExitStatus
    from httpie.utils import Spinner
    from httpie import ExitStatus
    from httpie.cli import parser
    # Build the arguments
    args = httpie.cli.parser.parse_args(['GET', 'www.google.com'])
    # Build the environment

# Generated at 2022-06-25 18:26:58.821136
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-25 18:27:01.426001
# Unit test for function program
def test_program():
    exit_status = main(args=['www.google.com'])

# Generated at 2022-06-25 18:27:03.426655
# Unit test for function main
def test_main():
    exit_status_0 = main()
    assert exit_status_0 == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:27:09.176699
# Unit test for function program
def test_program():
    args = ['http', 'localhost:8282/json']
    env = Environment()
    program(args=args, env=env)



# Generated at 2022-06-25 18:27:19.154575
# Unit test for function main
def test_main():
    import requests
    import pytest
    from requests.exceptions import HTTPError, ConnectionError, MissingSchema
    from httpie.cli.args import parser
    from httpie.context import Environment
    from multiprocessing import Process

    def prepare_args(url):
        url_list = url.split()
        parsed_args = parser.parse_args(args=url_list)
        return parsed_args

    def prepare_env():
        return Environment()

    def run_main(url: str, stdin_encoding: str, env: Environment, args: argparse.Namespace) -> ExitStatus:
        args_decoded = decode_raw_args(args, stdin_encoding)
        return main(args=args_decoded, env=env)


# Generated at 2022-06-25 18:27:30.349002
# Unit test for function main
def test_main():
    import pytest
    import sys
    from httpie.cli.constants import ExitStatus
    from httpie import context
    from httpie import ExitStatus
    from httpie.cli.definition import parser
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.config import Parser as ConfigParser
    from httpie.plugins.registry import PluginRegistry
    from httpie.plugins import builtin
    from httpie import ExitStatus
    from httpie.config import Config, AuthConfig
    from httpie.plugins.manager import PluginManager
    import httpie.cli
    from httpie.cli import env, main, print_debug_info, decode_raw_args
    from httpie.output import writer
    from httpie.plugins.manager import PluginManager
    from httpie.output.streams import WriteFlushFile
   

# Generated at 2022-06-25 18:27:39.728372
# Unit test for function program
def test_program():
    from io import StringIO
    from tempfile import mktemp
    import os
    import shutil
    from httpie import httpie_main
    from httpie.cli.constants import OUT_RESP_BODY
    import json
    import requests
    import sys
    import unittest

    class TestProgram(unittest.TestCase):


        def test_case_0(self):
            config_dir = mktemp(prefix="httpie-test-config-")
            args = ['GET', 'http://httpbin.org/get']
            outfile = mktemp(prefix="httpie-test-")
            args += ['--output', outfile]
            r = httpie_main(args=args, config_dir=config_dir)
            assert(r == 0)

# Generated at 2022-06-25 18:27:41.556668
# Unit test for function program
def test_program():
    env = Environment()
    args = parser.parse_args()
    program(args, env)


# Generated at 2022-06-25 18:28:07.647411
# Unit test for function program
def test_program():
    # try:
    #     program()
    # except SystemExit as e:
    #     print(e.code)
    program()

# Generated at 2022-06-25 18:28:08.556020
# Unit test for function program
def test_program():
    test_case_0()


# Generated at 2022-06-25 18:28:12.698182
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

    parsed_list = parser.parse_args(['http', '--help'])
    assert isinstance(parsed_list, list) is True

    from httpie import ExitStatus
    exit_status_0 = main(['http', '--help'])
    assert exit_status_0 != ExitStatus.SUCCESS
    assert isinstance(exit_status_0, int) is True

# Generated at 2022-06-25 18:28:24.532494
# Unit test for function main
def test_main():
    from httpie.output.streams import UnsupportedEnvironment
    from httpie.cli.args import parser as argparser
    from httpie.plugins.builtin import HTTPBasicAuth
    try:
        help_msg = main(args=['--help'])
    # Ignore UnsupportedEnvironment errors raised when writing to stdout
    # because --help is a special case.
    except UnsupportedEnvironment:
        pass
    args = argparser.parse_args(args=['--download', '--check-status', '--form', '--ignore-stdin', '--headers',
                                      'X-header:value', 'https://httpbin.org/post', 'key=value'])
    assert args.url == 'https://httpbin.org/post'

# Generated at 2022-06-25 18:28:33.304462
# Unit test for function program
def test_program():
    class FakePreparedRequest:

        def __init__(self, body):
            self.url = "http://localhost"
            self.body = body
            self.headers = {'a': 'b'}

    class FakeResponse:

        def __init__(self, body, status_code):
            self.raw = {}
            self.raw['status'] = status_code
            self.raw['reason'] = 'blah'
            self.text = body
            self.status_code = status_code

    class FakeEnv:

        def __init__(self):
            self.stdout = open("temp_case_0.txt", "wb")
            self.stderr = open("temp_case_1.txt", "wb")

        def __del__(self):
            self.stdout.close()
            self

# Generated at 2022-06-25 18:28:40.775551
# Unit test for function main
def test_main():
    assert main([]) == ExitStatus.SUCCESS
    assert main(['--version']) == ExitStatus.SUCCESS
    assert main(['--help']) == ExitStatus.SUCCESS
    assert main(['--debug']) == ExitStatus.SUCCESS
    assert main(['--traceback']) == ExitStatus.SUCCESS
    assert main(['--verbose']) == ExitStatus.SUCCESS
    assert main(['httpie']) == ExitStatus.SUCCESS
    assert main(['httpie', 'https://httpie.org/get']) == ExitStatus.SUCCESS
    assert main(['httpie', '--help', 'https://httpie.org/get']) == ExitStatus.SUCCESS
    assert main(['httpie', '--output=', 'https://httpie.org/get'])

# Generated at 2022-06-25 18:28:41.770708
# Unit test for function program
def test_program():
    import unittest


# Generated at 2022-06-25 18:28:49.573884
# Unit test for function main
def test_main():
    assert main(args=['http', '--debug']) == ExitStatus.SUCCESS
    assert main(args=['--debug', 'http']) == ExitStatus.SUCCESS
    assert main(args=['--debug', 'http', '--form']) == ExitStatus.SUCCESS
    assert main(args=['--debug', 'http', '--form', 'key=val']) == ExitStatus.SUCCESS
    assert main(args=['--debug', 'http', 'http://httpbin.org/get']) == ExitStatus.SUCCESS
    assert main(args=['--debug', 'http', 'GET', 'http://httpbin.org/get']) == ExitStatus.SUCCESS



# Generated at 2022-06-25 18:28:50.429926
# Unit test for function program
def test_program():
    main(args=['--version'])


# Generated at 2022-06-25 18:28:57.641312
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.config import Config
    from httpie.context import Environment
    import sys
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, config=Config())

    args = parser.parse_args(['https://httpbin.org/get'])
    exit_status = program(args, env)
    exit_status_0 = ExitStatus.SUCCESS
    assert exit_status == exit_status_0


# Generated at 2022-06-25 18:30:15.395172
# Unit test for function program
def test_program():
    result = program(['https://jsonplaceholder.typicode.com/posts'])
    assert result.status_code == 200
    assert result.reason == 'OK'    
    

# Generated at 2022-06-25 18:30:27.021099
# Unit test for function program
def test_program():
    import argparse

    args_0 = argparse.Namespace()
    args_0.config_dir = None
    args_0.config_file = None
    args_0.config_format = None
    args_0.debug_traceback = False
    args_0.download = False
    args_0.download_resume = False
    args_0.follow = False
    args_0.ignore_stdin = False
    args_0.max_redirects = 30
    args_0.max_timeline = 120
    args_0.output_file = None
    args_0.output_file_specified = False
    args_0.output_options = ['h', 'b']
    args_0.output_style = None
    args_0.output_style_specified = None
    args_0.output

# Generated at 2022-06-25 18:30:28.881531
# Unit test for function main
def test_main():
    print(test_case_0.__name__)
    main(sys.argv)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 18:30:31.574920
# Unit test for function program
def test_program():
    import argparse
    args = argparse.Namespace()
    env = Environment()
    exit_status = program(
        args=args,
        env=env
    )
    assert exit_status != ExitStatus.SUCCESS

# Generated at 2022-06-25 18:30:34.971816
# Unit test for function program
def test_program():
    test_header = {"Content-Type": "application/json"}
    test_data = "testData"
    test_args = {"data": test_data, "headers": test_header}
    test_env = Environment()
    program(test_args, test_env)



# Generated at 2022-06-25 18:30:38.420413
# Unit test for function program
def test_program():
    environment = Environment()
    arg_namespace = argparse.Namespace()
    test_program_result = program(arg_namespace, environment)
    print(test_program_result)


# Generated at 2022-06-25 18:30:42.331350
# Unit test for function program
def test_program():
    # Instantiate environment
    env = Environment()
    # Create list of arguments
    args = ["httpie", "--traceback"]
    # Pass arguments to main
    exit_code = program(args=args, env=env)
    assert exit_code == ExitStatus.ERROR

# Generated at 2022-06-25 18:30:44.514014
# Unit test for function program
def test_program():
    import argparse
    parsed_args = argparse.Namespace()
    parsed_args.url = 'https://httpbin.org/get'
    a = program(parsed_args)
    assert a == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:30:52.746121
# Unit test for function main
def test_main():
    # No args
    assert main() == ExitStatus.SUCCESS

    # Get request with args
    assert main(['get', 'httpbin.org']) == ExitStatus.SUCCESS

    # Get request with args and debug
    assert main(['get', '--debug', 'httpbin.org']) == ExitStatus.SUCCESS

    # Get request with args and traceback
    assert main(['get', '--traceback', 'httpbin.org']) == ExitStatus.SUCCESS

    # Head request with args
    assert main(['head', 'httpbin.org']) == ExitStatus.SUCCESS

    # Options request with args
    assert main(['options', 'httpbin.org']) == ExitStatus.SUCCESS

    # Patch request with args
    assert main(['patch', 'httpbin.org']) == Exit

# Generated at 2022-06-25 18:30:54.204292
# Unit test for function main
def test_main():
    # Test cases
    test_case_0()

if __name__ == '__main__':
    # test_main()
    main()

# Generated at 2022-06-25 18:31:43.300818
# Unit test for function program
def test_program():
    assert program((main()), sys.argv) != None

# Generated at 2022-06-25 18:31:44.767170
# Unit test for function program
def test_program():
    exit_status_2 = program(args=['--help'], env=Environment())


# Generated at 2022-06-25 18:31:53.273466
# Unit test for function program
def test_program():
    import io
    import mock
    import requests

    # Monkey-patching sys.stdin, sys.stdout, sys.stderr
    stdout = io.BytesIO()
    stderr = io.BytesIO()
    stdin = io.BytesIO()
    sys.stdin = stdin
    sys.stdout = stdout
    sys.stderr = stderr

    # Monkey-patching argparse.Namespace
    class argparse_Namespace_0():
        def __init__(self):
            self.verify = True
            self.headers = None
            self.output_options = None
            self.max_redirects = None
            self.timeout = None
            self.check_status = False
            self.download = False
            self.download_resume = True

# Generated at 2022-06-25 18:32:05.109756
# Unit test for function program

# Generated at 2022-06-25 18:32:13.325938
# Unit test for function program

# Generated at 2022-06-25 18:32:19.959791
# Unit test for function program
def test_program():

    exit_status_1 = main(['--json=nope', 'https://httpbin.org/get', 'Accept:application/json'])

    exit_status_2 = main(['https://httpbin.org/get', 'Accept:application/json'])

    exit_status_3 = main(['--json=nope', 'https://httpbin.org/get', 'Accept:application/json'])

    assert exit_status_0 == 0
    assert exit_status_1 == 0
    assert exit_status_2 == 0
    assert exit_status_3 == 0

# Generated at 2022-06-25 18:32:26.751032
# Unit test for function program
def test_program():
    class Arguments:
        def __init__(self):
            self.headers = None
            self.download = False
            self.output_options = []
            self.output_file = None
            self.output_file_specified = False
            self.check_status = True
            self.follow = False
            self.timeout = 30
            self.max_redirects = 10
            self.download_resume = False
            self.quiet = False

    class Environment:
        def __init__(self):
            self.config = config
            self.log_error = log_error
            self.stderr = stderr
            self.stdout = stdout
            self.stdout_isatty = stdout_isatty


# Generated at 2022-06-25 18:32:37.610822
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.cli.util import get_response, get_request
    from httpie.plugins.builtin import HTTPBasicAuth
    parsed_args = parser.parse_args(args=[
        '--auth=username:passwd',
        'httpbin.org/get',
    ])
    env = Environment()
    program(args=parsed_args, env=env)
    assert env.stdout.closed == False
    assert env.stderr.closed == False
    env.stdout.close()
    env.stderr.close()
    assert env.stdout.closed == True
    assert env.stderr.closed == True
    parsed_args = parser.parse_args(args=[
        'httpbin.org/get',
        '--download'
    ])

# Generated at 2022-06-25 18:32:40.414290
# Unit test for function main
def test_main():
    args = ['http','--pretty=all','example.org']
    exit_status_code = main(args);
    print(exit_status_code)
    assert exit_status_code == 0


# Generated at 2022-06-25 18:32:41.391965
# Unit test for function program
def test_program():
    exit_status = program()


# Generated at 2022-06-25 18:33:36.212274
# Unit test for function program
def test_program():
    import httpie.cli.argtypes
    import httpie.cli.definition
    import httpie.config
    import httpie.plugins
    import httpie.plugins.builtin
    import httpie.plugins.registry
    import httpie.output
    import httpie.input
    import httpie.downloads
    import httpie.context
    import pytest
    import requests
    import requests_toolbelt

    from httpie import __main__
    from httpie.cli.argtypes import KeyValueArg

    # Dump
    args = ['http', '--download', 'Dump']
    #args = env.program_name + args
    print(args)

    # Mock stdin

# Generated at 2022-06-25 18:33:44.825084
# Unit test for function program
def test_program():
    import argparse
    import requests
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.output.writer import MESSAGE_SEPARATOR_BYTES
    from httpie.context import Environment
    from io import StringIO
    stdout_0 = StringIO()
    stderr_0 = StringIO()
    env_0 = Environment()
    env_0.stdout = stdout_0
    env_0.stderr = stderr_0

# Generated at 2022-06-25 18:33:47.138245
# Unit test for function program
def test_program():
    program(args=['-v', 'http://localhost:8888/'], env=Environment())

# Generated at 2022-06-25 18:33:50.960280
# Unit test for function main
def test_main():
    import doctest
    doctest.testmod(name="main",
                    optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS)

if __name__ == '__main__':
    # test_main()
    test_case_0()

# Generated at 2022-06-25 18:33:51.828028
# Unit test for function program
def test_program():
    program(1, 2)


# Generated at 2022-06-25 18:33:53.048900
# Unit test for function program
def test_program():
    exit_status_0 = program()


# Generated at 2022-06-25 18:33:56.627933
# Unit test for function main
def test_main():
    # mock_env = MagicMock()
    # main(mock_env)
    test_case_0()
    # TODO: add test case
    # test_case_1()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 18:33:57.223798
# Unit test for function program
def test_program():
    main()

# Generated at 2022-06-25 18:33:58.826653
# Unit test for function program
def test_program():
    assert exit_status_0 == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:34:01.104556
# Unit test for function program
def test_program():
    args = ['https://google.com']
    env = Environment()
    exit_status = program(args, env)
