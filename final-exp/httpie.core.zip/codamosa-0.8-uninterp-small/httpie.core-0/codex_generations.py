

# Generated at 2022-06-25 18:26:35.683923
# Unit test for function main
def test_main():
    import pytest
    import httpie

    class overwrite_default_env:
        def __enter__(self):
            self.default_env = httpie.cli.default_env
            self.default_env.program_name = 'http_test'
            httpie.cli.default_env = self.default_env
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            httpie.cli.default_env = self.default_env

    args = ['test']
    exit_status = 1
    with overwrite_default_env():
        exit_status = main(args)
    assert exit_status == exit_status_0

# Generated at 2022-06-25 18:26:36.268654
# Unit test for function program
def test_program():
    exit_status_0 = main()


# Generated at 2022-06-25 18:26:46.875375
# Unit test for function program
def test_program():
    # Test case 0
    # Create Namespace with args
    args0 = argparse.Namespace()
    args0.check_status = False
    args0.download = False
    args0.download_resume = False
    args0.follow = False
    args0.headers = []
    args0.help = False
    args0.json = False
    args0.output_file = None
    args0.output_options = [b'H', b'B']
    args0.output_file_specified = False
    args0.quiet = False
    args0.style = None
    args0.style_sheets = False
    args0.traceback = False
    args0.unicode = False
    args0.verbose = 0
    args0.verify = True

    env0 = Environment()

    # Call program

# Generated at 2022-06-25 18:26:57.305291
# Unit test for function main
def test_main():
    from httpie.context import Environment
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    import argparse, os
    env = Environment(config_dir=DEFAULT_CONFIG_DIR)
    args = argparse.Namespace(
        check_status=True,
        headers=[],
        ignore_stdin=False,
        output_file=None,
        output_file_specified=False,
        output_options=[
            'h',
            'H',
            'b',
            'g'],
        stdin=None,
        stdin_isatty=False,
        url='--check-status',
    )
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 18:27:01.187408
# Unit test for function main
def test_main():
    exit_status = main(args=['--debug'])
    assert exit_status == ExitStatus.SUCCESS



# Generated at 2022-06-25 18:27:05.095888
# Unit test for function program
def test_program():
    import unittest.mock
    args = unittest.mock.MagicMock()
    env = unittest.mock.MagicMock()
    exit_status = program(args=args, env=env)
    return exit_status

# Generated at 2022-06-25 18:27:13.157669
# Unit test for function program
def test_program():
    exit_status_1 = program()
    print(f'exit_status_1 = {exit_status_1}')
    raise SystemExit
    exit_status_2 = program()
    print(f'exit_status_2 = {exit_status_2}')
    raise SystemExit
    exit_status_3 = program()
    print(f'exit_status_3 = {exit_status_3}')
    raise SystemExit


# Generated at 2022-06-25 18:27:23.635509
# Unit test for function program
def test_program():
    class test_args:
        def __init__(self):
            self.output_file = None
            self.output_file_specified = None
            self.check_status = False
            self.download = False
            self.download_resume = False
            self.follow = False
            self.headers = None
            self.quiet = False
            self.output_options = []

    class test_env:
        def __init__(self):
            self.stdout = sys.stdout
            self.stdout_isatty = False
            self.stderr = sys.stderr
            self.stderr_isatty = False
            self.stdin = sys.stdin
            self.stdin_isatty = False
            self.stdin_encoding = 'utf-8'

    test_env

# Generated at 2022-06-25 18:27:33.569301
# Unit test for function program
def test_program():
    
    import requests
    class Env:
        def __init__(self):
            self.program_name = ''
            self.stdout = sys.stdout
            self.stderr = sys.stderr
            self.stdin = sys.stdin
            self.stdin_encoding = 'utf-8'
            self.stdin_isatty = True
            self.stdout_isatty = True
            self.color = True
            self.headers = None
            self.verbosity_level = 0
            self.config = None
    
    headers = {'content-type': 'text/plain; charset=UTF-8'}
    enc = requests.utils.get_encodings_from_content(headers['content-type'])[0]
    assert enc == 'utf-8'
    

# Generated at 2022-06-25 18:27:45.013701
# Unit test for function main
def test_main():
    assert(main(args=['--help']) == ExitStatus.SUCCESS)
    assert(main(args=['https://google.com']) == ExitStatus.SUCCESS)
    assert(main(args=['https://google.com','--json']) == ExitStatus.SUCCESS)
    assert(main(args=['https://google.com','--form']) == ExitStatus.SUCCESS)
    assert(main(args=['https://google.com','--headers']) == ExitStatus.SUCCESS)
    assert(main(args=['https://google.com','--body']) == ExitStatus.SUCCESS)
    assert(main(args=['https://google.com','--verbose']) == ExitStatus.SUCCESS)

# Generated at 2022-06-25 18:29:57.151639
# Unit test for function main
def test_main():
    main(['--color=auto'])

# Generated at 2022-06-25 18:30:01.677767
# Unit test for function main
def test_main():
    # Creating the arguments list.
    argv = ['http', 'https://httpie.org', '--debug']
    
    # Calling the main function.
    exit_status = main(argv)

    # Checking the expected result.
    assert exit_status == ExitStatus.SUCCESS
    # Checking if the output is present.
    assert False


# Generated at 2022-06-25 18:30:08.628977
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest='_')
    subparser = subparsers.add_parser('get')
    subparser.add_argument('--output-options', action='store')
    subparser.add_argument('--download', action='store_true')
    subparser.add_argument('--download-resume', action='store_true')
    subparser.add_argument('--check-status', action='store_true')
    subparser.add_argument('--headers', action='store')
    subparser.add_argument('--follow', action='store_true')
    subparser.add_argument('--output-file', action='store')
    subparser.add_argument('--quiet', action='store_true')
    subparser.add_argument

# Generated at 2022-06-25 18:30:11.178736
# Unit test for function main
def test_main():
    from httpie.status import ERROR
    from httpie.client import main
    from httpie.cli.constants import OUT_REQ_HEAD
    test_arg = ["www.baidu.com"]
    result = main(test_arg)
    assert result == ERROR


# Generated at 2022-06-25 18:30:13.466318
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    env = Environment()
    program(args, env)

# Generated at 2022-06-25 18:30:19.113271
# Unit test for function program
def test_program():

# -------
# Step 1
# -------

    # args.output_options
    args = Parser().parse_args(['--print=H'])
    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (True, False)
    message = requests.Response()
    assert get_output_options(args, message) == (False, True)
    args = Parser().parse_args([])
    assert get_output_options(args, message) == (True, True)

# -------
# Step 2
# -------

    # args.headers
    args = Parser().parse_args([])
    assert args.headers == {}
    args = Parser().parse_args(['--header', 'Foo:bar'])
    assert args.headers == {'Foo': ['bar']}


# Generated at 2022-06-25 18:30:20.860588
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:30:29.906006
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins import builtin
    from httpie.plugins.manager import get_download_plugins

    env = Environment(config=Config(directory=builtin.DEFAULT_CONFIG_DIR))
    plugin_manager.load_installed_plugins()
    args = parser.parse_args(
        args=['--download', '--output', 'test_program.out', '--header', 'Authorization: Bearer ***'],
        env=env,
    )
    plugin_manager.load_installed_plugins()
    import os
    status = program(args=args, env=env)
    os.remove('test_program.out')
    assert status == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:30:31.487501
# Unit test for function program
def test_program():
    exit_status_0 = program(['https://www.bing.com'], 'env')
    pass

# Generated at 2022-06-25 18:30:41.784712
# Unit test for function main
def test_main():
    args = sys.argv
    env = Environment()
    program_name, *args = args
    env.program_name = os.path.basename(program_name)
    args = decode_raw_args(args, env.stdin_encoding)
    plugin_manager.load_installed_plugins()

    from httpie.cli.definition import parser

    if env.config.default_options:
        args = env.config.default_options + args

    include_debug_info = '--debug' in args
    include_traceback = include_debug_info or '--traceback' in args

    if include_debug_info:
        print_debug_info(env)
        if args == ['--debug']:
            return 0

    exit_status = 0


# Generated at 2022-06-25 18:33:17.163311
# Unit test for function program
def test_program():
    import argparse

# Generated at 2022-06-25 18:33:21.097184
# Unit test for function main
def test_main():
    import unittest
    import subprocess
    import re

    class MainTestCase(unittest.TestCase):
        def test_main(self):
            pass

    unittest.main()

# Generated at 2022-06-25 18:33:21.852941
# Unit test for function program
def test_program():
    exit_status = program()


# Generated at 2022-06-25 18:33:29.190343
# Unit test for function program
def test_program():
    args=[]
    env=Environment()
    assert program(parser.parse_args(args),env) == ExitStatus.SUCCESS
    args=['https://httpbin.org/get']
    assert program(parser.parse_args(args),env) == ExitStatus.SUCCESS
    args=['https://httpbin.org/get','--headers']
    assert program(parser.parse_args(args),env) == ExitStatus.SUCCESS
    args=['https://httpbin.org/get','--headers','--verbose']
    assert program(parser.parse_args(args),env) == ExitStatus.SUCCESS
    args=['https://httpbin.org/get','--headers','--verbose','--output=-']
    assert program(parser.parse_args(args),env) == ExitStatus.SUCCESS
   

# Generated at 2022-06-25 18:33:36.818829
# Unit test for function program
def test_program():
    from io import StringIO
    import sys
    import unittest

    from httpie.cli.argtypes import KeyValueArg
    from httpie.context import Environment
    from httpie.output.formatters import JSONFormatter
    from httpie.plugins.registry import plugin_manager
    from httpie.version import __version__

    import httpie.downloads

    class TestCase(unittest.TestCase):

        def setUp(self):
            self.env = Environment()
            self.output_stream = StringIO()
            self.env.stdout = self.output_stream
            self.env.stderr = StringIO()
            self.env.stdin = StringIO()
            plugin_manager.load_installed_plugins()

        def tearDown(self):
            pass


# Generated at 2022-06-25 18:33:47.117518
# Unit test for function program
def test_program():
    args = argparse.Namespace(
                    auth = None,
                    auth_type = 'basic',
                    body = None,
                    body_style = 'form',
                    check_status = True,
                    download = False,
                    download_resume = True,
                    follow = False,
                    form = False,
                    headers = [],
                    output_file = None,
                    output_file_specified = False,
                    output_options = ['h'],
                    output_style = 'all',
                    pretty = False,
                    quiet = False,
                    session = None,
                    stdin_data_required = False,
                    style = None,
                    syntax = None,
                    timeout = None,
                    url = None
                )
    env = Environment()

# Generated at 2022-06-25 18:33:55.409948
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser(prog='http',
                                     description='HTTPie - a CLI, cURL-like tool for humans.',
                                     add_help=False)
    parser.add_argument('-v', dest='version', action='store_true')
    parser.add_argument('-h', dest='manual', action='store_true')

    args = parser.parse_args()
    if args.version:
        exit(0)

    if args.manual:
        import webbrowser
        webbrowser.open_new("https://httpie.org/docs")
    exit_status = program(args)

# Generated at 2022-06-25 18:33:57.911837
# Unit test for function program
def test_program():
    import pytest
    program('args', 'env')


# Generated at 2022-06-25 18:34:01.575968
# Unit test for function main
def test_main():
    exit_status_0 = main()
    print("exit_status_0 =", exit_status_0)
    assert exit_status_0 == ExitStatus.SUCCESS

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:34:11.912064
# Unit test for function program
def test_program():
    import io
    import sys
    import requests
    import pytest
    from httpie.cli.definition import ArgumentParser
    from httpie.config import Config
    from httpie.downloads import Downloader
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import http_status_to_exit_status

    def get_args(args, env):
        return ArgumentParser(config_dir=env.config.directory, env=env, args=args).parse_args()

    env = Environment()
    env.stdin = io.StringIO()
    env.stdin_isatty = False
    env.stdout = StdoutBytesIO()
    env.stdout_isatty = False
    env.stderr = io.StringIO()
    env.stdin_encoding = sys