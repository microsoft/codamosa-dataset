

# Generated at 2022-06-25 18:26:55.086932
# Unit test for function main
def test_main():
    test_case_0()
    print("All tests passed")

# Generated at 2022-06-25 18:27:01.820849
# Unit test for function program
def test_program():
    """
    Unit test for program
    """

# Generated at 2022-06-25 18:27:09.335662
# Unit test for function main
def test_main():
    sys.argv = ["http", "--debug", "--traceback"]
    exit_status_0 = main()
    assert exit_status_0 == ExitStatus.SUCCESS
    sys.argv = ["http", "--debug"]
    exit_status_0 = main()
    assert exit_status_0 == ExitStatus.SUCCESS
    # TODO: Add more tests
    pass



# Generated at 2022-06-25 18:27:16.230662
# Unit test for function program
def test_program():
    import httpie

    parser = httpie.cli.definition.parser
    parsed_args = parser.parse_args(
        args=[
            'http',
            '--headers',
            '--print=B',
            '--debug',
            '--output=foo',
            'httpbin.org/get'
        ],
        env=httpie.context.Environment(),
    )
    print(parsed_args)
    program(parsed_args, httpie.context.Environment())
    
test_case_0()
#test_program()

# Generated at 2022-06-25 18:27:17.398175
# Unit test for function main
def test_main():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 18:27:26.472743
# Unit test for function program
def test_program():
    msg = collect_messages(args=['https://httpbin.org/get'])
    for message in msg:
        is_request = isinstance(message, requests.PreparedRequest)
        with_headers, with_body = get_output_options(args=None, message=message)
        print(message)
        print(with_headers)
        print(with_body)
        write_message(requests_message=message, env=None, args=None, with_headers=with_headers,
                          with_body=with_body)

if __name__ == "__main__":
    test_program()

# Generated at 2022-06-25 18:27:28.283989
# Unit test for function main
def test_main():
    args = []
    env = Environment()
    assert main(args, env) == ExitStatus.ERROR


# Generated at 2022-06-25 18:27:32.957532
# Unit test for function program
def test_program():
    args = [
        'httpie', 'GET', '\"http://httpbin.org/get?show_env=1\"'
    ]
    env = Environment()
    exit_status = program(args, env)
    assert ExitStatus.SUCCESS == exit_status

if __name__ == '__main__':
    test_case_0()
    test_program()

# Generated at 2022-06-25 18:27:42.092001
# Unit test for function program
def test_program():
    from httpie import __main__
    from httpie.context import Environment
    from httpie.plugins.manager import plugin_manager
    from httpie.cli.parser import parser
    from httpie.cli.definition import parser

    env = Environment()
    env.stderr = sys.stderr
    env.stdout = sys.stdout
    plugin_manager.load_installed_plugins()
    args = parser.parse_args()
    program(args, env)
    test_case_0()


if __name__ == '__main__':
    test_program()

# Generated at 2022-06-25 18:27:44.565422
# Unit test for function program
def test_program():
    argv = ['http', 'https://httpbin.org/get', 'Content-Type:+application/json;+charset=utf-8']
    exit_status = program(argv)


# Generated at 2022-06-25 18:28:18.313868
# Unit test for function program
def test_program():
    class Message:
        def __init__(self,headers,body):
            self.headers = headers
            self.body = body
            self.is_body_upload_chunk = False

    headers = {'b':'b1'}
    body = 'bb'
    msg = Message(headers,body)
    args = ['--output-options', 'b']
    env = ''
    args = program(args, env)
    assert args == {'b': 'b1'}
    assert args == {'b': 'bb'}

# Generated at 2022-06-25 18:28:30.185966
# Unit test for function program
def test_program():
    import pytest
    import sys
    from httpie.cli.parser import parser
    from typing import List
    from httpie import ExitStatus

    class FakeArgs(argparse.Namespace):
        def __init__(self, args: List[str] = sys.argv, stdin_encoding: str = None):
            self.args = args
            self.stdin_encoding = stdin_encoding

    def test_case_1():
        fake_args = FakeArgs(args=["./http/bin/http", "--download", "--check-status", "URL"])
        with pytest.raises(SystemExit) as e:
            env = Environment()
            program(env, fake_args)


# Generated at 2022-06-25 18:28:34.478985
# Unit test for function program
def test_program():
    from httpie.querystring import Querystring
    from httpie.config import Config
    from httpie import environment as env

    args = parser.parse_args()
    env.config = Config(no_config=True)
    messages = collect_messages(args=args)
    for message in messages:
        write_message(requests_message=message, env=env, args=args)



# Generated at 2022-06-25 18:28:41.591131
# Unit test for function program

# Generated at 2022-06-25 18:28:44.045224
# Unit test for function program
def test_program():
    program(sys.argv[0], sys.argv)


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:28:46.673169
# Unit test for function main
def test_main():
    # test case 0
    assert test_case_0() == 0

# Generated at 2022-06-25 18:28:47.600737
# Unit test for function program
def test_program():
    # TODO: Implement
    pass

# Generated at 2022-06-25 18:28:57.591996
# Unit test for function program
def test_program():
    args = {
        'headers': ['Accept: text/html'],
        'output_options': ['H','B'],
        'check_status': False,
        'download': False,
        'download_resume': False,
        'follow': False,
        'output_file': False,
        'output_file_specified': False,
        'quiet': False,
        'method': ['GET'],
        'url': ['http://httpbin.org/robots.txt']
    }
    program_result_0 = program(args, {
        '__name__': 'main',
        'argv': ['http']
    })
    assert program_result_0 == {
        '__name__': 'main',
        'argv': ['http']
    }


# Generated at 2022-06-25 18:29:06.002891
# Unit test for function program
def test_program():
    from io import BytesIO
    from io import StringIO
    from httpie.cli import definition
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.plugins.manager import PluginManager
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    # Test default values
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-25 18:29:15.416574
# Unit test for function program
def test_program():
    parser0 = argparse.ArgumentParser()
    parser0.add_argument('--download', default=False)
    parser0.add_argument('--headers', default=False)
    parser0.add_argument('--output', default=False)
    parser0.add_argument('--output-file', default=False)
    parser0.add_argument('--output-file-specified', default=False)
    parser0.add_argument('--output-options', default=False)
    parser0.add_argument('--quiet', default=False)

    env = Environment(
            config = Config(),
    )

    program(args=parser0, env = env)

# Generated at 2022-06-25 18:30:15.635055
# Unit test for function program
def test_program():
    exit_status = program()
    return exit_status


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:30:23.902111
# Unit test for function program
def test_program():
    """
    Test the actual program.
    """
    from httpie.cli.definition import parser
    from httpie.context import Environment

    # TODO: Test all types of exit_codes; not only ExitStatus.SUCCESS.
    exit_status = program(args=parser.parse_args(args=[
        '--version',
    ], env=Environment()), env=Environment())
    assert exit_status == ExitStatus.SUCCESS


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:30:33.469660
# Unit test for function main
def test_main():
    # Simple case
    exit_status_1 = main(['http', '--print=b', 'localhost'])
    assert exit_status_1 == 0

    # Timeout case
    exit_status_2 = main(['http', '--timeout=0.001', 'localhost'])
    assert exit_status_2 == 5

    # Too many redirects
    exit_status_3 = main(['http', '--max-redirects=1', 'localhost'])
    assert exit_status_3 == 6

    # Unhandled Exception
    exit_status_4 = main(['http', '--download=wrong_filename', 'localhost/?status=200'])
    assert exit_status_4 == 1


# Generated at 2022-06-25 18:30:36.222455
# Unit test for function program
def test_program():
    exit_status = ExitStatus.ERROR
    args = argparse.Namespace()
    env = Environment()
    exit_status = program(args, env)
    assert exit_status == ExitStatus.ERROR

# Generated at 2022-06-25 18:30:46.238400
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser()
    parser.add_argument('-b', action='store_true', dest='binary',
                        help='binary output')
    parser.add_argument('-I', action='store_true', dest='include',
                        help='include protocol headers in the output (H)')
    parser.add_argument('--ignore-stdin', action='store_true',
                        help='ignore stdin')
    parser.add_argument('--max-redirects', type=int, metavar='n',
                        help='don\'t follow more than n redirects')
    parser.add_argument('--output-file', metavar='path',
                        help='write output to <path> instead of stdout')

# Generated at 2022-06-25 18:30:53.995540
# Unit test for function program
def test_program():
    class FakeArgNameSpace:
        quiet = False
        output_options = []
        output_file = None
        output_file_specified = False
        download = False
        download_resume = False
        headers = {}
        check_status = False
        follow = True
        output_file = True
        output_file_specified = True
        def __init__(self, method: str, url: str, data: str, headers: str):
            self.method = method
            self.url = url
            self.data = data
            self.headers = headers
        def __str__(self):
            return ''

    class FakeEnvironment:
        stderr = None
        stdout = None
        stdin = None

    fake_args = FakeArgNameSpace('GET', 'http://httpbin.org/get', '', '')

# Generated at 2022-06-25 18:31:05.689031
# Unit test for function program
def test_program():
    class TestArgs:
        def __init__(self):
            self.check_status = True
            self.download_resume = True
            self.follow = True
            self.headers = []
            self.max_redirects = 1
            self.output_file = None
            self.output_file_specified = None
            self.quiet = False
            self.timeout = 1
            self.traceback = False

    class TestEnvironment:
        def __init__(self):
            self.config = None
            self.is_windows = True
            self.log_error = None
            self.stdin = None
            self.stdin_encoding = 'utf-8'
            self.stdin_isatty = True
            self.stdout = None
            self.stdout_isatty = True


# Generated at 2022-06-25 18:31:09.970825
# Unit test for function main
def test_main():
    # Test that a bad argument causes an exit status of ExitStatus.ERROR
    assert main(["bad_arg"]) == ExitStatus.ERROR
    # Test that a good argument causes an exit status of ExitStatus.SUCCESS
    assert main() == ExitStatus.SUCCESS



# Generated at 2022-06-25 18:31:19.214111
# Unit test for function program
def test_program():
    class Stdout:
        pass
    class Stderr:
        pass
    class Environment:
        def __init__(self):
            self.stdout = Stdout()
            self.stderr = Stderr()
            self.stdout_isatty = True
    env = Environment()
    class Arguments:
        def __init__(self):
            self.check_status = False
            self.download = False
            self.download_resume = False
            self.follow = False
            self.headers = False
            self.output_file = False
            self.output_file_specified = False
            self.output_options = False
            self.quiet = False
    args = Arguments()
    exit_status_0 = program(args, env)
    assert exit_status_0 == ExitStatus.SU

# Generated at 2022-06-25 18:31:28.422464
# Unit test for function main
def test_main():
    import pytest
    default_args = ['--debug']

# Generated at 2022-06-25 18:32:09.503164
# Unit test for function program
def test_program():
    main(['http', '--help'])
    main(['http', '--debug', '--help'])
    main(['http', '--version'])
    main(['http', '--traceback', '--version'])
    main(['httpie', '--help'])
    main(['httpie', '--version'])
    main(['http', '-h'])
    main(['http', '--help'])
    main(['http', '-v'])
    main(['http', '--version'])
    main(['http', '--debug'])
    main(['http', '--traceback'])
    main(['http', '-v', 'google.com'])
    main(['http', '--json', '--pretty', 'all', 'google.com'])
    main

# Generated at 2022-06-25 18:32:12.523595
# Unit test for function main
def test_main():
    assert ExitStatus.SUCCESS == main(["http", "--debug"])
    assert ExitStatus.ERROR == main(["http", "--debug", "--form", "abc=1"])



# Generated at 2022-06-25 18:32:12.995722
# Unit test for function program
def test_program():
    pass

# Generated at 2022-06-25 18:32:14.361646
# Unit test for function main
def test_main():
    # TO DO: Implement unit test for main
    assert True



# Generated at 2022-06-25 18:32:15.514935
# Unit test for function main
def test_main():
    """
    Exit status should be 0, indicating success
    """
    assert main() == 0

# Generated at 2022-06-25 18:32:16.308298
# Unit test for function program
def test_program():
    pass

# Generated at 2022-06-25 18:32:19.960443
# Unit test for function program
def test_program():
    args = []
    env = Environment()
    #args, env = parser.parse_args(args=args)
    print (args)
    print (env)
    exit_status = program(args, env)
    print (exit_status)

if __name__ == '__main__':
    test_program()

# Generated at 2022-06-25 18:32:26.775706
# Unit test for function program

# Generated at 2022-06-25 18:32:29.899800
# Unit test for function main
def test_main():
  print('test main')
  test_case_0()
  # TODO: implement test cases for main.
  # test_case_1()
  # test_case_2()


# Generated at 2022-06-25 18:32:37.489040
# Unit test for function program
def test_program():
    argv = ["http", "google.com"]
    exit_status_0 = main(argv)
    assert exit_status_0 == ExitStatus.SUCCESS
    argv = ["http", "-v", "google.com"]
    exit_status_0 = main(argv)
    assert exit_status_0 == ExitStatus.SUCCESS
    argv = ["http", "POST", "google.com"]
    exit_status_0 = main(argv)
    assert exit_status_0 == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:33:08.609388
# Unit test for function main
def test_main():
    assert main(['--version']) == 0
    assert main(['-v']) == 0
    assert main(['--debug']) == 0
    assert main(['--traceback']) == 0
    assert main(['--help']) == 0
    assert main(['-h']) == 0
    assert main(['-o', '9', '--output-file=10', 'http://127.0.0.1:5000/']) == 0
    assert main(['-o', '11', '--output-file=12', 'http://127.0.0.1:5000/']) == 0
    assert main(['-o', '13', '--output-file=12', 'http://127.0.0.1:5000/']) == 0

# Generated at 2022-06-25 18:33:11.004678
# Unit test for function main
def test_main():
    from httpie.output.formatters.colors import get_lexer
    assert get_lexer('json')

if __name__ == '__main__':
    # main()
    test_case_0()
    test_main()

# Generated at 2022-06-25 18:33:12.957943
# Unit test for function program
def test_program():
    exit_status_0 = main()
    assert(exit_status_0==0)


# Generated at 2022-06-25 18:33:23.497126
# Unit test for function program
def test_program():
    import os
    import pytest
    from tempfile import NamedTemporaryFile
    sys.argv = os.path.basename(__file__).split('.')
    args = [sys.argv[0], '-b', '--form', 'example.com', 'pass=123', '--output=test_program.txt',
    '2>/dev/null']
    exit_status = main(args)
    pytest.main([__file__])
    # check that the exit status is 0 (success)
    assert exit_status == 0
    # check that the output file exists
    with open('test_program.txt') as f:
        data = f.read()
        # check that the output file is not empty
        assert data != ''


# Generated at 2022-06-25 18:33:29.682805
# Unit test for function program
def test_program():
    import requests
    from httpie.cli.parser import parse_args
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    args = parse_args(args=[
        '--output=temp',
    ])
    env = Environment()
    program(args, env)
    result = open('temp', 'r')
    result.readline()
    result.readline()
    result_1 = result.readline()
    result_2 = result.readline()
    assert (result_1 == BINARY_SUPPRESSED_NOTICE and result_2 == BINARY_SUPPRESSED_NOTICE)

    args = parse_args(args=[
        '--verbose', '--output=temp',
    ])
    env = Environment()
    program(args, env)

# Generated at 2022-06-25 18:33:37.119896
# Unit test for function program
def test_program():
    import sys
    import argparse
    from httpie.cli.parser import parser
    parsed_args = parser.parse_args(['http', 'https://www.google.com/'])
    main(parsed_args, 'http')
    exit_status = program(parsed_args, 'http')
    parsed_args = parser.parse_args(['http', 'https://www.google.com/', '--download'])
    main(parsed_args, 'http')
    exit_status = program(parsed_args, 'http')
    parsed_args = parser.parse_args(['http', 'https://www.google.com/', '--download', '--download-resume'])
    main(parsed_args, 'http')

# Generated at 2022-06-25 18:33:47.441848
# Unit test for function program
def test_program():
    from unittest.mock import Mock
    from httpie.cli.definition import parser

    args = parser.parse_args(['get'])
    env = Mock()

    # test the following:
    # - non-HTTP exit statuses are returned directly
    # - KeyboardInterrupt
    # - SystemExit(success)
    # - SystemExit(failure)
    # - normal execution
    # - KeyboardInterrupt
    # - SystemExit
    # - requests.Timeout
    # - requests.TooManyRedirects
    # - any other exception
    #
    # TODO: the switch to ExitStatus should make the first use case unnecessary
    # TODO: maybe disallow calling program() inside a try/except? that would make it
    #       easier to test
    exit_status = program(args, env)
    assert exit_status

# Generated at 2022-06-25 18:33:48.732833
# Unit test for function main
def test_main():
    main(['httpie', '--debug'])


# Generated at 2022-06-25 18:33:53.692851
# Unit test for function main
def test_main():
    exit_status_0 = main()
    assert exit_status_0 == ExitStatus(0)
    # from httpie.cli.constants.responses import ERROR_CONNECTION_FAILED
    # assert exit_status_0 == ExitStatus.ERROR_CONNECTION_FAILED
    # assert exit_status_0 == ExitStatus.ERROR
    # assert exit_status_0 == ExitStatus.ERROR_TIMEOUT
    # assert exit_status_0 == ExitStatus.ERROR_TOO_MANY_REDIRECTS
    # exit_status_0 = main()
    # assert exit_status_0 == ExitStatus(0)
    # exit_status_0 = main()
    # assert exit_status_0 == ExitStatus(0)
    # exit_status_0 = main()
    # assert exit_status_0 == Exit

# Generated at 2022-06-25 18:34:00.504686
# Unit test for function program
def test_program():
    os_environ_bak = os.environ
    def cleanup(bak):
        os.environ = bak
    try:
        os.environ = {'HTTP_PROXY': 'http://user:pass@proxy.example.com'}
        exit_status = program(['-p', '-'], Environment())
        assert exit_status == ExitStatus.SUCCESS
    finally:
        cleanup(os_environ_bak)
    try:
        os.environ = {'HTTP_PROXY': 'http://user:pass@proxy.example.com'}
        exit_status = program(['-p', '-'], Environment())
        assert exit_status == ExitStatus.SUCCESS
    finally:
        cleanup(os_environ_bak)


# Generated at 2022-06-25 18:35:17.174597
# Unit test for function program
def test_program():
    from httpie import ExitStatus
    from httpie.cli.constants import OUT_RESP_HEAD
    from httpie.output.writer import OUTPUT_OPTIONS_MAP
    args = argparse.Namespace()
    env = Environment()
    env.config = argparse.Namespace()
    env.config.output_options = OUT_RESP_HEAD
    env.config.output_options = OUTPUT_OPTIONS_MAP(env.config.output_options)
    args.output_options = env.config.output_options
    args.headers = []
    args.check_status = True
    args.follow = False
    args.quiet = False
    args.output_file = None
    args.output_file_specified = False


    # TODO: Refactor and drastically simplify, especially so that the separator logic is

# Generated at 2022-06-25 18:35:21.702579
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    args = parser.parse_args(args=["--verbose", "https://httpbin.org/post", "testkey=testvalue"], env=Environment())
    exit_status = program(args=args, env=Environment())
    assert exit_status == 0

# Generated at 2022-06-25 18:35:22.638850
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:35:31.795416
# Unit test for function program
def test_program():
    from httpie import ExitStatus
    from httpie.cli.parser import parse_args
    from httpie.config import Environment, Config
    import json
    import os
    import shlex

    args = parse_args(shlex.split('--check-status --headers'), env=Environment())
    exit_status_0 = program(args=args, env=Environment())
    assert exit_status_0 == ExitStatus.SUCCESS

    args = parse_args(shlex.split('--check-status --headers www.google.com'), env=Environment())
    exit_status_1 = program(args=args, env=Environment())
    assert exit_status_1 == ExitStatus.SUCCESS

    args = parse_args(shlex.split('--check-status --headers --follow www.google.com'), env=Environment())
    exit_status

# Generated at 2022-06-25 18:35:39.951015
# Unit test for function main
def test_main():
    import json
    import requests

    class Args(list):
        output_file = None
        output_file_specified = False

    class MyEnvironment:

        class stdin:
            buffer = lambda self, *_: None

        class stderr:
            buffer = lambda self, *_: None
            write = lambda self, *_: None

        class stdout:
            buffer = lambda self, *_: None

        class config:

            class directory:
                pass

        stdin_encoding = "utf-8"


# Generated at 2022-06-25 18:35:42.982663
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    import sys
    import argparse
    args = parser.parse_args(args=['-b', '--debug'], env=Environment())
    return program(args, sys.stderr)
    assert exit_status == ExitStatus.ERROR


# Generated at 2022-06-25 18:35:51.839709
# Unit test for function program
def test_program():
    class FakeEnv:
        def __init__(self):
            self.config = None
            self.program_name = None
            self.stderr = None
            self.stdin_encoding = None
            self.stdout = None
            self.stdout_isatty = None
        def log_error(self,message,level='error'):
            pass

    class FakeArgs:
        def __init__(self):
            self.headers = {}
            self.method = 'POST'
            self.output_file = None
            self.output_file_specified = None
            self.output_options = []
            self.url = 'http://127.0.0.1:5000/'
            self.download = None
            self.download_resume = None
            self.follow = None
            self.check