

# Generated at 2022-06-25 18:28:08.400511
# Unit test for function main
def test_main():
    module_0 = module_0
    prepared_request_0 = module_0.PreparedRequest()
    exit_status_0 = main(prepared_request_0)


# Generated at 2022-06-25 18:28:14.461802
# Unit test for function program
def test_program():
    # Case 1:
    # Urllib3 HTTP request is sent but server is not there
    # Response: EXIT_STATUS.ERROR
    req_0 = module_0.PreparedRequest()
    req_0.body = 'b'
    req_0.headers = {'a':'b'}
    exit_status_0 = program(req_0, Environment())
    assert exit_status_0 == ExitStatus.ERROR


# Generated at 2022-06-25 18:28:18.503114
# Unit test for function program
def test_program():
    # Test with normal arguments.
    exit_status = program(['/home/httpie', 'GET', 'http://httpbin.org/get'])
    assert type(exit_status) == ExitStatus
    # Test with special arguments.
    exit_status = program(['/home/httpie', 'GET', 'http://httpbin.org/get'])
    assert type(exit_status) == ExitStatus
    # Test with special arguments.
    args = argparse.Namespace
    env = Environment
    exit_status = program(args, env)
    assert type(exit_status) == ExitStatus


# Generated at 2022-06-25 18:28:23.512733
# Unit test for function main
def test_main():
    # test case 0
    prepared_request_0 = io.BytesIO()
    exit_status_0 = main(prepared_request_0)


test_main()

# Generated at 2022-06-25 18:28:24.778973
# Unit test for function program
def test_program():

    # Test with parameters: args, env
    # TODO:
    pass

# Generated at 2022-06-25 18:28:27.516598
# Unit test for function program
def test_program():
    args_0 = []
    env_0 = Environment()
    testcase_program_0 = program(args_0, env_0)
    assert testcase_program_0 == ExitStatus("OK")


# Generated at 2022-06-25 18:28:32.587803
# Unit test for function main
def test_main():
    main("''")
    main("''", "b''")
    main("' '")
    main("' '", "b' '")


# Generated at 2022-06-25 18:28:40.276722
# Unit test for function main
def test_main():
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
    assert main(["hi"]) == 0
   

# Generated at 2022-06-25 18:28:47.232440
# Unit test for function program
def test_program():
    # Test with a positional argument
    assert program(['url'], Environment) == ExitStatus.SUCCESS
    # Test with a short option
    assert program(['--debug'], Environment) == ExitStatus.SUCCESS
    # Test with a long option
    assert program(['--timeout', '30'], Environment) == ExitStatus.SUCCESS
    # Test with multiple options
    assert program(['--timeout', '30', '--debug'], Environment) == ExitStatus.SUCCESS

import requests.models as module_2


# Generated at 2022-06-25 18:28:47.998524
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 18:29:29.092325
# Unit test for function program
def test_program():
    main(['pytest'])

# Generated at 2022-06-25 18:29:41.413912
# Unit test for function program
def test_program():
    class TestArgument:
        pass
    class TestEnvironment:
        pass
    class TestResponse:
        pass
    args = TestArgument()
    args.output_options = []
    args.download = False
    args.headers = []
    args.check_status = False
    args.follow = False
    args.quiet = False
    args.output_file = None
    args.output_file_specified = None
    args.download_resume = False
    env = TestEnvironment()
    env.stdout_isatty = True
    response = TestResponse()
    response.status_code = 200
    program(args, env)
    response.status_code = 300
    program(args, env)
    response.status_code = 400
    program(args, env)
    response.status_code = 500
   

# Generated at 2022-06-25 18:29:42.316241
# Unit test for function main
def test_main():
    # case 0
    test_case_0()

# Generated at 2022-06-25 18:29:46.888579
# Unit test for function main
def test_main():
    import sys
    import pathlib

    sys.path.append(str(pathlib.Path('.').absolute().parent))
    from httpie.cli import main

    args = [
        'http', 'GET', 'http://httpbin.org/get'
    ]
    env = Environment()
    exit_status = main(args, env)
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:29:51.809579
# Unit test for function program
def test_program():
    args = ["https://httpbin.org/get", "Accept:application/json", "--json"]
    try:
        with open("test.txt", "w") as f:
            exit_status = program(args, f)
    except Exception as e:
        print(e)



# Generated at 2022-06-25 18:29:56.225655
# Unit test for function program
def test_program():
    pass


if __name__ == '__main__':
    test_case_0()
    test_program()

# Generated at 2022-06-25 18:29:57.248898
# Unit test for function main
def test_main():
    #test_case_0()
    assert True

# Generated at 2022-06-25 18:30:05.658958
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli import definition
    from httpie.cli.argtypes import KeyValue

    class MockEnv:
        def __init__(self, program_name="httpie"):
            self.program_name = program_name
            self.stderr = sys.stderr
            self.stdout = sys.stdout


    class MockArgParser(argparse.ArgumentParser):
        def __init__(self, *args, **kwargs):
            kwargs["add_help"] = False
            super().__init__(*args, **kwargs)

        def error(self, message):
            pass

        def exit(self, status=0, message=None):
            pass


# Generated at 2022-06-25 18:30:08.289583
# Unit test for function program
def test_program():
    # TODO: Remove this function after refactoring.
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['--download', 'https://api.github.com'])
    return program(args, Environment())


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-25 18:30:13.685651
# Unit test for function program
def test_program():
    from httpie.core import main
    from httpie.cli.definition import parser
    from io import StringIO
    args = parser.parse_args(args=['httpbin.org'])
    env = Environment(stdout=StringIO())
    main.program(args=args, env=env)
    args = parser.parse_args(args=['httpbin.org/status/418'])
    env = Environment(stdout=StringIO())
    main.program(args=args, env=env)
    args = parser.parse_args(args=['httpbin.org/robots.txt'])
    env = Environment(stdout=StringIO())
    main.program(args=args, env=env)

# Generated at 2022-06-25 18:30:46.065175
# Unit test for function program
def test_program():
    import pprint
    class Dummy_environment():
        def __init__(self):
            self.stderr = None
            self.stdin = None
            self.stdin_isatty = False
            self.stdout = None
            self.stdout_isatty = True
            self.stdout_should_be_bytes = False
            self.stdout_text_encoding = 'utf8'
            self.stdout_errors = 'strict'
            self.stdout_can_output_colors = True
            self.config = None
            self.stdin_encoding = None
            self.stdout_encoding = None

    env = Dummy_environment()
    env.config = Dummy_environment()
    env.config.directory = None

# Generated at 2022-06-25 18:30:47.998881
# Unit test for function program
def test_program():
    args = "program"
    env = "env"
    assert program(args,env) == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:30:55.170389
# Unit test for function program
def test_program():
    p = os.path.dirname(os.path.abspath(__file__))
    a = os.path.dirname(os.path.dirname(p))
    sys.path.insert(0, a)

    test_args = ['http', 'https://httpie.org/']
    print(type(test_args[0]))
    test_env = Environment()

    test_args = decode_raw_args(test_args, test_env.stdin_encoding)


# Generated at 2022-06-25 18:30:56.683927
# Unit test for function main
def test_main():
    args = ['--debug']
    main(args)

# Generated at 2022-06-25 18:30:57.392631
# Unit test for function program
def test_program():
    pass

# Generated at 2022-06-25 18:31:09.526692
# Unit test for function program
def test_program():
    # Test case 1
    env_0 = Environment()
    env_0.program_name = 'http'
    env_0.stdout = io.BytesIO()
    env_0.stderr = io.StringIO()
    env_0.config = Configuration()
    env_0.config.directory = 'C:\\Users\\Giovanni\\PycharmProjects\\httpie'
    env_0.config.config_dir = 'C:\\Users\\Giovanni\\PycharmProjects\\httpie\\config'
    env_0.config.config_path = 'C:\\Users\\Giovanni\\PycharmProjects\\httpie\\config\\config.json'
    env_0.config.plugins_dir = 'C:\\Users\\Giovanni\\PycharmProjects\\httpie\\config\\plugins'

# Generated at 2022-06-25 18:31:19.214472
# Unit test for function program
def test_program():
    # Test case 1
    args = argparse.Namespace(
        cookies=[],
        headers=[],
        ignore_stdin=False,
        method=None,
        output_file=None,
        output_options=('H', 'b'),
        output_to_file=False,
        output_to_stdout=True,
        output_to_terminal=True,
        output_to_temporary_file=True,
        pretty='all',
        session=[],
        stdin_bytes=False,
        verify=True,
        verify_ssl_certs=True,
    )

# Generated at 2022-06-25 18:31:21.129205
# Unit test for function program
def test_program():
    exit_status = main(['--debug'])
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:31:26.986619
# Unit test for function program
def test_program():
    exit_status = program(
        args=[
            'GET',
            '-v',
            '--print=BbHh',
            '--timeout=3',
            '--max-redirects=10',
            'httpbin.org/get'
        ],
        env=Environment(stderr=sys.stderr, stdout=sys.stdout)
    )
    if exit_status == ExitStatus.SUCCESS:
        print(exit_status)

# Generated at 2022-06-25 18:31:31.547820
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    assert program(args, None) == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:33:20.744953
# Unit test for function main
def test_main():
    from httpie.cli import env
    from httpie.cli.definition import parser
    args = parser.parse_args(
        args=['-v'],
        env=env(),
    )
    assert main(args=['-v'], env=env()) == ExitStatus.SUCCESS



# Generated at 2022-06-25 18:33:28.433764
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser()
    parser.add_argument("--foo", help="foo help")
    parser.add_argument("--debug", action="store_true", help="debug help")
    parser.add_argument("--follow", help="follow help", action="store_true")
    parser.add_argument("--check-status", help="check status help", action="store_true")
    parser.add_argument("--download", help="download help", action="store_true")
    parser.add_argument("--download-resume", help="resume help", action="store_true")
    parser.add_argument("--max-redirects", help="max redirects", type=int)
    parser.add_argument("--timeout", help="timeout", type=int)

# Generated at 2022-06-25 18:33:29.037633
# Unit test for function program
def test_program():
    program()

# Generated at 2022-06-25 18:33:31.992832
# Unit test for function program
def test_program():
    import argparse
    
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    exit_status = program(args)
    assert exit_status == ExitStatus.SUCCESS



# Generated at 2022-06-25 18:33:34.684856
# Unit test for function program
def test_program():
    pass


# Generated at 2022-06-25 18:33:42.343546
# Unit test for function main
def test_main():
    test_case_0()


# Compiled code
_main_code = compile('\ndef _main(args, env):\n    return main(args=args, env=env)\n', '<string>', 'exec')

# Pattern to extract variable/argument/parameter for function '_main' from source code
_main_pattern = re.compile(r'\ndef _main\((?P<param>[^)]*)\):\n    return main\((?P<args>[^)]*)\)\n')

# Pattern to extract variable/argument/parameter 'args' for function 'main' from source code
_main_re_args = re.compile(r'\s*args\s*=[^,]*[,)]')

# Pattern to extract variable/argument/parameter 'env' for function 'main'

# Generated at 2022-06-25 18:33:49.060910
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', '--t', action='store_true')
    parser.add_argument('-f', '--follow', action='store_true')
    parser.add_argument('-h', '--headers', action='store_true')
    parser.add_argument('-b', '--body', action='store_true')
    parser.add_argument('-o', '--output_options', action='store_true')
    parser.add_argument('-d', '--download', action='store_true')
    parser.add_argument('-dr', '--download_resume', action='store_true')
    parser.add_argument('-of', '--output_file', action='store_true')

# Generated at 2022-06-25 18:33:51.984627
# Unit test for function program
def test_program():
    class Namespace(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    program(Namespace(), Environment())

# Generated at 2022-06-25 18:34:01.494475
# Unit test for function program
def test_program():
    # Capture arguments and calls to sys.exit
    _exit = sys.exit
    _argv = sys.argv
    captured_argv = []
    captured_exit_status = []

    # replace sys.exit with custom function
    try:
        sys.exit = lambda status: captured_exit_status.append(status)
        sys.argv = ['http']
        exit_status = program(args=['--debug'], env=Environment())
        assert len(captured_argv) == 1
        assert captured_argv[0] == ['--debug']
        assert exit_status == ExitStatus.SUCCESS
    finally:
        # restore sys.exit
        sys.exit = _exit
        sys.argv = _argv

# Generated at 2022-06-25 18:34:11.868778
# Unit test for function main
def test_main():
    import unittest

    class CmdArgs:
        # noinspection PyPep8Naming
        def __init__(self, program_name, cmd_string):
            self._program_name = program_name
            self._cmd_string = cmd_string
            self._ok = True
            self._parse_args()

        def _parse_args(self):
            import argparse

            parser = argparse.ArgumentParser("test_httpie", add_help=False)
            self.args = parser.parse_args(args=self._cmd_string)
            self._ok = True

        def isOk(self):
            return self._ok
