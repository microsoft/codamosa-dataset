

# Generated at 2022-06-25 18:26:57.306512
# Unit test for function program
def test_program():
    try:
        program(['--debug'])
    except SystemExit as e:
        assert e.code == ExitStatus.SUCCESS
    try:
        program(['--debug', 'https://httpie.org'])
    except SystemExit as e:
        assert e.code == ExitStatus.SUCCESS
    try:
        program(['--traceback', 'https://httpie.org'])
    except SystemExit as e:
        assert e.code != ExitStatus.SUCCESS
    try:
        program(['--download', '--output=file.txt', 'https://httpie.org'])
    except SystemExit as e:
        assert e.code == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:26:59.195576
# Unit test for function main
def test_main():
    test_case_0()

# Compiled version of test_main

# Generated at 2022-06-25 18:27:09.578821
# Unit test for function program
def test_program():
    # Sample test case 1
    str_args = "curl http://httpbin.org/ip"
    from httpie.cli.parser import parse_args
    from httpie import Environment
    from httpie.plugins.manager import plugin_manager
    from httpie.cli.constants import DEFAULT_OPTIONS
    env = Environment()
    plugin_manager.load_installed_plugins()
    args = parse_args(args=str_args, env=env)
    #assert args.headers == [('accept', 'application/json')]
    assert args.headers == []
    assert args.url == 'http://httpbin.org/ip'
    assert args.method == 'GET'
    #args.headers = DEFAULT_OPTIONS
    #assert args.headers == [('gzip', '')]

# Generated at 2022-06-25 18:27:13.527907
# Unit test for function program
def test_program():
    exit_status = program()
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:27:24.256992
# Unit test for function main

# Generated at 2022-06-25 18:27:25.775778
# Unit test for function main
def test_main():
    with pytest.raises(AssertionError):
        test_case_0()

# Generated at 2022-06-25 18:27:36.349435
# Unit test for function program
def test_program():
    
    import unittest
    import mock
    
    
    m_testArgs = mock.Mock()
    m_testArgs.headers = None
    m_testArgs.follow = None
    m_testArgs.download = None
    m_testArgs.download_resume = None
    
    
    
    class Test_program(unittest.TestCase):
        def setUp(self):
            pass
        
        def tearDown(self):
            pass
        
        # Test program() with param args.download set to True
        # Input:
        #        args.download = True

# Generated at 2022-06-25 18:27:45.590527
# Unit test for function main
def test_main():
    try:
        from httpie.cli.definition import parser
    except Exception as e:
        print(e)
        assert 0

# Generated at 2022-06-25 18:27:46.342217
# Unit test for function program
def test_program():
    assert program() is None


# Generated at 2022-06-25 18:27:47.843128
# Unit test for function program
def test_program():
    env = Environment()
    args = main(args=["--version"], env=env)
    assert(args == ExitStatus.SUCCESS)


# Generated at 2022-06-25 18:28:58.470528
# Unit test for function main
def test_main():
    exit_status_1 = main(args=['httpget ', '--debug'])
    exit_status_2 = main(args=['httpget', '--debug'])
    exit_status_3 = main(args=['httpget', '--debug'])
    exit_status_4 = main(args=['httpget', '--debug'])
    assert True


# Generated at 2022-06-25 18:28:59.377347
# Unit test for function program
def test_program():
    assert main() == 0


# Generated at 2022-06-25 18:29:01.925980
# Unit test for function program
def test_program():
    class Args:
        def __init__(self):
            self.output_options = ['hC']
    env = Environment()
    args = Args()
    program(args, env)

# Generated at 2022-06-25 18:29:13.690473
# Unit test for function main
def test_main():
    # noinspection PyUnusedLocal
    exit_status_9 = main(['--debug'])

    exit_status_1 = main(['httpie', '--debug'])
    # noinspection PyUnusedLocal
    exit_status_2 = main(['httpie', 'GET', 'google.com'])
    exit_status_3 = main(['httpie', 'GET', '--debug', 'google.com'])
    exit_status_4 = main(['httpie', '--debug', 'GET'])
    exit_status_5 = main(['--debug', 'httpie', 'GET'])
    exit_status_6 = main(['GET', 'httpie', '--debug'])
    exit_status_7 = main(['GET', '--debug'])

# Generated at 2022-06-25 18:29:20.297094
# Unit test for function main
def test_main():
    assert main(['http', '--version']) == ExitStatus.SUCCESS
    assert main(['http', 'https://httpbin.org/status/200']) == ExitStatus.SUCCESS
    assert main(['http', '--headers', 'https://httpbin.org/get']) == ExitStatus.SUCCESS
    assert main(['http', '--form', 'key=val', 'https://httpbin.org/post']) == ExitStatus.SUCCESS
    assert (main(['http', '--ignore-stdin', 'https://httpbin.org/status/200']) == ExitStatus.SUCCESS)
    assert (main(['http', '--json', '{"key": "val"}', 'https://httpbin.org/post']) == ExitStatus.SUCCESS)

# Generated at 2022-06-25 18:29:27.243436
# Unit test for function program
def test_program():
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.log_level = 'debug'
    env.config.directory = 'httpie'
    args = parser.parse_args(
        args=['http', 'https://httpbin.org/get'],
        env=env,
    )
    program(args=args, env=env)

# Generated at 2022-06-25 18:29:29.719232
# Unit test for function program
def test_program():
    exit_status = program(object, object)
    assert(exit_status == ExitStatus.SUCCESS)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 18:29:41.646582
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check-status", required=False, action='store_true')
    parser.add_argument("--download", required=False, action='store_true')
    parser.add_argument("--download-resume", required=False, action='store_true')
    parser.add_argument("--follow", required=False, action='store_true')
    parser.add_argument("--output", required=False, type=str, default="")
    parser.add_argument("--output-file", required=False, type=argparse.FileType('a'))
    parser.add_argument("--output-options", required=False, type=str, default="")
    parser.add_argument("--quiet", required=False, action='store_true')
    args = parser

# Generated at 2022-06-25 18:29:47.282134
# Unit test for function main
def test_main():
    env_0 = Environment()
    args_0 = ['/Users/joycelee/Desktop/httpie/httpie/cli/__main__.py', '--version']
    main_0 = main(args_0, env_0)
    assert main_0 == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:29:49.770141
# Unit test for function program
def test_program():
    exit_status = program(args=['https://google.com'], env=Environment())
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:30:33.244183
# Unit test for function program
def test_program():
    # Test program with valid arguments
    from httpie.cli.argtypes import KeyValueArg
    from httpie.config import Config, DEFAULT_CONFIG_DIR
    from httpie.plugins.manager import PluginManager

    config = Config(directory=DEFAULT_CONFIG_DIR)
    env = Environment(config=config)
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    args = parser.parse_args(['https://httpie.org/', 'Accept:application/json'], env)
    assert program(args=args, env=env) == ExitStatus.SUCCESS
    assert program(args=args, env=env) == ExitStatus.SUCCESS

if __name__ == '__main__':
    #test_case_0()
    test_program()

# Generated at 2022-06-25 18:30:36.818975
# Unit test for function main
def test_main():
    exit_status_1 = main(['-h'])
    assert exit_status_1 == ExitStatus.SUCCESS

    argv = ['http', 'GET']
    exit_status_2 = main(argv)
    assert exit_status_2 == ExitStatus.SUCCESS

    argv = ['http', 'httpbin.org']
    exit_status_3 = main(argv)
    assert exit_status_3 == ExitStatus.SUCCESS



# Generated at 2022-06-25 18:30:46.574791
# Unit test for function program
def test_program():

    # Test 1 - Basic Success
    args1 = ["https://httpbin.org/get"]
    args = parser.parse_args(args=args1)
    exit_status = program(args=args, env=Environment())
    assert exit_status == ExitStatus.SUCCESS

    # Test 2 - Basic Failure
    args2 = ["https://httpbin.org/status/400"]
    args = parser.parse_args(args=args2)
    exit_status = program(args=args, env=Environment())
    assert exit_status == ExitStatus.ERROR

    # Test 3 - File input failure
    args3 = ["-i", "file_does_not_exist.json", "https://httpbin.org/get"]
    args = parser.parse_args(args=args3)

# Generated at 2022-06-25 18:30:47.246581
# Unit test for function main
def test_main():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 18:30:54.656310
# Unit test for function main
def test_main():
    class StdIO:
        def __init__(self, log_file_name="test_log_main.log"):
            # Open a log file for the test case
            self.log_file = open(log_file_name, 'w')
            pass
        def write(self, buffer):
            self.log_file.write(buffer)
        def writelines(self, buffer):
            for line in buffer:
                self.log_file.write(line)
        def close(self):
            self.log_file.close()
    try:
        sys.stdin = StdIO()
        sys.stdout = StdIO()
        sys.stderr = StdIO()
        test_case_0()
    finally:
        sys.stdin.close()
        sys.stdout.close()


# Generated at 2022-06-25 18:30:56.489874
# Unit test for function program
def test_program():
    args = []
    exit_status = program(args=args, env=[])
    return exit_status


# Generated at 2022-06-25 18:30:57.516856
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:31:09.787067
# Unit test for function program
def test_program():
    """
    Unit test for function program
    """
    print("Unit test for function program")
    test_case_1()
    test_case_1_1()
    test_case_2()
    test_case_3()
    test_case_3_1()
    test_case_4()
    test_case_5()
    test_case_5_1()
    test_case_5_2()
    test_case_5_3()
    test_case_5_4()
    test_case_5_5()
    test_case_5_6()
    test_case_5_7()
    test_case_5_8()
    test_case_5_9()
    test_case_6()
    test_case_6_1()
    test_case_6_2

# Generated at 2022-06-25 18:31:19.226113
# Unit test for function program
def test_program():
    """
    Unit test for function program,
    it tests the content of final result.
    """
    class dummy_Env:
        """
        A dummy class to replace the env in function program,
        it offers a dummy variable stdout which remains the content of the result.
        """
        def __init__(self):
            self.stdout = []
            self.stderr = []
        def log_error(self, *args, **kwargs):
            self.stderr.append(args)
        def log_info(self, *args, **kwargs):
            self.stderr.append(args)
        def log_warning(self, *args, **kwargs):
            self.stderr.append(args)
        def log_debug(self, *args, **kwargs):
            self.stder

# Generated at 2022-06-25 18:31:20.646509
# Unit test for function main
def test_main():
    argv = ['http']
    # main(argv)



# Generated at 2022-06-25 18:32:03.359672
# Unit test for function main
def test_main():
    print("\nfunction main")
    test_case_0()

# Generated at 2022-06-25 18:32:12.467363
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser(
        prog='http',
        description='HTTPie %s, a CLI, cURL-like tool for humans.' % __version__
    )

    parser.add_argument(
        '--auth', metavar='USER:PASS',
        help='Basic/Digest/Custom authentication.'
    )
    parser.add_argument(
        '--auth-type', default='basic',
        help='Auth type (basic, digest, or a plugin name).'
    )
    parser.add_argument(
        '--auth-plugin',
        help='Authentication plugin name.'
    )

# Generated at 2022-06-25 18:32:21.165977
# Unit test for function program
def test_program():
    args = argparse.Namespace
    args.output_options = None
    args.headers = None
    args.download_resume = None
    args.download = True
    args.output_file = None
    args.output_file_specified = False
    args.check_status = None
    args.follow = True
    args.quiet = None
    env = Environment(
        stdin=sys.stdin,
        stdin_isatty=sys.stdin.isatty(),
        stdout=sys.stdout,
        stderr=sys.stderr,
        stdout_isatty=sys.stdout.isatty(),
        stderr_isatty=sys.stderr.isatty(),
    )
    exit_status = program(args, env)

# Generated at 2022-06-25 18:32:22.369454
# Unit test for function main
def test_main():
    test_case_0()

# Compute total number of tests

# Generated at 2022-06-25 18:32:23.517115
# Unit test for function main
def test_main():
    assert callable(main)



# Generated at 2022-06-25 18:32:24.481201
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 18:32:34.338624
# Unit test for function program
def test_program():
    import types
    import os
    import tempfile
    sys.argv = ['http', '--timeout=1.0', '--max-redirects=10', '--check-status',
                '--headers', 'Content-Type: application/json', '--output==', '--verbose',
                '--body={ "username": "Aladdin", "password": "OpenSesame" }',
                'https://httpie.org/get']
    test_env = Environment()
    test_env.stdin = sys.stdin
    test_env.stdout = sys.stdout
    test_env.stderr = sys.stderr
    test_env.stdin_isatty = False
    test_env.stdout_isatty = False
    test_env.stderr_isatty = False


# Generated at 2022-06-25 18:32:43.070527
# Unit test for function program
def test_program():
    from click.testing import CliRunner
    from httpie.cli import cli
    from httpie.plugins.builtin import HTTPBasicAuth

    plugin_manager.register(HTTPBasicAuth())
    runner = CliRunner()
    cli_args = ['--debug', 'httpbin.org/get', 'foo=bar', 'baz', '--auth=user:password', '--form']
    result = runner.invoke(cli.cli, cli_args)
    print(result.output)
    assert result.exit_code == ExitStatus.SUCCESS

if __name__ == '__main__':
    test_program()

# Generated at 2022-06-25 18:32:43.965973
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 18:32:45.989026
# Unit test for function program
def test_program():
    exit_status = program('https://www.google.com')
    assert exit_status == 0


# Generated at 2022-06-25 18:34:08.598925
# Unit test for function program
def test_program():

    class Args():
        def __init__(self, args=[]):
            self.args = args

        def __getitem__(self, i):
            return self.args[i]

        def __iter__(self):
            return iter(self.args)

    class Env():
        def __init__(self):
            self.stderr = sys.stderr
            self.stdout = sys.stdout
            self.stdout_isatty = sys.stdout.isatty()
            self.stdin_encoding = 'utf8'
            self.stdin_isatty = sys.stdin.isatty()

        def log_error(self, msg, level='error'):
            self.stderr.write(msg)


# Generated at 2022-06-25 18:34:11.912603
# Unit test for function program
def test_program():
    # Since program() calls out to main(), can't test it separately.
    # main() always returns an integer, and program() will always
    # return an integer so this test is only valid.
    assert isinstance(program(None, None), int)

# Generated at 2022-06-25 18:34:13.365017
# Unit test for function program
def test_program():
    args = 'https://httpbin.org/get'.split()
    env = Environment()
    program(args, env)

# Generated at 2022-06-25 18:34:22.463347
# Unit test for function main
def test_main():
    from httpie import stdin  # noqa
    from httpie.cli.definition import parser
    from httpie import env
    from httpie.cli.constants import DEFAULT_OPTIONS, DEFAULT_METHOD
    from httpie.cli.parser import parse_args
    from httpie.utils import get_response_type
    from httpie.context import Environment
    args, env = parse_args(decode_raw_args([], env.stdin_encoding), env=env, parser=parser)
    assert args.method == DEFAULT_METHOD
    assert args.headers == {}
    assert args.auth is None
    assert args.output_options == DEFAULT_OPTIONS
    assert args.output_file_specified is False
    assert args.output_file is None
    assert args.data is None

    # TODO: call

# Generated at 2022-06-25 18:34:24.803164
# Unit test for function program
def test_program():
    args = ['-v', 'https://google.com']
    env = Environment()
    env.config.default_options = None
    program(args=args, env=env)



# Generated at 2022-06-25 18:34:27.054512
# Unit test for function program
def test_program():
    test_program_0()
    test_program_1()
    test_program_2()
    test_program_3()
    test_program_4()
    test_program_5()


# Generated at 2022-06-25 18:34:35.111783
# Unit test for function program
def test_program():
    class args:
        output_file = None
        output_file_specified = False
        download = False
        download_resume = False
        follow = False
        headers = None
        max_redirects = None
        check_status = False
        quiet = False
        timeout = None
        output_options = ('all',)
    class env:
        stdout = sys.stdout
        stderr = sys.stderr
        stdout_isatty = True
        program_name = "http"
        def log_error(self, message, level = "error") -> None:
            print(message)
    exit_status = program(args, env)
    assert exit_status == ExitStatus.SUCCESS
    test_case_0()

# Generated at 2022-06-25 18:34:43.301649
# Unit test for function program
def test_program():
    from .output.formatter.colors import NoColors

    def stdout_isatty():
        return False

    # TODO: Remove the need for injecting a mocked object.
    class MockedEnvironment(Environment):
        def __init__(self, stdout_isatty):
            super().__init__()
            self.stdout_isatty = stdout_isatty

    class MockedNamespace:
        def __init__(self):
            self.headers = {}
            self.output_options = [
                OUT_REQ_HEAD,
                OUT_RESP_HEAD
            ]
            self.output_file = None
            self.check_status = True
            self.quiet = False
            self.acl = None
            self.form = {}
            self.data = None
            self.download = False

# Generated at 2022-06-25 18:34:44.388092
# Unit test for function program
def test_program():
    exit_status = program()
    return exit_status

# Generated at 2022-06-25 18:34:51.951864
# Unit test for function main
def test_main():
    import sys,io
    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput
    test_case_0()
    sys.stdout = sys.__stdout__