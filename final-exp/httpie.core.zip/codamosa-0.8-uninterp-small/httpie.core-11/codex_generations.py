

# Generated at 2022-06-25 18:26:35.788385
# Unit test for function program
def test_program():
    # Do this first so that we set a default
    # otherwise httpie itself messes it up somehow
    import httpie.cli.argtypes

# Generated at 2022-06-25 18:26:37.441195
# Unit test for function program
def test_program():
    main(['--version'])


# Generated at 2022-06-25 18:26:40.414366
# Unit test for function main
def test_main():
    args = ['-v']
    exit_status = main(args)

    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:26:41.742706
# Unit test for function main
def test_main():
    assert main([]) == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:26:43.048311
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:26:46.304866
# Unit test for function program
def test_program():
    args = parser.parse_args(["https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=ext_id:10731718"], env)
    program(args, env)


# Generated at 2022-06-25 18:26:57.033874
# Unit test for function main
def test_main():
    import pytest
    import tempfile
    import os

    @pytest.fixture
    def env():
        return Environment(stdin=tempfile.TemporaryFile(),
                           stdin_isatty=False,
                           stdout=tempfile.TemporaryFile(),
                           stdout_isatty=False,
                           stderr=tempfile.TemporaryFile(),
                           share_environment=False,
                           config_dir=tempfile.mkdtemp(),
                           config_dir_mode=0o700)

    @pytest.fixture
    def args(env):
        return ['http', '--json', 'https://httpbin.org/get']


# Generated at 2022-06-25 18:27:08.608514
# Unit test for function program
def test_program():
    import sys
    import os
    import tempfile
    import shutil
    import io

    class MockEnv:
        def __init__(self):
            # make temp folder
            self.temp_folder = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_folder, 'file.txt')

            # mock stdout
            self.stdout = io.StringIO()

            # set config dir to temp folder
            self.config_dir = self.temp_folder

            # create empty config file in temp folder
            self.config_file = os.path.join(self.config_dir, 'config')
            open(self.config_file, 'w+')

            # create empty keyring file in temp folder

# Generated at 2022-06-25 18:27:14.682347
# Unit test for function main
def test_main():
    with mock.patch('httpie.cli.program.program') as mock_program:
        mock_program.return_value = ExitStatus.SUCCESS
        main(['http', 'fake-arg'])
        mock_program.assert_called_with(
            args=mock.ANY,
            env=mock.ANY,
        )


# Generated at 2022-06-25 18:27:15.968085
# Unit test for function main
def test_main():
    """
    pytest --capture=tee-sys

    """
    test_case_0()

# Generated at 2022-06-25 18:27:46.644707
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 18:27:52.284942
# Unit test for function main
def test_main():
    # Capture the contents of stderr and stdout
    captured_stderr, captured_stdout = StringIO(), StringIO()
    old_stderr, old_stdout = sys.stderr, sys.stdout
    try:
        sys.stderr, sys.stdout = captured_stderr, captured_stdout
        args = [b'http']
        exit_status = main(args)
    finally:
        sys.stderr, sys.stdout = old_stderr, old_stdout
    stdout = captured_stdout.getvalue().strip()
    stderr = captured_stderr.getvalue().strip()
    assert exit_status == ExitStatus.ERROR, f'unexpected exit status {exit_status}'

# Generated at 2022-06-25 18:27:53.341301
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-25 18:27:56.503552
# Unit test for function main
def test_main():
    # Example 1
    x = main()
    assert x == 0
    # Example 2
    x = main()
    assert x == 0
    # Example 3
    x = main()
    assert x == 0
    


# Generated at 2022-06-25 18:28:03.790613
# Unit test for function program
def test_program():
    from httpie import StatusCodes
    from httpie.cli.definition import parser

    args = parser.parse_args()
    env = Environment()
    # Process messages as they’re generated

# Generated at 2022-06-25 18:28:11.233903
# Unit test for function program
def test_program():
    class Params():
        class Namespace():
            headers = {'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate', 'Connection': 'keep-alive', 'User-Agent': 'python-requests/2.19.1'}
            follow = False
            output_file = None
            output_options = (1, 8)
            check_status = False
            quiet = False
            stream = False
            download_resume = False
            download = False
            output_file_specified = False
    env = Environment()
    params = Params()
    exit_status_1 = program(params.Namespace(),env)
    assert exit_status_1 == 0


# Generated at 2022-06-25 18:28:20.465620
# Unit test for function main
def test_main():
    args_0 = ['--debug']
    exit_status_0 = main(args_0)
    assert exit_status_0 == ExitStatus.SUCCESS
    args_1 = ['--debug']
    exit_status_1 = main(args_1)
    assert exit_status_1 == ExitStatus.SUCCESS

    # TODO uncomment when implemented
    # args_2 = []
    # exit_status_2 = main(args_2)
    # assert exit_status_2 == ExitStatus.SUCCESS
    # args_3 = []
    # exit_status_3 = main(args_3)
    # assert exit_status_3 == ExitStatus.SUCCESS

    # TODO uncomment when implemented
    # args_4 = []
    # exit_status_4 = main(args_4)
    #

# Generated at 2022-06-25 18:28:23.983061
# Unit test for function program
def test_program():
    # TODO: Implement
    pass

# Generated at 2022-06-25 18:28:24.922495
# Unit test for function main
def test_main():
    assert main([]) == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:28:32.692310
# Unit test for function program
def test_program():
    from httpie.cli import definition, parser
    from httpie.cli.argtypes import KeyValueArg
    from httpie.config import BaseEnvironment
    from httpie import ExitStatus, Environment
    import io, sys


    args = parser.parse_args([u'http', u'-v', u'https://httpbin.org/json'])

    stdout = io.BytesIO()
    sys.stdout = stdout

    exit_status = program(args=args, env=Environment())
    #print(stdout.getvalue().decode('utf-8'))
    stdout.close()
    assert exit_status == ExitStatus.SUCCESS


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:29:10.631238
# Unit test for function program
def test_program():
    import pytest
    from httpie.context import Environment
    from httpie.cli.argtypes import KeyValueArgType


# Generated at 2022-06-25 18:29:13.808488
# Unit test for function program
def test_program():

    args = [
        "test",
        "http://www.google.com"
    ]

    env = Environment()
    exit_status = program(args, env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:29:16.582075
# Unit test for function main
def test_main():
    print("Starting test_main:")

    # Test case 0.
    # Command: http --help
    exit_status_0 = main(['http', '--help'])
    assert exit_status_0 == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:29:28.912828
# Unit test for function main
def test_main():
    import argparse
    input_args = argparse.Namespace(default_options=['--download'], follow=True, headers=None, output_file=None, output_file_specified=False, output_options=('o',), quiet=False, verbose=True, max_redirects=10, timeout=30, check_status=False, download=True, download_resume=False)
    input_args.headers = ['-H', 'Accept: */*']
    environment_0 = Environment()
    environment_0.check_requests_version = True
    environment_0.check_urllib3_version = True
    environment_0.prefer_ipv6 = False
    environment_0.user_agent = 'HTTPie/1.0.3'

# Generated at 2022-06-25 18:29:34.993442
# Unit test for function program
def test_program():
    from httpie.cli.decoders import BytesRequired

    class DummyArgs:
        data = None
        files = None
        json = None
        form = None

    # args without body
    args = DummyArgs()
    assert program(args, None) == 0

    # args with body (--data)
    args = DummyArgs()
    args.data = 'test'
    # See `cli/parser.py`: `data` is possible only if there is no `json`.
    assert not hasattr(DummyArgs, 'json')
    assert program(args, None) == 0

    # args with body (--form)
    args = DummyArgs()
    args.form = 'test'
    assert program(args, None) == 0

    # args with body (--files, --data, --form)
   

# Generated at 2022-06-25 18:29:43.725447
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit as e:
        assert e.code == ExitStatus.SUCCESS
    except KeyboardInterrupt:
        pass
    except:
        print('unexpected exception')
        raise

# Compatibility with Python 2.7, where argparse.Namespace doesn't have __eq__.
try:
    argparse.Namespace.__eq__
except AttributeError:
    argparse.Namespace.__eq__ = lambda self, other: self.__dict__ == other.__dict__

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 18:29:46.270477
# Unit test for function main
def test_main():
    args = ['httpie']
    env = Environment()
    exit_status = main(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:29:51.881106
# Unit test for function program
def test_program():
    sys.argv = ['http', 'http://httpbin.org/get']
    exit_status = program()
    assert exit_status == ExitStatus.SUCCESS
    sys.argv = ['http', 'http://httpbin.org/status/404']
    exit_status = program()
    assert exit_status == ExitStatus.ERROR_HTTP_4XX


# Generated at 2022-06-25 18:29:53.513699
# Unit test for function program
def test_program():
    obj = program(args=None, env=None)
    assert obj == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:30:01.407590
# Unit test for function main
def test_main():
    import pytest
    import sys
    import requests.exceptions
    class MockStderr:
        def __init__(self, version=None):
            self.version = version

        def write(self, req_msg: str):
            print(req_msg)

        def flush(self):
            pass

    class MockEnvironment():
        def __init__(self):
            self.program_name = "main.py"
            self.config_dir = "./"
            self.config = 'config'
            self.stdin_encoding = 'stdin_encoding'
            self.stdout = MockStderr()
            self.stderr = MockStderr('2.7.0')

        def log_error(self, msg: str, level: str=None):
            pass

    # Test case 1:

# Generated at 2022-06-25 18:30:34.164919
# Unit test for function main
def test_main():
    assert main(['http','https://httpbin.org/get']) == 0
    assert main(['http','--status','https://httpbin.org/get']) == 0
    assert main(['http','--verbose','https://httpbin.org/get']) == 0
    assert main(['http','--help']) == 0
    assert main(['http','-v']) == 0


# Generated at 2022-06-25 18:30:35.051287
# Unit test for function program
def test_program():
    exit_status_1 = program()

# Generated at 2022-06-25 18:30:38.824831
# Unit test for function program
def test_program():
    test_args = argparse.Namespace(args=['hey', 'man'])
    test_env = Environment()
    assert program(args=test_args, env=test_env) == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:30:47.294050
# Unit test for function program
def test_program():
    import argparse
    args = argparse.Namespace()
    args.follow = True
    args.output_file = None
    args.headers = {'Content-Type': 'application/json'}
    args.download = True
    args.download_resume = True
    args.output_options = ["b"]
    args.check_status = True
    args.quiet = False
    import tempfile
    tempFile = tempfile.NamedTemporaryFile()
    args.output_file_specified = tempFile
    import io
    f = io.StringIO()
    env = Environment()
    env.stdout = f
    env.stderr = f
    program(args, env)


# Generated at 2022-06-25 18:30:58.368258
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-25 18:31:01.807775
# Unit test for function main
def test_main():
    assert main(['http', 'get', 'google.com']) == ExitStatus.SUCCESS
    assert not main(['http', 'get', 'http://google.com'], env=Environment())



# Generated at 2022-06-25 18:31:12.396648
# Unit test for function program
def test_program():
    """
    Unit testing for program
    """
    class MockClass(object):
        """
        A mock class for argparse.Namespace
        """
        def __init__(self, request_body_read_callback):
            self.output_options = ['headers', 'body']
            self.output_file = sys.stdout
            self.check_status = True
            self.follow = True
            self.download = False
            self.download_resume = False
            self.request_body_read_callback = request_body_read_callback
    
    class Request(object):
        """
        Mock class for requests.PreparedRequest
        """
        def __init__(self):
            self.url = "http://httpbin.org/get"

# Generated at 2022-06-25 18:31:14.149695
# Unit test for function program
def test_program():
    program(args=argparse.Namespace(), env=Environment())
    return


# Generated at 2022-06-25 18:31:17.756364
# Unit test for function main
def test_main():
    # 401 Authorization Required
    exit_status_1 = main(['https://httpbin.org/basic-auth/user/password'],
                        env=Environment(config={"default_options": ["--auth", "user:password"]}))

    # 200 OK, normal case
    exit_status_2 = main(['https://httpbin.org/get'])

    assert True



# Generated at 2022-06-25 18:31:18.425521
# Unit test for function program
def test_program():
    pass

# Generated at 2022-06-25 18:31:59.174469
# Unit test for function program
def test_program():
    import argparse
    args = argparse.Namespace()
    env = Environment(stdout_isatty=False)
    exit_status = program(args, env)


# Generated at 2022-06-25 18:32:00.168042
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 18:32:03.754328
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    if False:
        main()
    else:
        test_main()

# Generated at 2022-06-25 18:32:07.930507
# Unit test for function program
def test_program():
    args1 = ['GET', 'http://test.com/test.txt']
    env1 = Environment()

    exit_status_1 = program(args=args1, env=env1)

    assert exit_status_1 == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:32:13.205289
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.cli.config import Config
    from httpie.plugins.registry import plugin_manager
    plugin_manager.load_installed_plugins()
    args = parser.parse_args(
        args=['http', 'httpbin.org/get'],
        env=Config(default_options=[])
    )
    program(args, '')


# Generated at 2022-06-25 18:32:17.497591
# Unit test for function main
def test_main():
    # Initialize Mock Objects
    env = Environment()
    args = ['https://google.com']

    # Call Function Under Test (FUT)
    exit_status = main(args, env)

    # Assert
    assert exit_status == ExitStatus.SUCCESS
    assert env.stderr.written



# Generated at 2022-06-25 18:32:25.230606
# Unit test for function main
def test_main():
    import json
    import tempfile
    import os
    import requests
    import sys


# Generated at 2022-06-25 18:32:27.883354
# Unit test for function main
def test_main():
    command_line_args = ['http', 'example.com']
    decode_raw_args(command_line_args, 'utf-8')
    test_case_0()

# Generated at 2022-06-25 18:32:30.832434
# Unit test for function program
def test_program():
    test_program_0()
    test_program_1()
    test_program_2()
    test_program_3()
    test_program_4()


# Generated at 2022-06-25 18:32:31.822551
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-25 18:34:11.741037
# Unit test for function program
def test_program():
    args0 = ['--download', '--output-file=test_file',
             '--download-resume', 'test_url']
    env = Environment()
    ret = program(args=args0, env=env)
    assert ret == None
    
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 18:34:20.931026
# Unit test for function main
def test_main():
    from unittest.mock import Mock

    from httpie.context import Environment

    env = Environment()
    args = [
        'http',
        '--verbose',
        'https://httpbin.org/get',
    ]
    print('\nTesting function main\n')
    print(f'args: {args}\n')
    print('Result:\n')
    main(args=args, env=env)
    
    assert env.stderr.getvalue() == '\n'
    env.stderr.reset_mock()
    
    # Test on HTTPConnection
    args = [
        'http',
        '--follow',
        '--max-redirects=0',
        '--data=hello',
        'http://httpbin.org/redirect/3',
    ]
   

# Generated at 2022-06-25 18:34:29.595051
# Unit test for function main
def test_main():
    import sys
    import os
    import subprocess
    import random
    import threading
    import time
    import json
    import os.path
    import shutil

    global httpbin  # Prevent resize during tests.

    from httpie import __main__
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from utils import TestEnvironment, http, HTTP_OK, COLOR, CRLF
    from fixtures import (
        FILE_PATH, FILE_CONTENT, JSON_FILE_PATH, JSON_FILE_CONTENT,
        BIN_FILE_PATH, BIN_FILE_CONTENT, BIN_FILE_PATH_ARG
    )
    from utils import httpbin, httpbin_secure


# Generated at 2022-06-25 18:34:33.036236
# Unit test for function program
def test_program():
    r = main(['--output-format=json', 'https://httpbin.org/'])
    assert r == ExitStatus.SUCCESS
    r = main(['--output-format=json', 'https://httpbin.org/'])
    assert r == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:34:33.528718
# Unit test for function program
def test_program():
    print(program)

# Generated at 2022-06-25 18:34:36.047019
# Unit test for function main
def test_main():
    os.chdir('./test')
    cmd_args = ['http']
    exit_status = main(cmd_args)
    print(f"exit_status = {exit_status}")



# Generated at 2022-06-25 18:34:43.188362
# Unit test for function program
def test_program():
    import os
    import pytest
    from httpie.cli import default_options
    from httpie.plugins import builtin
    from httpie.plugins.manager import PLUGIN_MANAGER
    from httpie.status import ExitStatus
    os.chdir('./test/')
    try:
        # Note: The signature of program() has changed.
        #       That's why we test the output of main() instead.
        #       The test needs to be updated.
        result = main(args=['--json', '-b'])
    except NotImplementedError:
        return
    assert result == ExitStatus.SUCCESS


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:34:51.086574
# Unit test for function program
def test_program():
    namespace = argparse.Namespace()
    namespace.program_name = 'httpie'
    namespace.headers = []
    namespace.limit_rate = None
    namespace.output_file = None
    namespace.output_file_specified = False
    namespace.body = None
    namespace.json = None
    namespace.form = False
    namespace.scheme = None
    namespace.host = None
    namespace.proxy = None
    namespace.cert = None
    namespace.verify = False
    namespace.timeout = None
    namespace.traceback = False
    namespace.debug = False
    namespace.check_status = True
    namespace.download = False
    namespace.follow = False
    namespace.download_resume = False
    namespace.headers = []
    namespace.ignore_stdin = False
    namespace.output_options = []
    namespace

# Generated at 2022-06-25 18:34:53.569645
# Unit test for function program
def test_program():
    exit_status = program(args=argparse.Namespace(follow=False, output_options=['format']), env=Environment())
    assert exit_status == 0


# Generated at 2022-06-25 18:35:02.748194
# Unit test for function main
def test_main():
    import tempfile
    import pytest
    import os
    import httpie
    def test_main_error(capsys):
        import sys

        def get_code(e):
            return e.code
        with pytest.raises(SystemExit) as e:
            httpie.main(['-vv'])  # Issue #538
        assert get_code(e) == httpie.ExitStatus.ERROR

        with pytest.raises(SystemExit) as e:
            httpie.main(['--json'])
        assert get_code(e) == httpie.ExitStatus.ERROR

        with pytest.raises(SystemExit) as e:
            httpie.main(['--form'])
        assert get_code(e) == httpie.ExitStatus.ERROR
