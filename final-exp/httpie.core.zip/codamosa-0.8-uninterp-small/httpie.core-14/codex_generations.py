

# Generated at 2022-06-25 18:27:07.037578
# Unit test for function program
def test_program():
    with open(r'C:\Users\tacad\Documents\GitHub\httpie\tests\data\request_headers', 'r') as myfile:
        test_data = myfile.read()
    print(f"\n{test_data}")
    env = Environment()
    args = ["GET", "http://httpbin.org/get", "--headers"]
    program(args=args, env=env)


# Generated at 2022-06-25 18:27:09.296081
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:27:13.086010
# Unit test for function main
def test_main():
    exit_status_1 = main(['http', '--ignore-stdin', 'https://httpie.org/'])
    if exit_status_1 == ExitStatus.SUCCESS:
        return True
    else:
        return False


# Generated at 2022-06-25 18:27:15.070516
# Unit test for function program
def test_program():
    import argparse
    args = argparse.Namespace()
    program(args, Environment())


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:27:17.281609
# Unit test for function program
def test_program():
    args = parser.parse_args(args=['http', '--help'], env=Environment())
    exit_status = program(args, Environment())
    print(exit_status)

# Generated at 2022-06-25 18:27:20.659036
# Unit test for function main
def test_main():
    args = [
        "httpie.py",
        "--version"
    ]
    exit_status = main(args)
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:27:29.304976
# Unit test for function program
def test_program():
    import os
    import sys
    from httpie import __main__
    # If stdin_encoding is None, assume that the user ran pip3 install -e ".[dev]" instead of installing the
    # package.
    if __main__.stdin_encoding is None:
        from importlib import reload
        reload(sys)
        sys.stdin = open(os.devnull)
        sys.stdin.encoding = 'utf-8'

    args = ['http', 'httpbin.org/get']
    env = __main__.Environment()
    exit_status_1 = program(args, env)


# Generated at 2022-06-25 18:27:33.166080
# Unit test for function main
def test_main():
    # Record the original sys.argv
    orignal_sys_argv = sys.argv[:]
    try:
        # Run function
        test_case_0()
    finally:
        # Reset sys.argv to original state
        sys.argv = orignal_sys_argv


# Generated at 2022-06-25 18:27:42.343602
# Unit test for function program
def test_program():
    # Tests that program() returns exit_status 0 when requests_messages = []
    assert program(argparse.Namespace(output_options=['hb'], follow=False, check_status=False),
                   Environment(stdout=io.StringIO(), stderr=io.StringIO())) == 0
    assert program(argparse.Namespace(output_options=['hb'], follow=False, check_status=False),
                   Environment(stdout=io.StringIO(), stderr=io.StringIO(), config=Configuration())) == 0



# Generated at 2022-06-25 18:27:49.319617
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('-m', '--method', dest='method', default='GET', type=str)
    parser.add_argument('--headers', dest='headers', default='', type=str)
    parser.add_argument('-f', '--follow', dest='follow', action='store_true')
    parser.add_argument('--check-status', dest='check_status', action='store_true')
    parser.add_argument('--max-redirects', dest='max_redirects', default=10, type=int)
    parser.add_argument('--timeout', dest='timeout', type=float)
    parser.add_argument('-d', '--download', dest='download', action='store_true')

# Generated at 2022-06-25 18:28:54.696771
# Unit test for function program
def test_program():
    args0 = [1,2,3]
    #env0 = Environment()
    program(args=args0, env=Environment())

# Generated at 2022-06-25 18:28:56.285165
# Unit test for function main
def test_main():
    exit_status_0 = main()



# Generated at 2022-06-25 18:28:58.299454
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 18:29:06.601299
# Unit test for function program
def test_program():

    args = argparse.Namespace()
    
    # Use a temporary environment.
    with httpie.cli.environment.Environment() as env:
        args.output_options = None
        
        # Test for requests.responses
        class message:
            status_code = 200
        message.raw = requests.Response()
        message.raw.status = 200
        message.raw.reason = 'OK'
        args.check_status = True
        args.follow = True
        args.quiet = True
        assert program(args, env) == ExitStatus.SUCCESS

        # Test for requests.responses
        class message:
            status_code = 200
        message.raw = requests.Response()
        message.raw.status = 200
        message.raw.reason = 'OK'
        args.check_status = True

# Generated at 2022-06-25 18:29:17.138598
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from unittest import TestCase

    patch('httpie.cli.app.program', autospec=True).start()
    with patch('httpie.cli.app.main_0', autospec=True) as main_0_mock:
        main_0_mock.return_value = ExitStatus.SUCCESS
        main(args=['req'])
        main_0_mock.assert_called_once_with(args=['req'], env=Environment())
        main_0_mock.reset_mock()

        main(args=['req'], env=Environment(colors=True))
        main_0_mock.assert_called_once_with(args=['req'], env=Environment(colors=True))

    patch.stopall()

#

# Generated at 2022-06-25 18:29:20.702420
# Unit test for function program
def test_program():
    # Test  case program
    args = []
    env = Environment()
    program(args, env)



if __name__ == '__main__':
    program(sys.argv)

# Generated at 2022-06-25 18:29:31.394213
# Unit test for function main
def test_main():
    # Add your own tests here
    args = ['http', 'https://httpbin.org/get']
    exit_status = main(args)
    # http --json https://httpbin.org/get
    args = ['http', '--json', 'https://httpbin.org/get']
    exit_status = main(args)
    
    # https://httpbin.org/get
    args = ['https://httpbin.org/get']
    exit_status = main(args)

    # http --debug httpie.org
    args = ['http', '--debug', 'httpie.org']
    exit_status = main(args)
    
    # http --traceback https://httpbin.org/get
    args = ['http', '--traceback', 'https://httpbin.org/get']
    exit_status = main

# Generated at 2022-06-25 18:29:42.197250
# Unit test for function main
def test_main():
    # Use --debug to raise exceptions and print debug info.
    os.chdir(r"D:\GitHub\httpie\tests")
    test_args0 = r"httpbin.org/get --timeout=0.001".split()
    test_args1 = r"httpbin.org/get --timeout=0.001 --debug".split()
    test_args2 = r"--debug --verbose".split()
    test_args3 = r"".split()
    test_args4 = r"".split()
    test_args5 = r"".split()
    test_args6 = r"".split()
    test_args7 = r"".split()
    test_args8 = r"".split()
    test_args9 = r"".split()

    test_case_0()

# Generated at 2022-06-25 18:29:46.060294
# Unit test for function main
def test_main():
  main()
  main(sys.argv)


# Generated at 2022-06-25 18:29:49.943563
# Unit test for function main
def test_main():
    import json
    # Testcase 1: normal test, output is 0
    sys.argv = ["http", "--json", "http://127.0.0.1:5000/get"]
    exit_status_1 = main()
    assert exit_status_1 == 0


# Generated at 2022-06-25 18:30:30.575446
# Unit test for function program
def test_program():
    try:
        program(['https://www.cloudflare.com/'], Environment())
        # This is to check if the program would raise any exceptions
        assert True
    except:
        assert False

# Generated at 2022-06-25 18:30:31.421107
# Unit test for function program
def test_program():
    args, env = program()

# Generated at 2022-06-25 18:30:32.850627
# Unit test for function main
def test_main():
    test_case_1()
    test_case_0()



# Generated at 2022-06-25 18:30:43.007066
# Unit test for function program
def test_program():
    class DummyEnvironment:
        def __init__(self):
            self.config = {
                "color": True,
                "theme": None,
                "default_options": [],
                "default_options_set": False,
                "directory": None,
                "max_host_history_length": 0,
                "max_request_history_length": 0,
                "output_options": [],
                "rc_path": None,
                "rc_paths": [],
                "timeout": None,
                "verify": True,
            }

        def log_error(self, message: str, level: str = "error"):
            print(f"{level}: {message}")

    # Basic test for program()

# Generated at 2022-06-25 18:30:48.082222
# Unit test for function main
def test_main():
    try:
        sys.argv = [sys.argv[0], "https://www.baidu.com"]
        sys.stdout = open("/tmp/httpie/http.martin.cmu.edu.txt", "w")
        test_case_0()
    finally:
        sys.stdout.flush()
        sys.stdout.close()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 18:30:55.220299
# Unit test for function program
def test_program():
    from os import name as os_name
    from sys import version_info as sys_version_info
    from httpie.cli.constants import IS_WINDOWS
    from httpie.cli.parser import parse_args
    from httpie.plugins.manager import builtin_plugins
    from httpie.status import ExitStatus
    from httpie.compat import is_py3
    import httpie
    if os_name == 'nt':
        del os_name
    if is_py3:
        del sys_version_info
    if IS_WINDOWS:
        del IS_WINDOWS
    if not builtin_plugins:
        builtin_plugins.append(httpie)
    args_0 = parse_args(args=['www.example.com'])

# Generated at 2022-06-25 18:31:07.798582
# Unit test for function main
def test_main():
    assert main(['http', 'http://localhost:8080']) == 0
    assert main(['http', 'http://localhost:8080', '--download', '--output', 'out.txt']) == 0
    assert main(['http', '--download']) == 0
    assert main(['http', '--json', '--help']) == 0
    assert main(['http', '--help']) == 0
    assert main(['http', '--json']) == 0
    assert main(['http', '-j']) == 0
    assert main(['http', 'http://localhost:8080', '--color', '--debug']) == 0
    assert main(['http', 'http://localhost:8080', '-c']) == 0

# Generated at 2022-06-25 18:31:14.778171
# Unit test for function main
def test_main():
    # Set up test data
    args_0 = ["httpie"]
    env_0 = Environment()
    main(args_0, env_0)
    main(args_0, env_0)
    main(args_0, env_0)
    main(args_0, env_0)
    main(args_0, env_0)
    main(args_0, env_0)
    main(args_0, env_0)
    main(args_0, env_0)
    main(args_0, env_0)
    main(args_0, env_0)
    main(args_0, env_0)
    main(args_0, env_0)
    main(args_0, env_0)
    main(args_0, env_0)

# Generated at 2022-06-25 18:31:27.132618
# Unit test for function program
def test_program():
    """

    :return:
    """
    import argparse
    import httpie.cli.constants as constants

# Generated at 2022-06-25 18:31:39.688966
# Unit test for function main
def test_main():
    exit_status_1 = main(['httpie.py'])
    res = requests.get('http://localhost:5000/')
    exit_status_2 = main(['httpie.py','http://localhost:5000/','GET'])
    exit_status_3 = main(['httpie.py','http://localhost:5000/','GET','--auth','jake:password'])
    exit_status_4 = main(['httpie.py','http://localhost:5000/','GET','--cookies','jake:password'])
    exit_status_5 = main(['httpie.py','http://localhost:5000/','GET','--form','jake:password'])
    exit_status_6 = main(['httpie.py','http://localhost:5000/','GET','--headers','jake:password'])
    exit_status

# Generated at 2022-06-25 18:32:41.627685
# Unit test for function main
def test_main():
    import httpie.plugins.builtin.asciinema
    import httpie.plugins.builtin.colors
    import httpie.plugins.builtin.format.formatters
    import httpie.plugins.builtin.format.formatters.colors

    import httpie.plugins.builtin.format.highlight
    import httpie.plugins.builtin.format.formatters.highlight

    import httpie.plugins.builtin.json.formatter
    import httpie.plugins.builtin.json.json
    import httpie.plugins.builtin.json.lexer

    import httpie.plugins.builtin.pretty.formatter
    import httpie.plugins.builtin.pretty.pretty
    import httpie.plugins.builtin.pretty.style

    import httpie.plugins.builtin.stream

    import httpie.plugins

# Generated at 2022-06-25 18:32:45.628278
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace(output_options=[], download=None, download_resume=None, follow=None, check_status=None, quiet=None, output_file=None, output_file_specified=False, headers=[])
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:32:52.963297
# Unit test for function main
def test_main():
    class stdin_mock:
        def __init__(self):
            self.content_json_bytes = b'{"mock": "stdin bytes"}'
            self.content_json_str = self.content_json_bytes.decode('ascii')
            self.fd = io.BytesIO(self.content_json_bytes)

        def isatty(self):
            return False

        def read(self):
            return self.content_json_str

        def readlines(self):
            return self.read().split('\n')

    class stderr_mock:
        def __init__(self):
            self.fd = io.BytesIO()

        def write(self, msg):
            self.fd.write(msg.encode('utf-8'))


# Generated at 2022-06-25 18:32:55.923505
# Unit test for function main
def test_main():
    # Case 0: run normally, return 0
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 18:32:56.869095
# Unit test for function program
def test_program():
    print(program)


# Generated at 2022-06-25 18:33:01.488229
# Unit test for function program
def test_program():
    pass
    #args = parser.parse_args(['https://httpbin.org/post', '-d', '''{"username": "abc", "password": "xyz"}'''])
    #exit_status = program(args=args, env=Environment())
    #assert exit_status == 0


# Generated at 2022-06-25 18:33:04.198077
# Unit test for function main
def test_main():
    import pytest, sys
    with pytest.raises(SystemExit, match=r'((?!0).)*$') as ex:
        sys.argv = ['http']
        main()
    assert ex.type == SystemExit
    assert ex.value.code != 0


# Generated at 2022-06-25 18:33:11.798746
# Unit test for function program
def test_program():
    class MockEnvironment:
        "Mocked environment"
        def __init__(self):
            pass
        
        def __repr__(self):
            return self.__str__()
        
        def __str__(self):
            return "Mocked environment"

        @property
        def stderr(self):
            return sys.stderr

        @property
        def stdout(self):
            return sys.stdout

        @property
        def stdout_isatty(self):
            return True


# Generated at 2022-06-25 18:33:13.142432
# Unit test for function program
def test_program():
    pass


# Generated at 2022-06-25 18:33:14.246188
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 18:34:06.802387
# Unit test for function main
def test_main():
    exit_status = main()
    assert exit_status is ExitStatus.SUCCESS


# Generated at 2022-06-25 18:34:09.260054
# Unit test for function main
def test_main():
    expected_exit_status = ExitStatus.ERROR
    actual_exit_status = main(['http','--debug'])
    assert(expected_exit_status==actual_exit_status)

# Generated at 2022-06-25 18:34:10.292284
# Unit test for function program
def test_program():
    print(program)


# Generated at 2022-06-25 18:34:19.699718
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.check_status = True
    args.download = False
    args.download_resume = False
    args.follow = False
    args.headers = []
    args.max_redirects = 30
    args.output_file = None
    args.output_file_specified = False
    args.output_options = ['h', 'b']
    args.prettify = False
    args.pretty_all = False
    args.quiet = False
    args.style = 'solarized'
    args.style_aliases = False
    args.timeout = 30
    args.verbose = True
    _env = Environment(config=None)
    res = program(args, _env)
    expected = ExitStatus.SUCCESS

# Generated at 2022-06-25 18:34:25.884282
# Unit test for function program
def test_program():
    args = ['get', 'https://www.google.com']
    env = Environment()
    program(args=args, env=env)

if __name__ == '__main__':
    from httpie.cli.request_items import Item, KeyValueArg, KeyValue, HTTPieArgumentParser
    from httpie.cli.constants import DEFAULT_OPTIONS
    # print(list(Item(item=i).value for i in DEFAULT_OPTIONS))
    for i in DEFAULT_OPTIONS:
        print(i)
    # test_case_0()

# Generated at 2022-06-25 18:34:27.307727
# Unit test for function main
def test_main():
    sys.argv = ["http", "--json", "http://www.google.com"]
    main()

# Generated at 2022-06-25 18:34:36.186502
# Unit test for function program
def test_program():
    import sys
    import pytest
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parser
    from httpie.keyvalue import KeyValue
    from httpie.status import ExitStatus

    args = parser.parse_args(["http://www.baidu.com"])

    exit_code = program(args, Environment())

    assert exit_code == ExitStatus.SUCCESS

    # check whether download is right
    if args.download:
        args.follow = True  # --download implies --follow.
        downloader = Downloader(output_file=args.output_file, progress_file=env.stderr, resume=args.download_resume)
        downloader.pre_request(args.headers)

# Generated at 2022-06-25 18:34:43.926311
# Unit test for function program
def test_program():
    from copy import copy
    from httpie.cli.definition import parser
    from httpie.compat import urlunparse
    from httpie.output.writer import write
    from httpie.plugins import FormatterPluginProxy
    from httpie.status import ExitStatus
    from httpie.utils import get_response_stream
    from httpie import ExitStatus

    class Args(object):
        def __init__(self):
            self.headers = None
            self.follow = False
            self.output_options = None
            self.method = None
            self.body = None
            self.timeout = None
            self.check_status = None
            self.download = None
            self.download_resume = None
            self.output_file = None
            self.output_file_specified = None
            self.stdin_isatty

# Generated at 2022-06-25 18:34:51.472615
# Unit test for function program
def test_program():
    import mock
    import requests
    import sys
    import contextlib
    sys.argv = ['http', 'http://httpbin.org/get']
    with mock.patch('requests.Session.send', mock.Mock()) as mock_send:
        response = requests.Response()
        response._content = b'A sample response'
        mock_send.return_value = response
        response.status_code = 200
        env = Environment()
        args = {}
        with contextlib.redirect_stdout(sys.stdout):
            program(args=args, env=env)
    print('Program() ran without exception')
    sys.argv = ['http', 'http://httpbin.org/get']
    env = Environment()
    args = {}
    if env.debug:
        main(env=env)
    print

# Generated at 2022-06-25 18:34:57.448563
# Unit test for function program
def test_program():
    from httpie.cli.parser import parser
    from cmd2.cli import Application


    # parser = Application.get_default_arg_parser()
    args = parser.parse_args(['-v','--all','8.8.8.8:80'])
    env = Environment()
    print(dir(args))
    print(dir(env))
    print(program(args, env))
    print(program(args, env))


if __name__ == '__main__':
    test_program()

# Generated at 2022-06-25 18:35:48.706482
# Unit test for function program
def test_program():
    program(sys.argv, Environment())
