

# Generated at 2022-06-25 18:26:53.958626
# Unit test for function main
def test_main():
    input_0 = ['', '--debug']
    environment_1 = module_0.Environment()
    var_1 = main(input_0, environment_1)
    assert var_1 is ExitStatus.ERROR


# Generated at 2022-06-25 18:27:01.055093
# Unit test for function program
def test_program():
    import requests
    
    # Create empty arguments with default values for all fields
    program_0 = requests.PreparedRequest()
    program_1 = requests.Response()
    program_0.method = "get"
    program_0.url = 'www.example.com'
    program_1.status_code = 200
    program_1.raw = "abc"
    program_2 = Environment()
    program_3 = parser.parse_args()
    program_4 = get_output_options(program_3, program_0)
    program_5 = get_output_options(program_3, program_1)
    program_3.output_options = ['OUT_REQ_HEAD']
    program_6 = get_output_options(program_3, program_0)
    assert program_4 == (True, True)
   

# Generated at 2022-06-25 18:27:03.752947
# Unit test for function main
def test_main():
    raw_args_0 = ['http', '--debug']
    var_0 = main(raw_args_0)


# Generated at 2022-06-25 18:27:11.072629
# Unit test for function main
def test_main():
    environment_0 = Environment()
    arg_0 = ['httpie', '/path?foo=bar&abc=xyz', '--form', 'abc=123', 'def=456']
    var_0 = main(arg_0, environment_0)


# Generated at 2022-06-25 18:27:17.029161
# Unit test for function program
def test_program():
    # Case 1
    args = argparse.Namespace()
    args.output_options = None
    env = Environment()
    var_1 = program(args, env)
    assert var_1 == ExitStatus.SUCCESS
    # Case 2
    args = argparse.Namespace()
    args.output_options = None
    env = Environment()
    var_1 = program(args, env)
    assert var_1 == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:27:28.380453
# Unit test for function program
def test_program():
    from httpie.cli.argtypes import KeyValueArgType, KeyValueType
    from httpie.cli.parser import parser
    from httpie.config import Environment
    from httpie.downloads import Downloader
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPAuthFromNetrc
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins import builtin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie import status
    environment_0 = Environment()
    def request_body_read_callback_0(chunk):
        assert type(chunk) is bytes
        assert chunk

# Generated at 2022-06-25 18:27:38.307929
# Unit test for function program
def test_program():
    from httpie.cli.parser import parser
    from httpie.compat import is_windows
    import os
    import sys
    import json
    print('Running %s with arguments %r on Python %r' % (program.__name__, sys.argv, sys.version))
 
    # Prepare a mock file
    input_path = os.path.join(os.path.dirname(__file__), 'input.json')
    mock_path = os.path.join(os.path.dirname(__file__), 'mock.json')
    with open(input_path, 'r') as f:
        for i in range(4):
            line = f.readline()
        with open(mock_path, 'w') as mock:
            mock.write(line)

    # Run program
    http_

# Generated at 2022-06-25 18:27:39.658472
# Unit test for function main
def test_main():
    environment_0 = Environment()
    var_0 = main(environment_0)


# Generated at 2022-06-25 18:27:41.173232
# Unit test for function program
def test_program():
    program(argparse.Namespace(), module_0.Environment())


# Generated at 2022-06-25 18:27:48.636498
# Unit test for function program
def test_program():
    import httpie.cli.definition as module_0
    import httpie.plugins.builtin as module_1
    import httpie.output.streams as module_2
    import httpie.plugins.registry as module_3
    import httpie.plugins.manager as module_4
    import httpie.plugins.builtin as module_5
    import httpie.plugins.builtin as module_6
    import httpie.plugins.builtin as module_7
    import httpie.plugins.builtin as module_8
    import httpie.plugins.builtin as module_9
    import httpie.plugins.builtin as module_10
    import httpie.plugins.builtin as module_11
    import httpie.plugins.builtin as module_12
    import httpie.plugins.builtin as module_13

# Generated at 2022-06-25 18:28:41.830410
# Unit test for function program
def test_program():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.constants import OUT_BODY, OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.cli.definition import Argument, parser
    from httpie.output.writer import MESSAGE_SEPARATOR_BYTES
    import io
    import requests

    # Piping stdout to a file-like object makes it possible to capture the output
    # and inspect it. This is especially useful since the output is generally
    # printed to a terminal, which makes it difficult to inspect.
    mock_stdout = io.BytesIO()

    args = [Argument('url', type=KeyValueArg()), Argument('--output-options', action='store')]

# Generated at 2022-06-25 18:28:42.820260
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 18:28:46.914424
# Unit test for function program
def test_program():
    args = parser.parse_args('--download test.html http://httpbin.org/get'.split(), env=Environment())
    program(args, env=Environment())


# Generated at 2022-06-25 18:28:47.701667
# Unit test for function program
def test_program():
    assert program


# Generated at 2022-06-25 18:28:58.045194
# Unit test for function main
def test_main():
    class Env:
        def __init__(self):
            self.stdin_encoding = 'UTF8'
            self.stdout = sys.stdout
            self.stderr = sys.stderr
            self.config = None

    class Config:
        def __init__(self):
            self.default_options = None
            self.directory = None

    class Stdout:
        def write(self, *args, **kwargs):
            pass


# Generated at 2022-06-25 18:29:06.388495
# Unit test for function program
def test_program():
    import argparse
    # Arrange
    args = argparse.Namespace()
    args.format = 'json'
    args.output_file = None
    args.output_file_specified = False
    args.output_options = ['all']
    args.download = False
    args.check_status = False
    args.follow = True
    args.download_resume = 0
    args.headers = None
    args.verbose = 0
    args.quiet = False
    args.output = None
    args.style = 'default'
    args.style_sheet = None
    args.prettify = False
    args.stream = True
    args.verify = True
    args.verify_ssl_certificates = False
    args.ca_bundle = None
    args.ignore_netrc = False
   

# Generated at 2022-06-25 18:29:16.976669
# Unit test for function program
def test_program():
    assert get_output_options[requests.PreparedRequest] == (False, False)
    assert get_output_options[requests.Response] == (True, True)
    assert http_status_to_exit_status(201, True) == ExitStatus.SUCCESS
    assert http_status_to_exit_status(201, False) == ExitStatus.SUCCESS
    assert http_status_to_exit_status(300, True) == ExitStatus.ERROR
    assert http_status_to_exit_status(301, False) == ExitStatus.ERROR
    assert http_status_to_exit_status(302, False) == ExitStatus.ERROR
    assert http_status_to_exit_status(303, False) == ExitStatus.ERROR
    assert http_status_to_exit_status(304, False) == ExitStatus.ERROR

# Generated at 2022-06-25 18:29:28.992641
# Unit test for function main
def test_main():
    exit_status_1 = main(['httpie', '--debug'])
    exit_status_2 = main(['httpie', '--version'])
    exit_status_3 = main(['httpie', '--help'])
    exit_status_4 = main(['httpie', '-'])
    exit_status_5 = main(['httpie', 'GET', 'http://example.com'])
    exit_status_6 = main(['httpie', 'https://httpbin.org/post', '-d', 'name=Goutham'])
    exit_status_7 = main(['httpie', 'https://en.wikipedia.org/wiki/HTTP'])
    exit_status_8 = main(['httpie', 'http://example.com', 'Accept:text/plain'])

# Generated at 2022-06-25 18:29:41.414877
# Unit test for function program
def test_program():
    class DummyArgs:
        def __init__(self, arg_list):
            self.headers = arg_list[0]
            self.output_options = arg_list[1]
            self.download = arg_list[2]
            self.input_file = arg_list[3]
            self.output_file = arg_list[4]
            self.max_redirects = arg_list[5]
            self.timeout = arg_list[6]
            self.check_status = arg_list[7]
            self.quiet = arg_list[8]
            self.follow = arg_list[9]
            self.method = arg_list[10]
            self.output_file_specified = arg_list[11]
            self.download_resume = arg_list[12]


# Generated at 2022-06-25 18:29:49.776737
# Unit test for function program
def test_program():
    env = Environment()

# Generated at 2022-06-25 18:32:02.277424
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser()
    parser.parse_args(['http', 'www.google.com'])
    parser.add_argument('--check-status', action='store_true')
    parser.add_argument('--download', action='store_true')
    parser.add_argument('--download-resume', action='store_true')
    parser.add_argument('--output-file')
    parser.add_argument('--output-file-specified', action='store_true')
    parser.add_argument('--quiet', action='store_true')
    parser.add_argument('--follow', action='store_true')
    parser.add_argument('--output-options')
    parser.add_argument('--headers')
    args = parser.parse_args(['http', 'www.google.com'])


# Generated at 2022-06-25 18:32:07.257840
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    env = Environment()
    test_case_0()
    test_case_1()

# This part is used to test program with some simple test cases,
# you should add some test here to ensure the correctness of your program.
# We can use command "make test" to run test cases.

# Generated at 2022-06-25 18:32:09.008214
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

    parser = parser
    args = parser.parse_args()



# Generated at 2022-06-25 18:32:14.940604
# Unit test for function program
def test_program():
    # TODO: Flaky test: times out for some tests
    # TODO: This test currently only tests the function itself
    # TODO: and not if it correctly sets the exit status.
    try:
        # TODO: Make tests more complete.
        env = Environment()
        args = ['-v', 'get', 'https://httpbin.org/get', 'Accept:application/json']
        exit_status = program(argv=args, env=env)
        assert exit_status == ExitStatus.SUCCESS, f'unexpected exit_status={exit_status}'
        # TODO: Verify also the output.
    except Exception as e:
        assert False, f'unexpected test failure {e!r}'



# Generated at 2022-06-25 18:32:23.527979
# Unit test for function program
def test_program():
    from httpie import __version__ as httpie_version
    from httpie.cli.dicts import DEFAULT_OPTIONS
    from httpie.cli.parser import parser
    import six
    import sys
    import random
    # Generate random user-agent & method

# Generated at 2022-06-25 18:32:28.028005
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit as e:
        assert e.code == ExitStatus.SUCCESS
    except Exception as e:
        print('Caught an exception: ' + repr(e))
        assert False

if __name__ == "__main__":
    # Unit tests for this module
    test_main()

# Generated at 2022-06-25 18:32:38.808150
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.config_dir = None
    args.config_file = None
    args.debug = None
    args.download = False
    args.download_resume = False
    args.follow = False
    args.help = False
    args.ignore_stdin = False
    args.max_redirects = 30
    args.output_file = open("test_program.txt", 'w')
    args.output_file_specified = False
    args.output_options = []
    args.output_options_specified = False
    args.print_options = None
    args.quiet = False
    args.session = None
    args.session_read_only = False
    args.style = None
    args.style_error = None
    args.style_error_specified = False
   

# Generated at 2022-06-25 18:32:48.303099
# Unit test for function program
def test_program():
    def check_status(self, status_code):
        self.status_code = status_code
        return self

    class output_indent:
        @staticmethod
        def get(self):
            return True

    class output_streaming:
        @staticmethod
        def get(self):
            return False

    class output_options:
        @staticmethod
        def __contains__(self, arg):
            if arg == '--stream':
                return True
            elif arg == '--pretty':
                return True
            elif arg == '--download':
                return True
            elif arg == '--json':
                return True

    class args_class:
        url = None
        output_file = None
        output_file_specified = None
        output_file_level = None
        output_options = output_

# Generated at 2022-06-25 18:32:54.333972
# Unit test for function program
def test_program():
    class EnvMock(object):
        def __init__(self):
            self.stdout = StringIO()
            self.stderr = StringIO()
            self.config = Configuration()
            self.config.default_options = None
            self.config.directory = None
            self.log_error = self.stderr.write
            self.stdout_isatty = True

    class MessageMock(object):
        def __init__(self, is_request, with_body=False):
            self.is_request = is_request
            self.with_body = with_body

        def is_body_upload_chunk(self):
            return self.with_body

        def body(self):
            return 'test body' if self.with_body else ''

        def headers(self):
            return None

# Generated at 2022-06-25 18:33:03.378721
# Unit test for function main