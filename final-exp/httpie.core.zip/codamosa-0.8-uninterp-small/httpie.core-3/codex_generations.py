

# Generated at 2022-06-25 18:27:09.488212
# Unit test for function main
def test_main():
    assert main(args=['http', '--debug']) == ExitStatus.SUCCESS
    assert main(args=['http', '--traceback']) == ExitStatus.ERROR
    assert main(args=['http', '--timeout', '0.1', '--max-redirects=0', 'http://127.0.0.1:0']) == ExitStatus.ERROR_TIMEOUT
    assert main(args=['http', '--max-redirects=0', '--follow', 'http://httpbin.org/redirect/2']) == ExitStatus.ERROR_TOO_MANY_REDIRECTS


# Generated at 2022-06-25 18:27:18.598899
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-file')
    parser.add_argument('--download')
    parser.add_argument('--download-resume')
    parser.add_argument('--output-options', nargs='*')
    parser.add_argument('--check-status')
    parser.add_argument('--follow')
    parser.add_argument('--quiet')
    args = parser.parse_args(args = ['--output-file=None', '--download', '--download-resume=False',
                        '--output-options=OUT_REQ_BODY', 'OUT_RESP_BODY', '--check-status',
                        '--follow', '--quiet'])
    env = Environment()
    program(args, env)
    assert exit_status == ExitStatus

# Generated at 2022-06-25 18:27:29.904089
# Unit test for function main
def test_main():
    from httpie.compat import is_windows
    if is_windows:
        # noinspection PyUnresolvedReferences
        import msvcrt
        msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
        msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)
        msvcrt.setmode(sys.stderr.fileno(), os.O_BINARY)
    main(['http', '--version'])
    main(['http', '--debug'])
    main(['http', '--debug', '127.0.0.1:80'])
    main(['http', '--traceback', '127.0.0.1:80'])

# Generated at 2022-06-25 18:27:33.328009
# Unit test for function main
def test_main():
    # Test case main
    # Function main, normal case, default values for arguments
    args = []
    env = Environment()
    exit_status_0 = main(args, env)
    assert (exit_status_0 == ExitStatus.SUCCESS)



# Generated at 2022-06-25 18:27:44.142298
# Unit test for function program
def test_program():
    from httpie import config
    from httpie.cli.definition import parser
    from httpie.cli.context import CONTEXT_SETTINGS

    args = parser.parse_args(
        args=['--debug'],
        env=config.Environment(stdin=io.BytesIO(), stdout=io.BytesIO(),
                               stdin_isatty=False, stdout_isatty=False, vc_dir=None),
    )
    program(args=args, env=config.Environment(stdin=io.BytesIO(), stdout=io.BytesIO(),
                                              stdin_isatty=False, stdout_isatty=False, vc_dir=None))


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:27:50.664395
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser()
    parser.add_argument('--headers', default = None)
    parser.add_argument('--output-options', default = ['--form'])
    parser.add_argument('--output-file-specified', default = False)
    parser.add_argument('--follow', default = False)
    parser.add_argument('--output-file', default= 'output.txt')
    parser.add_argument('--check-status', default = False)
    parser.add_argument('--quiet', default = False)
    parser.add_argument('--download', default = False)
    parser.add_argument('--download-resume', default = False)
    args = parser.parse_args()
    env = Environment()
    program(args, env)


# Generated at 2022-06-25 18:27:56.545034
# Unit test for function program
def test_program():
    args = ['https://httpbin.org']
    env = Environment()
    program(args=args, env=env)
    # check if the env variable is set with the expected values
    assert env.stdin_encoding == 'utf-8'
    assert env.stdout_encoding == 'utf-8'
    assert env.stderr_encoding == 'utf-8'


# Generated at 2022-06-25 18:27:59.059105
# Unit test for function program
def test_program():
    from unittest.mock import Mock
    env = Mock()
    args = Mock()
    messages = Mock()
    assert(program(args, env))


# Generated at 2022-06-25 18:28:09.739783
# Unit test for function main
def test_main():

    # Case 0: unit test (no coverage)
    test_case_0()

    # Case 1:
    # http --help | grep httpie
    # http --version | grep httpie
    # http --headers
    # http --json
    # http --pretty
    # http --body
    # http --download
    # http --form
    # http --output
    # http --session
    # http --auth
    # http --verify
    # http --debug
    # http --traceback
    # `http 'httpbin.org/user-agent'` | grep HTTPie
    # `http --style Solarized 'httpbin.org/user-agent'` | grep HTTPie
    # `http GET 'httpbin.org/user-agent'` | grep HTTPie
    # `http 'httpbin.org/get?key=

# Generated at 2022-06-25 18:28:11.440596
# Unit test for function program
def test_program():
    import subprocess
    exit_status = subprocess.call('http get github.com', shell=True)
    assert exit_status == 0

# unit test for function main

# Generated at 2022-06-25 18:28:53.614340
# Unit test for function program
def test_program():
    import shlex
    import io
    import contextlib
    from httpie.cli.constants import DEFAULT_ENCODING
    env = Environment()
    env.config = lambda: None
    env.config.directory = 'httpie'
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdout_isatty = False
    env.stdout_encoding = DEFAULT_ENCODING
    args = shlex.split("GET http://api.github.com/repos/jakubroztocil/httpie")
    args = argparse.Namespace(args)
    args.config_dir = env.config.directory
    args.config_dir_specified = False
    args.json = None
    args.output_file = None
    args.output

# Generated at 2022-06-25 18:29:00.310833
# Unit test for function program
def test_program():
    args = argparse.Namespace(
        check_status = True,
        follow = True,
        headers = ['cookies: b="b cookies"; a="a cookies"'],
        method = 'GET',
        output_options = ['BODY'],
        timeout = 30,
        url = 'http://httpbin.org/cookies',
        verify = True)
    env = Environment()

    exit_status = program(args=args, env=env)
    assert exit_status == 0

# Generated at 2022-06-25 18:29:01.890238
# Unit test for function program
def test_program():
    # Python 3.5
    #assert program([]) == 1
    test_case_0()

# Generated at 2022-06-25 18:29:05.308151
# Unit test for function program
def test_program():
    env0 = Environment()
    args0 = parser.parse_args(['https://httpbin.org/post', 'abc=123'], env0)
    exit_status_0 = program(args=args0, env=env0)
    assert exit_status_0 == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:29:12.438783
# Unit test for function main
def test_main():
    import urllib.request

    import pytest
    import requests

    # Test CLI in isolation.
    # These tests should always run successfully,
    # regardless of the user’s environment/configuration/dependencies,
    # and regardless of how the httpie package itself is installed.
    # Conversely, for every test there should be a way
    # to reproduce its failure by running the CLI manually.
    from httpie import __main__ as httpie_main
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.config import DEFAULT_CONFIG_DIR, Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager

    env = Environment(config_dir=DEFAULT_CONFIG_DIR)
    plugin_manager = PluginManager()


# Generated at 2022-06-25 18:29:13.724216
# Unit test for function program
def test_program():
    program(args=['https://google.com'], env=Environment())


# Generated at 2022-06-25 18:29:15.576965
# Unit test for function program
def test_program():
    result = program(OUT_REQ_HEAD, OUT_REQ_BODY)
    assert result is ExitStatus.SUCCESS

# Generated at 2022-06-25 18:29:16.394852
# Unit test for function main
def test_main():
    main(args=[])



# Generated at 2022-06-25 18:29:25.443606
# Unit test for function program
def test_program():
    import sys
    import tempfile
    tmp_file = tempfile.mktemp()
    print(tmp_file)
    args = ['http', '--output', tmp_file, 'www.google.com']
    program(args=args, env=Environment(program_name='http'))
    with open(tmp_file, 'r') as f:
        file_content = f.read()
    print(file_content)


# Generated at 2022-06-25 18:29:26.640971
# Unit test for function main
def test_main():
    assert main(sys.argv) == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:33:59.968262
# Unit test for function main
def test_main():
    import sys
    import os
    import contextlib
    from io import StringIO
    from unittest.mock import patch

    # Capture the output to stdout
    capturedOutput = StringIO() 
    sys.stdout = capturedOutput

    # Capture the output to stderr
    capturedError = StringIO()
    sys.stderr = capturedError

    # Construct arguments
    args = ["httpie.py", "--version"]

    # Call the function
    main(args)

    # Reset redirects
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__

    # Assert that the output to stdout is as expected
    assert capturedOutput.getvalue() == 'HTTPie 0.9.9\n'



# Generated at 2022-06-25 18:34:02.263353
# Unit test for function program
def test_program():
    exit_status = program(['--follow', '--timeout', '20', 'http://www.google.com'], env=Environment())
    assert exit_status == 0

# Generated at 2022-06-25 18:34:04.972223
# Unit test for function program
def test_program():
    env = Environment()
    args = program(argparse.Namespace(),env)
    assert args == 0


# Generated at 2022-06-25 18:34:13.873473
# Unit test for function program
def test_program():
    import tempfile
    # env = Environment()
    # env.stdout = tempfile.TemporaryFile(mode='w+b')
    # env.stderr = tempfile.TemporaryFile(mode='w+b')
    # env.config.default_options = ["-j", "--pretty=all"]
    # parser = argparse.ArgumentParser()
    # parser.add_argument('--json')
    # parser.add_argument('--pretty')
    # args = parser.parse_args()
    # program(args, env)
    # env.stdout.seek(0)
    # print(env.stdout.read())
    # env.stderr.seek(0)
    # print(env.stderr.read())



# Generated at 2022-06-25 18:34:22.893084
# Unit test for function program
def test_program():
    import argparse

    class StringContaining(str):
        def __eq__(self, other):
            return self in other
    class StringStartingWith(str):
        def __eq__(self, other):
            return other.startswith(self)
    
    args = argparse.Namespace()
    
    args.headers = None
    args.download = False
    args.download_resume = False
    args.output_file = None
    args.output_file_specified = False
    args.output_options = {'colors', 'format', 'headers', 'body', 'verbose'}
    args.check_status = False
    args.follow = True
    args.timeout = 30
    args.max_redirects = 10
    args.max_headers = None

# Generated at 2022-06-25 18:34:26.108110
# Unit test for function program
def test_program():
    args = ['-p data.txt https://localhost/', 'data=hello']
    env = Environment()
    exit_status = main(args, env)
    assert exit_status == ExitStatus.SUCCESS
    assert not env.stdout.closed


# Generated at 2022-06-25 18:34:30.518895
# Unit test for function main
def test_main():
    args = ['httpie', '--debug']
    try:
        main(args)
        assert True
    except SystemExit as e:
        assert e.code == ExitStatus.SUCCESS
        assert True
    except:
        assert False
    else:
        assert False

# Empty test to make PyFlakes happy.

# Generated at 2022-06-25 18:34:39.107010
# Unit test for function main
def test_main():
    try:
        import pytest
    except ImportError:
        print("Error: pytest is not installed")
        sys.exit(1)

    try:
        import hypothesis
    except ImportError:
        print("Error: hypothesis is not installed")
        sys.exit(1)

    import hypothesis.strategies as st
    import hypothesis.extra.pytestplugin

    hypothesis.extra.pytestplugin.pytest_runtest_call(None)

    @st.composite
    def pytest_call(draw):
        return draw(st.lists(elements=st.integers() | st.text(max_size=100),
                             min_size=0,
                             max_size=100))

    pytest_call()

# Generated at 2022-06-25 18:34:45.432700
# Unit test for function main
def test_main():
    assert main(["/Users/fivesheep/Desktop/backup/Github/httpie/http.py"]) == ExitStatus.SUCCESS
    # assert main(["/Users/fivesheep/Desktop/backup/Github/httpie/http.py", "--version"]) == ExitStatus.SUCCESS
    assert main(["/Users/fivesheep/Desktop/backup/Github/httpie/http.py", "--debug"]) == ExitStatus.SUCCESS
    assert main(["/Users/fivesheep/Desktop/backup/Github/httpie/http.py", "GET", "http://httpbin.org"]) == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:34:53.348737
# Unit test for function program
def test_program():
    exit_status = program(args=[],env=Environment())
    assert exit_status == ExitStatus.SUCCESS and exit_status == 0
    exit_status = program(args=['--help'], env=Environment())
    assert exit_status == ExitStatus.SUCCESS and exit_status == 0
    exit_status = program(args=['-h'], env=Environment())
    assert exit_status == ExitStatus.SUCCESS and exit_status == 0
    exit_status = program(args=['-v'], env=Environment())
    assert exit_status == ExitStatus.SUCCESS and exit_status == 0
    exit_status = program(args=['--version'], env=Environment())
    assert exit_status == ExitStatus.SUCCESS and exit_status == 0