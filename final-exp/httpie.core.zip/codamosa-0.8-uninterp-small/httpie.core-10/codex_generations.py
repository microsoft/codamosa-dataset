

# Generated at 2022-06-25 18:26:42.744926
# Unit test for function program
def test_program():
    args = parser.parse_args_test([
        'https://gist.github.com/dawsonbotsford/4074541'
    ])
    program(args=args, env=Environment())


# Generated at 2022-06-25 18:26:48.266089
# Unit test for function program
def test_program():
    # Testcase 0
    try:
        program(['--check-status'],Environment())
    except SystemExit:
        pass
    else:
        raise AssertionError("Expected SystemExit")

    # Testcase 1
    try:
        # --download-resume is only applicable with --download.
        program(['--download-resume'],Environment())
    except SystemExit:
        pass
    else:
        raise AssertionError("Expected SystemExit")



# Generated at 2022-06-25 18:26:52.249605
# Unit test for function program
def test_program():
    exit_status = program(args=['http'], env=None)
    print("exit_status = ", exit_status)

test_program()

# Generated at 2022-06-25 18:26:54.584206
# Unit test for function main
def test_main():
    # Test case 0
    test_case_0()

# Test if main() is called as a script
if __name__ == "__main__":
    main()

# Generated at 2022-06-25 18:26:56.453520
# Unit test for function program
def test_program():
    env=Environment()
    args=['wget.exe','git.exe','install.exe']
    program(args,env)


# Generated at 2022-06-25 18:27:02.937113
# Unit test for function program
def test_program():
    import argparse
    import os
    import random
    import shutil
    import requests
    from httpie.status import ExitStatus
    from httpie.output.writer import write_message, write_stream
    from httpie.cli.constants import OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.client import collect_messages

    req = requests.PreparedRequest()
    req.url = 'https://httpbin.org/get'
    req.method = 'GET'
    resp = requests.Response()
    resp.status_code = 200
    args = argparse.Namespace()
    env = Environment()
    downloader = Downloader(output_file=None, progress_file=None, resume=False)

# Generated at 2022-06-25 18:27:14.129341
# Unit test for function program
def test_program():
    from httpie.cli import main
    from httpie.cli.definition import parser
    from httpie.context import Environment
    header = {
        "Accept": "image/gif, image/jpeg, */*",
        "Accept-Language": "zh-cn",
        "Referer": "http://www.google.com/",
        "Accept-Encoding": "gzip, deflate",
        "User-Agent": "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)",
        "Host": "www.google.com",
        "If-Modified-Since": "Sat, 18 Mar 2017 13:39:53 GMT"
    }
    args = parser.parse_args(['http://httpbin.org/headers', '-H ' + str(header)])
    exit_

# Generated at 2022-06-25 18:27:23.118620
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check-status', default=False)
    parser.add_argument('--download', default=False)
    parser.add_argument('--follow', default=False)
    parser.add_argument('--output-options', default='')
    parser.add_argument('--quiet', default=False)

    args0 = parser.parse_args(args=[])
    # args0.output_options = ['a', 'b']
    env0 = Environment()

    exit_status_0 = program(args0, env0)
    assert exit_status_0 == ExitStatus.SUCCESS



# Generated at 2022-06-25 18:27:33.208743
# Unit test for function program

# Generated at 2022-06-25 18:27:36.916319
# Unit test for function main
def test_main():
    import unittest
    from httpie.cli.constants import DEFAULT_SERVER


# Generated at 2022-06-25 18:28:03.677288
# Unit test for function main
def test_main():
    exit_status = main(args=[])
    assert exit_status == ExitStatus.ERROR


# Generated at 2022-06-25 18:28:11.871804
# Unit test for function program
def test_program():
    import io
    from tempfile import TemporaryDirectory
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from requests.utils import requote_uri
    from httpie.cli.definition import parser
    env = Environment()
    arg_string = [
        'http',
        'https://httpbin.org/redirect-to?url=http://httpbin.org/get',
        '--max-redirects=2',
        '--output-file',
        'output.txt'
    ]
    args = parser.parse_args(args=arg_string, env=env)
    env.stdout = io.BytesIO()
    env.stderr = io.BytesIO()
    env.config.directory = TemporaryDirectory()

# Generated at 2022-06-25 18:28:23.561720
# Unit test for function main
def test_main():
    # 1.
    args = ['httpie', 'https://httpbin.org/get', '-h', 'User-Agent:Mozilla/5.0']
    env = Environment()
    return_value = main(args, env)
    assert(return_value == ExitStatus.SUCCESS)

    # 2.
    args = ['httpie', 'https://httpbin.org/get', '-h', 'User-Agent:Mozilla/5.0']
    env = Environment(stdin_file=None)
    return_value = main(args, env)
    assert (return_value == ExitStatus.SUCCESS)

    # 3.
    args = ['httpie', 'https://httpbin.org/get', '-h', 'User-Agent:Mozilla/5.0']

# Generated at 2022-06-25 18:28:24.488978
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-25 18:28:30.437978
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.follow = True
    args.headers = []
    args.output_file = None
    args.output_file_specified = False
    args.output_options = ['body']
    args.quiet = False
    args.check_status = False
    args.download = False
    args.download_resume = False
    env = Environment()
    exit_status = program(args, env)
    assert exit_status.value == 0


# Generated at 2022-06-25 18:28:31.582699
# Unit test for function program
def test_program():
    program(["https://httpbin.org/get"], Environment())


# Generated at 2022-06-25 18:28:33.107304
# Unit test for function program
def test_program():
    program("1234")

if __name__ == '__main__':
    program("1234")

# Generated at 2022-06-25 18:28:35.194753
# Unit test for function main
def test_main():
    sys.argv = ['http', 'https://httpbin.org/get']
    test_case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:28:38.159023
# Unit test for function program
def test_program():
    """
    Test for function program
    """
    # This is the target program to run
    return_value = program([], [])
    # This is the expected returned value
    assert return_value == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 18:28:47.661333
# Unit test for function program
def test_program():
    os.environ["HTTPIE_ENV"] = 'TEST'
    env = Environment()
    args = argparse.Namespace()
    args.follow = True
    args.output_options = ['b']
    args.output_file = None
    args.output_file_specified = False
    args.headers = None
    args.download = False
    args.download_resume = False
    args.check_status = False
    args.quiet = False
    exit_status_1 = program(args=args, env=env)
    assert exit_status_1 == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:29:38.517725
# Unit test for function main
def test_main():
    assert main(['http', 'http://httpbin.org/']) == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:29:39.512350
# Unit test for function main
def test_main():

    exit_status_0 = main(['--debug'])

# Generated at 2022-06-25 18:29:40.828511
# Unit test for function main
def test_main():
    test_case_0()

# Compiled version of test_main

# Generated at 2022-06-25 18:29:43.082756
# Unit test for function main
def test_main():
    from httpie.cli import exit_statuses
    assert main(args=['http', 'www.example.com']) is exit_statuses.SUCCESS


# Generated at 2022-06-25 18:29:46.280505
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS



# Generated at 2022-06-25 18:29:52.917314
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.headers = False
    args.output_options = [OUT_RESP_HEAD]
    args.follow = False
    args.download = False
    args.download_resume = True
    args.output_file = None
    args.output_file_specified = False
    args.check_status = True
    args.quiet = False
    env = Environment()
    program(args, env)


# Generated at 2022-06-25 18:30:01.003172
# Unit test for function main
def test_main():
    # Calling function main
    # main()
    main(['http'])
    main(['http', '--download'])
    main(['http', '--download', '-O'])
    main(['http', '--download', '-o'])
    main(['http', '--download', '--output'])
    main(['http', '--download', '--output-file'])
    main(['http', '--download', '--output', '-'])
    main(['http', '--download', '--output-file', '-'])
    main(['http', '--download', '-o', 'httpie-download.bin'])
    main(['http', '--download', '--output', 'httpie-download.bin'])

# Generated at 2022-06-25 18:30:07.925302
# Unit test for function program
def test_program():
    # No arguments
    args = argparse.Namespace()
    env = Environment()
    program(args, env)
    # Input arguments
    args.headers = ['foo: bar']
    args.output_options = [OUT_RESP_BODY]
    args.method = 'POST'
    args.ignore_stdin = False
    args.follow = True
    args.max_redirects = 5
    args.check_status = False
    args.json = True
    args.output_file_flags = 'w'
    args.output_file = 'test.txt'
    program(args, env)
    # Env arguments
    env.config.default_options = ['foo: bar']
    env.config.verbose = False
    env.config.directory = 'test'
    program(args, env)


# Generated at 2022-06-25 18:30:15.532069
# Unit test for function program
def test_program():
    args = Namespace(check_status=True, download=False, download_resume=True, follow=True, headers=[':method GET', ':scheme https'],
                     max_redirects=10, output_file_specified=False, output_file=None, output_options=[], output_style='colour',
                     quiet=False, timeout=10, traceback=False, verbose=False, verify=True)
    env = Environment()

# Generated at 2022-06-25 18:30:20.061225
# Unit test for function main
def test_main():
    main(['http', 'https://api.github.com/', 'Accept: application/vnd.github.v3+json', 'User-Agent: httpie'])


if __name__ == '__main__':
    # CLI entrypoint.
    sys.exit(main())

# Generated at 2022-06-25 18:32:39.632344
# Unit test for function main
def test_main():
    env = Environment()
    env.stdin_encoding = 'ascii'
    exit_status_0 = main(['--traceback'], env)
    assert exit_status_0 == ExitStatus.ERROR


# Generated at 2022-06-25 18:32:48.981287
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.config import ParserConfig
    from os.path import join, dirname
    from requests.auth import HTTPDigestAuth
    from urllib.parse import urlparse


# Generated at 2022-06-25 18:32:54.652227
# Unit test for function program
def test_program():
    args = ["http://httpbin.org/get","--timeout=10s","-v","--output=httpbin","--output-format=json","--output-options=b,h","--headers=Content-Type: application/json,X-Custom: 1","--body=message","--form","--form-string=key","--output-file=httpbin","--download","--download-output-prefix=1 2","--download-output-directory=./","--download-output-filename","--download-output-suffix=.csv","--download-log-file=download.log","--download-progress-file=/tmp/download_percentage.txt","--download-resume"]
    env = Environment()
    program(args,env)


# Generated at 2022-06-25 18:32:56.443351
# Unit test for function program
def test_program():
    program()


if __name__ == '__main__':
    main()
    # test_program()

# Generated at 2022-06-25 18:33:00.147760
# Unit test for function main
def test_main():
    args = sys.argv
    env = Environment()
    exit_status = main(args=args, env=env)
    assert ExitStatus.SUCCESS == exit_status



# Generated at 2022-06-25 18:33:01.865973
# Unit test for function main
def test_main():
    # Case 0: no args, no input
    global exit_status_0

    assert exit_status_0 == ExitStatus.SUCCESS


# Generated at 2022-06-25 18:33:08.795914
# Unit test for function program
def test_program():
    import unittest
    import requests
    import os
    import tempfile
    import shutil

    class Test_program(unittest.TestCase):
        def setUp(self):
            self._temp_dir = tempfile.mkdtemp()
            self._temp_download = tempfile.NamedTemporaryFile()
            self._temp_download_name = self._temp_download.name
            self._temp_download_path = os.path.join(self._temp_dir, self._temp_download_name)
            self._temp_download.close()

        def tearDown(self):
            shutil.rmtree(self._temp_dir, ignore_errors=True)

        def test_program_get_request(self):
            from httpie.cli.parser import parse_args

# Generated at 2022-06-25 18:33:09.638158
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 18:33:10.590790
# Unit test for function program
def test_program():
    assert program(None, None) == ExitStatus.SUCCESS

# Generated at 2022-06-25 18:33:13.913681
# Unit test for function program
def test_program():
    from httpie import cli

    parser = getattr(cli, 'parser')
    args = parser.parse_args(args=[])

    exit_status_0 = main()
    assert exit_status_0 == 0
