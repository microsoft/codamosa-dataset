

# Generated at 2022-06-23 19:08:57.605793
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = ['-b', '-h']

    request = requests.PreparedRequest()
    headers, body = get_output_options(args, request)
    assert headers
    assert body

    response = requests.Response()
    headers, body = get_output_options(args, response)
    assert headers
    assert body

# Generated at 2022-06-23 19:09:03.850082
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = []
    args.body_output_options = []
    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (True, False)

    args.output_options = ['all']
    assert get_output_options(args, message) == (True, True)

    args.output_options = ['none']
    assert get_output_options(args, message) == (False, False)

    args.output_options = ['h', 'H', 'b', 'B']
    assert get_output_options(args, message) == (True, False)

    args.output_options = ['h', 'H', 'b', 'B', 'all', 'b']

# Generated at 2022-06-23 19:09:05.788731
# Unit test for function program
def test_program():
    main(["http", "GET", "http://localhost:5000/question"])

# Generated at 2022-06-23 19:09:07.841728
# Unit test for function print_debug_info
def test_print_debug_info():
    env = {}
    env['stderr'] = "HTTPie 1.0.3\nRequests 2.24.0\nPygments 2.7.2\nPython 3.7.7\nenv\n\n\{output\}"
    assert print_debug_info(env) == env['stderr']

# Generated at 2022-06-23 19:09:16.624923
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr.buffer = io.BytesIO()
    print_debug_info(env)
    s = env.stderr.buffer.getvalue()
    # print(s)
    assert s.startswith(b'HTTPie ')
    assert b'\n\n' in s
    assert b'.config.directory' in s
    assert b'.stdin' in s
    assert b'.stdout' in s
    assert b'.stderr' in s
    assert b'.stdin_isatty' in s
    assert b'.stdout_isatty' in s
    assert b'.stderr_isatty' in s
    assert b'\n\n' in s
    assert b'\n' in s



# Generated at 2022-06-23 19:09:22.349237
# Unit test for function decode_raw_args
def test_decode_raw_args():
    """
    Test function decode_raw_args
    """
    content = ("--form a=Ä" + '\xff').encode('latin-1')
    args = decode_raw_args([content], 'latin-1')
    assert args[0] == content.decode('latin-1')

# Generated at 2022-06-23 19:09:24.910762
# Unit test for function program
def test_program():
    from httpie import __main__ as httpie_main
    # TODO: Refactor/simplify this function so I can test it.

# Generated at 2022-06-23 19:09:34.217423
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    # test response headers
    args.output_options = ['all']
    msg = requests.Response()
    with_headers, with_body = get_output_options(args=args, message=msg)
    assert with_headers
    assert with_body

    # test response body
    args.output_options = ['body']
    msg = requests.Response()
    with_headers, with_body = get_output_options(args=args, message=msg)
    assert not with_headers
    assert with_body

    # test request headers
    args.output_options = ['headers']
    msg = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args=args, message=msg)
    assert with_headers
    assert not with_body

    #

# Generated at 2022-06-23 19:09:45.030623
# Unit test for function main
def test_main():
    from io import StringIO
    from unittest.mock import patch
    from httpie.cli import main
    import sys

    # Create test environment
    stdout = StringIO()
    stderr = StringIO()
    env = dict(
        stdout=stdout,
        stderr=stderr,
        stdout_isatty=False,
        stdin_encoding='utf8',
        program_name='http',
        default_options=[],
    )

    # Get main function
    with patch('httpie.cli.main', autospec=True) as mock_main:
        with patch.object(sys, 'exit'):
            with patch.object(sys, 'argv', ['http', 'example.com']):
                main(env=env)
    # Check assertions

# Generated at 2022-06-23 19:09:51.250880
# Unit test for function main
def test_main():
    import tempfile
    os.environ['HTTPS_PROXY'] = 'https://127.0.0.1:3128'
    os.environ['HTTP_PROXY'] = 'http://127.0.0.1:3128'
    output_file = tempfile.NamedTemporaryFile()
    try:
        main(args=['--download', f'https://httpbin.org/bytes/100', '--output', output_file.name])
        with open(output_file.name, 'rb') as f:
            assert f.read() == b'\x00' * 100
    finally:
        output_file.close()

    output_file = tempfile.NamedTemporaryFile()

# Generated at 2022-06-23 19:09:57.552385
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[])
    message = requests.Response()

    # If the message is a request
    assert get_output_options(args, message) == (False, False)

    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY]
    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (True, True)

    # If the message is a response
    args.output_options = [OUT_RESP_HEAD, OUT_RESP_BODY]
    message = requests.Response()
    assert get_output_options(args, message) == (True, True)


# Generated at 2022-06-23 19:10:07.165054
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    f = io.StringIO()
    env = Environment()
    env.stderr = f
    print_debug_info(env)

# Generated at 2022-06-23 19:10:14.287135
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(
        stdin=io.BytesIO(),
        stdin_isatty=True,
        stdout=io.BytesIO(),
        stdout_isatty=True,
        stderr=io.BytesIO(),
        stderr_isatty=True,
        stdio_encoding='utf8'
    )
    print_debug_info(env)
    out = env.stderr.getvalue().decode('utf8')
    assert out.startswith('HTTPie ')

# Generated at 2022-06-23 19:10:18.424404
# Unit test for function program
def test_program():
    args = []
    env = Environment()
    assert program(args=args, env=env) == ExitStatus.SUCCESS


# Generated at 2022-06-23 19:10:21.401274
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['á', 'b'], 'utf-8') == ['á', 'b']

# Generated at 2022-06-23 19:10:28.981950
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.context import Environment
    from io import StringIO
    string = StringIO()
    env = Environment()
    env.stderr = string
    print_debug_info(env)
    string_value = string.getvalue()
    assert 'HTTPie ' in string_value
    assert 'Requests ' in string_value
    assert 'Pygments ' in string_value
    assert 'Python ' in string_value
    assert sys.executable in string_value
    assert platform.system() in string_value
    assert platform.release() in string_value
    assert repr(env) in string_value

# Generated at 2022-06-23 19:10:38.716047
# Unit test for function print_debug_info
def test_print_debug_info():
    from unittest.mock import patch
    from io import StringIO

    mock_stdout = StringIO()
    mock_stderr = StringIO()

    # noinspection PyPackageRequirements
    class MockEnvironment:
        def __init__(self):
            self.stdin_encoding = 'UTF-8'
            self.stdout = mock_stdout
            self.stderr = mock_stderr
            self.config = self
            self.log_level = 'error'

        @property
        def stdout_isatty(self):
            return False

        @staticmethod
        def log(*args, **kwargs):
            return

        @staticmethod
        def log_error(*args, **kwargs):
            return


# Generated at 2022-06-23 19:10:40.651928
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=['Hb'])
    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (True, True)
    message = requests.Response()
    assert get_ou

# Generated at 2022-06-23 19:10:45.688052
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'foo'], 'utf-8') == ['foo']
    assert decode_raw_args([bytes([0xff]), bytes([0xfe])], 'utf-8') == ['�', '�']
    assert decode_raw_args(['foo'], 'utf-8') == ['foo']

# Generated at 2022-06-23 19:10:48.422907
# Unit test for function main
def test_main():
    """
    Unit test for function main.
    """
    # TODO: Implement
    pass

# Generated at 2022-06-23 19:10:49.402752
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:10:57.797219
# Unit test for function get_output_options
def test_get_output_options():
    from argparse import Namespace
    args = Namespace()
    
    passed = True
    for key in [requests.PreparedRequest, requests.Response]:
        args.output_options = [key.__name__+'_HEAD']
        if get_output_options(args, key())[0] != True or get_output_options(args, key())[1] != False:
            passed = False
        args.output_options = [key.__name__+'_BODY']
        if get_output_options(args, key())[0] != False or get_output_options(args, key())[1] != True:
            passed = False
        args.output_options = [key.__name__+'_HEAD',key.__name__+'_BODY']

# Generated at 2022-06-23 19:10:59.909390
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'foo'], 'utf8') == ['foo']



# Generated at 2022-06-23 19:11:08.089163
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'foo', u'bar', 'baz'], 'utf8') == ['foo', 'bar', 'baz']
    assert decode_raw_args([b'f\xc3\xb6\xc3\xb6', u'bar', 'baz'], 'utf8') == ['föö', 'bar', 'baz']
    assert decode_raw_args([b'f\xc3\xb6\xc3\xb6', u'bar', 'baz'], 'ISO8859-1') == ['fÃ¶Ã¶', 'bar', 'baz']

# Generated at 2022-06-23 19:11:18.370289
# Unit test for function print_debug_info
def test_print_debug_info():
    class TestEnvironment(Environment):
        def __init__(self):
            super().__init__()
            self.stderr = io.StringIO()
            self.stdout = io.StringIO()
            self.stdin = io.StringIO()
            self.stdin_isatty = False
            self.stdout_isatty = False
            self.is_windows = False
            self.is_mac = False
            self.config = None
            self.headers = None
            self.ignore_stdin = False
            self.timeout = None
            self.max_redirects = None
            self.follow_redirects = False
            self.verify = True
            self.cert = None
            self.cert_key = None
            self.output_options = None
    e = TestEnvironment()
    print

# Generated at 2022-06-23 19:11:19.772453
# Unit test for function main
def test_main():
    sys.exit(main())

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 19:11:21.832976
# Unit test for function print_debug_info
def test_print_debug_info():
    """
    This unit test case check for
    the debug information printed
    on stdout at the end of program execution.

    """
    from httpie.core import main as httpie

# Assertion for the data printed on stdout
    assert httpie(["--debug"]) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:11:26.463484
# Unit test for function decode_raw_args
def test_decode_raw_args():
    """
    Test for function decode_raw_args
    """
    assert decode_raw_args(['test_test'], 'utf-8') == ['test_test']
    assert decode_raw_args([b'\xcd\xe5\xd2\xd1'], 'gbk') == ['中文']

# Generated at 2022-06-23 19:11:28.756751
# Unit test for function program
def test_program():
    env = Environment()
    exit_status = program(args='--version', env=env)
    assert env.stderr.getvalue().startswith('HTTPie')
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:11:35.738764
# Unit test for function get_output_options
def test_get_output_options():
    import argparse
    args = argparse.Namespace(output_options=set([OUT_RESP_HEAD]))
    message = requests.Response()
    message.headers = {
        'Content-Type': 'text/html'
    }
    with_headers, with_body = get_output_options(args=args, message=message)
    assert with_headers is True
    assert with_body is False

# Generated at 2022-06-23 19:11:47.470903
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()

    # below is the output of print_debug_info
    expected = 'HTTPie 1.0.2\nRequests 2.22.0\nPygments 2.4.2\nPython 2.7.12 (default, Nov 19 2016, 06:48:10) \n[GCC 5.4.0 20160609]\nLinux 4.4.0-59-generic\n\n'
    expected += '\n\n'

# Generated at 2022-06-23 19:11:55.308877
# Unit test for function get_output_options
def test_get_output_options():
    # Arrange
    args = {
        OUT_REQ_HEAD: False,
        OUT_REQ_BODY: False,
        OUT_RESP_HEAD: True,
        OUT_RESP_BODY: True
    }

    # Act
    with_headers, with_body = get_output_options(args, requests.PreparedRequest())

    # Assert
    assert not with_headers
    assert not with_body

    # Act
    with_headers, with_body = get_output_options(args, requests.Response())

    # Assert
    assert with_headers
    assert with_body

# Generated at 2022-06-23 19:12:06.170259
# Unit test for function get_output_options
def test_get_output_options():
    from pygments import __version__ as pygments_version
    from httpie import __version__ as httpie_version
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.cli.definition import parser
    import argparse
    import os
    import platform
    import sys
    assert 3 == 3


# Generated at 2022-06-23 19:12:14.658187
# Unit test for function get_output_options
def test_get_output_options():
    import argparse
    
    args = argparse.Namespace(output_options=[])
    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (False, False)

    args = argparse.Namespace(output_options=[head.value for head in [OUT_REQ_HEAD, OUT_REQ_BODY]])
    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (True, True)

    args = argparse.Namespace(output_options=[body.value for body in [OUT_RESP_HEAD, OUT_RESP_BODY]])
    message = requests.Response()
    assert get_output_options(args, message) == (True, True)

# Generated at 2022-06-23 19:12:17.271064
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    buffer = io.StringIO()
    print_debug_info(Environment(stderr=buffer))
    assert(buffer.getvalue().startswith('HTTPie'))

# Generated at 2022-06-23 19:12:19.637899
# Unit test for function main
def test_main():
    exit_status = main()
    assert exit_status == 0


# Generated at 2022-06-23 19:12:26.138107
# Unit test for function program
def test_program():
    import argparse
    args = argparse.Namespace(
        arg="test",
        default_options=[],
        follow=True,
        headers={},
        output_options=[],
        quiet=False,
        style="",
        verbose=False,
        verify=False,
        verify_options={},
    )
    env = Environment()
    assert program(args=args, env=env) == 0

# Generated at 2022-06-23 19:12:30.903420
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=set([OUT_REQ_HEAD, OUT_RESP_BODY]))
    message = requests.Response()
    with_headers, with_body = get_output_options(args, message)
    assert not with_headers
    assert with_body


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:12:32.713213
# Unit test for function main
def test_main():
    test_args = [
        'http'
    ]
    main()

# Generated at 2022-06-23 19:12:40.443283
# Unit test for function get_output_options
def test_get_output_options():
    class FakeArgs(object):
        def __init__(self):
            self.output_options = [OUT_RESP_BODY]

    fake_args = FakeArgs()
    fake_message = requests.PreparedRequest()

    assert get_output_options(fake_args, fake_message) == (False, False)

    fake_message = requests.Response()
    fake_message.status_code = 200

    assert get_output_options(fake_args, fake_message) == (False, True)

# Generated at 2022-06-23 19:12:53.798096
# Unit test for function print_debug_info
def test_print_debug_info():
    import contextlib
    import io
    import sys

    class FakeEnv(Environment):
        def __init__(self):
            self.stderr = io.TextIOWrapper(io.StringIO())
            self.stdout = io.TextIOWrapper(io.StringIO())
            self.config = FakeConfig()
            self.stdin_encoding = 'utf-8'
            self.log_level = 'debug'
            self.stdout_isatty = True
            self.stdin_isatty = True
            self.is_windows = False
            self.colors = True
            self.unicode_output = False
            self.use_envvars = False
            self.debug_flag_enabled = True

    class FakeConfig:
        def __init__(self):
            self.directory

# Generated at 2022-06-23 19:13:00.475039
# Unit test for function main
def test_main():
    from unittest.mock import MagicMock
    from httpie.core import main

    mock_env = MagicMock()
    mock_env.return_value = 'test_session1'

    assert main(['http', '--debug'], env=mock_env) == 0
    mock_env.log_error.assert_not_called()



# Generated at 2022-06-23 19:13:04.550331
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'foo', 'bar'], 'utf-8') == ['foo', 'bar']
    assert decode_raw_args([b'foo', 'bar'], 'ascii') == ['foo', 'bar']
    assert decode_raw_args(['foo', b'bar'], 'iso-8859-1') == ['foo', 'bar']

# Generated at 2022-06-23 19:13:11.442454
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        args=[
            'http',
            b'https://example.com/search?q=\xc7\xd1\xcc\xe5'
        ],
        stdin_encoding='gbk',
    ) == [
        'http',
        'https://example.com/search?q=\u4e16\u754c'
    ]


if __name__ == '__main__':
    main(sys.argv)

# Generated at 2022-06-23 19:13:20.075017
# Unit test for function main
def test_main():
    import httpie
    def main_test(args_or_config, argv=None):
        args = args_or_config if isinstance(args_or_config, list) else []
        env = Environment(config=args_or_config if isinstance(args_or_config, httpie.config.Config) else None)
        main(args=sys.argv if argv is None else argv, env=env)
    _test_main = main_test
    #main_test = _test_main
    del _test_main
    del httpie

# Generated at 2022-06-23 19:13:23.676584
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'http', b'q=\xe4\xb8\x8a\xe6\xb5\xb7'], 'utf8') == \
        ['http', 'q=\u4e0a\u6d77']

# Generated at 2022-06-23 19:13:30.198566
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.headers = None
    args.output_options = [OUT_REQ_HEAD, OUT_RESP_HEAD, OUT_RESP_BODY]
    env = Environment()
    env.stdout = sys.stdout
    program(args, env)


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:13:42.436909
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)

# Generated at 2022-06-23 19:13:51.737973
# Unit test for function print_debug_info
def test_print_debug_info():
    class FakeStdErr:
        def __init__(self):
            self.contents = []

        def __getattr__(self, item):
            if item == 'buffer':
                return self
            raise AttributeError

        def write(self, data):
            self.contents.append(data)
        def writelines(self, lines):
            self.contents.extend(lines)

    def custom_env(stderr):
        from httpie.context import Environment
        env = Environment()
        env.stderr = stderr
        return env

    env = custom_env(FakeStdErr())
    print_debug_info(env)
    contents = env.stderr.contents
    assert 'HTTPie ' in contents[0]
    assert 'Requests ' in contents[1]


# Generated at 2022-06-23 19:14:00.877336
# Unit test for function get_output_options
def test_get_output_options():
    assert get_output_options(argparse.Namespace(output_options=[]), requests.PreparedRequest()) == (False, False)
    assert get_output_options(argparse.Namespace(output_options=['reqBody']), requests.PreparedRequest()) == (False, True)
    assert get_output_options(argparse.Namespace(output_options=['reqHeaders']), requests.PreparedRequest()) == (True, False)
    assert get_output_options(argparse.Namespace(output_options=['respBody']), requests.Response()) == (False, True)
    assert get_output_options(argparse.Namespace(output_options=['respHeaders']), requests.Response()) == (True, False)

# Generated at 2022-06-23 19:14:10.578945
# Unit test for function main
def test_main():
    from io import BytesIO
    from io import StringIO
    import httpie.output.parser
    import httpie.output.formatters
    import httpie.output.streams
    import httpie.cli.parser
    import httpie.cli.stdin
    import httpie.plugins.manager
    import httpie.compat

    # Setup
    httpie.cli.parser.ArgumentParser = MockArgumentParser
    httpie.plugins.manager.plugin_manager = MockPluginManager
    httpie.cli.stdin.isatty = MockIsatty
    httpie.output.streams.isatty = MockIsatty
    httpie.compat.is_windows = MockIsWindows

    # Used for mocking stdin
    class ByteStringIO(StringIO):
        def read(self, n=-1):
            return

# Generated at 2022-06-23 19:14:15.468167
# Unit test for function decode_raw_args
def test_decode_raw_args():
    input = [b'\x80\x90', '\\x80\\x90']
    output = ['\u0080\u0090', '\\x80\\x90']
    assert decode_raw_args(input,
        'latin-1') == output

    input = [b'\xe1\x84\x90', '\\xe1\\x84\\x90']
    output = ['\ud504', '\\xe1\\x84\\x90']
    assert decode_raw_args(input,
        'latin-1') == output


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 19:14:24.028193
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = ['\u043f\u0440\u0438\u0432\u0435\u0442', '\u0430\u043c\u0435\u0440\u0438\u043a\u0430', '\u041c\u0435\u043d\u044f', '\u0437\u043e\u0432\u0443\u0442']
    assert decode_raw_args(args, 'utf-8') == ['привет', 'америка', 'Меня', 'зовут']
    assert decode_raw_args(args, 'cp866') == ['привет', 'америка', 'Меня', 'зовут']


# Generated at 2022-06-23 19:14:26.515769
# Unit test for function get_output_options
def test_get_output_options():
    get_output_options(requests.PreparedRequest(), OUT_REQ_HEAD)

# Generated at 2022-06-23 19:14:28.458589
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    # assert False, env.stderr.read()

# Generated at 2022-06-23 19:14:36.894888
# Unit test for function main
def test_main():
    os.system('python3 -m httpie.cli httpie --debug')
    os.system('python3 -m httpie.cli httpie --traceback')
    os.system('python3 -m httpie.cli httpie --download http://httpbin.org/image/jpeg --output-file=./jpeg.jpeg')
    os.system('python3 -m httpie.cli httpie --check-status httpbin.org/status/418')
    os.system('python3 -m httpie.cli httpie --check-status httpbin.org/status/201')
    os.system('python3 -m httpie.cli httpie --check-status httpbin.org/status/204')
    os.system('python3 -m httpie.cli httpie --check-status httpbin.org/status/301')

# Generated at 2022-06-23 19:14:47.559611
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from httpie.compat import is_windows
    if is_windows:
        import locale
        import codecs
        locale.setlocale(locale.LC_ALL, '')
        encoding = codecs.lookup(locale.getpreferredencoding()).name
        args = [b'123']
        assert decode_raw_args(args, encoding) == ['123']
        args = [b'123', b'456']
        assert decode_raw_args(args, encoding) == ['123', '456']
        args = [b'123', b'\u6f22\u5b57']
        assert decode_raw_args(args, encoding) == ['123', '\u6f22\u5b57']

# Generated at 2022-06-23 19:14:59.222665
# Unit test for function main
def test_main():
    def get_exit_code(args):
        try:
            return main(args)
        except SystemExit as e:
            return e.code

    assert get_exit_code(['http', '--debug']) == 0
    assert get_exit_code(['http', '--debug', 'get', 'http://httpbin']) == 0
    assert get_exit_code(['http', '--debug', '--timeout=1', '--follow', 'http://httpbin.org/delay/3']) == 1
    assert get_exit_code(['http', '--debug', '--check-status', '--follow', 'http://httpbin.org/status/500']) == 500


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:15:06.835334
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=[b'foo', b'bar', 'baz'], stdin_encoding='ascii') == [
        'foo',
        'bar',
        'baz'
    ]
    assert decode_raw_args(args=['foo', 'bar', 'baz'], stdin_encoding='ascii') == [
        'foo',
        'bar',
        'baz'
    ]

# Generated at 2022-06-23 19:15:16.572025
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # Conversion of sys.argv with bytes resulted from reading unbuffered sys.stdin
    # (in Python 3.x) to a list of str.
    assert decode_raw_args(['é'], 'latin-1') == ['é']
    assert decode_raw_args([b'\xc3\xa9'], 'utf-8') == ['é']

    # Conversion of os.environ.get('LANG') to str (in Python 2.x)
    assert decode_raw_args([b'en_US.UTF-8'], 'utf-8') == ['en_US.UTF-8']

# Generated at 2022-06-23 19:15:25.516532
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO, BytesIO
    from unittest.mock import patch
    import platform

    import pygments
    import requests
    from httpie import __version__ as httpie_version

    mock_stderr = StringIO()
    env = Environment()
    env.stderr = mock_stderr
    with patch('sys.executable', 'mock-executable'):
        mock_stdin = BytesIO(b'Mock stdin')
        env.stdin = mock_stdin
        print_debug_info(env)
        mock_stderr.seek(0)
        debug_info = mock_stderr.read()
    assert ('HTTPie ' + httpie_version) in debug_info
    assert ('Requests ' + requests.__version__) in debug_info

# Generated at 2022-06-23 19:15:37.526927
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    from httpie.cli.definition import parser
    def runtest(test_args):
        env = Environment(stdin=None, stdout=None, stderr=None)
        temp_file_name = tempfile.mktemp(text=False)
        test_args += ['-o', '.' + temp_file_name]
        sys.argv = ['http'] + test_args
        return os.system('http '+ ' '.join(test_args) + '>/dev/null 2>&1'), temp_file_name

# Generated at 2022-06-23 19:15:42.652575
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser
    from httpie.plugins.builtin import HTTPiePlugin
    args = parser.parse_args(args=['--output-options=req_b'], env=Environment())
    req = requests.PreparedRequest()
    assert get_output_options(args, req) == (True, True)

# Generated at 2022-06-23 19:15:43.607061
# Unit test for function print_debug_info
def test_print_debug_info():
    assert not print_debug_info

# Generated at 2022-06-23 19:15:49.697061
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

    args = parser.parse_args(
        args=[
            '--json', '--output', 'string', 'POST', 'http://example.com/', 'a=b', 'c==', 'd==='
        ],
        env=Environment(),
    )
    program(args=args, env=Environment())
    assert args.json
    assert args.output == 'string'
    assert args.method == 'POST'
    assert args.url == 'http://example.com/'
    assert args.data == ['a=b', 'c==', 'd===']



# Generated at 2022-06-23 19:15:58.759988
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        args=['-b', b'foo=1', '--form', b'bar=2'],
        stdin_encoding='utf8'
    ) == ['-b', 'foo=1', '--form', 'bar=2']
    assert decode_raw_args(
        args=[b'-b', b'foo=1', b'--form', '\xe2\x82\xac=2'],
        stdin_encoding='utf8'
    ) == ['-b', 'foo=1', '--form', '€=2']

# Generated at 2022-06-23 19:16:10.443827
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.config import AuthCredentials
    from httpie import ExitStatus
    from pygments.token import Token
    from httpie.cli.parser import KeyValueArgType

    # inputs for test_program
    url = 'http://httpbin.org/get'
    args = parser.parse_args(url.split(' '))
    env = Environment(stdout=None)

    # set some arguments
    args.output_options = []
    args.check_status = True
    args.follow = True
    args.download = False
    args.download_resume = False
    args.output_file = None
    args.output_file_specified = False

    # set initial value
    initial_request = None
    final_response = None
    download_stream = None
   

# Generated at 2022-06-23 19:16:22.347009
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import sys

    # Python 2 fallback PY2 str to unicode
    def _u(s):
        return s.decode('utf8') if type(s) is bytes else s

    # Python 3 fallback PY2 unicode to str
    def _b(s):
        return s.encode('utf8') if type(s) is str else s

    # sys.argv is always a list of bytes
    py2 = sys.version_info[0] == 2
    args = ['--form', 'foo=bar']
    args_bytes = list(map(_b, args))
    assert decode_raw_args(args, stdin_encoding='utf8') == args
    assert decode_raw_args(args_bytes, stdin_encoding='utf8') == args

    # str on PY2, bytes on

# Generated at 2022-06-23 19:16:30.301518
# Unit test for function main
def test_main():
    assert main(args=[os.path.basename(__file__), '--config-dir=/tmp/foo']) == ExitStatus.SUCCESS


if __name__ == '__main__':
    # noinspection PyBroadException
    try:
        exit_status = main()
    except BaseException as e:
        print(e, file=sys.stderr)
        exit_status = ExitStatus.ERROR
    finally:
        # noinspection PyUnboundLocalVariable
        sys.exit(exit_status)

# Generated at 2022-06-23 19:16:37.520379
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_HEAD, OUT_RESP_BODY]
    message = requests.PreparedRequest()
    print(get_output_options(args, message))

    args = argparse.Namespace()
    args.output_options = [OUT_REQ_HEAD, OUT_RESP_BODY]
    message = requests.Response()
    print(get_output_options(args, message))

# Generated at 2022-06-23 19:16:46.089676
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from httpie import ExitStatus
    from httpie.cli.definition import parser
    from httpie.context import Environment

    from tests import BasicAuthTestEnv, MockEnvironment

    # Python 3
    if sys.version_info >= (3, 0):
        assert decode_raw_args(['--form', 'get'], 'utf8') == ['--form', 'get']

    # Python 2
    else:
        assert decode_raw_args(['--form', 'get'.encode('utf8')], 'utf8') == ['--form', 'get']
        assert decode_raw_args([b'--form', 'get'.encode('utf8')], 'utf8') == ['--form', 'get']
        assert decode_raw_args([b'--form', b'get'], 'utf8') == ['--form', 'get']

# Generated at 2022-06-23 19:16:50.259382
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    env = Environment()
    env.stderr = io.StringIO()
    print_debug_info(env)
    assert env.stderr.getvalue().startswith('HTTPie ')

# Generated at 2022-06-23 19:16:50.897697
# Unit test for function program
def test_program():
    pass

# Generated at 2022-06-23 19:16:53.273174
# Unit test for function program
def test_program():
    args = program(['www.google.com', '--output=debug'], Environment())
    assert args == ExitStatus.SUCCESS


# Generated at 2022-06-23 19:16:55.179813
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    env = Environment()
    program(args, env)

# Generated at 2022-06-23 19:17:03.882374
# Unit test for function get_output_options
def test_get_output_options():
    from httpie import ExitStatus
    from httpie.cli.definition import parser

    def get_output_options(
        args: argparse.Namespace,
        message: Union[requests.PreparedRequest, requests.Response]
    ) -> Tuple[bool, bool]:
        return {
            requests.PreparedRequest: (
                OUT_REQ_HEAD in args.output_options,
                OUT_REQ_BODY in args.output_options,
            ),
            requests.Response: (
                OUT_RESP_HEAD in args.output_options,
                OUT_RESP_BODY in args.output_options,
            ),
        }[type(message)]

    parsed_args = parser.parse_args(
        args=['-h'],
        env=Environment()
    )

    is_request = isinstance

# Generated at 2022-06-23 19:17:12.041710
# Unit test for function main
def test_main():
    import tempfile

    from httpie.context import Environment

    env = Environment()

    # Invalid arguments
    for args in [[], ['--debug']]:
        assert main(args=args, env=env) == ExitStatus.ERROR

    # Debug info
    main(args=['--debug'], env=env)
    assert main(args=['http', '--debug', 'httpbin.org'], env=env) == ExitStatus.SUCCESS

    # No output
    args = ['http', '--check-status', '--quiet', 'httpbin.org']
    assert main(args=args, env=env) == ExitStatus.SUCCESS

    # No output --download
    args = ['http', '--download', '--quiet', 'httpbin.org']

# Generated at 2022-06-23 19:17:24.067110
# Unit test for function get_output_options
def test_get_output_options():
    from requests import PreparedRequest, Response
    args = argparse.Namespace(output_options=['body'])
    assert get_output_options(args=args, message=PreparedRequest()) == (False, True)
    assert get_output_options(args=args, message=Response()) == (False, True)

    args = argparse.Namespace(output_options=['body', 'headers'])
    assert get_output_options(args=args, message=PreparedRequest()) == (True, True)
    assert get_output_options(args=args, message=Response()) == (True, True)

    args = argparse.Namespace(output_options=['headers'])
    assert get_output_options(args=args, message=PreparedRequest()) == (True, False)

# Generated at 2022-06-23 19:17:31.469652
# Unit test for function program
def test_program():
    env = Environment()
    class args:
        headers = []
        download = False
        output_file = None
        download_resume = False
        output_options = OUT_REQ_HEAD
        quiet = False
        follow = False
        check_status = False
        output_file_specified = False

# Generated at 2022-06-23 19:17:32.679615
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'foo', 'bar', b'baz'], 'ascii') == ['foo', 'bar', 'baz']

# Generated at 2022-06-23 19:17:43.164682
# Unit test for function decode_raw_args
def test_decode_raw_args():
    """
    Unit test for function decode_raw_args

    """
    import locale

    stdin_encoding = locale.getpreferredencoding()
    assert decode_raw_args([b'some', 'text'], stdin_encoding) == [
        'some', 'text'
    ]
    assert decode_raw_args([b'some', b'bytes'], stdin_encoding) == [
        'some', 'bytes'
    ]
    assert decode_raw_args([b'some', b'bytes', 'mixed'], stdin_encoding) == [
        'some', 'bytes', 'mixed'
    ]

# Generated at 2022-06-23 19:17:46.736352
# Unit test for function decode_raw_args
def test_decode_raw_args():
    print(decode_raw_args(['test', '--verbose', 'test2'], "utf8"))


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:17:51.019401
# Unit test for function main
def test_main():
    # TODO: Add more tests
    assert main(['http', '--version']) == ExitStatus.SUCCESS
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--output-file', '-']) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:17:52.481381
# Unit test for function program
def test_program():
    pass


# Generated at 2022-06-23 19:17:56.488427
# Unit test for function print_debug_info
def test_print_debug_info():
    """
    Tests the function print_debug_info and all the methods it calls.
    """
    import io
    import sys

    sys.stdout = io.StringIO()

    env = Environment()
    print_debug_info(env)

    new_stdout = sys.stdout.getvalue()
    assert len(new_stdout) > 0

# Generated at 2022-06-23 19:18:04.526261
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    import sys
    import platform
    stdout = StringIO()
    stderr = StringIO()
    env = Environment(stdout=stdout, stderr=stderr)
    print_debug_info(env)
    output = stderr.getvalue()
    assert__name__ = 'httpie'
    assert isinstance(output, str)
    assert output.startswith('HTTPie')
    assert output.startswith('httpie')
    assert output.find('Requests') > 0
    assert output.find('Pygments') > 0
    assert output.find('Python' + sys.version) > 0
    assert output.find(platform.system()) > 0
    assert output.find(platform.release()) > 0
    assert len(output.splitlines()) == 7



# Generated at 2022-06-23 19:18:07.240092
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a', b'b', 'c'], 'utf8') == ['a', 'b', 'c']

# Generated at 2022-06-23 19:18:14.001289
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options = [
            OUT_REQ_HEAD,
            OUT_REQ_BODY,
            OUT_RESP_HEAD,
            OUT_RESP_BODY
        ]
    )
    assert get_output_options(args, requests.PreparedRequest()) == (True, True)
    assert get_output_options(args, requests.Response()) == (True, True)

# Generated at 2022-06-23 19:18:23.421834
# Unit test for function print_debug_info
def test_print_debug_info():
    from unittest import mock
    import os
    from httpie.context import Environment
    env = Environment()
    test = mock.MagicMock()
    test.write = mock.MagicMock()
    env.stderr = test
    expected = [
        f'HTTPie {httpie_version}\n',
        f'Requests {requests_version}\n',
        f'Pygments {pygments_version}\n',
        f'Python {sys.version}\n{sys.executable}\n',
        f'{platform.system()} {platform.release()}',
    ]
    print_debug_info(env)
    t = test.write.call_args[0][0]
    assert t in expected
    t = test.write.call_args[0][1]
    assert t in expected
   

# Generated at 2022-06-23 19:18:31.263946
# Unit test for function print_debug_info
def test_print_debug_info():
    stdout = StringIO()
    class CustomEnv(Environment):
        def __init__(self):
            super().__init__()
            self.stdout = stdout
            self.stderr = stdout
    env = CustomEnv()
    print_debug_info(env)
    output = stdout.getvalue()
    assert 'HTTPie' in output
    assert 'Requests' in output
    assert 'Pygments' in output
    assert 'Python' in output
    assert '\n\n' in output
    assert '<Environment' in output

# Generated at 2022-06-23 19:18:36.444951
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from httpie.config import get_config_dir
    env = Environment(stdin=None, stdin_isatty=True, stdout=StringIO(), stdout_isatty=False,
                      stderr=StringIO(), stderr_isatty=False, stdout_bytes_writable=True,
                      stdout_textmode=False, stdout_is_redirected=False, output_options={},
                      config_dir=get_config_dir(), config=None, stdin_encoding='utf8',
                      stdin_errors='strict', output_file=None, output_file_resolve_path=False)
    print_debug_info(env)
    assert(httpie_version in env.stderr.getvalue())

# Generated at 2022-06-23 19:18:39.238252
# Unit test for function program
def test_program():
    import pytest
    output = program(args=['localhost:8080', '-b', 'data'], env=Environment())
    assert output == ExitStatus.SUCCESS


# Generated at 2022-06-23 19:18:47.391398
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = []
    with pytest.raises(KeyError):
        get_output_options(args, 'foo')

    args.output_options = []
    assert get_output_options(args, requests.PreparedRequest()) == (False, False)

    args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)

    args.output_options = [OUT_REQ_BODY]
    assert get_output_options(args, requests.PreparedRequest()) == (False, True)

    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY]

# Generated at 2022-06-23 19:18:58.453708
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        args=['a', 'b', 'c'],
        stdin_encoding='utf8',
    ) == ['a', 'b', 'c']
    assert decode_raw_args(
        args=[b'a', 'b', 'c'],
        stdin_encoding='utf8',
    ) == ['a', 'b', 'c']
    assert decode_raw_args(
        args=[b'a', 'b', 'c'],
        stdin_encoding='latin1',
    ) == ['a', 'b', 'c']
    assert decode_raw_args(
        args=[b'\xc3\xa1', 'b', 'c'],
        stdin_encoding='utf8',
    ) == ['á', 'b', 'c']