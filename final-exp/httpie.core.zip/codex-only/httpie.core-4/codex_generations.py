

# Generated at 2022-06-23 19:08:54.278482
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options = ['resp_body']
    )
    message = requests.Response()
    with_headers, with_body = get_output_options(args, message)
    assert with_headers == False and with_body == True

    args = argparse.Namespace(
        output_options = ['resp_head']
    )
    message = requests.Response()
    with_headers, with_body = get_output_options(args, message)
    assert with_headers == True and with_body == False

    args = argparse.Namespace(
        output_options = ['resp_head', 'resp_body']
    )
    message = requests.Response()
    with_headers, with_body = get_output_options(args, message)
    assert with_headers == True and with_

# Generated at 2022-06-23 19:09:01.201048
# Unit test for function get_output_options
def test_get_output_options():
    import argparse
    from httpie.cli.definition import parser
    args = parser.parse_args(args=[
        'GET',
        'https://example.org',
    ])

    msg = requests.PreparedRequest()
    ret = get_output_options(args, msg)
    assert (False, True) == ret

    msg = requests.Response()
    ret = get_output_options(args, msg)
    assert (True, True) == ret

# Generated at 2022-06-23 19:09:05.087609
# Unit test for function print_debug_info
def test_print_debug_info():
    class FakeStderr(object):
        def __init__(self, stderr):
            self.stderr = stderr
        def write(self, msg):
            if msg == '\n':
                self.stderr.write(msg)
            else:
                self.stderr.write('stderr: ' + msg)
            return

    import sys
    sys.stderr = FakeStderr(sys.stderr)
    print_debug_info(env=Environment())
    return

# Unit test

# Generated at 2022-06-23 19:09:15.287938
# Unit test for function decode_raw_args
def test_decode_raw_args():
    def assertEqual(args_in: List[Union[str, bytes]], args_out: List[str]):
        args_out2 = decode_raw_args(args_in=args_in, stdin_encoding='utf-8')
        if args_out != args_out2:
            raise AssertionError(f'args_in={args_in!r}; args_out={args_out!r}; args_out2={args_out2!r}')

    assertEqual(args_in=['foo', 'bar'], args_out=['foo', 'bar'])
    assertEqual(args_in=[b'foo', 'bar'], args_out=['foo', 'bar'])

# Generated at 2022-06-23 19:09:22.407748
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=["body","headers"])
    request = requests.PreparedRequest()
    print(get_output_options(args,request))

    response = requests.Response()
    print(get_output_options(args, response))


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:09:25.424418
# Unit test for function main
def test_main():
    class MockEnv:
        def __init__(self):
            self.stdin_encoding = 'UTF-8'

    main(args=[], env=MockEnv())

# Generated at 2022-06-23 19:09:34.485122
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import os
    import sys
    import pytest
    from httpie.cli.constants import DEFAULT_CLI_ENCODING
    from httpie.output.streams import StdoutBytesIO

    # sys.stdin.encoding is None on Python 3.8+ on macOS
    # https://bugs.python.org/issue38070
    with open(__file__, 'rb') as f:
        original_stdin = sys.stdin
        sys.stdin = f
        stdin_encoding = sys.stdin.encoding or DEFAULT_CLI_ENCODING
    sys.stdin = original_stdin

    def _decode_raw_args(*args: Union[str, bytes]) -> List[str]:
        return decode_raw_args(args, stdin_encoding)


# Generated at 2022-06-23 19:09:39.874648
# Unit test for function print_debug_info
def test_print_debug_info():
    class DummyStderr:
        content = b''

        def write(self, bytes_):
            self.content += bytes_

    stderr = DummyStderr()
    env = Environment()
    env.stderr = stderr
    print_debug_info(env)
    assert stderr.content.startswith(b'HTTPie ')

# Generated at 2022-06-23 19:09:48.757802
# Unit test for function main
def test_main():
    assert main([sys.argv[0], 'GET', 'http://www.google.com/']) == ExitStatus.SUCCESS
    assert main([sys.argv[0], 'GET', 'http://www.google.com/', '--debug']) == ExitStatus.SUCCESS
    assert main([sys.argv[0], 'GET', 'http://www.google.com/', '--debug', '--debug-traceback']) == ExitStatus.SUCCESS
    assert main([sys.argv[0], 'GET', 'http://www.google.com/', '--debug-traceback']) == ExitStatus.ERROR
    assert main([sys.argv[0], 'GET', 'http://www.google.com/', '--debug-traceback', '--debug']) == ExitStatus.ERROR



# Generated at 2022-06-23 19:09:59.236504
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    import json
    import requests

    message = requests.PreparedRequest()
    message.body = json.dumps({'test': 'test'})

    with Environment() as env:
        env.config.default_options = ['--traceback', '--check-status']
        args = parser.parse_args(['--json'], env)
        assert program(args, env) == ExitStatus.SUCCESS
    with Environment() as env:
        env.config.default_options = ['--traceback', '--check-status']
        args = parser.parse_args(['--json'], env)
        assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:10:08.530897
# Unit test for function print_debug_info
def test_print_debug_info():
    class FakeStderr:
        def __init__(self):
            self.data = []

        def writelines(self, value):
            self.data.extend(value)

        def write(self, value):
            self.data.append(value)

    env = Environment(stdout=FakeStderr())

    print_debug_info(env)

    expected = """\
HTTPie 0.9.8
Requests 2.21.0
Pygments 2.2.0
Python 3.6.4 (v3.6.4:d48eceb, Dec 19 2017, 06:04:45) [MSC v.1900 32 bit (Intel)]
C:\\Users\\Kokocinski\\PycharmProjects\\httpie\\venv\\Scripts\\python.exe
Windows 10"""

    assert "\n".join

# Generated at 2022-06-23 19:10:12.601617
# Unit test for function program
def test_program():
    # Happy path
    assert program(args={"url":"http://www.google.com"}, env={}) == ExitStatus.SUCCESS
    # Bad response status code
    assert program(args={"url":"http://www.google.com"}, env={}) == ExitStatus.ERROR

# Generated at 2022-06-23 19:10:19.757938
# Unit test for function program
def test_program():
    from httpie.compat import is_windows
    from httpie import __file__ as httpie_file
    from httpie import cli

    httpie_file = httpie_file.replace('.pyc', '.py')
    args = cli.parser.parse_args(args=[
        '--print=H',
        'https://httpbin.org/headers',
    ], env=Environment())
    args.stdout = io.BytesIO()
    exit_status = program(
        args=args,
        env=Environment(colors=256),
    )
    assert exit_status is ExitStatus.SUCCESS

# Generated at 2022-06-23 19:10:21.667570
# Unit test for function main
def test_main():
    args = ['http', '--json', 'http://httpbin.org/get']
    exit_status = main(args=args)
    assert exit_status == ExitStatus.SUCCESS



# Generated at 2022-06-23 19:10:25.346402
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = decode_raw_args(['--form', b'k=v'], 'utf8')
    assert args == ['--form', 'k=v']



# Generated at 2022-06-23 19:10:32.770787
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert ['blah'] == decode_raw_args([b'blah'], 'ascii')
    assert ['blah'] == decode_raw_args([b'blah'], 'utf-8')
    assert ['blah'] == decode_raw_args([b'blah'], 'utf-16')
    assert ['blah'] == decode_raw_args([b'blah'], 'utf-32')
    assert ['blah'] == decode_raw_args(['blah'], 'ascii')
    assert ['blah'] == decode_raw_args(['blah'], 'utf-8')
    assert ['blah'] == decode_raw_args(['blah'], 'utf-16')
    assert ['blah'] == decode_raw_args(['blah'], 'utf-32')

# Generated at 2022-06-23 19:10:41.609941
# Unit test for function main
def test_main():
    from contextlib import contextmanager
    from io import StringIO

    from httpie import ExitStatus
    from httpie.client import main as http_main
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.models import Request
    from httpie.output.streams import Stream

    class StderrBytesIO(StringIO):
        """BytesIO that behaves as stderr.

        What matters is that the write method returns zero when called.

        """
        errors = 'strict'

        def write(self, data: bytes) -> int:
            StringIO.write(self, data.decode('utf8', errors='replace'))
            return 0

    @contextmanager
    def stderr_as_bytes_io():
        old_stderr = sys.stderr


# Generated at 2022-06-23 19:10:53.743017
# Unit test for function program
def test_program():
    # Test: --json
    args = parser.parse_args(['http', '--json', 'GET', 'https://github.com'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

    # Test: --pretty=all
    args = parser.parse_args(['http', '--pretty=all', 'GET', 'https://github.com'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

    # Test: --style
    args = parser.parse_args(['http', '--style=default', 'GET', 'https://github.com'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

    # Test: --download

# Generated at 2022-06-23 19:11:05.591546
# Unit test for function get_output_options
def test_get_output_options():
    # Some types
    from argparse import Namespace
    from httpie.config import Config
    from httpie.environment import Environment
    from httpie.compat import is_windows

    # Mockup
    args = Namespace()
    args.output_options = (OUT_REQ_HEAD | OUT_REQ_BODY | OUT_RESP_HEAD | OUT_RESP_BODY)
    req = requests.PreparedRequest()
    req.headers = {'Accept': 'text/html'}
    rsp = requests.Response()
    rsp.status_code = 200
    rsp.reason = 'OK'
    env = Environment(config=Config(), stdout_isatty=is_windows, stderr_isatty=is_windows)

    # Verify

# Generated at 2022-06-23 19:11:10.674928
# Unit test for function print_debug_info
def test_print_debug_info():
    class _:
        def __init__(self):
            self.stderr = []

        def write(self, x):
            self.stderr.append(x)

    env = _()
    print_debug_info(env=env)
    assert env.stderr[0].startswith('HTTPie ')
    assert env.stderr[1].startswith('Requests ')
    assert env.stderr[2].startswith('Pygments ')
    assert env.stderr[3].startswith('Python ')
    assert env.stderr[4].startswith(sys.executable)
    assert env.stderr[5].startswith(f'{platform.system()} {platform.release()}')
    assert env.stderr[7].startsw

# Generated at 2022-06-23 19:11:18.801009
# Unit test for function get_output_options
def test_get_output_options():
    import pytest
    from argparse import Namespace
    from requests import PreparedRequest, Response
    args = Namespace(
        output_options=[OUT_REQ_HEAD, OUT_RESP_BODY],
    )
    assert get_output_options(args, PreparedRequest()) == (True, False)
    assert get_output_options(args, Response()) == (False, True)
    args = Namespace(
        output_options=[OUT_REQ_HEAD, OUT_RESP_BODY, OUT_REQ_BODY],
    )
    assert get_output_options(args, PreparedRequest()) == (True, True)
    assert get_output_options(args, Response()) == (False, True)

# Generated at 2022-06-23 19:11:28.128970
# Unit test for function main
def test_main():
    def _assert(
        args: List[str],
        stdin_encoding: str,
        expected: List[str]
    ):
        assert decode_raw_args(args, stdin_encoding) == expected

    _assert(
        ["some", "raw", "args"],
        "UTF-8",
        ["some", "raw", "args"]
    )
    _assert(
        ["some", "raw", b"args"],
        "UTF-8",
        ["some", "raw", "args"]
    )
    _assert(
        ["some", "raw", b"args"],
        "UTF-16-LE",
        ["some", "raw", "a\x00r\x00g\x00s\x00"]
    )

# Generated at 2022-06-23 19:11:35.101148
# Unit test for function get_output_options
def test_get_output_options():
    env = Environment()
    args = [
        'http',
        '-jh',
        'example.com'
    ]
    args_namespace = parser.parse_args(args=args, env=env)
    assert get_output_options(args_namespace, requests.PreparedRequest()) == (True, False)
    assert get_output_options(args_namespace, requests.Response()) == (True, True)



# Generated at 2022-06-23 19:11:42.092745
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[OUT_RESP_HEAD, OUT_RESP_BODY])
    with_headers, with_body = get_output_options(args=args, message=requests.PreparedRequest())
    assert not with_headers and not with_body
    with_headers, with_body = get_output_options(args=args, message=requests.Response())
    assert with_headers and with_body

# Generated at 2022-06-23 19:11:46.064160
# Unit test for function print_debug_info
def test_print_debug_info():
    class FakeStderr:
        def __init__(self):
            self.content = []

        def write(self, x: str):
            self.content.append(x)

    env = Environment()
    env.stderr = FakeStderr()

    print_debug_info(env)


if __name__ == '__main__':
    # noinspection PyBroadException
    try:
        main()
    except KeyboardInterrupt:
        print('\n', end='')  # Avoid a double new line at the end.
        sys.exit(ExitStatus.ERROR_CTRL_C)
    except SystemExit as e:
        sys.exit(e.code)
    except Exception:
        import traceback

# Generated at 2022-06-23 19:11:48.216910
# Unit test for function program
def test_program():
    assert program(argparse.Namespace(), Environment()) == ExitStatus.SUCCESS



# Generated at 2022-06-23 19:11:54.147852
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # Test 1: str args
    assert decode_raw_args(['a', 'b', 'c', 'd'], 'utf-8') == ['a', 'b', 'c', 'd']
    # Test 2: mixed args (first 3 bytes, last 1 str)
    assert decode_raw_args([b'a', 'b', 'c', b'd'], 'utf-8') == ['a', 'b', 'c', 'd']


# Generated at 2022-06-23 19:11:58.314246
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr = BytesIO()
    print_debug_info(env)
    output = env.stderr.getvalue()

    assert b'HTTPie' in output
    assert b'Requests' in output
    assert b'Python' in output

# Generated at 2022-06-23 19:12:04.870846
# Unit test for function get_output_options
def test_get_output_options():
    args_dict = {
        'args': {
            'output_options': ['reqBody', 'respBody']
        }
    }
    args = argparse.Namespace(**args_dict['args'])
    message = requests.PreparedRequest()
    assert get_output_options(
        args=args,
        message=message
    ) == (False, True)

# Generated at 2022-06-23 19:12:08.466553
# Unit test for function print_debug_info
def test_print_debug_info():
    class Env:
        stdin_encoding = 'utf-8'
        config_dir = '/etc/httpie'

    result = print_debug_info(Env())
    assert result is None

# Generated at 2022-06-23 19:12:11.466577
# Unit test for function main
def test_main():
    """
    Unit test for main(). To run this, in the root of this git repo, run:
    python3 src/httpie/__main__.py
    """
    assert main([]) is not 0

# Generated at 2022-06-23 19:12:17.329665
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

    test_args = parser.parse_args(
        args=[
            "httpie", "httpbin.org/get"
        ],
        env=Environment(),
    )
    # TODO: test status
    status = program(args=test_args, env=Environment())
    assert status == ExitStatus.SUCCESS
    status = program(args=test_args, env=Environment())
    assert status == ExitStatus.SUCCESS


if __name__ == "__main__":
    test_program()

# Generated at 2022-06-23 19:12:25.533983
# Unit test for function decode_raw_args
def test_decode_raw_args():
    stdin_encoding='utf-8'
    bytes_args=[b'GET', b'hostname:80', b'test:test', b'-t' , b'json', b'name~=value', b'-X']
    str_args = [arg.decode(stdin_encoding) if type(arg) is bytes else arg for arg in bytes_args ]
    assert(decode_raw_args(bytes_args, stdin_encoding) == str_args)

# Generated at 2022-06-23 19:12:31.846839
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser
    from httpie import ExitStatus
    exit_status=ExitStatus.SUCCESS
    parsed_args = parser.parse_args(args=['--output-options=respHead,reqBody', 'GET', 'http://localhost:8080'])
    assert get_output_options(parsed_args, requests.Response()) == (True, True)
    assert get_output_options(parsed_args, requests.PreparedRequest()) == (False, True)

# Generated at 2022-06-23 19:12:34.440928
# Unit test for function decode_raw_args
def test_decode_raw_args():
    try:
        assert decode_raw_args([b'\xe1\xe2\xe3\xe4']) == ['áâãä']
        print("Success")
    except AssertionError:
        print("Exception")


# Generated at 2022-06-23 19:12:40.301170
# Unit test for function program
def test_program():
    from httpie.cli.runner import program
    from tests.examples import EXAMPLES

    for url in EXAMPLES:
        args = ['http', url, '--traceback', '--output-file=output_file']
        program(args, Environment())


if __name__ == '__main__':
    status = main()
    sys.exit(status)

# Generated at 2022-06-23 19:12:45.731227
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.argtypes import KeyValueArg

# Generated at 2022-06-23 19:12:56.269099
# Unit test for function program
def test_program():
    env = Environment(stdin=sys.stdin,
                      stdin_isatty=False,
                      stdout=sys.stdout,
                      stdout_isatty=False,
                      stdout_raw=False,
                      stderr=sys.stderr,
                      stderr_isatty=False,
                      stdout_binary=False,
                      stdout_isatty=False)
    args = parser.parse_args(['--verbose', 'https://httpbin.org/get'])
    print(program(args, env))
    args = parser.parse_args(['--help'])
    print(program(args, env))
    args = parser.parse_args(['https://httpbin.org/get', 'user-agent:testing'])
    print(program(args, env))



# Generated at 2022-06-23 19:13:05.620923
# Unit test for function get_output_options
def test_get_output_options():
    class ArgsCls:
        output_options = []
    args_cls = ArgsCls()
    print(get_output_options(args_cls, requests.PreparedRequest()))
    args_cls.output_options.append(OUT_REQ_HEAD)
    print(get_output_options(args_cls, requests.PreparedRequest()))
    args_cls.output_options.append(OUT_RESP_HEAD)
    print(get_output_options(args_cls, requests.PreparedRequest()))
    args_cls.output_options.append(OUT_REQ_BODY)
    print(get_output_options(args_cls, requests.PreparedRequest()))
    args_cls.output_options.append(OUT_RESP_BODY)
    print

# Generated at 2022-06-23 19:13:08.269622
# Unit test for function decode_raw_args
def test_decode_raw_args():
    #noinspection PyTypeChecker
    assert decode_raw_args(['--form', 'key=\xe5\x90\x8d\xe5\xad\x97'], 'utf8') == \
           ['--form', 'key=名字']

# Generated at 2022-06-23 19:13:10.069491
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    assert env.stderr.closed == False

# Generated at 2022-06-23 19:13:18.629230
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()

    def get_stderr_text():
        stderr = env.stderr
        stderr.seek(0)
        return stderr.read()

    env.stderr = io.BytesIO()
    print_debug_info(env)
    assert re.match(
        r'HTTPie .+\n'
        r'Requests .+\n'
        r'Pygments .+\n'
        r'Python .+\n'
        r'.+\n'
        r'.+\n'
        r'\n\n'
        r'<Environment.*',
        get_stderr_text()
    )

# Generated at 2022-06-23 19:13:23.747484
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        # bytes in command line are decoded
        [b'\xe7\x9a\x84'],
        'utf8'
    ) == ['的']
    assert decode_raw_args(
        # str as-is
        ['foo'],
        'utf8'
    ) == ['foo']
    assert decode_raw_args(
        # bytes in JSON data decoded
        ['{"data":"\xe7\x9a\x84"}'],
        'utf8'
    ) == ['{"data":"的"}']



# Generated at 2022-06-23 19:13:35.667830
# Unit test for function get_output_options
def test_get_output_options():
    import httpie
    import httpie.cli
    import httpie.cli.argtypes
    import json
    import requests

    __httpie_version__ = '1.0.2'
    __requests_version__ = '2.22.0'
    __pygments_version__ = '2.4.2'
    __program_name__ = 'http'
    __python_version__ = '3.7.3'
    __python_executable__ = '/usr/local/bin/python3'
    __system_release__ = '3.14.79-103.fc20.x86_64'
    __system_system__ = 'Linux'


# Generated at 2022-06-23 19:13:37.744493
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'\xe2\x98\x83'], 'utf8') == ['☃']

# Generated at 2022-06-23 19:13:48.936467
# Unit test for function program
def test_program():
	env = Environment()
	argstr = 'www.google.com --headers'
	args = main(argstr.split(' '), env)
	print("Exit Status: {}".format(args))
	
	argstr = 'www.google.com --headers'
	args = main(argstr.split(' '), env)
	print("Exit Status: {}".format(args))
	
	argstr = 'www.google.com --headers'
	args = main(argstr.split(' '), env)
	print("Exit Status: {}".format(args))
	
	argstr = 'www.google.com --headers'
	args = main(argstr.split(' '), env)
	print("Exit Status: {}".format(args))
	
	argstr = 'www.google.com --headers'

# Generated at 2022-06-23 19:13:52.313812
# Unit test for function print_debug_info
def test_print_debug_info():
    env=Environment()
    env.stderr.write('\nHello\n')
    print_debug_info(env)

# Generated at 2022-06-23 19:14:01.158387
# Unit test for function program
def test_program():
    from io import StringIO
    from httpie.cli.definition import parser
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import mimeparse
    import logging
    import tempfile
    import os
    import shutil
    import sys
    from httpie.context import Environment
    from httpie.client import collect_messages
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.downloads import Downloader
    from httpie.status import ExitStatus, http_status_to_exit_status
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    

# Generated at 2022-06-23 19:14:10.926058
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=[b'a', 'b'], stdin_encoding='utf-8') == ['a', 'b']
    assert decode_raw_args(args=[b'\xe4\xb8\x80', 'b'], stdin_encoding='utf-8') == ['一', 'b']
    assert decode_raw_args(args=[b'\xe4\xb8\x80', 'b'], stdin_encoding='utf-8') == ['一', 'b']
    assert decode_raw_args(args=[b'\xe4\xb8\x80', 'b'], stdin_encoding='gb18030') == ['一', 'b']

# Generated at 2022-06-23 19:14:21.847150
# Unit test for function main
def test_main():
    import shutil

    script_directory = os.path.dirname(os.path.realpath(__file__))
    test_directory = os.path.join(script_directory, '../tests')
    test_file = os.path.join(test_directory, '../requirements.txt')
    assert main(args=['--verbose', 'https://httpie.org']) == ExitStatus.SUCCESS
    assert main(args=['--quiet', 'https://httpie.org']) == ExitStatus.SUCCESS
    assert main(args=['--debug', test_file]) == ExitStatus.ERROR
    assert main(args=['--debug', '--form', 'test@test.test', 'https://httpie.org']) == ExitStatus.ERROR
    assert main(args=['--debug']) == ExitStatus.SU

# Generated at 2022-06-23 19:14:29.288240
# Unit test for function print_debug_info
def test_print_debug_info():
    class FakeStream:
        def __init__(self):
            self.data = []

        def write(self, data):
            self.data.append(data)

        def writelines(self, data):
            self.data.extend(data)

    stream = FakeStream()

    env = Environment(stderr=stream)

    print_debug_info(env)

    assert len(stream.data) == 5



# Generated at 2022-06-23 19:14:40.490703
# Unit test for function program
def test_program():
    '''
    This function tests the program function in cli.py.
    '''
    # Testing when invalid argv[1] is entered
    try:
        print(program(["test"]))
        raise Exception()
    except SystemExit:
        pass
    # Testing when --help flag is entered
    try:
        print(program(["http", "-h"]))
        raise Exception()
    except SystemExit:
        pass
    # Testing when --debug flag is entered
    try:
        print(program(["http", "--debug"]))
        raise Exception()
    except SystemExit:
        pass
    # Testing when valid url is entered
    try:
        print(program(["http", "google.com"]))
        raise Exception()
    except SystemExit:
        pass
    # Testing when valid url is entered and some headers

# Generated at 2022-06-23 19:14:41.971197
# Unit test for function program
def test_program():
    assert program(args=['mkdir'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:14:43.769226
# Unit test for function main
def test_main():
    import sys
    sys.argv = ['http', '--help']
    main()


# Generated at 2022-06-23 19:14:48.181821
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        [b'\xe4\xb8\x96\xe7\x95\x8c', '你好', 'mit \xf6sterreich'],
        stdin_encoding='utf-8'
    ) == ['世界', '你好', 'mit österreich']

# Generated at 2022-06-23 19:14:51.875100
# Unit test for function print_debug_info
def test_print_debug_info():
    # No error should be raised
    print_debug_info(env=Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr))

# Generated at 2022-06-23 19:14:56.573439
# Unit test for function get_output_options
def test_get_output_options():
    request_message = requests.PreparedRequest()
    response_message = requests.Response()
    args = argparse.Namespace(output_options=[])
    print(get_output_options(args, request_message))
    print(get_output_options(args, response_message))



# Generated at 2022-06-23 19:15:08.866672
# Unit test for function get_output_options
def test_get_output_options():
    from argparse import Namespace
    from httpie.cli.definition import parser

    # Case1: args ["httpie", "-oh", "-oj", "http://127.0.0.1:5000/request/1"]
    parsed_args = parser.parse_args(["httpie", "-oh", "-oj", "http://127.0.0.1:5000/request/1"])
    assert get_output_options(parsed_args, requests.PreparedRequest()) == (True, True)
    assert get_output_options(parsed_args, requests.Response()) == (True, True)

    # Case2: args ["httpie", "-oh", "-ob", "http://127.0.0.1:5000/request/1"]

# Generated at 2022-06-23 19:15:21.057607
# Unit test for function get_output_options
def test_get_output_options():
    class Args:
        output_options = []

    msg = requests.PreparedRequest()
    assert get_output_options(Args(), msg) == (False, False)

    Args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(Args(), msg) == (True, False)

    Args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY]
    assert get_output_options(Args(), msg) == (True, True)

    msg = requests.Response()
    Args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY]
    assert get_output_options(Args(), msg) == (False, False)

    Args.output_options = [OUT_RESP_HEAD]

# Generated at 2022-06-23 19:15:33.053650
# Unit test for function decode_raw_args
def test_decode_raw_args():
    def is_bytes_list(args):
        return isinstance(args, list) and all(b.__class__.__name__ == 'bytes' for b in args)
    a = 'Héllo'
    b = b'H\xc3\xa9llo'
    # Python 3
    if sys.version_info >= (3, 0):
        args = [a, b]
        assert decode_raw_args(args, 'utf-8') == ['Héllo', 'Héllo']
        assert is_bytes_list(args)
        # Python 2
    else:
        args = [a, b]
        assert decode_raw_args(args, 'utf-8') == args
        assert is_bytes_list(args)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 19:15:44.932525
# Unit test for function main
def test_main():
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    import io

    args = ['http', '--pretty=none', 'GET', 'https://httpbin.org/get']

    ERROR_TOO_MANY_REDIRECTS = 'Too many redirects (--max-redirects=10).'

    # Default, real stdin/stdout/stderr.
    with_stdin_arg = args + ['/dev/stdin']
    assert main(args=with_stdin_arg) == ExitStatus.SUCCESS

    # Default, no arguments.
    assert main(args=[]) == ExitStatus.ERROR
    assert main(args=['--debug']) == ExitStatus.SUCCESS
    assert main(args=['--help']) == Exit

# Generated at 2022-06-23 19:15:49.536787
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        ['--form', 'foo=bar', 'baz=qux'],
        stdin_encoding='utf8'
    ) == ['--form', 'foo=bar', 'baz=qux']
    assert decode_raw_args(
        [b'--form', 'foo=bar', b'baz=qux'],
        stdin_encoding='utf8'
    ) == ['--form', 'foo=bar', 'baz=qux']

# Generated at 2022-06-23 19:16:00.986569
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        form=False,
        headers='',
        output_options=['h'],
        output_format='',
        output_file=None,
        output_file_specified=False,
        check_status=False,
        style='',
        style_sheet=False,
        pretty=0,
        download=False,
        download_resume=False,
        max_redirects=30,
        auth=False,
        timeout=None,
        verify=None,
        proxies=None,
        allow_redirects=None,
        follow=False,
        verbose=0,
        quiet=False,
        output_dir=None,
        insecure=False,
        traceback=False,
    )
    request = requests.PreparedRequest()
    request.headers

# Generated at 2022-06-23 19:16:11.476220
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from unittest.mock import call

    class Environment:
        def __init__(self):
            self.stdout = io.BytesIO()
            self.stderr = io.BytesIO()
            self.stdin_encoding = 'utf-8'

    env = Environment()
    args = parser.parse_args(args=[
        '--verbose',
        '--form',
        '--json',
        'foo=bar',
        'baz',
        'https://httpbin.org/get',
    ],
                              env=env)
    program(args=args, env=env)
    stdout = env.stdout.getvalue()
    assert b'"foo": "bar"' in stdout
    assert b'"baz"' in stdout

# Generated at 2022-06-23 19:16:14.451827
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    env = Environment(stdout=io.BytesIO(),
                      stderr=io.BytesIO())
    print_debug_info(env)
    assert env.stderr.getvalue()

# Generated at 2022-06-23 19:16:22.424751
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from httpie.cli.args import ASCII_ENCODING

    assert decode_raw_args([b'foo'], ASCII_ENCODING) == ['foo']
    assert decode_raw_args([b'foo', 'bar'], ASCII_ENCODING) == ['foo', 'bar']
    assert decode_raw_args(['foo', b'bar'], ASCII_ENCODING) == ['foo', 'bar']
    assert decode_raw_args(['foo', 'bar'], ASCII_ENCODING) == ['foo', 'bar']

# Generated at 2022-06-23 19:16:29.003759
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    env = Environment()
    env.stdout_isatty = True
    get_output_options(args=args, message=requests.PreparedRequest())
    main(['--debug'])
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 19:16:41.331315
# Unit test for function decode_raw_args
def test_decode_raw_args():
    b_args = [b'http']
    str_args = decode_raw_args(b_args, 'utf8')
    assert str_args == ['http']


if __name__ == '__main__':  # pragma: no cover
    try:
        exit_status = main()

    # NOTE: `SystemExit` is subclass of `Exception`,
    # so it's caught by the except clause below too.
    #
    # The empty `except:` clause is intentional here,
    # as we want to suppress all errors in the `finally` clause too.
    except SystemExit as e:
        exit_status = e.code

    except:
        print_debug_info(Environment())
        sys.exit(ExitStatus.ERROR)


# Generated at 2022-06-23 19:16:42.115948
# Unit test for function main
def test_main():
    print(main())

test_main()

# Generated at 2022-06-23 19:16:54.795370
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import sys
    import unittest

    from httpie.core import Environment
    from httpie.cli.constants import DEFAULT_CONFIG_DIR

    class DebugInfoTestCase(unittest.TestCase):

        def test_basic(self):
            stdout = io.StringIO()
            stderr = io.StringIO()
            env = Environment(
                stdin_isatty=True,
                stdin=io.StringIO('Hello\nWorld\n'),
                stdout=stdout,
                stderr=stderr,
                colors=256,
                config_dir=DEFAULT_CONFIG_DIR,
            )
            print_debug_info(env)
            sys.stdout.write(stderr.getvalue())

# Generated at 2022-06-23 19:16:59.640194
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=[b'x'], stdin_encoding='ascii') == ['x']
    assert decode_raw_args(args=['x'], stdin_encoding='ascii') == ['x']
    assert decode_raw_args(args=[b'\xe4'], stdin_encoding='utf-8') == ['ä']

# Generated at 2022-06-23 19:17:06.953869
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['Hello'], 'UTF-8') == ['Hello']
    assert decode_raw_args([b'Hello world!'], 'UTF-8') == ['Hello world!']
    assert decode_raw_args(['\x80\x81\x82'], 'UTF-8') == ['\uFFFD\uFFFD\uFFFD']
    assert decode_raw_args([b'\x80\x81\x82'], 'ascii') == ['\x80\x81\x82']

# Generated at 2022-06-23 19:17:17.647762
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser(
        prog='http',
        # this is required to pass the test,
        # even though the actual httpie's CLI doesn't have it
        allow_abbrev=False,
        description='HTTPie - a CLI, cURL-like tool for humans.',
    )
    parser.add_argument('--check-status', action='store_true')
    parser.add_argument('--download', action='store_true')
    parser.add_argument('--download-resume')
    parser.add_argument('--follow', action='store_true')
    parser.add_argument('--output-file')
    parser.add_argument('--output-file-specified', action='store_true')
    output_options_group = parser.add_mutually_exclusive_group(required=False)


# Generated at 2022-06-23 19:17:23.666711
# Unit test for function get_output_options
def test_get_output_options():
    class args:
        pass
    args.opt = [OUT_REQ_BODY, OUT_RESP_HEAD]
    assert (
        get_output_options(args, requests.PreparedRequest()) ==
        (False, True)
    )
    assert (
        get_output_options(args, requests.Response()) ==
        (True, False)
    )

# Generated at 2022-06-23 19:17:31.224322
# Unit test for function get_output_options
def test_get_output_options():
    class Test:
        output_options: str
        headers: bool
        body: bool


# Generated at 2022-06-23 19:17:34.971247
# Unit test for function print_debug_info
def test_print_debug_info():
	env = Environment()
	debugInfo = print_debug_info(env)
	env.stderr.write(debugInfo)

if __name__ == '__main__':
    status = main()
    sys.exit(status.value)

# Generated at 2022-06-23 19:17:39.874506
# Unit test for function get_output_options
def test_get_output_options():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-v', '--verbose', action='store_true')
    parser.add_argument('--print', dest='output_options', action='append_const', const=OUT_RESP_HEAD)
    parser.add_argument('--print-body', dest='output_options', action='append_const', const=OUT_RESP_BODY)
    parser.add_argument('--print-headers', dest='output_options', action='append_const', const=OUT_RESP_HEAD)
    parser.add_argument('--print-request-body', dest='output_options', action='append_const', const=OUT_REQ_BODY)

# Generated at 2022-06-23 19:17:47.283444
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import unittest
    from unittest.mock import patch

    from httpie.context import Environment

    class Test_print_debug_info(unittest.TestCase):
        def test_print_debug_info(self):
            with patch.object(Environment, '__repr__', return_value='Test repr'):
                with patch('sys.stderr', new_callable=io.StringIO) as mock_stderr:
                    print_debug_info(Environment())
                    self.assertIn('Test repr', mock_stderr.getvalue())

# Generated at 2022-06-23 19:17:52.896950
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[OUT_REQ_HEAD])
    req_msg = requests.PreparedRequest()
    assert get_output_options(args, req_msg) == (True, False)
    resp_msg = requests.Response()
    assert get_output_options(args, resp_msg) == (False, False)


# Generated at 2022-06-23 19:17:55.262573
# Unit test for function main
def test_main():
    try:
        main(args=['http', 'https://httpie.org'])
    except SystemExit as e:
        assert e.code == 0



# Generated at 2022-06-23 19:18:00.575769
# Unit test for function program
def test_program():
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    env = Environment()
    url = 'https://www.microsoft.com/'
    args = parse_args(['get', url], env)
    exit_code = program(args, env)
    assert exit_code == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:18:03.338617
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['12', b'\xe2\x82\xac'], 'UTF-8') == ['12', '€']



# Generated at 2022-06-23 19:18:09.925624
# Unit test for function get_output_options
def test_get_output_options():
    env = Environment()
    args = argparse.Namespace()
    args.output_options = [ OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY ]
    response = requests.Request( 'GET', 'http://httpbin.org/status/500' ).prepare()
    request_options = get_output_options(args, response)
    assert not request_options[0] and request_options[1]
    response = requests.get( 'http://httpbin.org/status/500' )
    response_options = get_output_options(args, response)
    assert response_options[0] and response_options[1]

# Generated at 2022-06-23 19:18:16.154477
# Unit test for function get_output_options
def test_get_output_options():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-options', type=str, help='Output options')
    args = parser.parse_args(['--output-options', 'hH'])
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)
    assert get_output_options(args, requests.Response()) == (True, True)

# Generated at 2022-06-23 19:18:22.539605
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[OUT_REQ_HEAD, OUT_REQ_BODY])
    message = requests.PreparedRequest()
    assert (True, True) == get_output_options(args=args, message=message)

    args = argparse.Namespace(output_options=[OUT_RESP_HEAD, OUT_RESP_BODY])
    message = requests.Response()
    assert (True, True) == get_output_options(args=args, message=message)

test_get_output_options()

# Generated at 2022-06-23 19:18:28.781463
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    env = Environment(stdin=io.BytesIO(), stdin_isatty=True, stdout=io.BytesIO(), stdout_isatty=False,
                      stderr=io.BytesIO(), stderr_isatty=False)
    print_debug_info(env)
    assert env.stderr.getvalue().startswith('HTTPie ')

# Generated at 2022-06-23 19:18:31.143690
# Unit test for function program
def test_program():
    args = ['--form', 'filename@-', 'https://httpbin.org/anything']
    env = Environment()
    assert program(args=args, env=env) == 0

# Generated at 2022-06-23 19:18:35.877099
# Unit test for function get_output_options
def test_get_output_options():
    basic_args = argparse.Namespace()
    output_options_list = [
        OUT_REQ_HEAD,
        OUT_REQ_BODY,
        OUT_RESP_HEAD,
        OUT_RESP_BODY,
    ]
    for option in output_options_list:
        basic_args.output_options = [option]
        for request in [requests.PreparedRequest(), requests.Response()]:
            assert get_output_options(basic_args, request) == (option[:4] == "req-", option[:5] == "resp-")

# Generated at 2022-06-23 19:18:37.572990
# Unit test for function main
def test_main():
    args = ['--debug']

    main(args=args)



# Generated at 2022-06-23 19:18:45.475053
# Unit test for function program
def test_program():
    class Args():
        def __init__(self):
            self.headers = None
            self.output_options = None
            self.follow = None
            self.check_status = None
            self.quiet = None
            self.output_file = None
            self.output_file_specified = None

    args = Args()
    env = Environment()
    args.headers = None
    args.output_options = None
    args.follow = None
    args.check_status = None
    args.quiet = None
    args.output_file = None
    args.output_file_specified = None

    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:18:51.845042
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # gzip encoding
    stdin_encoding = 'utf-8'
    args = ['http', b'\xe9']
    args_decoded = decode_raw_args(args=args, stdin_encoding=stdin_encoding)
    assert args_decoded == ['http', 'é']