

# Generated at 2022-06-23 19:08:54.986058
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[OUT_REQ_HEAD, OUT_RESP_BODY])
    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (True, False)

    args = argparse.Namespace(output_options=[OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY])
    message = requests.Response()
    assert get_output_options(args, message) == (True, True)

# Generated at 2022-06-23 19:08:56.497278
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    assert 'HTTPie {httpie_version}' in env.stderr.getvalue()

# Generated at 2022-06-23 19:09:07.908067
# Unit test for function print_debug_info
def test_print_debug_info():
    class DummyFile:
        def __init__(self):
            self.lines = []

        def write(self, data):
            self.lines.append(data)

        def writelines(self, lines):
            for line in lines:
                self.write(line)

    f = DummyFile()
    e = Environment(
        stdin=DummyFile(),
        stdout=DummyFile(),
        stderr=f,
        stdout_isatty=False,
        stdin_encoding='UTF-8',
        stdin_isatty=False,
        config_dir=None,
        colors=None,
        defaults=None,
        default_options=None,
        config=None,
        args=None,
    )
    print_debug_info(env=e)
    assert f

# Generated at 2022-06-23 19:09:15.575517
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO

    env = Environment()
    env.stderr = StringIO()
    print_debug_info(env)
    env.stderr.seek(0)
    expected = [
        f'HTTPie {httpie_version}\n',
        f'Requests {requests_version}\n',
        f'Pygments {pygments_version}\n',
        f'Python {platform.python_version()}\n{sys.executable}\n',
        f'{platform.system()} {platform.release()}',
    ]
    assert env.stderr.readlines() == expected
    env.stderr.close()

# Generated at 2022-06-23 19:09:28.493270
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_UA
    from httpie.plugins.builtin import HTTPBasicAuth
    import io
    import unittest
    stdout = io.StringIO()
    stderr = io.StringIO()
    stdin = io.StringIO()
    env = Environment(
        stdin=stdin,
        stdout=stdout,
        stderr=stderr,
        config_dir=None,
        config_path=None,
        env=None,
        output_file=None,
        is_windows=None
    )
    test_arguments = ['httpie', 'GET', 'http://localhost:8080']
    assert main(args=test_arguments, env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:09:37.409588
# Unit test for function program
def test_program():
    class mockEnv():
        def __init__(self):
            self.log_file = WriteCapture()
            self.debug = False
            self.request_config = {}
            self.stdin = None
            self.stdin_isatty = True
            self.stdin_encoding = 'utf-8'
            self.stdout = WriteCapture()
            self.stdout_isatty = True
            self.stdout_color = True
            self.stdout_file = None
            self.stderr = WriteCapture()
            self.stderr_color = True
            self.stderr_file = None
            self.config = {}
            self.config_dir = None
            self.color_scheme = None
            self.headers = []
            self.ignore_stdin = False

# Generated at 2022-06-23 19:09:44.006751
# Unit test for function decode_raw_args
def test_decode_raw_args():
    def assert_decoded(args, expected, *, stdin_encoding):
        args = [
            str(arg)
            if type(arg) is not bytes else arg
            for arg in args
        ]
        result = decode_raw_args(args, stdin_encoding)
        assert result == expected

    def assert_decoded_ascii(args, expected):
        assert_decoded(args, expected, stdin_encoding='cp1252')
        assert_decoded(args, expected, stdin_encoding='utf-8')

    assert_decoded([b'a', 'b'], ['a', 'b'], stdin_encoding='cp1252')
    assert_decoded([b'a', 'b'], ['a', 'b'], stdin_encoding='utf-8')
   

# Generated at 2022-06-23 19:09:47.492720
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from unittest.mock import patch
    from httpie.context import Environment
    env = Environment()
    env.stderr = StringIO()
    # shoudld not be empty
    assert env.stderr.getvalue() == ""
    print_debug_info(env)
    assert env.stderr.getvalue() != ""

# Generated at 2022-06-23 19:09:54.650243
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr.writelines = mock.MagicMock()
    env.stderr.write = mock.MagicMock()
    print_debug_info(env)
    assert env.stderr.writelines.call_count == 1
    assert env.stderr.write.call_count == 6
    assert env.stderr.write.call_args_list[1][0][0] == 'HTTPie {httpie_version}\n'
    assert env.stderr.write.call_args_list[1][0][0].format(httpie_version=httpie_version)
    assert env.stderr.write.call_args_list[2][0][0] == 'Requests {requests_version}\n'
    assert env.stderr.write.call_

# Generated at 2022-06-23 19:09:58.337962
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    # TODO: better testing
    env.stderr.write("\n")

if __name__ == '__main__':
    from httpie.debug import enable_dev_mode
    enable_dev_mode()
    exit(main())

# Generated at 2022-06-23 19:10:07.719871
# Unit test for function main
def test_main():
    # TODO: (a) Finish unit tests. (b) Add pytest unit tests. See https://github.com/httpie/httpie/issues/891.
    import argparse
    import io

    def make_args(args_list):
        parser = argparse.ArgumentParser(prog='http')
        parser.add_argument('-v', '--verbose', action='store_true')
        parser.add_argument('--foo', dest='foo')
        parsed_args = parser.parse_args(args_list)
        parsed_args.is_input_file_path = lambda: False
        parsed_args.is_output_file_path = lambda: False
        return parsed_args


# Generated at 2022-06-23 19:10:12.649563
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    message = requests.PreparedRequest()
    options = get_output_options(args, message)
    assert options == (OUT_REQ_HEAD in args.output_options, OUT_REQ_BODY in args.output_options)


# Generated at 2022-06-23 19:10:13.502801
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)

# Generated at 2022-06-23 19:10:15.977799
# Unit test for function program
def test_program():
    assert program(args=['--debug'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--generate-config'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:10:20.760996
# Unit test for function main
def test_main():
    sys.argv = ["httpie.py", "--json", "GET", "https://api.github.com/users/joaquimserafim"]
    sys.exit(main())


# Generated at 2022-06-23 19:10:28.995348
# Unit test for function program
def test_program():
    import sys, io
    class TestEnv(Environment):
        def __init__(self):
            super().__init__()
            self.stdin = io.StringIO()
            self.stdout = io.StringIO()
            self.stderr = io.StringIO()

    env = TestEnv()
    args = []
    output = program(args, env)
    assert env.stdout.getvalue() == "[]"
    env.stdout.truncate(0)
    env.stdout.seek(0)
    args = ["https://httpie.org"]
    output = program(args, env)

# Generated at 2022-06-23 19:10:38.715741
# Unit test for function main
def test_main():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.config import Config
    from httpie.output.formatters.colors import NO_STYLE
    from httpie.output.streams import StdIOStreamWrapper
    from httpie.plugins import builtin
    from httpie.session import Session
    from httpie import cli, config
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.compat import is_windows
    from httpie.status import ExitStatus
    from httpie.cli.definition import parser
    from httpie.config import Config
    from httpie.context import Environment
    from httpie import __version__ as httpie_version

# Generated at 2022-06-23 19:10:40.020749
# Unit test for function main
def test_main():
    sys.exit(main())


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:10:48.581922
# Unit test for function decode_raw_args
def test_decode_raw_args():
    def decode(args):
        return decode_raw_args(args, 'iso-8859-1')

    assert decode(['-v', b'GET']) == ['-v', 'GET']
    assert decode(['-v', 'GET']) == ['-v', 'GET']
    assert decode([b'-v', b'GET']) == ['-v', 'GET']
    assert decode([b'-v', 'GET']) == ['-v', 'GET']

if __name__ == '__main__':
    sys.exit(int(main()))

# Generated at 2022-06-23 19:10:57.331194
# Unit test for function program
def test_program():
    from tests.mock import mock_env
    from httpie.cli.definition import parser
    from httpie.client import FakeStdin
    from httpie.core import main
    import io
    parser.prog = 'http'

    # test for --headers
    env = mock_env()
    env.stdin = FakeStdin(b"GET http://httpbin.org/ip")
    args = parser.parse_args(args=['--headers'], env=env)

# Generated at 2022-06-23 19:10:58.848788
# Unit test for function main
def test_main():
   assert main(['--debug']) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:11:07.364324
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.argtypes import OutputOptions
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-options", type=OutputOptions(), default=None)
    parser.add_argument("--quiet", action='store_true')
    request = requests.PreparedRequest()
    response = requests.Response()
    args = parser.parse_args(['--output-options=hbB', '--quiet'])
    assert get_output_options(args,request) == (True, False)
    assert get_output_options(args,response) == (False, True)


# Generated at 2022-06-23 19:11:16.409718
# Unit test for function get_output_options
def test_get_output_options():
	args = []
	request = requests.PreparedRequest()
	options = get_output_options(args, request)
	assert options[0] == False
	assert options[1] == False

	args.append(OUT_REQ_HEAD)
	args.append(OUT_REQ_BODY)
	options = get_output_options(args, request)
	assert options[0] == True
	assert options[1] == True

	response = requests.Response()
	options = get_output_options(args, response)
	assert options[0] == False
	assert options[1] == False


# Generated at 2022-06-23 19:11:20.963315
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # given
    stdin_encoding = 'latin'
    args = ['test', '100']

    # when
    result = decode_raw_args(args, stdin_encoding)

    # then
    assert result == args

# Generated at 2022-06-23 19:11:22.646668
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'--form'], 'ascii') == ['--form']



# Generated at 2022-06-23 19:11:28.977923
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://github.com','--form','a=b'])
    msg = KeyValueArg('a=b').convert(None, 'a', args, None)
    assert get_output_options(args, msg) == (True, True)
    msg = requests.PreparedRequest()
    assert get_output_options(args, msg) == (True, False)
    msg = requests.Response()
    assert get_output_options(args, msg) == (True, True)

# Generated at 2022-06-23 19:11:41.721154
# Unit test for function program
def test_program():
    env = Environment()
    request= requests.PreparedRequest()
    request.headers = {"X-Foo":"Bar", "Content-Type": "application/json"}
    request.body = "Hello world"
    initial_request = request
    args = argparse.Namespace(json="")
    response = requests.Response()
    response.status_code = 200
    response.raw = requests.packages.urllib3.response.HTTPResponse()
    response.raw.version = 11
    response.raw.status = 200
    response.raw.reason = "OK"
    response.raw.version = 11
    response.raw._method = "GET"
    response.raw.is_redirect = True
    response.raw._original_response = responses.BaseResponse()

# Generated at 2022-06-23 19:11:52.794573
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    response = requests.Response()
    response.is_redirect = True
    response.body = 'test'
    parsed_args = parser.parse_args(['https://www.example.com', '-f'])
    program(args=parsed_args, env=Environment(config=None, stdout=None, stderr=None))
    msg = requests.PreparedRequest()
    msg.is_body_upload_chunk = True
    msg.body = b'test'
    msg.headers = 'test'
    assert write_message(requests_message=msg, env=None, args=None, with_body=True, with_headers=False)
    assert write_stream(stream=b'test', outfile=None, flush=False)

# Generated at 2022-06-23 19:11:58.862619
# Unit test for function main
def test_main():
    import os
    import pickle
    import sys
    import builtins
    args = ['http', '--form', 'POST', 'http://httpbin.org/post']
    main(args, env=builtins.env)
    assert builtins.env.last_http_status == 200
    assert type(builtins.env.last_http_status) == int
    assert builtins.env.output_file.closed

# Generated at 2022-06-23 19:12:07.692585
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['x'], 'utf-8') == ['x']
    assert decode_raw_args([b'x'], 'utf-8') == ['x']
    assert decode_raw_args([b'\xe4'], 'utf-8') == ['ä']
    assert decode_raw_args([b'\xe4'], 'latin1') == ['ã']
    assert decode_raw_args([b'\xe4'], 'utf-16') == ['\ufffe\xe4']

# Generated at 2022-06-23 19:12:16.532882
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser
    from httpie.output.writer import MESSAGE_SEPARATOR_BYTES
    from httpie.output.formatters import get_formatter
    from httpie.context import Environment
    '''
    class LogCapture:
        def __init__(self, separator=MESSAGE_SEPARATOR_BYTES):
            self._buffer = []
            self.separator = separator

        def write(self, msg):
            self._buffer.append(msg)

        def flush(self):
            pass

        def getvalue(self):
            return self.separator.join(self._buffer)
    '''
    args = parser.parse_args(['http', 'localhost:3333'])
    env = Environment(stdin_encoding='utf8')

# Generated at 2022-06-23 19:12:21.685983
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = ['-b']
    message = requests.Response()
    assert get_output_options(args, message) == (True, False)
    args.output_options = ['-B']
    message = requests.Response()
    assert get_output_options(args, message) == (False, True)
    args.output_options = ['-h']
    message = requests.Response()
    assert get_output_options(args, message) == (True, False)
    args.output_options = ['-H']
    message = requests.Response()
    assert get_output_options(args, message) == (False, False)
    args.output_options = ['--verbose']
    message = requests.Response()
    assert get_output_options(args, message)

# Generated at 2022-06-23 19:12:32.360885
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'foo'], 'UTF-8') == ['foo']
    assert decode_raw_args([b'bar'], 'windows-1252') == ['bar']
    assert decode_raw_args([b'baz'], 'ascii') == ['baz']
    assert decode_raw_args([b'qux'], 'ascii') == ['qux']
    assert decode_raw_args([b'foo', b'bar', u'baz'], 'UTF-8') == ['foo', 'bar', 'baz']
    assert decode_raw_args([u'foo', b'bar', 'baz'], 'UTF-8') == ['foo', 'bar', 'baz']

# Generated at 2022-06-23 19:12:41.605935
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a', 'b', 'c'], 'utf-8') == ['a', 'b', 'c']
    if sys.version_info >= (3, 0):
        assert decode_raw_args([b'a', 'b', 'c'], 'utf-8') == ['a', 'b', 'c']
        assert decode_raw_args(['a', b'b', 'c'], 'utf-8') == ['a', 'b', 'c']
        assert decode_raw_args(['a', 'b', b'c'], 'utf-8') == ['a', 'b', 'c']

# Generated at 2022-06-23 19:12:54.312177
# Unit test for function print_debug_info
def test_print_debug_info():
    class dummy_stderr:
        content = None
        def writelines(self, x):
            self.content = ''.join(x)
    stderr = dummy_stderr()
    print_debug_info(Environment(stderr=stderr))
    assert stderr.content.find('HTTPie') != -1
    assert stderr.content.find('Requests') != -1
    assert stderr.content.find('Pygments') != -1
    assert stderr.content.find('Python') != -1
    assert stderr.content.find('config_dir') != -1
    assert stderr.content.find('ConfigFile') != -1
    assert stderr.content.find('stdin_isatty') != -1

# Generated at 2022-06-23 19:12:59.365678
# Unit test for function program
def test_program():
    out = StringIO()
    sys.stdout = out
    args = ['-f', 'https://google.com']
    program(args)
    output = out.getvalue().strip()
    print(output)
    assert output == 'HTTP/1.1 200 OK'

# Generated at 2022-06-23 19:13:04.055202
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options=[OUT_REQ_HEAD, OUT_RESP_BODY],
    )
    request = requests.PreparedRequest()
    head, body = get_output_options(args, request)
    assert head
    assert not body
    response = requests.Response()
    head, body = get_output_options(args, response)
    assert not head
    assert body

# Generated at 2022-06-23 19:13:06.175543
# Unit test for function print_debug_info
def test_print_debug_info():
    try:
        raise Exception
    except Exception:
        print_debug_info('env')

# Generated at 2022-06-23 19:13:16.768072
# Unit test for function program
def test_program():
    assert main(["http", "http://localhost:8081/get", "--json", "-v"]) == 0
    assert main(["http", "http://localhost:8081/get", "--headers", "-v"]) == 0
    assert main(["http", "http://localhost:8081/get", "-h", "-v"]) == 0
    assert main(["http", "http://localhost:8081/get", "--body", "-v"]) == 0
    assert main(["http", "http://localhost:8081/get", "--json", "--output", "output.json"]) == 0
    assert main(["http", "http://localhost:8081/get", "--download", "output.json"]) == 0

# Generated at 2022-06-23 19:13:21.250131
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options=[OUT_REQ_BODY, OUT_RESP_BODY]
    )
    assert get_output_options(args, requests.PreparedRequest()) == (False, True)
    assert get_output_options(args, requests.Response()) == (False, True)



# Generated at 2022-06-23 19:13:26.437074
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([
        b'--form',
        'user=John',
        b'--auth',
        'dev:secret'
    ],
        'utf8'
    ) == [
            '--form',
            'user=John',
            '--auth',
            'dev:secret'
    ]

# Generated at 2022-06-23 19:13:37.403507
# Unit test for function program
def test_program():
    class MockEnv(Environment):
        def __init__(self):
            self.stdout = io.BytesIO()
        def __repr__(self):
            return '<MockEnv()>'
    
    class MockArgs:
        def __init__(self):
            self.check_status = True
            self.quiet = False
            self.output_options = ['all']
            self.follow = True
            self.headers = 'accept-encoding: gzip, deflate'
            self.download = False
            self.download_resume = False
            self.output_file = None
            self.output_file_specified = False
        def __repr__(self):
            return '<MockArgs()>'
        

# Generated at 2022-06-23 19:13:48.700739
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(stdin=None, stdout=None, stderr=None, config_dir=None)
    env.debug = False
    env.stdin = None
    real_stderr = sys.stderr
    fake_stderr = StringIO()
    sys.stderr = fake_stderr
    print_debug_info(env)
    sys.stderr = real_stderr

# Generated at 2022-06-23 19:13:52.876221
# Unit test for function main
def test_main():
    import pytest
    from httpie.core import main as httpie

    with pytest.raises(SystemExit):
        httpie()

    with pytest.raises(SystemExit):
        httpie('--debug')

# Generated at 2022-06-23 19:14:01.432513
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = []
    msg = requests.PreparedRequest()
    assert (True, True) == get_output_options(args, msg)
    args.output_options.append(OUT_REQ_HEAD)
    args.output_options.append(OUT_REQ_BODY)
    assert (True, True) == get_output_options(args, msg)
    args.output_options.remove(OUT_REQ_BODY)
    args.output_options.append(OUT_RESP_BODY)
    assert (False, False) == get_output_options(args, msg)
    args.output_options.append(OUT_RESP_HEAD)
    assert (False, False) == get_output_options(args, msg)
    msg = requests.Response

# Generated at 2022-06-23 19:14:07.197136
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = ['h', 'b']
    message1 = requests.PreparedRequest()
    message2 = requests.Response()
    result1 = get_output_options(args, message1)
    result2 = get_output_options(args, message2)
    assert result1 == (True, True)
    assert result2 == (True, True)

# Generated at 2022-06-23 19:14:11.043224
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([
        b'http',
        b'--json',
        b'--verbose',
        b'request_ok'
    ], 'ascii') == ['http', '--json', '--verbose', 'request_ok']

# Generated at 2022-06-23 19:14:12.083925
# Unit test for function program
def test_program():
    pass

# Generated at 2022-06-23 19:14:22.417278
# Unit test for function program

# Generated at 2022-06-23 19:14:33.361128
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options = [OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY]
    )
    request = requests.PreparedRequest()
    response = requests.Response()

    with_headers, with_body = get_output_options(args, request)
    assert with_headers and with_body
    with_headers, with_body = get_output_options(args, response)
    assert with_headers and with_body

    args = argparse.Namespace(
        output_options = [OUT_REQ_HEAD, OUT_RESP_HEAD, OUT_RESP_BODY]
    )
    with_headers, with_body = get_output_options(args, request)
    assert with_headers and not with_

# Generated at 2022-06-23 19:14:41.671528
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=['vb', 'H', 'B'])

    assert get_output_options(args, requests.PreparedRequest()) == \
           (True, True)

    args.output_options = ['']
    assert get_output_options(args, requests.Response()) == \
           (False, False)

    args.output_options = ['B']
    assert get_output_options(args, requests.Response()) == \
           (False, True)

    args.output_options = ['H', 'B']
    assert get_output_options(args, requests.Response()) == \
           (True, True)


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 19:14:44.654497
# Unit test for function decode_raw_args
def test_decode_raw_args():
    """Test case for function decode_raw_args"""
    assert decode_raw_args(["http", "www.example.com"], "utf-8") == ["http", "www.example.com"]

# Generated at 2022-06-23 19:14:53.183926
# Unit test for function main
def test_main():
    """
    Pytest unit test for function main
    """
    from httpie.cli.parser import default_options
    from httpie.cli.definition import parser, parser_args
    from httpie.config import get_config, get_default_config_dir
    # Test 1
    env = Environment()
    # Test 1.1
    args = ["httpie"]
    exit_status = main(args, env)
    assert exit_status == ExitStatus.ERROR
    # Test 1.2
    args = ["httpie", "--version"]
    exit_status = main(args, env)
    assert exit_status == ExitStatus.SUCCESS
    # Test 1.3
    args = ["httpie", "--debug"]
    exit_status = main(args, env)
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-23 19:15:05.263523
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'\xd0\x94\xd0\xbe\xd0\xb1\xd1\x80\xd1\x8b\xd0\xb9', 'hello', 'world'], 'cp1251') == ['Добрый', 'hello', 'world']
    assert decode_raw_args(['hello', b'\xe4\xbd\xa0\xe5\xa5\xbd', 'world'], 'utf-8') == ['hello', '你好', 'world']
    assert decode_raw_args([b'\xd0\x94\xd0\xbe\xd0\xb1\xd1\x80\xd1\x8b\xd0\xb9'], 'cp1251') == ['Добрый']

# Generated at 2022-06-23 19:15:09.323634
# Unit test for function main
def test_main():
    initial_args = sys.argv
    try:
        sys.argv = ['http']
        request_args = main()
        assert request_args == sys.argv
    finally:
        sys.argv = initial_args


# Generated at 2022-06-23 19:15:10.436731
# Unit test for function main
def test_main():
    main(args=['httpie', '--debug'])

# Generated at 2022-06-23 19:15:15.764064
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from httpie.core import main
    try:
        main('http httpbin.org/bytes/[1-4]'.encode('utf-8').split())
    except SystemExit:
        pass


if __name__ == '__main__':
    try:
        exit_status = main()
    except UnicodeDecodeError:
        # Workaround for https://bugs.python.org/issue18378
        # Python 3.7 at least returns the wrong exit status in this scenario.
        exit_status = ExitStatus.ERROR
    sys.exit(exit_status)

# Generated at 2022-06-23 19:15:25.087612
# Unit test for function program
def test_program():
    from httpie.cli.argtypes import KeyValueArg
    def args(*kv_args: str) -> KeyValueArg:
        return KeyValueArg(kv_args, 'headers/data/json') 
    try:
        program(args = parser.parse_args(['--check-status', 'https://www.httpbin.org/get'], env=Environment()), env=Environment())
    except SystemExit:
        pass
    assert program(args = parser.parse_args(['https://www.httpbin.org/get'], env=Environment()), env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:15:26.400811
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:15:34.344669
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = [b'foo', 'bar', b'baz']
    decoded_args = decode_raw_args(args, sys.stdin.encoding)
    assert type(decoded_args[0]) is str
    assert type(decoded_args[1]) is str
    assert type(decoded_args[2]) is str
    assert decoded_args[0] == 'foo'
    assert decoded_args[1] == 'bar'
    assert decoded_args[2] == 'baz'


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 19:15:42.052913
# Unit test for function main
def test_main():
    import io

    stdout = io.BytesIO()
    stderr = io.BytesIO()
    exit_status = main(args=['/dev/null', '-v', 'GET', 'https://www.google.com'], env=Environment(stdout=stdout, stderr=stderr))

    assert exit_status == 0
    assert b'HTTP/' in stdout.getvalue()
    assert stderr.getvalue() == b''



# Generated at 2022-06-23 19:15:50.062191
# Unit test for function get_output_options
def test_get_output_options():
    import argparse
    args = argparse.Namespace()
    args.output_options = [OUT_RESP_BODY,OUT_RESP_HEAD,OUT_REQ_BODY,OUT_REQ_HEAD]
    class request_head:
        headers = {}
        class raw:
             status = '200'
             reason = 'OK'
    class request_body:
        headers = {}
        body = 'hello'
    class request_head_and_body:
        headers = {}
        body = 'hello'
        class raw:
             status = '200'
             reason = 'OK'
    class response_body:
        headers = {}
        body = 'hello'
        status_code = '200'
    class response_body_and_head:
        headers = {}
        body = 'hello'
        status

# Generated at 2022-06-23 19:15:56.911182
# Unit test for function program
def test_program():
    import argparse
    args = [ 'https://pypi.org/pypi/httpie/json', '-h', 'test:test' ]
    parser = argparse.ArgumentParser()
    parser.add_argument('url')
    parser.add_argument('-h','--headers')
    program(args=parser.parse_args(args), env=Environment())

# Generated at 2022-06-23 19:15:59.616802
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'hello'], 'utf-8') == ['hello']
    assert decode_raw_args([b'\xe2\x98\x83'], 'utf-8') == ['☃']

# Generated at 2022-06-23 19:16:10.948992
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=['hHB'])

    def test_tuple(expected_result: Tuple[bool, bool], message: Union[requests.PreparedRequest, requests.Response]):
        actual_result = get_output_options(args, message)
        assert expected_result == actual_result

    test_tuple(expected_result=(True, True), message=requests.PreparedRequest())
    test_tuple(expected_result=(True, True), message=requests.Response())

    args.output_options.remove('h')
    test_tuple(expected_result=(False, True), message=requests.PreparedRequest())
    test_tuple(expected_result=(False, True), message=requests.Response())

    args.output_options.remove('B')
    test_

# Generated at 2022-06-23 19:16:13.920654
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    out = StringIO()
    env = Environment(stdout=out)
    print_debug_info(env)
    print(out.getvalue())

# Generated at 2022-06-23 19:16:17.997257
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=[b'\x80a'], stdin_encoding='utf8') == ['\ufffda']


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:16:25.529649
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = []
    # args is of type argparse.Namespace
    # args.output_options is of type list
    msg = requests.PreparedRequest()
    assert get_output_options(args=args, message=msg) == (False, False)

    args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(args=args, message=msg) == (True, False)

    args.output_options = [OUT_REQ_BODY]
    assert get_output_options(args=args, message=msg) == (False, True)

    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY]

# Generated at 2022-06-23 19:16:33.756892
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(stdout=BytesIO(), stderr=BytesIO())
    print_debug_info(env)
    stderr_output = env.stderr.getvalue().strip().decode('utf8').split('\n')
    assert stderr_output[0].startswith('HTTPie ')
    assert stderr_output[1].startswith('Requests ')
    assert stderr_output[2].startswith('Pygments ')
    assert stderr_output[3].startswith('Python ')
    assert stderr_output[4].endswith('python')
    assert stderr_output[5].startswith('Darwin ')
    assert len(stderr_output) == 6
    assert not env.stdout.getvalue().strip()

# Generated at 2022-06-23 19:16:39.625965
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['foo'], stdin_encoding='utf8') == ['foo']
    assert decode_raw_args([b'foo'], stdin_encoding='utf8') == ['foo']
    assert decode_raw_args([b'\xe4\xb8\xad'], stdin_encoding='utf8') == ['中']

# Generated at 2022-06-23 19:16:41.563205
# Unit test for function program
def test_program():
    args = ["--check-status"]
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:16:54.181576
# Unit test for function get_output_options
def test_get_output_options():
    # Arrange
    class MockArguments(object):
        def __init__(self):
            self.output_options = ['--verbose']
    args = MockArguments()

    class MockRequest(object):
        def __init__(self):
            self.headers = {
                'content-type': 'application/json; charset=UTF-8',
            }
    request = MockRequest()

    class MockResponse(object):
        def __init__(self):
            self.headers = {
                'content-type': 'text/html; charset=utf-8',
            }
    response = MockResponse()

    # Act
    with_headers_request, with_body_request = get_output_options(
        args=args,
        message=request
    )

    with_headers_response, with_body_

# Generated at 2022-06-23 19:16:56.880189
# Unit test for function main
def test_main():
    try:
        main(['http', '--json', '-H', 'Accept: application/json', 'https://httpie.org/get'])
        assert True
    except Exception:
        assert False


# Generated at 2022-06-23 19:17:04.809390
# Unit test for function get_output_options
def test_get_output_options():
    class DummyRequest:
        def __init__(self):
            self.headers = {}
        is_body_upload_chunk = False
        body = b'body'
    class DummyResponse:
        def __init__(self):
            self.headers = {}
        status_code = 200
    class DummyArguments:
        def __init__(self):
            self.headers = {}
            self.output_options = [b'n']
            self.output_file = b'n'
            self.download = False

    request = DummyRequest()
    assert get_output_options(DummyArguments(), request) == (False, False)
    request.headers['HTTPie-test-header'] = 'test'
    request.headers['Content-Type'] = 'test'

# Generated at 2022-06-23 19:17:12.538733
# Unit test for function get_output_options
def test_get_output_options():
    class Request:
        headers = {}
        body = ''

    print(get_output_options(argparse.Namespace(output_options='Hh'), Request()))
    print(get_output_options(argparse.Namespace(output_options='h'), Request()))
    print(get_output_options(argparse.Namespace(output_options='H'), Request()))
    print(get_output_options(argparse.Namespace(output_options='b'), Request()))
    print(get_output_options(argparse.Namespace(output_options='B'), Request()))
    print(get_output_options(argparse.Namespace(output_options='n'), Request()))
    print(get_output_options(argparse.Namespace(output_options='v'), Request()))


# Generated at 2022-06-23 19:17:22.953678
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from tests.httpie.compat import is_py2
    from httpie.compat import b, s

    if is_py2:
        assert decode_raw_args(
            args=['GET', b('http://example.com'), 'b=c'],
            stdin_encoding='utf8'
        ) == [b('GET'), s('http://example.com'), 'b=c']
    else:
        assert decode_raw_args(
            args=['GET', b('http://example.com'), 'b=c'],
            stdin_encoding='utf8'
        ) == ['GET', 'http://example.com', 'b=c']

# Generated at 2022-06-23 19:17:26.551302
# Unit test for function main
def test_main():
    from httpie import cli
    status = main(['--debug', '--pretty=none', '--output=json', 'http://httpbin.org/headers'])
    assert status == cli.ExitStatus.SUCCESS

# Generated at 2022-06-23 19:17:32.822842
# Unit test for function decode_raw_args
def test_decode_raw_args():
    """
    Function test_decode_raw_args()
    """
    stdin_encoding = "ascii"
    test_list = decode_raw_args(['h', 'e', 'l', 'l', 'o'],
                                stdin_encoding)
    assert test_list == ['h', 'e', 'l', 'l', 'o']

# Generated at 2022-06-23 19:17:43.260678
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser
    # test for response
    args = parser.parse_args(['https://httpbin.org/get','-j'])
    print (get_output_options(args=args, message=requests.Response()))
    #test for request
    args = parser.parse_args(['https://httpbin.org/get','-b'])
    print (get_output_options(args=args, message=requests.PreparedRequest()))

#traceback.format_exc()
#sys.exit(int(ExitStatus.SUCCESS))
#sys.exit(int(ExitStatus.ERROR_TIMEOUT))

# Generated at 2022-06-23 19:17:44.190805
# Unit test for function program
def test_program():
    assert 0==ExitStatus.SUCCESS

# Generated at 2022-06-23 19:17:55.345162
# Unit test for function get_output_options
def test_get_output_options():
    try:
        from httpie.cli.parser import parse_args
    except ImportError:
        raise RuntimeError('httpie must be installed for running the unit tests.')

    args = parse_args(args=[])
    assert get_output_options(args=args, message=requests.PreparedRequest()) == (True, True)
    assert get_output_options(args=args, message=requests.Response()) == (False, False)

    args = parse_args(args=['--verbose'])
    assert get_output_options(args=args, message=requests.PreparedRequest()) == (True, True)
    assert get_output_options(args=args, message=requests.Response()) == (True, True)

    args = parse_args(args=['--print', 'Bb'])
    assert get_

# Generated at 2022-06-23 19:18:06.547042
# Unit test for function program
def test_program():
    import pytest
    import argparse
    import requests
    import os
    import platform
    import sys
    from typing import List, Optional, Tuple, Union
    def main(args: List[Union[str, bytes]] = sys.argv, env=Environment()) -> ExitStatus:
        """
        The main function.

        Pre-process args, handle some special types of invocations,
        and run the main program with error handling.

        Return exit status code.

        """
        program_name, *args = args
        env.program_name = os.path.basename(program_name)
        args = decode_raw_args(args, env.stdin_encoding)
        plugin_manager.load_installed_plugins()

        from httpie.cli.definition import parser


# Generated at 2022-06-23 19:18:16.205266
# Unit test for function get_output_options
def test_get_output_options():
    class FakeArgs:
        def __init__(self, output_options):
            self.output_options = output_options
        def __getitem__(self, item):
            return self.output_options[item]

    fakeargs = FakeArgs([OUT_REQ_BODY])
    msg = requests.Response()
    assert get_output_options(fakeargs, msg) == (False, True)

    fakeargs = FakeArgs([OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD])
    msg = requests.PreparedRequest()
    assert get_output_options(fakeargs, msg) == (True, True)

# Generated at 2022-06-23 19:18:19.708508
# Unit test for function program
def test_program():
    # TODO: Rewrite this test.
    # test_program() is a super-quick and dirty test
    # to make sure the imports don't explode when run as module.

    args = program([
        '--pretty', 'all',
        'https://httpbin.org/get',
    ])
    assert args == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:18:21.514637
# Unit test for function main
def test_main():
    assert 0 == main([])
    assert 0 == main(['--help'])
    assert 0 == main(['--version'])

# Generated at 2022-06-23 19:18:32.264332
# Unit test for function get_output_options
def test_get_output_options():
    import os
    import requests

    import httpie.cli.definition
    parser = httpie.cli.definition.parser
    env = httpie.context.Environment()
    args = parser.parse_args('--output-options=none'.split(), env=env)

    msg = requests.PreparedRequest()
    assert get_output_options(args, msg) == (False, False)

    msg = requests.PreparedRequest()
    msg.headers = {"X-Secret": "42"}
    assert get_output_options(args, msg) == (False, False)

    args = parser.parse_args('--output-options=headers'.split(), env=env)

    msg = requests.PreparedRequest()
    assert get_output_options(args, msg) == (True, False)

    msg = requests.PreparedRequest()
    msg

# Generated at 2022-06-23 19:18:41.469057
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'foo', b'bar'], 'utf-8') == ['foo', 'bar']
    from collections.abc import Iterable
    assert isinstance(decode_raw_args([iter([b'foo', b'bar'])], 'utf-8'), Iterable)
    assert isinstance(decode_raw_args([iter([b'foo', b'bar'])], 'utf-8'), list)
    assert decode_raw_args(iter([b'foo', b'bar']), 'utf-8') == ['foo', 'bar']

# Generated at 2022-06-23 19:18:50.134935
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=["req_body","resp_body"])
    prepared_request = requests.PreparedRequest()
    from httpie.output.writer import write_message
    with_headers, with_body = get_output_options(args=args, message=prepared_request)
    assert with_headers == False
    assert with_body == True
    response = requests.Response()
    with_headers, with_body = get_output_options(args=args, message=response)
    assert with_headers == False
    assert with_body == True