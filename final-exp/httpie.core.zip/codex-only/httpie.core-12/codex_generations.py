

# Generated at 2022-06-23 19:09:03.483955
# Unit test for function get_output_options
def test_get_output_options():
    class Test_args(object):
        def __init__(self):
            self.output_options = list()
    args = Test_args()
    args.output_options = [OUT_REQ_HEAD,OUT_REQ_BODY]
    # for requests.PreparedRequest
    is_req_head, is_req_body = get_output_options(args,requests.PreparedRequest())
    assert (is_req_head == True)
    assert (is_req_body == True)
    # for requests.Response
    is_resp_head, is_resp_body = get_output_options(args,requests.Response())
    assert (is_resp_head == False)
    assert (is_resp_body == False)

# Generated at 2022-06-23 19:09:09.571069
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr = StringIO()
    print_debug_info(env)
    assert env.stderr.getvalue() == 'HTTPie 1.0.3\nRequests 2.24.0\nPygments 2.7.2\nPython 3.7.6\n/usr/bin/python3.7\nLinux 4.19.114'

# Generated at 2022-06-23 19:09:10.738396
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'-'], 'utf8') == ['-']


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:09:11.580212
# Unit test for function program
def test_program():
    env = Environment()
    args = ['--debug']
    program(args, env)


# Generated at 2022-06-23 19:09:20.497051
# Unit test for function print_debug_info
def test_print_debug_info():
    def run(env, stdin_encoding, program_name, *args):
        old_stdout, old_stderr = sys.stdout, sys.stderr
        sys.stdout = StringIO()
        sys.stderr = StringIO()
        try:
            main(
                args=[program_name] + list(args),
                env=env,
            )
            return sys.stdout.getvalue(), sys.stderr.getvalue()
        finally:
            sys.stdout, sys.stderr = old_stdout, old_stderr

    # For some reason in pytest this func is executed multiple times, and the global variables
    # are kept in memory, so we need to clear them manually.
    from httpie.context import Environment
    from httpie.cli.constants import COLOR_

# Generated at 2022-06-23 19:09:22.009233
# Unit test for function print_debug_info
def test_print_debug_info():
    assert True

# Generated at 2022-06-23 19:09:30.992977
# Unit test for function print_debug_info
def test_print_debug_info():
    """To test function print_debug_info"""
    import io
    import sys
    sys.stdout=sys.stderr=io.StringIO()
    print_debug_info(Environment())
    test_output=sys.stdout.getvalue()
    sys.stdout=sys.__stdout__
    sys.stderr=sys.__stderr__
    assert ('HTTPie' in test_output)
    assert ('Requests' in test_output)
    assert ('Pygments' in test_output)
    assert ('Python' in test_output)
    assert ('\n\n' in test_output)



# Generated at 2022-06-23 19:09:39.143371
# Unit test for function program
def test_program():
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.definition import parser
    from httpie.client import collect_messages
    from collections import namedtuple
    from httpie.plugins.builtin import HTTPBasicAuth
    import tempfile
    import random
    import time

    # Create random filename
    TEST_FILENAME = ''.join(random.choice('0123456789ABCDEF') for i in range(8))
    TEST_FILENAME = f'TestFile_{TEST_FILENAME}.tmp'

    # Create request body
    TEST_REQUEST_BODY = 'Hello World!'

    # Create an argument object
    matched_args = parser._match_argument('header', 'hello:world')
    key_value_arg = KeyValueArgType()(matched_args[0])
   

# Generated at 2022-06-23 19:09:48.296111
# Unit test for function main
def test_main():
    assert main(['http']) == ExitStatus.ERROR
    assert main(['http', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--help']) == ExitStatus.SUCCESS
    assert main(['http', '--version']) == ExitStatus.SUCCESS
    assert main(['http', '--output-file=httpie.log', 'httpie.org']) == ExitStatus.SUCCESS
    assert main(['http', '--check-status', 'httpie.org']) == ExitStatus.SUCCESS
    assert main(['http', '--check-status' '-f', 'httpie.org']) == ExitStatus.SUCCESS
    assert main(['http', '--download', '--output=httpie.log', 'httpie.org']) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:09:50.284149
# Unit test for function print_debug_info
def test_print_debug_info():
    print_debug_info(Environment())

# Generated at 2022-06-23 19:09:57.074834
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([], 'utf8') == []
    assert decode_raw_args(['x'], 'utf8') == ['x']
    assert decode_raw_args([b'x'], 'utf8') == ['x']
    assert decode_raw_args([b'\xe5'], 'latin1') == ['å']
    assert decode_raw_args(['x', b'y', b'\xe5'], 'utf8') == ['x', 'y', 'å']

# Generated at 2022-06-23 19:10:06.221784
# Unit test for function program
def test_program():
    env = Environment()

# Generated at 2022-06-23 19:10:13.566082
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = ['h','b','vb','hb','v','q','c','s','all','vh','vb','B','H','hb','hB']
    message_req = requests.PreparedRequest()
    message_res = requests.Response()
    assert get_output_options(args, message_req) == (True, True)
    assert get_output_options(args, message_res) == (True, True)


# Generated at 2022-06-23 19:10:21.345828
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        args=['--form', b'a=b', 'c=d'],
        stdin_encoding='utf8',
    ) == ['--form', 'a=b', 'c=d']


if __name__ == '__main__':
    sys.exit(main(sys.argv, Environment()))

# Generated at 2022-06-23 19:10:23.964861
# Unit test for function decode_raw_args
def test_decode_raw_args():
    """ py.test unit test for function decode_raw_args """

    assert decode_raw_args([bytes('aaa', 'utf-8'), 'bbb'], 'utf-8') == ['aaa', 'bbb']

# Generated at 2022-06-23 19:10:27.848167
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import io
    bs = io.BytesIO(b'--form asd=qwe')
    result=decode_raw_args(bs.read().split(b' '),stdin_encoding='ascii')
    assert result[0]=='--form' and result[1]=='asd=qwe'

# Generated at 2022-06-23 19:10:31.783936
# Unit test for function get_output_options
def test_get_output_options():
    test_request = requests.PreparedRequest()
    output_options = get_output_options(test_request, OUT_REQ_BODY)
    assert(output_options == (True, False))

    test_response = requests.Response()
    output_options = get_output_options(test_response, OUT_RESP_BODY)
    assert(output_options == (False, True))

# Generated at 2022-06-23 19:10:40.873156
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = []
    # Request
    msg = requests.PreparedRequest()
    assert get_output_options(args, msg) == (True, True)
    args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(args, msg) == (True, False)
    args.output_options = [OUT_REQ_BODY]
    assert get_output_options(args, msg) == (False, True)
    # Response
    msg = requests.Response()
    assert get_output_options(args, msg) == (True, True)
    args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(args, msg) == (False, True)

# Generated at 2022-06-23 19:10:53.068285
# Unit test for function main
def test_main():
    from io import StringIO
    from httpie.cli import env, main, program
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.tests.utils import http, HTTP_OK
    from httpie.cli import parser
    from httpie.cli.argtypes import KeyValue
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.constants import DEFAULT_CONFIG_DIR

    args = ['--debug', '--download']

# Generated at 2022-06-23 19:11:04.610201
# Unit test for function main
def test_main():
    from httpie import ExitStatus
    from httpie.context import Environment

    def test_it(argv, stdin=b'', env=Environment(), exit_status=ExitStatus.SUCCESS):
        argv = [b'http'] + argv
        env.stdout.seek(0)
        env.stdout.truncate()
        env.stderr.seek(0)
        env.stderr.truncate()
        env.stdin = io.BytesIO(stdin)
        actual_exit_status = main(argv, env=env)
        assert actual_exit_status == exit_status
        return (
            env.stdout.getvalue().decode('utf8'),
            env.stderr.getvalue().decode('utf8'),
        )


# Generated at 2022-06-23 19:11:07.579174
# Unit test for function program
def test_program():
    """
    Unit test for function program
    """

    class DummyEnv(Environment):
        pass

    env = DummyEnv()
    args = ['greeting', "michael"]
    status = program(args, env)
    assert status == 0

    args = ['greeting', "-p", "age", "18"]
    status = program(args, env)
    assert status == 0

# Generated at 2022-06-23 19:11:16.409572
# Unit test for function print_debug_info
def test_print_debug_info():
    class FakeStream:
        def __init__(self):
            self.data = []

        def write(self, s):
            self.data.append(s)

        def get(self):
            return ''.join(self.data)
    env = Environment()
    env.stderr = FakeStream()
    print_debug_info(env)
    s = env.stderr.get()
    assert 'HTTPie' in s
    assert 'Requests' in s
    assert 'Pygments' in s
    assert 'Python' in s
    assert '~/.httpie' in s



# Generated at 2022-06-23 19:11:26.541428
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'foo', 'bar'], 'utf8') == ['foo', 'bar']
    assert decode_raw_args([b'foo', 'bar'], 'latin1') == ['foo\udcff', 'bar']
    # On Windows, the first command-line argument is the path to `http` executable.
    # http://stackoverflow.com/q/2598185/
    assert decode_raw_args([b'C:/Program Files/httpie/http'], 'utf8') == [r'C:/Program Files/httpie/http']
    assert decode_raw_args([b'C:/Program Files/httpie/http', 'bar'], 'utf8') == [r'C:/Program Files/httpie/http', 'bar']

# Generated at 2022-06-23 19:11:38.698878
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.headers = None
    args.ignore_stdin = False
    args.method = 'GET'
    args.timeout = 20
    args.auth = ('user', 'pass')
    args.max_redirects = 10
    args.download = False
    args.check_status = True
    args.follow = False
    args.download_resume = False
    args.output_file = None
    args.output_file_specified = False
    args.output_options = OUT_RESP_BODY
    args.url = 'https://github.com'
    env = Environment()


# Generated at 2022-06-23 19:11:46.555047
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace(url="http://localhost:8000", method="GET", headers={}, data={}, files={}, auth=(),
                              auth_type="basic", download=True, output_options=[], output_file=None,
                              output_file_specified=True, output_format="colors", download_resume=True,
                              max_redirects=10, timeout=None, check_status=True, quiet=False, follow=True)
    assert program(args, env) == 0


# Generated at 2022-06-23 19:11:47.627514
# Unit test for function print_debug_info
def test_print_debug_info():
    assert print_debug_info(arg)

# Generated at 2022-06-23 19:11:48.689601
# Unit test for function main
def test_main():
	print(main())


# Generated at 2022-06-23 19:11:53.084979
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    env = Environment()
    env.stderr = io.StringIO()
    print_debug_info(env)
    assert env.stderr.getvalue().startswith('HTTPie')
    assert httpie_version in env.stderr.getvalue()



# Generated at 2022-06-23 19:11:59.790749
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['foo'], 'utf-8') == ['foo']
    assert decode_raw_args([b'foo'], 'utf-8') == ['foo']
    assert decode_raw_args([b'foo', 'bar'], 'utf-8') == ['foo', 'bar']
    assert decode_raw_args([b'foo', u'bar', b'baz'], 'utf-8') == ['foo', 'bar', 'baz']

# Generated at 2022-06-23 19:12:09.362381
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import get_parser
    from httpie.cli.parser import env, config_dir, stdin_encoding
    from httpie.context import Environment

    parser = get_parser()
    args, _ = parser.parse_known_args(["-v"], env=env, config_dir=config_dir, stdin_encoding=stdin_encoding)
    req = requests.PreparedRequest()
    resp = requests.Response()
    assert get_output_options(args, req) == (False, True)
    assert get_output_options(args, resp) == (False, True)

# Generated at 2022-06-23 19:12:17.266101
# Unit test for function get_output_options
def test_get_output_options():
    request = requests.Request('GET', 'https://www.google.com')
    ret = get_output_options(argparse.Namespace(output_options=[
                                    'request_headers',
                                    'response_body']), request)
    assert ret == (True, False)

    ret = get_output_options(argparse.Namespace(output_options=[
                                    'request_body',
                                    'request_headers',
                                    'response_body']), request)
    assert ret == (True, False)

    response = requests.Response()
    response.status_code = 200
    ret = get_output_options(argparse.Namespace(output_options=[
                                    'request_headers',
                                    'response_body']), response)
    assert ret == (False, True)
    ret = get_output_options

# Generated at 2022-06-23 19:12:21.121736
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr = io.StringIO()
    print_debug_info(env)
    env.stderr.seek(0)
    print(env.stderr.read())

# Generated at 2022-06-23 19:12:23.812099
# Unit test for function main
def test_main():
    main_environment = main(["httpie", "--version"])
    assert main_environment == 0

# Generated at 2022-06-23 19:12:24.499601
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 19:12:28.409293
# Unit test for function program
def test_program():
    args = ['http', '--help']
    env = Environment()
    response = program(args, env)
    print('Response: ', response)
    assert response == ExitStatus.SUCCESS

if __name__ == '__main__':
    test_program()

# Generated at 2022-06-23 19:12:40.922864
# Unit test for function get_output_options
def test_get_output_options():
    for output_options in [[], [OUT_RESP_HEAD], [OUT_RESP_BODY]]:
        assert get_output_options(output_options, requests.PreparedRequest()) == (False, False)
        assert get_output_options(output_options, requests.Response()) == (False, False)
    for output_options in [[OUT_REQ_HEAD], [OUT_REQ_BODY]]:
        assert get_output_options(output_options, requests.PreparedRequest()) == (True, False)
        assert get_output_options(output_options, requests.Response()) == (False, False)

# Generated at 2022-06-23 19:12:53.884129
# Unit test for function get_output_options
def test_get_output_options():
    import unittest.mock
    args = unittest.mock.Mock()
    args.output_options = [OUT_REQ_BODY, OUT_RESP_HEAD]
    assert get_output_options(args=args, message=requests.PreparedRequest()) == (False, True)
    assert get_output_options(args=args, message=requests.Response()) == (True, False)
    args.output_options = [OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_HEAD, OUT_RESP_BODY]
    assert get_output_options(args=args, message=requests.PreparedRequest()) == (True, True)
    assert get_output_options(args=args, message=requests.Response()) == (True, True)
    args.output_

# Generated at 2022-06-23 19:13:03.571050
# Unit test for function program
def test_program():
    stdout_bytes = b""
    stdout_isatty = False
    class Stdout:
        def write(self, arg):
            nonlocal stdout_bytes
            stdout_bytes += arg
        def isatty(self):
            return stdout_isatty
    env = Environment()
    env.stdout = Stdout()
    args = argparse.Namespace()
    args.output_options = ["H"]
    with open("test.txt", "rb") as f:
        args.data = [f]
        assert program(args=args, env=env) == ExitStatus.SUCCESS
        print("\n")
        print(stdout_bytes)

# Generated at 2022-06-23 19:13:08.165867
# Unit test for function program
def test_program():
    exit_status = program(['https://httpie.org/doc'])
    if exit_status == ExitStatus.SUCCESS:
        print('SUCCESS')
    else:
        print('ERROR')
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:13:12.466118
# Unit test for function program
def test_program():

    from argparse import Namespace
    from httpie.cli.definition import parser as req_parser
    from httpie.context import Environment
    from httpie.status import http_status_to_exit_status, ExitStatus

    args = req_parser.parse_args([
        '--verbose',
        '--print',
        'BhF=',
        'https://httpbin.org/post'
    ])

    env = Environment()

    exit_status, exit_status_hostname_failed = None, None
    try:
        exit_status = program(
            args=args,
            env=env
        )
    except:
        pass


# Generated at 2022-06-23 19:13:16.983280
# Unit test for function program
def test_program():


    env = Environment()

    args = ['http', '127.0.0.1:5000/']

    #print(args)
    #print(env.program_name)
    #assert main(args, env) == 0
    #print(type(env(main(args, env))))
    #print(main(args, env))



# Generated at 2022-06-23 19:13:18.217720
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stdout.write('test123\n')

# Generated at 2022-06-23 19:13:27.162943
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.status import ExitStatus
    from pytest_httpie.httpbin import HTTPBIN_CLIENT
    import io

    env = Environment()
    args = parser.parse_args([
        'https://httpbin.org/get',
        '--check-status',
        '--headers',
        'foo:bar',
        'Content-Type:application/json',
        'Accept:text/plain',
        '--form',
        'text=foo',
        'string=',
        'empty=None',
    ], env=env)
    assert env.stdout_isatty
    assert not env.is_windows


# Generated at 2022-06-23 19:13:37.898889
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from pytest import raises
    from hypothesis import given
    from hypothesis.strategies import binary, text
    from httpie.cli.constants import DEFAULT_CLI_ENCODING

    def generate_args():
        yield ['hello', b'world']
        yield [b'hello', 'world']
        yield [b'hello', b'world']

    @given(binary(encoding=DEFAULT_CLI_ENCODING))
    def test_invalid_raw_bytes_args(arg: bytes):
        with raises(UnicodeDecodeError):
            decode_raw_args([arg], DEFAULT_CLI_ENCODING)


# Generated at 2022-06-23 19:13:49.038246
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    msg = requests.PreparedRequest()
    assert get_output_options(args, msg) == (True, True)
    args.output_options = [OUT_REQ_BODY]
    assert get_output_options(args, msg) == (True, True)
    args.output_options = [OUT_RESP_HEAD]
    assert get_output_options(args, msg) == (False, False)
    msg = requests.Response()
    assert get_output_options(args, msg) == (True, False)
    args.output_options = [OUT_RESP_HEAD, OUT_RESP_BODY]
    assert get_output_options(args, msg) == (True, True)
    args.output_options = []

# Generated at 2022-06-23 19:13:59.928272
# Unit test for function program
def test_program():
    import requests
    class MockStdout:
        def __init__(self):
            self.output = []
        
        def write(self, data):
            self.output.append(data)
        
        def read(self):
            return "".join(self.output)

    class MockArgs:
        output_file = MockStdout()
        output_file_specified = True

        def __init__(self, headers, check_status, quiet, follow, output_options):
            self.headers = headers
            self.check_status = check_status
            self.quiet = quiet
            self.follow = follow
            self.output_options = output_options

    class MockRequest:
        def __init__(self, url, method):
            self.url = url
            self.method = method
    

# Generated at 2022-06-23 19:14:09.954000
# Unit test for function get_output_options
def test_get_output_options():
    req = argparse.Namespace()
    req.output_options = []
    options = get_output_options(req, requests.PreparedRequest())
    assert(options == (False, False))
    req.output_options = [OUT_REQ_HEAD]
    options = get_output_options(req, requests.PreparedRequest())
    assert(options == (True, False))
    req.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY]
    options = get_output_options(req, requests.PreparedRequest())
    assert(options == (True, True))
    req.output_options = [OUT_RESP_HEAD]
    options = get_output_options(req, requests.Response())
    assert(options == (True, False))

# Generated at 2022-06-23 19:14:17.234396
# Unit test for function program
def test_program():
    env = Environment(
        stdin=io.BytesIO(),
        stdin_isatty=True,
        stdout=io.BytesIO(),
        stdout_isatty=True,
        stderr=io.BytesIO()
    )
    args = parser.parse_args(args=['https://httpie.org/test'], env=env)
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:14:24.617135
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import sys

    env = Environment()
    env.stderr = io.StringIO()

    print_debug_info(env)

    debug_info = env.stderr.getvalue()
    assert 'HTTPie ' in debug_info
    assert 'Requests ' in debug_info
    assert 'Pygments ' in debug_info
    assert 'Python ' in debug_info
    assert sys.version in debug_info
    assert sys.executable in debug_info

# Generated at 2022-06-23 19:14:27.048567
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'-'], stdin_encoding='utf-8') == ['-']

# Generated at 2022-06-23 19:14:36.201839
# Unit test for function program
def test_program():
    try:
        import requests_mock
    except ImportError:
        return None
    # Start with --download
    with requests_mock.Mocker() as m:
        session = requests.Session()
        session.max_redirects = 0
        m.get('http://httpbin.org/redirect/5', text='', status_code=302,
              additional_matcher=lambda request: request.method != 'HEAD')
        m.get('http://httpbin.org/redirect/5', text='Hello world!', status_code=200,
              additional_matcher=lambda request: request.method == 'HEAD')
        args = ['--check-status', '--max-redirects=3', '--method=HEAD', 'http://httpbin.org/redirect/5']

# Generated at 2022-06-23 19:14:41.577266
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=['\u2603'], stdin_encoding='utf8') == ['\u2603']
    assert decode_raw_args(args=['\u2603'], stdin_encoding='ascii') == ['\u2603']
    assert decode_raw_args(args=['é'], stdin_encoding='utf8') == ['é']
    assert decode_raw_args(args=['é'], stdin_encoding='ascii') == ['é']

# Generated at 2022-06-23 19:14:50.417034
# Unit test for function decode_raw_args
def test_decode_raw_args():
    if os.name != 'nt':
        assert decode_raw_args([b'http://example.com/\xe4\xf6\xfc'], 'utf-8') == ['http://example.com/\u00e4\u00f6\u00fc']
        assert decode_raw_args([b'http://example.com/\xc3\xa4\xc3\xb6\xc3\xbc'], 'utf-8') == ['http://example.com/\u00e4\u00f6\u00fc']
        assert decode_raw_args(['http://example.com/\u00e4\u00f6\u00fc'], 'utf-8') == ['http://example.com/\u00e4\u00f6\u00fc']
    else:
        assert decode_

# Generated at 2022-06-23 19:14:58.120305
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=[b'--help'], stdin_encoding='utf-8') == ['--help']
    assert decode_raw_args(args=[b'\xe2\x98\x80', '--help'], stdin_encoding='utf-8') == ['☀', '--help']
    assert decode_raw_args(args=[b'\xe2\x98\x80', '--help'], stdin_encoding='latin-1') == ['Âª', '--help']

# Generated at 2022-06-23 19:15:03.496992
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = ['http', '--json', b'{"a":"\xd0\xb1\xd0\xb2"}']
    decoded_args = decode_raw_args(args, 'utf8')
    assert decoded_args == ['http', '--json', '{"a":"бв"}']

# Generated at 2022-06-23 19:15:13.863901
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['foo'], 'utf-8') == ['foo']
    assert decode_raw_args([b'foo'], 'utf-8') == ['foo']
    assert decode_raw_args([b'foo', 'bar'], 'utf-8') == ['foo', 'bar']
    assert decode_raw_args(['foo', b'bar'], 'utf-8') == ['foo', 'bar']
    assert decode_raw_args([b'foo', b'bar'], 'utf-8') == ['foo', 'bar']
    assert decode_raw_args([b'\xe2\x9d\xa4', 'bar'], 'utf-8') == ['♥', 'bar']

# Generated at 2022-06-23 19:15:19.768694
# Unit test for function main
def test_main():
    def mock_program(args: argparse.Namespace, env: Environment) -> ExitStatus:
        return ExitStatus.SUCCESS

    program_ = main
    main_ = main
    main = mock_program
    try:
        assert main_(args=[], env=Environment()) == ExitStatus.SUCCESS
    finally:
        program, main = program_, main_

# Generated at 2022-06-23 19:15:21.665128
# Unit test for function decode_raw_args
def test_decode_raw_args():
    """
    Unit test for function decode_raw_args
    """
    assert decode_raw_args([b'\xe7\xb2\xbe\xe7\xae\x80', b'HTTPie'], 'utf-8') == [
        '精简', 'HTTPie']

# Generated at 2022-06-23 19:15:32.785721
# Unit test for function program
def test_program():
    from httpie import Environment
    import tempfile
    import os
    import shutil
    my_temp_dir = tempfile.mkdtemp()
    args = parser.parse_args(args=['www.google.com', '-o', 'my_output'], env=Environment(directory=my_temp_dir))
    if os.path.isfile('my_output'):
        os.remove('my_output')
    program(args, Environment())
    assert os.path.isfile('my_output')
    os.remove('my_output')
    program(args, Environment(color=0))
    assert os.path.isfile('my_output')
    os.remove('my_output')
    shutil.rmtree(my_temp_dir)

# Generated at 2022-06-23 19:15:44.724901
# Unit test for function program
def test_program():
    class Args:
        headers = None
        output_options = None
        output_file = None
        output_file_specified = None
        check_status = None
        follow = None
        quiet = None
        download = None
        download_resume = None
        def __init__(self):
            self.headers = []
            self.output_options = []
            self.output_file = None
            self.output_file_specified = None
            self.check_status = None
            self.follow = None
            self.quiet = None
            self.download = None
            self.download_resume = None
    class Environment:
        stdout = None
        stderr = None
        log_error = None
        stdout_isatty = None

# Generated at 2022-06-23 19:15:51.283869
# Unit test for function get_output_options
def test_get_output_options():
    assert get_output_options(argparse.Namespace(output_options=[]), requests.Response()) == (False, False)
    assert get_output_options(argparse.Namespace(output_options=[OUT_RESP_HEAD]), requests.Response()) == (True, False)
    assert get_output_options(argparse.Namespace(output_options=[OUT_RESP_BODY]), requests.Response()) == (False, True)
    assert get_output_options(argparse.Namespace(output_options=[OUT_REQ_HEAD]), requests.PreparedRequest()) == (True, False)
    assert get_output_options(argparse.Namespace(output_options=[OUT_REQ_BODY]), requests.PreparedRequest()) == (False, True)

# Generated at 2022-06-23 19:15:53.296498
# Unit test for function print_debug_info
def test_print_debug_info():
    class MockStdStream:
        def close(self):
            pass

        def write(self, x):
            return x

    from httpie.context import Environment
    env = Environment(stdin=MockStdStream(), stdout=MockStdStream(), stderr=MockStdStream())
    print_debug_info(env)

# Generated at 2022-06-23 19:16:02.359019
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a'], 'ascii') == ['a']
    assert decode_raw_args(['a'], 'utf-8') == ['a']
    assert decode_raw_args([b'a'], 'ascii') == ['a']
    assert decode_raw_args([b'a'], 'utf-8') == ['a']
    assert decode_raw_args([b'\xe4'], 'utf-8') == ['ä']
    assert decode_raw_args([b'\xc3\xa4'], 'utf-8') == ['ä']
    assert decode_raw_args([b'\xe4'], 'iso-8859-1') == ['ä']

# Generated at 2022-06-23 19:16:10.000466
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options = [OUT_REQ_HEAD,OUT_REQ_BODY])
    print(get_output_options(args,requests.PreparedRequest()))
    print(get_output_options(args,requests.Response()))
    args = argparse.Namespace(output_options = [OUT_REQ_HEAD])
    print(get_output_options(args,requests.PreparedRequest()))
    print(get_output_options(args,requests.Response()))

# Generated at 2022-06-23 19:16:14.445460
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'abc', '123'], 'utf-8') == ['abc', '123']
    assert decode_raw_args([b'abc', '123'], 'utf-8') == ['abc', '123']
    assert decode_raw_args([b'abc', '123'], 'utf-8') == ['abc', '123']
    assert decode_raw_args([b'abc', '123'], 'klingon') == ['abc', '123']

# Generated at 2022-06-23 19:16:21.073740
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = ['http', '--json', b'{"k":"v"}', 'http://example.org/']
    decoded_args = decode_raw_args(args=args, stdin_encoding='utf-8')
    assert decoded_args == [
        'http',
        '--json',
        '{"k":"v"}',
        'http://example.org/'
    ]

# Generated at 2022-06-23 19:16:26.651752
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a', 'b'], 'utf8') == ['a', 'b']
    assert decode_raw_args([b'a', 'b'], 'utf8') == ['a', 'b']
    assert decode_raw_args([b'a', 'b'], 'latin1') == ['a', 'b']
    assert decode_raw_args(['a', b'b'], 'utf8') == ['a', 'b']
    assert decode_raw_args(['a', b'b'], 'latin1') == ['a', 'b']
    assert decode_raw_args([b'a', b'b'], 'utf8') == ['a', 'b']



# Generated at 2022-06-23 19:16:29.304851
# Unit test for function main
def test_main():
    assert main(['http', 'w3.org']) is ExitStatus.SUCCESS

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:16:41.434024
# Unit test for function get_output_options
def test_get_output_options():
    args_dict = {
        'output_options': [],
        'output_options_delimiter': ',',
    }
    args = argparse.Namespace(**args_dict)

    assert get_output_options(args, requests.PreparedRequest()) == (False, False)
    assert get_output_options(args, requests.Response()) == (False, False)
    
    args_dict_1 = {
        'output_options': [OUT_REQ_HEAD, OUT_RESP_BODY],
        'output_options_delimiter': ';',
    }
    args_1 = argparse.Namespace(**args_dict_1)

    assert get_output_options(args_1, requests.PreparedRequest()) == (True, False)

# Generated at 2022-06-23 19:16:48.019967
# Unit test for function decode_raw_args
def test_decode_raw_args():
    try:
        test_str = 'tes\xc7\xc8\xc9t'.encode('utf-8')
    except NameError:
        # python3
        test_str = b'tes\xc7\xc8\xc9t'
    expected_str = 'tes\u0107\u0108\u0109t'
    assert decode_raw_args([test_str]) == [expected_str]

# Generated at 2022-06-23 19:16:55.564594
# Unit test for function get_output_options
def test_get_output_options():
    env = Environment()
    args = argparse.Namespace(
        output_options=['all'],
    )
    message_request = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args=args, message=message_request)
    assert with_headers
    assert with_body
    message_response = requests.Response()
    with_headers, with_body = get_output_options(args=args, message=message_response)
    assert with_headers
    assert with_body

# Generated at 2022-06-23 19:17:01.893894
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options = [OUT_REQ_BODY, OUT_RESP_BODY])
    message1 = requests.PreparedRequest()
    message2 = requests.Response()
    h1, b1 = get_output_options(args, message1)
    h2, b2 = get_output_options(args, message2)
    assert(h1 == False and b1 == True and h2 == False and b2 == True)


# Generated at 2022-06-23 19:17:03.755724
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'\xe2\x82\xac'], 'utf-8') == ['€']

# Generated at 2022-06-23 19:17:11.965703
# Unit test for function main
def test_main():
    import sys
    import unittest
    class TestStringMethods(unittest.TestCase):
        def test_main(self):
            main(args=["--traceback", "--body", "--check-status", "--debug", "--download", "--download-resume", "--follow", "-f", "-h", "-p", "-v", "--verbose", "-", "https://httpie.org"], env=Environment())
            main(args=["--traceback", "--body", "--check-status", "--debug", "--download", "--download-resume", "--follow", "-f", "-h", "-p", "-v", "--verbose", "--output", "file", "-", "https://httpie.org"], env=Environment())

# Generated at 2022-06-23 19:17:16.908066
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[OUT_REQ_HEAD, OUT_RESP_BODY])
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)
    assert get_output_options(args, requests.Response()) == (False, True)

# Generated at 2022-06-23 19:17:20.202798
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    env = Environment()
    exit_status=program(args, env)
    assert exit_status==ExitStatus.SUCCESS


# Generated at 2022-06-23 19:17:27.032036
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # assert that function returns the same input arg list
    # if all args are str
    arg_list = ['arg1', 'arg2', 'arg3']
    result = decode_raw_args(arg_list, "utf-8")
    assert arg_list is result
    # assert that function return decoded arg list
    # if an arg is bytes
    arg_list = ['arg1', 'arg2', b'arg3']
    result = decode_raw_args(arg_list, "utf-8")
    expected = ['arg1', 'arg2', 'arg3']
    assert result == expected

# Generated at 2022-06-23 19:17:30.318397
# Unit test for function decode_raw_args
def test_decode_raw_args():
    stdin_encoding = 'utf-8'
    assert decode_raw_args([b'http', 'example.org'], stdin_encoding) == ['http', 'example.org']

# Generated at 2022-06-23 19:17:43.314970
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # start with a default encoding and decode bytes to a string
    r = decode_raw_args(['o'], 'utf-8')
    assert r == ['o']
    r = decode_raw_args(['o'.encode('utf-8')], 'utf-8')
    assert r == ['o']
    # replace the default encoding with one that will not work
    r = decode_raw_args(['o'], 'utf-32')
    assert r == ['o']
    r = decode_raw_args(['o'.encode('utf-8')], 'utf-32')
    assert r[0] == 'o'
    # don't decode the first argument, which is the program name
    r = decode_raw_args([sys.executable, 'o'], 'utf-8')
    assert r[0] == sys

# Generated at 2022-06-23 19:17:53.128602
# Unit test for function main
def test_main():
    from io import StringIO
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie import ExitStatus
    from httpie.cli import env, parser
    env.config = parser.get_config(config_dir=DEFAULT_CONFIG_DIR)
    env.stdin_encoding = 'utf8'
    env.stdout = StringIO()
    env.stderr = StringIO()
    assert main(args=['', 'http://httpbin.org/'], env=env) == ExitStatus.SUCCESS
    # assert env.stdout.getvalue() == '\n'

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 19:17:54.114024
# Unit test for function program
def test_program():
    return main()

# Generated at 2022-06-23 19:18:02.931875
# Unit test for function get_output_options
def test_get_output_options():
    class PreppedRequest:
        headers = {}

    class Response:
        headers = {}

    class Args:
        output_options = []

    for which, message in [('request', PreppedRequest()), ('response', Response())]:
        for output_options in [[], [f'out_{which}_head'], [f'out_{which}_body'],
                               [f'out_{which}_head', f'out_{which}_body']]:
            args = Args()
            args.output_options = output_options
            assert get_output_options(args, message) == (output_options != [], output_options != [])

# Generated at 2022-06-23 19:18:06.397498
# Unit test for function get_output_options
def test_get_output_options():
    class Args:
        output_options = []

    msg = requests.PreparedRequest()
    assert get_output_options(Args(), msg) == (True, False)

    msg = requests.Response()
    assert get_output_options(Args(), msg) == (True, False)

# Generated at 2022-06-23 19:18:13.459514
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie import cli
    from httpie.plugins.builtin import HTTPBasicAuth

    env = Environment()
    args = parser.parse_args(['--debug', '--follow', '--auth=user:password',
                              'http://httpbin.org/basic-auth/user/password'], env=env)
    assert cli.main(args=args, env=env)

# Generated at 2022-06-23 19:18:23.119692
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import textwrap
    output = io.StringIO()
    print_debug_info(env=Environment(stderr=output))

# Generated at 2022-06-23 19:18:33.592178
# Unit test for function print_debug_info
def test_print_debug_info():
    class FakeFileObject:
        def __init__(self):
            self.content = []

        def writelines(self, lines: List[Union[str, bytes]]):
            self.content.extend(lines)

        def write(self, content: str):
            self.content.append(content)

    class FakeEnv:
        def __init__(self):
            self.stderr = FakeFileObject()
            self.stdin_encoding = 'utf-8'

        def __repr__(self):
            return '<FakeEnv>'

    env = FakeEnv()
    print_debug_info(env)

    assert env.stderr.content[0].startswith('HTTPie ')
    assert env.stderr.content[1].startswith('Requests ')

# Generated at 2022-06-23 19:18:37.457231
# Unit test for function main
def test_main():
    print(main(["./http.py", "http://icanhazip.com"]))
    print(main(["./http.py", "http://icanhazip.com", "--debug"]))

# Generated at 2022-06-23 19:18:42.232317
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert[
        'http',
        '--json',
        '--ignore-stdin',
        '--auth=test'
    ] == decode_raw_args([
        b'http',
        b'--json',
        b'--ignore-stdin',
        b'--auth=test'
    ], 'utf8')

# Generated at 2022-06-23 19:18:53.689705
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    f = StringIO()
    e = Environment(
        program_name='myprog',
        stdin=f,
        stdin_isatty=True,
        stdout=f,
        stdout_isatty=True,
        stderr=f,
        stderr_isatty=True,
        stdout_encoding=f.encoding,
        stdin_encoding=f.encoding,
        stdout_errors='replace',
        stdin_errors='replace',
        config_dir=os.path.join(os.path.expanduser('~'), '.httpie'),
    )
    print_debug_info(env=e)
    assert isinstance(f.getvalue(), l)