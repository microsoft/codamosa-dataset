

# Generated at 2022-06-23 19:08:57.894085
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    with open('debug.txt', 'w', encoding='utf-8') as output:
        env.stderr = output
        print_debug_info(env)


if __name__ == '__main__':
    status = main()
    sys.exit(status)

# Generated at 2022-06-23 19:08:59.267905
# Unit test for function program
def test_program():
    assert program('args','env') == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:09:07.535975
# Unit test for function program
def test_program():
    import argparse, os, requests, sys
    from httpie import __version__, context
    from httpie.cli.definition import parser
    args = parser.parse_args(["--check-status", "--method=GET", "--headers=Accept:application/json", "--follow", "--verbose", "--auth=user:pass", "http://httpbin.org/get", "-v", "-b", "-a", "user:pass"])
    status, response = program(args, Environment())
    print(status)
    assert status == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:09:16.688933
# Unit test for function program
def test_program():
    import requests
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie import __version__ as httpie_version
    from httpie.status import ExitStatus, http_status_to_exit_status
    import argparse
    # --download argument test

    download_args = [
        'http',
        '--download',
        'https://httpbin.org/get',
        '--download-resume',
        '--output',
        'output.txt',
    ]
    download_arg_value = parse_args(download_args)
    env = Environment()
    env.config.directory = 'httpie'
    env.program_name = 'http'
    download_response = requests.Response()
    download_response.status_code = 200
    download_response.raw

# Generated at 2022-06-23 19:09:20.276811
# Unit test for function program
def test_program():
    args = ['--check-status']
    env = Environment()
    expected = ExitStatus.SUCCESS
    actual = program(args=args, env=env)
    assert actual == expected

# Generated at 2022-06-23 19:09:23.618287
# Unit test for function get_output_options
def test_get_output_options():
    args_dict = {'output_options': ['resp.body'],
                 'output_options': ['resp.body', 'resp.headers'],
                 'output_options': ['resp.headers']}
    resp = requests.Response()
    for args in args_dict:
        with_headers, with_body = get_output_options(args, resp)
        assert with_headers == (
            OUT_RESP_HEAD in args.output_options) and with_body == (OUT_RESP_BODY in args.output_options)

# Generated at 2022-06-23 19:09:25.732879
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['foo', b'bar'], 'ascii') == ['foo', 'bar']

# Generated at 2022-06-23 19:09:27.186631
# Unit test for function main
def test_main():
    args = ["--help"]
    main(args)
    

# Generated at 2022-06-23 19:09:28.616244
# Unit test for function program
def test_program():
    #python -m unittest tests.test_program
    pass

# Generated at 2022-06-23 19:09:30.431147
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    assert True

# Generated at 2022-06-23 19:09:41.490319
# Unit test for function program
def test_program():
    from httpie import __version__
    from httpie.cli.definition import parser

    args = parser.parse_args(args=['--debug'])
    assert program(args, os.environ) == 0

    args = parser.parse_args(args=['--version'])
    assert program(args, os.environ) == 0

    args = parser.parse_args(args=['get', 'http://httpbin.org/'])
    assert program(args, os.environ) == 0

    args = parser.parse_args(args=['get', '--help'])
    assert program(args, os.environ) == 0

    args = parser.parse_args(args=['get', 'http://httpbin.org/'])
    assert program(args, os.environ) == 0


# Generated at 2022-06-23 19:09:43.940451
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a', b'b'], 'iso-8859-1') == ['a', 'b']

# Generated at 2022-06-23 19:09:47.732432
# Unit test for function main
def test_main():
    class Env:
        def __init__(self):
            self.stderr = sys.stderr
            self.stdin_encoding = sys.stdin.encoding

    env = Env()
    args = ['--debug']
    assert main(args, env) == ExitStatus.SUCCESS
    args = ['--traceback']
    assert main(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:09:51.188615
# Unit test for function main
def test_main():
    a = ['--form', 'video_url=http://www.youtube.com/v/foo']
    try:
        main(args=a)
    except SystemExit as e:
        assert e.code == 1, "No exception should be thrown or error should be thrown"
    finally:
        env = Environment()
        env.stdout.close()
        env.stderr.close()

# Generated at 2022-06-23 19:10:00.518381
# Unit test for function program
def test_program():
    '''
    Test for function program()
    '''

    import os
    import shutil
    import tempfile
    import binascii

    import requests
    import pytest
    from requests.models import RequestEncodingMixin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.status import ExitStatus
    from httpie.cli.parser import parser
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.downloads import Downloader

    class TestRequest(RequestEncodingMixin, requests.Request):
        def __init__(self, *args, **kwargs):
            self.method = kwargs.get('method', 'GET')

# Generated at 2022-06-23 19:10:05.354742
# Unit test for function get_output_options
def test_get_output_options():
    import httpie.cli.definition as definition
    args = definition.parser.parse_args(args=[])
    args.output_options = ('hBb',)
    msg = requests.PreparedRequest()
    assert get_output_options(args, msg) == (True, True)
    msg = requests.Response()
    assert get_output_options(args, msg) == (True, False)

# Generated at 2022-06-23 19:10:14.528783
# Unit test for function main
def test_main():
    import tempfile
    import os
    from httpie.core import main
    main(['-v'])
    with tempfile.TemporaryDirectory() as tmpdirname:
        file_path = os.path.join(tmpdirname, 'test.txt')
        with open(file_path, 'a') as outfile:
            main(['https://httpbin.org/get', '--output', outfile.name])
        with open(file_path, 'r') as read_file:
            content = read_file.read()
            print(content)
    return content


if __name__ == '__main__':
    content = test_main()

# Generated at 2022-06-23 19:10:26.603859
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr_isatty = False
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stdin_encoding = "UTF-8"

    stdout = io.StringIO()
    env.stdout = stdout
    stderr = io.StringIO()
    env.stderr = stderr
    print_debug_info(env)

    output = stderr.getvalue()

# Generated at 2022-06-23 19:10:33.699297
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b"\xe4\xb8\xad\xe6\x96\x87"], 'utf-8') == ["中文"]
    assert decode_raw_args(["中文"], 'utf-8') == ["中文"]
    assert decode_raw_args([123], 'utf-8') == [123]
    assert decode_raw_args([b"\xe4\xb8\xad\xe6\x96\x87", 123], 'utf-8') == ["中文", 123]
    assert decode_raw_args([b"\xe4\xb8\xad\xe6\x96\x87", "中文"], 'utf-8') == ["中文", "中文"]

# Generated at 2022-06-23 19:10:45.048600
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.status import ExitStatus

    # Create temp dir for testing
    from tests.support.config_dir import (
        create_config_dir,
        create_file_config,
        create_netrc_file,
        create_auth_file,
    )
    import tempfile
    import shutil
    os.mkdir('temp')
    # Create config dir with config file
    create_file_config('temp/config')
    # Create config dir with netrc file
    create_netrc_file('temp/netrc')
    # Create config dir with auth file
    create_auth_file('temp/auth')
    # Create default config dir

# Generated at 2022-06-23 19:10:46.887053
# Unit test for function main
def test_main():
    assert main(sys.argv) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:10:56.581471
# Unit test for function get_output_options
def test_get_output_options():
    class Response:
        status_code = 200
        headers = {}
        reason = "Reason"
        body = ""

    class PreparedRequest:
        headers = {}
        path_url = "/"
        method = "GET"

    args = argparse.Namespace(output_options=[])

    assert get_output_options(args=args, message=Response()) == (
        False, False,
    )
    assert get_output_options(args=args, message=PreparedRequest()) == (
        False, False,
    )

    args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(args=args, message=PreparedRequest()) == (
        True, False,
    )

# Generated at 2022-06-23 19:11:02.592981
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['--json'], stdin_encoding='utf-8') == ['--json']
    assert decode_raw_args([b'--json'], stdin_encoding='utf-8') == ['--json']
    assert decode_raw_args([b'--\xe2\x90\xa3'], stdin_encoding='utf-8') == ['--☣']

# Generated at 2022-06-23 19:11:07.198350
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.testing import StringIO
    env = Environment()
    env.stderr = StringIO()
    env.stdout = StringIO()
    print_debug_info(env)
    print(env.stderr.getvalue())
    print(env.stdout.getvalue())
    assert True

# Generated at 2022-06-23 19:11:18.371889
# Unit test for function print_debug_info
def test_print_debug_info():
    class STD:
        def __init__(self, *args):
            self.args=args
        def writelines(self, lines):
            for line in lines:
                print(line, file=sys.stderr)
        def write(self, str):
            print(str, file=sys.stderr)

    class StdIn:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class Env:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    stderr=STD()
    stdin=StdIn(encoding='utf8')
    env=Env(stderr=stderr,stdin=stdin)
    print_debug_info(env)

# Generated at 2022-06-23 19:11:19.770811
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr = sys.stdout
    print_debug_info(env)

# Generated at 2022-06-23 19:11:24.637111
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a', 'b', 'c'], 'utf8') == ['a', 'b', 'c']
    assert decode_raw_args(['a', b'b', 'c'], 'utf8') == ['a', 'b', 'c']
    assert decode_raw_args([b'a', b'b', b'c'], 'utf8') == ['a', 'b', 'c']

# Generated at 2022-06-23 19:11:33.314453
# Unit test for function main
def test_main():
    # stdout = io.StringIO()
    from io import BytesIO
    stdout = BytesIO()

    env = Environment(config=None)
    env.stdout = stdout

    exit_status = main(None, env)
    assert exit_status == ExitStatus.ERROR

    exit_status = main([], env)
    assert exit_status == ExitStatus.SUCCESS

    exit_status = main(['--debug'], env)
    assert exit_status == ExitStatus.SUCCESS

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 19:11:44.242902
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = [b'\xe3\x81\xb2\xe3\x82\x8d\xe3\x81\xac\xe3\x81\xaa\xe3\x81\x8d\xe3\x81\xaa\xe3\x81\x84']
    result = decode_raw_args(args=args, stdin_encoding='cp932')

    assert type(result[0]) is str
    # Python 3
    if sys.version_info[0] >= 3:
        assert result[0] == args[0].decode('cp932')
    # Python 2
    else:
        assert result[0] == args[0].decode('cp932').encode('utf-8')

# Generated at 2022-06-23 19:11:54.910617
# Unit test for function program
def test_program():
    from httpie.cli import parser as cli_parser
    from httpie.context import Environment
    from httpie.config import Config, DEFAULT_CONFIG_DIR
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth

    env = Environment(stdin=None, stdout=None, stderr=None, vars={})
    env.config = Config(
        config_dir=DEFAULT_CONFIG_DIR,
        config_path=None,
        config=None,
        env=env,
        plugins=(HTTPBasicAuth, HTTPDigestAuth),
    )

# Generated at 2022-06-23 19:12:04.359594
# Unit test for function program
def test_program():
    """
    Test function program().
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('url', help='target URL')
    parser.add_argument('-d', '--data')
    parser.add_argument('-o', '--output-file')
    parser.add_argument('-s', '--silent', help='redirect stdout to /dev/null', action='store_true')

    args = parser.parse_args(['http://httpbin.org/get', '-s', '-o', 'out.txt'])
    program(args.url, args.output_file, args.silent)

# Generated at 2022-06-23 19:12:08.805660
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'\xe7\x9a\x84', b'\xe6\x96\x87\xe4\xbb\xb6'], 'utf-8') == ['的', '文件']



# Generated at 2022-06-23 19:12:17.180787
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    import pytest
    # Complete args in Main
    str_args = ["httpie", "--json", "--debug"]
    # Convert str to byte
    byte_args = [bytes(arg, "utf-8") for arg in str_args]
    byte_args[0] = str_args[0].encode('utf-8')
    assert main(byte_args) == ExitStatus.SUCCESS
    # Exception
    args = ["httpie", "--json", "--debug", "--timeout", "1"]
    with pytest.raises(SystemExit) as e:
        main(args)
    assert e.value.code != ExitStatus.SUCCESS
    # KeyboardInterrupt
    def _raise_keyboard_interrupt():
        raise KeyboardInterrupt()
    parser

# Generated at 2022-06-23 19:12:27.339919
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(
        stdin=io.BytesIO(),
        stdout=io.BytesIO(),
        stderr=io.BytesIO(),
        stdin_isatty=False,
        stdout_isatty=False,
        stderr_isatty=False,
        color_enabled=False,
        stdin_encoding='utf8',
        stdout_encoding='utf8',
        stdout_errors='strict',
        program_name='http',
        config_dir='config_dir',
        config=None,
        default_options=[],
    )
    print_debug_info(env)

# Generated at 2022-06-23 19:12:40.112480
# Unit test for function print_debug_info
def test_print_debug_info():
    import unittest
    import io
    import contextlib
    from httpie.context import Environment
    from httpie import __version__
    from requests import __version__ as requests_version
    from pygments import __version__ as pygments_version
    import sys

    @contextlib.contextmanager
    def capture_stderr():
        stderr = sys.stderr
        try:
            sys.stderr = io.StringIO()
            yield sys.stderr
        finally:
            sys.stderr = stderr

    @contextlib.contextmanager
    def capture_stdout():
        stdout = sys.stdout
        try:
            sys.stdout = io.StringIO()
            yield sys.stdout
        finally:
            sys.stdout = stdout


# Generated at 2022-06-23 19:12:42.334803
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Check if __name__=='__main__'
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 19:12:48.156862
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'\xa5', 'foo'], 'latin1') == ['¥', 'foo']
    assert decode_raw_args([b'\xc5', 'foo'], 'latin1') == ['Å', 'foo']

# Generated at 2022-06-23 19:12:58.496158
# Unit test for function print_debug_info
def test_print_debug_info():
    from . import utils
    from httpie.compat import is_windows

    env = Environment()
    env.stdout = io.BytesIO()
    env.stderr = io.BytesIO()

    print_debug_info(env)

    os_info = platform.system() + ' ' + platform.release()
    debug_info = [
        f'HTTPie {httpie_version}\n',
        f'Requests {requests_version}\n',
        f'Pygments {pygments_version}\n',
        f'Python {sys.version}\n{sys.executable}\n',
        f'{os_info}\n',
        '\n\n',
        repr(env),
        '\n'
    ]


# Generated at 2022-06-23 19:13:09.481852
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (False, False)
    args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(args, message) == (True, False)
    args.output_options = [OUT_REQ_BODY]
    assert get_output_options(args, message) == (False, True)
    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY]
    assert get_output_options(args, message) == (True, True)
    response = requests.Response()
    args.output_options = [OUT_RESP_HEAD]
    assert get_output_options(args, response) == (True, False)

# Generated at 2022-06-23 19:13:11.987139
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace
    args.output_options = ['verbose', 'headers']

    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (True, False)

    message = requests.Response()
    assert get_output_options(args, message) == (True, False)

# Generated at 2022-06-23 19:13:18.669465
# Unit test for function get_output_options
def test_get_output_options():
    class TestArgParse:
        def __init__(self, options: List[str]):
            self.output_options = options
    # Positive case
    assert get_output_options(TestArgParse(['all']), requests.PreparedRequest()) == (True, True)
    assert get_output_options(TestArgParse(['all']), requests.Response()) == (True, True)
    # Negative case
    assert get_output_options(TestArgParse(['all']), TestArgParse([])) == (False, False)

# Generated at 2022-06-23 19:13:27.213914
# Unit test for function print_debug_info
def test_print_debug_info():
    def check(out, env):
        # create a string buffer
        buff = io.StringIO()
        # redirect stdout to the buffer
        env.stderr = buff
        # call the function
        print_debug_info(env)
        # print the contents of the buffer
        print(buff.getvalue())
        assert buff.getvalue() == out


    # test function is called
    env = Environment()

    # # test case 1
    # print('Test Case 1:')
    # out = "HTTPie 1.0.2\nRequests 2.21.0\nPygments 2.2.0\nPython 3.7.3 (default, Mar 27 2019, 22:11:17) \n[GCC 7.3.0]\nLinux 4.19.0-5-amd64"
    # check(

# Generated at 2022-06-23 19:13:33.712200
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = (OUT_REQ_HEAD, OUT_RESP_HEAD, OUT_RESP_BODY)

    req = requests.PreparedRequest()
    resp = requests.Response()

    assert get_output_options(args, req) == (True, False)
    assert get_output_options(args, resp) == (True, True)

# Generated at 2022-06-23 19:13:46.081594
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.context import Environment
    import httpie.config as config
    from io import StringIO, BytesIO
    from sys import getdefaultencoding
    from unittest import TestCase, mock
    from contextlib import contextmanager

    @contextmanager
    def patched_std_streams(
        stdin: IO = None,
        stdout: IO = None,
        stderr: IO = None,
        stdin_encoding: str = None,
    ) -> Generator[None, None, None]:
        saved = sys.stdin, sys.stdout, sys.stderr, sys.stdin.encoding

# Generated at 2022-06-23 19:13:57.971340
# Unit test for function print_debug_info
def test_print_debug_info():
    from .utils import mock_stdin_encoding
    from .context import Environment

    env = Environment(stdin_encoding=mock_stdin_encoding)
    print_debug_info(env)

    # noinspection SpellCheckingInspection

# Generated at 2022-06-23 19:14:04.703844
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import sys
    fake_env = Environment()
    fake_env.debug_output_file = io.StringIO()
    print_debug_info(env=fake_env)
    assert all(
        key in fake_env.debug_output_file.getvalue()
        for key in
        ['HTTPie', 'Requests', 'Pygments', 'Python', sys.executable, platform.system()]
    )

# Generated at 2022-06-23 19:14:12.824253
# Unit test for function main
def test_main():
    from unittest.mock import patch

    from httpie.cli.definition import parser

    with patch('sys.exit') as sys_exit:
        with patch('httpie.cli.constants.OUT_REQ_HEAD', 'H') as OUT_REQ_HEAD:
            with patch('httpie.cli.constants.OUT_REQ_BODY', 'B') as OUT_REQ_BODY:
                main(['--traceback', 'HtTp://example.com'])
                main(['--debug'])
                main([])

    with patch.object(parser, 'parse_args', side_effect=SystemExit(2)):
        main()

    with patch.object(parser, 'parse_args', side_effect=KeyboardInterrupt):
        main()

# Generated at 2022-06-23 19:14:22.946870
# Unit test for function main
def test_main():
    from io import BytesIO
    from io import StringIO
    from httpie import ExitStatus
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.manager import plugin_manager
    from tempfile import TemporaryDirectory

    cfg_dir = TemporaryDirectory()
    cfg_dir_name = cfg_dir.name
    cfg_dir.cleanup()


# Generated at 2022-06-23 19:14:29.501183
# Unit test for function get_output_options
def test_get_output_options():
    args=argparse.Namespace(output_options=[OUT_REQ_BODY, OUT_REQ_HEAD])
    msg = requests.PreparedRequest()
    assert get_output_options(args, msg) == (True, True)
    msg = requests.Response()
    assert get_output_options(args, msg) == (False, False)

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 19:14:32.351707
# Unit test for function main
def test_main():
    assert main(["httpie-0.9.8.exe", "--version"]) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:14:38.189230
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from httpie.cli.definition import parser
    from httpie import ExitStatus
    args = parser.parse_args(['--output-encoding', 'utf-8', 'get', 'http://httpbin.org/get'])
    assert decode_raw_args(args, 'utf-8') == ['--output-encoding', 'utf-8', 'get', 'http://httpbin.org/get']
    args = parser.parse_args(['--output-encoding', 'utf-8', 'get', 'http://httpbin.org/get'])
    assert decode_raw_args(args, 'utf-8') != ['--output-encoding', 'utf-8', 'get', 'http://httpbin.org/get']

# Generated at 2022-06-23 19:14:45.524459
# Unit test for function get_output_options
def test_get_output_options():
    args: argparse.Namespace = argparse.Namespace(output_options={OUT_REQ_HEAD, OUT_REQ_BODY})
    assert get_output_options(args, requests.PreparedRequest()) == (True, True)
    assert get_output_options(args, requests.Response()) == (False, False)


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:14:54.677714
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(**{
        'output_options': ['resp.headers', 'resp.body']
    })
    req = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args=args, message=req)
    assert with_headers == False
    assert with_body == False
    resp = requests.Response()
    with_headers, with_body = get_output_options(args=args, message=resp)
    assert with_headers == True
    assert with_body == True

# Generated at 2022-06-23 19:15:06.977900
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a', 'b', 'c'], 'utf-8') == ['a', 'b', 'c']
    assert decode_raw_args(['a', b'b', 'c'], 'utf-8') == ['a', 'b', 'c']
    assert decode_raw_args(['a', b'b', b'c'], 'utf-8') == ['a', 'b', 'c']
    assert decode_raw_args([b'a', b'b', b'c'], 'utf-8') == ['a', 'b', 'c']
    assert decode_raw_args([b'a', b'b', b'c'], 'iso-8859-1') == ['a', 'b', 'c']

# Generated at 2022-06-23 19:15:10.262368
# Unit test for function main
def test_main():
    args = ['http', 'httpbin.org/get']
    env = Environment()
    main(args=args, env=env)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 19:15:14.276276
# Unit test for function get_output_options
def test_get_output_options():
    options = Namespace(output_options=[OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD])
    req = requests.PreparedRequest()
    res = requests.Response()
    print(get_output_options(options, req))
    print(get_output_options(options, res))


# Generated at 2022-06-23 19:15:20.688909
# Unit test for function main
def test_main():
    """
    Test case for main()
    """
    # Success case
    result = main(["http", "httpbin.org/get"])
    assert result == ExitStatus.SUCCESS

    result = main(["http", "--debug"])
    assert result == ExitStatus.SUCCESS

    # Failure case
    result = main(["http"])
    assert result == ExitStatus.ERROR


# Generated at 2022-06-23 19:15:32.655243
# Unit test for function main
def test_main():
    from httpie.client import main as httpie_main
    from httpie.compat import is_windows
    
    # Test for common methods for all the http requests
    args = ['httpie', 'https://postman-echo.com/get']
    exit_status = httpie_main(args=args)
    assert exit_status == ExitStatus.SUCCESS

    args = ['httpie', 'https://postman-echo.com/post', '--data', 'a=1', 'b=2']
    exit_status = httpie_main(args=args)
    assert exit_status == ExitStatus.SUCCESS

    args = ['httpie', 'https://postman-echo.com/put', '--data', 'a=1', 'b=2']
    exit_status = httpie_main(args=args)


# Generated at 2022-06-23 19:15:42.793489
# Unit test for function main
def test_main():
    # setup
    stdin_encoding = 'utf-8'

# Generated at 2022-06-23 19:15:50.432784
# Unit test for function get_output_options
def test_get_output_options():
    program_name, *args = ['http', '--download', 'https://www.google.com']
    args = decode_raw_args(args, 'utf-8')
    # print(args)
    env.program_name = os.path.basename(program_name)
    args = decode_raw_args(args, env.stdin_encoding)
    plugin_manager.load_installed_plugins()

    from httpie.cli.definition import parser
    args = env.config.default_options + args
    parsed_args = parser.parse_args(
        args=args,
        env=env,
    )
    print(parsed_args)
    messages = collect_messages(args=parsed_args, config_dir=env.config.directory)
    print(type(messages))

# Generated at 2022-06-23 19:15:54.975500
# Unit test for function main
def test_main():
    args = ['http', 'www.example.com']
    env = Environment()
    main(args=args, env=env)


if __name__ == '__main__':
    print(main())

# Generated at 2022-06-23 19:16:03.355884
# Unit test for function main
def test_main():
    import io
    import sys
    from httpie.cli.definition import parser

    class Args:
        pass

    args = Args()
    args.headers = '1: 2'
    args.output_file = io.open('test.txt', 'w+')
    args.verbose = '1'

    env = Environment()
    env.log_level = 'debug'

    sys.argv = [sys.argv[0], 'localhost', '-h', args.headers, '-o', args.output_file, '-v']

    try:
        parsed_args = parser.parse_args(
            args=sys.argv[1:],
            env=env,
        )
    except SystemExit:
        assert False
    program(parsed_args, env)


# Generated at 2022-06-23 19:16:05.621601
# Unit test for function program
def test_program():
    # TODO: 2020-07-14T06:05:41+09:00
    #  Write the test code.
    pass



# Generated at 2022-06-23 19:16:13.217622
# Unit test for function print_debug_info
def test_print_debug_info():
    try:
        import win_unicode_console  # noqa
    except ImportError:
        return False

    from io import StringIO
    from typing import cast
    from unittest import TestCase

    from httpie import context

    class PrintDebugInfoTests(TestCase):
        def test_default(self):
            env = context.Environment()
            out = StringIO()
            env.stderr = cast(context.Environment, out)
            print_debug_info(env)
            out.seek(0)
            self.assertIn('HTTPie', out.read())

    return PrintDebugInfoTests('test_default')

# Generated at 2022-06-23 19:16:22.306315
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import sys

    class EnvMock:
        def __init__(self):
            self.stderr = io.StringIO()

        def __repr__(self):
            return 'EnvMock'

    env = EnvMock()
    print_debug_info(env)
    assert env.stderr.getvalue() == """HTTPie 1.0.4
Requests 2.22.0
Pygments 2.5.2
Python {sys.version}
{sys.executable}
{sys.platform}

EnvMock

""".format(sys=sys)


# Generated at 2022-06-23 19:16:30.575315
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = ['noprint', 'print']

    class TmpReq(requests.PreparedRequest):
        pass
    
    class TmpRsp(requests.Response):
        pass

    req = TmpReq()
    rsp = TmpRsp()

    # Test request:
    assert get_output_options(args, req) == (False, True)

    # Test response:
    assert get_output_options(args, rsp) == (True, True)

# Generated at 2022-06-23 19:16:41.954950
# Unit test for function main
def test_main():
    import subprocess
    import sys

    print("#############UnitTest: main#############")
    proc = subprocess.Popen(["http", "post"])
    proc.communicate()

    # 使用了选项“--check-status”而退出码不是0，显示状态码
    assert subprocess.call(["http", "--check-status", "HEAD", "https://www.httpbin.org/status/500"]) != 0

    # 显示版本时退出码为0
    assert subprocess.call(["http", "--version"]) == 0

    # 使用了“--debug”出错

# Generated at 2022-06-23 19:16:45.569579
# Unit test for function main
def test_main():
    assert main([]) == 2
    assert main(['']) == 0
    assert main(['--help']) == 0
    assert main(['--version']) == 0


# Generated at 2022-06-23 19:16:57.043071
# Unit test for function print_debug_info
def test_print_debug_info():
    """
    create a fake environment using the module io
    outfile = io.StringIO()
    and then set stderr to outfile by
    env.stderr = outfile
    caal the function print_debug_info, and then
    assert that the environment output is correct
    :return:
    """
    import io
    outfile = io.StringIO()
    env = Environment()
    env.stderr = outfile
    print_debug_info(env)

# Generated at 2022-06-23 19:16:59.803862
# Unit test for function main
def test_main():
    from . import main
    from .helpers import get_response
    from requests import __version__
    response = get_response('--version')
    assert response.status_code == ExitStatus.SUCCESS
    assert response.text.strip() == 'httpie '+__version__
    response = get_response('')
    assert response.status_code == ExitStatus.ERROR_CLIENT


# Generated at 2022-06-23 19:17:07.465789
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO
    args = parser.parse_args(['--ignore-stdin', 'https://api.github.com/repos/jakubroztocil/httpie'])
    env = Environment()
    env.stdout = StdoutBytesIO()
    program(args=args, env=env)
    assert b'Homepage' in env.stdout.getvalue()
    assert env.stdout.getvalue().endswith(b'\n')

# Generated at 2022-06-23 19:17:08.415976
# Unit test for function program
def test_program():
    main([])



# Generated at 2022-06-23 19:17:19.884291
# Unit test for function get_output_options
def test_get_output_options():
    test_options = ['b','B','h','H','j','J','p','P','t','T','u','U','v','V','all']
    for option in test_options:
        option_to_test  = list(option)
        # For any given combination of output options, at least one of the output_options is non-empty
        with open('/dev/null', 'wb') as null_file:
            request_message = requests.PreparedRequest()
            if option_to_test:
                request_message.headers = 'Header'
                response_message = requests.Response()
                response_message.headers = 'Header'
                for opt in option_to_test:
                    args = argparse.Namespace(
                        output_options=['all'],
                        output_file=null_file
                    )

# Generated at 2022-06-23 19:17:28.271500
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    import io
    from httpie.context import Environment

    env = Environment()
    env.stdout = io.StringIO()
    args = parser.parse_args(args=['http://httpbin.org'], env=env)
    assert program(args=args, env=env) == env.ExitStatus.SUCCESS
    output = env.stdout.getvalue()
    # First line should be a JSON object containing key `origin`
    assert output.splitlines()[0].split(':')[0] == '{'
    # Last line should be empty
    assert output.splitlines()[-1] == ''
    assert len(output.splitlines()) == 42

# Generated at 2022-06-23 19:17:41.083428
# Unit test for function program
def test_program():
    global exit_status
    exit_status=ExitStatus.SUCCESS

# Generated at 2022-06-23 19:17:49.268152
# Unit test for function get_output_options
def test_get_output_options():
    from httpie import main
    from httpie.cli.parser import parser

    args = parser.parse_args(
        args='--output-options=hb'.split(),
        env=Environment()
    )

    class TempRequest:
        pass

    class TempResponse:
        pass
    request = TempRequest()
    response = TempResponse()

    req_head, req_body = main.get_output_options(args=args, message=request)
    resp_head, resp_body = main.get_output_options(args=args, message=response)
    print(req_head, req_body, resp_head, resp_body)
    assert req_head == True and req_body == True and resp_head == True and resp_body == True

# Generated at 2022-06-23 19:17:58.637098
# Unit test for function get_output_options
def test_get_output_options():
    import inspect
    env = Environment()
    args = inspect.getargspec(parser.parse_args)[0]
    class argsStruct:
        def __init__(self, **entries):
            self.__dict__.update(entries)
    args = argsStruct(**{arg: None for arg in args[1:]})
    args.output_options = [OUT_REQ_HEAD, OUT_RESP_BODY]
    message = requests.PreparedRequest()
    assert(get_output_options(
        args=args,
        message=message
    ) == (True, False))
    message = requests.Response()
    assert(get_output_options(
        args=args,
        message=message
    ) == (False, True))

# Generated at 2022-06-23 19:18:08.013068
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser

    args = parser.parse_args(['GET', 'http://www.example.com'])
    request = requests.PreparedRequest()
    response = requests.Response()
    assert get_output_options(args, request) == (True, True)
    assert get_output_options(args, response) == (True, True)
    args.output_options.append(OUT_REQ_HEAD)
    assert get_output_options(args, request) == (True, True)
    args.output_options.append(OUT_REQ_BODY)
    assert get_output_options(args, request) == (False, True)
    args.output_options.append(OUT_RESP_HEAD)
    assert get_output_options(args, response) == (False, True)


# Generated at 2022-06-23 19:18:14.380141
# Unit test for function print_debug_info
def test_print_debug_info():
    class S:
        def __init__(self):
            self.s = ''

        def write(self, *args):
            self.s += ' '.join(args)

    s = S()
    print_debug_info(Environment(config_dir=None, stdout=s, stderr=s))
    assert 'httpie' in s.s
    assert 'requests' in s.s



# Generated at 2022-06-23 19:18:23.628639
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[OUT_REQ_HEAD, OUT_REQ_BODY])
    request = requests.PreparedRequest()
    assert get_output_options(args, request) == (True, True)
    assert get_output_options(args, request) != (True, False)
    assert get_output_options(args, request) != (False, True)
    response = requests.Response()
    assert get_output_options(args, response) == (False, False)
    args = argparse.Namespace(output_options=[OUT_RESP_HEAD, OUT_RESP_BODY])
    assert get_output_options(args, response) == (True, True)
    assert get_output_options(args, request) == (False, False)

# Generated at 2022-06-23 19:18:27.103129
# Unit test for function main
def test_main():
    # Temporary --debug flag set to not cause SystemExit
    sys.argv.append('--debug')
    r = main()
    assert(r == ExitStatus.SUCCESS)

# Generated at 2022-06-23 19:18:29.647974
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    buffer = io.StringIO()
    env.stderr.write = buffer.write

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 19:18:40.302197
# Unit test for function get_output_options
def test_get_output_options():
    from argparse import Namespace
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    env = Environment()
    args = Namespace(
        output_options=[OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD]
    )
    from requests import Response
    from httpie.client import collect_messages
    messages = collect_messages(args=args, config_dir=env.config.directory)
    for message in messages:
        print(f'{message.url}')
        print(f'message type: {type(message)}')

# Generated at 2022-06-23 19:18:42.555603
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    from io import StringIO
    env.stderr = StringIO()
    print_debug_info(env)
    assert "Python" in env.stderr.getvalue()

# Generated at 2022-06-23 19:18:54.544872
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.cli.constants import UNIX_CONFIG_DIR
    from httpie import ExitStatus
    from httpie.context import Environment
    env = Environment()