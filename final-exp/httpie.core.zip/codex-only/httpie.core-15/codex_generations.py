

# Generated at 2022-06-23 19:08:55.617598
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-23 19:09:01.763615
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'--form', b'a=1', b'a=2+'], 'utf-8') == ['--form', 'a=1', 'a=2+']
    assert decode_raw_args([b'--form', b'a=1', 'a=2+'], 'utf-8') == ['--form', 'a=1', 'a=2+']

# Generated at 2022-06-23 19:09:05.604577
# Unit test for function main
def test_main():
    assert main(['httpie', 'hello', '--check-status']) == ExitStatus.SUCCESS
    # TODO: Python 2.7
    # assert main(['httpie', 'non-exist']) == ExitStatus.ERROR
    assert main(['httpie', '--timeout', '1', 'https://httpbin.org/delay/5']) == ExitStatus.ERROR_TIMEOUT
    assert main(['httpie', 'https://httpbin.org/relative-redirect/2']) == ExitStatus.ERROR_TOO_MANY_REDIRECTS

# Generated at 2022-06-23 19:09:15.504392
# Unit test for function print_debug_info
def test_print_debug_info():
    # The function needs an Environment object
    # to work with which can be given as parameters
    # The default configuration file location is ~/.config/httpie
    # In ~/ do a
    #   > mkdir -p .config/httpie
    # to test the function.
    # In test directory:
    #   > pytest tests/test_print_debug_info.py
    env = Environment()
    env.config.directory = os.path.expanduser("~") + "/.config/httpie"
    env.config.load()
    env.stderr = StringIO()
    print_debug_info(env)
    assert("Python" in env.stderr.getvalue())

# Generated at 2022-06-23 19:09:21.871486
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    env = Environment()
    env.stderr = io.StringIO()
    print_debug_info(env=env)
    assert env.stderr.getvalue().startswith('HTTPie 1.')


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:09:24.498437
# Unit test for function main
def test_main():
    args = ["http", "--headers"]
    env = Environment()
    status = main(args, env)
    assert status == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:09:33.406050
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import locale

    if platform.system() == "Windows":
        assert decode_raw_args([b'test'], 'utf-8') == ["test"]
        assert decode_raw_args([b'test', b'\xe7\x9a\x84'], 'utf-8') == ["test", "的"]
        assert decode_raw_args([b'test', b'\xBA\xDA'], locale.getpreferredencoding()) == ["test", "㺚"]
        assert decode_raw_args([b'test', "string"], 'utf-8') == ["test", "string"]
    else:
        assert decode_raw_args([b'test'], 'utf-8') == ["test"]

# Generated at 2022-06-23 19:09:44.860085
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', '--check-status', '--ignore-stdin', '--stream', '--output=file'])
    from httpie import client
    msg_request = client.messages.PreparedRequest('http://httpie.org', 'GET')
    msg_response = client.messages.Response(b'http://httpie.org', 200)

    with_header_1, with_body_1 = get_output_options(args=args, message=msg_request)
    with_header_2, with_body_2 = get_output_options(args=args, message=msg_response)
    assert with_header_1 == False
    assert with_body_1 == False
    assert with_header_2 == False
    assert with_body

# Generated at 2022-06-23 19:09:51.959320
# Unit test for function print_debug_info
def test_print_debug_info():
    class Env():
        class Stderr():
            def __init__(self, env):
                self.env = env

            def writelines(self, lines):
                self.env.writelines.append(lines)

            def write(self, string):
                self.env.writelines.append(string)

        def __init__(self):
            self.writelines = []
            self.stderr = self.Stderr(self)

    env = Env()
    print_debug_info(env)

    assert len(env.writelines) == 6
    assert env.writelines[0].startswith('HTTPie ')
    assert env.writelines[1].startswith('Requests ')
    assert env.writelines[2].startswith('Pygments ')

# Generated at 2022-06-23 19:09:55.749345
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        ['a', b'b\xe4'],
        stdin_encoding='utf-8'
    ) == ['a', 'bä']


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:10:01.027768
# Unit test for function main
def test_main():
    def assert_main(args: List[str], expected: ExitStatus):
        assert main(args + ['https://httpbin.org/get']) == expected
    assert_main([], ExitStatus.SUCCESS)  # simple request
    assert_main(['--debug'], ExitStatus.SUCCESS)  # debug info and simple request
    assert_main(['--debug', '--traceback'], ExitStatus.ERROR)  # debug info, simple request and traceback
    assert_main(['--debug', 'https://httpbin.org/get'], ExitStatus.SUCCESS)  # debug info and simple request
    assert_main(['--debug', '--traceback', 'https://httpbin.org/get'], ExitStatus.ERROR)  # debug info, simple request and traceback

# Generated at 2022-06-23 19:10:09.953322
# Unit test for function program
def test_program():
    import pytest
    from io import StringIO
    from contextlib import redirect_stdout
    from unittest.mock import patch
    import httpie.config

    @patch('httpie.output.v0.output_options_override_implicit_body', return_value=True)
    def test(output_options_override_implicit_body):
        f = StringIO()

# Generated at 2022-06-23 19:10:17.853582
# Unit test for function get_output_options
def test_get_output_options():
    import pytest
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_HEAD, OUT_RESP_BODY]
    req_headers, req_body = get_output_options(
        args=args,
        message=requests.PreparedRequest(),
    )
    assert req_headers == True
    assert req_body == False
    resp_headers, resp_body = get_output_options(
        args=args,
        message=requests.Response(),
    )
    assert resp_headers == False
    assert resp_body == True
    with pytest.raises(KeyError):
        get_output_options(
            args=args,
            message=requests.Session(),
        )

# Generated at 2022-06-23 19:10:22.913501
# Unit test for function main
def test_main():
    from .utils import MockEnvironment, MockParser
    from .utils import override_stdout_encoding
    with override_stdout_encoding('utf8'):
        env = MockEnvironment()
        program = MockParser()
        main(args=[], env=env, program=program)
        assert program.called

# Generated at 2022-06-23 19:10:29.058071
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([u'a', u'b'], 'utf-8') == [u'a', u'b']
    assert decode_raw_args([b'a', b'b'], 'utf-8') == [u'a', u'b']
    assert decode_raw_args([b'a', b'b'], 'utf-16') == [u'a', u'b']
    assert decode_raw_args([u'a', b'b'], 'utf-16') == [u'a', u'b']

# Generated at 2022-06-23 19:10:38.715385
# Unit test for function get_output_options
def test_get_output_options():
    import argparse
    from httpie.cli.argtypes import KeyValueArgType

# Generated at 2022-06-23 19:10:50.744637
# Unit test for function get_output_options
def test_get_output_options():
    assert get_output_options(argparse.Namespace(output_options=['b','h','i','o','H','B','c']),requests.PreparedRequest()) == (True,True)
    assert get_output_options(argparse.Namespace(output_options=['b','h','i','o','H','B','c']),requests.Response()) == (True,True)
    assert get_output_options(argparse.Namespace(output_options=['b','h','i','o','H','B','c']),requests.PreparedRequest()) == (True,True)
    assert get_output_options(argparse.Namespace(output_options=['b','i','o','H','B','c']),requests.PreparedRequest()) == (True,False)

# Generated at 2022-06-23 19:10:55.292507
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([
        b'-X', b'POST',
        b'https://httpbin.org/anything',
        b'name==\xe2\x98\x83'
    ], stdin_encoding='utf-8') == [
        '-X', 'POST',
        'https://httpbin.org/anything',
        'name==☃'
    ]

# Generated at 2022-06-23 19:11:06.926478
# Unit test for function get_output_options
def test_get_output_options():
    """
    The current values are:
    OUT_REQ_HEAD = 1
    OUT_REQ_BODY = 2
    OUT_RESP_HEAD = 4
    OUT_RESP_BODY = 8
    """
    args = argparse.Namespace(output_options = [0,1,2,4,8], headers = {},
                              output_file = None, output_file_specified = False,
                              quiet = False, download = False, download_resume = False,
                              max_redirects = None, timeout = None, check_status = True, follow = True)
    from pygments import __version__ as pygments_version

    class Environment(object):
        config: Config = Config(directory = '~/.config/httpie')
        stdout_isatty = False
        stderr_is

# Generated at 2022-06-23 19:11:10.401383
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 19:11:16.914985
# Unit test for function main
def test_main():
    from httpie.compat import str
    import pathlib

    from httpie import ExitStatus
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD, OUT_STDOUT
    from httpie.cli.definition import parser
    from httpie.core import main
    from httpie.output.writer import MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.status import ExitStatus

    # Parser

# Generated at 2022-06-23 19:11:27.132127
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.argtypes import KeyValueArg
    import json
    import httpie.cli.definition


# Generated at 2022-06-23 19:11:39.346754
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import sys
    sys.stderr=io.StringIO()
    env = Environment()

# Generated at 2022-06-23 19:11:49.751960
# Unit test for function print_debug_info
def test_print_debug_info():

    class _Environment(Environment):
        def __init__(self):
            self.stdin = BytesIO()
            self.stderr = BytesIO()

    env = _Environment()
    print_debug_info(env)
    stderr_content = env.stderr.getvalue()
    assert f'HTTPie {httpie_version}' in stderr_content
    assert f'Requests {requests_version}' in stderr_content
    assert f'Pygments {pygments_version}' in stderr_content
    assert f'{platform.system()} {platform.release()}' in stderr_content
    assert f'Python {sys.version}' in stderr_content

# Generated at 2022-06-23 19:11:58.685842
# Unit test for function program
def test_program():
    from httpie.cli.constants import OUT_REQ_HEAD, OUT_REQ_BODY
    from httpie.compat import urlopen
    from requests import Request, Response
    from httpie.cli.definition import parser
    from httpie.output.streams import wrap_stdout
    from httpie.downloads import Downloader
    import tempfile
    import random
    import os.path
    import shutil
    import os
    import pickle
    import json

    class RequestsMock():
        def __init__(self):
            self.prepared_requests = []
            self.responses = []
            self.sessions = []
            self.prepared_request = Request()
            self.prepared_request.url = "https://httpbin.org"

# Generated at 2022-06-23 19:12:10.477012
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli import parse_output_options
    args = argparse.Namespace()
    args.output_options = parse_output_options('H,B')
    assert get_output_options(args, requests.PreparedRequest()) == (True, True)
    assert get_output_options(args, requests.Response()) == (True, True)
    args.output_options = parse_output_options('B')
    assert get_output_options(args, requests.PreparedRequest()) == (False, True)
    assert get_output_options(args, requests.Response()) == (False, True)
    args.output_options = parse_output_options('H')
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)

# Generated at 2022-06-23 19:12:13.392471
# Unit test for function program
def test_program():
    argv = ['http', '--check-status', 'http://httpbin.org/get']
    program(args=argv)
    assert argv[0] == 'http'

# Generated at 2022-06-23 19:12:19.309492
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    env = Environment(stdin=io.StringIO(), stdin_isatty=True, stdout=io.StringIO(), stdout_isatty=True, stderr=io.StringIO(),
                      stderr_isatty=True, colors=256, config_dir='~/.httpie', default_options=[], config_path='~/.httpie/config.json')
    print_debug_info(env)
    expected_output = f'HTTPie {httpie_version}\nRequests {requests_version}\nPygments {pygments_version}\nPython {sys.version}\n{sys.executable}\n{platform.system()} {platform.release()}\n\n\n{env}\n'

# Generated at 2022-06-23 19:12:20.705155
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)


# Generated at 2022-06-23 19:12:31.808071
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-23 19:12:39.140710
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    env = Environment(stderr=StringIO())
    print_debug_info(env)
    env.stderr.seek(0)
    info = env.stderr.read()
    assert httpie_version in info
    assert requests_version in info
    assert pygments_version in info
    assert sys.version in info
    assert sys.executable in info
    assert platform.system() in info
    assert platform.release() in info

# Generated at 2022-06-23 19:12:40.085623
# Unit test for function main
def test_main():
    assert main(['--debug']) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:12:46.452754
# Unit test for function print_debug_info
def test_print_debug_info():
    from tests.test_helpers import TestEnvironment
    from httpie import ExitStatus
    from httpie.cli import main
    args = ['--debug']
    env = TestEnvironment()
    main(args, env)
    assert env.stderr.getvalue() == (
        f'HTTPie {httpie_version}\n'
        f'Requests {requests_version}\n'
        f'Pygments {pygments_version}\n'
        f'Python {sys.version}\n{sys.executable}\n'
        f'{platform.system()} {platform.release()}'
        '\n\n'
        f'{repr(env)}'
        '\n'
    )
    assert main(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:12:56.961737
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    # Test when message is prepared request with no options chosen
    args.output_options = []
    message = requests.PreparedRequest()
    assert get_output_options(args=args, message=message) == (False, False)
    # Test when message is prepared request with headers chosen to be output
    # and no other options chosen
    args.output_options = [OUT_RESP_HEAD]
    message = requests.PreparedRequest()
    assert get_output_options(args=args, message=message) == (True, False)
    # Test when message is prepared request with body chosen to be output
    # and no other options chosen
    args.output_options = [OUT_RESP_BODY]
    message = requests.PreparedRequest()

# Generated at 2022-06-23 19:13:01.023307
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # Python 3.7+ on Windows
    # TODO: Find a better way to test.
    test_args = [b'hello', 'world', b'\xc3\xb1']
    result = decode_raw_args(test_args, 'utf-8')
    assert result == ['hello', 'world', 'ñ']


# Force signature type checking on mypy. https://github.com/python/mypy/issues/5374
if TYPE_CHECKING:
    main(args=List[str], env=Environment)

# Generated at 2022-06-23 19:13:03.532769
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['GET', b'http://example.com/\xe2\x98\x83'], 'utf8') ==\
        ['GET', 'http://example.com/☃']

# Generated at 2022-06-23 19:13:14.887420
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = {}
    request_message = requests.PreparedRequest()
    [req_head, req_body] = get_output_options(args, request_message)
    assert req_head == False
    assert req_body == False

    args.output_options = {'body': None, 'header': None}
    request_message = requests.PreparedRequest()
    [req_head, req_body] = get_output_options(args, request_message)
    assert req_head == True
    assert req_body == True

    args.output_options = {'body': None}
    response_message = requests.Response()
    [resp_head, resp_body] = get_output_options(args, response_message)
    assert resp_head == False
   

# Generated at 2022-06-23 19:13:22.515316
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO, BytesIO
    from httpie.context import Environment
    from httpie.status import ExitStatus
    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdout=BytesIO(),
        stdout_isatty=False,
        stderr=StringIO(),
    )
    env.stderr = 'c'
    print_debug_info(env)

# Generated at 2022-06-23 19:13:26.709211
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'\xe2\x99\xa5', 'c'], 'utf8') == ['♥', 'c']


if __name__ == '__main__':
    exit_status = main()
    sys.exit(exit_status)

# Generated at 2022-06-23 19:13:27.693181
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:13:38.173173
# Unit test for function program
def test_program():
    import requests
    import pytest
    import requests_mock
    import httpie.cli.argtypes
    import httpie.cli.definition
    import httpie.output

    mock = pytest.importorskip("mock")

    args = mock.Mock(spec=argparse.Namespace)

    # set the request body
    args.data = "hello"
    args.form = None
    args.files = None
    args.json = None
    args.response_is_json = False
    args.json_pp = False
    args.response_as_formatted_json = False
    args.timeout = 10
    args.max_redirects = 10
    args.output_options = ()
    args.session = requests.Session()
    args.stream = False
    args.check_status = True
   

# Generated at 2022-06-23 19:13:40.088452
# Unit test for function main
def test_main():
    exit_status = main(['http', '--debug'])
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:13:41.702504
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    out = io.StringIO()
    env = Environment(stdout=out, stderr=out)
    print_debug_info(env=env)
    assert out.getvalue() is not None

# Generated at 2022-06-23 19:13:51.312978
# Unit test for function print_debug_info
def test_print_debug_info():
    dummy_stderr = io.StringIO()
    env = Environment(stderr=dummy_stderr)
    print_debug_info(env)
    assert dummy_stderr.getvalue() == """HTTPie 1.0.2
Requests 2.21.0
Pygments 2.5.2
Python 3.7.3 (default, Jun 24 2019, 04:54:02) 
[GCC 9.1.0]
Linux 4.19.56-1-MANJARO x86_64

<httpie.context.Environment object at 0x7fa894f4ad68>

"""

    env = Environment(stderr=dummy_stderr, stdin=io.StringIO("Some random text"))
    print_debug_info(env)
    assert dummy_stderr.get

# Generated at 2022-06-23 19:13:54.561881
# Unit test for function main
def test_main():
    os.environ['PATH'] = ';'.join(sys.path)
    assert main() == ExitStatus.SUCCESS


if __name__ == "__main__":
    main()

# Generated at 2022-06-23 19:13:56.083575
# Unit test for function main
def test_main():
    """
    Testing main()
    """



# Generated at 2022-06-23 19:14:06.184327
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([], stdin_encoding="utf8") == []
    assert decode_raw_args(["abc"], stdin_encoding="utf8") == ["abc"]
    assert decode_raw_args([b"abc"], stdin_encoding="utf8") == ["abc"]
    assert decode_raw_args([b"abc", b"def"], stdin_encoding="utf8") == ["abc", "def"]
    assert decode_raw_args([b"abc", "def"], stdin_encoding="utf8") == ["abc", "def"]
    assert decode_raw_args([b"abc", u"def"], stdin_encoding="utf8") == ["abc", "def"]

# Generated at 2022-06-23 19:14:13.991253
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.config import Config

    args = parser.parse_args(
        args=[
            'github.com',
            'X-API-Token:42',
            'Authorization:Basic',
            'dXNlcjpzdXBlcnNlY3JldA==',
            'Accept:',
            'application/vnd.github.v3+json',
        ],
    )
    assert program(
        args=args,
        env=Environment(config=Config()),
    ) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:14:20.007450
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options=['reqHead', 'respBody'],
    )
    msg = requests.PreparedRequest()
    assert get_output_options(args=args, message=msg) == (True, False)

    msg = requests.Response()
    assert get_output_options(args=args, message=msg) == (False, True)



# Generated at 2022-06-23 19:14:28.101537
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr = io.StringIO()
    print_debug_info(env)
    debug_info = env.stderr.getvalue()
    assert 'HTTPie' in debug_info
    assert __version__ in debug_info
    assert 'Requests' in debug_info
    assert requests.__version__ in debug_info
    assert 'Pygments' in debug_info
    assert pygments.__version__ in debug_info

# Generated at 2022-06-23 19:14:33.323315
# Unit test for function main
def test_main():
    
    #Test1
    args = ['httpie', 'www.wiprodigital.com']
    exit_status = main(args)
    assert exit_status == ExitStatus.SUCCESS

    #Test2
    args = ['httpie', 'www.wiprodigital.com','--download']
    exit_status = main(args)
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-23 19:14:39.112464
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a', 'b'], stdin_encoding='ascii') == ['a', 'b']
    assert decode_raw_args(['a', b'b'], stdin_encoding='ascii') == ['a', 'b']
    assert decode_raw_args([b'a', b'b'], stdin_encoding='ascii') == ['a', 'b']

# Generated at 2022-06-23 19:14:49.450433
# Unit test for function main
def test_main():
    def test_main_regular_invocation(
        input_args,
        exit_status,
        simulated_stdout_bytes,
        simulated_stderr_bytes,
        simulated_env_vars,
        expected_env,
    ):
        simulated_stdout = BytesIO()
        simulated_stderr = BytesIO()
        expected_env.stdout = simulated_stdout
        expected_env.stderr = simulated_stderr
        actual_exit_status = main(
            args=input_args,
            env=expected_env,
        )
        assert exit_status == actual_exit_status
        assert simulated_stdout.getvalue() == simulated_stdout_bytes
        assert simulated_stderr.getvalue() == simulated_stderr_bytes

    test_main_regular_inv

# Generated at 2022-06-23 19:15:01.137955
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from io import StringIO

    env = Environment()
    env.stdin_isatty = True
    env.stdin_encoding = 'utf8'
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    env.stderr_isatty = True
    env.stderr_encoding = 'utf8'
    env.stdout = StringIO()
    env.stderr = StringIO()
    print_debug_info(env)
    assert env.stderr.getvalue().startswith('HTTPie ')
    env.stderr = None
    env.stdout = StringIO()
    print_debug_info(env)
    assert env.std

# Generated at 2022-06-23 19:15:12.768807
# Unit test for function print_debug_info
def test_print_debug_info():
    # ZSH shell, no TTY
    env = Environment(
        stdin=io.BytesIO(),
        stdin_isatty=False,
        stdout=io.BytesIO(),
        stdout_isatty=False,
        stderr=io.BytesIO(),
        stderr_isatty=False,
        colors=256,
    )
    print_debug_info(env)
    print(env.stderr.getvalue())

    env = Environment(
        stdin=io.BytesIO(),
        stdin_isatty=False,
        stdout=io.BytesIO(),
        stdout_isatty=False,
        stderr=io.BytesIO(),
        stderr_isatty=False,
        colors=256,
    )
    print_debug_info

# Generated at 2022-06-23 19:15:16.378041
# Unit test for function main
def test_main():
    exit_status = main(args=['--ignore-stdin', 'https://httpbin.org/get'])
    assert exit_status == ExitStatus.SUCCESS

    exit_status = main(args=['https://httpbin.org/get'])
    assert exit_status == ExitStatus.SUCCESS

    exit_status = main(args=['--debug'])
    assert exit_status == ExitStatus.SUCCESS

test_main()

# Generated at 2022-06-23 19:15:25.492917
# Unit test for function program
def test_program():
    from httpie.cli import get_error_exit_status
    from httpie.ui.utils import default_options
    import platform
    import requests
    import requests.hooks as hooks

    old_hooks = hooks.default_hooks()
    hooks.default_hooks.clear()

    class Response:
        def __init__(self):
            self.status_code = 200
            self.headers = {}
            self.request = 'request'

        @staticmethod
        def raise_for_status():
            pass

    class Session:
        def __init__(self):
            self.response = Response

        def prepare_request(self, request):
            return request

        def send(self, request):
            return Response()


# Generated at 2022-06-23 19:15:32.163095
# Unit test for function main
def test_main():
    class TestEnvironment:
        program_name = 'python'
        stdin_encoding = 'utf-8'
        config = {
            'default_options': ['--format', 'json', '-v']
        }
        stdout = sys.stdout
        stderr = sys.stderr

    test_exit_status = main(['python', '--debug'], env=TestEnvironment)
    assert test_exit_status == ExitStatus.SUCCESS



# Generated at 2022-06-23 19:15:40.209948
# Unit test for function get_output_options
def test_get_output_options():
    output_options = {
        requests.PreparedRequest: (
            True,
            True,
        ),
        requests.Response: (
            True,
            True,
        ),
    }
    message = requests.PreparedRequest()
    assert output_options[type(message)] == get_output_options(message,output_options)
    message = requests.Response()
    assert output_options[type(message)] == get_output_options(message,output_options)

# Generated at 2022-06-23 19:15:49.025324
# Unit test for function program
def test_program():
    import nose.tools as nt
    from io import StringIO
    from httpie.cli.definition import parser
    import httpie.cli.parser

    env = Environment(stdout=StringIO(), stderr=StringIO(), stdin=StringIO())

    try:
        parser.parse_args(args=[], env=env)
    except SystemExit as e:
        # noinspection PyUnresolvedReferences
        nt.assert_equal(e.code, ExitStatus.ERROR_NO_URL)
    else:
        nt.assert_true(False, 'SystemExit not raised')


# Generated at 2022-06-23 19:16:00.606368
# Unit test for function get_output_options
def test_get_output_options():
    # Arrange
    A = argparse.Namespace()
    A.output_options = [OUT_REQ_HEAD, OUT_RESP_BODY]
    A.output_options = set(A.output_options)

    B = argparse.Namespace()
    B.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY]
    B.output_options = set(B.output_options)

    msg1 = requests.PreparedRequest()
    msg2 = requests.Response()
    # Act
    actual1 = get_output_options(args=A, message=msg1)
    actual2 = get_output_options(args=A, message=msg2)

# Generated at 2022-06-23 19:16:02.930425
# Unit test for function program
def test_program():
    assert program(args=['GET', '/'], env=Environment()) == ExitStatus.SUCCESS


# Generated at 2022-06-23 19:16:10.312743
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options=['all'],
    )
    assert get_output_options(args, requests.PreparedRequest()) == (True, True)
    assert get_output_options(args, requests.Response()) == (True, True)

    args = argparse.Namespace(
        output_options=['none'],
    )
    assert get_output_options(args, requests.PreparedRequest()) == (False, False)
    assert get_output_options(args, requests.Response()) == (False, False)

# Generated at 2022-06-23 19:16:22.306059
# Unit test for function get_output_options

# Generated at 2022-06-23 19:16:26.768261
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'a'], 'iso8859-1') == ['a']
    assert decode_raw_args([b'a'], 'utf-8') == ['a']



# Generated at 2022-06-23 19:16:27.709496
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'foo', 'bar'], 'utf-8') == ['foo', 'bar']

# Generated at 2022-06-23 19:16:32.569370
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['--form', b'key=b\xc3\xa1r'], stdin_encoding='utf8') == ['--form', 'key=bár']

# Generated at 2022-06-23 19:16:33.721144
# Unit test for function main
def test_main():
    main(['http', '--help'])

# Generated at 2022-06-23 19:16:42.013697
# Unit test for function program
def test_program():
    import os
    import sys
    import httpie.cli.constants as C
    import httpie.cli.argtypes as AT
    import httpie.cli.utils as U
    import httpie.cli.output as O
    import httpie.cli.parser as P


    original_stderr = sys.stderr
    sys.stderr = open(os.devnull, 'w')
    original_stdout = sys.stdout
    sys.stdout = open(os.devnull, 'w')

    C, AT, U, O, P = sys.modules[__name__].C, sys.modules[__name__].AT, sys.modules[__name__].U, sys.modules[__name__].O, sys.modules[__name__].P

# Generated at 2022-06-23 19:16:54.753547
# Unit test for function print_debug_info
def test_print_debug_info():
    class TestEnv(Environment):
        def __init__(self, *args, **kwargs):
            self.stderr = io.StringIO()
            super().__init__(*args, **kwargs)

    test_env = TestEnv(colors=False)
    print_debug_info(env=test_env)

# Generated at 2022-06-23 19:16:56.080271
# Unit test for function program
def test_program():
    assert main(args = ['--debug']) == 0


# Generated at 2022-06-23 19:17:03.429978
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # Python 3.3
    if hasattr(sys.stdin, 'buffer'):
        args = [b'--form', b'a=\xe4\xb8\x96', b'b=\xe4\xb8\xad', b'c=\xe4\xb8\x89']
    else:
        args = ['--form', 'a=\xe4\xb8\x96', 'b=\xe4\xb8\xad', 'c=\xe4\xb8\x89']
    assert decode_raw_args(args, 'utf8') == ['--form', 'a=世', 'b=中', 'c=三']

# Generated at 2022-06-23 19:17:11.763872
# Unit test for function program
def test_program():
    import argparse
    from httpie.cli.definition import parser
    list_of_str_args = ['-b', 'www.google.com']
    args = parser.parse_args(args=list_of_str_args)
    exit_status = program(args=args, env=Environment())
    assert exit_status == 0
    assert len(args.args) == 1
    assert args.args[0] == 'www.google.com'
    assert args.output_options == ['format=colors']
    assert args.config.default_options == ['--pretty=all']
    assert args.config.directory == '/home/xliu4/.config'
    assert args.headers == ['Accept: application/json']
    assert args.insecure
    assert not args.output_file.closed

# Generated at 2022-06-23 19:17:13.687325
# Unit test for function program
def test_program():
    from httpie import program

    assert program(args=['http', 'httpbin.org']) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:17:23.114052
# Unit test for function decode_raw_args
def test_decode_raw_args():
    stdin_encoding = 'utf-8'
    expected = ['foo', 'bar']
    assert decode_raw_args(
        ['foo', 'bar'],
        stdin_encoding
    ) == expected
    assert decode_raw_args(
        [b'foo', 'bar'],
        stdin_encoding
    ) == expected
    assert decode_raw_args(
        ['foo', b'bar'],
        stdin_encoding
    ) == expected
    assert decode_raw_args(
        [b'foo', b'bar'],
        stdin_encoding
    ) == expected

# Generated at 2022-06-23 19:17:30.901324
# Unit test for function main
def test_main():
    
    import io
    from httpie.client import collect_messages


    # Check for prefix
    def test_main_prefix():
        out = io.StringIO()
        collect_messages = mock.MagicMock(
            return_value=[
                requests.PreparedRequest(),
                requests.Response()]
        )
        main(args=['--debug'], env=Environment(stdout=out))
        out.seek(0)
        assert out.read().startswith('HTTPie')

    # Check for HTTPie version
    def test_main_version():
        out = io.StringIO()
        collect_messages = mock.MagicMock(
            return_value=[
                requests.PreparedRequest(),
                requests.Response()]
        )

# Generated at 2022-06-23 19:17:36.208968
# Unit test for function main
def test_main():
    # Test KeyboardInterrupt
    exit_status = main(['', 'https://httpbin.org/get'])
    assert exit_status == ExitStatus.ERROR
    exit_status = main(['', 'https://httpbin.org/get'])
    assert exit_status == ExitStatus.SUCCESS
    
test_main()

# Generated at 2022-06-23 19:17:39.008533
# Unit test for function program
def test_program():
    assert get_output_options(env = "", message = "") == (None, None)


# Generated at 2022-06-23 19:17:40.047592
# Unit test for function program
def test_program():
    program('httpie-server')
    return True

# Generated at 2022-06-23 19:17:43.887634
# Unit test for function program
def test_program():
    """
    Program function unit test
    """
    args = ['www.google.com', '--debug']
    exit_status = program(args, env=Environment())
    assert exit_status == 0


# Generated at 2022-06-23 19:17:55.055935
# Unit test for function get_output_options
def test_get_output_options():
    from argparse import Namespace
    args = Namespace(output_options='')
    assert get_output_options(args, requests.PreparedRequest()) == (False, False)
    args = Namespace(output_options='H')
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)
    args = Namespace(output_options='B')
    assert get_output_options(args, requests.PreparedRequest()) == (False, True)
    args = Namespace(output_options='HB')
    assert get_output_options(args, requests.PreparedRequest()) == (True, True)
    args = Namespace(output_options='HB')
    assert get_output_options(args, requests.Response()) == (True, True)
    args = Namespace(output_options='B')


# Generated at 2022-06-23 19:18:04.731586
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'http', b'https://httpbin.org/get'], 'utf-8') == ['http', 'https://httpbin.org/get']
    assert decode_raw_args(['http', b'https://httpbin.org/get'], 'utf-8') == ['http', 'https://httpbin.org/get']
    assert decode_raw_args([b'http', 'https://httpbin.org/get'], 'utf-8') == ['http', 'https://httpbin.org/get']
    assert decode_raw_args(['http', 'https://httpbin.org/get'], 'utf-8') == ['http', 'https://httpbin.org/get']

# Generated at 2022-06-23 19:18:11.386818
# Unit test for function get_output_options
def test_get_output_options():
    ret = get_output_options(
        args = argparse.Namespace(
            output_options = [OUT_REQ_BODY, OUT_REQ_HEAD]
        ),
        message = requests.PreparedRequest()
    )
    assert ret == (True, True), ret

    ret = get_output_options(
        args = argparse.Namespace(
            output_options = [OUT_REQ_BODY]
        ),
        message = requests.PreparedRequest()
    )
    assert ret == (False, True), ret

    ret = get_output_options(
        args = argparse.Namespace(
            output_options = [OUT_REQ_HEAD]
        ),
        message = requests.PreparedRequest()
    )
    assert ret == (True, False), ret

    ret = get_output_

# Generated at 2022-06-23 19:18:21.699243
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'-H', 'foo'], 'utf8') == ['-H', 'foo']
    assert decode_raw_args([b'-H', 'foo'], 'latin1') == ['-H', 'foo']
    assert decode_raw_args([b'-H', b'\xc3\xa4'], 'utf8') == ['-H', 'ä']
    assert decode_raw_args([b'-H', b'\xc3\xa4'], 'latin1') == ['-H', 'Ä']
    assert decode_raw_args([b'-H', b'\xe5\xad\xa9\xe5\xa5\xb3'], 'gbk') == ['-H', '女']

# Generated at 2022-06-23 19:18:32.443350
# Unit test for function program
def test_program():
    import pytest
    import io, sys
    import requests

    class FakeResponse(requests.Response):
        def __init__(self):
            self.status_code = 200

    def call_program(cmd_args):
        fake_stdin = io.StringIO('')
        fake_stdout = io.StringIO()
        fake_stderr = io.StringIO()

        args = parser.parse_args(cmd_args.split())
        env = Environment(stdin=fake_stdin, stdout=fake_stdout, stderr=fake_stderr)

        program(args, env)
        return fake_stdout.getvalue()

    # TODO: Add more tests

    # 1. Test --output-options, with one request and one response

# Generated at 2022-06-23 19:18:42.995344
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=OUT_REQ_BODY + OUT_RESP_BODY)

    res_out_headers, res_out_body = get_output_options(args, requests.PreparedRequest())
    assert res_out_headers == True
    assert res_out_body == True

    res_out_headers, res_out_body = get_output_options(args, requests.Response())
    assert res_out_headers == True
    assert res_out_body == True


if __name__ == '__main__':
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(ExitStatus.ERROR_CTRL_C)

# Generated at 2022-06-23 19:18:49.080210
# Unit test for function get_output_options
def test_get_output_options():
    class TestNamespace(object):
        def __init__(self):
            self.output_options = ['req_headers', 'all_headers']

    class TestPreparedRequest(object):
        pass

    class TestResponse(object):
        pass

    test_ns = TestNamespace()
    test_req = TestPreparedRequest()
    test_resp = TestResponse()

    assert get_output_options(test_ns, test_req) == (True, True)
    assert get_output_options(test_ns, test_resp) == (True, True)

    test_ns.output_options = ['req_headers', 'resp_headers']
    assert get_output_options(test_ns, test_req) == (True, False)

# Generated at 2022-06-23 19:18:57.049215
# Unit test for function main
def test_main():
    def f(args: List[str]) -> str:
        return '\n'.join(decode_raw_args(args, 'cp1250'))
    assert f([b'http', b'--verbose']) == 'http\n--verbose'
    assert f([b'http', '--verbose']) == 'http\n--verbose'
    assert f(['http', b'--verbose']) == 'http\n--verbose'
    assert f(['http', '--verbose']) == 'http\n--verbose'