

# Generated at 2022-06-23 19:08:57.605680
# Unit test for function print_debug_info
def test_print_debug_info():
    class env():
        def __init__(self):
            self.stderr = sys.stderr
    print_debug_info(env())


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 19:09:02.173180
# Unit test for function decode_raw_args
def test_decode_raw_args():
    argv = [
        b'foo',
        'bar',
        b'baz',
        'qux'
    ]
    result = decode_raw_args(argv, 'cp437')
    assert result == ['foo', 'bar', 'baz', 'qux']
    assert all(isinstance(arg, str) for arg in result)

# Generated at 2022-06-23 19:09:13.420354
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = []
    req: requests.PreparedRequest = requests.PreparedRequest()
    resp: requests.Response = requests.Response
    assert get_output_options(args, req) == (False, False)
    args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(args, req) == (True, False)
    args.output_options = [OUT_REQ_BODY]
    assert get_output_options(args, req) == (False, True)
    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY]
    assert get_output_options(args, req) == (True, True)
    args.output_options = [OUT_RESP_HEAD]
    assert get_

# Generated at 2022-06-23 19:09:20.222907
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = [
        'http',
        'http://httpbin.org/post',
        '--form',
        b'foo=\xc5bar'
    ]
    assert (
        decode_raw_args(
            args=args,
            stdin_encoding='utf8'
        )
        == [
            'http',
            'http://httpbin.org/post',
            '--form',
            'foo=Åbar'
        ]
    )

# Generated at 2022-06-23 19:09:31.544745
# Unit test for function main
def test_main():

    class mock_stdin:
        def __init__(self, *args):
            self.buffer = bytes('mock_stdin', encoding='utf-8')

    class mock_RequestsTimeout:
        def __init__(self, *args):
            pass

    class mock_RequestsTooManyRedirects:
        def __init__(self, *args):
            pass

    class mock_HTTPError:
        def __init__(self, *args):
            pass

    class mock_ConnectionError:
        def __init__(self, *args):
            pass

    class mock_ClientError:
        def __init__(self, *args):
            pass

    class mock_ServerError:
        def __init__(self, *args):
            pass


# Generated at 2022-06-23 19:09:38.091300
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr = BytesIO()
    print_debug_info(env)
    assert env.stderr.getvalue().startswith(b'HTTPie ')
    env.stderr.close()
    env.stderr = None
    print_debug_info(env)
    assert True


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:09:46.129872
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['abc'], 'utf8') == ['abc']
    assert decode_raw_args([b'abc'], 'utf8') == ['abc']
    assert decode_raw_args([b'\xe2\x98\x83'], 'utf8') == ['☃']
    assert decode_raw_args([b'\xff'], 'utf8') == ['\ufffd']
    assert decode_raw_args([b'\xff'], 'ascii') == ['\ufffd']
    assert decode_raw_args([b'\xfe'], 'ascii') == ['\ufffd']

# Generated at 2022-06-23 19:09:47.575023
# Unit test for function main
def test_main():
    main(['httpie', '--debug'])

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 19:09:52.774556
# Unit test for function main
def test_main():
    from io import StringIO

    from httpie.config import Config
    from httpie.context import Environment
    from httpie.output.streams import OutStreams

    try:
        import unittest
        from unittest.mock import patch
    except ImportError:
        import unittest2 as unittest
        from mock import patch

    env = Environment(
        config=Config(),
        stdin=StringIO(''),
        stdin_isatty=False,
        stdout=StringIO(),
        stdout_isatty=False,
        stderr=StringIO(),
        stderr_isatty=False,
    )


# Generated at 2022-06-23 19:10:00.836262
# Unit test for function program
def test_program():
    pass
    # Base url
    args = argparse.Namespace(
        headers=[],
        max_redirects=30,
        full_url=True,
        verify=True,
        stream=False,
        timeout=30,
        check_status=False,
        json=None,
        body='',
        form=[],
        traceback=False,
        output_options=[],
        method=None,
        auth=None,
        follow=False,
        output_file=None,
        output_file_specified=False,
        download=False,
        download_resume=False,
        upload=None
    )
    args.headers = {
        'user-agent': 'HTTPie/0.9.9'
    }
    args.headers['accept'] = 'application/json'
    args

# Generated at 2022-06-23 19:10:06.107821
# Unit test for function get_output_options
def test_get_output_options():
    env = Environment()
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD]

    # assert get_output_options(args, requests.PreparedRequest()) == (True, True) # Failed, but there is no requests.PreparedRequest() in testing code
    assert get_output_options(args, requests.Response()) == (True, True)

# Generated at 2022-06-23 19:10:09.348637
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=[b'foo', b'bar'], stdin_encoding='utf8') == ['foo', 'bar']



# Generated at 2022-06-23 19:10:14.328214
# Unit test for function main
def test_main():
    from httpie.cli.parser import parse_args

    args = parse_args(args=['--traceback', 'https://httpbin.org/get'])

    assert main(['http', 'https://httpbin.org/get']) == ExitStatus.SUCCESS
    assert main(['http', 'https://httpbin.org/get'], args) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:10:26.561270
# Unit test for function main
def test_main():
    import pytest
    from httpie import config
    from httpie.context import Environment

    class MockArgumentParser(object):
        def __init__(self, args):
            self.args = args

        def parse_args(self, args, env):
            return self.args

    class MockExit(object):
        def __init__(self):
            self.code = 0

    class MockSuccess(object):
        def __init__(self):
            self.code = ExitStatus.SUCCESS

    class MockEnvironment(Environment):
        def __init__(self, stdin_encoding):
            super(MockEnvironment, self).__init__()
            self.stdin_encoding = stdin_encoding


# Generated at 2022-06-23 19:10:28.943208
# Unit test for function main
def test_main():
    sys.argv = ['http']
    args = ['https://httpbin.org/get', '--json', 'Arg1', '-X', 'POST', 'Arg2']
    main(args)

# Generated at 2022-06-23 19:10:34.180936
# Unit test for function get_output_options
def test_get_output_options():
    """
    Unit testing for function get_output_options
    """
    args = argparse.Namespace(output_options=['body', 'headers'])
    message = requests.Response()
    assert get_output_options(args, message) == (True, True)
    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (True, True)
    args = argparse.Namespace(output_options=['body'])
    assert get_output_options(args, message) == (False, True)
    assert get_output_options(args, message) == get_output_options(args, message)

# Generated at 2022-06-23 19:10:44.403176
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from tempfile import TemporaryDirectory
    from httpie.config import Config
    from httpie.context import Environment
    
    with TemporaryDirectory() as d:
        c = Config(d)
        env = Environment(
            stdin=None,
            stdin_isatty=None,
            stdout=StringIO(),
            stdout_isatty=None,
            stderr=StringIO(),
            stdout_bytes_written=0,
            stdin_encoding=None,
            stdout_encoding=None,
            stderr_encoding=None,
            config=c,
        )
        print_debug_info(env)


# Generated at 2022-06-23 19:10:55.296331
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = ['http', '--json', '-bhttpbin.org', 'http://httpbin.org/get']
    assert decode_raw_args(args=args, stdin_encoding='utf8') == args
    assert decode_raw_args(args=args, stdin_encoding='latin-1') == args
    assert decode_raw_args(args=args, stdin_encoding='utf-16') == args

    args = [b'http', b'--json', b'-bhttpbin.org', b'http://httpbin.org/post', b'a=1']
    assert decode_raw_args(args=args, stdin_encoding='utf8') == args
    assert decode_raw_args(args=args, stdin_encoding='utf-16') == args

    # noinspection SpellCheck

# Generated at 2022-06-23 19:11:06.928560
# Unit test for function print_debug_info
def test_print_debug_info():
    """
    Test if the function print_debug_info() prints the correct environment information.
    """
    from httpie.cli.constants import USER_CONFIG_DIR
    from httpie.context import Environment
    from io import StringIO
    from pathlib import Path
    from typing import List

    env = Environment(stdout=None, stdin=None, stderr=None)
    env.config.directory = USER_CONFIG_DIR
    env.config.load_config_file = False
    _stdout = StringIO()
    env.stdout = _stdout
    print_debug_info(env)
    _stdout = [x.strip() for x in _stdout.getvalue().split('\n')]
    assert type(env.stdout) is StringIO
    assert len(_stdout) == 8

# Generated at 2022-06-23 19:11:18.341153
# Unit test for function main
def test_main():
    from httpie import ExitStatus
    from httpie.context import Environment
    from io import BytesIO
    from sys import stdout as sys_stdout
    from unittest.mock import patch
    from httpie.cli.constants import OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY
    args = ['https://httpbin.org/get']
    env = Environment()
    env.config = type('config', (object,), {'default_options': ''})
    env.stdout = BytesIO()
    env.stderr = BytesIO()
    exit_status = main(args, env)
    output = sys_stdout.buffer.getvalue()
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:11:27.385914
# Unit test for function main
def test_main():
    def main_expects_bytes(args_str: str) -> (str, ExitStatus):
        bytes_args = sys.argv = decode_raw_args(args=args_str.split(), stdin_encoding='UTF-8')
        with open('tests/data/responses/google-http-bin.json', 'rb') as f:
            env = Environment(stdin=f)
        main(args=bytes_args, env=env)
        return env.stdout.buffer.getvalue().decode('UTF-8'), env.exit_status

    assert main_expects_bytes('url http://example.com') == (
        '\nHTTP/1.1 200 OK\n\n{}\n\n', ExitStatus.SUCCESS
    )

# Generated at 2022-06-23 19:11:39.668787
# Unit test for function main
def test_main():
    from httpie.cli.environment import Environment
    import os
    
    # Create fake httpie program
    fake_program_name = 'httpie'
    fake_httpie_program = os.path.join(os.path.expanduser('~'), fake_program_name)
    
    if os.path.exists(fake_httpie_program):
        os.remove(fake_httpie_program)
    
    with open(fake_httpie_program, 'w+') as httpie_prog:
        httpie_prog.write('\n')
    os.chmod(fake_httpie_program, 0o777)
    
    args = [fake_httpie_program]
    
    # copy the default env var
    default_env = os.environ.copy()
    default_env.update

# Generated at 2022-06-23 19:11:51.057345
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.context import Environment
    from io import StringIO
    import re

    info_file = StringIO()
    env = Environment(stderr=info_file)
    print_debug_info(env)
    info_file.seek(0)
    info_txt = info_file.read()
    assert re.compile('HTTPie [\d\.]+\nRequests [\d\.]+\nPygments [\d\.]+\nPython [\d\.]+\n.+\n.+\n.+').match(info_txt)
    assert re.compile('\'stdin_encoding\': \'[\w-]+\'').findall(info_txt)

# Generated at 2022-06-23 19:11:57.392147
# Unit test for function program
def test_program():
    args = [
        'main.py',
        '--output-options=all',
        '--form',
        'somefield==value',
        'http://www.test.com'
    ]
    exit_status = main(args)
    print(exit_status)
    print(type(exit_status))
    assert exit_status == 0


if __name__ == '__main__':
    test_program()

# Generated at 2022-06-23 19:12:03.015833
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(stdout=sys.stdout, stderr=sys.stderr, stdin=sys.stdin)
    output = sys.stdout
    def mock_write(data):
        output.write(data)
    env.stderr.write = mock_write
    print_debug_info(env)
    sys.stdout.close()

# Generated at 2022-06-23 19:12:14.328076
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # test with str
    assert ['http', 'http://example.com'] == decode_raw_args(['http', 'http://example.com'], 'utf-8')
    assert ['http', 'ISO-8859-1:http://example.com'] == decode_raw_args(['http', 'ISO-8859-1:http://example.com'], 'utf-8')
    assert ['--form', 'utf-8:id=\u4f60\u597d'] == decode_raw_args(['--form', 'utf-8:id=\u4f60\u597d'], 'utf-8')
    assert ['utf-8:id=\u4f60\u597d'] == decode_raw_args(['utf-8:id=\u4f60\u597d'], 'utf-8')

# Generated at 2022-06-23 19:12:15.387025
# Unit test for function program
def test_program():
    print(program())



# Generated at 2022-06-23 19:12:23.865892
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=[], stdin_encoding='utf-8') == []
    assert decode_raw_args(args=['foo'], stdin_encoding='utf-8') == ['foo']
    assert decode_raw_args(args=[b'foo'], stdin_encoding='utf-8') == ['foo']
    assert decode_raw_args(
        args=[b'\xff'],
        stdin_encoding='latin-1',
    ) == ['\xff']

# Generated at 2022-06-23 19:12:26.470858
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options={OUT_REQ_HEAD, OUT_RESP_BODY})
    assert get_output_options(args, requests.Response(status_code=200)) == (True, True)
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)

# Generated at 2022-06-23 19:12:34.138007
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'a', 'b', b'c'], 'utf-8') == ['a', 'b', 'c']
    assert decode_raw_args([b'a', 'b', b'c'], 'iso-8859-1') == ['á', 'b', 'ç']
    assert decode_raw_args([b'a', 'b', b'c'], 'ascii') == ['a', 'b', 'c']
    with pytest.raises(UnicodeDecodeError):
        decode_raw_args([b'a', 'b', b'c'], 'ascii') == ['á', 'b', 'ç']

# Generated at 2022-06-23 19:12:38.263133
# Unit test for function program
def test_program():
     data = [[1, 1], [1, 2], [2, 1], [2, 2]]
     for row in data:
         print(row)
 
if __name__ == '__main__':
     test_program()

# Generated at 2022-06-23 19:12:43.926497
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_BODY]
    message = requests.PreparedRequest()
    out = get_output_options(args, message)
    assert(out[0] and out[1])
    message = requests.Response()
    out = get_output_options(args, message)
    assert(not out[0] and out[1])


# Generated at 2022-06-23 19:12:53.140415
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # Mock sys.argv
    sys.argv = [b'test.py', b'\xe7\x9a\x84\xe6\x96\x87\xe6\x9c\xac', b'\xe7\xb9\x81\xe9\xab\x94']
    args = decode_raw_args(sys.argv, 'utf-8')
    assert args[0] == 'test.py'
    assert args[1] == '的文本'
    assert args[2] == '繁體'

# Generated at 2022-06-23 19:12:56.881561
# Unit test for function main
def test_main():
    import sys
    import json
    import os
    import urllib
    import prettytable
    sys.argv=[sys.argv[0],'www.google.com']
    exit_status=main()

# Generated at 2022-06-23 19:13:00.869388
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.headers = None
    env = Environment()
    print(program(args=args, env=env))


if __name__ == '__main__':
    program(args, env=Environment())

# Generated at 2022-06-23 19:13:02.145364
# Unit test for function main
def test_main():
    assert main(['http', '--version']) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:13:14.259338
# Unit test for function main
def test_main():
    from unittest import mock

    # Old-style class because of Python 2.
    class MockArgParser(object):
        def parse_args(self, args, env):
            return args

    # Old-style class because of Python 2.
    class MockEnvironment(object):
        def __init__(self):
            self.called_counter = 0

        def __call__(self, *args, **kwargs):
            self.called_counter += 1
            return self

        def __enter__(self):
            return self

        def __exit__(self, *args, **kwargs):
            return self

    mock_parser = MockArgParser()
    mock_env = MockEnvironment()


# Generated at 2022-06-23 19:13:25.709497
# Unit test for function program
def test_program():
    class Namespace:
        def __init__(self, headers, output_options, output_file, output_file_specified, follow, download,
                     download_resume, check_status, quiet):
            self.headers = headers
            self.output_options = output_options
            self.output_file = output_file
            self.output_file_specified = output_file_specified
            self.follow = follow
            self.download = download
            self.download_resume = download_resume
            self.check_status = check_status
            self.quiet = quiet

    class Env:
        def __init__(self, stdout_isatty):
            self.stdout_isatty = stdout_isatty

    args = Namespace([], [], None, None, True, True, None, True, False)

# Generated at 2022-06-23 19:13:32.045411
# Unit test for function program
def test_program():
    args = program(args = parser.parse_args(
        args = ['httpie.exe', 'https://httpbin.org/get', '-v'],
        env = Environment()), env = Environment())
    assert args == 0

if __name__ == '__main__':
    exit(main())
    # Unit test for function main
    test_program()

# Generated at 2022-06-23 19:13:38.538323
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert (decode_raw_args(
        [b'http', 'get', 'example.org'],
        'utf-8'
    ) == ['http', 'get', 'example.org'])
    assert (decode_raw_args(
        ['http', 'get', ''],
        'utf-8'
    ) == ['http', 'get', ''])

# Generated at 2022-06-23 19:13:39.168468
# Unit test for function program
def test_program():
    print(program())

# Generated at 2022-06-23 19:13:46.141479
# Unit test for function main
def test_main():
    assert main(['--help']) == ExitStatus.SUCCESS
    assert main(['--version']) == ExitStatus.SUCCESS
    assert main(['--debug']) == ExitStatus.SUCCESS
    assert main(['--traceback', '--debug']) == ExitStatus.SUCCESS
    assert main(['GET', 'https://httpie.org']) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:13:48.481228
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'-', b'bar'], 'utf8') == ['-', 'bar']

# Generated at 2022-06-23 19:13:54.933364
# Unit test for function main
def test_main():
    assert main(args=['get', 'http://httpbin.org/status/418']) == ExitStatus.ERROR
    assert main(args=['get', 'http://httpbin.org/status/500']) == ExitStatus.ERROR
    assert main(args=['get', 'http://httpbin.org/status/200']) == ExitStatus.SUCCESS


# Generated at 2022-06-23 19:14:03.632773
# Unit test for function get_output_options
def test_get_output_options():
    import argparse, requests
    args = argparse.Namespace()
    args.output_options = [
        OUT_REQ_HEAD,
        OUT_REQ_BODY
    ]
    req = requests.PreparedRequest()
    assert get_output_options(args, req) == (True, True)
    args.output_options = [
        OUT_REQ_HEAD
    ]
    assert get_output_options(args, req) == (True, False)
    args.output_options = [
        OUT_REQ_BODY
    ]
    assert get_output_options(args, req) == (False, True)
    args.output_options = []
    assert get_output_options(args, req) == (False, False)

# Generated at 2022-06-23 19:14:07.102827
# Unit test for function program
def test_program():
    import httpie
    from httpie import ExitStatus
    args = httpie.cli.parser.parse_args(['www.google.com'])
    env = httpie.Environment()
    assert program(args,env) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:14:12.917415
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options=[OUT_REQ_HEAD, OUT_RESP_HEAD, OUT_RESP_BODY],
    )
    for message_type in [requests.PreparedRequest, requests.Response]:
        with_headers, with_body = get_output_options(
            args=args,
            message=message_type()
        )
        if message_type is requests.PreparedRequest:
            assert with_body is False
            assert with_headers is True
        else:
            assert with_body is True
            assert with_headers is True

# Generated at 2022-06-23 19:14:16.576975
# Unit test for function main
def test_main():
    import pytest
    with pytest.raises(SystemExit) as e:
        main(args=['--debug'])
    assert e.value.code == 0

# Generated at 2022-06-23 19:14:18.038670
# Unit test for function program
def test_program():
    def program():
        return True
    assert program() == True


# Generated at 2022-06-23 19:14:24.861716
# Unit test for function get_output_options
def test_get_output_options():
    import unittest
    
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.manager import plugin_manager
    
    from httpie.cli.definition import parser
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    
    from httpie.client import collect_messages
    
    from httpie.status import ExitStatus, http_status_to_exit_status
    
    env = Environment()
    args = parser.parse_args(env=env, args=['GET', 'http://httpbin.org/headers'])
    assert(get_output_options(args=args, message=requests.Response()) == (False, True))
    
    args = parser

# Generated at 2022-06-23 19:14:33.280631
# Unit test for function main
def test_main():
    http_status_to_exit_status(http_status=200)
    http_status_to_exit_status(http_status=203)
    http_status_to_exit_status(http_status=300)
    http_status_to_exit_status(http_status=301)
    http_status_to_exit_status(http_status=302)
    http_status_to_exit_status(http_status=303)
    http_status_to_exit_status(http_status=404)
    http_status_to_exit_status(http_status=500)

# Generated at 2022-06-23 19:14:36.897376
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    env = Environment(stdout=StringIO, stderr=StringIO)
    print_debug_info(env)


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:14:38.212731
# Unit test for function main
def test_main():
    import sys
    assert main(['http']) == ExitStatus.ERROR


# Generated at 2022-06-23 19:14:42.754107
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['\x1b[38;5;2m¬', 'two'], 'ascii') == ['¬', 'two']

# Generated at 2022-06-23 19:14:44.998905
# Unit test for function main
def test_main():
    env = Environment()
    args = [env.program_name, '--debug']
    is_debug_mode = True
    main(args,env)

# Generated at 2022-06-23 19:14:57.921985
# Unit test for function main
def test_main():
    from httpie.context import Environment
    from httpie.output.writer import MESSAGE_SEPARATOR_BYTES

    class MyEnv(Environment):
        def __init__(self, stdout_isatty: bool):
            super().__init__()
            self.stdout = io.BytesIO()
            self.stderr = io.BytesIO()
            self.stdout_isatty = stdout_isatty

    env = MyEnv(True)

    # Test success
    sys.argv = ['http', '--debug', 'httpbin.org']
    assert main(env=env) == ExitStatus.SUCCESS

    # Test error
    args = ['http', "https://httpbin.org/status/500"]

    # Test long error message

# Generated at 2022-06-23 19:15:10.306771
# Unit test for function main
def test_main():
    import tempfile
    import os.path
    import requests
    import httpie
    httpie_path=httpie.__file__
    httpie_abs_path=os.path.dirname(os.path.abspath(httpie_path))
    httpie_exe=httpie_abs_path+"//http"
    args=[httpie_exe,"--download","-o","tmp_file"]
    tmp_file=tempfile.NamedTemporaryFile().name
    env=Environment(standard_stream1=tempfile.NamedTemporaryFile(),
                    standard_stream2=tempfile.NamedTemporaryFile(),
                    standard_stream3=tempfile.NamedTemporaryFile(),
                    config_directory=tempfile.NamedTemporaryFile().name)
    #args=["http","--download","-o","tmp_

# Generated at 2022-06-23 19:15:17.061715
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    f = StringIO()
    stdin_encoding='utf-8'
    env = Environment(
        stdin=StringIO(),
        stdin_isatty=True,
        stdin_encoding=stdin_encoding,
        stdout=StringIO(),
        stdout_isatty=True,
        stdout_encoding=stdin_encoding,
        stdout_raw=True,
        stderr=f,
        stderr_isatty=True,
        stderr_encoding=stdin_encoding,
    )
    print_debug_info(env)
    #print(f.getvalue())
    s = f.getvalue()
    assert 'Python' in s
    assert 'HTTPie' in s
    assert 'Requests' in s

# Generated at 2022-06-23 19:15:24.344079
# Unit test for function main
def test_main():
    from httpie.cli.test import http
    import os, sys
    from . import main
    from httpie import __version__ as httpie_version
    from httpie.client import StreamSender, __version__ as httpie_client_version

    test_path = os.path.dirname(__file__)
    f = open(os.path.join(test_path, "request_headers.txt"), "rb")
    sys.stdin = f
    env = Environment()

    assert(main(['--debug'], env=env) == ExitStatus.SUCCESS)



# Generated at 2022-06-23 19:15:35.358336
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(default_options=['--form'], output_options=[], max_redirects=10,
                              max_headers=None, compression=True, output_file=None, output_file_specified=False,
                              output_file_safe=True, output=None, verify=True, auth=None, insecure=False,
                              download=False, download_resume=False, follow=False,
                              check_status=False, timeout=None, max_error_length=4096, body_max_size=None)
    msg0 = requests.PreparedRequest()
    msg0.method = 'get'
    msg0.url = 'http://httpbin.org/get'
    msg0.headers = {'user-agent': 'https'}

# Generated at 2022-06-23 19:15:44.510530
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=["resp.headers"])

    assert get_output_options(args, requests.Request("GET", "https://a.b")) == (True, False)

    assert get_output_options(args, requests.Response()) == (True, False)

    args = argparse.Namespace(output_options=["resp.body"])
    assert get_output_options(args, requests.Request("GET", "https://a.b")) == (False, True)

    assert get_output_options(args, requests.Response()) == (False, True)

# Generated at 2022-06-23 19:15:50.970174
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # test all args are bytes
    args = [b'-X', b'POST', b'http://example.org', b'foo=bar']
    stdin_encoding = 'utf8'
    result = decode_raw_args(args, stdin_encoding)
    assert result == ['-X', 'POST', 'http://example.org', 'foo=bar']

    # test contains string args
    args = [b'-X', b'POST', 'http://example.org', b'foo=bar']
    stdin_encoding = 'utf8'
    result = decode_raw_args(args, stdin_encoding)
    assert result == ['-X', 'POST', 'http://example.org', 'foo=bar']

# Generated at 2022-06-23 19:15:55.942299
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['--form'], stdin_encoding='utf-8') == ['--form']
    assert decode_raw_args([b'A\xe3'], stdin_encoding='utf-8') == ['A\u00e3']

# Generated at 2022-06-23 19:16:03.919347
# Unit test for function main
def test_main():
    from httpie.context import Environment

    class MockArgParse:
        def __init__(self):
            self.quiet = False
            self.check_status = False
            self.download = False
            self.stream = False
            self.output_options = ['h']
            self.headers = {}
            self.timeout = None
            self.max_redirects = None
            self.follow = False
            self.verify = True
            self.verify_all = True
            self.request_items = []
            self.output_file = None
            self.output_file_specified = False
            self.download_resume = False

    env = Environment()
    args = MockArgParse()


# Generated at 2022-06-23 19:16:13.421751
# Unit test for function main
def test_main():
    import logging
    import tempfile
    from httpie.cli.context import Environment

    env = Environment()
    env.stdout = tempfile.TemporaryFile('w+b')
    env.stderr = tempfile.TemporaryFile('w+b')
    env.stdin_encoding = 'ascii'
    env.stdout_isatty = True
    env.color = True
    env.debug = True
    env.log_level = logging.INFO


# Generated at 2022-06-23 19:16:19.976022
# Unit test for function print_debug_info
def test_print_debug_info():

    class MockStdErr:

        def __init__(self):
            self.buf = []

        def writelines(self, lines):
            self.buf += lines

        def write(self, line):
            self.buf.append(line)

    env = Environment()
    env.stderr = MockStdErr()
    print_debug_info(env)



# Generated at 2022-06-23 19:16:26.651511
# Unit test for function main
def test_main():
    import unittest
    import sys

    class MainTestCase(unittest.TestCase):
        def setUp(self):
            self.old_argv = sys.argv
            sys.argv = ['http']

        def tearDown(self):
            sys.argv = self.old_argv

        def test_program_nonexistent(self):
            sys.argv[0] = '/nonexistent'
            with self.assertRaises(SystemExit):
                main()

        def test_program_mocked(self):
            sys.argv[0] = __file__
            try:
                main()
            except Exception:
                self.fail('unexpected exception')

    unittest.main()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 19:16:27.193301
# Unit test for function main
def test_main():
    assert isinstance(main(), int)

# Generated at 2022-06-23 19:16:34.280468
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['welcome'], 'utf-8') == ['welcome']
    assert decode_raw_args([b'welcome'], 'utf-8') == ['welcome']
    assert decode_raw_args([b'\xe9\xa9\xac\xe6\x99\xae'], 'utf-8') == ['马普']
    assert decode_raw_args([b'\xe9\xa9\xac\xe6\x99\xae'], 'ascii') == ['é©¬æ™®']
    assert decode_raw_args([b'\xe9\xa9\xac\xe6\x99\xae'], 'gbk') == ['马普']

# Generated at 2022-06-23 19:16:36.716995
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr.write = lambda x: None
    print_debug_info(env)

# Generated at 2022-06-23 19:16:38.857321
# Unit test for function main
def test_main():
    from httpie import ExitStatus
    status = main(['http', '--debug'])
    assert status == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:16:50.607299
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import io
    env = Environment(stdout=io.StringIO(), stderr=io.StringIO())
    print_debug_info(env)
    env.stderr.write('\n')

# Generated at 2022-06-23 19:16:53.693379
# Unit test for function main
def test_main():
    '''
    Make sure program can be imported.
    '''
    assert main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 19:16:54.278598
# Unit test for function get_output_options
def test_get_output_options():
    pass

# Generated at 2022-06-23 19:16:56.484996
# Unit test for function decode_raw_args
def test_decode_raw_args():
    return decode_raw_args(["I love", "你好", "Привет", "世界", "אזה"], "utf-8")

# Generated at 2022-06-23 19:17:04.612897
# Unit test for function program
def test_program():
    class my_stdin:
        def isatty(self):
            return True

    class my_stdout:
        def isatty(self):
            return True

    class my_stderr:
        def write(self, data: str):
            print(data)

        def isatty(self):
            return True

    class my_argparser:
        def parse_args(self, *args, **kwargs):
            return 'my_argparser'

    class my_downloader:
        def __init__(self, output_file, progress_file, resume):
            self.output_file = output_file
            self.progress_file = progress_file
            self.resume = resume
            self.status = type('', (), {})()
            self.status.total_size = 20
            self.status

# Generated at 2022-06-23 19:17:10.738189
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # check for empty list
    assert decode_raw_args([], 'utf-8') == []
    # check for mixed bytes, str
    assert decode_raw_args([b'hi', 'hello'], 'utf-8') == ['hi', 'hello']
    assert decode_raw_args(['hi', b'hello'], 'utf-8') == ['hi', 'hello']
    assert decode_raw_args([b'hi', b'hello'], 'utf-8') == ['hi', 'hello']


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 19:17:13.583324
# Unit test for function program
def test_program():
    exit_status = program(args=['httpie', 'httpbin.org/ip'], env=Environment())
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:17:25.293819
# Unit test for function main
def test_main():
    import unittest
    import os
    import sys
    import shutil
    from httpie.compat import is_windows
    from httpie.cli.constants import DEFAULT_CONFIG_DIR

    class TestMain(unittest.TestCase):

        def setUp(self):
            if os.path.isdir(DEFAULT_CONFIG_DIR):
                shutil.rmtree(DEFAULT_CONFIG_DIR)
            self.env = Environment()

        def tearDown(self):
            shutil.rmtree(DEFAULT_CONFIG_DIR)


        def test_invalid_args(self):
            self.assertRaises(SystemExit, main, args=[sys.argv[0], '--output-option'])



# Generated at 2022-06-23 19:17:27.977036
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = ['verbose']
    output_options = get_output_options(args=args, message=requests.PreparedRequest())
    assert(output_options == (True, True))

# Generated at 2022-06-23 19:17:40.451043
# Unit test for function program
def test_program():
    import io
    import json
    import httpie
    import httpie.plugins
    plugin_manager.get_plugins()
    httpie.plugins.manager.load_installed_plugins()
    class Env():
        program_name="httpie"
        config=httpie.config.Config(directory=".")
        stdin_encoding='utf-8'
        stdout=io.BytesIO()
        stdout_isatty=True
        stderr=io.BytesIO()
        stderr_isatty=True
    args=[
        "https://jsonplaceholder.typicode.com/todos/1",
        "-v"
    ]
    main2(args=args, env=Env)
    class HttpRequest():
        def __init__(self):
            self.method="GET"


# Generated at 2022-06-23 19:17:48.045962
# Unit test for function print_debug_info
def test_print_debug_info():
    import sys
    import io
    import tempfile
    t = tempfile.TemporaryFile()
    sys.stderr = t
    print_debug_info()
    t.seek(0)
    lines = t.read().decode('utf-8').splitlines()
    assert lines[0].startswith('HTTPie')
    assert lines[1].startswith('Requests')
    assert lines[2].startswith('Pygments')
    assert lines[3].startswith('Python')
    assert lines[4].startswith(platform.system())
    assert lines[5]
    assert lines[6]



# Generated at 2022-06-23 19:17:54.504844
# Unit test for function decode_raw_args
def test_decode_raw_args():
    bytes_args = ['a', 'b', 'c']
    str_args = ['x', 'y', 'z']
    mixed_args = ['2', b'3', '4']
    assert decode_raw_args(bytes_args, 'utf-8') == bytes_args
    assert decode_raw_args(str_args, 'utf-8') == str_args
    assert decode_raw_args(mixed_args, 'utf-8') == mixed_args

# Generated at 2022-06-23 19:17:59.571762
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [b'request', b'pretty']
    msg1 = requests.PreparedRequest()
    msg2 = requests.Response()
    assert get_output_options(args, msg1) == (True, True)
    assert get_output_options(args, msg2) == (True, True)

# Generated at 2022-06-23 19:18:08.580827
# Unit test for function program

# Generated at 2022-06-23 19:18:15.091533
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args_with_bytes = ['http', b'--json', 'http://httpie.org']
    assert decode_raw_args(args_with_bytes, "utf8") == ['http', '--json', 'http://httpie.org']
    assert decode_raw_args(args_with_bytes, "utf8") != ['http', '--json', 'http://httpie.org']


# Generated at 2022-06-23 19:18:23.945764
# Unit test for function print_debug_info
def test_print_debug_info():
    class MockStderr:
        def __init__(self):
            self.buff = []

        def write(self, msg):
            self.buff.append(msg)

    def test_assertion(expected, actual):
        assert expected in actual

    result = MockStderr()
    print_debug_info(Environment(result))
    test_assertion(f'HTTPie {httpie_version}',result.buff)
    test_assertion(f'Requests {requests_version}',result.buff)
    test_assertion(f'Pygments {pygments_version}',result.buff)
    test_assertion(f'Python {sys.version}',result.buff)
    test_assertion(f'{platform.system()} {platform.release()}',result.buff)

# Generated at 2022-06-23 19:18:25.369411
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'a\xc2\xb2'], 'utf-8') == ['a\xb2']



# Generated at 2022-06-23 19:18:34.047582
# Unit test for function main
def test_main():
    # Test function main
    _main = main
    # 1
    args = ['python', 'http', 'GET', 'http://example.com']
    env = Environment(stdin=None, stdin_isatty=False, stdout=None,
                      stdout_isatty=False, stderr=None,
                      stderr_isatty=False, configuration_dir=None,
                      configuration_file=None, configuration_defaults=None)
    _main(args=args, env=env)
    # 2
    args = ['python', 'http', '--output', 'httpie.txt', 'GET', 'http://example.com']

# Generated at 2022-06-23 19:18:44.396277
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['abc'], 'utf8') == ['abc']
    assert decode_raw_args([b'abc'], 'utf8') == ['abc']
    assert decode_raw_args([b'\xe3\x81\x82\xe3\x81\x84\xe3\x81\x86'], 'utf8') == ['あいう']
    assert decode_raw_args([b'\xe3\x81\x82\xe3\x81\x84\xe3\x81\x86'], 'utf16') == ['']

# Generated at 2022-06-23 19:18:48.880015
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        args=[b'arg1', b'\xe1\x88\xb4'],
        stdin_encoding='utf-8'
    ) == ['arg1', 'ሴ']

# Generated at 2022-06-23 19:18:53.258462
# Unit test for function main
def test_main():
    """
    Basic unit test for function main
    """
    print('httpie main.py: start testing function main')
    print('httpie main.py: end testing function main')


# Generated at 2022-06-23 19:19:01.205653
# Unit test for function print_debug_info
def test_print_debug_info():
    class Env(object):
        def __init__(self):
            self.stderr = []

        def write(self, msg):
            self.stderr.append(msg)

    test_env = Env()
    print_debug_info(test_env)
    expected_result = [
        'HTTPie ' + httpie_version + '\n',
        'Requests ' + requests_version + '\n',
        'Pygments ' + pygments_version + '\n',
        'Python ' + sys.version + '\n',
        sys.executable + '\n',
        platform.system() + ' ' + platform.release(),
    ]
    assert test_env.stderr == expected_result


# Simple unit test for main()