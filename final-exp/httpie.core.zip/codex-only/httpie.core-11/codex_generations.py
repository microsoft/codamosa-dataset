

# Generated at 2022-06-23 19:09:00.532745
# Unit test for function get_output_options
def test_get_output_options():
    request_1 = b'POST / HTTP/1.1\r\n' \
                b'Content-Type: application/json\r\n' \
                b'content-length: 11\r\n\r\n' \
                b'{"111": 222}'
    response_1 = b'HTTP/1.1 200 OK\r\n' \
                 b'Content-Type: application/json\r\n\r\n' \
                 b'{"111": 222}'

    parser = argparse.ArgumentParser()
    parser.add_argument('--output-options', default='')
    args = parser.parse_args([f'--output-options={option_string}'])
    args.timeout = 1.0
    args.max_redirects = 1


# Generated at 2022-06-23 19:09:05.245516
# Unit test for function main
def test_main():
    from httpie import __version__ as httpie_version
    from httpie.core import main

    # TODO: Define environment in a way that allows to set stdin, stdout, and stderr.
    environment = Environment(
        program_name='http',
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        config_dir=None,
        env={},
        version_info=(httpie_version, ),
    )

    assert main(args=['http', '--version'], env=environment) == ExitStatus.SUCCESS


__all__ = ('main', )

# Generated at 2022-06-23 19:09:06.419024
# Unit test for function program
def test_program():

    quit(0)

# Generated at 2022-06-23 19:09:11.032875
# Unit test for function program
def test_program():
    from tempfile import TemporaryDirectory
    from httpie.cli.definition import parser

    def run(*args):
        if len(args) == 1 and isinstance(args[0], list):
            args = args[0]
        args = parser.parse_args(args=args, env=Environment())
        return program(args=args, env=Environment())

    # TODO: Use a tmp file instead of stdout
    # TODO: Expand!
    assert run('httpie', '--json', '--pretty=all', 'http://example.org') == ExitStatus.SUCCESS
    assert run('httpie', 'http://httpbin.org/post', '--download', '--output=test.out') == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:09:13.869358
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [
        OUT_REQ_HEAD, OUT_RESP_HEAD, OUT_RESP_BODY,
    ]
    msg_req = requests.PreparedRequest()
    msg_resp = requests.Response()
    assert get_output_options(args, msg_req) == (True, False)
    assert get_output_options(args, msg_resp) == (True, True)

# Generated at 2022-06-23 19:09:14.973378
# Unit test for function main
def test_main():
    args = ['--debug', '--check-status']
    assert main(args) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:09:17.357438
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['foo', 'bar'], 'ascii') == ['foo', 'bar']


# Generated at 2022-06-23 19:09:29.939392
# Unit test for function get_output_options
def test_get_output_options():
    import argparse

    def _initialize_args(output_options):
        args = argparse.Namespace()
        args.output_options = output_options
        return args

    def _test(output_options, message_class, with_headers, with_body):
        args = _initialize_args(output_options)
        message = message_class()
        actual_with_headers, actual_with_body = get_output_options(args, message)
        assert with_headers == actual_with_headers
        assert with_body == actual_with_body

    _test([], requests.PreparedRequest, False, False)
    _test([], requests.Response, False, False)
    _test([OUT_REQ_HEAD], requests.PreparedRequest, True, False)

# Generated at 2022-06-23 19:09:38.339727
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_BODY, OUT_RESP_HEAD]
    message = requests.PreparedRequest()
    result = get_output_options(args, message)
    assert True == result[0]
    assert True == result[1]
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_BODY, OUT_RESP_HEAD]
    message = requests.Response()
    result = get_output_options(args, message)
    assert False == result[0]
    assert True == result[1]
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_BODY, OUT_RESP_HEAD]
    message = 'abcd'
    result = get_output_

# Generated at 2022-06-23 19:09:46.321292
# Unit test for function get_output_options
def test_get_output_options():
    args_req = argparse.Namespace(output_options=[1,2,3])
    args_resp = argparse.Namespace(output_options=[8])
    message_req = requests.PreparedRequest()
    message_resp = requests.Response()

    assert get_output_options(args_req, message_req) == (True, True)
    assert get_output_options(args_req, message_resp) == (False, False)
    assert get_output_options(args_resp, message_req) == (False, False)
    assert get_output_options(args_resp, message_resp) == (False, True)

# Generated at 2022-06-23 19:09:53.633042
# Unit test for function program
def test_program():
    import os
    import httpie
    # Build arguments list
    args = ['test.py']
    args.append('http://localhost:8080/upload/')
    args.append('-f')
    args.append(os.path.abspath(os.path.join(os.path.dirname(httpie.__file__), '../../test-data/upload.txt')))
    # Build env dictionary
    env = {}
    env['stdout'] = {}
    env['config'] = {}
    env['config']['default_options'] = ['test.py']
    env['config']['default_options'].append('http://localhost:8080/upload/')
    env['config']['default_options'].append('-f')

# Generated at 2022-06-23 19:09:59.346990
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['foo', 'b\xc3\xa4r'], 'UTF-8') == ['foo', 'bär']
    assert decode_raw_args([b'foo', 'b\xc3\xa4r'], 'UTF-8') == ['foo', 'bär']
    assert decode_raw_args([b'foo', b'b\xc3\xa4r'], 'UTF-8') == ['foo', 'bär']

# Generated at 2022-06-23 19:10:08.163460
# Unit test for function decode_raw_args

# Generated at 2022-06-23 19:10:19.065159
# Unit test for function main
def test_main():
    """
    Test the function main
    """
    import logging
    import os
    import platform
    import shutil
    import sys
    from unittest.mock import MagicMock

    from httpie import ExitStatus
    from httpie.client import collect_messages
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins import plugin_manager

    from . import httpbin  # noqa

    class MockExitCode:

        def __init__(self):
            self.exit_code = ExitStatus.SUCCESS

        def __call__(self, *_):
            sys.exit(self.exit_code)

    logging_level = logging.root.getEffectiveLevel()

# Generated at 2022-06-23 19:10:28.471842
# Unit test for function main
def test_main():
    env = Environment()
    env.stdout.isatty = True
    env.stdout.encoding = 'utf8'
    env.stdout.buffer.encoding = 'utf8'
    env.stdout.buffer.isatty = True
    env.config.color = True

# Generated at 2022-06-23 19:10:38.610889
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from unittest import TestCase

    class DecodeRawArgsTests(TestCase):

        def test_all_str(self):
            input = ['a', 'b', 'c', 'd']
            expected_output = ['a', 'b', 'c', 'd']
            self.assertEqual(expected_output, decode_raw_args(input, 'UTF-8'))

        def test_all_bytes(self):
            input = [b'a', b'b', b'c', b'd']
            expected_output = ['a', 'b', 'c', 'd']
            self.assertEqual(expected_output, decode_raw_args(input, 'UTF-8'))

        def test_mixed_types(self):
            input = ['a', b'b', 'c', b'd']
            expected

# Generated at 2022-06-23 19:10:44.246309
# Unit test for function decode_raw_args
def test_decode_raw_args():
    bytes_args = ['http', b'--json', b'{"id":3}', 'https://example.com/?a=\xe4']
    str_args = decode_raw_args(bytes_args, 'utf-8')
    assert str_args == ['http', '--json', '{"id":3}', 'https://example.com/?a=\xe4']

# Generated at 2022-06-23 19:10:55.152251
# Unit test for function program
def test_program():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeout", type=int)
    parser.add_argument("--max-redirects", type=int)
    parser.add_argument("--output-file", type=argparse.FileType)
    parser.add_argument("--download", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--check-status", action="store_true")
    parser.add_argument("--download-resume", action="store_true")
    parser.add_argument("--output-options")

# Generated at 2022-06-23 19:11:06.784281
# Unit test for function program
def test_program():
    class TestNamespace:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    from httpie.output.streams import StdoutStream
    import os
    from httpie.output.formatters.default import DefaultJSONFormatter
    from httpie.context import Environment
    env = Environment()
    env.stdout = StdoutStream(DefaultJSONFormatter())
    env.stdout_isatty = lambda: False
    env.color = False
    env.config.default_options = ["--debug"]
    env.verify = True
    env.config.use_https = True
    env.allow_auto_redirects = False
    env.headers = {"accept-encoding": "gzip, deflate"}
    env.config.directory = os.getcwd

# Generated at 2022-06-23 19:11:08.614133
# Unit test for function main
def test_main():
    assert main([]) == ExitStatus.ERROR
    assert main(['-v']) == ExitStatus.SUCCESS
    assert main(['-vv']) == ExitStatus.SUCCESS
    assert main(['-h']) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:11:18.422321
# Unit test for function main
def test_main():

    class MockEnv(Environment):

        def __init__(self):
            super().__init__()
            self.program_name = "Mock_program_name"
            self.debug = True
            self.log_level = "debug"
            self.stdout_isatty = True
            self.stdout_encoding = "utf-8"
            self.stdin_encoding = "utf-8"
            self.stderr_isatty = True
            self.stderr_encoding = "utf-8"
            self.config_dir = None
            self.colors = False
            self.key_data_format = "form"
            self.prettify = False
            self.style = None
            self.output_options = "-b"
            self.max_redirects = None


# Generated at 2022-06-23 19:11:25.361217
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=['h', 'Hb', 'bb'])
    request = requests.PreparedRequest()
    response = requests.Response()
    assert get_output_options(args, request) == (True, False), "Expected request to have headers only"
    assert get_output_options(args, response) == (True, True), "Expected response to have body and headers"
    response.raw = None # Hack to get write_message to not try to write a body for the response
    assert get_output_options(args, response) == (True, False), "Expected response to have no body with raw None"

# Generated at 2022-06-23 19:11:31.992258
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_HEAD, OUT_RESP_HEAD, OUT_RESP_BODY]
    msg = requests.PreparedRequest()
    assert get_output_options(args, msg) == (True, False)
    msg = requests.Response()
    assert get_output_options(args, msg) == (True, True)



# Generated at 2022-06-23 19:11:43.735151
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.context import Environment
    from httpie.cli.definition import parser
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    env = Environment()
    args = ["-b", "--pretty=all"]
    parsed_args = parser.parse_args(args=args, env=env)
    message = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args=parsed_args, message=message)
    assert (with_headers == True) and (with_body == True)

    message = requests.Response()
    parsed_args.output_options = [OUT_RESP_BODY, OUT_RESP_HEAD]

# Generated at 2022-06-23 19:11:45.996368
# Unit test for function main
def test_main():
    args = ['http', '--check-status']
    result = main(args)
    assert result == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:11:52.706240
# Unit test for function program
def test_program():
    from httpie import __version__ as httpie_version
    from httpie.cli.definition import parser
    from httpie.config import Config
    import os
    import sys
    # Create a default environment
    env = Environment()
    env.stdout = os.fdopen(os.open('get_out.txt', os.O_TRUNC | os.O_CREAT | os.O_WRONLY, 0o666), 'wb')
    sys.argv = ['http', '--print', 'Hhb']
    # Create a parser
    parser = parser.parse_args(['--print', 'Hhb'])
    # Prevent HTTPie to access the internet
    parser.follow = False

    # Usually, the main function is called.
    # In this method, we want to test the function program
    # and the function

# Generated at 2022-06-23 19:11:55.802465
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    env2 = Environment()
    env2.stderr = io.StringIO(str)
    print_debug_info(env2)
    print(env2.stderr.getvalue())


# Generated at 2022-06-23 19:12:00.118392
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from pprint import pformat
    from httpie.context import Environment

    stdout = StringIO()
    env = Environment()
    env.stderr = stdout
    print_debug_info(env)
    assert stdout.getvalue() == pformat(env)

# Generated at 2022-06-23 19:12:02.806112
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'hey-\xc3\xa1'], stdin_encoding='utf8') == ['hey-\xe1']

# Generated at 2022-06-23 19:12:08.807140
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'Arg\xc3\xa1t', 'Chytr\xfd', '-v', b'--insecure', b'--timeout=120'], 'UTF-8') == ['Argát', 'Chytrý', '-v', '--insecure', '--timeout=120']


# Generated at 2022-06-23 19:12:15.304185
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace(
        config_dir="",
        ignore_stdin=False,
        output_file=None,
        output_options=[],
        output_stream=None,
        quiet=False,
        verify=True,
    )
    os.environ["http_proxy"] = "127.0.0.1:1234"
    os.environ["https_proxy"] = "127.0.0.1:1234"
    assert program(args, env) == 100

# Generated at 2022-06-23 19:12:27.570438
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser
    from io import StringIO
    parsed_args = parser.parse_args(
        args=['GET', 'localhost'],
        env=Environment(),
    )
    msg = requests.PreparedRequest()
    assert get_output_options(parsed_args, msg) == (True, True)
    parsed_args.output_options = "nh"
    assert get_output_options(parsed_args, msg) == (False, False)
    parsed_args.output_options = "h"
    assert get_output_options(parsed_args, msg) == (True, False)
    parsed_args.output_options = "n"
    assert get_output_options(parsed_args, msg) == (False, True)

    s = StringIO()


# Generated at 2022-06-23 19:12:31.749315
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = ['http', '--json', b'{"key": "value"}']
    assert decode_raw_args(args, 'ascii') == ['http', '--json', '{"key": "value"}']

# Generated at 2022-06-23 19:12:42.713918
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()

    args.output_options = []
    assert (False, False) == get_output_options(args, requests.PreparedRequest())
    assert (False, False) == get_output_options(args, requests.Response())

    args.output_options = [OUT_REQ_HEAD]
    assert (True, False) == get_output_options(args, requests.PreparedRequest())
    assert (False, False) == get_output_options(args, requests.Response())

    args.output_options = [OUT_REQ_BODY]
    assert (False, True) == get_output_options(args, requests.PreparedRequest())
    assert (False, False) == get_output_options(args, requests.Response())

    args.output_options = [OUT_RESP_HEAD]

# Generated at 2022-06-23 19:12:52.711473
# Unit test for function print_debug_info
def test_print_debug_info():
    # dummy environment
    env = Environment()
    env.stderr = []

    # run test
    print_debug_info(env)

    # validate result
    expected_result_beginning = [
        f'HTTPie {httpie_version}\n',
        f'Requests {requests_version}\n',
        f'Pygments {pygments_version}\n',
        f'Python {sys.version}\n{sys.executable}\n',
        f'{platform.system()} {platform.release()}',
    ]
    assert env.stderr[:-2] == expected_result_beginning

# Generated at 2022-06-23 19:13:01.721645
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['abc', '中文', b'cba', b'\xe4\xb8\xad\xe6\x96\x87'], 'utf-8') == ['abc', '中文', 'cba', '中文']
    assert decode_raw_args(['abc', '中文', b'cba', b'\xe4\xb8\xad\xe6\x96\x87'], 'utf-8') != ['abc', '中文', 'cba', b'\xe4\xb8\xad\xe6\x96\x87']

# Generated at 2022-06-23 19:13:08.506729
# Unit test for function print_debug_info
def test_print_debug_info():
    stdout = BytesIO()
    stdout.isatty = False
    env = Environment(
        program_name='http',
        stdin=BytesIO(),
        stdout=stdout,
        stderr=stdout,
        stdin_isatty=False,
        stdout_isatty=False,
    )
    print_debug_info(env)

# Generated at 2022-06-23 19:13:14.393302
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'http://httpbin.org/get', b'foo:bar'], 'utf-8') == ['http://httpbin.org/get', 'foo:bar']
    assert decode_raw_args([b'http://httpbin.org/get', u'foo:bar'], 'utf-8') == ['http://httpbin.org/get', 'foo:bar']

# Generated at 2022-06-23 19:13:25.746436
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options=['h', 'b']
    )
    req = requests.PreparedRequest()
    assert get_output_options(args, req) == (True, True)
    resp = requests.Response()
    assert get_output_options(args, resp) == (True, True)
    args.output_options=['H', 'B']
    assert get_output_options(args, req) == (True, False)
    assert get_output_options(args, resp) == (True, False)
    args.output_options=['h', 'b', 'H']
    assert get_output_options(args, resp) == (True, True)
    args.output_options=[]
    assert get_output_options(args, req) == (False, False)

# Generated at 2022-06-23 19:13:32.895753
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    import csv
    args = parser.parse_args(['--body', '@test_program_json.json', '--download', '--output-file', 'out', '-v', 'https://httpbin.org/post'])
    return program(args, None)

if __name__ == '__main__':
    exit_status = main()
    sys.exit(exit_status)

# Generated at 2022-06-23 19:13:45.350536
# Unit test for function decode_raw_args
def test_decode_raw_args():
    """
    Test that function decode_raw_args
    decodes all byte arguments
    using the provided stdin encoding.

    """

# Generated at 2022-06-23 19:13:57.801799
# Unit test for function program
def test_program():
    print('start test_program')
    str1='code2.py --follow --max-redirects=10 --timeout=30 http://localhost:5003/v1/data/api/get_content?_id=5ea6f72a6c801915e18e7c47&src=u1'
    args1 = str1.split()
    print(args1)
    env = Environment()
    print(env)
    code = main(args1, env)
    print(code)
    if code == ExitStatus.SUCCESS:
        print('test_program success')
    else:
        print('test_program fail')
    # print('start test_program')
    # str1 = 'code2.py --follow --max-redirects=10 --timeout=30 http://localhost:5003/v1

# Generated at 2022-06-23 19:14:08.666122
# Unit test for function get_output_options
def test_get_output_options():
    args_dict1 = {
        'output_options': [
            'h', 'b', 
            'H', 'B'
        ]
    }
    args1 = argparse.Namespace(**args_dict1)

    args_dict2 = {
        'output_options': [
            'h', 'b', 
            'H'
        ]
    }
    args2 = argparse.Namespace(**args_dict2)

    args_dict3 = {
        'output_options': [
            'h', 'b'
        ]
    }
    args3 = argparse.Namespace(**args_dict3)

    args_dict4 = {
        'output_options': [
            'H', 'B'
        ]
    }

# Generated at 2022-06-23 19:14:13.061284
# Unit test for function print_debug_info
def test_print_debug_info():
    import sys
    import io
    import unittest
    class MyTest(unittest.TestCase):
        def test_print_debug_info(self):
            env = Environment()
            env.stderr = io.StringIO()
            print_debug_info(env)
            output = env.stderr.getvalue().splitlines()
            self.assertEqual(len(output), 8)
    unittest.main()

# Generated at 2022-06-23 19:14:22.569238
# Unit test for function get_output_options
def test_get_output_options():
    class Args:
        def __init__(self, output_options: List[str]):
            self.output_options = output_options

    class PreparedRequest:
        def __init__(self, headers: List[Tuple[str, str]]):
            self.headers = headers

    class Response:
        def __init__(self, status_code: int):
            self.status_code = status_code

    req = PreparedRequest([("Content-Type", "application/json")])
    resp = Response(200)

    assert get_output_options(Args([OUT_REQ_BODY]), req) == (False, True)
    assert get_output_options(Args([OUT_RESP_HEAD]), resp) == (True, False)

# Generated at 2022-06-23 19:14:28.150135
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['žluťoučký', 'koníček', b'\xe1\xe9\xed\xf3\xfa\xfd'], 'utf8') == \
           ['žluťoučký', 'koníček', 'áéíóúý']

# Generated at 2022-06-23 19:14:36.733392
# Unit test for function program
def test_program():
    from contextlib import contextmanager
    from io import StringIO
    from unittest.mock import Mock, patch

    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.context import Environment
    from httpie.client import collect_messages

    mock_stdin = StringIO('foo')
    mock_stdout = StringIO()
    mock_stderr = StringIO()

    @contextmanager
    def mock_stdio(stdout=mock_stdout, stdin=mock_stdin, stderr=mock_stderr):
        with patch('sys.stdin', stdin), patch('sys.stdout', stdout), patch(
                'sys.stderr', stderr):
            yield stdout, stdin, stderr

    args = argparse.Namespace()

# Generated at 2022-06-23 19:14:39.404388
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import sys
    assert decode_raw_args([b'blah', b'\xE2\x82\xAC'.decode('utf8')], sys.stdin.encoding) == ['blah', '€']

# Generated at 2022-06-23 19:14:45.651012
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(
        stdin=io.StringIO('contents'),
        stdin_isatty=True,
        stdout=io.StringIO(),
        stdout_isatty=True,
        stderr=io.StringIO(),
        stderr_isatty=False,
        color=True,
    )
    print_debug_info(env)


# Generated at 2022-06-23 19:14:57.374149
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = []
    message = requests.Response()
    assert get_output_options(args, message) == (False, False)
    args.output_options = [OUT_RESP_HEAD]
    assert get_output_options(args, message) == (True, False)
    args.output_options = [OUT_RESP_HEAD, OUT_RESP_BODY]
    assert get_output_options(args, message) == (True, True)
    message = requests.PreparedRequest()
    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY]
    assert get_output_options(args, message) == (True, True)

# Generated at 2022-06-23 19:15:09.815976
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[])
    message_req = requests.PreparedRequest()
    with_heders_req, with_body_req = get_output_options(args=args, message=message_req)
    assert not with_heders_req
    assert not with_body_req
    args.output_options=[OUT_REQ_HEAD, OUT_RESP_BODY]
    with_heders_req, with_body_req = get_output_options(args=args, message=message_req)
    assert with_heders_req
    assert not with_body_req
    message_resp = requests.Response()
    with_heders_resp, with_body_resp = get_output_options(args=args, message=message_resp)
    assert not with_heders_resp

# Generated at 2022-06-23 19:15:11.845416
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a', b'b', 'c'], 'euc-kr') == ['a', 'b', 'c']

# Generated at 2022-06-23 19:15:22.233645
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr = StringIO()
    print_debug_info(env)
    out = env.stderr.getvalue()
    res = True
    if out.find("HTTPie") == -1:
        res = False
    if out.find("Requests") == -1:
        res = False
    if out.find("Pygments") == -1:
        res = False
    if out.find("Python") == -1:
        res = False
    if out.find("platform.system()") == -1:
        res = False
    if out.find("platform.release()") == -1:
        res = False
    assert res == True

# Generated at 2022-06-23 19:15:31.078382
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a', '-b', '-'], 'utf-8') == ['a', '-b', '-']
    assert decode_raw_args([b'a', b'-b', b'-'], 'utf-8') == ['a', '-b', '-']
    assert decode_raw_args([b'a', '-b', b'-'], 'utf-8') == ['a', '-b', '-']
    assert decode_raw_args([b'a', b'-\xc3\xb6'.decode('utf8')], 'utf-8') == ['a', '-ö']

# Generated at 2022-06-23 19:15:35.863881
# Unit test for function get_output_options
def test_get_output_options():
    class Namespace(object):
        def __init__(self, output_options):
            self.output_options = output_options
    args = Namespace(output_options = ['respp'])
    message = requests.PreparedRequest
    assert get_output_options(args, message) == (False, True)
    message = requests.Response
    assert get_output_options(args, message) == (True, False)


# Generated at 2022-06-23 19:15:44.210244
# Unit test for function main
def test_main():
    # Test: main() exit status
    assert main([]) == ExitStatus.ERROR

    # Test: main() --version
    assert main(['--version']) == ExitStatus.SUCCESS

    # Test: main() --help
    assert main(['--help']) == ExitStatus.SUCCESS

    # Test: main() --debug
    assert main(['--debug']) == ExitStatus.SUCCESS

    # Test: main() --traceback
    assert main(['--traceback']) == ExitStatus.SUCCESS


# Generated at 2022-06-23 19:15:51.194328
# Unit test for function print_debug_info
def test_print_debug_info():
    """
    Test if print_debug_info(env) returns a debug string 
    """
    from httpie import environment
    env = environment.Environment()
    # assert print_debug_info(env) == 0
    assert print_debug_info(env)
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    out_tuple = (OUT_REQ_HEAD, OUT_REQ_BODY)
    from httpie.plugins.registry import plugin_manager
    plugin_manager.load_installed_plugins()
    import argparse
    parser = argparse.ArgumentParser()
    args = parser.parse_args(["--debug"])
    # assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:16:01.527415
# Unit test for function main
def test_main():
    import io
    import os
    import sys

    from httpie.cli.constants import DEFAULT_UA
    from httpie.config import Configuration

    # Prepare a fake config location to ensure env.config is initialized
    os.environ.update({
        Configuration.ENVVAR: './tests/fake-config-dir',
    })
    env = Environment()

    # mock stdin, stdout and stderr to test their outputs
    mock_stdin = io.BytesIO(b'\xa1\xa2\xa3\xa4')
    mock_stdout = io.BytesIO()
    mock_stderr = io.BytesIO()
    fake_args = [
        'test-httpie',
        '--debug',
    ]
    saved_sys_stderr = sys.stderr
    saved_

# Generated at 2022-06-23 19:16:11.884467
# Unit test for function decode_raw_args
def test_decode_raw_args():
    def is_str_list(args: List[str]) -> bool:
        return all(type(arg) is str for arg in args)

    def to_bytes(args: List[Union[str, bytes]]) -> List[bytes]:
        return [
            arg.encode()
            if type(arg) is str else arg
            for arg in args
        ]

    assert is_str_list(decode_raw_args(args=['abc'], stdin_encoding='utf-8'))
    assert is_str_list(decode_raw_args(args=[b'abc'], stdin_encoding='utf-8'))
    assert is_str_list(decode_raw_args(args=['abc', b'def'], stdin_encoding='utf-8'))
    assert is_str_list

# Generated at 2022-06-23 19:16:13.370252
# Unit test for function program
def test_program():
    program(["httpget", "http://www.example.com"], Environment())

# Generated at 2022-06-23 19:16:19.525272
# Unit test for function main
def test_main():
    assert main(args=['--download'], env=Environment(argv=['curl', 'www.google.com'])) == ExitStatus.SUCCESS
    assert main(args=['--download', 'www.google.com'], env=Environment(argv=['curl', '--download', 'www.google.com'])) == ExitStatus.SUCCESS

test_main()

# Generated at 2022-06-23 19:16:20.321487
# Unit test for function print_debug_info
def test_print_debug_info():
    print(print_debug_info())

# Generated at 2022-06-23 19:16:26.880571
# Unit test for function main
def test_main():
    from httpie.context import Environment
    from httpie.cli.constants import DEFAULT_CONFIG_DIR

    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBasicAuthFromKeyring
    from pygments.style import Style
    from pygments.token import Token
    from pygments.styles.default import DefaultStyle
    from typing import List
    import sys
    import os

    config_dir = os.path.expanduser(DEFAULT_CONFIG_DIR)
    config = {
        'colors': {
            'args': (Token.Arguments, 'bold blue'),
            'data': (Token.String, 'bold'),
        },
        'default_options': ['--form'],
        'style': 'default',
        'verbose': True,
    }

# Generated at 2022-06-23 19:16:30.853062
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['foo', b'bar'], 'utf-8') == ['foo', 'bar']
    assert decode_raw_args([b'foo', 'bar'], 'utf-8') == ['foo', 'bar']
    assert decode_raw_args([b'foo', b'bar'], 'utf-8') == ['foo', 'bar']
    assert decode_raw_args(['foo', 'bar'], 'utf-8') == ['foo', 'bar']
    assert decode_raw_args([], 'utf-8') == []
    assert decode_raw_args([b''], 'utf-8') == ['']
    assert decode_raw_args([b'\xe4'], 'utf-8') == ['\xe4']

# Generated at 2022-06-23 19:16:42.079235
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=['b'])
    message = requests.PreparedRequest()
    result = get_output_options(args=args, message=message)
    assert result == (False, True)
    args = argparse.Namespace(output_options=['h'])
    message = requests.PreparedRequest()
    result = get_output_options(args=args, message=message)
    assert result == (True, False)
    args = argparse.Namespace(output_options=['hb'])
    message = requests.PreparedRequest()
    result = get_output_options(args=args, message=message)
    assert result == (True, True)
    args = argparse.Namespace(output_options=['b'])
    message = requests.Response()
    result = get

# Generated at 2022-06-23 19:16:52.959109
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO

    try:
        from unittest import mock
    except ImportError:
        import mock

    env = Environment()
    env.stderr = StringIO()
    print_debug_info(env)
    env.stderr.seek(0)

    assert env.stderr.read()
    assert 'HTTPie' in env.stderr.read()
    assert 'Requests' in env.stderr.read()
    assert 'Pygments' in env.stderr.read()
    assert 'Python' in env.stderr.read()
    assert '\n\n' in env.stderr.read()

# Generated at 2022-06-23 19:16:54.620845
# Unit test for function program
def test_program():
    code = main(['httpbin.org', '--json'])
    assert code == 0

# Generated at 2022-06-23 19:17:03.394407
# Unit test for function get_output_options
def test_get_output_options():
    # Will produce a 
    # pylint: disable=unused-variable
    requests_parameters = ([], 'https://httpbin.org/get?key=value', '')

# Generated at 2022-06-23 19:17:08.214835
# Unit test for function decode_raw_args
def test_decode_raw_args():
    """
    Test for decode_raw_args - should work for all characters in ASCII
    """
    from httpie.cli.constants import DEFAULT_CLI_ENCODING
    stdin_encoding = DEFAULT_CLI_ENCODING
    args = [b'\xff']
    result = decode_raw_args(args, stdin_encoding)
    assert result == ['\ufffd']



# Generated at 2022-06-23 19:17:11.868829
# Unit test for function decode_raw_args
def test_decode_raw_args():
    decoded_args = decode_raw_args(
        ['--form', b'k1=v1'],
        'utf8',
    )
    assert isinstance(decoded_args, list)
    assert decoded_args == ['--form', 'k1=v1']

# Generated at 2022-06-23 19:17:20.312458
# Unit test for function get_output_options
def test_get_output_options():
    options = [OUT_REQ_HEAD,OUT_REQ_BODY,OUT_RESP_HEAD,OUT_RESP_BODY]
    args = argparse.Namespace()
    args.output_options = options

    # Test get_output_options when input is PreparedRequest
    assert get_output_options(args,requests.PreparedRequest()) == (True, True)

    # Test get_output_options when input is Response
    assert get_output_options(args,requests.Response()) == (True, True)

# Generated at 2022-06-23 19:17:29.361751
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import locale
    locale.setlocale(locale.LC_ALL, "")

    if sys.platform.startswith('win'):
        stdin_encoding = locale.getpreferredencoding()
        # "cp1252" on Python 3.6.0, "utf-8" on Python 3.6.4
    else:
        stdin_encoding = sys.stdin.encoding
    assert stdin_encoding is not None
    assert type(stdin_encoding) is str

    assert decode_raw_args([b'foo'], stdin_encoding) == ['foo']
    assert decode_raw_args([b'\xe2\x98\x83'], stdin_encoding) == ['☃']

# Generated at 2022-06-23 19:17:35.756685
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser
    from httpie.cli.parser import process_config_overrides
    args = parser.parse_args([])
    process_config_overrides(args)
    assert (True, True) == get_output_options(args, requests.PreparedRequest())
    assert (False, False) == get_output_options(args, requests.Response())



# Generated at 2022-06-23 19:17:46.514601
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from unittest.mock import patch
    from httpie.cli.helpers import FakeStdoutAndStderr

    with patch('httpie.cli.main.sys.stderr', new_callable=StringIO) as stderr:
        print_debug_info(Environment(stdout=FakeStdoutAndStderr(), stderr=stderr))
    # just some basic sanity checks
    assert 'HTTPie' in stderr.getvalue()
    assert 'Python' in stderr.getvalue()
    assert 'Requests' in stderr.getvalue()
    assert 'Pygments' in stderr.getvalue()
    assert stderr.getvalue().count('\n') > 10

# Generated at 2022-06-23 19:17:53.263378
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from unittest.mock import Mock
    env = Mock(stdout=StringIO(), stderr=StringIO())
    print_debug_info(env=env)
    assert env.stdout.getvalue() == ''
    assert env.stderr.getvalue().startswith(
        'HTTPie 0.9.7\nRequests 2.18.4\nPygments 2.2.0\nPython '
    )

# Generated at 2022-06-23 19:18:00.876614
# Unit test for function main
def test_main():
    """
    Test function main.

    """

    import unittest
    import unittest.mock
    from httpie.compat import StringIO

    def mock_main(args: List[Union[str, bytes]] = sys.argv, env=Environment()) -> ExitStatus:
        return main(args, env)

    class MainTestCase(unittest.TestCase):
        """
        Test class MainTestCase.

        """

        def setUp(self):
            self.env = Environment()
            self.env.stdout = StringIO()
            self.env.stderr = StringIO()


# Generated at 2022-06-23 19:18:12.243457
# Unit test for function program
def test_program():
    class TestNamespace(object):
        def __init__(self, headers, output_options, output_file, output_file_specified, download, download_resume, follow, timeout, max_redirects, check_status, quiet):
            self.headers = headers
            self.output_options = output_options
            self.output_file = output_file
            self.output_file_specified = output_file_specified
            self.download = download
            self.download_resume = download_resume
            self.follow = follow
            self.timeout = timeout
            self.max_redirects = max_redirects
            self.check_status = check_status
            self.quiet = quiet

    args = TestNamespace({}, [], None, None, None, None, None, None, None, None, None)
    print

# Generated at 2022-06-23 19:18:22.304680
# Unit test for function program

# Generated at 2022-06-23 19:18:29.786278
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'--data', 'штука'], 'utf8') == ['--data', 'штука']
    assert decode_raw_args([b'--data'], 'utf8') == ['--data']
    assert decode_raw_args([b'--data', 'штука'], 'ascii') == ['--data', '?']
    assert decode_raw_args([], 'ascii') == []

# Generated at 2022-06-23 19:18:36.511918
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # non-ASCII args
    args = ['\x80\x81']
    assert decode_raw_args(args, 'latin1') == [b'\xc2\x80\xc2\x81'.decode('latin1')]

    # --default-options
    if '--default-options' in sys.argv[1:]:
        args = sys.argv[1:]

# Generated at 2022-06-23 19:18:43.695273
# Unit test for function main
def test_main():
    from httpie.cli import main
    from httpie import Environment
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    # print(main(sys.argv))
    # print(main([sys.argv[0], "--debug"]))
    # print(main([sys.argv[0], "--timeout=3", "https://httpbin.org/delay/5"]))
    # print(main([sys.argv[0], "--check-status", "http://httpbin.org/status/500"]))
    # print(main([sys.argv[0], "--check-status", "--body", "--max-redirects=3", "https://httpbin.org/redirect-to?

# Generated at 2022-06-23 19:18:46.655742
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        ['--form', '-', b'status=201'],
        'utf8'
    ) == ['--form', '-', 'status=201']

# Generated at 2022-06-23 19:18:58.325523
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[])
    msg = requests.Response()
    assert get_output_options(args, msg) == (False, False)

    args = argparse.Namespace(output_options=[OUT_REQ_HEAD])
    msg = requests.Response()
    assert get_output_options(args, msg) == (False, False)

    args = argparse.Namespace(output_options=[OUT_REQ_BODY])
    msg = requests.Response()
    assert get_output_options(args, msg) == (False, False)

    args = argparse.Namespace(output_options=[OUT_REQ_HEAD, OUT_REQ_BODY])
    msg = requests.Response()
    assert get_output_options(args, msg) == (False, False)

    args = arg