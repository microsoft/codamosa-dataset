

# Generated at 2022-06-23 19:09:00.149895
# Unit test for function main
def test_main():
    import requests_mock
    req = requests.Request('GET', 'https://example.com').prepare()
    resp = req.send()
    with requests_mock.Mocker() as m:
        m.register_uri('GET', 'https://example.com', resp)
        assert main(args=['--print=bB', 'https://example.com/']) == ExitStatus.SUCCESS


if __name__ == '__main__':
    print(main())

# Generated at 2022-06-23 19:09:11.388732
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.args import Namespace
    from httpie.context import Environment
    args = Namespace()
    env = Environment()
    args.output_options = ['resp.body']
    args.json = False
    args.output_file = None

    resp = requests.Response()
    resp.status_code = 200
    resp.raw = requests.packages.urllib3.HTTPResponse()
    resp.raw.msg = requests.packages.urllib3.HTTPMessage()
    resp.raw.msg.headers = requests.structures.CaseInsensitiveDict()
    resp.raw.msg.headers.update({
        'Content-Type': 'application/json'
    })
    resp.raw.msg.version = 11
    resp.raw.reason = 'Ok'
    resp.raw.ch

# Generated at 2022-06-23 19:09:13.711731
# Unit test for function decode_raw_args
def test_decode_raw_args():
    print("function decode_raw_args")
    assert decode_raw_args(["haha"], "utf-8") == ["haha"]
    assert decode_raw_args([b"haha"], "utf-8") == ["haha"]
    assert decode_raw_args([b"\xff"], "utf-8") == ["\ufffd"]


# Generated at 2022-06-23 19:09:20.383618
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import sys

    env = Environment(
        stdin=io.BytesIO(),
        stdin_isatty=False,
        stdout=io.BytesIO(),
        stdout_isatty=False,
        stderr=io.BytesIO(),
        stderr_isatty=False,
    )
    print_debug_info(env)
    sys.stdout.write(env.stderr.getvalue())

# Generated at 2022-06-23 19:09:28.660166
# Unit test for function program
def test_program():
    import io
    import requests
    import json

    class FakeResponse:
        def __init__(self):
            self.code = 200
            self.reason = 'OK'

    class FakeEnv:
        stdout = io.BytesIO()
        stderr = io.BytesIO()

        def __init__(self):
            self.program_name = 'http'

    class FakeRequest:
        def __getattr__(self, item):
            return None

        def __init__(self):
            self.url = 'http://example.com/'

    env = FakeEnv()
    args = [
        'GET',
        '--json',
        'http://example.com/'
    ]
    program(args=parse_args(args=args, env=env), env=env)

# Generated at 2022-06-23 19:09:37.488470
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    assert get_output_options(args, requests.PreparedRequest()) == (True, True)
    assert not get_output_options(args, requests.Response()) == (True, True)

    args.output_options = "h"
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)
    assert get_output_options(args, requests.Response()) == (True, False)

    args.output_options = "b"
    assert get_output_options(args, requests.PreparedRequest()) == (False, True)
    assert not get_output_options(args, requests.Response()) == (False, True)

    args.output_options = "hb"

# Generated at 2022-06-23 19:09:43.190374
# Unit test for function get_output_options
def test_get_output_options():
    import requests

    args = argparse.Namespace()
    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_BODY]

    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (True, True)

    message = requests.Response()
    assert get_output_options(args, message) == (False, True)

# Generated at 2022-06-23 19:09:44.091539
# Unit test for function main
def test_main():
    print(main())

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 19:09:48.233588
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = ['http', 'example.org', '/']
    stdin_encoding = 'utf-8'
    assert decode_raw_args(args, stdin_encoding) == args

    args = ['http', 'example.org', '/'] + [b'abc']
    stdin_encoding = 'utf-8'
    assert decode_raw_args(args, stdin_encoding) == args[:-1] + ['abc']

# Generated at 2022-06-23 19:09:56.409320
# Unit test for function main
def test_main():
    from zerotk.easyfs import WPath
    import json
    import sys
    import unittest

    import httpie
    from zerotk.easycmd import Test

    arguments = ['--traceback', '--debug', '--default-options=--help', '--default-options=--debug', '--debug', '--default-options=--traceback']
    Test(main)(arguments, extra_paths=[WPath(httpie.__file__).dirname])


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 19:10:03.669042
# Unit test for function print_debug_info
def test_print_debug_info():
    class MockStderr:
        def __init__(self):
            self.data = None

        def writelines(self, lines):
            self.data = ''.join(lines)

    mock_stderr = MockStderr()
    print_debug_info(env=Environment(stderr=mock_stderr))
    assert 'HTTPie ' in mock_stderr.data
    assert 'Requests ' in mock_stderr.data
    assert 'Pygments ' in mock_stderr.data
    assert 'Python ' in mock_stderr.data
    assert '<httpie.context.Environment object at ' in mock_stderr.data

# Generated at 2022-06-23 19:10:06.928244
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['--json', b'{"a": "\xc3\xa1"}', 'GET'], 'utf8') == ['--json', '{"a": "\xc3\xa1"}', 'GET']

# Generated at 2022-06-23 19:10:10.491097
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    env = Environment(program_name='test', stdout=io.StringIO(), stderr=io.StringIO())
    assert print_debug_info(env) is None


# Generated at 2022-06-23 19:10:18.628105
# Unit test for function print_debug_info
def test_print_debug_info():
    # noinspection PyShadowingNames
    class FakeStderr:
        def __init__(self):
            self.s = ''

        def write(self, s):
            self.s += s

        def writelines(self, l):
            for s in l:
                self.write(s)

        def __repr__(self):
            return (
                f'HTTPie {httpie_version}\n'
                f'Requests {requests_version}\n'
                f'Pygments {pygments_version}\n'
                f'Python {sys.version}\n{sys.executable}\n'
                f'{platform.system()} {platform.release()}'
            )

    env = Environment(stdin=None, stdout=None, stderr=FakeStderr())
    print_debug

# Generated at 2022-06-23 19:10:23.625739
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options = ['all'],
    )

    # Request object
    req = requests.PreparedRequest()
    assert get_output_options(args, req) == (True, True)

    args.output_options = ['none']
    assert get_output_options(args, req) == (False, False)

    # Response object
    resp = requests.Response()
    assert get_output_options(args, resp) == (False, False)
    
    args.output_options = ['all']
    assert get_output_options(args, resp) == (True, True)

# Generated at 2022-06-23 19:10:32.273780
# Unit test for function program
def test_program():
    import pytest

    @pytest.fixture
    def mocked_write_message(mocker):
        return mocker.patch('httpie.output.writer.write_message')

    @pytest.fixture
    def mocked_write_stream(mocker):
        return mocker.patch('httpie.output.writer.write_stream')

    @pytest.fixture
    def env():
        return Environment()

    def test_args(**kwargs):
        class TestArgs:
            def __getattr__(self, item):
                return kwargs.get(item, None)
        return TestArgs()

    def test_request(**kwargs):
        class TestRequest(requests.PreparedRequest):
            def __init__(self, *args, **kwargs):
                super(TestRequest, self).__init

# Generated at 2022-06-23 19:10:35.858541
# Unit test for function main
def test_main():
    test_args = [
        'http',
        '--debug',
        'http://httpbin.org/status/201',
    ]
    test_exit_status = main(test_args)
    assert test_exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:10:45.103331
# Unit test for function program
def test_program():
    from httpie.context import Environment
    from httpie.cli.argtypes import KeyValueArgType

    args = ['http', '--json', '--form', '--form=test_arg',
            '--headers', 'test_header:test_value',
            '--form', '--form=test_arg2',
            'https://httpbin.org/post']
    test_env = Environment()
    test_env.stdout = sys.stdout
    test_env.stderr = sys.stderr
    print(program(args=args,
                  env=test_env))


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:10:46.371427
# Unit test for function print_debug_info
def test_print_debug_info():
    print_debug_info()


# Generated at 2022-06-23 19:10:53.415616
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from unittest import TestCase

    class IO(StringIO):
        @property
        def buffer(self):
            return self

    class Test(TestCase):
        @staticmethod
        def test_print_debug_info():
            out = IO()
            print_debug_info(Environment(stdout=out, stderr=out))
            out.seek(0)
            assert out.read().startswith('HTTPie ')

# Generated at 2022-06-23 19:11:05.193247
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(
        config=None,
        directory=None,
        stderr=MagicMock(spec=io.TextIOBase),
        stdin=MagicMock(spec=io.RawIOBase),
        stdin_isatty=True,
        stdout=MagicMock(spec=io.TextIOBase)
    )
    print_debug_info(env=env)

# Generated at 2022-06-23 19:11:13.356516
# Unit test for function get_output_options
def test_get_output_options():
    import os

    def get_output_options_argparse(
        args: argparse.Namespace,
        message: Union[requests.PreparedRequest, requests.Response]
    ) -> Tuple[bool, bool]:
        return {
            requests.PreparedRequest: (
                OUT_REQ_HEAD in args.output_options,
                OUT_REQ_BODY in args.output_options,
            ),
            requests.Response: (
                OUT_RESP_HEAD in args.output_options,
                OUT_RESP_BODY in args.output_options,
            ),
        }[type(message)]

    # Create requests.PreparedRequest and requests.Response
    class PreparedRequest(requests.PreparedRequest):
        def __init__(self):
            self.method = "GET"


# Generated at 2022-06-23 19:11:19.957125
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = []

    request = requests.PreparedRequest()
    print(get_output_options(args, request))
    response = requests.Response()
    print(get_output_options(args, response))


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 19:11:22.260059
# Unit test for function main
def test_main():
    import sys
    return_value = main()
    assert type(return_value) is ExitStatus, 'output of main is not an ExitStatus object'
    sys.exit(int(return_value))

# Generated at 2022-06-23 19:11:30.182347
# Unit test for function main
def test_main():
    from io import StringIO
    import sys
    import tempfile
    from httpie.utils import debug

    debug(True)

    def read_temp_file(file):
        file.seek(0)
        return file.read()

    output_file = tempfile.NamedTemporaryFile(delete=True, mode='w+')

    args = [
        'command',
        '--output=%s' % output_file.name,
        '--print=B',
        '--verbose',
        '--headers',
        '--debug',
        'http://httpbin.org/get'
    ]
    old_stderr = sys.stderr
    old_stdout = sys.stdout
    old_stdin = sys.stdin

# Generated at 2022-06-23 19:11:42.701211
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.environment import Environment
    from httpie.cli.parser import ArgType
    from httpie.compat import is_bytes
    from httpie.core import main
    from httpie.exit import ExitStatus

    # test command line
    args = parser.parse_args(['GET', 'http://127.0.0.1:8080/get', 'Content-Type:application/json'])
    assert args.url == 'http://127.0.0.1:8080/get'
    assert args.headers == {'Content-Type': 'application/json'}

    # test environment variable
    msg = repr(Environment())
    assert msg.find('program_name=') > 0
    assert msg.find('http_proxy=') > 0

    # test decode_

# Generated at 2022-06-23 19:11:45.948409
# Unit test for function program
def test_program():
    my_args = []
    my_env = Environment()
    my_args = initialize_parser()
    args = program(my_args, my_env)
    assert (args == ExitStatus.SUCCESS)


# Generated at 2022-06-23 19:11:56.334764
# Unit test for function print_debug_info
def test_print_debug_info():

    import tempfile
    import shutil
    from unittest.mock import Mock

    temp_dir = tempfile.mkdtemp()
    try:
        stderr = Mock(name='stderr', spec=sys.stderr)
        env = Environment(
            config_dir=temp_dir,
            env=os.environ,
            stdin=Mock(),
            stdin_isatty=True,
            stdout=Mock(),
            stdout_isatty=True,
            stderr=stderr,
            stderr_isatty=True,
            stdout_binary=False,
        )

        print_debug_info(env)
        assert stderr.mock_calls
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-23 19:12:08.553595
# Unit test for function print_debug_info
def test_print_debug_info():
    env = mock.Mock()
    env.stderr.write = mock.Mock()
    env.stderr.writelines = mock.Mock()
    env.stderr.write.return_value = None
    env.stderr.writelines.return_value = None
    print_debug_info(env)
    assert env.stderr.write.call_count == 5
    assert env.stderr.writelines.call_count == 2

# Generated at 2022-06-23 19:12:11.550063
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    env = Environment()
    env.stderr = io.StringIO()
    print_debug_info(env)

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:12:12.445010
# Unit test for function main
def test_main():
    assert main(args=[]) == ExitStatus.ERROR

# Generated at 2022-06-23 19:12:19.140645
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # Ensure we decode bytes arguments to str.
    args = [b'--form', b'foo=bar']
    assert decode_raw_args(args, stdin_encoding='ascii') == ['--form', 'foo=bar']

    # Ensure we leave str arguments as-is.
    args = ['--form', 'foo=bar']
    assert decode_raw_args(args, stdin_encoding='ascii') is args

    # Ensure we raise an error if decoding fails.
    args = [b'--form', b'\xff']
    with pytest.raises(UnicodeDecodeError):
        decode_raw_args(args, stdin_encoding='ascii')



# Generated at 2022-06-23 19:12:26.057927
# Unit test for function main
def test_main():
    import contextlib
    import io
    import unittest
    from unittest import mock

    def check_main(args: List[str], expected: ExitStatus):
        actual = main(args=args, env=Environment())
        assert actual == expected, f'{log(args)} -> {actual}, but {expected} expected'

    @contextlib.contextmanager
    def stdstreams(stdin=None, stdout=None, stderr=None):
        T = unittest.TestCase('__init__')
        old_stdin = sys.stdin
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdin = stdin or io.StringIO()
        sys.stdout = stdout or io.StringIO()
        sys.stderr = stder

# Generated at 2022-06-23 19:12:34.769701
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = []
    message = requests.PreparedRequest()

    assert get_output_options(args, message) == (False, False)

    args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(args, message) == (True, False)

    args.output_options = [OUT_REQ_BODY]
    assert get_output_options(args, message) == (False, True)

    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY]
    assert get_output_options(args, message) == (True, True)

    args.output_options = [OUT_RESP_HEAD]
    assert get_output_options(args, message) == (False, False)

    args

# Generated at 2022-06-23 19:12:44.374020
# Unit test for function program
def test_program():
    class MockClass():
        def __init__(self, env=Environment(), args=argparse.Namespace()):
            self.env = env
            self.args = args

    # mock requests.PreparedRequest object
    class PreparedRequest():
        def __init__(self):
            self.method = 'GET'

    # mock requests.Response object
    class Response():
        def __init__(self):
            self.status_code = 200
            self.raw = 'response'

    # mock downloader.py's Downloader object
    class Downloader():
        def __init__(self, output_file, progress_file, resume=False):
            self.output_file = output_file
            self.progress_file = progress_file
            self.resume = resume
            self.finished = True
            self.status = Mock

# Generated at 2022-06-23 19:12:48.923020
# Unit test for function program
def test_program():
    args = ["httpie", "https://www.google.com", ":80"]
    args = decode_raw_args(args, "utf-8")
    env = Environment()
    program(args)

# Generated at 2022-06-23 19:12:58.524342
# Unit test for function main
def test_main():
    import unittest
    import responses

    class TestMain(unittest.TestCase):
        @responses.activate
        def test_main(self):
            from httpie.cli.definition import parser
            from httpie.cli.entrypoint import main
            from httpie.cli.parser import get_parser_args
            parser_args = get_parser_args(**parser.parse_args([
                '--debug',
                'https://httpbin.org/get',
            ]).__dict__)
            responses.add(responses.GET, 'https://httpbin.org/get', json={})
            main(['--debug', 'https://httpbin.org/get'], env=parser_args.env)

    unittest.main()


# Generated at 2022-06-23 19:13:06.486164
# Unit test for function decode_raw_args
def test_decode_raw_args():
    def f(args, encoding, expected_args):
        actual_args = decode_raw_args(args, encoding)
        assert actual_args == expected_args, (actual_args, expected_args)

    f([b'http', b'http://httpbin.org/'], 'utf8', ['http', 'http://httpbin.org/'])
    f(['http', b'http://httpbin.org/'], 'utf8', ['http', 'http://httpbin.org/'])
    f(['http', b'http://httpbin.org/'], 'ascii', ['http', 'http://httpbin.org/'])


# Generated at 2022-06-23 19:13:16.940619
# Unit test for function get_output_options
def test_get_output_options():
    from argparse import Namespace
    from httpie.constants import HTTP_ACCEPT
    from httpie.output.writer import OUTPUT_OPTIONS_MAP
    from httpie.status import ExitStatus

    from requests import Request

    args = Namespace()
    args.output_options = [OUTPUT_OPTIONS_MAP[x] for x in ['all', 'req', 'resp']]

    args.headers = {HTTP_ACCEPT: 'application/json'}
    prepared_request = Request(method='GET', url='https://www.example.com/').prepare()
    assert get_output_options(args=args, message=prepared_request) == (True, True)

    args.headers = {HTTP_ACCEPT: 'application/json'}

# Generated at 2022-06-23 19:13:21.248684
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY]
    message = requests.Response()

    assert get_output_options(args, message) == (False, True)

# Generated at 2022-06-23 19:13:24.702004
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        ['GET', '--json', b'{"foo": "\xe4\xb8\x96\xe7\x95\x8c"}'],
        'utf8'
    ) == ['GET', '--json', '{"foo": "世界"}']

# Generated at 2022-06-23 19:13:36.518490
# Unit test for function get_output_options
def test_get_output_options():
    #Define Namespace for all CLI arguments
    class args:
        output_options = []
    #Check whether OUT_REQ_HEAD, OUT_RESP_BODY specified in args.output_options
    args.output_options.extend([OUT_REQ_HEAD,OUT_RESP_BODY])
    parsed_args = args()
    #Define prepare request object and response object for testing
    request = requests.PreparedRequest()
    response = requests.Response()
    #Check whether OUT_RESP_BODY is present in args.output_options and whether it is a response object
    assert(get_output_options(parsed_args,response) == (False,True))
    #Check whether OUT_REQ_HEAD is present in args.output_options and whether it is a request object

# Generated at 2022-06-23 19:13:38.783310
# Unit test for function main
def test_main():
    assert main([b'http', b'--debug']) == ExitStatus.SUCCESS


# Actual command-line invocation

# Generated at 2022-06-23 19:13:49.684956
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'FOO=bar'], 'utf-8') == ['FOO=bar']
    assert decode_raw_args([b'--form', b'FOO=bar'], 'utf-8') == ['--form', 'FOO=bar']
    assert decode_raw_args([b'--form', b'FOO=bar'], 'ascii') == ['--form', 'FOO=bar']
    assert decode_raw_args([b'--form', b'FOO=\xe4\xf6\xfc'], 'iso-8859-1') == ['--form', 'FOO=äöü']
    assert decode_raw_args([b'--form', b'FOO=\xc3\xa4\xc3\xb6\xc3\xbc'], 'utf-8')

# Generated at 2022-06-23 19:13:59.478335
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_BODY, OUT_REQ_HEAD]

    assert (False, True) == get_output_options(args, requests.Response())
    assert (True, True) == get_output_options(args, requests.PreparedRequest())
    assert (False, False) == get_output_options(args, requests.PreparedRequest())

    args.output_options = [OUT_REQ_HEAD]
    assert (True, False) == get_output_options(args, requests.PreparedRequest())

    args.output_options = []
    assert (False, False) == get_output_options(args, requests.PreparedRequest())

# Generated at 2022-06-23 19:14:09.541111
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    out = StringIO()
    env = Environment()
    env.stderr = out
    print_debug_info(env)
    assert out.getvalue() == (
        "HTTPie httpie-0.6.1\n"
        "Requests requests-2.20.0\n"
        "Pygments pygments-2.3.1\n"
        "Python 3.6.5 (default, Jul  5 2018, 18:28:30) \n[GCC 4.2.1 Compatible Apple LLVM 9.1.0 (clang-902.0.39.1)]\n"
        "Darwin 17.7.0\n\n\n"
        '<httpie.context.Environment object at 0x7fed58572fd0>\n'
    )

# Generated at 2022-06-23 19:14:13.990909
# Unit test for function main
def test_main():
    assert main(["http", "--version"]) == 0
    assert main(["http", "help"]) == 0
    assert main(["http", "--debug", "--verbose", "--headers", "GET", "127.0.0.1:5000/static/main.css"]) == 0

# Generated at 2022-06-23 19:14:15.207678
# Unit test for function main
def test_main():
    from httpie.cli import main
    # main([])

# Generated at 2022-06-23 19:14:19.606175
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'\xc3\xa1'], 'utf8') == ['á']
    assert decode_raw_args(['a'], 'latin1') == ['a']
    assert decode_raw_args(['a'], 'utf8') == ['a']

# Generated at 2022-06-23 19:14:31.759862
# Unit test for function main
def test_main():
    import os, sys
    from contextlib import redirect_stdout
    from io import StringIO
    from tempfile import TemporaryDirectory
    from httpie.cli.definition import parser

    env = Environment()

    # Basic checks
    assert main(['http: example.org'], env=env) == 0
    assert main(['http: example.org'], env=env) == 0
    assert main(['http: example.org --follow'], env=env) == 0
    assert main(['http: example.org --quiet'], env=env) == 0
    assert main(['http: example.org --download'], env=env) == 0
    assert main(['http: example.org --download --output=-'], env=env) == 0

# Generated at 2022-06-23 19:14:37.075996
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options=[OUT_REQ_BODY, OUT_RESP_BODY],
    )
    assert get_output_options(args=args, message=requests.PreparedRequest()) == (False, True)
    assert get_output_options(args=args, message=requests.Response()) == (False, True)

# Generated at 2022-06-23 19:14:42.374835
# Unit test for function main
def test_main():
    env = Environment()
    env.program_name = "http"
    env.config.default_options = [
        "--json"
    ]
    args = [
        "--pretty",
        "all",
        "--method",
        "POST",
        "http://httpbin.org/post"
    ]
    main(args=args, env=env)
    env.stdout.write("http.main() passed\n")
    env.stdout.flush()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 19:14:44.201844
# Unit test for function main
def test_main():
    from httpie import exit_status
    assert main(args=[]) == exit_status.ERROR_NO_URL

# Generated at 2022-06-23 19:14:52.886636
# Unit test for function main
def test_main():
    import sys
    class StderrWriter:
        def __init__(self):
            self.contents = ''
        def write(self, text):
            self.contents += text
    stderr = StderrWriter()
    exit_status = main(args=['http'], env=Environment(
        stdin=sys.stdin,
        stdin_isatty=False,
        stdout=sys.stdout,
        stdout_isatty=False,
        program_name='http',
        stderr=stderr,
        stdin_encoding='utf8',
        stdout_encoding='utf8',
        stderr_encoding='utf8'
    ))
    assert exit_status == ExitStatus.ERROR

# Generated at 2022-06-23 19:15:04.937523
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import sys
    for encoding in [None, 'latin1', 'utf-8', 'utf-16']:
        bytes_args = [b'--form', b'foo=bar\xc4\x84']
        if sys.version_info >= (3, 6):
            bytes_args += [b'--' + bytes(chr(i), 'ascii') + b'=bar' for i in range(128, 256)]
        if encoding is not None:
            # On Python 2, encoding can be None if there are only ASCII args.
            assert decode_raw_args(bytes_args, encoding) == [
                '--form', 'foo=bar\xc4\x84'] + [
                    '--' + chr(i) + '=bar' for i in range(128, 256)]

# Generated at 2022-06-23 19:15:14.609289
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace(config_dir='.httpie', config_path=None, config_file=None, styles=None,
                              output_options=None, ignore_stdin=False, default_options=[], _positional_args=[],
                              _actual_kwargs={}, output_file=None, output_file_specified=False,
                              output_file_encoding=None, output_file_line_ending=None,
                              output_file_append=False, follow=False, check_status=False,
                              max_redirects=10, download=False, download_resume=False)
    test_args = ['https://httpbin.org/get']
    sys.argv[1:] = test_args

# Generated at 2022-06-23 19:15:18.851328
# Unit test for function decode_raw_args
def test_decode_raw_args():
    decoded_args = decode_raw_args(["--get", "--", b"httpie.org"], "utf-8")
    assert decoded_args == decoded_args == ['--get', '--', 'httpie.org']

# Generated at 2022-06-23 19:15:23.999686
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'foo'], 'utf8') == ['foo']
    assert decode_raw_args(['foo'], 'utf8') == ['foo']
    assert decode_raw_args([b'foo', 'bar'], 'utf8') == ['foo', 'bar']
    with pytest.raises(UnicodeDecodeError):
        decode_raw_args([b'\xff'], 'utf8')

# Generated at 2022-06-23 19:15:25.480473
# Unit test for function main
def test_main():
    exit_status = main()
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:15:28.091951
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert (
        decode_raw_args(args=[b'foo'], stdin_encoding='UTF-8') ==
        ['foo']
    )

# Generated at 2022-06-23 19:15:35.564834
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    s = io.StringIO()
    env = Environment()
    env.stderr = s
    print_debug_info(env)
    s.seek(0)
    output = s.read()
    assert httpie_version in output
    assert requests_version in output
    assert pygments_version in output
    assert sys.version in output
    assert sys.executable in output
    assert platform.system() in output
    assert platform.release() in output


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:15:46.632744
# Unit test for function main
def test_main():
    #from io import StringIO
    #from tempfile import TemporaryDirectory
    #from unittest.mock import patch
    import io
    import unittest.mock
    import tempfile
    #from httpie.cli.argtypes import KeyValue
    #from httpie.config import Config
    #from httpie.context import Environment
    #from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    #from httpie.plugins.builtin import HTTPBasicAuth
    #from httpie.plugins import plugin_manager
    #from utils import MockEnvironment, MockRequestResponse

    # TODO
    #plugin_manager.register(HTTPBasicAuth)
    #plugin_manager.load_installed_plugins()

    #class TestEnvironment(Environment):
    #    def __init__(self, **kwargs):
   

# Generated at 2022-06-23 19:15:59.281193
# Unit test for function program
def test_program():
    class Namespace:
        def __init__(self, var):
            self.input = var
            self.output_options = ['h']
    from httpie.input.raw import RawRequest
    from httpie.input.utils import iter_raw_request_items
    from httpie.output.utils import get_output_options_argparser_kwargs
    env = Environment()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False

# Generated at 2022-06-23 19:16:10.001490
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options=[
            OUT_REQ_HEAD,
            OUT_REQ_BODY,
            OUT_RESP_HEAD,
            OUT_RESP_BODY,
        ]
    )
    request = requests.PreparedRequest()
    response = requests.Response()
    assert get_output_options(args=args, message=request) == (True, True)
    assert get_output_options(args=args, message=response) == (True, True)
    args.output_options = []
    assert get_output_options(args=args, message=request) == (False, False)
    assert get_output_options(args=args, message=response) == (False, False)

# Generated at 2022-06-23 19:16:12.682504
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)

# Generated at 2022-06-23 19:16:17.465518
# Unit test for function print_debug_info
def test_print_debug_info():
    origin_stderr_write = sys.stderr.write
    try:
        sys.stderr.write = lambda x: None
        print_debug_info(env=Environment())
    finally:
        sys.stderr.write = origin_stderr_write

# Generated at 2022-06-23 19:16:20.223427
# Unit test for function main
def test_main():
    import subprocess
    print(subprocess.check_output(["python3","httpie.py"]).decode())
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-23 19:16:26.832238
# Unit test for function get_output_options
def test_get_output_options():
    parser = argparse.ArgumentParser()
    parser.add_argument('-v', action='store_true')
    parser.add_argument('--all', action='store_const', const=argparse.SUPPRESS)
    parser.add_argument('--traceback', action='store_true')
    parser.add_argument('--debug', action='store_true')
    parser.add_argument('--download', action='store_true')
    parser.add_argument('--download-resume', type=int)
    parser.add_argument('--check-status', action='store_true')
    parser.add_argument('--headers', type=str, default=None)
    parser.add_argument('--output-file', nargs='?', type=argparse.FileType('wb'), default=None)
    parser.add_argument

# Generated at 2022-06-23 19:16:29.620842
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    s = io.StringIO()
    print_debug_info(Environment(stderr=s))
    out = s.getvalue()
    assert out.startswith('HTTPie')
    assert out.find('Requests') > 0
    assert out.find('Pygments') > 0
    assert out.find('Python') > 0
    assert out.find('\n\n') > 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:16:41.059976
# Unit test for function get_output_options
def test_get_output_options():
    env = Environment()
    args = argparse.Namespace(
        output_options=["hH", "bB"],
        output_file_specified=False
    )
    response = requests.Response()
    response.raw.status = 200
    response.raw.reason = "OK"
    response.headers = {"hTTPie": "Awesome"}

    headers, body = get_output_options(args, response)
    assert headers == True
    assert body == True

    request = requests.PreparedRequest()
    request.method = "GET"
    request.url = "https://httpie.org"
    request.headers = {"hTTPie": "Awesome"}

    headers, body = get_output_options(args, request)
    assert headers == True
    assert body == True

# Generated at 2022-06-23 19:16:42.914040
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'http', b'httpbin.org'], 'ascii') == ['http', 'httpbin.org']

# Generated at 2022-06-23 19:16:51.887243
# Unit test for function main
def test_main():
    from io import StringIO
    from httpie.cli.context import Environment
    from httpie.cli.constants import DEFAULT_OUTPUT_OPTIONS

    args = []
    env = Environment(stdin=StringIO(),stdout=StringIO(),stderr=StringIO(),default_stdout_isatty=True)
    # Inputs
    args.append("--debug")
    # Expected return
    # Outputs
    main(args=args,env=env)


# Generated at 2022-06-23 19:16:53.148566
# Unit test for function program
def test_program():
    exit_status = program()
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:16:55.454050
# Unit test for function program
def test_program():
    exit_status = ExitStatus.SUCCESS
    assert program() == exit_status

# Generated at 2022-06-23 19:16:57.507949
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.encoding = 'utf8'
    print_debug_info(env)

# Generated at 2022-06-23 19:17:05.160835
# Unit test for function print_debug_info
def test_print_debug_info():
    # Mocking variables that would normally be set by the environment
    class myEnv():
        def __init__(self):
            self.logging_level = 'info'
            self.debug = False
            self.colors = 256
            self.max_content_length = 10000000
            self.follow_redirects = True
            self.verify = True
            self.config_dir = '.httpie'
            self.config_file = 'config'
            self.cache_file = 'cache'
            self.max_history_length = 0
            self.default_options = ['--style', 'monokai']
            self.style = 'monokai'
            self.style_override = False

# Generated at 2022-06-23 19:17:12.689070
# Unit test for function get_output_options
def test_get_output_options():
    class dummy:
        def __init__(self, output_options):
            self.output_options = output_options
    assert get_output_options(dummy(output_options='hb'), requests.PreparedRequest()) == (True, True)
    assert get_output_options(dummy(output_options='b'), requests.PreparedRequest()) == (False, True)
    assert get_output_options(dummy(output_options='h'), requests.PreparedRequest()) == (True, False)
    assert get_output_options(dummy(output_options='Hb'), requests.Response()) == (True, True)
    assert get_output_options(dummy(output_options='B'), requests.Response()) == (False, True)

# Generated at 2022-06-23 19:17:24.656713
# Unit test for function program
def test_program():
    env = Environment()
    test_args = argparse.Namespace(
        output_options = ['stream'],
        output_file = None,
        output_file_specified = False,
        download = False,
        download_resume = False,
        follow = False,
        check_status = False,
        quiet = False
    )
    url = 'http://icanhazip.com'
    messages = collect_messages(args=test_args, config_dir=env.config.directory,
                                request_body_read_callback=None)
    prev_with_body = False
    for message in messages:
        is_request = isinstance(message, requests.PreparedRequest)
        with_headers, with_body = get_output_options(args=test_args, message=message)

# Generated at 2022-06-23 19:17:32.874775
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr = io.StringIO()
    print_debug_info(env)
    assert httpie_version == env.stderr.getvalue()
    env.stderr = io.StringIO()
    print_debug_info(env)
    assert requests_version == env.stderr.getvalue()
    env.stderr = io.StringIO()
    print_debug_info(env)
    assert pygments_version == env.stderr.getvalue()

# Generated at 2022-06-23 19:17:36.767469
# Unit test for function main
def test_main():
    assert main(['/home/sachin/.local/bin/http', 'httpie.org']) == 0
    assert main(['/home/sachin/.local/bin/http', 'httpie.org', '--debug']) == 0


# Generated at 2022-06-23 19:17:45.680127
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['1', '2', '\xe2\x98\x83'], 'utf8') == ['1', '2', '☃']
    assert decode_raw_args(['1', '2', '\xe2\x98\x83'], 'ISO-8859-1') == ['1', '2', 'â˜ƒ']
    assert decode_raw_args(['1', '2', '\xe2\x98\x83'], 'cp866') == ['1', '2', 'ЎУФ']

# Generated at 2022-06-23 19:17:46.963260
# Unit test for function main
def test_main():
    assert main(env=Environment()) == 0

test_main()

# Generated at 2022-06-23 19:17:57.719628
# Unit test for function main
def test_main():
    # Test CLI Help Page
    assert main('http --help'.split()) == ExitStatus.SUCCESS
    assert main('http --debug'.split()) == ExitStatus.SUCCESS

    # Test CLI --json Output
    assert main('http https://httpbin.org/get --json'.split()) == ExitStatus.SUCCESS
    assert main('http --json POST https://httpbin.org/post test=httpie'.split()) == ExitStatus.SUCCESS
    assert main('http --json --form POST https://httpbin.org/post test=httpie'.split()) == ExitStatus.SUCCESS

    # Test CLI --download Output
    assert main('http https://httpbin.org/image/png --download'.split()) == ExitStatus.SUCCESS

    # Test CLI Invalid URL
    assert main('http a-b-c'.split()) != Exit

# Generated at 2022-06-23 19:18:03.383361
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'abc'], 'ascii') == ['abc']
    assert decode_raw_args(['abc'], 'ascii') == ['abc']
    assert decode_raw_args([b'abc', 'def'], 'ascii') == ['abc', 'def']
    assert decode_raw_args(['abc', b'def'], 'ascii') == ['abc', 'def']

# Generated at 2022-06-23 19:18:10.179773
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = ['http', 'http://httpbin.org/get']
    decoded_args = decode_raw_args(args=args, stdin_encoding='utf8')
    assert decoded_args == args
    try:
        import locale  # TODO: Only for Python 3?
        stdin_encoding = locale.getpreferredencoding()
    except (ImportError, AttributeError):
        stdin_encoding = 'UTF-8'
    args = [b'http', 'http://httpbin.org/get']
    decoded_args = decode_raw_args(args=args, stdin_encoding=stdin_encoding)
    assert decoded_args == ['http', 'http://httpbin.org/get']

# Generated at 2022-06-23 19:18:20.896438
# Unit test for function main
def test_main():
    assert main() == ExitStatus.ERROR
    assert main('httpie', '--debug') == ExitStatus.SUCCESS
    assert main('httpie', '--debug') == ExitStatus.SUCCESS
    assert main('httpie', '--debug', '--traceback') == ExitStatus.ERROR
    assert main('httpie') == ExitStatus.ERROR
    assert main('httpie', 'get') == ExitStatus.SUCCESS
    assert main('httpie', 'get', 'https://httpbin.org/get') == ExitStatus.SUCCESS
    assert main('httpie', '--headers') == ExitStatus.ERROR
    assert main('httpie', '--headers', 'get', 'https://httpbin.org/get') == ExitStatus.SUCCESS
    assert main('httpie', '--verbose') == ExitStatus.ERROR
    assert main

# Generated at 2022-06-23 19:18:27.724645
# Unit test for function main
def test_main():
    # Test --debug
    result = main(['--debug'])
    assert result == ExitStatus.SUCCESS

    # Test --traceback
    result = main(['--traceback'])
    assert result != ExitStatus.SUCCESS

    # Test --traceback with --debug
    result = main(['--debug', '--traceback'])
    assert result != ExitStatus.SUCCESS
    
# Test for function program

# Generated at 2022-06-23 19:18:35.372299
# Unit test for function get_output_options
def test_get_output_options():
    def output_options(
        args, message
    ) -> Tuple[bool, bool]:
        return {
            requests.PreparedRequest: (
                OUT_REQ_HEAD in args.output_options,
                OUT_REQ_BODY in args.output_options,
            ),
            requests.Response: (
                OUT_RESP_HEAD in args.output_options,
                OUT_RESP_BODY in args.output_options,
            ),
        }[type(message)]
    # Check request
    args = argparse.Namespace(
            output_options=["hH"],
        )
    msg = requests.PreparedRequest()
    assert output_options(args, msg) == (True, False)
    # Check response

# Generated at 2022-06-23 19:18:40.491349
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert not decode_raw_args(['foo', 'bar'], 'utf-8')

    try:
        assert not decode_raw_args([b'foo', b'bar'], 'utf-8')
    except:
        pass

    assert decode_raw_args([b'foo', b'bar'], 'ascii') == ['foo', 'bar']

# Generated at 2022-06-23 19:18:42.081043
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=[b'abc', 'def'], stdin_encoding='utf8') == ['abc', 'def']

# Generated at 2022-06-23 19:18:47.969817
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a'], 'ascii') == ['a']
    assert decode_raw_args(['a', 'b'], 'ascii') == ['a', 'b']
    assert decode_raw_args([b'a', 'b'], 'ascii') == ['a', 'b']
    assert decode_raw_args([b'a'], 'ascii') == ['a']
    assert decode_raw_args([b'\xE2\x82\xAC'], 'utf8') == ['€']
    assert decode_raw_args([b'\xE2', '€'], 'utf8') == ['\xE2', '€']

# Generated at 2022-06-23 19:18:54.061252
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'foo', b'bar'], 'ascii') == ['foo', 'bar']
    assert decode_raw_args(['foo', 'bar'], 'ascii') == ['foo', 'bar']
    assert decode_raw_args(['foo', b'bar'], 'ascii') == ['foo', 'bar']