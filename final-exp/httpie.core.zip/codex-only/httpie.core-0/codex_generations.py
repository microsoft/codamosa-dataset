

# Generated at 2022-06-23 19:08:56.905535
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 19:09:02.521807
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    buffer = StringIO()
    env = Environment(
        stdin_isatty=False,
        stdin=None,
        stdout_isatty=False,
        stdout=buffer,
        stderr_isatty=False,
        stderr=buffer,
    )
    print_debug_info(env)
    print(buffer.getvalue())

# Generated at 2022-06-23 19:09:13.703745
# Unit test for function program
def test_program():
    from httpie.output.streams import StdinBytesIO
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.streams import StderrBytesIO
    from httpie.output.streams import StdinTextIO
    from httpie.output.streams import StdoutTextIO
    from httpie.output.streams import StderrTextIO

    from httpie.cli.definition import parser

    env = Environment()
    
    # Test with text streams.
    env.stdin = StdinTextIO
    env.stdout = StdoutTextIO
    env.stderr = StderrTextIO

    args = ['httpie', 'https://httpbin.org/get']
    parsed_args = parser.parse_args(argv=args, env=env)


# Generated at 2022-06-23 19:09:25.682791
# Unit test for function program
def test_program():
    def fake_collect_messages():
        message1 = requests.PreparedRequest()
        message1.body = "test body"
        message1.url = "http://www.baidu.com"
        message2 = requests.Response()
        message2.body = "test body for response"
        message2.raw.status_code = 200
        message2.url = "http://www.baidu.com"
        return [message1, message2]
    def fake_http_status_to_exit_status(http_status, follow=None):
        if http_status == 200:
            return ExitStatus.SUCCESS
        else:
            return ExitStatus.ERROR_TOO_MANY_REDIRECTS

    class fake_stdout:
        def write(self, data):
            print(data)

   

# Generated at 2022-06-23 19:09:29.984864
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'\xe4\xbd\xa0\xe5\xa5\xbd'], 'utf-8') == ['你好']
    assert decode_raw_args(['hello'], 'ascii') == ['hello']

# Generated at 2022-06-23 19:09:33.646508
# Unit test for function print_debug_info
def test_print_debug_info():
    from unittest import mock, TestCase
    from io import StringIO

    class Env(object):
        def __init__(self):
            self.stderr = StringIO()

    stderr = Env()
    main(['http', '--debug'], env=stderr)



# Generated at 2022-06-23 19:09:44.949267
# Unit test for function print_debug_info
def test_print_debug_info():
    class Env:
        class Stderr:
            def __init__(self):
                self.buf = ""
            def writelines(self, data):
                self.buf += "".join(data)
            def write(self, data):
                self.buf += data
        class Config:
            class Directory:
                def __init__(self):
                    self.directory = ""
        class Dir(Directory):
            pass
        class Log:
            pass
        class Stdout:
            pass
        def __init__(self):
            self.stderr = Env.Stderr()
            self.config = Env.Config()
            self.stderr_isatty = True
            self.stdout_isatty = True
            self.stdout = Env.Stdout()
            self.log

# Generated at 2022-06-23 19:09:50.517381
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    assert output.getvalue() == 'HTTPie {0}\n'.format(__version__) + \
        'Requests {0}\n'.format(requests.__version__) + \
        'Pygments {0}\n'.format(pygments.__version__) + \
        'Python {0}\n{1}\n'.format(sys.version, sys.executable) + \
        '{0} {1}\n'.format(platform.system(), platform.release()) + \
        '\n\n{0}\n'.format(repr(env))

# Generated at 2022-06-23 19:09:55.237264
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args1 = [b'test']
    result1 = decode_raw_args(args1, 'utf-8')
    assert result1 == ['test']

    args2 = ['test']
    result2 = decode_raw_args(args2, 'utf-8')
    assert result2 == ['test']

# Generated at 2022-06-23 19:09:59.793116
# Unit test for function print_debug_info
def test_print_debug_info():
    """
    Unit test for function print_debug_info
    :return:
    """
    class Env:
        stderr = sys.stderr
        stdin_encoding = 'utf8'
        stdin_isatty = True
        stdout_isatty = True

        @staticmethod
        def log_error(msg, level='error'):
            pass

    print_debug_info(Env())

# Generated at 2022-06-23 19:10:01.676866
# Unit test for function main
def test_main():
    assert main(['httpie', 'https://httpie.org']) == 0

test_main()

# Generated at 2022-06-23 19:10:13.439261
# Unit test for function main
def test_main():
    # test success
    args = ['http', '--version']
    sys.argv = args
    assert (main(args, Environment) == 0), "Should be true"
    args = ['http', '--debug']
    sys.argv = args
    assert (main(args, Environment) == 0), "Should be true"
    args = ['http', '--json', 'https://httpbin.org/get']
    sys.argv = args
    assert (main(args, Environment) == 0), "Should be true"
    args = ['http', '--pretty=all', 'https://httpbin.org/get', 'name==value']
    sys.argv = args
    assert (main(args, Environment) == 0), "Should be true"

# Generated at 2022-06-23 19:10:20.210069
# Unit test for function get_output_options
def test_get_output_options():

    resp = requests.Response()
    req = requests.Request()
    args = argparse.Namespace(output_options=[])

    assert get_output_options( args, resp) == (False, False)
    assert get_output_options( args, req) == (False, False)

    args = argparse.Namespace(output_options=[OUT_RESP_HEAD])
    assert get_output_options( args, resp) == (True, False)

    args = argparse.Namespace(output_options=[OUT_REQ_HEAD])
    assert get_output_options( args, req) == (True, False)

    args = argparse.Namespace(output_options=[OUT_REQ_BODY])
    assert get_output_options( args, req) == (False, True)


# Generated at 2022-06-23 19:10:22.795745
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['--form'], 'UTF-8') == ['--form']
    assert decode_raw_args([b'--form'], 'UTF-8') == ['--form']
    assert decode_raw_args([b'\u2014'], 'UTF-8') == ['\u2014']

# Generated at 2022-06-23 19:10:27.112121
# Unit test for function get_output_options
def test_get_output_options():
    class MockArgs:
        pass

    args = MockArgs()
    args.output_options = OUT_REQ_HEAD | OUT_RESP_BODY
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)
    assert get_output_options(args, requests.Response()) == (False, True)

# Generated at 2022-06-23 19:10:34.517063
# Unit test for function print_debug_info
def test_print_debug_info():
    """
    Tests the debug print function
    """
    output = io.StringIO()
    def mock_stderr_write(s):
        output.write(s)
    env = Environment()
    env.stderr.write = mock_stderr_write
    print_debug_info(env)
    print(output.getvalue())
    assert env.stderr.write == mock_stderr_write, "print_debug_info doesn't work"
    output.close()

# Generated at 2022-06-23 19:10:45.232176
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from click.testing import CliRunner
    runner = CliRunner()

    def decode_raw_args_test(args=[], stdin_encoding='utf-8'):
        raw_args = [
            bytes('foo' if type(i) == int else i, stdin_encoding) for i in args
        ]
        cli_args = decode_raw_args(args=raw_args, stdin_encoding='utf-8')
        assert cli_args == args

    decode_raw_args_test()
    decode_raw_args_test(args=['foo'])
    decode_raw_args_test(args=['foo', 1, 'bar'])
    decode_raw_args_test(args=['foo', 1, 'bar'], stdin_encoding='latin-1')

# Generated at 2022-06-23 19:10:46.489609
# Unit test for function print_debug_info
def test_print_debug_info():
    pass


# Generated at 2022-06-23 19:10:48.215422
# Unit test for function decode_raw_args
def test_decode_raw_args():
    decode_raw_args(args=[b'foo', b'bar'], stdin_encoding='utf-8')

# Generated at 2022-06-23 19:10:53.416169
# Unit test for function get_output_options
def test_get_output_options():
    args = Namespace()
    args.output_options = {
        OUT_RESP_BODY, OUT_RESP_HEAD
    }

    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (True, False)

    message = requests.Response()
    assert get_output_options(args, message) == (True, True)

# Generated at 2022-06-23 19:11:05.193369
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[OUT_RESP_BODY])
    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (False, False)

    args = argparse.Namespace(output_options=[OUT_REQ_BODY])
    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (False, True)

    args = argparse.Namespace(output_options=[OUT_REQ_BODY, OUT_REQ_HEAD])
    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (True, True)

    args = argparse.Namespace(output_options=[OUT_RESP_BODY])
    message = requests.Response()

# Generated at 2022-06-23 19:11:10.387838
# Unit test for function decode_raw_args
def test_decode_raw_args():
    raw_args = [
        b'\xe5\xb9\xb3\xe5\xb7\x9d\xe3\x81\xab\xe3\x81\xa1\xe3\x81\xaf',
        '-v',
        b'\xe3\x82\x88\xe3\x81\x86\xe3\x81\xbb\xe3\x81\x92',
        '--form',
        b'\xe3\x81\xbb\xe3\x81\x92\xe3\x81\xbc\xe3\x81\x86',
    ]
    decoded_args = decode_raw_args(raw_args, 'utf8')

# Generated at 2022-06-23 19:11:13.574509
# Unit test for function decode_raw_args
def test_decode_raw_args():
    encoded_args = ['http', b'http\u0020bin.org']
    decoded_args = decode_raw_args(encoded_args, 'utf8')
    assert decoded_args == ['http', 'http bin.org']

# Generated at 2022-06-23 19:11:19.954301
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['GET'], 'ascii') == ['GET']
    assert decode_raw_args([b'GET'], 'ascii') == ['GET']
    assert decode_raw_args([b'\xc4\x85'], 'utf8') == ['ą']


__all__ = ('main',)

# Generated at 2022-06-23 19:11:22.021048
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS
    assert main(['-V']) == ExitStatus.SUCCESS


# Generated at 2022-06-23 19:11:33.569064
# Unit test for function get_output_options
def test_get_output_options():
    from click.testing import CliRunner
    from httpie.cli import main as cli
    from httpie.cli.definition import parser

    class options_request(argparse.Namespace):
        def __init__(self, option_value: str):
            self.output_options = option_value
            self.output_file = None
            self.output_file_specified = False

    class options_response(argparse.Namespace):
        def __init__(self, option_value: str):
            self.output_options = option_value
            self.output_file = None
            self.output_file_specified = False

    class requests_request(requests.PreparedRequest):
        def __init__(self, method: str, url: str, headers: str, body: str):
            self.method = method
            self

# Generated at 2022-06-23 19:11:45.319420
# Unit test for function main
def test_main():
    from httpie.cli.constants import ExitStatus
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.compat import is_windows

    from pathlib import Path

    import requests
    import pytest
    import sys

    config_dir = Path(__file__).parent / 'config_dir'
    env = Environment(stdin=sys.stdin, stdout=sys.stdout,
                      stderr=sys.stderr, config_dir=config_dir)


# Generated at 2022-06-23 19:11:55.803276
# Unit test for function decode_raw_args
def test_decode_raw_args():
    PATH_PYTHON = 'Python 3.7.1 (v3.7.1:260ec2c36a, Oct 20 2018, 03:13:28) ' \
              '[MSC v.1915 64 bit (AMD64)]'
    PATH_PYTHON_WINDOWS = r'Python 3.7.1 (v3.7.1:260ec2c36a, Oct 20 2018, 03:13:28) ' \
              '[MSC v.1915 64 bit (AMD64)]'
    PATH_PYTHON_UTF8 = b'Python 3.7.1 (v3.7.1:260ec2c36a, Oct 20 2018, 03:13:28) ' \
              b'[MSC v.1915 64 bit (AMD64)]'

# Generated at 2022-06-23 19:11:58.877977
# Unit test for function get_output_options
def test_get_output_options():
    options = ['-b', '-h', '-sb', '-sh']
    args = parser.parse_args(options)

    assert get_output_options(args, requests.PreparedRequest()) == (True, True)
    assert get_output_options(args, requests.Response()) == (True, True)

# Generated at 2022-06-23 19:12:02.963062
# Unit test for function program
def test_program():
    args = parser.parse_args(['get','https://httpbin.org/get?test=test'])
    assert program(args, Environment()) == ExitStatus.SUCCESS


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:12:09.832629
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_RESP_HEAD, OUT_RESP_BODY]
    message = requests.PreparedRequest()
    message.method = 'PUT'
    assert get_output_options(args, message) == (False, False)
    message = requests.Response()
    message.status_code = 200
    assert get_output_options(args, message) == (True, True)

# Generated at 2022-06-23 19:12:17.585861
# Unit test for function get_output_options
def test_get_output_options():
    # httpie 0.10.0
    args = argparse.Namespace(output_options=['all'])
    message = requests.PreparedRequest()
    assert (True, True) == get_output_options(args, message)
    message = requests.Response()
    assert (True, True) == get_output_options(args, message)

    args = argparse.Namespace(output_options=['allb'])
    message = requests.PreparedRequest()
    assert (True, False) == get_output_options(args, message)
    message = requests.Response()
    assert (True, False) == get_output_options(args, message)

    args = argparse.Namespace(output_options=['alf'])
    message = requests.PreparedRequest()
    assert (False, True) == get_output_

# Generated at 2022-06-23 19:12:24.074454
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from httpie.context import Environment
    new_args = decode_raw_args(
        args=['http', 'GET', 'http://www.xxx.com'],
        stdin_encoding=Environment().stdin_encoding,
    )
    assert new_args == ['http', 'GET', 'http://www.xxx.com']

# Generated at 2022-06-23 19:12:29.708456
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    lines = env.stderr.getvalue().split('\n')
    assert 'HTTPie' in lines[0]
    assert 'Requests' in lines[1]
    assert 'Pygments' in lines[2]
    assert 'Python' in lines[3]
    assert '/usr/bin/python3.6' in lines[4]
    assert 'Linux' in lines[5]

# Generated at 2022-06-23 19:12:41.525039
# Unit test for function program
def test_program():
    # Change the current working directory so that the conf file is found (necessary on Windows)
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    # Set the output and progress file to bytes so we can check the output
    env = Environment(stdout=BytesIO(), stderr=BytesIO())

    # Required so it doesn't use the real stdin when reading the request body
    args = parser.parse_args(['--verbose', '--body=', '--form', 'POST', 'localhost'], env=env)

    # Execute the main program
    main(env=env, args=[sys.argv[0], '--verbose', '--body=', '--form', 'POST', 'localhost'])

    # Check the output

# Generated at 2022-06-23 19:12:54.226288
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_RESP_HEAD]
    message = requests.Response()
    with_headers, with_body = get_output_options(args, message)
    assert(with_headers)
    assert(not with_body)
    args.output_options = [OUT_RESP_BODY]
    with_headers, with_body = get_output_options(args, message)
    assert(not with_headers)
    assert(with_body)
    args.output_options = [OUT_REQ_HEAD]
    message = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args, message)
    assert(with_headers)
    assert(not with_body)

# Generated at 2022-06-23 19:13:04.753593
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from unittest import TestCase

    class DecodeRawArgsTestCase(TestCase):
        def setUp(self):
            self.args = ['/usr/bin/python3', '-c', 'print("hello")']
            self.args_bytes = [
                arg.encode() if type(arg) is str else arg
                for arg in self.args
            ]

        def test_returns_list_of_str(self):
            args = decode_raw_args(self.args_bytes, 'utf8')
            self.assertEqual(args, self.args)
            self.assertTrue(all(type(arg) is str for arg in args))

        def test_does_not_change_str_args(self):
            args = decode_raw_args(self.args, 'utf8')

# Generated at 2022-06-23 19:13:15.884257
# Unit test for function main
def test_main():
    from httpie import ExitStatus
    from httpie.cli import env
    
    assert main(['http', '--timeout=2', '--check-status', '--headers', 'http://www.google.com']) == ExitStatus.SUCCESS
    assert main(['http', '--timeout=2', '--check-status', '--headers', 'http://www.google.com']) == 0
    assert main(['http', '--timeout=2', '--headers', '--stream', '--check-status', 'http://www.google.com']) == ExitStatus.SUCCESS
    assert main(['http', '--timeout=2', '--headers', '--stream', '--check-status', 'http://www.google.com']) == 0

# Generated at 2022-06-23 19:13:24.996872
# Unit test for function get_output_options
def test_get_output_options():
    argparse_object = argparse.Namespace(output_options=[OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY])
    assert get_output_options(argparse_object, requests.PreparedRequest()) == (False, True)
    assert get_output_options(argparse_object, requests.Response()) == (True, True)
    argparse_object = argparse.Namespace(output_options=[OUT_REQ_HEAD])
    assert get_output_options(argparse_object, requests.PreparedRequest()) == (True, False)
    assert get_output_options(argparse_object, requests.Response()) == (False, False)

# Generated at 2022-06-23 19:13:36.959314
# Unit test for function get_output_options
def test_get_output_options():
        args = argparse.Namespace()
        args.output_options = {'body', 'headers'}
        
        req_msg = requests.PreparedRequest()
        assert get_output_options(args, req_msg) == (True, True)

        resp_msg = requests.Response()
        assert get_output_options(args, resp_msg) == (True, True)

        args.output_options = {'headers'}
        assert get_output_options(args, req_msg) == (True, False)
        assert get_output_options(args, resp_msg) == (True, False)

        args.output_options = {'body'}
        assert get_output_options(args, req_msg) == (False, True)

# Generated at 2022-06-23 19:13:41.781094
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    out = StringIO()
    print_debug_info(env=Environment(stderr=out))
    assert 'HTTPie' in out.getvalue()
    assert 'Requests' in out.getvalue()
    assert 'Pygments' in out.getvalue()
    assert 'Python' in out.getvalue()

# Generated at 2022-06-23 19:13:51.365376
# Unit test for function get_output_options
def test_get_output_options():
    request_output_options = get_output_options(
        args=argparse.Namespace(output_options=OUT_REQ_HEAD),
        message=requests.PreparedRequest()
    )
    assert request_output_options == (True, False)
    request_output_options = get_output_options(
        args=argparse.Namespace(output_options=OUT_REQ_BODY),
        message=requests.PreparedRequest()
    )
    assert request_output_options == (False, True)
    request_output_options = get_output_options(
        args=argparse.Namespace(output_options=OUT_REQ_HEAD + OUT_REQ_BODY),
        message=requests.PreparedRequest()
    )
    assert request_output_options == (True, True)
   

# Generated at 2022-06-23 19:13:54.454587
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_BODY, 'b']

    message = requests.PreparedRequest()
    assert (get_output_options(args, message) == (False, True))

    message = requests.Response()
    assert (get_output_options(args, message) == (False, False))

# Generated at 2022-06-23 19:14:05.404997
# Unit test for function main
def test_main():
    from httpie import ExitStatus
    from httpie.cli.constants import OUT_REQ_BODY, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output import OUTPUT_OPTIONS, output_options_from_kwargs
    from httpie.status import ExitStatus

    from httpie.cli import main

    from tests import http
    from tests.compat import str

    args = ['https://httpbin.org/get']

    env = Environment()

# Generated at 2022-06-23 19:14:10.886176
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a', 'b', 'c'], None) == ['a', 'b', 'c']
    try:
        decode_raw_args(['a', 'b', 'c'], None)
    except Exception as e:
        print(e)
        assert False, "Should not raise exception"


if __name__ == '__main__':
    exit_status = main()
    sys.exit(exit_status)

# Generated at 2022-06-23 19:14:16.127376
# Unit test for function main
def test_main():
    '''
    :return:
    '''
    sys.argv = ['http', 'https://github.com/jakubroztocil/httpie', '--json']
    env = Environment()
    exit_status = main(env=env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:14:17.860551
# Unit test for function decode_raw_args
def test_decode_raw_args():
    b = b'\xcf\x80'
    assert decode_raw_args([b], 'utf-8') == [b'\xcf\x80']

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 19:14:30.317614
# Unit test for function get_output_options
def test_get_output_options():
    args_output_options = [OUT_REQ_HEAD, OUT_RESP_HEAD]
    request = requests.PreparedRequest()
    assert get_output_options(args=args_output_options, message=request) == (True, False)
    response = requests.Response()
    assert get_output_options(args=args_output_options, message=response) == (True, False)

    args_output_options = [OUT_REQ_BODY, OUT_RESP_BODY]
    request = requests.PreparedRequest()
    assert get_output_options(args=args_output_options, message=request) == (False, True)
    response = requests.Response()
    assert get_output_options(args=args_output_options, message=response) == (False, True)


# Generated at 2022-06-23 19:14:36.669297
# Unit test for function main
def test_main():
    try:
        sys.argv[1] = '--version'
        exit_status = main()
        assert exit_status == ExitStatus.SUCCESS, 'exit_status'
    except:
        print('=======')
        traceback.print_exc()
        print('=======')
        assert False, 'failed'

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 19:14:44.757974
# Unit test for function get_output_options
def test_get_output_options():
    # Arrange
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_BODY, OUT_RESP_HEAD]
    req = requests.PreparedRequest()
    resp = requests.Response()
    # Act
    actual = get_output_options(args, req)
    # Assert
    assert actual == (False, True)
    # Act
    actual = get_output_options(args, resp)
    # Assert
    assert actual == (True, False)

# Generated at 2022-06-23 19:14:47.394094
# Unit test for function main
def test_main():
    args = ['http', 'https://httpbin.org/get']
    result  = main(args)
    assert result == ExitStatus.SUCCESS

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 19:14:59.561673
# Unit test for function print_debug_info
def test_print_debug_info():
    # Create env to use as a dummy 'system'.
    class TestStream:
        def write(self, *args):
            self.out = str(args[0])
    test_stream_stdin = TestStream()
    test_stream_stdout = TestStream()
    test_stream_stderr = TestStream()
    env = Environment(
        stdin=test_stream_stdin,
        stdout=test_stream_stdout,
        stderr=test_stream_stderr,
        program_name='httpie-unittest'
    )

    # Set env to Linux system, which will simplify output.
    platform.system = lambda: 'Linux'
    platform.release = lambda: '5.5.5-arch1-1'

    # Set env to be a tty.
    env.stdout

# Generated at 2022-06-23 19:15:11.588020
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options={"params", "body", "headers", "pretty", "style"})
    message = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args, message)
    assert with_headers == True
    assert with_body == True
    message = requests.Response()
    with_headers, with_body = get_output_options(args, message)
    assert with_headers == True
    assert with_body == True
    args = argparse.Namespace(output_options={"params", "body-debug", "headers", "pretty", "style"})
    message = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args, message)
    assert with_headers == True
    assert with_body == False
   

# Generated at 2022-06-23 19:15:16.673184
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.context import Environment
    from io import StringIO
    env = Environment()
    env.stderr = StringIO()
    print_debug_info(env)
    assert(env.stderr.getvalue() != "")
    env.stderr.close()

# Generated at 2022-06-23 19:15:24.676645
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(stdin=None,
                      stdin_isatty=True,
                      stdout=StringIO(),
                      stdout_isatty=True,
                      stderr=StringIO(),
                      stderr_isatty=True)
    print_debug_info(env)
    output = env.stderr.getvalue()
    assert output.startswith("HTTPie ")
    assert "\nRequests " in output
    assert "\nPygments " in output
    assert "\nPython " in output
    assert "\n" in output
    assert "\n\n" in output
    assert repr(env) in output
    assert "\n" in output

# Generated at 2022-06-23 19:15:29.240792
# Unit test for function print_debug_info
def test_print_debug_info():
    class TestEnvironment(Environment):
        def __init__(self):
            self.stderr = StringIO()
            self.stdout = StringIO()

    env = TestEnvironment()
    print_debug_info(env)
    assert 'HTTPie' in env.stderr.getvalue()

# Generated at 2022-06-23 19:15:41.414055
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options='')
    request = requests.PreparedRequest()
    response = requests.Response()
    assert get_output_options(args, request) == (False, False)
    assert get_output_options(args, response) == (False, False)

    args = argparse.Namespace(output_options='H')
    assert get_output_options(args, request) == (True, False)
    assert get_output_options(args, response) == (True, False)

    args = argparse.Namespace(output_options='h')
    assert get_output_options(args, request) == (True, False)
    assert get_output_options(args, response) == (True, False)

    args = argparse.Namespace(output_options='B')
    assert get

# Generated at 2022-06-23 19:15:43.953481
# Unit test for function main
def test_main():
    from httpie.cli import main
    import requests
    r = main()
    assert r == ExitStatus.SUCCESS
    assert r == requests.status_codes.codes.ok

# Generated at 2022-06-23 19:15:48.924889
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = argparse.Namespace()
    args.output_options = OUT_REQ_BODY
    assert get_output_options(args, requests.PreparedRequest()) == (False, True)
    args.output_options = OUT_REQ_BODY | OUT_REQ_HEAD | OUT_RESP_BODY
    assert get_output_options(args, requests.Response()) == (True, True)

# Generated at 2022-06-23 19:15:54.176560
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    env = Environment()
    out = StringIO()
    env.stderr = out
    print_debug_info()
    output = out.getvalue()
    env.stderr.close()
    return output

# Generated at 2022-06-23 19:16:02.908513
# Unit test for function main
def test_main():
    from httpie.cli.util import CompressedFile

    try:
        import http.client as http_client
    except ImportError:
        import httplib as http_client  # type: ignore

    class MockEnvironment:

        class MockStdOut:
            pass

        class MockStdErr:
            pass

        class MockStdIn:
            pass

        # noinspection PyMethodParameters
        class MockCompressedFile:
            file_obj: Optional[CompressedFile] = None
            GZIP_MODE = 'gzip'

            def open(self, file_obj, mode='w'):
                self.file_obj = file_obj
                return file_obj

        def __init__(self):
            self.stderr = MockEnvironment.MockStdErr()
            self.stdout = MockEnvironment

# Generated at 2022-06-23 19:16:05.566412
# Unit test for function print_debug_info
def test_print_debug_info():
    import io

    from httpie.context import Environment
    env = Environment()
    env.stderr = io.StringIO()

    print_debug_info(env)

# Generated at 2022-06-23 19:16:14.391517
# Unit test for function get_output_options
def test_get_output_options():
    import requests
    import pytest
    from collections import namedtuple
    from httpie.cli.definition import parser
    from httpie.output import writer
    import click

    class MockContext(object):
        def __init__(self):
            self.obj = parser.parse_args(['get', 'www.google.com'])

    mock_msg = requests.PreparedRequest()
    mock_msg.headers = {'Accept': 'application/json'}
    mock_msg.body = '{"foo": "bar"}'
    ctx = MockContext()

    # Case 1: all header and body options, default
    mock_msg.response_type = writer.OUTPUT_OPTION_REQUEST_BODY
    assert (True, True) == get_output_options(ctx.obj, mock_msg)
    mock_msg

# Generated at 2022-06-23 19:16:24.421351
# Unit test for function main
def test_main():
    assert main(['http', 'https://httpbin.org']) == 0
    assert main(['http', 'https://httpbin.org', '--debug']) == 0
    assert main(['http', 'https://httpbin.org', '--download']) == 0
    assert main(['http', 'https://httpbin.org', '--download', 'test.txt']) == 0
    assert main(['http', 'https://httpbin.org', '--download', 'test.txt', '--output', 'test.txt']) == 0
    assert main(['http', 'https://httpbin.org', '--download', '--quiet']) == 0
    assert main(['http', 'https://httpbin.org', '--download', '--quiet', '--check-status']) == 0

# Generated at 2022-06-23 19:16:29.859175
# Unit test for function main
def test_main():
    assert main(args=['--no-defaults']) == 0
    assert main(args=['-F', 'env']) == 0
    assert main(args=['--print=b']) == 0
    assert main(args=['-p']) == 0
    assert main(args=['-S', '2>/dev/null']) == 0

# Generated at 2022-06-23 19:16:32.007313
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'foo'], 'latin1') == ['foo']



# Generated at 2022-06-23 19:16:42.842609
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = ['b', 'h']
    message = requests.Response()
    assert get_output_options(args, message) == (True, True)
    args.output_options = ['b', 'hb']
    message = requests.Response()
    assert get_output_options(args, message) == (True, True)
    args.output_options = ['h']
    message = requests.Response()
    assert get_output_options(args, message) == (True, False)
    args.output_options = ['hb']
    message = requests.Response()
    assert get_output_options(args, message) == (True, True)
    args.output_options = ['b']
    message = requests.Response()

# Generated at 2022-06-23 19:16:55.492274
# Unit test for function get_output_options
def test_get_output_options():
    import unittest
    import httpie.output.streams

    class TestEnv(unittest.TestCase):
        args = argparse.Namespace(
            output_options = [OUT_RESP_HEAD, OUT_RESP_BODY]
        )
        env = Environment(stdin=httpie.output.streams.get_argparse_stdin())

        def test_response_headers_not_outputted(self):
            h, b = get_output_options(args=self.args, message=requests.Request())
            self.assertEqual((h, b), (False, False))

        def test_response_body_is_outputted(self):
            h, b = get_output_options(args=self.args, message=requests.Response())

# Generated at 2022-06-23 19:17:00.749838
# Unit test for function print_debug_info
def test_print_debug_info():
    debug_info = print_debug_info(env)
    assert "HTTPie" in debug_info
    assert "Requests" in debug_info
    assert "Pygments" in debug_info
    assert "Python" in debug_info
    assert "sys.executable" in debug_info
    assert "platform.system()" in debug_info
    assert "platform.release()" in debug_info


# Generated at 2022-06-23 19:17:01.733854
# Unit test for function main
def test_main():
    main()
    main(['--debug'])

# Generated at 2022-06-23 19:17:03.575570
# Unit test for function program
def test_program():
    print('test:')
    args = []
    env = Environment()
    program(args, env)


# Generated at 2022-06-23 19:17:08.053487
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        [b'--form', 'field=value'],
        'utf8'
    ) == ['--form', 'field=value']
    assert decode_raw_args(
        [b'--form', b'field=\xe5\x85\x83'],
        'gbk'
    ) == ['--form', 'field=元']

# Generated at 2022-06-23 19:17:13.809771
# Unit test for function main
def test_main():
    assert main(args=['--debug']) == ExitStatus.SUCCESS
    assert main(args=['--debug', 'http://example.com']) == ExitStatus.SUCCESS
    assert main(args=['--debug', 'http://example.com', '--output', 'httpbin.org']) == ExitStatus.SUCCESS


if __name__ == '__main__':
    sys.exit(main(args=sys.argv))

# Generated at 2022-06-23 19:17:17.170705
# Unit test for function main
def test_main():
    assert main(['http', 'httpbin.org/get']) == ExitStatus.SUCCESS

if __name__=='__main__':
    test_main()

# Generated at 2022-06-23 19:17:27.645178
# Unit test for function program
def test_program():
    env = Environment()

# Generated at 2022-06-23 19:17:39.400284
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.output_options = ['h', 'b']
    args.headers = []
    args.output_file = None
    args.check_status = False
    args.download_resume = False
    args.follow = False
    args.quiet = False
    args.method = 'GET'
    args.url = 'http://httpbin.org/get'
    exit_status = program(args=args, env=Environment())
    assert exit_status == ExitStatus.SUCCESS
    args.url = 'http://httpbin.org/status/404'
    exit_status = program(args=args, env=Environment())
    assert exit_status == ExitStatus.ERROR_HTTP_4XX

# Generated at 2022-06-23 19:17:48.617638
# Unit test for function print_debug_info
def test_print_debug_info():
    import optparse
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.output.writer import FormattedStdoutWriter

    class StdoutStderrCapture:
        stdout = io.BytesIO()
        stderr = io.BytesIO()

        @classmethod
        def close(cls):
            cls.stdout.close()
            cls.stderr.close()

    class ArgsCapture:
        output_options = [OUT_RESP_BODY]
        output_file_specified = False
        output_file = None

    class EnvCapture(Environment):
        args = ArgsCapture()
        stdout_isatty = True
        stderr_isatty = True

# Generated at 2022-06-23 19:17:53.218820
# Unit test for function main
def test_main():
    args = ['config', '--env', 'dev', '--endpoint', 'https://localhost:8080/v1/']
    env = Environment()
    result = main(args, env)
    assert result == ExitStatus.SUCCESS
    assert env.program_name == 'config'


# Generated at 2022-06-23 19:17:55.853854
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert(decode_raw_args([b'test'], 'ascii') == ['test'])
    assert(decode_raw_args(['test'], 'ascii') == ['test'])

# Generated at 2022-06-23 19:17:56.458119
# Unit test for function print_debug_info
def test_print_debug_info():
    pass

# Generated at 2022-06-23 19:17:59.874657
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    env = Environment()
    env.stderr = StringIO()
    print_debug_info(env)
    debug_info = env.stderr.getvalue()
    assert "HTTPie" in debug_info
    assert "Requests" in debug_info
    assert "Pygments" in debug_info
    assert "Python" in debug_info

# Generated at 2022-06-23 19:18:03.683675
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = decode_raw_args(['привет', b'\xea\x9b\x87'], 'utf-8')
    assert args[0] == 'привет'
    assert args[1] == 'ꛇ'

# Generated at 2022-06-23 19:18:14.622807
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a', 'b'], 'utf8') == ['a', 'b']
    assert decode_raw_args(['a', 'b'], 'cp1251') == ['a', 'b']
    assert decode_raw_args([b'a', 'b'], 'utf8') == ['a', 'b']
    assert decode_raw_args(['a', b'b'], 'utf8') == ['a', 'b']
    assert decode_raw_args([1, 2], 'utf8') == [1, 2]
    decode_raw_args([b'a', b'b'], 'utf8')
    decode_raw_args([b'\xe0', 'b'], 'cp1') == ['a', 'b']

# Generated at 2022-06-23 19:18:19.709060
# Unit test for function decode_raw_args
def test_decode_raw_args():
    """
    Test if decoding works correctly.

    >>> test_decode_raw_args()
    True
    """
    stdin_encoding = 'cp932'
    return decode_raw_args(['http', '--json', '--ignore-stdin', '-', 'a=\\U0001f600'], stdin_encoding) \
           == ['http', '--json', '--ignore-stdin', '-', 'a=\ud83d\ude00']



# Generated at 2022-06-23 19:18:30.435212
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = set()

    msg = requests.PreparedRequest()
    h, b = get_output_options(args, msg)
    assert not h and not b
    args.output_options = set([OUT_REQ_HEAD])
    h, b = get_output_options(args, msg)
    assert h and not b
    args.output_options = set([OUT_REQ_BODY])
    h, b = get_output_options(args, msg)
    assert not h and b
    args.output_options = set([OUT_REQ_HEAD, OUT_REQ_BODY])
    h, b = get_output_options(args, msg)
    assert h and b

    args.output_options = set()
    msg = requests.Response()

# Generated at 2022-06-23 19:18:31.837619
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(["abc",bytearray("def", "utf8")], "utf8") == ["abc", "def"]

# Generated at 2022-06-23 19:18:43.558083
# Unit test for function get_output_options
def test_get_output_options():
    import argparse
    args = argparse.Namespace()
    args.output_options = ['verbose']
    import requests
    h = requests.Request().prepare().headers
    assert get_output_options(args, requests.Request().prepare()) == (True, True)
    assert get_output_options(args, requests.Response(headers=h)) == (True, True)
    args.output_options = ['req_body']
    assert get_output_options(args, requests.Request().prepare()) == (True, True)
    assert get_output_options(args, requests.Response(headers=h)) == (True, False)
    args.output_options = ['resp_body']
    assert get_output_options(args, requests.Request().prepare()) == (False, False)

# Generated at 2022-06-23 19:18:51.686367
# Unit test for function decode_raw_args
def test_decode_raw_args():
    """
    assert(
        decode_raw_args([b'--form', b'key=\xe9\x93\xbe'])
        == ['--form', 'key=釾']
    )
    """
    assert(
        decode_raw_args([b'--form', b'key=\xe9\x93\xbe'], stdin_encoding='utf-8')
        == ['--form', 'key=釾']
    )

# Generated at 2022-06-23 19:18:52.323123
# Unit test for function program
def test_program():
    assert program() == 0

# Generated at 2022-06-23 19:18:56.879304
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace()
    args.output_options = []
    assert program(args, env) == ExitStatus.SUCCESS
    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY]
    assert program(args, env) == ExitStatus.SUCCESS