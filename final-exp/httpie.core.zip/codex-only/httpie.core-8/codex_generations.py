

# Generated at 2022-06-23 19:08:52.673074
# Unit test for function decode_raw_args
def test_decode_raw_args():
    stdin_encoding = 'utf-8'
    raw_args = [
        'GET',
        b'http://httpbin.org/get',
        '-v'
    ]
    assert decode_raw_args(raw_args, stdin_encoding) == [
        raw_args[0],
        raw_args[1].decode(stdin_encoding),
        raw_args[2]
    ]

# Generated at 2022-06-23 19:08:53.547498
# Unit test for function program
def test_program():
    pass

# Generated at 2022-06-23 19:09:00.439726
# Unit test for function get_output_options
def test_get_output_options():
    assert get_output_options(argparse.Namespace(
        output_options = {OUT_REQ_HEAD: True, OUT_RESP_BODY: True}
    ), requests.PreparedRequest()) == (True, False)
    assert get_output_options(argparse.Namespace(
        output_options = {OUT_REQ_HEAD: True, OUT_RESP_BODY: True}
    ), requests.Response()) == (False, True)

# Generated at 2022-06-23 19:09:05.896207
# Unit test for function get_output_options

# Generated at 2022-06-23 19:09:15.789808
# Unit test for function get_output_options
def test_get_output_options():
    import argparse
    import json
    import requests
    import sys
    import unittest

    args = argparse.Namespace(
        check_status=None,
        compress=False,
        config_dir=None,
        default_options=[],
        download=False,
        download_resume=True,
        download_dir=None,
        explicit_content_type=False,
        ignore_stdin=False,
        output_file=None,
        output_options=[
            'h',
            'b',
        ],
        formats=None,
        format=None,
        pretty=None,
        style='$',
        style_mappings=None,
        style_sheet=None,
        verbose=False
    )

    # Request
    message_req = requests.PreparedRequest()

# Generated at 2022-06-23 19:09:21.409441
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = []

    # get_output_options with empty args
    assert get_output_options(args, requests.PreparedRequest()) == (False, False)
    assert get_output_options(args, requests.Response()) == (False, False)

    args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)
    assert get_output_options(args, requests.Response()) == (False, False)

    args.output_options = [OUT_REQ_BODY]
    assert get_output_options(args, requests.PreparedRequest()) == (False, True)
    assert get_output_options(args, requests.Response()) == (False, False)

    args.output

# Generated at 2022-06-23 19:09:27.341950
# Unit test for function get_output_options
def test_get_output_options():
    test_args = argparse.Namespace()
    test_args.output_options = ['vb', 'h']
    test_message = requests.PreparedRequest()
    assert get_output_options(test_args, test_message) == (True, False)

    test_message = requests.Response()
    assert get_output_options(test_args, test_message) == (False, True)

# Generated at 2022-06-23 19:09:35.561224
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(stdout=io.BytesIO(), stderr=io.BytesIO())
    print_debug_info(env)
    assert env.stdout == b""
    assert env.stderr.getvalue().startswith(
        b'HTTPie 1.0.0\n'
        b'Requests 2.18.4\n'
        b'Pygments 2.2.0\n'
        b'Python 3.5.3 (default, Jan 19 2017, 14:11:04) \n[GCC 6.3.0 20170118]\n'
    )

# Generated at 2022-06-23 19:09:36.094265
# Unit test for function program
def test_program():
    pass

# Generated at 2022-06-23 19:09:43.060740
# Unit test for function decode_raw_args
def test_decode_raw_args():
    """
    Some tests for function decode_raw_args.
    """
    # noinspection SpellCheckingInspection

# Generated at 2022-06-23 19:09:48.463712
# Unit test for function program
def test_program():
    from httpie import cli
    from httpie.client import collect_messages
    from pygments import highlight, lexers, formatters
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    env = Environment(colors=False)
    args = parser.parse_args(args=[
        '--check-status',
        '-b',
        'GET',
        'https://httpbin.org/headers',
        'Accept:'
    ], env=env)
    exit_status = program(args, env)
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-23 19:09:56.815974
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        headers='Accept: application/json',
        output_options=['b', 'h']
    )
    class test_PreparedRequest(object):
        pass
    class test_Response(object):
        pass
    test_PreparedRequest_instance = test_PreparedRequest()
    test_Response_instance = test_Response()
    assert get_output_options(args, test_PreparedRequest_instance) == (True, True)
    assert get_output_options(args, test_Response_instance) == (True, True)

# Generated at 2022-06-23 19:10:05.756337
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_TIMEOUT, DEFAULT_VERIFY
    from httpie.http_exceptions import RetryTimeout

    def dummy_argparse_args(config_dir, timeout=DEFAULT_TIMEOUT):
        from httpie.client import DEFAULT_UA


# Generated at 2022-06-23 19:10:16.120455
# Unit test for function print_debug_info
def test_print_debug_info():
    class TestEnv(Environment):
        def __init__(self):
            self.stderr = io.StringIO()

    env = TestEnv()
    print_debug_info(env)
    env.stderr.seek(0)
    actual = env.stderr.read()

# Generated at 2022-06-23 19:10:20.519638
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'--form', 'field=\xc3\xa5'], 'utf8') == ['--form', 'field=\xe5']

# Generated at 2022-06-23 19:10:21.929193
# Unit test for function main
def test_main():
    args = ["http", "--debug"]
    main(args)


# Generated at 2022-06-23 19:10:31.149489
# Unit test for function main
def test_main():

    import argparse
    import httpie
    import httpie.cli.argtypes
    import httpie.plugins.builtin
    import httpie.plugins.local.httpie_plugins
    import httpie.plugins.unicode
    import json
    import logging
    import sys
    from unittest import mock
    from httpie.cli import definition
    from httpie.config import DefaultConfig

    class WriterStub:
        def __init__(self, log_stream: List[str]):
            self._log = log_stream
            self._position = 0

        def write(self, value: str):
            self._log.append(value)

        def close(self):
            pass

        def flush(self):
            pass

        def seek(self, pos):
            self._position = pos


# Generated at 2022-06-23 19:10:37.544296
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert ['á', 'b'] == decode_raw_args(['á', 'b'], 'utf8')
    assert ['á', 'b'] == decode_raw_args(['á', 'b'.encode('utf8')], 'utf8')
    assert ['á', 'b'] == decode_raw_args(['á'.encode('utf8'), 'b'], 'utf8')
    assert ['á', 'b'] == decode_raw_args(['á'.encode('utf8'), 'b'.encode('utf8')], 'utf8')

# Generated at 2022-06-23 19:10:42.041573
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    env = Environment(program_name='http', stdout=io.StringIO(), stderr=io.StringIO())
    print_debug_info(env)
    assert env.stderr.getvalue().startswith('HTTPie ')

# Generated at 2022-06-23 19:10:45.253781
# Unit test for function main
def test_main():
    from httpie.cli import env
    a, b = main(['--debug'], env)
    assert a == 1


# Generated at 2022-06-23 19:10:50.263706
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    _orig_stderr = sys.stderr
    sys.stderr = io.StringIO()
    print_debug_info(env=Environment())
    output = sys.stderr.getvalue()
    matches = [
        'HTTPie',
        'Requests',
        'Pygments',
        'Python',
        sys.executable,
        platform.system(),
        platform.release(),
    ]
    for match in matches:
        assert output.find(match) != -1  # TODO: Consider removing this test.
    sys.stderr = _orig_stderr

# Generated at 2022-06-23 19:10:58.250521
# Unit test for function get_output_options
def test_get_output_options():
    import requests
    import unittest
    import argparse
    class test_get_output_options(unittest.TestCase):
        def test_output_options_values(self):
            request = requests.PreparedRequest()
            response = requests.Response()
            args = argparse.Namespace(
                output_options = ["h", "b"]
            )
            self.assertEqual(get_output_options(args, request), (True, True))
            self.assertEqual(get_output_options(args, response), (True, True))
            args = argparse.Namespace(
                output_options = ["h"]
            )
            self.assertEqual(get_output_options(args, request), (True, False))

# Generated at 2022-06-23 19:11:01.169383
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    lines = []
    env.stderr = lines.append
    print_debug_info(env)
    assert 'Requests ' in ''.join(lines)

# Generated at 2022-06-23 19:11:10.991574
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    message = requests.Response()

    args.output_options = {OUT_RESP_HEAD, OUT_RESP_BODY}
    assert get_output_options(args, message) == (True, True)

    args.output_options = {OUT_RESP_HEAD}
    assert get_output_options(args, message) == (True, False)

    args.output_options = {OUT_RESP_BODY}
    assert get_output_options(args, message) == (False, True)

    args.output_options = set()
    assert get_output_options(args, message) == (False, False)

    args.output_options = {OUT_REQ_HEAD}
    assert get_output_options(args, message) == (True, False)


# Generated at 2022-06-23 19:11:13.770489
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['foo', b'bar'], 'utf8') == ['foo', 'bar']

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 19:11:15.386980
# Unit test for function program
def test_program():
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:11:23.878753
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['www.google.com', '--headers'])
    log_file = open("log_file.txt","w")
    #log_file.truncate(0)
    log_file.write(str(program(args,Environment())))
    log_file.close()
    log_file = open("log_file.txt","r")
    message = log_file.read()
    log_file.close()
    assert message == '0'
    return


# Generated at 2022-06-23 19:11:28.579511
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['aaa'], 'utf-8') == ['aaa']
    assert decode_raw_args([b'aaa'], 'utf-8') == ['aaa']
    assert decode_raw_args([b'aaa'], 'ascii') == ['aaa']


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 19:11:41.238587
# Unit test for function program
def test_program():
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.config import Config
    from httpie import ExitStatus
    from httpie.input import ParseError
    from httpie.plugins import registry
    from httpie.utils import StdinBytesIO
    from httpie.downloads import Downloader
    args = argparse.Namespace()
    args.headers = KeyValueArgType()(None)
    args.output_options = []
    args.timeout = None
    args.max_redirects = 30
    args.check_status = False
    args.follow = False
    env = Environment()
    env.config = Config()
    env.stdin = StdinBytesIO()
    env.stdin.encoding = 'utf8'
    env.stdout = io.BytesIO()
    env.stdout

# Generated at 2022-06-23 19:11:48.901968
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from httpie.context import Environment
    env = Environment()
    env.stderr = StringIO()
    print_debug_info(env)
    assert 'HTTPie' in env.stderr.getvalue()
    assert 'Requests' in env.stderr.getvalue()
    assert 'Pygments' in env.stderr.getvalue()
    assert 'Python' in env.stderr.getvalue()
    assert str(sys.version) in env.stderr.getvalue()

# Generated at 2022-06-23 19:11:58.163155
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    import builtins

    # The string below is the output of
    # {
    #   "follow": false,
    #   "json": false,
    #   "max_redirects": 10,
    #   "output_options": [
    #     "headers",
    #     "status",
    #     "body"
    #   ],
    #   "output_to_stdout": true,
    #   "pretty": false,
    #   "style": "friendly",
    #   "style_format": "terminal",
    #   "style_path": "",
    #   "timeout": 30,
    #   "verbose": false,
    #   "print_body_only_if_error": false,
    #   "json_indent": 2,
   

# Generated at 2022-06-23 19:12:10.096935
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[])
    message = requests.PreparedRequest()
    assert (True, True) == get_output_options(args, message)

    args = argparse.Namespace(output_options=[OUT_REQ_HEAD])
    message = requests.PreparedRequest()
    assert (True, False) == get_output_options(args, message)

    args = argparse.Namespace(output_options=[OUT_REQ_BODY])
    message = requests.PreparedRequest()
    assert (False, True) == get_output_options(args, message)

    args = argparse.Namespace(output_options=[OUT_RESP_HEAD])
    message = requests.Response()
    assert (True, False) == get_output_options(args, message)


# Generated at 2022-06-23 19:12:17.727239
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'foo'], 'utf-8') == ['foo']
    assert decode_raw_args([b'--form', 'baz'], 'utf-8') == [
        '--form',
        'baz'
    ]
    assert decode_raw_args([b'foo', b'bar', 'baz'], 'ascii') == [
        'foo',
        'bar',
        'baz'
    ]
    assert decode_raw_args([b'foo', b'bar', 'baz'], 'utf-8') == [
        'foo',
        'bar',
        'baz'
    ]

# Generated at 2022-06-23 19:12:29.644552
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = None
    message_req = requests.PreparedRequest()
    message_resp = requests.Response()
    assert get_output_options(args, message_req) == (False, False)
    assert get_output_options(args, message_resp) == (False, False)
    args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(args, message_req) == (True, False)
    assert get_output_options(args, message_resp) == (False, False)
    args.output_options = [OUT_REQ_BODY]
    assert get_output_options(args, message_req) == (False, True)
    assert get_output_options(args, message_resp) == (False, False)

# Generated at 2022-06-23 19:12:41.483941
# Unit test for function main
def test_main():
    class TestEnv:
        test = "test"
        stderr = TestEnv()
        stdout = TestEnv()
        stdin = TestEnv()
        stdin_isatty = False
        stdout_isatty = False
        stdin_encoding = "utf-8"

    class TestArgs:
        test = "test"
        headers = None
        output_options = None
        output_file = None
        output_file_specified = None
        quiet = None
        download = None
        download_resume = None
        check_status = None
        follow = None
        config_dir = None
        request_body_read_callback = None
        default_options = None
        args = None
        http_method = None


# Generated at 2022-06-23 19:12:42.064491
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 19:12:50.909594
# Unit test for function print_debug_info
def test_print_debug_info():
    import sys
    import io
    from .context import Environment
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    version = sys.version_info
    python = f'{version.major}.{version.minor}.{version.micro}'
    assert f'Pygments {pygments_version}\nPython {python}\n' in env.stdout.getvalue()
    env.stderr.close()

# Generated at 2022-06-23 19:12:58.688100
# Unit test for function get_output_options
def test_get_output_options():
    test_arguments = [
        '-f', '-v', '--json',
        'HTTPBIN_URL/get'
    ]
    from httpie.cli.definition import parser
    parsed_args = parser.parse_args(test_arguments)
    test_psr = requests.PreparedRequest()
    test_rs = requests.Response()
    print(get_output_options(parsed_args, test_psr))
    print(get_output_options(parsed_args, test_rs))

if __name__ == '__main__':
    main()
    # test_get_output_options()

# Generated at 2022-06-23 19:13:06.591863
# Unit test for function main
def test_main():
    from tests.constants import UNICODE
    from httpie.cli.constants import DEFAULT_UA
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    import requests

    class RecordingEnvironment(Environment):
        """
        Record the bytes sent to both stdout and stderr.
        """
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.stdout = BytesIO()
            self.stderr = BytesIO()

        def log_error(self, *args, **kwargs):
            return super().log_error(*args, file=self.stderr, **kwargs)

    env = RecordingEnvironment()

# Generated at 2022-06-23 19:13:09.911898
# Unit test for function decode_raw_args
def test_decode_raw_args():
    raw_args = [b'\xe5']
    args = decode_raw_args(raw_args, 'utf-8')
    assert args[0] == 'å'

    raw_args = [u'å', b'\xe5']
    args = decode_raw_args(raw_args, 'utf-8')
    assert args[0] == 'å'
    assert args[1] == 'å'

# Generated at 2022-06-23 19:13:18.507781
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import sys
    env = Environment()

    env.stderr = io.StringIO()
    print_debug_info(env)

    env.stderr.seek(0)
    stderr = env.stderr.read()
    assert f'HTTPie {httpie_version}\n' in stderr
    assert f'Requests {requests_version}\n' in stderr
    assert f'Pygments {pygments_version}\n' in stderr
    assert f'Python {sys.version}\n{sys.executable}\n' in stderr
    assert f'{platform.system()} {platform.release()}' in stderr

# Generated at 2022-06-23 19:13:25.709510
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(["abc"], "utf8") == ["abc"]
    assert decode_raw_args(["abc", "123"], "utf8") == ["abc", "123"]
    assert decode_raw_args([b"abc"], "utf8") == ["abc"]
    assert decode_raw_args([b"abc", b"123"], "utf8") == ["abc", "123"]
    assert decode_raw_args([b"abc", "123"], "utf8") == ["abc", "123"]
    assert decode_raw_args(["abc", b"123"], "utf8") == ["abc", "123"]

# Generated at 2022-06-23 19:13:37.065725
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.program_name = "HTTPie/0.9.6"
    env.stdout_isatty = True
    env.stdin_isatty = True
    env.stderr_isatty = True

    from io import StringIO
    stream = StringIO()
    env.stderr = stream
    print_debug_info(env)
    stream.seek(0)
    debug_info = stream.read()
    stream.close()

    d = {}
    for line in debug_info.split("HTTPie"):
        line = line.strip()
        key, value = line.split(" ")
        d[key] = value

    assert d["Requests"] == "2.22.0"
    assert d["Pygments"] == "2.4.2"

# Generated at 2022-06-23 19:13:41.830286
# Unit test for function main
def test_main():
    assert main(args=['http', '--debug']) == ExitStatus.SUCCESS
    assert main(args=['http', '--headers', '--debug']) == ExitStatus.SUCCESS
    assert main(args=['http', '--headers', '--debug', 'httpbin.org']) == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:13:43.693864
# Unit test for function print_debug_info
def test_print_debug_info():
    f = io.StringIO()
    env = Environment(stdout=f, stderr=f)
    print_debug_info(env)
    output = f.getvalue()
    assert 'HTTPie 0.9.2' in output
    assert 'Requests 2.2' in output


# Generated at 2022-06-23 19:13:50.441107
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[OUT_REQ_HEAD, OUT_RESP_BODY])
    msg = requests.Response()
    (with_headers, with_body) = get_output_options(args, msg)
    assert with_headers is False
    assert with_body is True

    msg = requests.PreparedRequest()
    (with_headers, with_body) = get_output_options(args, msg)
    assert with_headers is True
    assert with_body is False

# Generated at 2022-06-23 19:13:57.628837
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        args=[b'--form', b'key=val\xe2\x9c\x9f'],
        stdin_encoding='utf-8'
    ) == ['--form', 'key=val\u27bf']
    assert decode_raw_args(
        args=[b'key=val\xe2\x9c\x9f'],
        stdin_encoding='ascii'
    ) == ['key=val�']

# Generated at 2022-06-23 19:14:08.667511
# Unit test for function program
def test_program():
    from httpie.cli import parse_item
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.context import Environment
    from httpie.cli.util import get_response_type
    from httpie.plugins.manager import plugin_manager
    plugin_manager.load_installed_plugins()
    env = Environment()
    args = parse_item(
        args=['https://httpbin.org/get', '-b', 'key=val'],
        env=env,
    )
    assert isinstance(args, argparse.Namespace)
    downloader = Downloader(
        output_file=None,
        progress_file=env.stderr,
        resume=False
    )
    assert downloader
    # args.download = True
    # args.follow =

# Generated at 2022-06-23 19:14:10.230254
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'abc', 'def'], 'utf8') == ['abc', 'def']

# Generated at 2022-06-23 19:14:16.270592
# Unit test for function program
def test_program():
    args = ["httpie", "-b", "POST",
            "http://localhost:8080/", "a=b", "c=d"]
    env = Environment()
    env.stdin = open('tests/resources/stdin_test.txt', 'rb')
    env.stdin_isatty = False
    env.stdout = open('tests/tmp/test_program_out.txt', 'wb')
    env.stdout_isatty = True
    env.stderr = open('tests/tmp/test_program_err.txt', 'wb')
    env.stderr_isatty = True
    env.config.directory = 'tests'
    env.config.load()
    exit_status = main(args, env)
    assert exit_status == ExitStatus.SUCCESS
    assert os.stat

# Generated at 2022-06-23 19:14:20.718825
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(
            args=[
                '--debug',
                'http://www.google.com'
            ]
    )
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-23 19:14:30.617105
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser
    parsed_args = parser.parse_args([])
    #Test output options
    options = ['resp.body', 'resp.headers', 'req.body', 'req.headers']
    for option in options:
        parsed_args.output_options.append(option)
    #Test request
    request = requests.PreparedRequest()
    assert get_output_options(args=parsed_args, message=request) == (True, True)
    #Test response
    response = requests.Response()
    assert get_output_options(args=parsed_args, message=response) == (True, True)

# Generated at 2022-06-23 19:14:40.133102
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    captured_output = StringIO()
    env.stderr = captured_output
    print_debug_info(env)
    captured_output.seek(0)
    lines = captured_output.readlines()
    assert re.search(r'HTTPie \d\.\d', lines[0]) is not None
    assert re.search(r'Requests \d\.\d', lines[1]) is not None
    assert re.search(r'Pygments \d\.\d', lines[2]) is not None
    assert re.search(r'Python \d\.\d', lines[3]) is not None
    assert re.search(r'\w+ \d\.\d', lines[5]) is not None

# Generated at 2022-06-23 19:14:41.503061
# Unit test for function program
def test_program():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:14:50.379912
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from httpie.context import Environment
    from httpie.cli import http
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    env = Environment()
    env.stderr = StringIO()
    env.stdout = StringIO()
    args = http.parser.parse_args(args=['--debug'], env=env)

    http.program(args=args, env=env)

    assert 'HTTPie 2.0.0' in env.stderr.getvalue()
    'Requests 2.20.0' in env.stderr.getvalue()
    assert 'Pygments 2.2.0' in env.stderr.getvalue()

# Generated at 2022-06-23 19:15:01.624782
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from httpie.cli.constants import DEFAULT_TIMEOUT
    from httpie.context import Environment

    env: Environment = Environment()
    env.stdin_encoding = 'utf-8'
    original_config: dict = {
        'default_options': ['--form', '--json', '--pretty'],
        'colors': {
            'args': {
                'description': 'Argument names',
                'enabled': True,
            }
        },
        'config_dir': '/home/user/.httpie',
        'max_request_body_size': 1024 * 1024,
        'output_options': ['color'],
        'stream': False,
        'verify': True,
    }
    env.config = Config(**original_config)

# Generated at 2022-06-23 19:15:13.110640
# Unit test for function print_debug_info
def test_print_debug_info():
    class MockStderr(object):
        def __init__(self):
            self.data = []

        def write(self, data):
            self.data.append(data)

        def writelines(self, data):
            self.write(''.join(data))

    env = Environment()
    env.stderr = MockStderr()
    print_debug_info(env)
    assert len(env.stderr.data) == 5
    assert env.stderr.data[0].count('HTTPie ') == 1
    assert env.stderr.data[1].count('Requests ') == 1
    assert env.stderr.data[2].count('Pygments ') == 1
    assert env.stderr.data[3].count('Python ') == 1
    assert env.stder

# Generated at 2022-06-23 19:15:23.682479
# Unit test for function main
def test_main():
    # print(program(['-r', 'https://github.com/jkbrzt/httpie']))
    print(program(['-r', 'session.get', 'http://140.116.244.84', '-a', 'Shawn']))
    print(program(['-r', 'session.get', 'http://140.116.244.84', '-a', 'Jack']))
    print(program(['-r', 'session.get', 'http://140.116.244.84', '-a', 'Jack']))
    # print(main(['-r', 'https://github.com/jkbrzt/httpie'], env=Environment()))


# Generated at 2022-06-23 19:15:25.898851
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['\xe6', 'b\xc3\xa4'], 'utf-8') == ['æ', 'bå']

# Generated at 2022-06-23 19:15:38.018825
# Unit test for function decode_raw_args
def test_decode_raw_args():
    raw_input = ["asd", "asd", "asd", "asd", "asd"]
    assert decode_raw_args(raw_input, "utf-8") == raw_input

    raw_input = ["asd", "asd", "asd", "asd", "asd"]
    assert decode_raw_args(raw_input, "utf-16") == raw_input

    raw_input = ["asd", "asd", b"asd", b"asd", b"asd"]
    try:
        decode_raw_args(raw_input, "utf-16")
    except UnicodeDecodeError:
        assert True

    raw_input = ["asd", b"asd", "asd", b"asd", "asd"]

# Generated at 2022-06-23 19:15:43.253024
# Unit test for function main
def test_main():
    import unittest
    import sys

    class TestMain(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_main(self):
            # TODO: test real functionality
            ret = main()
            self.assertEqual(ret, 0)

    unittest.main()

# Generated at 2022-06-23 19:15:50.683515
# Unit test for function main
def test_main():
    from httpie.client import main
    from httpie.config import get_config_dir
    from httpie import __version__
    import os
    import pytest
    import sys
    from httpie.cli.constants import CONFIG_FILE_NAME
    import os
    import shutil


# Generated at 2022-06-23 19:15:56.621556
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = ['resp.body']

    msg1 = requests.PreparedRequest()
    msg2 = requests.Response()

    print(get_output_options(args, msg1))
    print(get_output_options(args, msg2))


# test_get_output_options()

# Generated at 2022-06-23 19:16:04.221378
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace()

# Generated at 2022-06-23 19:16:10.355601
# Unit test for function program
def test_program():
    http_response = requests.Response()
    http_response.status_code = 200
    http_response.raw = requests.packages.urllib3.response.HTTPResponse()

    message = http_response
    arg_namespace = argparse.Namespace()
    arg_namespace.output_options = [OUT_RESP_BODY]

    program(arg_namespace, message)
    assert message.status_code == 200

# Generated at 2022-06-23 19:16:20.172628
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import unittest
    import unittest.mock


    class PrintDebugInfoTestCase(unittest.TestCase):

        @unittest.mock.patch('sys.stderr', new_callable=io.StringIO)
        def test_print_info(self, stderr):
            print_debug_info(Environment())
            info = stderr.getvalue().splitlines()
            self.assertIn('HTTPie', info[0])
            self.assertEqual(9, len(info))


    unittest.main()


# Generated at 2022-06-23 19:16:31.672087
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(
        program_name='http',
        stdout=BytesIO(),
        stderr=BytesIO(),
        stdin=BytesIO(),
        config=Config(),
        stdin_encoding='utf8',
        stdout_isatty=False,
        stdin_isatty=False,
    )
    print_debug_info(env)
    assert b'HTTPie' in env.stderr.getvalue()
    assert b'Requests' in env.stderr.getvalue()
    assert b'Pygments' in env.stderr.getvalue()
    assert b'Python' in env.stderr.getvalue()
    assert f'{platform.system()} {platform.release()}'.encode('utf8') in env.stderr.getvalue()

# Generated at 2022-06-23 19:16:39.786899
# Unit test for function program
def test_program():

    class TestEnvironment(Environment):
        stdout_isatty = False
        config_dir = '/home/mateo'

    test_env = TestEnvironment()

    class TestArguments:
        follow = True
        output_file = None
        output_file_specified = False
        output_options = [1]
        download = True
        download_resume = True
        headers = [1]
        check_status = True
        quiet = True

    test_args = TestArguments()

    assert program(test_args, test_env) == 1


# Generated at 2022-06-23 19:16:46.655619
# Unit test for function get_output_options
def test_get_output_options():
    # The parsing of command line arguments is done using the argparse module
    # so the output options are saved in a Namespace object
    args = argparse.Namespace()
    args.output_options = ['h', 'all']
    request = requests.PreparedRequest()
    response = requests.Response()
    # Test for different request types
    assert get_output_options(args, request) == (True, False)
    assert get_output_options(args, response) == (True, True)
    args.output_options = ['b', 'all']
    assert get_output_options(args, request) == (False, False)
    assert get_output_options(args, response) == (False, True)

# Generated at 2022-06-23 19:16:48.930182
# Unit test for function main
def test_main():
    try:
        assert main() == ExitStatus.SUCCESS
    except:
        return False
    return True

# Generated at 2022-06-23 19:16:59.630458
# Unit test for function get_output_options
def test_get_output_options():
    class RequestsResponse:
        pass

    class RequestsPreparedRequest:
        pass

    args = argparse.Namespace(output_options=[])

    RequestsResponse.headers = {'Content-Type': 'text/html'}
    RequestsResponse.charset = 'utf8'
    RequestsResponse.status_code = 200

    RequestsPreparedRequest.headers = {'Content-Type': 'text/html'}
    RequestsPreparedRequest.charset = 'utf8'

    # Test that --headers arg correctly set with_headers to True
    args.output_options.append('headers')
    assert get_output_options(args, RequestsResponse()) == (True, False)
    assert get_output_options(args, RequestsPreparedRequest()) == (True, False)

    # Test that --body arg correctly

# Generated at 2022-06-23 19:17:01.474114
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS
    assert main(['http', '--debug']) == ExitStatus.SUCCESS



# Generated at 2022-06-23 19:17:06.130359
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.argtypes import KeyValueArg
    args = argparse.Namespace()
    args.headers = KeyValueArg(None)
    args.output_file = None
    args.output_options = [
        OUT_REQ_HEAD,
        OUT_REQ_BODY,
        OUT_RESP_HEAD,
        OUT_RESP_BODY,
    ]
    messages = collect_messages(args, '.', None)
    for m in messages:
        write_message(m, Environment(), args, True, True)

# Generated at 2022-06-23 19:17:16.485598
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import locale
    # Locale changes which character is used as argument
    # in bytestring (in python3)
    locale.setlocale(locale.LC_ALL, 'C')

    # Python 3 on Linux uses \xff as argument separator
    # Python 2 on Windows uses \xfe as argument separator
    # \xfe\xff is byte order mark
    assert b'\xff' in (b'\xff' + locale.getpreferredencoding(False).encode())
    assert b'\xff' not in (b'\xfe' + locale.getpreferredencoding(False).encode())
    args = [b'\xfe' + locale.getpreferredencoding(False).encode()]


# Generated at 2022-06-23 19:17:18.632694
# Unit test for function program
def test_program():
    program([], Environment())

if __name__ == '__main__':
    program([], Environment())

# Generated at 2022-06-23 19:17:24.386148
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = ['http', '/']
    assert decode_raw_args(args, 'utf-8') == args
    args = [b'http', '/']
    assert decode_raw_args(args, 'utf-8') == ['http', '/']
    args = [b'http', b'/']
    assert decode_raw_args(args, 'utf-8') == ['http', '/']

# Generated at 2022-06-23 19:17:36.948851
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import os
    from httpie.context import Environment
    from tests.helpers import http, httpbin, httpbin_secure

# Generated at 2022-06-23 19:17:41.657783
# Unit test for function print_debug_info
def test_print_debug_info():
    httpie_stderr = io.StringIO()
    httpie_env = Environment(stderr=httpie_stderr)
    print_debug_info(httpie_env)
    httpie_env.stderr.seek(0)
    httpie_stderr_str = httpie_env.stderr.read()
    httpie_info = httpie_stderr_str.splitlines()
    py_version = 'Python ' + sys.version
    httpie_version = r'HTTPie ' + __version__
    httpie_full_info = [httpie_info[0], py_version, httpie_info[-2], httpie_info[-1]]
    assert httpie_version == httpie_info[0]
    assert py_version == httpie_info[1]
   

# Generated at 2022-06-23 19:17:45.032179
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=[b'\xe4\xbd\xa0\xe5\xa5\xbd'],
                           stdin_encoding='utf-8') == ['你好']

# Generated at 2022-06-23 19:17:53.371312
# Unit test for function print_debug_info
def test_print_debug_info():
    class MyStderr:
        def __init__(self):
            self.data = []

        def writelines(self, lines):
            self.data += lines

        def write(self, s):
            self.data.append(s)

        def __repr__(self):
            return '\n'.join(self.data)

    stderr = MyStderr()
    env = Environment()
    env.stderr = stderr
    print_debug_info(env)
    assert 'HTTPie' in repr(stderr)
    assert 'Requests' in repr(stderr)

# Generated at 2022-06-23 19:17:57.058140
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'\xe3\x82\xaf\xe3\x83\xaa\xe3\x83\x83\xe3\x82\xaf'], 'utf-8') == ['クリック']

# Generated at 2022-06-23 19:18:06.809053
# Unit test for function decode_raw_args
def test_decode_raw_args():
    arg_str_str = ['http', 'get', 'http://httpbin.org/get']
    arg_str_bytes = ['http', 'get', b'http://httpbin.org/get']
    arg_bytes_str = [b'http', b'get', 'http://httpbin.org/get']
    arg_bytes_bytes = [b'http', b'get', b'http://httpbin.org/get']

# Generated at 2022-06-23 19:18:18.591332
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from httpie.compat import IS_PYTHON_3

    if not IS_PYTHON_3:
        # noinspection PyUnresolvedReferences
        from future.builtins import str as text_type
        # noinspection PyUnresolvedReferences
        from future.builtins import bytes as binary_type

        assert decode_raw_args(
            args=[b'--form'],
            stdin_encoding='utf8',
        ) == ['--form']

        assert decode_raw_args(
            args=[b'--form', 42],
            stdin_encoding='utf8',
        ) == [binary_type(b'--form'), 42]


# Generated at 2022-06-23 19:18:25.862248
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_RESP_HEAD]
    request_message = requests.PreparedRequest()
    assert get_output_options(args, request_message) == (False, False)
    response_message = requests.Response()
    assert get_output_options(args, response_message) == (True, False)
    args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(args, request_message) == (True, False)
    assert get_output_options(args, response_message) == (False, False)
    args.output_options = [OUT_REQ_BODY]
    assert get_output_options(args, request_message) == (False, True)

# Generated at 2022-06-23 19:18:31.303026
# Unit test for function main
def test_main():
    '''Unit test for function main

    Unit test for function main

    '''
    # noinspection PyProtectedMember
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--output-file=/dev/null', 'https://httpbin.org/get']) == ExitStatus.SUCCESS
    # noinspection PyProtectedMember



# Generated at 2022-06-23 19:18:38.174005
# Unit test for function program
def test_program():
    args = ['httpie', 'get', 'http://localhost:5000/starmap?id=2&id=4', '--html', '--verbose']
    result = program(args, Environment())
    assert result == ExitStatus.SUCCESS
    args = ['httpie', 'get', 'http://localhost:5000/starmap?id=2&id=4', '--json', '--verbose']
    result = program(args, Environment())
    assert result == ExitStatus.SUCCESS
    args = ['httpie', 'get', 'http://localhost:5000/starmap?id=2&id=4', '--pretty=all', '--verbose']
    result = program(args, Environment())
    assert result == ExitStatus.SUCCESS

# Generated at 2022-06-23 19:18:44.204588
# Unit test for function program
def test_program():
    args = ['--check-status', 'GET', 'http://httpbin.org/get']
    args = main(args=args)
    assert args == ExitStatus.SUCCESS
    #TODO: check value
    # args = ['--check-status', 'POST', 'http://httpbin.org/post']
    # args = main(args=args)
    # assert args == ExitStatus.SUCCESS

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 19:18:56.665611
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert [
        'http', '--json', '--form', '--xml', 'http://example.com'
    ] == decode_raw_args([
        'http', '--json', b'--form', '--xml', 'http://example.com'
    ], 'ascii')

    assert [
        'http', '--json', '--form', '--xml', 'http://example.com'
    ] == decode_raw_args([
        b'http', '--json', b'--form', '--xml', 'http://example.com'
    ], 'ascii')

    utf8_args = [
        b'http', '--', r'{"foo": "\u20ac"}'
    ]