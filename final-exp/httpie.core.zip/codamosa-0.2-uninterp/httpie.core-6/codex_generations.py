

# Generated at 2022-06-17 20:13:49.236398
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status

    args = ['--debug']
    env = Environment()
    program_name, *args = args
    env.program_name = os.path.basename(program_name)
    args = decode_raw_args

# Generated at 2022-06-17 20:13:56.775569
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.output.writer import write_stream
    from httpie.output.writer import MESSAGE_SEPARATOR_BYTES
    from httpie.output.writer import write_stream
    from httpie.output.writer import MESSAGE_SEPARATOR_BYTES
    from httpie.output.writer import write_stream
    from httpie.output.writer import MESSAGE_SEPARATOR_BYTES
    from httpie.output.writer import write_stream
   

# Generated at 2022-06-17 20:13:59.845734
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:14:10.282587
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus

    args = parse_args(args=[], env=Environment())
    assert program(args=args, env=Environment()) == ExitStatus.SUCCESS

    args = parse_args(args=['GET'], env=Environment())
    assert program(args=args, env=Environment()) == ExitStatus.ERROR

    args = parse_args(args=['GET', 'httpbin.org'], env=Environment())
    assert program(args=args, env=Environment()) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:14:17.217370
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message
    from httpie.status import ExitStatus
    from httpie.plugins.registry import plugin_manager
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 20:14:28.414476
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect

# Generated at 2022-06-17 20:14:29.736574
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--json', 'http://httpbin.org/get'])
    program(args, Environment())

# Generated at 2022-06-17 20:14:35.091423
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus

    def get_config_dir():
        return DEFAULT_CONFIG_DIR

    def get_config_path():
        return os.path.join(get_config_dir(), 'config.json')

    def get_config():
        return Config(get_config_path())

    def get_plugin_manager():
        return PluginManager()

    def get_env():
        return Environment(
            config=get_config(),
            plugin_manager=get_plugin_manager(),
        )

    def get_args():
        return ['http', 'https://httpbin.org/get']


# Generated at 2022-06-17 20:14:38.094432
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:14:47.385843
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins import plugin_manager
    from httpie.status import ExitStatus
    from httpie.config import Config
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LEN
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_COLOR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_COLOR_LEN
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_NO

# Generated at 2022-06-17 20:15:22.283315
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:15:25.207964
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:15:34.718938
# Unit test for function program
def test_program():
    import argparse
    import os
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status

    plugin_manager.load_installed_plugins()
    args = parser.parse_args(
        args=['--debug'],
        env=Environment()
    )
    exit_status = ExitStatus.SUCCESS
    downloader = None
    initial_request: Optional[requests.PreparedRequest] = None
    final_response: Optional[requests.Response] = None

   

# Generated at 2022-06-17 20:15:36.910732
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    main(args)

# Generated at 2022-06-17 20:15:45.010326
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--debug', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--debug', '--debug', '--debug']) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:15:59.115403
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'http://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)

# Generated at 2022-06-17 20:16:05.209000
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.3"\n  }, \n  "origin": "118.69.197.152", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''

# Generated at 2022-06-17 20:16:14.720919
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO

    env = Environment(stdout=StdoutBytesIO(), stderr=StdoutBytesIO())
    args = parser.parse_args(args=['--debug'], env=env)
    assert main(args=['--debug'], env=env) == ExitStatus.SUCCESS
    assert main(args=['--debug', '--traceback'], env=env) == ExitStatus.SUCCESS
    assert main(args=['--debug', '--traceback', '--output=json'], env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:16:21.377795
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.utils import get_response_stream
    from httpie.utils import get_response_text
    from httpie.utils import is_json
    from httpie.utils import is_text
    from httpie.utils import is_xml
    from httpie.utils import parse_json
    from httpie.utils import parse_xml

# Generated at 2022-06-17 20:16:30.747325
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.status import ExitStatus
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyAuthSession
    from httpie.plugins.builtin import HTTPAuthSession
    from httpie.plugins.builtin import HTTPBearerTokenAuthSession

# Generated at 2022-06-17 20:17:07.812974
# Unit test for function program
def test_program():
    import io
    import sys
    import unittest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info

    class TestProgram(unittest.TestCase):
        def setUp(self):
            self.env = Environment()
            self.env.stdin = io.BytesIO()
            self.env.stdout = io.BytesIO()
            self.env.stderr = io.BytesIO()
            self.env.stdout_isatty = False
            self.env.stderr_isatty = False

# Generated at 2022-06-17 20:17:16.294795
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    import requests
    import sys
    import os
    import platform
    import argparse
    import typing
    import pygments
    import httpie
    import requests


# Generated at 2022-06-17 20:17:21.151725
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'http://httpbin.org/get'])
    env = Environment()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:17:25.271051
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(
        args=['--debug', '--traceback', '--download', '--output-file', 'test.txt', 'http://httpbin.org/get'],
        env=Environment()
    )
    program(args=args, env=Environment())

# Generated at 2022-06-17 20:17:35.528169
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.cli.constants import OUT_REQ_BODY, OUT_RE

# Generated at 2022-06-17 20:17:43.871618
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTP

# Generated at 2022-06-17 20:17:50.265515
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.compat import is_windows
    from httpie.compat import is_py26
    from httpie.compat import is_py27
    from httpie.compat import is_py34
    from httpie.compat import is_py35


# Generated at 2022-06-17 20:18:00.978016
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:18:09.774919
# Unit test for function main
def test_main():
    import io
    import sys
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins import plugin_manager
    from httpie.config import Config
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.cli.definition import parser
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.utils import get_response_writer
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_

# Generated at 2022-06-17 20:18:18.754536
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.downloads import Downloader
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.client import collect_messages
    from httpie.context import Environment
    from httpie.status import ExitStatus, http_status_to_exit_status

# Generated at 2022-06-17 20:19:08.007976
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['http', 'httpbin.org'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:19:12.463590
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)
    assert env.stderr.getvalue() == '\n'
    assert env.stdout.getvalue() == '\n'


# Generated at 2022-06-17 20:19:20.054171
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.3"\n  }, \n  "origin": "47.100.247.80", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''


# Generated at 2022-06-17 20:19:25.895230
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins.manager import PluginManager
    from httpie.output.streams import StdoutBytesIO, StderrBytesIO
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTP

# Generated at 2022-06-17 20:19:35.649467
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info

    plugin_manager.clear()
    plugin_manager.register(HTTPBasicAuth)
    plugin_manager.load_installed_plugins()
    env = Environment(config_dir=DEFAULT_CONFIG_DIR)

# Generated at 2022-06-17 20:19:46.271473
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_config_dir
    from httpie.config import Config
    from httpie.plugins import AuthPlugin, FormatterPlugin, TransportPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_config_dir
    from httpie.config import Config

# Generated at 2022-06-17 20:19:59.383977
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    import sys
    import os
    import tempfile
    import shutil
    import io
    import requests
    import pytest
    import httpie

    def get_args(args):
        return parser.parse_args(args=args, env=Environment())

    def get_response_with_body(body):
        response = get_response()
        response.raw = io.BytesIO(body)
        response.raw.seek(0)
        response.raw.read = lambda size: response.raw.read(size)
        return response


# Generated at 2022-06-17 20:20:06.598944
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message
    from httpie.status import http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.plugins.registry import plugin_manager
    import requests
    import os
    import sys
    import platform
    import argparse
    from typing import List, Optional, Tuple, Union
    from pygments import __version__ as pygments_version
    from requests import __version__ as requests_version
    from httpie import __version__ as httpie_

# Generated at 2022-06-17 20:20:10.844539
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    exit_status = program(args=args, env=Environment())
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:20:13.151143
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS