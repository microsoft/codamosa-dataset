

# Generated at 2022-06-17 20:13:50.895423
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus

    plugin_manager.load_installed_plugins()
    env = Environment()
    env.config = Config(directory=DEFAULT_CONFIG_DIR)
    env.stdin_encoding = 'utf8'
    assert main(args=['http', '--debug'], env=env) == ExitStatus.SUCCESS
    assert main(args=['http', '--traceback'], env=env) == ExitStatus.ERROR
    assert main(args=['http', '--traceback', '--debug'], env=env) == ExitStatus.ERROR

# Generated at 2022-06-17 20:13:58.168025
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES

# Generated at 2022-06-17 20:14:06.671797
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--timeout=1', 'https://httpbin.org/delay/2']) == ExitStatus.ERROR_TIMEOUT
    assert main(['http', '--debug', '--traceback', '--max-redirects=0', 'https://httpbin.org/redirect/1']) == ExitStatus.ERROR_TOO_MANY_REDIRECTS
    assert main(['http', '--debug', '--traceback', '--timeout=1', 'https://httpbin.org/delay/2']) == ExitStatus.ERROR_TIMEOUT

# Generated at 2022-06-17 20:14:15.228880
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    import sys
    import unittest
    class TestMain(unittest.TestCase):
        def setUp(self):
            self.env = Environment()
            self.env.stdout = StdoutBytesIO()
            self.env.stderr = StdoutBytesIO()
            self.env.stdin = StdoutBytesIO()
            self.env.stdin_isatty = False
            self.env.stdout_isatty = False
            self.env.stderr_isatty = False
            self.env.config.directory = './'
            self.env.config.default_options = []

# Generated at 2022-06-17 20:14:18.804530
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:14:20.622918
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'http://httpbin.org/get'])
    assert program(args=args, env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:14:31.359310
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    import os
    import sys
    import tempfile
    import unittest
    import urllib.parse
    from unittest.mock import patch
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    class TestEnvironment(Environment):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

# Generated at 2022-06-17 20:14:36.845059
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:14:46.478983
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.constants import DEFAULT_OPTIONS
    from httpie.cli.definition import parser
    from httpie.output.writer import write_message
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.context import Environment
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.output.writer import write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.context import Environment
    from httpie.client import collect_messages
    from httpie.downloads import Downloader

# Generated at 2022-06-17 20:14:59.570765
# Unit test for function program
def test_program():
    import io
    import sys
    from httpie.cli.definition import parser
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus

    args = parser.parse_args(['--debug', '--follow', '--check-status', '--download', 'http://httpbin.org/get'])
    env = Environment()
    env.stdout = io.BytesIO()
    env.stderr = io.BytesIO()
    env.stdin = io.BytesIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.config.default_options = []
    env.config.directory = ''
    env.config.config_dir = ''

# Generated at 2022-06-17 20:16:06.245145
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH_COLOR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_COLOR
    from httpie.output.streams import BINARY_SUP

# Generated at 2022-06-17 20:16:15.537529
# Unit test for function main
def test_main():
    import pytest
    from httpie import ExitStatus
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_registry
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type

# Generated at 2022-06-17 20:16:17.307904
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:16:19.017813
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:16:29.983283
# Unit test for function main
def test_main():
    assert main(['httpie', '--debug']) == ExitStatus.SUCCESS
    assert main(['httpie', '--traceback']) == ExitStatus.ERROR
    assert main(['httpie', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['httpie', '--debug', '--traceback', '--timeout=1']) == ExitStatus.ERROR_TIMEOUT
    assert main(['httpie', '--debug', '--traceback', '--max-redirects=0']) == ExitStatus.ERROR_TOO_MANY_REDIRECTS
    assert main(['httpie', '--debug', '--traceback', '--check-status']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:16:33.586924
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:16:42.797450
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus

    args = parser.parse_args(args=['--debug', '--form', 'key=val', '--auth=user:pass', 'httpbin.org/post'])
    env = Environment()
    env.stdout = io.BytesIO()
    env.stderr = io.BytesIO()
    env.config.directory = os.path.join(os.path.dirname(__file__), '..', 'httpie')
    env.config.config_dir = os.path

# Generated at 2022-06-17 20:16:51.521838
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_config_dir
    from httpie.config import Config
    from httpie.output.streams import Streams
    from httpie.output.writer import write_message
    from httpie.output.formatters.colors import NO_COLOR_PALETTE
    from httpie.output.formatters.format import DEFAULT_FORMAT_OPTIONS
    from httpie.output.formatters.utils import get_preferred_json_indent
    from httpie.output.formatters.utils import get_preferred_json_sort_keys

# Generated at 2022-06-17 20:17:03.541030
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_SEPARATOR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_SEPARATOR_LENGTH
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_SEPAR

# Generated at 2022-06-17 20:17:13.916996
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus

    env = Environment()
    env.stdout = StdoutBytesIO()
    env.stderr = StdoutBytesIO()

    # Test for success
    args = parser.parse_args(args=['https://httpbin.org/get'], env=env)
    assert main(args=['http', 'https://httpbin.org/get'], env=env) == ExitStatus.SUCCESS
    assert main(args=['http', '--debug', 'https://httpbin.org/get'], env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:18:06.005486
# Unit test for function program
def test_program():
    import argparse
    import io
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager
    from httpie.status import ExitStatus

    env = Environment()
    env.stdout = io.BytesIO()
    env.stderr = io.BytesIO()
    env.stdin = io.BytesIO(b'{"hello": "world"}')
    env.config.default_options = ['--json']
    env.config.output_options = ['--pretty=all']
    env.config.colors = False

# Generated at 2022-06-17 20:18:12.318616
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.plugins.registry import plugin_manager
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:18:14.756741
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:18:22.001363
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyAuthSession
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPPassAuthSession

# Generated at 2022-06-17 20:18:30.597630
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--help']) == ExitStatus.SUCCESS
    assert main(['http', '--version']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug', '--help']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback', '--debug', '--version']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback', '--debug', '--help', '--version']) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:18:40.334362
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdout_isatty = sys.stdout.isatty()
    env.stderr_isatty = sys.stderr.isatty()
    env.config = None
    env.config_dir = None
    env.colors = None
    env.default_options = None
    env.default_options_specified = None
    env.output_options = None
    env.output_options_

# Generated at 2022-06-17 20:18:51.261003
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import ParseResult
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info

    def get_args(args: List[str]) -> ParseResult:
        return parser.parse_args(args=args, env=Environment())

    def get_exit_status(args: List[str]) -> ExitStatus:
        return main(args=args, env=Environment(stdout=StdoutBytesIO()))

    def get_stdout(args: List[str]) -> bytes:
        env = Environment(stdout=StdoutBytesIO())
        main(args=args, env=env)
       

# Generated at 2022-06-17 20:18:57.354155
# Unit test for function program
def test_program():
    import sys
    import io
    import argparse
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status

    plugin_manager.load_installed_plugins()
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin = io.StringIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False

# Generated at 2022-06-17 20:19:05.529777
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-17 20:19:14.788408
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.cli.utils import get_response_writer
    from httpie.output.streams import get_output_stream
    from httpie.output.writers import get_response_writer
    from httpie.status import ExitStatus
    from httpie.utils import get_response_body_stream
    from httpie.utils import get_response_body_stream
    from httpie.utils import get_response_body_stream
    from httpie.utils import get_response_body_stream
    from httpie.utils import get_response_body_stream
    from httpie.utils import get_response_body_stream
    from httpie.utils import get_response_body_stream
    from httpie.utils import get_response_body_stream