

# Generated at 2022-06-17 20:13:21.032929
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:13:23.650029
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:13:34.131595
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    import os
    import sys
    import tempfile
    import requests
    import pytest
    from pytest import raises
    from requests.exceptions import ConnectionError
    from requests.exceptions import HTTPError
    from requests.exceptions import ReadTimeout
    from requests.exceptions import TooManyRedirects

# Generated at 2022-06-17 20:13:46.002037
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO


# Generated at 2022-06-17 20:13:52.293494
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)

# Generated at 2022-06-17 20:13:54.781019
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:14:03.001229
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus

    env = Environment()
    env.stdout = io.BytesIO()
    env.stderr = io.BytesIO()
    env.stdin = io.BytesIO(b'{"a": "b"}')
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.config.default_options = ['--json']
    env.config.output_options = ['all']
    env.config.colors = False
    env.config.style = None
    env.config.download_res

# Generated at 2022-06-17 20:14:12.318456
# Unit test for function program
def test_program():
    class TestEnv:
        def __init__(self):
            self.stdout = sys.stdout
            self.stderr = sys.stderr
            self.stdout_isatty = sys.stdout.isatty()
            self.stderr_isatty = sys.stderr.isatty()
            self.stdin_encoding = sys.stdin.encoding
            self.stdin = sys.stdin
            self.stdin_isatty = sys.stdin.isatty()
            self.stdout_isatty = sys.stdout.isatty()
            self.stderr_isatty = sys.stderr.isatty()
            self.stdin_encoding = sys.stdin.encoding
            self.stdin = sys.stdin

# Generated at 2022-06-17 20:14:23.863115
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-17 20:14:33.135803
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message

    plugin_manager.load_installed_plugins()

    args = parser.parse_args(args=['--debug', '--form', 'foo=bar', '--auth-type=basic', '--auth=user:password', 'https://httpbin.org/post'], env=Environment())
    assert program(args=args, env=Environment()) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:15:13.997770
# Unit test for function program
def test_program():
    assert program(args=['--debug'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--traceback'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--traceback', '--debug'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--debug', '--traceback'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--debug', '--traceback', '--debug'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--debug', '--debug', '--traceback', '--debug'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:15:24.485758
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH_NO_COLOR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_NO_COLOR
    from httpie.output.streams import is_binary_response

# Generated at 2022-06-17 20:15:34.376000
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type

    plugin_manager.register(HTTPBasicAuth)
    env = Environment(
        config_dir=DEFAULT_CONFIG_DIR,
        stdin_isatty=True,
        stdout_isatty=True,
        stdin=None,
        stdout=None,
        stderr=None,
    )
    args = ['--debug']
    exit_status = main(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:15:37.330132
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:15:45.221906
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.plugins.registry import plugin_manager
    plugin_manager.load_installed_plugins()
    env = Environment()
    env.stdout = StdoutBytesIO()
    args = parser.parse_args(['--download', 'https://www.google.com'], env=env)
    downloader = Downloader(output_file=args.output_file, progress_file=env.stderr, resume=args.download_resume)
    downloader.pre_request(args.headers)

# Generated at 2022-06-17 20:15:59.145548
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.downloads import Downloader
    from httpie.cli.definition import parser
    from httpie.client import collect_messages
    from httpie.config import Config
    from httpie.plugins.builtin import HTTPBasicAuth
   

# Generated at 2022-06-17 20:16:10.165645
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import ParseResult
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPieHelp
    from httpie.plugins.builtin import HTTPieHTTP2
    from httpie.plugins.builtin import HTTPiePrettyOptions
    from httpie.plugins.builtin import HTTPieSession
    from httpie.plugins.builtin import HTTPieSSL
    from httpie.plugins.builtin import HTTPieStream

# Generated at 2022-06-17 20:16:17.837319
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', '--traceback'])
    assert main(args=args) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', '--traceback', '--output=json'])
    assert main(args=args) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', '--traceback', '--output=json', '--timeout=1'])
    assert main(args=args) == ExitStatus.ERROR_TIMEOUT

# Generated at 2022-06-17 20:16:23.507105
# Unit test for function program
def test_program():
    import argparse
    import os
    import sys
    from httpie.cli.definition import parser
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status

    env = Environment()
    env.program_name = os.path.basename(sys.argv[0])
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 20:16:31.885992
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type

    plugin_manager.load_installed_plugins()
    env = Environment()
    args = parse_args(args=['--debug'], env=env, parser=parser)
    assert main(args=['--debug'], env=env) == ExitStatus.SUCCESS
    args = parse_args(args=['--traceback'], env=env, parser=parser)
    assert main(args=['--traceback'], env=env) == ExitStatus.ERROR

# Generated at 2022-06-17 20:18:42.171280
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.plugins.registry import plugin_manager
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.status import ExitStatus, http_status_to_exit

# Generated at 2022-06-17 20:18:46.010778
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert program(args, Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:18:51.002725
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:19:01.218870
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTP

# Generated at 2022-06-17 20:19:12.463802
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES

# Generated at 2022-06-17 20:19:14.197954
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:19:21.442181
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:19:24.855218
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpie.org'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:19:34.750837
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    import io
    import sys
    import os
    import platform
    import requests
    import pygments
    import tempfile
    import unittest
    import unittest.mock
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import warnings
    import httpie
    import httpie.cli
    import httpie.cli.constants
    import httpie.cli.definition

# Generated at 2022-06-17 20:19:45.862870
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import JSONCompactFormatter
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONLinesFormatter
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import SyntaxPlugin

# Generated at 2022-06-17 20:20:41.862881
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', '--download', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:20:49.377075
# Unit test for function program

# Generated at 2022-06-17 20:20:59.675332
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import ParseResult
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.downloads import Downloader
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.streams import StdoutBytesIO

# Generated at 2022-06-17 20:21:06.915367
# Unit test for function program

# Generated at 2022-06-17 20:21:18.054217
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_detail
    from httpie.config import Config
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:21:29.867550
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus

    env = Environment(stdout=StdoutBytesIO(), stderr=StdoutBytesIO())
    args = parser.parse_args(['--debug'], env=env)
    assert program(args=args, env=env) == ExitStatus.SUCCESS

    args = parser.parse_args(['--traceback'], env=env)
    assert program(args=args, env=env) == ExitStatus.SUCCESS

    args = parser.parse_args(['--debug', '--traceback'], env=env)
    assert program(args=args, env=env) == ExitStatus.SUCCESS



# Generated at 2022-06-17 20:21:36.532193
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info

    env = Environment(
        config=Config(directory=DEFAULT_CONFIG_DIR),
        stdin=None,
        stdin_isatty=False,
        stdout=None,
        stdout_isatty=False,
        stderr=None,
        stderr_isatty=False,
        stdout_bytes_written=0,
    )
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 20:21:39.913403
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    main(args=args)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-17 20:21:42.937078
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:21:53.219769
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.2"\n  }, \n  "origin": "1.2.3.4", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''
