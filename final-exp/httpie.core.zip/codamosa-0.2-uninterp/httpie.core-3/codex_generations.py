

# Generated at 2022-06-17 20:13:26.766015
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get

# Generated at 2022-06-17 20:13:29.638154
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:13:36.864436
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response

    env = Environment()
    env.stdout = StdoutBytesIO()
    env.stderr = StdoutBytesIO()
    env.config.directory = '.'
    args = parser.parse_args(args=['https://httpbin.org/get'], env=env)
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS
    assert env.stdout.getvalue() == get_response('get')

# Generated at 2022-06-17 20:13:47.437541
# Unit test for function program
def test_program():
    import argparse
    import os
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status

    # noinspection PyDefaultArgument
    def main(args: List[Union[str, bytes]] = sys.argv, env=Environment()) -> ExitStatus:
        """
        The main function.

        Pre-process args, handle some special types of invocations,
        and run the main program with error handling.

        Return exit status code.

        """
        program_name, *args

# Generated at 2022-06-17 20:13:55.216746
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.plugins.registry import plugin_manager
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.client import collect_messages
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT

# Generated at 2022-06-17 20:14:01.331587
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
   

# Generated at 2022-06-17 20:14:08.815597
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.status import ExitStatus
    from httpie.utils import get_response_headers
    from httpie.compat import urlopen
    from httpie.downloads import Downloader
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.status import ExitStatus
    from httpie.utils import get_response_headers
    from httpie.compat import urlopen
    from httpie.downloads import Downloader
    from httpie.output.streams import StdoutBytesIO

# Generated at 2022-06-17 20:14:16.479663
# Unit test for function program

# Generated at 2022-06-17 20:14:18.846850
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:14:21.985260
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:15:04.907757
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins.registry import plugin_registry
    from httpie.plugins.registry import PluginRegistry
    from httpie.plugins import AuthPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import TransportPlugin
    from httpie.plugins import ViewPlugin
    from httpie.plugins import __version__ as httpie_plugins_version
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.utils import is_windows
    from httpie.utils import isatty
    from httpie.utils import is_json
   

# Generated at 2022-06-17 20:15:16.285690
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.config import Config
    from httpie.plugins import builtin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials
    from httpie.plugins.builtin import AuthCredentialsIniFile
    from httpie.plugins.builtin import AuthCredentialsIniFile

# Generated at 2022-06-17 20:15:26.057068
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import ParseResult
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:15:29.104144
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:15:39.248573
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:15:44.445767
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)

# Generated at 2022-06-17 20:15:52.085668
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus

    env = Environment()
    env.stdout = StdoutBytesIO()
    env.stderr = StdoutBytesIO()

    args = parser.parse_args(['--debug'], env=env)
    assert program(args, env) == ExitStatus.SUCCESS
    assert env.stdout.getvalue() == b''
    assert env.stderr.getvalue() != b''

    env.stdout = StdoutBytesIO()
    env.stderr = StdoutBytesIO()

    args = parser.parse_args(['--traceback'], env=env)

# Generated at 2022-06-17 20:16:00.252647
# Unit test for function main
def test_main():
    import io
    import sys
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus

    plugin_manager.register(HTTPBasicAuth)

    env = Environment(
        stdin=io.BytesIO(),
        stdin_isatty=False,
        stdout=io.BytesIO(),
        stdout_isatty=False,
        stderr=io.BytesIO(),
        stderr_isatty=False,
        config_dir=DEFAULT_CONFIG_DIR,
        config_path=None,
    )


# Generated at 2022-06-17 20:16:11.525860
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.context import Environment
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status

# Generated at 2022-06-17 20:16:13.694532
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:17:42.011731
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:17:49.298253
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager

# Generated at 2022-06-17 20:17:54.850561
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.status import ExitStatus
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins.registry import plugin_registry
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins.registry import plugin_registry
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins.registry import plugin_registry
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins.registry import plugin

# Generated at 2022-06-17 20:18:05.433402
# Unit test for function program
def test_program():
    assert program(args=['--debug'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--traceback'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--traceback', '--debug'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--debug', '--traceback'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--debug', '--debug'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--traceback', '--traceback'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--debug', '--traceback', '--debug'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:18:12.026412
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO, StderrBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.downloads import Downloader
    import os
    import sys
    import requests
    import io
    import tempfile
    import shutil

    def get_args(args: List[str]) -> argparse.Namespace:
        return parser.parse_args(
            args=args,
            env=Environment(),
        )

    def get_output(args: List[str]) -> Tuple[ExitStatus, bytes, bytes]:
        env = Environment()
        env.stdout = StdoutBytesIO()

# Generated at 2022-06-17 20:18:14.838108
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:18:17.445670
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:18:23.876098
# Unit test for function program
def test_program():
    import requests
    from httpie.cli.parser import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.cli.definition import parser
    from httpie.client import collect_messages

# Generated at 2022-06-17 20:18:31.347051
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type_raw
    from httpie.utils import get_response_type_raw_stream
    from httpie.utils import get_response_type_stream
    from httpie.utils import get_response_type_stream_raw
    from httpie.utils import get_response_type_stream_raw_stream
    from httpie.utils import get_response_type_stream_stream
    from httpie.utils import get_response_type_stream

# Generated at 2022-06-17 20:18:35.527033
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:19:37.670865
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

if __name__ == '__main__':
    test_program()

# Generated at 2022-06-17 20:19:41.482017
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

if __name__ == '__main__':
    test_program()

# Generated at 2022-06-17 20:19:49.424492
# Unit test for function program

# Generated at 2022-06-17 20:20:00.421793
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.manager import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_config_dir
    from httpie.config import Config
    from httpie.plugins import builtin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPPassAuth

# Generated at 2022-06-17 20:20:03.530657
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    env = Environment()
    args = parser.parse_args(args=['http://httpbin.org/get'], env=env)
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 20:20:05.423110
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:20:15.787056
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.config import Config
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPGSSAPIAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth


# Generated at 2022-06-17 20:20:24.826054
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message

    env = Environment()
    plugin_manager.load_installed_plugins()
    args = parser.parse_args(args=['--debug', 'https://httpbin.org/get'], env=env)
    assert program(args=args, env=env) == ExitStatus.SUCCESS

    args = parser.parse_args(args=['--debug', 'https://httpbin.org/status/404'], env=env)

# Generated at 2022-06-17 20:20:35.778495
# Unit test for function program
def test_program():
    import argparse
    import io
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES

# Generated at 2022-06-17 20:20:44.881758
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--debug', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--debug', '--debug', '--debug']) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:21:57.605354
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:22:02.001991
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:22:12.358205
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.output.writer import write_message
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.downloads import Downloader
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import FormAuth
    from httpie.plugins.builtin import Auth

# Generated at 2022-06-17 20:22:24.198899
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.downloads import Downloader


# Generated at 2022-06-17 20:22:29.344571
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    env = Environment()
    args = parser.parse_args(args=['https://httpbin.org/get'], env=env)
    assert program(args=args, env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:38.730007
# Unit test for function program
def test_program():
    assert program(args=['--debug'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--traceback'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--debug', '--traceback'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--debug', '--traceback', '--help'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--debug', '--traceback', '--help', '--debug'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--debug', '--traceback', '--help', '--debug', '--traceback'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:48.170923
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser