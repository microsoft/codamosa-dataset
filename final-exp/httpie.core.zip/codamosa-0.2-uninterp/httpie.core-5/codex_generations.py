

# Generated at 2022-06-17 20:13:46.375413
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    import os
    import shutil
    import tempfile
    import unittest

    class MainTest(unittest.TestCase):

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.config_dir = os.path.join(self.temp_dir, DEFAULT_CONFIG_DIR)
            os.makedirs(self.config_dir)
            self

# Generated at 2022-06-17 20:13:52.532190
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyBasicAuth
    from httpie.plugins.builtin import HTTPProxyDigestAuth
    from httpie.plugins.builtin import HTTPProxyBearerTokenAuth

# Generated at 2022-06-17 20:13:59.544785
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-17 20:14:07.587761
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect

# Generated at 2022-06-17 20:14:15.784336
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus

    env = Environment()
    args = parser.parse_args(args=['--debug'], env=env)
    assert program(args=args, env=env) == ExitStatus.SUCCESS

    args = parser.parse_args(args=['--traceback'], env=env)
    with pytest.raises(SystemExit):
        program(args=args, env=env)

    args = parser.parse_args(args=['--traceback', '--debug'], env=env)
    with pytest.raises(SystemExit):
        program(args=args, env=env)



# Generated at 2022-06-17 20:14:18.548201
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['http', 'https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)

# Generated at 2022-06-17 20:14:23.515983
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert program(args, Environment()) == ExitStatus.SUCCESS
    args = parser.parse_args(['--traceback'])
    assert program(args, Environment()) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', '--traceback'])
    assert program(args, Environment()) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    assert program(args, Environment()) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get', '--timeout', '0.1'])

# Generated at 2022-06-17 20:14:32.830063
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import httpie.cli.constants as C
    import httpie.cli.parser as parser
    import httpie.cli.definition as definition
    import httpie.cli.argtypes as argtypes
    import httpie.cli.utils as utils
    import httpie.cli.output as output
    import httpie.cli.downloads as downloads
    import httpie.cli.context as context
    import httpie.cli.program as program
    import httpie.cli.main as main
    import httpie.cli.downloads as downloads
    import httpie.cli.output as output
    import httpie.cli.context as context
    import httpie.cli.program as program
    import httpie.cli.main as main

# Generated at 2022-06-17 20:14:38.236916
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_config_dir
    from httpie.config import Config
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxy
    from httpie.plugins.builtin import HTTPiePlugin

# Generated at 2022-06-17 20:14:41.712513
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'http://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:15:10.794171
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:15:17.192117
# Unit test for function main
def test_main():
    import io
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from tests.test_client import MockResponse

    env = Environment()
    env.stdin = io.BytesIO()
    env.stdin_isatty = False
    env.stdout = io.BytesIO()
    env.stdout_isatty = False
    env.stderr = io.BytesIO()
    env.stderr_isatty = False
    env.config.default_options = ['--form']
    env.config.output_options = ['--pretty=all']
    env.config

# Generated at 2022-06-17 20:15:27.138434
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.utils import get_response_type
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type

# Generated at 2022-06-17 20:15:30.211938
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:15:32.970056
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['http', '--debug', 'http://httpbin.org/get'])
    program(args=args, env=Environment())

# Generated at 2022-06-17 20:15:42.895007
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins import AuthPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus

# Generated at 2022-06-17 20:15:51.499722
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.downloads import Downloader
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.streams import StderrBytesIO
    from httpie.output.streams import StdinBytesIO
    from httpie.output.streams import StdoutTextIOWrapper
    from httpie.output.streams import StderrTextIOWrapper
    from httpie.output.streams import StdinTextIOWrapper

# Generated at 2022-06-17 20:16:00.029487
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_registry
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH_COLOR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_COLOR

# Generated at 2022-06-17 20:16:11.211614
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_SEPARATOR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_SEPARATOR_LENGTH
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_SEPARATOR_BYTES

# Generated at 2022-06-17 20:16:18.542342
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info
    from httpie.downloads import Downloader

    plugin_manager.load_installed_plugins()


# Generated at 2022-06-17 20:17:42.569679
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS
    args = parser.parse_args(['--traceback'])
    assert main(args=args) == ExitStatus.ERROR
    args = parser.parse_args(['--traceback', '--debug'])
    assert main(args=args) == ExitStatus.ERROR
    args = parser.parse_args(['--debug', '--traceback'])
    assert main(args=args) == ExitStatus.ERROR
    args = parser.parse_args(['--debug', '--traceback', '--debug'])
    assert main(args=args) == ExitStatus.ERROR

# Generated at 2022-06-17 20:17:49.309040
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdout_isatty = sys.stdout.isatty()
    env.stderr_isatty = sys.stderr.isatty()
    env.config.directory = os.path.expanduser('~/.config/httpie')
    env.config.load()
    env.config.default_options = []
    env.config.default_options_specified = False

# Generated at 2022-06-17 20:17:59.512591
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    plugin_manager.register(HTTPBasicAuth)
    env = Environment(stdout=StdoutBytesIO(), stderr=StdoutBytesIO())
    args = parser.parse_args(args=['--debug'], env=env)
    assert main(args=['--debug'], env=env) == ExitStatus.SUCCESS
    args = parser.parse_args(args=['--traceback'], env=env)

# Generated at 2022-06-17 20:18:06.657066
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.cli.constants import OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY
    args = parser.parse_args(['--output-options', OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY, 'http://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:18:17.560634
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins import plugin_manager
    plugin_manager.register(HTTPBasicAuth)
    env = Environment(stdout=StdoutBytesIO(), stderr=StdoutBytesIO())
    args = parser.parse_args(args=['--debug', '--auth=user:password', '--verify=no', '--json', 'GET', 'http://httpbin.org/get'], env=env)
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCC

# Generated at 2022-06-17 20:18:23.974353
# Unit test for function main
def test_main():
    import io
    import sys
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus

    plugin_manager.clear()
    plugin_manager.load_installed_plugins()
    plugin_manager.register(HTTPBasicAuth)


# Generated at 2022-06-17 20:18:35.355622
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth

# Generated at 2022-06-17 20:18:42.669705
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.utils import get_response_stream
    from httpie.utils import get_response_text
    from httpie.utils import is_windows
    from httpie.utils import is_json
    from httpie.utils import is_pretty
    from httpie.utils import is_text
    from httpie.utils import is_verbose
    from httpie.utils import is_stream
    from httpie.utils import is_download

# Generated at 2022-06-17 20:18:52.562062
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins import plugin_manager
    plugin_manager.register(HTTPBasicAuth)
    env = Environment(stdout=StdoutBytesIO(), stderr=StdoutBytesIO())
    args = parser.parse_args(args=['--auth-type=basic', '--auth=user:password', 'https://httpbin.org/basic-auth/user/password'], env=env)
    assert program(args=args, env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:19:03.383257
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.downloads import Downloader

# Generated at 2022-06-17 20:20:02.252365
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader

# Generated at 2022-06-17 20:20:13.447088
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--traceback', '--traceback'])

# Generated at 2022-06-17 20:20:23.119222
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import ParseResult
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.utils import get_response_type
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.client import collect_messages
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE


# Generated at 2022-06-17 20:20:34.503381
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type

    plugin_manager.load_installed_plugins()

    # Test with a simple request
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment(stdout=StdoutBytesIO(), stderr=StdoutBytesIO())
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:20:36.952968
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:20:45.915947
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import Exit

# Generated at 2022-06-17 20:20:52.657496
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'http://httpbin.org/get'])
    env = Environment()
    program(args, env)

if __name__ == '__main__':
    test_program()

# Generated at 2022-06-17 20:21:00.946269
# Unit test for function program
def test_program():
    import argparse
    import os
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.config import Config
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTT

# Generated at 2022-06-17 20:21:06.969743
# Unit test for function main

# Generated at 2022-06-17 20:21:11.304918
# Unit test for function program
def test_program():
    assert program(args=['GET', 'http://httpbin.org/get'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['GET', 'http://httpbin.org/status/404'], env=Environment()) == ExitStatus.ERROR_HTTP_4XX
    assert program(args=['GET', 'http://httpbin.org/status/500'], env=Environment()) == ExitStatus.ERROR_HTTP_5XX
    assert program(args=['GET', 'http://httpbin.org/status/600'], env=Environment()) == ExitStatus.ERROR_HTTP_OTHER
    assert program(args=['GET', 'http://httpbin.org/status/200'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:17.313439
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.output_options = []
    args.download = False
    args.output_file = None
    args.output_file_specified = False
    args.headers = []
    args.check_status = False
    args.follow = False
    args.quiet = False
    args.download_resume = False
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdout_isatty = sys.stdout.isatty()
    env.stderr_isatty = sys.stderr.isatty()
    env.config = None

# Generated at 2022-06-17 20:22:20.841440
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', '--help'])
    assert main(args=args) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:24.482141
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stderr.getvalue() == '\n'

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 20:22:31.006778
# Unit test for function program
def test_program():
    import io
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message
    from httpie.status import ExitStatus
    from httpie.utils import get_response_as_json
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyAuthSession
   

# Generated at 2022-06-17 20:22:37.547495
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    args = parser.parse_args(['--debug', '--output-options', OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD, 'https://httpbin.org/get'])
    assert main(args=args) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:41.270265
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)