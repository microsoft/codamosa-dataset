

# Generated at 2022-06-17 20:13:45.668169
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS
    args = parser.parse_args(['--traceback'])
    assert main(args=args) == ExitStatus.ERROR
    args = parser.parse_args(['--traceback', '--debug'])
    assert main(args=args) == ExitStatus.ERROR
    args = parser.parse_args(['--debug', '--traceback'])
    assert main(args=args) == ExitStatus.ERROR
    args = parser.parse_args(['--debug', '--traceback', '--debug'])
    assert main(args=args) == ExitStatus.ERROR

# Generated at 2022-06-17 20:13:52.078673
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.output_options = ['all']
    args.headers = []
    args.download = False
    args.download_resume = False
    args.output_file = None
    args.output_file_specified = False
    args.check_status = False
    args.follow = False
    args.quiet = False
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdout_isatty = sys.stdout.isatty()
    env.stderr_isatty = sys.stderr.isatty()
    env.config = None
   

# Generated at 2022-06-17 20:13:59.213055
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-17 20:14:07.347942
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import KeyValueArgType
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import FormAuthPlugin
    from httpie.plugins.builtin import BasicAuthPlugin
    from httpie.plugins.builtin import DigestAuthPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials
    from httpie.plugins.builtin import AuthCredentialsIn

# Generated at 2022-06-17 20:14:15.649967
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus

    # Test that the program exits with the correct status code.
    # Test that the program exits with the correct status code.
    # Test that the program exits with the correct status code.
    # Test that the program exits with the correct status code.
    # Test that the program exits with the correct status code.
    # Test that the program exits with the correct status code.
    # Test that the program exits with the correct status code.
    # Test that the program exits with the correct status code.
    # Test that the

# Generated at 2022-06-17 20:14:26.831708
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--timeout=1', 'https://httpbin.org/delay/2']) == ExitStatus.ERROR_TIMEOUT
    assert main(['http', '--debug', '--traceback', '--max-redirects=0', 'https://httpbin.org/redirect/1']) == ExitStatus.ERROR_TOO_MANY_REDIRECTS
    assert main(['http', '--debug', '--traceback', '--max-redirects=0', 'https://httpbin.org/redirect/1']) == ExitStatus.ERROR_TOO_MANY_RED

# Generated at 2022-06-17 20:14:30.135120
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:14:36.734423
# Unit test for function program
def test_program():
    import argparse
    import os
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_body_stream
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SE

# Generated at 2022-06-17 20:14:40.237967
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:14:48.732320
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--timeout=1', 'http://httpbin.org/delay/2']) == ExitStatus.ERROR_TIMEOUT
    assert main(['http', '--debug', '--traceback', '--max-redirects=0', 'http://httpbin.org/redirect/1']) == ExitStatus.ERROR_TOO_MANY_REDIRECTS
    assert main(['http', '--debug', '--traceback', '--max-redirects=0', 'http://httpbin.org/redirect/1']) == ExitStatus.ERROR_TOO_MANY_RED

# Generated at 2022-06-17 20:15:44.883687
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type_raw
    from httpie.utils import get_response_type_raw_stream
    from httpie.utils import get_response_type_stream
    from httpie.utils import get_response_type_stream_raw
    from httpie.utils import get_response_type_stream_raw_stream
    from httpie.utils import get_response_type_stream_stream

# Generated at 2022-06-17 20:15:52.564707
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    exit_status = program(args, env)
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:16:00.340920
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.parser import ParseResult
    from httpie.context import Environment
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager

    args = parser.parse_args(
        args=['https://httpbin.org/get'],
        env=Environment(),
    )
    assert isinstance(args, ParseResult)

    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert isinstance(plugin_manager, PluginManager)

    exit_status = main()
    assert isinstance(exit_status, ExitStatus)

# Generated at 2022-06-17 20:16:05.495029
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', '--download', '--output-file', 'test.txt', 'https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)

# Generated at 2022-06-17 20:16:08.435172
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:16:12.065575
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

if __name__ == '__main__':
    test_program()

# Generated at 2022-06-17 20:16:20.910266
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', '--download', '--output-file', '-', 'https://httpbin.org/get'])
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdout_isatty = sys.stdout.isatty()
    env.stderr_isatty = sys.stderr.isatty()
    env.config = None
    env.config_dir = None
    env.config_path = None
    env.colors = None
    env.default_options = None


# Generated at 2022-06-17 20:16:30.559491
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    plugin_manager.register(HTTPBasicAuth)
    env = Environment(stdout=StdoutBytesIO(), stderr=StdoutBytesIO())
    args = parser.parse_args(args=['--auth-type=basic', '--auth=user:password', 'httpbin.org/basic-auth/user/password'], env=env)
    exit_status = program(args=args, env=env)

# Generated at 2022-06-17 20:16:41.071094
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO

    env = Environment()
    env.stdout = StdoutBytesIO()
    env.stderr = StdoutBytesIO()
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'], env=env)
    program(args, env)

# Generated at 2022-06-17 20:16:44.703943
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'httpbin.org'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:17:36.301120
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.3"\n  }, \n  "origin": "103.253.27.34", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''

# Generated at 2022-06-17 20:17:39.800524
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:17:47.384305
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.writer import write_message
    from httpie.status import ExitStatus
    from httpie.utils import get_response_body_bytes

    args = parser.parse_args(['http://httpbin.org/get'])
    env = Environment()
    env.stdout = StdoutBytesIO()
    env.stderr = StdoutBytesIO()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS
    assert env.stdout.getvalue() == get_response_body_bytes(args.url)


# Generated at 2022-06-17 20:17:51.775926
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:18:01.213340
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import unittest
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.env = Environment()
            self.env.config = Config(
                config_dir=tempfile.mkdtemp(),
                config_file=os.path.join(DEFAULT_CONFIG_DIR, 'config.json'),
                env=self.env,
            )
            self.env.plugins = PluginManager(load_plugins=False)

        def test_main_success(self):
            self.assertEqual

# Generated at 2022-06-17 20:18:05.017423
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    args = parser.parse_args(args=['--debug', 'https://httpbin.org/get'], env=Environment())
    program(args=args, env=Environment())

# Generated at 2022-06-17 20:18:11.750242
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.constants import DEFAULT_OPTIONS
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response

    args = parser.parse_args(args=['https://httpbin.org/get'], env=Environment())
    assert main(args=['https://httpbin.org/get'], env=Environment()) == ExitStatus.SUCCESS
    assert main(args=['https://httpbin.org/get'], env=Environment()) == ExitStatus.SUCCESS
    assert main(args=['https://httpbin.org/get'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:18:20.037458
# Unit test for function program
def test_program():
    assert program(args=['http', '--debug'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['http', '--traceback'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['http', '--debug', '--traceback'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['http', '--debug', '--traceback', '--timeout=1'], env=Environment()) == ExitStatus.ERROR_TIMEOUT
    assert program(args=['http', '--debug', '--traceback', '--max-redirects=0'], env=Environment()) == ExitStatus.ERROR_TOO_MANY_REDIRECTS

# Generated at 2022-06-17 20:18:29.455962
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-17 20:18:32.611566
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:19:25.229664
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpie.org'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:19:35.140380
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:19:38.343825
# Unit test for function program
def test_program():
    import argparse
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    program(args, Environment())

# Generated at 2022-06-17 20:19:47.596240
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--timeout', '1']) == ExitStatus.ERROR_TIMEOUT
    assert main(['http', '--debug', '--traceback', '--max-redirects', '0']) == ExitStatus.ERROR_TOO_MANY_REDIRECTS
    assert main(['http', '--debug', '--traceback', '--timeout', '1', '--max-redirects', '0']) == ExitStatus.ERROR_TIMEOUT

# Generated at 2022-06-17 20:19:59.659425
# Unit test for function program
def test_program():
    import os
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.utils import get_response_stream
    from httpie.downloads import Downloader
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins import AuthPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import TransportPlugin
    from httpie.plugins import AuthPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import TransportPlugin
    from httpie.plugins import AuthPlugin
    from httpie.plugins import FormatterPlugin

# Generated at 2022-06-17 20:20:05.092220
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    import sys
    args = parser.parse_args(
        args=['https://httpbin.org/get'],
        env=Environment(stdout=StdoutBytesIO(), stderr=sys.stderr)
    )
    assert program(args=args, env=Environment(stdout=StdoutBytesIO(), stderr=sys.stderr)) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:20:15.593887
# Unit test for function program
def test_program():
    import io
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus

    env = Environment()
    env.stdin = io.BytesIO(b'{"a": 1}')
    env.stdin_isatty = False
    env.stdout = io.BytesIO()
    env.stdout_isatty = False
    env.stderr = io.BytesIO()
    env.config = parser.parse_args(args=[], env=env).config

# Generated at 2022-06-17 20:20:18.682574
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', '--help'])
    main(args=args)

# Generated at 2022-06-17 20:20:26.390933
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.client import collect_messages
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP

# Generated at 2022-06-17 20:20:36.915607
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--download', 'https://www.google.com'])
    env = Environment()
    env.stdout = open('test_program.txt', 'w')
    program(args, env)
    env.stdout.close()

# Generated at 2022-06-17 20:21:57.072330
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', '--download', '--output-file', 'test.txt', 'http://httpbin.org/get'])
    env = Environment()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS
    assert os.path.isfile('test.txt')
    os.remove('test.txt')

# Generated at 2022-06-17 20:22:02.056462
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    plugin_manager.register(HTTPBasicAuth)
    env = Environment(stdout=StdoutBytesIO(), stderr=StdoutBytesIO())
    args = parser.parse_args(['--debug'], env=env)
    assert main(args=args, env=env) == ExitStatus.SUCCESS
    args = parser.parse_args(['--traceback'], env=env)
    assert main(args=args, env=env) == ExitStatus.SUCC

# Generated at 2022-06-17 20:22:05.940384
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:09.238849
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:16.915454
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)
    assert env.stdout.getvalue() == b'HTTP/1.1 200 OK\r\n\r\n{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/0.9.9"\n  }, \n  "origin": "127.0.0.1", \n  "url": "http://httpbin.org/get"\n}\n'


# Generated at 2022-06-17 20:22:25.724039
# Unit test for function program
def test_program():
    assert program(args=['http', 'https://httpbin.org/get'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['http', 'https://httpbin.org/get'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['http', 'https://httpbin.org/get'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['http', 'https://httpbin.org/get'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['http', 'https://httpbin.org/get'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['http', 'https://httpbin.org/get'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:28.798534
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)

# Generated at 2022-06-17 20:22:38.064600
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.writer import write_message
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.context import Environment
    from httpie.status import ExitStatus, http_status_to_exit_status

# Generated at 2022-06-17 20:22:46.376898
# Unit test for function main
def test_main():
    import io
    import sys
    import unittest
    from unittest.mock import patch

    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment

    class MainTestCase(unittest.TestCase):
        def setUp(self):
            self.stdout = io.StringIO()
            self.stderr = io.StringIO()
            self.env = Environment(
                stdin=io.StringIO(),
                stdout=self.stdout,
                stderr=self.stderr,
            )

        def test_main_debug(self):
            with patch.object(sys, 'argv', ['http', '--debug']):
                main(env=self.env)