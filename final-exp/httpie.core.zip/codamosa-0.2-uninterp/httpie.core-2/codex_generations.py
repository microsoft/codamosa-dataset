

# Generated at 2022-06-17 20:13:26.143692
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    plugin_manager.register(HTTPBasicAuth)
    env = Environment(stdout=StdoutBytesIO(), stderr=StdoutBytesIO())
    args = parser.parse_args(args=['--debug'], env=env)
    assert main(args=['--debug'], env=env) == ExitStatus.SUCCESS
    args = parser.parse_args(args=['--traceback'], env=env)

# Generated at 2022-06-17 20:13:35.560880
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus

    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:13:46.942940
# Unit test for function program
def test_program():
    import argparse
    import io
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status

    # noinspection PyDefaultArgument
    def main(args: List[Union[str, bytes]] = sys.argv, env=Environment()) -> ExitStatus:
        """
        The main function.

        Pre-process args, handle some special types of invocations,
        and run the main program with error handling.

        Return exit status code.

        """
        program_name, *args

# Generated at 2022-06-17 20:13:54.627252
# Unit test for function program
def test_program():
    import sys
    import os
    import tempfile
    import shutil
    import requests
    import httpie
    from httpie.cli.definition import parser
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    # noins

# Generated at 2022-06-17 20:14:05.381922
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages

# Generated at 2022-06-17 20:14:14.240100
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['https://httpbin.org/get'])
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdout_isatty = sys.stdout.isatty()
    env.stderr_isatty = sys.stderr.isatty()
    env.config = parser.parse_args(args=['--config-dir', '~/.httpie'])
    env.config.directory = '~/.httpie'
    env.config.default_options = []
    env.config.colors = 256


# Generated at 2022-06-17 20:14:25.346162
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-17 20:14:34.190656
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.client import collect_messages
    from httpie.status import http_status_to_exit_status
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment

# Generated at 2022-06-17 20:14:44.194175
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin

# Generated at 2022-06-17 20:14:54.130919
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_config_dir
    from httpie.config import Config
    from httpie.plugins import builtin

    plugin_manager.load_installed_plugins()
    plugin_manager.load_builtin_plugins()


# Generated at 2022-06-17 20:15:24.097835
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.client import collect_messages
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager

# Generated at 2022-06-17 20:15:30.540450
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.output_options = []
    args.headers = []
    args.download = False
    args.download_resume = False
    args.output_file = None
    args.output_file_specified = False
    args.check_status = False
    args.follow = False
    args.quiet = False
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:15:38.052377
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus

    args = parser.parse_args(['http', 'httpbin.org/get'])
    env = Environment(stdout=StdoutBytesIO(), stderr=StdoutBytesIO())
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:15:39.291398
# Unit test for function program
def test_program():
    assert program(args=['--debug'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:15:50.231163
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.headers = []
    args.output_options = []
    args.download = False
    args.download_resume = False
    args.output_file = None
    args.output_file_specified = False
    args.check_status = False
    args.follow = False
    args.quiet = False
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdout_isatty = sys.stdout.isatty()
    env.is_windows = sys.platform.startswith('win')
    env.config = Environment.Config()
    env.config

# Generated at 2022-06-17 20:15:53.951466
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:15:55.784218
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:15:58.519209
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['http', '--debug', 'http://httpbin.org/get'])
    env = Environment()
    assert program(args=args, env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:16:00.991748
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:16:06.843832
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES

# Generated at 2022-06-17 20:16:45.140566
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/2.2.0"\n  }, \n  "origin": "103.15.226.50", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''


# Generated at 2022-06-17 20:16:57.933038
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows


# Generated at 2022-06-17 20:17:08.521898
# Unit test for function program
def test_program():
    import io
    import sys
    import unittest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyAuthSession
    from httpie.plugins.builtin import HTTPAuthSession
    from httpie.plugins.builtin import HTTPBearer

# Generated at 2022-06-17 20:17:16.757156
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--check-status']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--check-status', '--download']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--check-status', '--download', '--download-resume']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--check-status', '--download', '--download-resume', '--follow']) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:17:20.619901
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)

# Generated at 2022-06-17 20:17:30.351333
# Unit test for function main
def test_main():
    import sys
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.status import http_status_to_exit_status
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:17:39.708523
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO

    env = Environment()
    env.stdout = StdoutBytesIO()
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'], env=env)
    program(args, env)

# Generated at 2022-06-17 20:17:44.972986
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    env.stdout = open('test.txt', 'w')
    env.stderr = open('test.txt', 'w')
    program(args, env)
    env.stdout.close()
    env.stderr.close()
    assert os.path.exists('test.txt')
    os.remove('test.txt')

# Generated at 2022-06-17 20:17:50.078979
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:18:00.604886
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    import os
    import sys
    import tempfile
    import unittest
    import requests
    from unittest.mock import patch
    from httpie.cli.definition import parser
    from httpie.plugins.builtin import HTTPBasicAuth

# Generated at 2022-06-17 20:18:23.353269
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'http://httpbin.org/get'])
    program(args=args, env=Environment())

# Generated at 2022-06-17 20:18:26.459545
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:18:32.800079
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins import AuthPlugin
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    import os
    import sys
    import tempfile
    import unittest

    class TestEnvironment(Environment):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.stdin_isatty = False
            self.stdout_isatty = False
            self

# Generated at 2022-06-17 20:18:41.414676
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-17 20:18:51.817921
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.tests.utils import TestEnvironment, httpbin

    env = TestEnvironment()
    plugin_manager.load_installed_plugins()

    args = parser.parse_args(args=['--debug'], env=env)
    assert main(args=['--debug'], env=env) == ExitStatus.SUCCESS

    args = parser.parse_args(args=['--traceback'], env=env)

# Generated at 2022-06-17 20:19:02.394860
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager

# Generated at 2022-06-17 20:19:06.899714
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.context import Environment
    from httpie.status import ExitStatus
    from httpie.plugins.registry import plugin_manager
    plugin_manager.load_installed_plugins()
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment(stdout=StdoutBytesIO(), stderr=StdoutBytesIO(), stdin=StdoutBytesIO())
    assert main(args=args, env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:19:09.477943
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:19:18.061025
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:19:24.276019
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:20:18.224691
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:20:20.714586
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:20:30.570998
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.cli.parser import KeyValueArgType
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyAuthSession
    from httpie.plugins.builtin import HTTPPassAuth

# Generated at 2022-06-17 20:20:41.283463
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyBasicAuth
    from httpie.plugins.builtin import HTTPProxyDigestAuth
    from httpie.plugins.builtin import HTTPProxyBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyTokenAuth


# Generated at 2022-06-17 20:20:45.883406
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.headers = []
    args.output_options = []
    args.download = False
    args.download_resume = False
    args.output_file = None
    args.output_file_specified = False
    args.check_status = False
    args.follow = False
    args.quiet = False
    env = Environment()
    assert program(args=args, env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:20:58.741623
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', '--traceback'])
    assert main(args=args) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', '--traceback', '--help'])
    assert main(args=args) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', '--traceback', '--version'])
    assert main(args=args) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', '--traceback', '--form', 'foo=bar'])

# Generated at 2022-06-17 20:21:06.574310
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-17 20:21:11.712836
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stderr.getvalue() == '\n\n'

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 20:21:20.294898
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.context import Environment
    env = Environment()
    env.stdout = StdoutBytesIO()
    env.stderr = StdoutBytesIO()
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'], env=env)
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:21:31.858990
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.output_options = ['all']
    args.headers = None
    args.download = False
    args.download_resume = False
    args.output_file = None
    args.output_file_specified = False
    args.check_status = False
    args.follow = False
    args.quiet = False
    env = Environment()
    env.stdout_isatty = False
    env.stdin_encoding = 'utf-8'
    env.config.directory = 'httpie'
    env.config.default_options = ['--json']
    env.config.default_options = ['--form']
    env.config.default_options = ['--print']
    env.config.default_options = ['--pretty']

# Generated at 2022-06-17 20:22:11.633474
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['httpie.org'])
    assert program(args, Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:13.069725
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:17.524261
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:26.136228
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD]
    args.headers = []
    args.download = False
    args.output_file = None
    args.output_file_specified = False
    args.download_resume = False
    args.follow = False
    args.check_status = False
    args.quiet = False
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdin_isatty = True
    env.stdout_isatty = True
    env.stderr_isatty = True

# Generated at 2022-06-17 20:22:35.778548
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message

    args = parser.parse_args(args=['httpbin.org/get'])
    env = Environment()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:42.291582
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.3"\n  }, \n  "origin": "127.0.0.1", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''