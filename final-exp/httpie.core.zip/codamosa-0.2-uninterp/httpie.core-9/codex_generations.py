

# Generated at 2022-06-17 20:14:14.013084
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type

    plugin_manager.clear()
    plugin_manager.register(HTTPBasicAuth)

    env = Environment(
        config_dir=DEFAULT_CONFIG_DIR,
        stdin=io.BytesIO(b'{"foo": "bar"}'),
        stdin_isatty=False,
        stdout=io.BytesIO(),
        stdout_isatty=False,
        stderr=io.BytesIO(),
        stderr_isatty=False,
    )

# Generated at 2022-06-17 20:14:25.173898
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.constants import DEFAULT_OPTIONS
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.client import collect_messages
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:14:34.056103
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-17 20:14:44.149072
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyAuthSession
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPPassAuthSession

# Generated at 2022-06-17 20:14:54.131156
# Unit test for function program
def test_program():
    import argparse
    import os
    import sys
    import tempfile
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status

    # noinspection PyDefaultArgument
    def main(args: List[Union[str, bytes]] = sys.argv, env=Environment()) -> ExitStatus:
        """
        The main function.

        Pre-process args, handle some special types of invocations,
        and run the main program with error handling.

        Return exit status code.

        """
        program

# Generated at 2022-06-17 20:15:01.344215
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.utils import get_response_stream
    from httpie.utils import get_response_text
    from httpie.utils import is_json
    from httpie.utils import is_text
    from httpie.utils import is_xml
    from httpie.utils import is_zip
    from httpie.utils import parse_json
    from httpie.utils import parse_xml

# Generated at 2022-06-17 20:15:12.142892
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info

    env = Environment()
    env.stdout = StdoutBytesIO()
    env.stderr = StdoutBytesIO()

    # Test for exit status
    args = parser.parse_args(['--debug'], env=env)
    assert main(args=args, env=env) == ExitStatus.SUCCESS

    # Test for exit status
    args = parser.parse_args(['--debug', '--traceback'], env=env)
    assert main(args=args, env=env) == ExitStatus.SUCCESS

    # Test for exit

# Generated at 2022-06-17 20:15:22.429796
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    env = Environment()
    env.stdout = StdoutBytesIO()
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'], env=env)
    program(args=args, env=env)

# Generated at 2022-06-17 20:15:32.806881
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message

    plugin_manager.load_installed_plugins()

    args = parser.parse_args(args=['--debug', '--form', 'foo=bar', 'https://httpbin.org/post'], env=Environment())
    assert program(args=args, env=Environment()) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:15:37.638991
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--json', 'http://httpbin.org/get'])
    env = Environment()
    program(args, env)

if __name__ == '__main__':
    test_program()

# Generated at 2022-06-17 20:16:07.313852
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

if __name__ == '__main__':
    test_program()

# Generated at 2022-06-17 20:16:10.678357
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'http://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)

# Generated at 2022-06-17 20:16:13.273374
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:16:20.939011
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO

    env = Environment()
    env.stdout = StdoutBytesIO()
    env.stderr = StdoutBytesIO()
    env.stdin = StdoutBytesIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.config.default_options = []
    env.config.directory = '.'
    env.config.config_dir = '.'
    env.config.config_path = '.'
    env.config.config_file_path = '.'
    env.config.config_dirs = ['.']
    env

# Generated at 2022-06-17 20:16:24.567473
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    program(args=args, env=Environment())

# Generated at 2022-06-17 20:16:32.159464
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.context import Environment
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.downloads import Downloader
   

# Generated at 2022-06-17 20:16:42.380868
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type_raw
    from httpie.utils import get_response_type_raw_stream
    from httpie.utils import get_response_type_stream
    from httpie.utils import is_json
    from httpie.utils import is_json_content_type
    from httpie.utils import is_text
    from httpie.utils import is_text_content_type
   

# Generated at 2022-06-17 20:16:51.287517
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback', '--traceback']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:16:56.052158
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:17:00.400256
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['https://httpbin.org/get'])
    env = Environment()
    assert program(args=args, env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:17:37.546876
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parser
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type

    plugin_manager.load_installed_plugins()


# Generated at 2022-06-17 20:17:40.451219
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'http://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:17:47.862205
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    import os
    import sys
    import tempfile

    def get_args(args: List[str]) -> argparse.Namespace:
        return parse_args(args=args, env=Environment(), parser=parser)

    def get_output(args: List[str]) -> str:
        with tempfile.TemporaryFile() as f:
            env = Environment(stdout=f)
            main(args=['http'] + args, env=env)


# Generated at 2022-06-17 20:17:51.480736
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:17:59.978406
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--output=json', 'https://httpbin.org/get'])
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdout_isatty = sys.stdout.isatty()
    env.stderr_isatty = sys.stderr.isatty()
    program(args, env)

# Generated at 2022-06-17 20:18:09.188504
# Unit test for function program
def test_program():
    import pytest
    import requests
    from httpie.cli.definition import parser
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus

    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:18:10.161039
# Unit test for function main
def test_main():
    # TODO: Add unit test for function main
    pass

# Generated at 2022-06-17 20:18:18.973594
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    import requests
    import sys
    import os
    import platform
    import argparse
    import pygments
    import pytest
    import io
    import tempfile
    import shutil
    import os
    import sys
    import platform
    import argparse
    import pygments
    import pytest
    import io
    import tempfile
    import shutil
    import os
   

# Generated at 2022-06-17 20:18:25.428458
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--check-status']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--check-status', '--download']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--check-status', '--download', '--download-resume']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--check-status', '--download', '--download-resume', '--follow']) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:18:32.262898
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-17 20:19:18.929102
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import ParseResult
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message
    from httpie.status import ExitStatus
    from httpie.utils import get_response_body_stream
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPiePlugin

# Generated at 2022-06-17 20:19:20.664659
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:19:25.944362
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.context import Environment
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    import requests


# Generated at 2022-06-17 20:19:35.708076
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.downloads import Downloader
    import os
    import tempfile
    import shutil
    import requests
    import pytest
    import json
    import time
    import random
    import string
    import sys
    import io
    import pytest
    import requests
    import httpie
    import httpie.cli
    import httpie.plugins
    import httpie.output
    import httpie.downloads
    import httpie.status
    import httpie.utils
    import httpie.context
    import httpie.client
    import httpie.plugins.builtin
    import http

# Generated at 2022-06-17 20:19:46.338596
# Unit test for function program
def test_program():
    import pytest
    import requests
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.utils import is_windows
    from httpie.utils import is_windows_stdout_redirected
    from httpie.utils import is_windows_stderr_redirected
    from httpie.utils import is_windows_stdout_tty
    from httpie.utils import is_windows_stderr_tty
    from httpie.utils import is_windows_stdin_tty
    from httpie.utils import is_windows

# Generated at 2022-06-17 20:19:51.834470
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.plugins.manager import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    import os
    import sys
    import tempfile

    # test_main_help
    def test_main_help():
        env = Environment()
        env.stdout = tempfile.TemporaryFile()
        env.stderr = tempfile.TemporaryFile()
        main(['http', '--help'], env=env)
        env.stdout.seek(0)
        env.stderr.seek(0)

# Generated at 2022-06-17 20:20:01.381324
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.status import http_status_to_exit_status
    from httpie.downloads import Downloader

# Generated at 2022-06-17 20:20:12.598850
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus

    env = Environment()
    env.stdout = io.BytesIO()
    env.stderr = io.BytesIO()
    env.stdin = io.BytesIO(b'{"a": 1}')

    args = parser.parse_args(args=['--json', 'POST', 'http://httpbin.org/post'], env=env)
    assert main(args=args, env=env) == ExitStatus.SUCCESS
    assert env.stdout.getvalue().strip() == b'{\n    "a": 1\n}'

    env.stdout = io.BytesIO()

# Generated at 2022-06-17 20:20:22.470090
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:20:29.371633
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows

# Generated at 2022-06-17 20:21:07.127398
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.cli.definition import parser
    from httpie.client import collect_messages
    from httpie.output.streams import BIN

# Generated at 2022-06-17 20:21:11.072490
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:21:14.985110
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:21:26.801923
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyAuthSession
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPPassAuthSession

# Generated at 2022-06-17 20:21:30.653076
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:21:32.597983
# Unit test for function program
def test_program():
    args = ['http', 'http://httpbin.org/get']
    env = Environment()
    assert program(args=args, env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:21:44.615685
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--timeout', '1']) == ExitStatus.ERROR_TIMEOUT
    assert main(['http', '--debug', '--traceback', '--max-redirects', '0']) == ExitStatus.ERROR_TOO_MANY_REDIRECTS
    assert main(['http', '--debug', '--traceback', '--download', '--output', '-']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--download', '--output', '-']) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:21:48.217024
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', 'http://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:21:56.661257
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:22:01.654890
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager
    import sys
    import os
    import requests
    import io
    import pytest
    import tempfile
    import shutil
    import json
    import time
    import random
    import string
    import httpie
    import httpie.plugins.builtin
    import httpie.plugins.manager
    import httpie.cli.definition
    import httpie.context
    import httpie.downloads
    import httpie.output.streams
    import httpie.output.writer
    import httpie.status
    import httpie.utils
    import httpie.plugins.built