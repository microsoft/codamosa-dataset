

# Generated at 2022-06-17 20:13:51.172239
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['http', 'https://httpbin.org/get'])
    assert program(args=args, env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:13:58.389005
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.3"\n  }, \n  "origin": "1.2.3.4", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''


# Generated at 2022-06-17 20:14:01.754068
# Unit test for function program
def test_program():
    args = ['--download', '--output-file', 'test.txt', 'https://httpbin.org/get']
    env = Environment()
    program(args=args, env=env)
    assert os.path.isfile('test.txt')
    os.remove('test.txt')

# Generated at 2022-06-17 20:14:09.068235
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.output_options = [OUT_RESP_BODY]
    args.output_file = None
    args.output_file_specified = False
    args.check_status = False
    args.download = False
    args.download_resume = False
    args.follow = False
    args.headers = []
    args.quiet = False
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdout_isatty = sys.stdout.isatty()
    env.stderr_isatty = sys.stderr.isatty()
    env

# Generated at 2022-06-17 20:14:16.618983
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    plugin_manager.load_installed_plugins()
    args = parser.parse_args(['--auth-type=basic', '--auth=user:password', 'http://httpbin.org/basic-auth/user/password'])
    env = Environment()
    env.config.default_options = ['--auth-type=basic', '--auth=user:password']
    env.config.directory = 'C:\\Users\\user\\AppData\\Roaming\\httpie'
    env.config.config_dir = 'C:\\Users\\user\\AppData\\Roaming\\httpie'

# Generated at 2022-06-17 20:14:27.523029
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.2"\n  }, \n  "origin": "127.0.0.1", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''

# Generated at 2022-06-17 20:14:30.422028
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)

# Generated at 2022-06-17 20:14:32.245352
# Unit test for function program
def test_program():
    assert program(args=['http', 'https://httpbin.org/get'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:14:37.639825
# Unit test for function program
def test_program():
    import pytest
    import requests
    from httpie.cli.definition import parser
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus


# Generated at 2022-06-17 20:14:40.375993
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:15:10.799744
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'http://httpbin.org/get'])
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdout_isatty = sys.stdout.isatty()
    env.stderr_isatty = sys.stderr.isatty()
    program(args, env)

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 20:15:16.202827
# Unit test for function program
def test_program():
    assert program(args=['http', '--debug', 'http://httpbin.org/get'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['http', '--debug', 'http://httpbin.org/get'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['http', '--debug', 'http://httpbin.org/get'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['http', '--debug', 'http://httpbin.org/get'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['http', '--debug', 'http://httpbin.org/get'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:15:26.006307
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import BuiltinPlugin
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type

# Generated at 2022-06-17 20:15:35.297488
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type_raw
    from httpie.utils import get_response_type_raw_stream
    from httpie.utils import get_response_type_stream
    from httpie.utils import get_response_type_stream_raw
    from httpie.utils import get_response_type_stream_raw_

# Generated at 2022-06-17 20:15:43.850006
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.client import collect_messages
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_HELP

# Generated at 2022-06-17 20:15:46.980807
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['httpie', '--debug'])
    env = Environment()
    program(args, env)

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 20:15:52.566835
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args=args, env=env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:16:01.026104
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/0.9.9"\n  }, \n  "origin": "1.2.3.4", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''


# Generated at 2022-06-17 20:16:06.866773
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:16:15.995829
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.context import Environment

    env = Environment(
        config=Config(directory=DEFAULT_CONFIG_DIR),
        stdin=sys.stdin,
        stdin_isatty=sys.stdin.isatty(),
        stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(),
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
    )
    assert main(args=['http', '--debug'], env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:16:43.659944
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_registry
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LF
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_CRLF
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_CR

# Generated at 2022-06-17 20:16:47.842759
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['--debug', '--traceback', '--download', 'https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 20:16:57.988566
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    args = parser.parse_args(['--output-options', 'hb', '--output-options', 'Hb', 'http://httpbin.org/get'])
    assert args.output_options == [OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY]
    assert program(args, Environment()) == ExitStatus.SUCCESS

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 20:17:01.322578
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    program(args, Environment())

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 20:17:11.811144
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--debug', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:17:18.537999
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--timeout=1', '--max-redirects=1', 'http://httpbin.org/redirect/1']) == ExitStatus.ERROR_TOO_MANY_REDIRECTS
    assert main(['http', '--debug', '--traceback', '--timeout=1', '--max-redirects=1', 'http://httpbin.org/redirect/1', '--follow']) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:17:28.678373
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows


# Generated at 2022-06-17 20:17:38.031730
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.utils import get_response_stream
    from httpie.utils import get_response_text
    from httpie.utils import get_response_type
    from httpie.utils import is_json

# Generated at 2022-06-17 20:17:46.183636
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.formatters.colors import NO_COLOR
    from httpie.output.formatters.format import get_preferred_output_format
    from httpie.output.formatters.utils import get_preferred_json_indent
    from httpie.output.formatters.utils import get_preferred_json_sort_keys
    from httpie.output.formatters.utils import get_preferred_unicode_is_binary

# Generated at 2022-06-17 20:17:59.117711
# Unit test for function program
def test_program():
    import requests
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.context import Environment
    from httpie.client import collect_messages
    from httpie.output.writer import write_message
    from httpie.downloads import Downloader
    from httpie.plugins.registry import plugin_manager
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.context import Environment
    from httpie.client import collect_messages
    from httpie.output.writer import write_message

# Generated at 2022-06-17 20:18:27.121087
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.headers = []
    args.output_options = []
    args.output_file = None
    args.output_file_specified = False
    args.download = False
    args.download_resume = False
    args.check_status = False
    args.follow = False
    args.quiet = False
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdout_isatty = sys.stdout.isatty()
    env.stderr_isatty = sys.stderr.isatty()
    env.stdin_encoding = sys

# Generated at 2022-06-17 20:18:38.618138
# Unit test for function program
def test_program():
    args = ['http', '--debug']
    env = Environment()
    assert main(args, env) == ExitStatus.SUCCESS
    assert env.program_name == 'http'
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'
    assert env.stderr_encoding == 'utf8'
    assert env.stdout_isatty is True
    assert env.stderr_isatty is True
    assert env.stdout.encoding == 'utf8'
    assert env.stderr.encoding == 'utf8'
    assert env.stdout.isatty() is True
    assert env.stderr.isatty() is True
    assert env.config.directory == '~/.config/httpie'

# Generated at 2022-06-17 20:18:50.813459
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus

    # Set up test environment

# Generated at 2022-06-17 20:19:01.023728
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-17 20:19:05.134398
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:19:14.515200
# Unit test for function main
def test_main():
    assert main(['--debug']) == ExitStatus.SUCCESS
    assert main(['--debug', '--traceback']) == ExitStatus.SUCCESS
    assert main(['--debug', '--traceback', '--debug']) == ExitStatus.SUCCESS
    assert main(['--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.SUCCESS
    assert main(['--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.SUCCESS
    assert main(['--debug', '--traceback', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:19:16.663893
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

if __name__ == '__main__':
    test_program()

# Generated at 2022-06-17 20:19:22.421358
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPGzip
    from httpie.plugins.builtin import HTTPJSONData
    from httpie.plugins.builtin import HTTPJSONPath
    from httpie.plugins.builtin import HTTPPrettyPrint
    from httpie.plugins.builtin import HTTPPrint0
    from httpie.plugins.builtin import HTTPPrintB
    from httpie.plugins.builtin import HTTPPrintH
    from httpie.plugins.builtin import HTTPPrintHB

# Generated at 2022-06-17 20:19:32.574425
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', '--download', '--output-file', 'test.txt', 'http://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/0.9.9"\n  }, \n  "origin": "1.2.3.4", \n  "url": "http://httpbin.org/get"\n}\n'
    assert env.st

# Generated at 2022-06-17 20:19:44.468811
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status

    # noinspection PyDefaultArgument

# Generated at 2022-06-17 20:20:15.594440
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import unittest
    from httpie.cli.definition import parser
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus

    class TestEnvironment(Environment):
        def __init__(self):
            self.stdin = sys.stdin
            self.stdin_isatty = sys.stdin.isatty()
            self.stdout = sys.stdout
            self.stdout_isatty = sys.stdout.isatty()
            self.stderr = sys.stderr
            self.stderr_isatty = sys.stderr.isatty()
            self.colors = 256
            self.config = None
            self.config_dir = None


# Generated at 2022-06-17 20:20:19.356886
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:20:21.808492
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:20:28.983182
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stderr.getvalue() == 'HTTPie 1.0.3\nRequests 2.22.0\nPygments 2.4.2\nPython 3.7.3 (default, Mar 27 2019, 22:11:17) \n[GCC 7.3.0]\nLinux 4.15.0-47-generic\n\n\n<httpie.context.Environment object at 0x7f7e7c0a6e10>\n\n'

# Generated at 2022-06-17 20:20:39.091203
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.client import collect_messages
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT

# Generated at 2022-06-17 20:20:47.171973
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins import AuthPlugin, FormatterPlugin
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins.builtin import HTTPBasicAuth

# Generated at 2022-06-17 20:20:55.959912
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.headers = []
    args.output_options = []
    args.output_file = None
    args.output_file_specified = False
    args.download = False
    args.download_resume = False
    args.check_status = False
    args.follow = False
    args.quiet = False
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:21:04.646942
# Unit test for function program
def test_program():
    import argparse
    import os
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status

    # noinspection PyDefaultArgument
    def main(args: List[Union[str, bytes]] = sys.argv, env=Environment()) -> ExitStatus:
        """
        The main function.

        Pre-process args, handle some special types of invocations,
        and run the main program with error handling.

        Return exit status code.

        """
        program_name, *args

# Generated at 2022-06-17 20:21:07.295779
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://www.google.com'])
    env = Environment()
    exit_status = program(args, env)
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:21:10.912326
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:32.903323
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stdout.getvalue() == '{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.3"\n  }, \n  "origin": "118.70.197.117", \n  "url": "https://httpbin.org/get"\n}\n'


# Generated at 2022-06-17 20:22:40.882469
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response_body_bytes
    from httpie.downloads import Downloader
    from httpie.plugins.registry import plugin_manager
    plugin_manager.load_installed_plugins()

    env = Environment()
    env.stdout = StdoutBytesIO()
    env.stderr = StdoutBytesIO()
    env.stdin_encoding = 'utf8'
    env.config.default_options = ['--form']
    env.config.output_options = ['--pretty=all']
    env.config.colors = False
    env.config.style = None

# Generated at 2022-06-17 20:22:49.346250
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.context import Environment
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.context import Environment
    from httpie.cli.constants import OUT_