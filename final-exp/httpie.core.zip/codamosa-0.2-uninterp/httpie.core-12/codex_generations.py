

# Generated at 2022-06-17 20:14:01.453493
# Unit test for function program
def test_program():
    assert program(args=['http', 'httpbin.org'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:14:05.699348
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.constants import DEFAULT_OPTIONS
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from tests.utils import MockEnvironment, MockResponse
    from tests.utils import httpbin, httpbin_secure
    from tests.utils import httpbin_any, httpbin_secure_any
    from tests.utils import httpbin_both, httpbin_secure_both
    from tests.utils import httpbin_digest_auth, httpbin_digest

# Generated at 2022-06-17 20:14:14.530996
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.downloads import Downloader
    import os
    import sys
    import requests
    import pytest
    import pygments
    import platform
    import argparse
    import io
    import tempfile
    import shutil
    import subprocess
    import json
    import time
    import random
    import string
    import http.server
    import socketserver
    import threading
    import urllib.parse
    import httpie.cli.constants as constants
    import httpie.output.writer as writer

# Generated at 2022-06-17 20:14:17.853103
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    exit_status = program(args, env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:14:28.962320
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:14:36.144937
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.config import Config
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:14:45.967080
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.manager import PluginManager
    from httpie.output.streams import StdoutBytesIO


# Generated at 2022-06-17 20:14:59.637012
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['http', 'http://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)

# Generated at 2022-06-17 20:15:12.008940
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_protocol
    from httpie.utils import get_response_status_line
    from httpie.utils import get_response_version
    from httpie.utils import get_response_headers
    from httpie.utils import get_response_headers_str
    from httpie.utils import get_response_body
    from httpie.utils import get_response_body_bytes
    from httpie.utils import get_response_body_str
    from httpie.utils import get_response_body_json

# Generated at 2022-06-17 20:15:22.215447
# Unit test for function program
def test_program():
    import requests
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.client import collect_messages
    from httpie.context import Environment
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.output.streams import Stdout

# Generated at 2022-06-17 20:15:58.413730
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.plugins.registry import plugin_manager
    plugin_manager.load_installed_plugins()
    args = parser.parse_args(['http://httpbin.org/get'])
    env = Environment()
    env.stdout = StdoutBytesIO()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:16:04.933798
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPGSSAPIAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPNTLMAuth
    from httpie.plugins.builtin import HTTPFileUpload
    from httpie.plugins.builtin import HTTPFileDownload
    from httpie.plugins.builtin import HTTP

# Generated at 2022-06-17 20:16:08.567924
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:16:16.805660
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyAuthSession
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPiePlugin

# Generated at 2022-06-17 20:16:19.260588
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(
        args=['http', 'https://httpbin.org/get'],
        env=Environment(),
    )
    assert program(args=args, env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:16:29.983358
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth

# Generated at 2022-06-17 20:16:40.582292
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import KeyValue
    from httpie.plugins.builtin import Form
    from httpie.plugins.builtin import JSON

# Generated at 2022-06-17 20:16:51.005370
# Unit test for function program
def test_program():
    import io
    import sys
    import unittest
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status

    class TestProgram(unittest.TestCase):
        def setUp(self):
            self.env = Environment()
            self.env.stdin = io.BytesIO()
            self.env.stdin

# Generated at 2022-06-17 20:16:54.341487
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:17:05.672388
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.utils import get_response_stream
    from httpie.utils import get_response_text
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type_raw
    from httpie.utils import is_json
    from httpie.utils import is_text
    from httpie.utils import is_xml
    from httpie.utils import is_zip


# Generated at 2022-06-17 20:18:04.753740
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:18:07.529419
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:18:10.872933
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:18:13.839115
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:18:16.071487
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http://httpbin.org/get'])
    program(args, Environment())

# Generated at 2022-06-17 20:18:19.730721
# Unit test for function program
def test_program():
    from httpie.cli.parser import parser
    args = parser.parse_args(['--debug', 'http://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:18:29.150254
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
   

# Generated at 2022-06-17 20:18:39.303526
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:18:45.816657
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['http', 'httpbin.org', '--json'])
    env = Environment()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:18:59.033821
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSA

# Generated at 2022-06-17 20:21:25.932685
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:21:34.758238
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.manager import plugin_manager
    from httpie.config import Config
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPGSSAPIAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyAuthSession
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPPassAuthSession

# Generated at 2022-06-17 20:21:45.499594
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins import AuthPlugin
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:21:58.688246
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.tests.utils import TestEnvironment
    from httpie.utils import get_response_data

    env = TestEnvironment()
    env.stdout = StdoutBytesIO()
    env.stderr = StdoutBytesIO()
    env.stdin = StdoutBytesIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.config.default_options = ['--form']
    env.config.output_options = ['--pretty=all']
    env.config.colors = 256
    env.config

# Generated at 2022-06-17 20:22:10.153186
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.output_options = []
    args.download = False
    args.output_file = None
    args.output_file_specified = False
    args.check_status = False
    args.follow = False
    args.headers = None
    args.download_resume = False
    args.quiet = False
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin_encoding = 'utf-8'
    env.stdout_isatty = True
    env.stderr_isatty = True
    env.stdin = sys.stdin
    env.config = None
    env.log_error = print
    env.log_info = print

# Generated at 2022-06-17 20:22:17.261019
# Unit test for function program

# Generated at 2022-06-17 20:22:25.520809
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['http', 'https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)
    assert env.stdout.getvalue() == '{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.3"\n  }, \n  "origin": "127.0.0.1", \n  "url": "https://httpbin.org/get"\n}\n'

# Generated at 2022-06-17 20:22:35.470861
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.3"\n  }, \n  "origin": "127.0.0.1", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''


# Generated at 2022-06-17 20:22:39.708727
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:22:46.977791
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPProxyPassAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin