

# Generated at 2022-06-17 20:13:11.415371
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['http', '--debug', 'httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:13:23.271410
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = ['resp.body']
    message = requests.Response()
    message.headers = {'Content-Type': 'text/html'}
    message.status_code = 200

# Generated at 2022-06-17 20:13:34.087166
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LF
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_CR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_CRLF
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LFCR
    from httpie.output.streams import BINARY_

# Generated at 2022-06-17 20:13:42.126374
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options=[
            OUT_REQ_HEAD,
            OUT_REQ_BODY,
            OUT_RESP_HEAD,
            OUT_RESP_BODY,
        ]
    )
    assert get_output_options(args=args, message=requests.PreparedRequest()) == (True, True)
    assert get_output_options(args=args, message=requests.Response()) == (True, True)

# Generated at 2022-06-17 20:13:46.168190
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_HEAD, OUT_RESP_BODY]
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)
    assert get_output_options(args, requests.Response()) == (False, True)

# Generated at 2022-06-17 20:13:52.395576
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser

# Generated at 2022-06-17 20:13:54.585359
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:14:05.340927
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.client import collect_messages
    from httpie.context import Environment
    from httpie.status import ExitStatus
    from httpie.utils import get_response


# Generated at 2022-06-17 20:14:09.031292
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', '--download', '--output-file=test.txt', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert os.path.exists('test.txt')
    os.remove('test.txt')


# Generated at 2022-06-17 20:14:11.963341
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:14:59.391802
# Unit test for function main
def test_main():
    import io
    import sys
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type

    # TODO: Refactor to use a mock.
    class MockPlugin(HTTPBasicAuth):
        name = 'mock'
        auth_type = 'mock'

    plugin_manager.register(MockPlugin)

    def mock_program(args: argparse.Namespace, env: Environment) -> ExitStatus:
        assert args.auth == ('mock', 'user', 'pass')

# Generated at 2022-06-17 20:15:11.202615
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.3"\n  }, \n  "origin": "127.0.0.1", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''


# Generated at 2022-06-17 20:15:17.501497
# Unit test for function program
def test_program():
    import argparse
    import io
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type_raw
    from httpie.utils import get_response_type_raw_stream
    from httpie.utils import get_response_type_stream
    from httpie.utils import get_response_type_stream_raw
    from httpie.utils import get_response_type_stream_raw_stream


# Generated at 2022-06-17 20:15:22.073016
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'httpbin.org'])
    env = Environment()
    program(args, env)
    assert env.stdout.getvalue() == b'HTTP/1.1 200 OK\r\n\r\n{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.3"\n  }, \n  "origin": "127.0.0.1", \n  "url": "https://httpbin.org/"\n}\n'


# Generated at 2022-06-17 20:15:25.054580
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:15:33.677315
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response_data

    env = Environment()
    env.stdout = StdoutBytesIO()
    args = parser.parse_args(['https://httpbin.org/get'], env=env)
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS
    assert env.stdout.getvalue().decode('utf-8') == get_response_data('get')
    env.stdout.close()

# Generated at 2022-06-17 20:15:43.020306
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_config_dir
    from httpie.config import Config
    from httpie.plugins import builtin
    from httpie.plugins.manager import PluginManager
    from httpie.output.streams import get_output_streams
    from httpie.output.writer import get_output_options_from_args
    from httpie.cli.definition import parser
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_items
   

# Generated at 2022-06-17 20:15:45.825131
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:15:53.528098
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--download', '--output-file', 'test.txt', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert os.path.isfile('test.txt')
    os.remove('test.txt')

# Generated at 2022-06-17 20:16:00.898819
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.2"\n  }, \n  "origin": "103.253.145.66", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''


# Generated at 2022-06-17 20:16:52.001749
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:17:03.877086
# Unit test for function program
def test_program():
    import io
    import sys
    import unittest
    from unittest.mock import patch
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    class TestProgram(unittest.TestCase):

        def setUp(self):
            self.env = Environment(colors=256)
            self.env.config.__dict__.update(default_options=['--verbose'])
           

# Generated at 2022-06-17 20:17:14.702869
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.parser import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus

    args = parser.parse_args(args=['--debug', '--traceback', '--verbose', '--print=H', '--body', '--form', 'https://httpbin.org/get'])
    env = Environment()
    env.stdout = io.BytesIO()
    env.stderr = io.BytesIO()
    env.stdin = io.BytesIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.is_windows = False
    env.config.colors = False
    env.config.default

# Generated at 2022-06-17 20:17:25.229461
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxy
    from httpie.plugins.builtin import Form
    from httpie.plugins.builtin import JSON
    from httpie.plugins.builtin import Debug
    from httpie.plugins.builtin import Download

# Generated at 2022-06-17 20:17:28.548761
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    assert program(args, Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:17:31.972121
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http://httpbin.org/get'])
    env = Environment()
    program(args, env)

if __name__ == '__main__':
    test_program()

# Generated at 2022-06-17 20:17:35.606523
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:17:45.645124
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message

    args = parser.parse_args(args=['--debug', '--follow', '--check-status', '--headers', 'GET', 'https://httpbin.org/get'])
    env = Environment()
    env.stdout = io.BytesIO()
    env.stderr = io.BytesIO()
    env.stdin = io.BytesIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.config

# Generated at 2022-06-17 20:17:59.101044
# Unit test for function main
def test_main():
    assert main(['httpie', '--debug']) == ExitStatus.SUCCESS
    assert main(['httpie', '--debug', '--traceback']) == ExitStatus.SUCCESS
    assert main(['httpie', '--debug', '--traceback', '--output=json']) == ExitStatus.SUCCESS
    assert main(['httpie', '--debug', '--traceback', '--output=json', 'https://httpbin.org/get']) == ExitStatus.SUCCESS
    assert main(['httpie', '--debug', '--traceback', '--output=json', 'https://httpbin.org/get', '--headers']) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:18:00.878036
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:19:22.271522
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.plugins.registry import plugin_manager
    from httpie.client import collect_messages
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.context import Environment
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.plugins.registry import plugin_manager


# Generated at 2022-06-17 20:19:32.535001
# Unit test for function program
def test_program():
    import argparse
    import os
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status

    # noinspection PyDefaultArgument
    def main(args: List[Union[str, bytes]] = sys.argv, env=Environment()) -> ExitStatus:
        """
        The main function.

        Pre-process args, handle some special types of invocations,
        and run the main program with error handling.

        Return exit status code.

        """
        program_name, *args = args
        env.program_name = os

# Generated at 2022-06-17 20:19:44.474724
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.context import Environment
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.downloads import Downloader
   

# Generated at 2022-06-17 20:19:50.790189
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.writer import write_message
    from httpie.status import ExitStatus
    from httpie.plugins.registry import plugin_manager
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.writer import write_message
    from httpie.status import ExitStatus
    from httpie.plugins.registry import plugin_manager
    from httpie.downloads import Downloader

# Generated at 2022-06-17 20:20:00.972684
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    plugin_manager.load_installed_plugins()
    env = Environment(stdout=StdoutBytesIO(), stderr=StdoutBytesIO(), stdin=StdoutBytesIO())
    args = parser.parse_args(['--debug'], env=env)
    assert program(args, env) == ExitStatus.SUCCESS
    args = parser.parse_args(['--traceback'], env=env)
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:20:12.306344
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.manager import plugin_manager
    from httpie.status import ExitStatus
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.client import collect_messages
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.context import Environment
    from httpie.cli.constants import OUT_REQ_BODY, OUT_

# Generated at 2022-06-17 20:20:22.162157
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message

    plugin_manager.clear()
    plugin_manager.load_installed_plugins()

    class TestEnvironment(Environment):
        def __init__(self):
            super().__init__()
            self.stdout = StdoutBytesIO()
            self.stderr = StdoutBytesIO()

    env = TestEnvironment()
    args = parser.parse_args(args=['--debug'], env=env)

# Generated at 2022-06-17 20:20:29.180713
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.downloads import Downloader
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.streams import StderrBytesIO
    from httpie.output.streams import StdinBytesIO
    from httpie.output.streams import StdoutTextIOWrapper
    from httpie.output.streams import StderrTextIOWrapper
    from httpie.output.streams import StdinTextIOWrapper


# Generated at 2022-06-17 20:20:31.921673
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:20:42.051722
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins import builtin
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows

# Generated at 2022-06-17 20:21:20.516315
# Unit test for function program
def test_program():
    import httpie.cli.parser
    import httpie.cli.definition
    import httpie.cli.constants
    import httpie.plugins.builtin.auth.basic
    import httpie.plugins.builtin.auth.digest
    import httpie.plugins.builtin.auth.plugin
    import httpie.plugins.builtin.downloads
    import httpie.plugins.builtin.form
    import httpie.plugins.builtin.generic
    import httpie.plugins.builtin.graphql
    import httpie.plugins.builtin.html
    import httpie.plugins.builtin.json
    import httpie.plugins.builtin.pretty
    import httpie.plugins.builtin.sessions
    import httpie.plugins.builtin.stream
    import httpie.plugins.builtin.style

# Generated at 2022-06-17 20:21:31.963777
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info
    from httpie.downloads import Downloader
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.streams import StderrBytesIO
    from httpie.output.streams import StdinBytesIO
    from httpie.output.streams import StdoutTextIOWrapper
    from httpie.output.streams import StderrTextIOWrapper
    from httpie.output.streams import StdinTextIOWrapper
    from httpie.output.streams import StdoutBytesIO

# Generated at 2022-06-17 20:21:37.863338
# Unit test for function program
def test_program():
    assert program(args=['--debug'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--traceback'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--debug', '--traceback'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--debug', '--traceback', '--debug'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--debug', '--traceback', '--debug', '--traceback'], env=Environment()) == ExitStatus.SUCCESS
    assert program(args=['--debug', '--traceback', '--debug', '--traceback', '--debug'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:21:49.503180
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:21:57.329788
# Unit test for function program

# Generated at 2022-06-17 20:22:09.325294
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--timeout', '1']) == ExitStatus.ERROR_TIMEOUT
    assert main(['http', '--debug', '--traceback', '--max-redirects', '0']) == ExitStatus.ERROR_TOO_MANY_REDIRECTS
    assert main(['http', '--debug', '--traceback', '--download', '--output', '-']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--download', '--output', '-']) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:16.974292
# Unit test for function main
def test_main():
    import os
    import sys
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status


# Generated at 2022-06-17 20:22:25.750431
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS
    assert main(['--debug']) == ExitStatus.SUCCESS
    assert main(['--traceback']) == ExitStatus.ERROR
    assert main(['--help']) == ExitStatus.SUCCESS
    assert main(['--version']) == ExitStatus.SUCCESS
    assert main(['--verbose']) == ExitStatus.ERROR
    assert main(['--verbose', '--debug']) == ExitStatus.ERROR
    assert main(['--verbose', '--traceback']) == ExitStatus.ERROR
    assert main(['--verbose', '--help']) == ExitStatus.SUCCESS
    assert main(['--verbose', '--version']) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:31.981031
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.streams import StderrBytesIO
    from httpie.output.streams import StdinBytesIO
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.context import Environment
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD

# Generated at 2022-06-17 20:22:40.323189
# Unit test for function program
def test_program():
    import argparse
    import io
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status