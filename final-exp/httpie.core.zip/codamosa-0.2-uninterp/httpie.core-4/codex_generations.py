

# Generated at 2022-06-17 20:14:27.606974
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)
    assert env.stderr.getvalue() == 'HTTPie 0.9.9\nRequests 2.18.4\nPygments 2.2.0\nPython 3.6.3 (v3.6.3:2c5fed8, Oct  3 2017, 18:11:49) [MSC v.1900 64 bit (AMD64)]\nC:\\Users\\micha\\Anaconda3\\python.exe\n\nWindows 10\n\n\n'

# Generated at 2022-06-17 20:14:35.333008
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--json', 'https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)
    assert env.stdout.getvalue() == b'{\n    "args": {}, \n    "headers": {\n        "Accept": "*/*", \n        "Accept-Encoding": "gzip, deflate", \n        "Host": "httpbin.org", \n        "User-Agent": "HTTPie/0.9.9"\n    }, \n    "origin": "1.2.3.4", \n    "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''


# Generated at 2022-06-17 20:14:45.312527
# Unit test for function main
def test_main():
    assert main(['httpie', '--debug']) == ExitStatus.SUCCESS
    assert main(['httpie', '--traceback']) == ExitStatus.ERROR
    assert main(['httpie', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['httpie', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['httpie', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['httpie', '--debug', '--traceback', '--debug', '--debug']) == ExitStatus.ERROR
    assert main(['httpie', '--debug', '--traceback', '--debug', '--debug', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:14:59.324722
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info
    from httpie.downloads import Downloader
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.streams import StderrBytesIO
    from httpie.output.streams import StdinBytesIO
    from httpie.output.streams import StdoutTextIOWrapper
    from httpie.output.streams import StderrTextIOWrapper
    from httpie.output.streams import StdinTextIOWrapper

# Generated at 2022-06-17 20:15:11.971792
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.downloads import Downloader
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.streams import StderrBytesIO
    from httpie.output.streams import StdinBytesIO
    from httpie.output.streams import StdoutTextIOWrapper
    from httpie.output.streams import StderrTextIOWrapper
    from httpie.output.streams import StdinTextIOWrapper


# Generated at 2022-06-17 20:15:14.058337
# Unit test for function main
def test_main():
    args = ['http', '--debug']
    exit_status = main(args)
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:15:24.533456
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.output.streams import is_binary_response
    from httpie.output.streams import write_binary_response_to_output_stream
    from httpie.output.streams import write_binary_response_to_output_stream_with_progress


# Generated at 2022-06-17 20:15:27.788746
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    main(args=args, env=env)

# Generated at 2022-06-17 20:15:31.495350
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 20:15:38.645335
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.status import http_status_to_exit_status
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.client import collect_mess

# Generated at 2022-06-17 20:16:15.039378
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'httpbin.org'])
    env = Environment()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:16:21.558124
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin

# Generated at 2022-06-17 20:16:30.839418
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status

    # noinspection PyDefaultArgument

# Generated at 2022-06-17 20:16:41.283316
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdout_isatty = sys.stdout.isatty()
    env.stderr_isatty = sys.stderr.isatty()
    env.config = parser.parse_args(['--config-dir', '~/.httpie'])
    env.config.directory = os.path.expanduser('~/.httpie')

# Generated at 2022-06-17 20:16:51.044373
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_SEPARATOR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_SEPARATOR_LENGTH
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_SEPARATOR_BYTES
   

# Generated at 2022-06-17 20:16:59.659511
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    import os
    import sys
    import platform
    import requests
    import pygments
    import argparse
    from typing import List, Optional, Tuple, Union
    from pygments import __version__ as pygments_version
    from requests import __version__ as requests_version

# Generated at 2022-06-17 20:17:10.116187
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--timeout=1', 'https://httpbin.org/delay/2']) == ExitStatus.ERROR_TIMEOUT
    assert main(['http', '--debug', '--traceback', '--max-redirects=0', 'https://httpbin.org/redirect/1']) == ExitStatus.ERROR_TOO_MANY_REDIRECTS
    assert main(['http', '--debug', '--traceback', 'https://httpbin.org/status/500']) == ExitStatus.ERROR
   

# Generated at 2022-06-17 20:17:17.732419
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins import AuthPlugin
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:17:26.172223
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LF
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_CR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_CRLF
    from httpie.output.streams import BINARY

# Generated at 2022-06-17 20:17:28.945698
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:18:08.721835
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    env = Environment()
    args = parser.parse_args(['-v', 'https://httpbin.org/get'], env=env)
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:18:18.110360
# Unit test for function program
def test_program():
    import io
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.downloads import Downloader
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyAuthSession
    from httpie.plugins.builtin import HTTPPassAuth

# Generated at 2022-06-17 20:18:27.078651
# Unit test for function program
def test_program():
    class Args:
        def __init__(self):
            self.headers = None
            self.output_options = None
            self.output_file = None
            self.output_file_specified = None
            self.quiet = None
            self.check_status = None
            self.follow = None
            self.download = None
            self.download_resume = None

    class Env:
        def __init__(self):
            self.stdout = None
            self.stdout_isatty = None
            self.stderr = None
            self.log_error = None

    args = Args()
    env = Env()
    program(args, env)

# Generated at 2022-06-17 20:18:31.599803
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:18:40.901302
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--help']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--version']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--help', '--version']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--version', '--help']) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:18:46.176624
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args=args, env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:18:59.241958
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE


# Generated at 2022-06-17 20:19:01.044506
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['httpie.org'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:19:04.835580
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'httpbin.org'])
    program(args, Environment())

# Generated at 2022-06-17 20:19:05.848249
# Unit test for function main
def test_main():
    # TODO: Add tests for main()
    pass

# Generated at 2022-06-17 20:19:27.951071
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:19:36.709509
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.constants import DEFAULT_OPTIONS
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    env = Environment()
    env.stdout = io.BytesIO()
    env.stderr = io.BytesIO()
    env.stdin = io.BytesIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.config.default_options = DEFAULT_OPTIONS
    plugin_

# Generated at 2022-06-17 20:19:46.931828
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins import builtin
    from httpie.status import ExitStatus
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    args = parser.parse_args(args=['--debug', '--form', 'key=val', 'https://httpbin.org/post'], env=Environment())
    assert program(args=args, env=Environment()) == ExitStatus.SUCCESS
    args = parser.parse_args(args=['--debug', '--form', 'key=val', 'https://httpbin.org/post'], env=Environment())

# Generated at 2022-06-17 20:19:59.444526
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.definition import parser
    from httpie.cli.parser import KeyValue
    from httpie.cli.utils import get_response_type
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager

# Generated at 2022-06-17 20:20:01.416964
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:20:06.034921
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

if __name__ == '__main__':
    test_program()

# Generated at 2022-06-17 20:20:16.520263
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type

    plugin_manager.load_installed_plugins()

    def run(args: List[str], env: Environment) -> ExitStatus:
        return main(args=args, env=env)


# Generated at 2022-06-17 20:20:21.680269
# Unit test for function program
def test_program():
    import argparse
    import os
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.status import ExitStatus

    args = parser.parse_args(
        args=['https://httpbin.org/get'],
        env=Environment(),
    )
    assert program(args=args, env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:20:28.903230
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.client import collect_messages
    from httpie.config import Config
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
   

# Generated at 2022-06-17 20:20:32.305409
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    env = Environment()
    program(args, env)

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 20:21:01.186938
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.constants import DEFAULT_OPTIONS
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_SEPARATOR
    from httpie.output.streams import B

# Generated at 2022-06-17 20:21:03.526437
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)


if __name__ == '__main__':
    main()

# Generated at 2022-06-17 20:21:10.446319
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_items
    from httpie.cli.utils import get_response_stream
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_

# Generated at 2022-06-17 20:21:11.762730
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:21:20.312670
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.downloads import Downloader
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.streams import StderrBytesIO
    from httpie.output.streams import StdinBytesIO
    from httpie.output.streams import StdoutTextIOWrapper
    from httpie.output.streams import StderrTextIOWrapper

# Generated at 2022-06-17 20:21:31.861030
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins import AuthPlugin
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    import os
    import shutil
    import tempfile
    import unittest

    class MainTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 20:21:37.797351
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_registry
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type

    plugin_registry.register(HTTPBasicAuth)
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-17 20:21:49.321583
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPProxyPassAuth
    from httpie.plugins.builtin import HTTP2
    from httpie.plugins.builtin import HTTP3
    from httpie.plugins.builtin import HTTPie

# Generated at 2022-06-17 20:21:57.214275
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', '--download', '--output-file', 'test.txt', 'https://httpbin.org/get'])
    env = Environment()
    env.program_name = 'http'
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdout_isatty = sys.stdout.isatty()
    env.stderr_isatty = sys.stderr.isatty()
    env.config = None
    env.config_dir = None
    env.config_path = None
    env.col

# Generated at 2022-06-17 20:22:09.248257
# Unit test for function program
def test_program():
    import requests
    import httpie.cli.argtypes
    import httpie.cli.definition
    import httpie.cli.parser
    import httpie.context
    import httpie.downloads
    import httpie.output.writer
    import httpie.plugins.builtin.auth
    import httpie.plugins.builtin.core
    import httpie.plugins.builtin.downloads
    import httpie.plugins.builtin.form
    import httpie.plugins.builtin.generic_url
    import httpie.plugins.builtin.headers
    import httpie.plugins.builtin.http
    import httpie.plugins.builtin.json
    import httpie.plugins.builtin.output_options
    import httpie.plugins.builtin.pretty
    import httpie.plugins.builtin.session
    import httpie.plugins

# Generated at 2022-06-17 20:22:35.851309
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:22:42.545626
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import get_parser
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.client import collect_messages
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    import requests
    import os
    import sys
   