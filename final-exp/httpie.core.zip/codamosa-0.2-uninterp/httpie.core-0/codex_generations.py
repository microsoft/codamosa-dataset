

# Generated at 2022-06-17 20:13:18.125695
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-17 20:13:27.317524
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.utils import get_response_stream
    from httpie.utils import get_response_text
    from httpie.utils import is_windows
    from httpie.utils import is_valid_url
    from httpie.utils import parse_auth
    from httpie.utils import parse_items
    from httpie.utils import parse_key_value_input
    from httpie.utils import parse_querystring
    from httpie.utils import parse

# Generated at 2022-06-17 20:13:36.449048
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[])
    assert get_output_options(args, requests.PreparedRequest()) == (False, False)
    assert get_output_options(args, requests.Response()) == (False, False)

    args = argparse.Namespace(output_options=[OUT_REQ_HEAD])
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)
    assert get_output_options(args, requests.Response()) == (False, False)

    args = argparse.Namespace(output_options=[OUT_REQ_BODY])
    assert get_output_options(args, requests.PreparedRequest()) == (False, True)
    assert get_output_options(args, requests.Response()) == (False, False)


# Generated at 2022-06-17 20:13:47.139365
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-17 20:13:50.172524
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[OUT_REQ_HEAD, OUT_RESP_BODY])
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)
    assert get_output_options(args, requests.Response()) == (False, True)

# Generated at 2022-06-17 20:13:57.594122
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--check-status']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--check-status', '--download']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--check-status', '--download', '--download-resume']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:14:06.293707
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_registry
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LEN
    from httpie.output.streams import is_binary_response
    from httpie.output.streams import write_binary_response_to_output_stream
    from httpie.output.streams import write_binary_response_

# Generated at 2022-06-17 20:14:14.966031
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages

# Generated at 2022-06-17 20:14:25.819744
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import ParseResult
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus

    plugin_manager.clear()
    plugin_manager.load_installed_plugins()
    plugin_manager.register(HTTPBasicAuth)
    plugin_manager.register(PluginManager)

    args = parser.parse_args(
        args=['--auth-type=basic', '--auth=user:password', 'httpbin.org/basic-auth/user/password'],
        env=Environment(),
    )
    assert program(args=args, env=Environment()) == Exit

# Generated at 2022-06-17 20:14:34.532018
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY]
    assert get_output_options(args, requests.PreparedRequest()) == (True, True)
    assert get_output_options(args, requests.Response()) == (True, True)
    args.output_options = [OUT_REQ_HEAD, OUT_RESP_HEAD]
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)
    assert get_output_options(args, requests.Response()) == (True, False)
    args.output_options = [OUT_REQ_BODY, OUT_RESP_BODY]

# Generated at 2022-06-17 20:15:00.471325
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'httpbin.org', '--json'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:15:04.070730
# Unit test for function program
def test_program():
    args = ['--debug']
    env = Environment()
    exit_status = main(args, env)
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:15:14.421443
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPGSSAPIAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPNegotiateAuth
    from httpie.plugins.builtin import HTTPNtlmAuth
    from httpie.plugins.builtin import HTTPFileUpload

# Generated at 2022-06-17 20:15:18.204587
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:15:25.585809
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_registry
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type_raw
    from httpie.utils import get_response_type_raw_stream
    from httpie.utils import get_response_type_stream
    from httpie.utils import is_windows
    from httpie.utils import is_windows_stdout_redirected
    from httpie.utils import is_windows_stderr_redirected
    from httpie.utils import is_windows_stdin

# Generated at 2022-06-17 20:15:29.053831
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(
        args=['--json', 'https://httpbin.org/get'],
        env=Environment(),
    )
    program(args=args, env=Environment())

# Generated at 2022-06-17 20:15:32.675657
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    env = Environment()
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'], env=env)
    program(args=args, env=env)

# Generated at 2022-06-17 20:15:42.622058
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPAWSAuth
    from httpie.plugins.builtin import HTTPNtlmAuth
    from httpie.plugins.builtin import HTTPNegotiateAuth
    from httpie.plugins.builtin import HTTPTlsAuth
    from httpie.plugins.builtin import HTTPJ

# Generated at 2022-06-17 20:15:46.276325
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--json', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:15:47.405451
# Unit test for function program
def test_program():
    assert program(args=['--help'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:17:16.429243
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

if __name__ == '__main__':
    test_program()

# Generated at 2022-06-17 20:17:27.101617
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY]
    args.headers = []
    args.download = False
    args.download_resume = False
    args.output_file = None
    args.output_file_specified = False
    args.check_status = False
    args.follow = False
    args.quiet = False
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdout_isatty = sys.stdout.isatty()
    env

# Generated at 2022-06-17 20:17:37.092492
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.manager import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_body_bytes
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth

# Generated at 2022-06-17 20:17:45.325690
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager

    plugin_manager.load_installed_plugins()
    plugin_manager.register(HTTPBasicAuth)
    plugin_manager.register(HTTPiePlugin)
    plugin_manager.register(PluginManager)

# Generated at 2022-06-17 20:17:58.335295
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.output_options = []
    args.download = False
    args.download_resume = False
    args.output_file = None
    args.output_file_specified = False
    args.check_status = False
    args.follow = False
    args.quiet = False
    args.headers = []
    env = Environment()
    env.stdout_isatty = False
    env.stdin_encoding = 'utf-8'
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.config = None
    env.log_error = print
    program(args=args, env=env)

# Generated at 2022-06-17 20:18:08.087682
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.manager import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    import os
    import sys
    import tempfile
    import requests
    import pytest

    # Unit test for function main
    def test_main():
        from httpie.cli.definition import parser
        from httpie.context import Environment
        from httpie.plugins.manager import plugin_manager
        from httpie.status import ExitStatus
        from httpie.utils import get_response
        from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
        import os
        import sys
        import tempfile

# Generated at 2022-06-17 20:18:10.916829
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:18:17.718191
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import ParseResult
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info

    def get_args(args: List[str]) -> ParseResult:
        return parser.parse_args(args=args, env=Environment())

    def get_response(args: List[str]) -> requests.Response:
        return get_response_info(get_args(args))[0]

    def get_exit_status(args: List[str]) -> ExitStatus:
        return main(args=args, env=Environment())


# Generated at 2022-06-17 20:18:28.278538
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', '--traceback'])
    assert main(args=args) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', '--traceback', '--help'])
    assert main(args=args) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', '--traceback', '--version'])
    assert main(args=args) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', '--traceback', '--form', 'key=value'])

# Generated at 2022-06-17 20:18:38.858205
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.plugins.registry import plugin_manager
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:21:09.015823
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:21:18.752431
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:21:30.423049
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import JSONCompactFormatter
    from httpie.plugins.builtin import JSONPrettyFormatter
    from httpie.plugins.builtin import JSONFormatter

# Generated at 2022-06-17 20:21:36.856331
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    plugin_manager.register(HTTPBasicAuth)
    env = Environment(stdout=StdoutBytesIO(), stderr=StdoutBytesIO())
    args = parser.parse_args(args=['--debug'], env=env)
    assert main(args=['--debug'], env=env) == ExitStatus.SUCCESS
    args = parser.parse_args(args=['--traceback'], env=env)

# Generated at 2022-06-17 20:21:41.261028
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:21:51.945116
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.client import collect_messages
    from httpie.context import Environment
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.output.streams import StdoutBytesIO


# Generated at 2022-06-17 20:21:58.383796
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.downloads import Downloader
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.streams import StderrBytesIO
    from httpie.output.streams import StdinBytesIO
    from httpie.output.streams import StdoutTextIOWrapper
    from httpie.output.streams import StderrTextIOWrapper
    from httpie.output.streams import StdinTextIOWrapper

# Generated at 2022-06-17 20:22:02.138482
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:22:12.463074
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:22:24.235594
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.2"\n  }, \n  "origin": "103.233.76.226", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''
    assert env.log_debug.getvalue() == b''