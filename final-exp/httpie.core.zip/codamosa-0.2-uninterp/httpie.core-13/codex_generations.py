

# Generated at 2022-06-17 20:13:36.414541
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.3"\n  }, \n  "origin": "1.2.3.4", \n  "url": "https://httpbin.org/get"\n}\n'

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 20:13:47.137967
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:13:54.894428
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    import sys

# Generated at 2022-06-17 20:13:59.387714
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    plugin_manager.register(HTTPBasicAuth)
    args = parser.parse_args(['-v', '--auth', 'user:pass', 'https://httpbin.org/basic-auth/user/pass'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:14:09.694752
# Unit test for function program

# Generated at 2022-06-17 20:14:12.693274
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'http://httpbin.org/get'])
    env = Environment()
    env.program_name = 'http'
    program(args, env)

# Generated at 2022-06-17 20:14:24.044646
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback']) == ExitStatus.SUCCESS
    assert main(['http', '--debug', '--traceback', '--timeout=0']) == ExitStatus.ERROR_TIMEOUT
    assert main(['http', '--debug', '--traceback', '--max-redirects=0']) == ExitStatus.ERROR_TOO_MANY_REDIRECTS
    assert main(['http', '--debug', '--traceback', '--max-redirects=0', '--timeout=0']) == ExitStatus.ERROR_TIMEOUT

# Generated at 2022-06-17 20:14:33.278946
# Unit test for function main
def test_main():
    import unittest
    from httpie.cli.constants import DEFAULT_OPTIONS
    from httpie.cli.parser import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOT

# Generated at 2022-06-17 20:14:36.857146
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', '--debug', 'http://example.com'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:14:46.518988
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY

# Generated at 2022-06-17 20:15:17.570278
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:15:20.901051
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', '--headers', '--body', 'https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)

# Generated at 2022-06-17 20:15:26.312838
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS
    args = parser.parse_args(['--traceback'])
    assert main(args=args) == ExitStatus.ERROR
    args = parser.parse_args(['--traceback', '--debug'])
    assert main(args=args) == ExitStatus.ERROR
    args = parser.parse_args(['--debug', '--traceback'])
    assert main(args=args) == ExitStatus.ERROR
    args = parser.parse_args(['--debug', '--traceback', '--debug'])
    assert main(args=args) == ExitStatus.ERROR

# Generated at 2022-06-17 20:15:35.506464
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.downloads import Download

# Generated at 2022-06-17 20:15:38.340953
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:15:45.556117
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.3"\n  }, \n  "origin": "103.241.230.162", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''


# Generated at 2022-06-17 20:15:48.858284
# Unit test for function main
def test_main():
    # TODO: add test
    pass


# Generated at 2022-06-17 20:15:59.887729
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.utils import get_response_stream
    from httpie.utils import get_response_text
    from httpie.utils import get_response_type
    from httpie.utils import is_json
    from httpie.utils import is_pretty
    from httpie.utils import is_raw_response_type
    from httpie.utils import is_text_response_type
    from httpie.utils import is_verbose

# Generated at 2022-06-17 20:16:05.995583
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type

# Generated at 2022-06-17 20:16:09.276414
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:16:40.656976
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_registry
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type

    # noinspection PyTypeChecker
    plugin_registry.register(HTTPBasicAuth())
    # noinspection PyTypeChecker
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    config = Config(directory=DEFAULT_CONFIG_DIR)
    env = Environment(config=config)

# Generated at 2022-06-17 20:16:45.028163
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:16:47.217925
# Unit test for function main
def test_main():
    # TODO: Implement
    assert False

# Generated at 2022-06-17 20:16:53.933230
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message
    from httpie.status import ExitStatus
    from httpie.utils import get_response_body_bytes
    from httpie.downloads import Downloader
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth

# Generated at 2022-06-17 20:17:05.376040
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_range
    from httpie.utils import get_response_stream
    from httpie.utils import get_response_text
    from httpie.utils import get_response_writer
    from httpie.utils import is_json
    from httpie.utils import is_

# Generated at 2022-06-17 20:17:15.125895
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.constants import DEFAULT_OPTIONS
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.output.writer import write_stream
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_HELP
    from httpie.output.streams import is_binary_response

# Generated at 2022-06-17 20:17:25.629413
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_

# Generated at 2022-06-17 20:17:28.591718
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:17:32.898427
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['--debug'])
    env = Environment()
    assert program(args=args, env=env) == ExitStatus.SUCCESS
    assert program(args=['--debug'], env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:17:41.237055
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.3"\n  }, \n  "origin": "1.2.3.4", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''

# Generated at 2022-06-17 20:18:41.323211
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH_COLOR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH_COLOR_RESET

# Generated at 2022-06-17 20:18:51.783556
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_WIDTH
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_HEIGHT
    from httpie.output.streams import BINARY_SUP

# Generated at 2022-06-17 20:19:02.356524
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus

    args = parser.parse_args(args=[
        '--print=H',
        '--form',
        '--verbose',
        '--output=test.txt',
        'https://httpbin.org/post',
        'foo=bar',
        'baz=bar',
    ])
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin = io.StringIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False

# Generated at 2022-06-17 20:19:07.298032
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:19:11.365788
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', '--download', 'https://httpbin.org/get'])
    env = Environment()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:19:13.474909
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    main(args=args)

# Generated at 2022-06-17 20:19:18.903140
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', '--download', '--output-file', 'test.txt', 'https://httpbin.org/get'])
    env = Environment()
    env.stdout = open('test.txt', 'w')
    env.stderr = open('test.txt', 'w')
    env.stdin_encoding = 'utf-8'
    env.config.directory = 'test.txt'
    env.config.default_options = ['--debug', '--traceback', '--download', '--output-file', 'test.txt']
    env.config.default_options_specified = True
    env.config.default_options_override = True
    env.config.default_options_override_specified = True

# Generated at 2022-06-17 20:19:20.605540
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:19:26.270407
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.output.streams import is_binary_response
    from httpie.output.streams import write_binary_response_to_output_stream
    from httpie.output.streams import write_binary_response_to_output_stream

# Generated at 2022-06-17 20:19:35.866496
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    env = Environment()
    env.stdout = StdoutBytesIO()
    args = parser.parse_args(['https://httpbin.org/get'], env=env)
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:20:09.484730
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages

    args = parser.parse_args(args=['http://httpbin.org/get'], env=Environment())
    exit_status = program(args=args, env=Environment())
    assert exit_status == ExitStatus.SUCCESS

    args = parser.parse_args(args=['http://httpbin.org/get'], env=Environment())
    exit_status = program(args=args, env=Environment())

# Generated at 2022-06-17 20:20:19.631469
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.parser import get_parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO, StderrBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response_body_bytes
    from httpie.downloads import Downloader
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins import builtin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPAuth

# Generated at 2022-06-17 20:20:27.386934
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info

    plugin_manager.clear()
    plugin_manager.register(HTTPBasicAuth)
    plugin_manager.load_installed_plugins()

    env = Environment()
    env.config.directory = DEFAULT_CONFIG_DIR
    env.config.load()

    args = ['--debug', '--form', 'POST', 'http://httpbin.org/post', 'foo=bar', 'baz=bar']

# Generated at 2022-06-17 20:20:38.179766
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    import requests
    import sys
    import os
    import platform
    import argparse
    import pygments
    import httpie
    import requests
    import sys
    import os
    import platform
    import argparse
    import pygments
    import httpie

# Generated at 2022-06-17 20:20:41.596400
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:20:49.378250
# Unit test for function main
def test_main():
    import io
    import sys
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.context import Environment

    class MockStdin:
        def __init__(self, encoding):
            self.encoding = encoding

        def isatty(self):
            return False

    class MockStdout:
        def __init__(self):
            self.buffer = io.BytesIO()

        def isatty(self):
            return False

    class MockStderr:
        def __init__(self):
            self.buffer = io.BytesIO()

        def isatty(self):
            return False

    class MockArgv:
        def __init__(self, argv):
            self.argv = argv


# Generated at 2022-06-17 20:20:59.963858
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status

    plugin_manager.load_installed_plugins()
    args = parser.parse_args(
        args=['--download', '--output-file=test.txt', '--download-resume', '--check-status', '--follow', '--output-options=b', '--headers', 'Content-Type:text/plain', '--verbose', '--body', 'test'],
        env=Environment()
    )

# Generated at 2022-06-17 20:21:07.156498
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPClientCertAuth
    from httpie.plugins.builtin import HTTPAsciiCodec
    from httpie.plugins.builtin import HTTPIgnoreStdinPlugin
    from httpie.plugins.builtin import HTTPJSONDataDumper

# Generated at 2022-06-17 20:21:18.196743
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus

    plugin_manager.register(HTTPBasicAuth)
    env = Environment(
        config=Config(directory=DEFAULT_CONFIG_DIR),
        stdin=sys.stdin,
        stdin_isatty=sys.stdin.isatty(),
        stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(),
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
    )


# Generated at 2022-06-17 20:21:23.534317
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-17 20:21:58.991703
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_SEPARATOR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_SEPARATOR_LENGTH
    from httpie.output.streams import BINARY_SUPPRESSED_

# Generated at 2022-06-17 20:22:10.398405
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LEN
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LEN_STR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_STR
    from httpie.output.streams import BINARY_SUPPRESSED_NOT

# Generated at 2022-06-17 20:22:15.582056
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', '--traceback'])
    assert main(args=args) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', '--traceback', '--timeout', '1', 'https://httpbin.org/delay/2'])
    assert main(args=args) == ExitStatus.ERROR_TIMEOUT
    args = parser.parse_args(['--debug', '--traceback', '--max-redirects', '0', 'https://httpbin.org/redirect/1'])
    assert main(args=args) == ExitStatus.ERROR_TOO_MANY_RED

# Generated at 2022-06-17 20:22:24.866241
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus

    env = Environment()
    env.stdout = StdoutBytesIO()
    env.stderr = StdoutBytesIO()
    env.stdin = StdoutBytesIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.config.directory = '.'
    env.config.default_options = []
    env.config.default_options_spec = {}
    env.config.config_dir = '.'
    env.config.config_path = '.'

# Generated at 2022-06-17 20:22:28.046675
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'httpbin.org'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:22:30.837452
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:39.633627
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS
    assert main(['--debug']) == ExitStatus.SUCCESS
    assert main(['--help']) == ExitStatus.SUCCESS
    assert main(['--version']) == ExitStatus.SUCCESS
    assert main(['--traceback']) == ExitStatus.ERROR
    assert main(['--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['--traceback', '--debug', '--help']) == ExitStatus.SUCCESS
    assert main(['--traceback', '--debug', '--version']) == ExitStatus.SUCCESS
    assert main(['--traceback', '--debug', '--help', '--version']) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:42.975910
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    exit_status = program(args=args, env=Environment())
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:45.461316
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    assert main(args=args) == ExitStatus.SUCCESS