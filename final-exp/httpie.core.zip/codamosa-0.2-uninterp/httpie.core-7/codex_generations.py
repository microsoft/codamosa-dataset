

# Generated at 2022-06-17 20:13:50.379831
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_preferred_output_format
    from httpie.output.formatters.utils import get_preferred_style
    from httpie.output.formatters.utils import get_preferred_format

# Generated at 2022-06-17 20:13:57.741044
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PluginManager
    from httpie.output.streams import StdoutBytesIO, StderrBytesIO
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.cli.definition import parser
    from httpie.client import collect_messages
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PluginManager
   

# Generated at 2022-06-17 20:14:06.389423
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

# Generated at 2022-06-17 20:14:15.020375
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES

# Generated at 2022-06-17 20:14:25.901650
# Unit test for function program
def test_program():
    import io
    import sys
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message

    args = parser.parse_args(args=['--debug', '--form', 'POST', 'http://httpbin.org/post'], env=Environment())
    assert program(args=args, env=Environment()) == ExitStatus.SUCCESS

    args = parser.parse_args(args=['--debug', '--form', 'POST', 'http://httpbin.org/post'], env=Environment())
    assert program(args=args, env=Environment()) == ExitStatus

# Generated at 2022-06-17 20:14:34.591724
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    import os
    import shutil
    import tempfile
    import unittest

    class MainTestCase(unittest.TestCase):

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.config_dir = os.path.join(self.temp_dir, DEFAULT_CONFIG_DIR)
            os.mkdir(self.config_dir)

# Generated at 2022-06-17 20:14:44.593244
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.cli.parser import parser
    from httpie.cli.definition import parser
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArg

# Generated at 2022-06-17 20:14:59.226283
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.utils import get_response_as_json

    args = parser.parse_args(args=['--json', 'https://httpbin.org/get'])
    env = Environment()
    env.stdout = io.BytesIO()
    env.stderr = io.BytesIO()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:15:05.672059
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:15:16.960743
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response_info


# Generated at 2022-06-17 20:15:51.630374
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:15:56.611739
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:16:08.915657
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyBasicAuth
    from httpie.plugins.builtin import HTTPProxyDigestAuth
    from httpie.plugins.builtin import HTTPProxyBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyTokenAuth


# Generated at 2022-06-17 20:16:17.044743
# Unit test for function main
def test_main():
    import io
    import sys
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins import builtin
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins.registry import plugin_registry
    from httpie.status import ExitStatus

    def test_main_with_args(args: List[str], expected_exit_status: ExitStatus,
                            expected_stdout: str = '', expected_stderr: str = ''):
        stdout = io.StringIO()
        stderr = io.StringIO()
        env = Environment(stdout=stdout, stderr=stderr)
        exit_status = main(args=args, env=env)
        assert exit_status == expected_exit_status

# Generated at 2022-06-17 20:16:21.351198
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    plugin_manager.load_installed_plugins()
    env = Environment()
    args = parser.parse_args(args=['--auth-type=basic', '--auth=user:password', 'https://httpbin.org/basic-auth/user/password'], env=env)
    assert program(args=args, env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:16:25.094340
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--json', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:16:32.375723
# Unit test for function program
def test_program():
    import pytest
    import requests
    from httpie.cli.definition import parser
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message

    args = parser.parse_args(args=['https://httpbin.org/get'])
    env = Environment()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

    args = parser.parse_args(args=['https://httpbin.org/status/404'])
    env = Environment()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.ERROR_HTTP_4XX


# Generated at 2022-06-17 20:16:42.530152
# Unit test for function program
def test_program():
    import requests
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.status import ExitStatus

# Generated at 2022-06-17 20:16:51.379486
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins import AuthPlugin
    from httpie.status import ExitStatus
    from httpie.config import Config
    from httpie.cli.definition import parser
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import KeyValue, KeyValueArgType
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import KeyValue, KeyValueArgType
    from httpie.cli.definition import parser
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import KeyValue, KeyValueArgType


# Generated at 2022-06-17 20:17:03.407912
# Unit test for function program
def test_program():
    import io
    import sys
    import unittest
    from unittest.mock import patch
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_content_type
    from httpie.utils import get_response_text_encoding
    from httpie.utils import is_json
    from httpie.utils import is_text
    from httpie.utils import is_xml
    from httpie.utils import is_zip
    from httpie.utils import parse_json
    from httpie.utils import parse_xml

# Generated at 2022-06-17 20:17:34.722325
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    # Unit test for function main
    def test_main():
        from httpie.cli.constants import DEFAULT_CONFIG_DIR
        from httpie.context import Environment
        from httpie.plugins.builtin import HTTPBasicAuth
        from httpie.plugins.manager import PluginManager
        from httpie.plugins.registry import plugin_manager

# Generated at 2022-06-17 20:17:43.211851
# Unit test for function program
def test_program():
    import argparse
    import httpie.cli.definition
    import httpie.cli.parser
    import httpie.cli.utils
    import httpie.context
    import httpie.downloads
    import httpie.plugins.builtin.downloads
    import httpie.plugins.builtin.form
    import httpie.plugins.builtin.pretty
    import httpie.plugins.builtin.sessions
    import httpie.plugins.builtin.stream
    import httpie.plugins.builtin.upload
    import httpie.plugins.manager
    import httpie.plugins.registry
    import httpie.status
    import httpie.utils
    import httpie.utils.structures
    import httpie.utils.url
    import httpie.version
    import pygments
    import pygments.formatters
    import pygments.lex

# Generated at 2022-06-17 20:17:45.496785
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', '--json', 'http://httpbin.org/get'])
    assert program(args, Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:17:59.094008
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    plugin_manager.register(HTTPBasicAuth)
    args = parser.parse_args(['--auth-type=basic', '--auth=user:password', 'httpbin.org/basic-auth/user/password'])

# Generated at 2022-06-17 20:18:01.284467
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'http://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:18:09.955874
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPPassDigestAuth
    from httpie.plugins.builtin import HTTPPassBasicAuth
    from httpie.plugins.builtin import HTTPPassProxyAuth
    from httpie.plugins.builtin import HTTPPassTokenAuth

# Generated at 2022-06-17 20:18:18.850258
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message

    plugin_manager.clear()
    plugin_manager.load_installed_plugins()
    plugin_manager.register(HTTPBasicAuth)
    plugin_manager.register(PluginManager)

    env = Environment()
    args = parse_args(args=['--debug'], env=env)
    assert program(args=args, env=env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:18:24.892162
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus

    plugin_manager.clear()
    plugin_manager.register(HTTPBasicAuth)
    plugin_manager.load_installed_plugins()
    env = Environment()
    args = parser.parse_args(['--auth-type=basic', '--auth=user:pass', 'http://httpbin.org/basic-auth/user/pass'], env=env)
    assert program(args, env) == ExitStatus.SUCCESS

    plugin_manager.clear()
    plugin_manager.register(HTTPBasicAuth)
    plugin_

# Generated at 2022-06-17 20:18:31.915605
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.client import collect_messages
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager

# Generated at 2022-06-17 20:18:35.571449
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:19:26.383206
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--debug', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:19:35.868581
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    class TestEnvironment(Environment):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.stdin_isatty = True
            self.stdout_isatty = True
            self.is_windows = False

# Generated at 2022-06-17 20:19:46.401363
# Unit test for function main
def test_main():
    import pytest
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.cli.definition import parser
    from httpie.context import Environment

    args = parser.parse_args(args=['--debug'], env=Environment())
    assert main(args=['--debug']) == ExitStatus.SUCCESS

    args = parser.parse_args(args=['--traceback'], env=Environment())
    assert main(args=['--traceback']) == ExitStatus.ERROR

    args = parser.parse_args(args=['--output-options', OUT_REQ_HEAD, OUT_RESP_BODY], env=Environment())

# Generated at 2022-06-17 20:19:55.757208
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace()
    args.output_options = []
    args.download = False
    args.output_file = None
    args.output_file_specified = False
    args.download_resume = False
    args.headers = []
    args.follow = False
    args.check_status = False
    args.quiet = False
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:19:57.963084
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:20:05.894757
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH_COLOR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_COLOR
    from httpie.output.streams import BINARY_SUP

# Generated at 2022-06-17 20:20:07.668994
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:20:11.115422
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:20:21.069828
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:20:28.454099
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyAuthSession
    from httpie.plugins.builtin import HTTPProxyAuthSession
    from httpie.plugins.builtin import HTTPProxyAuthSession
    from httpie.plugins.builtin import HTTPProxyAuth

# Generated at 2022-06-17 20:21:53.960691
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePluginException
    from httpie.plugins.builtin import HTTPiePluginException
    from httpie.plugins.builtin import HTTPiePluginException
    from httpie.plugins.builtin import HTTPiePluginException
    from httpie.plugins.builtin import HTTPiePluginException
    from httpie.plugins.builtin import HTTPiePluginException
    from httpie.plugins.builtin import HTTPiePluginException
    from httpie.plugins.builtin import HTTPiePlugin

# Generated at 2022-06-17 20:22:00.269585
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)
    assert env.stdout.getvalue() == '{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.3"\n  }, \n  "origin": "127.0.0.1", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == ''

# Generated at 2022-06-17 20:22:05.255897
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)

# Generated at 2022-06-17 20:22:08.243811
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', '--traceback', '--download', 'https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)

# Generated at 2022-06-17 20:22:11.890669
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:13.664558
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:22:24.376425
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH_STR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_STR
    from httpie.output.streams import BINARY_SUP

# Generated at 2022-06-17 20:22:30.235050
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message
    from httpie.utils import get_response_stream
    from httpie.utils import is_windows
    from httpie.utils import is_json
    from httpie.utils import is_text
    from httpie.utils import is_verbose
    from httpie.utils import is_very_verbose
    from httpie.utils import parse_auth
    from httpie.utils import parse_items
    from httpie.utils import parse_key_value_

# Generated at 2022-06-17 20:22:39.172961
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_error_message

    plugin_manager.load_installed_plugins()


# Generated at 2022-06-17 20:22:46.711348
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
   