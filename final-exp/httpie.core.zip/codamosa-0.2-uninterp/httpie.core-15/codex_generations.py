

# Generated at 2022-06-17 20:13:05.866441
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:13:17.340158
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.writer import write_message
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.plugins.registry import plugin_manager
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.client import collect_messages
    import requests
    import os
    import sys
    import platform
    import argparse
    import pygments
    import pytest
    import io
    import os
    import sys
    import platform
    import pygments
    import pytest
    import io
    import os
    import sys
    import platform
    import pygments
   

# Generated at 2022-06-17 20:13:26.796605
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins import AuthPlugin
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LEN
    from httpie.output.streams import is_binary_response
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_bytes

# Generated at 2022-06-17 20:13:35.121651
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.2"\n  }, \n  "origin": "127.0.0.1", \n  "url": "https://httpbin.org/get"\n}\n'

# Generated at 2022-06-17 20:13:46.703777
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.writer import write_message
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.status import http_status_to_exit_status
    from httpie.utils import get_response_protocol
    from httpie.utils import get_response_status_line
    from httpie.utils import get_response_version

    env = Environment()
    env.stdout = StdoutBytesIO()
    env.stderr = StdoutBytesIO()
    env.config.directory = './tests/config'
    env.config.default_options = ['--form']
    env.config

# Generated at 2022-06-17 20:13:52.700860
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.plugins.manager import plugin_manager

    plugin_manager.load_installed_plugins()

    args = parser.parse_args(args=['--debug', '--traceback', '--follow', '--check-status', '--download', '--output=test.txt', '--download-resume', 'http://httpbin.org/get'])
    env = Environment()
    env.stdout = open('test.txt', 'wb')

# Generated at 2022-06-17 20:13:59.665550
# Unit test for function program
def test_program():
    import os
    import sys
    import tempfile
    import unittest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    class TestProgram(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.TemporaryDirectory()

# Generated at 2022-06-17 20:14:03.486546
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:14:12.776772
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type

# Generated at 2022-06-17 20:14:24.081219
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus

    args = parser.parse_args(args=['httpbin.org/get'])
    env = Environment(stdout=StdoutBytesIO())
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:15:02.711838
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.output_options = ['all']
    args.headers = {}
    args.download = False
    args.download_resume = False
    args.output_file = None
    args.output_file_specified = False
    args.check_status = False
    args.follow = False
    args.quiet = False
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdout_isatty = sys.stdout.isatty()
    env.stderr_isatty = sys.stderr.isatty()
    env.config = None
   

# Generated at 2022-06-17 20:15:11.582771
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response_data

    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment(stdout=StdoutBytesIO(), stderr=StdoutBytesIO())
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS
    assert get_response_data(env.stdout)['url'] == 'https://httpbin.org/get'

# Generated at 2022-06-17 20:15:17.132332
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args=args, env=env)
    assert env.stdout.getvalue() == '{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.3"\n  }, \n  "origin": "127.0.0.1", \n  "url": "https://httpbin.org/get"\n}\n'

# Generated at 2022-06-17 20:15:27.022225
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie import __version__ as httpie_version
    from httpie.plugins.registry import plugin_manager
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.client import collect_messages
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD

# Generated at 2022-06-17 20:15:35.946851
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus

    # noinspection PyUnresolvedReferences
    import httpie.cli.parser

    # noinspection PyUnresolvedReferences
    import httpie.cli.definition

    # noinspection PyUnresolvedReferences
    import httpie.cli.argtypes

    # noinspection PyUnresolvedReferences
    import httpie.cli.exceptions

    # noinspection PyUnresolvedReferences
    import httpie.cli.formatters

    # noinspection PyUnresolvedReferences
    import httpie.cli.utils

    # noinspection PyUnresolvedReferences
    import httpie.cli.argtypes

    # noins

# Generated at 2022-06-17 20:15:46.358063
# Unit test for function program
def test_program():
    import httpie.cli.parser
    import httpie.cli.definition
    import httpie.cli.argtypes
    import httpie.cli.exceptions
    import httpie.cli.formatters
    import httpie.cli.utils
    import httpie.cli.sessions
    import httpie.cli.downloads
    import httpie.cli.auth
    import httpie.cli.config
    import httpie.cli.output
    import httpie.cli.output.streams
    import httpie.cli.output.formatters
    import httpie.cli.output.writers
    import httpie.cli.output.colors
    import httpie.cli.output.theme
    import httpie.cli.output.theme.default
    import httpie.cli.output.theme.solarized

# Generated at 2022-06-17 20:15:53.019243
# Unit test for function main
def test_main():
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['http', '--debug', '--traceback', '--debug', '--traceback', '--debug']) == ExitStatus.ERROR

# Generated at 2022-06-17 20:15:56.824771
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:16:03.665435
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.config import Config
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.client import collect_messages
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.config import Config
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
   

# Generated at 2022-06-17 20:16:13.618263
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins.registry import plugin_registry
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins.registry import plugin_registry
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins.registry import plugin_registry
    from httpie.plugins.builtin import HTTPBasicAuth

# Generated at 2022-06-17 20:18:01.333094
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_config_dir
    from httpie.config import Config
    from httpie.output.streams import get_default_stdout
    from httpie.output.streams import get_default_stderr
    from httpie.output.streams import get_default_stdin
    from httpie.output.streams import get_default_stdin_encoding
    from httpie.output.streams import get_default_stdout_isatty
    from httpie.output.streams import get_default_stderr_isatty
    from httpie.output.streams import get

# Generated at 2022-06-17 20:18:09.773977
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/1.0.3"\n  }, \n  "origin": "118.69.76.212", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''


# Generated at 2022-06-17 20:18:13.210262
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-17 20:18:16.155477
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:18:27.043861
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    env = Environment()
    program(args, env)
    assert env.stdout.getvalue() == b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Accept-Encoding": "gzip, deflate", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/0.9.9"\n  }, \n  "origin": "127.0.0.1", \n  "url": "https://httpbin.org/get"\n}\n'
    assert env.stderr.getvalue() == b''


# Generated at 2022-06-17 20:18:38.577758
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.output.streams import is_binary_response
    from httpie.output.streams import write_binary_response_to_output_stream
    from httpie.output.streams import write_binary_response_to_stdout

# Generated at 2022-06-17 20:18:50.775958
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'http://www.google.com'])
    env = Environment()
    program(args, env)

# Generated at 2022-06-17 20:18:57.001086
# Unit test for function main
def test_main():
    import io
    import sys
    from httpie.cli.definition import parser

    def get_args(args: List[str]) -> argparse.Namespace:
        return parser.parse_args(args=args, env=Environment())

    def get_exit_status(args: List[str]) -> ExitStatus:
        return main(args=args, env=Environment())

    def get_stdout(args: List[str]) -> str:
        env = Environment()
        env.stdout = io.StringIO()
        main(args=args, env=env)
        return env.stdout.getvalue()

    def get_stderr(args: List[str]) -> str:
        env = Environment()
        env.stderr = io.StringIO()
        main(args=args, env=env)

# Generated at 2022-06-17 20:19:00.045717
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    args = parser.parse_args(['https://httpbin.org/get'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-17 20:19:10.843105
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type_raw
    from httpie.utils import get_response_type_raw_stream
    from httpie.utils import get_response_type_stream
    from httpie.utils import get_response_type_stream_raw
    from httpie.utils import get_response_type_stream_raw_stream
    from httpie.utils import get_response_type_stream_stream
    from httpie.utils import get_response_type_stream