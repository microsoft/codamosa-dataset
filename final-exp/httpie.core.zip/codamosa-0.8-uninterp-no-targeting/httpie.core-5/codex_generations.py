

# Generated at 2022-06-21 13:50:58.601199
# Unit test for function program
def test_program():
    assert program(args=0, env=0) == 1

# Generated at 2022-06-21 13:51:10.173082
# Unit test for function get_output_options

# Generated at 2022-06-21 13:51:16.143858
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['GET', 'https://httpbin.org'])
    request = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args, request)
    assert with_headers == True
    assert with_body == False

    response = requests.Response()
    with_headers, with_body = get_output_options(args, response)
    assert with_headers == True
    assert with_body == True

test_get_output_options()

# Generated at 2022-06-21 13:51:25.713084
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import locale
    import sys
    from click.testing import CliRunner
    from httpie.cli.parser import parser
    import httpie.plugins
    httpie.plugins.load_installed_plugins()

    runner = CliRunner()
    args = ['http', '--json', 'httpie.org']
    result = runner.invoke(parser.parse_args, args=args)
    assert result.exit_code == ExitStatus.SUCCESS
    stdin_encoding = locale.getpreferredencoding(do_setlocale=False) or sys.getfilesystemencoding()
    assert result.output.encode(args[-1].encode(stdin_encoding))

# Generated at 2022-06-21 13:51:34.520421
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['foo', b'bar'], 'ascii') == ['foo', 'bar']
    assert decode_raw_args([b'foo', 'bar'], 'ascii') == ['foo', 'bar']
    assert decode_raw_args([b'foo', b'bar'], 'utf8') == ['foo', 'bar']
    assert decode_raw_args([b'f\u00e4o', b'b\u00e4r'], 'utf8') == [
        'fäo', 'bär']

# Generated at 2022-06-21 13:51:39.286176
# Unit test for function main
def test_main():
    class Env:
        program_name = 'http'
        stdin_encoding = 'UTF-8'
        stderr = sys.stderr
        config = type('Config', (), {
            'directory': '~/.httpie',
            'default_options': [],
        })()

    main(args=['--debug'], env=Env())

# Generated at 2022-06-21 13:51:49.184200
# Unit test for function program
def test_program():
    import sys
    # construct test environment
    class environment():
        def __init__(self):
            self.config = 'config'
            self.stdout = sys.stdout
            self.stderr = sys.stderr
            self.stdin = sys.stdin
            self.stdin_encoding = 'UTF-8'
            self.stdout_isatty = False
            self.stderr_isatty = False
            self.stdin_isatty = True

    # construct test argument
    class TestArgument:
        def __init__(self):
            self.default_options = []
            self.debug = False
            self.download = False
            self.download_resume = False
            self.headers = {}

# Generated at 2022-06-21 13:51:58.263246
# Unit test for function decode_raw_args
def test_decode_raw_args():
    class FakeStdin:
        encoding = 'ascii'
        def __init__(self):
            self.written_data = []
        def write(self, data):
            self.written_data.append(data)
    stdin = FakeStdin()
    env = Environment(stdin=stdin, stderr=stdin,
                      stdout=stdin)
    args = [arg.encode(env.stdin_encoding) for arg in ["foo", "bär"]]
    decoded = decode_raw_args(args, env.stdin_encoding)
    assert decoded == ["foo", "bär"]

# Generated at 2022-06-21 13:52:01.982325
# Unit test for function main
def test_main():
    exit_status = main()
    if exit_status != ExitStatus.SUCCESS:
        raise SystemExit(exit_status)
    print("Unit test for function main passed")

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-21 13:52:06.150462
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.context import Environment
    from io import StringIO

    output = StringIO()
    env = Environment(stdout=output, stderr=output)
    print_debug_info(env)
    assert isinstance(output.getvalue(), str)

# Generated at 2022-06-21 13:52:37.462768
# Unit test for function main
def test_main():
    print(main(args=['httpie', '--debug'], env=Environment()))



# Generated at 2022-06-21 13:52:42.527745
# Unit test for function program
def test_program():
    args = ['http', 'httpie.org']
    env = Environment()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS
    #assert program(args, env) == 0
    #assert program(args, env) == 0


# Generated at 2022-06-21 13:52:52.728106
# Unit test for function get_output_options
def test_get_output_options():
    arg = argparse.Namespace(output_options=[1])
    assert(get_output_options(arg, requests.PreparedRequest()) == (True, False))
    assert(get_output_options(arg, requests.Response()) == (False, False))
    arg.output_options = [2]
    assert(get_output_options(arg, requests.Response()) == (False, True))
    arg.output_options = [3]
    assert(get_output_options(arg, requests.PreparedRequest()) == (True, True))
    assert(get_output_options(arg, requests.Response()) == (True, True))
    arg.output_options = [4]
    assert(get_output_options(arg, requests.PreparedRequest()) == (False, False))
    arg.output_options = [5]
   

# Generated at 2022-06-21 13:52:59.526163
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options=[OUT_REQ_HEAD, OUT_RESP_HEAD, OUT_REQ_BODY, OUT_RESP_BODY],
    )
    message = requests.PreparedRequest()
    assert get_output_options(args=args, message=message) == (True, True)

    message = requests.Response()
    assert get_output_options(args=args, message=message) == (True, True)

# Generated at 2022-06-21 13:53:03.151594
# Unit test for function print_debug_info
def test_print_debug_info():
    class Test:
        def __repr__(self):
            return "Test output"

        def write(self, x):
            print(x)

    test = Test()

    print_debug_info(test)

# Generated at 2022-06-21 13:53:10.917782
# Unit test for function get_output_options
def test_get_output_options():
    dummy_args = argparse.Namespace()
    dummy_args.output_options = {'b', 'B'}

    # Test for prepared request
    dummy_prepared_request = requests.PreparedRequest()
    with_headers, with_body = get_output_options(dummy_args, dummy_prepared_request)
    assert with_headers
    assert with_body

    # Test for response
    dummy_response = requests.Response()
    with_headers, with_body = get_output_options(dummy_args, dummy_response)
    assert not with_headers
    assert with_body

# Initialize logging early
# noinspection PyUnresolvedReferences
import httpie.logging

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 13:53:17.372394
# Unit test for function get_output_options
def test_get_output_options():
    class MockArgs:
        def __init__(self):
            self.output_options = []
        def __getitem__(self, key):
            return self.output_options[key]
        def __setitem__(self, key, value):
            self.output_options[key] = value
    class MockMessage:
        pass
    msg = MockMessage()
    args = MockArgs()
    args[OUT_REQ_HEAD] = True
    args[OUT_REQ_BODY] = True
    assert get_output_options(args, msg) == (False, False)
    msg = MockMessage()
    msg.status_code = 404
    args = MockArgs()
    args[OUT_RESP_HEAD] = True
    args[OUT_RESP_BODY] = True
    assert get_output_options

# Generated at 2022-06-21 13:53:21.062981
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    env = Environment()
    env.stderr = StringIO()
    print_debug_info(env)
    assert env.stderr.getvalue()

# Generated at 2022-06-21 13:53:28.772073
# Unit test for function program
def test_program():
    a = ['--download /Users/yutakatsumura/Desktop/1','https://api.github.com/repos/httpie/httpie/commits']
    # b = ['--download /Users/yutakatsumura/Desktop/1','echo','ひらがな','日本語']
    c = ['--follow','--check-status','https://google.com']
    d = ['--download /Users/yutakatsumura/Desktop/1','https://upload.wikimedia.org/wikipedia/commons/d/dd/'
         'H264_encoder_decoder.png']
    e = ['--download /Users/yutakatsumura/Desktop/1','https://raw.githubusercontent.com/httpie/httpie/master/'
         'httpie/client.py']

# Generated at 2022-06-21 13:53:37.038568
# Unit test for function get_output_options
def test_get_output_options():
    #header flags should be chosen over general ones
    args = argparse.Namespace(output_options=['body', 'reqheaders', 'respheaders'])
    message = requests.PreparedRequest()
    result = get_output_options(args, message)
    assert result[0]
    assert not result[1]

    message = requests.Response()
    result = get_output_options(args, message)
    assert result[0]
    assert not result[1]

    #general flags should be chosen if header flags not present
    args = argparse.Namespace(output_options=['body', 'headers'])
    message = requests.PreparedRequest()
    result = get_output_options(args, message)
    assert result[0]
    assert result[1]

    message = requests.Response()
    result = get_output

# Generated at 2022-06-21 13:53:57.908909
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from tempfile import TemporaryDirectory
    from httpie.context import Environment

    class StdIO:
        def __init__(self):
            self.buffer = StringIO()

    with TemporaryDirectory() as temp_dir:
        env = Environment(
            stdin=StdIO(),
            stdout=StdIO(),
            stderr=StdIO(),
            config_dir=temp_dir,
        )
        print_debug_info(env)
        env.stderr.buffer.seek(0)
        env.stderr.buffer.read()

# Generated at 2022-06-21 13:53:59.969091
# Unit test for function main
def test_main():
    main(["http", "https://www.google.com/"])
    main(["http", "--debug"])



# Generated at 2022-06-21 13:54:04.856494
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = decode_raw_args(['test', b'some', 'other', b'args'], 'utf-8')
    assert len(args) == 4
    assert args[0] == 'test'
    assert args[1] == 'some'
    assert args[2] == 'other'
    assert args[3] == 'args'

# Generated at 2022-06-21 13:54:05.784848
# Unit test for function program
def test_program():
    assert program() == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:54:12.130389
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = []
    msg = requests.PreparedRequest()
    assert(get_output_options(args, msg) == (False, False))
    args.output_options = [OUT_REQ_HEAD, OUT_RESP_BODY]
    assert(get_output_options(args, msg) == (True, False))
    args.output_options = [OUT_RESP_BODY, OUT_REQ_HEAD]
    assert(get_output_options(args, msg) == (True, False))
    msg = requests.Response()
    assert(get_output_options(args, msg) == (False, True))

# Generated at 2022-06-21 13:54:23.151851
# Unit test for function main
def test_main():
    assert main(["C:\\Users\\John\\Anaconda3\\Scripts\\http", "--version"]) == ExitStatus.SUCCESS
    assert main(["C:\\Users\\John\\Anaconda3\\Scripts\\http", "--debug"]) == ExitStatus.SUCCESS
    assert main(["C:\\Users\\John\\Anaconda3\\Scripts\\http", "--help"]) == ExitStatus.SUCCESS
    assert main(["C:\\Users\\John\\Anaconda3\\Scripts\\http", "--traceback"]) == ExitStatus.ERROR
    assert main(["C:\\Users\\John\\Anaconda3\\Scripts\\http", "http://api.github.com/repos/jakubroztocil/httpie/commits"]) == ExitStatus.SUCCESS

# Unit

# Generated at 2022-06-21 13:54:33.349862
# Unit test for function print_debug_info
def test_print_debug_info():
    import os
    from httpie.context import Environment
    try:
        import unittest.mock as mock
    except ImportError:
        import mock
    env = Environment()
    env.stderr = mock.MagicMock()
    print_debug_info(env)
    env.stderr.write.assert_any_call('HTTPie %s\n' % __version__)
    env.stderr.write.assert_any_call('Requests %s\n' % requests.__version__)
    env.stderr.write.assert_any_call('Pygments %s\n' % pygments.__version__)
    env.stderr.write.assert_any_call('Python %s\n' % sys.version)

# Generated at 2022-06-21 13:54:42.088912
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[OUT_REQ_HEAD,OUT_REQ_BODY,OUT_RESP_HEAD,OUT_RESP_BODY])
    request = requests.PreparedRequest()
    response = requests.Response()
    assert get_output_options(args, request) == (True, True)
    assert get_output_options(args, response) == (True, True)
    args = argparse.Namespace(output_options=[OUT_REQ_HEAD,OUT_RESP_HEAD])
    assert get_output_options(args, request) == (True, False)
    assert get_output_options(args, response) == (True, False)
    args = argparse.Namespace(output_options=[OUT_REQ_BODY,OUT_RESP_BODY])
    assert get

# Generated at 2022-06-21 13:54:45.829784
# Unit test for function decode_raw_args
def test_decode_raw_args():
    print(type(sys.argv[1]))
    print(decode_raw_args(sys.argv, 'utf-8'))

if __name__ == '__main__':
    #test_decode_raw_args()
    main()

# Generated at 2022-06-21 13:54:48.723210
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a', b'b'.decode('utf-8'), 'c'], 'utf-8') == ['a', 'b', 'c']

# Generated at 2022-06-21 13:55:18.533035
# Unit test for function main
def test_main():
    import os
    import tempfile
    env=Environment()
    url=tempfile.gettempdir()+'/cookies.txt'

# Generated at 2022-06-21 13:55:21.360015
# Unit test for function program
def test_program():
    """
    function program test
    """
    exit_status = program(args=sys.argv, env=Environment())
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:55:33.401391
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import pytest
    from httpie.context import Environment
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.args import CaseInsensitiveNamespace
    from httpie.config import Config, ConfigDict
    env = Environment()
    env.stdin_encoding = 'utf8'
    assert decode_raw_args(['k', 'v'], env.stdin_encoding) == ['k', 'v']
    assert decode_raw_args(['k', 'v'], 'ascii') == ['k', 'v']
    assert decode_raw_args(['k', b'v'], 'ascii') == ['k', 'v']
    assert decode_raw_args(['k', b'v'], 'utf8') == ['k', 'v']

# Generated at 2022-06-21 13:55:41.267837
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    assert env.stderr.getvalue() == 'HTTPie 1.0.1\n' \
                                    'Requests 2.19.1\n' \
                                    'Pygments 2.2.0\n' \
                                    'Python 3.7.0\n' \
                                    '/Library/Frameworks/Python.framework/Versions/3.7/bin/python3\n' \
                                    'Darwin 18.0.0\n\n\n' \
                                    '<httpie.context.Environment object at 0x10c6a3588>\n'



# Generated at 2022-06-21 13:55:49.400858
# Unit test for function main
def test_main():
    import io
    import pytest

    args = ['-v', 'GET', 'httpbin.org/get', 'hello=World']
    stdin = io.BytesIO(b'content')
    stdout = io.BytesIO()
    stderr = io.BytesIO()

    main(args=args, env=Environment(stdin=stdin, stdout=stdout, stderr=stderr))
    assert stderr.getvalue() == ''
    assert stdout.getvalue().count(b'\n') == 9
    stdout.seek(0)
    parsed_request_line, parsed_headers, parsed_body = [next(stdout).decode() for _ in range(3)]
    assert parsed_request_line == 'GET /get HTTP/1.1\n'

# Generated at 2022-06-21 13:55:56.426407
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY]

    # requests.PreparedRequest
    msg = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args=args, message=msg)
    assert with_headers
    assert with_body

    # requests.Response
    msg = requests.Response()
    with_headers, with_body = get_output_options(args=args, message=msg)
    assert not with_headers
    assert not with_body

# Generated at 2022-06-21 13:56:07.500923
# Unit test for function main
def test_main():
    # Test case 1 Test help argument
    assert main(['http', '--help']) == ExitStatus.SUCCESS

    # Test case 2 Test empty argument
    assert main([]) == ExitStatus.ERROR

    # Test case 3 Test no such file
    assert main(['http', '"https://github.com/chancezhang/httpie/blob/master/setup.py"']) == ExitStatus.SUCCESS

    # Test case 4 Test download
    assert main(['http', '"https://github.com/chancezhang/httpie/blob/master/setup.py"', '--download']) == ExitStatus.SUCCESS
    # TODO: Need unit test for download file
    # TODO: We can check the size of the downloaded file

    # Test case 5 Test no such handler

# Generated at 2022-06-21 13:56:09.454452
# Unit test for function main
def test_main():
    pass



# Generated at 2022-06-21 13:56:18.336288
# Unit test for function decode_raw_args
def test_decode_raw_args():
    def helper(args: List[Union[str, bytes]], encoding: str, expected_output: List[str]) -> None:
        output = decode_raw_args(args, encoding)
        assert output == expected_output

    helper([], 'utf-8', [])
    helper([b'asdf'], 'utf-8', ['asdf'])
    helper([b'\xc3\xa5', 'asdf'], 'utf-8', ['å', 'asdf'])
    helper([b'\xc3\xa5', 'asdf'], 'utf-16', ['å', 'asdf'])

# Generated at 2022-06-21 13:56:26.180940
# Unit test for function print_debug_info
def test_print_debug_info():
    class Environment(object):

        class Config(object):

            class Colors(object):

                httpie_colors = {}
                pygments_colors = {}
                term_support = False

            colors = Colors()
            default_options = []
            default_implicit_content_type = None
            directory = None
            config_file = None
            config_dir = None
            config_file_path = None
            netrc_file = None
            netrc_file_path = None
            config_override = {}
            max_redirects = 10
            opt_history = False
            trim_ok = False
            download_dir = None
            follow_redirects = True

        class Style(object):

            class Attributes(object):

                def __init__(self):
                    self.reset = False

# Generated at 2022-06-21 13:57:27.447843
# Unit test for function get_output_options
def test_get_output_options():
    # Test get_output_options returns properly with a request
    args = argparse.Namespace(
        output_options=[
            OUT_REQ_HEAD
        ]
    )
    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (True, False)

    # Test get_output_options returns properly with a response
    args = argparse.Namespace(
        output_options=[
            OUT_RESP_BODY
        ]
    )
    message = requests.Response()
    message.status_code = 200
    assert get_output_options(args, message) == (False, True)

# Generated at 2022-06-21 13:57:29.867848
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a', b'b', 'c'], 'ascii') == ['a', 'b', 'c']

# Generated at 2022-06-21 13:57:41.020637
# Unit test for function main
def test_main():
    assert main(['http', 'httpie.org'])==0
    assert main(['http', 'httpie.org/get']) == 0
    assert main(['http', 'httpie.org/get', '--verbose']) == 0
    assert main(['http', 'httpie.org/post', '--verbose']) == 0
    assert main(['http', 'httpie.org/get', '--check-status']) == 0
    assert main(['http', 'httpie.org/get', '--download']) == 0
    assert main(['http', 'httpie.org/get', '--download', '--output=1.txt']) == 0
    assert main(['http', 'httpie.org/get', '--download', '--output=-']) == 0

# Generated at 2022-06-21 13:57:52.089025
# Unit test for function get_output_options
def test_get_output_options():
    env = Environment()
    args = argparse.Namespace(
        output_options="all",
        follow=True,
        timeout=30,
        max_redirects=10,
        download=False,
        output_file=None,
        output_file_specified=False,
        check_status=True,
        quiet=False,
    )
    s = requests.Session()
    headers = {'Accept': 'application/json'}
    stream = open('test_get_output_options.txt', 'r')
    r = s.prepare_request(requests.Request(method='GET', url='https://httpbin.org/get', headers=headers))
    assert get_output_options(args=args, message=r) == (True, True)
    r = s.send(r, stream=stream)

# Generated at 2022-06-21 13:57:58.763105
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'HTTPie'], 'utf-8') == ['HTTPie']
    assert decode_raw_args(['HTTPie'], 'utf-8') == ['HTTPie']
    assert decode_raw_args([b'HTTPie', 'HTTPie'], 'utf-8') == ['HTTPie', 'HTTPie']
    assert decode_raw_args(['HTTPie', b'HTTPie'], 'utf-8') == ['HTTPie', 'HTTPie']

# Generated at 2022-06-21 13:58:09.572606
# Unit test for function print_debug_info
def test_print_debug_info():
    class FakeStderr:
        _txt = str()

        def write(self, txt: str) -> None:
            self._txt += txt

        def getvalue(self) -> str:
            return self._txt

    fake_stderr = FakeStderr()
    print_debug_info(env=Environment(stderr=fake_stderr))
    txt = fake_stderr.getvalue()
    assert f'HTTPie {httpie_version}\n' in txt
    assert f'Requests {requests_version}\n' in txt
    assert f'Pygments {pygments_version}\n' in txt
    assert f'Python {sys.version}\n' in txt
    assert sys.executable in txt

# Generated at 2022-06-21 13:58:17.170026
# Unit test for function decode_raw_args

# Generated at 2022-06-21 13:58:28.838273
# Unit test for function main
def test_main():
    def main_factory(env_arg=None):
        def new_main(args):
            return main(args, env_arg)
        return new_main

    from httpie.cli.constants import UNICODE_EMOJI
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.downloads import FakeDownload

    for IntegerExitStatus in [ExitStatus, int]:
        env = Environment(stdin_isatty=False)
        env.stdout.isatty = False
        env.stderr.isatty = False
        env.stdout = FakeDownload()
        env.stderr = FakeDownload()
        new_main = main_factory(env)
        new_main(['--debug'])
        assert env.stdout.getvalue

# Generated at 2022-06-21 13:58:33.745576
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_RESP_BODY]
    msg = requests.PreparedRequest()
    assert get_output_options(args, msg) == (False, False)

    msg = requests.Response()
    assert get_output_options(args, msg) == (False, True)



# Generated at 2022-06-21 13:58:36.808866
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = [b'test', b'-b', b'test']
    stdin_encoding = 'utf-8'
    assert decode_raw_args(args, stdin_encoding) == ['test', '-b', 'test']
    args = [b'test', b'\xe2\x82\xac', b'test']
    stdin_encoding = 'utf-8'
    assert decode_raw_args(args, stdin_encoding) == ['test', '€', 'test']

# Generated at 2022-06-21 13:59:53.748987
# Unit test for function program
def test_program():
    import argparse
    from httpie.cli.parser import default_options
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.defaults import DEFAULT_OUTPUT_OPTIONS


# Generated at 2022-06-21 13:59:56.866332
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--debug', 'httpbin.org'])
    env = Environment()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-21 14:00:05.656065
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['\u041f\u0440\u0438\u0432\u0456\u0442'],
                           'utf-8') == ['Привіт']
    assert decode_raw_args([b'\xe8\xb7\xaf\xe7\x94\xb1'],
                           'utf-8') == ['路由']
    assert decode_raw_args([b'\xe8\xb7\xaf\xe7\x94\xb1', 'Привіт', 'foo/bar'],
                           'utf-8') == ['路由', 'Привіт', 'foo/bar']

# Generated at 2022-06-21 14:00:12.503543
# Unit test for function program
def test_program():
    from httpie.cli.parser import parse_args
    from httpie.cli.constants import DEFAULT_OPTIONS
    env = Environment()
    args = parse_args(args=DEFAULT_OPTIONS)
    args.headers = {'Content-Type': 'application/json'}
    args.verbose = True
    args.url = 'https://httpbin.org/post'
    args.data = '{"name": "yuan"}'
    program(args, env)

# Generated at 2022-06-21 14:00:23.664725
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = [
        b'--option',
        b'\xe4\xf6\xfc',
        b'--',
        b'\xe4\xf6\xfc',
        b'hello',
        b'\xe4\xf6\xfc',
    ]
    assert decode_raw_args(args, 'latin1') == [
        '--option',
        '\xe4\xf6\xfc',
        '--',
        '\xe4\xf6\xfc',
        'hello',
        '\xe4\xf6\xfc',
    ]

# Generated at 2022-06-21 14:00:26.971235
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert ['foo'] == decode_raw_args(['foo'], stdin_encoding='ascii')
    assert ['\u2014'] == decode_raw_args(
        ['\xe2\x80\x94'], stdin_encoding='utf8')

# Generated at 2022-06-21 14:00:32.064492
# Unit test for function program
def test_program():
    args = argparse.Namespace(config_dir="/home/jsun/.httpie", config_file=None, default_options=None, debug=False,
                              follow=True, headers=None, ignore_stdin=False, output_file=None, output_file_specified=False,
                              output_options=['h', 'b'], download=False, download_resume=False, quiet=False, traceback=False,
                              styles=[])
    env = Environment()
    program(args, env)