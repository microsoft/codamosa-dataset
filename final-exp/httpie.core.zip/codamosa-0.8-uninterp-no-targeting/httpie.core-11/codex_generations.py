

# Generated at 2022-06-21 13:51:24.296401
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options=[],
    )

    message = requests.PreparedRequest()
    get_output_options(args=args, message=message)

    message = requests.Response()
    get_output_options(args=args, message=message)



# Generated at 2022-06-21 13:51:27.344795
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['help', b'arg'], 'utf-8') == ['help', 'arg']

# Generated at 2022-06-21 13:51:28.136450
# Unit test for function print_debug_info
def test_print_debug_info():
    return

# Generated at 2022-06-21 13:51:39.276484
# Unit test for function main
def test_main():
    # Dummy values for main
    args = ['HTTPie']
    env = Environment()
    env.config.directory = '/Users/vismaya/PycharmProjects/httpie/httpie'
    env.config.default_options = []
    env.config.default_options = env.config.default_options + ['--output=json']
    env.stdin_isatty = False
    env.stdin_encoding = 'utf-8'
    env.stdout_isatty = False
    env.stdout_missing_encoding_warning = False
    env.stdout_encoding = 'utf-8'
    env.stdout_raw = sys.stdout
    env.stdout_fileno = sys.stdout.fileno()
    env.stderr = sys.stderr
    env

# Generated at 2022-06-21 13:51:44.198055
# Unit test for function main
def test_main():
    assert main(args=['main', 'GET', 'github.com']) == ExitStatus.SUCCESS
    assert main(args=['main', 'GET', 'github.com', '-vb']) == ExitStatus.SUCCESS
    assert main(args=['main', 'GET', 'github.com', '-v']) == ExitStatus.SUCCESS
    assert main(args=['main', 'GET', 'github.com', '--traceback', '--form', 'abc']) == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:51:55.816042
# Unit test for function print_debug_info
def test_print_debug_info():
    # arrange
    import io
    import mock
    import os
    import platform
    import sys
    import unittest

    stdout_mock = mock.MagicMock()
    stdout_mock.write = mock.MagicMock()
    stdout_mock.writelines = mock.MagicMock()
    platform_mock = mock.MagicMock()
    platform_mock.system = mock.MagicMock(return_value='MacOS')
    platform_mock.release = mock.MagicMock(return_value='Mojave')
    sys_mock = mock.MagicMock()
    sys_mock.executable = mock.MagicMock()
    sys_mock.version = mock.MagicMock()
    os_mock = mock.MagicMock()
    os_mock.path

# Generated at 2022-06-21 13:52:07.356923
# Unit test for function print_debug_info
def test_print_debug_info():
    _stdin = io.StringIO()
    _stdout = io.StringIO()
    _stderr = io.StringIO()
    env = Environment(
        stdin=_stdin,
        stdout=_stdout,
        stderr=_stderr,
    )
    print_debug_info(env)

# Generated at 2022-06-21 13:52:07.971566
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-21 13:52:14.071470
# Unit test for function program
def test_program():
    from httpie.cli.parser import parse_args
    from httpie.config import create_config_dir

    create_config_dir()
    args = ['-m', 'GET', 'https://httpbin.org/get']
    args = parse_args(args)
    assert program(args, []) == 0
    args = ['-m', 'GET', 'https://httpbin.org/status/404']
    args = parse_args(args)
    assert program(args, []) == 1
    args = ['-m', 'GET', 'https://httpbin.org/status/404']
    args = parse_args(args)
    assert program(args, []) == 1

# Generated at 2022-06-21 13:52:21.837450
# Unit test for function program
def test_program():
    req = requests.PreparedRequest()
    req.method = 'GET'
    req.url = 'http://httpbin.org/get'
    resp = requests.Response()
    env = Environment()
    resp.url = 'http://httpbin.org/get'
    resp.raw = requests.packages.urllib3.HTTPResponse()
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY]
    args.check_status = False
    args.follow = False
    args.output_file = None
    args.output_file_specified = False
    args.download = False
    args.download_resume = False
    args.headers = ''
    args.quiet

# Generated at 2022-06-21 13:52:49.356630
# Unit test for function main
def test_main():
    r1 = main(['--debug'])


# Generated at 2022-06-21 13:52:59.731515
# Unit test for function main
def test_main():
    from httpie.client import main as client_main

    assert main([b'http', b'--headers', b'hi']) == client_main([b'http', b'--headers', b'hi'])
    assert main([b'--debug', b'http']) == ExitStatus.SUCCESS
    assert main([b'--debug']) == ExitStatus.SUCCESS
    assert main([b'--debug', b'--json', b'--form', b'http://json-form.org']) == ExitStatus.SUCCESS
    assert main([b'--debug', b'--traceback', b'http']) == ExitStatus.ERROR
    assert main([b'--debug', b'--traceback', b'--json', b'--form', b'http://json-form.org']) == ExitStatus.ERROR


# Generated at 2022-06-21 13:53:09.001861
# Unit test for function get_output_options
def test_get_output_options():
    env = Environment()
    args = argparse.Namespace()
    args.output_options = OUT_REQ_HEAD + OUT_REQ_BODY
    request = requests.PreparedRequest()
    (with_headers, with_body) = get_output_options(args=args, message=request)
    assert with_headers
    assert with_body

    args.output_options = OUT_RESP_HEAD + OUT_RESP_BODY
    request = requests.Response()
    (with_headers, with_body) = get_output_options(args=args, message=request)
    assert with_headers
    assert with_body

    args.output_options = OUT_RESP_HEAD
    request = requests.Response()

# Generated at 2022-06-21 13:53:15.697806
# Unit test for function get_output_options
def test_get_output_options():

    # mock a argparse.Namespace class, because py.test will not refer to that module
    class Args(object):
        def __init__(self, output_options: List[str]):
            self.output_options = output_options

    args = Args([])
    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY]
    assert (True, True) == get_output_options(args, requests.PreparedRequest())
    assert (True, True) == get_output_options(args, requests.Response())

    args.output_options = [OUT_REQ_HEAD, OUT_RESP_HEAD]
    assert (True, False) == get_output_options(args, requests.PreparedRequest())

# Generated at 2022-06-21 13:53:26.304260
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options = ['resp.body']
    )
    msg = requests.PreparedRequest(
        method = 'GET',
        url = 'http://example.com',
        headers = {'Content-Type': 'text/plain'},
        body = b'q=a%20b%20c',
    )
    assert get_output_options(args, msg) == (False, True)

    msg = requests.Response(
        url = 'http://httpbin.org/get',
        status_code = 200,
        reason = 'OK',
        headers = {'Content-Type': 'application/json'},
        request = requests.Request('GET', 'http://httpbin.org/get'),
        history = []
    )
    assert get_output_options(args, msg)

# Generated at 2022-06-21 13:53:27.063815
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-21 13:53:28.829442
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    env.stderr.close()
    assert os.path.isfile('stderr')

# Generated at 2022-06-21 13:53:39.030840
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = set()
    msg = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args=args, message=msg)
    assert not with_headers and not with_body
    args.output_options.add(OUT_REQ_HEAD)
    with_headers, with_body = get_output_options(args=args, message=msg)
    assert with_headers and not with_body
    args.output_options.add(OUT_REQ_BODY)
    with_headers, with_body = get_output_options(args=args, message=msg)
    assert with_headers and with_body
    msg = requests.Response()

# Generated at 2022-06-21 13:53:39.880233
# Unit test for function get_output_options
def test_get_output_options():
    pass

# Generated at 2022-06-21 13:53:50.230829
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = ('H', 'b')

    def Options(headers: bool, body: bool):
        return get_output_options(args, requests.PreparedRequest()) == (headers, body)

    assert Options(True, True)
    args.output_options = ('h', 'B')
    assert Options(True, True)
    args.output_options = ('h', 'b')
    assert Options(True, True)

    assert Options(False, False)
    args.output_options = ('h',)
    assert Options(True, False)
    args.output_options = ('h', 'h', 'H', 'H')
    assert Options(True, False)
    args.output_options = ('b',)
    assert Options(False, True)
    args.output

# Generated at 2022-06-21 13:54:39.820645
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import json

    args_list_of_bytes = [
        b"/usr/local/bin/http",
        b"--json",
        b'{"var1": "abc"}',
        b"--form",
        b"var2=c%2Bd",
        b"https://httpbin.org/post"
    ]
    args_list_of_strings = [
        "/usr/local/bin/http",
        "--json",
        '{"var1": "abc"}',
        "--form",
        "var2=c%2Bd",
        "https://httpbin.org/post"
    ]

    assert args_list_of_strings == decode_raw_args(args_list_of_bytes, "utf-8")
    assert args_list_of_strings == decode_raw_

# Generated at 2022-06-21 13:54:46.484694
# Unit test for function get_output_options
def test_get_output_options():
    class FakeArgs:
        output_options = OUT_REQ_HEAD | OUT_REQ_BODY | OUT_RESP_BODY
    args = FakeArgs()
    message = requests.PreparedRequest()
    res = get_output_options(args, message)
    assert(res[0] == True and res[1] == True)
    message = requests.Response()
    res = get_output_options(args, message)
    assert(res[0] == False and res[1] == True)

# Generated at 2022-06-21 13:54:52.872064
# Unit test for function get_output_options
def test_get_output_options():
    class args:
        output_options = [OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD]

    class request:
        pass

    class response:
        pass

    request = request()
    response = response()

    assert get_output_options(args, request) == (True, True)
    assert get_output_options(args, response) == (True, True)

# Generated at 2022-06-21 13:55:00.089054
# Unit test for function print_debug_info
def test_print_debug_info():
    import httpie.cli.parser
    from httpie.config import Config
    from httpie.output.streams import StdStreams
    env = Environment(
        config=Config(directory=None),
        stdout=StdStreams(
            bytes_stream=None,
            isatty=False,
        ),
        stderr=StdStreams(
            bytes_stream=None,
            isatty=False,
        ),
        stdin_encoding='utf8',
    )
    print_debug_info(env)

# Generated at 2022-06-21 13:55:04.204393
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    env = Environment()
    env.stdout = env.stdout_raw = StringIO()
    env.stderr = env.stderr_raw = StringIO()
    main(args=['--debug'], env=env)
    assert 'HTTPie' in env.stderr.getvalue()

# Generated at 2022-06-21 13:55:12.044347
# Unit test for function main
def test_main():
    class _Environment(Environment):
        def __init__(self):
            self.stdin_encoding = 'ascii'
            self.stdout = sys.stdout
            self.stderr = sys.stderr

            self.program_name = ''
            self.config = argparse.Namespace(output_options=set(), default_options=set())

        def log_error(self, message, **kwargs):
            pass

        @property
        def stdout_isatty(self):
            return True

    main(env=_Environment())

# Generated at 2022-06-21 13:55:17.617079
# Unit test for function print_debug_info
def test_print_debug_info():
    # TODO: Stub stdin, stdout, stderr in a better way  
    # that handles unicode chars, etc.
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    print_debug_info(env)
    print(env.stderr.getvalue())
    assert env.stdout.getvalue() == ""

# Generated at 2022-06-21 13:55:20.696286
# Unit test for function main
def test_main():
    assert main() == main(sys.argv) == main(sys.argv, Environment())
    assert main(['-v']) == main(['--verbose']) == main(['get'], Environment()) == main(['get', '-v'], Environment())

# Generated at 2022-06-21 13:55:30.728550
# Unit test for function program
def test_program():
    from pprint import pprint
    from httpie import config
    from httpie.output.streams import get_output_stream
    from httpie.plugins import plugin_manager as pm, builtin
    from httpie.cli.definition import parser

    plugin_manager.load_installed_plugins()
    config_dir = config.CONFIG_DIR
    args = parser.parse_args(config_dir=config_dir, args=['-A', 'httpie/1.0.3', '--json', '--debug', 'http://httpbin.org/get'])
    pprint(args)
    pprint(program(args=args, env=Environment()))
    print(33)

# Generated at 2022-06-21 13:55:34.896768
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    env = Environment(stdin=io.BytesIO(), stdout=io.BytesIO(), stderr=io.BytesIO())
    print_debug_info(env)
    assert set(env.stderr.getvalue().splitlines()) == {
        f'HTTPie {httpie_version}',
        f'Requests {requests_version}',
        f'Pygments {pygments_version}',
        f'Python {sys.version}',
        f'{platform.system()} {platform.release()}',
    }
    assert env.stderr.getvalue().count('\n') == 7

# Generated at 2022-06-21 13:57:34.315294
# Unit test for function get_output_options
def test_get_output_options():
    args = main(['--print', 'bB'])
    # Test for request header
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)
    # Test for request body
    assert get_output_options(args, requests.Response()) == (False, True)
    # Test for response header
    args = main(['--print', 'hH'])
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)
    # Test for response body
    assert get_output_options(args, requests.Response()) == (False, True)
    # Test for request and response header
    args = main(['--print', 'all'])
    assert get_output_options(args, requests.PreparedRequest()) == (True, True)
    # Test for request and response

# Generated at 2022-06-21 13:57:43.257999
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    from httpie.context import Environment
    env = Environment()
    env.stderr = io.StringIO()
    print_debug_info(env)
    assert env.stderr.getvalue() == (
        'HTTPie {}\n'
        'Requests {}\n'
        'Pygments {}\n'
        'Python {}\n{}\n'
        '{} {}\n'.format(
            httpie_version,
            requests_version,
            pygments_version,
            sys.version,
            sys.executable,
            platform.system(),
            platform.release()))

# Generated at 2022-06-21 13:57:53.806915
# Unit test for function program

# Generated at 2022-06-21 13:58:04.587070
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    response = requests.Response()
    request = requests.PreparedRequest()

    args.output_options = []
    assert get_output_options(args, response) == (False, False)
    assert get_output_options(args, request) == (False, False)

    args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(args, response) == (False, False)
    assert get_output_options(args, request) == (True, False)

    args.output_options = [OUT_RESP_BODY]
    assert get_output_options(args, response) == (False, True)
    assert get_output_options(args, request) == (False, False)


# Generated at 2022-06-21 13:58:14.477824
# Unit test for function program

# Generated at 2022-06-21 13:58:26.716084
# Unit test for function program
def test_program():
    class TestArgNamespace:
        def __init__(self, output_options="", download=False, download_resume=False, output_file=[], headers="",
                     follow=False, check_status=False, quiet=False, output_file_specified=False):
            self.output_options = output_options
            self.download = download
            self.download_resume = download_resume
            self.output_file = output_file
            self.headers = headers
            self.follow = follow
            self.check_status = check_status
            self.output_file_specified = output_file_specified
            self.quiet = quiet
    from httpie.context import Environment
    # program_name, *args = "httpie test".split(" ")


# Generated at 2022-06-21 13:58:36.528942
# Unit test for function main
def test_main():
    import pytest
    from contextlib import suppress

    from httpie import ExitStatus
    from httpie.compat import is_windows

    from . import UnixHTTPieTest, WindowsHTTPieTest
    from . import BaseTestWithInvalidInput as InvalidInputTest, BaseTestWithLargeContentAndStream as LargeContentTest

    BaseHTTPieTest = WindowsHTTPieTest if is_windows else UnixHTTPieTest

    class MainTest(BaseHTTPieTest):

        def test_error(self):
            test_env = Environment()
            test_args = ['--verbose', '--debug', '--traceback']
            assert main(args=test_args, env=test_env) == ExitStatus.ERROR
            assert test_env.stderr.getvalue().startswith('\nHTTPie')


# Generated at 2022-06-21 13:58:44.524865
# Unit test for function get_output_options
def test_get_output_options():
    """
    Verify the behavior of get_output_options
    """
    import argparse
    args = argparse.Namespace(output_options=["time_elapsed"])
    class Response:
        pass
    msg = Response()
    head, body = get_output_options(args, msg)
    assert head == False
    assert body == False
    args = argparse.Namespace(output_options=["time_elapsed", "resp_body"])
    head, body = get_output_options(args, msg)
    assert head == False
    assert body == True
    args = argparse.Namespace(output_options=["time_elapsed", "req_head"])
    class Request:
        pass
    msg = Request()
    head, body = get_output_options(args, msg)

# Generated at 2022-06-21 13:58:50.530948
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser
    env = Environment()
    args = parser.parse_args([])
    for message in (requests.PreparedRequest(), requests.Response()):
        opt = get_output_options(args, message)
        assert(opt[0] or opt[1])

    args = parser.parse_args(['-b', '-h'])
    opt = get_output_options(args, requests.PreparedRequest())
    assert(opt[0] and opt[1])

    args = parser.parse_args(['-B', '-H'])
    opt = get_output_options(args, requests.Response())
    assert(opt[0] and opt[1])

    args = parser.parse_args(['-jb'])

# Generated at 2022-06-21 13:58:53.777031
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = [b'\x80', '\xF0', '\U0010FFFF']
    assert decode_raw_args(args, 'utf-8') == args
test_decode_raw_args()

# Generated at 2022-06-21 14:00:03.007071
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from contextlib import contextmanager
    import tempfile
    from httpie import context
    import os

    @contextmanager
    def io():
        old_stdin = context.env.stdin
        old_stdout = context.env.stdout
        old_stderr = context.env.stderr

        try:
            context.env.stdin = StringIO()
            context.env.stdout = StringIO()
            context.env.stderr = StringIO()
            yield context.env
        finally:
            context.env.stdin = old_stdin
            context.env.stdout = old_stdout
            context.env.stderr = old_stderr
    context.env.config.directory = tempfile.TemporaryDirectory()

# Generated at 2022-06-21 14:00:09.660073
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import sys

    env = Environment(
        stdin=io.StringIO(),
        stdin_isatty=False,
        stdout=io.StringIO(),
        stdout_isatty=False,
        stdout_bytes_as_text=True,
        stderr=io.StringIO(),
    )

    print_debug_info(env)

    expected_stdout_lines = [
        f'HTTPie {httpie_version}\n',
        f'Requests {requests_version}\n',
        f'Pygments {pygments_version}\n',
        f'Python {sys.version}\n{sys.executable}\n',
        f'{platform.system()} {platform.release()}',
    ]

# Generated at 2022-06-21 14:00:15.918438
# Unit test for function program
def test_program():
    import requests
    import pytest
    from httpie import ExitStatus
    from httpie.cli import parser

    args = parser.parse_args(
        args=[
            '--check-status',
            '--follow',
            '--output=json',
            'http://httpbin.org/get',
        ]
    )
    assert program(args=args, env=args.env) == ExitStatus.SUCCESS



# Generated at 2022-06-21 14:00:19.184005
# Unit test for function decode_raw_args

# Generated at 2022-06-21 14:00:27.629008
# Unit test for function program
def test_program():
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.context import Environment
    import sys
    
    #arrange
    args = ['https://google.com']
    env = Environment(stdin=sys.stdin,
                      stdin_isatty=False,
                      stdout=sys.stdout,
                      is_windows=False,
                      stdout_isatty=False,
                      stderr=sys.stderr)
    env.config.default_options = ['--pretty=all', '--style=solarized', '--format=' + DEFAULT_FORMAT]
    #act
    result = program(args, env)
    #assert
    assert result == ExitStatus.SUCCESS

# Generated at 2022-06-21 14:00:30.854090
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['--form'], 'ascii') == ['--form']
    assert decode_raw_args([b'--form'], 'ascii') == ['--form']
    assert decode_raw_args([b'--form'], 'utf-8') == ['--form']

# Generated at 2022-06-21 14:00:34.977393
# Unit test for function decode_raw_args
def test_decode_raw_args():
    """
    Tests that some args in bytes should be decoded to str,
    and others in str should be left valid.

    """
    assert decode_raw_args(
        args=['猫', '--form', b'foo=bar', '--json', '\'{"baz": "猫"}\''],
        stdin_encoding='ascii'
    ) == [
        '猫',
        '--form',
        'foo=bar',
        '--json',
        '\'{"baz": "猫"}\''
    ]