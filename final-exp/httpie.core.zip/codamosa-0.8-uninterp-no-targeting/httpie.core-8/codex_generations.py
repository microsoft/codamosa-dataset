

# Generated at 2022-06-21 13:51:32.613838
# Unit test for function decode_raw_args
def test_decode_raw_args():
    if type(sys.stdin.encoding) is str:
        original = [b'\xe2\x82\xac', b'a', 'b']
        expected = ['€', 'a', 'b']
        assert decode_raw_args(original, sys.stdin.encoding) == expected

# Generated at 2022-06-21 13:51:39.592365
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr = StringIO()
    print_debug_info(env)
    output = env.stderr.getvalue()
    line_break_count = output.count('\n')
    assert line_break_count == 1
    assert f'HTTPie {httpie_version}' in output
    assert f'Requests {requests_version}' in output
    assert f'Pygments {pygments_version}' in output
    assert f'Python {sys.version}' in output

# Generated at 2022-06-21 13:51:46.162444
# Unit test for function print_debug_info
def test_print_debug_info():
    # Create env object 
    class Env:
        pass
    env = Env()
    
    # Mock stderr
    from io import TextIOWrapper
    from io import BytesIO
    env.stderr = TextIOWrapper(BytesIO())

    # Mock sys.version and sys.executable
    import sys
    sys.version = '3.7.3'
    sys.executable = 'C:\\Users\\aditi\\AppData\\Local\\Programs\\Python\\Python37\\python.exe'

    # Mock platform
    import platform
    platform.system = lambda: 'Windows'
    platform.release = lambda: '10'

    # Mock repr of env

# Generated at 2022-06-21 13:51:47.631883
# Unit test for function program
def test_program():
    program(args, env)

# Generated at 2022-06-21 13:51:58.893106
# Unit test for function print_debug_info
def test_print_debug_info():
    class FakeEnv:
        def __init__(self):
            self.stderr = []
        def write(self, line):
            self.stderr.append(line)

    import platform
    platform_info = platform.system() + ' ' + platform.release()
    f = FakeEnv()
    print_debug_info(f)
    list = f.stderr
    assert list[0].startswith('HTTPie ')
    assert list[1].startswith('Requests ')
    assert list[2].startswith('Pygments ')
    assert list[3].startswith('Python ')
    assert list[4].startswith('Executable: ')
    assert list[5] == platform_info
    assert list[6] == '\n\n'

# Generated at 2022-06-21 13:52:09.786387
# Unit test for function program
def test_program():
    import pytest
    from httpie import ExitStatus, Environment
    from httpie.cli.definition import parser
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    with open('test_httpie_download.csv', 'rb') as f:
        filename = f.read()
    with open('test_httpie_download.csv', 'rb') as f:
        file_contents = f.read()

# Generated at 2022-06-21 13:52:19.143380
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[])
    req = requests.PreparedRequest()
    resp = requests.Response()
    res = {
        requests.PreparedRequest: (False, False),
        requests.Response: (False, False)
    }
    assert res == get_output_options(args, req)
    assert res == get_output_options(args, resp)

    args = argparse.Namespace(output_options=[OUT_REQ_HEAD])
    req = requests.PreparedRequest()
    resp = requests.Response()
    res = {
        requests.PreparedRequest: (True, False),
        requests.Response: (False, False)
    }
    assert res == get_output_options(args, req)
    assert res == get_output_options(args, resp)


# Generated at 2022-06-21 13:52:23.062905
# Unit test for function print_debug_info
def test_print_debug_info():
      env = Environment() 
      output_test = print_debug_info(env)
      assert env.stderr.getvalue()[0:26] == 'HTTPie 1.0.2\nRequests 2.19'

# Generated at 2022-06-21 13:52:27.830116
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_HEAD, OUT_RESP_BODY]

    msg = requests.PreparedRequest()
    assert get_output_options(args, msg) == (True, False)
    msg = requests.Response()
    assert get_output_options(args, msg) == (False, True)


# Generated at 2022-06-21 13:52:34.083614
# Unit test for function print_debug_info
def test_print_debug_info():
    import sys
    import io
    env = Environment()
    env.stderr = io.StringIO()
    sys.stderr = env.stderr

    print_debug_info(env)
    assert env.stderr.getvalue() == """HTTPie 0.9.8
Requests 2.20.1
Pygments 2.4.1
Python 3.7.6 (default, Jan  8 2020, 20:23:39) [MSC v.1916 64 bit (AMD64)]
C:\\Users\\li\\PycharmProjects\\untitled\\venv\\Scripts\\python.exe
Windows 10"""

# Generated at 2022-06-21 13:54:37.833413
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    buf = io.StringIO()
    env = Environment(stdout=buf,stderr=buf)
    print_debug_info(env)
    content = buf.getvalue()
    assert content.startswith('HTTPie')

# Generated at 2022-06-21 13:54:38.404053
# Unit test for function main
def test_main():
    main(["test"])

# Generated at 2022-06-21 13:54:41.040624
# Unit test for function print_debug_info
def test_print_debug_info():
    from . import Environment
    import io
    out = io.StringIO()
    env = Environment()
    env.stderr = out
    print_debug_info(env)
    assert('HTTPie' in out.getvalue())

# Generated at 2022-06-21 13:54:46.089719
# Unit test for function main
def test_main():
    assert main(["http","httpbin.org","/get"]) == 0
    assert main(["http","httpbin.org","/post","hello=world"]) == 0
    assert main(["http","httpbin.org","/delete"]) == 0
    assert main(["http","httpbin.org","/delete","delete_content=delete_content"]) == 0

# Generated at 2022-06-21 13:54:56.700059
# Unit test for function main
def test_main():
    import pytest
    from httpie.utils import RedirectHandler
    from httpie.requestbuilder import config, requestbuilder
    from httpie.context import Environment
    env = Environment()
    class Config(config):
        def __init__(self):
            self.default_options = ['--ignore-stdin', '--follow']
            self.directory = '~/.httpie'
    env.config = Config()
    env.stdin_isatty = False
    env.stdout_isatty = True
    env.config.default_options = ['--ignore-stdin', '--follow']
    env.config.directory = '~/.httpie'
    args=['https://httpie.org', 'http://httpbin.org/redirect/1', 'http://httpbin.org/redirect/2']

# Generated at 2022-06-21 13:55:05.293091
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from httpie.context import Environment
    import platform
    import sys
    import httpie
    env = Environment()
    env.stderr = StringIO()
    print_debug_info(env)
    env.stderr.seek(0)
    x = env.stderr.getvalue()
    print(x)
    assert "HTTPie 0.9.9\n" in x
    assert "Requests 2.22.0\n" in x
    assert "Pygments 2.4.2\n" in x
    assert f"Python {sys.version}\n" in x
    assert f"{platform.system()} {platform.release()}" in x

# Generated at 2022-06-21 13:55:16.088628
# Unit test for function get_output_options
def test_get_output_options():
    from unittest import TestCase, main, mock
    from unittest.mock import Mock, patch
    from types import SimpleNamespace

    with patch("httpie.cli.main.requests") as requests:
        pr = requests.PreparedRequest.return_value
        requests.Response.return_value = 'response'
        args = SimpleNamespace(_output_options=[])
        args.output_options = {OUT_REQ_HEAD, OUT_RESP_BODY}
        assert(get_output_options(args, pr) == (True, False))

        args = SimpleNamespace(_output_options=[])
        args.output_options = {OUT_REQ_HEAD, OUT_RESP_BODY}
        assert(get_output_options(args, 'response') == (False, True))


# Generated at 2022-06-21 13:55:23.277898
# Unit test for function main
def test_main():
    try:
        from unittest.mock import patch
        from io import StringIO
    except ImportError:
        from mock import patch
        from StringIO import StringIO
    import requests
    import sys
    sys.argv = ['http','--debug']
    with patch('sys.stdout', new_callable=StringIO) as patched_stdout:
        with patch.object(requests,'get', return_value=requests.Response()) as patched_get:
            try:
                main()
            except SystemExit as e:
                assert e.code == 0
    assert patched_stdout.getvalue().startswith('HTTPie')
    assert calls_with_args(patched_get, 'http://example.com/', headers={}, timeout=None)

# Generated at 2022-06-21 13:55:28.604443
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    from httpie.context import Environment
    fp = io.StringIO()
    print_debug_info(env = Environment(
        stdin_isatty=False,
        stdout_isatty=False,
        stdin=fp,
        stdout=fp,
        stderr=fp,
    ))
    assert True

# Generated at 2022-06-21 13:55:34.609325
# Unit test for function get_output_options
def test_get_output_options():
    args = ['--output', 'headers']
    # TODO: add test for `isinstance(message, requests.Response)`
    message = requests.PreparedRequest()
    assert get_output_options(message=message, args=args) == (True, False)
    args = ['--output', 'all']
    assert get_output_options(message=message, args=args) == (True, True)

# Generated at 2022-06-21 13:56:36.947709
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=['a', b'b'], stdin_encoding='utf8') == ['a', 'b']

# Generated at 2022-06-21 13:56:39.810383
# Unit test for function decode_raw_args
def test_decode_raw_args():
    a = ['a', b'b', 'c']
    assert decode_raw_args(a, 'utf-8') == ['a', 'b', 'c']

# Generated at 2022-06-21 13:56:46.216150
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli import env
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    parsed=argparse.Namespace()
    parsed.headers=False
    parsed.output_options={OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD}
    message=requests.PreparedRequest()
    message.headers={}
    message.body=""
    headers, body=get_output_options(parsed, message)
    assert all((headers, not body))
    message=requests.Response()
    message.headers={}
    message.body=""
    headers, body=get_output_options(parsed, message)
    assert all((headers, body))
    message

# Generated at 2022-06-21 13:56:47.708097
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)

# Generated at 2022-06-21 13:56:59.311265
# Unit test for function get_output_options
def test_get_output_options():
    args_1 = argparse.Namespace(output_options=[OUT_REQ_BODY])
    message_1 = requests.PreparedRequest()
    out_1 = get_output_options(args=args_1, message=message_1)
    assert out_1 == (False, True)

    args_2 = argparse.Namespace(output_options=[OUT_REQ_HEAD])
    message_2 = requests.PreparedRequest()
    out_2 = get_output_options(args=args_2, message=message_2)
    assert out_2 == (True, False)

    args_3 = argparse.Namespace(output_options=[OUT_REQ_HEAD,
                                                OUT_REQ_BODY])
    message_3 = requests.PreparedRequest()
    out_3 = get_output_

# Generated at 2022-06-21 13:57:10.076051
# Unit test for function main
def test_main():
    import os
    import re
    from io import BytesIO
    from httpie.cli import main as cli_main
    from httpie.utils import get_response_encoding
    from httpie.output.writer import get_message_writer
    from urllib.parse import splitquery
    from os import devnull
    from requests import Response
    from httpie.compat import is_windows
    from httpie.plugins.registry import plugin_manager


# Generated at 2022-06-21 13:57:16.746704
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[OUTPUT_OPTION_SHORT_NAMES_TO_FULL_NAMES[OUTPUT_OPTION_SHORT_NAME_REQ_BODY], OUTPUT_OPTION_SHORT_NAMES_TO_FULL_NAMES[OUTPUT_OPTION_SHORT_NAME_RESP_BODY]], follow=False, download=False, download_resume=False, output_file=None, headers=[])
    msg = requests.Response()
    assert get_output_options(args=args, message=msg) == (False, True)



# Generated at 2022-06-21 13:57:26.007739
# Unit test for function get_output_options
def test_get_output_options():
    test_args = argparse.Namespace(
            output_options=[
                OUT_REQ_HEAD,
                OUT_REQ_BODY,
                OUT_RESP_HEAD,
                OUT_RESP_BODY,
            ]
        )
    test_request = requests.PreparedRequest()
    test_response = requests.Response()

    options = get_output_options(args=test_args, message=test_request)
    assert options == (True, True)

    options = get_output_options(args=test_args, message=test_response)
    assert options == (True, True)

    test_args.output_options = [
        OUT_REQ_HEAD,
        OUT_RESP_HEAD,
    ]

# Generated at 2022-06-21 13:57:33.211019
# Unit test for function print_debug_info
def test_print_debug_info():
    debug_info = io.StringIO()
    env = Environment(stderr=debug_info)
    print_debug_info(env)
    assert debug_info.getvalue().startswith(
        'HTTPie ' + httpie_version + '\n'
        'Requests ' + requests_version + '\n'
        'Pygments ' + pygments_version + '\n'
        'Python ' + sys.version + '\n' + sys.executable + '\n'
    )

# Generated at 2022-06-21 13:57:45.174494
# Unit test for function program
def test_program():
    from httpie.config import Config
    from httpie.core import main
    from httpie.input import KeyValue, KeyValueArgType
    from httpie.plugins import plugin_manager
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.utils import get_response_dict

    from . import MockEnvironment, http

    plugin_manager.load_installed_plugins()


# Generated at 2022-06-21 13:59:11.845825
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # Assert correct decoding of bytes args
    args = ['httpie', b'--b=123', b'-f', b'abc']
    assert decode_raw_args(args, 'ascii') == ['httpie', '--b=123', '-f', 'abc']

    # Assert that bytes args and str args can coexist
    args = ['httpie', b'--b=123', '-f', b'abc']
    assert decode_raw_args(args, 'ascii') == ['httpie', '--b=123', '-f', 'abc']

# Generated at 2022-06-21 13:59:21.802843
# Unit test for function main
def test_main():
    """
    Unit test for function `main` in module `httpie.cli`.

    """
    from httpie.client import collect_messages
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD
    from httpie.cli.definition import parser
    from httpie.status import ExitStatus
    from httpie.context import Environment
    from httpie import __main__
    import os
    import sys
    import platform
    import pytest
    args = '--debug'.split(' ')
    env = Environment()
    # env.stderr = pytest.stderr
    # env.stderr.lines = pytest.stderr.lines
    # env.stdout = pytest.stdout
    # env.stdout.lines = pytest.stdout.lines
   

# Generated at 2022-06-21 13:59:28.637502
# Unit test for function print_debug_info
def test_print_debug_info():
    import os
    import sys
    import unittest
    # noinspection PyProtectedMember
    from httpie.config import get_config_dir
    from httpie.status import ExitStatus
    from tests.utils import TestEnvironment

    class _TestPrintDebugInfo(unittest.TestCase):

        def setUp(self):
            self.tempdir = os.path.join(os.path.dirname(__file__), 'tempdir')
            if not os.path.isdir(self.tempdir):
                os.mkdir(self.tempdir)

        def test_happy_path(self):
            env = TestEnvironment(stdout=sys.stdout, config_dir=self.tempdir)
            env.stdout.truncate(0)

# Generated at 2022-06-21 13:59:35.781547
# Unit test for function get_output_options
def test_get_output_options():
    import _argparse
    env = Environment()
    args = _argparse.Namespace(
        output_options=["verbose"]
    )
    msg = requests.PreparedRequest()
    assert get_output_options(args, msg) == (True, True)

    msg = requests.Response()
    assert get_output_options(args, msg) == (False, False)

    args = _argparse.Namespace(
        output_options=["none"]
    )
    assert get_output_options(args, msg) == (False, False)

# Generated at 2022-06-21 13:59:42.327050
# Unit test for function decode_raw_args
def test_decode_raw_args():
    stdin_encoding = 'utf-8'
    args = ['a', b'b', 'c', b'd']
    result = decode_raw_args(args, stdin_encoding)
    assert result == ['a', 'b', 'c', 'd']


if __name__ == '__main__':
    try:
        exit_status = main()
    except KeyboardInterrupt:
        exit_status = ExitStatus.ERROR_CTRL_C

    sys.exit(exit_status)

# Generated at 2022-06-21 13:59:48.200032
# Unit test for function main
def test_main():
    import httpie.cli.constants
    import httpie.plugins
    httpie.cli.constants.DEFAULT_CONFIG_DIR = 'test_httpie_config'
    httpie.plugins.__path__.append('test_httpie_plugins')
    os.mkdir(httpie.cli.constants.DEFAULT_CONFIG_DIR)
    with open(os.path.join(httpie.cli.constants.DEFAULT_CONFIG_DIR, 'config.ini'), 'w') as f:
        f.write("""\
[defaults]
default_options = --headers
""")

    import io
    import sys
    import unittest

    class Tester(unittest.TestCase):
        def setUp(self):
            self.orig_argv = sys.argv


# Generated at 2022-06-21 13:59:58.867609
# Unit test for function program
def test_program():
    """
    Test function program.
    """
    import argparse
    import io
    import os
    import sys
    import unittest
    from unittest.mock import patch

    from httpie.cli.constants import DEFAULT_UA

    class ProgramTestCase(unittest.TestCase):
        def setUp(self):
            self.stdout = io.StringIO()
            self.stderr = io.StringIO()
            self.env = Environment(stdin=sys.__stdin__, stdout=self.stdout, stderr=self.stderr,
                                   color=False, config_dir=None)

        def tearDown(self):
            self.stderr.close()
            self.stdout.close()


# Generated at 2022-06-21 14:00:02.618563
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=['ä'], stdin_encoding='utf-8') == ['ä']
    assert decode_raw_args(args=[b'\xc3\xa4'], stdin_encoding='latin1') == ['ä']

# Generated at 2022-06-21 14:00:08.636675
# Unit test for function decode_raw_args
def test_decode_raw_args():
    raw_arg_bytes = [
        b'--form',
        b'id=1',
        b'--form',
        b'name=John Doe'
    ]

    raw_arg_str = [
        '--form',
        'id=1',
        '--form',
        'name=John Doe'
    ]

    env = Environment()
    env.stdin_encoding = 'utf8'
    assert [c for c in decode_raw_args(raw_arg_bytes, env.stdin_encoding)] == \
        [c for c in raw_arg_str]

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 14:00:13.964615
# Unit test for function decode_raw_args
def test_decode_raw_args():
    raw_args = ['POST', 'http://httpbin.org/post', 'Foo:=bar']
    stdin_encoding = 'utf-8'
    args = decode_raw_args(raw_args, stdin_encoding)
    assert (args == ['POST', 'http://httpbin.org/post', 'Foo:=bar'])