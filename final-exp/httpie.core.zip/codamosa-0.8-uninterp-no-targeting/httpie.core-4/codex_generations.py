

# Generated at 2022-06-21 13:51:03.877493
# Unit test for function get_output_options
def test_get_output_options():
    arg_namespace = argparse.Namespace()
    empty_condition = get_output_options(args=arg_namespace, message=arg_namespace)
    assert empty_condition == (False, False)

    arg_namespace.output_options = [OUT_REQ_HEAD]
    partial_condition = get_output_options(args=arg_namespace, message=arg_namespace)
    assert partial_condition == (True, False)

    arg_namespace.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY]
    full_condition = get_output_options(args=arg_namespace, message=arg_namespace)
    assert full_condition == (True, True)

# Generated at 2022-06-21 13:51:07.039718
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr = FakeStream()
    print_debug_info(env)
    assert env.stderr.text.startswith('HTTPie ')



# Generated at 2022-06-21 13:51:16.416085
# Unit test for function program
def test_program():
    from httpie.cli.constants import ENV_CONFIG_DIR
    from httpie.compat import is_py26, is_windows

    import httpie
    env = Environment(stdout=False, stderr=False)

    if is_py26 or is_windows:
        return

    # Simple GET request
    args = ["http://httpbin.org/get"]
    exit_status = program(args=parser.parse_args(args=args, env=env), env=env)
    assert exit_status == ExitStatus.SUCCESS

    # GET request with form/json/headers data,
    # and a redirect to a HTTPS URL

# Generated at 2022-06-21 13:51:21.732694
# Unit test for function main
def test_main():
    print("test_main")
    print(main(['http', '--debug', '--traceback', 'httpbin.org/get']))

if __name__ == '__main__':
    print("main")
    print(main(['http', '--debug', '--traceback', 'httpbin.org/get']))

# Generated at 2022-06-21 13:51:26.096295
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=[b'\xe6\x88\x91\xe6\x98\xaf'], stdin_encoding='utf8') == ['我是']


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 13:51:33.956758
# Unit test for function main
def test_main():
    import unittest
    from httpie.core import main as httpie_core_main

    from httpie.core import main as httpie_core_main
    class TestHttpieMain(unittest.TestCase):

        def test_main(self):
            exit_code = httpie_core_main(args=[])
            self.assertEqual(exit_code, 1)

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-21 13:51:38.029792
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert (
        decode_raw_args(
            ['http', b'-v', 'http://httpbin.org', b'b\xe9b\xe9'],
            'utf8'
        )
        ==
        ['http', '-v', 'http://httpbin.org', 'bébé']
    )

# Generated at 2022-06-21 13:51:42.949695
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = [b'--form', b'name=\xe6\x96\xb0\xe5\x8b\x95\xe6\x89\x8b\xe6\x9c\xba']
    stdin_encoding = 'utf-8'
    decode_raw_args(args, stdin_encoding)

# Generated at 2022-06-21 13:51:50.385455
# Unit test for function get_output_options
def test_get_output_options():
    class MockArgs:
        def __init__(self):
            self.output_options = ['body']
    mock_args = MockArgs()
    header_show, body_show = get_output_options(mock_args, requests.PreparedRequest())
    assert header_show is False
    assert body_show
    header_show, body_show = get_output_options(mock_args, requests.Response())
    assert header_show is True
    assert body_show

# Generated at 2022-06-21 13:51:59.620475
# Unit test for function print_debug_info
def test_print_debug_info():
    class MockStderr:
        def __init__(self):
            self.contents = []
        def write(self, x):
            self.contents.append(x)
    env = Environment(stderr=MockStderr())
    print_debug_info(env)
    env.stderr.write('\n')
    output = ''.join(env.stderr.contents)
    assert 'HTTPie' in output
    assert 'Requests' in output
    assert 'Pygments' in output
    assert 'Python' in output
    assert "3.7.3" in output
    assert "3.8.2" in output

# Generated at 2022-06-21 13:52:45.332704
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'foo', 'bar'], 'utf-8') == ['foo', 'bar']

# Generated at 2022-06-21 13:52:47.641965
# Unit test for function program
def test_program():
    assert program
    #TODO: Add test cases to test program function
    # pass

# Generated at 2022-06-21 13:52:48.600572
# Unit test for function print_debug_info
def test_print_debug_info():
    print_debug_info(Environment())

# Generated at 2022-06-21 13:52:50.592354
# Unit test for function print_debug_info
def test_print_debug_info():
    assert print_debug_info(httpie_version) is not None



# Generated at 2022-06-21 13:52:54.080190
# Unit test for function program
def test_program():
    environment = Environment()
    args = ArgumentParser().parse_args([
        '--download', 'https://httpbin.org/robots.txt'
    ])
    exit_status = program(args, environment)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:53:04.161146
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    env = Environment()
    env.stderr = io.StringIO()
    print_debug_info(env)
    # Remove the last two empty lines (empty str and new line)
    assert env.stderr.getvalue().rsplit('\n', 2)[0] == '''HTTPie 3.0.0
Requests 2.22.0
Pygments 2.4.2
Python 3.6.3 (v3.6.3:2c5fed8, Oct  3 2017, 18:11:49) [MSC v.1900 64 bit (AMD64)]
C:\\Anaconda3\\python.exe
Windows 7

<httpie.context.Environment object at 0x0000023D1E1FA198>'''

# Generated at 2022-06-21 13:53:14.243459
# Unit test for function get_output_options
def test_get_output_options():
    assert get_output_options(
        argparse.Namespace(output_options=[]),
        requests.PreparedRequest()
    ) == (False, False)

    assert get_output_options(
        argparse.Namespace(output_options=[OUT_REQ_HEAD]),
        requests.PreparedRequest()
    ) == (True, False)

    assert get_output_options(
        argparse.Namespace(output_options=[OUT_REQ_BODY]),
        requests.PreparedRequest()
    ) == (False, True)

    assert get_output_options(
        argparse.Namespace(output_options=[OUT_REQ_HEAD, OUT_REQ_BODY]),
        requests.PreparedRequest()
    ) == (True, True)


# Generated at 2022-06-21 13:53:25.586301
# Unit test for function get_output_options
def test_get_output_options():
    args_res_head = argparse.Namespace(output_options=OUT_RESP_HEAD)
    args_req_body = argparse.Namespace(output_options=OUT_REQ_BODY)
    args_all = argparse.Namespace(output_options=OUT_REQ_HEAD + OUT_REQ_BODY + OUT_RESP_HEAD + OUT_RESP_BODY)
    req_msg = requests.PreparedRequest()
    res_msg = requests.Response()
    assert get_output_options(args_res_head, res_msg) == (True, False)
    assert get_output_options(args_req_body, req_msg) == (False, True)
    assert get_output_options(args_all, res_msg) == (True, True)
    assert get_output_options

# Generated at 2022-06-21 13:53:34.841239
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['Uživatel:heslo'], 'utf-8') == ['Uživatel:heslo']
    assert decode_raw_args(['Uživatel:heslo'], 'iso-8859-2') == ['Uživatel:heslo']
    assert decode_raw_args(['Пользователь:пароль'], 'utf-8') == ['Пользователь:пароль']
    assert decode_raw_args(['Uživatel:heslo'], 'cp1252') == ['Uživatel:heslo']




# Generated at 2022-06-21 13:53:36.437493
# Unit test for function main
def test_main():
    print(main())

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 13:54:20.388322
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['GET'], 'utf8') == ['GET']
    assert decode_raw_args(['GET', b'hello'], 'latin1') == ['GET', 'hello']


if __name__ == '__main__':
    try:
        exit(main())
    except KeyboardInterrupt:
        # Display the ^C to stderr as otherwise it would be suppressed by
        # Python because of PEP 3140: http://www.python.org/dev/peps/pep-3140/
        sys.stderr.write('\n\n^C\n')
        exit(ExitStatus.ERROR_CTRL_C)

# Generated at 2022-06-21 13:54:23.572620
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['--form', b'key=value', b'http://httpbin.org/post'], 'utf-8') == ['--form', 'key=value', 'http://httpbin.org/post']

# Generated at 2022-06-21 13:54:33.938381
# Unit test for function get_output_options
def test_get_output_options():
    env = Environment()
    args = ['http', '--output=body', '--upload', '/']
    parsed_args = argparse.Namespace()
    parsed_args.output_options = None
    parsed_args.output_options = [Entry.from_str('output_options') for Entry in args if Entry.startswith('--output')]
    parsed_args.output_options = set(parsed_args.output_options)
    parsed_args.headers = None
    parsed_args.timeout = 5
    parsed_args.max_redirects = 30
    parsed_args.download = False
    parsed_args.output_file = None
    parsed_args.follow = True
    parsed_args.check_status = True
    parsed_args.download_resume = False
    parsed_args.quiet = False
   

# Generated at 2022-06-21 13:54:37.652507
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[OUT_REQ_HEAD])
    message = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args=args, message=message)
    assert with_headers
    assert not with_body

# Generated at 2022-06-21 13:54:44.233359
# Unit test for function print_debug_info
def test_print_debug_info():
    class MockFile:
        def __init__(self):
            self.lines = []
        def write(self, s):
            self.lines.append(s)
        def writelines(self, iterable):
            for line in iterable:
                self.lines.append(line)

    class MockEnvironment:
        def __init__(self):
            self.stderr = MockFile()
        def __repr__(self):
            return "This is a mock environment"

    env = MockEnvironment()
    print_debug_info(env)
    lines = env.stderr.lines
    assert lines[2] == f'Requests {requests_version}\n'
    assert lines[6] == f'Python {sys.version}\n{sys.executable}\n'

# Generated at 2022-06-21 13:54:52.125385
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.output.writer import write_message, write_stream
    import io
    import sys
    args = parser.parse_args(
        args=[
            'http', 'http://www.example.com'
        ],
        env=Environment()
    )
    stdout = io.StringIO()
    sys.stdout = stdout
    #assert 0 == program(args=args, env=Environment())
    stdout.close()
    sys.stdout = sys.__stdout__

# Generated at 2022-06-21 13:54:55.687163
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import locale
    assert decode_raw_args([b'-'], locale.getpreferredencoding()) == [
        '-'
    ]
    assert decode_raw_args([b'\xe3\x81\x82'], 'utf-8') == [
        'あ'
    ]

# Generated at 2022-06-21 13:54:58.012713
# Unit test for function print_debug_info
def test_print_debug_info():
    print("test")
    env = Environment()
    print_debug_info(env)

test_print_debug_info()

# Generated at 2022-06-21 13:55:02.367728
# Unit test for function program
def test_program():
    assert program([''], Environment(stdin_encoding='utf8')) == ExitStatus.ERROR
    assert program([''], Environment(stdin_encoding='utf8', stdout_isatty=True)) == ExitStatus.ERROR

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 13:55:09.231111
# Unit test for function main
def test_main():
    from .config import Config
    from .context import Environment
    from .status import ExitStatus
    from .output.streams import Streams
    from .parser import parse_args

    class StderrBytesIO(io.BytesIO):
        def write(self, s: Union[str, bytes]) -> int:
            return super().write(s.encode('utf8'))

    class StdoutBytesIO(io.BytesIO):
        def write(self, s: Union[str, bytes]) -> int:
            return super().write(s.encode('utf8'))

    config = Config()
    config.directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '.httpie')

# Generated at 2022-06-21 13:56:37.059547
# Unit test for function program
def test_program():
    from io import StringIO
    from unittest import mock
    import httpie
    from httpie import client
    from httpie import exit_status
    from tests.compat import is_windows
    from tests.utils import http


# Generated at 2022-06-21 13:56:41.475376
# Unit test for function print_debug_info
def test_print_debug_info():
    stdout, stderr = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = StringIO(), StringIO()
    env = Environment()
    print_debug_info(env)
    sys.stdout, sys.stderr = stdout, stderr

# Generated at 2022-06-21 13:56:52.953420
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(stdout=io.BytesIO(), stderr=io.BytesIO())
    print_debug_info(env)

# Generated at 2022-06-21 13:56:56.057129
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    env = Environment()
    env.stderr = io.StringIO()
    print_debug_info(env)
    assert env.stderr.getvalue()

# Generated at 2022-06-21 13:56:57.300454
# Unit test for function program
def test_program():
    raise NotImplementedError



# Generated at 2022-06-21 13:57:02.264277
# Unit test for function print_debug_info
def test_print_debug_info():
    class Env:
        class StdErr:
            def write(self, value):
                pass

        stderr = StdErr()

    env = Env()
    print_debug_info(env)


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 13:57:12.375776
# Unit test for function main
def test_main():
    # Unit tests for main()

    import contextlib
    from httpie.cli import main
    from httpie.context import Environment, EnvironmentError
    from httpie.plugins import plugin_manager

    plugin_manager.load_installed_plugins()

    from pprint import pformat
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    @contextlib.contextmanager
    def capture_stdout():
        old_stdout = sys.stdout
        sys.stdout = io.StringIO()
        try:
            yield sys.stdout
        finally:
            sys.stdout = old_stdout

    @contextlib.contextmanager
    def capture_stderr():
        old_stderr = sys.stderr
        sys.stderr = io.StringIO()

# Generated at 2022-06-21 13:57:14.403996
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.environment import Environment
    args = parser.parse_args(args=['-u','http://baidu.com'], env=Environment())
    assert program(args, Environment()) == ExitStatus.SUCCESS


# Generated at 2022-06-21 13:57:17.782287
# Unit test for function get_output_options
def test_get_output_options():
    class args:
        output_options = [OUT_REQ_HEAD, OUT_RESP_HEAD]
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)
    assert get_output_options(args, requests.Response()) == (True, False)



# Generated at 2022-06-21 13:57:21.054797
# Unit test for function program
def test_program():
    env = Environment()
    class TestArgs:
        def __init__(self):
            self.output_options = ['headers']
    args = TestArgs()
    assert program(args=args, env=env) == ExitStatus.SUCCESS