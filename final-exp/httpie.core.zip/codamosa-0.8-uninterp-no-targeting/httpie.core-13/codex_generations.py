

# Generated at 2022-06-21 13:51:08.451904
# Unit test for function program
def test_program():
    class args:
        download = False
        output_file = None
        output_file_specified = False
        follow = False
        quiet = False
        output_options = [OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY]
        headers = []
        check_status = False
        download_resume = False

    class env:
        class stdout:
            isatty = False
        stdout_isatty = stdout.isatty
        log_error = print

    assert ExitStatus.SUCCESS == program(args=args, env=env)

# Generated at 2022-06-21 13:51:17.381141
# Unit test for function print_debug_info
def test_print_debug_info():
    class FakeStderr:
        def __init__(self, buffer: List[str]):
            self.buffer = buffer

        def write(self, text: Union[str, bytes]):
            self.buffer.append(text)

    buffer = []
    env = Environment(
        config_dir=None,
        stdin=None,
        stdin_isatty=True,
        stdout=None,
        stdout_isatty=True,
        stdout_bytes_written=0,
        stdout_raw=FakeStderr(buffer),
        stdout_encoding='utf8',
        stderr=None,
        stdout_isatty=True,
        program_name=None,
    )
    print_debug_info(env=env)

# Generated at 2022-06-21 13:51:19.182359
# Unit test for function program
def test_program():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 13:51:29.297259
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import unittest
    class Stderr(io.TextIOWrapper):
        def __init__(self):
            self.closed = False
            self.buffer = io.BytesIO()
        def close(self):
            self.closed = True
        def write(self, text):
            self.buffer.write(text.encode('utf-8'))
        def getvalue(self):
            self.buffer.seek(0)
            return self.buffer.read().decode()
        def empty(self):
            self.buffer.seek(0)
            self.buffer.truncate()
    class TestCase(unittest.TestCase):
        def setUp(self):
            self.env = Environment()
            self.env.stderr = Stderr()

# Generated at 2022-06-21 13:51:38.449149
# Unit test for function get_output_options
def test_get_output_options():
    import argparse
    parsed_args = argparse.Namespace(
        output_options=set([OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD])
    )
    messages = [requests.Request('GET', 'http://example.com/'),
                requests.PreparedRequest(),
                requests.Response()]
    expected_result = [(True, True), (True, True), (True, True)]
    for message, expected in zip(messages, expected_result):
        assert get_output_options(parsed_args, message) == expected

# Generated at 2022-06-21 13:51:41.799867
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'yolo'], 'utf-8') == ['yolo']
    assert decode_raw_args([b'y\xc3\xb3l\xc3\xb3'], 'utf-8') == ['yóló']

# Generated at 2022-06-21 13:51:48.573003
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # This tests that even args that are not UTF-8
    # but valid in the current user's locale
    # can be correctly processed.
    assert decode_raw_args(
        args=[b'httpie', str('--form').encode(), b'key=v\xf6lue'],
        stdin_encoding='utf-8'
    ) == ['httpie', '--form', 'key=völue']

# Generated at 2022-06-21 13:51:55.434299
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    env = Environment()
    args = parser.parse_args(
        args=[
            '--output-options=hdr',
            '--output-format=json',
            '--body',
            '--all',
            '--follow',
            '-v',
            'GET',
        ],
        env=env,
    )
    assert program(
        args=args,
        env=env,
    ) == ExitStatus.ERROR

# Generated at 2022-06-21 13:52:02.584618
# Unit test for function main
def test_main():
    assert main() == 0
    assert main(['--debug']) == 0
    assert main(['--debug', '--traceback']) == 0
    assert main(['--debug', '--output=raw']) == 0
    assert main(['--debug', '--follow=false']) == 0
    assert main(['--debug', '--output-file=raw']) == 0
    assert main(['--debug', '--timeout=10', 'https://httpbin.org/status/200']) == 0

# Generated at 2022-06-21 13:52:10.967418
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert(decode_raw_args(['a', 'b', 'c'], 'utf-8') == ['a', 'b', 'c'])
    assert(decode_raw_args([b'a', b'b', b'c'], 'utf-8') == ['a', 'b', 'c'])
    assert(decode_raw_args(['a', b'b', 'c'], 'utf-8') == ['a', 'b', 'c'])
    assert(decode_raw_args([b'a', 'b', b'c'], 'utf-8') == ['a', 'b', 'c'])

# Generated at 2022-06-21 13:53:35.311448
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser

    args = parser.parse_args([])

    assert get_output_options(args, 'aaa') == (False, False)

    assert get_output_options(args, requests.PreparedRequest()) == (False, False)

    assert get_output_options(args, requests.Response()) == (False, False)

    args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)

    args.output_options = [OUT_RESP_HEAD]
    assert get_output_options(args, requests.Response()) == (True, False)

    args.output_options = [OUT_REQ_BODY]

# Generated at 2022-06-21 13:53:44.605577
# Unit test for function get_output_options
def test_get_output_options():
    o = argparse.Namespace(
            output_options = ['all']
            )
    msg = requests.PreparedRequest()
    assert get_output_options(o, msg) == (True, True)
    msg = requests.Response()
    assert get_output_options(o, msg) == (True, True)
    o.output_options = ['none']
    assert get_output_options(o, msg) == (False, False)
    msg = requests.PreparedRequest()
    assert get_output_options(o, msg) == (False, False)

# Generated at 2022-06-21 13:53:50.315321
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=None)
    response = requests.Response()
    assert get_output_options(args, response) == (True, True)
    args.output_options = {OUT_RESP_HEAD}
    assert get_output_options(args, response) == (True, False)
    args.output_options = {OUT_RESP_BODY}
    assert get_output_options(args, response) == (False, True)

# Generated at 2022-06-21 13:53:57.458514
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.cli.environment import Environment
    args = parser.parse_args(args=['-p', 'chrome', 'http://httpbin.org/get'])

    env = Environment(
        program_name='http',
        config_dir='/',
        stdin=sys.stdin.buffer,
        stdin_isatty=True,
        stdout=sys.stdout.buffer,
        stdout_isatty=False,
        stderr=sys.stderr.buffer,
        stderr_isatty=False,
        stdin_encoding='utf-8',
        stdout_encoding='utf-8',
        stderr_encoding='utf-8'
    )


# Generated at 2022-06-21 13:54:06.284782
# Unit test for function main
def test_main():
    print(main(['--version']))
    print(main(['https://postman-echo.com/get?foo=bar', 'User-Agent: httpie_0123']))
    print(main(['https://postman-echo.com/get?foo=bar', '-v']))
    print(main(['https://postman-echo.com/get?foo=bar', '--auth', 'admin:123123']))
    print(main(['https://postman-echo.com/get?foo=bar', '--json', '{"data": "admin"}']))
    print(main(['https://postman-echo.com/get?foo=bar', '--headers', '{"data": "admin"}']))

# Generated at 2022-06-21 13:54:11.841203
# Unit test for function main
def test_main():
    old_argv = sys.argv
    old_stdout, old_stderr = sys.stdout, sys.stderr
    try:
        sys.argv = ['http']
        sys.stdout = sys.stderr = io.StringIO()
        main()
        assert sys.stdout.getvalue() and not sys.stderr.getvalue()
    finally:
        sys.argv = old_argv
        sys.stdout, sys.stderr = old_stdout, old_stderr


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 13:54:22.884409
# Unit test for function get_output_options

# Generated at 2022-06-21 13:54:32.975987
# Unit test for function program
def test_program():
    args = ['GET','https://www.google.com']
    env = Environment()
    program_return = program(args=args, env=env)
    assert program_return != ExitStatus.SUCCESS
    args = ['GET','https://www.google.com','-v']
    program_return = program(args=args, env=env)
    assert program_return == ExitStatus.SUCCESS
    args = ['GET','https://www.google.com','-h','Accept:text/*']
    program_return = program(args=args, env=env)
    assert program_return == ExitStatus.SUCCESS
    args = ['POST','https://www.google.com']
    program_return = program(args=args, env=env)
    assert program_return != ExitStatus.SUCCESS

# Generated at 2022-06-21 13:54:36.936819
# Unit test for function main
def test_main():
    args = ['/Users/jdperreault/httpie', '--body', 'This is a test.', 'http://httpbin.org/post']
    env = Environment()
    assert main(args=args, env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:54:43.886441
# Unit test for function program
def test_program():
    print("testing program")
    import sys
    import argparse
    
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.constants import ENV_CONFIG_DIR
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPHeader
    from httpie.plugins.builtin import HTTPCookie
    from httpie.plugins.builtin import HTTPieArgumentParser
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PLUGIN_MAP
    from httpie.status import ExitStatus
    # from httpie.cli.definition import parser

# Generated at 2022-06-21 13:55:38.291220
# Unit test for function get_output_options
def test_get_output_options():
    response = requests.Response()
    request = requests.PreparedRequest()
    assert get_output_options(response, [OUT_RESP_HEAD, OUT_REQ_BODY]) == (True, False)
    assert get_output_options(request, [OUT_RESP_HEAD, OUT_REQ_BODY]) == (False, True)
    assert get_output_options(response, [OUT_RESP_HEAD, OUT_REQ_HEAD]) == (True, False)
    assert get_output_options(request, [OUT_RESP_HEAD, OUT_REQ_HEAD, OUT_REQ_BODY]) == (True, True)

# Generated at 2022-06-21 13:55:43.656972
# Unit test for function main
def test_main():
    import os
    import sys
    import platform
    
    assert httpie_version=="2.3.0"
    assert requests_version=="2.23.0"
    assert pygments_version=='2.6.1'
    assert int(sys.version[0])==3
    assert sys.executable=='/Users/xueweizhang/opt/anaconda3/bin/python'
    assert platform.system()=='Darwin'
    assert platform.release()=='19.6.0'

# Generated at 2022-06-21 13:55:45.368484
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'\xe6\x96\x87', '2'], 'latin1') == ['文', '2']

# Generated at 2022-06-21 13:55:47.834052
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace(output_options=["json"],headers="[]")
    assert program(args,env) == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:55:56.885831
# Unit test for function decode_raw_args
def test_decode_raw_args():
    stdin_encoding = 'utf-8'
    some_bytes_args = [b'--headers', b'x-arg: bla\xe7']
    expected_str_args = ['--headers', 'x-arg: blaç']
    assert decode_raw_args(some_bytes_args, stdin_encoding) == expected_str_args
    # We also test the case where there is an already str arg,
    # to make sure these are not also decoded.
    some_bytes_and_str_args = [b'--headers', 'x-arg: astrarg']
    assert decode_raw_args(some_bytes_and_str_args, stdin_encoding) == some_bytes_and_str_args

# Generated at 2022-06-21 13:56:05.696973
# Unit test for function program
def test_program():
    env.stderr.writelines([
        f'HTTPie {httpie_version}\n',
        f'Requests {requests_version}\n',
        f'Pygments {pygments_version}\n',
        f'Python {sys.version}\n{sys.executable}\n',
        f'{platform.system()} {platform.release()}',
    ])
    env.stderr.write('\n\n')
    env.stderr.write(repr(env))
    env.stderr.write('\n')


# Generated at 2022-06-21 13:56:12.488422
# Unit test for function main
def test_main():
    import tempfile
    import os
    import pytest

    def run_main(args):
        return main(['http'] + args, env=Environment(
                config_dir=tempfile.mkdtemp(),
                stdin_isatty=False,
                stdin=None,
                stdin_encoding='utf8'))

    assert run_main(['--debug']) == ExitStatus.SUCCESS
    assert run_main(['GET', 'example.org']) == ExitStatus.SUCCESS
    assert run_main(['GET', '--timeout', '0.0000001', 'example.org']) == ExitStatus.ERROR_TIMEOUT
    assert run_main(['GET', '--max-redirects', '0', 'http://httpbin.org/redirect/3']) == ExitStatus.ERROR_TOO

# Generated at 2022-06-21 13:56:22.526765
# Unit test for function print_debug_info
def test_print_debug_info():
    # create a fake environment that write to a buffer
    # and set it to the global environment
    # this way, the debug info is printed to the buffer
    buffer = StringIO()
    env = Environment()
    env.stderr = buffer
    main(env=env)

    # parse the buffer and test the output
    buffer.seek(0)
    lines = buffer.readlines()
    assert lines[0].startswith("HTTPie")
    assert lines[1].startswith("Requests")
    assert lines[2].startswith("Pygments")
    assert lines[3].startswith("Python")
    assert lines[4].startswith("C:\\Users")
    assert lines[5].startswith("Windows")

# Generated at 2022-06-21 13:56:26.957811
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        [b'\xe3\x81\x82'],  # b'\xe3\x81\x82' is 'あ' in UTF-8
        'utf8'
    ) == ['あ']


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 13:56:36.072919
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_BODY, OUT_REQ_HEAD]
    message = requests.PreparedRequest()
    assert (True, True) == get_output_options(args, message)
    args.output_options = [OUT_RESP_BODY, OUT_RESP_HEAD]
    message = requests.Response()
    assert (True, True) == get_output_options(args, message)
    args.output_options = [OUT_RESP_HEAD]
    message = requests.PreparedRequest()
    assert (True, False) == get_output_options(args, message)

# Generated at 2022-06-21 13:58:38.457568
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from httpie.status import ExitStatus
    parser = argparse.ArgumentParser()
    args = parser.parse_args(args=['--debug'])
    if args:
        env = Environment(stdout=StringIO(), stderr=StringIO())
        print_debug_info(env)
        assert ExitStatus.SUCCESS == main(env=env)
    else:
        assert ExitStatus.ERROR == main(env=env)

# Generated at 2022-06-21 13:58:44.586613
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    parsed_args = parser.parse_args(
        args=[
            '--pretty=all',
            '--pretty-options', 'colors,format',
            # '--download-resume',
            '--download',
            '--verbose',
            # '--follow',
            '--check-status',
            '--output-file', 'test.html',
            'https://example.com',
        ]
    )
    # print(parsed_args)
    env = Environment()
    status = program(parsed_args, env)
    assert status != 0
    # assert False

# Generated at 2022-06-21 13:58:52.943037
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    content = io.StringIO()
    env = Environment()
    env.stderr = content
    print_debug_info(env)
    assert content.getvalue() == f'HTTPie {httpie_version}\nRequests {requests_version}\nPygments {pygments_version}\nPython {sys.version}\n{sys.executable}\n{platform.system()} {platform.release()}\n\n\n<context.Environment object at 0x7f55294f4be0>\n'
    content.close()

# Generated at 2022-06-21 13:58:57.973382
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from unittest.mock import Mock, MagicMock
    mock_stderr = StringIO()
    mock_env = Mock(stderr=mock_stderr)
    print_debug_info(mock_env)
    mock_env.stderr = MagicMock()
    # mock_env.stderr.writelines.assert_called_with()
    # mock_env.stderr.write.assert_called_once()

# Generated at 2022-06-21 13:59:01.192310
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    assert env.stderr.getvalue()[0:14] == 'HTTPie 1.0.3\n'
    #print(env.stderr.getvalue())

# Generated at 2022-06-21 13:59:12.510553
# Unit test for function main
def test_main():
    from click.testing import CliRunner
    from httpie.cli.constants import CONFIG_DIR
    from httpie.context import Environment
    import os
    import platform
    import shutil
    import sys
    from httpie import __version__ as httpie_version
    from requests import __version__ as requests_version
    from pygments import __version__ as pygments_version
    from httpie.output.writer import MESSAGE_SEPARATOR_BYTES
    from httpie.utils import get_os_environ, get_unicode_stream, get_unicode_stdin

    # Preprocess function main()
    # According to the python version, the type of sys.stdin will be different
    # In python2, sys.stdin.read() returns a string
    # In python3, sys.stdin.read() returns

# Generated at 2022-06-21 13:59:22.568319
# Unit test for function get_output_options
def test_get_output_options():
  args1 = argparse.Namespace(output_options = ["resp_header"])
  args2 = argparse.Namespace(output_options = ["body"])
  x1 = requests.PreparedRequest()
  x2 = requests.Response()
  x3 = requests.PreparedRequest()
  x4 = requests.Response()
  x1.headers = x2.headers = x3.headers = x4.headers = {}
  x1.body = x3.body = b"test"
  x2.body = x4.body = b"test"
  assert get_output_options(args1, x1) == (True, False)
  assert get_output_options(args2, x2) == (False, True)
  assert get_output_options(args1, x3) == (False, True)
 

# Generated at 2022-06-21 13:59:28.063290
# Unit test for function program
def test_program():
    from httpie.cli.context import Context
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    class FakeArgParser:
        def __init__(self):
            self.output_options = [OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD]
            self.stdout = self.stderr = None

    return program(FakeArgParser(), env=Context())


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 13:59:33.744601
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=[''])
    get_output_options(args, requests.PreparedRequest())[0]
    get_output_options(args, requests.PreparedRequest())[1]
    assert get_output_options(args, requests.Response())[0]
    assert get_output_options(args, requests.Response())[1]


# Generated at 2022-06-21 13:59:34.315904
# Unit test for function print_debug_info
def test_print_debug_info():
    pass