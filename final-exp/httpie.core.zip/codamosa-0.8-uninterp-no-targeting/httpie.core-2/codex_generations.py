

# Generated at 2022-06-21 13:52:18.797165
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=[b'foo'], stdin_encoding='utf-8') == ['foo']

# Generated at 2022-06-21 13:52:27.519195
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['UTF-8'], 'UTF-8') == ['UTF-8']
    # see http://stackoverflow.com/questions/6269765/what-does-u-prefix-do-in-python
    # FIXME: Why does this work under Python 2 and not Python 3?
    # assert decode_raw_args([u'UTF-8'.encode('UTF-8')], 'UTF-8') == [u'UTF-8']
    assert decode_raw_args([b'UTF-8'], 'UTF-8') == ['UTF-8']

# Generated at 2022-06-21 13:52:30.690966
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options=['b', 'hb'],
    )
    msg = requests.PreparedRequest()
    assert get_output_options(args, msg) == (False, True)



# Generated at 2022-06-21 13:52:42.669605
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    httpie_version_orgin = httpie_version

# Generated at 2022-06-21 13:52:50.775445
# Unit test for function decode_raw_args
def test_decode_raw_args():
    try:
        u'\u2713'.encode('ascii')
    except UnicodeEncodeError:
        pass
    else:
        assert False, 'Expected a UnicodeEncodeError to be raised.'

    b1 = '\xe2\x9c\x93'.encode('utf-8')
    b2 = '\xe2\x9c\x93'.encode('utf-8')

    assert decode_raw_args([b1, b2], stdin_encoding='utf-8') == [u'\u2713', u'\u2713']

# Generated at 2022-06-21 13:52:55.140322
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    fake_stderr = StringIO()
    env = Environment()
    env.stderr = fake_stderr
    print_debug_info(env=env)
    output = fake_stderr.getvalue().strip()
    assert all((
        'HTTPie' in output,
        'Requests' in output,
        'Pygments' in output,
        'Python' in output,
        sys.executable in output,
    ))

# Generated at 2022-06-21 13:53:05.950766
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options=[],
        output_file=None,
        output_file_specified = False,
    )
    assert get_output_options(args, requests.Response()) == (False, False)
    args = argparse.Namespace(
        output_options=[OUT_RESP_HEAD],
        output_file=None,
        output_file_specified = False,
    )
    assert get_output_options(args, requests.Response()) == (True, False)
    args = argparse.Namespace(
        output_options=[OUT_RESP_BODY],
        output_file=None,
        output_file_specified = False,
    )
    assert get_output_options(args, requests.Response()) == (False, True)

# Generated at 2022-06-21 13:53:11.314691
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = {
        OUT_REQ_HEAD,
        OUT_REQ_BODY,
        OUT_RESP_HEAD,
        OUT_RESP_BODY,
    }
    assert get_output_options(args, requests.PreparedRequest()) == (True, True)
    assert get_output_options(args, requests.Response()) == (True, True)

# Generated at 2022-06-21 13:53:23.179241
# Unit test for function program
def test_program():
    env = Environment()
    env.program_name = "myprogram"
    env.config.directory = "/usr/local/bin"
    parser = argparse.ArgumentParser()
    parser.add_argument('download', type=bool)
    parser.add_argument('output_file', type=None)
    parser.add_argument('download_resume', type=bool)
    parser.add_argument('output_options', type=list)
    parser.add_argument('headers', type=dict)
    parser.add_argument('output_file_specified', type=bool)
    parser.add_argument('check_status', type=bool)
    parser.add_argument('quiet', type=bool)
    parser.add_argument('follow', type=bool)
    args = parser.parse_args()
    args.download = True

# Generated at 2022-06-21 13:53:24.494168
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)

# Generated at 2022-06-21 13:54:40.240849
# Unit test for function decode_raw_args
def test_decode_raw_args():
    stdin_encoding = 'utf-8'

    def assert_decoded(args: List[Union[str, bytes]], expected: List[str]):
        assert decode_raw_args(args, stdin_encoding) == expected

    # noinspection SpellCheckingInspection
    assert_decoded(
        ['/home/žluťoučký/kůň', '--max-redirects=10'],
        [r'/home/žluťoučký/kůň', r'--max-redirects=10']
    )

# Generated at 2022-06-21 13:54:49.714622
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.compat import is_windows, is_py26
    from io import StringIO

    class MockEnvironment:
        def __init__(self):
            self.stderr = StringIO()

    env = MockEnvironment()
    print_debug_info(env)
    data = env.stderr.getvalue()
    assert 'HTTPie' in data
    assert 'Requests' in data
    assert 'Pygments' in data
    assert 'Python' in data
    if not is_py26:
        assert 'sys.implementation' in data
    assert f'is_windows={is_windows()}' in data
    assert f'is_py26={is_py26}' in data

# Generated at 2022-06-21 13:54:51.310864
# Unit test for function main
def test_main():
    # TODO: Add test
    pass


# Generated at 2022-06-21 13:55:01.542938
# Unit test for function program
def test_program():
    class TestArgParse:
        def __init__(self):
            self.headers = None
            self.output_options = None
            self.output_file = None
            self.download = None
            self.download_resume = None
            self.quiet = None
            self.follow = None
            self.check_status = None
            self.output_file_specified = None
            self.timeout = None
            self.max_redirects = None

    class TestEnvironment:
        def __init__(self):
            self.stdout = sys.stdout
            self.stdout_isatty = False
            self.stderr = sys.stderr

    args = TestArgParse()

# Generated at 2022-06-21 13:55:08.842219
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from httpie.config import Config
    from httpie.compat import is_windows
    config = Config(
        default_options=[],
        env=Environment(
            stdin_encoding='utf8',
            stdin=io.BytesIO(),
            stdin_isatty=is_windows,
            stdout_isatty=is_windows,
        )
    )
    assert decode_raw_args(['hello'], config.stdin_encoding) == ['hello']
    assert decode_raw_args([b'hello'], config.stdin_encoding) == ['hello']
    assert decode_raw_args([b'\x80\x81\x82'], config.stdin_encoding) == ['\u0080\u0081\u0082']

# Generated at 2022-06-21 13:55:12.542788
# Unit test for function main
def test_main():
    #result = main('httpie')
    result = main('httpie','--debug','--traceback','--output-options=all')
    print(type(result))
    print(result)
    assert result == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:55:20.797869
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from httpie import ExitStatus
    from httpie.cli.constants import OUTPUT_OPTIONS
    result = []
    for output_option in OUTPUT_OPTIONS:
        result.append(decode_raw_args([output_option], stdin_encoding='utf-8'))
    assert result == [[OUTPUT_OPTIONS[0]], [OUTPUT_OPTIONS[1]],
                      [OUTPUT_OPTIONS[2]], [OUTPUT_OPTIONS[3]],
                      [OUTPUT_OPTIONS[4]]]

    result = decode_raw_args([], stdin_encoding='utf-8')
    assert result == []



# Generated at 2022-06-21 13:55:32.271638
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # Test against invalid encoding
    invalid_encoding = 'invalid_encoding'
    original_stdin = sys.stdin
    sys.stdin = io.StringIO('test\n')
    assert decode_raw_args([b'--', b'--foo=bar'], invalid_encoding)[1] == b'--foo=bar'
    sys.stdin = original_stdin

    # Test against invalid string
    invalid_str = "S".encode('cp1252')
    assert decode_raw_args([invalid_str], 'cp1252')[0] == invalid_str.decode('cp1252', 'surrogateescape')


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 13:55:35.562877
# Unit test for function main
def test_main():
    sys.argv = ['httpie', 'https://httpbin.org/get']
    exit_status = main()
    assert exit_status == ExitStatus.SUCCESS


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 13:55:44.318128
# Unit test for function main
def test_main():
    # https://github.com/jakubroztocil/httpie/pull/1247
    # from httpie import status
    # from httpie.cli import main, httpie_version
    # from httpie.config import DEFAULT_CONFIG_DIR
    import platform
    # from tempfile import TemporaryDirectory
    # from pytest import raises
    # from httpie.plugins import plugin_manager
    from httpie.context import Environment
    from httpie.status import http_status_to_exit_status
    # from httpie.client import collect_messages
    from httpie.config import Config
    from httpie.downloads import Downloader
    # from httpie.output.writer import write_stream, write_message, MESSAGE_SEPARATOR_BYTES
    # import os
    import requests
    # import py

# Generated at 2022-06-21 13:56:23.066924
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a', 'b'], 'utf-8') == ['a', 'b']
    assert decode_raw_args(['a', b'b'], 'utf-8') == ['a', 'b']

# Generated at 2022-06-21 13:56:26.059366
# Unit test for function decode_raw_args
def test_decode_raw_args():
    a = ['GET']
    assert decode_raw_args(a, 'utf-8') == a
    a = [b'GET']
    assert decode_raw_args(a, 'utf-8') == ['GET']

# Generated at 2022-06-21 13:56:31.033728
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        args=[
            '-',
            b'\xc4\x85',
            '\x10',
            b'\x10',
        ],
        stdin_encoding='UTF-8',
    ) == [
        '-',
        'ą',
        '\x10',
        '\x10',
    ]

# Generated at 2022-06-21 13:56:42.325342
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a'], 'utf-8') == ['a']
    assert decode_raw_args([u'a'], 'utf-8') == ['a']
    assert decode_raw_args([b'a'], 'utf-8') == ['a']
    assert decode_raw_args(['a', u'b', b'c'], 'utf-8') == ['a', 'b', 'c']
    assert decode_raw_args([b'a', u'b', 'c'], 'utf-8') == ['a', 'b', 'c']
    assert decode_raw_args([b'a', 'b', u'c'], 'utf-8') == ['a', 'b', 'c']

# Generated at 2022-06-21 13:56:53.971898
# Unit test for function program
def test_program():
    import sys
    import io
    import httpie.input
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_items, KeyValueArgType
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.config import Config
    test_url = 'https://httpbin.org/get'

    argv = ['http', test_url]

    parsed_args = parser.parse_args(argv)
    stdin = io.StringIO('')
    stdin.encoding = 'utf8'
    stdout = io.StringIO()
    stderr = io.StringIO()
    parsed_args.auth = None
    parsed_args.output_options = ()
    parsed_args.download = False
    parsed_args.follow = False
    parsed_args.output

# Generated at 2022-06-21 13:56:59.554798
# Unit test for function program
def test_program():
    print('### test_program ###')
    from httpie.cli.definition import parser
    parsed_args = parser.parse_args(['--check-status', '--method=GET', 'https://httpbin.org'])
    program(parsed_args, env=Environment())


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 13:57:06.083686
# Unit test for function main
def test_main():
    exit_status = main(
        [
            'http',
            'https://dummy.restapiexample.com/api/v1/employees',
            'https://dummy.restapiexample.com/api/v1/update/21',
            'https://dummy.restapiexample.com/api/v1/delete/2'
        ]
    )
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:57:15.384108
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[])

    def check(message, exp_with_headers, exp_with_body):
        actual_with_headers, actual_with_body = get_output_options(args, message)
        assert actual_with_headers is exp_with_headers
        assert actual_with_body is exp_with_body

    check(requests.PreparedRequest(), False, False)
    check(requests.Response(), False, False)

    args.output_options = [OUT_REQ_HEAD]
    check(requests.PreparedRequest(), True, False)
    check(requests.Response(), False, False)

    args.output_options = [OUT_RESP_HEAD]
    check(requests.PreparedRequest(), False, False)

# Generated at 2022-06-21 13:57:19.359036
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['--json', b'{"hello": "world"}'], 'utf-8') == ['--json', '{"hello": "world"}']
    assert decode_raw_args(['-f', b'file.txt'], 'utf-8') == ['-f', 'file.txt']

# Generated at 2022-06-21 13:57:27.818961
# Unit test for function program
def test_program():
    from httpie.cli import environment
   # from httpie.output.streams import NoOpStream
    from httpie.plugins.builtin import httpie_sessions
    import pytest
    env = environment.Environment()
    #pytest.main()
    #env = environment.Environment(stdout=NoOpStream(), stderr=NoOpStream())
    #env = environment.Environment(stdout=NoOpStream(), stderr=NoOpStream())
    #env = environment.Environment()
    env.stdout_isatty = env.stderr_isatty = False

# Generated at 2022-06-21 13:59:36.518982
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    env = Environment(default_options=[], defaults=True, config_dir=DEFAULT_CONFIG_DIR)
    out = io.StringIO()
    env.stderr = out
    print_debug_info(env)
    assert out.getvalue() == 'HTTPie X.Y.Z\nRequests X.Y.Z\nPygments X.Y.Z\nPython X.Y.Z\n\n\n<httpie.context.Environment object at 0x10e040d50>\n'

# Generated at 2022-06-21 13:59:45.289746
# Unit test for function get_output_options
def test_get_output_options():
    opt_req_headers = True
    opt_req_body = OUT_REQ_BODY in [OUT_REQ_BODY]
    opt_resp_headers = True
    opt_resp_body = OUT_RESP_BODY in [OUT_RESP_BODY]
    is_request = True
    message = requests.PreparedRequest()
    my_result = get_output_options(args = argparse.Namespace(output_options = [OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY]), message = message)
    expected_result = (True, True)

# Generated at 2022-06-21 13:59:55.941091
# Unit test for function main
def test_main():
    from httpie.core import main
    from httpie import ExitStatus
    from httpie.cli.constants import OUTPUT_OPTIONS
    assert ExitStatus.SUCCESS == main([])
    assert ExitStatus.SUCCESS == main([])
    assert ExitStatus.SUCCESS == main(['http'])
    assert ExitStatus.SUCCESS == main(['http', 'https://www.example.com'])
    assert ExitStatus.SUCCESS == main(['http', 'https://www.example.com', '-v'])
    assert ExitStatus.SUCCESS == main(['http', 'https://www.example.com', '-v', '--follow'])

# Generated at 2022-06-21 14:00:03.918749
# Unit test for function program
def test_program():
    exit_status : ExitStatus = 0
    args = ["http", "google.com"]
    env = Environment()
    exit_status = main(args, env)
    assert exit_status == 0

    args = ["http", "--json", "--form", "--form-string", "var=val", "--verbose", "google.com"]
    env = Environment()
    exit_status = main(args, env)
    assert exit_status == 0

    args = ["http", "--download", "--check-status", "google.com"]
    env = Environment()
    exit_status = main(args, env)
    assert exit_status == 0

# Generated at 2022-06-21 14:00:12.773182
# Unit test for function decode_raw_args

# Generated at 2022-06-21 14:00:14.772603
# Unit test for function main
def test_main():
    main(['--help'])


if __name__ == '__main__':
    # Unit test main
    test_main()

# Generated at 2022-06-21 14:00:22.363387
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_BODY, OUT_RESP_HEAD]

    message = requests.PreparedRequest()

    assert get_output_options(args=args, message=message) == (True, True)

    message = requests.Response()

    assert get_output_options(args=args, message=message) == (True, True)

# Generated at 2022-06-21 14:00:26.228581
# Unit test for function program
def test_program():
    class FakeArgs():
        def __init__(self):
            self.output_file = None
            self.output_file_specified = None

    class FakeEnv():
        def __init__(self):
            self.stderr = 'stderr'
    program(FakeArgs(), FakeEnv())

# Generated at 2022-06-21 14:00:32.540982
# Unit test for function print_debug_info
def test_print_debug_info():
    class Env:
        class Config:
            class Detect:
                def get_best_encoding():
                    return 'utf-8'
        config = Config()
        stderr = StringIO()
        def __init__(self):
            self.stdout_isatty = True
    e = Env()
    print_debug_info(e)
    assert 'HTTPie' in e.stderr.getvalue()
    assert 'Requests' in e.stderr.getvalue()
    assert 'Pygments' in e.stderr.getvalue()
    assert 'Python' in e.stderr.getvalue()
