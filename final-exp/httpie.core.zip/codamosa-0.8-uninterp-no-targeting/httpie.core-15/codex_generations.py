

# Generated at 2022-06-21 13:51:17.597272
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from tempfile import TemporaryDirectory
    from httpie import Environment

    class Stderr(StringIO):
        def write(self, s):
            super().write(s)
            if s.endswith('\n'):
                self.flush()

    with TemporaryDirectory() as config_dir:
        config_file_path = os.path.join(config_dir, 'config.json')
        with open(config_file_path, 'w') as config_file:
            config_file.write('{\n  "default_options": ["--form"]\n}')
        with Stderr() as stderr:
            env = Environment(config_dir=config_dir, stderr=stderr)
            print_debug_info(env)

# Generated at 2022-06-21 13:51:28.571459
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.follow = True  # --download implies --follow.
    args.output_file = 'output.txt'
    args.download = False
    args.download_resume = True
    args.headers = []
    args.output_options = []
    args.check_status = False
    args.quiet = False

    env = Environment()
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.stdin_encoding = 'ascii'
    env.stdin = input()
    env.stdout = ''
    env.stderr = ''
    env.log_level = 'info'
    env.output_options = []
    env.explicit_output_options = False
    env.preferred_encod

# Generated at 2022-06-21 13:51:37.808769
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from httpie.cli.constants import DEFAULT_CLI_ENCODING

    assert decode_raw_args(['hi'], DEFAULT_CLI_ENCODING) == ['hi']
    assert decode_raw_args([b'hi'], DEFAULT_CLI_ENCODING) == ['hi']
    assert decode_raw_args([b'h\xe9'], DEFAULT_CLI_ENCODING) == ['hé']
    assert decode_raw_args([b'h\xe9', b'hi', 'hi'], DEFAULT_CLI_ENCODING) == ['hé', 'hi', 'hi']

# Generated at 2022-06-21 13:51:40.605725
# Unit test for function print_debug_info
def test_print_debug_info():
    # patch stderr
    env = Environment()
    env.stderr = MagicMock()
    print_debug_info(env)
    env.stderr.write.assert_called_with('HTTPie 0.9.9\nRequests 2.10.0\nPygments 2.1.3\nPython 2.7.10\n/usr/local/bin/python2.7\nDarwin 15.0.0')


# Generated at 2022-06-21 13:51:44.865312
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = [b'args', 'str', b'args2']
    stdin_encoding = 'utf-8'
    expected_result = ['args', 'str', 'args2']

    assert decode_raw_args(args, stdin_encoding) == expected_result

# Generated at 2022-06-21 13:51:56.750615
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    import argparse
    import requests
    # noinspection PyTypeChecker
    class ArgparseNamespace:
        """
        Simple class for representing an Argparse Namespace object
        """
        def __init__(self):
            self.output_options = None

    args = ArgparseNamespace()
    msg = requests.PreparedRequest()
    args.output_options = []
    assert get_output_options(args, msg) == (False, False)
    args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(args, msg) == (True, False)

# Generated at 2022-06-21 13:51:57.476448
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-21 13:52:08.202533
# Unit test for function program
def test_program():
    from httpie.cli.parser import parser
    from httpie import ExitStatus

    args_with_url = parser.parse_args(['httpie', '-v', 'http://127.0.0.1'])
    assert program(args_with_url, None) == ExitStatus.SUCCESS

    args_without_url = parser.parse_args(['httpie', '-v'])
    assert program(args_without_url, None) == ExitStatus.ERROR

    args_with_piped_input = parser.parse_args(['httpie', '-v', 'http://127.0.0.1'])
    sys.stdin = io.StringIO("test_stdin")
    assert program(args_with_piped_input, None) == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:52:16.350642
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from httpie.cli import get_raw_httpie_args
    args_ver_1 = [
        '-v', 'POST',
        'http://example.com/',
        'foo=bar',
        'baz=bar baz',
        'bin=@test-bin.png'
    ]
    decoded_args = decode_raw_args(get_raw_httpie_args(args_ver_1), 'utf-8')
    vers_2 = ['-v', 'POST', 'http://example.com/', 'foo=bar', 'baz=bar baz', 'bin=@test-bin.png']
    assert decoded_args == vers_2

# Generated at 2022-06-21 13:52:23.021019
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options = [])
    print(get_output_options(args, requests.Request()))
    args = argparse.Namespace(output_options = ['H'])
    print(get_output_options(args, requests.Response()))
    args = argparse.Namespace(output_options = ['B'])
    print(get_output_options(args, requests.PreparedRequest()))
    args = argparse.Namespace(output_options = ['H', 'hB'])
    print(get_output_options(args, requests.PreparedRequest()))
    args = argparse.Namespace(output_options = ['HB'])
    print(get_output_options(args, requests.Response()))
    args = argparse.Namespace(output_options = ['h'])


# Generated at 2022-06-21 13:52:49.692315
# Unit test for function main
def test_main():
    import pytest
    from io import StringIO
    args = ['httpie', '--debug', 'get', 'google.com']
    env = Environment()
    env.stdout = StringIO()
    env.stderr = StringIO()
    main(args=args, env=env)
    output = env.stdout.getvalue()
    assert 'HTTPie' in output
    assert 'Requests' in output
    assert 'Python' in output

# Generated at 2022-06-21 13:52:52.579561
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'a', 'b', 'c'], 'utf-8') == ['a', 'b', 'c']
    assert decode_raw_args([b'a', 'b', b'c'], 'utf-8') == ['a', 'b', 'c']
    assert decode_raw_args([b'a', b'b', b'c'], 'utf-8') == ['a', 'b', 'c']

# Generated at 2022-06-21 13:53:03.496395
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import os
    import codecs
    from httpie.context import Environment
    from httpie.plugins.builtin import BasicAuth
    import httpie.cli.parser
    from httpie.cli.utils import args_from_unicode_string
    from httpie.compat import urlunparse

    headers = [h for h in BasicAuth.arg_parser.headers if h.name in ('Authorization', 'Proxy-Authorization')]
    arg_parser = argparse.ArgumentParser()
    httpie.cli.parser.build_parser(arg_parser, headers)
    args = arg_parser.parse_args(args_from_unicode_string('http:www.example.com'))
    env = Environment(args=args)
    assert env.stdin_encoding == sys.stdin.encoding

# Generated at 2022-06-21 13:53:14.196962
# Unit test for function program
def test_program():
    import pytest
    #import cProfile
    #import pstats
    #from io import StringIO

    #pr = cProfile.Profile()
    #pr.enable()

    # test an exiting code
    args = helper_test_args(exit_status=ExitStatus.SUCCESS)
    assert program(args=args, env=Environment()) == ExitStatus.SUCCESS

    #test an error code
    assert program(args=helper_test_args(exit_status=ExitStatus.ERROR), env=Environment()) == ExitStatus.ERROR

    # test exception
    with pytest.raises(SystemExit):
        args = helper_test_args(exit_status=ExitStatus.ERROR)
        args.output_options = ['invalid']
        program(args=args, env=Environment())

    #pr.disable()
    #s

# Generated at 2022-06-21 13:53:25.547225
# Unit test for function program
def test_program():
    """
    Test for program function.

    """
    class ParsedArgs():
        """
        Mock for class ParsedArgs.

        """
        def __init__(self):
            self.output_options = []
        def __repr__(self):
            return 'ParsedArgs object'

    class Environment():
        """
        Mock for class Environment.

        """
        def __init__(self):
            self.stdout = sys.stdout
            self.stderr = sys.stderr
            self.stdout_isatty = sys.stdout.isatty()
        def __repr__(self):
            return 'Environment object'

    args = ParsedArgs()
    env = Environment()
    status_code = program(args, env)
    assert status_code == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:53:26.593847
# Unit test for function main
def test_main():
    #todo
    pass



# Generated at 2022-06-21 13:53:30.826825
# Unit test for function main
def test_main():

    from httpie.context import Environment

    env=Environment(config_dir='/path/to/config.json')
    args=['get', '127.0.0.1/']
    assert main(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:53:31.781021
# Unit test for function program
def test_program():
    assert program(args=['--help'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:53:36.081501
# Unit test for function get_output_options
def test_get_output_options():
    test_args = argparse.Namespace(
        output_options = ['json', 'stdout', 'all'],
    )
    assert get_output_options(test_args, requests.PreparedRequest()) == (True, True)
    assert get_output_options(test_args, requests.Response()) == (True, True)



# Generated at 2022-06-21 13:53:39.137201
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    try:
        print_debug_info(env)
    except Exception:
        traceback.print_exc()
        assert False

# Generated at 2022-06-21 13:54:22.065272
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.output import JSONOutput, OutputOptions
    from httpie.tests.utils import mock_environment

    args = parser.parse_args(['http', 'example.org'])
    args.output_options = OutputOptions.OUTPUT_OPTIONS_MAP.get('"')
    env = mock_environment()

    actual = program(args, env)
    assert isinstance(env.stdout, JSONOutput)
    assert actual == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:54:32.019147
# Unit test for function program

# Generated at 2022-06-21 13:54:40.277777
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=OUT_REQ_HEAD | OUT_REQ_BODY )
    req = requests.PreparedRequest()
    assert get_output_options(args, req) == (True, True)

    args = argparse.Namespace(output_options=OUT_REQ_HEAD)
    req = requests.PreparedRequest()
    assert get_output_options(args, req) == (True, False)

    args = argparse.Namespace(output_options=OUT_RESP_HEAD | OUT_RESP_BODY)
    resp = requests.Response()
    assert get_output_options(args, resp) == (True, True)

# Generated at 2022-06-21 13:54:43.687501
# Unit test for function program
def test_program():
    args=['GET', 'www.google.com']
    print('\n')
    print(program(args, sys.stdin))

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 13:54:54.088458
# Unit test for function get_output_options
def test_get_output_options():
    from .constants import OUT_REQ_BODY
    from .constants import OUT_REQ_HEAD
    from .constants import OUT_RESP_BODY
    from .constants import OUT_RESP_HEAD

    from .definition import parser

    from .output.argtypes import KeyValueArg

    args = parser.parse_args(args=[
        "--debug", 
        'https://httpbin.org/headers'
    ])

    request = requests.PreparedRequest()
    response = requests.Response()

    assert get_output_options(args, request) == (True, True)
    assert get_output_options(args, response) == (True, True)

    args.output_options = [OUT_REQ_BODY, OUT_REQ_HEAD]
    assert get_output_options(args, request)

# Generated at 2022-06-21 13:54:57.048502
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from httpie.cli.constants import DEFAULT_CLI_ENCODING
    assert decode_raw_args(['a', b'b'], DEFAULT_CLI_ENCODING) == ['a', 'b']

# Generated at 2022-06-21 13:55:06.440830
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # TODO: Write unit test.
    args = [
        b'http',
        b'--json',
        b'--verbose',
        b'--debug',
        b'http://httpbin.org/post',
    ]
    env = Environment()
    env.stdin_encoding = 'ascii'

    decoded_args = decode_raw_args(args, env.stdin_encoding)
    assert decoded_args[0]==b'http'.decode(encoding=env.stdin_encoding)
    assert decoded_args[1]==b'--json'.decode(encoding=env.stdin_encoding)
    assert decoded_args[2] == b'--verbose'.decode(encoding=env.stdin_encoding)
    assert decoded_args

# Generated at 2022-06-21 13:55:09.622889
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(
        args=['httpie', '--debug'],
        env=Environment(),
    )
    program(args=args, env=Environment())

# Generated at 2022-06-21 13:55:12.911714
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stdout.write('Hello, world!\n')
    env.stderr.write('Goodbye, world!\n')
    print_debug_info(env)

# Generated at 2022-06-21 13:55:15.305344
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    assert print_debug_info(env=Environment(stderr=io.StringIO())) is None

# Generated at 2022-06-21 13:56:07.970296
# Unit test for function program
def test_program():
    env = Environment()
    args = parser.parse_args(args = ['https://blog.arroyocode.com'], env=env)
    status = program(args,env)
    assert status == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:56:20.017477
# Unit test for function program
def test_program():
    from io import BytesIO

    from httpie.compat import is_windows
    from httpie.core import main
    from httpie.context import Environment

    """
    from httpie import ExitStatus
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.client import collect_messages
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    """

    args = ['--quiet', 'https://httpbin.org/get']
    exit

# Generated at 2022-06-21 13:56:27.068887
# Unit test for function main
def test_main():
    from httpie.cli.constants import OUT_REQ_BODY, OUT_BODY_AUTO, OUT_REQ_HEAD
    from httpie.context import Environment
    from httpie.output.writer import MESSAGE_SEPARATOR_BYTES
    from io import StringIO
    import requests
    import sys

    env = Environment()
    env.stdout = StringIO()
    env.stderr = StringIO()
    env.stdin_encoding = 'utf8'
    # args = ['http', '--debug', 'example.com']
    args = ['http', '--output=stdout', '-b', 'example.com']
    env.config.default_options = ['-b']
    # assert main(args=args, env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:56:33.213791
# Unit test for function main
def test_main():
    import subprocess
    from httpie import ExitStatus
    from httpie.cli import main
    subprocess.check_call(('python', str(main.__code__.co_filename), '--version'))
    assert main([str(main.__code__.co_filename), '--version']) == ExitStatus.SUCCESS


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 13:56:38.689775
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(stdin_isatty=True, stdout_isatty=False, stdin=sys.stdin, stdout=sys.stdout,
                      stdout_binary=False, stderr=sys.stderr, stdout_isatty=False)
    print_debug_info(env)



# Generated at 2022-06-21 13:56:43.871342
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options=[
            OUT_REQ_HEAD,
            OUT_REQ_BODY,
            OUT_RESP_HEAD,
            OUT_RESP_BODY,
        ]
    )
    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (True, True)
    message = requests.Response()
    assert get_output_options(args, message) == (True, True)

# Generated at 2022-06-21 13:56:45.346640
# Unit test for function program
def test_program():
    import pytest
    return pytest.main([__file__])



# Generated at 2022-06-21 13:56:56.698801
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'--form', b'a=1', b'\xc3\xb6'], 'ascii') == ['--form', 'a=1', '\ufffd']
    assert decode_raw_args([b'--form', b'a=1', b'\xc3\xb6'], 'utf-8') == ['--form', 'a=1', 'ö']
    assert decode_raw_args([b'--form', b'a=1', b'\x80'], 'ascii') == ['--form', 'a=1', '\ufffd']
    assert decode_raw_args(['--form', 'a=1', '\xc3\xb6'], 'ascii') == ['--form', 'a=1', '\xc3\xb6']

# Generated at 2022-06-21 13:57:06.591042
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options=['out_head', 'out_body'],
    )
    request = requests.PreparedRequest()
    assert get_output_options(args=args, message=request) == (True, True)
    response = requests.Response()
    assert get_output_options(args=args, message=response) == (True, True)

    args = argparse.Namespace(
        output_options=['out_head'],
    )
    assert get_output_options(args=args, message=request) == (True, False)
    assert get_output_options(args=args, message=response) == (True, False)

# Generated at 2022-06-21 13:57:10.621077
# Unit test for function print_debug_info
def test_print_debug_info():
    """
    Unit test for function print_debug_info
    """
    import io
    import sys
    stderr = sys.stderr
    sys.stderr = io.StringIO()
    print_debug_info()
    sys.stderr.close()
    sys.stderr = stderr

# Generated at 2022-06-21 13:59:10.158533
# Unit test for function main
def test_main():
    # print(program(['get', 'www.google.com']))
    print(program(['get', 'www.google.com']))

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-21 13:59:15.642759
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from httpie.context import Environment

    env = Environment()
    env.stdout = StringIO()
    env.stderr = StringIO()
    env.stdin = StringIO()

    print_debug_info(env)
    assert env.stderr.getvalue().endswith('\n\n')

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 13:59:22.181676
# Unit test for function program
def test_program():
    url = "http://httpbin.org/get"
    args = argparse.Namespace()
    args.follow = True
    args.verbose = True
    args.output_options = ("hHbB", ["h", "H", "b", "B"])
    args.output_file = None
    args.output_file_specified = False
    args.headers = []
    args.download = True
    args.download_resume = True
    assert program(args, Environment()) == 0

# Generated at 2022-06-21 13:59:26.125482
# Unit test for function decode_raw_args
def test_decode_raw_args():
    arg = "abcd"
    stdin_encoding = "utf-8"
    result = decode_raw_args([arg.encode("utf-8")], stdin_encoding)
    assert result[0] == arg
    assert result[0] == "abcd"
    assert result[0].encode("utf-8") == b"abcd"

# Generated at 2022-06-21 13:59:35.905497
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)

# Generated at 2022-06-21 13:59:38.074954
# Unit test for function program
def test_program():
    program(['-v','https://api.github.com/repos/jakubroztocil/httpie'])

# Generated at 2022-06-21 13:59:39.226597
# Unit test for function program
def test_program():
    program()
    

# Generated at 2022-06-21 13:59:48.560362
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = None
    message = requests.PreparedRequest()
    actual = get_output_options(args, message)
    expected = (False, False)
    assert actual == expected

    args.output_options = [OUT_REQ_HEAD]
    message = requests.PreparedRequest()
    actual = get_output_options(args, message)
    expected = (True, False)
    assert actual == expected

    args.output_options = [OUT_REQ_BODY]
    message = requests.PreparedRequest()
    actual = get_output_options(args, message)
    expected = (False, True)
    assert actual == expected

    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY]
    message = requests.Pre

# Generated at 2022-06-21 13:59:51.000073
# Unit test for function main
def test_main():
    "Checks whether main function is working properly"

    assert(main(['http','www.google.com'])==0)

# Generated at 2022-06-21 13:59:54.252458
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        [b'\xe4\xb8\x96\xe7\x95\x8c'],
        stdin_encoding='utf-8'
    ) == ['世界']

