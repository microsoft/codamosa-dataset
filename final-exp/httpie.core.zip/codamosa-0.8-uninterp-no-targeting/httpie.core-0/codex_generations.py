

# Generated at 2022-06-21 13:51:10.170591
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    env = Environment()
    env.stderr = StringIO()
    print_debug_info(env)
    output = env.stderr.getvalue()
    assert f'HTTPie {httpie_version}\n' in output
    assert f'Requests {requests_version}\n' in output


# Generated at 2022-06-21 13:51:15.291961
# Unit test for function program
def test_program():
    from unittest.mock import Mock
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.definition import parser
    from httpie.context import Environment

    args = parser.parse_args(['get', 'http://httpbin.org/headers'])
    env = Environment()
    program(args, env)


if __name__ == '__main__':
    sys.exit(int(main() or 0))

# Generated at 2022-06-21 13:51:27.160180
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=['chanel', 'fujifilm'])
    message = requests.PreparedRequest(headers={'Host': 'example.com', 'Content-Type': 'multipart/form-data'}, body='body')
    actual = get_output_options(args, message)
    expected = (False, False)
    assert actual == expected

    args = argparse.Namespace(output_options=['chanel', 'fujifilm', 'request-headers'])
    message = requests.PreparedRequest(headers={'Host': 'example.com', 'Content-Type': 'multipart/form-data'}, body='body')
    actual = get_output_options(args, message)
    expected = (True, False)
    assert actual == expected


# Generated at 2022-06-21 13:51:33.904960
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # Test normal case
    assert decode_raw_args(["foo", "bar"], "utf8") == ["foo", "bar"]

    # Test bytes in args
    assert decode_raw_args([b"foo", b"bar"], "utf8") == ["foo", "bar"]

    # Test mixed case
    assert decode_raw_args(["foo", b"bar"], "utf8") == ["foo", "bar"]

# Generated at 2022-06-21 13:51:38.567471
# Unit test for function print_debug_info
def test_print_debug_info():
    class TestStdErr():
        def __init__(self):
            self.written = []

        def writelines(self, obj):
            self.written = obj

    testenv = Environment()
    testenv.stderr = TestStdErr()

    print_debug_info(testenv)

    assert len(testenv.stderr.written) == 6
    assert testenv.stderr.written[0].startswith('HTTPie ')
    assert testenv.stderr.written[1].startswith('Requests ')
    assert testenv.stderr.written[2].startswith('Pygments ')
    assert testenv.stderr.written[3].startswith('Python ')
    assert testenv.stderr.written[4].startswith('"') and test

# Generated at 2022-06-21 13:51:42.815853
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_BODY, OUT_RESP_HEAD]

    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (False, True)
    message = requests.Response()
    assert get_output_options(args, message) == (True, False)

# Generated at 2022-06-21 13:51:52.399077
# Unit test for function main
def test_main():
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    output_options = (
        OUT_REQ_HEAD, OUT_RESP_HEAD, OUT_REQ_BODY,
        OUT_RESP_BODY
    )
    args = ['--output-options', ','.join(output_options), 'https://httpie.org']
    assert main(args=args, env=Environment()) == ExitStatus.SUCCESS


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 13:52:03.193327
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from contextlib import redirect_stderr
    from unittest import mock
    from . import main
    env = Environment()
    env.stderr = StringIO()
    with redirect_stderr(env.stderr):
        main(['--debug'], env=env)
    env.stderr.seek(0)
    class t_mock():
        def __init__(self):
            pass
        def __getattribute__(self, name):
            if name == 'name':
                return 'nt'
            else:
                return 'Windows'
    with mock.patch('platform.system', return_value=t_mock()):
        buff = env.stderr.read()

# Generated at 2022-06-21 13:52:10.290245
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a', b'b'], 'ascii') == ['a', 'b']
    assert decode_raw_args(['-b', b'b'], 'utf-8') == ['-b', 'b']
    assert decode_raw_args(['-f', b'b'], 'utf-8') == ['-f', 'b']
    assert decode_raw_args(['--form', b'b'], 'utf-8') == ['--form', 'b']

# Generated at 2022-06-21 13:52:17.319210
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        args=['a', 'b'],
        stdin_encoding='utf-8'
    ) == ['a', 'b']
    assert decode_raw_args(
        args=[b'a', 'b'],
        stdin_encoding='utf-8'
    ) == ['a', 'b']
    assert decode_raw_args(
        args=[b'\xe2\x82\xac', 'b'],
        stdin_encoding='utf-8'
    ) == ['€', 'b']



# Generated at 2022-06-21 13:52:55.737801
# Unit test for function main
def test_main():
    import io
    import random
    import tempfile
    import os

    stdin = io.BytesIO(b'123\n456\n789\n')
    stdout = io.BytesIO()
    stderr = io.BytesIO()

    env = Environment(
        stdin=stdin,
        stdout=stdout,
        stderr=stderr,
        stdin_isatty=True,
        stdout_isatty=True,
        stderr_isatty=True,
    )

    progname = os.path.basename(__file__)
    args = [progname, '--form', '--json', 'https://httpbin.org/post',
            'a=b']
    main(args, env=env)



# Generated at 2022-06-21 13:52:58.331423
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'a', 'b', 'c'], 'utf-8') == ['a', 'b', 'c']

# Generated at 2022-06-21 13:53:08.061878
# Unit test for function program
def test_program():
    from click.testing import CliRunner
    from httpie.cli import cli
    # argv = ['-h']

    # argv = ['httpbin.org']
    # argv = ['https://api.github.com/events']

    # argv = ['http://httpbin.org/get', 'Accept:application/json']
    # argv = ['http://httpbin.org/headers', 'Accept:application/json']
    # argv = ['http://httpbin.org/ip']
    # argv = ['http://httpbin.org/user-agent']
    # argv = ['http://httpbin.org/headers']
    # argv = ['http://httpbin.org/deny']
    # argv = ['http://httpbin.org/redirect/4']

    # argv = ['http://

# Generated at 2022-06-21 13:53:12.961041
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        [b'--form'],
        'UTF-8'
    ) == ['--form']
    assert decode_raw_args(
        [b'\xE2\x98\x83'],
        'UTF-8'
    ) == ['☃']


if __name__ == '__main__':
    sys.exit(main() or 0)

# Generated at 2022-06-21 13:53:20.512263
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # sys.stdin.encoding can be None
    if sys.stdin.encoding is not None:
        assert decode_raw_args(["\xF0\x9F\x8D\xB9\xEF\xB8\x8F"], sys.stdin.encoding) == ["\U0001F531"]
    assert decode_raw_args(["\xE2\x98\x83"], "utf-8") == ["\u2603"]

# Generated at 2022-06-21 13:53:28.544678
# Unit test for function get_output_options
def test_get_output_options():
    class request:
        headers = [{"Accept-Encoding": "gzip, deflate"}]

    class response:
        headers = [{"Content-Encoding": "gzip"}]

    # for request check

# Generated at 2022-06-21 13:53:33.842776
# Unit test for function get_output_options
def test_get_output_options():

    class MockArg(argparse.Namespace):
        pass

    mock_arg = MockArg()
    mock_arg.output_options = ['resp_body', 'resp_headers', 'resp_cookies']

    class MockMessage(object):
        pass

    mock_resp = MockMessage()
    mock_req = MockMessage()

    assert get_output_options(mock_arg, mock_resp) == (True, True)
    assert get_output_options(mock_arg, mock_req) == (False, False)

# Generated at 2022-06-21 13:53:45.988563
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[])
    message = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args, message)
    assert not with_headers
    assert not with_body

    args = argparse.Namespace(output_options=[OUT_REQ_HEAD])
    with_headers, with_body = get_output_options(args, message)
    assert with_headers
    assert not with_body

    args = argparse.Namespace(output_options=[OUT_REQ_BODY])
    with_headers, with_body = get_output_options(args, message)
    assert not with_headers
    assert with_body

    args = argparse.Namespace(output_options=[OUT_REQ_HEAD, OUT_REQ_BODY])

# Generated at 2022-06-21 13:53:54.425310
# Unit test for function program
def test_program():
    import tempfile
    import httpie.cli.parser
    env = Environment()
    args = httpie.cli.parser.parser.parse_args(
        args=['http', '--verbose'],
        env=env,
    )
    status = program(args=args, env=env)
    assert status != ExitStatus.SUCCESS, 'Should fail for non-existent URL.'
    assert env.stderr.getvalue().startswith('ConnectionError:')
    env.stderr.truncate(0)
    args = httpie.cli.parser.parser.parse_args(
        args=['--debug', '--traceback', 'http', '--verbose'],
        env=env,
    )
    try:
        program(args=args, env=env)
    except Exception:
        print

# Generated at 2022-06-21 13:54:05.121898
# Unit test for function main
def test_main():
    import pytest

    from httpie.cli.constants import DEFAULT_OPTIONS
    from httpie.parser import parse_items

    env = Environment()  # type: Environment

    # No args.
    assert main(args=[], env=env) == ExitStatus.SUCCESS
    assert main(args=['--debug'], env=env) == ExitStatus.SUCCESS

    # Help
    assert main(args=['--help'], env=env) == ExitStatus.SUCCESS
    assert main(args=['get', '--help'], env=env) == ExitStatus.SUCCESS

    # Invalid
    assert main(args=['-'], env=env) == ExitStatus.ERROR
    assert main(args=['--invalid'], env=env) == ExitStatus.ERROR

    # Normal

# Generated at 2022-06-21 13:54:38.424176
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.args import parse_args
    import argparse
    arg_str = '--form --json-string --output-headers --output-body'
    args = parse_args(arg_str.split(' '), env = Environment())
    msg = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args, msg)
    assert(with_headers == True)
    assert(with_body == True)


# Generated at 2022-06-21 13:54:47.665167
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import sys
    from io import StringIO
    from unittest.mock import patch

    x = StringIO()
    sys.stderr = x
    print_debug_info(Environment())
    sys.stderr = sys.__stderr__
    assert x.getvalue().strip() == 'HTTPie {httpie_version}\nRequests {requests_version}\nPygments {pygments_version}\nPython {sys.version}\n{sys.executable}\n{platform.system()} {platform.release()}'.format(
        httpie_version=__version__,
        requests_version=__version__,
        pygments_version=__version__,
        sys=sys,
        platform=platform
    )


# Generated at 2022-06-21 13:54:58.207154
# Unit test for function print_debug_info
def test_print_debug_info():
    import io

    env = Environment()
    env.stderr = io.StringIO()
    print_debug_info(env)

# Generated at 2022-06-21 13:55:02.153637
# Unit test for function decode_raw_args
def test_decode_raw_args():
    stdin_encoding = 'utf-8'
    args_in = [b'http', b'http://example.com']
    args_out = decode_raw_args(args_in, stdin_encoding)
    assert args_out == ['http', 'http://example.com']

# Generated at 2022-06-21 13:55:09.128041
# Unit test for function main
def test_main():
    def mock_decode_raw_args(args, stdin_encoding):
        return args
    import httpie.cli.program
    httpie.cli.program.decode_raw_args = mock_decode_raw_args
    import httpie.status
    from pytest import raises

    from httpie.cli.context import Environment

    env = Environment()
    # assert main(['http', 'httpie.org'], env) == ExitStatus.SUCCESS
    # assert main(['http', 'httpie.org'], env) == ExitStatus.SUCCESS

    # with raises(SystemExit) as e:
    #     main(['http', 'httpie.org', '--not-an-option'], env)
    # assert e.value.code == ExitStatus.ERROR


# Generated at 2022-06-21 13:55:18.360986
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import unittest
    class TestStderr:
        def __init__(self):
            self.d = io.StringIO()
        def write(self, s):
            self.d.write(s)
        def get_value(self):
            return self.d.getvalue()
    env = Environment()
    env.stderr = TestStderr()
    print_debug_info(env)
    output = env.stderr.get_value()
    assert 'HTTPie ' in output
    assert 'Requests ' in output
    assert 'Pygments ' in output
    assert 'Python ' in output
    assert '\n' in output
    assert '\n\n' in output

# Generated at 2022-06-21 13:55:30.107686
# Unit test for function decode_raw_args

# Generated at 2022-06-21 13:55:34.482124
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

    args = parser.parse_args(
        args=['get', 'localhost:8080/get'], )

    program(args=args, env=Environment())


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 13:55:40.291122
# Unit test for function get_output_options
def test_get_output_options():
    message = '''
        with body arg
        with headers: True
        with body: True
        request body read callback
        request body read callback
        request body read callback
        request body read callback
        request body read callback
    '''
    args = 4
    print(get_output_options(
        args=args,
        message=message
    ))

if __name__ == '__main__':
    exit_status = main()
    sys.exit(exit_status.value)

# Generated at 2022-06-21 13:55:42.536132
# Unit test for function get_output_options
def test_get_output_options():
    args = []
    message = []
    print(get_output_options(args, message))

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 13:57:02.321370
# Unit test for function print_debug_info
def test_print_debug_info():
    with TemporaryDirectory() as temp_dir:
        test_env = Environment(config_dir=temp_dir, stdout_isatty=False, stdin_isatty=False,
                        stdout=StringIO(), stderr=StringIO())
        print_debug_info(test_env)
        test_env.stderr.seek(0)
        stderr_lines = test_env.stderr.readlines()
        assert len(stderr_lines) == 5
        for line in stderr_lines[:-1]:
            assert line.endswith('\n')
        assert stderr_lines[-1].endswith(os.linesep + os.linesep)
        assert 'HTTPie {httpie_version}' in stderr_lines[0]

# Generated at 2022-06-21 13:57:12.422022
# Unit test for function print_debug_info
def test_print_debug_info():
    '''
    Test function print_debug_info().
    Expect the class Enviornment to output a similar
    type to the below.
    '''
    env = Environment()
    print_debug_info(env)
    print("\n")
    class Environment:
        '''
        Mock environment class object.
        '''
        config = ''
        colormode = ''
        default_options = ''
        editor = ''
        env = ''
        help = ''
        is_windows = ''
        pager = ''
        program_name = ''
        stdin = ''
        stdin_isatty = ''
        stdin_encoding = ''
        stdout = ''
        stdout_isatty = ''
        stdout_text_stream = ''
        stderr = ''
        stderr_is

# Generated at 2022-06-21 13:57:13.182311
# Unit test for function program
def test_program():
    assert program([], '') == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:57:16.274180
# Unit test for function get_output_options
def test_get_output_options():
    from argparse import Namespace
    env = Environment()
    args = Namespace(output_options=['resp.body', 'resp.headers'])

    assert get_output_options(args=args, message=None) == (True, True)

# Generated at 2022-06-21 13:57:20.694346
# Unit test for function decode_raw_args
def test_decode_raw_args():
    def assert_expected(args: List[Union[str, bytes]], expected: List[str]) -> None:
        assert decode_raw_args(args=args, stdin_encoding='utf-8') == expected

    assert_expected(args=['echo', 'äöü'], expected=['echo', 'äöü'])
    assert_expected(args=['echo', b'\xe4\xf6\xfc'], expected=['echo', 'äöü'])

# Generated at 2022-06-21 13:57:25.445334
# Unit test for function main
def test_main():
    class MockStdErr:
        def __init__(self):
            self.buffer = []

        def write(self, string: str):
            self.buffer.append(string)

        def __str__(self):
            return ''.join(self.buffer)

    mock_stderr = MockStdErr()
    def mock_exit(code):
        if code == ExitStatus.ERROR:
            raise SystemExit("Test")

    class MockEnv:
        def __init__(self):
            self.stderr = mock_stderr
            self.exit = mock_exit

    # Case 0 - Normal program
    mock_env = MockEnv()
    args = ['http', 'localhost']
    assert main(args, mock_env) == ExitStatus.SUCCESS

    # Case 1 - --help


# Generated at 2022-06-21 13:57:36.590758
# Unit test for function print_debug_info
def test_print_debug_info():
    output = []
    env = Environment(
        stdin=io.StringIO(),
        stdout=io.StringIO(),
        stderr=io.StringIO(),
        argv=['httpie-test'],
        config_dir=None,
        default_options=[],
    )
    print_debug_info(env=env)
    env.stderr.seek(0)
    for line in env.stderr:
        output.append(line)

# Generated at 2022-06-21 13:57:41.505505
# Unit test for function decode_raw_args
def test_decode_raw_args():
    print( decode_raw_args(['0','1','2'], 'utf-8'))
    print(decode_raw_args([b'0', b'1', b'2'], 'utf-8'))


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 13:57:52.481025
# Unit test for function get_output_options
def test_get_output_options():
    import httpie.cli.definition
    args = httpie.cli.definition.get_parser().parse_args(['GET', 'http://httpbin.org/anything'])
    args.output_options = ['Hb']
    assert get_output_options(args, requests.PreparedRequest()) == (True, True)
    assert get_output_options(args, requests.Response()) == (False, True)
    args.output_options = ['HHb']
    assert get_output_options(args, requests.PreparedRequest()) == (True, True)
    assert get_output_options(args, requests.Response()) == (True, True)
    args.output_options = ['hb']
    assert get_output_options(args, requests.PreparedRequest()) == (False, True)

# Generated at 2022-06-21 13:58:03.822642
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = []
    assert get_output_options(args, requests.PreparedRequest()) == (False, False)
    args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)
    args.output_options = [OUT_REQ_BODY]
    assert get_output_options(args, requests.PreparedRequest()) == (False, True)
    args.output_options = [OUT_REQ_BODY, OUT_RESP_BODY]
    assert get_output_options(args, requests.PreparedRequest()) == (False, True)
    assert get_output_options(args, requests.Response()) == (False, True)

# Generated at 2022-06-21 13:59:21.119090
# Unit test for function print_debug_info
def test_print_debug_info():
    """
    Unit test to check if debug info of the program
    is printed properly
    """
    result_debug_info = None
    env = Environment()
    env.stderr = io.StringIO()
    print_debug_info(env)
    result_debug_info = env.stderr.getvalue()
    assert result_debug_info == 'HTTPie 1.0.3\nRequests 2.22.0\nPygments 2.4.2\nPython 3.7.2 (default, Jan 13 2019, 14:28:59) \n[GCC 8.2.1 20181127]\nLinux 4.15.0-45-generic\n'

# Generated at 2022-06-21 13:59:23.943359
# Unit test for function get_output_options
def test_get_output_options():
    args=argparse.Namespace(output_options=['bb', 'b', 'hb'], )
    print(args.output_options)
    header, body = get_output_options(args=args, message=requests.Response())
    print('Header:', header, '\nBody:', body)   
    header, body = get_output_options(args=args, message=requests.PreparedRequest())
    print('Header:', header, '\nBody:', body)


# Generated at 2022-06-21 13:59:31.867831
# Unit test for function get_output_options
def test_get_output_options():
    import argparse

    args = argparse.Namespace(
        output_options = [OUT_REQ_HEAD, OUT_RESP_BODY])
    messages = [requests.PreparedRequest(), requests.Response()]
    
    for msg in messages:
        with_headers, with_body = get_output_options(args, msg)
        assert(with_headers == isinstance(msg, requests.PreparedRequest))

# Generated at 2022-06-21 13:59:34.734788
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = ['http', '--args-file', b'bytes.txt']
    assert decode_raw_args(args=args, stdin_encoding='utf8') == [
        'http', '--args-file', 'bytes.txt'
    ]

# Generated at 2022-06-21 13:59:44.219721
# Unit test for function program
def test_program():
    """
    Test normal usage of function program.
    :return:
    """
    # Test 1: without downloading
    args = argparse.Namespace(
        headers=None,
        output_file=None,
        output_options=None,
        output_file_specified=None,
        download=None,
        download_resume=None,
        follow=None,
        quiet=None,
        check_status=None,
    )
    env = Environment()
    assert program(args=args, env=env) == ExitStatus.SUCCESS

    # Test 2: with downloading

# Generated at 2022-06-21 13:59:47.696567
# Unit test for function main
def test_main():
    assert main(args=['--version'], env=Environment()) == ExitStatus.SUCCESS
    assert main(args=['-L'], env=Environment()) == ExitStatus.SUCCESS

test_main()

# Generated at 2022-06-21 13:59:55.681114
# Unit test for function print_debug_info
def test_print_debug_info():
    debug_info = []
    class FakeStderr:
        def writelines(self, lines):
            debug_info.extend(lines)
    env = Environment()
    env.stderr = FakeStderr()
    print_debug_info(env)
    assert all(x in debug_info for x in ["HTTPie", "Requests", "Pygments", "Python", "platform.system()", "platform.release()"])
    assert all(x not in debug_info for x in ["Environment", "key", "val"])
    

# Generated at 2022-06-21 14:00:00.130409
# Unit test for function get_output_options
def test_get_output_options():
    request = requests.PreparedRequest()
    response = requests.Response()
    args = argparse.Namespace(output_options= [OUT_REQ_HEAD,OUT_RESP_BODY])
    assert get_output_options(args, request) == (True,False)
    assert get_output_options(args,response) == (False,True)

# Generated at 2022-06-21 14:00:06.241041
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['foo', 'bar'], sys.stdin.encoding) == ['foo', 'bar']
    assert decode_raw_args(['foo', b'bar'], sys.stdin.encoding) == ['foo', 'bar']
    assert decode_raw_args([b'foo', 'bar'], sys.stdin.encoding) == ['foo', 'bar']
    assert decode_raw_args([b'foo', b'bar'], sys.stdin.encoding) == ['foo', 'bar']

# Generated at 2022-06-21 14:00:14.566317
# Unit test for function program
def test_program():
    def test_program_success():
        parser = argparse.ArgumentParser()
        parser.add_argument('file', type=argparse.FileType('r'), default=sys.stdout)
        args = parser.parse_args(['-', '--output-file', '-'])
        args.json = False
        env = Environment()
        env.stdin = sys.stdin
        env.config = args
        result = program(args, env)
        assert result == ExitStatus.SUCCESS
    def test_program_fail():
        result = program(None, None)
        assert result == ExitStatus.ERROR