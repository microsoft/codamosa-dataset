

# Generated at 2022-06-21 13:51:13.596768
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from httpie.compat import is_windows
    stdout = StringIO()
    stderr = StringIO()
    env = Environment(stdout=stdout, stderr=stderr)
    print_debug_info(env)
    assert len(stderr.getvalue().splitlines()) == 6
    print_debug_info(env)
    stdout = StringIO()
    stderr = StringIO()
    env = Environment(stdout=stdout, stderr=stderr)
    print_debug_info(env)
    assert len(stderr.getvalue().splitlines()) == 6
    if is_windows:
        assert stderr.getvalue().splitlines()[5] == 'Windows 7'

# Generated at 2022-06-21 13:51:25.320464
# Unit test for function main
def test_main():
    from httpie.cli.constants import EXIT_STATUS_LABELS
    assert main(["http", "http://localhost:8080/api/v1/payments/client/1", "-v"]) == 0
    assert main(["http", "http://localhost:8080/api/v1/payments/client/1", "--json={" , "\"beneficiaryId\"", ":", "\"d34478b1-b0e6-4d9f-a973-a03b322ef065\"", "," , "\"currency\"", ":", "\"PLN\"", "," , "\"amount\"", ":", "50.00", "," , "\"title\"", ":", "\"one\"", "}", "-v"]) == 0

# Generated at 2022-06-21 13:51:35.626721
# Unit test for function get_output_options
def test_get_output_options():
    req_args = argparse.Namespace(
        output_options=[str(OUT_REQ_HEAD)],
    )
    # request
    msg = requests.PreparedRequest()
    with_headers, with_body = get_output_options(
        args=req_args, message=msg
    )
    assert with_headers, with_body == (True, False)
    # response
    msg = requests.Response()
    with_headers, with_body = get_output_options(
        args=req_args, message=msg
    )
    assert with_headers, with_body == (False, False)



# Generated at 2022-06-21 13:51:40.995071
# Unit test for function program
def test_program():
    def mock_parse_args(args):
        return argparse.Namespace()
    def collect_messages(args, config_dir, request_body_read_callback):
        return [requests.PreparedRequest(),requests.Response()]
    args = mock_parse_args([])
    env = Environment()
    assert program(args, env) != ExitStatus.SUCCESS


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 13:51:43.772641
# Unit test for function main
def test_main():
    args = ["python", "-v"]
    env = Environment()
    assert main(args = args, env = env) == 0


# Generated at 2022-06-21 13:51:45.275977
# Unit test for function main
def test_main():
    """
    Test function main
    """
    # TODO: Add tests
    pass

# Generated at 2022-06-21 13:51:57.155380
# Unit test for function get_output_options
def test_get_output_options():
    import argparse
    args = argparse.Namespace()
    args.output_options = []
    assert get_output_options(args, requests.PreparedRequest()) == (False, False)
    args.output_options = [OUT_REQ_HEAD]
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)
    args.output_options = [OUT_RESP_HEAD]
    assert get_output_options(args, requests.PreparedRequest()) == (False, False)
    args.output_options = [OUT_RESP_BODY]
    assert get_output_options(args, requests.PreparedRequest()) == (False, False)
    args.output_options = [OUT_REQ_BODY]

# Generated at 2022-06-21 13:51:58.605707
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        main()

# Generated at 2022-06-21 13:52:09.544371
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli import parser
    from httpie.compat import urlopen
    from httpie.downloads import Downloader
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    env = Environment()
    env.stdin = io.BytesIO(b'TEST INPUT')
    env.stdin_encoding = 'utf8'


    # Test with quiet mode and check status.
    args = ['--quiet', '--check-status', 'httpbin.org/status/500']
    args = parser.parse_args(args=decode_raw_args(args, env.stdin_encoding), env=env)
    with pytest.raises(SystemExit) as excinfo:
        program(args, env)
    assert excinfo.value.code == Exit

# Generated at 2022-06-21 13:52:17.103178
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from httpie.core import TEST_TEST_ENVIRONMENT
    os.environ.update(TEST_TEST_ENVIRONMENT)
    os.environ["HTTPIE_TEST_ARGS"] = "['--form', 'b\\\\xc3\\\\xbc']"
    args = eval(os.environ["HTTPIE_TEST_ARGS"])
    decoded_args = decode_raw_args(args, 'utf-8')
    assert decoded_args == ['--form', 'bü']
    del os.environ["HTTPIE_TEST_ARGS"]

# Generated at 2022-06-21 13:52:47.641822
# Unit test for function program
def test_program():
    
    # Example 1: Testing for the given inputs.
    args=['http', 'www.google.com']
    env=Environment()
    #print(program(args,env))
    
    # Example 2: Testing for the given inputs.
    args=['http', '--help']
    env=Environment()
    env.config.default_options=['--debug']
    #print(program(args,env))
    #print_debug_info(env)
    
    # Example 3: Testing for the given inputs.
    args=['http', 'get', 'http://jsonplaceholder.typicode.com/posts/1']
    env=Environment()
    #print(program(args,env))
    
    # Example 4: Testing for the given inputs.

# Generated at 2022-06-21 13:52:56.584551
# Unit test for function program
def test_program():
    try:
        import httpie
    except ModuleNotFoundError:
        # Let's assume we're running from the source tree.
        httpie = sys.modules['httpie']
        httpie.__file__ = os.path.abspath(os.path.join('../httpie.py'))
    _exit_status = program(args=httpie.cli.parser.parse_args(['--debug']), env=Environment())
    assert _exit_status == ExitStatus.SUCCESS


if __name__ == '__main__':
    sys.exit(main() or ExitStatus.SUCCESS)

# Generated at 2022-06-21 13:53:06.955187
# Unit test for function program
def test_program():
    args=[]
    env=Environment()
    import io
    import tempfile
    import shutil

    class Args:
        headers = None
        http_version = 'HTTP/1.1'
        form = False
        ignore_stdin = True
        headers = None
        json = None
        __args = None
        verbose = False

        stream = io.StringIO()
        stdout = io.StringIO()
        stderr = io.StringIO()
        stdin = io.StringIO()

        auth = None
        auth_type = 'basic'
        verify = True
        timeout = None
        follow = False
        max_redirects = None
        check_status = True
        data = None
        json = None
        output_file = None
        output_file_specified = False
        output_options

# Generated at 2022-06-21 13:53:15.760614
# Unit test for function print_debug_info
def test_print_debug_info():
    class MockFile:
        def __init__(self, list_of_strings=[]):
            self.list_of_strings = list_of_strings

        def write(self, string):
            self.list_of_strings.append(string)

        def writelines(self, strings):
            self.list_of_strings.extend(strings)

    class MockEnv:
        def __init__(self):
            self.stderr = MockFile()
            self.stdin_encoding = 'utf-8'

    env = MockEnv()
    print_debug_info(env)

# Generated at 2022-06-21 13:53:26.304752
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.cli import debug
    from unittest import mock
    from io import StringIO
    env = mock.Mock()
    env.stderr = StringIO()
    print_debug_info(env)
    debug_info = env.stderr.getvalue()
    debug_info_lines = debug_info.split('\n')
    assert 'HTTPie' in debug_info_lines[0]
    assert 'Requests' in debug_info_lines[1]
    assert 'Pygments' in debug_info_lines[2]
    assert 'Python' in debug_info_lines[3]
    assert '<Environment' in debug_info_lines[-3]
    assert debug_info_lines[-2] == ''
    assert debug_info_lines[-1] == ''

# Generated at 2022-06-21 13:53:35.880732
# Unit test for function main
def test_main():
    exit_status = main(['http', '--traceback', '--debug', '--verbose', 'https://www.google.com'])
    assert exit_status == 0
    exit_status = main(['http', '--debug', 'https://www.google.com'])
    assert exit_status == 0
    exit_status = main(['http', '--verbose', 'https://www.google.com'])
    assert exit_status == 0
    try:
        exit_status = main(['http', '--verbose', 'https://www.google.comasdasdasdasd'])
        assert False
    except Exception as e:
        assert exit_status == ExitStatus.ERROR
    exit_status = main(['http', '--verbose', 'https://www.google.com'])
    assert exit

# Generated at 2022-06-21 13:53:37.333296
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    assert True

# Generated at 2022-06-21 13:53:48.876502
# Unit test for function print_debug_info
def test_print_debug_info():
    class env:
        stderr = []

        def writelines(self, messages):
            self.stderr.extend(messages)

        def write(self, message):
            self.stderr.append(message)

    expected_stderr = [
        f'HTTPie {httpie_version}\n',
        f'Requests {requests_version}\n',
        f'Pygments {pygments_version}\n',
        f'Python {sys.version}\n{sys.executable}\n',
        f'{platform.system()} {platform.release()}',
        '\n\n',
        '<httpie.context.Environment object at 0x7f5b7d865050>',
        '\n'
    ]

    print_debug_info(env)
    assert env

# Generated at 2022-06-21 13:53:55.097913
# Unit test for function program
def test_program():
    from . import cli
    from .context import Environment
    debug = 0
    env = Environment()
    env.stdout = sys.__stdout__
    env.stderr = sys.__stderr__
    parser = cli.get_parser(env)
    # Get the Python code for the parsed arguments
    python_code = parser.format_help()
    args = parser.parse_args(*['-v', 'https://httpstat.us/500', '--timeout=0.1'])
    assert program(args, env) == ExitStatus.ERROR_TIMEOUT


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 13:54:00.780266
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = ['str1', b'\xe6\x96\xb0\xe5\x8a\xa0\xe5\x9d\xa1']
    assert decode_raw_args(args, 'gb2312') == ['str1', '新加坡']
    args = ['str1']
    assert decode_raw_args(args, 'gb2312') == ['str1']

# Generated at 2022-06-21 13:54:39.900316
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([], 'utf-8') == []
    assert decode_raw_args(['text'], 'utf-8') == ['text']
    assert decode_raw_args(['text'], 'ascii') == ['text']
    assert decode_raw_args([b'\xc2\xa9'], 'utf-8') == ['\u00a9']
    assert decode_raw_args([b'\xc2\xa9'], 'ascii') == ['\u00a9']

    # TODO: add tests for handling decoding errors
    # Should treat encoding errors like UnicodeDecodeError
    # assert decode_raw_args([b'\xff'], 'ascii') == ValueError

# Generated at 2022-06-21 13:54:42.271664
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = [b'\\u00e9']
    assert decode_raw_args(args, 'utf-8')[0] == 'é'

# Generated at 2022-06-21 13:54:52.872832
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[])
    request = requests.PreparedRequest()
    headers, body = get_output_options(args, request)
    assert not headers and not body

    args = argparse.Namespace(output_options=[OUT_REQ_HEAD])
    request = requests.PreparedRequest()
    headers, body = get_output_options(args, request)
    assert headers and not body

    args = argparse.Namespace(output_options=[OUT_REQ_BODY])
    request = requests.PreparedRequest()
    headers, body = get_output_options(args, request)
    assert not headers and body

    args = argparse.Namespace(output_options=[OUT_REQ_HEAD, OUT_REQ_BODY])
    request = requests.PreparedRequest()
    headers

# Generated at 2022-06-21 13:54:54.544012
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'b', 's'], 'utf8') == ['b', 's']

# Generated at 2022-06-21 13:55:03.552104
# Unit test for function decode_raw_args
def test_decode_raw_args():
    u'\N{GREEK SMALL LETTER ALPHA}\N{GREEK CAPITAL LETTER OMEGA}'
    assert decode_raw_args(
        args=[b'\xce\xb1', b'\xce\xa9'],
        stdin_encoding='utf8'
    ) == [u'\N{GREEK SMALL LETTER ALPHA}', u'\N{GREEK CAPITAL LETTER OMEGA}']

    assert decode_raw_args(
        args=['test', '\N{GREEK SMALL LETTER ALPHA}'],
        stdin_encoding='utf8'
    ) == ['test', '\N{GREEK SMALL LETTER ALPHA}']

# Generated at 2022-06-21 13:55:08.721123
# Unit test for function main
def test_main():
    assert main(['httpie', '--output=tmp', '--headers', 'http://www.google.com']) == 0
    assert main(['httpie', '--output=tmp', 'http://www.google.com']) == 0
    assert main(['httpie', '--output=tmp', '--method=POST', 'http://www.google.com']) == 0

# Generated at 2022-06-21 13:55:19.058317
# Unit test for function program
def test_program():
    import io
    import os
    import sys

    from httpie.cli.definition import CustomArgs, CustomArgsParser
    from httpie.config import Config
    from httpie.output.writers import get_output_writer

    class MockEnvironment(Environment):
        def __init__(self):
            super().__init__()

            self.config = Config(
                directory='./config',
                errors_as_exit_status=True,
                colors=True,
                hl=True,
                output_options=['implicit_content_type'],
                stream=True,
                theme='nord',
                verbose=True,
            )
            self.verbosity_level = 0
            self.download_inprogress = False
            self.stdin = io.BytesIO
            self.stdin_isatty = True


# Generated at 2022-06-21 13:55:28.015517
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    env = Environment(stdout=io.StringIO(), stderr=io.StringIO())
    print_debug_info(env)
    assert 'HTTPie ' in env.stderr.getvalue()
    assert 'Requests ' in env.stderr.getvalue()
    assert 'Pygments ' in env.stderr.getvalue()
    assert 'Python ' in env.stderr.getvalue()
    assert 'win32' in env.stderr.getvalue() or 'win64' in env.stderr.getvalue()

# Generated at 2022-06-21 13:55:38.332292
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([], 'UTF-8') == []
    assert decode_raw_args([b'abc'], 'UTF-8') == ['abc']
    assert decode_raw_args([b'\xe4\xb8\x80'], 'UTF-8') == ['一']
    assert decode_raw_args(['abc'], 'UTF-8') == ['abc']
    assert decode_raw_args(['\xe4\xb8\x80'], 'UTF-8') == ['\xe4\xb8\x80']
    assert decode_raw_args([b'\xe4\xb8\x80', '\xe4\xb8\x80'], 'UTF-8') == ['一', '\xe4\xb8\x80']

# Generated at 2022-06-21 13:55:44.318250
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    stream = StringIO()
    env = Environment(stderr=stream)
    print_debug_info(env)
    assert stream.getvalue() == 'HTTPie 0.9.9\nRequests 2.13.0\nPygments 2.2.0\nPython 3.6.0 (v3.6.0:41df79263a11, Dec 23 2016, 08:06:12) [MSC v.1900 64 bit (AMD64)]\nC:\\Users\\myuser\\Anaconda3\\python.exe\nWindows 10\n'

# Generated at 2022-06-21 13:56:09.775342
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    args = parser.parse_args(args=['--debug', 'https://httpbin.org/get'])
    assert program(args=args, env=Environment()) == 0
    args = parser.parse_args(args=['https://httpbin.org/get'])
    assert program(args=args, env=Environment()) == 0
    args = parser.parse_args(args=['--download', '-o', 'x', 'https://httpbin.org/get'])
    assert program(args=args, env=Environment()) == 0
    args = parser.parse_args(args=['--download', 'https://httpbin.org/get'])
    assert program(args=args, env=Environment()) == 0

# Generated at 2022-06-21 13:56:14.138692
# Unit test for function program
def test_program():
    # ensure that arguments are decoded
    for arg in decode_raw_args([sys.executable.encode(), '-c', 'print("hello")'], 'utf-8'):
        pass

if __name__ == '__main__':
    def test_main():
        main()

# Generated at 2022-06-21 13:56:16.781869
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'\xe4\xb8\x96\xe7\x95\x8c', 'foo'], 'utf8') == ['世界', 'foo']

# Generated at 2022-06-21 13:56:25.791106
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    out = StringIO()
    print_debug_info(env=Environment(stdin=None, stdout=out, stderr=out))
    str_out = out.getvalue()
    lines = str_out.splitlines()
    assert lines[0].startswith('HTTPie ')
    assert lines[1].startswith('Requests ')
    assert lines[2].startswith('Pygments ')
    assert lines[3].startswith('Python ')
    assert lines[4].startswith('Windows ') or lines[4].startswith('Darwin ')
    assert lines[5] == ''
    assert lines[6] == ''

# Generated at 2022-06-21 13:56:35.233048
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    import platform
    import sys

    env = Environment()
    env.stderr = StringIO()

    print_debug_info(env)

    lines = env.stderr.getvalue().splitlines()
    assert lines == [
        f'HTTPie {httpie_version}',
        f'Requests {requests_version}',
        f'Pygments {pygments_version}',
        f'Python {sys.version}',
        f'{sys.executable}',
        f'{platform.system()} {platform.release()}',
        '',
        '',
        repr(env),
        '',
    ]

# Generated at 2022-06-21 13:56:41.520201
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.output.writers import GetterStreamWriter
    from httpie.tests.utils import TestEnvironment
    from httpie import ExitStatus
    parser.prog = 'http'
    program(['http', 'www.github.com', '--body'], TestEnvironment())
    assert(program(['http', 'www.github.com', '--headers'], TestEnvironment())==ExitStatus.SUCCESS)

# Generated at 2022-06-21 13:56:49.845831
# Unit test for function decode_raw_args
def test_decode_raw_args():
    test_cases = [
        ([b'\xe2\x80\xa2'], 'utf-8', ['•']),
        ([b'\xe2\x80\xa2'], 'iso8859-1', ['Ã¢Â¢']),
        (['\xe2\x80\xa2'], 'utf-8', ['\xe2\x80\xa2']),
    ]
    for (args, stdin_encoding, expected) in test_cases:
        assert decode_raw_args(args, stdin_encoding) == expected



# Generated at 2022-06-21 13:56:54.960377
# Unit test for function get_output_options
def test_get_output_options():
    """
    Test get_output_options()
    """
    # given
    args = argparse.Namespace()
    args.output_options = ['h']
    msg = requests.PreparedRequest()
    # when
    res = get_output_options(args, msg)
    # then
    assert (True, False) == res

# Generated at 2022-06-21 13:57:02.986557
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[OUT_REQ_HEAD, OUT_RESP_BODY])
    m = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args=args, message=m)
    assert with_headers
    assert not with_body
    m = requests.Response()
    with_headers, with_body = get_output_options(args=args, message=m)
    assert not with_headers
    assert with_body

# Generated at 2022-06-21 13:57:12.952434
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # stdin_encoding is ignored
    assert decode_raw_args(args=[b'--traceback'], stdin_encoding='utf-8') == ['--traceback']
    assert decode_raw_args(args=['--traceback'], stdin_encoding='utf-8') == ['--traceback']
    assert decode_raw_args(args=[b'httpbin.org'], stdin_encoding='utf-8') == ['httpbin.org']
    assert decode_raw_args(args=['httpbin.org'], stdin_encoding='utf-8') == ['httpbin.org']
    # noinspection SpellCheckingInspection

# Generated at 2022-06-21 13:57:31.784263
# Unit test for function main
def test_main():
    # TODO: Use pytest.
    # TODO: Run this as part of CI.
    import unittest.mock

    # TODO: Put back-in args.
    args = ['http']
    env = Environment()
    main(args=args, env=env)



# Generated at 2022-06-21 13:57:36.335699
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = [b'1', '2', b'3']
    args = decode_raw_args(args, stdin_encoding='utf-8')
    assert args == ['1', '2', '3']


if __name__ == '__main__':
    status = main()
    sys.exit(status)

# Generated at 2022-06-21 13:57:39.645258
# Unit test for function main
def test_main():
    ret = main(['http://httpbin.org/headers', '-p'])
    assert ret == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:57:42.177435
# Unit test for function decode_raw_args
def test_decode_raw_args():
    decode_raw_args([b'\xcf\x80\xcf\x81', 'www.google.com'], 'utf8') == ['πρ', 'www.google.com']

# Generated at 2022-06-21 13:57:53.015218
# Unit test for function get_output_options
def test_get_output_options():
    from collections import namedtuple
    from httpie.compat import urllib3
    from httpie.compat import is_pyver_compatible
    from httpie.output.writer import MESSAGE_SEPARATOR_BYTES

    Response = namedtuple('Response', 'status_code headers body')
    def prepare_response(body):
        return Response(200, {}, body)

    if not is_pyver_compatible(2, 6):
        return prepare_response({'content-type': 'application/json'})

    if urllib3.__version__ < '1.15':
        return prepare_response({'content-type': 'application/json'})

    args = argparse.Namespace(output_options=[])

    message = prepare_response(b'{"foo": "bar"}')
    with_headers

# Generated at 2022-06-21 13:58:04.092693
# Unit test for function main
def test_main():
    import unittest
    import unittest.mock


    class mainTests(unittest.TestCase):
        """Test cases for main"""
        def test_main(self):
            """test main"""
            print_debug_info = unittest.mock.Mock()
            class ExitStatus:
                SUCCESS = 0
                ERROR_CTRL_C = 130
                ERROR = 1
                ERROR_TIMEOUT = 0
                ERROR_TOO_MANY_REDIRECTS = 0
            exit_status = ExitStatus.SUCCESS

# Generated at 2022-06-21 13:58:05.277785
# Unit test for function main
def test_main():
    assert main(args=['http']) == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:58:06.172226
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:58:15.665605
# Unit test for function program
def test_program():
    class Environment:
        def __init__(self):
            self.config = {}
            self.stdout = sys.stdout
            self.stderr = sys.stderr
            self.stdin_encoding = sys.stdin.encoding
            self.stdout_isatty = sys.stdout.isatty()
            self.stderr_isatty = sys.stderr.isatty()
            self.log_level = 'default'
            self.colors = {}
            self.default_options = {}

    class Args:
        def __init__(self):
            self.output_file_specified = None
            self.output_file = sys.stdout
            self.output_options = []
            self.method = 'GET'

# Generated at 2022-06-21 13:58:24.793370
# Unit test for function get_output_options
def test_get_output_options():
    m = requests.PreparedRequest()
    print(get_output_options(argparse.Namespace(output_options=['a','b','c','d']), m))
    m = requests.Response()
    print(get_output_options(argparse.Namespace(output_options=['a','b','c','d']), m))

if __name__ == '__main__':
    test_get_output_options()
    exit_status = main()
    sys.exit(exit_status)

# Generated at 2022-06-21 13:58:44.964323
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.cli.parser import parse_arguments
    from httpie import ExitStatus
    from httpie.context import Environment
    from typing import List

    env = Environment()
    arg1 = str("--debug")
    arg2 = str("--help")
    arg3 = str("--version")
    arg4 = str("--traceback")
    arg5 = str("GET")
    arg6 = str("test.com")
    arg7 = str("-v")
    arg8 = str("--form")
    arg9 = str("'name==test'")
    arg10 = str("--json")
    arg11 = str("'{ \"name\": \"test\" }'")

# Generated at 2022-06-21 13:58:56.150326
# Unit test for function get_output_options
def test_get_output_options():
    import io
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.definition import parser
    from requests import PreparedRequest, Response

    args = parser.parse_args(args=['GET', 'http://example.org'], env=Environment())
    args.output_options = []
    # TODO: Fails.
    assert get_output_options(args=args, message=PreparedRequest()) == (True, True)
    assert get_output_options(args=args, message=Response()) == (True, True)
    args.output_options = ['H']
    assert get_output_options(args=args, message=PreparedRequest()) == (True, False)
    assert get_output_options(args=args, message=Response()) == (True, False)

# Generated at 2022-06-21 13:59:06.192103
# Unit test for function get_output_options
def test_get_output_options():
    class TestRequest:
        method = 'GET'
        url = 'http://httpbin.org/get'
        headers = {'Accept': 'application/json'}

    class TestResponse:
        headers = {'Content-Type': 'application/json'}

    class TestArgs:
        output_options = []

    assert get_output_options(TestArgs(), TestRequest()) == (False, False)
    assert get_output_options(TestArgs(), TestResponse()) == (False, False)

    class TestArgs:
        output_options = [OUT_REQ_HEAD]

    assert get_output_options(TestArgs(), TestRequest()) == (True, False)
    assert get_output_options(TestArgs(), TestResponse()) == (False, False)

    class TestArgs:
        output_options = [OUT_RESP_HEAD]

# Generated at 2022-06-21 13:59:12.384931
# Unit test for function decode_raw_args
def test_decode_raw_args():
    try:
        env = Environment()
        env.stdin_encoding = 'utf-8'
        args = decode_raw_args(["abcd", "a-b-c-d"], env.stdin_encoding)
        print(args)
        assert args[0] == "abcd"
        assert args[1] == "a-b-c-d"
    except AssertionError as e:
        print(e)

# Generated at 2022-06-21 13:59:17.482474
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=['X'], stdin_encoding='UTF-8') == ['X']
    assert decode_raw_args(args=['X'.encode('UTF-8')], stdin_encoding='UTF-8') == ['X']
    assert decode_raw_args(args=[b'X'], stdin_encoding='UTF-8') == ['X']

# Generated at 2022-06-21 13:59:19.871525
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr = open('debug.txt', 'w')
    print_debug_info(env)

# Generated at 2022-06-21 13:59:27.554314
# Unit test for function main
def test_main():
    import io
    import sys
    import unittest

    from httpie.core import main as httpie

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.encoding = 'utf8'
            self.default_stdin = sys.stdin
            self.default_stdout = sys.stdout
            self.default_stderr = sys.stderr
            sys.stdin = io.StringIO()
            sys.stdout = io.StringIO()
            sys.stderr = io.StringIO()

        def tearDown(self):
            sys.stdin = self.default_stdin
            sys.stdout = self.default_stdout
            sys.stderr = self.default_stderr


# Generated at 2022-06-21 13:59:37.208615
# Unit test for function get_output_options
def test_get_output_options():
    class Request:
        pass

    class Response:
        pass

    req = Request()
    req.headers = {'content_type': 'application/json', 'key': 'value'}
    resp = Response()
    resp.headers = {'content_type': 'application/json'}

    def parse_args(arg_str):
        from httpie.cli.definition import parser
        args = parser.parse_args(arg_str.split())
        return args

    args = parse_args('-b')
    assert get_output_options(args, req) == (False, True)
    assert get_output_options(args, resp) == (False, True)
    args = parse_args('-h')
    assert get_output_options(args, req) == (True, False)

# Generated at 2022-06-21 13:59:45.706834
# Unit test for function get_output_options
def test_get_output_options():

    from httpie.cli.definition import parser
    from httpie.cli.parser import KeyValueArgType
    from tests.test_utils import TestEnvironment
    from httpie import ExitStatus

    args = parser.parse_args([
        '--print', 'h',
        'httpbin.org/get',
        'test-header:test-value'
    ], env=TestEnvironment())

    msg = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args, msg)
    assert with_headers is True
    assert with_body is False

    msg = requests.Response()
    with_headers, with_body = get_output_options(args, msg)
    assert with_headers is False
    assert with_body is False


# Generated at 2022-06-21 13:59:54.209985
# Unit test for function print_debug_info
def test_print_debug_info():
    os.environ['HTTPIE_CONFIG_DIR'] = 'c:\\'
    env = Environment(stdin_isatty=False, stdout_isatty=False, stderr_isatty=False, stdin=None, stdout=io.BytesIO(),
                      stderr=io.BytesIO(), stdin_encoding='utf-8', stdout_encoding=None,
                      stderr_encoding=None, stdin_errors=None, stdout_errors=None, stderr_errors=None)
    print_debug_info(env)

# Generated at 2022-06-21 14:00:15.252667
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    with CaptureStderr() as stderr:
        print_debug_info(env)
    out = stderr.getvalue()
    assert 'HTTPie' in out
    assert 'Requests' in out
    assert 'Python' in out
    assert 'Pygments' in out
    assert f'Python {sys.version}' in out
    assert sys.executable in out
    assert f'{platform.system()} {platform.release()}' in out



# Generated at 2022-06-21 14:00:20.127873
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from httpie.context import Environment
    env = Environment()
    env.stderr = StringIO()
    print_debug_info(env)
    assert 'HTTPie' in env.stderr.getvalue()

# Generated at 2022-06-21 14:00:25.266915
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'--form'], 'utf-8') == ['--form']
    assert decode_raw_args([b'\xe3\x81\x82'], 'sjis') == ['あ']
    assert decode_raw_args([b'a', b'b', '\xe3\x81\x82'], 'sjis') == ['a', 'b', 'あ']

# Generated at 2022-06-21 14:00:32.400737
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = []
    args.output_options.append('hB')
    args.output_options.append('h')
    args.output_options.append('b')

    fake_message_header = requests.PreparedRequest()
    (with_headers_req, with_body_req) = get_output_options(args, fake_message_header)
    assert with_headers_req == True
    assert with_body_req == True

    fake_message_body = requests.Response()
    (with_headers_resp, with_body_resp) = get_output_options(args, fake_message_body)
    assert with_headers_resp == True
    assert with_body_resp == True

# Generated at 2022-06-21 14:00:33.025222
# Unit test for function main
def test_main():
    assert ExitStatus.SUCCESS == main()

# Generated at 2022-06-21 14:00:35.460384
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    my_stderr = StringIO()
    my_env = Environment(stderr=my_stderr)
    print_debug_info(env=my_env)

if __name__ == '__main__':
    sys.exit(main())