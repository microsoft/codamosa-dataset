

# Generated at 2022-06-21 13:51:05.048780
# Unit test for function get_output_options
def test_get_output_options():

    args = argparse.Namespace(output_options = ['b'])
    resp = requests.Response()

    print(get_output_options(args, resp))


# Generated at 2022-06-21 13:51:14.862280
# Unit test for function decode_raw_args

# Generated at 2022-06-21 13:51:26.903046
# Unit test for function main
def test_main():
    from httpie.cli import __main__
    from httpie.core import main
    from httpie.core.environment import Environment
    from httpie import __version__ as httpie_version

    env = Environment(
        program_name=__main__.__name__,
        stdin=open('/dev/null', 'rb'),
        stdin_isatty=True,
        stdin_encoding=sys.getdefaultencoding(),
        stdout=open('/tmp/stdout', 'wb'),
        stdout_isatty=False,
        stdout_encoding=sys.getdefaultencoding(),
        stderr=open('/tmp/stderr', 'wb'),
    )
    # From httpie/cli/__main__.py
    # http --json GET https://httpbin.org/get
   

# Generated at 2022-06-21 13:51:28.659484
# Unit test for function main
def test_main():
    assert main(['http', '--help']) == 0


# Generated at 2022-06-21 13:51:29.755903
# Unit test for function main
def test_main():
    pass



# Generated at 2022-06-21 13:51:40.524468
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import subprocess
    import inspect
    import os, sys
    import shlex
    import json

    path = os.path.dirname(inspect.stack()[0][1])
    test_root = os.path.join(path,'tests')
    test_file = os.path.join(test_root,"data/raw_args.json")
    with open(test_file) as f:
        tests = json.load(f)

    for test in tests:
        env = Environment()
        env.stdin_encoding = test['stdin_encoding']
        env.stdout_encoding = test['stdout_encoding']
        env.stderr_encoding = test['stderr_encoding']
        out_ = test['args']

# Generated at 2022-06-21 13:51:52.219173
# Unit test for function program
def test_program():
    program(argparse.Namespace(
    method=HttpMethod.GET,
    url=URL('http://jsonplaceholder.typicode.com/todos/1'),
    headers=[],
    follow=False,
    output_options=[],
    output_file=None,
    raw_body=None,
    form=None,
    files=None,
    data=None,
    json=None,
    output_file_specified=None,
    force_colors=False,
    style=None,
    pretty=None,
    print_headers=None,
    download=None,
    download_resume=None,
    quiet=None,
    verbose=None,
    check_status=None,
    max_redirects=30,
    timeout=30), Environment())



# Generated at 2022-06-21 13:51:53.614789
# Unit test for function program
def test_program():
    exit_code = main()
    assert exit_code == 0

# Generated at 2022-06-21 13:52:01.873918
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(stderr=StringIO())
    print_debug_info(env)
    env.stderr.seek(0)
    output = env.stderr.read().splitlines()
    assert output[0].startswith('HTTPie ')
    assert output[1].startswith('Requests ')
    assert output[2].startswith('Pygments ')
    assert output[3].startswith('Python ')
    assert output[4].startswith(sys.executable)
    assert output[5].startswith(platform.system())



# Generated at 2022-06-21 13:52:06.844708
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['foo'], 'ascii') == ['foo']
    assert decode_raw_args([b'foo'], 'ascii') == ['foo']
    assert decode_raw_args([b'foo'], 'utf-8') == ['foo']



# Generated at 2022-06-21 13:52:32.513841
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser
    args = parser.parse_args(args=[
        'http',
        'localhost:8080',
        '-v',
    ])
    assert get_output_options(args, requests.PreparedRequest()) == (True, True)
    assert get_output_options(args, requests.Response()) == (True, True)

# Generated at 2022-06-21 13:52:44.780099
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import os
    s = io.StringIO(u"")
    os.environ['HTTPIE_CONFIG_DIR'] = '/test'
    env = Environment(stdin=s, stdout=s, stderr=s)
    print_debug_info(env=env)

# Generated at 2022-06-21 13:52:50.774918
# Unit test for function print_debug_info
def test_print_debug_info():
    class FakeStdErr:
        def __init__(self):
            self.data = []
        def write(self, data):
            self.data.append(data)
    env = Environment()
    env.stderr = FakeStdErr()
    print_debug_info(env)
    print(env.stderr.data)
    assert len(env.stderr.data) == 6

# Generated at 2022-06-21 13:53:01.201285
# Unit test for function main
def test_main():
    """
    Unit test for function main.

    In case of error will be raised an exception.
    """
    args=[] 
    args.append("www.google.com")
    args.append("-v")
    status=main(args)
    assert status==0    

    args=[] 
    args.append("www.google.com")
    status=main(args)
    assert status==0    

    args=[] 
    args.append("www.google.com")
    status=main(args)
    assert status==0    

    args=[] 
    args.append("www.google.com")
    status=main(args)
    assert status==0    

    args=[] 
    args.append("www.google.com")
    status=main(args)
    assert status==0    

# Generated at 2022-06-21 13:53:05.125549
# Unit test for function program
def test_program():
    env = Environment()
    args = ["https://httpbin.org/get","--help","--test","test"]
    status = program(args,env)
    assert(status == ExitStatus.SUCCESS)


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 13:53:08.481696
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'http', ':'], 'utf8') == ['http', ':']
    assert decode_raw_args([b'http', ':'], 'latin1') == ['Ôhttp', ':']

# Generated at 2022-06-21 13:53:16.839627
# Unit test for function get_output_options
def test_get_output_options():
    current_directory = os.getcwd()
    directory = os.path.join(current_directory, 'tests', 'files')
    config = os.path.join(directory, 'httpie')
    environment = Environment(config_dir=config)
    args = parser.parse_args(['--debug', '--output=/tmp/output'], env=environment)
    # Testing for request
    environment.stdout = open('/tmp/output', 'w')
    request = requests.PreparedRequest()
    request.method = 'GET'
    request.url = 'http://www.google.com/'
    with_headers, with_body = get_output_options(args=args, message=request)
    # Headers and Body
    assert(with_headers and with_body)

# Generated at 2022-06-21 13:53:20.852966
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = ['-b']
    msg = requests.PreparedRequest()
    assert get_output_options(args, msg) == (False, True)

# Generated at 2022-06-21 13:53:21.562683
# Unit test for function program
def test_program():
    main('program')

# Generated at 2022-06-21 13:53:27.445436
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # Test edge cases on Python 3.
    assert decode_raw_args([], 'ascii') == []
    assert decode_raw_args([b''], 'ascii') == ['']
    assert decode_raw_args([b'foo'], 'ascii') == ['foo']
    assert decode_raw_args([b'foo', u'bar'], 'ascii') == ['foo', 'bar']
    assert decode_raw_args([u'foo', b'bar'], 'ascii') == ['foo', 'bar']
    # Test edge cases on Python 2.
    assert decode_raw_args([], 'ascii') == []
    assert decode_raw_args([''], 'ascii') == ['']
    assert decode_raw_args(['foo'], 'ascii') == ['foo']

# Generated at 2022-06-21 13:53:55.525989
# Unit test for function program
def test_program():
    import httpie.cli.parser
    env=Environment()
    sys.stderr.write('1')
    args=httpie.cli.parser.parser.parse_args([
        '-f',
        'POST',
        '127.0.0.1:5000/api/v2/app/orders',
        '-H',
        'Cookie: sessionid=abc123',
        'Content-Type: application/json',
        '-d',
        '{"order_status": "CREATED"}',
    ], env=env)
    assert isinstance(args, argparse.Namespace)
    assert args.output_options==('h', 'b')
    # program(args=args, env=env)
    env.stderr.write('2')

# Generated at 2022-06-21 13:53:56.410663
# Unit test for function main
def test_main():
    assert main([]) == ExitStatus.ERROR

# Generated at 2022-06-21 13:53:57.739179
# Unit test for function program
def test_program():
    pass

# Generated at 2022-06-21 13:54:07.480185
# Unit test for function get_output_options
def test_get_output_options():
    # Test case 1: output both headers and body
    args = {
        'output_options': 'hb',
        'check_status': True,
        'download': True,
        'download_resume': False,
        'follow': True,
        'headers': None,
        'output_file': None,
        'output_file_specified': False,
    }
    args = argparse.Namespace(**args)
    message = requests.PreparedRequest()
    output_headers, output_body = get_output_options(args=args, message=message)
    assert output_headers
    assert output_body

    # Test case 2: output headers only

# Generated at 2022-06-21 13:54:17.433209
# Unit test for function get_output_options
def test_get_output_options():
    class A:
        output_options = []

    a = A()
    out_head,out_body = get_output_options(a,requests.PreparedRequest())
    assert out_head == False
    assert out_body == False
    a.output_options = ['--print=H']
    out_head,out_body = get_output_options(a,requests.PreparedRequest())
    assert out_head == True
    assert out_body == False
    a.output_options = ['--print=B']
    out_head,out_body = get_output_options(a,requests.PreparedRequest())
    assert out_head == False
    assert out_body == True
    a.output_options = ['--print=Hb']

# Generated at 2022-06-21 13:54:19.489424
# Unit test for function main
def test_main():
    assert main(['--debug']) == ExitStatus.SUCCESS


# Generated at 2022-06-21 13:54:20.990596
# Unit test for function main
def test_main():
    return main()


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 13:54:21.600804
# Unit test for function program
def test_program():
    pass

# Generated at 2022-06-21 13:54:31.505349
# Unit test for function program
def test_program():
    import tempfile, shutil
    import requests_mock
    with requests_mock.Mocker() as m:
        m.get('http://localhost', text = 'a')
        tmpdir = tempfile.mkdtemp()
        try:
            c = Environment(stdout=tempfile.TemporaryFile(), stderr=None, config_dir=tmpdir)
        except TypeError:
            # compatibility with python 3.4
            c = Environment(stdout=tempfile.TemporaryFile(), stderr=None, config_dir=tmpdir)
        main(['http', 'http://localhost'], env=c)
        c.stdout.seek(0)
        assert c.stdout.read() == b"HTTP/1.1 200 OK\r\ncontent-length: 1\r\n\r\na"


# Generated at 2022-06-21 13:54:41.061225
# Unit test for function main
def test_main():
    import io
    import sys
    sys.argv = ['http', 'httpbin.org/get']
    # sys.stdout should be TextIOWrapper
    assert 'TextIOWrapper' in str(type(sys.stdout))
    # sys.stdout should be a wrapper of sys.__stdout__
    assert sys.__stdout__ == sys.stdout.buffer
    old_stdout = sys.stdout
    sys.stdout = io.BytesIO()
    main()
    sys.stdout.seek(0)
    # print(sys.stdout.read())
    assert b'HTTP/1.1 200 OK' in sys.stdout.read()
    assert b'GET /get HTTP/1.1' in sys.stdout.read()
    sys.stdout = old_stdout

# Generated at 2022-06-21 13:55:01.474972
# Unit test for function print_debug_info
def test_print_debug_info():
    from unittest.mock import Mock
    from io import StringIO
    env_stderr = Mock()
    env_stderr.wri

# Generated at 2022-06-21 13:55:07.067165
# Unit test for function main
def test_main():
    assert main(['--download', '--output', 'output_file', '--download-resume', '-H', 'Accept:text/plain', 'https://www.google.com/']) == ExitStatus.SUCCESS
    assert main(['-H', 'Accept:text/plain', 'https://www.g00gle.com/']) == ExitStatus.ERROR_CONNECT_FAILED
    assert main(['-H', 'Accept:text/plain', 'https://www.google.com/']) == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:55:17.708979
# Unit test for function main
def test_main():
    assert main(['--help']) == ExitStatus.SUCCESS
    assert main(['--version']) == ExitStatus.SUCCESS
    assert main(['--debug']) == ExitStatus.SUCCESS
    assert main(['https://httpbin.org/get']) == ExitStatus.SUCCESS
    with pytest.raises(SystemExit) as e:
        main(['--help'])
    assert e.value.code == ExitStatus.SUCCESS
    with pytest.raises(SystemExit):
        main(['https://httpbin.org/status/500'])
    with pytest.raises(SystemExit):
        main(['--check-status', 'https://httpbin.org/status/500'])
    assert main(['https://httpbin.org/get']) == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:55:29.436391
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.parser import parser, args_from_config
    args = parser.parse_args(args=[], env=Environment())

    request_body = requests.PreparedRequest()
    response_body = requests.Response()

    args.output_options = None
    assert get_output_options(args=args, message=request_body) == (True, True)
    assert get_output_options(args=args, message=response_body) == (True, True)

    args.output_options = []
    assert get_output_options(args=args, message=request_body) == (True, True)
    assert get_output_options(args=args, message=response_body) == (True, True)

    args.output_options = [OUT_REQ_HEAD]

# Generated at 2022-06-21 13:55:39.925862
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from unittest.mock import patch
    out = StringIO()
    with patch('sys.stdout', new=out):
        from httpie.cli.argtypes import KeyValueArgType
        args = [
            'test',
            '--debug',
            '--form',
            'foo=bar',
            'test'
        ]
        args = KeyValueArgType().convert(args[4:], None, None)
        args.debug = True
        print_debug_info(args)
        out.seek(0)

# Generated at 2022-06-21 13:55:47.856810
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    import os
    import sys
    import tempfile
    import unittest

    temp_config_dir = tempfile.mkdtemp()

    class SysModuleMock(object):
        def __init__(self):
            self.version = '2.7.18'
            self.executable = '/tmp/python2.7'
    sys_module_mock = SysModuleMock()

    class MockStderr(object):
        def __init__(self):
            self.lines: List[str] = []

        def writelines(self, lines):
            self.lines.extend(lines)

        def write(self, s):
            self.lines.append(s)


# Generated at 2022-06-21 13:55:50.776219
# Unit test for function program
def test_program():
    from httpie import ExitStatus

    print("test_program start")

    assert main(["--version"]) == ExitStatus.SUCCESS

    print("test_program end")

# Generated at 2022-06-21 13:55:54.835365
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = [b'foo', 'bar', b'\xe2\x99\xa5']
    decode_raw_args(args, 'utf-8') == ['foo', 'bar', '♥']
    decode_raw_args(args, 'latin1') == ['foo', 'bar', 'â\x99¥']

# Generated at 2022-06-21 13:55:56.344604
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'--form'], 'UTF-8') == ['--form']

# Generated at 2022-06-21 13:56:07.425889
# Unit test for function print_debug_info
def test_print_debug_info():
    from tempfile import NamedTemporaryFile
    from io import TextIOWrapper

    with NamedTemporaryFile('w+t', encoding='utf8') as debug_out:
        env = Environment(debug_out)
        print_debug_info(env)
        debug_out.seek(0)
        text = [l.strip() for l in debug_out.readlines()]
        assert text[0] == f'HTTPie {httpie_version}'
        assert text[1] == f'Requests {requests_version}'
        assert text[2] == f'Pygments {pygments_version}'
        assert text[3] == f'Python {sys.version}'
        assert text[4] == sys.executable

# Generated at 2022-06-21 13:56:44.848554
# Unit test for function main
def test_main():
    '''
    Just run main() and make sure the return status is correct.
    Expect a 200 HTTP status code.
    '''
    import os
    import subprocess
    import sys
    assert main(sys.argv) == 0
    assert main(['http', '--check-status', 'https://httpbin.org/get']) == 0
    assert main(['http', '--check-status', 'https://httpbin.org/status/404']) == 1
    p = subprocess.Popen(['http', '--check-status', 'https://httpbin.org/status/404'], stdout=subprocess.PIPE)
    assert p.wait() == 1
    assert p.returncode == 1

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 13:56:47.286176
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(stdin=None, stdout=None, stderr=None)
    print_debug_info(env)

# Generated at 2022-06-21 13:56:49.509237
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'a', 'b', b'c'], 'utf-8') == ['a', 'b', 'c']

# Generated at 2022-06-21 13:57:01.280319
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
            output_options={
                'verbose': False,
                'headers': False,
                'body': False,
                'http2': False,
                'pretty': False,
                'style': [],
                'stream': False,
                'all': False,
                'implicit_json_output': False
            }
        )

    # example PreparedRequest
    message = requests.PreparedRequest()
    assert (False, False) == get_output_options(args, message)

    args.output_options['headers'] = True
    assert (True, False) == get_output_options(args, message)

    args.output_options['body'] = True
    assert (True, True) == get_output_options(args, message)


# Generated at 2022-06-21 13:57:09.701566
# Unit test for function get_output_options
def test_get_output_options():
    import argparse
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD]
    msg = requests.PreparedRequest()
    print(get_output_options(args=args, message=msg))
    msg = requests.Response()
    print(get_output_options(args=args, message=msg))


if __name__ == '__main__':
    exit(main())

# test_get_output_options()

# Generated at 2022-06-21 13:57:18.647226
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        check_status=True,
        download=False,
        download_resume=True,
        follow=True,
        headers=None,
        ignore_stdin=False,
        output_file=sys.stdout,
        output_file_specified=False,
        output_options=[
            'b',
            'H',
        ],
        pretty=True,
        quiet=False,
        session=False,
        verbose=False,
        verify=True,
    )
    header = requests.Response()
    body = requests.Response()
    header.headers = 'header_text'
    body.content = b'body_text'
    assert get_output_options(args, header) == (True, False)

# Generated at 2022-06-21 13:57:21.195759
# Unit test for function program

# Generated at 2022-06-21 13:57:28.970862
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    from httpie.compat import is_windows
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.plugins.manager import PluginManager

    class FakeStderr(io.BytesIO):
        def isatty(self) -> bool:
            return True

    class FakeStdin(io.BytesIO):
        def isatty(self) -> bool:
            return True

    class FakeConfig(Config):
        def __init__(
            self,
            directory: Optional[str] = None,
            default_options: Optional[List[str]] = None,
        ):
            super().__init__(directory=directory, default_options=default_options)

            # Patch some config values so that the output is easy to test.
           

# Generated at 2022-06-21 13:57:35.791074
# Unit test for function get_output_options
def test_get_output_options():
    """
    Test for function get_output_options.
    """
    args = argparse.Namespace()

    # Test case 1
    args.output_options = [OUT_REQ_HEAD]
    message = requests.PreparedRequest()
    result = ([False, True], [True, False])
    assert result == get_output_options(args, message)

    # Test case 2
    args.output_options = [OUT_RESP_HEAD]
    message = requests.Response()
    assert result == get_output_options(args, message)

# Generated at 2022-06-21 13:57:42.713715
# Unit test for function decode_raw_args
def test_decode_raw_args():
    stdin_encoding = 'utf-8'
    byte_args = ['http', b'--headers', '--output', b'./output.txt', b'http://www.google.com/']
    string_args = ['http', '--headers', '--output', './output.txt', 'http://www.google.com/']
    result = decode_raw_args(byte_args, stdin_encoding)
    assert result == string_args

# Generated at 2022-06-21 13:58:32.569564
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from httpie import Environment
    buffer = StringIO()
    env = Environment(stdin=None, stdout=buffer, stderr=buffer)
    print_debug_info(env)

# Generated at 2022-06-21 13:58:34.674952
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b"--url", b"http://example.com"], 'UTF-8') == ['--url', 'http://example.com']

# Generated at 2022-06-21 13:58:42.235319
# Unit test for function decode_raw_args
def test_decode_raw_args():
    test_cases = [
        ([], 'utf8', []),
        (['abc'], 'utf8', ['abc']),
        (['a', 'b', 'c'], 'ascii', ['a', 'b', 'c']),
        (['a', b'b', 'c'], 'ascii', ['a', 'b', 'c']),
        (['a', b'\xc2b', 'c'], 'utf8', ['a', 'b', 'c']),
    ]
    for test_case in test_cases:
        assert decode_raw_args(test_case[0], test_case[1]) == test_case[2]

# Generated at 2022-06-21 13:58:53.121826
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # If there is no encoding error, then the bytes argument will be successfully converted to
    # the str format
    assert decode_raw_args([b'http', 'https://httpbin.org'], 'utf-8') == ['http', 'https://httpbin.org']
    # The argument is a str format, and the conversion result is the same as the original format
    assert decode_raw_args([b'http', 'https://httpbin.org'], 'utf-8') == ['http', 'https://httpbin.org']
    # If there is an encoding error, then the byte argument will be the original byte string
    assert decode_raw_args([b'http', b'\xa5\xa5'], 'utf-8') == ['http', b'\xa5\xa5']

main()

# Generated at 2022-06-21 13:59:00.088668
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'arg'], 'cp1251') == ['arg']
    assert decode_raw_args([b'--arg'], 'utf8') == ['--arg']
    assert decode_raw_args([b'--arg', b'123'], 'ascii') == ['--arg', '123']
    assert decode_raw_args([b'--arg', b'123', b'--arg2'], 'latin-1') == \
           ['--arg', '123', '--arg2']
    assert decode_raw_args([b'--arg', b'123', b'--arg2', 'str'], 'utf16') == \
           ['--arg', '123', '--arg2', 'str']

# Generated at 2022-06-21 13:59:04.953212
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    test_value = StringIO()
    with mock.patch('httpie.cli.main.env') as mock_env:
        mock_env.stderr = test_value
        main.print_debug_info(mock_env)
        mock_env.stderr.writelines.assert_called_once_with(mock.ANY)

# Generated at 2022-06-21 13:59:09.459116
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    assert env.stderr.getvalue()
    env.stderr.close()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 13:59:15.642630
# Unit test for function main
def test_main():
    def do_test(argv, stdin_encoding, **environ):
        env = Environment(ENV=environ)
        # Allow sys.argv to be modified by tests.
        old_sys_argv = sys.argv
        sys.argv = argv
        try:
            return main(args=argv, env=env)
        finally:
            # Restore.
            sys.argv = old_sys_argv
    return do_test


# Generated at 2022-06-21 13:59:23.955995
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.plugins.registry import plugin_manager

    import os
    plugin_manager.load_installed_plugins()
    parser.parse_args([])
    parser.parse_args(['https://example.org'])
    parser.parse_args(['https://example.org','--print','BODY'])
    parser.parse_args(['https://example.org', '-b'])
    parser.parse_args(['https://example.org', '--download'])
    parser.parse_args(['https://www.baidu.com'])
    print(os.path.abspath(__file__))

# Generated at 2022-06-21 13:59:27.088696
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['ಠ_ಠ'], 'utf-8') == ['ಠ_ಠ']
    assert decode_raw_args([b'\xe0\xb2\xa0_\xe0\xb2\xa0'], 'utf-8') == ['ಠ_ಠ']