

# Generated at 2022-06-21 13:50:55.123018
# Unit test for function main
def test_main():
    # To test that no error occurred if not --check-status
    assert main(['http://example.org']) == 0
    # To test that a KeyboardInterrupt error occurred
    assert main(['http://example.org', '--check-status']) == 1

test_main()

# Generated at 2022-06-21 13:51:05.521921
# Unit test for function program
def test_program():
    from unittest.mock import Mock
    from httpie.cli.definition import parser
    from httpie.cli.parser import KeyValueArgType
    from httpie.config import BaseConfig
    from httpie.output.streams import StdoutBytesIO

    args = parser.parse_args(["get", "https://httpbin.org/get"])
    env = Environment(config=BaseConfig(), stdout=StdoutBytesIO(), stdin=Mock(), stderr=Mock())
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

    args = parser.parse_args(["get", "https://httpbin.org/get", "LICENSE"])

# Generated at 2022-06-21 13:51:15.258310
# Unit test for function get_output_options
def test_get_output_options():
    class MockArgs():
        def __init__(self, options):
            self.output_options = options

    args = MockArgs(['h', 'v'])
    assert get_output_options(args, requests.PreparedRequest()) == (True, True)
    assert get_output_options(args, requests.Response()) == (True, True)

    args = MockArgs(['v'])
    assert get_output_options(args, requests.PreparedRequest()) == (False, True)
    assert get_output_options(args, requests.Response()) == (False, True)

    args = MockArgs(['h'])
    assert get_output_options(args, requests.PreparedRequest()) == (True, False)
    assert get_output_options(args, requests.Response()) == (True, False)

    args = MockArgs

# Generated at 2022-06-21 13:51:19.845424
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a', b'b', 'c'], 'utf-8') == ['a', 'b', 'c']
    assert decode_raw_args([b'a', 'b'], 'utf-8') == ['a', 'b']

# Generated at 2022-06-21 13:51:22.464117
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS
    assert main(env=Environment(stdin_isatty=False), args=['--debug']) == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:51:30.885966
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr = StringIO()
    print_debug_info(env)

# Generated at 2022-06-21 13:51:36.913017
# Unit test for function print_debug_info
def test_print_debug_info():
    class Mock:
        def __init__(self):
            self._ = []
        def writelines(self, lines):
            self._.extend(lines)
    mock = Mock()

    env = Environment()
    env.stderr = mock
    print_debug_info(env)
    s = ''.join(mock._)
    assert s.startswith('HTTPie ')

# Generated at 2022-06-21 13:51:38.625595
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    env.stderr.close()

# Generated at 2022-06-21 13:51:45.476462
# Unit test for function get_output_options
def test_get_output_options():
    
    import pytest
    args = {
        'output_options': ['resp.body', 'req.headers']
    }
    req = requests.PreparedRequest()
    resp = requests.Response()
    assert get_output_options(args, req) == (True, False)
    assert get_output_options(args, resp) == (False, True)

    req.body = 1
    resp.reason = 2
    args = {
        'output_options': ['resp.body', 'req.headers']
    }
    assert get_output_options(args, req) == (True, False)
    assert get_output_options(args, resp) == (False, True)

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 13:51:50.701416
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    assert env.stderr.getvalue().startswith('HTTPie ')
    assert env.stderr.getvalue().endswith('\n')
    assert env.stderr.getvalue().count('\n') >= 6

# Generated at 2022-06-21 13:52:19.874098
# Unit test for function print_debug_info
def test_print_debug_info():
    """
    Test the function print_debug_info().
    """
    import io
    import sys

    env = Environment(
        stdin=io.BytesIO(),
        stdin_isatty=False,
        stdout=io.BytesIO(),
        stdout_isatty=False,
        stderr=io.BytesIO()
    )

    # Patch sys.version and sys.executable to avoid breaking the unit test when the
    # versions change.
    sys.version = 'unittest_version'
    sys.executable = 'unittest_executable'

    # Enable stdin, stdout and stderr
    env.stdin = io.BytesIO()
    env.stderr = io.BytesIO()
    env.stdout = io.BytesIO()

    # Print debug info
    print

# Generated at 2022-06-21 13:52:23.791809
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'\xe2\x80\x93'], 'UTF-8') == ['\u2013']
    assert decode_raw_args([u'\u2013'], 'UTF-8') == ['\u2013']

# Generated at 2022-06-21 13:52:32.882146
# Unit test for function get_output_options
def test_get_output_options():
    env = Environment()
    args = argparse.Namespace()
    args.output_options = []
    msg = requests.Response()
    assert get_output_options(args, msg) == (False, False)

    args.output_options = [OUT_RESP_HEAD]
    assert get_output_options(args, msg) == (True, False)

    args.output_options = [OUT_RESP_HEAD, OUT_RESP_BODY]
    assert get_output_options(args, msg) == (True, True)

    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY]
    msg = requests.PreparedRequest()
    assert get_output_options(args, msg) == (True, True)



# Generated at 2022-06-21 13:52:37.027913
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'\xd3\x04.\x08\x1c\x04'], 'utf-8') == ['贡献.听说']

# Generated at 2022-06-21 13:52:42.440351
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    class Request:
        pass
    class Response:
        pass
    setattr(args, 'output_options', ['req_headers', 'res_body'])
    assert (True, True) == get_output_options(args, Request())
    assert (False, True) == get_output_options(args, Response())

# Generated at 2022-06-21 13:52:52.648644
# Unit test for function program
def test_program():
    import pytest
    from httpie.input import ParseError
    from httpie.client import FatalClientError
    from httpie.status import ExitStatus
    import httpie
    import requests

    # At the time of writing, the following input is not supported.
    args = ['http', 'www.google.com', '--output-file=httpie.txt']
    try:
        env = httpie.Environment()
        program(args=args, env=env)
    except ParseError:
        assert True
    except FatalClientError:
        assert True
    except SystemExit as e:
        assert e.code == ExitStatus.ERROR
    else:
        assert False

    args = ['http', 'httpbin.org/status/500', '--verbose']

# Generated at 2022-06-21 13:52:54.124929
# Unit test for function main
def test_main():
    main(['https://localhost:8080/'])


# Generated at 2022-06-21 13:52:56.469030
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    env.stderr.seek(0)
    assert env.stderr.read()

# Generated at 2022-06-21 13:53:06.824478
# Unit test for function main
def test_main():
    import subprocess
    def test(cmd: str):
        return subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    r1 = test("http https://www.google.com/ --debug")
    r2 = test("http https://www.google.com/ --debug")
    r3 = test("http https://www.google.com/ --debug")
    if r1.returncode == 0 and r2.returncode == 0 and r3.returncode == 0:
        print("test_main passed.")
        return True
    else:
        print("test_main failed", r1.returncode, r2.returncode, r3.returncode)

# Generated at 2022-06-21 13:53:15.640281
# Unit test for function get_output_options

# Generated at 2022-06-21 13:53:50.274329
# Unit test for function program
def test_program():
    from httpie.config import Config
    from httpie.context import Environment, Environment
    from io import StringIO
    from mocks import MockEnvironment
    from httpie.cli.argtypes import KeyValueArg, KeyValue, DataDict
    from colorama import init
    init()

    class MockArgs:
        def __init__(self, headers : List[KeyValue] = None, output_options : List[str] = None):
            self.headers = headers
            self.output_options = output_options
            self.output_file = None
            self.output_file_specified = False
            self.follow = True
            self.download = False
            self.check_status = False
            self.download_resume = False
            self.quiet = False


# Generated at 2022-06-21 13:53:57.430413
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    stdin = io.BytesIO("""
      POST /post HTTP/1.1
      Host: httpbin.org
      Accept-Encoding: gzip, deflate
      Accept: */*
      User-Agent: python-requests/2.18.4
      Content-Length: 4
      Content-Type: application/json

      test

    POST /post HTTP/1.1
    Host: httpbin.org
    Accept-Encoding: gzip, deflate
    Accept: */*
    User-Agent: python-requests/2.18.4
    Content-Length: 4
    Content-Type: application/json

    test
    """.strip().encode('ascii'))
    stdout = io.BytesIO()
    stderr = io.BytesIO()

# Generated at 2022-06-21 13:54:07.235877
# Unit test for function decode_raw_args
def test_decode_raw_args():
    raw_args = [b'raw_arg1', 'non-raw_arg1', b'raw_arg2', 'non-raw_arg2']
    stdin_encoding = 'utf-8'
    # This is just for type checking in this case
    expected = [str, str, str, str]

    args = decode_raw_args(args=raw_args, stdin_encoding=stdin_encoding)

    assert len(args) == len(raw_args)
    assert all(type(arg) == expected[i] for i, arg in enumerate(args))
    assert all(arg == raw_args[i].decode(stdin_encoding) if type(raw_args[i]) is bytes else arg == raw_args[i]
               for i, arg in enumerate(args))

# Generated at 2022-06-21 13:54:08.962844
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr.write = MagicMock()
    print_debug_info(env)
    env.stderr.write.called

# Generated at 2022-06-21 13:54:13.179307
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(
        args=[b'GET'],
        stdin_encoding='utf-8'
    ) == ['GET']
    assert decode_raw_args(
        args=['GET'],
        stdin_encoding='utf-8'
    ) == ['GET']
    assert decode_raw_args(
        args=[b'\xe4\xbd\xa0\xe5\xa5\xbd'],
        stdin_encoding='utf-8'
    ) == ['你好']

# Generated at 2022-06-21 13:54:17.954490
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.core import main
    from unittest.mock import MagicMock

    fake_stdout = MagicMock()

    env = main.Environment()
    env.stderr = fake_stdout
    main.print_debug_info(env)
    assert fake_stdout.write.called is True


# Generated at 2022-06-21 13:54:27.343343
# Unit test for function program
def test_program():
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.config = Config()
    env.config.colors = None
    env.stdout_isatty = False
    exit_status = program(
        args=argparse.Namespace(
            check_status=True,
            download=False,
            download_resume=False,
            follow=True,
            headers=None,
            output_file=None,
            output_options=None,
            quiet=False,
            traceback=False,
            verbose=False,
            output_file_specified=False,
        ),
        env=env,
    )
    assert exit_status == ExitStatus.SUCCESS



# Generated at 2022-06-21 13:54:28.574945
# Unit test for function print_debug_info
def test_print_debug_info():
    pass

# Generated at 2022-06-21 13:54:34.243094
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    assert env.stdout.getvalue() == f'HTTPie {httpie_version}\nRequests {requests_version}\nPygments {pygments_version}\nPython {sys.version}\n{sys.executable}\n{platform.system()} {platform.release()}\n\n\n{repr(env)}\n'


# Generated at 2022-06-21 13:54:34.890981
# Unit test for function program
def test_program():
    return program()

# Generated at 2022-06-21 13:55:26.830233
# Unit test for function print_debug_info
def test_print_debug_info():
    env=Environment()
    env.stderr=io.StringIO()
    env.stderr.isatty = lambda: True
    print_debug_info(env)
    env.stderr.seek(0)
    s=env.stderr.read()
    assert 'HTTPie 1.0.3' in s
    assert 'Requests 2.23.0' in s
    assert 'Pygments 2.5.2' in s
    assert 'Python 3.8.4' in s
    assert 'Windows 10' in s
    assert '<httpie.context.Environment object at' in s

# Generated at 2022-06-21 13:55:28.177212
# Unit test for function program
def test_program():
    # TODO
    pass

# Generated at 2022-06-21 13:55:33.401688
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options = [OUT_REQ_BODY]
    )

    request = requests.PreparedRequest()
    assert get_output_options(args, request) == (False, True)

    response = requests.Response()
    assert get_output_options(args, response) == (False, False)

# Generated at 2022-06-21 13:55:41.244016
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = [
        '--form',
        b'-a',
        b'httpie:password',
        '-A',
        b'Mozilla/5.0',
        'https://httpbin.org/anything',
        '--json',
        b'{"name": "value"}'
    ]
    assert decode_raw_args(args, 'ascii') == [
        '--form',
        '-a',
        'httpie:password',
        '-A',
        'Mozilla/5.0',
        'https://httpbin.org/anything',
        '--json',
        '{"name": "value"}'
    ]

# Generated at 2022-06-21 13:55:44.580681
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b"arg"], "utf-8") == ["arg"]
    assert decode_raw_args(["arg"], "utf-8") == ["arg"]
    assert decode_raw_args([b"arg", u"arg"], "utf-8") == ["arg", "arg"]

# Generated at 2022-06-21 13:55:49.010396
# Unit test for function main
def test_main():
    """
    Test the unit method main
    """
    # When:
    # the main method is called and the exit status is different from 0
    assert main(args=[sys.argv[0], '--debug']) != 0

    # When:
    # the main method is called and the exit status is equals to 0
    assert main(args=[sys.argv[0], '--debug', 'GET', 'http://httpbin.org/status/200']) == 0

# Generated at 2022-06-21 13:55:51.775328
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = [b'--debug', 'foo']
    assert decode_raw_args(args=args, stdin_encoding='utf8') == ['--debug', 'foo']

# Generated at 2022-06-21 13:55:54.793039
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args_str = ['-b', 'key:value', '--form', 'a', 'b']
    assert decode_raw_args(args_str, 'utf-8') == args_str



# Generated at 2022-06-21 13:56:05.900551
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie import __version__ as httpie_version
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.status import ExitStatus
    from httpie.utils import get_os_username
    from httpie.plugins import plugin_manager
    from pygments import __version__ as pygments_version
    from requests import __version__ as requests_version
    import platform
    import sys
    from httpie.output.writer import write_message
    class MockStderr:
        def __init__(self, env):
            self.env = env

        def write(self,s):
            self.env.stderr.write(s)
        def writelines(self,s):
            self.env.stderr.writelines(s)

# Generated at 2022-06-21 13:56:10.816382
# Unit test for function print_debug_info
def test_print_debug_info():
    debug_info = []
    def mock_write(s):
        nonlocal debug_info
        debug_info.append(s)

    class MockStderr:
        def write(self, s):
            mock_write(s)

    import sys
    import platform
    original_version = sys.version

# Generated at 2022-06-21 13:56:38.839309
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    s = io.StringIO()
    print_debug_info(Environment(stderr=s))
    s.seek(0)
    assert s.read() == 'HTTPie {0}\nRequests {1}\nPygments {2}\nPython {3}\n{4}\n{5} {6}'.format(
        __version__,
        requests.__version__,
        pygments.__version__,
        sys.version,
        sys.executable,
        platform.system(),
        platform.release()
    )

# Generated at 2022-06-21 13:56:42.900983
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'foo'], 'utf-8') == ['foo']
    assert decode_raw_args(['foo', b'bar'], 'utf-8') == ['foo', 'bar']
    assert decode_raw_args(['foo', 'bar'], 'utf-8') == ['foo', 'bar']

# Generated at 2022-06-21 13:56:54.280425
# Unit test for function decode_raw_args

# Generated at 2022-06-21 13:57:03.585353
# Unit test for function decode_raw_args
def test_decode_raw_args():
    # Setup
    args = ['/usr/bin/http', 'https://httpbin.org/post']
    stdin_encoding = 'utf8'
    assert(all(type(arg) is str for arg in args))

    # Test
    args_bytes = [arg.encode() for arg in args]
    args_decoded = decode_raw_args(args_bytes, stdin_encoding)
    assert(all(type(arg) is str for arg in args))
    assert(args == args_decoded)


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 13:57:07.221597
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'\xe8'], 'utf-8') == ['è']

if __name__ == '__main__':
    exit_status = main()  # pragma: no cover
    sys.exit(exit_status)

# Generated at 2022-06-21 13:57:07.862374
# Unit test for function program
def test_program():
    pass

# Generated at 2022-06-21 13:57:16.712498
# Unit test for function main
def test_main():
    # TODO: Can we use `assert_raises_as` here?
    try:
        from simplefix import FixMessage
    except ImportError:
        pytest.skip('requires the simplefix package')

    from httpie.compat import is_windows

    def dummy_function(*args, **kwargs):
        pass

    def Popen_mock(*args, **kwargs):
        return mock.Mock(stdout=io.BytesIO(b'{"x": "y"}\n'), stderr=io.BytesIO(b'error=1'))

    def Popen_mock_stdin_encoding(*args, **kwargs):
        return mock.Mock(stdout=io.BytesIO(
            f'a{ascii_bytes}b'.encode('ascii')
        ))


# Generated at 2022-06-21 13:57:25.971026
# Unit test for function print_debug_info
def test_print_debug_info():
    """
    Test print_debug_info()
    """

    class EnvironmentMock:
        def __init__(self):
            self.stderr = StderrMock()

    class StderrMock:
        def __init__(self):
            self.s = []

        def write(self, msg):
            self.s.append(msg)

        def writelines(self, msg):
            self.s.append(msg)

    env = EnvironmentMock()
    print_debug_info(env)
    assert (len(env.stderr.s) == 6)
    assert (env.stderr.s[0].startswith("HTTPie "))
    assert (env.stderr.s[1].startswith("Requests "))

# Generated at 2022-06-21 13:57:27.132617
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-21 13:57:28.345635
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:58:25.119999
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    env = Environment()
    main(args, env)

# Generated at 2022-06-21 13:58:28.598308
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser

    args = parser.parse_args(["http", "www.baidu.com"])
    sys.argv = ["httpie.py", "http", "www.baidu.com"]
    main(sys.argv, env=Environment())

# Generated at 2022-06-21 13:58:37.934804
# Unit test for function program
def test_program():
    from httpie.cli.args import args_parser
    from httpie.context import Environment
    from httpie.output.streams import StdoutStderrBytesIO
    args = args_parser.parse_args(['--body', '--verbose', '--ignore-stdin', 'GET', 'https://httpbin.org/get'])
    env = Environment(stdout=StdoutStderrBytesIO(), stderr=StdoutStderrBytesIO())
    program(args=args, env=env)
    assert len(env.stdout.getvalue()) > 0

if __name__ == '__main__':
    exit_status = main(sys.argv, Environment())
    sys.exit(exit_status)

# Generated at 2022-06-21 13:58:44.930423
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(stdin=io.BytesIO(), stdout=io.BytesIO(), stderr=io.BytesIO())
    print_debug_info(env)
    stderr_bytes = env.stderr.getvalue()
    env.stderr.close()
    stderr = stderr_bytes.decode('ascii')
    assert 'HTTPie' in stderr
    assert 'Requests' in stderr
    assert 'Pygments' in stderr
    assert 'Python' in stderr
    assert sys.version in stderr
    assert sys.executable in stderr
    assert platform.system() in stderr
    assert platform.release() in stderr

# Generated at 2022-06-21 13:58:56.150840
# Unit test for function get_output_options
def test_get_output_options():
    assert get_output_options(argparse.Namespace(output_options=['b','h']), requests.PreparedRequest()) == (True, True)
    assert get_output_options(argparse.Namespace(output_options=['h']), requests.PreparedRequest()) == (True, False)
    assert get_output_options(argparse.Namespace(output_options=['b']), requests.PreparedRequest()) == (False, True)
    assert get_output_options(argparse.Namespace(output_options=[]), requests.PreparedRequest()) == (False, False)

    assert get_output_options(argparse.Namespace(output_options=['B','H']), requests.Response()) == (True, True)

# Generated at 2022-06-21 13:59:01.084466
# Unit test for function get_output_options
def test_get_output_options():
    class Args():
        output_options = {OUT_REQ_BODY, OUT_REQ_HEAD}
    args = Args()

    class PreparedRequest(object):
        pass
    class Response(object):
        pass

    assert get_output_options(args=args, message=PreparedRequest()) == (True, True)
    assert get_output_options(args=args, message=Response()) == (False, False)

# Generated at 2022-06-21 13:59:09.193457
# Unit test for function print_debug_info

# Generated at 2022-06-21 13:59:15.678414
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=["json", "pretty"])
    req = requests.PreparedRequest()
    req.headers = {'Header-Field': 'request'}
    resp = requests.Response()
    resp.headers = {'Header-Field': 'response'}
    options_req = get_output_options(args, req)
    options_resp = get_output_options(args, resp)
    assert options_req == (True, True)
    assert options_resp == (True, True)

# Generated at 2022-06-21 13:59:25.220762
# Unit test for function main
def test_main():
    def run_main(
        args: List[str],
        env: Environment,
        exit_status: Union[ExitStatus, Exception],
        stdin: bytes = b'',
    ) -> Tuple[int, bytes, bytes]:
        stdin_original = sys.stdin
        stdin_encoding_original = env.stdin_encoding
        env.stdin_encoding = 'utf-8'
        if stdin:
            sys.stdin = io.BytesIO(stdin)

# Generated at 2022-06-21 13:59:27.918265
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'123', '456', b'789'], stdin_encoding='utf8') == ['123', '456', '789']

# Generated at 2022-06-21 14:00:28.067455
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser
    args = parser.parse_args(['arg1', 'arg2'])
    args.output_options = ['hbh', 'noB']
    resp = requests.Response()
    resp.is_redirect = False
    resp.request = requests.Request()
    resp.request.method = 'get'
    resp_head, resp_body = get_output_options(args, resp)
    assert(resp_head == True and resp_body == False)
    resp.is_redirect = True
    resp_head, resp_body = get_output_options(args, resp)
    assert(resp_head == True and resp_body == False)
    req = requests.PreparedRequest()
    req.headers = {}

# Generated at 2022-06-21 14:00:31.008164
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options = ['hb']
    )
    message = requests.PreparedRequest()
    assert get_output_options(args, message) == (True, True)

if __name__ == '__main__':
    print(main())

# Generated at 2022-06-21 14:00:37.311038
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import re
    import unittest

    class MockStdErr:
        def __init__(self):
            self.output = io.StringIO()

        def write(self, s):
            self.output.write(s)

        def writelines(self, lines):
            self.output.writelines(lines)

        def getvalue(self):
            return self.output.getvalue()

    class MockView():
        def __getattr__(self, item):
            return None

    class TestPrintDebugInfo(unittest.TestCase):
        def test_prints_httpie_info(self):

            stderr = MockStdErr()

            env = Environment(stderr=stderr)
            env.config = MockView()
            env.stdin = MockView()
            env