

# Generated at 2022-06-21 13:51:20.250350
# Unit test for function print_debug_info
def test_print_debug_info():
    import sys
    import unittest
    from unittest.mock import patch
    from io import StringIO
    stdout = StringIO()
    stderr = StringIO()
    with patch('sys.stdout', stdout):
        with patch('sys.stderr', stderr):
            print_debug_info(sys.stdout, sys.stderr)
    expected = [
        f'HTTPie {httpie_version}\n',
        f'Requests {requests_version}\n',
        f'Pygments {pygments_version}\n',
        f'Python {sys.version}\n{sys.executable}\n',
        f'{platform.system()} {platform.release()}\n',
    ]

# Generated at 2022-06-21 13:51:26.096785
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    stdout = StringIO()
    stderr = StringIO()
    main(['http', '--debug'], Environment(stdout=stdout, stderr=stderr))
    assert stdout.getvalue() == ''
    assert stderr.getvalue().startswith('HTTPie ')

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 13:51:31.661151
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr = io.StringIO()
    print_debug_info(env)
    output = env.stderr.getvalue()
    assert 'HTTPie' in output
    assert 'Python' in output
    assert 'Requests' in output
    assert 'Pygments' in output



# Generated at 2022-06-21 13:51:41.916654
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.constants import OUTPUT_OPTIONS, DEFAULT_OPTIONS, DEFAULT_METHOD
    from httpie.plugins import plugin_manager
    from httpie.input import SEP_CREDENTIALS
    from httpie.output.streams import MissingStdinError
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.status import ExitStatus

    def _test_program(
        args: List[str],
        exit_status: ExitStatus,
        expected_stdout: str,
    ):
        """
        Runs program() with `args` and asserts that
        the `exit_status` and the contents of sys.stdout
        are as expected.

        """
        import sys

# Generated at 2022-06-21 13:51:51.588728
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert main(['http', b'--json', '-'],
                env=Environment(stdin_encoding='latin1')) == ExitStatus.ERROR_HTTP_4XX
    assert main(['http', '--json', b'-'],
                env=Environment(stdin_encoding='utf8')) == ExitStatus.SUCCESS
    # The following test will fail miserably on Windows.
    if sys.platform != 'win32':
        assert main(['http', '--json', b'-'],
                    env=Environment(stdin_encoding='ascii')) == ExitStatus.ERROR_HTTP_4XX

# Generated at 2022-06-21 13:52:02.573169
# Unit test for function program
def test_program():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.definition import parser

    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.status import ExitStatus

    args = parser.parse_args(
        args=["http", "--auth-type=basic", "--auth=user:password", "127.0.0.1:5000"],
        env=Environment(),
    )
    plugin_manager.load_builtin_plugins()

    args.auth = HTTPBasicAuth().get_auth(args)
    args.headers = KeyValueArg('header').convert(args.headers, args, 'headers')
    exit_status = program(args=args, env=Environment())

    #Check exit status
    assert(exit_status == ExitStatus.SUCCESS)

    return exit_status

# Generated at 2022-06-21 13:52:06.844359
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment

    exit_code = program(parser.parse_args(['https://httpbin.org/status/200']), Environment())
    assert exit_code == 0

# Generated at 2022-06-21 13:52:08.201436
# Unit test for function print_debug_info
def test_print_debug_info():
    main(['--debug'])
    main(['--debug', '--traceback'])

# Generated at 2022-06-21 13:52:09.458466
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    
    print_debug_info(env)

# Generated at 2022-06-21 13:52:17.449191
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    env = Environment(stdout=StringIO(), stderr=StringIO())
    print_debug_info(env)
    debug_info = env.stderr.getvalue()
    assert f'HTTPie {httpie_version}' in debug_info
    assert f'Requests {requests_version}' in debug_info
    assert f'Pygments {pygments_version}' in debug_info
    assert f'Python {sys.version}' in debug_info
    assert sys.executable in debug_info
    assert f'{platform.system()} {platform.release()}' in debug_info

# Generated at 2022-06-21 13:52:43.893415
# Unit test for function print_debug_info
def test_print_debug_info():
    class MockStdErr:
        def __init__(self):
            self.lines = []

        def writelines(self, lines: List[str]):
            self.lines.extend(lines)

        def write(self, line: str):
            self.lines.append(line)

    mock_stderr = MockStdErr()
    env = Environment()
    env.stderr = mock_stderr
    print_debug_info(env)

# Generated at 2022-06-21 13:52:53.834866
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        follow = False,
        max_redirects = 30,
        output_options = [],
        output_file = 'test_output_file',
        output_file_specified = False,
        verbose = False,
        headers = [],
        download = False,
        download_resume = False,
    )
    request = requests.PreparedRequest()
    response = requests.Response()

    request_body_read_callback = None

    """command is POST --output=req_body http://localhost:8080/a"""
    args.output_options = [OUT_REQ_BODY]
    assert get_output_options(args, request) == (False, True)
    assert get_output_options(args, response) == (False, False)


# Generated at 2022-06-21 13:53:03.927340
# Unit test for function program
def test_program():
    from httpie.cli.constants import DEFAULT_PRESET_OPTIONS
    from httpie.cli.definition import parser

    env = Environment()
    for path in DEFAULT_PRESET_OPTIONS:
        env.config.load_preset(path, override=False)

    # the actual tests
    args = parser.parse_args(args=['httpie.org'], env=env)
    status = program(args=args, env=env)
    assert status == ExitStatus.SUCCESS

    args = parser.parse_args(args=['--timeout=10', 'httpie.org'], env=env)
    status = program(args=args, env=env)
    assert status == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:53:13.253987
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=[b'foo'], stdin_encoding='utf8') == ['foo']
    assert decode_raw_args(args=[b'foo\xe2\x85\xab'], stdin_encoding='utf8') == ['fooⅫ']
    assert decode_raw_args(args=[b'foo\x80'], stdin_encoding='utf8') == ['foo\x80']
    assert decode_raw_args(args=[b'foo\x80'], stdin_encoding='latin1') == ['foo\x80']
    assert decode_raw_args(args=[b'foo'], stdin_encoding='latin1') == ['foo']

# Generated at 2022-06-21 13:53:14.814031
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.context import Environment
    env = Environment()
    print_debug_info(env)

# Generated at 2022-06-21 13:53:26.012306
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import TextIOWrapper

    class TextIOWrapper_with_buffer_mock(TextIOWrapper):

        buffer = None

        @property
        def buffer(self):
            return self._buffer

        @buffer.setter
        def buffer(self, value):
            self._buffer = value

    def string_IO_from(src: Union[TextIOWrapper_with_buffer_mock, bytes]) -> TextIOWrapper_with_buffer_mock:
        """
        Return a TextIOWrapper_with_buffer_mock object instance
        with a buffer attribute that refers to a BytesIO object
        whose contents are the contents of src.

        """
        assert isinstance(src, (TextIOWrapper_with_buffer_mock, bytes))
        from io import BytesIO


# Generated at 2022-06-21 13:53:27.991116
# Unit test for function main
def test_main():
    assert main(["http", "get", "https://api.github.com/zen"]) == 0

# Generated at 2022-06-21 13:53:35.816282
# Unit test for function get_output_options
def test_get_output_options():
    def _test_case(args, message, with_headers, with_body):
        actual_with_headers, actual_with_body = get_output_options(args, message)
        assert actual_with_headers == with_headers
        assert actual_with_body == with_body

    args = argparse.Namespace(
        output_options=[OUT_REQ_HEAD, OUT_RESP_HEAD, OUT_RESP_BODY]
    )
    _test_case(args, requests.PreparedRequest(), with_headers=True, with_body=False)
    _test_case(args, requests.Response(), with_headers=True, with_body=True)

# Generated at 2022-06-21 13:53:40.018560
# Unit test for function print_debug_info
def test_print_debug_info():
    import sys
    sys.stderr = open(r".\test.txt", "a")
    print_debug_info(Environment())

# main(args=sys.argv)

# Generated at 2022-06-21 13:53:50.316162
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from contextlib import redirect_stderr
    stderr = StringIO()
    with redirect_stderr(stderr):
        print_debug_info(Environment())
    assert 'HTTPie ' in stderr.getvalue()
    assert 'Requests ' in stderr.getvalue()
    assert 'Pygments ' in stderr.getvalue()
    assert 'Python ' in stderr.getvalue()
    assert sys.executable in stderr.getvalue()
    assert platform.system() in stderr.getvalue()
    assert platform.release() in stderr.getvalue()


# help: print help and exit
# version: print version and exit
# verify
# proxy
# debug, traceback
# check_status, download, download_resume

# Generated at 2022-06-21 13:54:22.757621
# Unit test for function program
def test_program():
    from httpie.cli import prog
    from httpie.output.writer import write_message, split_body, write_stream
    from httpie.output.formatters import JSONFormatter, URLEncodedFormatter, UnquotedJSONFormatter, TokenizedJSONFormatter, TokenizedURLEncodedFormatter, TokenizedUnquotedJSONFormatter

    args = prog.get_args(['--json', '--headers', '/v1/resource'])
    args.quiet = False
    args.output_options = ['h', 'b']
    args.headers = []
    args.output_file = None
    args.download = False
    args.download_resume = False
    args.formatter = JSONFormatter()
    args.follow = False
    args.check_status = True
    args.output_file_specified = False


# Generated at 2022-06-21 13:54:30.298895
# Unit test for function print_debug_info
def test_print_debug_info():
    BufferedStderr = io.StringIO()
    print_debug_info(Environment(stderr=BufferedStderr))
    assert 'HTTPie' in BufferedStderr.getvalue()
    assert 'Requests' in BufferedStderr.getvalue()
    assert 'Pygments' in BufferedStderr.getvalue()
    assert 'Python' in BufferedStderr.getvalue()
    assert 'IO.UnsupportedOperation' not in BufferedStderr.getvalue()
    assert 'Windows' in BufferedStderr.getvalue() or 'Linux' in BufferedStderr.getvalue()

# Generated at 2022-06-21 13:54:40.281633
# Unit test for function main
def test_main():
    assert main(env=Environment(stdout_isatty=True))==0
    assert main(['http.py', '--debug'],env=Environment(stdout_isatty=True))==0
    assert main(['http.py', '--debug', '--quiet'],env=Environment(stdout_isatty=True))==0
    assert main(args=['http.py', '--debug', '--output-file', 'C:/Users/Abhilash/Desktop/PyScript/httpie/test_main.py', '--output-options=format'],env=Environment(stdout_isatty=True))==0

# Generated at 2022-06-21 13:54:51.171470
# Unit test for function main
def test_main():
    import tempfile
    import os, shutil
    from httpie import ExitStatus
    from httpie.cli.__main__ import main
    import pytest
    class Dummy_env:
        def __init__(self):
            self.stderr = open(os.devnull, 'w')

    tmpdir = tempfile.mkdtemp()
    args = ['https://httpie.org/', '--output', os.path.join(tmpdir,'out.txt'), '--debug']
    env = Dummy_env()
    env.program_name = 'http'

# Generated at 2022-06-21 13:54:53.369511
# Unit test for function print_debug_info
def test_print_debug_info():
    print_debug_info(env)

if __name__ == '__main__':
    #print(main())
    test_print_debug_info()

# Generated at 2022-06-21 13:55:03.471400
# Unit test for function main
def test_main():
    from unittest import mock
    from httpie.cli.context import Environment
    from httpie.context import Context
    from httpie.status import ExitStatus

    # Checking whether error handling works
    def side_effect_func(*args, **kwargs):  # Don't need to know exactly what it does
        raise RuntimeError('test_main_error')

    patcher = mock.patch('httpie.cli.main.program', side_effect=side_effect_func)
    # Starting to mock the side effect in 'program'
    patcher.start()

    # Create a mock 'Environment' object
    context = Context()
    filename = 'httpie/cli/config'
    context.config_dir = os.path.join(os.path.dirname(__file__), '../', '../', filename)
    context.stdin_

# Generated at 2022-06-21 13:55:05.358585
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'x', 'y'], 'utf8') == ['x', 'y']

# Generated at 2022-06-21 13:55:11.019541
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert ['a', 'b'] == decode_raw_args(['a', 'b'], 'utf-8')
    assert ['a', 'b'] == decode_raw_args([b'a', b'b'], 'utf-8')
    assert ['a', '€'] == decode_raw_args([b'a', b'\xe2\x82\xac'], 'utf-8')

# Generated at 2022-06-21 13:55:20.732026
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import logging
    import tempfile
    from httpie.context import Environment

    env = Environment()

    # TODO: Implement proper testing of logging.
    # `http --debug` should output everything that was logged.
    #
    # env.stderr = io.BytesIO()
    # logging.basicConfig(stream=env.stderr, level=logging.DEBUG)
    #
    # env.config.directory = tempfile.mkdtemp()
    # print_debug_info(env)
    # logging.shutdown()
    #
    # # ...
    #
    # shutil.rmtree(env.config.directory)

    env.stderr = io.BytesIO()
    print_debug_info(env)

# Generated at 2022-06-21 13:55:33.013260
# Unit test for function main
def test_main():
    from httpie.cli.constants import (
        UNICODE_BYTES,
    )
    from httpie.cli.parser import get_parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import builtin_plugins, plugin_manager

    plugin_manager.load_installed_plugins()

    class MockExitCodeException(SystemExit):

        def __init__(self, status):
            self.status = status
            super().__init__(status)

    def mock_program(args, env):
        if 'status500' in args:
            return ExitStatus.ERROR
        elif 'timeout' in args:
            raise requests.Timeout

# Generated at 2022-06-21 13:57:49.682852
# Unit test for function program
def test_program():
    import argparse
    from httpie import argument_parser, cli_server
    
    args = argparse.Namespace()
    args.url = '127.0.0.1:8500'
    args.check_status = True
    args.method = 'GET'
    args.headers =  '--header "Content-type: application/json"'
    args.allow_redirects = True
    args.timeout = 60
    args.output_options = "Hh"
    args.download = False
    args.output_file = None
    args.output_file_specified = True
    args.verify = True
    args.verify_ssl = True

    d = program(args, cli_server.env)
    assert d == 0


# Generated at 2022-06-21 13:57:55.363572
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_HEAD, OUT_RESP_BODY]
    message_type_list = [
        requests.PreparedRequest,
        requests.Response
    ]
    for message_type in message_type_list:
        if message_type is requests.PreparedRequest:
            assert get_output_options(args=args, message=requests.PreparedRequest()) == (True, False)
        else:
            assert get_output_options(args=args, message=requests.Response()) == (False, True)

# Generated at 2022-06-21 13:58:00.818179
# Unit test for function decode_raw_args
def test_decode_raw_args():
    raw_args = [b'a', 'b', b'\xe2\x9c\x93']
    decoded_args = decode_raw_args(raw_args, 'utf-8')
    assert decoded_args == ['a', 'b', '✓']
    assert type(decoded_args[-1]) is str


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 13:58:06.482297
# Unit test for function main
def test_main():
    # Initialize Environment
    e = Environment()
    # test with the --json and --verbose flag
    main_result = main(['httpie', '--json', '--verbose'], env=e)
    # I couldn't get the argparse to work with the default in the main function
    # because the path to the config file was being passed in from the system environment
    # so I had to hard code the path to the config file here
    # I think it's fine because the test is isolated to this file
    # You can see the error I got below

# Generated at 2022-06-21 13:58:09.029250
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(stderr=io.StringIO())
    print_debug_info(env)
    assert env.stderr.getvalue()

# Generated at 2022-06-21 13:58:16.983013
# Unit test for function main
def test_main():
    # mock env
    class MockedEnvironment:
        def __init__(self, config=None):
            self.stderr = sys.stderr
            self.stdin_encoding = sys.stdin.encoding
            self.log_stderr = self.stderr.write
            self.config = MockedConfig(config)
            self.stdout = sys.stdout

    class MockedConfig:
        def __init__(self, config):
            self.directory = "./"
            self.default_options = config

    def mock_get_output_options(param1, param2):
        # param1 is args
        # param2 is response
        return (True, True)

    # captured output
    output = StringIO()

    # use capsys to caputure stdout

# Generated at 2022-06-21 13:58:27.812582
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser

    env = Environment()
    args = parser.parse_args(
            env=env,
            args=['--print', 'Bb', 'httpbin.org', '-X', 'GET',]
    )

    message = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args=args, message=message)
    assert(with_headers == False)
    assert(with_body == True)

    message = requests.Response()
    with_headers, with_body = get_output_options(args=args, message=message)
    assert(with_headers == False)
    assert(with_body == True)

# Generated at 2022-06-21 13:58:38.067452
# Unit test for function decode_raw_args
def test_decode_raw_args():
    for args in [
        [b'\xd4\xce\xd5\xe2\xd4\xd8'],
        ['foo', b'\xd4\xce\xd5\xe2\xd4\xd8'],
        [b'\xd4\xce\xd5\xe2\xd4\xd8', 'bar'],
        ['foo', b'\xd4\xce\xd5\xe2\xd4\xd8', 'bar'],
    ]:
        assert decode_raw_args(args, 'cp1251') == [
            'ÔÎÕÂÔØ'
            if type(arg) is bytes else arg
            for arg in args
        ]


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 13:58:45.345527
# Unit test for function get_output_options
def test_get_output_options():
    global args
    class Args:
        def __init__(self):
            self.output_options = ''
            self.check_status = True
            self.download = True
            self.download_resume = False
            self.follow = True
            self.headers = ''
            self.output_file = 'stdout'
            self.output_file_specified = True
            self.quiet = False
            self.timeout = 30
            self.max_redirects = 10
            self.repeat = 1
            self.session_read = False
            self.session_write = False
            self.session_name = ''
            self.session_read_only = False
            self.session_spec = ''
            self.stream = False
            self.verbose = False
            self.verify = True
            self.auth = ''

# Generated at 2022-06-21 13:58:50.769992
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=['žluťoučký', b'k\xf8\xf8h'], stdin_encoding='ascii') == ['žluťoučký', 'k\ufffd\ufffdh']
    assert decode_raw_args(args=[b'\xe9\x9d\x99', '-', 'a'], stdin_encoding='utf-8') == ['静', '-', 'a']

    try:
        decode_raw_args(args=[b'\xe9\x9d\x99', 'b'], stdin_encoding='ascii')
    except Exception as e:
        assert isinstance(e, UnicodeDecodeError)