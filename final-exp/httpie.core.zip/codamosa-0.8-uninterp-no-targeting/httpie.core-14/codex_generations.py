

# Generated at 2022-06-21 13:51:35.330351
# Unit test for function main
def test_main():
    import sys
    import doctest
    doctest.testmod()


# Generated at 2022-06-21 13:51:43.410199
# Unit test for function program
def test_program():
    from httpie.cli import program
    from httpie.cli.definition import parser
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.output.formatters.colors import NoColors
    from httpie.context import Environment
    import httpie
    
    def check_program(arguments, expected_status):
        args = parser.parse_args(
            args=arguments,
            env=Environment()
        )
        status = program(args=args, env=Environment())
        if status != expected_status:
            print(arguments, expected_status, status)
    
    check_program(['httpie', '--help'], 0)
    
if __name__ == '__main__':
    main();

# Generated at 2022-06-21 13:51:45.793462
# Unit test for function program
def test_program():
    status = program(args = ['httpie', 'http://httpbin.org/ip'], env = Environment())
    assert status == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:51:50.652136
# Unit test for function main
def test_main():
    assert main(['http', '--output=json', 'http://example.com']) == 2
    assert main(['http', 'http://httpbin.org/get']) == 0
    assert main(['http', '--debug']) == 0


# Generated at 2022-06-21 13:51:52.126905
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)

# Generated at 2022-06-21 13:52:02.985138
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.output.streams import StdoutBytesIO, StderrBytesIO
    env = Environment()
    env.stdin = StdoutBytesIO()
    env.stdout = StdoutBytesIO()
    env.stderr = StderrBytesIO()
    args = parser.parse_args(args=['--debug', '--traceback', '--verbose',
                                   'GET', 'http://httpbin.org/robots.txt',
                                   'User-Agent:hello'], env=env)
    program(args=args, env=env)
    assert env.stdout.getvalue().__contains__(b"User-Agent: hello")



# Generated at 2022-06-21 13:52:12.699972
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    from httpie.cli.parser import get_parser

    # self.assertIn(b'Python', result)
    # self.assertIn(str.encode(sys.executable), result)
    # self.assertIn(str.encode(platform.system()), result)
    # self.assertIn(str.encode(platform.release()), result)
    parser, namespace = get_parser(stdin_encoding='utf8')
    parser.parse_args(['--debug'], namespace=namespace)
    assert namespace.debug
    result = io.StringIO()
    with patch('httpie.cli.main.httpie_version', new_callable=PropertyMock) as httpie_version:
        httpie_version.return_value = "0.9.9"

# Generated at 2022-06-21 13:52:21.117411
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args_bytes_unicode = ['http', 'get', 'http://example.com/?foo=%41', u'--auth=%E3%81%82']
    assert decode_raw_args(args_bytes_unicode, 'utf8') == ['http', 'get', 'http://example.com/?foo=%41', '--auth=あ']
    assert decode_raw_args(args_bytes_unicode, 'sjis') == ['http', 'get', 'http://example.com/?foo=%41', '--auth=あ']
    assert decode_raw_args(args_bytes_unicode, 'iso2022_jp') == ['http', 'get', 'http://example.com/?foo=%41', '--auth=あ']

# Generated at 2022-06-21 13:52:31.052789
# Unit test for function main
def test_main():
    from httpie.context import Environment
    from httpie.cli.definition import parser
    from httpie.downloads import Downloader
    argvs = [
        'http',
        '--debug',
        'https://jsonplaceholder.typicode.com/todos/1'
    ]
    env = Environment(stdin_isatty=True, stdout_isatty=True, stdin=None, stdout=None, stderr=None)
    assert main(argvs, env) == 0

    args, unknown = parser.parse_known_args(argvs, env)
    assert args.debug == True
    assert args.output_file == None
    assert args.output_options == [OUT_RESP_BODY]
    assert args.output_style == None
    assert args.output_style_examples

# Generated at 2022-06-21 13:52:33.201084
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr = sys.stderr
    print_debug_info(env)

# Generated at 2022-06-21 13:54:03.204053
# Unit test for function get_output_options
def test_get_output_options():
    # prepare command line arguments
    args = argparse.Namespace(
        output_options=['all', 'method', 'version', 'status', 'summary', 'url']
    )

    # test request message
    request = requests.PreparedRequest()

    assert get_output_options(args, request) == (True, True)

    # test response message
    response = requests.Response()

    assert get_output_options(args, response) == (True, True)

# Generated at 2022-06-21 13:54:10.058613
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=[OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD])

    # Arrange
    # request message
    request = requests.PreparedRequest()
    with_headers, with_body = get_output_options(args, request)

    # request message
    response = requests.Response()
    with_headers, with_body = get_output_options(args, response)

    # Assert the function get_output_options
    assert with_headers == True and with_body == True
    assert with_headers == True and with_body == True



# Generated at 2022-06-21 13:54:21.403248
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = (OUT_REQ_HEAD, OUT_RESP_BODY)

    class requests_Message:
        pass

    def check(message_type, expected):
        message = requests_Message()
        message.__class__ = message_type
        assert get_output_options(args, message) == expected

    check(requests.PreparedRequest, (True, False))
    check(requests.Response, (False, True))

    args.output_options = (OUT_REQ_HEAD | OUT_REQ_BODY, OUT_RESP_HEAD | OUT_RESP_BODY)
    check(requests.PreparedRequest, (True, True))
    check(requests.Response, (True, True))

# Generated at 2022-06-21 13:54:29.277880
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    assert f'HTTPie {httpie_version}\n' in env.stderr.buffer.getvalue()
    assert f'Requests {requests_version}\n' in env.stderr.buffer.getvalue()
    assert f'Pygments {pygments_version}\n' in env.stderr.buffer.getvalue()
    assert f'Python {sys.version}\n{sys.executable}\n' in env.stderr.buffer.getvalue()
    assert f'{platform.system()} {platform.release()}' in env.stderr.buffer.getvalue()

# Generated at 2022-06-21 13:54:33.300651
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    
    args = parser.parse_args(args=['--output-options', 'resp.headers', 'GET', 'www.google.com'])
    env = Environment()
    
    program(args=args, env=env)

# Generated at 2022-06-21 13:54:36.020760
# Unit test for function program
def test_program():
    main(['http', 'get', 'http://httpbin.org/get', '-i'])

if __name__ == '__main__':
    test_program()

# Generated at 2022-06-21 13:54:38.103020
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'+foo', '-b'], 'utf8') == ['+foo', '-b']

# Generated at 2022-06-21 13:54:40.348473
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    print_debug_info(env)
    assert env.stderr_isatty is True
    assert env.stdout_isatty is True

# Generated at 2022-06-21 13:54:41.918625
# Unit test for function program
def test_program():
    assert program(['-b "auth":123']) == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:54:52.693286
# Unit test for function print_debug_info
def test_print_debug_info():
    env=Environment()
    env.debug=1
    env.config.directory="test"
    env.stdin_encoding="utf-8"
    env.stdin_isatty=False
    env.stdin=sys.stdout
    env.stdout=sys.stdout
    env.stderr=sys.stderr
    env.is_windows=False
    env.colors=256
    env.config.default_options=['']
    env.config.max_headers=0
    env.config.max_fields_size=0
    env.config.max_body_size=0
    env.config.style=None
    env.config.style_error=None
    env.config.style_out=None
    env.config.style_out_error=None

# Generated at 2022-06-21 13:56:43.645486
# Unit test for function print_debug_info
def test_print_debug_info():
    try:
        with open("log.txt", "w") as f:
            env.stderr = f
            print_debug_info(env)
    except:
        assert False
    finally:
        if os.path.exists("log.txt"):
            os.remove("log.txt")

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 13:56:54.705732
# Unit test for function program
def test_program():
    import os
    import sys
    from httpie.cli.argtypes import KeyValueArg
    from httpie.context import Environment
    
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.client import collect_messages
    def separate():
        getattr(env.stdout, 'buffer', env.stdout).write(MESSAGE_SEPARATOR_BYTES)


# Generated at 2022-06-21 13:57:06.529382
# Unit test for function print_debug_info
def test_print_debug_info():
    class TestEnv:
        class TestStderr:
            writelines_arg = []
            def writelines(self, arg):
                self.writelines_arg = arg

            def write(self, arg):
                self.writelines_arg.append(arg)

    env = TestEnv()
    env.stderr = TestEnv.TestStderr()
    print_debug_info(env)
    assert env.stderr.writelines_arg[0].startswith('HTTPie ')
    assert env.stderr.writelines_arg[1].startswith('Requests ')
    assert env.stderr.writelines_arg[2].startswith('Pygments ')
    assert env.stderr.writelines_arg[3].startswith('Python')
    assert env.st

# Generated at 2022-06-21 13:57:12.255245
# Unit test for function print_debug_info
def test_print_debug_info():
    from tests.data import BIN_DIRECTORY
    from httpie.context import Environment
    env = Environment(stdin_isatty=True,
                      stdout_isatty=True,
                      stdout=sys.__stdout__,
                      stdin=sys.__stdin__,
                      program_name=BIN_DIRECTORY + '/http',
                      config_dir=BIN_DIRECTORY)
    print_debug_info(env)


# Generated at 2022-06-21 13:57:20.338812
# Unit test for function main
def test_main():
    from httpie.cli.argtypes import KeyValueArgType
    args = ['--form', '--json', '{"b":2}', 'example.org', 'X-Foo:bar']
    parsed_args = KeyValueArgType.parse(args)
    assert parsed_args.json is None
    assert parsed_args.data == {'b': 2}
    assert parsed_args.headers == {'X-Foo': 'bar'}
    assert parsed_args.url.url == 'http://example.org'
    args = ['example.org', 'X-Foo:bar', '--form', '--json', '{"a": 1}']
    parsed_args = KeyValueArgType.parse(args)
    assert parsed_args.json is None
    assert parsed_args.data == {'a': 1}

# Generated at 2022-06-21 13:57:28.470564
# Unit test for function main
def test_main():
    from httpie.output.streams import StdoutBytesIO, StderrBytesIO
    from httpie.context import Environment
    # Test default options
    env = Environment()
    env.config.default_options = ['--debug']
    env.stdout = StdoutBytesIO()
    env.stderr = StderrBytesIO()

    assert main(args=['http'], env=env) == ExitStatus.ERROR

    assert env.stdout.getvalue() == b''
    assert env.stderr.getvalue() == b'HTTPie 0.9.8\n\nPython 3.6.0\n/usr/local/bin/python3.6\n\n\n\n\n'

    # Test --debug --traceback
    env = Environment()
    env.stdout = StdoutBytes

# Generated at 2022-06-21 13:57:39.693192
# Unit test for function program
def test_program():
    args = argparse.Namespace(
        debug=False,
        download=False,
        download_resume=False,
        follow=False,
        headers=[],
        ignore_stdin=False,
        max_redirects=30,
        output_options=[],
        output_file=None,
        output_file_specified=False,
        quiet=False,
        timeout=None,
        verbose=0,
        verify=True,
    )
    assert program(args, Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:57:50.920856
# Unit test for function main
def test_main():
    from unittest import TestCase
    from unittest.mock import Mock, patch
    from httpie import ExitStatus

    class MockEnvironment(Environment):
        def __init__(self):
            super().__init__()
            self.stdout_isatty = False
            self.stderr = Mock()
            self.log = self.stderr
            self.log_error = self.stderr.write

    class MainTestCase(TestCase):

        @patch('httpie.cli.main.program', return_value=ExitStatus.SUCCESS)
        def test_success(self, program):
            main(args=['get', 'http://httpbin.org/status/204'],
                 env=MockEnvironment())
            assert program.called


# Generated at 2022-06-21 13:58:02.247902
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.compat import urlencode, is_py2
    from httpie.config import config_filename, Configuration
    from httpie.context import Environment
    from httpie.input import ParseError
    from tempfile import NamedTemporaryFile
    from httpie import ExitStatus
    from httpie.cli.base import get_response
    from httpie.core import main as core_main

    import pycurl
    import pickle
    import io
    import json

    def mock_core_main(args: List[str]):
        class MockExit:
            def __call__(self, args):
                return None

# Generated at 2022-06-21 13:58:04.828578
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.context import Environment
    from unittest.mock import Mock
    env = Environment()
    env.stderr = Mock()
    print_debug_info(env)



# Generated at 2022-06-21 13:59:34.851007
# Unit test for function main
def test_main():
    import sys
    # noinspection PyTypeChecker
    sys.argv = [sys.argv[0]] # drop the '-m httpie' part
    # noinspection PyTypeChecker
    main()


# Generated at 2022-06-21 13:59:44.241687
# Unit test for function print_debug_info
def test_print_debug_info():
    chunks = []
    env = Environment(
        stdin=None,
        stdin_isatty=True,
        stdout=io.StringIO(),
        stdout_isatty=True,
        stderr=io.StringIO(),
        stderr_isatty=True,
    )
    env.stderr.write = chunks.append
    print_debug_info(env=env)

    lines = ''.join(chunks).splitlines()
    lines_expected = [
        f'HTTPie {httpie_version}',
        f'Requests {requests_version}',
        f'Pygments {pygments_version}',
        f'Python {sys.version}',
        f'{platform.system()} {platform.release()}',
    ]

# Generated at 2022-06-21 13:59:47.696979
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert (
        decode_raw_args(
            args=[b'\xe4', 'a'],
            stdin_encoding='utf8',
        )
        == ['ä', 'a']
    )

# Generated at 2022-06-21 13:59:58.526829
# Unit test for function decode_raw_args

# Generated at 2022-06-21 14:00:01.048030
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr = BytesIO()
    print_debug_info(env)
    assert env.stderr.getvalue().decode('utf8').find('HTTPie ') == 0

# Generated at 2022-06-21 14:00:03.200736
# Unit test for function main
def test_main():
    try:
        sys.exit(main())
    except SystemExit as e:
        return e.code

# Generated at 2022-06-21 14:00:09.798482
# Unit test for function program
def test_program():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.definition import parser
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth

    args = parser.parse_args(['--auth-type=basic', '--auth=user:password', 'GET', 'http://httpbin.org/basic-auth/user/password'])
    env = Environment(stdin_isatty=True, stdout_isatty=True,
                      stdin=io.StringIO(),
                      stdout=io.StringIO(),
                      stderr=io.StringIO(),
                      vc_branch='test_program')
    assert program(args, env) == ExitStatus.SUCCESS



# Generated at 2022-06-21 14:00:13.210421
# Unit test for function program
def test_program():
    import sys
    program(['http', '--debug', '--json', '--body', 'GET', 'http://httpbin.org/ip'], Environment())


# Generated at 2022-06-21 14:00:24.340210
# Unit test for function print_debug_info
def test_print_debug_info():
    class stdout:
        def __init__(self):
            print_debug_info(self)

        def writelines(self,msgs):
            self.msgs = msgs

        def write(self, msg):
            self.msg = msg

    stdout = stdout()
    assert stdout.msgs == 'HTTPie 0.9.9\nRequests 2.21.0\nPygments 2.3.1\nPython 3.7.3\n/usr/bin/python3\nLinux 4.4.0-154-generic\n\n\n<httpie.context.Environment object at 0x7f0c9b974b50>\n'
    assert stdout.msg == '<httpie.context.Environment object at 0x7f0c9b974b50>\n'

# Generated at 2022-06-21 14:00:31.223866
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import unittest

    env = Environment()
    env.stderr = io.StringIO()

    print_debug_info(env)

    debug_info = env.stderr.getvalue().replace('\r', '').split('\n')
    assert debug_info[0].startswith('HTTPie ')
    assert debug_info[1].startswith('Requests ')
    assert debug_info[2].startswith('Pygments ')
    assert debug_info[3].startswith('Python ')
    assert debug_info[4].startswith('/')
    assert debug_info[5].startswith('Darwin ')
    assert debug_info[6:10] == ['', '', '', '']