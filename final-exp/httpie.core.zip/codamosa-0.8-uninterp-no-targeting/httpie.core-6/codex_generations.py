

# Generated at 2022-06-21 13:51:30.204410
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie import cli
    from httpie.context import Environment
    from httpie.status import ExitStatus
    from pytest import raises

    def run(
        args: List[str],
        env: Environment = Environment(),
    ) -> ExitStatus:
        return cli.main(args=args, env=env)

    with raises(SystemExit):
        run(['--help'])
    assert run(['https://google.com']) == ExitStatus.SUCCESS
    assert run(['--debug']) == ExitStatus.SUCCESS
    assert run(['--config-dir', parser.get_default_config_dir()]) == ExitStatus.SUCCESS



# Generated at 2022-06-21 13:51:40.747522
# Unit test for function program
def test_program():
    import argparse
    args = argparse.Namespace()

    # test sample args
    args.headers = [("Accept", "application/json")]
    args.output_file = None
    args.output_file_specified = False
    args.output_options = [b"hb"]
    args.download = False
    args.download_resume = False
    args.check_status = False
    args.follow = False
    args.quiet = False

    # test sample env
    from httpie.context import Environment
    import io

# Generated at 2022-06-21 13:51:52.659528
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(output_options=['b', 'h'])
    assert (True, True) == get_output_options(args, requests.PreparedRequest())
    args = argparse.Namespace(output_options=['b', 'h'])
    assert (True, True) == get_output_options(args, requests.Response())
    args = argparse.Namespace(output_options=['B', 'h'])
    assert (True, True) == get_output_options(args, requests.Response())
    args = argparse.Namespace(output_options=['H', 'b'])
    assert (True, True) == get_output_options(args, requests.Response())
    args = argparse.Namespace(output_options=['H', 'b'])

# Generated at 2022-06-21 13:52:03.471764
# Unit test for function decode_raw_args
def test_decode_raw_args():
    test_args = ['http', 'https://api.github.com/repos/jkbrzt/httpie/issues']
    assert decode_raw_args(test_args, 'utf-8') == test_args

    test_args = [b'http', 'https://api.github.com/repos/jkbrzt/httpie/issues']
    assert decode_raw_args(test_args, 'utf-8') == ['http', 'https://api.github.com/repos/jkbrzt/httpie/issues']

    test_args = [b'http', b'https://api.github.com/repos/jkbrzt/httpie/issues']

# Generated at 2022-06-21 13:52:12.972845
# Unit test for function get_output_options
def test_get_output_options():
    class MockArgs:
        pass
    mock_args = MockArgs()
    mock_args.output_options = [OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD]


    class MockMessage:
        pass
    
    mock_message = MockMessage()
    mock_message.kind = "request"
    
    test_with_headers, test_with_body = get_output_options(mock_args, mock_message)
    assert(test_with_headers == True)
    assert(test_with_body == True)

    mock_message.kind = "response"

    test_with_headers, test_with_body = get_output_options(mock_args, mock_message)
    assert(test_with_headers == True)
   

# Generated at 2022-06-21 13:52:16.000542
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=['abc', b'a\xe2\x82\xac'], stdin_encoding='utf-8') == ['abc', 'a€']



# Generated at 2022-06-21 13:52:22.840562
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS
    assert main(['--help']) == ExitStatus.SUCCESS
    assert main(['--version']) == ExitStatus.SUCCESS
    assert main(['--debug']) == ExitStatus.SUCCESS
    assert main(['--traceback']) == ExitStatus.SUCCESS
    assert main(['-q']) == ExitStatus.ERROR
    assert main(['-X']) == ExitStatus.ERROR
    assert main(['http://httpbin.org', '-X', 'GET']) == ExitStatus.SUCCESS
    assert main(['http://httpbin.org', '-v', '--traceback']) == ExitStatus.SUCCESS
    assert main(['-v', '--check-status', '--traceback', 'http://httpbin.org']) == Exit

# Generated at 2022-06-21 13:52:32.190959
# Unit test for function main
def test_main():
    import pytest
    from requests.exceptions import Timeout
    # Test --help
    with pytest.raises(SystemExit):
        main(['--help'])
    # Test --version
    with pytest.raises(SystemExit):
        main(['--version'])
    # Test a simple request
    with pytest.raises(requests.exceptions.ConnectionError):
        main(['GET', 'http://httpbin.org/ip'])
    # Test a non-existent command
    with pytest.raises(SystemExit):
        main(['--help', 'non-existent'])
    # Test timeout
    with pytest.raises(Timeout):
        main(['--timeout', 2, 'GET', 'http://httpbin.org/delay/3'])
    # Test too many redirects

# Generated at 2022-06-21 13:52:37.724061
# Unit test for function main
def test_main():
    # TODO: mock the command-line parsing result and run the tests in-process

    def check(args, expected):
        actual = main(args=args)
        if expected != actual:
            raise AssertionError(f'{actual} != {expected} for {args}')

    check([''], ExitStatus.SUCCESS)
    check(['--help'], ExitStatus.SUCCESS)
    check(['--version'], ExitStatus.SUCCESS)
    check(['--debug'], ExitStatus.SUCCESS)
    check(['--debug', 'HEAD', 'http://example.org'], ExitStatus.SUCCESS)
    check(['GET', 'http://example.org'], ExitStatus.SUCCESS)
    check(['GET', 'http://example.org/404'], ExitStatus.ERROR)


# Generated at 2022-06-21 13:52:49.486198
# Unit test for function program
def test_program():
    from httpie import cli
    from httpie.cli import parse_items, ParseError
    args = cli.parser.parse_args(['--debug'])
    assert program(args, Environment()) == 0
    assert program(cli.parser.parse_args(['get', 'https://httpie.org']), Environment()) == 0

    try:
        assert program(cli.parser.parse_args(['get', '--form', 'field=value', 'https://httpie.org']), Environment())
    except ParseError:
        pass

    try:
        assert program(cli.parser.parse_args(['get', '--json={"field":"value"}', 'https://httpie.org']), Environment())
    except ParseError:
        pass


# Generated at 2022-06-21 13:54:21.218156
# Unit test for function print_debug_info
def test_print_debug_info():
    '''
    单元测试函数print_debug_info()
    :return:
    '''
    class TestEnv(Environment):
        pass
    test_env = TestEnv()
    import io
    stderr = io.StringIO()
    test_env.stderr = stderr
    print_debug_info(test_env)
    assert 'HTTPie' in stderr.getvalue()

# Generated at 2022-06-21 13:54:31.021507
# Unit test for function get_output_options
def test_get_output_options():
    # Test for request type
    class MockReq:
        def __init__(self, output_options):
            self.output_options = output_options

    req = MockReq(output_options=OUT_REQ_HEAD)
    assert(get_output_options(req, req) == (True, False))
    req = MockReq(output_options=OUT_REQ_BODY)
    assert(get_output_options(req, req) == (False, True))
    req = MockReq(output_options=OUT_REQ_HEAD | OUT_REQ_BODY)
    assert(get_output_options(req, req) == (True, True))

    # Test for response type
    resp = MockReq(output_options=OUT_RESP_HEAD)

# Generated at 2022-06-21 13:54:40.728342
# Unit test for function get_output_options

# Generated at 2022-06-21 13:54:51.707873
# Unit test for function program
def test_program():
    from httpie.core import main
    import subprocess
    import difflib
    from jsondiff import diff
    from json import dumps

    #testing a simple case of the http command
    args = main(['http', 'http://httpbin.org/get'])
    assert args == ExitStatus.SUCCESS

    #testing a simple case of the http command
    args = main(['http', '--help'])
    assert args == ExitStatus.SUCCESS

    #testing a simple case of the http command
    args = main(['http', '-v'])
    assert args == ExitStatus.SUCCESS

    #testing a simple case of the http command
    args = main(['http', '--version'])
    assert args == ExitStatus.SUCCESS

    #testing a simple case of the http command

# Generated at 2022-06-21 13:55:01.850470
# Unit test for function program
def test_program():
    import os
    import requests
    import pytest

    class DemoNamespace:

        def __init__(self):
            self.headers = None
            self.output_file = None
            self.output_options = None
            self.quiet = None
            self.check_status = None
            self.follow = None

    class DemoStdErr:

        def __init__(self):
            self.content = ''

        def write(self, content):
            self.content += content
            return self.content

    def test_program_exception():
        env = Environment()
        env.config.directory = os.getcwd()
        args = DemoNamespace()
        args.headers = None
        args.check_status = False
        args.follow = False
        args.quiet = False

# Generated at 2022-06-21 13:55:11.672305
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from io import StringIO
    from httpie.compat import is_windows

    class Dummy(object):
        def __init__(self, value):
            self.value = value

        def decode(self, encoding):
            return self.value

    class DummyArgs(object):
        def __init__(self):
            self.stdin = None

    args = [
        'httpie',
        b'GET',
        'http://httpie.org/',
        b'User-Agent:Mozilla/5.0 (X11; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0',
        'Accept-Encoding:gzip',
        'Accept:application/json',
        b'Foo:Bar:=:baz'
    ]
    # On Windows

# Generated at 2022-06-21 13:55:21.126083
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR, DEFAULT_OUTPUT_OPTIONS, DEFAULT_OUTPUT_OPTIONS_UNICODE, DEFAULT_VERIFY
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.output.formatters import JSONFormatter, NoneFormatter, UnicodeJSONFormatter
    
    env = Environment()
    config = Config(config_dir=DEFAULT_CONFIG_DIR, config_path=None, config=None,
                    default_options=DEFAULT_OUTPUT_OPTIONS, default_options_unicode=DEFAULT_OUTPUT_OPTIONS_UNICODE,
                    verify=DEFAULT_VERIFY)
    
    env.config = config
    env.config.formatter = JSONFormatter()

# Generated at 2022-06-21 13:55:28.311485
# Unit test for function main
def test_main():
    def argv(*args: List[str]) -> List[Union[str, bytes]]:
        return [arg.encode() if isinstance(arg, str) else arg for arg in args]

    assert main(argv('http') + ['--debug'])
    assert main(argv('httpie') + ['--debug'])
    assert main(argv('httpie') + ['--debug', '--traceback'])



# Generated at 2022-06-21 13:55:33.663183
# Unit test for function get_output_options
def test_get_output_options():
    class Args():
        output_options = ['req_body', 'resp_body']

    class Req(): pass
    class Resp(): pass

    req = Req()
    resp = Resp()

    assert get_output_options(Args(), req) == (False, True)
    assert get_output_options(Args(), resp) == (False, True)

# Generated at 2022-06-21 13:55:35.245850
# Unit test for function print_debug_info
def test_print_debug_info():
    env1 = Environment()
    assert print_debug_info(env1) == None # check assert return None


# Generated at 2022-06-21 13:56:08.266420
# Unit test for function get_output_options
def test_get_output_options():
    import argparse

    # 1. No default options
    args1 = argparse.Namespace(output_options=[OUT_RESP_BODY])
    message1 = requests.PreparedRequest()
    pair1 = get_output_options(args=args1, message=message1)
    assert pair1 == (False, True)

    # 2. With default options
    args2 = argparse.Namespace(output_options=[OUT_REQ_HEAD])
    message2 = requests.Response()
    pair2 = get_output_options(args=args2, message=message2)
    assert pair2 == (True, False)


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 13:56:20.055887
# Unit test for function program
def test_program():
    from httpie.cli.constants import DEFAULT_TIMEOUT
    from httpie.config import Config

    def mock_collect_messages(*, args, config_dir, request_body_read_callback=None):
        return [
            requests.PreparedRequest(),
            requests.Response(),
        ]

    class mock_Downloader:
        def pre_request(self, headers):
            pass

        def start(self, initial_url, final_response):
            return None, None

        def finish(self):
            pass

        def failed(self):
            pass

    class mock_Environment:
        config = Config(directory='./')
        stdout = mock_stdout()
        stderr = mock_stderr()

        def __repr__(self):
            return 'mock_Environment'


# Generated at 2022-06-21 13:56:24.154212
# Unit test for function print_debug_info
def test_print_debug_info():
    import io

    class FakeStderr:
        def writelines(self, lines):
            return lines

        def write(self, text):
            return text

    class FakeEnv:
        def __init__(self):
            self.stderr = FakeStderr()

    env = FakeEnv()
    print_debug_info(env)



# Generated at 2022-06-21 13:56:31.772894
# Unit test for function main
def test_main():
    anl = ["http", "--debug", "--output=json", "https://httpbin.org/get"]
    expected = {'headers': {'User-Agent': 'HTTPie/1.0.2'}, 'origin': '82.144.57.61', 'url': 'https://httpbin.org/get'}
    assert main(anl) == 0
    assert main(anl).value == 0
    assert main(anl).value == 0
    assert main(anl) == 0
    assert main(anl).value == 0
    assert main(anl).value == 0


# Generated at 2022-06-21 13:56:42.901383
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(args=[b'some', 'args'], stdin_encoding='utf-8') == ['some', 'args']
    assert decode_raw_args(args=[b'some', 'args'], stdin_encoding='ascii') == ['some', 'args']
    assert decode_raw_args(args=['some', 'args'], stdin_encoding='utf-8') == ['some', 'args']
    assert decode_raw_args(args=[b'some'], stdin_encoding='ascii') == ['some']
    assert decode_raw_args(args=[b'some'], stdin_encoding='utf-8') == ['some']
    assert decode_raw_args(args=['some'], stdin_encoding='ascii') == ['some']
    assert decode

# Generated at 2022-06-21 13:56:49.313998
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment()
    env.stderr = io.StringIO()

    print_debug_info(env)
    assert env.stderr.getvalue() == "HTTPie 0.3.2\nRequests 2.18.4\nPygments 2.2.0\nPython 3.7.5\n/venv/bin/python3\nMacOS 19.0.0\n\n\n"

# Generated at 2022-06-21 13:57:01.230046
# Unit test for function main
def test_main():
    def run(args, exit_status=ExitStatus.SUCCESS, include_stderr=True):
        env = Environment(
            program_name='http',
            stdin=None,
            stdin_isatty=False,
            stdout=BytesIO(),
            stdout_isatty=False,
            stderr=BytesIO() if include_stderr else None,
            stderr_isatty=False,
        )
        assert main(args=['http'] + args, env=env) == exit_status
        out = env.stdout.getvalue().decode('utf8')
        if include_stderr:
            err = env.stderr.getvalue().decode('utf8')
        else:
            err = ''
        return out, err

    # Invalid Unicode
    #

# Generated at 2022-06-21 13:57:10.885625
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = [b'--form', b'a=b', b'c=d']
    assert decode_raw_args(args, 'utf8') == ['--form', 'a=b', 'c=d']
    assert decode_raw_args(args, 'latin1') == ['--form', 'a=b', 'c=d']
    assert decode_raw_args(args, 'ascii') == ['--form', 'a=b', 'c=d']
    assert decode_raw_args(args, 'utf-16')[0] == '--form'
    assert decode_raw_args(args, 'utf-16')[-1] == 'c=d'

# Generated at 2022-06-21 13:57:16.619707
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace(
        output_options=[
            OUT_REQ_HEAD,
            OUT_REQ_BODY,
            OUT_RESP_HEAD,
            OUT_RESP_BODY,
        ]
    )
    req = requests.PreparedRequest()
    assert get_output_options(args=args, message=req) == (True, True)
    resp = requests.Response()
    assert get_output_options(args=args, message=resp) == (True, True)

# Generated at 2022-06-21 13:57:20.407630
# Unit test for function print_debug_info
def test_print_debug_info():
    from httpie.context import Environment
    from io import StringIO
    import sys
    sys_stdout_orig = sys.stdout
    sys.stdout = StringIO()
    print_debug_info(env=Environment())
    sys.stdout = sys_stdout_orig

# Generated at 2022-06-21 13:58:27.473072
# Unit test for function main
def test_main():
    dir = os.getcwd()
    url = 'http://localhost:2970/hello'
    method = 'GET'
    args = [
        'http',
        '--debug',
        '--method',
        method,
        '--headers',
        'Content-type: application/json',
        '--json',
        '{"name":"bob"}',
        url
        ]
    output_file = "out.txt"
    env = Environment()
    env.program_name = os.path.basename(__file__)
    args = decode_raw_args(args, env.stdin_encoding)
    plugin_manager.load_installed_plugins()

    from httpie.cli.definition import parser

    if env.config.default_options:
        args = env.config.default_options + args



# Generated at 2022-06-21 13:58:34.121434
# Unit test for function get_output_options
def test_get_output_options():
    from httpie.cli.definition import parser
    args = parser.parse_args(['--form', 'foo=1', 'bar=2'])
    msg = requests.PreparedRequest()
    msg.body = b'foo=1&bar=2'
    msg.headers = {'content-type': 'application/x-www-form-urlencoded'}
    with_headers, with_body = get_output_options(args, msg)
    assert(with_headers and not with_body)

# Generated at 2022-06-21 13:58:37.891744
# Unit test for function decode_raw_args
def test_decode_raw_args():
    res = decode_raw_args(["http", "--form", "a=1", "ascii", "árvíztűrő"], "ascii")
    assert "árvíztűrő" in str(res)

# Generated at 2022-06-21 13:58:41.360193
# Unit test for function program
def test_program():
    assert program("url",{})== ExitStatus.SUCCESS
    try:
        import argparse
        from httpie.cli.definition import parser
        parser.parse_args("url",{})
    except SystemExit as e:
        assert e.code == ExitStatus.ERROR


# Generated at 2022-06-21 13:58:52.034474
# Unit test for function get_output_options
def test_get_output_options():
    test_args= argparse.Namespace()
    test_args.output_options=[]

    test_message=requests.PreparedRequest()
    assert get_output_options(args=test_args, message=test_message)==(False, False)
    test_args.output_options=['h']
    assert get_output_options(args=test_args, message=test_message)==(True, False)
    test_args.output_options=['b']
    assert get_output_options(args=test_args, message=test_message)==(False, True)
    test_args.output_options=['b','h']
    assert get_output_options(args=test_args, message=test_message)==(True, True)

    test_message=requests.Response()
    assert get

# Generated at 2022-06-21 13:58:55.072359
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    f = io.StringIO()
    e = Environment(stderr=f)
    print_debug_info(e)
    return f.getvalue()



# Generated at 2022-06-21 13:58:55.787676
# Unit test for function program
def test_program():
    return program(arguments, environment)

# Generated at 2022-06-21 13:58:57.973429
# Unit test for function program
def test_program():
    sys.argv = ['./test.py', 'httpbin.org/get']
    env = Environment()
    assert program(args=main(env=env), env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:59:03.466494
# Unit test for function main
def test_main():
    """
    This unit test for function main
    """
    args: argparse.Namespace
    env: Environment

    assert main(['https://httpbin.org/get'], env) == 0
    assert main(['https://httpbin.org/get', '--follow'], env) == 0
    assert main(['https://httpbin.org/get', '--version'], env) == 0
    assert main(['https://httpbin.org/get', '--error-overwrite'], env) == 0
    assert main(['https://httpbin.org/get', '--error-overwrite'], env) == 0
    assert main(['https://httpbin.org/post', '--form'], env) == 0

# Generated at 2022-06-21 13:59:14.800568
# Unit test for function get_output_options
def test_get_output_options():

    # Example:
    #   headers_request, body_request = get_output_options(
    #       args=args,
    #       message=requests.PreparedRequest(),
    #   )
    #   headers_response, body_response = get_output_options(
    #       args=args,
    #       message=requests.Response(),
    #   )

    class Test:
        args = argparse.Namespace()
        args.output_options = []

        # Test outputs:

        # No outputs
        '''
        False False
        False False
        '''

        # headers
        '''
        True False
        True False
        '''
        args.output_options.append(OUT_REQ_HEAD)
        args.output_options.append(OUT_RESP_HEAD)

        # headers