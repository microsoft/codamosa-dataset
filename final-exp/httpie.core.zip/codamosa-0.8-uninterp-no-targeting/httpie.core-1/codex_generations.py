

# Generated at 2022-06-21 13:51:27.403659
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import sys
    assert sys.argv == decode_raw_args(sys.argv, sys.stdin.encoding)

# Generated at 2022-06-21 13:51:30.615361
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    env = Environment()
    env.stderr = StringIO()
    print_debug_info(env)
    print(env.stderr.getvalue())

# Generated at 2022-06-21 13:51:41.037329
# Unit test for function main
def test_main():
    import os
    import pytest
    import sys

    @pytest.fixture
    def patched_print(monkeypatch):
        import builtins
        mocked = Mock()
        monkeypatch.setattr(builtins, "print", mocked)
        return mocked

    @pytest.fixture
    def patched_downloader(monkeypatch):
        mocked = Mock()
        monkeypatch.setattr("httpie.cli.main.Downloader", mocked)
        return mocked

    @pytest.fixture
    def patched_program(monkeypatch):
        mocked = Mock()
        monkeypatch.setattr("httpie.cli.main.program", mocked)
        return mocked

    # Prepare an environment with a dummy config file
    config_path = "test/config_file.json"

# Generated at 2022-06-21 13:51:53.073003
# Unit test for function program
def test_program():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.definition import parser
    args_list = ['-v', '--json', '{"message": "Hello World!"}', '--follow', '--check-status', '--timeout', '100',
                 '--form-string', 'foo=bar', '--form', 'key=value', '--form', 'baz=qux', '--form', 'Q=Q', '--output',
                 'tests\\test.txt', 'http://httpbin.org/post', '--headers', 'key1:value1', 'key2:value2']
    args_list = parser.parse_args(args_list)
    args_list.headers.append(KeyValueArg(key='Accept ', value='json'))

# Generated at 2022-06-21 13:51:53.861414
# Unit test for function print_debug_info
def test_print_debug_info():
    assert print_debug_info(env=Environment()) == None

# Generated at 2022-06-21 13:52:01.389889
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    print_debug_info(env)
    assert env.stderr.getvalue() == f'HTTPie {httpie_version}\nRequests {requests_version}\nPygments {pygments_version}\nPython {sys.version}\n{sys.executable}\n{platform.system()} {platform.release()}\n\n\nEnvironment()\n'

# Generated at 2022-06-21 13:52:03.128996
# Unit test for function program
def test_program():
    # mocker.patch('httpie.cli.definition.parser')
    assert program(
        args=argparse.Namespace(),
        env=Environment()
    ) == 0

# Generated at 2022-06-21 13:52:12.818085
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = []
    r1 = requests.PreparedRequest()
    r2 = requests.Response()
    assert get_output_options(args, r1) == (False, False)
    assert get_output_options(args, r2) == (False, False)
    args.output_options = ['all']
    assert get_output_options(args, r1) == (True, True)
    assert get_output_options(args, r2) == (True, True)
    args.output_options = ['all', 'none']
    assert get_output_options(args, r1) == (True, True)
    assert get_output_options(args, r2) == (True, True)
    args.output_options = ['none']
    assert get_

# Generated at 2022-06-21 13:52:19.995332
# Unit test for function print_debug_info
def test_print_debug_info():
    class FakeStream(io.StringIO):
        def writelines(self, lines: List[str]) -> None:
            self.write('\n'.join(lines))
    fake_env = Environment()
    fake_env.stderr = FakeStream()
    print_debug_info(env=fake_env)
    result: str = fake_env.stderr.getvalue()  # type: ignore
    assert result.count('\n') > 10
    assert 'HTTPie' in result
    assert 'Requests' in result
    assert 'Pygments' in result
    assert 'Python' in result
    assert platform.system() in result

# Generated at 2022-06-21 13:52:23.571023
# Unit test for function program
def test_program():
    err_msg = 'hello world'
    env = Environment()
    env.log_error(err_msg)
    assert env.stderr.getvalue() == err_msg.encode() + b'\n'

# Generated at 2022-06-21 13:53:40.907102
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(["a", b"\xe4"], 'ascii') == ['a', 'ä']

# Generated at 2022-06-21 13:53:45.310060
# Unit test for function main
def test_main():
    from httpie.cli.context import Environment, Config
    from httpie.cli.definition import get_parser

    env = Environment()
    args = get_parser(env).parse_args(['https://httpbin.org/get'])
    ret = program(args, env)

# Generated at 2022-06-21 13:53:48.156034
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    outstr = StringIO()
    env = Environment(stdout=outstr)
    print_debug_info(env)
    assert outstr.getvalue().startswith("HTTPie")

# Generated at 2022-06-21 13:53:54.355377
# Unit test for function print_debug_info
def test_print_debug_info():
    class EnvironmentMock():
        def __init__(self) -> None:
            self.stderr = []

        def writelines(self, lines: list) -> None:
            self.stderr += lines

    env = EnvironmentMock()
    print_debug_info(env)
    # As it's a tricky task to set up an Environment with valid objects, we only check a fixed prefix of the output.
    assert env.stderr[0] == "HTTPie "
    assert env.stderr[1] == "Requests "
    assert env.stderr[2] == "Pygments "

# Generated at 2022-06-21 13:53:56.000596
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args([b'--debug'], 'iso-8859-1') == ['--debug']

# Generated at 2022-06-21 13:54:06.562547
# Unit test for function program
def test_program():
    # Initialize class Environment
    env = Environment()
    env.stderr = sys.stderr
    env.stdout = sys.stdout
    env.stdin_encoding = 'utf8'
    # Initialize class ArgumentParser
    args = argparse.Namespace()
    args.stream = False
    args.check_status = True
    args.follow = False
    args.output_options = OUT_RESP_BODY
    args.headers = None
    #args.output_file = None
    #args.output_file_specified = False
    #args.download = False
    #args.download_resume = False
    # Initialize class Downloader
    downloader = Downloader()
    downloader.output_file = None
    downloader.progress_file = sys.stderr

# Generated at 2022-06-21 13:54:08.991159
# Unit test for function print_debug_info
def test_print_debug_info():
    env = Environment(stderr=StringIO())
    print_debug_info(env)
    assert env.stderr.getvalue().startswith('HTTPie 0.9.9\nRequests 2.')

# Generated at 2022-06-21 13:54:14.481483
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['\x80'], 'latin1') == ['\x80']
    assert decode_raw_args([b'\x80'], 'latin1') == ['\x80']
    assert decode_raw_args([b'\x80'], 'utf8') == [f'\ufffd']

# Generated at 2022-06-21 13:54:17.197377
# Unit test for function main
def test_main():
    args = ["https://www.wikipedia.org"]
    status_code = (main(args))
    assert (ExitStatus.SUCCESS == status_code)

# Generated at 2022-06-21 13:54:22.067239
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    res = main(args=['http', '--debug'])
    assert res == ExitStatus.SUCCESS
    args = parser.parse_args(args=['http'])
    res = program(args=args, env=Environment())
    assert res == ExitStatus.SUCCESS

# Generated at 2022-06-21 13:55:02.919397
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import sys
    assert decode_raw_args([b'abc'], 'utf8') == ['abc']
    assert decode_raw_args([b'\xc4\x85'], 'utf8') == ['ą']
    if sys.stdin.encoding != 'utf8':
        assert decode_raw_args([b'abc'], sys.stdin.encoding) == ['abc']
        assert decode_raw_args([b'\xc4\x85'], sys.stdin.encoding) == ['ą']



# Generated at 2022-06-21 13:55:07.579254
# Unit test for function get_output_options
def test_get_output_options():
    args = Types(output_options=[OUT_REQ_HEAD, OUT_RESP_HEAD, OUT_REQ_BODY, OUT_RESP_BODY])
    req_headers, req_body = get_output_options(args, requests.PreparedRequest())
    assert req_headers
    assert req_body
    resp_headers, resp_body = get_output_options(args, requests.Response())
    assert resp_headers
    assert resp_body



# Generated at 2022-06-21 13:55:10.785754
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from httpie.cli.definitions import UNICODE_SUPPORT

    if UNICODE_SUPPORT:
        assert decode_raw_args([b'foo', 'bar'], 'utf8') == ['foo', 'bar']

# Generated at 2022-06-21 13:55:15.072322
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = ['resp.headers', 'body']

    assert get_output_options(args, requests.PreparedRequest()) == (False, True)
    assert get_output_options(args, requests.Response()) == (True, True)

# Generated at 2022-06-21 13:55:22.652156
# Unit test for function print_debug_info
def test_print_debug_info():
    debug_info = ""
    env = Environment()

    # redirect the output to a string.
    sys.stdout = io.StringIO()
    print_debug_info(env)
    debug_info = sys.stdout.getvalue()
    # restore print
    sys.stdout = sys.__stdout__

    # assert if debug_info contains the necessary info
    assert(debug_info.find("HTTPie") != -1)
    assert(debug_info.find("Requests") != -1)
    assert(debug_info.find("Pygments") != -1)
    assert(debug_info.find("Python") != -1)
    assert(debug_info.find("OS") != -1)
    assert(debug_info.find("CPU") != -1)

# Generated at 2022-06-21 13:55:27.432844
# Unit test for function decode_raw_args
def test_decode_raw_args():
    decoded_args = decode_raw_args(['abc',b'123',b'\xe4\xb8\xad\xe6\x96\x87'], stdin_encoding='utf-8')
    assert decoded_args == ['abc', '123', '中文']

# Generated at 2022-06-21 13:55:36.048639
# Unit test for function print_debug_info
def test_print_debug_info():
    from StringIO import StringIO
    from httpie.cli.context import Context
    from httpie.config import Config, DEFAULT_CONFIG_DIR

    env = Environment()
    env.config = Config(
        directory=DEFAULT_CONFIG_DIR,
        env=env,
    )
    env.config.load()
    env.stdout = StringIO()
    env.stderr = StringIO()

    print_debug_info(env)

    output = env.stdout.getvalue().splitlines()
    assert len(output) > 0
    assert output[0] == 'HTTPie %s' % httpie_version

# Generated at 2022-06-21 13:55:44.760135
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY]
    body = 'test'
    request = requests.PreparedRequest()
    request.body = body
    request.headers = {"test_1": "test_1", "test_2": "test_2"}
    response = requests.Response()
    response.status_code = 200
    response._content = bytes(body, encoding='utf-8')
    response.content = bytes(body, encoding='utf-8')

    with_headers, with_body = get_output_options(args, request)
    assert with_headers is True
    assert with_body is True

    with_headers, with_body = get_output_options(args, response)
    assert with_headers is False

# Generated at 2022-06-21 13:55:47.721336
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = ['gzip', 'form']

    assert get_output_options(args, requests.PreparedRequest()) == (True, True)
    assert get_output_options(args, requests.Response()) == (True, True)

# Generated at 2022-06-21 13:55:50.592065
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert ['foo', 'arg', 'baz'] == decode_raw_args(['foo', b'arg', 'baz'], 'ascii')

# Generated at 2022-06-21 13:57:09.246078
# Unit test for function program
def test_program():
    import os
    import sys
    import argparse
    from httpie.context import Environment
    from httpie.input import parse_items
    #try:
    #    print("import config")
    #    import httpie.plugins.config
    #except Exception as e:
    #    print("import config error")
    #    print(e)
    #    return
    #try:
    #    print("import auth")
    #    import httpie.plugins.auth
    #except Exception as e:
    #    print("import auth error")
    #    print(e)
    #    return
    #try:
    #    print("import download")
    #    import httpie.plugins.download
    #except Exception as e:
    #    print("import download error")
    #    print(e)
    #   

# Generated at 2022-06-21 13:57:18.381012
# Unit test for function print_debug_info
def test_print_debug_info():
    import io
    import sys
    import unittest.mock

    env = Environment(
        stdin=unittest.mock.Mock(spec=io.IOBase),
        stdin_isatty=False,
        stdout=unittest.mock.Mock(spec=io.IOBase),
        stdout_isatty=False,
        stderr=unittest.mock.Mock(spec=io.IOBase),
        stderr_isatty=False,
    )
    print_debug_info(env)

# Generated at 2022-06-21 13:57:27.162977
# Unit test for function print_debug_info
def test_print_debug_info():
    class DummyStderr:
        def __init__(self):
            self.lines = []

        def write(self, line):
            self.lines.append(line)

        def writelines(self, lines):
            self.lines.extend(lines)

        def write(self, line):
            self.lines.append(line)

    env = Environment()
    env.stderr = DummyStderr()
    print_debug_info(env)

    assert env.stderr.lines[0].startswith('HTTPie 1.0')
    assert env.stderr.lines[1].startswith('Requests ')
    assert env.stderr.lines[2].startswith('Pygments ')
    assert env.stderr.lines[3].startswith('Python ')


# Generated at 2022-06-21 13:57:33.387499
# Unit test for function print_debug_info
def test_print_debug_info():
    from io import StringIO
    from httpie.context import Environment
    env = Environment()
    env.stderr = StringIO()
    print_debug_info(env)
    result = env.stderr.getvalue()
    assert 'HTTPie' in result, result
    assert 'Requests' in result, result
    assert 'Pygments' in result, result
    assert 'Python' in result, result
    assert str(type(env)) in result, result


# Generated at 2022-06-21 13:57:39.693273
# Unit test for function get_output_options
def test_get_output_options():
    assert get_output_options(
        args=argparse.Namespace(output_options=['Body', 'Head']),
        message=requests.PreparedRequest()) == (True, True)
    assert get_output_options(
        args=argparse.Namespace(output_options=['Body', 'Head']),
        message=requests.Response()) == (True, True)

# Generated at 2022-06-21 13:57:50.919794
# Unit test for function main
def test_main():
    from httpie.cli.parser import parser_defaults_dict
    from httpie.context import Environment
    from tests.mocking import MockEnvironment
    env = Environment()
    args = parser_defaults_dict()
    args.update({'form': 'data'})
    args.update({'headers': ['User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36']})
    args.update({'headers': ['Cookie: _ga=GA1.1.1057631743.1563312496; _gid=GA1.1.1465698291.1563312496; _fbp=fb.1.1563312496637.1786137586']})


# Generated at 2022-06-21 13:58:02.247861
# Unit test for function get_output_options
def test_get_output_options():
    import requests
    class args:
        output_options = [OUT_REQ_HEAD, OUT_RESP_HEAD]
    assert(get_output_options(args = args, message = requests.Response()) == (True, False))
    assert(get_output_options(args = args, message = requests.PreparedRequest()) == (True, False))
    args.output_options = [OUT_REQ_BODY, OUT_RESP_BODY]
    assert(get_output_options(args = args, message = requests.Response()) == (False, True))
    assert(get_output_options(args = args, message = requests.PreparedRequest()) == (False, True))
    args.output_options = [OUT_REQ_BODY, OUT_RESP_HEAD]

# Generated at 2022-06-21 13:58:12.140075
# Unit test for function program
def test_program():
    from click.testing import CliRunner
    program_output = []
    output_options = None

    def get_write_func():
        global program_output
        return program_output.append

    def _program(args: argparse.Namespace, env: Environment) -> ExitStatus:
        global output_options
        output_options = args.output_options
        return main(args, env)

    env = Environment(
        stdin=io.BytesIO(),
        stdin_isatty=False,
        stdout=io.StringIO(),
        stdout_isatty=True,
        stderr=io.StringIO(),
        stderr_isatty=True,
        color=lambda _: (True, False, False),
    )

    runner = CliRunner()

# Generated at 2022-06-21 13:58:15.198151
# Unit test for function decode_raw_args
def test_decode_raw_args():
    args = [b'some', b'bytes', b'args']
    stdin_encoding = 'ascii'
    expected_result = ['some', 'bytes', 'args']
    assert decode_raw_args(args, stdin_encoding) == expected_result

# Generated at 2022-06-21 13:58:25.027692
# Unit test for function decode_raw_args
def test_decode_raw_args():
    assert decode_raw_args(['a'], 'utf-8') == ['a']
    assert decode_raw_args(['a', 'b'], 'utf-8') == ['a', 'b']
    assert decode_raw_args([b'a'], 'utf-8') == ['a']
    assert decode_raw_args([b'a', b'b'], 'utf-8') == ['a', 'b']
    assert decode_raw_args([b'a', 'b'], 'utf-8') == ['a', 'b']


# Generated at 2022-06-21 13:59:38.072395
# Unit test for function program
def test_program():
    args = argparse.Namespace(output_options={'verbose'})
    class io:
        def __init__(self):
            self.buffer = bytes()
        def write(self, write):
            self.buffer+=write
    env = Environment()
    env.stdout=io()
    program(args, env)

# Generated at 2022-06-21 13:59:46.054332
# Unit test for function print_debug_info
def test_print_debug_info():
    class StubStderr(io.BytesIO):
        def writelines(self, lines: List[str]):
            for line in lines:
                self.write(line.encode())

    stderr_io = StubStderr()
    env = Environment(stderr=stderr_io)
    print_debug_info(env=env)
    stderr_io.seek(0)
    output_str = stderr_io.read().decode()
    assert 'HTTPie ' in output_str
    assert 'Requests ' in output_str
    assert 'Pygments ' in output_str
    assert 'Python ' in output_str
    assert f'{platform.system()} {platform.release()}' in output_str
    assert '\n\n' in output_str

# Generated at 2022-06-21 13:59:56.634815
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    env = Environment()
    args.headers = {}
    args.download = False
    args.output_file = 0
    args.output_file_specified = False
    args.output_options = ['resp.body']
    args.method = 'GET'
    args.ignore_stdin = False
    args.check_status = False
    args.output_options = []
    args.quiet = False
    args.url = 'https://httpbin.org/get'
    args.timeout = 30
    args.follow = False
    args.max_redirects = 3
    args.check_status = True
    args.download_resume = False
    args.session = requests.sessions.Session()
    args.auth = None
    assert program(args, env) == 1



# Generated at 2022-06-21 14:00:06.047058
# Unit test for function decode_raw_args
def test_decode_raw_args():
    from httpie.context import Environment
    from httpie.compat import is_windows
    import locale
    import sys

    def get_stdin_encoding(locale_encoding=locale.getpreferredencoding(False)):
        """
        On Windows, sys.stdin.encoding is cp1252
        while the console window's encoding is usually cp850.

        """
        if is_windows:
            global_encoding = sys.getfilesystemencoding()
            # Note: We assume the encoding has been set explicitly,
            # because the Windows console doesn't export its encoding.
            if global_encoding != locale_encoding:
                return global_encoding
        return locale_encoding

    env = Environment()
    if is_windows:
        env.set('LANG', 'en_GB.UTF-8')

# Generated at 2022-06-21 14:00:17.457194
# Unit test for function decode_raw_args
def test_decode_raw_args():
    def assert_args_decoded(args: List[Union[str, bytes]], stdin_encoding: str, expected_args: List[str]):
        assert decode_raw_args(args=args, stdin_encoding=stdin_encoding) == expected_args

    assert_args_decoded(
        args=['--form', 'name=value'],
        stdin_encoding='utf-8',
        expected_args=['--form', 'name=value'],
    )
    assert_args_decoded(
        args=['--form', b'name=value'],
        stdin_encoding='utf-8',
        expected_args=['--form', 'name=value'],
    )

# Generated at 2022-06-21 14:00:24.022458
# Unit test for function decode_raw_args
def test_decode_raw_args():
    import pytest
    assert decode_raw_args([b'\xa3', '\xa3'], 'utf-8') == ['£', '£']
    assert decode_raw_args([b'\xa3', '\xa3'], 'ascii') == ['¤', '¤']
    with pytest.raises(UnicodeDecodeError):
        decode_raw_args([b'\xa3', '\xa3'], 'utf-16')

# Generated at 2022-06-21 14:00:31.066647
# Unit test for function program
def test_program():
    from httpie import ExitStatus
    from httpie.cli.definition import parser
    from httpie.config import Config
    from httpie.context import Environment

    def mock_collect_messages(args, config_dir, request_body_read_callback):
        # Fake request msg
        request = requests.PreparedRequest()
        request.url = "http://mocked.example"
        request.method = 'GET'
        request.headers = {"mock_header": "mock_header_value"}
        request.body = 'mock_request_body'
        yield request

        # Fake response msg
        response = requests.Response()
        response.status_code = 200
        response.request = request
        response.headers = {"mock_header": "mock_response_header_value"}