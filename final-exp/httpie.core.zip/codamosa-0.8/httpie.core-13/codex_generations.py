

# Generated at 2022-06-11 23:23:04.521875
# Unit test for function main
def test_main():
    def get_main_parser():
        parser = argparse.ArgumentParser(add_help=False)
        parser.add_argument('--help', dest='help', action='store_true')
        parser.add_argument('url', default='www.example.com')
        return parser
    """
    Test main function
    """
    parser = get_main_parser()
    args, rest = parser.parse_known_args(['--help'])
    exit_status = main(['http', '--help'])
    assert exit_status == ExitStatus.SUCCESS

    exit_status = main(['http', '-h', '-v', 'www.google.com'])
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:23:10.402861
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    test_env = Environment()
    test_env.config.directory = '.'
    test_env.config.load()
    print(main(args=['--debug'], env=test_env))
    print(main(args=['--debug', 'https://httpie.org'], env=test_env))
    print(main(args=['https://httpie.org'], env=test_env))

test_main()

# Generated at 2022-06-11 23:23:14.728880
# Unit test for function main
def test_main():
    assert main() == 0
    import subprocess
    result = subprocess.run([sys.executable, "httpie.py", "GET", "google.com", "-v", "--debug"], stdout=subprocess.PIPE)
    assert result.returncode == 0

# Generated at 2022-06-11 23:23:25.274088
# Unit test for function program
def test_program():
    import collections
    import timeit
    #import time

    import requests as requests_lib
    #import requests
    import httpie as httpie_lib
    import httpie.cli.args as args_lib
    import httpie.cli.parser as parser_lib
    import httpie.cli.constants as constants_lib

    #import httpie.output.writers.formatters.management as management_lib

# Generated at 2022-06-11 23:23:36.081335
# Unit test for function program
def test_program():
    from io import StringIO
    from httpie.config import Environment

    args_obj = argparse.Namespace(output_options=['resp.body'], follow=False, output_file='stdout',
                                  output_file_specified=False)
    env_obj = Environment(stdin=StringIO('plain text'), stdin_isatty=True, stdout=StringIO(),
                          stdout_isatty=False, stderr=StringIO(), stderr_isatty=False,
                          color_mode='auto', config_dir=None, config_file=None)
    exit_status = program(args_obj, env_obj)
    assert exit_status == ExitStatus.ERROR
    assert env_obj.stdout.getvalue() == 'plain text'
    assert env_obj.stderr.getvalue

# Generated at 2022-06-11 23:23:47.881124
# Unit test for function program
def test_program():
    import argparse

    env = Environment(
        stdin=None,
        stdout=None,
        stderr=None,
        stdin_encoding=None,
        stdin_isatty=False,
        stdout_isatty=False,
        stdout_supports_ansi=False,
        stdout_supports_colors=False,
        stdout_encoding=None,
        stdout_raw=False,
        stdout_line_buffering=True,
        stderr_encoding=None,
        stderr_raw=False,
        config=None,
        is_windows=False,
        is_linux=False,
    )

# Generated at 2022-06-11 23:23:49.114093
# Unit test for function program
def test_program():
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-11 23:23:53.532568
# Unit test for function program
def test_program():
    args = [
        '--timeout=3',
        '--max-redirects=10',
        '-v',
        'httpbin.org/status/200'
    ]
    env = Environment()
    code = main(args, env)
    assert code == 0

# Generated at 2022-06-11 23:23:58.736937
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

    args = parser.parse_args(args=['http', '--debug', '--download', 'my_path'])
    #env = Environment()
    #program(args, env)


if __name__ == '__main__':
    if sys.argv[1:2] == ['--test']:
        test_program()
    else:
        main()

# Generated at 2022-06-11 23:24:10.496679
# Unit test for function main
def test_main():
    import sys
    import unittest
    import mock

    # https://docs.python.org/3/library/unittest.mock.html#mock-namespace-api
    class ArgvTest(unittest.TestCase):
        @mock.patch('httpie.main.main')
        def test_main(self, main_mock):
            assert main_mock
            import httpie.main
            assert httpie.main.main is main_mock

            # TODO: Figure out why setting a function's __name__ is not enough
            # for it to be properly imported by `import httpie`
            # (it’s imported as httpie.<module>.<function>)
            #
            # httpie.main.main.__name__ = 'httpie.core.main.main'
            # import http

# Generated at 2022-06-11 23:24:42.559549
# Unit test for function main
def test_main():
    """
    Test main() function.
    """
    # TODO: Complete test_main function

    # TODO: Add test cases

# Generated at 2022-06-11 23:24:52.004322
# Unit test for function program
def test_program():
    import pytest
    from httpie import ExitStatus
    from httpie.cli import env, args

    def assert_program(
        input_args,
        expected_args=None,
        output_args=None,
        exit_status=ExitStatus.SUCCESS
    ):
        if output_args:
            output_args = [arg.split('=') for arg in output_args]
        parsed_args = args.parser.parse_args(
            input_args,
        )
        if expected_args:
            expected_args = [arg.split('=') for arg in expected_args]
        else:
            expected_args = []

# Generated at 2022-06-11 23:24:56.384621
# Unit test for function program
def test_program():
    assert program(env=Environment(), args=argparse.Namespace(method='GET', url='httpbin.org')) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:24:57.524386
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-11 23:24:58.133922
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 23:25:05.116857
# Unit test for function main
def test_main():
    import tempfile

    from httpie import ExitStatus
    from httpie.compat import is_windows
    from httpie.context import Environment

    env = Environment()
    env.stdin_isatty = True
    env.stdout_isatty = True
    env.stderr_isatty = False

    # TODO: unit test that sys.stdout is not sys.stderr.

    # TODO: remove the need for this special case.
    if not is_windows:
        env.stdout_encoding = 'UTF-8'
        env.stderr_encoding = 'UTF-8'

    # TODO: properly test with --output

    # Check success on a simple request.
    rc = main(args=['get', 'https://httpbin.org/'], env=env)

# Generated at 2022-06-11 23:25:13.382120
# Unit test for function program
def test_program():
    def test_env(**kwargs):
        output_file = io.StringIO()
        class TestEnv:
            log_error = print
            config = TestConfig()
            stdout = TestFile(outfile=output_file)
            stdout_isatty = True
            def __init__(self, **kwargs):
                self.__dict__.update(kwargs)
        TestEnv.config.__dict__.update(kwargs)
        return TestEnv()
    env = test_env(default_options=['--verbose', '--print=HB'])
    args = parser.parse_args(['httpbin.org/headers'], env=env)
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:25:23.817479
# Unit test for function program
def test_program():
    class namespace:
        program_name = "httpie"
        config_dir = ".httpie"
        def __init__(self, url, method, headers, output_options, check_status, output_file, output_file_specified, timeout, follow, max_redirects, download, quiet, download_resume):
            self.url = url
            self.method = method
            self.headers = headers
            self.output_options = output_options
            self.check_status = check_status
            self.output_file = output_file
            self.output_file_specified= output_file_specified
            self.timeout = timeout
            self.follow = follow
            self.max_redirects = max_redirects
            self.download = download
            self.quiet = quiet
            self.download_resume = download_

# Generated at 2022-06-11 23:25:31.507511
# Unit test for function program
def test_program():
    import tempfile
    import unittest
    import mock

    #from httpie.cli.constants import OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_BODY, OUT_RESP_HEAD

    class programTestCase(unittest.TestCase):
        # Process messages as they’re generated
        def test_program(self):
            class myRequest:
                def __init__(self, payload):
                    self.payload = payload

                def prep_body(self):
                    pass

                def prepare(self):
                    return self.payload

            class myResponse:
                def __init__(self, payload):
                    self.payload = payload

            mocked_env = mock.Mock()
            mocked_args = mock.Mock()
            mocked_args.quiet = False
            mocked

# Generated at 2022-06-11 23:25:40.979717
# Unit test for function program
def test_program():
    class options_object(object):
        def __init__(self):
            self.headers = []
            self.output_options = []
            self.output_file = None
            self.output_file_specified = False
            self.check_status = False
            self.download = False
            self.download_resume = False
            self.follow = False
            self.timeout = 60
            self.max_redirects = 10
            self.quiet = False

    options = options_object()

    def test_program(url):
        options.output_options = ['all']
        class environment_object(object):
            def __init__(self):
                self.stdout = sys.stdout
                self.stderr = sys.stderr
                self.stdin = sys.stdin

# Generated at 2022-06-11 23:26:25.724119
# Unit test for function program
def test_program():
    from httpie import ExitStatus
    from httpie.cli.constants import OUT_REQ_HEAD, OUT_REQ_BODY
    from httpie.config import Config
    from httpie.status import http_status_to_exit_status
    from httpie.environment import Environment
    from httpie.cli.parser import create_parser
    request_body_read_callback = None
    args = create_parser().parse_args([
        'http', 'github.com',
        '--output=/dev/null',
        '--check-status',
    ])
    env = Environment(config=Config())
    exit_status = program(args=args, env=env)
    assert exit_status == http_status_to_exit_status(http_status=200)

# Generated at 2022-06-11 23:26:36.201145
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace(
        arg = "sample-command"
    )
    try:
        if args == ['--debug']:
            return ExitStatus.SUCCESS
    except SystemExit as e:
        if e.code != ExitStatus.SUCCESS:
            env.stderr.write('\n')
            exit_status = ExitStatus.ERROR
    else:
        try:
            exit_status = program(
                args=args,
                env=env,
            )
        except KeyboardInterrupt:
            env.stderr.write('\n')
            exit_status = ExitStatus.ERROR_CTRL_C
        except SystemExit as e:
            if e.code != ExitStatus.SUCCESS:
                env.stderr.write('\n')
                exit

# Generated at 2022-06-11 23:26:38.309412
# Unit test for function main
def test_main():
    """
    Run pytest tests
    """
    import pytest
    assert pytest.main(["httpie"]) == 0

# Generated at 2022-06-11 23:26:48.421355
# Unit test for function program
def test_program():
    """
    Unit test for function program

    """
    import io,sys,json

    class TestEnvironment(Environment):
        @property
        def stdout_isatty(self):
            return True
    env = TestEnvironment()
    env.stdout = io.StringIO()
    sys.argv = ['']
    args = ['https://httpbin.org/post', '-s', '-F', 'a=1', '-F', 'a=2', '-F', 'a=3']
    program(args=parser.parse_args(args=args, env=env), env=env)
    response = json.loads(env.stdout.getvalue())
    assert response['form']['a'] == ['1', '2', '3']

# Generated at 2022-06-11 23:26:57.581150
# Unit test for function program
def test_program():
    class FakeEnvironment():
        def __init__(self):
            self.stderr = sys.stderr
            self.stdout = sys.stdout
            self.stdout_isatty = False
        def log_error(self, msg, level='error'):
            print(f'{level}:{msg}')

    class FakeRequest():
        def __init__(self, headers, body, method="GET"):
            self.headers = headers
            self.body = body
            self.method = method
            self.url = "foo"
        def __repr__(self):
            return f'<FakeRequest url:{self.url} method:{self.method}>'

    class FakeResponse():
        def __init__(self, headers, body):
            self.headers = headers
            self.body = body


# Generated at 2022-06-11 23:26:58.864773
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:27:06.855437
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.output.streams import get_stderr

    args = ['http', 'httpbin.org', '--debug']
    env = Environment(config_dir=DEFAULT_CONFIG_DIR, stdin=None, stdout=None, stderr=get_stderr())
    main(args=args, env=env)


if __name__ == '__main__':
    main(sys.argv)

# Generated at 2022-06-11 23:27:08.990828
# Unit test for function program
def test_program():
    args = ['http', '--headers', 'httpbin.org']
    env = Environment()
    main(args=args, env=env)

# Generated at 2022-06-11 23:27:16.982729
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie import ExitStatus
    from requests import Response

    args = parser.parse_args([
        #'--form',
        '--body',
        #'--print=BhH',
        'http://httpbin.org/anything'
    ])
    response = Response()
    response.status_code = 500
    exit_status = program(args=args, env=Environment())
    assert (exit_status == ExitStatus.ERROR)
    exit_status = program(args=args, env=Environment())
    assert (exit_status == ExitStatus.SUCCESS)

# Run unit test
#test_program()

# Generated at 2022-06-11 23:27:20.509366
# Unit test for function program
def test_program():
    from httpie import exit_status
    from httpie.cli.definition import parser as cli_parser
    args = cli_parser.parse_args('https://httpbin.org/get'.split())
    assert program(args, Environment()) == exit_status.SUCCESS

# Generated at 2022-06-11 23:30:11.677746
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    print(main())

# Generated at 2022-06-11 23:30:21.660940
# Unit test for function program
def test_program():

    from httpie.cli.definition import parser, parse_args, add_parser_output_options
    from httpie.input import FileBytesRawJSONRenderer

    args = parser.parse_args([
        '--no-traceback',
        '--check-status',
        '--download',
        '--max-redirects=5',
        '--timeout=1',
        'GET', 'https://httpie.org/',
        'User-Agent:HTTPie/1.0',
        'Accept-Encoding:gzip, deflate',
        'Accept:*/*',
    ])

    assert isinstance(args, argparse.Namespace)


if __name__ == '__main__':

    # Unit test for function main
    exit(main(['-d', '/path/to/file']))

# Generated at 2022-06-11 23:30:30.777594
# Unit test for function main
def test_main():
    from httpie.cli.common import print_output
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import builtin
    from httpie.status import ExitStatus
    from requests.structures import CaseInsensitiveDict
    from pygments.lexers import HttpLexer
    from unittest.mock import MagicMock, patch
    from httpie.cli.parser import Parser
    from httpie.cli.definition import parser

    builtin.load_plugins()

    class MockArgs:
        def __init__(self, **kwargs):
            self.__dict__ = kwargs

    class MockResponse:
        def __init__(self, status_code, headers=None, content=None):
            self.status_code = status_code
            self.headers

# Generated at 2022-06-11 23:30:39.142887
# Unit test for function program
def test_program():
    from httpie import ExitStatus

    assert program.__name__ == 'program'

    def program_arg(args, env=Environment()):
        # type: (List[str], Environment) -> ExitStatus
        return program(args=parser.parse_args(args=args, env=env), env=env)

    test_cases = [
        ([], ExitStatus.SUCCESS),
        (['--debug'], ExitStatus.SUCCESS),
        (['--version'], ExitStatus.SUCCESS),
        (['--help'], ExitStatus.SUCCESS),
        (['--help', 'get'], ExitStatus.SUCCESS),
    ]

    for args, expected_result in test_cases:
        assert program_arg(args, env=Environment()) == expected_result

# Generated at 2022-06-11 23:30:45.958372
# Unit test for function program
def test_program():
    from httpie.cli.context import FakeStdin, FakeStdout, FakeStderr
    from httpie.cli.definition import parser
    from httpie.requests_auth import BasicAuth
    stdin = FakeStdin(b'test=test')
    stdout = FakeStdout()
    stderr = FakeStderr()
    args = parser.parse_args(
        args=['-v', 'https://httpbin.org/get'],
        env=Environment(
            stdin=stdin,
            stdout=stdout,
            stderr=stderr,
            is_windows=(platform.system() == 'Windows')))
    program(args=args, env=Environment())
    assert stdout.content.decode() == 'test=test'

# Generated at 2022-06-11 23:30:48.686224
# Unit test for function program
def test_program():
    import httpie.cli.args

    print('test function program')
    print(program(httpie.cli.args.parser.parse_args(['--help'])))

# Generated at 2022-06-11 23:30:49.522827
# Unit test for function program
def test_program():
    pass


# Generated at 2022-06-11 23:30:50.543118
# Unit test for function program
def test_program():
    env = Environment()
    assert program(args=['https://httpbin.org/get'], env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:30:54.880986
# Unit test for function main
def test_main():
    from httpie.context import Environment
    from httpie.cli.definition import parser
    from httpie.cli.parser import get_parser
    from httpie import core

    def reset_parser():
        parser.env = Environment()
        parser.parser = get_parser()
        core.request_items = []
        core.auth = None
        core.verify = True
        core.cert = None

    args = ['https://httpbin.org']
    assert main(args, env=Environment()) == ExitStatus.SUCCESS
    reset_parser()

    args = ['--json', '{"hello": "world"}', 'https://httpbin.org/post']
    assert main(args, env=Environment()) == ExitStatus.SUCCESS
    reset_parser()


# Generated at 2022-06-11 23:31:03.561762
# Unit test for function program
def test_program():
    from httpie.output.defaults import DEFAULT_OPTIONS
    from httpie.cli import argtypes
    from httpie.cli.parser import get_parser, validate_config_dir
    parser = get_parser()
    args = parser.parse_args(
        args=[
            '--follow',
            '--check-status',
            '-o', '/tmp/httpie_out',
            '-v',
            'http://www.columbia.edu/~fdc/sample.pdf'
        ]
    )
    validate_config_dir(args)
    env = Environment()
    args.output_options = DEFAULT_OPTIONS
    args.headers = argtypes.KeyValueArgType()(args.headers)
    program(args, env)
