

# Generated at 2022-06-11 23:23:18.572498
# Unit test for function main
def test_main():
    assert main(['--debug']) == ExitStatus.SUCCESS
    assert main(['--debug'], Environment()) == ExitStatus.SUCCESS
    assert main() == ExitStatus.SUCCESS
    assert main([]) == ExitStatus.SUCCESS
    assert main(['GET', 'https://httpbin.org']) == ExitStatus.SUCCESS
    assert main(['GET', 'https://httpbin.org', '--json']) == ExitStatus.SUCCESS
    assert main(['GET', 'https://httpbin.org', '--pretty', 'all']) == ExitStatus.SUCCESS
    assert main(['GET', 'https://httpbin.org', '--pretty', 'all', '--json']) == ExitStatus.SUCCESS
    assert main(['GET', 'https://google.com']) == ExitStatus.ERROR

# Generated at 2022-06-11 23:23:30.294646
# Unit test for function main
def test_main():
    from io import BytesIO
    from io import TextIOWrapper
    from io import UnsupportedOperation
    from tempfile import mkdtemp
    from tempfile import TemporaryDirectory
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from urllib.parse import ParseResult
    from urllib.parse import urlsplit
    assert main(['http', 'http://localhost:1']) == ExitStatus.ERROR_UNREACHABLE
    post_output = b"""POST /post HTTP/1.1
Transfer-Encoding: chunked

5
Hello
0

"""
    with patch('builtins.open', create=True) as mock_open:
        handler = mock_open.return_value.__enter__.return_value

# Generated at 2022-06-11 23:23:38.298939
# Unit test for function program
def test_program():
    args = parser.parse_args(
        args=[

        ],
        env=Environment()
    )
    if args.download:
        args.follow = True  # --download implies --follow.
        downloader = Downloader(output_file=args.download_output_file, progress_file=env.stderr, resume=args.download_resume)
        downloader.pre_request(args.headers)
    messages = collect_messages(args=args, config_dir=env.config.directory,
                                request_body_read_callback=request_body_read_callback)

    for message in messages:
        is_request = isinstance(message, requests.PreparedRequest)
        with_headers, with_body = get_output_options(args=args, message=message)
        do_write_body = with_

# Generated at 2022-06-11 23:23:43.117666
# Unit test for function program
def test_program():
    from httpie.cli.parser import parser as arg_parser
    
    args = arg_parser.parse_args('get httpbin.org/get'.split())
    env = Environment()
    ret = program(args, env)
    print(repr(ret))


# Generated at 2022-06-11 23:23:48.286152
# Unit test for function main
def test_main():
    # Need to encode the string because it's fed to sys.argv unmodified
    arg = "https://www.mashable.com/2018/07/29/mute-user-twitter-conversation/"
    arg = arg.encode('utf-8')
    env = Environment()
    # Test if the program runs without error
    main([arg] , env)



# Generated at 2022-06-11 23:23:58.777803
# Unit test for function main
def test_main():
    def program_mock(args: argparse.Namespace, env: Environment):
        return ExitStatus.ERROR

    from httpie.cli.definition import parser

    args = [
        '--method', 'POST',
        '--form', 'key=val',
        '--form', 'other=val',
        '--json', 'key=val',
        '--json', 'other=val',
        'http://httpbin.org/anything',
    ]

    # Fix for Python < 3.6
    # https://github.com/psf/black/issues/265#issuecomment-503645239
    if not hasattr(sys, 'argv'):
        sys.argv = ['http', '--debug']
    parsed_args = parser.parse_args(args=args)
    parsed_args.program = program_

# Generated at 2022-06-11 23:24:10.547921
# Unit test for function main
def test_main():
    import shutil
    import sys
    import tempfile
    #from httpie.cli.constants import UNICODE_SUPPORT

    class MockStdin:

        def isatty(self):
            return True

        def close(self):
            return True

    class MockStdout:

        def isatty(self):
            return True

        def close(self):
            return True

    class MockStderr:
        def write(self, text):
            # print(text)
            return True

        def flush(self):
            return True

    class MockArgumentParser(argparse.ArgumentParser):
        def __init__(self, *args, **kwargs):
            super(MockArgumentParser, self).__init__(*args, **kwargs)


# Generated at 2022-06-11 23:24:12.724115
# Unit test for function main
def test_main():
    assert main(['httpie.py', '-v']) == 0

# Generated at 2022-06-11 23:24:13.503876
# Unit test for function program
def test_program():
    program()

# Generated at 2022-06-11 23:24:21.252179
# Unit test for function program
def test_program():
    class args:
        redirect = False
        download = False
        args = ["post", "http://localhost:5000/test"]
        method = "POST"
        output_options = ['all']
        output_options_specified = True
        quiet = False
        check_status = False
        download_resume = False
        output_file = 1
        output_file_specified = False

    class env:
        stdout = 1
        stderr = 1

        class config:
            default_options = []
            directory = "."

        def log_error(self, a, b):
            pass

    assert program(args, env) == 0

# Generated at 2022-06-11 23:25:23.027187
# Unit test for function main
def test_main():
	exit_code = main()
	assert exit_code == 0

# Generated at 2022-06-11 23:25:30.999961
# Unit test for function main
def test_main():
    import argparse
    import doctest
    doctest.testmod()
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('-f', '--file')
    parser.add_argument('-b', '--bar')
    parser.add_argument('-f', action='store_true')
    try:
        import getopt
    except ImportError:
        parser.add_argument('-g', action='store_true')
    else:
        parser.add_argument('-g')
    parser.add_argument('--version', action='version')
    parser.add_argument('-m', '--method')
    parser.add_argument('-B', '--data', help='The data to be sent to the server')

# Generated at 2022-06-11 23:25:32.329266
# Unit test for function main
def test_main():
    assert main(args=['httpie', '--help']) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:25:36.951990
# Unit test for function main
def test_main():
    from httpie.cli import env
    from httpie.cli.definition import parser

    parsed_args = parser.parse_args(
        args=['--download'],
        env=env.Environment(),
    )
    exit_status = program(
        args=parsed_args,
        env=env.Environment(),
    )
    print(exit_status)

# Generated at 2022-06-11 23:25:47.043680
# Unit test for function main
def test_main():
    # Setup
    import unittest
    from httpie.cli.constants import DEFAULT_UA
    from httpie.compat import urlopen
    from httpie.context import Environment
    from httpie.config import Config, EnvironmentConfig

    from httpie.plugins.registry import plugin_manager

    from httpie.cli.definition import parser
    from httpie import __version__
    from requests import __version__ as requests_version

    class RequestLoggingPlugin:
        name = 'RequestLoggingPlugin'
        description = 'Log all request bodies.'

        def get_request_kwargs(self, session, args, verify, cert):
            class RequestWrapper:
                def __init__(self, wrapped):
                    self._wrapped = wrapped


# Generated at 2022-06-11 23:25:48.312600
# Unit test for function main
def test_main():
    import doctest
    doctest.testmod()


# Generated at 2022-06-11 23:25:56.636499
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser()
    parser.add_argument("-q","--quiet",action="store_true")
    parser.add_argument("-F","--follow")
    parser.add_argument("-O","--output-file")
    parser.add_argument("--output-file-specified",action="store_true")
    parser.add_argument("--no-output",action="store_true")
    parser.add_argument("-o","--output-options")
    parser.add_argument("-b","--body")
    parser.add_argument("-f","--form")
    parser.add_argument("-j","--json")
    parser.add_argument("--download",action="store_true")
    parser.add_argument("--download-resume",action="store_true")

# Generated at 2022-06-11 23:26:06.053859
# Unit test for function program
def test_program():
    import requests
    from httpie.cli.definition import parser
    from pprint import pprint as pp
    from unittest.mock import Mock

    args = parser.parse_args('get https://httpbin.org/get'.split(), env=Mock())
    args.stream = True
    env = Mock()

    messages = collect_messages(args=args, config_dir=env.config.directory)
    print('\n'.join(map(str, messages)))
    print()

    write_message(None, env, args)
    write_message(None, env, args, with_body=True)
    write_message(None, env, args, with_body=True, with_headers=True)

    # test_program()

# Generated at 2022-06-11 23:26:16.616890
# Unit test for function main
def test_main():
    import pytest
    from pytest import approx
    from contextlib import contextmanager
    from httpie.context import Environment


    @contextmanager
    def capture_sys_output():
        import sys
        from io import StringIO
        old_stdout, old_stderr = sys.stdout, sys.stderr
        try:
            out = [StringIO(), StringIO()]
            sys.stdout, sys.stderr = out
            yield out
        finally:
            sys.stdout, sys.stderr = old_stdout, old_stderr
            out[0] = out[0].getvalue()
            out[1] = out[1].getvalue()

    env = Environment()
    args1 = ['http', '--debug', 'http:8080/api']

# Generated at 2022-06-11 23:26:24.457809
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.config import Config
    from httpie.output.streams import ConcatenatedStreamWriter
    args = parser.parse_args(
        args=[
            '--download',
            '--max-redirects=1',
            '--timeout=10',
            '--output-file=testfile',
            '--download-resume',
            'http://127.0.0.1:8000/',


        ],
        env=Environment(config=Config(),concatenated_stream_writer=ConcatenatedStreamWriter())
    )
    program(args,Environment())

# Generated at 2022-06-11 23:28:53.765184
# Unit test for function program
def test_program():
    import io
    import sys
    import os
    from io import StringIO
    from contextlib import redirect_stdout
    from env import Environment
    from cli.definition import parser
    def debug_catch():
        catch_output = StringIO()
        with redirect_stdout(catch_output):
            program()
            assert catch_output.getvalue() == "Received response:\n<Response [200]>\n"
    test_args = "httpie httpbin.org/get".split()
    args = parser.parse_args(args=test_args, env=Environment())
    program(args,Environment())
    debug_catch()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:28:58.326954
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

    args = parser.parse_args(["--method=get", "--headers", "User-Agent:hello", "https://www.baidu.com"])
    exit_status = program(args, Environment())
    assert exit_status == ExitStatus.SUCCESS


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:29:04.686793
# Unit test for function program
def test_program():
    import io
    import locale
    args = argparse.Namespace()
    args.output_options = ['all']
    args.stdin_encoding = locale.getpreferredencoding()
    args.stdout = io.BytesIO()
    args.stderr = io.BytesIO()
    args.method = 'GET'
    args.url = 'http://localhost:4545'
    exit_status = program(args)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:29:05.670917
# Unit test for function main
def test_main():
    #TODO: needs to be implemented
    assert False

# Generated at 2022-06-11 23:29:09.094247
# Unit test for function main
def test_main():
    import httpie.cli.argtypes
    import httpie.cli.definition

    input_args = [
        'https://google.com',
        '--help'
    ]

    main(input_args)

# Generated at 2022-06-11 23:29:20.161399
# Unit test for function main
def test_main():
    from httpie.context import Environment
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    import os
    import tempfile

    # prepare a temp config dir
    fd, config_dir = tempfile.mkstemp()
    os.close(fd)
    os.mkdir(config_dir)

    # prepare a temp file
    temp_file = tempfile.NamedTemporaryFile(dir=config_dir, delete=False)
    temp_file_name = temp_file.name
    temp_file.write("hello".encode("utf8"))
    temp_file.close()


# Generated at 2022-06-11 23:29:24.776106
# Unit test for function main
def test_main():
    from httpie.cli.environment import Environment
    env = Environment()
    exit_status = main(['httpie', '--help'], env)
    assert exit_status == ExitStatus.SUCCESS
    exit_status = main(['httpie', '--debug'], env)
    assert exit_status == ExitStatus.SUCCESS


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:29:25.851686
# Unit test for function program
def test_program():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:29:27.092520
# Unit test for function program
def test_program():
    assert program(args=['https://google.com'], env=Environment()) == 0

# Generated at 2022-06-11 23:29:37.625448
# Unit test for function main
def test_main():
    from httpie.shared.app import http
    from io import StringIO
    from unittest.mock import patch

    # Returns the context manager's __enter__ value
    stdin = StringIO("abc")
    with patch("sys.stdin", stdin):
        with patch("sys.stdout", new_callable=StringIO):
            with patch("httpie.cli.program.program", lambda *a: ExitStatus.ERROR_HTTP):
                with patch("sys.stderr", new=StringIO()):
                    # "http 'http://httpbin.org/get' --body"
                    sys.argv = ["http", "http://httpbin.org/get", "--body"]
                    assert http() == ExitStatus.ERROR_HTTP.value
                    # "http -f POST 'http://httpbin.org/post' --form

# Generated at 2022-06-11 23:30:20.919819
# Unit test for function main
def test_main():
    assert main(['http', 'httpbin.org', '--output=text']) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:30:21.673086
# Unit test for function program
def test_program():
    print(program())

# Generated at 2022-06-11 23:30:24.184051
# Unit test for function program
def test_program():
    pass

if __name__ == '__main__':
    exit(main())  # pragma: no cover

# Generated at 2022-06-11 23:30:24.800228
# Unit test for function program
def test_program():
    pass

# Generated at 2022-06-11 23:30:26.779452
# Unit test for function program
def test_program():
    assert program(['--json', 'https://httpbin.org/get'], Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:30:36.644576
# Unit test for function main
def test_main():
    class Env:
        class Stdout:
            def __init__(self):
                self.log = ''
            def write(self, data):
                self.log += str(data)
        class Stderr:
            def write(self, data):
                pass
        stdout = Stdout()
        stderr = Stderr()
    # Test success
    args = ['http', '--version', '-v']
    env = Env()
    assert main(args, env=env) == ExitStatus.SUCCESS
    args = ['http', '--version', '-v']
    assert main(args, env=env) == ExitStatus.SUCCESS
    args = ['http', '--version', '-v']
    assert main(args, env=env) == ExitStatus.SUCCESS
    args

# Generated at 2022-06-11 23:30:37.508491
# Unit test for function program
def test_program():
    # TODO
    pass

# Generated at 2022-06-11 23:30:44.876377
# Unit test for function program
def test_program():
    import os
    import requests
    import pytest
    from httpie.context import Environment
    from httpie.cli.definition import parser

    args=parser.parse_args(['http://127.0.0.1:5000/'])
    env=Environment()
    env.stdin_isatty=True
    env.stdout_isatty=True
    env.stderr_isatty=True
    env.color=True
    env.stdout_isatty=True
    env.stderr_isatty=True
    env.color=True
    # Create test directory
    env.config.directory = os.path.join(env.config.directory,"httpie_test_"+os.environ["USER"])

# Generated at 2022-06-11 23:30:50.613253
# Unit test for function main
def test_main():
    from httpie.input import SEP_CREDENTIALS
    from httpie.cli.parser import parser

    args = parser.parse_args([
        '--auth-type=basic',
        '--auth', 'test' + SEP_CREDENTIALS + 'test',
        '127.0.0.1:5000'
    ])
    assert main(sys.argv[:1], args) == ExitStatus.SUCCESS



# Generated at 2022-06-11 23:30:51.009315
# Unit test for function program
def test_program():
    assert True