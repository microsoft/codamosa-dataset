

# Generated at 2022-06-11 23:23:36.223423
# Unit test for function program
def test_program():
    # pylint: disable=W0621
    # noinspection PyUnusedLocal
    def dummy_requests_message(method=None, url=None, headers=None, body=None):
        dummy_requests_message.url = url
        dummy_requests_message.body = str(body)
        return dummy_requests_message


# Generated at 2022-06-11 23:23:37.709034
# Unit test for function main
def test_main():
    print(main())


# Generated at 2022-06-11 23:23:48.770010
# Unit test for function program
def test_program():
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.definition import parser
    from httpie.cli.utils import get_response_or_error
    from httpie.client import Client
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins import builtin

    class MockEnvironment:
        def __init__(self):
            self.stdout = sys.stdout
            self.stderr = sys.stderr
            self.log_error = sys.stderr.write
            self.log_info = sys.stdout.write
            self.stdout_isatty = sys.stdout.isatty()
            self.stderr_isatty = sys.stderr.isatty()
            self.stdin_encoding = 'utf8'

# Generated at 2022-06-11 23:23:59.162279
# Unit test for function program
def test_program():
    import requests
    import argparse
    args_parent = argparse.Namespace()
    args_parent.check_status = False
    args_parent.download = False
    args_parent.download_resume = False
    args_parent.follow = True
    args_parent.output_file = None
    args_parent.output_file_specified = False
    args_parent.output_options = [OUT_REQ_HEAD]
    args_parent.quiet = False
    args_parent.stream = False
    env = Environment()
    args = argparse.Namespace()
    args.headers = ""
    args.method = "GET"
    args.output_options = [args_parent.output_options]
    args.url = "https://httpie.org/test"

# Generated at 2022-06-11 23:24:02.233416
# Unit test for function program
def test_program():
    result = program([
        'http',
        'https://httpbin.org/get',
        '-v',
        '-p', 'win'
    ], Environment())
    print(result)

# Generated at 2022-06-11 23:24:14.862278
# Unit test for function program
def test_program():
    import argparse
    env = Environment()
    parser = argparse.ArgumentParser()
    parser.add_argument('--auth')
    parser.add_argument('--body')
    parser.add_argument('--check-status')
    parser.add_argument('--download')
    parser.add_argument('--download-resume')
    parser.add_argument('--follow')
    parser.add_argument('--form')
    parser.add_argument('--headers')
    parser.add_argument('--max-redirects')
    parser.add_argument('--output')
    parser.add_argument('--output-file')
    parser.add_argument('--output-options')
    parser.add_argument('--pretty')
    parser.add_argument('--quiet')

# Generated at 2022-06-11 23:24:15.378746
# Unit test for function program
def test_program():
    assert program() == 0

# Generated at 2022-06-11 23:24:24.733314
# Unit test for function main
def test_main():
    # (1) Test exit status without error
    args = ["--help"]
    env = Environment()
    exit_status = main(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

    # (2) Test exit status with error
    args = ["invalidArg"]
    exit_status = main(args=args, env=env)
    assert exit_status == ExitStatus.ERROR

    # (2) Test exit status with error by KeyboardInterrupt
    args = ["https://www.google.com"]
    exit_status = main(args=args, env=env)
    assert exit_status == ExitStatus.ERROR_CTRL_C


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:24:35.757978
# Unit test for function program
def test_program():
    from httpie.cli.argtypes import KeyValueArgType

    from httpie.plugins import builtin
    from httpie.plugins.manager import plugin_manager

    plugin_manager.remove_all()  # Note: Must be built-in plugins only!
    plugin_manager.load_builtin_plugins()
    builtins = plugin_manager.get_builtin_plugins()
    # test with all plugins
    for plugin in builtins:
        plugin_manager.load_plugin(plugin)
    args = ['-v', 'POST', 'https://httpbin.org/post']
    args.insert(0, 'http')
    exit_status = program(args=KeyValueArgType.parse(args), env=Environment())
    assert exit_status in (ExitStatus.SUCCESS, ExitStatus.ERROR_TIMEOUT)

# Generated at 2022-06-11 23:24:46.673604
# Unit test for function main
def test_main():
    import random
    import string
    import threading
    import time
    from httpie.cli.constants import (
        DEFAULT_CONFIG_DIR,
        CONFIG_DIR_ENV_VAR
    )
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from tests import http
    from tests.test_output_streams import TEST_CONFIG_DIRECTORY
    from tests.utils import httpbin
    try:
        import pytest
    except ImportError:
        import subprocess
        import sys
        errno = subprocess.call([sys.executable, '-m', 'pip', 'install', 'pytest'])
        if errno:
            exit(errno)
        else:
            import pytest

# Generated at 2022-06-11 23:25:15.885041
# Unit test for function program
def test_program():
    args = parser.parse_args(args=['get', 'http://httpbin.org'], env=Environment())
    assert program(args, Environment()) is ExitStatus.SUCCESS

# Generated at 2022-06-11 23:25:25.223671
# Unit test for function program
def test_program():
    # Tests from httpie/test/test_program.py

    from httpie.config import Config
    from httpie.context import Environment


    def get_args(argv):
        assert isinstance(argv, list)
        env = Environment(config=Config())
        _program_name, *_args = argv
        return env, _args


    def get_status_code(argv):
        env, args = get_args(argv)

# Generated at 2022-06-11 23:25:26.629679
# Unit test for function main
def test_main():
    return main(args=['https://httpbin.org/status/200'])

# Generated at 2022-06-11 23:25:27.053386
# Unit test for function program
def test_program():
    program()

# Generated at 2022-06-11 23:25:32.097501
# Unit test for function main
def test_main():
    assert main([]) == ExitStatus.SUCCESS
    assert main(['--version']) == ExitStatus.SUCCESS
    assert main(['-h']) == ExitStatus.SUCCESS
    assert main(['--help']) == ExitStatus.SUCCESS
    assert main(['http://example.com/', '-v']) == ExitStatus.SUCCESS
    assert main(['http://example.com/', '--json']) == ExitStatus.SUCCESS


# Generated at 2022-06-11 23:25:40.203549
# Unit test for function main
def test_main():
    from httpie.context import TestEnvironment
    from httpie.cli.parser import parser
    from httpie.status import ExitStatus
    def handler(args: argparse.Namespace, env: Environment) -> ExitStatus:
        assert args.arg == ['1', '2']
        assert env.program_name == 'http'
        return ExitStatus.SUCCESS
    env = TestEnvironment()
    parser.set_defaults(program=handler)
    assert main(['http', '1', '2'], env) == ExitStatus.SUCCESS
    assert main(['http', '-X', '--json', '1', '2'], env) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:25:50.401994
# Unit test for function program
def test_program():
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io

# Generated at 2022-06-11 23:25:53.854855
# Unit test for function program
def test_program():
    env = Environment()
    # args = parser.parse_args(['GET', 'cmcd.com'], env)
    args = parser.parse_args(['GET', 'cmcd.com', '--json'], env)
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:25:57.733385
# Unit test for function main
def test_main():
    assert main(args=['--key', 'value', 'http://www.example.com/']) is ExitStatus.SUCCESS
    assert main(args=['--key', 'value', 'http://www.example.com/']) is ExitStatus.SUCCESS

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 23:25:58.729171
# Unit test for function program
def test_program():
    pass


# Generated at 2022-06-11 23:26:58.215678
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO, StderrBytesIO

    env = Environment(
        stdin=StdoutBytesIO,
        stdout=StdoutBytesIO,
        stderr=StderrBytesIO,
        stdout_isatty=False,
        stderr_isatty=False,
    )
    args = parser.parse_args(''.split(), env=env)
    program(args, env)


if __name__ == '__main__':
    program()

# Generated at 2022-06-11 23:27:06.081063
# Unit test for function main
def test_main():
    class EnvStub:
        stdin_encoding = 'utf8'
        program_name = 'http'
        stdout_isatty = False
        stderr_isatty = False
        __repr__ = lambda self: '<env_stub>'

        def log_error(self, msg, level=None):
            pass

    env = EnvStub()
    for argv in [
        ['http', '--print=h', 'httpbin.org/headers'],
    ]:
        main(argv, env)

# Generated at 2022-06-11 23:27:09.034059
# Unit test for function main
def test_main():
    import pytest
    from httpie.core import main

    exit_status = main(['--debug'])
    # Unit test exit code is 0 or 1
    assert exit_status == 0 or exit_status == 1

# Generated at 2022-06-11 23:27:10.671742
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    env = Environment()
    print(program(args, env))

# Generated at 2022-06-11 23:27:13.619151
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    env = Environment()
    test_url = 'httpbin.org/get'
    args.url = test_url
    env.config.default_options = ['--form']
    args.headers = ['Content-Type:application/json']
    args.method = 'POST'
    args.data = '{"username":"httpie"}'

    ret = program(args, env)
    assert ret == 0

# Generated at 2022-06-11 23:27:15.431044
# Unit test for function program
def test_program():
    args = ['https://reqres.in/api/users/2']
    env = Environment()
    env.stdin_encoding = 'utf8'
    assert program(args=args, env=env) == ExitStatus.SUCCESS


# Generated at 2022-06-11 23:27:16.602177
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:27:17.539458
# Unit test for function main
def test_main():
    import pytest
    #assert main() == 'world'

# Generated at 2022-06-11 23:27:19.411714
# Unit test for function main
def test_main():
    # Just a test
    main(args=['http-bin', 'get', '-h'])

# Generated at 2022-06-11 23:27:21.213681
# Unit test for function program
def test_program():
    args, env = program(['--debug'], Environment())
    assert len(args) == 1
    assert isinstance(env, Environment)

# Generated at 2022-06-11 23:28:44.179173
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS



# Generated at 2022-06-11 23:28:55.138752
# Unit test for function program
def test_program():
    import pytest
    from httpie import ExitStatus

# Generated at 2022-06-11 23:29:01.929161
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace()
    args.output_options = []

    #Successful request
    args.method = "GET"
    args.url = "https://httpbin.org/get"
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

    #Failed request
    args.url = "https://httpbin.org/status/404"
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.ERROR_NOT_FOUND


if __name__ == '__main__':  # pragma: no cover
    try:
        exit_status = main()
    except KeyboardInterrupt:
        print('\nKeyboard Interrupt', file=sys.stderr)
       

# Generated at 2022-06-11 23:29:04.241588
# Unit test for function program
def test_program():
    exit_status = program(args=sys.argv, env=Environment())
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-11 23:29:15.112025
# Unit test for function program
def test_program():
    import pytest
    from httpie import ExitStatus
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.cli.parser import parser
    from typing import List, Tuple

    class fake_requests:
        class Response:
            def __init__(self, status_code, is_redirect):
                self.status_code = status_code
                self.is_redirect = is_redirect

        @staticmethod
        def get(*args, **kwargs):
            return fake_requests.Response(status_code=200, is_redirect=False)

    def fake_collect_messages(args: argparse.Namespace, follow: bool, **kwargs):
        if 'test.com' in args.url:
            yield fake_requests.get(args.url)
       

# Generated at 2022-06-11 23:29:16.187463
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:29:18.240797
# Unit test for function main
def test_main():
    exit_status = main()
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:29:26.579680
# Unit test for function main
def test_main():
    import os
    import sys

    def test_exit_status(args, expected_exit_status):
        # noinspection PyUnusedLocal
        def mock_write_stream(stream, outfile, flush):
            assert False, 'write_stream() should not be called'

        # noinspection PyUnusedLocal
        def mock_write_message(requests_message, env, args, with_headers, with_body):
            assert False, 'write_message() should not be called'

        from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
        from httpie.context import Environment
        from httpie.output.writer import MESSAGE_SEPARATOR_BYTES, write_message, write_stream

# Generated at 2022-06-11 23:29:37.095162
# Unit test for function program
def test_program():
    import pytest
    from httpie.compat import namedtuple
    from httpie.downloads import Downloader

    from requests.adapters import HTTPAdapter
    from requests.models import PreparedRequest, Response
    from requests.packages.urllib3.util.retry import Retry
    from requests.sessions import Session

    from httpie.cli.definition import parser

    from . import Result


# Generated at 2022-06-11 23:29:38.693077
# Unit test for function main
def test_main():
    assert main([]) == ExitStatus.ERROR
    assert main(['-h']) == ExitStatus.ERROR


# Generated at 2022-06-11 23:31:10.167934
# Unit test for function program
def test_program():
    from httpie.cli import Program
    from httpie.cli.definition import parser
    from httpie.cli.utils import get_response, get_request
    from httpie.cli.utils import Argument

    args = parser.parse_args([
        'https://github.com'
    ])

    args = parser.parse_args([
        '--form',
        'test',
        'https://github.com'
    ])

    args = parser.parse_args([
        '--headers',
        'test',
        'https://github.com'
    ])

    args = parser.parse_args([
        '--print',
        'H',
        'https://github.com'
    ])


# Generated at 2022-06-11 23:31:11.522215
# Unit test for function main
def test_main():
    assert main(['httpie', '--help']) == 0



# Generated at 2022-06-11 23:31:12.389955
# Unit test for function program
def test_program():
    return program.__doc__

# Generated at 2022-06-11 23:31:13.696156
# Unit test for function main
def test_main():
 
    # Assert
    assert main() == 0

# Generated at 2022-06-11 23:31:14.563717
# Unit test for function program
def test_program():
    status = program()
    return status

# Generated at 2022-06-11 23:31:22.978291
# Unit test for function program
def test_program():
    import pytest

    def program_test_fail(args: [str]):
        with pytest.raises(SystemExit) as pytest_wrapped_e:
            program(args=args)
        assert pytest_wrapped_e.type == SystemExit
        assert pytest_wrapped_e.value.code == ExitStatus.ERROR

    def program_test_success(args: [str]):
        with pytest.raises(SystemExit) as pytest_wrapped_e:
            program(args=args)
        assert pytest_wrapped_e.type == SystemExit
        assert pytest_wrapped_e.value.code == ExitStatus.SUCCESS


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:31:33.805033
# Unit test for function main
def test_main():
    http = 'http'
    localhost = 'localhost:5000'
    path = '/v2/pet/findByStatus?status=available'
    printed_to_stderr = '-'
    found_localhost = False
    found_path = False
    found_printed_to_stderr = False

    for line in run_program(http, localhost, path):
        if localhost in line:
            found_localhost = True

        if path in line:
            found_path = True

        if printed_to_stderr in line:
            found_printed_to_stderr = True

    assert found_localhost and found_path and found_printed_to_stderr, \
        'Test for main failed, final url or printed to stderr not found'



# Generated at 2022-06-11 23:31:36.151592
# Unit test for function main
def test_main():
    assert main(['http', 'http://www.google.com']) == 0
    assert main(['http', 'http://www.google.com'], env={'stdin_isatty': False}) == 0

# Generated at 2022-06-11 23:31:40.456528
# Unit test for function program
def test_program():
    env = Environment()
    env.stdin = ['{"test":123}']
    args = [
        "--json"
    ]
    result = program(args=args, env=env)
    assert result == 0

# Generated at 2022-06-11 23:31:45.779257
# Unit test for function main
def test_main():
    # TODO: Test a variety of use cases, including errors and help.
    assert main([]) == ExitStatus.SUCCESS
    assert main(['--debug']) == ExitStatus.SUCCESS
    assert main(['--debug', 'GET']) == ExitStatus.SUCCESS
    assert main(['GET']) == ExitStatus.SUCCESS
    assert main(['GET', 'example.org']) == ExitStatus.SUCCESS