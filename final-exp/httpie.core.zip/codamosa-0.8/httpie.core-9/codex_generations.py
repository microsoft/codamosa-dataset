

# Generated at 2022-06-11 23:23:20.390677
# Unit test for function program
def test_program():
    from httpie.output.streams import StdoutStderrBytesIOWrapper
    from httpie.context import Environment
    from httpie.cli.definition import parser

    class MockEchoServer(HTTPServer):
        def do_GET(self):
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain; charset=utf-8')
            self.end_headers()
            self.wfile.write('test response'.encode('utf-8'))

    server_address = ('', 0)
    httpd = MockEchoServer(server_address, BaseHTTPRequestHandler)
    host, port = httpd.server_address


# Generated at 2022-06-11 23:23:32.223793
# Unit test for function program
def test_program():
    args = ['http', 'http://httpbin.org/get']
    
    class EnvironmentMock(object):
        def __init__(self):
            self.stdout = sys.stdout
            self.stdout_isatty = sys.__stdout__.isatty()
            self.stderr = sys.stderr
            self.stderr_isatty = sys.__stderr__.isatty()
            self.stdin = sys.stdin
            self.stdin_isatty = sys.__stdin__.isatty()
            self.output = sys.stdout
            self.output_isatty = sys.__stdout__.isatty()
            self.stdin_encoding = sys.stdin.encoding or sys.getdefaultencoding()

# Generated at 2022-06-11 23:23:39.200045
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.config import DEFAULT_CONFIG_DIR, create_config_dir
    create_config_dir(DEFAULT_CONFIG_DIR)
    from httpie.plugins.manager import plugin_manager
    plugin_manager.load_installed_plugins()
    from httpie.output.formats.colors import style_streams
    from httpie import ExitStatus
    from httpie.output.config import TestEnvironment
    args = TestEnvironment()
    args.headers = []
    args.output_options = DEFAULT_FORMAT
    args.output_format = DEFAULT_FORMAT
    args.stdin_encoding = 'utf-8'
    args.stdout_encoding = 'utf-8'
    args.format = None
    args.config_dir

# Generated at 2022-06-11 23:23:45.454235
# Unit test for function main
def test_main():
    def callback(arg):
        return True
    sys.argv = ['httpie', 'https://httpie.org', '--timeout=30']
    env = Environment()
    env.config.default_options = ['--debug', '--traceback']

    status = main(env=env, args=sys.argv)
    assert status == ExitStatus.SUCCESS, "Should return Success"

# Generated at 2022-06-11 23:23:49.583459
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    env = Environment()
    env.config.default_options = ['--verbose']
    args = parser.parse_args(args=['get', 'www.google.com', '--json'], env=env)
    assert program(args=args, env=env) == ExitStatus.SUCCESS



# Generated at 2022-06-11 23:23:50.632592
# Unit test for function program
def test_program():
    program(['--help'])

test_program()

# Generated at 2022-06-11 23:24:00.387395
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--check-status", help="Exit with a non-zero status code if HTTP status code is larger then 399", action="store_true")
    parser.add_argument("-d", "--download", help="Download file", action="store_true")
    parser.add_argument("--download-resume", help="Resume file", action="store_true")
    parser.add_argument("-o", "--output-file", help="Output file", type=argparse.FileType())
    parser.add_argument("-S", "--print-req-headers", help="Output request headers", action="store_true")
    parser.add_argument("-D", "--download-output-file", help="Output file for download", type=argparse.FileType())

# Generated at 2022-06-11 23:24:13.137438
# Unit test for function program
def test_program():
    env = Environment()
    args = ["http"]
    assert program(args, env) == 0
    args = ["http", "-h"]
    assert program(args, env) == 0
    args = ["http", "--version"]
    assert program(args, env) == 0
    args = ["http", "--help"]
    assert program(args, env) == 0
    args = ["http", "www.example.com", "--version"]
    assert program(args, env) == 0
    args = ["http", "--check-status", "www.example.com"]
    assert program(args, env) == 0
    args = ["http", "www.example.com", "--headers"]
    assert program(args, env) == 0
    args = ["http", "www.example.com", "-v"]

# Generated at 2022-06-11 23:24:14.245945
# Unit test for function main
def test_main():
    main(args=[], env=Environment())

# Generated at 2022-06-11 23:24:24.331461
# Unit test for function main
def test_main():
    from httpie.cli.context import Context
    from httpie import __version__ as httpie_version
    c = Context()
    c.args = ['http', '--debug']
    c.env = Environment()
    c.env.program_name = 'http'
    c.env.stdin_encoding = 'utf-8'
    c.env.stdin = BytesIO(b'a=1&a=2&f=%E6%96%87%E6%A1%A3&f=%E6%96%87%E6%A1%A3httpbin.org/post'.encode('utf-8'))
    status = main(args=c.args, env=c.env)
    #print(status)
    print('test_main:')

# Generated at 2022-06-11 23:24:50.919676
# Unit test for function program
def test_program():
    """Doesn't work properly, downloader outputs filename which causes test to fail"""
    import pytest
    import io
    input_stdin = io.TextIOWrapper(io.BufferedReader(io.BytesIO(b'Test\n')), encoding='utf-8')
    output_stdout = io.BytesIO()
    output_stderr = io.TextIOWrapper(io.BytesIO())
    out_env = Environment(
        stdin=input_stdin,
        stdout=output_stdout,
        stderr=output_stderr,
    )
    with pytest.raises(SystemExit) as pytest_wrap_base:
        args = ['--download', 'https://httpie.org']
        main(args, env=out_env)
    assert pytest_wrap_base

# Generated at 2022-06-11 23:24:55.207222
# Unit test for function main
def test_main():
    import httpie.cli.program
    try:
        httpie.cli.program.main()
    except SystemExit as e:
        assert e.args[0] == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:24:55.924632
# Unit test for function main
def test_main():
    print(main())


# Generated at 2022-06-11 23:24:56.598562
# Unit test for function program
def test_program(): pass

# Generated at 2022-06-11 23:24:58.081384
# Unit test for function main
def test_main():
    # function main should be executed without error
    assert main() == 0

# Generated at 2022-06-11 23:25:05.096580
# Unit test for function main
def test_main():
    from httpie import exit_status

    import pytest

    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parser

    # pylint: disable=expression-not-assigned
    pytest.raises(SystemExit, main, ['--debug']) == exit_status.SUCCESS
    pytest.raises(SystemExit, main,
                  ['--form', 'field=a', 'field=b', '--pretty=all',
                   'GET', 'https://localhost/']) == exit_status.ERROR

    args = parser.parse_args(args=[
        '--auth-type=basic',
        '--auth=user:passwd',
        'https://localhost/',
        'key:=val'
    ], env=Environment())

# Generated at 2022-06-11 23:25:06.592702
# Unit test for function program
def test_program():
    assert  program(sys.argv, Environment()) == ExitStatus.SUCCESS


# Generated at 2022-06-11 23:25:14.270872
# Unit test for function program
def test_program():
    from httpie import input
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.definition import parser
    from httpie.cli.definition import parser
    from httpie.compat import is_windows
    from httpie.environment import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.status import ExitStatus

    args = parser.parse_args(['--ignore-stdin', '--body=@"C:/Users/kumar/Desktop/hackerrank/curl-to-httpie/test_input.txt"', 'http://httpbin.org/post'])
    env = Environment()
    env.config.__dict__['ignore_stdin'] = True
    env.config.__dict__['default_options'] = []

# Generated at 2022-06-11 23:25:24.379448
# Unit test for function program
def test_program():
    class ConsoleStderr:
        def __init__(self):
            pass

        def write(self, s):
            print(s, end='')

    class ConsoleStdout:
        def __init__(self):
            pass

        def write(self, s):
            print(s, end='')

    class Console:
        def __init__(self):
            self.stdin = ConsoleStdin()
            self.stderr = ConsoleStderr()
            self.stdout = ConsoleStdout()

    class Headers:
        def __init__(self, key=0, value=0):
            self.key = key
            self.value = value

    class Args:
        def __init__(self):
            self.args = ['https://httpbin.org/get']

# Generated at 2022-06-11 23:25:31.845828
# Unit test for function main
def test_main():
    import httpie.cli.parser as parser

    class MockArgs(object):
        """
        Mock argparse.Namespace object
        """
        def __init__(self, url, method):
            self.method = method
            self.url = url

    def test_get_method():
        parsed_args = parser.parse_args(['GET', 'http://httpbin.org/status/503'])
        exit_status = program(parsed_args, Environment())
        assert exit_status == ExitStatus.ERROR_HTTP_503

    def test_wrong_method():
        parsed_args = parser.parse_args(['XYZ', 'http://httpbin.org/status/503'])
        exit_status = program(parsed_args, Environment())
        assert exit_status == ExitStatus.ERROR


# Generated at 2022-06-11 23:25:55.754093
# Unit test for function program
def test_program():
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.cli.definition import parser
    from tests.httpbin import HTTPBIN_URL

    args = parser.parse_args(['--traceback', HTTPBIN_URL + '/headers'])
    print(program(args=args))

    args = parser.parse_args([HTTPBIN_URL + '/headers'])
    print(program(args=args))

    args = parser.parse_args(['--output', 'headers', HTTPBIN_URL + '/headers'])
    print(program(args=args))

    args = parser.parse_args(['--output', 'body', HTTPBIN_URL + '/headers'])

# Generated at 2022-06-11 23:26:04.119307
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser()
    parser.add_argument('-b', '--body', action="store_true")
    args = parser.parse_args(args=["-b"])

    class Environment:
        class config:
            directory = ""
        program_name = ""
        stdin_encoding = "utf-8"
        stdout = sys.stdout
        stderr = sys.stderr
        stdout_isatty = True
        is_windows = False

    env = Environment()
    program(args=args, env=env)


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-11 23:26:09.416444
# Unit test for function main
def test_main():

    assert main(['http']) == ExitStatus.SUCCESS
    assert main(['http', '--debug']) == ExitStatus.SUCCESS
    assert main(['http', '--help']) == ExitStatus.SUCCESS
    assert main(['http', '--version']) == ExitStatus.SUCCESS


if __name__ == '__main__':
    sys.exit(main(sys.argv))

# Generated at 2022-06-11 23:26:13.935727
# Unit test for function program
def test_program():
    args = argparse.Namespace(argv=[
                                'http', '--debug', '--log-debug', '--pretty=all', 'http://example.com/'
                                ])
    env = Environment()
    main(args, env)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:26:17.407255
# Unit test for function main
def test_main():
    from httpie.cli.environment import Environment
    args = ['--debug']
    env = Environment()

    main(args=args, env=env)


if __name__ == '__main__':
    main()
    #test_main()

# Generated at 2022-06-11 23:26:26.900821
# Unit test for function main
def test_main():
    # Test success
    assert main() == ExitStatus.SUCCESS
    assert main(['--debug']) == ExitStatus.SUCCESS

    # Test --help
    assert main(['--help']) == ExitStatus.SUCCESS
    assert main(['-h']) == ExitStatus.SUCCESS

    # Test --version
    assert main(['--version']) == ExitStatus.SUCCESS
    assert main(['-v']) == ExitStatus.SUCCESS

    # Test failures
    assert main(['--abra']) == ExitStatus.ERROR
    assert main(['-X']) == ExitStatus.ERROR
    assert main(['http://httpbin.org', '--abra']) == ExitStatus.ERROR
    assert main(['-X', 'CONNECT', '--abra']) == ExitStatus.ERROR

# Generated at 2022-06-11 23:26:34.787910
# Unit test for function program
def test_program():
    env = Environment()
    args = [
    '--b',
    'G:\\Programming\\Python\\work\\httpie\\examples\\heart.png',
    '--form',
    '--json',
    '--output=G:\\Programming\\Python\\work\\httpie\\examples\\heart1.png',
    '--verbose',
    '--download',
    'http://127.0.0.1:5000/upload',
    '--send-user=admin',
    '--send-password=admin'
    ]
    main(args,env)

# Generated at 2022-06-11 23:26:42.576945
# Unit test for function program

# Generated at 2022-06-11 23:26:51.922300
# Unit test for function program
def test_program():
    import subprocess
    import shutil
    import requests
    import time
    import os

# Generated at 2022-06-11 23:26:59.447403
# Unit test for function main
def test_main():
    import io
    args_list = ['test.exe']
    io_bytes = io.BytesIO()


# Generated at 2022-06-11 23:27:21.060310
# Unit test for function program
def test_program():
    from httpie.context import Environment
    from httpie.cli.parser import parser
    args = parser.parse_args(args=['get', 'http://httpbin.org/get'], env=Environment())
    exit_status = program(args=args, env=Environment())
    assert exit_status == ExitStatus.SUCCESS
    assert 'httpbin.org' in args.url.hostname


# Generated at 2022-06-11 23:27:29.482401
# Unit test for function program
def test_program():
    class Ns:
        def __init__(self):
            self.output_options = ['body', 'head']
            self.output_file = None
            self.output_file_specified = True
            self.check_status = False
            self.quiet = False
            self.follow = True
            self.download = False
            self.download_resume = False
            self.headers = []
        def __repr__(self):
            return 'Ns()'
    args = Ns()
    env = Environment()
    env.config.directory.user_config = 'D:\\workspace\\httpie\\tests\\fixtures\\user\\config.json'
    env.stdout = open('d:\\test_out.txt', 'wb')

# Generated at 2022-06-11 23:27:33.801213
# Unit test for function program
def test_program():
    args = ["http", "httpie.org", "-o", "httpie.org.html"]
    env = Environment()
    exit_status = program(args, env)
    print(exit_status)


if __name__ == "__main__":
    test_program()

# Generated at 2022-06-11 23:27:41.396167
# Unit test for function program
def test_program():
    """
    unit test for program
    """
    def tester(args, test_cases):
        parser.parse_args = args
        program(parser.parse_args, env=Environment())
        for i in range(len(test_cases)):
            assert program(parser.parse_args, env=Environment()) == test_cases[i]
    args = []
    test_cases = [ExitStatus.SUCCESS, ExitStatus.ERROR, ExitStatus.ERROR_CTRL_C]
    tester(args, test_cases)


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:27:43.975944
# Unit test for function program
def test_program():
    program([
        'http',
        '--verbose',
        'www.example.com',
    ])

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-11 23:27:46.996513
# Unit test for function program
def test_program():
    """
    Test function program

    """
    assert main(args=['https://httpbin.org/get']) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:27:53.347416
# Unit test for function program
def test_program():
    import pytest
    import requests
    def get_args():
        parser = argparse.ArgumentParser()
        parser.add_argument('-b', '--body')
        parser.add_argument('-f', '--follow')
        parser.add_argument('-c', '--check-status')
        parser.add_argument('-t', '--timeout')
        parser.add_argument('-H', '--headers')
        parser.add_argument('-d', '--download')
        parser.add_argument('-r', '--download-resume')
        parser.add_argument('-o', '--output')
        return parser

# Generated at 2022-06-11 23:27:58.863002
# Unit test for function program
def test_program():
    import io
    import sys
    stdin = io.StringIO()
    stdout = io.StringIO()
    args = ["http", "--output", "text", "http://www.example.com"]
    exit_status = main(args=args, env=Environment(stdin=stdin, stdout=stdout))
    # assert stdout.getvalue() == ""
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:28:01.106670
# Unit test for function program
def test_program():
    def test_program():
        args = argparse.Namespace()
        env = Environment()
        args.headers = []
        program(args,env)

# Generated at 2022-06-11 23:28:11.635088
# Unit test for function program
def test_program():
    import argparse
    args = argparse.Namespace(download=False,
                              download_resume=False,
                              form=[],
                              follow=False,
                              headers=[],
                              input=None,
                              json=[],
                              max_redirects=10,
                              method='GET',
                              output_file=None,
                              output_file_specified=False,
                              output_options=[],
                              output_to_terminal=False,
                              timeout=30,
                              url='https://httpbin.org/get')
    class Environment(object):
        def __init__(self):
            self.stderr = sys.stderr
            self.stdout = sys.stdout
            self.stderr_isatty = sys.stderr.isat

# Generated at 2022-06-11 23:28:57.322450
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.formatters import JSONFormatter
    env = Environment()
    args = parser.parse_args('httpie'.split())
    import requests.models
    with pytest.warns(UserWarning):
        requests_message = requests.models.PreparedRequest()
        exit_status = program(args, env)
        requests_message.prepare_url('https://httpbin.org/anything', None)
        requests_message.prepare_headers(args.headers)
        requests_message.prepare_cookies(args.cookies)
        formatter = JSONFormatter()
        for message in requests_message.iter_body():
            formatter.write_body(message)
    assert exit_status == ExitStatus

# Generated at 2022-06-11 23:28:59.232289
# Unit test for function program
def test_program():
  pos_args = '--verbose http://httpbin.org/json'.split()
  main(['http', *pos_args])

# Generated at 2022-06-11 23:29:10.243559
# Unit test for function program
def test_program():
    '''
    [httpie.py] Test function: program
    '''
    class Args():
        def __init__(self):
            self.args = ["https://httpbin.org/get"]
            self.headers = None
            self.timeout = 5
            self.max_redirects = 30
            self.check_status = True
            self.follow = True
            self.download = False
            self.download_resume = False
            self.output_file = None
            self.output_file_specified = False
            self.output_options = OUT_RESP_BODY
    args = Args()
    class Env():
        def __init__(self):
            self.config = None
            self.stdout = sys.stdout

# Generated at 2022-06-11 23:29:21.227315
# Unit test for function main
def test_main():
    import io
    import sys

    from httpie.context import Environment

    from httpie.cli.parser import DEFAULTS
    from httpie import ExitStatus

    # Capture output to stdout when running main
    stdout = io.StringIO()
    with stdout_redirected(stdout):
        args = []
        main(args=args, env=Environment())
        out = stdout.getvalue()
        assert out.endswith(DEFAULTS['help'])
        assert os.getcwd() in out

    args = ['--debug']
    main(args=args, env=Environment(stdout=stdout))
    out = stdout.getvalue()
    assert out.endswith(DEFAULTS['help'])

    assert main(args=['--debug'], env=Environment(stdout=stdout))

# Generated at 2022-06-11 23:29:29.152083
# Unit test for function program
def test_program():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.constants import OUTPUT_OPTIONS
    from httpie.config import Config
    from httpie import ExitStatus
    from httpie.utils import UnavailableLocalFileError
    from io import BytesIO
    from io import UnsupportedOperation
    from io import TextIOWrapper
    from unittest import mock
    from urllib.parse import ParseResult
    import httpie
    import requests
    import pytest
    import sys
    import tempfile
    import threading

    parser = httpie.cli.definition.parser
    config_dir = Config.get_config_dir()
    # Redirect stdout and stderr to capture any output
    stdout = sys.stdout
    stderr = sys.stderr
    # Create

# Generated at 2022-06-11 23:29:32.539227
# Unit test for function main
def test_main():
    assert main(['--help']) == ExitStatus.SUCCESS
    assert main(['--version']) == ExitStatus.SUCCESS
    assert main(['--debug']) == ExitStatus.SUCCESS
    assert main([]) == ExitStatus.ERROR

# Generated at 2022-06-11 23:29:41.894508
# Unit test for function program
def test_program():
    #print("Executing Unit Test")
    import argparse

# Generated at 2022-06-11 23:29:50.388678
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_SERVER
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PluginManager

    class FakeStdin:
        def __init__(self):
            self.buffer = b'{"name": "Jane", "age": 37}'

        def isatty(self):
            return False

    class FakeStdout:
        def __init__(self):
            self.buffer = io.BytesIO()

        def isatty(self):
            return False

    plugin_manager = PluginManager()
    plugin_manager.add_plugin(HTTPiePlugin())
    fake_stderr = FakeStdout()
    fake_stdout = FakeStdout()
    fake_stdin = FakeStdin()

# Generated at 2022-06-11 23:29:51.016419
# Unit test for function program
def test_program():
    assert main() == 0

# Generated at 2022-06-11 23:29:52.202283
# Unit test for function program
def test_program():
    exit_status_code = main()
    assert exit_status_code == 0