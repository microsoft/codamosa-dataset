

# Generated at 2022-06-11 23:23:15.875237
# Unit test for function main
def test_main():
    p = main(['--output-options', 'b', '--output-options', 'hB', 'http://httpbin.org/get'])
    assert p == ExitStatus.SUCCESS



# Generated at 2022-06-11 23:23:21.890935
# Unit test for function program
def test_program():
    write_stream(stream=None, outfile=None, flush=False)

    args = argparse.Namespace()
    args.debug = True
    args.download = True
    args.headers = []
    args.output_file = 'outfile.txt'
    args.output_file_specified = True
    args.output_options = []
    args.quiet = False
    env=Environment()

    program(args=args, env=env)

# Generated at 2022-06-11 23:23:24.928012
# Unit test for function main
def test_main():
    assert main(args=['--debug']) == ExitStatus.SUCCESS
    assert main(args=['--debug', 'https://httpbin.org/ip']) == ExitStatus.SUCCESS



# Generated at 2022-06-11 23:23:26.460636
# Unit test for function program
def test_program():
    if __name__ == '__main__':
        sys.exit(main())

# Generated at 2022-06-11 23:23:36.820839
# Unit test for function main
def test_main():
    import pytest

# Generated at 2022-06-11 23:23:48.209844
# Unit test for function program
def test_program():
    from httpie.core import main
    import requests
    import pytest

    url = 'https://httpbin.org/get'

    def test_200():
        assert main([url]) == ExitStatus.SUCCESS
        assert main(['-v', url]) == ExitStatus.SUCCESS

    def test_418():
        assert main(['--check-status', url + '/status/418']) == ExitStatus.ERROR_HTTP_418
        assert main(['-v', '--check-status', url + '/status/418']) == ExitStatus.ERROR_HTTP_418

    def test_500():
        assert main(['--check-status', url + '/status/500']) == ExitStatus.ERROR_HTTP_5XX
        assert main(['-v', '--check-status', url + '/status/500']) == ExitStatus

# Generated at 2022-06-11 23:23:49.153943
# Unit test for function program
def test_program():
    assert program('--debug') != ExitStatus.SUCCESS

# Generated at 2022-06-11 23:23:59.478213
# Unit test for function program
def test_program():
    from httpie.compat import urlparse
    from httpie.context import Environment
    import sys
    import requests
    # get default args
    default_args = main()
    env = Environment()
    default_args.username = 'admin'
    default_args.password = '123456'
    default_args.auth_type = 'basic'

    # test command 'GET'
    default_args.method = 'GET'
    default_args.url = 'http://localhost:8000/api/'
    if sys.version_info >= (3, 6):
        try:
            program(default_args, env)
        except requests.exceptions.ConnectionError:
            pass

    # test command 'OPTIONS'
    default_args.method = 'OPTIONS'

# Generated at 2022-06-11 23:24:07.137133
# Unit test for function main
def test_main():
    assert main(['httpie','httpie.org']) == 0
    assert main(['httpie','--debug','httpie.org']) == 0
    assert main(['httpie','--traceback','httpie.org']) == 0
    assert main(['httpie','-v','httpie.org']) == 0
    assert main(['httpie','-v','--stream']) == 1
    assert main(['httpie','-v','--traceback']) == 1

# Generated at 2022-06-11 23:24:10.445654
# Unit test for function program
def test_program():
    args = ['example_url']
    env = Environment()
    env.stdout = io.StringIO()
    assert program(args, env) == ExitStatus.SUCCESS
    print(env.stdout.getvalue())

# Generated at 2022-06-11 23:26:14.954258
# Unit test for function main
def test_main():
    from pytest import raises
    from httpie.output.exceptions import ParseError
    from httpie.config import Config
    import contextlib
    import io

    config = Config(directory='.')
    exit_status = ExitStatus.SUCCESS
    shutdown_stderr = io.StringIO()
    shutdown_stdout = io.StringIO()


# Generated at 2022-06-11 23:26:24.820316
# Unit test for function program
def test_program():
    from httpie.compat import is_windows
    from httpie.core import StatusCodes
    from httpie.cli import options
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HTTPHeaderDict
    from httpie.status import http_status_to_exit_status
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    import io
    class FakeClientResponse:
        def __init__(self, status_code, reason, url, headers, content, version, encoding=None, history=None):
            self.status_code = status_code
            self.reason = reason
            self.url = url
            self.headers = headers
            self.content = content
            self.version = version

# Generated at 2022-06-11 23:26:35.164858
# Unit test for function main
def test_main():
    from io import BytesIO
    from httpie import main as test_main
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    with open(os.path.join(DEFAULT_CONFIG_DIR, 'config.json'), 'w') as f:
        f.write("{\"default_options\": [\"--verbose\"]}")
    sys.argv = [sys.argv[0], '--print', 'YAML']
    test_main()
    sys.argv = [sys.argv[0], '--timeout', '3', 'httpbin.org/get']
    test_main()
    sys.argv = [sys.argv[0], '--ignore-stdin', '-', 'httpbin.org/get']
    env = Environment()
    env.stdin.write

# Generated at 2022-06-11 23:26:38.433445
# Unit test for function main
def test_main():
    env = Environment()
    env.stdin = io.StringIO('test')
    exit_code = main(['', 'GET', 'http://en.wikipedia.org'], env=env)
    assert exit_code == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:26:48.876118
# Unit test for function program
def test_program():
    def parse_args_object(args: List[str]) -> argparse.Namespace:
        from httpie.cli.definition import parser
        parsed_args = parser.parse_args(args=args, env=Environment())
        return parsed_args

    # test --help
    assert program(parse_args_object(['--help']), Environment()) == ExitStatus.SUCCESS
    assert program(parse_args_object(['hello', '--help']), Environment()) == ExitStatus.SUCCESS

    # test --version
    assert program(parse_args_object(['--version']), Environment()) == ExitStatus.SUCCESS
    assert program(parse_args_object(['hello', '--version']), Environment()) == ExitStatus.SUCCESS

    # test --get

# Generated at 2022-06-11 23:26:57.848932
# Unit test for function program
def test_program():
    import pytest
    from httpie import ExitStatus
    from httpie.client.tokens import RequestToken
    from httpie.cli.argtypes import KeyValueArg

    args = []
    env = Environment()

    args = [
        RequestToken('GET', 'https://httpbin.org/get'),
        RequestToken('GET', 'https://httpbin.org/get',
                     [['Accept', 'application/json']]),
        RequestToken('GET', 'https://httpbin.org/get',
                     [['Accept', 'application/json']]),
        RequestToken('GET', 'https://httpbin.org/get',
                     [['Accept', 'application/json']]),
    ]

    parsed_args = argparse.Namespace()

    # Case 1: No redirect
    parsed_args.max_redirects = 0

# Generated at 2022-06-11 23:26:58.586249
# Unit test for function main
def test_main():
    assert main == main

# Generated at 2022-06-11 23:26:59.538000
# Unit test for function main
def test_main():
    assert ExitStatus.SUCCESS == main()

# Generated at 2022-06-11 23:27:10.506427
# Unit test for function program
def test_program():
    """
    unit test for function program
    """
    import argparse
    import os
    import sys

    # test data

# Generated at 2022-06-11 23:27:14.783128
# Unit test for function program
def test_program():
    # pylint: disable=W0212
    from httpie.core import main as program
    from httpie.compat import str
    assert program([]) == 0
    #assert program(['--debug']) == 0
    #assert program(['--version']) == 0
    #assert program(['GET', 'https://httpbin.org/ip']) == 0

# Generated at 2022-06-11 23:28:00.569542
# Unit test for function main
def test_main():
    class TestEnv:
        stdin_encoding = 'utf-8'
        stdout = sys.stdout
        stderr = sys.stderr
        is_windows = False
    exit_status = main(
        args=['http', 'https://www.linode.com'],
        env=TestEnv()
    )
    assert exit_status == ExitStatus.SUCCESS

if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-11 23:28:11.129203
# Unit test for function program
def test_program():
    import os
    import requests
    import sys
    import tempfile
    import unittest
    import unittest.mock


    class Mock(unittest.TestCase):
        def setUp(self):
            self.temp_file = tempfile.NamedTemporaryFile()
            self.env = unittest.mock.create_autospec(Environment)
            self.env.stdout = self.temp_file
            self.env.config.directory = tempfile.TemporaryDirectory()
            self.env.stdout_isatty = False
            self.env.stderr_isatty = False
            self.args = unittest.mock.create_autospec(argparse.Namespace)
            self.args.ignore_stdin = None
            self.args.output_options = []


# Generated at 2022-06-11 23:28:21.707565
# Unit test for function main
def test_main():
    import os
    import sys
    dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(dir + '/../../')
    save_argv = sys.argv
    sys.argv = [sys.argv[0], '--debug']

    from httpie.cli.definition import parser, DEBUG_ENVVAR_HELP

    import pytest
    from httpie.compat import is_windows
    from httpie.status import ExitStatus, http_status_to_exit_status

    stdin = sys.stdin.buffer if is_windows and sys.version_info < (3, 8) else sys.stdin
    stdout = sys.stdout.buffer if is_windows and sys.version_info < (3, 8) else sys.stdout

   

# Generated at 2022-06-11 23:28:29.671504
# Unit test for function program

# Generated at 2022-06-11 23:28:32.138058
# Unit test for function program
def test_program():
    exit_status = program(args=["www.google.com"], env=Environment())
    print(exit_status)


# Generated at 2022-06-11 23:28:34.832867
# Unit test for function main
def test_main():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    # test_main()
    sys.exit(main())

# Generated at 2022-06-11 23:28:41.717900
# Unit test for function main
def test_main():
    class env_mock:
        def __init__(self):
            pass

    class cli_args_mock:
        def __init__(self):
            self.headers = ""
            self.method = "GET"
            self.output_file = None
            self.output_file_specified = False
            self.output_options = ["all"]
            self.timeout = 10
            self.url = "https://httpie.org"

    args = sys.argv
    args.append("--headers")
    args.append("key:value")
    args.append("--timeout=5")
    args.append("--output=all")
    args.append("--output-file-specified")
    args.append("--output-file=")
    args.append("GET")

# Generated at 2022-06-11 23:28:42.992818
# Unit test for function main
def test_main():
    assert main([]) == 0

# Generated at 2022-06-11 23:28:46.154293
# Unit test for function program
def test_program():
    args = main(['--debug', 'get', 'https://httpbin.org/get'])
    print(args)


if __name__ == '__main__':
    test_program()

# Generated at 2022-06-11 23:28:48.707557
# Unit test for function program
def test_program():
    from httpie import ExitStatus
    exit_status = ExitStatus.SUCCESS
    return exit_status

# Generated at 2022-06-11 23:30:09.911542
# Unit test for function main
def test_main():
    print(main())

if __name__ == "__main__":
    app = sys.argv[1]
    main()

# Generated at 2022-06-11 23:30:13.571035
# Unit test for function program
def test_program():
    print("Test Start")
    args = ['http', 'https://github.com', '-b', '--headers', '--output=-', '-f', '--check-status']
    exit_status = program(args=args, env=Environment())
    print(exit_status)
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-11 23:30:16.034368
# Unit test for function main
def test_main():
    print(main())

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 23:30:17.665019
# Unit test for function main
def test_main():
    assert main(["http","--follow","get","https://httpbin.org/get"])==ExitStatus.SUCCESS

# Generated at 2022-06-11 23:30:28.178882
# Unit test for function program
def test_program():
    class args:
        download = False
        follow = True
        headers = None
        output_file = None
        output_file_specified = False
        output_options = OUT_REQ_HEAD | OUT_RESP_HEAD
        quiet = False
        #request_body = b'{"test":"test"}'
        request_body = '{"test":"test"}'
        timeout = 30
    class env:
        stdout = sys.stdout
        stdout_isatty = False
        stderr = sys.stderr
        def log_error(self, error_msg, level='error'):
            print(error_msg)
        
    #args = ['--download', '--download-resume', '--output-file=test.json']
    #args = ['--download', '--download-resume']
   

# Generated at 2022-06-11 23:30:29.814808
# Unit test for function program
def test_program():
    assert program('', '') == ''

# Generated at 2022-06-11 23:30:32.221140
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace(url='http://localhost:5000/', output_file=None)
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:30:34.466392
# Unit test for function main
def test_main():
    import pytest
    from httpie import ExitStatus

    result = main(['https://httpbin.org/get']);
    assert result == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:30:42.615159
# Unit test for function main
def test_main():
    import io
    import sys
    import unittest

    from httpie.cli.definition import parser
    from httpie.context import Environment

    class MainTestCase(unittest.TestCase):
        def setUp(self):
            self.stdout = io.StringIO()
            self.stderr = io.StringIO()
            self.env = Environment()
            self.env.stdout = self.stdout
            self.env.stderr = self.stderr
            self.orig_argv = sys.argv
            self.orig_stdout = sys.stdout
            self.orig_stderr = sys.stderr
            sys.stdout = self.stdout
            sys.stderr = self.stderr

        def tearDown(self):
            sys.argv = self.orig

# Generated at 2022-06-11 23:30:52.896094
# Unit test for function program
def test_program():
    import unittest
    import requests
    from httpie.output.writer import write_message, write_stream
    import json

    class check_request_body_read_callback(unittest.TestCase):
        def setUp(self):
            self.env = Environment()
            self.env.config.directory = 'config_dir'
            self.args = argparse.Namespace()
            self.args.headers = {}

        def tearDown(self):
            self.env = None
            self.args = None

        def test_initial_request(self):
            self.args.method = 'GET'
            self.args.url = 'https://httpbin.org/get'
            self.args.timeout = 10
            self.args.output_options = [OUT_REQ_BODY]

            messages = collect_mess

# Generated at 2022-06-11 23:32:21.154339
# Unit test for function program
def test_program():
    assert program(args=['test'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:32:23.873332
# Unit test for function program
def test_program():
    env = Environment()
    args = ['--json', 'http://httpbin/get', 'Accept:application/json']
    print(program(args=args, env=env))

# Generated at 2022-06-11 23:32:32.389743
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser(prog='http')
    parser.add_argument('--output-options', '-o', type=str, default='Hh')
    parser.add_argument('--verbose', '-v', dest='output_options', type=str, action=argparse.StoreAppendConstant, const='H')
    parser.add_argument('--headers', '-h', type=str, action='append')
    parser.add_argument('--body', '-b', type=str)
    parser.add_argument('--download', type=str)
    parser.add_argument('--download-resume', action='store_true')
    parser.add_argument('--follow', action='store_true')
    parser.add_argument('--check-status', action='store_true')

# Generated at 2022-06-11 23:32:41.571936
# Unit test for function main
def test_main():

    from httpie.cli.parser import parser
    from httpie.client import collect_messages
    from httpie.compat import is_windows
    from httpie.input import InputFile
    from httpie.output.writer import write_message, write_stream
    from httpie.status import ExitStatus

    with TemporaryEnvironment() as env:
        env.stdin_isatty = False
        # TODO: Use a dummy file for this and assert it was called appropriately.
        args = parser.parse_args(
            args=['http',
                  '--debug',
                  'http://httpbin.org/stream/3',
                  'range==0-5'],
            env=env,
        )
        exit_status = main(args=args, env=env)
        assert exit_status == ExitStatus.SUCCESS