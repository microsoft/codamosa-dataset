

# Generated at 2022-06-11 23:23:22.774684
# Unit test for function main
def test_main():
    """
    Unit test.
    """
    assert True

# Generated at 2022-06-11 23:23:34.188536
# Unit test for function program
def test_program():
    def parse_args(args: List[str], **kwargs):
        return main(args=['http'] + args)

    assert parse_args(['httpbin.org']) == ExitStatus.SUCCESS
    assert parse_args(['--version']) == ExitStatus.SUCCESS
    assert parse_args(['--help']) == ExitStatus.SUCCESS
    assert parse_args(['-v', 'httpbin.org']) == ExitStatus.SUCCESS
    assert parse_args(['--verbose', 'httpbin.org']) == ExitStatus.SUCCESS
    assert parse_args(['--json', 'httpbin.org']) == ExitStatus.SUCCESS
    assert parse_args(['--traceback', 'httpbin.org']) == ExitStatus.ERROR

# Generated at 2022-06-11 23:23:36.489794
# Unit test for function main
def test_main():
    import doctest
    doctest.run_docstring_examples(main, globals())


# Generated at 2022-06-11 23:23:38.235184
# Unit test for function program
def test_program():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:23:46.813766
# Unit test for function program
def test_program():
    class TestEnv:
        class config:
            class directory:
                pass
        class stderr:
            pass
        class stdin:
            pass
        class stdout:
            pass
    class TestArgs:
        class headers:
            pass
        class max_redirects:
            pass
        class timeout:
            pass
        class method:
            pass
        class url:
            pass
        class output_options:
            pass
    te = TestEnv()
    ta = TestArgs()
    ta.output_options = []
    main()

# Generated at 2022-06-11 23:23:58.082969
# Unit test for function program
def test_program():
    import argparse
    import requests
    import tempfile
    import os
    import time
    import http.client
    import socket
    import sys
    import re
    import urllib3
    from httpie import ExitStatus

    class MockEnv:
        stdout = tempfile.TemporaryFile('wb+')
        verbose = False
        stdout_isatty = True
        log_error = print
        stderr = tempfile.TemporaryFile('wb+')


# Generated at 2022-06-11 23:24:02.495352
# Unit test for function main
def test_main():
    assert main(['http', 'www.example.com']) == 1
    assert main(['http', 'www.example.com/']) == 0
    assert main(['http', 'https://example.com']) == 0
    assert main(['http', '--verbose', 'https://example.com']) == 0


# Generated at 2022-06-11 23:24:05.430909
# Unit test for function main
def test_main():
    assert main(['http', '--help']) == ExitStatus.SUCCESS



# Generated at 2022-06-11 23:24:08.332851
# Unit test for function main
def test_main():
    try:
        assert main(['httpie', 'post', '--help']) == ExitStatus.SUCCESS
    except Exception as ex:
        print(ex)

# Generated at 2022-06-11 23:24:13.033062
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.output_options = ['h']
    args.headers = {}
    args.output_file = None
    args.output_file_specified = False
    assert type(program(args, env=Environment())) is ExitStatus

# Generated at 2022-06-11 23:25:55.175615
# Unit test for function main
def test_main():
    print(main(['--debug']))
    print(main(['--timeout', '0.1', '--follow', 'http://github.com/jakubroztocil/httpie']))


# Generated at 2022-06-11 23:26:05.118520
# Unit test for function main
def test_main():
    assert main(['http', 'https://httpbin.org/get']) == ExitStatus.SUCCESS
    assert main(['http', 'http://localhost:1234']) == ExitStatus.ERROR_CONNECTION_FAILED
    assert main(['http', 'http://httpbin.org/status/418']) == ExitStatus.ERROR_HTTP_418
    assert main(['http', 'http://httpmock.invalid']) == ExitStatus.ERROR_CONNECTION_FAILED
    assert main(['http', '--download', '--output=test.html', 'http://httpbin.org/links/10/0']) == ExitStatus.SUCCESS
    assert main(['http', '--download', '--output=test.html', 'http://httpbin.org/range/1000000']) == ExitStatus.ERROR_

# Generated at 2022-06-11 23:26:13.658117
# Unit test for function program
def test_program():
    # Given
    from unittest.mock import Mock

    args = argparse.Namespace()
    mock_request = Mock()
    mock_request.method = 'GET'
    mock_request.url = '/index.html'
    expected_response = Mock()
    expected_response.status_code = 200
    args.output_options = OUT_REQ_HEAD | OUT_RESP_HEAD
    # When
    with mock.patch('httpie.client.collect_messages', return_value=[mock_request, expected_response]):
        # Then
        assert program(args=args, env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:26:23.597906
# Unit test for function program
def test_program():
    import requests
    import io
    import sys
    import pytest
    from httpie.output.formatters import BaseFormatter
    from httpie.cli.definition import parser

    argv = [
        sys.executable,
        '--debug',
    ]
    env = Environment()
    parsed_args = parser.parse_args(args=argv, env=env)
    print(type(env.stdin))
    print(type(parser))
    print(type(parsed_args))
    print(type(sys.stdout))
    print(type(sys.stderr))
    print(env.stdin)
    print(parser)
    print(parsed_args)
    print(sys.stdout)
    print(sys.stderr)
    # with pytest.raises(Exception

# Generated at 2022-06-11 23:26:33.875552
# Unit test for function program
def test_program():
    from httpie.client import parse_items
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins import builtin
    from httpie.plugins import plugin_manager
    from httpie.version import __version__ as httpie_version
    from httpie.downloads import Downloader
    import requests
    import unittest
    import io
    import os
    import os.path

    home = os.path.expanduser("~")
    default_config_dir = os.path.join(home, ".config", "httpie")
    class TestRequest:
        def __init__(self, url, method, body, headers):
            self.url = url
            self.method = method
            self.body = body
            self.headers = headers


# Generated at 2022-06-11 23:26:42.110601
# Unit test for function main
def test_main():
    import io
    import sys
    import unittest.mock

    from httpie.status import ExitStatus

    class StdStreams:
        def __init__(self, stdin, stdout, stderr):
            self.stdin = stdin
            self.stdout = stdout
            self.stderr = stderr

    class MockStream:
        def __init__(self, underlying_value=None):
            self._underlying_value = underlying_value or io.StringIO()

        def write(self, value):
            self._underlying_value.write(value)

        def flush(self):
            self._underlying_value.flush()

        def isatty(self):
            return self._underlying_value.isatty()

        def read(self):
            return self._underlying_

# Generated at 2022-06-11 23:26:52.599015
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    import os
    from io import StringIO

    old_stdout = sys.stdout
    sys.stdout = StringIO()

    file_content = ['hello world', 'hello world', 'hello world', 'hello world', 'hello world', 'hello world', 'hello world', 'hello world', 'hello world', 'hello world', 'hello world', 'hello world']


# Generated at 2022-06-11 23:26:56.038080
# Unit test for function program
def test_program():
    import io

    args = ['--headers', 'Accept: text/html']
    stdout = io.StringIO()
    env = Environment(stdout=stdout)
    program(args, env)
    assert stdout.getvalue() == 'Accept: text/html\n'

# Generated at 2022-06-11 23:26:59.234943
# Unit test for function main
def test_main():
    args = ['http', '--x', '--y', '--debug', 'http://httpbin.org/get']
    assert main(args) == ExitStatus.SUCCESS



# Generated at 2022-06-11 23:27:10.214347
# Unit test for function main
def test_main():
    from ..output.indentation import Indentation


# Generated at 2022-06-11 23:28:21.369342
# Unit test for function program
def test_program():
    args = ["https://www.google.com","-p","--headers"]
    env=Environment()
    env.program_name = "http"
    args = decode_raw_args(args, env.stdin_encoding)
    plugin_manager.load_installed_plugins()
    from httpie.cli.definition import parser

    if env.config.default_options:
        args = env.config.default_options + args

    parsed_args = parser.parse_args(
        args=args,
        env=env,
    )

    try:
        exit_status = program(
            args=parsed_args,
            env=env,
        )
    except KeyboardInterrupt:
        env.stderr.write('\n')
        if include_traceback:
            raise
        exit_status = ExitStatus

# Generated at 2022-06-11 23:28:23.899257
# Unit test for function main
def test_main():
    args = ['--debug']
    exit_status = main(args=args, env=Environment.testing())
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:28:24.807288
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 23:28:25.854620
# Unit test for function program
def test_program():
    exit_status = main()
    assert exit_status == 0

# Generated at 2022-06-11 23:28:35.442064
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    import json
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.downloads import Downloader
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.config import HTTPieConfig
    from httpie.client import collect_messages
    from httpie.plugins import builtin
    from httpie.core import enhance_iter
    import time

    plugin_manager.get_instances = lambda: [
        plugin()
        for plugin in builtin.__all__ + [HTTPBasicAuth]
    ]

    # http --print=b --print=H --verbose --debug --body  http

# Generated at 2022-06-11 23:28:39.324571
# Unit test for function main
def test_main():
    try:
        assert main(['httpie', 'http://httpie.org']) == 0
    except SystemExit as e:
        if e.code != ExitStatus.SUCCESS:
            raise
    finally:
        print('Unit test complete!')


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 23:28:42.767612
# Unit test for function program
def test_program():
    args = ['--check-status', 'httpbin.org']
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-11 23:28:53.995332
# Unit test for function main
def test_main():
    # type: () -> None
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.context import EnvironmentDefault

    def get_env(raw_args):
        env = EnvironmentDefault()
        env.config.user_agent = DEFAULT_UA
        env.config.default_options = []
        main(args=raw_args, env=env)
        return env

    # error returns
    env = get_env(['--debug'])
    assert env.exit_status == ExitStatus.SUCCESS
    env = get_env(['--download', 'http://www.baidu.com/'])
    assert env.exit_status == ExitStatus.ERROR_TOO_MANY_REDIRECTS
    env = get_env(['http://127.0.0.1/'])


# Generated at 2022-06-11 23:28:56.503288
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    status = main(['-b'], parser)
    assert status == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:29:06.646724
# Unit test for function program
def test_program():
    from httpie.config import Config, DEFAULT_OPTIONS, DEFAULT_USER_CONFIG_DIR
    from httpie.context import Environment, EnvironmentConfig
    from httpie.cli.args import parse_args, parser
    #build the parsing
    env = Environment()
    config = Config(directory=DEFAULT_USER_CONFIG_DIR, config_file=None, env=env)
    env_config = EnvironmentConfig(env=env, config=config)

# Generated at 2022-06-11 23:29:38.308659
# Unit test for function program
def test_program():

    # GIVEN
    args = argparse.Namespace()
    args.headers = ['a']
    args.session = "httpie"
    args.config_dir = "~/.config/httpie"
    env = Environment()
    env.config = "~/.config/httpie"

    # WHEN
    program(args, env)

# Generated at 2022-06-11 23:29:44.630658
# Unit test for function program

# Generated at 2022-06-11 23:29:53.423399
# Unit test for function main
def test_main():
    import httpie.cli.config
    # The "main function"
    httpie.cli.config.Environment().stdin_encoding = 'utf-8'
    httpie.cli.config.Environment().stdout_isatty = True
    assert httpie.cli.main(args=['https://httpie.org/']) == ExitStatus.SUCCESS
    assert httpie.cli.main(args=['https://httpie.org/', '-b']) == ExitStatus.SUCCESS
    assert httpie.cli.main(args=['--debug']) == ExitStatus.SUCCESS
    assert httpie.cli.main(args=['--traceback']) == ExitStatus.ERROR
    assert httpie.cli.main(args=['-h']) == ExitStatus.ERROR

# Generated at 2022-06-11 23:30:04.299156
# Unit test for function program
def test_program():
    from httpie import config
    from httpie.cli.definition import parser

    config_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

    args=["http", "--auth=user:pass", "https://httpbin.org/basic-auth/user/pass"]

    parsed_args = parser.parse_args(
        args=args,
        env=Environment(config_dir=config_dir, stdout=sys.stdout, stderr=sys.stderr, stdin=sys.stdin,
                        stdin_isatty=sys.stdin.isatty(), stdout_isatty=sys.stdout.isatty())
    )


# Generated at 2022-06-11 23:30:04.852652
# Unit test for function program
def test_program():
    assert 1==1

# Generated at 2022-06-11 23:30:05.366366
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 23:30:14.153332
# Unit test for function main
def test_main():
    import sys
    import os
    import unittest
    from unittest import mock

    from httpie.cli.constants import DEFAULT_UA, DEFAULT_TIMEOUT
    from httpie.cli.constants import OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY
    from httpie.core import main
    from httpie.config import Config
    class Test_main(unittest.TestCase):
        def test_main(self):
            with mock.patch("sys.stdin.isatty", return_value=True):
                args = [
                    'GET',
                    '-v',
                    'https://www.google.com/search',
                    'q=httpie'
                ]

# Generated at 2022-06-11 23:30:16.730652
# Unit test for function program
def test_program():
    """
    Unit test for function program
    """
    result = program(args=argparse.ArgumentParser())
    assert result == ExitStatus.SUCCESS


# Generated at 2022-06-11 23:30:19.190370
# Unit test for function main
def test_main():
    env=Environment()
    env.program_name="http"
    args=["http", "-v", "https://httpbin.org/get"]
    assert main(args,env)==0

# Generated at 2022-06-11 23:30:29.091328
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    args = parser.parse_args(args=['https://google.com/'], env=Environment())
    assert program(args=args,env=Environment()) == 0 #correct address

    args = parser.parse_args(args=['https://google.com/'], env=Environment())
    assert program(args=args,env=Environment()) == 0 #correct address

    args = parser.parse_args(args=['http://google.com/'], env=Environment())
    assert program(args=args,env=Environment()) == 1 #wrong address

    args = parser.parse_args(args=['http://'.encode()], env=Environment())
    assert program(args=args,env=Environment()) == 1 #wrong address