

# Generated at 2022-06-11 23:23:41.236644
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:23:45.355562
# Unit test for function program
def test_program():
    from httpie import status
    
    def program_with_args(program_args, program_kwargs):
        args = parser.parse_args(args=program_args)
        program(args, **program_kwargs)
        return args
    return program_with_args


# Generated at 2022-06-11 23:23:47.451410
# Unit test for function program
def test_program():
    args = ['--debug']
    env = Environment()
    assert main(args=args, env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:23:50.547958
# Unit test for function program
def test_program():
    args = 'GET https://www.baidu.com/s?wd=snowleopard333'
    mark = program(args.split(' '),Environment())
    # print(mark)


# Generated at 2022-06-11 23:23:58.083104
# Unit test for function program
def test_program():
    from httpie.context import Environment
    from httpie.cli.parser import parser
    args = parser.parse_args(args=['--debug'], env=Environment())
    program(args, Environment())
    args = parser.parse_args(args=['--debug', '--pretty', 'all'], env=Environment())
    program(args, Environment())
    args = parser.parse_args(args=['--debug', '--pretty', 'all', 'https://httpbin.org/get'], env=Environment())
    program(args, Environment())

# Generated at 2022-06-11 23:24:08.332835
# Unit test for function main
def test_main():
    class TestEnv(Environment):
        """
        Environment that keeps output in memory.
        """
        def __init__(self):
            super(TestEnv, self).__init__()
            self.stdout = io.StringIO()
            self.stderr = io.StringIO()
    env = TestEnv()
    exit_status = main(args=['get', 'https://github.com/', 'Accept:'], env=env)
    assert exit_status == ExitStatus.SUCCESS
    assert 'HTTP 200'.encode() in env.stdout.getvalue()
    assert '<!DOCTYPE html>'.encode() in env.stdout.getvalue()



# Generated at 2022-06-11 23:24:14.019698
# Unit test for function main
def test_main():
    import platform
    import sys
    import pygments
    import requests
    assert httpie_version == httpie.__version__
    assert requests_version == requests.__version__
    assert pygments_version == pygments.__version__
    assert sys.version == platform.python_version()
    assert sys.executable == platform.system()

# Generated at 2022-06-11 23:24:21.207264
# Unit test for function main
def test_main():
    """
    This is a unit test for main.
    Take a look at the current output and make sure it's what you expect
    Now add (and fix) some tests below
    Make sure you always start with a test_ prefix for your function
    """
    # create an instance of the temporary file to write the output of the function to
    # start with a blank file for each test
    import tempfile
    f = tempfile.TemporaryFile(mode='w+t', encoding='utf-8')

# Generated at 2022-06-11 23:24:31.905437
# Unit test for function main
def test_main():
    # Unit test for function program
    import io
    import pytest
    import sys
    import unittest
    import unittest.mock
    from io import StringIO
    from httpie.cli.definition import parser
    from httpie.cli.utils import args_from_env
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.status import ExitStatus

    # Unit test for function program
    test_data = [
        ["httpie.py", "httpbin.org/encoding/utf8", "--output=json"],
        ["httpie.py", "httpbin.org/encoding/utf8", "--output=json"]
    ]


# Generated at 2022-06-11 23:24:41.069837
# Unit test for function main
def test_main():
    stdout = io.BytesIO()
    stderr = io.BytesIO()
    env = Environment(stdout=stdout, stderr=stderr)
    #args = ['-u', 'http://localhost:8000/post', 'id=1', 'name=2', '-v']
    args = ['-u', 'https://www.baidu.com', 'id=1', 'name=2', '-v']
    exit_status = main(args=args, env=env)
    print(stderr.getvalue())
    print(stdout.getvalue())


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 23:26:56.420404
# Unit test for function main
def test_main():
    class StdOutBytesIO(BytesIO):
        def write(self, x):
            super().write(x.encode('utf8'))

    class StdErrBytesIO(BytesIO):
        def write(self, x):
            super().write(x.encode('utf8'))

    class stdinBytesIO(BytesIO):
        def write(self, x):
            super().write(x.encode('utf8'))

    env = Environment(
        stdin=stdinBytesIO(b'{"key": "value"}'),
        stdout=StdOutBytesIO(),
        stderr=StdErrBytesIO(),
        vars={},
    )

    # Error
    result = main(args=['localhost', '-d', 'key=value'], env=env)

# Generated at 2022-06-11 23:26:59.146560
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args([])
    env = Environment()
    program(args=args, env=env)

# Generated at 2022-06-11 23:27:01.155753
# Unit test for function main
def test_main():
    # TODO: test function main

    #assert 0 == main(["httpie", "http://google.com"], {})
    pass



# Generated at 2022-06-11 23:27:08.904820
# Unit test for function main
def test_main():
    def check(decode_raw_args, stdin_encoding):
        arg = argparse.Namespace()
        arg.decode_raw_args = decode_raw_args
        arg.stdin_encoding = stdin_encoding
        env = Environment()
        main(arg, env)
    check(1, 1)
    check('', '')
    check(False, False)
    check(True, True)

if __name__ == "__main__":  # pragma: no cover
    main()

# Generated at 2022-06-11 23:27:10.213788
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        sys.exit(main())

# Generated at 2022-06-11 23:27:12.156157
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args([])
    env = Environment()
    assert program(args, env) == 1

# Generated at 2022-06-11 23:27:21.642290
# Unit test for function main
def test_main():
    import argparse
    import os
    import subprocess
    import urllib
    import pytest

    class MockArgumentParser:
        def __init__(self, args):
            self.args = args
        def add_argument(self, *args, **kwargs): pass
        def parse_args(self): return self.args

    class MockEnvironment:
        def __init__(self):
            self.program_name = 'http'
            self.stdin_encoding = 'utf8'
            self.stdout = self
            self.stdout_isatty = False
            self.stderr = sys.stderr

    class MockStandardOutput:
        def __init__(self):
            self.buffer = self

# Generated at 2022-06-11 23:27:23.741591
# Unit test for function program
def test_program():
    assert program(argparse.Namespace(output_options=['all']), Environment()) == 0

################################################################################

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-11 23:27:27.918824
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    env = Environment()
    env.stdout_isatty = True
    args = parser.parse_args(['https://httpbin.org/get'], env=env)
    program(args, env)
    assert len(env.http_log_messages) == 2

# Generated at 2022-06-11 23:27:38.962206
# Unit test for function main
def test_main():
    assert main(["/tmp/httpie/httpie/httpie-0.5.0-py2.py3-none-any.whl"]) == ExitStatus.ERROR
    assert main(["/tmp/httpie/httpie/httpie-0.5.0-py2.py3-none-any.whl","https://www.google.com/"]) == ExitStatus.ERROR
    assert main(["/tmp/httpie/httpie/httpie-0.5.0-py2.py3-none-any.whl","http://httpbin.org/status/200,404"]) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:29:00.468213
# Unit test for function program
def test_program():
    from httpie.cli.parser import parser

    # just for testing purpose
    args = parser.parse_args(['--debug', 'www.baidu.com'])
    env = Environment()

    # use the test_data to test the program

# Generated at 2022-06-11 23:29:02.826837
# Unit test for function program
def test_program():
    assert main(['httpie', '-u', 'user:password', 'https://google.com']) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:29:04.025635
# Unit test for function main
def test_main():
    # main()
    main()



# Generated at 2022-06-11 23:29:14.867883
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser

    env = Environment()

    program_name = 'http'
    arguments = ['--json', '--headers', '--form', 'https://httpbin.org/post', 'key1=value1', 'key2=value2']
    exit_status = main(args=[program_name] + arguments, env=env)

    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:29:24.676965
# Unit test for function program
def test_program():
    import argparse
    import io
    import os
    import sys

    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.status import http_status_to_exit_status

    from httpie.cli.definition import parser

    args_parsed = parser.parse_args(
        args=['--debug', 'GET', 'https://httpie.org/index.html'],
        env=Environment(config_dir='test_program_env')
    )

    orig_stdout = sys.stdout
    orig_stderr = sys.stderr

    # redirect stdout and stderr to avoid printing to stdout or stderr during the test
    sys.stdout = io.StringIO

# Generated at 2022-06-11 23:29:26.282158
# Unit test for function main
def test_main():
    result = main(['httpie', '--debug', '--traceback'])
    assert result == ExitStatus.ERROR


# Generated at 2022-06-11 23:29:27.131175
# Unit test for function program
def test_program():
	print("")

# Generated at 2022-06-11 23:29:31.657631
# Unit test for function main
def test_main():
    from httpie.context import Environment
    import requests
    import requests_mock

    env = Environment()
    env.program_name = "httpie"
    args = ['www.google.com', '-v']

    exit_status = main(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS
    
    
    

# Generated at 2022-06-11 23:29:41.279079
# Unit test for function main
def test_main():
    assert main(["http", "get"]) == 0
    assert main(["http", "get", "--help"]) == 0
    assert main(["http", "get", "--debug"]) == 0
    assert main(["http", "get", "--input-raw-json"]) == 1
    assert main(["http", "get", "--check-status"]) == 1
    assert main(["http", "get", "--download", "https://jsonplaceholder.typicode.com/todos/1"]) == 0
    assert main(["http", "get", "https://jsonplaceholder.typicode.com/todos/1"]) == 1
    assert main(["http", "get", "https://httpbin.org/get"]) == 0

# Generated at 2022-06-11 23:29:49.907615
# Unit test for function program
def test_program():
    import builtins
    from mock import Mock
    from httpie.cli.definition import parser

    args = parser.parse_args(args=["httpie", "--help"])

# Generated at 2022-06-11 23:31:23.315638
# Unit test for function program
def test_program():
    """
    Test for program.

    Check for the functioning of the main program.

    """
    assert program([], Environment()) == ExitStatus.SUCCESS
    assert program(["--download"], Environment()) == ExitStatus.SUCCESS
    assert program(["--download", "--check-status"], Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:31:34.409780
# Unit test for function program
def test_program():
    output_options = (OUT_REQ_HEAD, OUT_RESP_BODY)
    env = Environment(
        stdin_isatty=True,
        stdout_isatty=False,
        stderr_isatty=True,
        stdout=sys.stdout,
        stderr=sys.stderr,
        stdin=sys.stdin,
    )
    parser = argparse.ArgumentParser(prog='http', description='cURL-like tool for humans.')
    parser.add_argument('--output-options', action='store', choices=('H', 'BHb'), type=str, default='HBb')
    args = parser.parse_args()
    args.output_options = output_options

# Generated at 2022-06-11 23:31:45.190073
# Unit test for function main
def test_main():
    from httpie.context import Environment
    from test.test_helpers import http, get_file_size, load_json
    # test requests
    env = Environment()
    os.makedirs("./output_files", exist_ok=True)
    # test requests
    assert main(["http", "http://localhost:7777/index.html"]) == ExitStatus.SUCCESS
    assert main(["http", "http://localhost:7777/index.html", "--download"]) == ExitStatus.SUCCESS
    assert main(["http", "http://localhost:7777/index.html", "--download", "-O"]) == ExitStatus.SUCCESS
    assert get_file_size("./index.html") == get_file_size("../tests/output_files/index.html")

# Generated at 2022-06-11 23:31:46.655518
# Unit test for function program
def test_program():
    args = []
    env = Environment()
    assert program(args=args, env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:31:55.526041
# Unit test for function main
def test_main():
    assert main() == 0
    assert main(args=['GET', 'http://example.com']) == 0
    assert main(args=['--help']) == 0
    assert main(args=['--version']) == 0
    assert main(args=['--debug']) == 0
    assert main(args=['GET', 'http://example.com', '--help']) == 0
    assert main(args=['GET', 'http://example.com', '--version']) == 0
    assert main(args=['GET', 'http://example.com', '--debug']) == 0
    assert main(args=['GET', 'http://example.com', '-h']) == 0
    assert main(args=['GET', 'http://example.com', '-v']) == 0


# Generated at 2022-06-11 23:32:03.505961
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace()
    args.output_options = ['all']
    args.output_file = None
    args.output_file_specified = False
    args.output_file_path = None
    args.check_status = False
    args.download = False
    args.download_resume = False
    args.follow = False
    args.method = 'GET'
    args.json = None
    args.stdin_json = False
    args.pretty = 'all'
    args.style = None
    args.style_output_file_path = None
    args.style_override = False
    args.output_dir = None
    args.output_dir_options = None
    args.output_dir_separator = None
    args.output_dir_fields = None


# Generated at 2022-06-11 23:32:11.872405
# Unit test for function main
def test_main():
    args = ['https://postman-echo.com/get', '-f', '-b', 'd:1']
    # args = ['https://postman-echo.com/get', 'json', '-f', '-b', 'd:1']
    # args = ['--debug', 'https://postman-echo.com/get', '-f', '-b', 'd:1']
    print('sys.argv = ', sys.argv)
    print('args = ', args)
    exit_status = main(args)
    print('exit_status = ', exit_status)


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 23:32:21.359129
# Unit test for function program
def test_program():
    assert program(['httpie', '--version']) not in [0, 1]
    assert program(['httpie', '--version', '--check-status']) not in [0, 1]
    assert program(['httpie', '--version', '--check-status', '--quiet']) not in [0, 1]
    assert program(['httpie', '--version', '--check-status', '--quiet', '--output=-']) not in [0, 1]
    assert program(['httpie', '--version', '--check-status', '--output=-']) not in [0, 1]


if __name__ == '__main__':
    exit_status = main()
    sys.exit(exit_status)

# Generated at 2022-06-11 23:32:30.300494
# Unit test for function main
def test_main():
    assert main(["http", "-v"]) == 0
    assert main(["http", "--debug"]) == 0
    assert main(["http", "--help"]) == 0
    assert main(["http", "--help-headers"]) == 0
    assert main(["http", "--version"]) == 0
    assert main(["http", "www.google.com"]) == 0
    assert main(["http", "POST", "www.google.com"]) == 0
    assert main(["http", "PUT", "www.google.com"]) == 0
    assert main(["http", "GET", "www.google.com"]) == 0
    assert main(["http", "HEAD", "www.google.com"]) == 0