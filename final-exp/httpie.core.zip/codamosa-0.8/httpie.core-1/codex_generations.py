

# Generated at 2022-06-11 23:23:21.886114
# Unit test for function program
def test_program():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.compat import bytes_
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO

    env = Environment(
        stdin=StdoutBytesIO(),
        stdin_isatty=False,
        stdout=StdoutBytesIO(),
        stdout_isatty=False,
    )
    args = argparse.Namespace()
    args.headers = KeyValueArg([]).parse(env=env, value=['User-Agent: HTTPie v1.0'])
    args.method = 'GET'
    args.output_options = []
    args.url = 'http://example.org'

    program(args=args, env=env)

    assert env.stdout.getvalue()

# Generated at 2022-06-11 23:23:22.874110
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:23:27.292386
# Unit test for function program
def test_program():
    args = ['http', 'https://www.google.com']
    env = Environment()
    exit_status = program(args,env)
    assert exit_status == ExitStatus.SUCCESS


if __name__ == '__main__':
    exit_status = main()
    sys.exit(exit_status)

# Generated at 2022-06-11 23:23:31.062139
# Unit test for function program
def test_program():
    program('http --ignore-stdin httpbin.org/get', env)


if __name__ == '__main__':
    # print(sys.argv)
    print(main())

# Generated at 2022-06-11 23:23:32.446994
# Unit test for function program
def test_program():
    assert program(args=['--debug'], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:23:34.799142
# Unit test for function program
def test_program():
    program([])
    program(['www.baidu.com'])
    program(['-v'])
    program(['--debug'])


# Generated at 2022-06-11 23:23:46.992527
# Unit test for function program
def test_program():
    from io import BytesIO
    from httpie.cli.definition import parser
    from httpie import ExitStatus
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    env = Environment()
    url = 'https://httpbin.org/'
    status_url = 'https://httpbin.org/status/200'
    headers = {"Some":"Header"}
    payload = {'key': 'value'}
    payloaddata = b'\x80\x02cecho.echo\nEcho\nq\x00)\x81q\x01.'
    data = "data"
    form = "form"
    download = "download.json"
    follow = True
    output_file_specified = False
    quiet = True
    params = {'some':'param'}
    output_options

# Generated at 2022-06-11 23:23:51.495365
# Unit test for function main
def test_main():
    env=Environment()
    assert main(['httpie', '--version'], env) == ExitStatus.SUCCESS
    assert main(['httpie', '--headers'], env) == ExitStatus.ERROR_CLI
    assert main(['httpie', 'httpbin.org'], env) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:24:00.856803
# Unit test for function main
def test_main():
    # TODO: Move to httpie.test.test_main
    from io import BytesIO
    from httpie.utils import MockEnvironment

    # Py3 Only
    # from argparse import Namespace

    def get_output(args=None, env=None):
        stdout = BytesIO()
        stderr = BytesIO()
        if args is None:
            args = []
        if env is None:
            env = MockEnvironment(stdout=stdout, stderr=stderr)
        main(args=args, env=env)
        return stdout.getvalue(), stderr.getvalue()

    # TODO: Be less fragile!

    # Should not output anything if no args are given.
    assert get_output() == (b'', b'')

    # Should print usage when given `--help

# Generated at 2022-06-11 23:24:09.534870
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser()
    parser.add_argument('-p', '--program')
    parser.add_argument('-b', '--binary')
    parser.add_argument('-o', '--output')
    parser.add_argument('-T', '--timeout')
    parser.add_argument('--check-status')
    parser.add_argument('--follow')
    args = parser.parse_args()

    main(args=args)


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:25:05.586835
# Unit test for function program
def test_program():
    from tests.helpers import http
    from tests.helpers import httpbin
    from httpie import ExitStatus
    from httpie.cli import env
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parser

    import requests

    env.config.default_options = [
        '--print',
        'H',
        '--print',
        'B',
        '--check-status',
        '--follow',
    ]
    env.config.output_options_specified = True

    # TODO: Use a mock HTTP server here.
    args = parser.parse_args(['--output-file=/dev/null', httpbin.url + '/status/200'])
    assert program(args=args, env=env) == ExitStatus.SUCCESS


# Generated at 2022-06-11 23:25:13.728190
# Unit test for function program
def test_program():
    import httpie.cli.parser
    import httpie.cli.args
    import httpie.cli.parser
    import httpie.cli.constants
    import httpie.cli.argtypes
    import httpie.cli.exceptions
    from httpie.client import JSON_ACCEPT
    from httpie.models import ContentType, Request, Response
    import httpie.compression
    import httpie.downloads
    import httpie.plugins
    import httpie.plugins.builtin
    import httpie.output.streams
    import httpie.output.formatters.colors
    import httpie.status
    import httpie.context
    import httpie.downloads
    import httpie.output.streams
    import httpie.cli.formatter
    from pygments import lexers, util as pyg_util
    import http

# Generated at 2022-06-11 23:25:19.419763
# Unit test for function program
def test_program():
    import unittest
    import httplib2
    class Test(unittest.TestCase):
        def test_program(self):
            h = httplib2.Http()
            resp = h.request('http://www.example.org', 'GET')[0]
            self.assertEqual( resp.get('status'), '200')
    unittest.main()


# Generated at 2022-06-11 23:25:21.758280
# Unit test for function main
def test_main():
    main(['http', '--version'])
    main(['http', '--debug'])
    main(['http', '--debug', '--traceback'])

# Generated at 2022-06-11 23:25:30.228953
# Unit test for function program

# Generated at 2022-06-11 23:25:31.766024
# Unit test for function program
def test_program():
    exit_status = program(
        args=None,
        env=None,
    )

    assert exit_status == 0

# Generated at 2022-06-11 23:25:41.223076
# Unit test for function main
def test_main():
    try:
        from io import StringIO, BytesIO
        from unittest import mock
    except ImportError:
        return
    utf8 = 'utf-8'
    stdout = BytesIO()
    stdin = BytesIO()
    stdin.buffer = stdin
    stdout.buffer = stdout
    stdin_encoding = utf8
    stderr = StringIO()
    env = Environment(
        stdin=stdin, stdout=stdout, stderr=stderr, stdin_encoding=utf8)
    print(env.is_windows)
    import shlex
    args_str = ' '.join(['--ignore-stdin', '--debug', 'http://httpbin.org/get'])
    args_raw = shlex.split(args_str)
   

# Generated at 2022-06-11 23:25:42.875810
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    import temppathlib
    # TODO: Refactor `progr

# Generated at 2022-06-11 23:25:53.280491
# Unit test for function main
def test_main():
    import pytest
    import io
    import httpie.cli.argtypes as argtypes
    io = io.StringIO()
    env = Environment(stdout=io, stderr=io)
    with pytest.raises(SystemExit):
        main(args=['http', '--foo'], env=env)
        assert False

    io = io.getvalue()
    assert 'unrecognized arguments' in io

    io = io.StringIO()
    env = Environment(stdout=io, stderr=io)
    with pytest.raises(SystemExit):
        main(args=['http', '--auth', '123'], env=env)
        assert False

    io = io.getvalue()
    assert 'invalid value' in io

    # Feel free to add more tests

# Generated at 2022-06-11 23:26:03.001573
# Unit test for function program
def test_program():
    import os
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.context import Environment
    from httpie.core import program
    from httpie.output.writer import write_message


# Generated at 2022-06-11 23:26:29.459530
# Unit test for function program
def test_program():

    import os
    os.system("http -p /Users/mak.ho/Documents/project/httpie/packages/httpie/test_program.txt -b https://github.com/psf/requests")



# Generated at 2022-06-11 23:26:34.095483
# Unit test for function program
def test_program():
    from httpie.cli.constants import DEFAULT_OUTPUT_OPTIONS

    from httpie.client import (
        build_request_from_args,
        load_json_or_form_data_into_json_or_form_data_kwargs,
    )
    from httpie.compat import str
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.input.v1 import FluentRequestParser
    from httpie.plugins import plugin_manager
    from httpie.status import http_status_to_exit_status

    plugin_manager.load_installed_plugins()


# Generated at 2022-06-11 23:26:35.502152
# Unit test for function program
def test_program():
    program(""" --check-status http://www.google.com""", Environment())

# Generated at 2022-06-11 23:26:39.038265
# Unit test for function program
def test_program():
    assert ExitStatus.ERROR == 1
    assert ExitStatus.ERROR_TIMEOUT == 26
    assert ExitStatus.ERROR_TOO_MANY_REDIRECTS == 29
    assert ExitStatus.ERROR_CTRL_C == 130
    assert ExitStatus.SUCCESS == 0

# Generated at 2022-06-11 23:26:42.811346
# Unit test for function program
def test_program():
    args = ['https://httpbin.org/post', 'joke=one']
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    program(args, env)
    return True

# Generated at 2022-06-11 23:26:45.484264
# Unit test for function program
def test_program():
    class Env:
        class Config:
            @property
            def directory(self):
                return 'dir'
        env = Env()
        args = Env()
        program(env,args)


# Generated at 2022-06-11 23:26:55.923684
# Unit test for function program
def test_program():
    import pytest
    from requests.exceptions import MissingSchema
    from httpie.cli.definition import parser

    # Catches the system exit
    with pytest.raises(SystemExit):
        # Tests for a successful http call
        args = parser.parse_args(args=['-v', 'https://httpbin.org/get'], env=Environment())
        program(args=args, env=Environment())

    # Catches the system exit
    with pytest.raises(SystemExit):
        # Tests for a successful http call
        args = parser.parse_args(args=['-v', 'https://httpbin.org/get'], env=Environment())
        args.output_options.append("-s")
        program(args=args, env=Environment())

    # Catches the system exit

# Generated at 2022-06-11 23:27:07.262968
# Unit test for function main
def test_main():
    import io
    import os
    import sys
    import unittest
    from httpie import config
    from httpie.cli import constants
    class TestMain(unittest.TestCase):
        # Tests for function main()

        def setUp(self):
            self.env = Environment()
            self.env.config = config.Config(
                config_dir=os.path.join(constants.ROOT_DIR, "tests", "configs", "main")
            )
            self.env.stdout = io.StringIO()
            self.env.stdin = io.StringIO()
            self.env.stderr = io.StringIO()
            self.env.stdin_encoding = "utf-8"
        def tearDown(self):
            self.env.stdout.close()
            self.env

# Generated at 2022-06-11 23:27:16.762385
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace(check_status=False, 
                              debug=False, 
                              download=False, 
                              download_resume=False, 
                              follow=False, 
                              output_file=None, 
                              output_file_specified=False, 
                              output_options=[OUT_RESP_BODY], 
                              quiet=False, 
                              traceback=False, 
                              verbose=0,
                              headers=[],
                              method=None,
                              output_format=None,
                              url=None,
                              pattern_search_word=None)
    assert program(args, env) == ExitStatus.SUCCESS

"""
The following code is for testing 
"""


# Generated at 2022-06-11 23:27:19.326878
# Unit test for function program
def test_program():
    from httpie.cli.parser import parser
    args = parser.parse_args(['https://google.com', '--download'])
    program(args, Environment())

# Generated at 2022-06-11 23:28:28.334303
# Unit test for function program
def test_program():
    import io
    import io
    import unittest
    import requests
    from httpie.context import Environment
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.definition import parser
    from httpie import ExitStatus
    from httpie.cli.parser import get_parser
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import ERROR_OUTPUT_ENCODING_UTF8
    from httpie.compat import is_windows

    class MessageCollector():

        def __init__(self):
            self.messages = []

        def collect(self, req_resp):
            self.messages.append(req_resp)


# Generated at 2022-06-11 23:28:35.277847
# Unit test for function program
def test_program():
    class FakeEnv:
        def __init__(self):
            self.stderr = open(os.devnull, 'w')
            self.stdout = open(os.devnull, 'w')
            self.config = None
    class FakeArgs:
        def __init__(self):
            self.output_options = []
            self.output_file = None
            self.output_file_specified = None
    args = FakeArgs()
    env = FakeEnv()
    return program(args=args, env=env)


# Generated at 2022-06-11 23:28:37.423339
# Unit test for function main
def test_main():
    exit_status = main(['httpie', '--debug'])
    assert exit_status == ExitStatus.SUCCESS



# Generated at 2022-06-11 23:28:40.253988
# Unit test for function program
def test_program():
    from httpie.context import Environment
    from httpie.cli.parser import parser
    env = Environment()
    args = parser.parse_args([
    '--check-status',
    'https://httpbin.org/get'
    ], env)
    program(args, env)


# Generated at 2022-06-11 23:28:52.109175
# Unit test for function program
def test_program():
    args = [
        'https://www.python.org',
        '--timeout=0.001'
    ]

    env1 = Environment()
    env1.stdout_isatty = True
    env1.stdout_encoding = 'utf-8'
    env1.stdout = StringIO()
    env1.stderr = StringIO()

    exit_status = main(args, env1)
    assert exit_status == ExitStatus.ERROR_TIMEOUT

    env2 = Environment()
    env2.stdout_isatty = False
    env2.stdout_encoding = 'utf-8'
    env2.stdout = StringIO()
    env2.stderr = StringIO()

    exit_status = main(args, env2)
    assert exit_status == ExitStatus.ERROR_TIME

# Generated at 2022-06-11 23:29:00.626808
# Unit test for function main
def test_main():
    import os
    import json
    import shlex
    from io import TextIOWrapper

    import pytest
    from requests import Request

    from httpie import ExitStatus

    from httpie.compat import BytesIO, is_windows, urlopen, HTTPError
    from httpie.cli.definition import parser
    from httpie.client import JSON_ACCEPT, JSON_CONTENT_TYPES
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.core import main as httpie
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    DEV_NULL = open(os.devnull, 'w')
    STDIN_BYTES = b'stdin bytes'
    STDIN_TEXT = STDIN_BYTES.decode('utf8')


# Generated at 2022-06-11 23:29:11.379000
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import platform
    from httpie.context import Environment
    import httpie.output.writers as ow
    import httpie.input.argtypes as argtypes
    from httpie import plugins

    # If httpbin is down, skip unit test
    from httpie.input import httpbin_org
    from urllib3.exceptions import MaxRetryError
    try:
        httpbin_org.get(timeout=2)
    except (MaxRetryError, requests.ConnectTimeout):
        print('Skipping test_main because httpbin is down')
        return


# Generated at 2022-06-11 23:29:17.861346
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    env = Environment()
    args.output_options = ['all']
    r = requests.Response()
    r.headers = {}
    r.status_code = 200
    messages = collect_messages(args=args, config_dir=env.config.directory)
    messages.append(r)
    assert program(args, env) == ExitStatus.SUCCESS


# Generated at 2022-06-11 23:29:26.342464
# Unit test for function program
def test_program():
    import os
    import pytest
    from pytest import raises
    from httpie.cli.definition import parser
    from httpie.cli.parser import ParseResult
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPDigestAuth
    import click

    ret = program(args=['https://httpbin.org/get'], env=Environment())
    assert ret == ExitStatus.SUCCESS
    with raises(requests.Timeout):  # timeout
        program(args=['httpbin.org', '--timeout', '0.001'], env=Environment())
    with raises(requests.TooManyRedirects):  # max_redirects
        program(args=['httpbin.org', '--max-redirects', '0'], env=Environment())

# Generated at 2022-06-11 23:29:27.270910
# Unit test for function program
def test_program():
    assert program([], Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:30:15.510990
# Unit test for function main
def test_main():
    import io
    from httpie.cli.constants import (
        OUT_RESP_BODY, OUT_REQ_BODY,
        OUT_REQ_HEAD, OUT_RESP_HEAD
    )
    from httpie.cli.parser import Config

    # Simple usage test, no output
    # env = Environment()
    # exit_status = main(args=['https://httpbin.org/get'], env=env)
    # assert exit_status == ExitStatus.SUCCESS
    # assert env.stderr.getvalue() == ''
    # assert env.stdout.getvalue() == ''

    # Simple usage test, stdout in windows
    # env = Environment(stdin=io.BytesIO(), stdout=io.StringIO(), stderr=io.StringIO())
    # exit_status = main(

# Generated at 2022-06-11 23:30:22.242631
# Unit test for function program
def test_program():
    from httpie import ExitStatus
    
    def test_preflight_redirect():
        output = program(
            args=[
                '--auth', 'testuser:testpass',
                '--verify', 'no',
                '--max-redirects=0',
                'OPTIONS', 'http://httpbin.org/hidden-basic-auth/testuser/testpass'
            ],
            env=Environment()
        )
        assert output == ExitStatus.SUCCESS

    test_preflight_redirect()

test_program()

# Generated at 2022-06-11 23:30:27.862362
# Unit test for function main
def test_main():
    # TODO Fix the test to run properly
    env: Environment = Environment()
    args: List[str] = [
        "https://www.python.org/",
    ]
    exit_status = main(args, env)
    assert type(exit_status) is ExitStatus
    assert exit_status == 1


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:30:31.264145
# Unit test for function main
def test_main():
    args = ['http', 'https://httpbin.org/get', '--json', '-v']
    assert main(args) == ExitStatus.SUCCESS


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:30:32.563812
# Unit test for function main
def test_main():
    # Test that the main function runs correctly
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:30:33.808679
# Unit test for function main
def test_main():
    def test():
        print("Hello")
    main(test)

# Generated at 2022-06-11 23:30:42.038787
# Unit test for function main
def test_main():
    import unittest
    import traceback
    from io import StringIO
    from httpie.client import collect_messages
    from httpie.compat import is_windows
    from httpie.downloads import Downloader
    from httpie.plugins import AuthPlugin, FormatterPlugin, TransportPlugin
    from httpie.plugins.builtin import (
        HTTPBasicAuth,
        HTTPDigestAuth,
        HTTPExpectHeader,
        HTTPHeader,
        HTTPTrace,
        HTTPiePlugin,
        MultipartFormData
    )
    from httpie.plugins.manager import DEFAULT_PLUGINS

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.env = Environment()

        def tearDown(self):
            import shutil

# Generated at 2022-06-11 23:30:52.170266
# Unit test for function program
def test_program():
    """
    Verify that HTTPie can get correct HTTP status code from a test website
        https://httpstatuses.com/200
    """
    sout = io.StringIO()

    class Environment(object):
        class Config(object):
            class directory(object):
                class httpie(object):
                    quiet = False
                    download_resume = False
        config = Config()
        stdin = None
        stdin_isatty = False
        stdout = sout
        stdout_isatty = False
        stderr = None
        program_name = "httpie"

    # Some simple tests

# Generated at 2022-06-11 23:30:53.725144
# Unit test for function program
def test_program():
    pass

if __name__ == '__main__':
    sys.exit(main())  # pragma: no cover

# Generated at 2022-06-11 23:31:02.905542
# Unit test for function main
def test_main():
    env = Environment()
    env.config = mock.MagicMock()
    env.config.default_options = ['--timeout=3']
    env.config.directory = '/tmp/directory'
    env.log = mock.MagicMock()
    env.stdin_encoding = 'utf8'
    env.stdin = mock.MagicMock()
    env.stdin.encoding = 'utf8'
    env.stdout = mock.MagicMock()
    env.stderr = mock.MagicMock()

    # test normal exit
    args = ['http', '--debug', 'https://httpbin.org/']

# Generated at 2022-06-11 23:32:09.075000
# Unit test for function program
def test_program():
    from httpie.cli.parser import parser
    from httpie.output.streams import StreamPrinter
    from tests.helpers import httpbin_both, httpbin_secure
    env = Environment()
    args = parser.parse_args(['--check-status', httpbin_both + '/get'], env)
    program(args, env)
    assert env.output.last_status_code == 200
    args = parser.parse_args(['--check-status', httpbin_both + '/get', '-o', 'json'], env)
    program(args, env)
    assert env.output.last_status_code == 200
    env.output = StreamPrinter()
    args = parser.parse_args([httpbin_secure + '/get'], env)
    program(args, env)
    assert env.output.last

# Generated at 2022-06-11 23:32:17.909018
# Unit test for function program
def test_program():
    env = Environment()
    args = ['http', 'get', 'https://us.httpbin.org/get']

# Generated at 2022-06-11 23:32:27.489176
# Unit test for function main
def test_main():
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.status import ExitStatus
    from httpie.compat import is_windows

    # Mock functions
    def mock_print_debug_info(env: Environment):
        print('debug info')

    def mock_main(args: List[str], env=Environment()):
        print(args, env)
        return ExitStatus.ERROR

    # Save the real functions to restore after
    print_debug_info_original = print_debug_info
    main_original = main


# Generated at 2022-06-11 23:32:36.532111
# Unit test for function program
def test_program():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.plugins import builtin

    assert ExitStatus.SUCCESS == program(args=['GET', 'http://httpbin.org/get'], env=Environment())
    assert ExitStatus.ERROR == program(args=['INVALID_METHOD', 'http://httpbin.org/get'], env=Environment())
    assert ExitStatus.ERROR_TIMEOUT == program(args=['GET', 'http://httpbin.org/delay/2'], env=Environment(timeout=0.01))

    args = [
        'GET',
        'http://httpbin.org/redirect/2',
        KeyValueArg('--max-redirects', '0'),
    ]