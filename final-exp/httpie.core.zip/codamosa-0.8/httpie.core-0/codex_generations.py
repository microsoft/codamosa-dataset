

# Generated at 2022-06-11 23:23:26.831772
# Unit test for function main
def test_main():
    class MockEnv:
        program_name = "http"
        stdin_encoding = "utf8"
        config = Config()
        stdout = sys.stdout
        stderr = sys.stderr
    assert ExitStatus.SUCCESS == main(args=['--debug'], env=MockEnv())
    assert ExitStatus.SUCCESS == main(args=['GET', 'https://httpbin.org/get'], env=MockEnv())
    assert ExitStatus.SUCCESS == main(args=['GET', 'https://httpbin.org/status/200'], env=MockEnv())
    assert ExitStatus.ERROR == main(args=['GET', 'https://httpbin.org/status/404'], env=MockEnv())

# Generated at 2022-06-11 23:23:37.063746
# Unit test for function program
def test_program():
    assert main() == ExitStatus.ERROR
    assert main(["http", "https://jsonplaceholder.typicode.com/posts/1"]) == ExitStatus.SUCCESS
    assert main(["http", "https://jsonplaceholder.typicode.com/posts/1", "--download"]) == ExitStatus.SUCCESS
    assert main(["http", "https://jsonplaceholder.typicode.com/posts/1", "--download", "--output", "json-1.json"]) == ExitStatus.SUCCESS
    assert main(["http", "https://jsonplaceholder.typicode.com/posts/1", "--download", "--output", "json-1.json", "--check-status"]) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:23:48.395232
# Unit test for function main
def test_main():
    import os
    from unittest.mock import patch
    from httpie.output.streams import StdoutBytesIO, StderrBytesIO

    args = ['http', 'httpbin.org/get']
    stdout = StdoutBytesIO()
    stderr = StderrBytesIO()

# Generated at 2022-06-11 23:23:49.686293
# Unit test for function main
def test_main():
    exit_stat = main()
    return exit_stat


# Generated at 2022-06-11 23:23:59.738847
# Unit test for function program
def test_program():
    import os
    import tempfile
    from httpie import __version__ as httpie_version
    from httpie.core import main as core_main
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.cli.parser import parser
    from httpie import ExitStatus
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins import plugin_manager

    args = ['--auth-type=httpie', '--auth=user:password', '--download', 'GET', 'http://httpbin.org/get']
    # args = ['--download', 'GET', 'http://httpbin.org/get']

    config_dir = os.path.join(os.path.dirname(__file__), '../../httpie')

# Generated at 2022-06-11 23:24:12.421040
# Unit test for function main
def test_main():
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()
    main(['httpie', '--debug', 'https://www.httpie.org/'])
    output = sys.stdout.getvalue().strip()
    error = sys.stderr.getvalue().strip()
    with open('./HTTPie/test_helpers/raw_output/debug_info.txt', 'r') as expected:
        expected_output = expected.read().strip()
    with open('./HTTPie/test_helpers/raw_output/debug_error.txt', 'r') as expected_error:
        expected_error = expected_error.read().strip()
    assert output == expected_output

# Generated at 2022-06-11 23:24:14.063118
# Unit test for function main
def test_main():
    # The unit test for function main can be defined here
    pass


# Generated at 2022-06-11 23:24:19.560546
# Unit test for function main
def test_main():
    import os
    import tempfile

    tmpdir = tempfile.mkdtemp()

    # Test http
    with open(tmpdir + '/test.txt', 'w+') as tmpfile:
        curdir = os.getcwd()
        os.chdir(tmpdir)
        main(['http', 'http://httpbin.org/get'], env=Environment())
        os.chdir(curdir)

test_main()

# Generated at 2022-06-11 23:24:30.617457
# Unit test for function main
def test_main():
    from httpie.cli.debug import debug
    from httpie.status import ExitStatus

    import os

    import contextlib
    import io
    import sys

    @contextlib.contextmanager
    def capture_debug_info(*, env=os.environ, program_name=None) -> io.StringIO:
        stdout = sys.stdout
        stderr = sys.stderr

# Generated at 2022-06-11 23:24:31.187123
# Unit test for function main
def test_main():
     assert main() == 0

# Generated at 2022-06-11 23:26:01.743463
# Unit test for function main
def test_main():
    import argparse

# Generated at 2022-06-11 23:26:12.380626
# Unit test for function main
def test_main():
    from httpie import ExitStatus
    # main() performs a system exit, so we'd like to suppress that.
    def mock_exit(self, *args, **kwargs):
        pass
    from httpie.cli.constants import AUTHORS
    from httpie.context import Environment
    import unittest
    class MyTestCase(unittest.TestCase):
        @unittest.mock.patch("httpie.cli.program.sys.exit")
        def test_basic(self, mock_sys_exit):
            def mock_write(self, *args, **kwargs):
                pass
            mock_sys_exit.side_effect = mock_exit
            env = Environment()
            env.stderr.write = mock_write
            env.stdout.write = mock_write

# Generated at 2022-06-11 23:26:22.323951
# Unit test for function main
def test_main():
    from io import StringIO
    from httpie.output.streams import write_bytes_to_stream
    from httpie.cli.definition import parser
    from httpie.compat import urlopen
    from httpie.downloads import Downloader
    from httpie.plugins.registry import plugin_manager
    from httpie.output.streams import write_bytes_to_stream
    from httpie.config import Config
    from httpie.context import Environment
    import requests

    args = [
        'http',
        '--verify',
        'no',
        'https://httpbin.org/get',
    ]


# Generated at 2022-06-11 23:26:25.205117
# Unit test for function program
def test_program():
    #assert program(sys.argv, Environment()) == ExitStatus.SUCCESS
    assert main(sys.argv, Environment()) == ExitStatus.SUCCESS

if __name__ == "__main__":
    main()

# Generated at 2022-06-11 23:26:30.201480
# Unit test for function main
def test_main():
  status = main(args=["http", "https://httpbin.org/get", "-v"]);
  assert(status in (ExitStatus.SUCCESS,ExitStatus.ERROR_TIMEOUT,ExitStatus.ERROR_TOO_MANY_REDIRECTS));

if __name__ == "__main__":
	test_main()

# Generated at 2022-06-11 23:26:34.691045
# Unit test for function main
def test_main():
    assert main(args=['http', '--debug']) == ExitStatus.SUCCESS
    assert main(args=['http', '--help']) == ExitStatus.SUCCESS
    assert main(args=['http', 'http://www.google.com', '--output', 'json']) == ExitStatus.SUCCESS


# Generated at 2022-06-11 23:26:35.320341
# Unit test for function program
def test_program():
    program()

# Generated at 2022-06-11 23:26:36.330192
# Unit test for function program
def test_program():
    assert program([], Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:26:38.090269
# Unit test for function program
def test_program():
    assert program(args=['https://httpbin.org/get'], env='testing') == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:26:43.651886
# Unit test for function main
def test_main():
    args = ["http","www.baidu.com"]
    assert main(args) == 0
    args = ["https","www.baidu.com"]
    assert main(args) == 0
    args = ["https","www.baidu.com","-v"]
    assert main(args) == 0
    args = ["https","www.baidu.com","--debug"]
    assert main(args) == 0

# Generated at 2022-06-11 23:27:49.304815
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace
    args.__dict__ = {'httpbin': True, 'json': True, 'headers': 'key:value', 'body': 'key:value'}
    assert program(args=args, env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:28:00.377013
# Unit test for function main
def test_main():
    http_statuses = [200, 201, 400, 401, 403, 404, 405, 410, 500, 501, 502]
    status_matrix = []

    for http_status in http_statuses:
        status_matrix.append([
            http_status,
            http_status_to_exit_status(http_status=http_status, follow=True),
            http_status_to_exit_status(http_status=http_status, follow=False)
        ])


# Generated at 2022-06-11 23:28:02.389881
# Unit test for function program
def test_program():
    exit_status = program(args = ['https://www.google.com'], env = Environment())
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:28:03.494770
# Unit test for function program
def test_program():
    pass


# Generated at 2022-06-11 23:28:06.407962
# Unit test for function main
def test_main():
    args = ['httpie', 'curl', 'https://github.com']
    assert main(args) == ExitStatus.SUCCESS


if __name__ == "__main__":
    main()

# Generated at 2022-06-11 23:28:10.768413
# Unit test for function program
def test_program():
    exit_status = 0
    from httpie.cli.constants import OUT_RESP_HEAD
    options = argparse.Namespace()
    options.headers = ''
    options.output_options = [OUT_RESP_HEAD]
    assert program(options, Environment()) == exit_status

# Generated at 2022-06-11 23:28:13.391616
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['httpie', 'https://www.google.fr'])
    return program(args, Environment())

# Generated at 2022-06-11 23:28:14.715488
# Unit test for function main
def test_main():
    assert main() == 1
    assert main('--debug') == 0

# Generated at 2022-06-11 23:28:24.301535
# Unit test for function main
def test_main():
    assert main() == 0
    assert main(["--debug"]) == 0
    assert main(["GET", "http://localhost:5000/test"]) == 200
    assert main(["GET", "https://localhost:5000/test"]) == 200
    assert main(["POST", "http://localhost:5000/test"]) == 405
    assert main(["POST", "https://localhost:5000/test"]) == 405
    assert main(["GET", "http://google.com/test"]) == 200
    assert main(["GET", "https://google.com/test"]) == 200
    assert main(["GET", "https://httpbin.org/status/200"]) == 200


# Generated at 2022-06-11 23:28:28.020770
# Unit test for function program
def test_program():
    from httpie.status import ExitStatus
    from httpie.cli.argument_parser import parser
    from httpie import ExitStatus
    env = Environment()
    args = parser.parse_args(args=['http://google.com'], env=env)
    assert ExitStatus.SUCCESS == program(args=args, env=env)

# Generated at 2022-06-11 23:29:42.191631
# Unit test for function program
def test_program():
    import types
    import unittest
    from httpie.cli.args import Namespace
    from httpie.config import Config
    from httpie.output.writer import get_message_writer
    from httpie.downloads import Downloader
    from httpie import Environment
    class programTest(unittest.TestCase):
        @classmethod
        def setUpClass(self):
            self.env = Environment()

# Generated at 2022-06-11 23:29:50.724342
# Unit test for function main

# Generated at 2022-06-11 23:30:00.395767
# Unit test for function main
def test_main():
    from httpie.context import Environment
    from httpie.cli.constants import OUT_REQ_BODY
    import sys
    import io
    env = Environment()
    env.stderr = io.StringIO()
    env.stdout = io.StringIO()
    env.stdin = io.StringIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.is_windows = False
    env.config.default_options = ["--traceback"]
    args = sys.argv
    args.append("https://duckduckgo.com")
    args.append('--output-options')
    args.append(OUT_REQ_BODY)
    sys.argv = args
    main(args,env)

# Generated at 2022-06-11 23:30:07.179240
# Unit test for function program
def test_program():
    '''
    Unit test for function program
    '''
    import requests
    import pytest
    from httpie import ExitStatus
    from httpie.cli.definition import parser

    parsed_args = parser.parse_args(
        args=['http://httpbin.org/get'],
        env=Environment(),
    )
    exit_status = program(
        args=parsed_args,
        env=Environment(),
    )
    assert exit_status


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:30:08.482528
# Unit test for function main
def test_main():
    # TODO: implement
    return


# Generated at 2022-06-11 23:30:12.011076
# Unit test for function main
def test_main():
    def test(*args, **kwargs):
        program_name, args = args
        env = kwargs['env']
        exit_status = kwargs['exit_status']
        assert main(args=args, env=env) == exit_status
    return test

# Generated at 2022-06-11 23:30:22.051538
# Unit test for function program

# Generated at 2022-06-11 23:30:31.007687
# Unit test for function main
def test_main():
    import io
    env = Environment(
        stdin=io.BytesIO(),
        stdin_isatty=False,
        stdout=io.BytesIO(),
        stdout_isatty=False,
        stderr=io.BytesIO(),
    )

# Generated at 2022-06-11 23:30:39.648023
# Unit test for function main
def test_main():
    class Mock(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def write(self, _=None):
            pass
    class MockEnvironment(Environment):
        def __init__(self):
            super(MockEnvironment,self).__init__()
            self.stderr = self.stdout = Mock()
            self.stdout_isatty = False
            self.stdin_encoding = 'utf-8'

    args = Mock(download=False, download_resume=False, output_file=None, output_file_specified=False,
                      output_options=[], quiet=True, check_status=False, follow=False,
                      headers=[], verify=None, timeout=None, max_redirects=30)
    env = MockEnvironment()

# Generated at 2022-06-11 23:30:41.655914
# Unit test for function program
def test_program():
    command = "http www.baidu.com"
    arg = command.split()
    args = main(arg)
    assert args == ExitStatus.SUCCESS