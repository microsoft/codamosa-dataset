

# Generated at 2022-06-11 23:23:20.727997
# Unit test for function main
def test_main():
    from . import cli
    from .config import Config
    from .context import Environment
    from .output.streams import StdIOStreams
    from httpie.input.utils import RawBytesInputReader
    from httpie.downloads import Downloader
    import os
    import tempfile

# Generated at 2022-06-11 23:23:32.446881
# Unit test for function program
def test_program():
    # Setup
    import io
    import os
    import sys
    import unittest

    class StdIO():
        def __init__(self, input_content=None, isatty=False):
            self.output_content = ''
            self.input = io.StringIO(input_content) if input_content else None
            if self.input:
                self.input.isatty = lambda: isatty
            self.isatty = isatty

        def __enter__(self):
            if self.input:
                self._stdin = sys.stdin
                sys.stdin = self.input
            self._stdout = sys.stdout
            self._stderr = sys.stderr
            sys.stdout = self
            sys.stderr = self
            return self


# Generated at 2022-06-11 23:23:33.453908
# Unit test for function main
def test_main():
    main(['--debug'])

# Generated at 2022-06-11 23:23:38.390058
# Unit test for function main
def test_main():
    from httpie.cli.argument_parser import parser
    args = parser.parse_args()
    exit_status = main(args=['--debug'],env=Environment())
    assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-11 23:23:49.218558
# Unit test for function program
def test_program():
    with pytest.raises(AttributeError):
        httpie.cli.main.program()

    # TODO: Fix the unit tests to avoid using `sys.stdout.buffer` and `sys.stderr.buffer`.
    sys.stdout.buffer = io.BytesIO()
    sys.stderr.buffer = io.BytesIO()
    parser = httpie.cli.definition.parser
    env = httpie.cli.main.Environment()

    args = parser.parse_args(
        args=['https://example.com'],
        env=env,
    )
    es = httpie.cli.main.program(args=args, env=env)
    assert sys.stderr.buffer.getvalue().startswith(b'HTTPie ')

    sys.stdout.buffer = io.BytesIO()
   

# Generated at 2022-06-11 23:23:51.408029
# Unit test for function main
def test_main():
    exit_status = main(args=["--version"])
    assert exit_status == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:24:00.814323
# Unit test for function program
def test_program():
    class MockEnvironment:
        def __init__(self):
            self.stderr = MockFile()
            self.stdout = MockFile()
            self.stdout_isatty = False
            self.log_error = MockLogError()
            self.config = MockConfig()
            self.config.directory = "/"

    class MockConfig:
        def __init__(self):
            self.default_options = []

    class MockLogError:
        def __init__(self):
            self.messages = []

        def __call__(self, message, level='error'):
            self.messages.append(message)

    class MockFile:
        def __init__(self):
            self.content = []

        def write(self, message):
            self.content.append(message)

    output_file

# Generated at 2022-06-11 23:24:13.610216
# Unit test for function main
def test_main():

    """
    test main function
    :return:
    """
    import sys
    import os
    from httpie.cli.environment import Environment
    from httpie.cli.definition import parser
    from httpie import __version__ as httpie_version

    env = Environment()
    args = []
    args.append(os.getcwd())
    args.append("--form")
    args.append("--pretty=all")
    args.append("--download")
    args.append("--traceback")
    args.append("http://baidu.com")
    program_name, *args = args
    env.program_name = os.path.basename(program_name)
    args = decode_raw_args(args, env.stdin_encoding)
    print(args)
    parsed_args = parser.parse

# Generated at 2022-06-11 23:24:16.134857
# Unit test for function program
def test_program():
    # TODO: More thorough testing
    from httpie.cli.definition import parser
    p = parser.parse_args(['GET'])
    assert program(p, Environment()) == ExitStatus.ERROR

# Generated at 2022-06-11 23:24:26.609705
# Unit test for function main

# Generated at 2022-06-11 23:24:55.184065
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.headers = []
    args.download = False
    args.download_resume = False
    args.output_file = None
    args.output_file_specified = False
    args.follow = False
    args.check_status = False
    args.quiet = False
    env = Environment()
    env.stdout = sys.stdout
    print(env.stdout)
    args.output_options = [OUT_RESP_HEAD, OUT_RESP_BODY]
    #print(args)
    main(args=args, env=env)

if __name__ == '__main__':
    main()
    #test_program()

# Generated at 2022-06-11 23:24:55.678359
# Unit test for function program
def test_program():
    pass

# Generated at 2022-06-11 23:25:03.955121
# Unit test for function program
def test_program():
    class fakeArgs:
        def __init__(self):
            self.check_status = True
            self.download = False
            self.download_resume = False
            self.follow = True
            self.headers = None
            self.output_file = '/Users/rgc/Documents/workspace/httpie/tests/sample-output.txt'
            self.output_file_specified = True
            self.output_options = ['all']
            self.quiet = False
            self.timeout = 30
    class fakeEnv:
        def __init__(self):
            self.config = None
            self.stderr = '/Users/rgc/Documents/workspace/httpie/tests/sample-output.txt'

# Generated at 2022-06-11 23:25:06.045091
# Unit test for function program
def test_program():
    main(['https://httpbin.org/get?a=1&b=2'])
# end

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:25:13.970015
# Unit test for function program
def test_program():
    from httpie import ExitStatus
    from . import BaseTest

    class Test(BaseTest):
        kwargs = {'headers': [], 'body': ''}
        headers = None
        body = None
        exit_status = ExitStatus.SUCCESS

        def pre_request(self, args):
            self.url = args.url
            self.kwargs = args.kwargs
            self.headers = args.headers
            self.body = args.body
            self.output_options = args.output_options
            self.exit_status = program(args, env=self.env)

        def test_headers_HTTP_200_OK(self):
            self.pre_request(self.mock_args('get', '--headers', self.kwargs))
            self.assertIn('header', self.headers)


# Generated at 2022-06-11 23:25:22.077397
# Unit test for function program
def test_program():
    from httpie import ExitStatus
    from httpie.cli.context import Environment
    from httpie.cli.definition import parser
    import io
    import requests
    args = parser.parse_args(['http://httpbin.org/get'], env=Environment())
    env = Environment(stdout=io.BytesIO(),
                        stdout_isatty=True,
                        stdin=io.BytesIO(),
                        configuration_dir='')
    status = program(args=args, env=env)
    assert isinstance(status, ExitStatus)
    assert status.value == ExitStatus.SUCCESS.value

# Generated at 2022-06-11 23:25:23.538218
# Unit test for function program
def test_program():
    assert program(['foo', 'bar']) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:25:27.004634
# Unit test for function main
def test_main():
    args = ["lol", "keke"]
    env = Environment()
    assert main(args=args, env=env) == ExitStatus.SUCCESS
    assert env.program_name == "lol"


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:25:30.146890
# Unit test for function main
def test_main():
    args = ["http", "get", "https://api.github.com/orgs/kennethreitz/members", "-v"]
    env = Environment()
    exitstatus = main(args, env)
    assert(exitstatus == ExitStatus.SUCCESS)



# Generated at 2022-06-11 23:25:39.579943
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.tests.compat import patch
    from httpie.tests.data import (
        BIN_FILE_PATH,
        BIN_FILE_CONTENT,
        BIN_FILE_PATH_ARG,
        JSON_FILE_PATH,
        JSON_FILE_CONTENT,
        JSON_FILE_PATH_ARG,
        TEXT_FILE_CONTENT,
    )


# Generated at 2022-06-11 23:26:15.093428
# Unit test for function main
def test_main():
    # test program name
    assert main(["http"])[0] == "http"
    # test if program exist
    assert main(["http", "https://httpbin.org/get"]) == 200
    # test if program exist
    assert main(["http", "--check-status", "https://httpbin.org/get"]) == 200
    # test if program exist
    assert main(["http", "--check-status", "https://httpbin.org/get"]) == 200
    # test if program exist
    assert main(["http", "--check-status", "https://httpbin.org/get", "x-test"]) == 200
    
    # test if program exist

# Generated at 2022-06-11 23:26:24.944774
# Unit test for function main
def test_main():
    from io import TextIOWrapper
    from io import BytesIO
    import io
    file_name = 'test.txt'
    txt = 'hello'
    encoding = 'utf-8'
    h = open(file_name, 'wb')
    h.write(txt.encode(encoding))
    h.close()
    argv = ['httpie',file_name]
    env = Environment()
    env.stdin_isatty = False
    env.to_bytes = lambda x: x.encode('utf8')
    env.stdout_isatty = True
    env.stdin_encoding = encoding
    env.stderr = TextIOWrapper(io.BytesIO(),encoding=encoding)
    env.stdin = open(file_name, 'rb')
    main

# Generated at 2022-06-11 23:26:35.310182
# Unit test for function program
def test_program():
    class Namespace:
        download = True
        headers = None
        check_status = True
        follow = True
        quiet = False
        output_options = [OUT_RESP_HEAD, OUT_RESP_BODY]
        output_file_specified = True
        output_file = None
        download_resume = False
        disable_colors = False

    args = Namespace()

    def separate():
        print()

    class Environment:
        config = None
        stderr = None
        log_error = None
        program_name = "http"
        stdout_isatty = True

    env = Environment()
    env.program_name = "http"
    env.log_error = print
    env.stderr = sys.stderr
    env.stdout_isatty = True
    env

# Generated at 2022-06-11 23:26:42.805609
# Unit test for function program
def test_program():
    import json
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from tests.constants import BIN_FILE_PATH, URL, BIN_FILE_CONTENT, UNICODE, JSON_DATA

    with open(BIN_FILE_PATH, mode='rb') as f:
        bin_file_content = f.read()

    env = Environment()

    # Basic GET
    exit_status, kwargs = program({'--print': 'hb', 'GET': URL}, env)
    assert exit_status == ExitStatus.SUCCESS
    assert kwargs == {'--print': 'hb', 'GET': URL}

    # Basic GET with redirect

# Generated at 2022-06-11 23:26:52.169409
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR

    try:
        os.mkdir(DEFAULT_CONFIG_DIR)
    except FileExistsError:
        pass

    try:
        file_path = os.path.join(DEFAULT_CONFIG_DIR, 'config.json')
        with open(file_path, 'w', encoding='utf8') as file:
            file.write(
                '''{
                    "default_options": [
                        "--form",
                        "--verbose"
                     ]
                 }''')
        assert main(['http', '--headers']) == 0
    finally:
        os.remove(file_path)

# Generated at 2022-06-11 23:26:59.585299
# Unit test for function main
def test_main():
    import io
    import unittest

    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins import plugin_manager

    class MockStdStream:
        def __init__(self, value=None, errors='strict'):
            if value is None:
                value = io.BytesIO()
            if isinstance(value, bytes):
                value = io.BytesIO(value)
            self.value = value
            self.errors = errors

        def __getattr__(self, item):
            return getattr(self.value, item)

        def buffer(self):
            return self

    class ExitStatusTestCase(unittest.TestCase):
        """
        Test case for function main
        """


# Generated at 2022-06-11 23:27:02.497375
# Unit test for function main
def test_main():
    # name_args = ['http', 'https://www.google.com']
    env = Environment()
    assert main(env=env) == 0
    # assert main(name_args) == 0

# Generated at 2022-06-11 23:27:13.116734
# Unit test for function program
def test_program():
    import io
    import sys
    
    from httpie.client import collect_messages
    from httpie.output.writer import write_message
    from httpie.context import Environment  # for unit-test
    
    # sys.argv = ['http']
    
    args = []
    args.append('--debug')
    args.append('--body')
    args.append('--check-status')
    args.append('--headers')
    args.append('--traceback')
    
    args.append('GET')
    args.append('http://httpbin.org/')
    
    result = main(args)
    print(result)
    
    # sys.argv = ['./http']
    # args = sys.argv
    # exit_status = main(args)
    # print(exit_

# Generated at 2022-06-11 23:27:18.021941
# Unit test for function main
def test_main():
    import sys
    import time

    def get_output(args):
        stdout = sys.stdout
        sys.stdout = StringIO()
        print(sys.getdefaultencoding())
        main(args)
        out = sys.stdout.getvalue()
        sys.stdout = stdout
        return out

    assert 'GET' in get_output(['httpie', 'example.com'])

    assert 'HTTP/1.0' in get_output(['httpie', '--pretty=all', 'httpbin.org/get'])

    assert 'HTTP/1.1' in get_output(['httpie', '--pretty=all', 'httpbin.org/headers'])

    assert 'name' in get_output(['httpie', '--body', 'httpbin.org/anything'])


# Generated at 2022-06-11 23:27:25.497825
# Unit test for function program
def test_program():
    from httpie.cli import parse_args
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPAuthDigest, HTTPAuthNegotiate, HTTPBasicAuthError

    args = parse_args(args=['--auth', 'user:password', 'httpbin.org'], env=Environment())

    actual_exit_status = program(args=args, env=Environment())
    assert actual_exit_status == ExitStatus.SUCCESS

    args = parse_args(args=['--auth', 'user:password', 'httpbin.org'], env=Environment())
    auth = HTTPBasicAuth()
    messages = auth.enhance_args(args)
    assert messages
    assert messages[0]["type"] == "basic"
    assert messages[0]["username"] == "user"

# Generated at 2022-06-11 23:28:30.443217
# Unit test for function main
def test_main():
    # error in argv
    assert main(args=['httpie', '-f'], env=Environment()) == ExitStatus.ERROR
    # program success, status code 0
    assert main(args=['httpie', 'https://google.com'], env=Environment()) == ExitStatus.SUCCESS
    # program success, status code 2
    assert main(args=['httpie', 'https://github.com'], env=Environment()) == ExitStatus.SUCCESS
    assert main(args=['httpie', 'https://httpstat.us/201'], env=Environment()) == ExitStatus.SUCCESS
    # program success, status code 3
    assert main(args=['httpie', 'https://httpstat.us/300'], env=Environment()) == ExitStatus.ERROR
    # program success, status code 4

# Generated at 2022-06-11 23:28:39.714021
# Unit test for function program
def test_program():
    def separate(args):
        getattr(env.stdout, 'buffer', env.stdout).write(MESSAGE_SEPARATOR_BYTES)

    def request_body_read_callback(chunk):
        should_pipe_to_stdout = bool(
            # Request body output desired
            OUT_REQ_BODY in args.output_options
            # & not `.read()` already pre-request (e.g., for  compression)
            and initial_request
            # & non-EOF chunk
            and chunk
        )
        if should_pipe_to_stdout:
            msg = requests.PreparedRequest()
            msg.is_body_upload_chunk = True
            msg.body = chunk
            msg.headers = initial_request.headers

# Generated at 2022-06-11 23:28:51.769279
# Unit test for function program
def test_program():
    urls = [
        "http://localhost:8000",
        "https://httpbin.org/cookies/set?a=b&c=d",
        "https://httpbin.org/cookies",
        "https://httpbin.org/cookies/set?a=b&c=d",
        "https://httpbin.org/cookies"
    ]
    args = argparse.Namespace()
    args.url = urls[0]
    args.headers = []
    args.follow = True
    args.output_file = None
    args.output_file_specified = False
    args.output_options = ["h"]
    args.download = False
    args.download_resume = False
    args.check_status = False
    args.quiet = False
    env = Environment()

# Generated at 2022-06-11 23:28:54.996591
# Unit test for function program
def test_program():
    import argparse
    args = argparse.Namespace
    args.url = 'http://www.google.com'
    env = Environment
    env.stdout = ['http']
    print(program(args, env))

# Generated at 2022-06-11 23:28:58.890977
# Unit test for function main
def test_main():
    # import doctest
    # doctest.testmod()
    exit_status = main(['http', '--debug', 'http://httpbin.org/get'])
    assert exit_status == ExitStatus.SUCCESS


if __name__ == '__main__':
    exit_status = main()
    sys.exit(exit_status)

# Generated at 2022-06-11 23:29:09.756994
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.models import Environment, KeyValue

    class Args():
        def __init__(self):
            self.args = ['http', '-v', '--form', 'POST', 'echo.getpostman.com', 'key=value', '--headers', 'key: value']
            self.headers = []
            self.output_options = []
            self.out_file = None
            self.download = None
            self.download_output_file = False
            self.download_resume = False
            self.output_options = ['h']
            self.form = True
            self.timeout = 0
            self.max_redirects = 0
            self.check_status = False
            self.download_options = ['b']



# Generated at 2022-06-11 23:29:14.214545
# Unit test for function main
def test_main():
    env = Environment()
    env.stdin_encoding = 'utf-8'
    result = main(['httpie.exe', 'GET', 'http://httpie.org'], env)
    assert result == ExitStatus.SUCCESS


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:29:24.224119
# Unit test for function program
def test_program():
    from httpie import __version__
    from httpie.cli.constants import EXIT_STATUS_LABELS

    env = Environment()
    env.program_name = 'http'
    env.stdin = ''
    env.stdin_isatty = False
    env.stdin_encoding = 'utf8'
    env.stdin_errors = 'strict'
    env.stdout = open('/dev/null', 'w')
    env.stdout_isatty = False
    env.stdout_encoding = 'utf8'
    env.stderr = open('/dev/null', 'w')
    env.stderr_isatty = False
    env.stderr_encoding = 'utf8'

    from httpie.config import Config


# Generated at 2022-06-11 23:29:26.408202
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    exit_status = main(args=['--style', 'colors', 'GET'], env=Environment())
    assert type(exit_status) is ExitStatus

# Generated at 2022-06-11 23:29:36.923289
# Unit test for function main
def test_main():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR, DEFAULT_CONFIG_FILENAME
    from httpie.context import Environment

    def print_debug_info_mock(env):
        pass
    # noinspection PyUnresolvedReferences
    from unittest.mock import patch, MagicMock
    m = MagicMock()
    m.configure_mock(**{'isatty.return_value': False})
    m1 = MagicMock()
    m1.configure_mock(**{'isatty.return_value': True})


# Generated at 2022-06-11 23:31:17.739944
# Unit test for function program
def test_program():
    exit_status = program(args=['--help'], env=Environment(program_name='http', stdin_encoding='utf-8'))
    assert exit_status == 0



# Generated at 2022-06-11 23:31:20.332258
# Unit test for function main
def test_main():
    from click.testing import CliRunner
    runner = CliRunner()
    result = runner.invoke(main)
    assert result.exit_code == 0
    assert result.output == u'Hello, World!\n'

# Generated at 2022-06-11 23:31:30.118308
# Unit test for function main
def test_main():
    import io
    import unittest

    class StdIOBytesIO(io.BytesIO):
        def write(self, s: Union[str, bytes]):
            super().write(s if type(s) is bytes else s.encode('utf8'))

    class TestMain(unittest.TestCase):

        def setUp(self):
            self.stdout = StdIOBytesIO()
            self.stderr = StdIOBytesIO()
            self.env = Environment(
                stdout=self.stdout,
                stderr=self.stderr,
            )

        def test_main(self):
            main([], self.env)

    unittest.main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:31:37.828452
# Unit test for function main
def test_main():
    '''
    This tests the main function to see if the 
	functionality works
    '''
    assert main([
        'http', '--verbose',
        # stdout=StringIO(),
        # stdout_isatty=False,
    ]) == ExitStatus.SUCCESS
    assert main([
        'http', '--debug',
        # stdout=StringIO(),
        # stdout_isatty=False,
    ]) == ExitStatus.SUCCESS
    assert main([
        'http', '--traceback',
        # stdout=StringIO(),
        # stdout_isatty=False,
    ]) == ExitStatus.SUCCESS
    # assert main([
        # 'http', '-h',
        # stdout=StringIO(),
        # stdout_isatty=False,


# Generated at 2022-06-11 23:31:45.002560
# Unit test for function main
def test_main():
    assert main(['--debug']) == ExitStatus.SUCCESS
    assert main(['--quiet']) == ExitStatus.SUCCESS
    assert main([]) == ExitStatus.ERROR
    assert main(['--debug', '--verbose']) == ExitStatus.SUCCESS
    assert main(['--debug']) == ExitStatus.SUCCESS
    assert main(['--quiet']) == ExitStatus.SUCCESS
    assert main([]) == ExitStatus.ERROR

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-11 23:31:53.340990
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.cli.exceptions import ParseError
    from httpie.cli.utils import get_response
    from httpie.context import Environment
    from httpie.downloads import Downloader
    import argparse

    class _Response(object):
        def __init__(self, status_code, headers, reason=None, elapsed=None, encoding=None):
            self.headers = headers
            self.status_code = status_code
            self.raw = self
            self.reason = reason
            self.elapsed = elapsed
            self.encoding = encoding

    def do_request(*args, **kwargs):
        assert args[0] == 'GET'
        assert args[1] == 'http://httpbin.org/get'

# Generated at 2022-06-11 23:31:57.276207
# Unit test for function main
def test_main():
    from httpie.cli import environment
    # noinspection PyTypeChecker
    assert main(['http', '--debug', 'http://httpbin.org/json'], environment.Environment()) == 0
    # noinspection PyTypeChecker
    assert main(['http', 'http://httpbin.org/json'], environment.Environment()) == 0

# Generated at 2022-06-11 23:31:58.995565
# Unit test for function program
def test_program():
    args = main(['--check-status', 'http://localhost:5000/'])
    assert (args == 0)


# Generated at 2022-06-11 23:32:07.954402
# Unit test for function program
def test_program():
    import httpie.cli.argtypes
    import httpie.cli.parser
    args_parser = httpie.cli.parser.Parser()
    args = args_parser.parse_args(args=["test_program"],
                           env=httpie.context.Environment())
    args.headers = httpie.cli.argtypes.KeyValueArgType.to_py(args.headers)
    args.output_options = httpie.cli.argtypes.OutputOptionsArgType.to_py(args.output_options)
    args.method = "GET"
    args.url = "https://httpbin.org/get"
    args.timeout = 3
    args.max_redirects = 0
    program(args, httpie.context.Environment())

# Generated at 2022-06-11 23:32:11.871958
# Unit test for function program
def test_program():
    # Need set up 3 different cases for HTTP request
    # 1) http -v 'http://example.com/'
    # 2) http -v 'http://example.com/' httpie/0.5.2
    # 3) http -v 'http://httpbin.org/post' foo=bar
    # assert equal
    return
