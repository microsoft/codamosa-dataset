

# Generated at 2022-06-11 23:23:34.269480
# Unit test for function main
def test_main():
    from io import BytesIO
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.environment import Environment

    env = Environment(
        config=Config(directory=DEFAULT_CONFIG_DIR),
        stdin=BytesIO(b'...'),
        stdin_isatty=True,
        stdout=BytesIO(),
        stdout_isatty=True,
        stderr=BytesIO()
    )
    assert main(args=[], env=env) == ExitStatus.SUCCESS



# Generated at 2022-06-11 23:23:35.936300
# Unit test for function program
def test_program():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:23:47.766996
# Unit test for function program
def test_program():
    env = Environment()
    test_args = argparse.Namespace()
    test_args.output_options = [OUT_REQ_HEAD, OUT_RESP_HEAD]
    test_args.check_status = True
    test_args.follow = True
    test_args.headers = {"X-Test": "test"}
    test_args.download = False
    test_args.output_file = None
    test_args.output_file_specified = False
    test_args.quiet = False
    test_args.method = "GET"
    test_args.auth = None
    test_args.auth_type = None
    test_args.verify = True
    test_args.timeout = 30
    test_args.max_redirects = 10
    test_args.form = []
    test_args.data

# Generated at 2022-06-11 23:23:50.294414
# Unit test for function main
def test_main():
    os.environ['http_proxy'] = 'http://127.0.0.1:9988'
    assert main(args=['http://google.com']) == 0

# Generated at 2022-06-11 23:24:00.130602
# Unit test for function program

# Generated at 2022-06-11 23:24:12.880734
# Unit test for function program
def test_program():

    class FakeEnv:
        def __init__(self, stdout_isatty, stdout, stderr):
            self.stdout_isatty = stdout_isatty
            self.stdout = stdout
            self.stderr = stderr
            self.config = {'directory': '~'}

    class FakeArgs:
        def __init__(self, check_status, download, follow, headers, output_file, output_file_specified,
                     output_options, quiet, download_resume, timeout):
            self.check_status = check_status
            self.download = download
            self.follow = follow
            self.headers = headers
            self.output_file = output_file
            self.output_file_specified =  output_file_specified
            self.output_options = output_

# Generated at 2022-06-11 23:24:16.743358
# Unit test for function main
def test_main():
    from httpie.context import Environment
    env = Environment()
    env.stdin_encoding = 'utf-8'
    assert main(args=['httpie', 'GET', 'http://httpbin.org/get'], env=env) == ExitStatus.SUCCESS

test_main()

# Generated at 2022-06-11 23:24:19.495259
# Unit test for function main
def test_main():
    exit_status = main(
        args=[
            'httpie',
            '--output=INVALID_VALUE',
            'https://httpbin.org/get',
        ],
        env=Environment(debug=True),
    )
    assert exit_status == ExitStatus.ERROR

# Generated at 2022-06-11 23:24:25.501253
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args([
        "--check-status",
        "--fail",
        "-X", "POST",
        "-H", "Content-Type: application/json",
        "-H", "Accept: application/json",
        "-b", "'{'id': 'a'}'",
        "https://httpie.org/doc"
    ])
    program(args, Environment())

# Generated at 2022-06-11 23:24:36.269465
# Unit test for function main
def test_main():
    from io import StringIO
    import sys

    class StdStreamsCapture:
        def __init__(self):
            self.stdout_buffer = StringIO()
            self.stderr_buffer = StringIO()

        def __enter__(self):
            self.stdout = sys.stdout
            self.stderr = sys.stderr
            sys.stdout = self.stdout_buffer
            sys.stderr = self.stderr_buffer
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            sys.stdout = self.stdout
            sys.stderr = self.stderr

    # case 1: no argument
    with StdStreamsCapture():
        assert main() == ExitStatus.ERROR

    # case 2: GET request

# Generated at 2022-06-11 23:25:29.402465
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:25:35.702967
# Unit test for function main
def test_main():
    program_name = sys.argv[0]
    sys.argv[0] = 'Python'

    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.config import Directory

    my_env = Environment(config_dir=Directory('.'))

    my_args = ['GET', 'https://www.httpie.org']

    my_result = main(args=my_args, env=my_env)

    assert my_result == ExitStatus.SUCCESS
    assert sys.argv[0] == program_name

# Generated at 2022-06-11 23:25:45.905028
# Unit test for function program
def test_program():
    import unittest
    from httpie.cli.definition import parser
    from pygments import highlight
    from pygments.formatters import TerminalTrueColorFormatter
    from pygments.lexers import HttpLexer
    from typing import List
    from httpie.constants import COMMANDS
    from httpie.output.formatter.colors import get_lexer
    from httpie.downloads import Downloader
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.input import KeyValue
    from httpie.plugins import plugin_manager
    from httpie.config import DEFAULT_CONFIG_DIR
    import os
    import sys
    import requests
    import time
    import platform
    import signal
    import pathlib
    import io


# Generated at 2022-06-11 23:25:55.055308
# Unit test for function program
def test_program():
    messages = [
        requests.PreparedRequest(),
        requests.Response(),
    ]
    class MockRequestsMessages(object):
        def __iter__(self):
            return iter(messages)
    # TODO: Mock the main thing
    args = argparse.Namespace(
        output_options=[],
    )
    with patch('httpie.cli.main.collect_messages') as mock_collect_messages:
        mock_collect_messages.return_value = MockRequestsMessages()
        program(args=args, env=Environment())
        assert mock_collect_messages.mock_calls == [call(args=args, request_body_read_callback=None)]
        # Only call write_message once, because we have the same output options for both messages

# Generated at 2022-06-11 23:25:55.874584
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:25:57.167658
# Unit test for function program
def test_program():
    """
    Tests the main program without error handling.
    """
    assert 1 == 1

# Generated at 2022-06-11 23:26:00.944189
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    env = Environment()
    args = ['-b', '-p', 'windows', 'https://google.com']
    program(parser.parse_args(args=args, env=env), env)


# Generated at 2022-06-11 23:26:11.526972
# Unit test for function main
def test_main():
    os.environ['HTTPIE_CONFIG_DIR'] = os.path.join(os.path.dirname(__file__), 'conf')

    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('-v','--verbose', default=False, action='store_true')
    parser.add_argument('-c','--check-status', default=False, action='store_true')
    parser.add_argument('-f','--follow', default=False, action='store_true')
    parser.add_argument('-q', '--quiet', default=False, action='store_true')
    parser.add_argument('-o', '--output-file', dest='output_file_specified', default=False, action='store_true')

# Generated at 2022-06-11 23:26:15.387877
# Unit test for function main
def test_main():
    from httpie import ExitStatus
    # If this test fails, it probably means that you renamed a function or method,
    # and that you need to adjust the `main` function accordingly.
    assert ExitStatus.SUCCESS == main(['http', '--debug', 'https://httpie.org'])

# Generated at 2022-06-11 23:26:21.503114
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    env = Environment()
    exit_status = program(args=args, env=env)
    if exit_status != ExitStatus.SUCCESS :
        raise ValueError(f'program() returns unexpected exit status value')

# Testing the main()
if __name__ == '__main__':
    exit_status = main()
    if exit_status != ExitStatus.SUCCESS :
        raise ValueError(f'main() returns unexpected exit status value')

# Generated at 2022-06-11 23:27:09.820734
# Unit test for function program
def test_program():
    from click.testing import CliRunner
    from httpie.cli.definition import parser
    from httpie.output.streams import StdoutBytesIO

    runner = CliRunner()
    result = runner.invoke(program,['https://www.sina.com.cn'])
    print(result.output)
    assert True

# Generated at 2022-06-11 23:27:13.116597
# Unit test for function main
def test_main():
    # TODO: test the main function
    # https://github.com/psf/black/issues/430#issuecomment-521305112
    return
    main(
        args=[
            '--debug',
        ],
        env=Environment(),
    )

# Generated at 2022-06-11 23:27:19.624064
# Unit test for function program
def test_program():
    # taken from https://httpie.org/doc#testing
    sys.argv = ['http', 'https://httpbin.org/post', 'foo=bar', 'baz=bar']
    args = parser.parse_args(args=sys.argv[1:])
    #args.headers = parser.parse_headers(args, env=Environment())
    program(args)

# script to actually run
if __name__ == '__main__':
    main()
    #test_program()

# Generated at 2022-06-11 23:27:25.838636
# Unit test for function main
def test_main():
    from io import StringIO
    from argparse import Namespace
    args = decode_raw_args([b'--version'], 'UTF-8')
    output = StringIO()
    env = Environment(stdout=output)
    main(args, env)
    assert output.getvalue().startswith('HTTPie')
    args = decode_raw_args([b'GET', b'http://example.com'], 'UTF-8')
    output = StringIO()
    env = Environment(stdout=output, config_dir=None)
    main(args, env)
    assert output.getvalue().startswith('HTTP/')


if __name__ == '__main__':
    print(main())

# Generated at 2022-06-11 23:27:36.262841
# Unit test for function main
def test_main():
    # def main(args: List[Union[str, bytes]] = sys.argv, env=Environment()) -> ExitStatus:
    assert main(['/usr/bin/http', '--version']) == ExitStatus.SUCCESS
    assert main(['/usr/bin/http', '--debug']) == ExitStatus.SUCCESS
    assert main(['/usr/bin/http', '--help']) == ExitStatus.SUCCESS
    assert main(['/usr/bin/http', '--help-keywords']) == ExitStatus.SUCCESS
    assert main(['/usr/bin/http', '--form', '--body', 'test', 'http://www.example.com']) == ExitStatus.SUCCESS



# Generated at 2022-06-11 23:27:42.446099
# Unit test for function program
def test_program():
    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie import ExitStatus
    from tests.compat import mock
    env = Environment()
    args = parse_args(args=['-f', 'httpbin.org/get'], env=env)
    if is_windows:
        env.stdout.buffer = mock.MagicMock(name='stdout.buffer')
    assert program(args=args, env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:27:51.667421
# Unit test for function program
def test_program():
    from httpie.output.formatters import JSONFormatter

    def stdin_mock():
        return io.StringIO("http://httpbin.org/get  ")

    def stdout_mock():
        return io.StringIO("")

    def stderr_mock():
        return io.StringIO("")

    class argparse_mock():
        def __init__(self,**kwargs):
            self.__dict__.update(kwargs)


# Generated at 2022-06-11 23:28:01.641662
# Unit test for function main
def test_main():
    # Generic error handling
    try:
        assert main('http -j httpbin.org/ip'.split()) == ExitStatus.ERROR
    except SystemExit as e:
        assert e.code == ExitStatus.ERROR

    # Default-options + error handling
    try:
        assert main(['--debug', 'http -j httpbin.org/ip']) == ExitStatus.ERROR
    except SystemExit as e:
        assert e.code == ExitStatus.ERROR

    # --traceback + error handling
    try:
        assert main(['--traceback', 'http -j httpbin.org/ip']) == ExitStatus.ERROR
    except SystemExit as e:
        assert e.code == ExitStatus.ERROR

    # Explicit exit code + error handling

# Generated at 2022-06-11 23:28:11.759211
# Unit test for function program
def test_program():
    assert main(['httpie', '--debug']) == ExitStatus.SUCCESS
    assert main(['httpie', '--traceback']) == ExitStatus.ERROR
    assert main(['httpie', '--timeout', '0']) == ExitStatus.SUCCESS

    assert main(['httpie', '--output-file=test_output_file', '--timeout', '0']) == ExitStatus.SUCCESS

    assert main(['httpie', '--check-status', 'https://www.baidu.com']) == ExitStatus.SUCCESS
    assert main(['httpie', '--check-status', 'https://www.baidu.com/404']) == ExitStatus.ERROR

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:28:22.730852
# Unit test for function main
def test_main():
    import tempfile
    import unittest
    from unittest.mock import patch, MagicMock

    class MyTestCase(unittest.TestCase):
        def test_main_program_with_success(self):
            with patch('httpie.cli.program') as mock_program:
                mock_program.return_value = 0
                self.assertEqual(main(args=['httpie']), 0)

        def test_main_program_with_system_exit(self):
            with patch('httpie.cli.program') as mock_program:
                mock_program.side_effect = SystemExit(1)
                self.assertEqual(main(args=['httpie']), 1)


# Generated at 2022-06-11 23:29:00.701427
# Unit test for function program
def test_program():
    from os import path
    from httpie.context import Environment
    import httpie.config
    import httpie.downloads
    import httpie.cli.constants
    import httpie.cli.definition
    import httpie.cli.argtypes
    import httpie.output.formatters.default
    import httpie.output.formatters.colors
    import httpie.output.formatters.json
    import httpie.output.formatters.table
    import httpie.output.formatters.vertical_table
    import httpie.compat
    import httpie.plugins.builtin
    import httpie.plugins.manager
    from httpie.compat import is_windows, is_py26
    from httpie.client import requests
    import pygments
    import pygments.lexers
    import pygments.styles
    import py

# Generated at 2022-06-11 23:29:04.025670
# Unit test for function program
def test_program():
    program([['', '', 'GET', 'http://localhost:5000/api/v1/resources/books?page=1']])
    print("Test for program completed")
    print("\n")


# Generated at 2022-06-11 23:29:05.330900
# Unit test for function program
def test_program():
    pass
#
# if __name__ == '__main__':
#     program()

# Generated at 2022-06-11 23:29:07.022086
# Unit test for function main
def test_main():
    status=main()
    assert isinstance(status,ExitStatus)
    print (status)

# Generated at 2022-06-11 23:29:08.483100
# Unit test for function main
def test_main():
    code = main(['--debug'])
    assert code == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:29:19.691986
# Unit test for function main
def test_main():
    from httpie.cli.constants import VERSION_OPTION
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins import AuthPlugin, FormatterPlugin, TransportPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.status import ExitStatus
    import logging
    import os
    import requests.sessions
    import sys
    import warnings
    warnings.filterwarnings('error')
    plugin_manager.locate_plugins = lambda: {}
    plugin_manager.load_installed_plugins = lambda: {}

    stdin = sys.stdin.buffer
    stdout = sys.stdout.buffer
    stderr = sys.stderr.buffer

# Generated at 2022-06-11 23:29:24.924332
# Unit test for function program
def test_program():
    from httpie.context import Environment
    from httpie.cli.definition import parser

    args = parser.parse_args(['--debug'])
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS
    args = parser.parse_args(['--debug', 'GET', 'http://example.com'])
    assert program(args, env) == ExitStatus.SUCCESS

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:29:26.616479
# Unit test for function main
def test_main():
    main(args=['httpie', 'http', '10.101.206.15:5000/']) == 0

# Generated at 2022-06-11 23:29:37.134533
# Unit test for function program

# Generated at 2022-06-11 23:29:43.352923
# Unit test for function program
def test_program():
    parser = argparse.ArgumentParser("Testing program")
    parser.add_argument("-X", "--method", help="HTTP method to use")
    parser.add_argument("--headers", help="HTTP headers to use")
    parser.add_argument("--auth", help="HTTP Authorization header value")
    parser.add_argument("--timeout", help="Connection timeout in seconds")
    parser.add_argument("--max-redirects", help="Maximum number of redirects to follow")
    parser.add_argument("--verify", help="Set to false to skip SSL certificate verification")
    parser.add_argument("--ssl-cert", help="Client certificate file path")
    parser.add_argument("--output-file", help="Write output to a file")
    parser.add_argument("--download", help="Download the response body to a file")

# Generated at 2022-06-11 23:30:50.777959
# Unit test for function program
def test_program():
    "Tests for program"
    # 1. test --version
    argument = ["--version"]
    program(argument,Environment())

    # 2. test --help
    argument = ["--help"]
    program(argument,Environment())

    # 3. test --debug
    argument = ["--debug"]
    program(argument,Environment())

    # 4. test GET
    argument = ["GET"]
    program(argument,Environment())

    # 5. test POST
    argument = ["--form","POST"]
    program(argument,Environment())

    # 6. test HEAD
    argument = ["HEAD"]
    program(argument,Environment())

    # 7. test OPTIONS
    argument = ["OPTIONS"]
    program(argument,Environment())

    # 8. test DELETE
    argument = ["DELETE"]
    program(argument,Environment())

# Generated at 2022-06-11 23:30:55.172007
# Unit test for function program
def test_program():
    args = {'headers': None, 
            'output_options': 'h,b', 
            'output_file': None, 
            'download': False, 
            'download_resume': False, 
            'output_file_specified': False, 
            'max_redirects': 30, 
            'check_status': False, 
            'follow': False, 
            'timeout': 30, 
            'pretty': False, 
            'style': 'solarized', 
            'colors': 256, 
            'stream': True, 
            'verify': True, 
            'auth': None, 
            'download_as_temp': False}

# Generated at 2022-06-11 23:30:55.721180
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 23:31:00.780811
# Unit test for function main
def test_main():
    args = ["C:\\Users\\chinm\\Downloads\\HTTPie\\httpie-0.9.9\\http", "--headers", "--verbose", "--body", "--output=C:\\Users\\chinm\\Downloads\\HTTPie\\httpie-0.9.9\\output-1.json", "https://www.google.com"]
    env = Environment()
    main(args, env)


# Generated at 2022-06-11 23:31:02.865283
# Unit test for function main
def test_main():
    #assert(main(['--debug']) == 0)
    assert(main(['--help']) == 0)


# Generated at 2022-06-11 23:31:03.377744
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 23:31:13.574218
# Unit test for function program
def test_program():
    from clint.textui import puts, colored
    from httpie.status import ExitStatus
    from httpie.context import Environment
    import requests
    import sys
    import os
    import requests_mock
    from httpie.cli.parser import get_parser
    from httpie.compat import is_py26

    env = Environment(
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        stdin_isatty=sys.stdin.isatty(),
        stdout_isatty=sys.stdout.isatty(),
        configuration_dir=os.path.join(os.path.dirname(__file__), 'fixtures/.httpie')
    )

    with requests_mock.mock() as m:
        m

# Generated at 2022-06-11 23:31:22.721758
# Unit test for function program
def test_program():
    def t(args, exit_status=ExitStatus.SUCCESS):
        from httpie.cli.formatter.colors import ColoredStreamHandler
        from httpie.cli.parser import parse_authorize
        from httpie.plugins import builtin
        from io import StringIO
        import json
        args = parse_authorize(args)
        env = Environment(
            stdin=StringIO(),
            stdout=StringIO(),
            stderr=StringIO(),
            color_env_var=None,
            stdout_isatty=(platform.system() != 'Windows'),
            stdin_isatty=True,
            vt100_support=True,
            stdin_encoding='utf8',
            config_dir=None,
            default_options=[],
            config=None,
        )

# Generated at 2022-06-11 23:31:23.355711
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 23:31:28.481293
# Unit test for function program
def test_program():

    #arr = ['./http', '--output=httpie.txt', 'google.com']
    arr = ['http', 'google.com', '-o', 'httpie.txt']
    exit_status = main(arr)

    print(ExitStatus(exit_status))


if __name__=='__main__':
    test_program()

# Generated at 2022-06-11 23:32:25.216594
# Unit test for function main
def test_main():
    args="the first and second string".split()
    env=Environment()
    assert(main(args,env)==0)
    
    args="the first and second string".split()
    env=Environment()
    assert(main(args,env)==0)
    
test_main()

# Generated at 2022-06-11 23:32:27.910630
# Unit test for function program
def test_program():
    assert program(["http", "www.baidu.com", "-v"]) == 0
    assert program(['http', 'httpbin.org/headers', '--headers', 'a: b']) == 0

# Generated at 2022-06-11 23:32:37.107746
# Unit test for function main
def test_main():
    import mock
    import pytest

    from httpie.cli.exc import CLIError
    from httpie.cli.definition import parser

    from httpie import cli


    def assert_exited_with(args, exit_status_expected, exit_code_expected=None):
        args = [sys.executable] + args
        try:
            cli.main(args=args)
        except SystemExit as e:
            exit_status_actual = ExitStatus(e.code)
        except KeyboardInterrupt:
            exit_status_actual = ExitStatus.ERROR_CTRL_C
        except CLIError:
            exit_status_actual = ExitStatus.ERROR
        else:
            assert False, 'Expected SystemExit when running: %s' % args

        assert exit_status_actual == exit_status_expected