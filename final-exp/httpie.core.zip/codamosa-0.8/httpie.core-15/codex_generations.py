

# Generated at 2022-06-11 23:23:05.089031
# Unit test for function program
def test_program():
    import requests
    import responses

    url = 'https://httpbin.org/get'
    args = argparse.Namespace(method='GET', headers=[], auth=None, verify=None,
                              timeout=None, max_redirects=30, download=None,
                              output_file=None, output_options=[],
                              output_format='colors', stdout=None)

    config_dir = {'http': {'verify': 'False', 'timeout': '20'},
                  'headers': {'Connection': 'close',
                              'User-Agent': 'Mozilla'},
                  'auth': {'username': 'test', 'password': 'test'},
                  'download': {'default-filename': 'index.html'}}

    env = Environment()


# Generated at 2022-06-11 23:23:11.229228
# Unit test for function program
def test_program():
    def main():
        parser = argparse.ArgumentParser()
        parser.add_argument("-v", "--verbose", action="store_true")
        parser.add_argument("square", type=int,
                            help="display a square of a given number")
        args = parser.parse_args()
        answer = args.square ** 2
        if args.verbose:
            print("the square of {} equals {}".format(args.square, answer))
        else:
            print(answer)
    pass


# Generated at 2022-06-11 23:23:22.360311
# Unit test for function main
def test_main():
    import tempfile

    # test whether the main function exits with a success status after executing with no command
    assert main(["http", "--verbose"]) == ExitStatus.SUCCESS

    # test whether the main function exits with an error status after executing with some wrong command
    assert main(["http", "--verbose", "--download"]) == ExitStatus.ERROR

    #test whether the main function exits with a success status after executing with a full command
    with tempfile.NamedTemporaryFile() as tf:
        assert main(["http", "--verbose", "--download", "www.google.com", "-o", tf.name]) == ExitStatus.SUCCESS

    # test whether the main function exits with a success status after executing with optional arguments
    assert main(["http", "--download"]) == ExitStatus.SUCCESS
    assert main

# Generated at 2022-06-11 23:23:25.026083
# Unit test for function program
def test_program():

    # import arguments
    args = parse_args([])
    env = Environment()

    # get response from given URL
    response = program(args,env)
    assert response.status



# Generated at 2022-06-11 23:23:35.953600
# Unit test for function get_output_options
def test_get_output_options():
    o = [OUT_REQ_HEAD, OUT_REQ_BODY]
    assert get_output_options(argparse.Namespace(output_options=o),
                              requests.PreparedRequest()
    ) == (True, True)
    o = [OUT_RESP_HEAD, OUT_RESP_BODY]
    assert get_output_options(argparse.Namespace(output_options=o),
                              requests.Response()
    ) == (True, True)
    o = []
    assert get_output_options(argparse.Namespace(output_options=o),
                              requests.Response()
    ) == (False, False)
    o = [OUT_REQ_HEAD]

# Generated at 2022-06-11 23:23:47.766225
# Unit test for function get_output_options
def test_get_output_options():
    import io
    import argparse
    from httpie.cli.definition import parser
    args_str = [
        'GET',
        'https://www.python.org/',
        'Accept: application/json',
        '-b',
        '--body-only',
        '--check-status',
        '-f',
        '--form',
        '--headers',
        '--headers-only',
        '-H',
        '--ignore-stdin',
        '--max-redirects',
        '-r',
        '--print-body',
        '-v',
        '--verbose',
        '--verify',
        '--debug',
        '--traceback',
        '--timeout',
    ]

# Generated at 2022-06-11 23:23:53.578881
# Unit test for function program
def test_program():
    args = ['https://www.google.com', '-d', '{}']
    args = decode_raw_args(args, 'utf-8')
    assert args[0] == 'https://www.google.com'
    assert args[1] == '-d'
    assert args[2] == '{}'
    

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:24:01.370069
# Unit test for function get_output_options
def test_get_output_options():
    class Args(object):
        output_options = [OUT_REQ_HEAD, OUT_RESP_HEAD, OUT_RESP_BODY]

    class E(httpie.Environment):
        stdin_isatty = True
        stdin_encoding = "utf-8"
        stdin = io.BytesIO()
        stdout = io.BytesIO()
        stderr = io.BytesIO()
        config_dir = None
        colors = 256
        auto_colors = False
        force_colors = False
        is_windows = sys.platform == "win32"
        stdout_isatty = sys.platform != "win32"
        default_options = []
        aliases = {}
        config = httpie.Config(None)
        colors_enabled = True
        debug = False

# Generated at 2022-06-11 23:24:14.151944
# Unit test for function main
def test_main():
    from io import BytesIO
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPDigestAuth, APIKeyAuthPlugin
    from httpie.cli.argparser import parser
    from pytest import raises

    args_str = '--verbose -h Foo-Bar:Baz --insecure https://httpbin.org/headers'
    stdout = BytesIO()
    stderr = BytesIO()

    config = Config(
        config_dir=None,
        default_options=[],
        default_options_unix=[],
    )

# Generated at 2022-06-11 23:24:16.701430
# Unit test for function program
def test_program():
	args = parser.parse_args('-v'.split())
	exit_status = program(args = args, env = Environment())
	assert exit_status == ExitStatus.SUCCESS


# Generated at 2022-06-11 23:24:58.713675
# Unit test for function program
def test_program():
    assert main(['https://httpbin.org/get']) == ExitStatus.SUCCESS
    assert main(['--debug']) == ExitStatus.SUCCESS
    assert main(['--download']) == ExitStatus.ERROR

# Generated at 2022-06-11 23:25:01.228895
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace()
    program(args, env)
    print(env.stdin.read())

if __name__ == "__main__":
    test_program()

# Generated at 2022-06-11 23:25:11.172991
# Unit test for function program
def test_program():
    from httpie.cli.definition import (
        parser,
        parser_assert_valid_args,
    )
    from httpie.output.writer import (
        write_message,
        write_stream,
    )
    from httpie.downloads import (
        Downloader,
        StreamWithCallback,
    )
    from httpie.context import Environment

    class StringIO(object):
        '''
        File-like API for in-memory bytestrings
        '''

        def __init__(self, buf=''):
            self.buf = buf

        def write(self, s):
            self.buf += s

        def flush(self):
            pass

        def getvalue(self):
            return self.buf


# Generated at 2022-06-11 23:25:22.882896
# Unit test for function main
def test_main():
    from py_httpie.core  import main
    from py_httpie.core  import httpie_version
    from py_httpie.core  import ExitStatus
    from py_httpie.core  import Environment
    from py_httpie.core  import decode_raw_args
    from py_httpie.core  import print_debug_info
    import argparse
    import os
    import platform
    import sys
    from typing import List, Optional, Tuple, Union
    from py_httpie.core import collect_messages
    from py_httpie.core import program
    from py_httpie.core import requests
    from py_httpie.core import requests

    print(httpie_version)
    assert httpie_version == '1.0.2'
    assert ExitStatus.SUCCESS == 0
    assert Exit

# Generated at 2022-06-11 23:25:30.915063
# Unit test for function program
def test_program():
    import argparse
    import httpie.config
    import httpie.cli.argtypes
    args = argparse.Namespace()
    config = httpie.config.Config(directory=None)
    httpie.cli.argtypes.KeyValueArgType.SEP_REGEX = r'\s*;\s*'
    environment = httpie.cli.Environment(
        config=config,
        stdin=None,
        stdin_isatty=True,
        stdout=None,
        stdout_isatty=True,
        stderr=None,
        stderr_isatty=True,
    )

# Generated at 2022-06-11 23:25:32.710097
# Unit test for function main
def test_main():
    assert main(['hi', 'how', 'are', 'you']) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:25:42.132008
# Unit test for function get_output_options
def test_get_output_options():
    args = argparse.Namespace()
    args.output_options = ''
    message = requests.Response()
    message.status_code = 200
    assert get_output_options(args, message) == (False, True)
    args.output_options = 'redirect'
    assert get_output_options(args, message) == (False, True)
    args.output_options = 'h'
    assert get_output_options(args, message) == (True, False)
    args.output_options = 'H'
    assert get_output_options(args, message) == (False, False)
    args.output_options = 'Hb'
    assert get_output_options(args, message) == (True, True)
    args.output_options = 'hb'

# Generated at 2022-06-11 23:25:52.524630
# Unit test for function program
def test_program():
    # Testing program function with --download and success
    program_download_success_args = argparse.Namespace()
    program_download_success_args.stdout = sys.stdout
    program_download_success_args.download = True
    program_download_success_args.output_options = ['-b', '-h']
    program_download_success_args.output_file = sys.stdout
    program_download_success_args.output_file_specified = False
    program_download_success_args.check_status = True
    program_download_success_args.download_resume = False
    program_download_success_args.follow = True
    program_download_success_env = Environment()
    assert (program(program_download_success_args, program_download_success_env) == ExitStatus.SUCCESS)

# Generated at 2022-06-11 23:25:54.341942
# Unit test for function program
def test_program():
    try:
        program([])
    except ValueError:
        pass
    else:
        assert False, "Should have thrown a ValueError"

# Generated at 2022-06-11 23:25:55.835680
# Unit test for function program
def test_program():
    assert program([]) == ExitStatus.SUCCESS


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:26:41.950434
# Unit test for function program
def test_program():
    try:
        import pytest
    except:
        print("Tests need pytest to be installed.")
        exit()
    env = Environment()
    env.stdout = sys.stdout
    parser = argparse.ArgumentParser(prog='http')
    parser.add_argument('--output-options')
    parser.add_argument('--stream')
    args = parser.parse_args(['--output-options', 'test_output_options', '--stream', 'test_stream'])
    args.output_options = ["test_output_options"]
    args.stream = "test_stream"
    assert(program(args, env) == ExitStatus.SUCCESS)

if __name__ == '__main__':
    status = main()
    exit(status)

# Generated at 2022-06-11 23:26:43.276068
# Unit test for function program
def test_program():
    assert program(args=[], env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:26:46.524642
# Unit test for function main
def test_main():
    env = Environment()
    args = ['test']
    exit_status = main(args=args, env=env)
    print(exit_status)
    return exit_status


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 23:26:56.639983
# Unit test for function program
def test_program():
    import keyring
    import hashlib
    import codecs
    import base64

    # Test for Post
    env = Environment()
    env.stdin = open('../test_files/test.json', 'rb')
    env.stdin_encoding = 'utf-8'
    args = ['http', '-v', 'http://httpbin.org/post', 'key1=value1', 'key2=@../test_files/test.json', 'key3=@../test_files/test.txt', '--form', '--json', '--headers=Authorization:Basic', '--print=BH', '--output=../test_files/output.json']
    program(args=args, env=env)
    # Test for Get
    env = Environment()

# Generated at 2022-06-11 23:26:57.496989
# Unit test for function program
def test_program():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:27:08.818836
# Unit test for function program
def test_program():
    environment = Environment()
    args_namespace = argparse.Namespace(
        auth=None,
        headers=None,
        output_options=[],
        output_file=None,
        output_file_specified=False,
        method=None,
        query_string=[],
        timeout=None,
        verify=None,
        verify_ssl=False,
        max_redirects=None,
        traceback=False,
        debug=False,
        download=False,
        download_resume=True,
        follow=False,
        check_status=True,
        quiet=False,
        verbose=False,
        json=None,
        form=None,
        body=None,
    )

    assert program(args_namespace, environment) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:27:18.477439
# Unit test for function program
def test_program():
    import pytest
    from httpie import ExitStatus
    from httpie.cli.definition import parser
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.context import Environment
    from httpie.input import SEP_CREDENTIALS
    from httpie.clitools import get_auth_plugin
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPTokenAuth
    from httpie.compat import is_windows

    env = Environment()
    parse = parser.parse_args
    # env.stdin_isatty = False
    args = parse(args=['--debug'], env=env)
    print_debug_info(env)
    if args == ['--debug']:
        assert ExitStatus.SUCCESS == 0
    print

# Generated at 2022-06-11 23:27:23.114529
# Unit test for function main
def test_main():
    import pytest
    from requests import Timeout
    from httpie.cli.definition import parser


    argv = [
        'http',
        "--auth", "username:password"
        ]

    default_config_dir = parser.get_default('config_dir')
    parser.get_default('config_dir').return_value = None

    with pytest.raises(Timeout):
        main(args=argv)

# Generated at 2022-06-11 23:27:33.407558
# Unit test for function program
def test_program():
    """
    Unit test for function program
    """

    class MockParser:
        """
        Mock class for parser
        """

        def __init__(self):
            self.args = argparse.Namespace()
            self.args.check_status = False
            self.args.download = False
            self.args.download_resume = False
            self.args.follow = False
            self.args.max_redirects = 10
            self.args.output_file = None
            self.args.quiet = False
            self.args.timeout = 30
            self.args.output_options = ["json.stream"]

# Generated at 2022-06-11 23:27:43.055628
# Unit test for function program
def test_program():
    import io
    import sys
    import requests
    import argparse
    from httpie.cli.parser import parser

    args = parser.parse_args(args=["--header", "Content-Type: application/json", "--output=json", "-H", "Accept: application/json", "PUT", "http://localhost:5000/student/3", ''' { "name": "Sara", "age": 35, "grade": 87.5 } '''], env=Environment())
    env = Environment()
    env.stdin_encoding = 'utf8'
    env.stdin = io.StringIO()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    args.headers.append(('Content-Type', 'application/json'))

# Generated at 2022-06-11 23:28:15.592204
# Unit test for function main
def test_main():
    from httpie.tests.utils import TestEnvironment
    from httpie.cli.parser import parser
    args = parser.parse_args(args=['http', 'http://www.google.com'], env = TestEnvironment(stdin_isatty=True))
    program(args, env=TestEnvironment(stdin_isatty=True))

# Generated at 2022-06-11 23:28:16.548675
# Unit test for function main
def test_main():
    # TODO: needs non-trivial refactoring to make it possible to test
    assert True

test_main()

# Generated at 2022-06-11 23:28:21.434114
# Unit test for function main
def test_main():
    args = ["httpie-0.9.9", "GET", "http://httpbin.org/get?a=1", "b=2", "Accept:application/json"]
    env = Environment()
    program_name, *args = args
    env.program_name = os.path.basename(program_name)
    args = decode_raw_args(args, env.stdin_encoding)
    plugin_manager.load_installed_plugins()

    from httpie.cli.definition import parser

    if env.config.default_options:
        args = env.config.default_options + args

    include_debug_info = '--debug' in args
    include_traceback = include_debug_info or '--traceback' in args

    if include_debug_info:
        print_debug_info(env)
       

# Generated at 2022-06-11 23:28:23.598185
# Unit test for function main
def test_main():
    import argparse
    import os
    import sys

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:28:30.349135
# Unit test for function program
def test_program():
    from httpie.context import Environment
    import io
    def main(args: List[Union[str, bytes]] = sys.argv, env=Environment()) -> ExitStatus:
        program_name, *args = args
        env.program_name = os.path.basename(program_name)
        args = decode_raw_args(args, env.stdin_encoding)
        plugin_manager.load_installed_plugins()

        from httpie.cli.definition import parser

        if env.config.default_options:
            args = env.config.default_options + args

        try:
            parsed_args = parser.parse_args(
                args=args,
                env=env,
            )
        except KeyboardInterrupt:
            env.stderr.write('\n')

        exit_status = ExitStatus.SUCC

# Generated at 2022-06-11 23:28:39.655953
# Unit test for function main
def test_main():
    raw_args = ['--debug']
    assert main(args=raw_args) == ExitStatus.SUCCESS
    raw_args = ['--download', 'https://httpbin.org/image/jpeg']
    assert main(args=raw_args) == ExitStatus.SUCCESS
    raw_args = ['httpbin.org']
    assert main(args=raw_args) == ExitStatus.SUCCESS
    raw_args = ['httpbin.org', 'Accept:text/html']
    assert main(args=raw_args) == ExitStatus.SUCCESS
    # test POST JSON data
    raw_args = ['httpbin.org', 'Accept:text/html', 'cookie:chocolate', 'name:Bryan']
    assert main(args=raw_args) == ExitStatus.SUCCESS
    # test PUT data


# Generated at 2022-06-11 23:28:48.841390
# Unit test for function program
def test_program():
    assert program(args=argparse.Namespace(
        output_options=[ OUT_REQ_BODY ],
        output_file=None,
        output_file_specified=False,
        download=False,
        download_resume=True,
        follow=False,
        check_status=False,
        quiet=False,
        headers=[],
        verbose=False
    ), env=Environment(stderr=MockFile(), stdout=MockFile())) == ExitStatus.SUCCESS

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-11 23:28:58.653180
# Unit test for function main
def test_main():
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    env = Environment()
    args = ['--debug', '--auth=admin:admin', '--output-options={}', 'https://httpbin.org/get']
    args = decode_raw_args(args, env.stdin_encoding)
    plugin_manager.load_installed_plugins()

    from httpie.cli.definition import parser

    if env.config.default_options:
        args = env.config.default_options + args

    include_debug_info = '--debug' in args

# Generated at 2022-06-11 23:29:00.519675
# Unit test for function main
def test_main():
    assert main(['http', 'httpbin.org/get']) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:29:01.698782
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:30:28.217535
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie import __main__ 

    args = parser.parse_args(args=['--max-redirects=0', 'https://httpbin.org/redirect/1'], env=env)
    status = __main__.program(args=args, env=env)
    assert status.name == 'ERROR_TOO_MANY_REDIRECTS'


# Generated at 2022-06-11 23:30:37.786904
# Unit test for function main
def test_main():
    try:
        main(["http://httpbin.org/get"])
    except SystemExit as e:
        assert e.code == ExitStatus.SUCCESS

    try:
        main(["http://httpbin.org/status/500"])
    except SystemExit as e:
        assert e.code == ExitStatus.ERROR_HTTP_5XX

    try:
        main(["http://httpbin.org/status/400"])
    except SystemExit as e:
        assert e.code == ExitStatus.ERROR_HTTP_4XX

    try:
        main(["http://httpbin.org/status/100"])
    except SystemExit as e:
        assert e.code == ExitStatus.ERROR_HTTP_1XX


# Generated at 2022-06-11 23:30:45.098571
# Unit test for function program
def test_program():
    from httpie.cli.constants import OUT_REQ_HEAD, OUT_RESP_HEAD


# Generated at 2022-06-11 23:30:48.150706
# Unit test for function program
def test_program():
    args = ['test.test_program', '--body', 'test']
    env = Environment()
    assert(program(args=args, env=env) == ExitStatus.SUCCESS)


# Generated at 2022-06-11 23:30:52.596591
# Unit test for function main
def test_main():
    global sys
    sys = __import__('sys_mock')
    assert main(args=['httpie']) == ExitStatus.SUCCESS
    assert sys.stdout.value == ''
    assert sys.stderr.value == 'HTTPie 1.0.2\nRequests 2.22.0\nPython 3.6.9\n'


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:30:57.085116
# Unit test for function main
def test_main():
    import io
    import sys
    sys.argv = ["http"]
    stderr = io.StringIO()
    status = main(args=sys.argv, env=Environment(stderr=stderr))
    print(stderr.getvalue())
    assert status == ExitStatus.SUCCESS


if __name__ == "__main__":
    test_main()

# Generated at 2022-06-11 23:31:06.016628
# Unit test for function program
def test_program():
    print('Unit test for program')


# Generated at 2022-06-11 23:31:06.855968
# Unit test for function main
def test_main():
    assert 'hello' == 'hello'

# Generated at 2022-06-11 23:31:15.345206
# Unit test for function program
def test_program():
    print("\nTesting program(args, env)")
    os.chdir("..")
    os.chdir("tests")
    print("\tTesting: program([\"httpie\", \"--json\", \"GET\", \"http://httpbin.org/get\"], Environment())")
    program(["httpie", "--json", "GET", "http://httpbin.org/get"], Environment())
    print("\tTesting: program([\"httpie\", \"--form\", \"POST\", \"\"], Environment())")
    program(["httpie", "--form", "POST", ""], Environment())


# Generated at 2022-06-11 23:31:23.637067
# Unit test for function program
def test_program():
    from io import StringIO, BytesIO
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    args = argparse.Namespace()
    args.headers = [('header1','value1'),('header2','value2')]
    args.output_options = ['h', 'b']
    args.timeout = 30
    args.max_redirects = 10

    class Dummy():
        def __init__(self, encoding='utf-8'):
            self.encoding = encoding
            self.buffer = BytesIO('')
        def write(self, data):
            self.buffer.write(data.encode(self.encoding))
        def read(self, data):
            return self.buffer.getvalue()
        def isatty(self):
            return True

    env