

# Generated at 2022-06-11 23:23:37.588716
# Unit test for function program
def test_program():
    from tests.utils import http
    from httpie.cli import main
    import requests
    import socket
    # not an error
    exit_status = main.program([http, 'http://localhost:80'])
    assert exit_status == ExitStatus.SUCCESS
    # not an error
    exit_status = main.program([http, 'www.google.com'])
    assert exit_status == ExitStatus.SUCCESS
    # timeout
    exit_status = main.program([http, '--timeout=3', 'localhost:80'])
    assert exit_status == ExitStatus.ERROR_TIMEOUT
    # server not found
    exit_status = main.program([http, 'localhost:59'])
    assert exit_status == ExitStatus.ERROR
    # max redirects

# Generated at 2022-06-11 23:23:48.702673
# Unit test for function main
def test_main():
    class Env:
        def __init__(self):
            self.program_name = 'http'
            self.config_dir = 'config'
            self.config = Env
            self.stdin_encoding = 'utf-8'
            self.is_windows = False
            self.is_macos = False
            self.stdout_isatty = True
            self.stdin_isatty = True
            self.stdout = sys.stdout
            self.stdin = sys.stdin
            self.stderr = sys.stderr
            self.stdin_isatty = True
            self.stdout_isatty = True
            self.color = True
            self.format = ['json']
            self.stream = False
            self.follow = False

# Generated at 2022-06-11 23:23:49.686183
# Unit test for function program
def test_program():
    pass


# Generated at 2022-06-11 23:23:50.304279
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 23:23:55.987192
# Unit test for function main
def test_main():
    import pytest
    from httpie import ExitStatus
    from httpie.core import program
    from httpie.cli.constants import ExitStatus
    import sys
    env = Environment()
    assert main(['httpie', '--version'], env) == ExitStatus.SUCCESS
    assert main(['httpie', '-h'], env) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:24:05.602201
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    from httpie.compat import str
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.status import ExitStatus
    from httpie.utils import get_response
    env = Environment()
    config = Config(directory='')
    args = parser.parse_args(args=['--json', 'https://github.com/'], env=env, config_dir=config.directory)
    exit_code = program(args=args, env=env)
    if exit_code == ExitStatus.SUCCESS:
        assert (get_response(args=args, env=env).status_code == 200)
    else:
        pass


# Generated at 2022-06-11 23:24:06.681764
# Unit test for function main
def test_main():
    from httpie.core import main
    main()

# Generated at 2022-06-11 23:24:10.393734
# Unit test for function main
def test_main():
    if platform.system() == 'Windows':
        return
    else:
        import httpie.output.formatters.colors as colors
        colors.disable_colors = True
        main(['https://www.google.com', '-v'])

# Generated at 2022-06-11 23:24:13.550793
# Unit test for function program
def test_program():
    test_args = ['http', '--pretty=all', 'https://httpbin.org/get']
    main(args=test_args)

# Generated at 2022-06-11 23:24:17.748236
# Unit test for function program
def test_program():
    class FakeArgumentParser:
        def parse_args(self, args: List[Union[str, bytes]], env: Environment) -> ExitStatus:
            return ExitStatus.SUCCESS

    parser = FakeArgumentParser()

    try:
        result = program(None, parser, Environment())
        assert result == 0
    except Exception as e:
        assert False, e.args[0]

# Generated at 2022-06-11 23:24:48.728734
# Unit test for function main
def test_main():
    from unittest.mock import Mock

    env = Environment()
    result = main(args = ['https://httpbin.org/get'], env=env)
    assert result == ExitStatus.SUCCESS

    result = main(args = ['https://httpbin.org/post', "hello=world", "name=lhy"], env=env)
    assert result == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:24:55.863909
# Unit test for function main
def test_main():
    class TempDir:
        def __init__(self):
            import tempfile, shutil
            self.d = tempfile.mkdtemp()
            self.filename = os.path.join(self.d, 'foo.html')
        def __enter__(self):
            return self.d
        def __exit__(self, exc_type, exc_value, traceback):
            shutil.rmtree(self.d)

    from httpie.cli.argtypes import KeyValueArg, KeyValueArgType
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD

    with TempDir() as tmp_dir:
        url = 'http://localhost:8080/example.html'

# Generated at 2022-06-11 23:25:00.246995
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser

    args = parser.parse_args(['--debug', '--download', 'https://www.google.com'])
    env = Environment()

    exit_status = program(args=args, env=env)
    print(exit_status)


if __name__ == '__main__':
    test_program()

# Generated at 2022-06-11 23:25:10.715664
# Unit test for function program
def test_program():
    import unittest

    from httpie.cli.definition import parser as cli
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    class TestProgram(unittest.TestCase):
        def setUp(self):
            self.env = Environment()

        def assert_outputs_all(
            self,
            expected_output_iterable,
            output_options: List[int] = None,
            output_file=None,
            stdin=b'',
            httpbin='http://httpbin.org/{method}',
            method='get',
            **kwargs
        ):
            kwargs.setdefault('c', None)
            if output_options:
                kwargs.setdefault('output_options', [])
                kw

# Generated at 2022-06-11 23:25:22.215698
# Unit test for function program
def test_program():
    env = Environment()
    env.stdin = sys.stdin
    env.stdin_isatty = False
    env.stdout = sys.stdout
    env.stdout_isatty = True
    env.stderr = sys.stderr
    env.stderr_isatty = True
    env.config = {
        'default_options': [],
        '__meta__': None
    }
    args = argparse.Namespace(
        output_options=[],
        output_file=None,
        follow=True,
        download=False,
        download_resume=False
    )
    env.config.directory = str(Path(__file__).parent)
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:25:24.588925
# Unit test for function program
def test_program():
    args = argparse.Namespace(
        output_options=[], headers=[], method='GET',
        download=False, download_resume=False, output_file=None, output_file_specified=False
    )

    env = Environment()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:25:26.028541
# Unit test for function main
def test_main():
    try:
        assert main() == 0
    except KeyboardInterrupt:
        assert True

# Generated at 2022-06-11 23:25:32.620329
# Unit test for function main
def test_main():
    from httpie.cli.argtypes import KeyValueArg, KeyValueArgType
    from httpie.cli.definition import parser
    from httpie.context import Environment

    arg_parser = argparse.ArgumentParser(
        prog='hello_world',
        add_help=False,
        formatter_class=argparse.RawTextHelpFormatter,
    )
    arg_parser.add_argument('--test',
        action='store_true',
        required=False,
        help='test help',
    )
    arg_parser.add_argument('--url',
        action='store',
        required=True,
        help='url help',
    )

# Generated at 2022-06-11 23:25:33.888019
# Unit test for function program
def test_program():
    assert program(['http']) is ExitStatus.SUCCESS

# Generated at 2022-06-11 23:25:35.896391
# Unit test for function main
def test_main():
    from httpie import __main__

    assert main(env=__main__.env) == __main__.env.exit_status

# Generated at 2022-06-11 23:28:14.095962
# Unit test for function main
def test_main():
    # Unit test for function main
    env = Environment()
    # for simple test
    # argv = ['http', '--json', 'google.com']
    # argv = ['http', '--json', '--ignore-stdin', 'GET http://google.com']
    # argv = ['http', '--json', '--ignore-stdin', 'POST http://google.com hello="world"']
    # argv = ['http', '--json', '--ignore-stdin', 'POST http://google.com hello=@test.txt']
    # argv = ['http', '--json', '--ignore-stdin', 'POST http://google.com < test.txt']
    # argv = ['http', '--json', '--ignore-stdin', 'POST http://google.com < test.txt']
    # arg

# Generated at 2022-06-11 23:28:25.177717
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from httpie.cli.definition import parser
    from httpie.output.defaults import DEFAULT_OPTIONS
    from httpie.config import DEFAULT_CONFIG_DIR
    import inspect
    import os
    import json
    import sys
    import requests
    from httpie.plugins import FormatterPlugin
    import pytest
    def plugin_load():
        return
    def mock_formatter_plugin(self, output_stream, color_settings, PygmentsClass):
        return
    def mock_print(self, args, env, outfile):
        return
    with patch('httpie.plugins.registry.PluginManager.load_installed_plugins') as mock_method:
        mock_method.side_effect = plugin_load

# Generated at 2022-06-11 23:28:27.775729
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    return main(args=['--debug', '--form', 'status=200'], env=Environment())

if __name__ == "__main__":
    test_program()

# Generated at 2022-06-11 23:28:37.256777
# Unit test for function program
def test_program():
    from httpie.output.writer import bytes_writer
    from httpie.cli.definition import parser
    from httpie.config import Config
    from httpie.context import Environment

    args = parser.parse_args(args=['a','b','c','--timeout','0','--max-redirects','10'])

    env = Environment()
    env.stdin_encoding = 'UTF-8'
    env.stdin = sys.stdin
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.config = Config(directory = './tests/', config_file_name = 'httpie_test.cfg')

    exit_status = program(args = args, env = env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:28:38.409482
# Unit test for function program
def test_program():
    args = 1
    env = 1
    program(args, env)

# Generated at 2022-06-11 23:28:50.852837
# Unit test for function program
def test_program():
    class argparse:
        class Namespace:
            def __init__(self):
                self.headers = "nothing"
                self.output_options = "nothing"
                self.output_file_specified = False
                self.quiet = False
                self.check_status = True
                self.follow = False
                self.download = False
                self.download_resume = False
                self.output_file = None
                self.url = "nothing"
                self.request = "nothing"
                self.method = "nothing"
                self.data = "nothing"
                self.data_binary = False
                self.files = "nothing"
                self.auth = "nothing"
                self.auth_type = "nothing"
                self.headers = "nothing"
                self.json = "nothing"
                self.form = False

# Generated at 2022-06-11 23:29:00.032121
# Unit test for function program
def test_program():
    """test for function program"""
    import argparse
    class FakeEnv:
        """fake class for env"""
        def __init__(self):
            self.stdout = ""
            self.stdout_isatty = False
            self.stderr = ""

# Generated at 2022-06-11 23:29:10.761629
# Unit test for function program
def test_program():
    env = Environment()
    env.program_name = "http"
    args = ["GET", "http://www.google.com"]
    main(args, env)
    main(["--download", "http://www.google.com"], env)
    main(["--download", "--output", "./test.html", "http://www.google.com"], env)
    main(["--download", "--output", "./test.html", "--continue", "http://www.google.com"], env)
    main(["--download", "--output", "./test.html", "--download-resume", "http://www.google.com"], env)
    main(["--download", "--output", "./test.html", "--download-resume", "--continue", "http://www.google.com"], env)



# Generated at 2022-06-11 23:29:21.824087
# Unit test for function program
def test_program():
    def test_argparse_namespace(args):
        class argparse_namespace:
            def __init__(self):
                self.headers = args[0]
                self.output_options = args[1]
                self.output_file = args[2]
                self.quiet = args[3]
                self.download = args[4]
                self.follow = args[5]
                self.check_status = args[6]
                self.download_resume = args[7]
        return argparse_namespace()

    class environment:
        def __init__(self):
            self.stdout_isatty = True
            self.config = self

        @property
        def stdout(self):
            class stdout:
                def __init__(self):
                    self.buffer = self

# Generated at 2022-06-11 23:29:29.795881
# Unit test for function program
def test_program():
    import argparse
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.definition import parser
    from httpie.compat import urlencode
    from httpie.downloads import Downloader
    from httpie.input import ParseError
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import get_plugins

    #
    # Invocations with an invalid request
    #

    # No URL.
    with pytest.raises(ParseError):
        program(args=parser.parse_args(['GET']), env=Environment())

    # Invalid URL.
    with pytest.raises(ParseError):
        program(args=parser.parse_args(['GET', ':']), env=Environment())


    #
    # Invocations with a valid request

# Generated at 2022-06-11 23:31:00.170921
# Unit test for function program
def test_program():
    args = program(args = ['./http --print=b http://httpbin.org/'], env = Environment())
    assert args == ExitStatus.SUCCESS

if __name__ == '__main__':
	main()

# Generated at 2022-06-11 23:31:01.592724
# Unit test for function program
def test_program():
    def func():
        return "hello world"
    print(func())

# Generated at 2022-06-11 23:31:11.341161
# Unit test for function main
def test_main():
    """
    this function test the function main, it checks if the function return value is correct
    """
    sys.argv = ["httpie.exe", "--help"]
    assert main().name == ExitStatus.SUCCESS.name
    sys.argv = ["httpie.exe", "--version"]
    assert main().name == ExitStatus.SUCCESS.name
    sys.argv = ["httpie.exe", "--json", "httpbin.org/status/418"]
    assert main().name == "ERROR_UNKNOWN"
    sys.argv = ["httpie.exe", "--headers", "httpbin.org/"]
    assert main().name == ExitStatus.SUCCESS.name
    sys.argv = ["httpie.exe", "--check-status", "httpbin.org/"]

# Generated at 2022-06-11 23:31:21.248092
# Unit test for function main
def test_main():
    import sys
    from contextlib import contextmanager
    from io import StringIO
    from unittest.mock import call
    from httpie import ExitStatus

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    class Env:
        def __init__(self):
            self.stderr = 'stderr value'
            self.stdout = 'stdout value'
            self.stdin = 'stdin value'

# Generated at 2022-06-11 23:31:22.950466
# Unit test for function main
def test_main():
    assert main(['--debug', '--traceback']) == ExitStatus.ERROR
    assert main(['--debug']) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:31:34.103492
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from requests.exceptions import ConnectionError
    from httpie.cli.config import CONFIG_DIR

# Generated at 2022-06-11 23:31:37.180038
# Unit test for function program
def test_program():
    main(["get", "https://www.baidu.com/", "-H", "User_Agent: Baidu Spider"])


if __name__ == '__main__':
    main()
    test_program()

# Generated at 2022-06-11 23:31:41.184091
# Unit test for function main

# Generated at 2022-06-11 23:31:48.324575
# Unit test for function program
def test_program():
    # passing empty list of args
    args = []
    
    # passing args with -v
    args = ['--debug']
    main(args)

    # passing args with timeout 1s
    args = ['--timeout=1']
    main(args)

    # passing args with timeout 0s
    args = ['--timeout=0']
    main(args)

    # passing args with invalid follow url
    args = ['--follow', 'randominvalidurl']
    main(args)

    # passing args with invalid timeout
    args = ['--timeout=asd']
    main(args)
    
    
if __name__ == '__main__':
    test_program()

# Generated at 2022-06-11 23:31:57.442958
# Unit test for function main
def test_main():
    from httpie.client import collect_messages
    from httpie.cli.parser import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie import ExitStatus
    from httpie.context import Environment
    from httpie.cli.parser import StatusCodes
