

# Generated at 2022-06-11 23:23:20.053014
# Unit test for function program
def test_program():
    from httpie.cli.constants import CONFIG_DIR_PATH, DEFAULT_CONFIG_PATH
    import shutil, tempfile
    import os
    import sys
    import json

# Generated at 2022-06-11 23:23:31.879405
# Unit test for function main
def test_main():
    def test_exit_code(args, expected):
        global __file__
        from httpie import context
        from httpie.compat import is_py26
        from httpie.cli import main
        try:
            env = context.Environment()
            assert main(args=args, env=env) == expected
        except SystemExit as e:
            if is_py26:
                # Python 2.6 raises a string exception.
                # In this case we assume that it's our own SystemExit
                # with a custom code, so return that code.
                assert e.message == str(expected)
                return int(e.message)
            else:
                raise
    assert test_exit_code(['GET', '--debug', 'https://httpbin.org/status/418'], 0) == 0

# Generated at 2022-06-11 23:23:37.417485
# Unit test for function main
def test_main():
    import pytest
    from unittest.mock import MagicMock
    from io import StringIO

    env = MagicMock()
    env.stdin = StringIO()
    env.stdin.encoding = 'ASCII'
    env.stderr = StringIO()
    env.program_name = 'nttt'
    main(['nttt', '-v', '--form', 'POST', 'https://httpbin.org/post', 'a=1'], env)


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-11 23:23:39.284327
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-11 23:23:47.367128
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(
        args=['get', 'http://httpbin.org/get'],
        env=Environment()
    )
    program(args=args, env=Environment()) # Should not throw exceptions.
    print("test passed. Check to see if return value is 200")
    print("test_program() passed")

if(__name__ == '__main__'):
    program(args=['get', 'http://httpbin.org/get', '-v'], env=Environment())

# Generated at 2022-06-11 23:23:48.881435
# Unit test for function main
def test_main():
    env = Environment()
    assert main([],env=env) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:23:51.061185
# Unit test for function program
def test_program():
    main(args=['https://httpbin.org/get'])

if __name__ == '__main__':
    test_program()

# Generated at 2022-06-11 23:24:00.621872
# Unit test for function program

# Generated at 2022-06-11 23:24:13.320761
# Unit test for function main
def test_main():
    # coverage: exclude
    import shutil
    import tempfile
    import unittest.mock as mock
    from httpie.context import Environment
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.base import parser
    from tests.helpers import TestEnvironment

    # Mock stderr (do not clutter output)
    tmp_stderr = tempfile.TemporaryFile('w')

# Generated at 2022-06-11 23:24:22.759156
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    def get_args(args) -> argparse.Namespace:
        return parser.parse_args(args=args, env=Environment())
    args = ['--debug']
    status = main(args)
    assert status == ExitStatus.SUCCESS

    url = 'https://httpbin.org/get'
    args = [url]
    status = main(args)
    assert status == ExitStatus.SUCCESS

    args = [url, '-v']
    status = main(args)
    assert status == ExitStatus.SUCCESS

    args = ['--traceback', url, '-v']
    status = main(args)
    assert status == ExitStatus.SUCCESS

    args = ['-o', 'output.html', url]
    status = main(args)
   

# Generated at 2022-06-11 23:25:54.431019
# Unit test for function program
def test_program():
    env = Environment()
    args = argparse.Namespace()
    args.headers = []
    args.output_options = []
    args.download = False
    args.output_file = None
    args.output_file_specified = False
    args.follow = False
    args.check_status = False
    args.quiet = True
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:26:04.368477
# Unit test for function program
def test_program():
    environment = Environment(stdin=io.StringIO(""),stdin_isatty=False)
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug",action="store_true")
    parser.add_argument("--output-options", default = [OUT_RESP_BODY,OUT_RESP_HEAD], nargs='?')
    parser.add_argument("--download",action="store_true")
    parser.add_argument("--output-file",default=None)
    parser.add_argument("--download-resume",action="store_true")
    parser.add_argument("--follow",action="store_true")
    parser.add_argument("--check-status",action="store_true")
    parser.add_argument("--quiet",action="store_true")
    parser.add

# Generated at 2022-06-11 23:26:06.098313
# Unit test for function main
def test_main():
    args = 'http ie.org'.split()
    assert main(args) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:26:08.337986
# Unit test for function main
def test_main():
    args = ['--debug']
    main(args)
    env = Environment()
    main(args, env)



# Generated at 2022-06-11 23:26:08.986877
# Unit test for function program
def test_program():
    assert True

# Generated at 2022-06-11 23:26:14.342195
# Unit test for function main
def test_main():
    ret_value = main(["httpie", "--version"])
    assert ret_value == ExitStatus.SUCCESS
    ret_value = main(["httpie", "--help"])
    assert ret_value == ExitStatus.SUCCESS
    ret_value = main(["httpie", "--index"])
    assert ret_value == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:26:16.517973
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    env = Environment()
    assert program(args, env) == ExitStatus.SUCCESS



# Generated at 2022-06-11 23:26:22.127157
# Unit test for function program
def test_program():
    from mock import Mock
    from requests.models import Response
    args = ["http://httpie.org"]
    args = argparse.Namespace(args=args,
                              headers="header-value",
                              verbose=0)
    env = Environment()
    env.stdout = Mock()
    program(args=args, env=env)
    assert env.stdout.write.call_count == 1


# Generated at 2022-06-11 23:26:22.712558
# Unit test for function program
def test_program():
    print(program())

# Generated at 2022-06-11 23:26:28.455315
# Unit test for function program
def test_program():
    from httpie import exit_statuses
    from httpie.cli import engine
    from httpie.cli.parser import parser
    from httpie.output.streams import UnsupportedEnvironment
    args = parser.parse_args([
        '--download', 'https://github.com/jakubroztocil/httpie/archive/master.zip'
    ])
    try:
        engine.program(args=args, env=Environment())
    except UnsupportedEnvironment:
        pass

# Generated at 2022-06-11 23:27:02.926335
# Unit test for function program
def test_program():
    import unittest
    unittest.main()

# Run the unit test

# Generated at 2022-06-11 23:27:13.475772
# Unit test for function main
def test_main():
    assert main(['--version']) == 0
    assert main(['--help']) == 0
    assert main(['--nonexistent_option']) != 0
    assert main(['get', 'https://httpbin.org/get']) == 0
    assert main(['get', 'https://httpbin.org/get', '--help']) == 0
    assert main(['get', 'https://httpbin.org/status/200']) == 0
    assert main(['get', 'https://httpbin.org/status/404']) == ExitStatus.ERROR_HTTP_4XX
    assert main(['get', 'https://httpbin.org/status/500']) == ExitStatus.ERROR_HTTP_5XX
    assert main(['get', 'https://httpbin.org/status/533']) == ExitStatus.ERROR_HTTP_

# Generated at 2022-06-11 23:27:16.816876
# Unit test for function program
def test_program():
    import pytest
    from httpie import ExitStatus
    from httpie.cli.argparser import parser

    args = parser.parse_args([
        '--headers', 'Accept: */*',
        '--auth', 'user:pass',
        'https://httpbin.org/get',
        'Foo:Bar',
        'Baz:',
    ])

    assert not program(args=args, env=Environment())
    assert program(args=args, env=Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:27:17.376368
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-11 23:27:25.266728
# Unit test for function program
def test_program():
    args = argparse.Namespace()
    args.headers = []
    args.output_file = None
    args.output_file_specified = False
    args.download = False
    args.download_resume = False
    args.check_status = False
    args.quiet = False
    args.follow = False
    args.max_redirects = 10
    args.output_options = ['all']
    args.timeout = '20'
    args.error_traceback = False
    args.verbose = 1
    args.debug = False
    args.pretty = None
    args.style = None
    args.colors = None
    args.stream = False
    args.all = False
    args.form = False
    args.json = False
    args.headers = False

# Generated at 2022-06-11 23:27:34.309328
# Unit test for function main
def test_main():
    from httpie.context import Environment
    env = Environment()
    assert main(['http', '--traceback', 'https://httpbin.org/', '--headers'], env) == 1
    assert main(['http', '--traceback', 'https://httpbin.org/', '--headers'], env) == 1
    assert main(['http', '--traceback', 'https://httpbin.org/', '--headers'], env) == 1
    assert main(['http', '--traceback', 'https://httpbin.org/', '--headers'], env) == 1

if __name__ == '__main__':
    main()



# Generated at 2022-06-11 23:27:40.598704
# Unit test for function main
def test_main():
    exit_status = main(['--debug'])
    assert not exit_status
    exit_status = main(['--traceback'])
    assert not exit_status
    exit_status = main(['--check-status', 'https://httpie.org/status/100'])
    assert exit_status == ExitStatus.ERROR_HTTP_2XX
    # exit_status = main(['https://httpie.org/status/404'])
    # assert exit_status == ExitStatus.ERROR

# Generated at 2022-06-11 23:27:50.403003
# Unit test for function main
def test_main():
    """
    This is a unit test for the main function
    """
    from httpie.context import Environment
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.client import collect_messages
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.cli.definition import parser
    env = Environment()

    args = ['httpie', '-h']
    main(args)

    args = ['httpie', '--debug']
    main(args)


# Generated at 2022-06-11 23:27:54.440643
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://example.org'])
    env = Environment()
    main(args=args, env=env)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 23:28:04.342281
# Unit test for function main
def test_main():
    environment = Environment()
    environment.stderr = sys.stderr
    
    class argparse_namespace(object):
        def __init__(self):
            self.check_status = False
            self.config_dir = None
            self.download = True
            self.download_resume = False
            self.follow = True
            self.headers = []
            self.output_file = None
            self.output_file_specified = False
            self.output_options = ['all']
            self.quiet = False
            self.timeout = None
            self.max_redirects = 30
            self.method = "GET"
            self.url = "https://httpbin.org/get"
            self.session_read = False
            self.session_write = False
            self.session = None

# Generated at 2022-06-11 23:29:25.036093
# Unit test for function main
def test_main():
    print(decode_raw_args(['abc', b'abc'], 'utf-8')==['abc', 'abc'])
    print(decode_raw_args(['abc', b'\xC4\x98'], 'utf-8')==['abc', '\u0118'])
    print(decode_raw_args(['abc', b'\xC4\x98'], 'latin-1')==['abc', '\xC4\x98'])
    print(decode_raw_args(['abc', b'\xC4\x98'], 'iso8859-13')==['abc', '\u0118'])

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 23:29:30.325111
# Unit test for function program
def test_program():
    '''
    Test to check the return value of function program
    '''

# Generated at 2022-06-11 23:29:31.322704
# Unit test for function program
def test_program():
    from httpie import cli
    cli.program()

# Generated at 2022-06-11 23:29:37.213464
# Unit test for function main
def test_main():
    args = ['--check-status', '--follow', '--timeout', '10', '--max-redirects', '3', '--verbose', '--print=hBH', '--pretty', 'all', '--download', '--download-resume', '--output-file', 'output.txt']
    env = Environment()
    exit_status = main(args, env)

# Generated at 2022-06-11 23:29:44.077418
# Unit test for function program
def test_program():
    # TODO: Improve unit test
    import tempfile
    import requests
    import argparse
    import os
    import sys
    import httpie.config
    import httpie.env
    def test_func(args):
        args.method = 'GET'
        args.url = 'http://localhost:5000/'
        args.headers = {}
        args.ignore_stdin = True
        http_env = httpie.env.Environment()
        config = httpie.config.Config(http_env)
        parsed_args = argparse.Namespace()
        parsed_args.config_dir = config.directory
        parsed_args.output_options = {'body'}
        parsed_args.check_status = True
        parsed_args.download = False
        parsed_args.download_resume = False

# Generated at 2022-06-11 23:29:47.736977
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(['https://localhost:3000/api/v1/users/'])
    env = Environment()
    exit_status = program(args=args, env=env)
    assert exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:29:52.752290
# Unit test for function program
def test_program():
    print("====== test_program() ======")
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.output.streams import get_output_stream
    env = Environment()
    args = parser.parse_args(['get', 'http://www.python.org'], env=env)
    program(args=args, env=env)


if __name__ == '__main__':
    test_program()

# Generated at 2022-06-11 23:29:53.304946
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 23:29:58.567261
# Unit test for function program
def test_program():
    args = argparse.Namespace(check_status=False, follow=False, headers=[], output_file=None,
                              output_file_specified=False, download=False, download_resume=False,
                              output_options=[], output=None, quiet=False, verbose=False, timeout=None)
    env = Environment()
    program(args=args, env=env)

# Generated at 2022-06-11 23:30:07.992275
# Unit test for function main
def test_main():
    import io
    import unittest

    class TestIO(io.TextIOBase):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    class Tester(unittest.TestCase):
        def test_two(self):
            env = Environment(stdout=TestIO(), stdin=TestIO(), stderr=TestIO())
            assert (
                    main(
                        ['http', '--debug'],
                        env,
                    )
                    == ExitStatus.SUCCESS
            )

        def test_one(self):
            assert (
                    main(
                        ['http', '--debug'],
                    )
                    == ExitStatus.SUCCESS
            )