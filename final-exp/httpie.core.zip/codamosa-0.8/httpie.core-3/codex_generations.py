

# Generated at 2022-06-11 23:23:18.889296
# Unit test for function program
def test_program():

    # Start by creating a mock environment
    class MockEnvironment:
        def __init__(self):
            self.stdout_isatty = False
            self.stderr = "test"
            self.config = None

    class MockArgumentParser:
        def __init__(self):
            self.values = "test"
            self.url = "https://www.httpie.org"
            self.headers = "test"
            self.output_options = "test"
            self.output_file = None
            self.output_file_specified = "test"
            self.download = False
            self.download_resume = False
            self.check_status = False
            self.follow = False
            self.quiet = False

    # Start by creating a mock environment
    mock_environment = MockEnvironment()
    mock_

# Generated at 2022-06-11 23:23:24.085998
# Unit test for function program
def test_program():
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.cli.definition import parser
    args = parser.parse_args([
        '-v',
        'localhost:'
    ])
    assert program(args=args, env=Environment()) == ExitStatus.ERROR

# Generated at 2022-06-11 23:23:25.937545
# Unit test for function program
def test_program():
    program(parse_args(['http://httpbin.org/', 'test_program']), Environment())


# Generated at 2022-06-11 23:23:27.943817
# Unit test for function program
def test_program():
    args, env = object(), object()
    assert program(args, env) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:23:37.589170
# Unit test for function program
def test_program():
    class Error(Exception):
        pass

    env = Environment()
    env.stdout = io.StringIO()

    def collect_messages(args, **kwargs):
        if args.headers:
            raise Error('program.py')
        yield requests.PreparedRequest()
        yield requests.Response()

    from httpie.cli import parser

    def parse_args(args, env):
        args = parser.parse_args(args, env=env)
        args.config.directory = None
        args.output_options = [OUT_REQ_HEAD, OUT_REQ_BODY, OUT_RESP_HEAD, OUT_RESP_BODY]
        args.output_options = [OUT_REQ_HEAD]
        return args


# Generated at 2022-06-11 23:23:48.702400
# Unit test for function program
def test_program():
  import httpie
  import os
  import requests
  args = ['--debug', '1', '-f', '-a', 'X-Arg: val', '--form', 'field=value', 'https://httpbin.org/get']
  env = Environment()
  exit_status = program(args, env)
  assert exit_status == ExitStatus.SUCCESS
  
  args = ['--debug', '1', '-v', '-a', 'X-Arg: val', '--form', 'field=value', 'https://httpbin.org/get']
  env = Environment()
  exit_status = program(args, env)
  assert exit_status == ExitStatus.SUCCESS
  

# Generated at 2022-06-11 23:23:49.306775
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 23:23:59.613832
# Unit test for function program
def test_program():
    class MockEnv(Environment):
        def __init__(self):
            self.stdout = sys.stdout
            self.stderr = sys.stderr

    class MockDownloader:
        def __init__(self):
            self.finished = False
            self.interrupted = False

        def finish(self):
            self.finished = True

        def failed(self):
            self.failed = True

    class MockFinalResponse:
        def __init__(self):
            self.status_code = 200

    class MockInitialRequest:
        def __init__(self):
            self.url = None

    parser = argparse.ArgumentParser()
    parser.add_argument('--download', action = 'store_true')
    parser.add_argument('--download_resume', action = 'store_true')
   

# Generated at 2022-06-11 23:24:12.317888
# Unit test for function main
def test_main():
    assert main()
    assert main([])
    assert main(["-X", "GET", "localhost"])
    assert main(["--json", "localhost"])
    assert main(["--form", "localhost"])
    assert main(["--headers", "localhost"])
    assert main(["--check-status", "localhost"])
    assert main(["--download", "localhost"])
    assert main(["--exit-status", "localhost"])
    assert main(["--quiet", "localhost"])
    assert main(["--verbose", "localhost"])
    assert main(["--style=auto", "localhost"])
    assert main(["--style=colorful", "localhost"])
    assert main(["--style=colors", "localhost"])
    assert main(["--force-colors", "localhost"])


# Generated at 2022-06-11 23:24:20.465881
# Unit test for function main
def test_main():
    assert main(['/bin/http', '--version']) == ExitStatus.SUCCESS
    assert main(['/bin/http', '--debug']) == ExitStatus.SUCCESS
    assert main(['/bin/http', '--method', 'GET', 'httpbin.org']) == ExitStatus.SUCCESS
    assert main(['/bin/http', '--follow', '--download', 'httpbin.org/bytes/65535']) == ExitStatus.SUCCESS
    assert main(['/bin/http', '--method', 'GET', 'httpbin.org/get?key=val']) == ExitStatus.SUCCESS
    assert main(['/bin/http', '--method', 'POST', '--form', 'name=val', 'httpbin.org/post']) == ExitStatus.SUCCESS