

# Generated at 2022-06-11 23:24:00.415448
# Unit test for function program
def test_program():
    class TestEnvironment(Environment):
        download_path = ''
        download_resume_supported = ''
        download_continue_supported = ''
        download_chunk_size = ''

        def __init__(self, stdin_encoding, stdin):
            super(TestEnvironment, self).__init__(stdin_encoding,stdin)


    def fake_collect_messages(args, config_dir, request_body_read_callback):
        class FakeRequest():
            body = 'test'
            headers = {'test':'headers'}

        class FakeResponse():
            body = 'test'
            headers = {'headers':'test'}
            status_code = 200

        return [FakeRequest(), FakeResponse()]


# Generated at 2022-06-11 23:24:10.394331
# Unit test for function program
def test_program():
    import pytest
    from httpie.input import ParseError
    from httpie.cli.parser import parser

    with pytest.raises(ParseError):
        program(parser.parse_args([]),Environment())

    with pytest.raises(ParseError):
        program(parser.parse_args(['--timeout=r']),Environment())

    with pytest.raises(ParseError):
        program(parser.parse_args(['--auth-type=r']),Environment())

    with pytest.raises(ParseError):
        program(parser.parse_args(['--json=r']),Environment())

# Generated at 2022-06-11 23:24:11.182619
# Unit test for function main
def test_main():
    assert main(['httpie', 'www.example.com']) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:24:20.184931
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.input import ParseError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    args = parser.parse_args("http://httpbin.org/get".split())
    args.headers = [("Foo", "bar")]
    # Case 1: Successful Request
    assert program(args=args, env=Environment()) == ExitStatus.SUCCESS
    # Case 2: Handle errors with tracebacks
    args = parser.parse_args("http://httpbin.org/status/500".split())
    assert program(args=args, env=Environment()) == ExitStatus.ERROR
    # Case 3: Handle error with no tracebacks
    args = parser.parse_args(["--traceback", "http://httpbin.org/status/500"])

# Generated at 2022-06-11 23:24:31.136223
# Unit test for function main
def test_main():
    from httpie.cli.definition import parser
    parsed_args = parser.parse_args(
        args=[
            'http://echo.jason-french.com/get',
            'foo==bar',
            'baz',
            'Content-Type:application/json',
            '-H',
            'Cache-Control:none',
            '-v',
            '--debug'
        ],
    )

# Generated at 2022-06-11 23:24:38.212306
# Unit test for function program
def test_program():
    import subprocess
    import os
    import tempfile
    tmpfile = tempfile.NamedTemporaryFile()
    try:
        subprocess.run(['python', os.path.abspath(__file__), '--download', 'https://example.org',
                        '--output-file', tmpfile.name, '-v'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    finally:
        tmpfile.close()
    return


if __name__ == '__main__':
    print(main())

# Generated at 2022-06-11 23:24:42.206585
# Unit test for function program
def test_program():
    args = argparse.Namespace(
    output_options=['pretty'],
    )
    env = Environment()
    program(args=args, env=env)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:24:51.640161
# Unit test for function main
def test_main():
    import doctest
    from . import context
    from . import cli
    from . import downloads
    from . import errors
    from . import exit_status
    from . import sessions
    from . import status
    from . import utils
    env = context.Environment()
    doctest.testmod(cli, raise_on_error=True, extraglobs={'env': env})
    doctest.testmod(downloads, raise_on_error=True, extraglobs={'env': env})
    # A test that should not be doctested because of
    # https://github.com/python-pillow/Pillow/issues/1763
    # doctest.testmod(output.pics, raise_on_error=True, extraglobs={'env': env})

# Generated at 2022-06-11 23:24:56.100608
# Unit test for function program
def test_program():
    import sys
    import os
    sys.argv=['httpie', 'https://ringzer0ctf.com/challenges/13']
    main()

# Generated at 2022-06-11 23:25:04.151127
# Unit test for function program
def test_program():
    from httpie.cli.argtypes import KeyValueArg
    from httpie import config, env as httpie_env

    # Create dummy httpie_env.
    httpie_env.is_windows = lambda: False
    httpie_env.is_mac = lambda: True
    httpie_env.stdout_isatty = lambda: True

    class Arguments:
        def __init__(self, headers: List[KeyValueArg], config_dir: str):
            self.headers = headers
            self.config_dir = config_dir

        def __repr__(self):
            return f'<Arguments> headers={self.headers}, config_dir={self.config_dir}'


# Generated at 2022-06-11 23:25:46.953509
# Unit test for function program

# Generated at 2022-06-11 23:25:55.782035
# Unit test for function program
def test_program():
    from httpie import ExitStatus

    # Success
    assert program(
        args=argparse.Namespace(
            '--json',
            output_options=[],
            follow=False,
            download=False,
            check_status=False,
            http_method='GET',
            url='https://httpbin.org/get'
        ),
        env=Environment()
    ) == ExitStatus.SUCCESS

    # Async error
    assert program(
        args=argparse.Namespace(
            '--json',
            output_options=[],
            follow=False,
            download=False,
            check_status=False,
            http_method='GET',
            url='https://httpbin.org/delay/4'
        ),
        env=Environment()
    ) == ExitStatus.ERROR_CTRL_C



# Generated at 2022-06-11 23:26:05.915787
# Unit test for function program
def test_program():
    import io
    import sys
    import json
    import unittest
    import requests
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.cli.definition import parser
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.input import ParseError
    from httpie.status import ExitStatus
    from httpie.plugins.registry import plugin_manager
    from httpie import __version__ as httpie_version
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES

    env = Environment(stdout=io.StringIO(), stdin_encoding='utf8')
    plugin_

# Generated at 2022-06-11 23:26:07.343818
# Unit test for function program
def test_program():
    assert program(args=None, env=None) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:26:13.508169
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    args = parser.parse_args(
        args = ['http://localhost:5000/api/get_agreement_by_name/123'],
        env = Environment(stdout=sys.stdout)
    )
    assert(program(args, Environment(stdout=sys.stdout)) == ExitStatus.SUCCESS)

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-11 23:26:23.466998
# Unit test for function program
def test_program():
    import sys
    import os
    import tempfile
    import argparse
    import pytest
    import shutil
    from httpie import __version__
    from httpie.cli.constants import OUT_REQ_BODY, OUT_REQ_HEAD, OUT_RESP_BODY, OUT_RESP_HEAD
    from httpie.cli.definition import parser
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.status import ExitStatus, http_status_to_exit_status
    from httpie.downloads import Downloader
    from httpie.output.writer import write_message, write_stream, MESSAGE_SEPARATOR_BYTES
    plugin_manager.load_installed_plugins()

    exit_status = ExitStatus.SUCCESS


# Generated at 2022-06-11 23:26:32.605071
# Unit test for function main
def test_main():
    # TODO: Test coverage!
    assert main() == ExitStatus.SUCCESS
    assert main(args=['--debug']) == ExitStatus.SUCCESS
    assert main(args=['--debug', '--download']) == ExitStatus.SUSPENDED
    assert main(args=['--debug', '--download=fd.txt']) == ExitStatus.SUSPENDED
    assert main(args=['GET']) == ExitStatus.ERROR_NO_URL
    assert main(args=['--traceback', 'GET']) == ExitStatus.ERROR_NO_URL
    assert main(args=['--help']) == ExitStatus.SUCCESS
    assert main(args=['--version']) == ExitStatus.SUCCESS



# Generated at 2022-06-11 23:26:41.572037
# Unit test for function program
def test_program():
    import argparse
    class Mock_args:
        def __init__(self):
            self.headers = {}
            self.check_status = False
            self.follow = True
            self.download = False
            self.download_resume = False
            self.output_file = None
            self.output_file_specified = False
            self.quiet = False
            self.output_options = 'none'
    from httpie import Environment
    import pytest
    args = Mock_args()
    env = Environment()
    assert program(args=args,env=env) == ExitStatus.SUCCESS
    args.output_file = 'a'
    args.output_file_specified = True
    assert program(args=args,env=env) == ExitStatus.SUCCESS
    assert program(args=None,env=None)

# Generated at 2022-06-11 23:26:52.022262
# Unit test for function program
def test_program():
    assert program(args=['http', 'https://httpbin.org/get'], env=Environment()) == 0
    assert program(args=['http', 'https://httpbin.org/get', '-I'], env=Environment()) == 0
    assert program(args=['http', 'https://httpbin.org/get', '-Ib'], env=Environment()) == 0
    assert program(args=['http', 'https://httpbin.org/post', '-d', 'k=3'], env=Environment()) == 0
    assert program(args=['http', 'https://httpbin.org/post', '-d', 'k=3', '-b'], env=Environment()) == 0
    assert program(args=['http', 'https://httpbin.org/get', '-a', 'user:pass'], env=Environment())

# Generated at 2022-06-11 23:26:59.518117
# Unit test for function main
def test_main():
    return
    # Check if we can run program with both stdout and stderr as files
    # sys.stdout = open(str(Path.home.joinpath('.httpie', 'stdout.txt')), 'w')
    # sys.stderr = open(str(Path.home.joinpath('.httpie', 'stderr.txt')), 'w')
    #
    # # Run program
    # assert main(['httpie', '--debug', '--traceback', '-j', 'https://httpbin.org/get']) == ExitStatus.SUCCESS
    # assert main(['httpie', '--debug', '--traceback', 'https://httpbin.org/get']) == ExitStatus.SUCCESS
    #
    # # Check if error message on timeout is correct
    # assert main(['http

# Generated at 2022-06-11 23:27:54.525968
# Unit test for function program
def test_program():
    def test_program_helper(args: List[str], stdin_encoding: str) -> int:
        args = decode_raw_args(args, stdin_encoding)
        env = Environment()
        return program(parser.parse_args(args=args, env=env), env)
    assert ExitStatus.SUCCESS == test_program_helper(['www.baidu.com'], 'ascii')


# Generated at 2022-06-11 23:28:04.424714
# Unit test for function program
def test_program():
    exit_status = ExitStatus.SUCCESS
    # TODO: Refactor and drastically simplify, especially so that the separator logic is elsewhere.
    downloader = None
    initial_request: Optional[requests.PreparedRequest] = None
    final_response: Optional[requests.Response] = None
    bytecodes = []

# Generated at 2022-06-11 23:28:15.074972
# Unit test for function main
def test_main():
    from io import StringIO
    from httpie.cli.definition import parser

    def do_main(args: List[str]) -> ExitStatus:
        return main(args=['http'] + args, env=Environment(
            stdin_isatty=True,
            stdout_isatty=True,
            stdin=StringIO(),
            stdout=StringIO(),
            stderr=StringIO(),
            stdin_encoding='utf8',
            stdout_encoding='utf8',
            stderr_encoding='utf8',
            config=parser.DEFAULT_CONFIG,
        ))

    assert do_main(args=['--help']) == ExitStatus.SUCCESS
    assert do_main(args=['--version']) == ExitStatus.SUCCESS



# Generated at 2022-06-11 23:28:16.426688
# Unit test for function program
def test_program():
	pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 23:28:25.254808
# Unit test for function program
def test_program():
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.headers = argparse.Namespace()
    args.method = argparse.Namespace()
    args.params = argparse.Namespace()
    args.data = argparse.Namespace()
    args.json = argparse.Namespace()
    args.download = None
    args.output_file = argparse.Namespace()
    args.output_file_specified = argparse.Namespace()
    args.check_status = argparse.Namespace()
    result = program(args,env)
    print(result)

# Generated at 2022-06-11 23:28:34.793289
# Unit test for function program
def test_program():
    import pytest
    from httpie.cli.argtypes import KeyValueArg
    import json

    class Args:
        output_options = []
        headers = []
        body = {}
        form = {}
        json = None
        download = False
        output_file = ""
        output_file_specified = False
        download_resume = False
        data = ""
        files = []
        body = ""
        method = ""
        url = ""
        timeout = 0
        check_status = False
        follow = False
        quiet = False


    class Env:
        stderr = ""
        log_error = ""
        stdout_isatty = ""
        config = ""
        program_name = ""
        stdout = ""



# Generated at 2022-06-11 23:28:40.454880
# Unit test for function main
def test_main():
    from httpie.compat import is_windows
    env = Environment()
    if is_windows():
        try:
            env.stdin = open('nul', 'rb')
        except FileNotFoundError:
            env.stdin = open('nul', 'w')
    else:
        env.stdin = open('/dev/null', 'rb')
    env.stdout = io.BytesIO()
    env.stderr = io.BytesIO()
    env.stdout_isatty = False
    main(['--debug'], env=env)

# Generated at 2022-06-11 23:28:49.010207
# Unit test for function main
def test_main():
    # PYTHONPATH='..' python3 -m httpie.cli.main --debug https://httpbin.org/get
    # PYTHONPATH='..' python3 -m httpie.cli.main --debug https://httpbin.org/status/404
    # PYTHONPATH='..' python3 -m httpie.cli.main --debug https://httpbin.org/json
    # PYTHONPATH='..' python3 -m httpie.cli.main --debug https://httpbin.org/stream/20
    pass

# Generated at 2022-06-11 23:28:49.564807
# Unit test for function main
def test_main():
    print(main())

# Generated at 2022-06-11 23:28:59.198789
# Unit test for function program
def test_program():
    from httpie.cli.definition import parser
    from httpie.input import get_input_stream
    from httpie.output.streams import STDOUT
    from httpie.context import Environment
    from httpie import ExitStatus

    args = parser.parse_args(['httpie', '--debug', 'https://www.google.com'])
    main(args)

    env = Environment(stdin=get_input_stream(),
                      stdin_isatty=True,
                      stdout=STDOUT,
                      stdout_isatty=True,
                      stdin_encoding='utf8',
                      stdout_encoding='utf8',
                      stdout_raw=False)
    args = parser.parse_args(['httpie', '--debug', 'https://www.google.com'])
    program(args, env)



# Generated at 2022-06-11 23:32:06.221370
# Unit test for function program
def test_program():
	from httpie.cli.definition import parser
	from httpie.context import Environment

	args = parser.parse_args(args=['--check-status', '--download', '--output-file=test.txt', 'http://127.0.0.1/tasks'])
	env = Environment()
	try:
		program(args=args, env=env)
		assert False
	except SystemExit as e:
		assert e.code != ExitStatus.SUCCESS
		assert e.code == ExitStatus.ERROR_TOO_MANY_REDIRECTS



# Generated at 2022-06-11 23:32:09.895832
# Unit test for function main
def test_main():
    # call without any argument -> error
    assert main(["http"]) == ExitStatus.ERROR
    # call with an URL -> SUCCESS
    assert main(["http", "https://httpbin.org"]) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:32:13.829225
# Unit test for function program
def test_program():
    import httpie
    from . import mock
    from httpie.cli.definition import parser

    env = mock.Environment()
    args = parser.parse_args(
        args=['https://httpbin.org/get'],
        env=env,
    )
    exit_status = program(args, env)
    assert exit_status == httpie.ExitStatus.SUCCESS

# Generated at 2022-06-11 23:32:15.113236
# Unit test for function main
def test_main():
    assert main() == ExitStatus.SUCCESS



# Generated at 2022-06-11 23:32:25.345830
# Unit test for function program
def test_program():
    '''
    The test method which covers the main program logic
    '''
    s = 'https://www.pexels.com/search/'

# Generated at 2022-06-11 23:32:26.754940
# Unit test for function program
def test_program():
    assert program(['http://localhost:5000/'], Environment()) == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:32:27.603678
# Unit test for function program
def test_program():
    program("www.google.com", "GET")

# Generated at 2022-06-11 23:32:36.685193
# Unit test for function program
def test_program():
    from httpie.cli.parser import parser
    from httpie.cli.constants import DEFAULT_OPTIONS
    from httpie.config import Config
    from httpie.environment import Environment
    from httpie.compat import is_windows
    from httpie.context import Context
    from httpie import output

    import sys
    import os
    import shutil

    from httpie.config import (AuthCredentials, Config, __version__,
                               is_windows)
    from httpie.core import main as core_main
    from httpie.plugins import builtin
    from httpie.plugins import plugin_manager
    from httpie.models import Request, Environment
    from httpie.compat import is_windows
    import httpie.plugins
    import httpie.downloads
    import httpie.core
