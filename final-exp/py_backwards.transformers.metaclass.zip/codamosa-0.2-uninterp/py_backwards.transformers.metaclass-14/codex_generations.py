

# Generated at 2022-06-18 00:08:22.556608
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = input_code.get_ast()
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)
    assert ast_to_str(new_node) == ast_to_str(expected_code.get_ast())


# Generated at 2022-06-18 00:08:32.156047
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_to_ast
    from ..utils.tree import print_ast
    from ..utils.tree import compare_ast
    from ..utils.tree import get_node_by_path
    from ..utils.tree import get_node_by_name
    from ..utils.tree import get_node_by_type
    from ..utils.tree import get_node_by_type_and_name
    from ..utils.tree import get_node_by_type_and_value
    from ..utils.tree import get_node_by_value
    from ..utils.tree import get_node_by_value_and_name
    from ..utils.tree import get_node_by_value_and_type
    from ..utils.tree import get_node_by_value_and_

# Generated at 2022-06-18 00:08:35.297375
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse
    from ..utils.test_utils import round_trip


# Generated at 2022-06-18 00:08:44.708982
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            node.body.insert(0, ast.parse('import six').body[0])
            return self.generic_visit(node)  # type: ignore

    node = ast.parse('class A(metaclass=B): pass')
    TestTransformer().visit(node)
    assert ast_to_str(node) == 'import six\nclass A(metaclass=B): pass'



# Generated at 2022-06-18 00:08:53.910030
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import unicode
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer
    from .context import Context
    from . import transforms

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node


# Generated at 2022-06-18 00:09:04.014877
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef
    from ..utils.test_utils import parse_to_module
    from ..utils.test_utils import parse_to_stmt

    # Test case 1
    # Tested code:
    # class A(metaclass=B):
    #     pass
    # Expected result:
    # class A(_py_backwards_six_with_metaclass(B)):
    #     pass
    code = 'class A(metaclass=B):\n    pass'

# Generated at 2022-06-18 00:09:13.819736
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import compare_source

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    transform_and_compare(MetaclassTransformer, source, expected)

    source = """
        class A(B, metaclass=C):
            pass
    """

# Generated at 2022-06-18 00:09:20.517867
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare

    transform_and_compare(MetaclassTransformer,
                          """
                          class A(metaclass=B):
                              pass
                          """,
                          """
                          from six import with_metaclass as _py_backwards_six_withmetaclass
                          class A(_py_backwards_six_withmetaclass(B)):
                              pass
                          """)


# Generated at 2022-06-18 00:09:32.399995
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet

    snippet_ast = parse_snippet(six_import)
    snippet_ast.body.extend(parse_snippet(class_bases))

    class_ast = parse_ast("""
    class A(metaclass=B):
        pass
    """)

    expected_ast = parse_ast("""
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

    expected_ast.body.extend(snippet_ast.body)

    transformer = MetaclassTransformer()
    actual_ast = transformer.visit(class_ast)

# Generated at 2022-06-18 00:09:40.430065
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.unparse import Unparser

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert Unparser(tree).unparse() == source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

# Generated at 2022-06-18 00:09:49.929462
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(input_code.get_source())
    MetaclassTransformer().visit(node)
    assert ast.dump(node) == ast.dump(ast.parse(expected_code.get_source()))



# Generated at 2022-06-18 00:09:51.094235
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_node_equal
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:09:59.818439
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_equal_ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:10:04.017239
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword

    classdef = ast_classdef(name='A',
                            bases=[ast_name(id='B')],
                            keywords=[ast_keyword(arg='metaclass', value=ast_name(id='C'))])
    expected = ast_classdef(name='A',
                            bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                            args=[ast_name(id='C'), ast_name(id='B')])])
    assert MetaclassTransformer().visit(classdef) == expected

# Generated at 2022-06-18 00:10:08.410248
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import ast_to_source as a2s
    from ..utils.source import ast_to_code as a2c
    from ..utils.source import ast_to_source_and_code as a2sac
    from ..utils.source import code_to_ast as c2a
    from ..utils.source import code_to_source as c2s
    from ..utils.source import code_to_ast_and_source as c2aas
    from ..utils.source import source_to_code_and_ast as s2ca
    from ..utils.source import code_to_source_and

# Generated at 2022-06-18 00:10:16.324262
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import exec_

    @snippet
    def code():
        class A(metaclass=B):
            pass

    node = ast.parse(code.get_body())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == six_import.get_body() + code.get_body()

    # Check that the code is actually valid
    exec_(ast_to_str(node))


# Generated at 2022-06-18 00:10:26.131103
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.tree_compare import compare_ast

    class_def = ast_class(name='A',
                          bases=[],
                          keywords=[ast_keyword(arg='metaclass',
                                                value=ast_name(id='B'))])

    expected = ast_class(name='A',
                         bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                         args=[ast_name(id='B'),
                                               ast_name(id='object')],
                                         keywords=[])],
                         keywords=[])


# Generated at 2022-06-18 00:10:34.970997
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source_to_ast as ast
    from ..utils.source import source
    from ..utils.compare import compare_ast
    from ..utils.source import dedent

    source = dedent('''
        class A(metaclass=B):
            pass
    ''')
    expected = dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')
    tree = ast(source)
    MetaclassTransformer().visit(tree)
    compare_ast(tree, expected)


# Generated at 2022-06-18 00:10:35.471703
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-18 00:10:37.020551
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:10:50.714454
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_factory
    from ..utils.tree import print_tree

    class_def = ast_factory(ast.ClassDef, name='A', bases=[], keywords=[],
                            body=[], decorator_list=[])
    module = ast_factory(ast.Module, body=[class_def])
    print_tree(module)

    transformer = MetaclassTransformer()
    module = transformer.visit(module)
    print_tree(module)

    assert transformer._tree_changed is True
    assert len(module.body) == 2
    assert isinstance(module.body[0], ast.ImportFrom)
    assert isinstance(module.body[1], ast.ClassDef)

# Generated at 2022-06-18 00:10:59.849428
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_and_compare_ast
    from ..utils.test_utils import transform_and_compare_source
    from ..utils.test_utils import transform_and_compare_source_with_import

    source = """
        class A(metaclass=B):
            pass
    """
    expected_source = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """

# Generated at 2022-06-18 00:11:07.535822
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import ast_to_source as ats
    from ..utils.source import ast_to_code as atc

    # Test 1
    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    ast_node = sta(source)
    mct = MetaclassTransformer()
    mct.visit(ast_node)

# Generated at 2022-06-18 00:11:17.057942
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PYTHON_VERSION

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert tree_to_str(node) == after.get_source()

# Generated at 2022-06-18 00:11:21.805188
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import parse_ast
    from ..utils.tree import tree_to_str
    from ..utils.tree import tree_to_str_with_comments


# Generated at 2022-06-18 00:11:31.122903
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import ast_to_str
    from ..utils.tree import parse_ast_str

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = parse_ast_str(before.get_ast())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_ast()

# Generated at 2022-06-18 00:11:36.103596
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PY2

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()

# Generated at 2022-06-18 00:11:43.694500
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_factory import ast_factory
    from ..utils.snippet import snippet

    @snippet
    def source():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(source.get_source())
    node = MetaclassTransformer().visit(node)
    assert ast_to_str(node) == expected.get_source()

# Generated at 2022-06-18 00:11:50.546276
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_node_equals
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import parse_snippet_as_module
    from ..utils.test_utils import run_transformer
    from ..utils.test_utils import transform_snippet

    # Test with no metaclass
    node = parse_snippet_as_module("class A(object): pass")
    node = run_transformer(MetaclassTransformer, node)
    assert_node_equals(node, "class A(object): pass")

    # Test with metaclass
    node = parse_snippet_as_module("class A(metaclass=B): pass")

# Generated at 2022-06-18 00:11:54.830063
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compiler import compile_snippet
    from ..utils.visitor import dump

    snippet_ = snippet('''
        class A(metaclass=B):
            pass
    ''')

    tree = compile_snippet(source(*snippet_.get_source()))
    tree = MetaclassTransformer().visit(tree)
    assert dump(tree) == source(*snippet_.get_source())

# Generated at 2022-06-18 00:12:10.211570
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transformer = MetaclassTransformer()
    node = before.get_ast()
    node = transformer.visit(node)
    assert ast_to_str(node) == ast_to_str(after.get_ast())
    assert compile_snippet(node) == compile_

# Generated at 2022-06-18 00:12:12.673774
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.unparse import Unparser

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    node = ast.parse(source)
    MetaclassTransformer().visit(node)
    Unparser(node)

# Generated at 2022-06-18 00:12:23.241397
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.snippet import snippet
    from ..utils.test import run_test_snippets

    @snippet
    def test_snippet():
        class A(metaclass=B):
            pass

    @snippet
    def expected_snippet():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    test_snippet_ast = compile_snippet(test_snippet)
    expected_snippet_ast = compile_snippet(expected_snippet)

   

# Generated at 2022-06-18 00:12:29.252469
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_compare import compare_ast

    node = ast.ClassDef(name='A',
                        bases=[ast.Name(id='object', ctx=ast.Load())],
                        keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='B', ctx=ast.Load()))],
                        body=[],
                        decorator_list=[])


# Generated at 2022-06-18 00:12:39.985517
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_withmetaclass import SixWithMetaclassTransformer
    from .six_import import SixImportTransformer
    from .six_withmetaclass import SixWithMetaclassTransformer
    from .six_import import SixImportTransformer
    from .six_withmetaclass import SixWithMetaclassTransformer
    from .six_import import SixImportTransformer
    from .six_withmetaclass import SixWithMetaclassTransformer
    from .six_import import SixImportTransformer
    from .six_withmetaclass import SixWithMetaclassTransformer
    from .six_import import SixImportTransformer

# Generated at 2022-06-18 00:12:50.039245
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet
    from ..utils.test_utils import assert_ast_equal

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    assert_ast_equal(MetaclassTransformer().visit(before.get_ast()),
                     after.get_ast())
    assert compile_snippet(before) == compile_snippet(after)

# Generated at 2022-06-18 00:12:50.931361
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compat import parse
    from ..utils.unparse import Unparser


# Generated at 2022-06-18 00:12:52.914860
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:12:55.316811
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:12:56.807483
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:13:19.838267
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_equal

    code = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = ast.parse(code)
    MetaclassTransformer().visit(tree)
    assert_equal(ast_to_str(tree), expected)

# Generated at 2022-06-18 00:13:22.692105
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef


# Generated at 2022-06-18 00:13:24.654605
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast, compare_asts


# Generated at 2022-06-18 00:13:28.215751
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef


# Generated at 2022-06-18 00:13:35.188585
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_source

    source = '''
    class A(metaclass=B):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_source(tree, expected)



# Generated at 2022-06-18 00:13:41.695342
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_node

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    node = get_node(source, MetaclassTransformer)
    assert_equal_source(node, expected)

# Generated at 2022-06-18 00:13:49.981982
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import ast_to_source as ats
    from ..utils.source import code_to_ast as cta
    from ..utils.source import code_to_source as cts
    from ..utils.source import ast_to_code as atc
    from ..utils.source import source_to_code as stc
    from ..utils.source import code_to_source as cts
    from ..utils.source import source_to_ast as sta
    from ..utils.source import ast_to_source as ats
    from ..utils.source import source_to_ast_and_code as st

# Generated at 2022-06-18 00:13:58.771529
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword

    class_def = ast_class(name='A',
                          bases=[],
                          keywords=[ast_keyword(arg='metaclass',
                                                value=ast_name(id='B'))],
                          body=[])

    expected = ast_class(name='A',
                         bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                         args=[ast_name(id='B'),
                                               ast.List(elts=[])],
                                         keywords=[])],
                         keywords=[],
                         body=[])

    transformer = MetaclassTransformer()

# Generated at 2022-06-18 00:14:09.316717
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_with_metaclass import SixWithMetaclassTransformer
    from .six_with_metaclass import six_with_metaclass_import

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node

    class_def = ast.parse('class A(metaclass=B): pass').body[0]
    assert tree_to_str(class_def) == 'class A(metaclass=B): pass'
    class_def = SixImportTransformer().visit(class_def)
    assert tree_to

# Generated at 2022-06-18 00:14:20.064927
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)

    @snippet
    def test_class():
        class A(metaclass=B):
            pass

    class_def = get_ast_from_source(test_class.get_source()).body[0]

# Generated at 2022-06-18 00:14:52.741418
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast


# Generated at 2022-06-18 00:14:59.588047
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PYTHON_VERSION
    from ..utils.compat import PYTHON_VERSION_INFO

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    node = MetaclassTransformer().visit(node)
    assert tree_to_str(node) == after.get_source()

# Generated at 2022-06-18 00:15:10.009313
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_and_compile

    code = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_ast(code)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, parse_snippet(expected))
    assert transformer.tree_changed()
    assert transform_and_compile

# Generated at 2022-06-18 00:15:14.747516
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    class_def = parse_ast("""
        class A(metaclass=B):
            pass
    """)
    expected = parse_ast("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(class_def)
    assert_equal_ast(class_def, expected)

# Generated at 2022-06-18 00:15:22.590137
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_source

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    assert_source(MetaclassTransformer, source, expected)

# Generated at 2022-06-18 00:15:30.266211
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer
    from .utils import get_transformed_ast

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return self.generic_visit(node)  # type: ignore

    class TestClass(object):
        def __init__(self):
            self.a = 1

    class TestClass2(TestClass):
        def __init__(self):
            super(TestClass2, self).__init__

# Generated at 2022-06-18 00:15:39.554522
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as to_ast
    from ..utils.source import source_to_code as to_code
    from ..utils.source import source_to_ast_and_code as to_ast_and_code
    from ..utils.source import ast_to_source as to_source
    from ..utils.source import ast_to_code as to_c
    from ..utils.source import ast_and_code_to_source as to_s
    from ..utils.source import ast_and_code_to_code as to_cc
    from ..utils.source import code_to_ast as to_a
    from ..utils.source import code_to_source as to_s
    from ..utils.source import code_to_ast_and_code as to_a_and_c

# Generated at 2022-06-18 00:15:41.238060
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:15:48.165635
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree
    from ..utils.test_utils import transform_and_compare_ast
    from ..utils.test_utils import transform_and_compare_source

    source = """
        class A(metaclass=B):
            pass
    """
    expected_source = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_ast_tree(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    transform_and_compare_ast(transformer, source, expected_source)


# Generated at 2022-06-18 00:15:57.982031
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef
    from ..utils.test_utils import parse_to_module
    from ..utils.test_utils import parse_to_expr
    from ..utils.test_utils import parse_to_stmt
    from ..utils.test_utils import parse_to_object
    from ..utils.test_utils import parse_to_tuple
    from ..utils.test_utils import parse_to_list
    from ..utils.test_utils import parse_to_slice
    from ..utils.test_utils import parse_to_comprehension
    from ..utils.test_utils import parse_to

# Generated at 2022-06-18 00:17:17.314288
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_tree as stt
    from ..utils.source import tree_to_source as tts
    from ..utils.source import tree_to_code as ttc
    from ..utils.source import tree_to_ast as tta
    from ..utils.source import ast_to_source as ats
    from ..utils.source import ast_to_tree as att
    from ..utils.source import ast_to_code as atc


# Generated at 2022-06-18 00:17:20.159223
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_tree as stt
    from ..utils.source import source_to_node as stn
    from ..utils.source import source_to_nodes as stns

    # Test 1

# Generated at 2022-06-18 00:17:25.221464
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = input_code.get_ast()
    expected_node = expected_code.get_ast()
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)
    assert ast_to_str(new_node) == ast_to_str(expected_node)

# Generated at 2022-06-18 00:17:29.818073
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:17:36.065912
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import ast_to_source as a2s
    from ..utils.source import ast_to_code as a2c
    from ..utils.source import ast_to_source_and_code as a2sac
    from ..utils.source import code_to_ast as c2a
    from ..utils.source import code_to_source as c2s
    from ..utils.source import code_to_ast_and_source as c2aas
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import ast_to_source_and

# Generated at 2022-06-18 00:17:42.959124
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_builder import ast_from_str
    from ..utils.ast_visitor import ASTVisitor
    from ..utils.ast_visitor import visit_ast

    class_def = ast_from_str("""
        class A(metaclass=B):
            pass
    """)
    transformer = MetaclassTransformer()
    visit_ast(class_def, transformer)
    assert transformer._tree_changed
    assert astor.to_source(class_def) == """
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """

# Generated at 2022-06-18 00:17:50.209850
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import exec_

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

    expected = snippet.get_body(metaclass=ast.Name(id='C', ctx=ast.Load()),
                                bases=[ast.Name(id='B', ctx=ast.Load())])


# Generated at 2022-06-18 00:17:52.437406
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:17:56.808618
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import ast_load
    from ..utils.ast_helpers import ast_dump
    from ..utils.ast_helpers import ast_store
    from ..utils.ast_helpers import ast_equal


# Generated at 2022-06-18 00:18:00.372302
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    tree = ast.parse(input_code.get_body())
    MetaclassTransformer().visit(tree)
    assert ast_to_str(tree) == expected_code.get_body()