

# Generated at 2022-06-18 00:08:23.146487
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:08:32.340068
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test import run_test_on_ast

    @snippet
    def test_code():
        class A(metaclass=B):
            pass

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    test_code = test_code.get_body()
    expected = expected.strip()

    assert ast_to_str(test_code) == expected

    run_test_on_ast(test_code, expected, MetaclassTransformer)

# Generated at 2022-06-18 00:08:42.522514
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import get_metaclass

    @snippet
    def test_class():
        class A(metaclass=B):
            pass

    @snippet
    def expected_class():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    @snippet
    def test_class_no_metaclass():
        class A():
            pass

    @snippet
    def expected_class_no_metaclass():
        class A():
            pass

    @snippet
    def test_class_multiple_bases():
        class A(B, metaclass=C):
            pass

# Generated at 2022-06-18 00:08:46.542671
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import round_trip


# Generated at 2022-06-18 00:08:48.689181
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:08:56.516483
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import compare_ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='object', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:09:00.080656
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins
    from ..utils.compat import six
    from ..utils.compat import typing


# Generated at 2022-06-18 00:09:08.023780
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword

    class_def = ast_class(bases=[ast_name(id='object')],
                          keywords=[ast_keyword(arg='metaclass',
                                                value=ast_name(id='B'))],
                          name='A')
    expected = ast_class(bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                         args=[ast_name(id='B'),
                                               ast_name(id='object')],
                                         keywords=[])],
                         name='A')

    transformer = MetaclassTransformer()
    actual = transformer.visit(class_def)

# Generated at 2022-06-18 00:09:15.280412
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    class MetaclassTransformer(BaseNodeTransformer):
        """Compiles:
            class A(metaclass=B):
                pass
        To:
            class A(_py_backwards_six_with_metaclass(B))
        
        """
        target = (2, 7)

# Generated at 2022-06-18 00:09:23.634705
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = compile_snippet(before.get_source(), 'before.py', 'exec')
    node = MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()

# Generated at 2022-06-18 00:09:35.235533
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_with_metaclass import SixWithMetaclassTransformer
    from .six_with_metaclass import _six_with_metaclass_import
    from .six_with_metaclass import _six_with_metaclass_call

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:09:44.648198
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_ast

    snippet = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    node = source_to_ast(snippet)
    node = MetaclassTransformer().visit(node)
    assert tree_to_str(node) == expected
    compile_snippet(node)

# Generated at 2022-06-18 00:09:47.056660
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import ast_equal
    from ..utils.ast_helpers import dump
    from ..utils.ast_helpers import parse


# Generated at 2022-06-18 00:10:17.236692
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-18 00:10:26.852492
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    node = ast.ClassDef(name='A',
                        bases=[ast.Name(id='B', ctx=ast.Load())],
                        keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='C', ctx=ast.Load()))],
                        body=[],
                        decorator_list=[])
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert transformer._tree_changed
    assert node.bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert node.bases[0].args[0].id == 'C'
    assert node.bases[0].args[1].id == 'B'
    assert node.keywords == []

# Generated at 2022-06-18 00:10:32.860429
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_source

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    assert_source(MetaclassTransformer, source, expected)

# Generated at 2022-06-18 00:10:40.759469
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()

    code = compile_snippet(node)
    assert code.co_consts[0]

# Generated at 2022-06-18 00:10:42.675805
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:10:46.598161
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast


# Generated at 2022-06-18 00:10:53.253662
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword, ast_str
    from ..utils.tree import tree_to_str
    from ..utils.source_factory import source_for_node

    class_def = ast_classdef(name='A',
                             bases=[ast_name(id='B')],
                             keywords=[ast_keyword(arg='metaclass', value=ast_name(id='C'))])
    expected = ast_classdef(name='A',
                            bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                            args=[ast_name(id='C'), ast_name(id='B')])])


# Generated at 2022-06-18 00:11:05.271041
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_attr
    from ..utils.test_utils import get_ast_node_attr_value
    from ..utils.test_utils import get_ast_node_attr_value_name
    from ..utils.test_utils import get_ast_node_attr_value_elts
    from ..utils.test_utils import get_ast_node_attr_value_elts_name
    from ..utils.test_utils import get_ast_node_attr_value_elts_value
    from ..utils.test_utils import get_ast

# Generated at 2022-06-18 00:11:15.586027
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='Foo', ctx=ast.Load())]
            return node

    class Test(object):
        class A(object):
            pass

    class Test2(object):
        class A(metaclass=TestTransformer):
            pass


# Generated at 2022-06-18 00:11:27.123044
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef
    from ..utils.test_utils import parse_to_module
    from ..utils.test_utils import parse_to_expr
    from ..utils.test_utils import parse_to_stmt
    from ..utils.test_utils import parse_to_block
    from ..utils.test_utils import parse_to_tuple
    from ..utils.test_utils import parse_to_list
    from ..utils.test_utils import parse_to_dict
    from ..utils.test_utils import parse_to_name
    from ..utils.test_utils import parse_to_attribute


# Generated at 2022-06-18 00:11:34.746963
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins
    from ..utils.snippet import snippet
    from ..utils.source import source_to_ast

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = source_to_ast(before.get_source())
    node = MetaclassTransformer().visit(node)

# Generated at 2022-06-18 00:11:43.848609
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import get_metaclass

    class A(get_metaclass(object, type)):
        pass

    node = ast.parse(ast_to_str(ast.ClassDef(name='A',
                                             bases=[ast.Name(id='object', ctx=ast.Load())],
                                             keywords=[ast.keyword(arg='metaclass',
                                                                   value=ast.Name(id='type', ctx=ast.Load()))],
                                             body=[],
                                             decorator_list=[])))
    transformer = MetaclassTransformer()
    transformer.visit(node)

# Generated at 2022-06-18 00:11:44.773984
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast


# Generated at 2022-06-18 00:11:53.086827
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import exec_

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()

    # Make sure the code still runs
    exec_(compile(node, '', 'exec'))

# Generated at 2022-06-18 00:11:55.725743
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:12:04.992493
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins
    from ..utils.snippet import snippet
    from ..utils.source_code import SourceCode
    from ..utils.compiler import compile_snippet
    from ..utils.six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def test_code():
        class A(metaclass=B):
            pass

    # Compile the test code
    module = compile_snippet(test_code.get_source(), 'test_code', 'exec')

    # Get the class A
    class_a = module.body[0]

    # Check that the class A is defined as expected

# Generated at 2022-06-18 00:12:06.091309
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source


# Generated at 2022-06-18 00:12:22.270128
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_and_compile

    snippet_1 = """
        class A(metaclass=B):
            pass
    """
    snippet_2 = """
        class A(B):
            pass
    """
    snippet_3 = """
        class A(B, C):
            pass
    """
    snippet_4 = """
        class A(B, C, D):
            pass
    """
    snippet_5 = """
        class A(B, C, D, E):
            pass
    """

# Generated at 2022-06-18 00:12:27.098853
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_equal

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:12:37.550571
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef
    from ..utils.test_utils import parse_to_module
    from ..utils.test_utils import parse_to_stmt
    from ..utils.test_utils import parse_to_expr
    from ..utils.test_utils import parse_to_name
    from ..utils.test_utils import parse_to_arg
    from ..utils.test_utils import parse_to_arguments
    from ..utils.test_utils import parse_to_keyword
    from ..utils.test_utils import parse_to_alias
    from ..utils.test_utils import parse_to_com

# Generated at 2022-06-18 00:12:39.359703
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:12:41.578431
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import parse_ast


# Generated at 2022-06-18 00:12:50.038258
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def code():
        class A(metaclass=B):
            pass

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    node = ast.parse(code.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == expected

# Generated at 2022-06-18 00:12:56.415515
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.source import source

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    module = ast.Module(body=[class_def])
    print_tree(module)
    print()
    transformer = MetaclassTransformer()
    module = transformer.visit(module)
    print_tree(module)
    print()
    print(source(module))

# Generated at 2022-06-18 00:13:06.448962
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast
    from ..utils.unparse import Unparser

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    expected_source = source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')
    tree = ast.parse(source)
    tree = MetaclassTransformer().visit(tree)
    Unparser(tree)
    assert compare_ast(tree, ast.parse(expected_source))

# Generated at 2022-06-18 00:13:08.001141
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, compare_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:13:09.729542
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:13:27.049945
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import parse


# Generated at 2022-06-18 00:13:35.985955
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_with_metaclass import SixWithMetaclassTransformer
    from .six_import import six_import
    from .six_with_metaclass import class_bases

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            if node.keywords:
                metaclass = node.keywords[0].value
                node.bases = class_bases.get_body(metaclass=metaclass,  # type: ignore
                                                  bases=ast.List(elts=node.bases))

# Generated at 2022-06-18 00:13:44.818498
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at
    from .base import BaseNodeTransformer

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass


    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)



# Generated at 2022-06-18 00:13:52.008523
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

# Generated at 2022-06-18 00:13:59.143187
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    MetaclassTransformer().visit(tree)
    assert_equal_source(tree, expected)

# Generated at 2022-06-18 00:14:09.596586
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet

    # Test case 1
    # Tested snippet:
    #   class A(metaclass=B):
    #       pass
    # Expected result:
    #   class A(_py_backwards_six_with_metaclass(B)):
    #       pass
    snippet_code = 'class A(metaclass=B):\n    pass'
    expected_code = 'class A(_py_backwards_six_withmetaclass(B)):\n    pass'
    tree = ast.parse(snippet_code)
    transformer = MetaclassTransformer()
    transformer.visit(tree)


# Generated at 2022-06-18 00:14:18.221725
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_to_ast(source)
    tree = MetaclassTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:14:20.281804
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:14:29.997473
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[],
                             keywords=[ast.keyword(arg='metaclass',
                                                    value=ast.Name(id='B',
                                                                   ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:14:40.791519
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source
    from ..utils.test_utils import get_tree_changed

    source = get_source('''
        class A(metaclass=B):
            pass
    ''')
    tree_changed = get_tree_changed('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')
    ast

# Generated at 2022-06-18 00:15:25.678828
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

# Generated at 2022-06-18 00:15:35.850292
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = input_code.get_ast()
    expected = expected_code.get_ast()
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)
    assert ast_to_str(new_node) == ast_to_str(expected)

# Generated at 2022-06-18 00:15:44.298581
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins_name
    from .base import BaseNodeTransformer
    from .six import SixTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id=builtins_name('str'), ctx=ast.Load())]
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id=builtins_name('int'), ctx=ast.Load())]
            return node


# Generated at 2022-06-18 00:15:47.924574
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_builder import build_ast
    from ..utils.ast_visitor import ASTVisitor


# Generated at 2022-06-18 00:15:50.593795
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:15:59.659820
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.ast_factory import ast_factory
    from ..utils.source_factory import source_factory
    from ..utils.source_factory import source_factory
    from ..utils.source_factory import source_factory
    from ..utils.source_factory import source_factory
    from ..utils.source_factory import source_factory
    from ..utils.source_factory import source_factory
    from ..utils.source_factory import source_factory
    from ..utils.source_factory import source_factory
    from ..utils.source_factory import source_factory
    from ..utils.source_factory import source_factory

# Generated at 2022-06-18 00:16:06.438873
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_and_compile
    from ..utils.test_utils import transform_and_compile_snippet

    # Test with a class with a metaclass
    class_def = parse_snippet("""
        class A(metaclass=B):
            pass
    """)
    expected = parse_snippet("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)
    assert_equal_ast(expected, MetaclassTransformer().visit(class_def))

    # Test with a class without a metaclass
    class_def

# Generated at 2022-06-18 00:16:10.594106
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import get_source
    from ..utils.ast_helpers import get_source_from_node


# Generated at 2022-06-18 00:16:12.232768
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import ast_equal


# Generated at 2022-06-18 00:16:20.318418
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_factory
    from ..utils.tree import tree_to_str
    from ..utils.six import six_import_str, six_withmetaclass_str
    from ..utils.snippet import snippet
    from ..utils.compile_to_ast import compile_to_ast

    @snippet
    def code():
        class A(metaclass=B):
            pass

    expected = ast_factory(
        """
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """)

    node = compile_to_ast(code)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert tree_to_str(node) == tree_to

# Generated at 2022-06-18 00:17:51.736802
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:18:01.562356
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_nodes
    from ..utils.test_utils import get_ast_node_type
    from ..utils.test_utils import get_ast_node_attr
    from ..utils.test_utils import get_ast_node_attrs
    from ..utils.test_utils import get_ast_node_attr_value
    from ..utils.test_utils import get_ast_node_attr_values
    from ..utils.test_utils import get_ast_node_attr_type
    from ..utils.test_utils import get_ast_node_attr_types
    from ..utils.test_utils import get_ast

# Generated at 2022-06-18 00:18:10.884733
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_node_equals
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_tree
    from ..utils.test_utils import get_node_name

    # Test case 1
    node = get_ast_node('''
        class A(metaclass=B):
            pass
    ''')
    expected = get_ast_tree('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert_node_equals(expected, node)
    assert transformer._tree_

# Generated at 2022-06-18 00:18:17.318657
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import dump
    from ..utils.compat import python_version

    class_def = ast.ClassDef(name='A',
                             bases=[],
                             keywords=[ast.keyword(arg='metaclass',
                                                    value=ast.Name(id='B',
                                                                   ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])