

# Generated at 2022-06-18 00:08:22.127216
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import get_ast_node_name

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    module = ast.Module(body=[class_def])

    transformer = MetaclassTransformer()
    module = transformer.visit(module)
    assert transformer._tree_changed

    class_def = module.body[1]

# Generated at 2022-06-18 00:08:31.779031
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six_import import six_import
    from .class_bases import class_bases

    class MetaclassTransformer(BaseNodeTransformer):
        """Compiles:
            class A(metaclass=B):
                pass
        To:
            class A(_py_backwards_six_with_metaclass(B))
        
        """
        target = (2, 7)
        dependencies = ['six']

        def visit_Module(self, node: ast.Module) -> ast.Module:
            insert_at(0, node, six_import.get_body())
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-18 00:08:34.378678
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:08:45.230525
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile_to_ast import compile_to_ast

    @snippet
    def test_snippet():
        class A(metaclass=B):
            pass

    expected_ast = build_ast(test_snippet)
    expected_ast.body[0].value.bases = class_bases.get_body(metaclass=ast.Name(id='B', ctx=ast.Load()),
                                                            bases=ast.List(elts=[], ctx=ast.Load()))
    expected_ast.body[0].value.keywords = []

# Generated at 2022-06-18 00:08:47.388817
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:08:52.765534
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_nodes
    from ..utils.test_utils import get_ast_node_by_name
    from ..utils.test_utils import get_ast_node_by_type


# Generated at 2022-06-18 00:08:56.321721
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:08:59.597463
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:09:04.478530
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import builtins

    class A(metaclass=builtins.type):
        pass

    node = ast.parse(ast_to_str(ast.Module(body=[A])))
    MetaclassTransformer().visit(node)

# Generated at 2022-06-18 00:09:14.119537
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str

    node = ast.Module(body=[ast.ClassDef(name='A',
                                         bases=[ast.Name(id='B', ctx=ast.Load())],
                                         keywords=[ast.keyword(arg='metaclass',
                                                               value=ast.Name(id='C', ctx=ast.Load()))])])

# Generated at 2022-06-18 00:09:24.890573
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import transform_and_compare_snippet

    snippet_ast = parse_snippet('''
        class A(metaclass=B):
            pass
    ''')

    expected_ast = parse_snippet('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')


# Generated at 2022-06-18 00:09:33.584470
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    MetaclassTransformer().visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:09:35.669885
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import compare_source


# Generated at 2022-06-18 00:09:45.769767
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_type
    from ..utils.test_utils import get_ast_node_value
    from ..utils.test_utils import get_ast_node_lineno
    from ..utils.test_utils import get_ast_node_col_offset
    from ..utils.test_utils import get_ast_node_end_lineno
    from ..utils.test_utils import get_ast_node_end_col_offset
    from ..utils.test_utils import get_ast_node_body
    from ..utils.test_utils import get_ast_node_orelse

# Generated at 2022-06-18 00:09:46.871389
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:10:17.013345
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-18 00:10:19.521616
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:10:27.807527
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import exec_

    @snippet
    def module():
        class A(metaclass=B):
            pass

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    node = ast.parse(module.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == expected

    exec_(compile(node, '<test>', 'exec'))


# Generated at 2022-06-18 00:10:37.178540
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)

    @snippet
    def input_source():
        class A(metaclass=B):
            pass

    @snippet
    def expected_source():
        from six import with_metaclass as _py_backwards_six_withmetaclass

# Generated at 2022-06-18 00:10:48.061165
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet
    from .base import BaseNodeTransformer

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = compile_snippet(before)
    assert isinstance(node, ast.Module)
    assert ast_to_str(node) == ast_to_str(compile_snippet(after))

# Generated at 2022-06-18 00:10:58.001505
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_snippet

    snippet = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = ast.parse(snippet)
    MetaclassTransformer().visit(tree)
    assert tree_to_str(tree) == expected

    # Test that the snippet compiles
    compile_snippet(expected)

# Generated at 2022-06-18 00:11:00.834283
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import compare_source


# Generated at 2022-06-18 00:11:08.355992
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compile import compile_snippet

    snippet = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = ast.parse(snippet)
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)
    assert tree_to_str(new_tree) == expected
    code = compile_snippet(new_tree)
    assert code.co_consts[0] == _py_backwards_six_with

# Generated at 2022-06-18 00:11:18.572421
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import ast_to_source as ats
    from ..utils.source import ast_to_code as atc
    from ..utils.source import ast_to_source_and_code as atsac
    from ..utils.source import code_to_ast as cta
    from ..utils.source import code_to_source as cts
    from ..utils.source import code_to_ast_and_source as ctas
    from ..utils.source import source_to_code_and_ast as stca
    from ..utils.source import code_to_source_and_ast as ctsa


# Generated at 2022-06-18 00:11:21.450007
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:11:31.459016
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import builtins

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    module = ast.Module(body=[class_def])

# Generated at 2022-06-18 00:11:32.738986
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:11:34.182474
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_code


# Generated at 2022-06-18 00:11:43.541411
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins

    class_def = ast.ClassDef(name='A', bases=[ast.Name(id='object', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[], decorator_list=[])


# Generated at 2022-06-18 00:11:50.300494
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ..utils.tree import tree_to_str
    from ..utils.source import source_to_str
    from ..utils.snippet import snippet

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)

    class MetaclassTransformer(BaseNodeTransformer):
        """Compiles:
            class A(metaclass=B):
                pass
        To:
            class A(_py_backwards_six_with_metaclass(B))
        
        """

# Generated at 2022-06-18 00:12:06.166481
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transformer = MetaclassTransformer()
    assert transformer.visit(before.get_ast()) == after.get_ast()
    assert compile_snippet(before) == compile_snippet(after)

# Generated at 2022-06-18 00:12:16.720925
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = input_code.get_ast()
    expected_node = expected_code.get_ast()

    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)

    assert ast_to_str(new_node) == ast_to_str(expected_node)

# Generated at 2022-06-18 00:12:24.230326
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test import transform_and_compare

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transform_and_compare(MetaclassTransformer, before, after)

# Generated at 2022-06-18 00:12:28.029566
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_tree
    from ..utils.tree import to_source
    from ..utils.tree import assert_source


# Generated at 2022-06-18 00:12:38.637744
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PY36
    from ..utils.compat import PY37

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert tree_to_str(node) == after.get_source()

    @snippet
    def before():
        class A(B, metaclass=C):
            pass


# Generated at 2022-06-18 00:12:41.299126
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:12:43.013041
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import ast_equal


# Generated at 2022-06-18 00:12:53.138814
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.compile_source import compile_source

    class_def = ast_class(name='A', bases=[], keywords=[ast_keyword(arg='metaclass', value=ast_name(id='B'))])
    module = ast.Module(body=[class_def])
    transformer = MetaclassTransformer()
    transformer.visit(module)

    assert module.body[0].bases == [ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                             args=[ast_name(id='B'), ast_name(id='object')],
                                             keywords=[])]

    assert compile

# Generated at 2022-06-18 00:12:54.494777
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-18 00:13:00.865265
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ..utils.tree import parse_to_ast
    from ..utils.tree import print_ast

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node


# Generated at 2022-06-18 00:13:25.041682
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import get_metaclass

    @snippet
    def code():
        class A(metaclass=B):
            pass

    node = ast.parse(code.get_source())
    transformer = MetaclassTransformer()
    transformer.visit(node)

# Generated at 2022-06-18 00:13:34.198663
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet
    from .base import BaseNodeTransformer

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = compile_snippet(before.get_source(), ast.parse)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == after.get_source()

# Generated at 2022-06-18 00:13:40.513785
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    transform_and_compare(MetaclassTransformer,
                          """
                          class A(metaclass=B):
                              pass
                          """,
                          """
                          from six import with_metaclass as _py_backwards_six_withmetaclass
                          class A(_py_backwards_six_withmetaclass(B)):
                              pass
                          """)

# Generated at 2022-06-18 00:13:42.471200
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:13:50.478044
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import python_version
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer
    from . import base
    from . import six
    from . import metaclass
    import sys
    import os
    import io
    import unittest
    import textwrap
    import typing
    import six
    import astunparse
    import astor
    import asttokens
    import typed_astunparse
    import typed_astor
    import typed_asttokens
    import typed_ast
    import ast
    import typing
    import six
    import astunparse
    import ast

# Generated at 2022-06-18 00:13:51.367542
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:13:53.430960
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_tree as stt


# Generated at 2022-06-18 00:13:59.491704
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ..utils.tree import tree_to_str
    from ..utils.source import source_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PYTHON_VERSION

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)


# Generated at 2022-06-18 00:14:09.610328
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

    module = ast.Module(body=[class_def])

    transformer = MetaclassTransformer()
    transformer.visit(module)


# Generated at 2022-06-18 00:14:12.032097
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:14:56.017139
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:15:07.604420
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_builder import ast_from_code
    from ..utils.ast_builder import ast_from_snippet
    from ..utils.ast_builder import ast_from_str

    # Test with no metaclass
    code = 'class A(object): pass'
    expected = ast_from_str(code)
    actual = MetaclassTransformer().visit(ast_from_code(code))
    assert astor.to_source(expected) == astor.to_source(actual)

    # Test with metaclass
    code = 'class A(metaclass=B): pass'
    expected = ast_from_str('class A(_py_backwards_six_withmetaclass(B)): pass')

# Generated at 2022-06-18 00:15:09.598063
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:15:15.939507
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import builtins

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[ast.Pass()],
                             decorator_list=[])
    module = ast.Module(body=[class_def])
    transformer = MetaclassTransformer()
    module = transformer.visit(module)
    assert transformer._tree_changed

# Generated at 2022-06-18 00:15:25.357584
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_ast(source)
    MetaclassTransformer().visit(tree)
    assert_equal_source(tree, expected)

# Generated at 2022-06-18 00:15:31.289971
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree
    from ..utils.test_utils import round_trip_dump
    from ..utils.test_utils import round_trip_load

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast_tree(source)
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)
    assert transformer.tree_changed
    assert_equal_ast(expected, new_tree)
    assert_equal_ast

# Generated at 2022-06-18 00:15:32.790577
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-18 00:15:40.568435
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import builtins
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transformer = MetaclassTransformer()
    node = ast.parse(input_code.get_source())
    transformer.visit(node)
    assert ast_to_str(node) == expected_code.get_source()

# Generated at 2022-06-18 00:15:42.439161
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:15:47.449552
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)
    assert_equal_source(tree, expected)

# Generated at 2022-06-18 00:17:09.681707
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import ast_to_source as ats
    from ..utils.source import ast_to_code as atc
    from ..utils.source import ast_and_code_to_source as atcas
    from ..utils.source import ast_and_code_to_code as atcac
    from ..utils.source import code_to_ast as cta
    from ..utils.source import code_to_source as cts
    from ..utils.source import code_to_ast_and_code as ctaac
    from ..utils.source import ast_and_code_to_ast as atca


# Generated at 2022-06-18 00:17:18.604396
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    module = ast.Module(body=[class_def])
    transformer = MetaclassTransformer()
    transformer.visit(module)
    assert transformer._tree_changed

# Generated at 2022-06-18 00:17:22.975122
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test import transform_and_compare

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transform_and_compare(MetaclassTransformer, before, after)

# Generated at 2022-06-18 00:17:32.900643
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet
    from ..utils.test_utils import assert_ast_equal

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transformer = MetaclassTransformer()
    transformer.visit(before.get_ast())
    assert_ast_equal(ast_to_str(transformer.tree), ast_to_str(after.get_ast()))

# Generated at 2022-06-18 00:17:37.410084
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_unchanged
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import round_trip

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    new_tree = round_trip(tree, transformer)
    assert_equal_source(expected, new_tree)
    assert_tree_unchanged(tree, transformer)



# Generated at 2022-06-18 00:17:47.316106
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import builtins

    @snippet
    def test_class():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = test_class.get_ast()
    expected = expected.get_ast()

    transformer = MetaclassTransformer()
    transformer.visit(node)

    assert ast_to_str(node) == ast_to_str(expected)

# Generated at 2022-06-18 00:17:48.816020
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, assert_equal_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:17:59.056181
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_equal_ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='object', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:18:08.113128
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.ast import get_ast

    source_code = source('''
        class A(metaclass=B):
            pass
    ''')
    expected_code = source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    tree = get_ast(source_code)
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)

    assert transformer.tree_changed is True
    assert expected_code == source(new_tree)

# Generated at 2022-06-18 00:18:16.028442
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword

    classdef = ast_classdef(name='A',
                            bases=[ast_name(id='object')],
                            keywords=[ast_keyword(arg='metaclass',
                                                  value=ast_name(id='B'))])
    expected = ast_classdef(name='A',
                            bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                            args=[ast_name(id='B'),
                                                  ast_name(id='object')],
                                            keywords=[])])

    transformer = MetaclassTransformer()
    result = transformer.visit(classdef)
