

# Generated at 2022-06-18 00:08:21.775072
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_ast
    from ..utils.snippet import snippet
    from ..utils.test_utils import transform, run_test_driver

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transform(MetaclassTransformer, before, after)



# Generated at 2022-06-18 00:08:23.877009
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast


# Generated at 2022-06-18 00:08:33.046508
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import builtins

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    expected_code = expected_code.get_ast()
    input_code = input_code.get_ast()

    transformer = MetaclassTransformer()
    transformer.visit(input_code)
    assert ast_to_str(input_code) == ast_to_str

# Generated at 2022-06-18 00:08:43.098810
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import python_version
    from ..utils.compat import is_py2
    from ..utils.compat import is_py3
    from ..utils.compat import is_py33
    from ..utils.compat import is_py34
    from ..utils.compat import is_py35
    from ..utils.compat import is_py36
    from ..utils.compat import is_py37
    from ..utils.compat import is_py38
    from ..utils.compat import is_py39
    from ..utils.compat import is_py310
    from ..utils.compat import is_py311
    from ..utils.compat import is_py312

# Generated at 2022-06-18 00:08:53.291999
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet

    snippet_ast = parse_snippet(six_import)
    snippet_ast.body.extend(parse_snippet(class_bases))

    tree = parse_ast('''
        class A(metaclass=B):
            pass
    ''')

    expected_tree = parse_ast('''
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_tree_changed(transformer)
    assert_equal

# Generated at 2022-06-18 00:09:03.983063
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .utils import transform_and_compile

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='C', ctx=ast.Load())]
            return node


# Generated at 2022-06-18 00:09:13.609131
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet

    snippet_ast = parse_snippet(six_import)
    snippet_ast.body.extend(parse_snippet(class_bases).body)

    class_ast = parse_ast("""
    class A(metaclass=B):
        pass
    """)

    expected_ast = parse_ast("""
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

    expected_ast.body.extend(snippet_ast.body)

    transformer = MetaclassTransformer()
    transformer.visit(class_ast)

# Generated at 2022-06-18 00:09:23.349041
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword

    class_def = ast_class(name='A',
                          bases=[],
                          keywords=[ast_keyword(arg='metaclass',
                                                 value=ast_name(id='B'))],
                          body=[])
    expected = ast_class(name='A',
                         bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                         args=[ast_name(id='B'),
                                               ast.List(elts=[])])],
                         keywords=[],
                         body=[])

    transformer = MetaclassTransformer()
    result = transformer.visit(class_def)

# Generated at 2022-06-18 00:09:29.626135
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:09:33.814877
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.source_factory import source

    class_def = ast_class(name='A', bases=[], keywords=[ast_keyword(arg='metaclass', value=ast_name(id='B'))])
    module = ast.Module(body=[class_def])
    expected = ast.Module(body=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                        args=[ast_name(id='B'), ast_name(id='A')])])

    transformer = MetaclassTransformer()
    assert transformer.visit(module) == expected

# Generated at 2022-06-18 00:09:38.799422
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_to_ast
    from ..utils.tree import print_ast


# Generated at 2022-06-18 00:09:40.424438
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import ast_equal


# Generated at 2022-06-18 00:09:49.243758
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

# Generated at 2022-06-18 00:09:53.537644
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_with_metaclass import SixWithMetaclassTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node


# Generated at 2022-06-18 00:09:59.279449
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_source

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    assert_source(MetaclassTransformer, source, expected)

# Generated at 2022-06-18 00:10:05.524559
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str_with_lineno

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:10:14.948630
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node

    class TestTransformer3(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node


# Generated at 2022-06-18 00:10:20.761825
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.compat import get_metaclass

    class A(metaclass=get_metaclass()):
        pass

    tree = ast.parse(print_tree(A))
    MetaclassTransformer().visit(tree)

# Generated at 2022-06-18 00:10:22.646555
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:10:28.718464
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:10:35.053134
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast


# Generated at 2022-06-18 00:10:42.165404
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef

    classdef = parse_to_classdef("""
        class A(metaclass=B):
            pass
    """)

    expected = parse_to_classdef("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    assert_equal_ast(MetaclassTransformer().visit(classdef), expected)


# Generated at 2022-06-18 00:10:49.925557
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_node

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    node = get_node(source)
    MetaclassTransformer().visit(node)
    assert_equal_source(node, expected)

# Generated at 2022-06-18 00:10:59.604458
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import round_trip
    from ..utils.test_utils import round_trip_dump
    from ..utils.test_utils import round_trip_load

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    tree = MetaclassTransformer().visit(tree)

# Generated at 2022-06-18 00:11:07.333956
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_from_str
    from .base import BaseNodeTransformer
    from ..utils.snippet import snippet

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)

    class MetaclassTransformer(BaseNodeTransformer):
        """Compiles:
            class A(metaclass=B):
                pass
        To:
            class A(_py_backwards_six_with_metaclass(B))
        
        """
        target = (2, 7)

# Generated at 2022-06-18 00:11:10.269330
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import PY2


# Generated at 2022-06-18 00:11:19.876625
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_attr
    from ..utils.test_utils import get_ast_node_attr_value
    from ..utils.test_utils import get_ast_node_attr_type
    from ..utils.test_utils import get_ast_node_attr_value_type
    from ..utils.test_utils import get_ast_node_attr_value_value
    from ..utils.test_utils import get_ast_node_attr_value_value_type
    from ..utils.test_utils import get_ast_node_attr_

# Generated at 2022-06-18 00:11:30.830277
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.compiler import compile_snippet
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.keywords = [ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))]
            return node

    class_def = compile_snippet('''
        class A:
            pass
    ''')
    TestVisitor().visit(class_def)

    transformer = MetaclassTransformer()
    transformer.visit(class_def)

    assert tree_to_str(class_def)

# Generated at 2022-06-18 00:11:40.558072
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = compile_snippet(before)
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == ast_to_str(compile_snippet(after))

# Generated at 2022-06-18 00:11:51.929055
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import builtins

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert tree_to_str(node) == after.get_source()

# Generated at 2022-06-18 00:12:01.867780
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:12:06.679189
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_code

    code = '''
    class A(metaclass=B):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    assert_equal_code(MetaclassTransformer, code, expected)

# Generated at 2022-06-18 00:12:16.330157
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.source import source_to_unicode

    source = source_to_unicode('''
        class A(metaclass=B):
            pass
    ''')
    tree = get_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert astor.to_source(tree) == source_to_unicode('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

# Generated at 2022-06-18 00:12:18.575797
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast


# Generated at 2022-06-18 00:12:21.713933
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:12:29.447406
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.compile import compile_function
    from ..utils.snippet import snippet
    from ..utils.tree import tree_to_str

    @snippet
    def test_class(metaclass):
        class A(metaclass=metaclass):
            pass

    node = ast_class(name='A',
                     bases=[],
                     keywords=[ast_keyword(arg='metaclass',
                                           value=ast_name(id='metaclass'))],
                     body=[])


# Generated at 2022-06-18 00:12:38.131598
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast

    class_def = get_ast("""
        class A(metaclass=B):
            pass
    """)
    expected = get_ast("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)
    transformer = MetaclassTransformer()
    result = transformer.visit(class_def)
    assert astor.to_source(result) == astor.to_source(expected)

# Generated at 2022-06-18 00:12:48.231402
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_equal

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))])

# Generated at 2022-06-18 00:12:51.690422
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac

    # Test case 1

# Generated at 2022-06-18 00:12:53.421545
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:13:19.694080
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import get_metaclass

    @snippet
    def test_class():
        class A(metaclass=B):
            pass

    node = test_class.get_ast()
    assert isinstance(node, ast.Module)
    assert len(node.body) == 1
    assert isinstance(node.body[0], ast.ClassDef)
    assert node.body[0].name == 'A'
    assert len(node.body[0].bases) == 1
    assert isinstance(node.body[0].bases[0], ast.Name)
    assert node.body[0].bases[0].id == 'B'
   

# Generated at 2022-06-18 00:13:28.779587
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_factory import ast_factory
    from ..utils.snippet import snippet
    from ..utils.compat import PY2

    if PY2:
        return

    @snippet
    def test_code():
        class A(metaclass=B):
            pass

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    node = ast.parse(test_code.get_source())
    transformer = MetaclassTransformer()
    transformer.visit(node)

# Generated at 2022-06-18 00:13:38.376601
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name
    from ..utils.tree import to_source
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_with_metaclass import SixWithMetaclassTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                  args=[ast_name(id='B')],
                                  keywords=[])
            node.keywords = []
            return node


# Generated at 2022-06-18 00:13:46.149714
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.source_code import SourceCode
    from ..utils.context import Context
    from ..utils.snippet import snippet
    from ..utils.six import PY2
    from ..utils.six import PY3

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    if PY2:
        expected = after
    elif PY3:
        expected = before


# Generated at 2022-06-18 00:13:52.970197
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_with_metaclass import SixWithMetaclassTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='A', ctx=ast.Load())]
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node


# Generated at 2022-06-18 00:13:55.165566
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import parse_ast
    from ..utils.tree import print_ast


# Generated at 2022-06-18 00:14:03.425371
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_node_equals
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import round_trip

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    tree = MetaclassTransformer().visit(tree)
    assert_node_equals(expected, tree)
    assert_node_equals(expected, round_trip(tree))

# Generated at 2022-06-18 00:14:12.374734
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import is_py27

    @snippet
    def code():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    if is_py27:
        expected = expected.get_body()
        expected = ast.fix_missing_locations(expected)
        expected = ast_to_str(expected)

        tree = code.get_ast()
        tree = MetaclassTransformer().visit(tree)

# Generated at 2022-06-18 00:14:22.178381
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_tree
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_unicode

    snippet_code = """
    class A(metaclass=B):
        pass
    """
    snippet_tree = parse_tree(snippet_code)
    snippet_ast = snippet_tree.body[0]
    assert isinstance(snippet_ast, ast.ClassDef)
    assert snippet_ast.keywords[0].arg == 'metaclass'

    transformer = MetaclassTransformer()
    transformer.visit(snippet_tree)

# Generated at 2022-06-18 00:14:29.613534
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_to_ast(source)
    MetaclassTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:15:12.204803
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_withmetaclass import SixWithMetaclassTransformer
    from .six_withmetaclass import six_withmetaclass_import
    from .six_withmetaclass import six_withmetaclass_call
    from .six_withmetaclass import six_withmetaclass_call_with_bases
    from .six_withmetaclass import six_withmetaclass_call_with_bases_and_keywords
    from .six_withmetaclass import six_withmetaclass_call_with_keywords
    from .six_withmetaclass import six_withmetaclass_call_with

# Generated at 2022-06-18 00:15:14.518702
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, assert_equal_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:15:26.539821
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.tree import ast_to_str
    from ..utils.test_utils import assert_equal_ast

    class_def = ast_class(name='A',
                          bases=[ast_name('B')],
                          keywords=[ast_keyword(arg='metaclass',
                                                value=ast_name('C'))])

    expected = ast_class(name='A',
                         bases=[ast_call(func=ast_name('_py_backwards_six_withmetaclass'),
                                         args=[ast_name('C'),
                                               ast_name('B')])])

    transformer = MetaclassTransformer()

# Generated at 2022-06-18 00:15:36.806886
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import builtins

    class A(metaclass=builtins.type):
        pass

    node = ast.parse(ast_to_str(ast.Module([ast.ClassDef(name='A',
                                                         bases=[],
                                                         keywords=[ast.keyword(arg='metaclass',
                                                                               value=ast.Name(id='type',
                                                                                              ctx=ast.Load()))],
                                                         body=[],
                                                         decorator_list=[])])))
    transformer = MetaclassTransformer()
    transformer.visit(node)

# Generated at 2022-06-18 00:15:45.129106
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .six import SixTransformer

    @snippet
    def code():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    tree = ast.parse(code.get_source())
    tree = MetaclassTransformer().visit(tree)
    tree = SixTransformer().visit(tree)
    assert ast_to_str(tree) == expected.get_source()

# Generated at 2022-06-18 00:15:55.549179
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_end_node
    from ..utils.test_utils import parse_to_node
    from ..utils.test_utils import parse_to_node_object
    from ..utils.test_utils import parse_to_object
    from ..utils.test_utils import parse_to_tuple

    # Test case 1
    node = parse_to_node("""
        class A(metaclass=B):
            pass
    """)

# Generated at 2022-06-18 00:16:03.785103
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import builtins

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    module = ast.Module(body=[class_def])

# Generated at 2022-06-18 00:16:15.071445
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet
    from ..utils.test_utils import assert_equal_code

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    tree = compile_snippet(before.get_source())
    transformer = MetaclassTransformer()
    transformer.visit(tree)

# Generated at 2022-06-18 00:16:22.475435
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast, get_name
    from ..utils.snippet import snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = get_ast(before.get_source())
    node = MetaclassTransformer().visit(node)
    assert astor.to_source(node) == after.get_source()



# Generated at 2022-06-18 00:16:29.018159
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    node = parse_ast("""
        class A(metaclass=B):
            pass
    """)
    expected = parse_ast("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert_equal_ast(node, expected)

# Generated at 2022-06-18 00:18:04.884081
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare


# Generated at 2022-06-18 00:18:11.291363
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    expected = source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert compare_ast(tree, ast.parse(expected))