

# Generated at 2022-06-18 00:08:12.415701
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:08:21.726961
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as to_ast
    from ..utils.source import source_to_code as to_code
    from ..utils.source import source_to_ast_and_code as to_ast_and_code
    from ..utils.source import ast_to_source as to_source

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = to_ast(source)
    MetaclassTransformer().visit(tree)
    assert to_source(tree) == expected


# Generated at 2022-06-18 00:08:23.495328
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:08:32.800899
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.snippet import snippet
    from ..utils.test import run_test_snippet

    @snippet
    def test_snippet():
        class A(metaclass=B):
            pass

    expected_ast = ast.Module(body=[
        six_import.get_body()[0],
        ast.ClassDef(name='A',
                     bases=[class_bases.get_body()[0]],
                     keywords=[],
                     body=[],
                     decorator_list=[])
    ])

    expected_code = compile_snippet(ast_to_str(expected_ast))

# Generated at 2022-06-18 00:08:39.647677
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    expected = source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert compare_ast(tree, expected)

# Generated at 2022-06-18 00:08:41.713895
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:08:52.805705
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet

    class_def = parse_snippet('class A(metaclass=B): pass')
    expected = parse_snippet('class A(_py_backwards_six_withmetaclass(B)): pass')
    transformer = MetaclassTransformer()
    assert_equal_ast(transformer.visit(class_def), expected)

    class_def = parse_snippet('class A(B, metaclass=C): pass')
    expected = parse_snippet('class A(_py_backwards_six_withmetaclass(C), B): pass')
    transformer = MetaclassTransformer()

# Generated at 2022-06-18 00:09:03.983132
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import python_version
    from ..utils.compat import PY2
    from ..utils.compat import PY3
    from ..utils.compat import PY36
    from ..utils.compat import PY37
    from ..utils.compat import PY38
    from ..utils.compat import PY39

    @snippet
    def input():
        class A(metaclass=B):
            pass

    @snippet
    def expected_output():
        from six import with_metaclass as _py_backwards_six_withmetaclass

# Generated at 2022-06-18 00:09:06.789523
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:09:16.863968
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call
    from ..utils.ast_factory import ast_class
    from ..utils.ast_factory import ast_name
    from ..utils.ast_factory import ast_keyword
    from ..utils.ast_factory import ast_module
    from ..utils.ast_factory import ast_str
    from ..utils.ast_factory import ast_tuple
    from ..utils.ast_factory import ast_list
    from ..utils.ast_factory import ast_pass
    from ..utils.ast_factory import ast_num
    from ..utils.ast_factory import ast_attribute
    from ..utils.ast_factory import ast_binop
    from ..utils.ast_factory import ast_boolop

# Generated at 2022-06-18 00:09:23.179740
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_tree as stt
    from ..utils.source import tree_to_source as tts
    from ..utils.source import tree_to_code as ttc
    from ..utils.source import tree_to_ast as tta


# Generated at 2022-06-18 00:09:34.269730
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import roundtrip_unparse

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, parse_snippet(expected))

# Generated at 2022-06-18 00:09:37.415056
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:09:46.835233
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = input_code.get_ast()
    expected_node = expected_code.get_ast()

    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)

    assert ast_to_str(new_node) == ast_to_str(expected_node)

# Generated at 2022-06-18 00:09:49.277529
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:09:54.605357
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import exec_

    @snippet
    def test_snippet():
        class A(metaclass=B):
            pass

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    module = ast.parse(test_snippet.get_source())
    MetaclassTransformer().visit(module)
    assert ast_to_str(module) == expected

    exec_(compile(module, '<test>', 'exec'))

# Generated at 2022-06-18 00:10:02.433552
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet
    from ..utils.test import assert_equal

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transformer = MetaclassTransformer()
    module = compile_snippet(before.get_source(), '<test>', 'exec')
    transformer.visit(module)

# Generated at 2022-06-18 00:10:11.368606
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import builtins
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)

    @snippet
    def test_class():
        class A(metaclass=B):
            pass

    node = test_class.get_ast()

# Generated at 2022-06-18 00:10:21.408364
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PYTHON_VERSION
    from ..utils.compat import PYTHON_VERSION_INFO
    from ..utils.compat import PYTHON_VERSION_MAJOR
    from ..utils.compat import PYTHON_VERSION_MINOR
    from ..utils.compat import PYTHON_VERSION_MICRO
    from ..utils.compat import PYTHON_VERSION_STRING
    from ..utils.compat import PYTHON_VERSION_TUPLE
    from ..utils.compat import PYTHON_VERSION_IS_RELEASE
    from ..utils.compat import PYTHON_VERSION_IS_BETA


# Generated at 2022-06-18 00:10:23.858879
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:10:39.833075
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str

# Generated at 2022-06-18 00:10:49.042897
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test import assert_equal

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert_equal(ast_to_str(node), after.get_source())

# Generated at 2022-06-18 00:10:59.490946
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.tree import ast_to_source as a2s
    from ..utils.tree import ast_to_code as a2c
    from ..utils.tree import ast_to_source as a2s
    from ..utils.tree import ast_to_code as a2c
    from ..utils.tree import ast_to_source as a2s
    from ..utils.tree import ast_to_code as a2c
    from ..utils.tree import ast_to_source as a2s
    from ..utils.tree import ast_to_code as a2c
    from ..utils.tree import ast_to_source as a2s
    from ..utils.tree import ast_to_code as a

# Generated at 2022-06-18 00:11:01.958260
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_source
    from ..utils.compat import PYTHON_VERSION


# Generated at 2022-06-18 00:11:09.105816
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef

    classdef = parse_to_classdef("""
        class A(metaclass=B):
            pass
    """)

    expected_classdef = parse_to_classdef("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    module = parse_to_ast("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
    """)


# Generated at 2022-06-18 00:11:11.778021
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:11:19.624900
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    ast_tree = parse_ast("""
    class A(metaclass=B):
        pass
    """)
    expected_tree = parse_ast("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(ast_tree)
    assert_equal_ast(ast_tree, expected_tree)

# Generated at 2022-06-18 00:11:22.807496
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc


# Generated at 2022-06-18 00:11:26.319944
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_compare import compare_ast
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_withmetaclass import SixWithMetaclassTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            if node.keywords:
                metaclass = node.keywords[0].value
                node.bases = class_bases.get_body(metaclass=metaclass,  # type: ignore
                                                  bases=ast.List(elts=node.bases))
                node.keywords = []
                self._tree_changed = True



# Generated at 2022-06-18 00:11:32.969691
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ..utils.tree import parse_to_ast
    from ..utils.tree import get_ast_node_at_line
    from ..utils.tree import get_ast_node_name
    from ..utils.tree import get_ast_node_bases
    from ..utils.tree import get_ast_node_keywords
    from ..utils.tree import get_ast_node_keyword_name
    from ..utils.tree import get_ast_node_keyword_value
    from ..utils.tree import get_ast_node_keyword_value_name
    from ..utils.tree import get_ast_node_keyword_value_attr
    from ..utils.tree import get_ast_node_keyword_value_attr_name

# Generated at 2022-06-18 00:11:50.694644
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import generate_source_code
    from ..utils.test_utils import assert_source_code

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = generate_source_code(source)
    MetaclassTransformer().visit(tree)
    assert_source_code(tree, expected)

# Generated at 2022-06-18 00:11:59.147656
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import get_metaclass_keyword

    class A(metaclass=B):
        pass

    node = ast.parse(tree_to_str(A))
    node = MetaclassTransformer().visit(node)
    assert get_metaclass_keyword(node) is None

# Generated at 2022-06-18 00:12:07.104540
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as to_ast
    from ..utils.source import source_to_code as to_code
    from ..utils.source import source_to_ast_and_code as to_ast_and_code
    from ..utils.source import ast_to_source as to_source

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    ast_node = to_ast(source)
    transformer = MetaclassTransformer()
    new_ast_node = transformer.visit(ast_node)

# Generated at 2022-06-18 00:12:14.913416
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast_node
    from ..utils.test_utils import parse_to_funcdef

    node = parse_to_ast_node("""
    class A(metaclass=B):
        pass
    """)
    expected = parse_to_funcdef("""
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    assert_equal_ast(MetaclassTransformer().visit(node), expected)

# Generated at 2022-06-18 00:12:22.604853
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import builtins
    from ..utils.snippet import snippet
    from ..utils.test import run_test_on_ast

    @snippet
    def input_code():
        class A(metaclass=type):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(type)):
            pass

    run_test_on_ast(input_code.get_ast(), expected_code.get_ast(), MetaclassTransformer)

# Generated at 2022-06-18 00:12:28.825829
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet
    from ..utils.test import assert_ast_equal
    from .base import BaseNodeTransformer

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transformer = MetaclassTransformer()
    assert_ast_equal(transformer.visit(before.get_ast()), after.get_ast())

# Generated at 2022-06-18 00:12:31.660290
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, compare_ast
    from ..utils.test_utils import parse


# Generated at 2022-06-18 00:12:41.418396
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.source_factory import source

    class_def = ast_class(name='A',
                          bases=[],
                          keywords=[ast_keyword(arg='metaclass',
                                                 value=ast_name(id='B'))])
    expected = ast_class(name='A',
                         bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                         args=[ast_name(id='B'),
                                               ast_name(id='object')],
                                         keywords=[])],
                         keywords=[])

    transformer = MetaclassTransformer()

# Generated at 2022-06-18 00:12:51.646602
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast

    code = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    assert_equal_ast(MetaclassTransformer, code, expected)

    code = """
    class A(B, metaclass=C):
        pass
    """

# Generated at 2022-06-18 00:12:57.480811
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:13:22.840055
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import PY2
    from ..utils.compat import PY3
    from ..utils.compat import PY35
    from ..utils.compat import PY36
    from ..utils.compat import PY37
    from ..utils.compat import PY38
    from ..utils.compat import PY39
    from ..utils.compat import PY310
    from ..utils.compat import PY311
    from ..utils.compat import PY312
    from ..utils.compat import PY313
    from ..utils.compat import PY314
    from ..utils.compat import PY315
    from ..utils.compat import PY316

# Generated at 2022-06-18 00:13:32.524218
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node

    class TestMetaclassTransformer(MetaclassTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node

    class TestSixTransformer(SixTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node


# Generated at 2022-06-18 00:13:42.042113
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_and_compile

    class_def = parse_snippet('class A(metaclass=B): pass')
    expected = parse_snippet('class A(_py_backwards_six_withmetaclass(B)): pass')
    assert_equal_ast(MetaclassTransformer().visit(class_def), expected)

    class_def = parse_snippet('class A(B, metaclass=C): pass')
    expected = parse_snippet('class A(_py_backwards_six_withmetaclass(C, B)): pass')

# Generated at 2022-06-18 00:13:48.603762
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test import transform_and_compare

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transform_and_compare(MetaclassTransformer, before, after)

# Generated at 2022-06-18 00:13:54.027905
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef
    from ..utils.test_utils import parse_to_module
    from ..utils.test_utils import parse_to_expr
    from ..utils.test_utils import parse_to_stmt
    from ..utils.test_utils import parse_to_block

    # Test case 1
    # Tested code:
    # class A(metaclass=B):
    #     pass
    # Expected output:
    # class A(_py_backwards_six_with_metaclass(B)):
    #     pass

# Generated at 2022-06-18 00:13:57.524679
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast


# Generated at 2022-06-18 00:14:08.363208
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast, parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef

    classdef = parse_to_classdef("""
    class A(metaclass=B):
        pass
    """)
    expected = parse_to_classdef("""
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    assert_equal_ast(MetaclassTransformer().visit(classdef), expected)

    classdef = parse_to_classdef("""
    class A(B, metaclass=C):
        pass
    """)

# Generated at 2022-06-18 00:14:09.545996
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:14:20.370780
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_factory import ast_factory
    from ..utils.snippet import snippet
    from ..utils.compat import get_ast_factory
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast_factory.Name(id='test', ctx=ast.Load())]
            return self.generic_visit(node)  # type: ignore

    class_def = snippet.get_ast('''
        class A(metaclass=B):
            pass
    ''')
    transformer = TestTransformer()
    transformer.vis

# Generated at 2022-06-18 00:14:30.075578
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_type
    from ..utils.test_utils import get_ast_node_value
    from ..utils.test_utils import get_ast_node_lineno
    from ..utils.test_utils import get_ast_node_col_offset
    from ..utils.test_utils import get_ast_node_end_lineno
    from ..utils.test_utils import get_ast_node_end_col_offset
    from ..utils.test_utils import get_ast_node_body
    from ..utils.test_utils import get_ast_node_orelse

# Generated at 2022-06-18 00:15:12.447489
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.tree import assert_tree

    class_def = ast_class(name='A',
                          bases=[ast_name(id='B')],
                          keywords=[ast_keyword(arg='metaclass',
                                                value=ast_name(id='C'))])

    expected = ast_class(name='A',
                         bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                         args=[ast_name(id='C'),
                                               ast_name(id='B')])])

    assert_tree(MetaclassTransformer().visit(class_def), expected)

# Generated at 2022-06-18 00:15:24.779508
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compiler import compile_snippet

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[])

# Generated at 2022-06-18 00:15:30.973792
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..compiler import Compiler
    from ..utils.compat import PY2

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    compiler = Compiler()
    compiler.add_transformer(MetaclassTransformer)
    if PY2:
        expected_code = expected_code.get_body()

# Generated at 2022-06-18 00:15:38.549446
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_ast

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    expected = source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    tree = get_ast(source)
    new_tree = MetaclassTransformer().visit(tree)
    assert compare_ast(new_tree, get_ast(expected))

# Generated at 2022-06-18 00:15:46.474066
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

    class_def = TestVisitor().visit

# Generated at 2022-06-18 00:15:56.419091
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_with_metaclass import SixWithMetaclassTransformer
    from .six_import import six_import
    from .six_with_metaclass import six_with_metaclass
    from .six_with_metaclass import class_bases
    import six
    import sys

    class TestMetaclassTransformer(BaseNodeTransformer):
        """Compiles:
            class A(metaclass=B):
                pass
        To:
            class A(_py_backwards_six_with_metaclass(B))
        
        """

# Generated at 2022-06-18 00:16:04.475578
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str

    class_def = ast.ClassDef(name='A',
                             bases=[],
                             keywords=[ast.keyword(arg='metaclass',
                                                    value=ast.Name(id='B',
                                                                   ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:16:15.261869
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import roundtrip_unparse
    from ..utils.test_utils import roundtrip_visit

    # Test 1:
    # Test that the snippet is inserted at the beginning of the module
    # and that the class is transformed
    module = parse_snippet("""
        class A(metaclass=B):
            pass
    """)
    module = roundtrip_visit(module, MetaclassTransformer)

# Generated at 2022-06-18 00:16:21.740233
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compiler import compile_snippet
    from ..utils.visitor import dump
    from ..utils.visitor import assert_equal_source

    snippet = source('''
    class A(metaclass=B):
        pass
    ''')
    node = compile_snippet(snippet, 'single', 'exec')
    MetaclassTransformer().visit(node)
    assert_equal_source(dump(node), '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''')

# Generated at 2022-06-18 00:16:29.979708
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef

    source = '''
    class A(metaclass=B):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    tree = parse_to_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_ast(expected, tree)


# Generated at 2022-06-18 00:18:10.264819
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test import transform_test

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transform_test(MetaclassTransformer, before, after)