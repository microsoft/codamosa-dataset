

# Generated at 2022-06-18 00:08:19.994211
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import builtins

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert tree_to_str(node) == after.get_source()

# Generated at 2022-06-18 00:08:22.230271
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:08:31.877712
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet
    from .base import BaseNodeTransformer

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = compile_snippet(before)
    node = MetaclassTransformer().visit(node)
    assert ast_to_str(node) == ast_to_str(compile_snippet(after))

# Generated at 2022-06-18 00:08:41.714644
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name

    # Test 1
    node = parse_ast("""
        class A(metaclass=B):
            pass
    """)
    node = get_ast_node(node, 'ClassDef')
    node = MetaclassTransformer().visit(node)
    assert_equal_ast(node, """
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    # Test 2
    node = parse_ast("""
        class A(B, metaclass=C):
            pass
    """)
    node = get

# Generated at 2022-06-18 00:08:51.806446
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compiler import compile_snippet
    from ..utils.visitor import dump
    from ..utils.ast import get_ast

    snippet = source('''
    class A(metaclass=B):
        pass
    ''')
    tree = get_ast(snippet)
    MetaclassTransformer().visit(tree)
    assert compile_snippet(dump(tree)) == compile_snippet(source('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''))

# Generated at 2022-06-18 00:09:03.247506
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import parse_module

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = parse_module(before.get_source())
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert_equal_source(after.get_source(), ast.unparse(node))

# Generated at 2022-06-18 00:09:07.950807
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_and_compare

    # Test 1

# Generated at 2022-06-18 00:09:18.077788
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword
    from ..utils.source import source
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                  args=[node.keywords[0].value,
                                        ast.List(elts=node.bases)])
            node.keywords = []
            return node


# Generated at 2022-06-18 00:09:24.069437
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:09:34.775718
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import source_to_tree_and_code as sttac
    from ..utils.source import source_to_tree as stt
    from ..utils.source import source_to_code_and_tree as stcat
    from ..utils.source import source_to_code_and_ast as stca
    from ..utils.source import source_to_ast_and_tree as stat
    from ..utils.source import source_to_tree_and_ast as stta
    from ..utils.source import source_to_code_and_ast_and_tree as stcat

# Generated at 2022-06-18 00:09:40.168969
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compiler import compile_snippet

    snippet = source(MetaclassTransformer.visit_ClassDef)
    assert snippet == compile_snippet(MetaclassTransformer.visit_ClassDef)

# Generated at 2022-06-18 00:10:15.720005
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-18 00:10:23.900668
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.test import assert_equal

    snippet = """
    class A(metaclass=B):
        pass
    """
    expected = """
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    tree = ast.parse(snippet)
    MetaclassTransformer().visit(tree)
    assert_equal(ast_to_str(tree), expected)
    compile_snippet(tree)

# Generated at 2022-06-18 00:10:32.941906
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:10:40.820908
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import ast_to_source as ats
    from ..utils.source import ast_to_code as atc
    from ..utils.source import ast_and_code_to_source as atcas
    from ..utils.source import ast_and_code_to_code as atcc
    from ..utils.source import code_to_ast as cta
    from ..utils.source import code_to_source as cts
    from ..utils.source import code_to_ast_and_code as ctaac
    from ..utils.source import ast_and_code_to_ast as atca
   

# Generated at 2022-06-18 00:10:42.764322
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:10:52.129427
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import parse_module
    from ..utils.compat import PYTHON_VERSION

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    if PYTHON_VERSION < (2, 7):
        assert MetaclassTransformer.visit(parse_module(before.get_source())) == parse_module(after.get_source())
    else:
        assert MetaclassTransformer.visit(parse_module(before.get_source())) == parse_module(before.get_source())

# Generated at 2022-06-18 00:10:54.147361
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:11:03.163905
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins
    from ..utils.compat import six
    from ..utils.compat import typing

    class A(metaclass=type):
        pass

    class B(metaclass=type):
        pass

    class C(metaclass=type):
        pass

    class D(metaclass=type):
        pass

    class E(metaclass=type):
        pass

    class F(metaclass=type):
        pass

    class G(metaclass=type):
        pass

    class H(metaclass=type):
        pass

    class I(metaclass=type):
        pass

    class J(metaclass=type):
        pass


# Generated at 2022-06-18 00:11:05.905236
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:11:11.735490
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:11:22.481698
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PY2

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    if PY2:
        assert ast_to_str(MetaclassTransformer().visit(before.get_ast())) == after.get_ast_str()

# Generated at 2022-06-18 00:11:32.113022
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import compare_source

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    transform_and_compare(MetaclassTransformer, source, expected)

    source = """
        class A(B, metaclass=C):
            pass
    """

# Generated at 2022-06-18 00:11:41.088515
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    assert_equal_ast(MetaclassTransformer().visit(ast.parse(before.get_source())),
                     ast.parse(after.get_source()))

# Generated at 2022-06-18 00:11:47.418729
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helper import ast_load
    from ..utils.ast_helper import ast_dump
    from ..utils.ast_helper import ast_store
    from ..utils.ast_helper import ast_equal


# Generated at 2022-06-18 00:11:55.330071
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import source_to_tree_and_code as sttac
    from ..utils.source import source_to_tree as stt
    from ..utils.source import source_to_code_and_tree as stcat
    from ..utils.source import source_to_code_and_ast as stca
    from ..utils.source import source_to_ast_and_tree as stat
    from ..utils.source import source_to_ast_and_code_and_tree as staact
    from ..utils.source import source_to_code_and_ast_and_tree as stcat
   

# Generated at 2022-06-18 00:11:57.315869
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:12:06.343620
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.compile import compile_func
    from ..utils.tree import tree_to_str

    class_def = ast.ClassDef(name='A',
                             bases=[],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B',
                                                                  ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

    module = ast.Module(body=[class_def])

    transformer = MetaclassTransformer()
    transformer.visit(module)


# Generated at 2022-06-18 00:12:11.515059
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword
    from ..utils.compile_source import compile_source


# Generated at 2022-06-18 00:12:19.817002
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet
    from ..utils.test_utils import assert_ast_equal

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transformer = MetaclassTransformer()
    transformer.visit(before.get_ast())
    assert_ast_equal(transformer.tree, after.get_ast())

# Generated at 2022-06-18 00:12:29.714038
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_code
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:12:32.438193
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:12:38.674648
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    transform_and_compare(MetaclassTransformer,
                          """
                          class A(metaclass=B):
                              pass
                          """,
                          """
                          from six import with_metaclass as _py_backwards_six_withmetaclass
                          class A(_py_backwards_six_withmetaclass(B)):
                              pass
                          """)

# Generated at 2022-06-18 00:12:48.794751
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id=builtins.object.__name__, ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    module = ast.Module(body=[class_def])
    transformer = MetaclassTransformer()
    transformer.visit(module)

# Generated at 2022-06-18 00:12:57.026108
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.source_factory import source

    class_def = ast_class(name='A',
                          bases=[ast_name(id='B')],
                          keywords=[ast_keyword(arg='metaclass', value=ast_name(id='C'))])
    expected = ast_class(name='A',
                         bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                         args=[ast_name(id='C'), ast_name(id='B')])])
    assert MetaclassTransformer().visit(class_def) == expected


# Generated at 2022-06-18 00:13:07.750235
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef
    from ..utils.test_utils import parse_to_module
    from ..utils.test_utils import parse_to_stmt

    # Test 1
    classdef = parse_to_classdef("""
        class A(metaclass=B):
            pass
    """)
    expected = parse_to_classdef("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)
    assert_equal_ast(MetaclassTransformer().visit(classdef), expected)

    # Test 2

# Generated at 2022-06-18 00:13:11.325742
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import parse_ast
    from ..utils.tree import print_ast
    from ..utils.tree import tree_to_str
    from ..utils.tree import tree_to_str_with_comments


# Generated at 2022-06-18 00:13:21.337523
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins

    class A(metaclass=builtins.type):
        pass

    class B(metaclass=builtins.type):
        pass

    class C(metaclass=builtins.type):
        pass

    class D(metaclass=builtins.type):
        pass

    class E(metaclass=builtins.type):
        pass

    class F(metaclass=builtins.type):
        pass

    class G(metaclass=builtins.type):
        pass

    class H(metaclass=builtins.type):
        pass

    class I(metaclass=builtins.type):
        pass


# Generated at 2022-06-18 00:13:27.345701
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_ast

    class_def = parse_ast("""
        class A(metaclass=B):
            pass
    """)

    expected = parse_ast("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    transformer = MetaclassTransformer()
    transformer.visit(class_def)
    assert_equal_code(class_def, expected)

# Generated at 2022-06-18 00:13:34.551419
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    MetaclassTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:14:00.295497
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_withmetaclass import SixWithMetaclassTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='C', ctx=ast.Load())]
            return node


# Generated at 2022-06-18 00:14:09.597817
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast
    from ..utils.unparse import Unparser
    from ..utils.visitor import dump_tree

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    expected = source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    tree = ast.parse(source)
    tree = MetaclassTransformer().visit(tree)
    Unparser(tree)
    compare_ast(tree, expected)

# Generated at 2022-06-18 00:14:20.108725
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = input_code.get_ast()
    expected = expected_code.get_ast()
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)
    assert tree_to_str(new_node) == tree_to_str(expected)

# Generated at 2022-06-18 00:14:21.631248
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compile


# Generated at 2022-06-18 00:14:30.034981
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def test_class():
        class A(metaclass=B):
            pass

    @snippet
    def expected_class():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = test_class.get_ast()
    expected = expected_class.get_ast()
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == ast_to_str(expected)

# Generated at 2022-06-18 00:14:39.324265
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet

    snippet = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    node = parse_snippet(snippet)
    expected = parse_snippet(expected)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert_equal_ast(node, expected)


# Generated at 2022-06-18 00:14:45.324254
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import parse
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_with_metaclass import SixWithMetaclassTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node


# Generated at 2022-06-18 00:14:55.783075
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test import assert_equal

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transformer = MetaclassTransformer()
    assert_equal(ast_to_str(transformer.visit(before.get_ast())),
                 ast_to_str(after.get_ast()))

# Generated at 2022-06-18 00:15:04.815304
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import exec_

    @snippet
    def code():
        class A(metaclass=B):
            pass

    node = ast.parse(code.get_source())
    MetaclassTransformer().visit(node)

# Generated at 2022-06-18 00:15:13.607862
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import builtins

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    expected_code = expected_code.get_ast()
    expected_code.body[0].value.bases[0].value.args[0].id = 'B'
    expected_code.body[0].value.bases[0].value.args[0].ctx = ast

# Generated at 2022-06-18 00:15:57.523386
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node

    class TestMetaclassTransformer(MetaclassTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node

    class TestSixTransformer(SixTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node


# Generated at 2022-06-18 00:15:59.457933
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:16:06.346692
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)


# Generated at 2022-06-18 00:16:14.395440
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test import transform

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    assert transform(MetaclassTransformer, before.get_ast(), after.get_ast())

# Generated at 2022-06-18 00:16:23.957556
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_and_compile
    from ..utils.test_utils import transform_and_compile_snippet

    # Test with no metaclass
    class_def = parse_snippet('class A(object): pass')
    assert_equal_ast(class_def, transform_and_compile_snippet('class A(object): pass'))

    # Test with metaclass
    class_def = parse_snippet('class A(metaclass=B): pass')

# Generated at 2022-06-18 00:16:30.279569
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_factory
    from ..utils.source_factory import source_factory
    from ..utils.tree_compare import compare_ast

    source = source_factory(
        """
        class A(metaclass=B):
            pass
        """)
    expected = source_factory(
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """)

    tree = ast.parse(source)
    tree = MetaclassTransformer().visit(tree)
    assert compare_ast(tree, expected)

# Generated at 2022-06-18 00:16:33.845749
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, compare
    from ..utils.test_utils import parse


# Generated at 2022-06-18 00:16:37.971515
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_source

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    assert_source(MetaclassTransformer, source, expected)

# Generated at 2022-06-18 00:16:40.025700
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:16:47.688844
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef

    class_def = parse_to_classdef("""
        class A(metaclass=B):
            pass
    """)
    expected_class_def = parse_to_classdef("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    module = parse_to_ast("""
        class A(metaclass=B):
            pass
    """)