

# Generated at 2022-06-18 00:08:23.064525
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_compare import compare_ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:08:32.523091
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PY2

    @snippet
    def code():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    if PY2:
        expected = expected.get_body()
    else:
        expected = code.get_body()

    node = code.get_ast()
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == ast_to_str

# Generated at 2022-06-18 00:08:35.628347
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:08:38.100335
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import PY2


# Generated at 2022-06-18 00:08:46.542511
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.compiler import compile_snippet
    from ..utils.visitor import dump
    from ..utils.ast import parse

    source = source(six_import) + source(class_bases) + source(test_MetaclassTransformer_visit_Module)
    tree = parse(source)
    tree = MetaclassTransformer().visit(tree)
    code = compile_snippet(tree)
    print(dump(tree))
    print(code)
    exec(code)



# Generated at 2022-06-18 00:08:50.210142
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_module
    from ..utils.test_utils import parse_to_node


# Generated at 2022-06-18 00:08:57.260881
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import get_metaclass_bases

    class A(metaclass=type):
        pass

    node = ast.parse(ast_to_str(ast.ClassDef(name='A',
                                             bases=[ast.Name(id='type',
                                                             ctx=ast.Load())],
                                             keywords=[],
                                             body=[],
                                             decorator_list=[],
                                             lineno=1,
                                             col_offset=0)))

    transformer = MetaclassTransformer()
    transformer.visit(node)


# Generated at 2022-06-18 00:09:04.657016
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import builtins

    @snippet
    def test_class():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = test_class.get_ast()
    expected_node = expected.get_ast()
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == ast_to_str(expected_node)

# Generated at 2022-06-18 00:09:10.836689
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_source

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:09:21.094683
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str_with_imports
    from ..utils.tree import ast_to_str_with_imports_and_code
    from ..utils.tree import ast_to_str_with_code
    from ..utils.tree import ast_to_str_with_code_and_imports
    from ..utils.tree import ast_to_str_with_code_and_imports_and_comments
    from ..utils.tree import ast_to_str_with_comments
    from ..utils.tree import ast_to_str_with_comments_and_imports
    from ..utils.tree import ast_to_str_with_comments_and_imports_and_code

# Generated at 2022-06-18 00:09:27.670550
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:09:35.796664
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import parse_ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer_class = TestTransformer

        def test_class_with_metaclass(self):
            source = 'class A(metaclass=B): pass'
            expected = 'class A(_py_backwards_six_withmetaclass(B)): pass'
            self.assertTransformedEquals(source, expected)


# Generated at 2022-06-18 00:09:45.846561
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_node_equals
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:10:15.996481
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-18 00:10:25.803954
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

    module = ast.Module(body=[class_def])

    module = MetaclassTransformer().visit(module)

# Generated at 2022-06-18 00:10:35.358143
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = compile_snippet(before)
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == ast_to_str(compile_snippet(after))



# Generated at 2022-06-18 00:10:36.877108
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare_ast
    from ..utils.test_utils import compare_source


# Generated at 2022-06-18 00:10:46.038019
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef

    classdef = parse_to_classdef("""
    class A(metaclass=B):
        pass
    """)
    expected = parse_to_classdef("""
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    assert_equal_ast(MetaclassTransformer().visit(classdef), expected)



# Generated at 2022-06-18 00:10:52.292158
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_function

    @snippet
    def test_snippet(metaclass):
        class A(metaclass=metaclass):
            pass

    node = ast.parse(test_snippet.get_source())
    node = MetaclassTransformer().visit(node)
    assert ast_to_str(node) == test_snippet.get_source(metaclass=six_import.get_body()[0].names[0])
    compile_function(node)

# Generated at 2022-06-18 00:11:01.600234
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import parse_tree
    from .base import BaseNodeTransformer

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)

    class MetaclassTransformer(BaseNodeTransformer):
        """Compiles:
            class A(metaclass=B):
                pass
        To:
            class A(_py_backwards_six_with_metaclass(B))
        
        """
        target = (2, 7)

# Generated at 2022-06-18 00:11:15.457549
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_and_compile
    from ..utils.test_utils import transform_and_compile_snippet

    snippet_ast = parse_snippet(six_import)
    snippet_ast.body.extend(parse_snippet(class_bases))

    class_ast = parse_ast("""
        class A(metaclass=B):
            pass
    """)

    expected_ast = parse_ast("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)


# Generated at 2022-06-18 00:11:26.982949
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_module
    from ..utils.test_utils import parse_to_node

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    module = parse_to_module(source)
    node = parse_to_node(source)
    transformer = MetaclassTransformer()
    transformer.visit(module)
    assert_equal_ast(parse_to_ast(expected), module)
    transformer

# Generated at 2022-06-18 00:11:31.800555
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source

    code = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = ast.parse(code)
    MetaclassTransformer().visit(tree)
    assert source(tree) == expected

# Generated at 2022-06-18 00:11:41.815083
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = input_code.get_ast()
    expected_node = expected_code.get_ast()
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)
    assert ast_to_str(new_node) == ast_to_str(expected_node)

# Generated at 2022-06-18 00:11:53.196210
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    node = ast.ClassDef(name='A',
                        bases=[ast.Name(id='object', ctx=ast.Load())],
                        keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='B', ctx=ast.Load()))],
                        body=[],
                        decorator_list=[])

    transformer = MetaclassTransformer()
    transformer.visit(node)

    assert transformer._tree_changed is True
    assert node.bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert node.bases[0].args[0].id == 'B'
    assert node.bases[0].args[1].id == 'object'
    assert node.keywords == []

# Generated at 2022-06-18 00:11:55.710304
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:11:57.315611
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:12:06.344303
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import ast_from_str
    from ..utils.tree import to_source
    from ..utils.snippet import snippet
    from ..utils.compat import get_metaclass

    @snippet
    def source():
        class A(metaclass=B):
            pass

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    node = ast_from_str(source.get_source())
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert to_source(node) == expected

    # Test that the class is still a class
   

# Generated at 2022-06-18 00:12:16.951158
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Setup
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.ast_builder import build_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.ast_builder import build_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.ast_builder import build_ast
    from ..utils.source import source_to_unicode

# Generated at 2022-06-18 00:12:23.697001
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet

    @snippet
    def code():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(code.get_source())
    MetaclassTransformer().visit(node)
    assert tree_to_str(node) == expected.get_source()

# Generated at 2022-06-18 00:12:39.605012
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet

    snippet = """
        class A(metaclass=B):
            pass
    """
    expected_snippet = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    node = parse_snippet(snippet)
    expected_node = parse_snippet(expected_snippet)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert_equal_ast(node, expected_node)



# Generated at 2022-06-18 00:12:47.001766
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_ast

    code = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(code)
    MetaclassTransformer().visit(tree)
    assert_equal_code(expected, tree)

# Generated at 2022-06-18 00:12:53.394946
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer
    from .utils import transform_code
    from .utils import assert_equal_code

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.name = 'Test'
            return node


# Generated at 2022-06-18 00:13:03.189494
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer
    from .with_statement import WithStatementTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='C', ctx=ast.Load())]
            return node


# Generated at 2022-06-18 00:13:13.165616
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = input_code.get_ast()
    expected = expected_code.get_ast()
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == ast_to_str(expected)

# Generated at 2022-06-18 00:13:17.837793
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac

    # Test 1

# Generated at 2022-06-18 00:13:24.951946
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    node = parse_ast("""
        class A(metaclass=B):
            pass
    """)
    expected = parse_ast("""
        class A(_py_backwards_six_with_metaclass(B)):
            pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert_equal_ast(node, expected)

# Generated at 2022-06-18 00:13:34.269318
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import exec_

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    node = MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()

    exec_(after.get_source())

# Generated at 2022-06-18 00:13:37.820017
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:13:39.727746
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:13:51.473886
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source


# Generated at 2022-06-18 00:14:00.922002
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword

    class_def = ast_class(
        name='A',
        bases=[],
        keywords=[ast_keyword(arg='metaclass', value=ast_name(id='B'))],
        body=[],
        decorator_list=[],
    )

    expected = ast_class(
        name='A',
        bases=[ast_call(
            func=ast_name(id='_py_backwards_six_withmetaclass'),
            args=[ast_name(id='B')],
            keywords=[],
        )],
        keywords=[],
        body=[],
        decorator_list=[],
    )

    transformer = MetaclassTransformer()

# Generated at 2022-06-18 00:14:02.939996
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, assert_equal_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:14:05.368788
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:14:13.053331
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_str

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = compile_snippet(before)
    MetaclassTransformer().visit(node)
    assert tree_to_str(node) == tree_to_str(compile_snippet(after))
    assert source

# Generated at 2022-06-18 00:14:23.062163
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:14:30.477272
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:14:32.102456
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:14:41.746843
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_source(tree, expected)

# Generated at 2022-06-18 00:14:43.586782
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert source == source(tree)

# Generated at 2022-06-18 00:15:09.806196
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.unparse import Unparser

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert Unparser(tree).unparse() == source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

# Generated at 2022-06-18 00:15:16.055243
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import parse_ast
    from ..utils.tree import print_ast
    from ..utils.tree import tree_to_str
    from ..utils.tree import tree_to_str_with_comments
    from ..utils.tree import tree_to_str_without_comments
    from ..utils.tree import tree_to_str_without_comments_or_newlines
    from ..utils.tree import tree_to_str_without_newlines
    from ..utils.tree import tree_to_str_without_newlines_or_comments
    from ..utils.tree import tree_to_str_without_newlines_or_comments_or_indentation
    from ..utils.tree import tree_to_str_without_new

# Generated at 2022-06-18 00:15:27.536325
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_str

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

    module = ast.Module(body=[class_def])
    module = MetaclassTransformer().visit(module)

# Generated at 2022-06-18 00:15:34.368284
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_source

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    assert_source(MetaclassTransformer, source, expected)

# Generated at 2022-06-18 00:15:42.917179
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import run_transformer
    from ..utils.fake_ast import fake_ast

    class A(metaclass=type):
        pass

    class B(metaclass=type, x=1):
        pass

    class C(metaclass=type, x=1, y=2):
        pass

    class D(metaclass=type, x=1, y=2, z=3):
        pass

    class E(metaclass=type, x=1, y=2, z=3, a=4):
        pass

    class F(metaclass=type, x=1, y=2, z=3, a=4, b=5):
        pass


# Generated at 2022-06-18 00:15:53.903158
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ast import ClassDef, Name, Load, Str, keyword, Module, parse
    from ..utils.tree import insert_at

    class_def = ClassDef(name='A',
                         bases=[Name(id='object', ctx=Load())],
                         keywords=[keyword(arg='metaclass',
                                           value=Name(id='B', ctx=Load()))],
                         body=[],
                         decorator_list=[])

    module = Module(body=[class_def])
    module = MetaclassTransformer().visit(module)

# Generated at 2022-06-18 00:16:02.457457
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet

    snippet_six_import = six_import.get_body()
    snippet_class_bases = class_bases.get_body()

    # Test case 1
    node = parse_snippet("""
    class A(metaclass=B):
        pass
    """)
    expected_node = parse_snippet("""
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert_equal_ast(node, expected_node)

# Generated at 2022-06-18 00:16:14.435600
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str_with_imports
    from ..utils.tree import ast_to_str_with_imports_and_code
    from ..utils.tree import ast_to_str_with_code
    from ..utils.tree import ast_to_str_with_code_and_imports
    from ..utils.tree import ast_to_str_with_code_and_imports_and_comments
    from ..utils.tree import ast_to_str_with_comments
    from ..utils.tree import ast_to_str_with_comments_and_imports
    from ..utils.tree import ast_to_str_with_comments_and_imports_and_code

# Generated at 2022-06-18 00:16:21.851166
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import PY2
    from ..utils.snippet import snippet
    from ..utils.test import transform_and_compare

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transform_and_compare(MetaclassTransformer, before, after)

    @snippet
    def before():
        class A(object, metaclass=B):
            pass


# Generated at 2022-06-18 00:16:28.661482
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_to_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:17:34.974973
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_builder import ast_from_str
    from ..utils.ast_visitor import AstVisitor
    from ..utils.ast_visitor import AstVisitorWithRecursionLimit
    from ..utils.ast_visitor import AstVisitorWithRecursionLimit
    from ..utils.ast_visitor import AstVisitorWithRecursionLimit
    from ..utils.ast_visitor import AstVisitorWithRecursionLimit
    from ..utils.ast_visitor import AstVisitorWithRecursionLimit
    from ..utils.ast_visitor import AstVisitorWithRecursionLimit
    from ..utils.ast_visitor import AstVisitorWithRecursionLimit
    from ..utils.ast_visitor import AstVisitorWithRecursionLimit
    from ..utils.ast_visitor import AstVisitorWithRecursionLimit

# Generated at 2022-06-18 00:17:41.637428
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    transformer = MetaclassTransformer()
    assert_equal_ast(transformer.visit(parse_to_ast(source)),
                     parse_to_ast(expected))

# Generated at 2022-06-18 00:17:49.387242
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_equal
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_with_metaclass import SixWithMetaclassTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-18 00:17:59.714013
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    transform_and_compare(MetaclassTransformer,
                          """
                          class A(metaclass=B):
                              pass
                          """,
                          """
                          from six import with_metaclass as _py_backwards_six_withmetaclass
                          class A(_py_backwards_six_withmetaclass(B)):
                              pass
                          """)


# Generated at 2022-06-18 00:18:09.879382
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_type
    from ..utils.test_utils import get_ast_node_value
    from ..utils.test_utils import get_ast_node_lineno
    from ..utils.test_utils import get_ast_node_col_offset
    from ..utils.test_utils import get_ast_node_end_lineno
    from ..utils.test_utils import get_ast_node_end_col_offset
    from ..utils.test_utils import get_ast_node_body
    from ..utils.test_utils import get

# Generated at 2022-06-18 00:18:16.858221
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_source
    from ..utils.compat import builtins

    node = ast.ClassDef(name='A',
                        bases=[ast.Name(id=builtins, ctx=ast.Load())],
                        keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='B', ctx=ast.Load()))],
                        body=[],
                        decorator_list=[])

    transformer = MetaclassTransformer()
    result = transformer.visit(node)

    assert to_source(result) == 'class A(_py_backwards_six_withmetaclass(B)):\n    pass'