

# Generated at 2022-06-18 00:08:20.408166
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import get_metaclass

    class A(metaclass=get_metaclass()):
        pass

    node = ast.parse(ast_to_str(ast.ClassDef(name='A',
                                             bases=[],
                                             keywords=[ast.keyword(arg='metaclass',
                                                                   value=ast.Name(id='get_metaclass',
                                                                                  ctx=ast.Load()))],
                                             body=[],
                                             decorator_list=[])))

# Generated at 2022-06-18 00:08:22.542085
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:08:32.127327
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six_import import six_import
    from .six_import import six_import_str

    class DummyTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            return node

    transformer = DummyTransformer()
    node = ast.parse('class A(metaclass=B): pass')
    node = transformer.visit(node)
    assert ast_to_str(node) == 'class A(metaclass=B): pass'

    transformer = MetaclassTransformer()
    node = ast.parse('class A(metaclass=B): pass')
    node = transformer.visit(node)
   

# Generated at 2022-06-18 00:08:34.907146
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:08:45.906992
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_ast

    @snippet
    def test_snippet():
        class A(metaclass=B):
            pass

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    module = source_to_ast(test_snippet.get_source())
    transformer = MetaclassTransformer()
    module = transformer.visit(module)
    assert ast_to_str(module) == expected


# Generated at 2022-06-18 00:08:48.093555
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:08:54.623989
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:09:04.075497
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet

    snippet_ast = parse_snippet(six_import)
    snippet_ast.body.extend(parse_snippet(class_bases).body)

    class_ast = parse_ast("""
    class A(metaclass=B):
        pass
    """)

    expected_ast = parse_ast("""
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

    expected_ast.body.extend(snippet_ast.body)

    transformer = MetaclassTransformer()
    actual_ast = transformer.visit(class_ast)

    assert_equal_

# Generated at 2022-06-18 00:09:09.016209
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_str
    from ..utils.source import source_to_ast_str


# Generated at 2022-06-18 00:09:15.699406
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.tree import to_source
    from ..utils.compat import PY2

    class_def = ast_class(name='A',
                          bases=[ast_name(id='object')],
                          keywords=[ast_keyword(arg='metaclass',
                                                value=ast_name(id='B'))])
    module = ast.Module(body=[class_def])
    transformer = MetaclassTransformer()
    transformer.visit(module)

# Generated at 2022-06-18 00:09:27.669713
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_builder import ast_from_str
    from ..utils.ast_builder import ast_from_snippet
    from ..utils.ast_builder import ast_from_file
    from ..utils.ast_builder import ast_from_module
    from ..utils.ast_builder import ast_from_class
    from ..utils.ast_builder import ast_from_function
    from ..utils.ast_builder import ast_from_method
    from ..utils.ast_builder import ast_from_expression
    from ..utils.ast_builder import ast_from_statement
    from ..utils.ast_builder import ast_from_arguments
    from ..utils.ast_builder import ast_from_keyword
    from ..utils.ast_builder import ast_from_alias
    from ..utils.ast_builder import ast

# Generated at 2022-06-18 00:09:35.796895
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six_import import six_import
    from .six_import import six_import_str
    from .six_import import six_import_str_with_newline
    from .six_import import six_import_str_with_newline_and_indent
    from .six_import import six_import_str_with_newline_and_indent_and_comment
    from .six_import import six_import_str_with_newline_and_indent_and_comment_and_blank_line
    from .six_import import six_import_str_with_newline_and_indent_and_comment_and_blank_line_and_comment

# Generated at 2022-06-18 00:09:45.847191
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PY2

    @snippet
    def test_snippet():
        class A(metaclass=B):
            pass

    @snippet
    def expected_snippet():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    if PY2:
        expected_snippet = expected_snippet.get_body()
    else:
        expected_snippet = test_snippet.get_body()

    tree = test_snippet.get_ast()
   

# Generated at 2022-06-18 00:09:50.570390
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins

    class A(metaclass=builtins.type):
        pass

    node = ast.parse(tree_to_str(A))
    node = MetaclassTransformer().visit(node)

# Generated at 2022-06-18 00:09:58.227587
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_factory import ast_factory
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet

    @snippet
    def test_snippet():
        class A(metaclass=B):
            pass

    expected_ast = ast_factory(
        """
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    )

    test_ast = ast.parse(test_snippet.get_source())
    transformer = MetaclassTransformer()
    transformer.visit(test_ast)

# Generated at 2022-06-18 00:10:05.336320
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PYTHON_VERSION

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    tree = ast.parse(input_code.get_source())
    transformer = MetaclassTransformer(PYTHON_VERSION)
    transformer.visit(tree)
    assert tree_to_str(tree) == expected_code.get_source()




# Generated at 2022-06-18 00:10:14.235160
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)


# Generated at 2022-06-18 00:10:16.193192
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:10:26.023535
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet
    from ..utils.test_utils import assert_equal_code

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    node = MetaclassTransformer().visit(node)
    assert_equal_code(ast_to_str(node), after.get_source())

    module

# Generated at 2022-06-18 00:10:28.022779
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:10:37.245157
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import exec_

    @snippet
    def code():
        class A(metaclass=B):
            pass

    node = ast.parse(code.get_source())
    MetaclassTransformer().visit(node)
    exec_(ast_to_str(node), globals())
    assert A.__class__ == _py_backwards_six_withmetaclass(B)



# Generated at 2022-06-18 00:10:48.134815
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.tree import assert_equal_ast

    node = ast_class(name='A',
                     bases=[ast_name(id='B')],
                     keywords=[ast_keyword(arg='metaclass',
                                           value=ast_name(id='C'))])
    expected = ast_class(name='A',
                         bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                         args=[ast_name(id='C'),
                                               ast_name(id='B')])])

    transformer = MetaclassTransformer()
    result = transformer.visit(node)
    assert_

# Generated at 2022-06-18 00:10:58.835204
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = compile_snippet(before)
    node = MetaclassTransformer().visit(node)
    assert ast_to_str(node) == ast_to_str(compile_snippet(after))

# Generated at 2022-06-18 00:11:03.850026
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    transform_and_compare(MetaclassTransformer,
                          """
                          class A(metaclass=B):
                              pass
                          """,
                          """
                          from six import with_metaclass as _py_backwards_six_withmetaclass
                          class A(_py_backwards_six_withmetaclass(B)):
                              pass
                          """)

# Generated at 2022-06-18 00:11:10.224884
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword
    from ..utils.tree import tree_to_str

    classdef = ast_classdef(name='A',
                            bases=[ast_name(id='B')],
                            keywords=[ast_keyword(arg='metaclass',
                                                  value=ast_name(id='C'))])
    expected = ast_classdef(name='A',
                            bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                            args=[ast_name(id='C'),
                                                  ast_name(id='B')])])

    transformer = MetaclassTransformer()
    result = transformer.vis

# Generated at 2022-06-18 00:11:19.839566
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_and_compile

    source = '''
    class A(metaclass=B):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, parse_snippet(expected))
    assert transformer.tree_changed
    assert transform_and

# Generated at 2022-06-18 00:11:28.006308
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast

    src = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    assert_equal_ast(MetaclassTransformer, src, expected)

# Generated at 2022-06-18 00:11:34.970258
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .six_import import six_import
    from .class_bases import class_bases
    from .metaclass import MetaclassTransformer
    from ..utils.snippet import snippet
    from ..utils.source import source_to_str
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_node
    from ..utils.source import source_to_tuple
    from ..utils.source import source_to_dict
    from ..utils.source import source_to_json
    from ..utils.source import source_to_yaml
    from ..utils.source import source_to_

# Generated at 2022-06-18 00:11:43.914808
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_and_compile
    from ..utils.test_utils import transform_and_compile_snippet

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    assert_equal_ast(MetaclassTransformer, source, expected)

    # Test that the transformer works with a real module

# Generated at 2022-06-18 00:11:45.267475
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:12:02.280953
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet

    source = parse_snippet("""
    class A(metaclass=B):
        pass
    """)
    expected = parse_snippet("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    transformer = MetaclassTransformer()
    result = transformer.visit(source)
    assert_equal_ast(result, expected)
    assert transformer._tree_changed

# Generated at 2022-06-18 00:12:09.033185
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_source
    from ..utils.compat import StringIO

    class_def = ast.ClassDef(name='A',
                             bases=[],
                             keywords=[ast.keyword(arg='metaclass',
                                                    value=ast.Name(id='B',
                                                                   ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    module = ast.Module(body=[class_def])
    transformer = MetaclassTransformer()
    module = transformer.visit(module)
    assert transformer.tree_changed

# Generated at 2022-06-18 00:12:17.505974
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_str
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_code
    from ..utils.source import source_to_function
    from ..utils.source import source_to_method
    from ..utils.source import source_to_class
    from ..utils.source import source_to_object
    from ..utils.source import source_to_module
    from ..utils.source import source_to_ast_module
    from ..utils.source import source_to_tree_module
    from ..utils.source import source_to_code_module

# Generated at 2022-06-18 00:12:25.040268
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import builtins
    from ..utils.compat import six

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    module = ast.parse(input_code.get_source())
    module = MetaclassTransformer().visit(module)
    assert ast_to_str(module) == expected_code.get_source()

# Generated at 2022-06-18 00:12:35.562844
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import builtins

    @snippet
    def input_code():
        class A(metaclass=type):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(type)):
            pass

    node = input_code.get_ast()
    expected_node = expected_code.get_ast()
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)
    assert ast_to_str(new_node) == ast_to_str

# Generated at 2022-06-18 00:12:37.865793
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:12:48.074979
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import get_ast_node_at_line
    from ..utils.test_utils import get_ast_node_name_at_line
    from ..utils.test_utils import get_ast_node_type_at_line
    from ..utils.test_utils import get_ast_node_value_at_line
    from ..utils.test_utils import get_ast_node_lineno_at_line
    from ..utils.test_utils import get_ast_node_col_offset_at_line
    from ..utils.test_utils import get_ast_node_end_lineno_at_line

# Generated at 2022-06-18 00:12:54.884882
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:13:05.813872
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

# Generated at 2022-06-18 00:13:14.322638
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.source_factory import source

    class_def = ast_class(name='A',
                          bases=[],
                          keywords=[ast_keyword(arg='metaclass',
                                                value=ast_name(id='B'))],
                          body=[])
    module = ast.Module(body=[class_def])

# Generated at 2022-06-18 00:13:35.961388
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_ast
    from ..utils.test_utils import assert_equal_ast

    snippet_ = """
    class A(metaclass=B):
        pass
    """
    snippet_expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    ast_ = source_to_ast(snippet_)
    ast_expected = source_to_ast(snippet_expected)

# Generated at 2022-06-18 00:13:44.784467
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import get_metaclass
    from ..utils.snippet import snippet
    from ..utils.compat import get_metaclass
    from ..utils.compat import get_metaclass

    @snippet
    def test_class():
        class A(metaclass=B):
            pass

    @snippet
    def expected_class():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(test_class.get_source())
    expected_node = ast.parse(expected_class.get_source())
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert ast_to_

# Generated at 2022-06-18 00:13:51.983831
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_builder import ast_from_str
    from ..utils.ast_visitor import ASTVisitor
    from ..utils.ast_visitor import visit_tree
    from ..utils.ast_visitor import visit_tree_with_transformer

    class Visitor(ASTVisitor):
        def __init__(self):
            self.visited = []

        def visit_ClassDef(self, node):
            self.visited.append(node)

    class_def = ast_from_str("class A(metaclass=B): pass")
    visitor = Visitor()
    visit_tree(class_def, visitor)
    assert len(visitor.visited) == 1
    assert visitor.visited[0] == class_def


# Generated at 2022-06-18 00:14:01.768266
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword
    from ..utils.source import source
    from ..utils.compile import compile_to_ast

    class_def = ast_classdef(name='A',
                             bases=[],
                             keywords=[ast_keyword(arg='metaclass',
                                                   value=ast_name(id='B'))],
                             body=[])

    module = ast.Module(body=[class_def])

# Generated at 2022-06-18 00:14:11.392919
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet
    from ..utils.test import assert_equal

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transformer = MetaclassTransformer()
    node = compile_snippet(before.get_source(), 'exec')
    transformer.visit(node)
    assert_equal(ast_to_str(node), after.get_source())

# Generated at 2022-06-18 00:14:21.631811
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import get_metaclass
    from ..utils.six import with_metaclass

    class A(with_metaclass(type)):
        pass

    class B(with_metaclass(get_metaclass(A))):
        pass

    class C(with_metaclass(type, get_metaclass(A))):
        pass

    class D(with_metaclass(get_metaclass(A), type)):
        pass

    class E(with_metaclass(get_metaclass(A), get_metaclass(B))):
        pass


# Generated at 2022-06-18 00:14:29.416604
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast

    code = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_to_ast(code)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:14:34.141181
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import parse
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.name = 'Test'
            return node

    class TestMetaclassTransformer(MetaclassTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.name = 'Test'
            return node


# Generated at 2022-06-18 00:14:44.762369
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_factory
    from ..utils.tree import to_source
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast_factory(input_code)
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)
    assert transformer._tree_changed
    assert to_source(new_node) == expected_code

# Generated at 2022-06-18 00:14:48.092734
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins


# Generated at 2022-06-18 00:15:26.881157
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.name = 'Test'
            return node

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='object', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:15:34.901467
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_to_ast(source)
    MetaclassTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:15:43.474647
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_factory import ast_factory
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_ast_equal

    @snippet
    def code():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    tree = ast_factory(code)
    expected_tree = ast_factory(expected)
    transformer = MetaclassTransformer()
    transformer.visit(tree)

# Generated at 2022-06-18 00:15:54.881089
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import parse_module_ast, dump_module_ast

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    module_ast = parse_module_ast(before.get_ast())
    transformer = MetaclassTransformer()
    transformer.visit(module_ast)
    assert dump_module_ast(module_ast) == dump_module_ast(parse_module_ast(after.get_ast()))

# Generated at 2022-06-18 00:16:00.260833
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_with_metaclass import SixWithMetaclassTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node


# Generated at 2022-06-18 00:16:10.463041
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_str
    from ..utils.tree import to_source
    from .base import BaseNodeTransformer
    from .six_transformer import SixTransformer
    from .utils import get_transformed_ast

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                  args=[ast_name(id='B')],
                                  keywords=[])
            node.keywords = []
            self._tree_changed = True
            return self.generic_visit(node)  #

# Generated at 2022-06-18 00:16:19.056753
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import parse_module
    from ..utils.tree import print_tree
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import NodeTransformer
    from .base import NodeVisitor
    from .base import visit_children
    from .base import visit_children_if_changed
    from .base import visit_children_if_changed_recursive
    from .base import visit_children_recursive
    from .base import visit_children_recursive_if_changed
    from .base import visit_children_recursive_if_changed_recursive
    from .base import visit_children_recursive_recursive

# Generated at 2022-06-18 00:16:21.762251
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare

    def test_case(before, after):
        transform_and_compare(MetaclassTransformer, before, after)


# Generated at 2022-06-18 00:16:30.003997
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_ast(expected, tree)

    source = """
    class A(B, metaclass=C):
        pass
    """

# Generated at 2022-06-18 00:16:37.308033
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import ast_to_source as ats
    from ..utils.source import ast_to_code as atc
    from ..utils.source import ast_and_code_to_source as atcas
    from ..utils.source import ast_and_code_to_code as atcac
    from ..utils.source import code_to_ast as cta
    from ..utils.source import code_to_source as cts
    from ..utils.source import code_to_ast_and_code as ctaac
    from ..utils.source import ast_and_code_to_ast as atca


# Generated at 2022-06-18 00:17:58.844640
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    node = ast.parse(source)
    MetaclassTransformer().visit(node)
    assert_equal_source(node, expected)

# Generated at 2022-06-18 00:18:06.793104
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ignore_ws
    from ..utils.test_utils import parse_ast

    code = '''
    class A(metaclass=B):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    tree = parse_ast(code)
    MetaclassTransformer().visit(tree)
    assert_equal_ignore_ws(expected, tree)

# Generated at 2022-06-18 00:18:14.468245
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import get_ast_arguments

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    module = ast.Module(body=[class_def])
    transformer = MetaclassTransformer()
    module = transformer.visit(module)
    assert transformer._tree_changed