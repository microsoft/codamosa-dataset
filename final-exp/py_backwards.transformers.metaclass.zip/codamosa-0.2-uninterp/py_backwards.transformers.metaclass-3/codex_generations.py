

# Generated at 2022-06-18 00:08:22.305155
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_str
    from ..utils.compile_source import compile_source
    from ..utils.source import source

    class_def = ast_class(name='A',
                          bases=[ast_name(id='object')],
                          keywords=[ast_call(func=ast_name(id='metaclass'),
                                             args=[ast_name(id='B')])])
    module = ast.Module(body=[class_def])
    source_ = source(module)

# Generated at 2022-06-18 00:08:27.432957
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import parse

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    tree = parse(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert source != tree

# Generated at 2022-06-18 00:08:34.371604
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()


# Generated at 2022-06-18 00:08:45.182820
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str_no_lineno
    from ..utils.tree import ast_to_str_no_lineno_no_col_offset
    from ..utils.tree import ast_to_str_no_lineno_no_col_offset_no_ctx
    from ..utils.tree import ast_to_str_no_lineno_no_col_offset_no_ctx_no_type_comment
    from ..utils.tree import ast_to_str_no_lineno_no_col_offset_no_ctx_no_type_comment_no_type_ignore
    from ..utils.tree import ast_to_str_no_lineno_no_col_offset_no_ctx_no_type

# Generated at 2022-06-18 00:08:54.255305
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_factory import ast_factory
    from ..utils.snippet import snippet
    from ..utils.ast_factory import ast_factory
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.tree import ast_to_str
    from ..utils.ast_factory import ast_factory
    from ..utils.snippet import snippet
    from ..utils.tree import ast_to_str
    from ..utils.ast_factory import ast_factory
    from ..utils.snippet import snippet
    from ..utils.tree import ast_to_str
    from ..utils.ast_factory import ast_factory

# Generated at 2022-06-18 00:09:03.528239
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_str

    snippet = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    tree = compile_snippet(snippet, 'single', 'exec')
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert source_to_str(tree) == expected

# Generated at 2022-06-18 00:09:10.824756
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_ast(source)
    MetaclassTransformer().visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:09:21.095371
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import source_to_tree as stt
    from ..utils.source import source_to_tree_and_code as sttac
    from ..utils.source import source_to_tree_and_code_and_ast as sttc
    from ..utils.source import source_to_tree_and_code_and_ast_and_source as sttca
    from ..utils.source import source_to_tree_and_code_and_ast_and_source_and_tree as sttcas
    from ..utils.source import source_to_tree_and_code_and_ast_and_

# Generated at 2022-06-18 00:09:27.900088
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source

    class_def = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    MetaclassTransformer().visit(class_def)
    assert_equal_source("""
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """, class_def)

# Generated at 2022-06-18 00:09:32.676219
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    from typed_ast import ast3 as ast
    from ..utils.tree import dump
    from ..utils.tree import parse
    from ..utils.tree import tree_to_str
    from ..utils.tree import tree_to_str_no_lineno
    from ..utils.tree import tree_to_str_no_lineno_no_col_offset


# Generated at 2022-06-18 00:09:45.635959
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_ast

    snippet = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = source_to_ast(snippet)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert ast_to_str(tree) == expected
    assert compile_snippet(snippet) == compile_snippet(expected)

# Generated at 2022-06-18 00:09:51.666183
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_snippet

    snippet = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = ast.parse(snippet)
    MetaclassTransformer().visit(tree)
    assert tree_to_str(tree) == expected
    compile_snippet(tree)



# Generated at 2022-06-18 00:10:00.673976
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PY2

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    if PY2:
        expected_code = expected_code.get_body()
        input_code = input_code.get_body()
        expected_code = ast.fix_missing_locations(expected_code)
        input_code = ast.fix_missing_loc

# Generated at 2022-06-18 00:10:05.853736
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import builtins

    class A(metaclass=builtins.type):
        pass

    node = ast.parse(ast_to_str(ast.Module(body=[A])))
    MetaclassTransformer().visit(node)

# Generated at 2022-06-18 00:10:09.895161
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_source
    from ..utils.test_utils import round_trip


# Generated at 2022-06-18 00:10:19.424176
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import python_version
    from ..utils.test_utils import assert_equal_ast

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    node = MetaclassTransformer().visit(node)
    assert_equal_ast(ast.parse(after.get_source()), node)



# Generated at 2022-06-18 00:10:21.408481
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:10:29.191537
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast

    # Test with metaclass
    node = get_ast("""
    class A(metaclass=B):
        pass
    """)
    node = MetaclassTransformer().visit(node)
    assert astor.to_source(node) == """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    # Test without metaclass
    node = get_ast("""
    class A():
        pass
    """)
    node = MetaclassTransformer().visit(node)

# Generated at 2022-06-18 00:10:38.091382
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_equal_ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='object', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

# Generated at 2022-06-18 00:10:48.936816
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test_utils import assert_equal_ast

    class_def = ast.ClassDef(name='A',
                             bases=[],
                             keywords=[ast.keyword(arg='metaclass',
                                                    value=ast.Name(id='B',
                                                                   ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    module = ast.Module(body=[class_def])
    expected = ast.Module(body=[six_import.get_body()[0], class_def])
    transformer = MetaclassTransformer()
    actual = transformer.visit(module)
    assert_equal_ast(actual, expected)

# Generated at 2022-06-18 00:11:01.474374
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.ast import parse

    source_code = source('''
        class A(metaclass=B):
            pass
    ''')
    tree = parse(source_code)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert source(tree) == source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

# Generated at 2022-06-18 00:11:03.888825
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    transform_and_compare(MetaclassTransformer, '''
    class A(metaclass=B):
        pass
    ''')

# Generated at 2022-06-18 00:11:07.203244
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:11:14.535307
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    node = parse_ast(source)
    MetaclassTransformer().visit(node)
    assert_equal_source(node, expected)

# Generated at 2022-06-18 00:11:25.042680
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PY2

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = input_code.get_ast()
    expected = expected_code.get_ast()
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)

# Generated at 2022-06-18 00:11:33.160342
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet_to_ast

    class_def = snippet_to_ast("""
        class A(metaclass=B):
            pass
    """)

    expected = snippet_to_ast("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    transformer = MetaclassTransformer()
    transformer.visit(class_def)
    assert ast_to_str(class_def) == ast_to_str(expected)

# Generated at 2022-06-18 00:11:36.391512
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast, get_name, get_call_name


# Generated at 2022-06-18 00:11:44.280848
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node

    tree = ast.parse('class A(metaclass=B): pass')
    tree = MetaclassTransformer().visit(tree)
    tree = TestTransformer().visit(tree)

# Generated at 2022-06-18 00:11:51.152160
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_factory import ast_factory
    from ..utils.snippet import snippet
    from ..utils.compat import PY2

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    if PY2:
        expected_code = expected_code.get_body()
        input_code = input_code.get_body()
        transformer = MetaclassTransformer()

# Generated at 2022-06-18 00:12:00.806771
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    expected_code = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    node = ast.parse(input_code.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == expected_code

# Generated at 2022-06-18 00:12:22.206513
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PY2

    @snippet
    def module():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    if PY2:
        expected = expected.get_body()
    else:
        expected = module.get_body()

    node = module.get_ast()
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)
    assert ast_to_

# Generated at 2022-06-18 00:12:24.773309
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_unicode


# Generated at 2022-06-18 00:12:35.562754
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import source_to_code_and_ast as stca
    from ..utils.source import source_to_ast_and_code_and_tree as staact
    from ..utils.source import source_to_code_and_ast_and_tree as stcat
    from ..utils.source import source_to_tree as stt
    from ..utils.source import source_to_code_and_tree as stct
    from ..utils.source import source_to_ast_and_tree as stat
    from ..utils.source import source_to_code_and_ast_and_tree as st

# Generated at 2022-06-18 00:12:45.968141
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.name = 'Test'
            return node

    node = ast.parse('class A(metaclass=B): pass')
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'

    transformer = TestTransformer()
    transformer.visit(node)

# Generated at 2022-06-18 00:12:54.995115
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet
    from .base import BaseNodeTransformer

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = compile_snippet(before.get_source(), ast.parse)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert tree_to_str(node) == after.get_source()




# Generated at 2022-06-18 00:12:56.686205
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, assert_equal_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:13:00.349215
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast


# Generated at 2022-06-18 00:13:10.774841
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_compare import compare_ast
    from ..utils.snippet import snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    node = MetaclassTransformer().visit(node)
    expected = ast.parse(after.get_source())
    assert compare_ast(node, expected)

# Generated at 2022-06-18 00:13:15.149999
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    node = ast.parse(source)
    MetaclassTransformer().visit(node)
    assert ast.dump(node) == source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')


# Generated at 2022-06-18 00:13:23.257206
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import get_ast_arguments
    from ..utils.compat import get_ast_keywords
    from ..utils.compat import get_ast_keyword
    from ..utils.compat import get_ast_arg
    from ..utils.compat import get_ast_keyword_arg
    from ..utils.compat import get_ast_keyword_value
    from ..utils.compat import get_ast_keyword_name
    from ..utils.compat import get_ast_keyword_arg_name
    from ..utils.compat import get_ast_keyword_arg_value
    from ..utils.compat import get_ast_keyword_arg_keyword

# Generated at 2022-06-18 00:14:03.464872
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.tree import tree_to_str


# Generated at 2022-06-18 00:14:10.916224
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''') == source(tree)

# Generated at 2022-06-18 00:14:21.608471
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compat import builtins

    source_code = source('''
    class A(metaclass=B):
        pass
    ''')

    node = ast.parse(source_code)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert transformer._tree_changed is True
    assert source_code != source(node)

    source_code = source('''
    class A(B, metaclass=C):
        pass
    ''')

    node = ast.parse(source_code)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert transformer._tree_changed is True
    assert source_code != source(node)


# Generated at 2022-06-18 00:14:30.622128
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_source
    from ..utils.test_utils import round_trip

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_source(source)
    tree = MetaclassTransformer().visit(tree)
    assert_equal_ast(tree, parse_ast(expected))
    assert round_trip(tree) == expected

# Generated at 2022-06-18 00:14:39.082754
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.test import assert_node_equals
    from ..utils.tree import parse_ast

    node = parse_ast("""
    class A(metaclass=B):
        pass
    """)
    expected = parse_ast("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert_node_equals(expected, node)

# Generated at 2022-06-18 00:14:46.372406
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet

    snippet_ast = parse_snippet(six_import)
    snippet_ast.body.extend(parse_snippet(class_bases))

    node = parse_ast("""
    class A(metaclass=B):
        pass
    """)
    expected = parse_ast("""
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

    transformer = MetaclassTransformer()
    transformer.visit(node)

    assert_equal_ast(node, expected)

# Generated at 2022-06-18 00:14:56.631773
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import ast_to_source as ats

    # Test 1
    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = sta(source)
    MetaclassTransformer().visit(tree)
    assert ats(tree) == expected

    # Test 2

# Generated at 2022-06-18 00:15:07.953176
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PY2

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    if PY2:
        expected_code = expected_code.get_body()
        expected_code = ast.fix_missing_locations(expected_code)
        expected_code = ast_to_str(expected_code)

        input_code = input_code.get

# Generated at 2022-06-18 00:15:15.181826
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:15:18.746351
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast


# Generated at 2022-06-18 00:16:16.211712
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_equal

    class_def = ast.ClassDef(name='A',
                             bases=[],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B',
                                                                  ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

# Generated at 2022-06-18 00:16:20.540027
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import dump
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node


# Generated at 2022-06-18 00:16:28.692403
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source

    class_def = ast_factory(
        """
        class A(metaclass=B):
            pass
        """,
        mode='exec',
    )
    expected = ast_factory(
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """,
        mode='exec',
    )
    transformer = MetaclassTransformer()
    transformer.visit(class_def)
    assert source(class_def) == source(expected)

# Generated at 2022-06-18 00:16:31.801384
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_builder import ast_from_str
    from ..utils.ast_helper import ast_equal
    from ..utils.ast_visitor import visit_ast


# Generated at 2022-06-18 00:16:36.702764
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:16:42.937934
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compiler import compile_snippet

    class_def = ast.ClassDef(name='A',
                             bases=[],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B',
                                                                  ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:16:47.556208
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_str

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:16:57.442793
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import six

    class A(six.with_metaclass(object)):
        pass

    node = ast.parse(ast_to_str(ast.ClassDef(name='A',
                                             bases=[ast.Name(id='object', ctx=ast.Load())],
                                             keywords=[ast.keyword(arg='metaclass',
                                                                   value=ast.Name(id='object', ctx=ast.Load()))],
                                             body=[],
                                             decorator_list=[])))
    node = MetaclassTransformer().visit(node)

# Generated at 2022-06-18 00:17:01.200412
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert print_tree(node) == after.get_source()
    compile_snippet(node)

# Generated at 2022-06-18 00:17:08.763222
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import parse
    from ..utils.tree import dump
    from ..utils.tree import compare_ast
    from ..utils.tree import compare_source
    from ..utils.tree import compare_source_with_snippet
    from ..utils.tree import compare_source_with_snippet_with_indent
    from ..utils.tree import compare_source_with_snippet_with_indent_with_newline
    from ..utils.tree import compare_source_with_snippet_with_newline
    from ..utils.tree import compare_source_with_snippet_with_newline_with_indent
    from ..utils.tree import compare_source_with_snippet_with_newline_