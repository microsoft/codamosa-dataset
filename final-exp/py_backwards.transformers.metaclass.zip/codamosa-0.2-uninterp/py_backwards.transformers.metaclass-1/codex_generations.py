

# Generated at 2022-06-18 00:08:20.146650
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            node.body.insert(0, ast.Expr(value=ast.Str(s='test')))
            return node

    node = ast.parse('class A(metaclass=B): pass')
    node = TestTransformer().visit(node)

# Generated at 2022-06-18 00:08:30.546013
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_nodes
    from ..utils.test_utils import get_ast_node_type
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_attr
    from ..utils.test_utils import get_ast_node_attrs
    from ..utils.test_utils import get_ast_node_attr_value
    from ..utils.test_utils import get_ast_node_attr_values
    from ..utils.test_utils import get_ast_node_attr_value_type
    from ..utils.test_utils import get

# Generated at 2022-06-18 00:08:35.970992
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_source

    source = """
        class A(metaclass=B):
            pass
        """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    assert_source(MetaclassTransformer, source, expected)

# Generated at 2022-06-18 00:08:47.034471
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            node.body.insert(0, ast.Expr(value=ast.Str(s='test')))
            return self.generic_visit(node)  # type: ignore

    node = ast.parse('x = 1')
    node = TestTransformer().visit(node)
    assert tree_to_str(node) == '''\
Module(body=[Expr(value=Str(s='test')), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1))])
'''

#

# Generated at 2022-06-18 00:08:52.451305
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_source
    from ..utils.test_utils import round_trip_dump
    from ..utils.test_utils import round_trip_load
    from ..utils.test_utils import round_trip_parse
    from ..utils.test_utils import round_trip_source


# Generated at 2022-06-18 00:09:03.760416
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    node = ast.Module(body=[
        ast.ClassDef(name='A',
                     bases=[ast.Name(id='object', ctx=ast.Load())],
                     keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                     body=[],
                     decorator_list=[])
    ])

# Generated at 2022-06-18 00:09:12.236941
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(input_code.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == expected_code.get_source()



# Generated at 2022-06-18 00:09:17.295886
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast

    code = '''class A(metaclass=B):
    pass'''

# Generated at 2022-06-18 00:09:22.861988
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def code():
        class A(metaclass=B):
            pass

    node = ast.parse(code.get_body())
    MetaclassTransformer().visit(node)

# Generated at 2022-06-18 00:09:33.412984
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree
    from ..utils.test_utils import transform_and_compile

    source = '''
        class A(metaclass=B):
            pass
    '''
    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    '''
    tree = parse_ast_tree(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected)
    transform_and_compile(source, expected)

# Generated at 2022-06-18 00:09:45.883833
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node

    class TestTransformer3(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node


# Generated at 2022-06-18 00:09:52.258266
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer

    @snippet
    def test():
        class A(metaclass=B):
            pass

    tree = ast.parse(test.get_source())
    tree = SixTransformer().visit(tree)
    tree = MetaclassTransformer().visit(tree)

# Generated at 2022-06-18 00:10:00.318079
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_node_equals
    from ..utils.test_utils import assert_tree_equals
    from ..utils.test_utils import parse_ast

    class_def = parse_ast("""
        class A(metaclass=B):
            pass
    """)
    expected = parse_ast("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    transformer = MetaclassTransformer()
    transformer.visit(class_def)
    assert_tree_equals(class_def, expected)
    assert transformer._tree_changed is True



# Generated at 2022-06-18 00:10:06.098829
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .utils import get_transformed_ast

    class A(metaclass=type):
        pass

    class B(metaclass=type, x=1):
        pass

    class C(metaclass=type, x=1, y=2):
        pass

    class D(metaclass=type, x=1, y=2, z=3):
        pass

    class E(metaclass=type, x=1, y=2, z=3, w=4):
        pass

    class F(metaclass=type, x=1, y=2, z=3, w=4, v=5):
        pass



# Generated at 2022-06-18 00:10:07.247291
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, assert_equal_source


# Generated at 2022-06-18 00:10:09.512926
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform


# Generated at 2022-06-18 00:10:15.818866
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def __init__(self):
            self.metaclass = None
            self.bases = None

        def visit_ClassDef(self, node: ast.ClassDef) -> None:
            self.metaclass = node.keywords[0].value
            self.bases = node.bases


# Generated at 2022-06-18 00:10:17.285412
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:10:26.886338
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import builtins

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:10:36.437153
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = input_code.get_ast()
    expected_node = expected_code.get_ast()
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)
    assert ast_to_str(new_node) == ast_to_str(expected_node)

# Generated at 2022-06-18 00:10:48.392127
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def code():
        class A(metaclass=B):
            pass

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    tree = ast.parse(code.get_body())
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert ast_to_str(tree) == expected

# Generated at 2022-06-18 00:10:59.192409
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import ast_to_source as ats
    from ..utils.source import ast_to_code as atc
    from ..utils.source import ast_to_source_and_code as atsac
    from ..utils.source import code_to_ast as cta
    from ..utils.source import code_to_source as cts
    from ..utils.source import code_to_ast_and_source as ctas
    from ..utils.source import source_to_code_and_ast as stca
    from ..utils.source import code_to_source_and_ast as ctsa


# Generated at 2022-06-18 00:11:02.654143
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import PYTHON_VERSION

    class TestTransformer(MetaclassTransformer):
        def __init__(self):
            self._tree_changed = False


# Generated at 2022-06-18 00:11:08.474072
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as to_ast
    from ..utils.source import source_to_code as to_code
    from ..utils.source import source_to_ast_and_code as to_ast_and_code
    from ..utils.source import ast_to_source as to_source
    from ..utils.source import ast_and_code_to_source as to_source_and_code
    from ..utils.source import ast_and_code_to_source as to_source_and_code
    from ..utils.source import code_equal
    from ..utils.source import ast_equal


# Generated at 2022-06-18 00:11:18.378209
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = input_code.get_ast()
    expected = expected_code.get_ast()
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == ast_to_str(expected)

# Generated at 2022-06-18 00:11:29.052188
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import exec_

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()

    exec_(after.get_source())

# Generated at 2022-06-18 00:11:30.492236
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast


# Generated at 2022-06-18 00:11:32.595248
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import round_trip


# Generated at 2022-06-18 00:11:34.802990
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:11:43.876961
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.test import transform
    from ..utils.tree import node_equals

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:11:51.150096
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:12:00.174212
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import builtins

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert tree_to_str(node) == after.get_source()

# Generated at 2022-06-18 00:12:01.980634
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:12:08.858888
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_with_metaclass import SixWithMetaclassTransformer
    from .six_with_metaclass import six_with_metaclass
    from .six_with_metaclass import six_with_metaclass_import

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            if node.keywords:
                metaclass = node.keywords[0].value

# Generated at 2022-06-18 00:12:17.393242
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.tree import to_source
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                  args=[node.keywords[0].value,
                                        ast.List(elts=node.bases)])
            node.keywords = []
            return node


# Generated at 2022-06-18 00:12:24.969746
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)

    class MetaclassTransformer(BaseNodeTransformer):
        """Compiles:
            class A(metaclass=B):
                pass
        To:
            class A(_py_backwards_six_with_metaclass(B))
        
        """
        target = (2, 7)

# Generated at 2022-06-18 00:12:34.276705
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_tree
    from ..utils.compat import to_tuple

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_tree(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert to_tuple(tree) == to_tuple(parse_tree(expected))

# Generated at 2022-06-18 00:12:44.862314
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.tree import ast_to_source

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='object', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:12:46.905909
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:12:55.698125
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()
    assert compile_snippet(node) == compile_snippet(after.get_ast())

# Generated at 2022-06-18 00:13:16.324857
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.tree import ast_print

    class_def = ast_class(name='A',
                          bases=[],
                          keywords=[ast_keyword(arg='metaclass',
                                                value=ast_name(id='B'))],
                          body=[])
    module = ast.Module(body=[class_def])

    transformer = MetaclassTransformer()
    module = transformer.visit(module)

    assert transformer._tree_changed is True

# Generated at 2022-06-18 00:13:23.963859
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_unicode

    source = source_to_unicode('''
        class A(metaclass=B):
            pass
    ''')
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    print_tree(tree)
    code = compile_snippet(tree)
    assert code.co_consts[0] == 'A'
    assert code.co_consts[1] == 'B'
    assert code.co_consts[2] == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-18 00:13:34.129404
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_code_equal
    from ..utils.test_utils import parse_ast

    # Test case 1
    node = parse_ast("""
        class A(metaclass=B):
            pass
    """)
    expected = parse_ast("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)
    MetaclassTransformer().visit(node)
    assert_code_equal(node, expected)

    # Test case 2
    node = parse_ast("""
        class A(B, metaclass=C):
            pass
    """)

# Generated at 2022-06-18 00:13:43.965567
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import python_version
    from ..utils.compat import typed_ast_version
    from ..utils.compat import is_typed_ast
    from ..utils.compat import is_typed_ast_unsupported
    from ..utils.compat import is_typed_ast_unsupported_version
    from ..utils.compat import is_typed_ast_unsupported_version_error
    from ..utils.compat import is_typed_ast_unsupported_error
    from ..utils.compat import is_typed_ast_unsupported_node
    from ..utils.compat import is_typed_ast_unsupported_node_error
   

# Generated at 2022-06-18 00:13:49.273301
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:13:57.409848
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_equal

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

# Generated at 2022-06-18 00:14:01.368515
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_builder import ast_from_str
    from ..utils.ast_visitor import AstVisitor
    from ..utils.ast_visitor import visit_ast
    from ..utils.ast_visitor import visit_ast_with_transformer


# Generated at 2022-06-18 00:14:11.105915
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.source_factory import source

    class_def = ast_class(name='A',
                          bases=[ast_name(id='object')],
                          keywords=[ast_keyword(arg='metaclass',
                                                value=ast_name(id='B'))])
    module = ast.Module(body=[class_def])

# Generated at 2022-06-18 00:14:21.595604
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_and_compile
    from ..utils.test_utils import transform_and_compile_snippet

    # Test that the transformer does not change the AST if there is no metaclass keyword
    ast_node = parse_snippet('class A(B): pass')
    transformer = MetaclassTransformer()
    transformer.visit(ast_node)
    assert_equal_ast(ast_node, parse_snippet('class A(B): pass'))

    # Test that the transformer does not change the AST if there is a metaclass keyword but no bases

# Generated at 2022-06-18 00:14:30.585837
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_to_ast

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    tree = compile_to_ast(before.get_source())
    MetaclassTransformer().visit(tree)
    assert ast_to_str(tree) == after.get_source()

# Generated at 2022-06-18 00:14:59.848849
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef
    from ..utils.test_utils import parse_to_module
    from ..utils.test_utils import parse_to_stmt

    # Test for classdef with metaclass
    classdef = parse_to_classdef("class A(metaclass=B): pass")
    expected = parse_to_classdef("class A(_py_backwards_six_withmetaclass(B)): pass")
    assert_equal_ast(MetaclassTransformer().visit(classdef), expected)

    # Test for classdef without metaclass
    classdef = parse_to_

# Generated at 2022-06-18 00:15:10.082062
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_with_metaclass import SixWithMetaclassTransformer
    from .six_import_with_metaclass import SixImportWithMetaclassTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node

    class TestMetaclassTransformer(MetaclassTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node


# Generated at 2022-06-18 00:15:16.036448
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import PY2
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(input_code.get_source())
    node = MetaclassTransformer().visit(node)
    assert ast_to_str(node) == expected_code.get_source()

# Generated at 2022-06-18 00:15:27.506727
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import builtins

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(input_code.get_source())
    expected = ast.parse(expected_code.get_source())
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == ast_to_str

# Generated at 2022-06-18 00:15:37.814865
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.compile import compile_function
    from ..utils.tree import tree_to_str
    from ..utils.test import assert_equal

    def test_case(code, expected):
        tree = ast.parse(code)
        transformer = MetaclassTransformer()
        transformer.visit(tree)
        actual = tree_to_str(tree)
        assert_equal(actual, expected)

    test_case(
        code='''
        class A(metaclass=B):
            pass
        ''',
        expected='''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        '''
    )

   

# Generated at 2022-06-18 00:15:45.785811
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    node = MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()

# Generated at 2022-06-18 00:15:55.821093
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_with_metaclass import SixWithMetaclassTransformer
    from .six_with_metaclass import six_with_metaclass_import
    from .six_with_metaclass import six_with_metaclass_call

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            if node.keywords:
                metaclass = node.keywords[0].value

# Generated at 2022-06-18 00:16:04.016313
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_attr
    from ..utils.test_utils import get_ast_node_type
    from ..utils.test_utils import get_ast_node_lineno
    from ..utils.test_utils import get_ast_node_col_offset
    from ..utils.test_utils import get_ast_node_end_lineno
    from ..utils.test_utils import get_ast_node_end_col_offset
    from ..utils.test_utils import get_ast_node_body
    from ..utils.test_utils import get

# Generated at 2022-06-18 00:16:15.073025
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_node as stn
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_tokens as stt
    from ..utils.source import source_to_token_list as sttl
    from ..utils.source import source_to_tokens_list as sttl
    from ..utils.source import source_to_ast_list as stal
    from ..utils.source import source_to_ast_list as stal
    from ..utils.source import source_to_ast_list as stal
    from ..utils.source import source_to_ast_list as stal
    from ..utils.source import source_to_ast_list as stal
    from ..utils.source import source_to

# Generated at 2022-06-18 00:16:17.165024
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, compare_ast
    from ..utils.test_utils import parse


# Generated at 2022-06-18 00:17:20.984764
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import get_metaclass_keyword
    from ..utils.compat import get_metaclass_keyword_value
    from ..utils.compat import get_metaclass_keyword_value_name
    from ..utils.compat import get_metaclass_keyword_value_attr
    from ..utils.compat import get_metaclass_keyword_value_call
    from ..utils.compat import get_metaclass_keyword_value_call_func
    from ..utils.compat import get_metaclass_keyword_value_call_args
    from ..utils.compat import get_metaclass_keyword_value_call_args_elts

# Generated at 2022-06-18 00:17:25.566876
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.tree import tree_to_str

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='object', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

    module = ast.Module(body=[class_def])
    MetaclassTransformer().visit(module)

# Generated at 2022-06-18 00:17:34.432581
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet
    from ..utils.compiler import assert_compiled_correctly

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    node = MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()
    assert_compiled

# Generated at 2022-06-18 00:17:36.269590
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast
    from ..utils.tree import dump_ast


# Generated at 2022-06-18 00:17:43.337226
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast

    class_def = parse_to_ast("""
    class A(metaclass=B):
        pass
    """)

    expected = parse_to_ast("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

    transformer = MetaclassTransformer()
    transformer.visit(class_def)
    assert_equal_ast(class_def, expected)

# Generated at 2022-06-18 00:17:49.627033
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import parse

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = parse(before.get_ast())
    MetaclassTransformer().visit(node)
    assert before.get_source() == after.get_source()

# Generated at 2022-06-18 00:17:59.780241
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name
    from ..utils.source_factory import source

    class_def = ast_class(name='A',
                          bases=[],
                          keywords=[ast.keyword(arg='metaclass', value=ast_name('B'))])
    module = ast.Module(body=[class_def])
    expected = ast.Module(body=[six_import.get_body(),
                                ast_class(name='A',
                                          bases=[ast_call(func=ast_name('_py_backwards_six_withmetaclass'),
                                                          args=[ast_name('B')],
                                                          keywords=[])])])

# Generated at 2022-06-18 00:18:08.320347
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def code():
        class A(metaclass=B):
            pass

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    node = ast.parse(code.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == expected

# Generated at 2022-06-18 00:18:13.239981
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_source

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert_source(tree, expected)