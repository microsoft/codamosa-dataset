

# Generated at 2022-06-18 00:08:20.779148
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef

    classdef = parse_to_classdef("""
        class A(metaclass=B):
            pass
    """)

    expected_classdef = parse_to_classdef("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    module = parse_to_ast("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
    """)


# Generated at 2022-06-18 00:08:22.566301
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:08:29.725592
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compile import compile_snippet
    from ..utils.snippet import snippet

    @snippet
    def test():
        class A(metaclass=B):
            pass

    node = ast.parse(test.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == compile_snippet(test.get_source())

# Generated at 2022-06-18 00:08:39.775200
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins_name
    from ..utils.snippet import snippet
    from ..utils.source import source_to_unicode

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(source_to_unicode(before.get_source()))
    node = MetaclassTransformer().visit(node)

# Generated at 2022-06-18 00:08:51.009749
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins_name
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from . import six
    from . import builtins
    from . import typing
    from . import typing_extensions
    from . import collections_abc
    from . import abc
    from . import enum
    from . import dataclasses
    from . import typing_inspect
    from . import contextvars
    from . import typing_inspect
    from . import typing_inspect
    from . import typing_inspect
    from . import typing_inspect
    from . import typing_inspect
    from . import typing_inspect
    from . import typing_inspect
    from . import typing_

# Generated at 2022-06-18 00:08:56.262860
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_attr
    from ..utils.test_utils import get_ast_node_attr_value
    from ..utils.test_utils import get_ast_node_attr_value_name
    from ..utils.test_utils import get_ast_node_attr_value_attr
    from ..utils.test_utils import get_ast_node_attr_value_attr_value
    from ..utils.test_utils import get_ast_node_attr_value_attr_value_name
    from ..utils.test_utils import get_ast_

# Generated at 2022-06-18 00:08:57.892256
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import parse


# Generated at 2022-06-18 00:09:06.580940
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

# Generated at 2022-06-18 00:09:08.577328
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:09:11.808695
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:09:20.061483
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    tree = ast.parse(source)
    tree = MetaclassTransformer().visit(tree)
    assert source(tree) == source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')


# Generated at 2022-06-18 00:09:31.719912
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.snippet import snippet

    @snippet
    def input_snippet():
        class A(metaclass=B):
            pass

    @snippet
    def expected_snippet():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    input_ast = ast.parse(input_snippet.get_source())
    expected_ast = ast.parse(expected_snippet.get_source())

    transformer = MetaclassTransformer()

# Generated at 2022-06-18 00:09:42.797753
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast

    code = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    assert_equal_ast(MetaclassTransformer, code, expected)

    code = """
        class A(B, C, metaclass=D):
            pass
    """

# Generated at 2022-06-18 00:09:50.798577
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_factory
    from ..utils.snippet import snippet

    @snippet
    def test_snippet():
        class A(metaclass=B):
            pass

    tree = ast.parse(test_snippet.get_source())
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed

    expected_tree = ast_factory(
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    )
    assert tree == expected_tree



# Generated at 2022-06-18 00:09:55.849326
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins

    class A(metaclass=type):
        pass

    node = ast.parse(tree_to_str(A))
    MetaclassTransformer().visit(node)

# Generated at 2022-06-18 00:09:57.311517
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:10:04.721720
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast_from_source

    @snippet
    def source():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    source_ast = get_ast_from_source(source.get_source())
    expected_ast = get_ast_from_source(expected.get_source())
    transformer = MetaclassTransformer()
    result = transformer.visit(source_ast)
   

# Generated at 2022-06-18 00:10:10.081358
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str

    node = ast.parse('class A(metaclass=B): pass')
    node = MetaclassTransformer().visit(node)
    assert ast_to_str(node) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'


# Generated at 2022-06-18 00:10:18.003466
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet

    snippet = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_snippet(snippet)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, parse_ast(expected))

# Generated at 2022-06-18 00:10:27.446499
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_factory
    from ..utils.tree import tree_to_str

    class_def = ast_factory(
        """
        class A(metaclass=B):
            pass
        """
    )
    expected = ast_factory(
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    )
    transformer = MetaclassTransformer()
    module = transformer.visit(ast.Module(body=[class_def]))
    assert tree_to_str(module) == tree_to_str(expected)


# Generated at 2022-06-18 00:10:37.719528
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    module = parse_ast("""
    class A(metaclass=B):
        pass
    """)

    expected = parse_ast("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

    transformer = MetaclassTransformer()
    assert_equal_ast(expected, transformer.visit(module))



# Generated at 2022-06-18 00:10:48.610944
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import roundtrip_unparse

    snippet_code = """
    class A(metaclass=B):
        pass
    """
    expected_code = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    snippet_ast = parse_snippet(snippet_code)
    expected_ast = parse_ast(expected_code)
    transformer = MetaclassTransformer()
    result_ast = transformer.visit(snippet_ast)

# Generated at 2022-06-18 00:10:59.412971
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast_node
    from ..utils.test_utils import parse_to_class_node

    class_node = parse_to_class_node("""
        class A(metaclass=B):
            pass
    """)

    expected_class_node = parse_to_class_node("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    module_node = parse_to_ast_node("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
    """)


# Generated at 2022-06-18 00:11:02.201208
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import round_trip
    from ..utils.test_utils import round_trip_dump


# Generated at 2022-06-18 00:11:09.057254
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast_tree
    from ..utils.test_utils import transform_and_compile

    tree = parse_ast_tree('''
        class A(metaclass=B):
            pass
    ''')
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_source(new_tree, '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')
    assert transform_and_compile(new_tree)



# Generated at 2022-06-18 00:11:15.801919
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("class A(metaclass=B): pass")
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert transformer._tree_changed
    assert ast.dump(node) == "from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass"


# Generated at 2022-06-18 00:11:17.703270
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:11:29.136621
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import parse_ast_str
    from ..utils.tree import tree_to_str
    from ..utils.tree import tree_to_str_with_comments
    from ..utils.tree import tree_to_str_with_comments_and_newlines
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import NodeTransformer
    from .base import NodeVisitor
    from .base import Transformer
    from .base import Visitor
    from .base import visit_children
    from .base import visit_children_with_newlines
    from .base import visit_children_with_newlines_and_comments
    from .base import visit_children_with_newlines_and

# Generated at 2022-06-18 00:11:35.603362
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.snippet import snippet
    from ..utils.tree import tree
    from ..utils.visitor import print_visitor
    from .base import BaseNodeTransformer
    from .metaclass import MetaclassTransformer

    @snippet
    def source_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass


# Generated at 2022-06-18 00:11:43.452534
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            return node

    node = ast.parse('class A(metaclass=B): pass')
    expected = ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)): pass')
    actual = TestTransformer().visit(node)
    assert tree_to_str(actual) == tree_to_str(expected)


# Generated at 2022-06-18 00:12:01.867892
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_code
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_ast

    @snippet
    def code():
        class A(metaclass=B):
            pass

    expected_code = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = compile_code(code)
    assert_equal_ast(tree, expected_code)
    assert_equal_code(tree, expected_code)

# Generated at 2022-06-18 00:12:08.788702
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_str
    from .base import BaseNodeTransformer
    from .six_transformer import SixTransformer
    from .metaclass_transformer import MetaclassTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node


# Generated at 2022-06-18 00:12:10.459877
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:12:18.822636
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import assert_dependencies_added
    from ..utils.test_utils import assert_dependencies_not_added

    # Test without metaclass
    class_def = ast.parse('class A(B): pass').body[0]
    transformer = MetaclassTransformer()
    assert_equal_ast(transformer.visit(class_def), class_def)
    assert_tree_not_changed(transformer)
    assert_dependencies_not_added(transformer)

    # Test with metaclass

# Generated at 2022-06-18 00:12:21.708907
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:12:26.373306
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet

    @snippet
    def code():
        class A(metaclass=B):
            pass

    tree = ast.parse(code.get_source())
    MetaclassTransformer().visit(tree)

# Generated at 2022-06-18 00:12:36.559844
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    # Test case 1
    class_def = ast.ClassDef(name='A',
                             bases=[],
                             keywords=[ast.keyword(arg='metaclass',
                                                    value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    module = ast.Module(body=[class_def])
    expected = snippet(
        '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        '''
    )
    expected = ast.parse

# Generated at 2022-06-18 00:12:44.761969
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:12:51.906902
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast, get_name, get_names
    from ..utils.snippet import snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = get_ast(before.get_source())
    MetaclassTransformer().visit(node)
    assert astor.to_source(node) == after.get_source()



# Generated at 2022-06-18 00:13:02.652430
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at
    from .base import BaseNodeTransformer

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass


    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)


    class MetaclassTransformer(BaseNodeTransformer):
        """Compiles:
            class A(metaclass=B):
                pass
        To:
            class A(_py_backwards_six_with_metaclass(B))
        
        """
        target = (2, 7)

# Generated at 2022-06-18 00:13:22.385923
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast


# Generated at 2022-06-18 00:13:24.358453
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_node


# Generated at 2022-06-18 00:13:34.092520
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import get_metaclass
    from ..utils.compat import get_bases

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = input_code.get_ast()
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == ast_to_str(expected_code.get_ast())


# Generated at 2022-06-18 00:13:36.796774
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import round_trip


# Generated at 2022-06-18 00:13:43.668155
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    expected = source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    tree = get_ast(source)
    new_tree = MetaclassTransformer().visit(tree)
    assert compare_asts(expected, new_tree)

# Generated at 2022-06-18 00:13:50.775557
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()
    assert compile_snippet(node) == compile_snippet(after.get_ast())

# Generated at 2022-06-18 00:13:59.987839
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

    module = ast.Module(body=[class_def])

    expected_module = ast.Module(body=[six_import.get_body(),
                                       class_def])


# Generated at 2022-06-18 00:14:02.053697
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:14:11.565841
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword
    from ..utils.tree import tree_to_str

    class_def = ast_classdef(name='A',
                             bases=[],
                             keywords=[ast_keyword(arg='metaclass',
                                                   value=ast_name(id='B'))])
    expected = ast_classdef(name='A',
                            bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                            args=[ast_name(id='B'),
                                                  ast.List(elts=[])],
                                            keywords=[])])

    transformer = MetaclassTransformer()
    result = transformer.vis

# Generated at 2022-06-18 00:14:21.706538
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name
    from ..utils.snippet import snippet
    from ..utils.tree import tree_to_str

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = input_code.get_ast()
    expected_node = expected_code.get_ast()

    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)

    assert tree_to_str

# Generated at 2022-06-18 00:14:58.789302
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str

# Generated at 2022-06-18 00:15:07.848226
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_node_source

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    MetaclassTransformer().visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:15:14.073766
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compiler import compile_snippet

    snippet = """
        class A(metaclass=B):
            pass
    """
    module = compile_snippet(snippet)
    transformer = MetaclassTransformer()
    transformer.visit(module)
    assert ast_to_str(module) == """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """

# Generated at 2022-06-18 00:15:26.149058
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='C', ctx=ast.Load())]
            return node


# Generated at 2022-06-18 00:15:34.598908
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile
    from ..utils.test_utils import assert_code_equal

    code = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = compile(code, '<test>', 'exec')
    assert_code_equal(compile(expected, '<test>', 'exec'), tree)

# Generated at 2022-06-18 00:15:36.351617
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, assert_equal_source
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:15:44.735461
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .six_transformer import SixTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast_call('_py_backwards_six_withmetaclass',
                                   [node.keywords[0].value,
                                    ast.List(elts=node.bases)])]
            node.keywords = []
            return node


# Generated at 2022-06-18 00:15:55.500400
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PY2
    from ..utils.compat import PY3
    from ..utils.compat import PY35
    from ..utils.compat import PY36
    from ..utils.compat import PY37
    from ..utils.compat import PY38
    from ..utils.compat import PY39

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

# Generated at 2022-06-18 00:16:02.605099
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source

    # Given
    class_def = ast_factory(
        """
        class A(metaclass=B):
            pass
        """
    )
    transformer = MetaclassTransformer()

    # When
    transformer.visit(class_def)

    # Then
    assert source(class_def) == """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

# Generated at 2022-06-18 00:16:06.530176
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:17:25.566378
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import builtins

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(input_code.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == expected_code.get_source()

# Generated at 2022-06-18 00:17:27.442991
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:17:35.509640
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ..utils.tree import tree_to_str
    from ..utils.source import source_to_str
    from ..utils.snippet import snippet
    from ..utils.source import source_to_str
    from ..utils.tree import tree_to_str
    from ..utils.source import source_to_str
    from ..utils.tree import tree_to_str
    from ..utils.source import source_to_str
    from ..utils.tree import tree_to_str
    from ..utils.source import source_to_str
    from ..utils.tree import tree_to_str
    from ..utils.source import source_to_str
    from ..utils.tree import tree_to_str
    from ..utils.source import source_to_

# Generated at 2022-06-18 00:17:43.752471
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src
    from .base import BaseNodeTransformer
    from .six import SixTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases.append(ast.Name(id='B', ctx=ast.Load()))
            return node

    node = ast.parse('class A(metaclass=B): pass')
    node = MetaclassTransformer().visit(node)
    node = SixTransformer().visit(node)
    node = TestTransformer().visit(node)

# Generated at 2022-06-18 00:17:50.690471
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_builder import ast_from_str
    from ..utils.ast_visitor import ASTVisitor
    from ..utils.ast_visitor import visit_children
    from ..utils.ast_visitor import visit_children_if_changed
    from ..utils.ast_visitor import visit_children_if_changed_and_changed
    from ..utils.ast_visitor import visit_children_if_changed_and_changed_and_changed
    from ..utils.ast_visitor import visit_children_if_changed_and_changed_and_changed_and_changed
    from ..utils.ast_visitor import visit_children_if_changed_and_changed_and_changed_and_changed_and_changed
    from ..utils.ast_visitor import visit_children_if_changed_and_changed

# Generated at 2022-06-18 00:17:59.844993
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins
    from ..utils.compat import six
    from ..utils.compat import typing
    from ..utils.compat import abc
    from ..utils.compat import collections
    from ..utils.compat import functools
    from ..utils.compat import itertools
    from ..utils.compat import operator
    from ..utils.compat import reprlib
    from ..utils.compat import weakref
    from ..utils.compat import _thread
    from ..utils.compat import _dummy_thread
    from ..utils.compat import _markupbase
    from ..utils.compat import _threading_local
    from ..utils.compat import _weakrefset

# Generated at 2022-06-18 00:18:10.036653
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_equal

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
