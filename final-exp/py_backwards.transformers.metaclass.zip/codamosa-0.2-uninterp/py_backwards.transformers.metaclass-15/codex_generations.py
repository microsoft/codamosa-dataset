

# Generated at 2022-06-18 00:08:22.811820
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_source
    from ..utils.test_utils import round_trip

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    node = parse_source(source)
    node = MetaclassTransformer().visit(node)
    assert_equal_ast(node, parse_ast(expected))
    assert_equal_ast(node, round_trip(node))

# Generated at 2022-06-18 00:08:26.275037
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import ast_equal
    from ..utils.ast_helpers import parse
    from ..utils.ast_helpers import unparse


# Generated at 2022-06-18 00:08:33.809270
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_factory
    from ..utils.tree import print_tree
    from ..utils.source import source

    class_def = ast_factory(
        """
        class A(metaclass=B):
            pass
        """,
        mode='exec',
    )
    expected = ast_factory(
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """,
        mode='exec',
    )
    transformer = MetaclassTransformer()
    transformer.visit(class_def)
    assert source(class_def) == source(expected)

# Generated at 2022-06-18 00:08:44.490966
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as to_ast
    from ..utils.source import source_to_code as to_code
    from ..utils.source import source_to_ast_and_code as to_ast_and_code
    from ..utils.source import ast_to_source as to_source
    from ..utils.source import ast_to_code as to_c
    from ..utils.source import ast_to_source_and_code as to_s_and_c
    from ..utils.source import source_to_ast_and_code_and_tree as to_ast_and_code_and_tree
    from ..utils.source import ast_to_source_and_code_and_tree as to_s_and_c_and_t
    from ..utils.source import source_to_ast_and_

# Generated at 2022-06-18 00:08:53.804413
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name

    # Test with metaclass
    source = '''
        class A(metaclass=B):
            pass
    '''
    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    '''
    transform_and_compare(source, expected, MetaclassTransformer)

    # Test without metaclass
    source = '''
        class A(B):
            pass
    '''

# Generated at 2022-06-18 00:08:57.440067
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_equal
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:08:59.187960
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare


# Generated at 2022-06-18 00:09:07.239105
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_str

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

    expected = compile_snippet(source_to_str(six_import) + '\n' +
                               source_to_str(class_bases) + '\n' +
                               tree_to_str(class_def))


# Generated at 2022-06-18 00:09:08.877785
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:09:17.519184
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_snippet

    snippet = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = compile_snippet(snippet, 'exec')
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert tree_to_str(tree) == expected

# Generated at 2022-06-18 00:09:20.060282
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, compare_source


# Generated at 2022-06-18 00:09:28.678555
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compiler import compile_snippet
    from ..utils.visitor import dump

    snippet_ = snippet('''
        class A(metaclass=B):
            pass
    ''')

    module, = compile_snippet(source(*snippet_.get_source()), MetaclassTransformer)
    assert dump(module) == source(*six_import.get_source(),
                                  *class_bases.get_source(),
                                  *snippet_.get_source()).strip()

# Generated at 2022-06-18 00:09:29.974188
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, compare_source


# Generated at 2022-06-18 00:09:34.010901
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_equal_ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:09:40.383167
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:09:49.209738
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword
    from ..utils.source_factory import source

    class_def = ast_classdef(name='A',
                             bases=[ast_name(id='B')],
                             keywords=[ast_keyword(arg='metaclass',
                                                   value=ast_name(id='C'))])
    module = ast.Module(body=[class_def])


# Generated at 2022-06-18 00:10:19.354139
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-18 00:10:21.364778
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:10:28.524131
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_snippet

    snippet = """
    class A(metaclass=B):
        pass
    """
    tree = ast.parse(snippet)
    tree = MetaclassTransformer().visit(tree)
    assert tree_to_str(tree) == """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    assert compile_snippet(tree) == compile_snippet(snippet)

# Generated at 2022-06-18 00:10:31.912641
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.source import source_to_unicode


# Generated at 2022-06-18 00:10:42.984917
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compile import compile_snippet

    snippet = """
    class A(metaclass=B):
        pass
    """
    expected_snippet = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = ast.parse(snippet)
    tree = MetaclassTransformer().visit(tree)
    assert tree_to_str(tree) == expected_snippet
    compile_snippet(tree)

# Generated at 2022-06-18 00:10:52.265903
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_equal

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:11:01.557245
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.source_factory import source

    class_def = ast_class(name='A',
                          bases=[ast_name(id='B')],
                          keywords=[ast_keyword(arg='metaclass',
                                                value=ast_name(id='C'))])
    module = ast.Module(body=[class_def])
    transformer = MetaclassTransformer()
    transformer.visit(module)

# Generated at 2022-06-18 00:11:08.851370
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import parse

    class_def = parse('class A(metaclass=B): pass').body[0]
    assert isinstance(class_def, ast.ClassDef)
    assert len(class_def.keywords) == 1
    assert class_def.keywords[0].arg == 'metaclass'
    assert isinstance(class_def.keywords[0].value, ast.Name)
    assert class_def.keywords[0].value.id == 'B'

    class_def = MetaclassTransformer().visit(class_def)
    assert isinstance(class_def, ast.ClassDef)
    assert len(class_def.keywords) == 0

# Generated at 2022-06-18 00:11:19.151123
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:11:29.703686
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_snippet

    snippet = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = ast.parse(snippet)
    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)
    assert tree_to_str(tree) == expected
    assert compile_snippet(tree) == compile_snippet(expected)

# Generated at 2022-06-18 00:11:40.488096
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import python_version
    from ..utils.compat import python_version_tuple
    from ..utils.compat import python_version_str

    # Test for Python 2.7

# Generated at 2022-06-18 00:11:51.575337
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transformer = MetaclassTransformer()
    assert_equal_ast(transformer.visit(ast.parse(before.get_source())),
                     ast.parse(after.get_source()))

# Generated at 2022-06-18 00:12:01.905923
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_unicode

    snippet = """
    class A(metaclass=B):
        pass
    """
    tree = ast.parse(snippet)
    tree = MetaclassTransformer().visit(tree)
    assert print_tree(tree) == source_to_unicode("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    assert compile_snippet(tree)

# Generated at 2022-06-18 00:12:03.705579
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:12:17.774561
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet
    from ..utils.test_utils import assert_ast_equal

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transformer = MetaclassTransformer()
    transformer.visit(before.get_ast())
    assert_ast_equal(transformer.tree, after.get_ast())

# Generated at 2022-06-18 00:12:20.343278
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast, get_name, get_body
    from ..utils.test_utils import assert_equal_source


# Generated at 2022-06-18 00:12:26.294256
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_str

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

    module = ast.Module(body=[class_def])

    expected_module = ast.Module(body=[six_import.get_body(),
                                       class_def])


# Generated at 2022-06-18 00:12:28.253327
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:12:36.686601
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer
    from ..utils.snippet import snippet

    @snippet
    def code():
        class A(metaclass=B):
            pass

    node = ast.parse(code.get_source())
    SixTransformer().visit(node)
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == code.get_source(target=(2, 7))



# Generated at 2022-06-18 00:12:42.305271
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.test import transform

    class A(metaclass=type):
        pass

    expected = """\
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(type)):
        pass
    """

    assert transform(A, MetaclassTransformer) == expected

# Generated at 2022-06-18 00:12:45.832977
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compiler import compile_snippet

    snippet = source(MetaclassTransformer.visit_ClassDef)
    assert compile_snippet(snippet)

# Generated at 2022-06-18 00:12:54.885086
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ..utils.tree import parse_to_ast
    from ..utils.source import source_to_unicode
    from ..utils.snippet import snippet

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node

# Generated at 2022-06-18 00:13:02.251581
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    class A(metaclass=B):
        pass
    """

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    tree = parse_ast(source)
    MetaclassTransformer().visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:13:11.364320
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def code():
        class A(metaclass=B):
            pass

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    node = ast.parse(code.get_source())
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == expected

# Generated at 2022-06-18 00:13:34.094182
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
        class A(metaclass=B):
            pass
    """
    expected_source = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """

    expected_ast = parse_ast(expected_source)
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)
    assert_equal_ast(expected_ast, tree)
    assert_equal

# Generated at 2022-06-18 00:13:43.870097
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_factory import ast_factory
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_str
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_tree_str
    from ..utils.source import source_to_tree_str_with_imports
    from ..utils.source import source_to_tree_str_with_imports_and_backwards
    from ..utils.source import source_to_tree_str_with_imports_and_backwards_and_future

# Generated at 2022-06-18 00:13:45.498778
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:13:52.484016
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword
    from ..utils.source import source
    from ..utils.snippet import snippet
    from ..utils.tree import to_source
    from .base import BaseNodeTransformer
    from .metaclass import MetaclassTransformer

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)


# Generated at 2022-06-18 00:13:56.041170
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import parse_ast

    code = '''
        class A(metaclass=B):
            pass
    '''
    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    '''
    tree = parse_ast(code)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected)
    assert_tree_changed(transformer)

# Generated at 2022-06-18 00:14:06.632203
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import parse_to_classdef
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_module
    from ..utils.test_utils import parse_to_stmt

    # Test 1
    # Test that the transformer adds the correct import statement
    # and that it adds the correct call to _py_backwards_six_withmetaclass
    # Test that the transformer removes the metaclass keyword argument
    # Test that the transformer does not change the class name
    # Test that the transformer does not change the class body

# Generated at 2022-06-18 00:14:13.147954
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer
    from .with_statement import WithStatementTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='C', ctx=ast.Load())]
            return node


# Generated at 2022-06-18 00:14:23.143042
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def code():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(code.get_body())
    expected_node = ast.parse(expected.get_body())
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)
    assert ast_to_str(new_node) == ast_to_str(expected_node)

# Generated at 2022-06-18 00:14:30.834662
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, assert_equal_ast
    from ..utils.test_utils import assert_equal_code

    code = """
        class A(metaclass=B):
            pass
    """
    expected_code = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    assert_equal_ast(transform(MetaclassTransformer, code), expected_code)
    assert_equal_code(transform(MetaclassTransformer, code), expected_code)

# Generated at 2022-06-18 00:14:37.953931
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:15:12.970663
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str_with_imports
    from ..utils.tree import get_ast_from_source
    from ..utils.tree import get_source_from_ast
    from ..utils.tree import get_source_from_ast_with_imports
    from ..utils.tree import get_source_from_source
    from ..utils.tree import get_source_from_source_with_imports
    from ..utils.tree import get_source_from_source_with_imports_and_transformer
    from ..utils.tree import get_source_from_source_with_transformer
    from ..utils.tree import get_source_from_tree
    from ..utils.tree import get_source_from

# Generated at 2022-06-18 00:15:24.982697
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_with_metaclass import SixWithMetaclassTransformer
    from .six_with_metaclass_import import SixWithMetaclassImportTransformer
    from .six_with_metaclass_import_from import SixWithMetaclassImportFromTransformer
    from .six_with_metaclass_import_from_as import SixWithMetaclassImportFromAsTransformer
    from .six_with_metaclass_import_from_as_import import SixWithMetaclassImportFromAsImportTransformer
    from .six_with_metaclass_import_from_as_import_from import SixWithMetaclassImportFrom

# Generated at 2022-06-18 00:15:26.769438
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:15:34.521901
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compiler import compile_snippet

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    tree = compile_snippet(source, MetaclassTransformer)
    assert source(tree) == source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

# Generated at 2022-06-18 00:15:40.501350
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.unparse import Unparser

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert Unparser(tree).unparse() == source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

# Generated at 2022-06-18 00:15:47.678709
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import python_version
    from ..utils.compat import get_ast_type
    from ..utils.compat import get_ast_arguments
    from ..utils.compat import get_ast_keywords
    from ..utils.compat import get_ast_keyword
    from ..utils.compat import get_ast_keyword_arg
    from ..utils.compat import get_ast_keyword_value
    from ..utils.compat import get_ast_arguments_args
    from ..utils.compat import get_ast_arguments_kwonlyargs
    from ..utils.compat import get_ast_arguments_kw_defaults

# Generated at 2022-06-18 00:15:57.523094
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_module
    from ..utils.test_utils import parse_to_node
    from ..utils.test_utils import parse_to_object
    from ..utils.test_utils import parse_to_source
    from ..utils.test_utils import parse_to_type
    from ..utils.test_utils import parse_to_visit
    from ..utils.test_utils import parse_visit_and_dump
    from ..utils.test_utils import parse_visit_and_pickle
    from ..utils.test_utils import parse_visit_and_source
    from ..utils.test_utils import parse_visit_and_type

# Generated at 2022-06-18 00:16:01.502965
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compat import builtins
    from ..utils.unparse import Unparser

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert Unparser(tree).unparse() == '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    '''

# Generated at 2022-06-18 00:16:12.902431
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str

# Generated at 2022-06-18 00:16:22.060945
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_and_reparse

    snippet_ast = parse_snippet(six_import)
    snippet_ast.body.extend(parse_snippet(class_bases))

    class_ast = parse_ast("""
    class A(metaclass=B):
        pass
    """)

    expected_ast = parse_ast("""
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

    assert_equal_ast(transform_and_reparse(class_ast, MetaclassTransformer),
                     expected_ast)

# Generated at 2022-06-18 00:17:41.217356
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast

    code = '''
    class A(metaclass=B):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    tree = parse_to_ast(code)
    MetaclassTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:17:48.913222
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = compile_snippet(before.get_source(), 'before.py', 'exec')
    node = MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()

# Generated at 2022-06-18 00:17:59.157374
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword
    from ..utils.source import source
    from ..utils.compile import compile_source
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .metaclass import MetaclassTransformer

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)


# Generated at 2022-06-18 00:18:01.601652
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, compare
    from ..utils.test_utils import parse_ast

    # Test 1

# Generated at 2022-06-18 00:18:09.719717
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transformer = MetaclassTransformer()
    assert_equal_ast(transformer.visit(ast.parse(before.get_source())),
                     ast.parse(after.get_source()))

# Generated at 2022-06-18 00:18:17.414632
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins_name

    node = ast.ClassDef(name='A',
                        bases=[ast.Name(id=builtins_name('object'), ctx=ast.Load())],
                        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                        body=[],
                        decorator_list=[])