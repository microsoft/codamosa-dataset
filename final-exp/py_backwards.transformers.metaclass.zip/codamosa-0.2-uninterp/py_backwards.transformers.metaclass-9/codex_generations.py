

# Generated at 2022-06-18 00:08:18.475241
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_unchanged
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_source

    # Test case 1

# Generated at 2022-06-18 00:08:24.834735
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_withmetaclass import SixWithMetaclassTransformer

    class TestMetaclassTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node

    class TestSixImportTransformer(SixImportTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node


# Generated at 2022-06-18 00:08:33.481134
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import parse
    from ..utils.ast_helpers import compare_ast
    from ..utils.ast_helpers import get_ast_node_at_line
    from ..utils.ast_helpers import get_ast_node_name_at_line
    from ..utils.ast_helpers import get_ast_node_type_at_line
    from ..utils.ast_helpers import get_ast_node_lineno_at_line
    from ..utils.ast_helpers import get_ast_node_col_offset_at_line
    from ..utils.ast_helpers import get_ast_node_end_lineno_at_line
    from ..utils.ast_helpers import get_ast_node_end_col_offset_at_line

# Generated at 2022-06-18 00:08:41.220510
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef

    classdef = parse_to_classdef("""
        class A(metaclass=B):
            pass
    """)

    expected = parse_to_classdef("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    assert_equal_ast(MetaclassTransformer().visit(classdef), expected)



# Generated at 2022-06-18 00:08:52.374351
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_equal

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:09:03.726695
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_str
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_function
    from ..utils.source import source_to_class
    from ..utils.source import source_to_object
    from ..utils.source import source_to_function_object
    from ..utils.source import source_to_class_object
    from ..utils.source import source_to_object_object
    from ..utils.source import source_to_function_object_object
    from ..utils.source import source

# Generated at 2022-06-18 00:09:10.906209
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import get_metaclass

    @snippet
    def code():
        class A(metaclass=B):
            pass

    tree = ast.parse(code.get_body())
    MetaclassTransformer().visit(tree)

# Generated at 2022-06-18 00:09:12.694516
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:09:16.005550
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:09:18.867031
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compiler import compile_snippet

    snippet = source(MetaclassTransformer.visit_ClassDef)
    assert compile_snippet(snippet)

# Generated at 2022-06-18 00:09:30.751412
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    assert_equal_ast(MetaclassTransformer().visit(ast.parse(before.get_source())),
                     ast.parse(after.get_source()))

# Generated at 2022-06-18 00:09:32.350790
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:09:42.875839
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import builtins

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = input_code.get_ast()
    node = MetaclassTransformer().visit(node)
    expected_node = expected_code.get_ast()
    assert ast_to_str(node) == ast_to_str(expected_node)

# Generated at 2022-06-18 00:09:49.514522
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)
    assert_equal_source(tree, expected)

# Generated at 2022-06-18 00:09:54.572188
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast
    from ..utils.unparse import Unparser

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    expected_source = source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    Unparser(tree)
    result_source = source(Unparser(tree))

    assert compare_ast(result_source, expected_source)

# Generated at 2022-06-18 00:10:02.432331
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PY2
    from ..utils.compat import PY3

    @snippet
    def code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_py2():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    @snippet
    def expected_py3():
        class A(metaclass=B):
            pass

    node = ast.parse(code.get_source())
    transformer = MetaclassTransformer()

# Generated at 2022-06-18 00:10:11.367672
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compiler import compile_snippet
    from ..utils.visitor import dump
    from ..utils.ast import get_ast

    snippet = source(MetaclassTransformer.visit_ClassDef)
    ast = get_ast(snippet)
    node = ast.body[0]
    assert isinstance(node, ast.ClassDef)
    assert node.keywords
    assert node.keywords[0].arg == 'metaclass'

    compiled = compile_snippet(snippet, MetaclassTransformer)
    ast = get_ast(compiled)
    node = ast.body[0]
    assert isinstance(node, ast.ClassDef)
    assert not node.keywords
    assert isinstance(node.bases[0], ast.Call)

# Generated at 2022-06-18 00:10:21.408849
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import get_test_data
    from ..utils.test_utils import get_test_data_path
    from ..utils.test_utils import get_test_data_path
    from ..utils.test_utils import get_test_data_path
    from ..utils.test_utils import get_test_data_path
    from ..utils.test_utils import get_test_data_path
    from ..utils.test_utils import get_test_data_path
    from ..utils.test_utils import get_test_data_path
    from ..utils.test_utils import get_test_data_path
    from ..utils.test_utils import get_test_data_path
    from ..utils.test_utils import get_test_data_

# Generated at 2022-06-18 00:10:29.191544
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='C', ctx=ast.Load())]
            return node

    source = """
        class A(metaclass=B):
            pass
    """
    tree = ast.parse(source)
    tree = SixTransformer().visit(tree)
    tree = MetaclassTransformer

# Generated at 2022-06-18 00:10:38.091034
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins
    from ..utils.snippet import snippet
    from ..utils.source import source_to_ast
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.context import Context
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins

    @snippet
    def source():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass

# Generated at 2022-06-18 00:10:51.771125
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_source
    from ..utils.snippet import snippet
    from ..utils.compat import python_version
    from ..utils.compat import PY2

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    if python_version < (3, 6):
        expected = after
    else:
        expected = before

    tree = ast.parse(before)
    MetaclassTransformer().visit(tree)
    assert to_source(tree) == expected



# Generated at 2022-06-18 00:11:00.965259
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins

    node = ast.ClassDef(name='A',
                        bases=[ast.Name(id='B', ctx=ast.Load())],
                        keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='C', ctx=ast.Load()))],
                        body=[],
                        decorator_list=[])


# Generated at 2022-06-18 00:11:04.336647
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compiler import compile_snippet
    from ..utils.visitor import dump

    snippet = source(MetaclassTransformer, 'visit_ClassDef')
    module, _ = compile_snippet(snippet)
    assert dump(module) == snippet

# Generated at 2022-06-18 00:11:13.028343
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast, compare_asts
    from ..utils.test_utils import get_test_data

    source = get_test_data('metaclass_transformer_visit_ClassDef_source.py')
    expected = get_test_data('metaclass_transformer_visit_ClassDef_expected.py')

    source_ast = get_ast(source)
    expected_ast = get_ast(expected)

    transformer = MetaclassTransformer()
    transformer.visit(source_ast)

    assert compare_asts(expected_ast, source_ast)

# Generated at 2022-06-18 00:11:17.484719
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.compat import StringIO
    from ..utils.compat import unicode
    from ..utils.compat import bytes
    from ..utils.compat import long
    from ..utils.compat import int
    from ..utils.compat import basestring
    from ..utils.compat import unicode
    from ..utils.compat import bytes
    from ..utils.compat import long
    from ..utils.compat import int
    from ..utils.compat import basestring
    from ..utils.compat import unicode
    from ..utils.compat import bytes
    from ..utils.compat import long
    from ..utils.compat import int
    from ..utils.compat import basestring

# Generated at 2022-06-18 00:11:21.066329
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import parse_ast
    from ..utils.tree import compare_ast


# Generated at 2022-06-18 00:11:24.524016
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:11:32.782394
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PY2

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = before.get_ast()
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_ast_str()

# Generated at 2022-06-18 00:11:41.975937
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import python_version

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()

# Generated at 2022-06-18 00:11:53.195230
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import PY2
    from ..utils.compat import PY3
    from ..utils.compat import PY35
    from ..utils.compat import PY36
    from ..utils.compat import PY37
    from ..utils.compat import PY38

    class A(object):
        pass

    class B(object):
        pass

    class C(object):
        pass

    class D(object):
        pass

    class E(object):
        pass

    class F(object):
        pass

    class G(object):
        pass

    class H(object):
        pass

    class I(object):
        pass

    class J(object):
        pass


# Generated at 2022-06-18 00:12:06.129346
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare

    code = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    transform_and_compare(MetaclassTransformer, code, expected)

# Generated at 2022-06-18 00:12:16.668522
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = before.get_ast()
    Metac

# Generated at 2022-06-18 00:12:24.478022
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_to_ast(source)
    funcdef = parse_to_funcdef(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected)
    assert transformer.tree_changed()
    assert transformer.dependencies_changed(set())

# Generated at 2022-06-18 00:12:27.364194
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:12:34.663952
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer
    from .utils import transform_code
    from .utils import transform_ast

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.name = 'Test'
            return node


# Generated at 2022-06-18 00:12:45.087512
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    node = MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()

# Generated at 2022-06-18 00:12:54.272397
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import get_ast_arguments

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = input_code.get_ast()
    expected = expected_code.get_ast()

    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)

    assert ast_to_str(new_node) == ast_to

# Generated at 2022-06-18 00:13:05.086785
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.tree import to_source

    class_def = ast_factory(
        'ClassDef',
        name='A',
        bases=[ast.Name(id='object', ctx=ast.Load())],
        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
        body=[],
        decorator_list=[],
    )

    expected = source('''
        class A(_py_backwards_six_withmetaclass(B, object)):
            pass
    ''')

    transformer = MetaclassTransformer()
    transformer.visit(class_def)
   

# Generated at 2022-06-18 00:13:10.782594
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.snippet import snippet
    from ..utils.tree import print_tree

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    tree = get_ast(before.get_source())
    MetaclassTransformer().visit(tree)
    assert astor.to_source(tree) == after.get_source()

# Generated at 2022-06-18 00:13:16.902971
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_and_compile
    from ..utils.test_utils import transform_and_compile_snippet

    # Test 1
    code = """
        class A(metaclass=B):
            pass
    """
    expected_code = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_ast(code)
    transformer = MetaclassTransformer()
    transformer.visit(tree)

# Generated at 2022-06-18 00:13:43.297465
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword, ast_num
    from ..utils.source import source

    class_def = ast_class(name='A',
                          bases=[ast_name(id='B')],
                          keywords=[ast_keyword(arg='metaclass', value=ast_name(id='C'))],
                          body=[ast_call(func=ast_name(id='print'),
                                         args=[ast_num(n=1)])])
    module = ast.Module(body=[class_def])

# Generated at 2022-06-18 00:13:50.995697
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import compare_ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:14:00.399476
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as to_ast
    from ..utils.source import source_to_code as to_code
    from ..utils.source import source_to_ast_and_code as to_ast_and_code
    from ..utils.source import ast_to_source as to_source
    from ..utils.source import ast_to_code as to_c
    from ..utils.source import ast_to_source_and_code as to_s_and_c
    from ..utils.source import source_to_source_and_code as to_s_and_c_from_s
    from ..utils.source import source_to_ast_and_source as to_a_and_s
    from ..utils.source import source_to_ast_and_source_and_code as to_a_and_

# Generated at 2022-06-18 00:14:10.475467
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword
    from ..utils.compile_snippet import compile_snippet

    transformer = MetaclassTransformer()
    node = ast_classdef(name='A',
                        bases=[ast_name(id='B')],
                        keywords=[ast_keyword(arg='metaclass', value=ast_name(id='C'))])
    expected = ast_classdef(name='A',
                            bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                            args=[ast_name(id='C'), ast_name(id='B')],
                                            keywords=[])])

# Generated at 2022-06-18 00:14:21.351232
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import ast_to_source as ats
    from ..utils.source import ast_to_code as atc
    from ..utils.source import ast_to_source_and_code as atsac
    from ..utils.source import source_to_source as sts
    from ..utils.source import source_to_source_and_code as stsac
    from ..utils.source import source_to_ast_and_source as staas
    from ..utils.source import source_to_ast_and_source_and_code as staasc

# Generated at 2022-06-18 00:14:30.941619
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import builtins

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id=builtins, ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    module = ast.Module(body=[class_def])
    transformer = MetaclassTransformer()
    module = transformer.visit(module)
    assert transformer._tree_changed is True

# Generated at 2022-06-18 00:14:32.625421
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:14:40.368222
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    transform_and_compare(MetaclassTransformer,
                          """
                          class A(metaclass=B):
                              pass
                          """,
                          """
                          from six import with_metaclass as _py_backwards_six_withmetaclass
                          class A(_py_backwards_six_withmetaclass(B)):
                              pass
                          """)

# Generated at 2022-06-18 00:14:45.935833
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import parse_snippet_as_module

    class_def = parse_snippet('class A(metaclass=B): pass')
    expected = parse_snippet_as_module('class A(_py_backwards_six_withmetaclass(B)): pass')

    assert_equal_ast(expected, MetaclassTransformer().visit(class_def))

# Generated at 2022-06-18 00:14:56.441933
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef
    from ..utils.test_utils import parse_to_module
    from ..utils.test_utils import parse_to_stmt

    # Test 1
    # Input:
    # class A(metaclass=B):
    #     pass
    # Expected output:
    # class A(_py_backwards_six_with_metaclass(B))
    #     pass
    input_ast = parse_to_classdef("class A(metaclass=B): pass")

# Generated at 2022-06-18 00:15:35.465509
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast, get_name, get_node_of_class


# Generated at 2022-06-18 00:15:43.951402
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import exec_

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()

    exec_(before.get_source(), globals())
    exec_(after.get_source(), globals())


# Generated at 2022-06-18 00:15:47.378108
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:15:57.322023
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    module = ast.Module(body=[class_def])
    expected = ast.Module(body=[six_import.get_body(),
                                class_def])

# Generated at 2022-06-18 00:16:00.574573
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ast import parse
    from ..utils.ast_helpers import dump_ast
    from ..utils.ast_helpers import get_ast_node
    from ..utils.ast_helpers import get_ast_nodes


# Generated at 2022-06-18 00:16:06.840937
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id='C', ctx=ast.Load())]
            return node


# Generated at 2022-06-18 00:16:16.882682
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast

    class_def = ast_class(name='A',
                          bases=[],
                          keywords=[ast_keyword(arg='metaclass',
                                                value=ast_name(id='B'))])

    expected_class_def = ast_class(name='A',
                                   bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                                   args=[ast_name(id='B'),
                                                         ast_name(id='object')],
                                                   keywords=[])])


# Generated at 2022-06-18 00:16:23.264647
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.compat import StringIO
    from ..utils.source import source
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet
    from ..utils.test_utils import assert_tree_equal

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    tree = compile_snippet(before)
    expected_tree = compile_snippet(after)
    MetaclassTransformer().visit

# Generated at 2022-06-18 00:16:30.298313
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

# Generated at 2022-06-18 00:16:40.192068
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer
    from .base import BaseNodeTransformer