

# Generated at 2022-06-18 00:08:23.711761
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_ast

    code = """
        class A(metaclass=B):
            pass
    """
    expected_code = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    expected_ast = parse_ast(expected_code)
    ast_ = parse_ast(code)
    transformer = MetaclassTransformer()
    transformer.visit(ast_)
    assert_equal_ast(ast_, expected_ast)
    assert_equal_code(code, expected_code)

# Generated at 2022-06-18 00:08:32.933709
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as to_ast
    from ..utils.source import source_to_code as to_code
    from ..utils.source import source_to_ast_and_code as to_ast_and_code
    from ..utils.source import ast_to_source as to_source

    # Test 1
    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = to_ast(source)
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)
    assert to_source(new_tree) == expected

    # Test 2

# Generated at 2022-06-18 00:08:39.648552
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compile
    from ..utils.test_utils import assert_equal_source

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = transform_and_compile(source, MetaclassTransformer)
    assert_equal_source(tree, expected)

# Generated at 2022-06-18 00:08:47.079720
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_transformed_code_equals
    assert_transformed_code_equals(
        """
        class A(metaclass=B):
            pass
        """,
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """,
        MetaclassTransformer
    )

# Generated at 2022-06-18 00:08:54.524296
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()

# Generated at 2022-06-18 00:08:57.166943
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:08:58.742198
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor


# Generated at 2022-06-18 00:09:02.857345
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    module = ast.Module(body=[class_def])
    print_tree(module)

    transformer = MetaclassTransformer()
    module = transformer.visit(module)
    print_tree(module)

    assert transformer._tree_changed
    assert len(module.body) == 2
    assert isinstance(module.body[0], ast.ImportFrom)


# Generated at 2022-06-18 00:09:10.705428
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test import transform_and_compare

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transform_and_compare(MetaclassTransformer, before, after)

# Generated at 2022-06-18 00:09:18.954212
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    node = parse_ast("""
    class A(metaclass=B):
        pass
    """)
    expected = parse_ast("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert_equal_ast(node, expected)

# Generated at 2022-06-18 00:09:29.799253
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, compare_ast
    from ..utils.test_utils import parse

    code = '''
    class A(metaclass=B):
        pass
    '''

    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''

    tree = parse(code)
    new_tree = transform(tree, MetaclassTransformer)
    compare_ast(new_tree, expected)

# Generated at 2022-06-18 00:09:32.900252
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    expected = source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert compare_ast(tree, expected)

# Generated at 2022-06-18 00:09:35.439967
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:09:37.904580
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import compare_source


# Generated at 2022-06-18 00:09:47.238817
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.compile_source import compile_source
    from ..utils.source import source

    class_def = ast_class(name='A',
                          bases=[ast_name(id='object')],
                          keywords=[ast_keyword(arg='metaclass',
                                                value=ast_name(id='B'))])

# Generated at 2022-06-18 00:10:17.383597
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-18 00:10:19.950182
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:10:21.856788
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:10:24.313198
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast_node


# Generated at 2022-06-18 00:10:35.053988
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword
    from ..utils.source import source

    classdef = ast_classdef(name='A',
                            bases=[],
                            keywords=[ast_keyword(arg='metaclass',
                                                  value=ast_name(id='B'))])

    expected = ast_classdef(name='A',
                            bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                            args=[ast_name(id='B'),
                                                  ast.List(elts=[])])])

    transformer = MetaclassTransformer()
    result = transformer.visit(classdef)
    assert source(result)

# Generated at 2022-06-18 00:10:41.587022
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.tree import ast_parse


# Generated at 2022-06-18 00:10:46.937514
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compiler import compile_snippet
    from ..utils.visitor import dump

    snippet = source(MetaclassTransformer.visit_ClassDef)
    tree = compile_snippet(snippet)
    print(dump(tree))

# Generated at 2022-06-18 00:10:52.424702
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equals_source
    from ..utils.test_utils import parse_ast

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equals_source(expected, tree)

# Generated at 2022-06-18 00:11:01.393020
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import get_test_data_path
    from ..utils.test_utils import get_test_data_content
    from ..utils.test_utils import get_test_data_content_as_ast

    path = get_test_data_path('metaclass_transformer_visit_ClassDef.py')
    expected_path = get_test_data_path('metaclass_transformer_visit_ClassDef_expected.py')
    expected = get_test_data_content(expected_path)
    expected_ast = get_test_data_content_as_ast(expected_path)

    transform_and_compare(path, expected, expected_ast, MetaclassTransformer)

# Generated at 2022-06-18 00:11:08.736749
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import python_version
    from ..utils.compat import get_ast_node_name
    from ..utils.compat import get_ast_node_fields
    from ..utils.compat import get_ast_node_field_names
    from ..utils.compat import get_ast_node_field_value
    from ..utils.compat import set_ast_node_field_value
    from ..utils.compat import get_ast_node_field_type
    from ..utils.compat import get_ast_node_field_types
    from ..utils.compat import get_ast_node_field_type_name
    from ..utils.compat import get_

# Generated at 2022-06-18 00:11:11.417500
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:11:16.687274
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword, ast_list
    from ..utils.compile_source import compile_source
    from ..utils.source import source

    class_def = ast_class(name='A',
                          bases=ast_list(elts=[ast_name(id='object')]),
                          keywords=[ast_keyword(arg='metaclass',
                                                value=ast_name(id='B'))])


# Generated at 2022-06-18 00:11:28.122320
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()
    assert compile_snippet(node) == compile_snippet(after.get_ast())

# Generated at 2022-06-18 00:11:35.037412
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet

    snippet_ast = parse_snippet(six_import)
    snippet_ast.body.extend(parse_snippet(class_bases).body)

    node = parse_ast('''
        class A(metaclass=B):
            pass
    ''')
    expected = parse_ast('''
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')
    expected.body[0].bases[0].elts.extend(snippet_ast.body)

    transformer = MetaclassTransformer()
    result = transformer.visit(node)
   

# Generated at 2022-06-18 00:11:41.421688
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    transform_and_compare(MetaclassTransformer,
                          """
                          class A(metaclass=B):
                              pass
                          """,
                          """
                          from six import with_metaclass as _py_backwards_six_withmetaclass
                          class A(_py_backwards_six_withmetaclass(B)):
                              pass
                          """)

# Generated at 2022-06-18 00:11:56.289046
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:12:05.454022
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PYTHON_VERSION

    # When
    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    module = ast.Module(body=[class_def])
    transformer = MetaclassTransformer(PYTHON_VERSION)
    transformer.visit(module)
    result = tree_to_str(module)

# Generated at 2022-06-18 00:12:09.708022
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.tree import tree_to_str


# Generated at 2022-06-18 00:12:10.985690
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_code


# Generated at 2022-06-18 00:12:19.287291
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_ast

    snippet = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = source_to_ast(snippet)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert print_tree(tree) == expected

    # Test

# Generated at 2022-06-18 00:12:21.709776
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:12:28.362041
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import transform_and_compare_with_expected
    from ..utils.test_utils import transform_and_compare_with_expected_text
    from ..utils.test_utils import transform_and_compare_with_expected_text_and_back
    from ..utils.test_utils import transform_and_compare_with_expected_text_and_back_with_dependencies
    from ..utils.test_utils import transform_and_compare_with_expected_text_and_back_with_dependencies_and_target
    from ..utils.test_utils import transform_and_compare_with_expected_text_and_back_with_dependencies_and_target_and_debug
    from ..utils.test_utils import transform

# Generated at 2022-06-18 00:12:31.004317
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:12:37.911320
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import parse

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = parse(before.get_ast())
    MetaclassTransformer().visit(node)
    assert before.get_source() == after.get_source()

# Generated at 2022-06-18 00:12:48.121044
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PY2

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    if PY2:
        expected_code = expected_code.get_body()
        expected_code = ast.fix_missing_locations(expected_code)
        expected_code = ast_to_str(expected_code)
        expected_code = expected_code.strip

# Generated at 2022-06-18 00:13:11.035109
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.ast_factory import ast_factory

    class_def = ast_factory('''
        class A(metaclass=B):
            pass
    ''')

    expected_class_def = ast_factory('''
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    transformer = MetaclassTransformer()
    transformer.visit(class_def)
    assert tree_to_str(class_def) == tree_to_str(expected_class_def)

# Generated at 2022-06-18 00:13:17.100412
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import get_metaclass

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(input_code.get_source())
    node = MetaclassTransformer().visit(node)
    assert ast_to_str(node) == expected_code.get_source()

# Generated at 2022-06-18 00:13:22.133138
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import ast_to_source as ats

    # Test 1

# Generated at 2022-06-18 00:13:31.491697
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name
    from ..utils.compile_source import compile_source

    # Test case 1
    node = ast_class(name='A', bases=[], keywords=[], body=[])
    node = MetaclassTransformer().visit(node)
    assert compile_source(node) == 'class A:\n    pass\n'

    # Test case 2
    node = ast_class(name='A', bases=[], keywords=[ast_call(func=ast_name(id='metaclass'), args=[ast_name(id='B')])], body=[])
    node = MetaclassTransformer().visit(node)

# Generated at 2022-06-18 00:13:37.866064
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform
    from ..utils.test_utils import compare_source

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = transform(MetaclassTransformer, source)
    compare_source(tree, expected)

# Generated at 2022-06-18 00:13:46.217424
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import get_metaclass

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(input_code.get_source())
    node = MetaclassTransformer().visit(node)
    assert ast_to_str(node) == expected_code.get_source()

# Generated at 2022-06-18 00:13:47.958116
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, compare_source


# Generated at 2022-06-18 00:13:56.845869
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import source_to_tree_and_code as sttac
    from ..utils.source import source_to_tree as stt
    from ..utils.source import source_to_code_and_tree as stcat
    from ..utils.source import source_to_code_and_ast as stca
    from ..utils.source import source_to_tree_and_ast as stta
    from ..utils.source import source_to_ast_and_tree as staat
    from ..utils.source import source_to_code_and_ast_and_tree as stcat

# Generated at 2022-06-18 00:13:58.842067
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:14:09.352649
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import builtins

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id=builtins, ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    module = ast.Module(body=[class_def])
    module = MetaclassTransformer(module).visit(module)

# Generated at 2022-06-18 00:14:47.336139
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_and_compare

    class_def = parse_snippet('class A(metaclass=B): pass')
    expected = parse_snippet('class A(_py_backwards_six_withmetaclass(B)): pass')
    assert_equal_ast(expected, transform_and_compare(class_def, MetaclassTransformer))



# Generated at 2022-06-18 00:14:57.265767
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.compat import exec_
    from ..utils.snippet import snippet
    from ..utils.test import run_local_tests

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    class B:
        pass

    node = ast.parse(before.get_source())
    node = MetaclassTransformer().visit(node)
    assert print_tree(node) == after.get_source()

# Generated at 2022-06-18 00:15:08.382024
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_factory
    from ..utils.tree import to_source
    from ..utils.snippet import snippet
    from ..utils.compat import PYTHON_VERSION
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        target = (2, 7)
        dependencies = ['six']

        def visit_Module(self, node: ast.Module) -> ast.Module:
            insert_at(0, node, six_import.get_body())
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-18 00:15:13.000548
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, compare_source

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    compare_source(transform(MetaclassTransformer, source), expected)

# Generated at 2022-06-18 00:15:25.023696
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    class A(ast.NodeTransformer):
        def visit_ClassDef(self, node):
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node

    class B(ast.NodeTransformer):
        def visit_ClassDef(self, node):
            node.bases = [ast.Name(id='C', ctx=ast.Load())]
            return node

    class C(ast.NodeTransformer):
        def visit_ClassDef(self, node):
            node.bases = [ast.Name(id='D', ctx=ast.Load())]
            return node


# Generated at 2022-06-18 00:15:26.500100
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:15:27.958200
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:15:35.387443
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import builtins

    class A(metaclass=builtins.type):
        pass

    node = ast.parse(ast_to_str(A))
    node = MetaclassTransformer().visit(node)

# Generated at 2022-06-18 00:15:43.874510
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import builtins

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    module_node = ast.parse(input_code.get_source())
    transformer = MetaclassTransformer()
    new_module = transformer.visit(module_node)
    assert transformer.tree_changed is True
    assert tree_to_str(new_module) == tree

# Generated at 2022-06-18 00:15:55.279342
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_ast

    snippet_ast = parse_snippet(six_import)
    snippet_ast.body.extend(parse_snippet(class_bases))

    class_def_ast = parse_ast('''
        class A(metaclass=B):
            pass
    ''')

    expected_ast = parse_ast('''
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')


# Generated at 2022-06-18 00:17:19.909074
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast, get_source
    from ..utils.test_helpers import assert_source


# Generated at 2022-06-18 00:17:25.035019
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

# Generated at 2022-06-18 00:17:32.646510
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import parse_module

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    module = parse_module(before.get_ast())
    transformer = MetaclassTransformer()
    transformer.visit(module)
    assert transformer._tree_changed
    assert module == parse_module(after.get_ast())

# Generated at 2022-06-18 00:17:37.038688
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:17:38.395546
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:17:47.791932
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet

    snippet = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    node = parse_snippet(snippet)
    expected = parse_ast(expected)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert_equal_ast(node, expected)

# Generated at 2022-06-18 00:17:49.210908
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:17:59.497119
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_str
    from ..utils.source import source_to_ast_str

    @snippet
    def input_snippet():
        class A(metaclass=B):
            pass

    @snippet
    def expected_snippet():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass


# Generated at 2022-06-18 00:18:09.600637
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.snippet import snippet
    from ..utils.tree import tree_to_str

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B, C)):
            pass


# Generated at 2022-06-18 00:18:12.584019
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast, get_name_node, get_class_node
    from ..utils.source_helpers import get_source
