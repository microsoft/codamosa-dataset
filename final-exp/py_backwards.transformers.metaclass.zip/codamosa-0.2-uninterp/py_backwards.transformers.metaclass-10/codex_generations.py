

# Generated at 2022-06-18 00:08:22.025942
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.compile import compile_snippet
    from ..utils.context import Context
    from ..utils.source import Source
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_code_equal

    source = Source("""
    class A(metaclass=B):
        pass
    """)
    context = Context(source)
    node = compile_snippet(source.code, filename=source.path)
    transformer = MetaclassTransformer(context)
    new_node = transformer.visit(node)

# Generated at 2022-06-18 00:08:23.877541
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:08:26.703899
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, assert_equal_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:08:34.078611
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='object', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

    module = ast.Module(body=[class_def])
    module = MetaclassTransformer().visit(module)


# Generated at 2022-06-18 00:08:40.402908
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import generate_test_ast

    class_def = generate_test_ast('''
        class A(metaclass=B):
            pass
    ''')

    expected_class_def = generate_test_ast('''
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    assert_equal_ast(MetaclassTransformer().visit(class_def), expected_class_def)

# Generated at 2022-06-18 00:08:51.586700
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import parse_tree
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    tree = parse_tree(before.get_ast())
    tree = SixTransformer().visit(tree)
    tree = MetaclassTransformer().visit(tree)
    assert before.get_source() == after

# Generated at 2022-06-18 00:09:03.461603
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import get_metaclass

    class A(get_metaclass(ast.ClassDef)):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            if node.keywords:
                metaclass = node.keywords[0].value
                node.bases = class_bases.get_body(metaclass=metaclass,  # type: ignore
                                                  bases=ast.List(elts=node.bases))
                node.keywords = []
                self._tree_changed = True

            return self.generic_visit(node)  # type: ignore

    class B(A):
        pass


# Generated at 2022-06-18 00:09:12.731978
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_factory import ast_factory
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_equal_ast

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transformer = MetaclassTransformer()
    transformer.visit(before.get_ast())
    assert_equal_ast(transformer.tree, after.get_ast())

# Generated at 2022-06-18 00:09:22.825896
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword

    class_def = ast_classdef(
        name='A',
        bases=[ast_name('object')],
        keywords=[ast_keyword(
            arg='metaclass',
            value=ast_name('B')
        )],
        body=[],
        decorator_list=[]
    )


# Generated at 2022-06-18 00:09:33.945385
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_module as stm
    from ..utils.source import source_remove_comments as src
    from ..utils.source import source_strip_all as ssa
    from ..utils.source import source_to_tokens as stt
    from ..utils.source import source_to_tokens_remove_comments as sttrc
    from ..utils.source import source_to_tokens_strip_all as sttsa
    from ..utils.source import source_to_tokens_strip_all_remove_comments as sttsarc
    from ..utils.source import source_to_tokens_strip_all_remove_comments_untokenize as sttsarcu
    from ..utils.source import source_to_tok

# Generated at 2022-06-18 00:09:39.997391
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call
    from ..utils.ast_factory import ast_class
    from ..utils.ast_factory import ast_name
    from ..utils.ast_factory import ast_module
    from ..utils.ast_factory import ast_str
    from ..utils.ast_factory import ast_keyword
    from ..utils.ast_factory import ast_list
    from ..utils.ast_factory import ast_num
    from ..utils.ast_factory import ast_tuple
    from ..utils.ast_factory import ast_attr


# Generated at 2022-06-18 00:09:45.628400
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(code)
    tree = MetaclassTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:09:52.490387
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

# Generated at 2022-06-18 00:10:00.871554
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast
    from ..utils.unparse import Unparser

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    expected_source = source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    actual_source = Unparser(tree).unparse()
    assert compare_ast(actual_source, expected_source)

# Generated at 2022-06-18 00:10:09.782083
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_funcdef
    from ..utils.test_utils import parse_to_classdef

    # Test with metaclass
    classdef = parse_to_classdef("class A(metaclass=B): pass")
    transformer = MetaclassTransformer()
    transformer.visit(classdef)
    assert_equal_ast(transformer.tree, parse_to_ast("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """))

    # Test without metaclass
    classdef = parse_to_

# Generated at 2022-06-18 00:10:11.842091
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:10:22.074698
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

# Generated at 2022-06-18 00:10:30.026019
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    transform_and_compare(MetaclassTransformer,
                          """
                          class A(metaclass=B):
                              pass
                          """,
                          """
                          from six import with_metaclass as _py_backwards_six_withmetaclass
                          class A(_py_backwards_six_withmetaclass(B)):
                              pass
                          """)

# Generated at 2022-06-18 00:10:37.814942
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import builtins

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    module = ast.parse(input_code.get_body())
    module = MetaclassTransformer().visit(module)
    assert ast_to_str(module) == expected_code.get_body()

# Generated at 2022-06-18 00:10:40.949918
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import transform_ast


# Generated at 2022-06-18 00:10:52.777477
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import ast_to_source as ats
    from ..utils.source import ast_to_code as atc
    from ..utils.source import ast_to_source_and_code as atsac
    from ..utils.source import code_to_ast as cta
    from ..utils.source import code_to_source as cts
    from ..utils.source import code_to_ast_and_source as ctas
    from ..utils.source import source_to_code_and_ast as stca
    from ..utils.source import code_to_source_and_ast as ctsa


# Generated at 2022-06-18 00:10:55.637860
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:11:03.894148
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins
    from ..utils.snippet import snippet
    from ..utils.source import source_to_ast

    @snippet
    def before():
        class A(metaclass=type):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(type)):
            pass

    transformer = MetaclassTransformer()
    node = source_to_ast(before.get_source())
    transformer.visit(node)

# Generated at 2022-06-18 00:11:15.042161
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = input_code.get_ast()
    expected = expected_code.get_ast()
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == ast_to_str(expected)

# Generated at 2022-06-18 00:11:17.015986
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:11:28.466350
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_str

    class_def = ast_class(name='A',
                          bases=[ast_name(id='object')],
                          keywords=[ast_call(func=ast_name(id='metaclass'),
                                             args=[ast_name(id='B')])])

    expected_class_def = ast_class(name='A',
                                   bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                                   args=[ast_name(id='B'),
                                                         ast_name(id='object')])])

    transformer = MetaclassTransformer()
    assert transformer.visit(class_def) == expected

# Generated at 2022-06-18 00:11:33.932587
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    node = parse_ast(source)
    MetaclassTransformer().visit(node)
    assert_equal_code(expected, node)

# Generated at 2022-06-18 00:11:40.878237
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare

    transform_and_compare(MetaclassTransformer,
                          """
                          class A(metaclass=B):
                              pass
                          """,
                          """
                          from six import with_metaclass as _py_backwards_six_withmetaclass
                          class A(_py_backwards_six_withmetaclass(B)):
                              pass
                          """)

# Generated at 2022-06-18 00:11:52.976812
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword
    from ..utils.tree import tree_to_str

    class_def = ast_classdef(name='A',
                             bases=[ast_name(id='B')],
                             keywords=[ast_keyword(arg='metaclass',
                                                   value=ast_name(id='C'))])
    expected = ast_classdef(name='A',
                            bases=[ast_call(func=ast_name(id='_py_backwards_six_withmetaclass'),
                                            args=[ast_name(id='C'),
                                                  ast_name(id='B')])])

    transformer = MetaclassTransformer()

# Generated at 2022-06-18 00:12:03.224887
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()
    assert compile_snippet(node) == compile_snippet(after.get_ast())

# Generated at 2022-06-18 00:12:15.119377
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:12:17.841092
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source

    source = source('''
        class A(metaclass=B):
            pass
    ''')

    node = ast.parse(source)
    MetaclassTransformer().visit(node)
    assert source == ast.unparse(node)

# Generated at 2022-06-18 00:12:25.237745
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_withmetaclass import SixWithMetaclassTransformer
    from .metaclass import MetaclassTransformer
    from .dependencies import DependenciesTransformer
    from .tree import TreeTransformer

    @snippet
    def source():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass


# Generated at 2022-06-18 00:12:35.603377
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_equal_ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

# Generated at 2022-06-18 00:12:46.012755
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import compare_trees

    node = ast.ClassDef(name='A',
                        bases=[ast.Name(id='B', ctx=ast.Load())],
                        keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='C', ctx=ast.Load()))],
                        body=[],
                        decorator_list=[])


# Generated at 2022-06-18 00:12:54.735179
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.compile_source import compile_source
    from ..utils.source import source

    class_def = ast_class(name='A',
                          bases=[],
                          keywords=[ast_keyword(arg='metaclass',
                                                 value=ast_name(id='B'))],
                          body=[])
    module = ast.Module(body=[class_def])
    transformer = MetaclassTransformer()
    transformer.visit(module)

# Generated at 2022-06-18 00:13:03.294523
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.name = 'Test'
            return self.generic_visit(node)  # type: ignore

    # Test
    node = ast.parse('class A(metaclass=B): pass')
    MetaclassTransformer().visit(node)
    TestTransformer().visit(node)
    assert ast_to_str(node) == 'class Test(_py_backwards_six_withmetaclass(B)): pass'

# Generated at 2022-06-18 00:13:06.449503
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:13:11.935305
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_ast

    code = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(code)
    MetaclassTransformer().visit(tree)
    assert_equal_code(expected, tree)

# Generated at 2022-06-18 00:13:22.027888
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import roundtrip_unparse

    source = '''
    class A(metaclass=B):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    tree = parse_ast(source)
    tree = MetaclassTransformer().visit(tree)
    assert_equal_ast(tree, parse_snippet(expected))

# Generated at 2022-06-18 00:13:48.897151
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import get_metaclass_keyword_name

    class TestClass(metaclass=type):
        pass

    node = ast.parse(ast_to_str(ast.ClassDef(name='TestClass',
                                             bases=[],
                                             keywords=[ast.keyword(arg=get_metaclass_keyword_name(),
                                                                    value=ast.Name(id='type',
                                                                                   ctx=ast.Load()))],
                                             body=[],
                                             decorator_list=[])))

    transformer = MetaclassTransformer()
    transformer.visit(node)

# Generated at 2022-06-18 00:13:57.406391
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_builder import ast_from_str
    from ..utils.ast_visitor import ASTVisitor

    class Visitor(ASTVisitor):
        def __init__(self):
            self.metaclass = None
            self.bases = None

        def visit_Call(self, node):
            if isinstance(node.func, ast.Name) and node.func.id == '_py_backwards_six_withmetaclass':
                self.metaclass = node.args[0]
                self.bases = node.args[1:]

    class_def = ast_from_str("""
    class A(metaclass=B):
        pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(class_def)

# Generated at 2022-06-18 00:14:08.288865
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import builtins
    from ..utils.compat import six
    from ..utils.compat import typing

    class A(object):
        pass

    class B(metaclass=A):
        pass

    class C(object, metaclass=A):
        pass

    class D(object, metaclass=A, __qualname__='D'):
        pass

    class E(object, metaclass=A, __qualname__='E', __module__='__main__'):
        pass

    class F(object, metaclass=A, __qualname__='F', __module__='__main__', __doc__='F'):
        pass


# Generated at 2022-06-18 00:14:15.567242
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_with_metaclass(B)):
            pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:14:21.190912
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compiler import compile_snippet
    from ..utils.visitor import dump
    from ..utils.ast import parse

    snippet = source(MetaclassTransformer.visit_ClassDef)
    module = parse(snippet)
    MetaclassTransformer().visit(module)
    assert compile_snippet(dump(module))

# Generated at 2022-06-18 00:14:22.365444
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, compare_source


# Generated at 2022-06-18 00:14:24.605030
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, assert_equal_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:14:28.037569
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:14:29.844003
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:14:31.182245
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, assert_equal_code

# Generated at 2022-06-18 00:15:15.942199
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_factory import ast_factory

    class_def = ast_factory(ast.ClassDef, name='A', bases=[], keywords=[], body=[])
    class_def.keywords.append(ast_factory(ast.keyword, arg='metaclass', value=ast.Name(id='B', ctx=ast.Load())))
    module = ast_factory(ast.Module, body=[class_def])

    transformer = MetaclassTransformer()
    module = transformer.visit(module)


# Generated at 2022-06-18 00:15:27.444651
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_ast_and_code as staac
    from ..utils.source import ast_to_source as ats
    from ..utils.source import ast_to_code as atc
    from ..utils.source import ast_to_source_and_code as atsac
    from ..utils.source import code_equal
    from ..utils.source import source_equal
    from ..utils.source import ast_equal
    from ..utils.source import ast_source_equal
    from ..utils.source import ast_code_equal
    from ..utils.source import ast_source_code_equal
    from ..utils.source import ast_source_code_equal_with_print
   

# Generated at 2022-06-18 00:15:36.119588
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast

    code = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_to_ast(code)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:15:44.540733
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='object', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:15:47.498612
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:15:57.390877
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:16:05.130236
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .with_metaclass import MetaclassTransformer
    from .utils import get_transformed_ast

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            node = SixTransformer().visit(node)
            node = MetaclassTransformer().visit(node)
            return node

    source = """
    class A(metaclass=B):
        pass
    """

# Generated at 2022-06-18 00:16:15.585284
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import python_version

    @snippet
    def code():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(code.get_source())
    transformer = MetaclassTransformer(python_version)
    transformer.visit(node)
    assert ast_to_str(node) == expected.get_source()

# Generated at 2022-06-18 00:16:18.129702
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:16:26.352032
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.unparse import Unparser
    from ..utils.compare_ast import compare_ast

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    expected = source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    result = Unparser(tree)

    assert compare_ast(result, expected)