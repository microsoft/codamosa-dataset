

# Generated at 2022-06-18 00:08:10.628023
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    transform_and_compare(MetaclassTransformer, 'class A(metaclass=B): pass')

# Generated at 2022-06-18 00:08:20.780230
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.snippet import snippet
    from ..utils.tree import tree

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    module = ast.parse(input_code.get_source())
    transformer = MetaclassTransformer()
    new_module = transformer.visit(module)
    assert source(new_module) == expected_code.get_source()
   

# Generated at 2022-06-18 00:08:22.270832
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import parse_ast


# Generated at 2022-06-18 00:08:27.432717
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-18 00:08:30.600938
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:08:39.647839
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compile import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = compile_snippet(before.get_source())
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == after.get_source()



# Generated at 2022-06-18 00:08:42.081907
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import ast_from_code
    from ..utils.tree import tree_to_str


# Generated at 2022-06-18 00:08:45.279409
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.unparse import Unparser


# Generated at 2022-06-18 00:08:53.767532
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet

    snippet = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    node = parse_snippet(snippet)
    expected_node = parse_ast(expected)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert_equal_ast(node, expected_node)

# Generated at 2022-06-18 00:09:04.014148
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PY2
    from ..utils.compat import PY3

    @snippet
    def code():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = code.get_ast()
    expected_node = expected.get_ast()

    transformer = MetaclassTransformer()
    transformer.visit(node)


# Generated at 2022-06-18 00:09:14.659208
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='object', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

    module = ast.Module(body=[class_def])

    transformer = MetaclassTransformer()
    module = transformer.visit(module)

    assert transformer._tree_changed is True

# Generated at 2022-06-18 00:09:23.819758
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.ast_factory import ast_factory

    class_def = ast_factory(
        """
        class A(metaclass=B):
            pass
        """,
        mode='exec',
    )

    expected = ast_factory(
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """,
        mode='exec',
    )

    transformer = MetaclassTransformer()
    transformer.visit(class_def)
    assert tree_to_str(class_def) == tree_to_str(expected)

# Generated at 2022-06-18 00:09:34.635999
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='object', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

# Generated at 2022-06-18 00:09:41.992476
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:09:50.437193
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

    module = ast.Module(body=[class_def])

    transformer = MetaclassTransformer()
    transformer.visit(module)

    assert transformer._tree_changed

    assert module.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert module.body[0].bases[0].args[0].id == 'C'

# Generated at 2022-06-18 00:09:58.029590
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import parse_tree
    from ..utils.tree import print_tree
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    from .base import NodeTransformerTestCase
    from .base import NodeTransformerTestCase
    from .base import NodeTransformerTestCase
    from .base import NodeTransformerTestCase
    from .base import NodeTransformerTestCase
    from .base import NodeTransformerTestCase
    from .base import NodeTransformerTestCase
    from .base import NodeTransformerTestCase
    from .base import NodeTransformerTestCase
    from .base import NodeTransformerTestCase
    from .base import NodeTransformerTestCase

# Generated at 2022-06-18 00:10:05.183823
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source

    source = """
    class A(metaclass=B):
        pass
    """
    expected_source = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    expected_ast = get_ast(expected_source)

    node = get_ast(source)
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)
    assert_equal_ast(expected_ast, new_node)

# Generated at 2022-06-18 00:10:13.018528
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_file
    from ..utils.test_utils import get_ast_from_file_and_transform

    # Test case 1
    # Test case 1.1

# Generated at 2022-06-18 00:10:24.152049
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    node = MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()

# Generated at 2022-06-18 00:10:35.011767
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.compat import PY2
    from ..utils.compat import PY3

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:10:40.953867
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, assert_equal_source


# Generated at 2022-06-18 00:10:50.811786
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import PYTHON_VERSION

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='object', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:10:59.928818
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer = TestTransformer
        target = (2, 7)

        def test_class_with_metaclass(self):
            tree = ast.parse("""
            class A(metaclass=B):
                pass
            """)
            expected = ast.parse("""
            class A(_py_backwards_six_withmetaclass(B)):
                pass
            """)

# Generated at 2022-06-18 00:11:03.964884
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_node as stn
    from ..utils.source import source_to_code as stc
    from ..utils.source import source_to_tokens as stt
    from ..utils.source import source_to_token_names as sttn


# Generated at 2022-06-18 00:11:13.676867
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_ast_equal

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transformer = MetaclassTransformer()
    tree = transformer.visit(before.get_ast())
    assert_ast_equal(tree, after.get_ast())

# Generated at 2022-06-18 00:11:23.512994
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def class_def():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    tree = class_def.get_tree()
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert ast_to_str(tree) == ast_to_str(expected.get_tree())

# Generated at 2022-06-18 00:11:26.840747
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:11:33.287381
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast
    from ..utils.unparse import Unparser

    source = source('''
        class A(metaclass=B):
            pass
    ''')
    expected_source = source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    compare_ast(Unparser(tree).unparse(), expected_source)

# Generated at 2022-06-18 00:11:43.081294
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ..utils.tree import tree_to_str
    from ..utils.source import source_to_str

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node):
            node.bases = [ast.Name(id='B', ctx=ast.Load())]
            return node

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

    expected_class_def = ast.Class

# Generated at 2022-06-18 00:11:49.890318
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    tree = compile_snippet(before)
    assert ast_to_str(tree) == ast_to_str(compile_snippet(after))

    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert ast_to_str(tree)

# Generated at 2022-06-18 00:12:00.844338
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import round_trip


# Generated at 2022-06-18 00:12:06.645494
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_factory
    from ..utils.compile_source import compile_source
    from ..utils.source import source

    source_code = source('''
        class A(metaclass=B):
            pass
    ''')
    tree = ast.parse(source_code)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert compile_source(ast_factory(tree)) == compile_source(source_code)

# Generated at 2022-06-18 00:12:16.028682
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.compat import parse

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert print_tree(node) == after.get_source()

# Generated at 2022-06-18 00:12:23.971354
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name, ast_keyword
    from ..utils.compile import compile_to_ast

    # Test 1:
    # class A(metaclass=B):
    #     pass
    #
    # Should compile to:
    # class A(_py_backwards_six_with_metaclass(B)):
    #     pass
    node = ast_class(name='A',
                     bases=[],
                     keywords=[ast_keyword(arg='metaclass', value=ast_name(id='B'))],
                     body=[])

# Generated at 2022-06-18 00:12:35.473323
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = ast.parse(before.get_source())
    MetaclassTransformer().visit(node)
    assert ast_to_str(node) == after.get_source()


# Generated at 2022-06-18 00:12:36.800486
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source


# Generated at 2022-06-18 00:12:47.138684
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    from .six_with_metaclass import SixWithMetaclassTransformer
    from .six_with_metaclass import six_with_metaclass
    from .six_with_metaclass import six_with_metaclass_import
    from .six_with_metaclass import six_with_metaclass_import_str
    from .six_with_metaclass import six_with_metaclass_str

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node):
            return node


# Generated at 2022-06-18 00:12:48.992077
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import roundtrip


# Generated at 2022-06-18 00:12:55.323382
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = parse_ast(source)
    MetaclassTransformer().visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:12:57.527867
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:13:22.886009
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippets
    from .base import BaseNodeTransformer
    from .metaclass import MetaclassTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast_name(id='B')]
            return node


# Generated at 2022-06-18 00:13:27.844193
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_source

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    assert_source(MetaclassTransformer, source, expected)

# Generated at 2022-06-18 00:13:37.586369
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_classdef, ast_name, ast_keyword
    from ..utils.source_factory import source

    source_code = source('''
    class A(metaclass=B):
        pass
    ''')
    tree = ast.parse(source_code)
    transformer = MetaclassTransformer()
    transformer.visit(tree)

# Generated at 2022-06-18 00:13:46.000602
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = compile_snippet(before.get_source(), 'before.py', 'exec')
    node = SixTransformer().visit(node)

# Generated at 2022-06-18 00:13:52.853114
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_node_equals
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_unchanged
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_tree
    from ..utils.test_utils import parse_ast_tree
    from ..utils.test_utils import parse_source_to_ast

    # Test 1: Test that a class with a metaclass is transformed correctly
    source = """
        class A(metaclass=B):
            pass
    """

# Generated at 2022-06-18 00:13:57.774127
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = parse_ast(code)
    MetaclassTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:14:08.548576
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_withmetaclass

# Generated at 2022-06-18 00:14:15.565901
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.compat import builtins
    from ..utils.snippet import snippet
    from ..utils.tree import parse

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    node = parse(before.get_ast())
    MetaclassTransformer().visit(node)
    assert after.get_ast() == node

# Generated at 2022-06-18 00:14:26.186518
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .utils import transform_and_compare_ast

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node

    class TestTransformer3(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node


# Generated at 2022-06-18 00:14:33.755450
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PY2

    @snippet
    def code():
        class A(metaclass=B):
            pass

    @snippet
    def expected():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    if PY2:
        expected = expected.get_body()
    else:
        expected = code.get_body()

    node = code.get_ast()
    node = MetaclassTransformer().visit(node)
    assert ast_to_str(node) == ast_to

# Generated at 2022-06-18 00:15:10.118823
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import round_trip


# Generated at 2022-06-18 00:15:16.179937
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source

    source = source('''
    class A(metaclass=B):
        pass
    ''')
    tree = ast.parse(source)
    node = tree.body[0]
    assert isinstance(node, ast.ClassDef)
    assert len(node.keywords) == 1
    assert node.keywords[0].arg == 'metaclass'
    assert isinstance(node.keywords[0].value, ast.Name)
    assert node.keywords[0].value.id == 'B'

    MetaclassTransformer().visit(tree)

    assert len(node.keywords) == 0
    assert len(node.bases) == 1
    assert isinstance(node.bases[0], ast.Call)

# Generated at 2022-06-18 00:15:27.634108
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

# Generated at 2022-06-18 00:15:36.044064
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test import transform_and_compare

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transform_and_compare(MetaclassTransformer, before, after)

# Generated at 2022-06-18 00:15:44.471966
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.compat import PY2
    from ..utils.test_utils import assert_equal_ast

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    if PY2:
        assert_equal_ast(MetaclassTransformer.run(before.get_ast()), after.get_ast())

# Generated at 2022-06-18 00:15:47.503517
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:15:57.390915
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import parse_ast

    # Test case 1:
    #   class A(metaclass=B):
    #       pass
    #
    # Should be transformed to:
    #   class A(_py_backwards_six_with_metaclass(B)):
    #       pass
    #
    # And the tree should be changed.
    node = parse_ast("class A(metaclass=B): pass")
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert_tree_changed(transformer)

# Generated at 2022-06-18 00:15:58.672973
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, compare_ast


# Generated at 2022-06-18 00:16:01.156538
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:16:12.234383
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_compare import compare_ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='object', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-18 00:17:49.320365
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_builder import build_ast
    from ..utils.ast_visitor import ASTVisitor

    class_def = build_ast("""
        class A(metaclass=B):
            pass
    """)

    transformer = MetaclassTransformer()
    transformer.visit(class_def)
    assert astor.to_source(class_def) == """
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """

    # Check that the transformer is idempotent
    transformer.visit(class_def)
    assert astor.to_source(class_def) == """
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """

    # Check that the transformer is idempot

# Generated at 2022-06-18 00:17:59.648202
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_unchanged
    from ..utils.test_utils import get_ast

    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = get_ast(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_tree_changed(transformer)
    assert_equal_source(tree, expected)


# Generated at 2022-06-18 00:18:01.524360
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source


# Generated at 2022-06-18 00:18:05.647003
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import get_test_data

    transform_and_compare(MetaclassTransformer, get_test_data('metaclass_transformer_visit_ClassDef.py'))