

# Generated at 2022-06-21 17:35:07.521250
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .reflex import ReflexNodeTransformer
    from ast_tools.transformers import TransformerSequence
    from .. import tree



# Generated at 2022-06-21 17:35:10.081740
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from py_backwards.utils.test_utils import parse_and_transform

# Generated at 2022-06-21 17:35:21.174173
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer().visit(
        ast.parse("""
        class A(metaclass=B):
            pass
        """)
    ) == ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """)


# Generated at 2022-06-21 17:35:29.210881
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_setup import setup_test
    from ..node import Node
    test_file_path, root_node = setup_test(MetaclassTransformer, 'class A(metaclass=B): pass', '2.7')

    from .test_setup import sample_file
    sample_file(MetaclassTransformer, six_import.get_body(), 'six.py')

    metaclass_name = 'B'
    metaclass_node = Node('Name', id=metaclass_name, context=ast.Load(),
                          path=[metaclass_name], file_path=test_file_path)


# Generated at 2022-06-21 17:35:32.830699
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    assert six_import.get_body() in MetaclassTransformer.visit_Module(
        ast.parse("pass")).body  # type: ignore



# Generated at 2022-06-21 17:35:38.841809
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import inspect
    import six
    from typing import Dict, Mapping, Type
    
    a_types = six.with_metaclass(dict)
    if isinstance(a_types, Mapping):
        _dict: Dict[str, Type[a_types]] = {
            name: obj_type
            for name, obj_type in inspect.getmembers(a_types)
            if inspect.isclass(obj_type)
        }
    else:
        _dict = {}


# Coverage testing of class ClassDef

# Generated at 2022-06-21 17:35:51.709207
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=DeprecationWarning)
        s = '''
            class A(metaclass=B):
                pass
            
            class C(B, metaclass=D):
                pass
            
            class E:
                pass
        '''
        module = ast.parse(s)

        MetaclassTransformer(None).visit(module)

# Generated at 2022-06-21 17:35:53.618385
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-21 17:36:00.805542
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    mt = MetaclassTransformer()

# Generated at 2022-06-21 17:36:06.151324
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    ast = parse("class A(): pass")
    module = MetaclassTransformer().visit(ast)
    expected = "from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A():\n    pass\n"
    assert astor.to_source(module) == expected

# Generated at 2022-06-21 17:36:21.358819
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import six
    import os
    import sys

    oldpath = os.path.dirname(six.__file__)
    sys.path.insert(0, oldpath)

    from typed_ast import ast3 as ast
    from ..utils.testing import test_transformer
    import _py_backwards.transformers.metaclass_transformer

    # Create AST
    node = ast.Module(body=[
        ast.ClassDef(name="A",
                     body=[],
                     bases=[ast.Name(id="object", ctx=ast.Load())],
                     keywords=[ast.keyword(arg="metaclass", value=ast.Name(id="B", ctx=ast.Load()))])
    ])

    # Verify the transformer works as expected

# Generated at 2022-06-21 17:36:22.319578
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-21 17:36:27.964128
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.fake_ast import ast_from_string
    from typed_ast import TypeIgnore
    from .remove_type_comments import RemoveTypeCommentsTransformer


# Generated at 2022-06-21 17:36:36.308494
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = 'class A(metaclass=B):\n    pass'
    expected_output = 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'
    output = MetaclassTransformer().visit(ast.parse(code))
    assert astunparse.unparse(output) == expected_output

# Generated at 2022-06-21 17:36:37.485930
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:36:39.602356
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:36:51.941345
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    
    """
    Test for the method visit_ClassDef of the class MetaclassTransformer
    """
    
    from ast import parse
    from .test_BaseNodeTransformer import patch
    from .test_BaseNodeTransformer import configure
    from .test_BaseNodeTransformer import reset

    node = parse("""
        class A:
            pass
        """).body[0]
    transformer = MetaclassTransformer()
    node = transformer.visit(node)
    assert patch(node, __name__) == parse("""
        class A(_py_backwards_six_withmetaclass(None, A)):
            pass
        """).body[0]
    configure(transformer, tree_changed=False)
    node = transformer.visit(node)

# Generated at 2022-06-21 17:37:00.121202
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import run_transformer

    module_string = '''
    class A(metaclass=B):
        pass
    '''

    expected_output_string = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    result = run_transformer(MetaclassTransformer, module_string)
    assert expected_output_string == result

# Generated at 2022-06-21 17:37:03.751909
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:37:06.185981
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """Unit tests for constructor of class MetaclassTransformer."""
    # Arrange

# Generated at 2022-06-21 17:37:17.431130
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    
    import ast as py_ast
    from ..utils.source import source_to_unicode
    from ..visitor import GenericPrintVisitor
    from ..utils.visitor import replace_visitor

    my_classes = source_to_unicode("""
    import six
    class A(metaclass=six.with_metaclass):
        pass
    
    class B(object, metaclass=six.with_metaclass):
        pass
    
    class C:
        pass
    """)
    m = py_ast.parse(my_classes)
    v = MetaclassTransformer()
    m_new = v.visit(m, ())
    assert not v.tree_changed

    m_new = replace_visitor(m_new, GenericPrintVisitor)
    assert source_to_unicode

# Generated at 2022-06-21 17:37:19.407888
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert issubclass(MetaclassTransformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:37:24.012449
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    node = ast.parse('class A(metaclass=B):\n    def __init__(self, x):\n        self.x = x\n    def sayhi(self):\n        print(self.x)')
    node = MetaclassTransformer.run(node)
    print(ast.dump(node))

# Generated at 2022-06-21 17:37:35.049301
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    class TestTransformer(ast.NodeTransformer):
        def visit_Str(self, node):
            if node.s == 'six':
                return ast.Str(s='typed_ast')
            if node.s == 'with_metaclass':
                return ast.Str(s='with_metaclass')
            return node

    source = """
    class A(metaclass=B):
        pass
    """
    tree = ast.parse(source)

    transformer = MetaclassTransformer()
    transformer.visit(tree)

    newtree = TestTransformer().visit(tree)


# Generated at 2022-06-21 17:37:41.502154
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.testutils import assert_ast_eq
    from ..utils.testutils import assert_tree_changed
    m = ast.parse('a = 1')
    assert_ast_eq(MetaclassTransformer().visit(m), 
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n'
        'a=1')



# Generated at 2022-06-21 17:37:49.984001
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    from ..utils.source import Source
    from .. import compile_snippet
    from ..utils.snippet import snippet
    import textwrap

    context = Context()
    source = Source(
        textwrap.dedent(
            '''
            class Base(object):
                pass
            class A(Base, metaclass=type):
                pass
            class B(Base, metaclass=Base):
                pass
            '''
        )
    )
    source.add_transform(MetaclassTransformer, context)
    source.add_transform(six_import)
    source.add_transform(class_bases)

    # We only check that there is no error
    compile_snippet(source)

# Generated at 2022-06-21 17:38:00.007348
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .examples import Metaclass_examples
    import sys

    print("sys.version_info[:2] = {!r}".format(sys.version_info[:2]))

    for example in Metaclass_examples:
        source = example['source']
        expected = example['expected']

        mt = MetaclassTransformer()
        tree = mt.visit(ast.parse(source))
        code = compile(tree, '<string>', mode='exec')

        # test that the :source: is compiled to the :expected:
        exec(code)

        if __name__ == '__main__':
            print("\nTesting MetaclassTransformer")
            print("Example:")
            print(source)
            print("Result:")
            print(astor.to_source(tree))

# Generated at 2022-06-21 17:38:04.409060
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.example import example
    from ..fixer import fixer
    example1 = example(
        """
        #!/usr/bin/env python
        class A(metaclass=B):
            pass
        """)
    assert example1.code == fixer.fix_code(example1.code, python_version=(2,7))

# Generated at 2022-06-21 17:38:14.891272
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import textwrap
    node = ast.parse(textwrap.dedent("""
    class A(metaclass=B):
        pass
    """))
    exp_node = ast.parse(textwrap.dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """))
    node = MetaclassTransformer().visit(node)
    print(ast.dump(node))
    print(ast.dump(exp_node))
    assert ast.dump(node) == ast.dump(exp_node)

# Generated at 2022-06-21 17:38:24.976637
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast, typing
    from ast import ClassDef, keyword, Name, Str, Module
    from .transformers import MetaclassTransformer
    from ..utils.snippet import snippet
    from ..utils.tree import file_from_ast, tree_to_str
    from typed_ast import ast3

    # snippet: class A(metaclass=B): pass
    class A(metaclass=B):
        pass

    # snippet: class A
    class A:
        pass

    n = ast.parse(str(A))
    n = ast.fix_missing_locations(n)


# Generated at 2022-06-21 17:38:39.959813
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    transformer = MetaclassTransformer()
    result = transformer.visit_Module(ast.parse(
        "class A(object):\n"
        "    pass"
    ))
    expected = ast.parse(
        "from six import with_metaclass as _py_backwards_six_withmetaclass\n"
        "\n"
        "class A(object):\n"
        "    pass"
    )
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-21 17:38:51.724658
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert MetaclassTransformer.run('''
        class Foo(metaclass=type):
            pass
    ''') == '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class Foo(_py_backwards_six_withmetaclass(type, )):
        pass
    '''

    assert MetaclassTransformer.run('''
        class Foo(object, metaclass=type):
            pass
    ''') == '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class Foo(_py_backwards_six_withmetaclass(type, object)):
        pass
    '''



# Generated at 2022-06-21 17:38:57.690260
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    from .base import BaseNodeTransformer
    from .six import fix_six_import
    from .six_metaclasses import MetaclassTransformer

    code = """
    class A(metaclass=B):
        pass
    """

    tree = ast3.parse(code)
    MetaclassTransformer().visit(tree)

# Generated at 2022-06-21 17:39:00.274638
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:39:05.692400
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor  # type: ignore
    source = '''class MyClass(metaclass=type):
    pass'''
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)

# Generated at 2022-06-21 17:39:10.781068
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip

    source = """
    class A(metaclass=B):
        pass
    """
    tree = ast.parse(source)
    MetaclassTransformer.run_fragment(tree)
    code = compile(tree, "<test>", "exec")
    exec(code)

    assert round_trip(tree, MetaclassTransformer)

# Generated at 2022-06-21 17:39:14.284565
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse("class A(object, metaclass=B): pass")
    MetaclassTransformer().visit(module)

    assert module.body[-1].bases[0].func.func.id == "_py_backwards_six_withmetaclass"



# Generated at 2022-06-21 17:39:18.633234
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.tester import tree_test
    import ast

    node = ast.Module()
    transformer = MetaclassTransformer()
    result = transformer.visit(node)

    assert transformer._tree_changed is True
    assert result == six_import.get_ast()


# Generated at 2022-06-21 17:39:23.285584
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testing import fix, assert_func
    
    fix(MetaclassTransformer, 'pipeline.classic', '''
        from abc import ABCMeta
        class A(object, metaclass=ABCMeta):
            def __init__(self, a):
                self.a = a
        def x():
            return A(A.x)
    ''')
    assert_func('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(ABCMeta, object)):
            def __init__(self, a):
                self.a = a
        def x():
            return A(A.x)
    ''')

# Generated at 2022-06-21 17:39:32.448966
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class Foo(object):
        pass

    class Bar(Foo, metaclass=type):
        pass

    am_i_bar = isinstance(Bar, Bar)
    assert am_i_bar is True  # pylint: disable=unidiomatic-typecheck

    # type: ignore
    # pylint: disable=unsubscriptable-object


# The linter is wrong; this *is* a test
# pylint: disable=no-member,too-few-public-methods

# Generated at 2022-06-21 17:39:54.840106
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    ast_tree = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    expected_result = ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    MetaclassTransformer().visit(ast_tree)
    assert ast_tree == expected_result



# Generated at 2022-06-21 17:40:06.277511
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse('class A(metaclass=B):\n    pass')
    MetaclassTransformer().visit(module)
    assert ast.dump(module) == \
        '''Module(body=[ImportFrom(module='six',
                                   names=[alias(name='with_metaclass',
                                   asname='_py_backwards_six_withmetaclass')],
                                   level=0),
                            ClassDef(name='A',
                                     bases=[Call(func=Name(id='_py_backwards_six_withmetaclass',
                                                            ctx=Load()),
                                                 args=[Name(id='B', ctx=Load())],
                                                 keywords=[])],
                                     body=[],
                                     decorator_list=[],
                                     keywords=[])])'''

# Generated at 2022-06-21 17:40:17.722232
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from textwrap import dedent
    from ..utils.sourcetree import SourceTree
    from ..utils.lines import split_lines

    source = dedent("""\
        class Foo(Bar, object, metaclass=MetaBar):
            pass
        """)
    expected_source = dedent("""\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class Foo(_py_backwards_six_withmetaclass(MetaBar, Bar, object)):
            pass
        """)

    tree = SourceTree.from_lines(split_lines(source))
    transformation = MetaclassTransformer()
    end_tree = transformation.visit(tree)
    end_source = str(end_tree)

    print(end_source)
    assert end_source == expected_

# Generated at 2022-06-21 17:40:24.655666
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer(2, 7)
    assert transformer.target == (2, 7)
    assert transformer.dependencies == ['six']
    assert transformer._tree_changed == False
    assert transformer.import_set == set()
    # get_body() is an alias for unparse()
    assert six_import.get_body() == six_import.unparse()
    assert class_bases.get_body(metaclass="Hello", bases=["World"]) == class_bases.unparse(metaclass="Hello", bases=["World"])

# Generated at 2022-06-21 17:40:35.487178
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    from ..utils.test_utils import get_ast

    m = get_ast(textwrap.dedent('''
    class A(B, object, metaclass=C):
        pass
    ''')).body[0]

    mt = MetaclassTransformer()
    mt.visit(m)
    assert mt._tree_changed

    metaclass_arg = ast.Name(id="C")
    metaclass_call = ast.Call(
        func=ast.Name(id="_py_backwards_six_withmetaclass"),
        args=[metaclass_arg],
        keywords=[],
        starargs=None,
        kwargs=None
    )
    assert metaclass_call.lineno == 2
    assert metaclass_call.col_offset == 19

   

# Generated at 2022-06-21 17:40:36.959423
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:40:46.746192
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = """
        class Foo:
            pass
        
        class Bar(metaclass=Foo):
            pass"""
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    class Foo:
        pass

    class Bar(_py_backwards_six_withmetaclass(Foo)):
        pass"""
    tree = ast.parse(source)
    assert MetaclassTransformer().visit(tree) == expected

# Generated at 2022-06-21 17:40:54.437047
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # pragma: no cover
    src = dedent("""\
        class A(metaclass=B):
            pass
    """)
    module = ast.parse(src)
    MetaclassTransformer(module).run()
    code = compile(module, '<test>', 'exec')
    eval(code)
    assert A.__class__.__class__.__name__ == 'B'

# Generated at 2022-06-21 17:41:01.336905
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse("""
        class C(metaclass=m):
            pass
        class D(m):
            pass
    """)
    MetaclassTransformer(target_version=(2,7)).visit(module)
    assert ast.dump(module) == """\
Module(body=[
    ClassDef(name='C',
             bases=[_py_backwards_six_withmetaclass(m)],
             keywords=[],
             body=[Pass()],
             decorator_list=[]),
    ClassDef(name='D',
             bases=[m],
             keywords=[],
             body=[Pass()],
             decorator_list=[])])\
"""

# Generated at 2022-06-21 17:41:02.203740
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:41:49.429319
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.tests import assert_equal_pyast
    from typed_ast import ast3 as ast

    node = ast.Module(body=[
        ast.Expr(value=ast.Str(s='hello world')),
        ast.ClassDef(name='Foo',
                     bases=[ast.Name(id='Bar', ctx=ast.Load())],
                     keywords=[ast.keyword(arg='metaclass',
                                           value=ast.Name(id='A', ctx=ast.Load()))],
                     body=[ast.Pass()],
                     decorator_list=[])
    ])


# Generated at 2022-06-21 17:41:58.544381
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():

    class MockNode(ast.AST):
        _fields = ('body',)

        def __init__(self, body: list) -> None:
            self.body = body

    # test if body is inserted
    node = MockNode(body=[])
    MetaclassTransformer().visit_Module(node)
    assert len(node.body) == 1

    # test if body is not inserted if body is not empty
    node = MockNode(body=[ast.Pass()])
    MetaclassTransformer().visit_Module(node)
    assert len(node.body) == 1


# Generated at 2022-06-21 17:42:08.300965
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    code = 'class A(metaclass=B, c, d):pass'
    module = compile(code, '', 'exec', ast.PyCF_ONLY_AST)
    module = MetaclassTransformer().visit(module)
    module = astor.to_source(module)
    assert module == 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B, *[c, d])):\n    pass\n'

# Generated at 2022-06-21 17:42:21.229417
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import generate_source
    from ..utils.compiler import compile_snippet, get_name_node

    source = generate_source(MetaclassTransformer.snippets)
    expected_code = """\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class _py_backwards_test_class(_py_backwards_six_withmetaclass(metaclass), abc, object):
        pass
    """
    expected_ast = compile_snippet(source, '_py_backwards_test_class')

    ast = compile_snippet(MetaclassTransformer.get_fixed_source(), '_py_backwards_test_class')

    assert ast == expected_ast

# Generated at 2022-06-21 17:42:23.242963
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-21 17:42:30.836839
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast

    source = """\
        class A(metaclass=B):
            pass
    """
    expected = """\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """

    metaclass = MetaclassTransformer()
    tree = ast.parse(source)
    metaclass.visit(tree)
    out = ast.fix_missing_locations(tree)
    result = compile(out, '', 'exec')

    assert result == compile(expected, '', 'exec')

# Generated at 2022-06-21 17:42:31.306092
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:42:41.408167
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse("class A(metaclass=B): pass")
    node = MetaclassTransformer().visit(module)
    result = ast.dump(node)

    import textwrap

# Generated at 2022-06-21 17:42:46.564141
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    source = textwrap.dedent("""\
    class A(b, metaclass=C):
        pass
    """)
    tree = ast.parse(source)
    tree = transformer.visit(tree)
    assert transformer.tree_changed()
    source = textwrap.dedent("""\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(C), b):
        pass
    """)
    assert ast.dump(tree) == ast.dump(ast.parse(source))

# Generated at 2022-06-21 17:42:48.869938
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:44:12.302751
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import mypy.api
    from ..utils.test_fixtures import change_dir_to_module

# Generated at 2022-06-21 17:44:22.513063
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_eq
    from .base import BaseNodeTransformer

    class ExampleTransformer(BaseNodeTransformer):
        def visit_foo(self, node: ast.Str) -> ast.Str:
            return ast.Str(s=node.s + 'bar')

    expected = ast.Module(
        body=[ast.Import(names=[ast.alias(name='six', asname=None)]),
              ast.Assign(targets=[ast.Name(id='bar', ctx=ast.Store())],
                         value=ast.Str(s='foobar')),
              ast.Expr(value=ast.Num(n=42))])

# Generated at 2022-06-21 17:44:23.346054
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor


# Generated at 2022-06-21 17:44:32.798876
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """
    >>> from typed_ast import ast3
    >>> from typed_ast.ast3 import (
    ...     Module, ClassDef, Name, Load, NameConstant, List
    ... )

    >>> node = Module(body=[
    ...     ClassDef(name='A', keywords=[], body=[], decorator_list=[],
    ...     bases=[], keywords=[])
    ... ])

    >>> MetaclassTransformer().visit(node)
    >>> assert ast3.dump(node) == "from six import with_metaclass as _py_backwards_six_withmetaclass\\n\\n\\nclass A(_py_backwards_six_withmetaclass(metaclass=None, *[])):\\n    pass\\n\\n"
    """

# Generated at 2022-06-21 17:44:40.402938
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    s = """
    class A(metaclass=B):
        pass
    """
    expected_class = """
    _py_backwards_six_withmetaclass(B, )
    """

    class_def = MetaclassTransformer().visit(ast.parse(s)).body[0]
    class_def = ast.fix_missing_locations(class_def)

    assert ast.dump(class_def) == expected_class

# Generated at 2022-06-21 17:44:41.606887
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:44:44.823856
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import make_visitor_test_case

    MyTransformer = make_visitor_test_case(MetaclassTransformer)

    # Case 1
    transformer = MyTransformer(version=(3, 4))

# Generated at 2022-06-21 17:44:52.031433
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    snippet = """class MyClass(metaclass=MyMetaclass):
    pass
    """
    tree = compile(snippet, '', 'exec', _ast.PyCF_ONLY_AST)
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit_Module(tree)
    assert ast.dump(tree) == '<_ast.Module object at 0x7fb9f9ecd160>'


# Generated at 2022-06-21 17:44:52.946284
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:44:53.569826
# Unit test for method visit_ClassDef of class MetaclassTransformer