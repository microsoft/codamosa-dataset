

# Generated at 2022-06-21 17:35:21.616041
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    node = ast.ClassDef(name='A',
                        bases=[],
                        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B')),
                                  ast.keyword(arg='bogus', value=ast.Name(id='C'))],
                        body=[ast.Pass()],
                        decorator_list=[])
    x = MetaclassTransformer().visit(node)

    assert x.bases[0].value.args == [ast.Name(id='B')]
    assert len(x.keywords) == 1
    assert x.keywords[0].arg == 'bogus'



# Generated at 2022-06-21 17:35:23.758707
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse('class A(metaclass=B): pass')
    transform = MetaclassTransformer()
    transform.visit(tree)

# Generated at 2022-06-21 17:35:26.146970
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    m = ast.parse('class A():pass')
    t = MetaclassTransformer()
    t.visit(m)
    assert compile(m, filename='<none>', mode='exec')

# Generated at 2022-06-21 17:35:28.063323
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    module = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    MetaclassTransformer()(module)
    print(ast.dump(module))

# Generated at 2022-06-21 17:35:38.041448
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    code = """class A(metaclass=B):\n    pass"""
    expected = """from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass"""
    module = ast.parse(code)
    c = MetaclassTransformer()
    c.visit(module)
    new_code = astor.to_source(module)
    assert new_code == expected

# Generated at 2022-06-21 17:35:44.096637
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    from ..custom_ast import load
    result: ast.Module = load(MetaclassTransformer._test1.__doc__)
    assert result is not None
    assert result.body[0].value.elts[0].id == 'six'

# Generated at 2022-06-21 17:35:46.239717
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer(2, 7, dependencies=['six'])

# Generated at 2022-06-21 17:35:48.205183
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six

# Generated at 2022-06-21 17:35:59.999125
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    code = """
    class A(metaclass=type):
        def __new__(self):
            return super(A, self).__new__(self)
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(type, object)):
        def __new__(self):
            return super(A, self).__new__(self)
    """
    expected_ast = parse(expected).body[1]

    # When
    result = MetaclassTransformer().visit(parse(code))

    # Then
    assert replace(expected_ast, '\n', '') == replace(result, '\n', '')



# Generated at 2022-06-21 17:36:10.603103
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    out = six_import.get_ast()
    out = class_bases.get_ast(metaclass=ast.Name(id="foo", ctx=ast.Load()), 
                          bases=ast.List(elts=[ast.Name(id="bar", ctx=ast.Load())]))
    assert (ast.dump(out) ==
            "Expr(value=Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), "
            "args=[Name(id='foo', ctx=Load()), Name(id='bar', ctx=Load())], keywords=[], starargs=None, kwargs=None))")

# Generated at 2022-06-21 17:36:14.490753
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:36:22.018499
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    assert transformer.visit_ClassDef(ast.ClassDef(name="A",
                                        bases=[],
                                        keywords=[ast.keyword(arg="metaclass",value=ast.Name(id="B"))],
                                        body=[], decorator_list=[])) == ast.ClassDef(name="A",
                                                                        bases=class_bases.get_body(metaclass=ast.Name(id="B"), bases=ast.List(elts=[])),
                                                                        keywords=[],
                                                                        body=[], decorator_list=[])

# Generated at 2022-06-21 17:36:23.178085
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:36:31.884249
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import BaseNodeTransformerTestCase
    from .test_six import test_six_import
    def test(self):
        tree = ast.parse('class A(object): pass')
        expected = ast.parse('class A(_py_backwards_six_with_metaclass(object)):\n    pass')
        tree = MetaclassTransformer().visit(tree)
        self.assertEqual(ast.dump(tree), ast.dump(expected))
    test_six_import(test)
    BaseNodeTransformerTestCase.test_constructor(MetaclassTransformer)

# Generated at 2022-06-21 17:36:33.759373
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:36:34.787931
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:36:42.162786
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from six import PY2
    from typed_ast import ast3 as ast

    class_node = ast.AST(
        body=[ast.ClassDef(
              name='',
              bases=[],
              keywords=[],
              body=[ast.Pass()])],
        type_ignores=[]
    )

    if PY2:
        wanted = ast.Module(
            body=[
                ast.ImportFrom(
                    module='six',
                    names=[ast.alias(
                        name='with_metaclass',
                        asname='_py_backwards_six_withmetaclass')],
                    level=0)
            ] + class_node.body,
            type_ignores=[]
        )

# Generated at 2022-06-21 17:36:43.020363
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:36:54.123741
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    method_text = 'def __new__(cls, *args, **kwargs):\n        return super(A, cls).__new__(cls, *args, **kwargs)\n'
    class_text = 'class A(metaclass = type):\n        ' + method_text
    module_text = 'import bar\nimport baz\n\n' + class_text + '\n'
    node = ast.parse(module_text)
    transformer = MetaclassTransformer()
    output_node = transformer.visit(node)
    assert(output_node.body[0].name == 'six')
    assert(output_node.body[1].name == 'A')
    assert(output_node.body[1].body[0].name == '__new__')
    transformer.finish()

# Generated at 2022-06-21 17:37:02.341303
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("""
                     class A(metaclass=B):
                         pass
                     """, mode='exec')
    MetaclassTransformer().visit(node)


# Generated at 2022-06-21 17:37:07.151146
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:37:10.763321
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import six

    @six.add_metaclass(type)
    class A:
        def m(self):
            self.a = 0
            return 1
    assert A().m() == 1


# Generated at 2022-06-21 17:37:21.895554
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    t = MetaclassTransformer()
    expected = ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\n'
                         'class A(_py_backwards_six_withmetaclass(metaclass, bases)):\n'
                         '    pass\n')
    node = ast.parse('class A(metaclass=metaclass):\n'
                     '    pass\n')
    assert astor.to_source(t.visit(node.body[0])) == astor.to_source(expected.body[-1])


# Generated at 2022-06-21 17:37:33.115790
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3
    from textwrap import dedent
    import sys

    transformer = MetaclassTransformer(sys.version_info, {})
    module = ast3.parse(dedent("""\
    class Test(metaclass=type):
        pass
    """))
    module_new = transformer.visit(module)
    assert transformer._tree_changed  # pylint: disable=protected-access
    assert ast3.dump(module_new) == dedent("""\
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class Test(_py_backwards_six_withmetaclass(type, )):
        pass
    """)

# Generated at 2022-06-21 17:37:34.634708
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:37:43.014568
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    src = """
    class A(metaclass=B):
        pass
    """
    out = """
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    node = ast.parse(src)
    mt = MetaclassTransformer()
    mt.visit(node)
    assert ast.dump(node) == ast.dump(ast.parse(out))

# Generated at 2022-06-21 17:37:48.454850
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    module = ast.parse(dedent('''\
        class A(metaclass=B):
            pass
        '''))
    MetaclassTransformer(package='foo').visit(module)
    
    assert(module.body[1].bases[0].func.id == '_py_backwards_six_withmetaclass')
    assert(module.body[1].bases[0].args[0].id == 'B')


# Generated at 2022-06-21 17:37:50.097728
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:37:53.771200
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = '''class A(metaclass=B):
        pass'''.lstrip()

# Generated at 2022-06-21 17:37:58.498838
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    t = MetaclassTransformer()

    classname = ast.Name(id='A', ctx=ast.Load())
    cls = ast.ClassDef(name=classname,
                       bases=[],
                       body=[],
                       keywords=[])


# Generated at 2022-06-21 17:38:11.158198
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree_compare import assert_ast_is

    node = ast.Module(body=[])
    result = MetaclassTransformer().visit(node)

    expected_import = six_import.get_body()
    assert_ast_is(expected_import, result.body[0])  # type: ignore


# Generated at 2022-06-21 17:38:15.918351
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    from .test_util import roundtrip

    source = """
    class A(metaclass=B):
        pass
    """

    tree = ast.parse(source)
    tree2 = roundtrip(tree, MetaclassTransformer)

    assert str(tree2) == six_import + class_bases("B")

# Generated at 2022-06-21 17:38:19.732171
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse('class Class(object): pass')
    module = MetaclassTransformer().visit(node)
    assert module.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'


# Generated at 2022-06-21 17:38:24.077214
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # Example 1
    example_ast = ast.parse("class A(metaclass=B):\n    pass")
    transformed = MetaclassTransformer().visit(example_ast)

# Generated at 2022-06-21 17:38:26.935495
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast.ast3 import parse
    from typed_ast._ast3 import AST
    from ..transformers import ASTTransformer
    from ..utils.tree import ast_to_str


# Generated at 2022-06-21 17:38:30.666112
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    self = MetaclassTransformer()
    node = ast.parse('''class A(metaclass=B):
        pass''')

    self.visit(node)


    assert node.body[0].keywords == []
    assert isinstance(node.body[0].bases[0], ast.Call)
    assert node.body[0].bases[0].args[0].id == 'B'

# Generated at 2022-06-21 17:38:38.814247
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from six import PY2
    from typed_ast import ast3 as ast
    from .for_loop import ForLoopTransformer

    module = ast.parse("""
        import six
        class A(metaclass=B):
            pass
        """)  # type: ast.Module
    module = MetaclassTransformer.run_pipeline(module)
    if PY2:
        assert module.body[0] == six_import.get_body()[0]
    assert isinstance(module.body[-1], ast.ClassDef)
    class_def = module.body[-1]
    assert class_def.keywords == []
    assert len(class_def.bases) == 1

# Generated at 2022-06-21 17:38:51.480472
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from textwrap import dedent
    from .base import BaseNodeTransformer
    from .six import SixTransformer
    from .utils import compile_source
    import ast

    source = dedent("""\
    class B(metaclass=type):
        pass
    """)

    module = compile_source(source, __name__, [SixTransformer, MetaclassTransformer])
    assert len(module.body) == 2
    assert isinstance(module.body[1], ast.ClassDef)

# Generated at 2022-06-21 17:38:52.456509
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:39:02.793125
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    class DummyTransformer(BaseNodeTransformer):
        _tree_changed = False

        def generic_visit(self, node):
            # type: (ast.AST) -> ast.AST
            return node

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B', ctx=ast.Load()))])


# Generated at 2022-06-21 17:39:27.726897
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test with metaclass
    node = ast.parse('class A(metaclass=B): pass')
    transformer = MetaclassTransformer()
    result = transformer.visit(node)
    assert transformer.tree_changed
    result = ast.dump(result)
    result = result[result.find('class A'):]
    expected = ast.dump(ast.parse('class A(_py_backwards_six_withmetaclass(B)): pass'))[16:]
    assert expected == result

    # Test without metaclass
    node = ast.parse('class A: pass')
    transformer = MetaclassTransformer()
    result = transformer.visit(node)
    assert not transformer.tree_changed
    assert result == node

# Generated at 2022-06-21 17:39:34.985477
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # pylint: disable=missing-docstring
    t = MetaclassTransformer()
    tree = ast.parse('class A(metaclass=B):\n    pass')
    tree = t.visit(tree)
    assert str(tree) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'



# Generated at 2022-06-21 17:39:35.807585
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:39:42.393968
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import ast_util
    from ..ast_util import ast2source
    from typed_ast import ast3
    from typing import List
    from .util import round_trip, UnitTest
    from .util import patch_default_module, path_module

    patch_default_module(path_module(__file__))
    node: ast3.ClassDef = ast.parse(
        'class A(metaclass=B):\n'
        '    pass'
    )
    tree_path: List[str] = ['body']
    transformer = MetaclassTransformer()
    with UnitTest(node, transformer, tree_path):
        transformer.visit(node)
        source = ast2source(node)

# Generated at 2022-06-21 17:39:44.048874
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-21 17:39:54.123864
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typing as t
    from ..utils import parse, dump_code

    def check(code: str, *bases: t.Union[str, t.Tuple[str, ...]], metaclass: str, deprecation_code: int):
        mod = parse(code)
        MetaclassTransformer(version=(2, 7)).visit(mod)
        for base in bases:
            if isinstance(base, str):
                base = (base,)
            assert f"class A({', '.join(base)})" in dump_code(mod)
        assert 'six' in dump_code(mod)
        if deprecation_code == 1:
            assert "DeprecationWarning" in dump_code(mod)
        else:
            assert "DeprecationWarning" not in dump_code(mod)


# Generated at 2022-06-21 17:39:56.375615
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    six_import()
    class_bases(metaclass=ast.Name(id='A'), bases=[ast.Name(id='B')])

# Generated at 2022-06-21 17:40:06.657061
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor      # type: ignore
    from typing import List, Tuple
    assert MetaclassTransformer.dependencies == ['six']
    assert MetaclassTransformer.target == (2, 7)
    assert isinstance(MetaclassTransformer.visit_Module(None, None), ast.Module)
    assert isinstance(MetaclassTransformer.visit_ClassDef(None, None), ast.ClassDef)
    from .base import BaseNodeTransformer
    b = BaseNodeTransformer()
    assert isinstance(MetaclassTransformer.generic_visit(b, None), ast.AST)
    assert b._tree_changed is False
    assert isinstance(MetaclassTransformer.visit(b, None), ast.AST)

# Generated at 2022-06-21 17:40:15.153417
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.testing import assert_source

    src = """
    class A(metaclass=B, **kwargs):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(_py_backwards_six_withmetaclass(B, *[])):
        pass
    """
    tree = ast.parse(src)
    MetaclassTransformer().visit(tree)
    assert_source(tree, expected)


# Generated at 2022-06-21 17:40:22.702892
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class A(object):
        class B(object):
            pass
    tree = ast.parse(dedent("""
        from typing import List
        from six import six_with_metaclass

        class A(object):
            class B(six_with_metaclass(list)):
                pass

        class C(six_with_metaclass(object)):
            pass
            """).strip())
    MetaclassTransformer().visit(tree)
    exec(compile(tree, filename="<ast>", mode="exec"), globals())
    assert isinstance(C, A)

# Generated at 2022-06-21 17:40:59.321843
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import six
    from ast import parse, dump
    from typed_ast import ast27
    from _ast import AST
    if six.PY3:
        assert AST == ast27.AST
        AST = ast27.AST
    code = """class A(metaclass=B):
    pass"""
    node = parse(code)
    transformer = MetaclassTransformer()
    node = transformer.visit(node)
    assert transformer.tree_changed() is True

# Generated at 2022-06-21 17:41:02.356611
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mt = MetaclassTransformer

    assert_equal(mt.target, (2, 7))
    assert_equal(mt.dependencies, ['six'])

# Generated at 2022-06-21 17:41:10.699272
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .. import defaults
    from ..compat import ast27
    from .base import BaseTestParser, BaseTestTransformer


    class TestParser(BaseTestParser):
        def test_metaclass_adds_import(self):
            code = '''class A(metaclass=B): pass'''
            node = self.parse(code)
            self.assertEqual(1, len(node.body))
            self.assertEqual(ast27.Module(body=[ast27.ImportFrom(module='six', names=[ast27.alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0)]),
                             node.body[0])


# Generated at 2022-06-21 17:41:12.041574
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:41:13.911751
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer.__name__ == 'MetaclassTransformer'

# Generated at 2022-06-21 17:41:23.567113
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # Create transformer object
    transformer = MetaclassTransformer()

    # Create sample AST
    ast_node = ast.Module(
        body=[ast.ClassDef(
                  name='A',
                  bases=[],
                  body=[],
                  decorator_list=[],
                  keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))])]
    )

    # Transform AST
    transformer.visit(ast_node)

    # Check that the transformer worked
    assert transformer._tree_changed == True

    # Check the resulting AST

# Generated at 2022-06-21 17:41:29.651980
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import typed_ast.ast3

    class CodegenMixin(object):
        def to_source(self, indent_with=' ' * 4, add_line_information=False):
            generator = typed_ast.ast3.Python3CodeGenerator()
            generator.write_node(self, indent_with=indent_with,
                                 add_line_information=add_line_information)
            return generator.result
    typed_ast.ast3.Module.__bases__ += (CodegenMixin,)


# Generated at 2022-06-21 17:41:36.791262
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import textwrap
    from ..transformer import Py33Fixer
    transformer = Py33Fixer()

    expected = textwrap.dedent('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class Bar(object):
        pass
    ''').strip()
    new = transformer.visit(ast.parse(textwrap.dedent('''
    class Bar(metaclass=object):
        pass
    ''').strip()))
    assert new == ast.parse(expected)



# Generated at 2022-06-21 17:41:49.533781
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.python_source import PythonSource
    from ..utils.ast_pretty_print import pretty_ast

    node = PythonSource("""
        class A(metaclass=B):
            pass
    """).get_ast()

    # No imports
    assert len(node.body) == 1

    # Transform
    transformer = MetaclassTransformer()
    transformer.visit(node)

    # Imports, classes
    assert len(node.body) == 2

# Generated at 2022-06-21 17:41:59.078134
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Setup
    class_node = ast.parse('class A(metaclass=B): pass').body[0]
    # Act
    transformed = MetaclassTransformer().visit(class_node)
    # Verify
    assert transformed.bases == [ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass',
                                                        ctx=ast.Load()),
                                          args=[ast.Name(id='B', ctx=ast.Load())],
                                          keywords=[],
                                          starargs=None,
                                          kwargs=None)]
    assert transformed.keywords == []


# Generated at 2022-06-21 17:43:12.869891
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Program 1:
    # class A(metaclass=B):
    #    pass
    #
    # Compiles to:
    # class A(_py_backwards_six_withmetaclass(B)):
    #    pass
    node = ast.parse("class A(metaclass=B): pass")
    MetaclassTransformer().visit(node)
    result = ast.dump(node, annotate_fields=False, include_attributes=False)


# Generated at 2022-06-21 17:43:15.625473
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    m = MetaclassTransformer()
    assert 'PyBackwards' in m.__repr__()

# Generated at 2022-06-21 17:43:23.335471
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    M = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    transformer = MetaclassTransformer()
    M = transformer.visit(M)
    assert transformer._tree_changed
    assert ast.dump(M) == ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """).body

# Generated at 2022-06-21 17:43:31.497555
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    node = ast.parse("class A(metaclass=B): pass")
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert text(node) == text(ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """))



# Generated at 2022-06-21 17:43:38.114220
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import (
        source_to_ast as to_ast,
        ast_to_source as to_source,
        write_ast_as_module,
        make_temp_directory,
    )
    from ..utils.test_utils import assert_equal_with_printing

    from six import with_metaclass as _py_backwards_six_with_metaclass


# Generated at 2022-06-21 17:43:41.810083
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    test_module = ast.parse('class A(metaclass=int): pass')

# Generated at 2022-06-21 17:43:42.411366
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:43:54.210414
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import os
    import counter, magic_type
    from six.moves import _six_moves
    import _py_backwards_six_with_metaclass
    class A(_py_backwards_six_with_metaclass.B, type, object):
        pass

# Generated at 2022-06-21 17:44:01.737609
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import round_trip
    from ..library import astor
    code = """\
    class A(B, metaclass=C):
        pass
    """
    tree = astor.parse_tree(code)
    round_trip(tree, expected="""\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(C))
        pass
    """)

# Generated at 2022-06-21 17:44:02.848114
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    return MetaclassTransformer