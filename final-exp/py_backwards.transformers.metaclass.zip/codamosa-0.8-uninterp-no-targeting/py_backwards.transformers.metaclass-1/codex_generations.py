

# Generated at 2022-06-21 17:35:18.350082
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # type: () -> None
    from typed_ast import ast3 as ast
    from ..utils.pyversion import PY2
    source = 'class A(): pass'
    node = ast.parse(source)
    MetaclassTransformer().visit(node)
    if PY2:
        assert node.body[0].bases == []
    else:
        assert node.body[0].bases == [ast.Name(id='object', ctx=ast.Load())]

# Generated at 2022-06-21 17:35:29.113122
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():


    class Node(object):
        def __init__(self):
            self.value = None
            self.bases = None
            self.keywords = False

    class Keyword(object):
        def __init__(self):
            self.arg = None

    class List(object):
        def __init__(self):
            self.elts = None

    node = Node()
    keyword = Keyword()
    keyword.arg = '\n            metaclass=Type\n        '
    node.keywords = keyword

    node.bases = List()
    node.bases.elts = ['\n            Node\n        ']

    metaclass = MetaclassTransformer()
    metaclass.visit_ClassDef(node)
    assert not node.keywords
    assert node.bases.el

# Generated at 2022-06-21 17:35:41.378374
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast as pyast
    from ..utils.source import source_to_unicode

    node = pyast.Module(body=[
        pyast.ClassDef(name="A", bases=[], body=[pyast.Pass()], keywords=[pyast.keyword(arg='metaclass', value=pyast.Name(id='B', ctx=pyast.Load()))]),
    ])


# Generated at 2022-06-21 17:35:42.981605
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-21 17:35:46.311606
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:35:55.221304
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    ast_tree = ast.parse('class A(metaclass=B):\n    pass')
    MetaclassTransformer(ast_tree).run()
    assert ast.dump(ast_tree) == 'Module(body=[ImportFrom(module=' \
        '\'six\', names=[alias(name=\'with_metaclass\', asname=\'_py_backwards_six_withmetaclass\')], level=0), ' \
        'ClassDef(bases=[Expr(value=Call(func=Name(id=\'_py_backwards_six_withmetaclass\', ctx=Load()), ' \
        'args=[Name(id=\'B\', ctx=Load())], keywords=[], starargs=None, kwargs=None)), Expr(value=Str(s=\'A\'))], '

# Generated at 2022-06-21 17:36:01.820021
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Test visit_ClassDef method of class MetaclassTransformer."""
    # Create a ClassDef node with metaclass=B
    metaclass = ast.Name(id='B', ctx=ast.Load())
    class_def = ast.ClassDef(name='A', bases=[metaclass], keywords=[])

    # Run method transform of class MetaclassTransformer
    class_def_transformed = MetaclassTransformer.transform(class_def)

    # The transformed class_def should be:
    # class A(_py_backwards_six_with_metaclass(B))
    assert isinstance(class_def_transformed, ast.ClassDef)
    assert class_def_transformed.keywords == []
    assert isinstance(class_def_transformed.bases[0].func, ast.Name)


# Generated at 2022-06-21 17:36:02.497921
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:36:09.847987
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse('''
    class A(metaclass=B, extra='Foo'):
        pass
    ''')
    md = MetaclassTransformer()
    md.generic_visit(node)
    assert '_py_backwards_six_with_metaclass' in astor.to_source(node)
    assert 'extra' not in astor.to_source(node)



# Generated at 2022-06-21 17:36:12.384206
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import parse
    from ..utils.compile import run_code

# Generated at 2022-06-21 17:36:17.903308
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import ast_transformer
    from .test_base import _reset_registry
    _reset_registry()


# Generated at 2022-06-21 17:36:31.124571
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .. import six
    import sys

    class TestMetaclassTransformer(MetaclassTransformer):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._tree_changed = False

    module = ast.parse('''
        class A(metaclass=type):
            pass

        class C(D, metaclass=F):
            pass

        class E:
            __metaclass__ = F
            pass
    ''')

    mocked_six = six.__dict__.copy()
    mocked_six['_py_backwards_six_with_metaclass'] = lambda x, *y: y + (x,)

# Generated at 2022-06-21 17:36:41.076243
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_2to3 import transformer
    from .newstyle import NewStyleTransformer
    class_metadata_transformer = transformer(NewStyleTransformer)
    # Make this function testable by switching contexts
    with _make_context(class_metadata_transformer, MetaclassTransformer, ()) as ctx:
        ctx.visit_Module()

# Generated at 2022-06-21 17:36:52.634651
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_fixtures import FuncDef, ClassDef, Assert, Expr, Import
    from ..utils.test_fixtures import parse_to_FunctionDef, Assign, ImportFrom
    from ..utils.future_unittest import TestCase

    tree = parse_to_FunctionDef("""
    class MyClass(object):
        pass
    """)
    assert_func_body = [ClassDef(name='MyClass', lineno=2, col_offset=4,
                                 keywords=[], bases=[], body=[])]

    mt = MetaclassTransformer()
    mt.visit(tree)


# Generated at 2022-06-21 17:36:58.514181
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import textwrap
    from ..utils.source import source_to_ast

    source = textwrap.dedent("""\
    class Foo(metaclass=type):
        pass
    """)

    ast_ = source_to_ast(source)
    visitor = MetaclassTransformer()
    visitor.visit(ast_)
    expected = six_import.get_body() + class_bases.get_body().body
    assert ast_.body == expected



# Generated at 2022-06-21 17:37:01.439461
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import run_on_lines


# Generated at 2022-06-21 17:37:09.945526
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse('class A(metaclass=object): pass')
    transformer = MetaclassTransformer(2, 7)
    transformer.visit(node)
    assert transformer._tree_changed == True
    assert dump_python_source(node) == 'from six import with_metaclass as _py_backwards_six_withmetaclass; class A(_py_backwards_six_withmetaclass(object)): pass'
    transformer._tree_changed = False
    transformer.visit(node)
    assert transformer._tree_changed == False

# Generated at 2022-06-21 17:37:11.394509
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 17:37:20.209591
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_node = ast.parse(
        """class A(metaclass=B):
               pass
           """
    )
    transformer = MetaclassTransformer()
    tree = transformer.visit(test_node)
    assert transformer._tree_changed

# Generated at 2022-06-21 17:37:33.036752
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source_to_node
    from ..utils.compare_ast import compare_ast, fix_ast

    source = """
        class A(metaclass = B):
            pass

        class C(metaclass = D, e = f):
            pass
        """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

        class C(_py_backwards_six_withmetaclass(D), e = f):
            pass
        """

    source_ast = source_to_node(source)
    MetaclassTransformer().visit(source_ast)
    expected_ast = source_to_node(expected)

# Generated at 2022-06-21 17:37:38.548611
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_node

    m = MetaclassTransformer()

# Generated at 2022-06-21 17:37:40.845064
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    obj = MetaclassTransformer(None)
    assert obj.target == (2, 7)
    assert obj.dependencies == ['six']

# Generated at 2022-06-21 17:37:42.080100
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()

# Generated at 2022-06-21 17:37:49.917970
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Test that six.withmetaclass is imported when visit_Module is called
    # Given
    transformer = MetaclassTransformer()
    node = ast.Module()

    # When
    node = transformer.visit_Module(node)

    # Then
    assert len(node.body) == 1
    assert node.body[0].name == 'six'
    assert node.body[0].asname == '_py_backwards_six'
    assert len(node.body[0].names) == 1
    assert node.body[0].names[0].name == 'withmetaclass'
    assert node.body[0].names[0].asname == '_py_backwards_six_withmetaclass'


# Generated at 2022-06-21 17:37:59.964311
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    global_ns = {}  # type: Dict[str, Any]
    exec(compile(testdata_six_with_metaclass.get_ast(), 'testdata', 'exec'), global_ns)
    global_ns["A"].__module__ = "testdata"
    assert global_ns["A"].__qualname__ == "A"
    metaclass = MetaclassTransformer()
    metaclass.visit(testdata_six_with_metaclass.get_ast())
    
    print('')
    print('INPUT')
    print(testdata_six_with_metaclass.get_source())
    print('')
    print('OUTPUT')
    print(metaclass.get_source(indent_with=' ' * 4, eol='\n'))

   

# Generated at 2022-06-21 17:38:11.604814
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class1 = ast.ClassDef(name='B',
                          bases=[ast.Name(id='object', ctx=ast.Load())],
                          keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='object', ctx=ast.Load()))])
    class2 = ast.ClassDef(name='A',
                          bases=[ast.Attribute(value=ast.Name(id='six', ctx=ast.Load()), attr='with_metaclass', ctx=ast.Load())],
                          keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))])

    with MetaclassTransformer() as t:
        tree = t.visit(ast.Module(body=[class1, class2]))
    


# Generated at 2022-06-21 17:38:21.672886
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils import cst_to_ast

    cst = ("metaclass = 3\n"
           "class A(metaclass=metaclass):\n"
           "    pass")
    cst_node = ast.parse(cst)
    ast_node = MetaclassTransformer().visit(cst_node)

# Generated at 2022-06-21 17:38:24.825544
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer.dependencies == ['six']
    assert MetaclassTransformer.target == (2, 7)


if __name__ == '__main__':
    MetaclassTransformer.main()

# Generated at 2022-06-21 17:38:31.090205
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from typed_ast import ast3 as ast

    class A(object):
        pass

    class B(object, metaclass=A):
        pass

    tree = ast.parse(astor.to_source(B))
    transformer = MetaclassTransformer()
    tree2 = transformer.visit(tree)

    class_node = tree2.body[0].body[0]
    assert len(class_node.bases) == 1
    assert isinstance(class_node.bases[0], ast.List)
    assert class_node.bases[0].elts == []

    assert len(class_node.keywords) == 0

# Generated at 2022-06-21 17:38:38.864952
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astunparse
    import sys

    # Test for the case:
    #        class A(metaclass=B):
    #            pass
    code1 = "class A(metaclass=B):\n    pass"
    tree1 = ast.parse(code1)
    tree1 = MetaclassTransformer().visit(tree1)
    assert astunparse.unparse(tree1) == "from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass"

    # Test for the case:
    #        class A(x, metaclass=B):
    #            pass
    code2 = "class A(x, metaclass=B):\n    pass"
   

# Generated at 2022-06-21 17:38:54.214050
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    t = MetaclassTransformer(None, None)
    module = ast.parse("class A(metaclass=B): pass")
    node = t.visit(module)
    assert node.body[0].lineno == 1 and node.body[0].col_offset == 0, \
        "The code was not inserted at the beginning of the file"
    assert node.body[1].lineno == 1 and node.body[1].col_offset == 0, \
        "The code was not inserted at the beginning of the file"
    assert node.body[2].lineno == 1 and node.body[1].col_offset == 0, \
        "The code was not inserted at the beginning of the file"

# Generated at 2022-06-21 17:39:01.371278
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    cls = '''
    class Foo(metaclass=Bar): pass
    '''
    # When
    tree = ast.parse(cls)
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(tree)
    # Then
    expected = '''
    import six
    
    
    class Foo(_py_backwards_six_withmetaclass(Bar)): pass
    '''
    assert tree_to_string(tree).strip() == expected.strip()

# Generated at 2022-06-21 17:39:03.996861
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str, parse
    from .base import BaseNodeTransformer


# Generated at 2022-06-21 17:39:12.558573
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    raw_code = """
    class A(object, metaclass=B):
        pass
    """
    expected_code = """
    from six import with_metaclass as _py_backwards_six_with_metaclass
    
    class A(_py_backwards_six_with_metaclass(B, object)):
        pass
    """
    module = compile(raw_code, 'py', mode='exec')
    tree = ast.parse(raw_code)
    t = MetaclassTransformer()
    t.visit(tree)
    assert t._tree_changed
    code_expected = compile(expected_code, 'py', mode='exec')
    assert stringify(module) == stringify(code_expected)

# Generated at 2022-06-21 17:39:19.770818
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    @snippet
    def test_snippet():
        class Foo(metaclass=type):
            pass
        # lgtm [py/printing-non-ascii]
        class Bar(object, metaclass=type):
            pass

    old_tree = test_snippet.get_ast()

    expected_new_tree = test_snippet.rewrite(lambda tree: MetaclassTransformer(tree))

    new_tree = MetaclassTransformer(old_tree)
    assert expected_new_tree == new_tree

# Generated at 2022-06-21 17:39:28.604425
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_module = ast.parse("""
    class A(metaclass=B):
        pass
    """)

    transformer = MetaclassTransformer().visit(test_module)
    transformer.body[0].body[0].bases = ast.List(elts=transformer.body[0].body[0].bases)

    expected_module = ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    assert transformer == expected_module

# Generated at 2022-06-21 17:39:38.544213
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Compile:
        class A(metaclass=B):
            pass
    To:
        class A(_py_backwards_six_with_metaclass(B)):
            pass
    """
    from typed_ast import ast3 as ast

    class B:
        pass
    node = ast.ClassDef(
        name='A',
        bases=[],
        body=[],
        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id="B", ctx=ast.Load()))]
    )
    node_copy = copy.copy(node)
    transformer = MetaclassTransformer()
    changed_node = transformer.visit(node)
    assert transformer._tree_changed
    assert len(changed_node.bases) == 1

# Generated at 2022-06-21 17:39:43.558409
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    src = """
        class A(B, metaclass=C):
            pass
        class D(metaclass=C):
            pass
    """
    tree = MetaclassTransformer().visit(ast.parse(src))

# Generated at 2022-06-21 17:39:53.703490
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # type: () -> None
    code = 'class ExampleClass(metaclass=ABCMeta): pass'
    tree = ast.parse(code)
    transform = MetaclassTransformer()
    transform.visit(tree)


# Generated at 2022-06-21 17:39:54.879396
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import run_transformer_on_single_file


# Generated at 2022-06-21 17:40:02.390257
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer()

# Generated at 2022-06-21 17:40:10.189704
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse(textwrap.dedent(
        """\
        class BaseMetaclass(type):
            @classmethod
            def __prepare__(cls, name, bases):
                return {'bar': 'baz'}

        class Meta(BaseMetaclass):
            pass

        class A(metaclass=Meta):
            pass
        """
    ))

    result = MetaclassTransformer.run_pipeline(module)


# Generated at 2022-06-21 17:40:15.200377
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    input_code = """
    class A(metaclass=B):
        pass
    """
    expected_output = """
    class A(with_metaclass(B)):
        pass
    """
    transformer = MetaclassTransformer()
    output_ast = transformer.visit(ast.parse(input_code))
    assert ast.dump(output_ast) == expected_output

# Generated at 2022-06-21 17:40:18.847584
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    src = '''
        
        class A(metaclass=B):
            pass
    '''
    tree = ast.parse(src)
    MetaclassTransformer().visit(tree)
    exec(compile(tree, '<test>', 'exec'))

# Generated at 2022-06-21 17:40:25.784581
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    module = ast.parse('''
    class A(metaclass=B):
        pass

    ''')
    class_ = module.body[0]
    metaclass = class_.keywords[0].value
    class_.bases = class_bases.get_body(metaclass=metaclass, bases=ast.List(elts=class_.bases))
    class_.keywords = []
    expected = astor.to_source(module)

    m = MetaclassTransformer()
    got = astor.to_source(m.visit(module))
    assert got == expected



# Generated at 2022-06-21 17:40:36.173367
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import copy
    import typed_ast.ast3 as ast
    from typed_ast.transforms.six_metaclass import MetaclassTransformer
    from utils import parse
    import six

    class HasMetaclassTest(six.with_metaclass(object)):
        pass

    def assert_transformed_to(code, expected):
        global_namespace = {
            'six': six,
            'HasMetaclassTest': HasMetaclassTest,
        }
        node = parse(code)
        transformer = MetaclassTransformer()
        node = transformer.visit(node)
        if transformer.tree_changed:
            compiled = compile(node, '<string>', 'exec')
            exec(compiled, global_namespace, global_namespace)
        node2 = parse(code)
        transformer

# Generated at 2022-06-21 17:40:45.791982
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a = ast.parse('class A(object):\n    pass\n')
    transformer = MetaclassTransformer()
    node = transformer.visit(a)
    assert str(node) == '\n'.join([
        'import six',
        'from six import with_metaclass as _py_backwards_six_withmetaclass',
        '',
        'class A(_py_backwards_six_withmetaclass(object)):',
        '    pass',
        ]
    )



# Generated at 2022-06-21 17:40:54.642213
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class nMeta(object, metaclass=type):
        pass

    class Meta(type):
        pass

    class Node(with_metaclass(_py_backwards_six_withmetaclass(Meta), nMeta)):
        pass
    n = Node()
    n.__metaclass__ = Meta
    assert isinstance(n, nMeta)
    assert isinstance(n, Meta)

# Generated at 2022-06-21 17:40:55.914254
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import make_module


# Generated at 2022-06-21 17:40:57.577570
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:41:12.678547
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from six import exec_
    import codecs

# Generated at 2022-06-21 17:41:16.331056
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tree = ast.parse('''
        class A(metaclass=B):
            pass''')


# Generated at 2022-06-21 17:41:26.505147
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.ClassDef(name='A', bases=[], body=[], keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))], decorator_list=[])
    node = MetaclassTransformer().visit(node)
    assert len(node.bases) == 1
    assert ast.dump(node.bases[0]) == "Expr(_py_backwards_six_with_metaclass(B), [], [], None)"


# Generated at 2022-06-21 17:41:39.421041
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .six_transformer import SixTransformer
    from .scoped_globals import ScopedGlobalsTransformer
    from .dotted_import import DottedImportTransformer
    from .rename_globals import RenameGlobalsTransformer
    from ..fix import Fix
    from ..codegen import to_source
    from ..utils.test import make_test_python_source

    test_source = make_test_python_source(__file__)
    fixes = Fix.get_fixes(test_source,
                          transformers=[ScopedGlobalsTransformer,
                                        DottedImportTransformer,
                                        MetaclassTransformer,
                                        RenameGlobalsTransformer,
                                        SixTransformer])

# Generated at 2022-06-21 17:41:47.271357
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse('class A(metaclass=B):\n  pass', mode='exec')
    node = node.body[0]
    assert isinstance(node, ast.ClassDef)
    mt = MetaclassTransformer()
    node = mt.visit(node)
    assert mt._tree_changed
    assert isinstance(node.bases[0], ast.Call)
    assert mt.dependencies == ['six']

# Generated at 2022-06-21 17:41:59.636994
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class A(object):
        pass
    class B(metaclass=A):
        pass
    class C(B):
        pass
    class D(metaclass=A, bases=(B, C)):
        pass
    node = MetaclassTransformer().run(ast.parse(inspect.getsource(test_MetaclassTransformer)))
    assert six_import.get_source() in node.body[0].body[0].value.s
    assert class_bases.get_source() in node.body[2].bases[0].args[0].func.value.id
    assert class_bases.get_source() in node.body[3].bases[0].args[0].func.value.id

# Generated at 2022-06-21 17:42:02.003185
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    src = '''class A(metaclass=B):
    pass'''

# Generated at 2022-06-21 17:42:06.529059
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils import parse_ast
    from ..utils.compat import bytes

    file_name = 'test.py'
    transformer = MetaclassTransformer()


# Generated at 2022-06-21 17:42:08.367284
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """
    Test to ensure that the MetaclassTransformer constructor works as it should
    """
    # Should not raise an exception
    MetaclassTransformer()

# Generated at 2022-06-21 17:42:19.399632
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    node = ast.ClassDef(name='A', bases=[], keywords=[ast.keyword(arg='metaclass',
                                                                   value=ast.Name(id='B'))],
                        body=[], decorator_list=[ast.Name(id='_decorator_list')])
    transformer.visit(node)
    assert transformer._tree_changed == True
    assert node.keywords == []
    assert node.bases[0].func.id == '_py_backwards_six_withmetaclass'



# Generated at 2022-06-21 17:42:54.511170
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    from typed_ast import ast3
    from typed_ast_transforms.transforms import MetaclassTransformer

    # Python 2.7 syntax

# Generated at 2022-06-21 17:42:58.511740
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    from .test_transformer import transform_snippet
    from .test_visitor import assert_source


# Generated at 2022-06-21 17:43:03.069142
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import compile_snippet
    mod = compile_snippet('class A(object): pass', MetaclassTransformer)

    class_def = mod.body[0]

    assert len(class_def.bases) == 1
    assert class_def.bases[0].func.id == '_py_backwards_six_with_metaclass'
    assert class_def.bases[0].args[0].id == 'object'

# Generated at 2022-06-21 17:43:04.475148
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """ """
    pass

# Generated at 2022-06-21 17:43:06.579226
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:43:14.513488
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    glob = {}
    exec(MetaclassTransformer.__qualname__ + '.visit_ClassDef', glob)
    visit_ClassDef = glob['visit_ClassDef']
    assert visit_ClassDef(ast.parse('class A(metaclass=B): pass').body[0]) == ast.parse(
        'from six import with_metaclass as _py_backwards_six_withmetaclass;\n'
        'class A(_py_backwards_six_withmetaclass(B)): pass'
    ).body[1]

# Generated at 2022-06-21 17:43:23.367466
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast3
    transformer = MetaclassTransformer()

    code = """class A(object):\n    def __init__(self):\n        pass"""

    tree = ast3.parse(code)
    transformer.visit(tree)

    assert transformer.tree_changed() == False

    code = """class A(metaclass=B):\n    def __init__(self):\n        pass"""

    tree = ast3.parse(code)
    transformer.visit(tree)

    assert transformer.tree_changed() == True

# Generated at 2022-06-21 17:43:32.686966
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .three_to_two import fix_missing_locations
    from ..utils.location import LocationRange
    transformer = MetaclassTransformer(LocationRange.from_single_name('test'))
    new_node = transformer.visit(ast.parse('class A(metaclass=B):\n pass'))
    new_node = fix_missing_locations(new_node)

# Generated at 2022-06-21 17:43:44.882623
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile
    from .. import tree

    six_import.import_name = "six"
    class_bases.function_name = "_py_backwards_six_withmetaclass"

    class_bases.import_name = "_py_backwards_six_withmetaclass"

    source = """\
    class A(metaclass=B):
        pass
    """
    tree = compile(source)

    # test cases
    assert isinstance(tree, ast.Module)
    body = tree.body

    # test six import statement
    assert isinstance(body[0], ast.ImportFrom)
    assert body[0].module == six_import.import_name
    assert body[0].names == [six_import.name]
    assert body[0].level == 0

    # test class statement
   

# Generated at 2022-06-21 17:43:50.532115
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .util import final_pass_fixture, source_fixture
    source = source_fixture('class_meta.py')
    expected = source_fixture('class_meta_expected.py')
    actual = final_pass_fixture(source, (MetaclassTransformer, ))
    assert actual == expected

# Generated at 2022-06-21 17:44:53.967844
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:44:57.944907
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    expected_source = "from six import with_metaclass as _py_backwards_six_with_metaclass\n\n"
    code = "class A(metaclass=B):\n    def __init__(self):\n        pass"
    tree = ast.parse(code)
    node = MetaclassTransformer().visit(tree)
    assert ast.dump(node)[:len(expected_source)] == expected_source


# Generated at 2022-06-21 17:45:03.762699
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    node = ast.parse(six_import.example() + '''
    class A(metaclass=B):
        pass
    ''')
    new_node = MetaclassTransformer().visit(node)
    assert ast.dump(new_node) == '''
    import six
    class A(six.with_metaclass(B)):
        pass
    '''


__all__ = [
    'MetaclassTransformer'
]

# Generated at 2022-06-21 17:45:07.869886
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import compile_source
    from .. import dependencies
    src = 'class A(metaclass=str): pass'
    node = compile_source(src, "fake.py", 'exec')
    assert node.body[0].bases
    assert node.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass' # type: ignore
    assert dependencies(node) == {'six'}