

# Generated at 2022-06-21 17:35:13.401222
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:35:14.788250
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:35:23.965995
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import format_ast
    import textwrap
    test_input = textwrap.dedent("""\
    class Metaclass(object):
        pass

    class X(metaclass=Metaclass):
        pass
    """)
    test_expected_output = textwrap.dedent("""\
    from six import with_metaclass as _py_backwards_six_withmetaclass



    class Metaclass(object):
        pass

    class X(_py_backwards_six_withmetaclass(Metaclass)):
        pass
    """)

# Generated at 2022-06-21 17:35:29.443633
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.data import MODULE_WITH_METACLASSES
    from ..utils.tree import to_ast
    from ..utils.general import to_source_code
    from ..utils.general import compare_source_code

    result = MetaclassTransformer().visit(to_ast(MODULE_WITH_METACLASSES))
    expected = to_ast(six_import.get_source_code() + MODULE_WITH_METACLASSES)

    assert compare_source_code(to_source_code(result), to_source_code(expected))


# Generated at 2022-06-21 17:35:37.693680
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:35:39.443298
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:35:50.895516
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    print('[6to7]: Testing MetaclassTransformer')
    import astor
    source = '''
    class A(metaclass=B):
        pass
    '''
    
    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed, 'Tree is not changed.'

    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''

    assert astor.to_source(tree).strip() == expected.strip(), 'AST is different.'

# Generated at 2022-06-21 17:35:59.755582
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import generate_snippet_ast
    from ..utils.test_utils import expect_same_ast

    tree = generate_snippet_ast('''
    class A(B, metaclass=C):
        pass
    ''')
    six_import_tree = six_import.get_ast()
    class_bases_tree = class_bases.get_ast()

    MetaclassTransformer().visit(tree)

    expect_same_ast(six_import_tree, tree.body[0])
    expect_same_ast(class_bases_tree, tree.body[1].bases[0])

# Generated at 2022-06-21 17:36:11.501247
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.compiler import compile_and_run
    from ..utils.snippet import snippet
    from compile_time_utils import metaclass
    from compile_time_utils import six

    @metaclass(six.text_type)
    class Meta(object):
        pass

    class Parent(six.with_metaclass(Meta, object)):
        pass

    class Child(Parent):
        pass

    @six.add_metaclass(Meta)
    class Child2(Parent, Child):
        pass


# Generated at 2022-06-21 17:36:22.232858
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:36:32.343891
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tree = ast.parse("""class A(metaclass=B): pass""")

    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)
    assert transformer.tree_changed

    exec(compile(new_tree, "<test>", "exec"))

    cls_A = dict(locals())['A']

    # Test custom `__new__` function is defined
    assert "__new__" in dir(cls_A)

    # Test custom `__new__` function is defined
    assert "__prepare__" in dir(cls_A)


# Generated at 2022-06-21 17:36:33.141962
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:36:41.706448
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import (
        assert_invalid,
        assert_invalid_with_msg,
        assert_valid,
        assert_valid_with_msg,
    )
    from .base import BaseSyntaxError
    from .utils import assert_node_unchanged

    # Test when targe=2.7
    visitor = MetaclassTransformer(2.7)
    class_def = ast.parse("class A(object): pass")
    node = visitor.visit(class_def)

# Generated at 2022-06-21 17:36:47.377641
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import unittest
    from ast import parse


# Generated at 2022-06-21 17:36:56.966072
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from astor.code_gen import to_source

    node_1 = ast.parse('''
    class Foo(Bar):
        pass
    ''')
    # append__metaclass_snippet = append__metaclass_snippet.get_body()
    #
    # # for assert_source in
    # assert append__metaclass_snippet == ast.parse('''
    # __metaclass__ = type
    # ''')
    #
    # class_node = node_1.body[0]
    # class_node.keywords = [ast.kwarg('__metaclass__', ast.Name(id='type'))]
    #
    # node_2 = ast.parse(to_source(node_1), filename='<ast>')
    #
    # #

# Generated at 2022-06-21 17:36:58.396816
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor


# Generated at 2022-06-21 17:36:59.568921
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3


# Generated at 2022-06-21 17:37:06.458579
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast as pyast
    snippet_tree = six_import.get_tree()
    node = pyast.parse(snippet_tree.decode('utf-8'))
    new_node = MetaclassTransformer().visit_Module(node)
    assert new_node == node


# Generated at 2022-06-21 17:37:15.664586
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # 1. Setup
    node = ast.parse('''
    import six

    class A(metaclass=B):
        pass
    ''')

    # 2. Exercise
    transformer = MetaclassTransformer()
    transformed_node = transformer.visit_Module(node)

    # 3. Verify
    assert transformer.changed
    assert transformer.dependencies == ['six']

# Generated at 2022-06-21 17:37:25.824463
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # This needs to be in a func to prevent syntax errors on 2.6
    class_def = ast.parse("class A(metaclass=type): pass").body[0]
    assert isinstance(class_def, ast.ClassDef)
    assert class_def.keywords[0].value == ast.Name(id='type')

    class_def = MetaclassTransformer().visit(class_def)
    assert isinstance(class_def, ast.ClassDef)
    assert not class_def.keywords
    assert isinstance(class_def.bases[0].func, ast.Attribute)
    assert class_def.bases[0].func.attr == '_py_backwards_six_withmetaclass'
    assert isinstance(class_def.bases[0].args[0], ast.Name)
   

# Generated at 2022-06-21 17:37:29.471983
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-21 17:37:35.044048
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
	s = "class A(metaclass=object): pass"
	t = ast.parse(s)
	node = t.body[0]
	assert node.keywords[0].value.id == "object"
	res = MetaclassTransformer().visit_ClassDef(node)
	assert node.bases[0].func.id == "_py_backwards_six_withmetaclass"
	assert node.bases[0].args[0].id == "object"


# Generated at 2022-06-21 17:37:37.611892
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal_source

# Generated at 2022-06-21 17:37:44.681243
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    with six_import():
        with class_bases() as bases:
            tree = ast.parse('''
                class A(metaclass=B):
                    pass
            ''')
            node = tree.body[0]
            assert isinstance(node, ast.ClassDef)
            assert len(node.keywords) == 1
            transformer = MetaclassTransformer()
            transformer.visit(tree)
            assert node.bases[0] == bases.get()
            assert len(node.keywords) == 0
            # assert transformer._tree_changed



# Generated at 2022-06-21 17:37:51.424344
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    c = MetaclassTransformer()
    module = ast.parse('class A(metaclass=B): pass')
    module = c.visit(module)
    assert(c._tree_changed)
    assert(str(module) ==
            "from six import with_metaclass as _py_backwards_six_withmetaclass\n" +
            "\n" +
            "class A(_py_backwards_six_withmetaclass(B)):\n" +
            "    pass\n")


# Generated at 2022-06-21 17:37:59.138956
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import textwrap
    module_node = ast.parse(textwrap.dedent('''\
        class A(metaclass=B):
            pass
        '''))
    MetaclassTransformer.visit(module_node)
    expected_node = ast.parse(textwrap.dedent('''\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        '''))
    assert ast.dump(module_node) == ast.dump(expected_node)


# Generated at 2022-06-21 17:37:59.518394
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:37:59.864767
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:38:11.604605
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import parse

    from ..utils.context import Context
    ctx = Context()
    ctx.add_lookup('six')

# Generated at 2022-06-21 17:38:21.673657
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import typing
    import unittest

    import astunparse
    import gast
    from typed_ast import ast3 as ast

    from ..utils.snippet import snippet
    from .base import _BaseTestCase

    # type: typing.Type[ast.AST]
    ast_class = getattr(gast, 'AST' if sys.version_info.minor < 8 else 'Node')

    # test_MetaclassTransformer_visit_ClassDef_get_body

    def get_body():
        class A(metaclass=B):
            pass

    # test_MetaclassTransformer_visit_ClassDef_expected_body

    def expected_body():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    # test_MetaclassTransformer

# Generated at 2022-06-21 17:38:30.943868
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.compiler import compile

    class Foo(object):
        pass

    node = ast.parse(source(Foo, version=(2, 7)))
    compile(node, version=(2, 7))

    transformer = MetaclassTransformer(node)
    transformer.visit(node)

    assert source(node) == dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class Foo(_py_backwards_six_withmetaclass(object)):
        pass
    """)

# Generated at 2022-06-21 17:38:41.481626
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import BaseTestTransformer
    from ..utils.codegen import to_source
    from ..utils.source import Source
    from ..utils.tree import get_element_at
    from ..utils.errors import ParseError
    from ..utils.log import logger
    import unittest
    
    
    
    class TestMetaclassTransformer(unittest.TestCase):
        def test_simple(self):
            source = """
            class A(object):
                pass
                
            class B(metaclass=type):
                pass
            """
            expected = """
            class A(object):
                pass
    
    
            class B(_py_backwards_six_withmetaclass(type, object)):
                pass
            """
            source = Source(source, "test.py")

# Generated at 2022-06-21 17:38:46.949183
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class Context:
        tree_changed = False

    t = MetaclassTransformer(Context())
    assert t.target == (2, 7)
    assert t.source == (3, 0)
    assert isinstance(t, BaseNodeTransformer)



# Generated at 2022-06-21 17:38:52.555686
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    
    # from six import with_metaclass as _py_backwards_six_withmetaclass
    expected_code_from_six_import = 'from six import with_metaclass as _py_backwards_six_withmetaclass'

    # _py_backwards_six_withmetaclass(metaclass, *bases)
    expected_code_from_class_bases_get_body = '_py_backwards_six_withmetaclass(metaclass, *bases)'

    # class A(metaclass=B):
    #     pass

# Generated at 2022-06-21 17:38:54.727727
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # type: () -> None
    assert MetaclassTransformer(None).__class__.__name__ == "MetaclassTransformer"


# Generated at 2022-06-21 17:39:06.002669
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_utils import make_module

# Generated at 2022-06-21 17:39:11.823394
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source

    class SampleTransformer(BaseNodeTransformer):
        pass

    code = '''
    class A(object):
        pass

    class B(metaclass=C):
        pass
    '''

    for version in (2, 7):
        tree = ast.parse(code)
        transformer = SampleTransformer()
        transformer.visit(tree)
        assert source(tree) == '''
    class A(object):
        pass

    class B(object):
        pass
    ''', version

# Generated at 2022-06-21 17:39:23.050405
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    tree = ast.parse(test)
    node = tree.body[0]
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        tree = MetaclassTransformer.run(tree)
        assert len(w) == 1
        assert ("backwards-compatibility with Python 2. The 2to3 "
                "transformer was disabled.") in str(w[0].message)
    expected_tree = ast.parse(expected)

# Generated at 2022-06-21 17:39:29.088993
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():

    @snippet
    def target_before():
        class A(metaclass=B):
            pass

    @snippet
    def target_after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

    assert str(transform(target_before, MetaclassTransformer)) == \
        str(target_after)

# Generated at 2022-06-21 17:39:38.945134
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .. import parse_module
    from ..utils.ast_helpers import get_node
    from ..utils.six import text_type
    from ..utils.visitor import print_visitor, assert_visitor

    source = parse_module(__file__, 'class.6.py')
    transformer = MetaclassTransformer()
    target = parse_module(__file__, 'class.7.py')

    transformed = transformer.run(source)
    print_visitor(transformed)

    assert_visitor(transformed, target)

    # test deserialization from json
    json_transformer = MetaclassTransformer.from_json(transformer.to_json())
    assert transformer.to_json() == json_transformer.to_json()

    assert text_type(transformed) == text_type(target)

# Generated at 2022-06-21 17:39:57.286268
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    # For a class that uses python 2.6 syntax
    class_ = ast.ClassDef(name='A',
            bases=[
                ast.Name(id='B', ctx=ast.Load())
                ],
            body=[
                ast.Pass(),
                ],
            decorator_list=[],
            keywords=[],
            lineno=1,
            col_offset=12)

# Generated at 2022-06-21 17:40:07.921032
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # pylint: disable=line-too-long
    code = '''class A(metaclass=B, something=else):
        pass
    '''
    tree = ast.parse(code)
    MetaclassTransformer().visit(tree)
    expected = '''from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass A(_py_backwards_six_withmetaclass(B, *[])):\n    pass'''
    assert expected == astor.to_source(tree)

    code = '''class A(metaclass=B, something=else):
        pass
    '''
    tree = ast.parse(code)
    MetaclassTransformer().visit(tree)

# Generated at 2022-06-21 17:40:19.138805
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from py_backwards.utils.tree import parse
    from ..unittest_tools import assert_code_equal
    from .lambda_transformer import LambdaTransformer
    from .unpacking_transformer import UnpackingTransformer
    from .power_transformer import PowerTransformer
    from .division_transformer import DivisionTransformer
    from .print_transformer import PrintTransformer
    from .raise_transformer import RaiseTransformer
    from .assert_transformer import AssertTransformer
    from .exec_transformer import ExecTransformer
    from .non_local_transformer import NonLocalTransformer
    from .metaclass_transformer import MetaclassTransformer

    sample = """
        class A(metaclass=B):
            pass
        """

# Generated at 2022-06-21 17:40:25.731355
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    from ..utils.ast_helpers import assert_source

    s = six_import.get_source()

    class DummyTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            insert_at(0, node, six_import.get_body())
            return self.generic_visit(node)  # type: ignore

    class_def = ast.ClassDef(name='A',
                             bases=[],
                             body=[],
                             keywords=[],
                             decorator_list=[])


# Generated at 2022-06-21 17:40:35.570549
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast
    import named_ast
    import textwrap
    source = textwrap.dedent("""\
    class A(object):
        pass
    class B(metaclass=A):
        pass
    """)
    expected = textwrap.dedent("""\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(object):
        pass
    class B(_py_backwards_six_withmetaclass(A)):
        pass
    """)
    module_ast = named_ast.parse(source)
    MetaclassTransformer().visit(module_ast)
    actual = named_ast.dump(module_ast)
    assert actual == expected
    print(actual)

# Generated at 2022-06-21 17:40:39.233761
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    m = ast.parse('class A(object): pass').body[0]
    t = MetaclassTransformer()
    r = t.visit(m)
    assert r.body[0].name == 'six'
    assert r.body[1] is m


# Generated at 2022-06-21 17:40:50.597620
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    # Given
    node = ast.ClassDef(name="A",
                        bases=[ast.Name(id="object", ctx=ast.Load())],
                        keywords=[ast.keyword(arg="metaclass",
                                              value=ast.Name(id="B", ctx=ast.Load()))])
    transformer = MetaclassTransformer()

    # When
    result = transformer.visit_ClassDef(node=node)

    # Then
    assert result.bases == ast.List(elts=class_bases.get_body(metaclass=ast.Name(id="B", ctx=ast.Load()),
                                                              bases=[ast.Name(id="object", ctx=ast.Load())]).args)
    assert result.keywords == []


# Generated at 2022-06-21 17:40:51.424419
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:40:58.818485
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    from ..utils.ast_builder import ast_builder

    src = "class A(metaclass=B): pass"
    tree = ast_builder.string_build(src, __name__, __file__)
    transformer = MetaclassTransformer()
    transformed = transformer.visit(tree)
    assert transformer._tree_changed is True

# Generated at 2022-06-21 17:41:06.069033
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import textwrap

    node = ast.parse(
        textwrap.dedent('''\
        class A(metaclass=B):
            pass
        ''')
    )
    MetaclassTransformer(node)
    assert ast.dump(node) == \
        'Module(body=[Import(names=[alias(name="six", asname=None)])], type_ignores=[])'

# Generated at 2022-06-21 17:41:23.318307
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-21 17:41:31.993642
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.fake import FakeParser
    from ..utils.compat import python_version, bytes_
    fp = FakeParser()

    transformer = MetaclassTransformer()
    if python_version < (3, 7):
        tree = fp.parse("""class A(metaclass=B):\n    pass\n""")

# Generated at 2022-06-21 17:41:34.025188
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 17:41:42.374465
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    src = "class Test(metaclass=abc.ABCMeta): pass"
    dest = six_import.get_body()
    dest.append(class_bases.get_body(metaclass=ast.Name(id='abc.ABCMeta', ctx=ast.Load()), bases=ast.List(elts=[], ctx=ast.Load())))
    dest = ast.Module(body=dest)
    actual = compile(src, '<string>', 'exec')
    actual = ast.parse(src)
    actual = MetaclassTransformer().visit(actual).body[0]
    actual = ast.fix_missing_locations(actual)  # type: ignore
    assert codegen.to_source(dest) == codegen.to_source(actual)

# Generated at 2022-06-21 17:41:49.437863
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    node = ast.parse(code)
    result = MetaclassTransformer().visit_Module(node)
    result_code = compile(result, '<string>', 'exec')
    exec(result_code)
    result_code = result_code.co_consts[1]
    assert code_equal(result_code, expected)

# Generated at 2022-06-21 17:41:56.858881
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    this = MetaclassTransformer({}, (2, 7))
    assert (this._tree_changed is False)

# Generated at 2022-06-21 17:42:00.556419
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class A(metaclass=type):
        pass

    expected = '''\
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(type)):
        pass
    '''
    node = ast.parse(textwrap.dedent(inspect.getsource(A)))
    assert MetaclassTransformer().visit(node) == ast.parse(expected)

# Generated at 2022-06-21 17:42:03.754353
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    from ..utils.testutils import check_ast

    ast_str = 'class A(metaclass=B): pass'

# Generated at 2022-06-21 17:42:11.431830
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    nodes = [
        ast.ClassDef(name="A", 
            bases=[[
                ast.Name(id="metaclass", ctx=ast.Load)]],
            keywords=[ast.keyword(arg="metaclass", value=ast.Name(id="B", ctx=ast.Load))
            ],
            body=[ast.Pass()]
        )
    ]
    module = ast.Module(body=nodes)

# Generated at 2022-06-21 17:42:22.106078
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    ast_tree = ast.Module(body=[ast.ClassDef(name='A', bases=[],
                                             keywords=[ast.keyword(arg='metaclass',
                                                                    value=ast.Name(id='B', ctx=ast.Load()))],
                                             body=[], decorator_list=[])])


# Generated at 2022-06-21 17:43:04.910129
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import os

    if sys.version_info[:2] == (2, 7):
        import six
        from astunparse import dump
        from typed_ast import ast3 as ast
        from typed_ast import ast27 as ast2
        from typed_ast.transforms import MetaclassTransformer

        def _print_result(tree):
            import six
            print(six.text_type(dump(tree)))

        def test_six_import_transformer(tree):
            tree = MetaclassTransformer().visit(tree)
            _print_result(tree)
            return tree

        module = """
        class Foo(Bar):
            pass
        """
        tree = ast2.parse(module)
        test_six_import_transformer(tree)
        assert tree is not None

# Generated at 2022-06-21 17:43:13.197248
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    class MyTest(unittest.TestCase):
        def transform(self, source: str) -> str:
            root = ast.parse(source)
            MetaclassTransformer(debug=False).visit(root)
            return compile(root, '<string>', 'exec').co_code.co_consts[1].co_lnotab[0]  # type: ignore

    test = MyTest()
    assert test.transform("class A(): pass") == b'\x00\t\x00\n'
    assert test.transform("class A(metaclass=type): pass") == b'\x00\t\x00\n'

# Generated at 2022-06-21 17:43:19.703327
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .fixtures.simple_classdef import node, expected_node

    t = MetaclassTransformer('2.7')
    new_node = t.visit(node)

    assert ast.dump(new_node) == ast.dump(expected_node)

# Generated at 2022-06-21 17:43:22.215060
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..compile import compile_
    from ..visitor import dump

    class Dummy(ast.NodeVisitor):
        pass

    class DummyCompiler(BaseNodeTransformer):
        transformer = Dummy()


# Generated at 2022-06-21 17:43:25.650331
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from collections import OrderedDict

    # A class that uses metaclass keyword

# Generated at 2022-06-21 17:43:33.441153
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_visitor import source_to_module
    import six
    import astor

    source = """
    class A(metaclass=int):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(int, object)):
        pass
    """
    module = source_to_module(source)
    assert module is not None
    transformer = MetaclassTransformer()
    transformer.visit(module)
    assert six.PY3 and astor.to_source(module).strip() == expected

# Generated at 2022-06-21 17:43:45.192657
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    mt = MetaclassTransformer()
    tree = ast.parse("class A(metaclass=B): pass")
    mt.visit(tree)
    assert mt._tree_changed

# Generated at 2022-06-21 17:43:50.776457
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test import snippet_to_test, test_to_program
    module = ast.parse(snippet_to_test(MetaclassTransformer.visit_Module))
    assert module == test_to_program(MetaclassTransformer.visit_Module)


# Generated at 2022-06-21 17:43:53.344196
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    MetaclassTransformer.test(
        'class C(metaclass=A):\n    pass',
        'class C(_py_backwards_six_withmetaclass(A)):\n    pass'
    )



# Generated at 2022-06-21 17:44:02.864257
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    #from typed_ast import ast3 as ast
    from ...utils.helpers import parse, compare_trees
    import six
    import ast as pyast

    x = six.with_metaclass('B')

    tree = parse('''class A(metaclass=B):
                        pass''')

    tree2 = parse('''from six import with_metaclass as _py_backwards_six_withmetaclass
                    class A(_py_backwards_six_withmetaclass(B))''')
    MetaclassTransformer.visit(tree)
    assert compare_trees(tree, tree2)
