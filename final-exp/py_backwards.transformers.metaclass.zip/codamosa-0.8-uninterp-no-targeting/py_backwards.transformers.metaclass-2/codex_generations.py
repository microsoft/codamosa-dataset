

# Generated at 2022-06-21 17:35:07.520926
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from unittest import TestCase
    from ..utils.codegen import codegen
    from .. import base


# Generated at 2022-06-21 17:35:18.117386
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    node = ast.parse('class A(metaclass=A): pass')
    MetaclassTransformer().visit(node)
    assert ast.dump(node) == "Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='A', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='A', ctx=Load())], keywords=[])], body=[Pass()], decorator_list=[])])"

# Generated at 2022-06-21 17:35:19.974056
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:35:28.661951
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import ast_builder
    from ..utils.python import parse_snippet
    
    original_ast = parse_snippet('class A(metaclass=B):pass')
    tree_transformer = MetaclassTransformer()
    transformed_ast = tree_transformer.visit(original_ast)

    assert_that(ast_builder.AstBuilder(transformed_ast).ast_is_equal_to(
        """
        _py_backwards_six_withmetaclass(B,object)
        class A(_py_backwards_six_withmetaclass(B,object)):
            pass
        """
    ))

# Generated at 2022-06-21 17:35:34.671274
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source: str = 'class A(metaclass=B):\n    pass'
    tree: ast.Module = ast.parse(source)

# Generated at 2022-06-21 17:35:42.264942
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    m = ast.parse("class A(metaclass=B): pass")
    node = m.body[0]
    assert isinstance(node, ast.ClassDef)

    assert node.keywords[0].value.id == 'B'
    MetaclassTransformer.visit_Module(MetaclassTransformer(), m)

    assert m.body[0].value.args[0].id == 'B'
    assert len(m.body) == 2
    assert isinstance(m.body[0], ast.Expr)
    assert isinstance(m.body[0].value, ast.Call)

# Generated at 2022-06-21 17:35:53.189577
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    m = ast.parse(
            """
            class MC(type):
                pass
            class C(object, metaclass=MC):
                pass
            """
    )
    m2 = MetaclassTransformer().visit(m)

# Generated at 2022-06-21 17:35:58.249661
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test the way the node ClassDef is processed in the method visit_ClassDef of class MetaclassTransformer
    node = ast.parse("class A(metaclass=B): pass")
    MetaclassTransformer().visit(node)
    print(ast.dump(node))
    expected = ast.parse(
        """class A(_py_backwards_six_withmetaclass(B)):
            pass""")
    assert ast.dump(node) == ast.dump(expected)



# Generated at 2022-06-21 17:36:02.014919
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    myClass = MetaclassTransformer()
    assert repr(myClass) == "<MetaclassTransformer({'six'})>"

# Generated at 2022-06-21 17:36:12.312842
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    six_import_snippet = six_import.get_body()[0]
    mcls_snippet = class_bases.get_body(metaclass=ast.Name(id='doge', ctx=ast.Load()),
                                        bases=ast.List(elts=[], ctx=ast.Load()))[0]
    code = """
        class Bar:
            pass

        class Foo(Bar, doge=Bar):
            pass
    """
    tree = ast.parse(code)
    MetaclassTransformer.run_default(tree)
    assert len(tree.body) == 3
    assert isinstance(tree.body[0], ast.Expr)
    assert ast.dump(tree.body[0]) == ast.dump(six_import_snippet)
    assert ast.dump

# Generated at 2022-06-21 17:36:22.049861
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    six_import_s = six_import.get_body()
    body = [
        ast.Expr(six_import_s),
        ast.Assign(
            targets=[ast.Name(id='foo', ctx=ast.Store())],
            value=ast.Name(id='bar', ctx=ast.Load())
        )
    ]
    node = ast.Module(body=body)
    transformer = MetaclassTransformer()
    res = transformer.visit_Module(node)

    assert transformer._tree_changed
    assert six_import_s in res.body


# Generated at 2022-06-21 17:36:24.469096
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast as pyast
    from ..transformer import Transformer


# Generated at 2022-06-21 17:36:33.617838
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import unittest
    from ...testing import fix, run_all_tests
    from ...testing.utils import assert_equal

    class BogusMetaClass(object):
        pass

    class Test(unittest.TestCase):
        def test(self):
            tree = ast.parse("class A(metaclass=BogusMetaClass): pass")
            node = tree.body[0]
            node_transformed = MetaclassTransformer().visit_ClassDef(node)
            expected = ast.parse("class A(_py_backwards_six_withmetaclass(BogusMetaClass)): pass")
            assert_equal(expected, node_transformed)
            assert_equal(True, node_transformed is not node)

    run_all_tests(__name__, [Test])


# Unit

# Generated at 2022-06-21 17:36:36.627677
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_string

    source = """class A(metaclass=B): pass"""

# Generated at 2022-06-21 17:36:40.349492
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ...tests.fixtures import make_test_case
    from ...tests.fixtures import e2l_test_case

    test_case = make_test_case({
        'with_metaclass.py': """\
            class A(metaclass=B):
                pass
            """
    })

    e2l_test_case(test_case, MetaclassTransformer)

# Generated at 2022-06-21 17:36:42.398289
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    from ast import parse


# Generated at 2022-06-21 17:36:45.640600
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys  # type: ignore
    sys.exit() if six.PY3 else sys.exit(0)  # type: ignore

# Generated at 2022-06-21 17:36:54.548354
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..unitutil.snippet import snippet
    from ..unitutil.file_snippet import file_snippet
    from ..unitutil import ASTTester
    import ast

    code = snippet(
        """
        class A(metaclass=B):
            pass
        """
    )
    expected = snippet(
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        
        class A(_py_backwards_six_with_metaclass(B)):
            pass
        """
    )
    result = file_snippet(code, target=(2, 7))
    ASTTester(result, expected).assert_matches()

# Generated at 2022-06-21 17:36:58.074460
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.fake import FakeFile
    from ..utils.test_utils import transform


# Generated at 2022-06-21 17:37:06.320871
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typing import Dict
    from typed_ast import ast3 as ast

    from .test_ClassTransformer import class_transformer, build_class_def
    from .test_LineTransformer import line_transformer, build_num

    class NodeBuilder:
        _mappings: Dict[str, ast.AST] = {}

        @classmethod
        def reset(cls):
            cls._mappings = {}

        @classmethod
        def build(cls, node: ast.AST):
            if isinstance(node, (ast.Name, ast.Num)):
                return node

            if isinstance(node, ast.keyword):
                return node

            if isinstance(node, ast.Expr):
                return ast.Expr(value=cls.build(node.value))


# Generated at 2022-06-21 17:37:23.453422
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from textwrap import dedent
    from .utils import dedent_source
    from ..utils.ast import generate_ast, parse_ast
    test_code = dedent(
        """
        class A(metaclass=Name):
            pass
        class B(metaclass=Name, object):
            pass
        class C(Name, metaclass=Name, object):
            pass
        class D(object, Name, metaclass=Name):
            pass
        class E(Name, object, metaclass=Name):
            pass
        class F(object, metaclass=Name, Name):
            pass""")

# Generated at 2022-06-21 17:37:33.198468
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class_node = ast.parse(
        """
            class A(metaclass=B):
                pass
            """
    )
    transformed_class = MetaclassTransformer().visit(class_node)

    assert(transformed_class is not None)

    expected_class = ast.parse(
        """
        class A(_py_backwards_six_withmetaclass(B, object)):
            pass
        from six import with_metaclass  as _py_backwards_six_withmetaclass"""
    )

    assert(ast.dump(transformed_class) == ast.dump(expected_class))

# Generated at 2022-06-21 17:37:42.721682
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import xfail_py2_no_six
    import astor
    tree = ast.parse("""
    class A(metaclass=B):
        pass
    class B(metaclass=C):
        pass
    """)

    node = MetaclassTransformer().visit(tree)
    xfail_py2_no_six()

# Generated at 2022-06-21 17:37:50.872100
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse('\n'.join([
        "class A(metaclass=types.new_class('A'),):",
        '    pass',
    ]))
    transformer = MetaclassTransformer()
    transformed_tree = transformer.visit(tree)
    assert transformer.tree_changed == True

# Generated at 2022-06-21 17:37:56.194427
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    It should convert single-inheritance classes with a metaclass to a six.with_metaclass call
    """
    from typed_ast import ast3 as ast
    
    class_stmt = ast.ClassDef(name='A',
                              bases=[ast.Name(id='object', ctx=ast.Load())],
                              keywords=[ast.keyword(arg='metaclass',
                                                    value=ast.Name(id='B', ctx=ast.Load()))],
                              body=[], decorator_list=[])
    

# Generated at 2022-06-21 17:38:00.837544
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    meta = MetaclassTransformer()
    # Simple class declaration
    node = ast.parse("class A(): pass")
    meta.visit(node)
    six = ast.parse(six_import.source)
    class A(ast.ClassDef):
        name = 'A'
        body = list()
        decorator_list = list()
        bases = list()
    assert node.body == six.body + [A()]



# Generated at 2022-06-21 17:38:03.562081
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typing
    import astor
    class Test(typing.NamedTuple):
        code: str
        expected: ast.AST

# Generated at 2022-06-21 17:38:15.159332
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert_equal(
        MetaclassTransformer().visit(ast.parse("""
            class Class(object):
                pass
        """)),
        ast.parse("""
            from six import with_metaclass as _py_backwards_six_withmetaclass

            class Class(_py_backwards_six_withmetaclass(object, )):
                pass
        """)
    )

    assert_equal(
        MetaclassTransformer().visit(ast.parse("""
            class Class(metaclass=object):
                pass
        """)),
        ast.parse("""
            from six import with_metaclass as _py_backwards_six_withmetaclass

            class Class(_py_backwards_six_withmetaclass(object, )):
                pass
        """)
    )

# Generated at 2022-06-21 17:38:18.783194
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    t = MetaclassTransformer({})
    node = ast.parse('class A(metaclass=int): pass')

# Generated at 2022-06-21 17:38:25.427603
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .unittest_tools import assert_transformation, get_node, get_source
    from typed_ast import ast3 as ast

    source = """
    class Test:
        def __init__(self):
            self.value = 1
    """
    expected = """
    class Test(_py_backwards_six_withmetaclass(B))
        def __init__(self):
            self.value = 1
    """
    node = get_node(source, version=(2, 7))
    assert_transformation(
        MetaclassTransformer, node, expected,
    )

# Generated at 2022-06-21 17:38:37.547704
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class A(metaclass=Foo):  # type: ignore
        pass



# Generated at 2022-06-21 17:38:43.658379
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast
    import typed_astunparse
    transformer = MetaclassTransformer()
    node = ast.parse("class A(metaclass=B): pass", version=(2, 7))
    transformer.visit(node)


# Generated at 2022-06-21 17:38:55.515045
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.Module(body=[ast.ClassDef(name='Test',
                                           bases=[],
                                           keywords=[ast.keyword(arg='metaclass',
                                                                 value=ast.Name(id='B'))],
                                           body=[])])
    transformer = MetaclassTransformer()
    transformer.visit(module)
    assert transformer._tree_changed

    six_import_node = ast.Import(names=[ast.alias(name='six',
                                                 asname=None)])
    assert module.body[0] == six_import_node


# Generated at 2022-06-21 17:38:56.455919
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:39:03.618258
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    c = MetaclassTransformer()
    assert c.visit_ClassDef(ast.parse("class A(metaclass=B):\n    pass").body[0])  # type: ignore
    assert c.visit_ClassDef(ast.parse("class A(metaclass=B, object):\n    pass").body[0])  # type: ignore
    assert c.visit_ClassDef(ast.parse("class A():\n    pass").body[0])  # type: ignore

# Generated at 2022-06-21 17:39:12.854827
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """
    Test transforming
        class A(metaclass=B):
            pass
    To:
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_with_metaclass(B))
    """
    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[])
    module = ast.Module(body=[class_def])

    result = MetaclassTransformer().visit(module)
    assert isinstance(result, ast.Module)
    print(ast.dump(result))


# Generated at 2022-06-21 17:39:17.313211
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """ Tests the constructor of class MetaclassTransformer. """
    obj = MetaclassTransformer()
    assert obj.dependencies == ['six']
    assert obj.target == (2, 7)
    assert isinstance(obj, BaseNodeTransformer)
    assert not hasattr(obj, '_tree_changed')


# Generated at 2022-06-21 17:39:28.904412
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..ast import meta
    from ..convert import fix_missing_locations
    from typed_ast.ast3 import parse
    from ..utils.ast_visitor import AstVisitor
    from typing import List

    code = '''class A(object, metaclass=B):
    pass
    
    if True:
        class C(object):
            pass
        '''

    node = parse(code)

    class V(AstVisitor):
        def __init__(self):
            super().__init__()
            self.classes = []  # type: List[ast.ClassDef]

        def visit_ClassDef(self, node):
            self.classes.append(node)

    visitor = V()
    visitor.visit(node)

    original_class_a = visitor.classes[0]  # type: ast

# Generated at 2022-06-21 17:39:35.845392
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast as python_ast

    source = '''
    class A(metaclass=B):
        pass
    '''
    expected_snippet = '''\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''

    tree = python_ast.parse(source)
    assert MetaclassTransformer().visit(tree) == expected_snippet

# Generated at 2022-06-21 17:39:36.745291
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor

# Generated at 2022-06-21 17:40:04.532664
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_transform
    from typed_ast import ast3

    assert_transform(
        MetaclassTransformer,
        """
        class A(object, metaclass=B):
            pass
        """,
        """
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    )

    assert_transform(
        MetaclassTransformer,
        """
        class A(object, metaclass=B):
            def __init__(self):
                pass
        """,
        """
        class A(_py_backwards_six_withmetaclass(B)):
            def __init__(self):
                pass
        """
    )


# Generated at 2022-06-21 17:40:08.573446
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    source = """class A(metaclass=B):
    pass"""
    tree = ast.parse(source)
    transformer.visit(tree)

# Generated at 2022-06-21 17:40:11.411031
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()

# Generated at 2022-06-21 17:40:15.595806
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_utils import transform

    assert transform(MetaclassTransformer, "class A(metaclass=B): pass") == \
        six_import() + '\n' + \
        "class A(with_metaclass(B)):\n    pass"

# Generated at 2022-06-21 17:40:24.995954
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTest, Snippet
    from ..utils.tree import is_equal


# Generated at 2022-06-21 17:40:35.689574
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import source_to_module
    from .six import SixTransformer
    from .utils import ModuleTransformer
    from .six_import import SixImportTransformer

    code = six_import.get_body() + 'class A(object):pass'
    module = source_to_module(code)
    module = ModuleTransformer(
        transformers=[SixTransformer, SixImportTransformer, MetaclassTransformer]).visit(module)

    class_def = module.body[1]
    assert class_def.keywords == []
    assert code_equal(class_def.bases[0], class_bases.get_body(metaclass=ast.Name(
        id='object', ctx=ast.Load()), bases=ast.List(elts=[])))



# Generated at 2022-06-21 17:40:36.490297
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:40:49.228005
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ...tests.fixtures import (make_test_module, make_test_class,
                                   make_test_metaclass, make_test_decorator)
    from .six import six_import
    from .test_base import NodeTransformerTestCase

    class TestMetaclassTransformer(MetaclassTransformer, NodeTransformerTestCase):
        pass


# Generated at 2022-06-21 17:40:57.263876
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    def run_test(node):
        tree = ast.parse(node)
        transformer = MetaclassTransformer()
        transformer.visit(tree)
        assert tree.body[0].body[0].value.args[0].id == 'Foo'

    run_test('class A(metaclass=Foo): pass')
    run_test('class A(Foo, metaclass=Foo): pass')

# Generated at 2022-06-21 17:40:58.077028
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-21 17:41:41.720664
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast27 as ast

    class A:
        pass

    class B:
        pass

    node = ast.ClassDef()
    node.keywords = [ast.keyword(arg="metaclass",
                                 value=ast.Name(id="A", ctx=ast.Load()))]
    node.bases = [ast.Name(id="B", ctx=ast.Load())]

    m = MetaclassTransformer()
    m.visit(node)
    assert node.bases[0].args[0].id == "A"
    assert node.bases[0].args[1].id == "B"
    assert node.keywords == []
    assert not m.is_unchanged()


# Generated at 2022-06-21 17:41:51.889514
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import six

    from typed_ast import ast3 as ast
    from ..utils.node_utils import dump, node_to_str
    from ..utils.ast_utils import SameNodeException

    ast_before = ast.parse(dedent('''\
        class A(metaclass=B):
            pass
    '''))
    ast_after = ast.parse(dedent('''\
        class A(_py_backwards_six_with_metaclass(B)):
            pass
    '''))
    t = MetaclassTransformer()
    t.visit(ast_before)

# Generated at 2022-06-21 17:41:58.080549
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse("")
    assert isinstance(module, ast.Module)
    transformer = MetaclassTransformer()
    transformer.visit_Module(module)
    res = ast.dump(module)
    expected = '''Module(body=[
    Import(names=[alias(
        name='six',
        asname=None)])])'''
    assert res == expected


# Generated at 2022-06-21 17:42:00.152431
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:42:05.723240
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """class A(metaclass=B):
    pass"""

    expected = """class A(_py_backwards_six_with_metaclass(B)):
    pass"""

    assert_equal(MetaclassTransformer().visit(ast.parse(code)), ast.parse(expected))



# Generated at 2022-06-21 17:42:13.332767
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.astx import assert_equal_ast
    import textwrap
    src = textwrap.dedent("""
    class A(metaclass=type):
        pass
    """)
    expected = textwrap.dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass    
    class A(_py_backwards_six_withmetaclass(type)):
        pass
    """)
    tree = ast.parse(src)
    MetaclassTransformer(None).visit(tree)
    assert_equal_ast(expected, tree)


# Generated at 2022-06-21 17:42:17.179753
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .fixtures.six_withmetaclass import source, expected
    from ... import transform

    output = transform(source, [MetaclassTransformer])

    assert output == expected

# Generated at 2022-06-21 17:42:24.174065
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from _py_backwards.tests.typing import Dummy
    from _py_backwards.visitors import MetaclassTransformer

    source = """
    class A(object):
        pass
    """
    transformer = MetaclassTransformer(source)
    assert transformer._tree_changed == False
    result = transformer.visit(ast.parse(source))

    assert transformer._tree_changed == False
    assert isinstance(result.body[0], ast.ClassDef)
    assert isinstance(result.body[0].bases[0], ast.Str)
    assert result.body[0].bases[0].s == 'object'


# Generated at 2022-06-21 17:42:30.621041
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert six_import._get_code() == "from six import with_metaclass as _py_backwards_six_withmetaclass"
    assert class_bases._get_code() == '_py_backwards_six_withmetaclass(metaclass, *bases)'
    source = "class A(metaclass=B): pass"
    tree = ast.parse(source)
    MetaclassTransformer(source, tree).run()

# Generated at 2022-06-21 17:42:41.369447
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typing import List, Union
    from typed_ast import ast3 as ast

    six_import = snippet('''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    ''')

    class_bases = snippet('''
    _py_backwards_six_withmetaclass(metaclass, *bases)
    ''')


# Generated at 2022-06-21 17:44:12.340105
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import six
    import sys
    import ast
    if sys.version_info[:2] < (3, 6):
        source_code = "class A(object, metaclass=six.with_metaclass(type)):\n    def f(self):\n        return 42"
    else:
        source_code = "class A(object, metaclass=type):\n    def f(self):\n        return 42"
    node = ast.parse(source_code)
    with_metaclass = MetaclassTransformer()
    with_metaclass.visit(node)
    code = compile(node, "<test>", "exec")
    globals_ = {}
    exec(code, globals_)

# Generated at 2022-06-21 17:44:17.048770
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = parse('class metaclass(metaclass=_py_backwards_six_withmetaclass):\n    pass')
    MetaclassTransformer.apply_transform(node)
    assert str(node) == '\n'.join(six_import.get_body()) + '\n' + str(node)

# Generated at 2022-06-21 17:44:18.401691
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor

# Generated at 2022-06-21 17:44:24.478795
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    import textwrap
    s = textwrap.dedent('''
        class A(metaclass=B):
            pass
    ''')
    t = textwrap.dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_with_metaclass(B))
    
    ''')
    test_ast = astor.parse_file(s)
    transformer = MetaclassTransformer()
    t_ast = transformer.visit(test_ast)
    assert astor.to_source(t_ast) == t

# Generated at 2022-06-21 17:44:33.756004
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import types
    import astor
    from typing import Optional

    class A(object):
        pass

    class B(object):
        __metaclass__ = A

    class C(object, metaclass=A):
        pass

    class D(metaclass=A):
        pass

    assert B.__class__.__name__ == 'A'
    # TODO: Fix https://github.com/pybpc/pybpc/issues/49
    #assert C.__class__.__name__ == 'A'
    assert D.__class__.__name__ == 'A'

    @snippet
    def test(metaclass):
        class A(metaclass=metaclass):
            pass


    for cls in (A, types.FunctionType):
        test_code = test.get_

# Generated at 2022-06-21 17:44:43.021143
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    sample = ast.parse((
        'from inspect import isclass\n'
        'class A:\n'
        '    pass\n'
        'class B(A, metaclass=type):\n'
        '    pass\n'
        ))
    expected = ast.parse((
        'import six\n'
        'from inspect import isclass\n'
        'class A:\n'
        '    pass\n'
        'class B(_py_backwards_six_withmetaclass(type), *(A,)):\n'
        '    pass\n'
        ))
    transformer = MetaclassTransformer()
    result = transformer.visit(sample)
    assert transformer._tree_changed
    assert codegen.to_source(result) == codegen

# Generated at 2022-06-21 17:44:53.778813
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_name
    from .unittest_transformer_util import should_transform_to
    from .unittest_transformer_util import run_test

    # Simple class
    run_test(MetaclassTransformer,
             """
             class A(object):
                 pass
             """,
             """
             class A(_py_backwards_six_withmetaclass(object)):
                 pass
             """,
             [six_import])

    # Class with methods

# Generated at 2022-06-21 17:44:56.904351
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = """
    class A(metaclass=B):
        pass
    """
    module = ast.parse(code)
    module = MetaclassTransformer().visit(module)
    assert ast.dump(module) == snippet.dump(six_import) + snippet.dump(code)


# Generated at 2022-06-21 17:45:06.358787
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from six import with_metaclass as _py_backwards_six_with_metaclass
    from typed_ast.ast3 import parse

    tree = parse(u"""
    class A(metaclass=B):
        pass
    """)
    MetaclassTransformer().visit(tree)
    assert type(tree.body[0].bases[0]) == ast.Call
    assert type(tree.body[0].bases[0].func) == ast.Name
    assert tree.body[0].bases[0].func.id == '_py_backwards_six_with_metaclass'
    assert tree.body[0].bases[0].args[0].id == 'B'
