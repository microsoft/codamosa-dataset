

# Generated at 2022-06-21 17:35:16.455780
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()

# Generated at 2022-06-21 17:35:28.725504
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse(dedent("""\
        class A(metaclass=B):
            pass
    """))
    t = MetaclassTransformer()
    new_module = t.visit(module)
    assert ast.dump(new_module) == dedent("""\
        Module(body=[
            ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_with_metaclass')], level=0),
            ClassDef(name='A', bases=[
                Call(func=Name(id='_py_backwards_six_with_metaclass', ctx=Load()), args=[Name(id='B', ctx=Load())], keywords=[])
            ], body=[
            ], decorator_list=[])
        ])""")

#

# Generated at 2022-06-21 17:35:29.332747
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:35:41.477063
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.Module([
        ast.ClassDef(
            name='A',
            bases=[],
            keywords=[ast.keyword(
                arg='metaclass',
                value=ast.Name(id='B', ctx=ast.Load()),
            )],
            body=[],
            decorator_list=[],
            lineno=1,
            col_offset=0,
        )
    ])

# Generated at 2022-06-21 17:35:49.444063
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    self = MetaclassTransformer()
    node = ast.parse('class B(metaclass=A): pass')
    result = self.visit_Module(node)
    assert str(result).strip() == 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass B(_py_backwards_six_withmetaclass(A)):\n    pass'


# Generated at 2022-06-21 17:36:00.291590
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    import astor

    source = textwrap.dedent('''
    class A(metaclass=B):
        pass
    ''')

    node = ast.parse(source).body[0]
    assert isinstance(node, ast.ClassDef)
    assert node.name == 'A'
    assert len(node.keywords) == 1
    assert node.keywords[0].arg == 'metaclass'
    assert isinstance(node.keywords[0].value, ast.Name)
    assert node.keywords[0].value.id == 'B'

    node = MetaclassTransformer().visit(node)

    assert isinstance(node, ast.ClassDef)
    assert node.name == 'A'
    assert len(node.keywords) == 0

# Generated at 2022-06-21 17:36:02.891984
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:36:10.833572
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """
    class A(B, C, metaclass=D):
        pass
    """
    tree = ast.parse(source)
    expected = """
    class A(_py_backwards_six_withmetaclass(D, *[B, C])):
        pass
    """
    expected_tree = ast.parse(expected)

    transformer = MetaclassTransformer()
    node = transformer.visit(tree.body[0])
    assert ast.dump(node) == ast.dump(expected_tree.body[0])

# Generated at 2022-06-21 17:36:20.321007
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = """
        class A(metaclass=B):
            pass
    """
    tree = ast.parse(code)
    tree = MetaclassTransformer().visit(tree)
    assert ast.dump(tree) == "Module(body=[\n  ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0),\n  ClassDef(name='A', bases=[_py_backwards_six_withmetaclass(B)], body=[], decorator_list=[], keywords=[])\n])"

# Generated at 2022-06-21 17:36:30.591125
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Test the snippet get_body() of six_import def
    expected = ast.Module(body=[
        ast.ImportFrom(module='six', names=[
            ast.alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')
        ], level=0)
    ])
    actual = six_import.get_body()
    assert actual == expected
    
    source = six_import.dedent().strip()
    tree = ast.parse(source)
    transformed = MetaclassTransformer().visit(tree)
    assert transformed == expected


# Generated at 2022-06-21 17:36:34.935173
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import ClassDef

# Generated at 2022-06-21 17:36:37.710187
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    transformer = MetaclassTransformer(target_versions={'python': (2, 7)})

# Generated at 2022-06-21 17:36:50.972964
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import pytest
    from typed_ast import ast3 as ast
    from ..utils.tree import make_tree

    t = MetaclassTransformer()

    # Test that method visit_ClassDef properly transforms a class definition
    # with a metaclass keyword argument.

    # Test that method visit_ClassDef properly transforms a class definition
    # with a metaclass keyword argument.

    module = make_tree(
        ast.Module,
        [
            ast.ClassDef(name='A', bases=[], keywords=[
                ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load())),
            ], body=[], decorator_list=[])
        ]
    )

    t.visit_Module(module)


# Generated at 2022-06-21 17:36:53.627682
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    code = """
        class A(metaclass=B):
            pass
    """
    a = ast.parse(code)
    scope = {}

    import six
    scope.update(six.__dict__)

    # When
    a = MetaclassTransformer().visit(a)

    # Then
    code = compile(a, __file__, mode='exec')
    exec(code, scope)

    assert scope['A'] == scope['_py_backwards_six_with_metaclass'](scope['B'])
    assert six in MetaclassTransformer.dependencies

# Generated at 2022-06-21 17:37:01.946087
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    import astunparse
    from ..utils.test_utils import transform_and_compare

    # Test "basics"

# Generated at 2022-06-21 17:37:10.682736
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import textwrap
    source = textwrap.dedent('''\
        class A(metaclass=B):
            pass
        ''')
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    want = textwrap.dedent('''\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B, )):
            pass
        ''')
    have = astor.to_source(tree)
    assert have == want

# Generated at 2022-06-21 17:37:17.335461
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import six

    import ast
    import astunparse
    from ..utils.tree import print_tree

    class Py27Transformer(MetaclassTransformer):
        target = (2, 7)


# Generated at 2022-06-21 17:37:24.672857
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Source:
    # class A(metaclass=B):
    #     pass
    module_node = ast.Module(body=[
        ast.ClassDef(name='A',
                     bases=[ast.Name(id='B', ctx=ast.Load())],
                     keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                     body=[ast.Pass()],
                     decorator_list=[])
    ])

    transformer = MetaclassTransformer()
    module_node = transformer.visit(module_node)

    assert module_node.body[0].bases == class_bases.get_body()
    assert module_node.body[0].keywords == []

# Generated at 2022-06-21 17:37:30.193592
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import context
    import astor
    tree = context.load('metaclass', 'for_test')
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert tree == astor.parse_file(context.get_filename('metaclass', 'expected'))

# Generated at 2022-06-21 17:37:32.028850
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast

# Generated at 2022-06-21 17:37:41.097061
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Setup
    node = parse('a = 1')
    transformer = MetaclassTransformer()

    # Exercise
    actual = transformer.visit_Module(node)

    # Verify
    expected = parse('from six import with_metaclass as _py_backwards_six_withmetaclass\na = 1')
    assert ast.dump(actual) == ast.dump(expected)



# Generated at 2022-06-21 17:37:42.294481
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import sys
    from ast import parse


# Generated at 2022-06-21 17:37:46.878998
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # data.
    code = """
    class Foo:
        pass
    
    """
    # run code.
    root = ast3.parse(code)
    MetaclassTransformer().visit(root)
    code = ast3.unparse(root)
    assert code == six_import() + '\n\n' + code



# Generated at 2022-06-21 17:37:49.157195
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # type: () -> ()
    # Arrange
    import six
    import sys

    sys.modules['six'] = six
    transpiler = MetaclassTransformer()

# Generated at 2022-06-21 17:37:58.792858
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from six import with_metaclass as _py_backwards_six_withmetaclass
    from ..utils.fake import FakeFile
    input_tree = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(input_tree)
    assert isinstance(new_tree, ast.Module)
    assert len(new_tree.body) == 2
    assert isinstance(new_tree.body[0], ast.Assign)
    assert new_tree.body[0].value == _py_backwards_six_withmetaclass
    assert new_tree.body[1] == input_tree.body[0]

# Generated at 2022-06-21 17:38:00.347163
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert_equal(
        compile(six_import.get_source(), '<string>', 'exec'),
        MetaclassTransformer.source_to_ast(six_import.get_source())
    )

# Generated at 2022-06-21 17:38:00.719222
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:38:01.414398
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:38:04.179503
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = '''
        import six
        class A(metaclass=B):
            pass
        class B(object): pass
    '''
    result = '''
        import six
        class A(six.with_metaclass(B)):
            pass
        class B(object): pass
    '''
    tree = parser.parse(source)
    vm = MetaclassTransformer()
    vm.transform(tree)
    assert result == tree.as_string()

# Generated at 2022-06-21 17:38:06.406043
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:38:10.756200
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:38:11.092553
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:38:15.417508
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import test_utils
    from ..utils.test_utils import make_test, get_test_desc

    test_desc = get_test_desc(test_MetaclassTransformer)

    # Test 1

# Generated at 2022-06-21 17:38:17.245575
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from py_backwards.utils.ast_tools import parse_to_ast

# Generated at 2022-06-21 17:38:26.103741
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    t = MetaclassTransformer()
    code = """class Test(metaclass=int):
    pass
"""
    tree = ast.parse(code)
    METACLASS = ast.Name(id='int', ctx=ast.Load())
    expected_tree = ast.Module(body=[six_import.get_body()[0],
                                     ast.ClassDef(name='Test',
                                                  bases=[class_bases.get_body(metaclass=METACLASS,
                                                                              bases=ast.List(elts=[]))[0]],
                                                  body=[],
                                                  decorator_list=[])])

    # No need to test the rest of the code, because the constructor of the superclass
    # BaseNodeTransformer already takes care of that

# Generated at 2022-06-21 17:38:28.779336
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile
    namespace = {}
    source = "class A(metaclass=B): pass"
    compile(source, "<test>", "exec", namespace=namespace)
    assert "A" in namespace  # type: ignore
    assert isinstance(namespace["A"], type)  # type: ignore

# Generated at 2022-06-21 17:38:32.773424
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import make_sure_writable
    node = ast.parse('class A(metaclass=int):    pass')
    make_sure_writable(node)
    transformed = MetaclassTransformer.run_pipeline(node)
    six_import = """from six import with_metaclass as _py_backwards_six_withmetaclass"""
    with_meta = """_py_backwards_six_withmetaclass(int)"""

# Generated at 2022-06-21 17:38:37.631857
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.ast_builder import build_ast

    @snippet
    def test_module():
        class A(metaclass=B):
            pass

    metaclass_transformer = MetaclassTransformer()
    test_node = build_ast().from_snippets(test_module.get_body())
    metaclass_transformer.visit(test_node)
    assert metaclass_transformer._tree_changed is True


# Generated at 2022-06-21 17:38:42.066319
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import transforms

    test_ast = ast.parse("""
        class A(metaclass=B):
            pass
        """)

    transformer = MetaclassTransformer()
    new_ast = transformer.visit(test_ast)



# Generated at 2022-06-21 17:38:49.568822
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from textwrap import dedent
    stmt = dedent('''
        class C(metaclass=type):
            pass
        ''')
    node = ast.parse(stmt)
    MetaclassTransformer().visit(node)
    print(node)
    assert compile(node, '<test>', 'exec').co_consts[1].co_consts == (
            None, None, None, None, None, type, None)

# Generated at 2022-06-21 17:39:03.857554
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import parse
    from textwrap import dedent

    src = dedent('''
    class A(metaclass=B):
        pass
    ''')
    tree = parse(src)
    t = MetaclassTransformer(tree)
    new_tree = t.visit(tree)
    assert (new_tree.body[0].value.keywords[0].value.elts[0].value.id == '_py_backwards_six_withmetaclass')

# Generated at 2022-06-21 17:39:12.995295
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import (Module, ClassDef, Name, Store, NameConstant,
                                AugAssign, Load, BinOp, Add, Mult, Num,
                                Assign, Subscript, Index, List)
    from typed_ast import c_ast3 as c


# Generated at 2022-06-21 17:39:13.922494
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    pass


# Generated at 2022-06-21 17:39:15.544010
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_astunparse import unparse
    import sys


# Generated at 2022-06-21 17:39:21.961906
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import Source

    source = Source('class A(metaclass=B):\n    pass')
    MetaclassTransformer.transform(source)
    assert source.code == 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass\n'

# Generated at 2022-06-21 17:39:30.695020
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import assert_equal_ast
    metaclass_node = ast.parse("class Metaclass: pass")
    class_node = ast.parse("class A(metaclass=Metaclass): pass")
    module_node = ast.Module(body=[metaclass_node, class_node])

    expected_module_node = ast.parse("from six import with_metaclass as _py_backwards_six_withmetaclass;"
                                     "class Metaclass: pass;"
                                     "class A(_py_backwards_six_withmetaclass(Metaclass)): pass")
    assert_equal_ast(expected_module_node, MetaclassTransformer().visit(module_node))


# Generated at 2022-06-21 17:39:34.588884
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor  # type: ignore

    class Source(MetaclassTransformer):
        def __init__(self):
            self._tree_changed = False

        def generic_visit(self, node):
            return node


# Generated at 2022-06-21 17:39:41.718182
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.ast import parse
    from ..utils.source import source
    from ..utils.snippet import snippet
    from ..utils.tree_compare import tree_contains_node, tree_contains_node_at
    from .base import BaseNodeTransformer, NodeTransformer

    class_def_transformer = NodeTransformer()
    transformer = MetaclassTransformer()
    module = parse(source(six_import.get_body() + source(class_bases.get_body(metaclass=transformer.visit(parse(source('metaclass'))),
                                                                              bases=parse('bases')))))
    module = transformer.visit(module)
    assert transformer._tree_changed


# Generated at 2022-06-21 17:39:48.709471
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
    import six
    class Test(metaclass=list):
        pass
    """

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class Test(_py_backwards_six_withmetaclass(list)):
        pass
    """
    assert MetaclassTransformer(code).run() == expected



# Generated at 2022-06-21 17:39:59.408003
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typing import Dict, List, Optional
    from typed_ast import ast3 as ast

    from ..utils.testing import TransformerTestCase

    from .base import BaseNodeTransformer

    from .contextmanager import ContextManagerTransformer
    from .strings import StringTransformer
    from .unpacking import UnpackingTransformer

    class TestMetaclassTransformer(TransformerTestCase):
        TRANSFORMER_CLASS = MetaclassTransformer
        DEPENDENCIES = [
            StringTransformer,
            UnpackingTransformer,
            ContextManagerTransformer,
        ]


# Generated at 2022-06-21 17:40:15.750441
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast.ast3 import parse


# Generated at 2022-06-21 17:40:22.255549
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    tree = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    new_tree = MetaclassTransformer().visit(tree)
    assert ast.dump(new_tree) == ast.dump(ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """))

# Generated at 2022-06-21 17:40:28.020329
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import six
    import sys

    if sys.version_info < (2, 7):
        six_mod = six.moves.__dict__['__six_moves']
    else:
        six_mod = six.moves.__dict__['_six']

    six_mod.move_metaclass = MetaclassTransformer()

    from six import with_metaclass as _py_backwards_six_withmetaclass

    class FooMeta(type):
        def __new__(mcs, name, bases, attrs):
            attrs['qux'] = 'quux'
            return type.__new__(mcs, name, bases, attrs)


    class Foo(with_metaclass(FooMeta)):
        bar = 'baz'

    assert Foo.qux == 'quux'

# Generated at 2022-06-21 17:40:30.916250
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as _ast

# Generated at 2022-06-21 17:40:38.224624
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    mp = MetaclassTransformer(verbose=True)
    source = """class A(metaclass=B):\n    pass"""
    tree = parser.suite(source)
    mp.visit(tree)
    assert mp.tree.children[0].body[0].body[1].elts[0].id == '_py_backwards_six_withmetaclass'  # type: ignore



# Generated at 2022-06-21 17:40:49.357354
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest
    from ..testing.utils import transform

    class TestMetaclassTransformer(unittest.TestCase):
        def test_metaclass_keyword(self):
            code = '''\
            class A(metaclass = B):
                pass
            '''
            result = '''\
            from six import with_metaclass as _py_backwards_six_withmetaclass
            
            class A(_py_backwards_six_withmetaclass(B)):
                pass
            '''
            transform(MetaclassTransformer, code, result)

    # Run tests
    unittest.main(verbosity=2)

# Generated at 2022-06-21 17:40:53.953792
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six

    class Example(six.with_metaclass(type, object)):
        ...

    assert Example.__mro__ == (Example, object)
    assert Example.__class__ == type



# Generated at 2022-06-21 17:40:59.795393
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..tests.test_transformer import check_transform

    src = """\
    class A(metaclass=C):
        pass
    """
    expected = """\
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(C)):
        pass
    """
    check_transform(src, expected, MetaclassTransformer)



# Generated at 2022-06-21 17:41:06.794663
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import _ast as ast
    node = ast.Module()
    transformer = MetaclassTransformer()
    new_node = transformer.visit_Module(node)
    assert len(new_node.body) == 1
    assert type(new_node.body[0]) is ast.FunctionDef
    assert new_node.body[0].name == '_py_backwards_six_withmetaclass'


# Generated at 2022-06-21 17:41:12.237718
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    class_def = ast.parse('class A(metaclass=B): pass')

    # When
    transform = MetaclassTransformer()
    transform.visit(class_def)

    # Then
    assert compile(class_def, '<test>', 'exec')

# Generated at 2022-06-21 17:41:47.807737
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def = ast.parse('class A(metaclass=B): pass').body[0]
    assert MetaclassTransformer().visit(class_def) == ast.parse(
        'class A(_py_backwards_six_withmetaclass(B)): pass').body[0]


# Generated at 2022-06-21 17:41:59.762204
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class t:
        pass
    class a(t):
        pass

    assert ast.dump(MetaclassTransformer().visit(ast.parse('class a(metaclass=t): pass')),
                    annotate_fields=False) == ast.dump(ast.parse('class a(_py_backwards_six_withmetaclass(t))'),
                                                       annotate_fields=False)

    assert ast.dump(MetaclassTransformer().visit(ast.parse('class a(b, c, metaclass=t): pass')),
                    annotate_fields=False) == ast.dump(ast.parse('class a(_py_backwards_six_withmetaclass(t, b, c))'),
                                                       annotate_fields=False)


# Generated at 2022-06-21 17:42:10.014173
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from pprint import pprint
    from typed_ast import ast3 as ast
    from typed_astunparse import unparse
    from typed_astunparse import unparse
    from typed_ast.ast3 import ClassDef
    from ..utils.tree import ast_to_bin_tree
    from .six import six_import

    source = 'class A(metaclass=B): pass'
    ast_tree = compile(source, '', 'exec', ast.PyCF_ONLY_AST)
    expected_ast_tree = compile(
        (six_import.def_statement() +
        'class A(_py_backwards_six_withmetaclass(B)): pass'),
        '', 'exec', ast.PyCF_ONLY_AST)
    expected_ast_tree.body[0].lineno = 1
    expected_

# Generated at 2022-06-21 17:42:12.836004
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source_code = """class A(metaclass=B):
        pass"""

# Generated at 2022-06-21 17:42:13.823233
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-21 17:42:16.337453
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:42:24.594823
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    nodes = [
        ast.ClassDef(name="A",
                     bases=[ast.Name(id="object",  # type: ignore
                                     ctx=ast.Load())],
                     keywords=[ast.keyword(arg="metaclass",  # type: ignore
                                           value=ast.Name(id="type", ctx=ast.Load()))],  # type: ignore
                     body=[],
                     decorator_list=[])
    ]

# Generated at 2022-06-21 17:42:29.007365
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class_def = ast.parse('class A(metaclass=B):\n    pass').body[0]
    print(ast.dump(class_def))

# Generated at 2022-06-21 17:42:37.777749
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tests = [
        (
            'class A(metaclass=B): pass',
            'class A(_py_backwards_six_withmetaclass(B)): pass'
        ),
    ]

    for in_, expected in tests:
        tree = ast.parse(in_)
        MetaclassTransformer().visit(tree)
        out = ast.dump(tree)
        assert out == expected

# Generated at 2022-06-21 17:42:43.666162
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # arrange
    module = ast.parse('class A(metaclass=B):\n    pass', mode='exec')
    trans = MetaclassTransformer()

    # act
    transformed_module = trans.visit(module)

    # assert
    expected_transformed_module = ast.parse(
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n\n'
        'class A(_py_backwards_six_withmetaclass(B)):\n    pass',
        mode='exec')
    assert ast.dump(transformed_module) == ast.dump(expected_transformed_module)



# Generated at 2022-06-21 17:43:58.600440
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    sample_code = """class A(metaclass=B): pass"""

# Generated at 2022-06-21 17:44:10.280295
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    t = MetaclassTransformer()
    node = ast.Module(body=[ast.ClassDef(name='A', bases=[ast.Name(id='B', ctx=ast.Load())],
                          keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='C', ctx=ast.Load()))],
                          body=[])])
    new_node = t.visit(node)
    assert ast.dump(new_node) == "Module(body=[ClassDef(name='A', bases=[Call(args=[Name(id='C', ctx=Load())], func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), keywords=[])], body=[], keywords=[])])"

# Generated at 2022-06-21 17:44:14.362723
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.utils import get_ast
    from ..utils.pretty import DUMMY_SOURCE
    import typed_ast.ast3 as ast
    from ..transforms.MetaclassTransformer import MetaclassTransformer

# Generated at 2022-06-21 17:44:23.319195
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import textwrap
    from ..utils.source import source_to_ast

    code = textwrap.dedent(r"""
        class A(metaclass=B):
            pass
    """)

    generator = MetaclassTransformer()
    assert generator.code_changed
    tree = source_to_ast(code)
    new_tree = generator.visit(tree)

    expected_code = textwrap.dedent(r"""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    assert generator.code_changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected_code))

# Generated at 2022-06-21 17:44:33.072504
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .module import ModuleTransformer
    from . import six as transformerSix
    from . import six as transformerSix

    template = '''
    class {name}({metaclass}):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class {name}(_py_backwards_six_withmetaclass({metaclass})):
        pass
    '''
    expected_six = '''
        class {name}(_py_backwards_six_withmetaclass({metaclass}))
    '''


# Generated at 2022-06-21 17:44:42.828692
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.fake import FakeModule, FakeList
    from ..utils.mock import Mock, patch
    from ..utils.test import assert_equal
    from .nodes import list_fields
    from .six_helpers import six_import_transformed, six_import_untransformed
    m = FakeModule(body=[six_import_untransformed, ], line_no=1)
    with patch('py_backwards.transformers.metaclass_transformer.six_import') as mock_six_import:
        Mock(ast.parse(six_import_transformed)).mock_body[0] >> mock_six_import
        t = MetaclassTransformer()
        t.visit(m)
        assert_equal(mock_six_import.call_count, 1)

# Generated at 2022-06-21 17:44:47.094656
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = '''class A(metaclass=B): pass'''

# Generated at 2022-06-21 17:44:55.880870
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import textwrap
    from ..visitors.ast_to_code import AstToCodeTransformer
    from ..utils.test_utils import should_pass, should_fail

    class Foo(object):
        pass

    class Bar(Foo):
        pass

    # Should pass
    should_pass(
        MetaclassTransformer(),
        textwrap.dedent('''
            class A(metaclass=type):
                pass
            '''),
        textwrap.dedent('''
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(type)):
                pass
            ''')
    )

    # Should pass

# Generated at 2022-06-21 17:45:05.473687
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast
    import typed_ast.ast3 as typed_ast
    from typed_ast.transforms.py27_backports.six_backports import six_import

    code = """
    class A(metaclass=B):
        pass    """

    node = ast.parse(code)
    typed_node = typed_ast.ast3.parse(code)

    transformer = MetaclassTransformer()
    _node = transformer.visit(typed_node)
    assert _node.body[0].__dict__ == six_import.get_body().__dict__
    assert _node.body[1].__dict__ == node.body[0].__dict__



# Generated at 2022-06-21 17:45:14.989310
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # This test is needed in order to assert that the snippet of code
    # used to convert metaclasses works well.
    metaclass = ast.Name(id='Test', ctx=ast.Load())
    node = ast.ClassDef(name='A',
                        bases=[metaclass],
                        body=[],
                        keywords=[])
    
    expected_node: ast.ClassDef = ast.ClassDef(name='A',
                                        bases=[ast.List(elts=[metaclass])],
                                        body=[],
                                        keywords=[])
    
    node = MetaclassTransformer().visit(node)
    assert node == expected_node