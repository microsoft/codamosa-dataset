

# Generated at 2022-06-21 17:35:23.429411
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse(
        '''
        class A(metaclass=B):
            pass
        '''
    )

    MetaclassTransformer().visit(tree)

# Generated at 2022-06-21 17:35:30.243381
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import unittest
    import textwrap
    from .util import compile_source
    from ..utils.tree import parse

    class TestMetaclassTransformer(unittest.TestCase):
        def test_metaclass_transformer(self):
            source = textwrap.dedent('''
            class A(metaclass=B):
                pass
            ''')
            tree = parse(source)
            compile_source(tree, [MetaclassTransformer])
            metaclass_transformer = textwrap.dedent('''
            from six import with_metaclass as _py_backwards_six_withmetaclass

            class A(_py_backwards_six_withmetaclass(B)):
                pass
            ''')

# Generated at 2022-06-21 17:35:41.880500
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    t = MetaclassTransformer()
    assert not t._tree_changed

    # No keywords
    class_node = ast.ClassDef(name='A',
                              bases=[ast.Name(id='B', ctx=ast.Load())],
                              body=[ast.Pass()],
                              keywords=[],
                              decorator_list=[])
    t.visit(class_node)
    assert not t._tree_changed

    # 1 keyword
    class_node = ast.ClassDef(name='A',
                              bases=[ast.Name(id='B', ctx=ast.Load())],
                              body=[ast.Pass()],
                              keywords=[ast.arg('metaclass', ast.Name(id='B', ctx=ast.Load()))],
                              decorator_list=[])
    t.vis

# Generated at 2022-06-21 17:35:46.004597
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = """class A(metaclass=B):
                pass"""


# Generated at 2022-06-21 17:35:50.435637
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    tree = ast.parse("""
    class A(metaclass=B):
        pass
    class C(metaclass=B):
        pass
    """)

# Generated at 2022-06-21 17:35:51.947186
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:35:54.641787
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    MetaclassTransformer.assert_compiler_output(
        '''
        class A(metaclass=M):
            pass
        ''',
        '''
        class A(M):
            pass
        '''
    )

# Generated at 2022-06-21 17:35:59.670558
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..transformer.six_metaclass import MetaclassTransformer

    transformer = MetaclassTransformer()
    class_def = ast.ClassDef(name='A', keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))], bases=[ast.Name(id='object', ctx=ast.Load())], body=[], decorator_list=[])
    transformer.visit(class_def)

    assert class_def.bases[0].args[1].id == 'B'

# Generated at 2022-06-21 17:36:09.310981
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = """
        class A(metaclass=B):
            pass
    """
    tree = ast.parse(source)  # type: ignore

    transformer = MetaclassTransformer()
    transformer.visit(tree)  # type: ignore

    expected_result = """
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """

    assert ast.dump(tree) == expected_result

# Generated at 2022-06-21 17:36:20.427314
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    from textwrap import dedent
    snippet = dedent("""\
        class Meta(type):
            pass

        class A(metaclass=Meta):
            pass
        """)
    module = ast.parse(snippet, filename='<test>')
    module = MetaclassTransformer().visit(module)
    assert module is not None
    assert astor.to_source(module) == dedent("""\
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class Meta(type):
            pass

        class A(_py_backwards_six_withmetaclass(Meta)):
            pass
        """)

# Generated at 2022-06-21 17:36:33.016033
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Meta(type):
        pass

    class Foo(metaclass=Meta):
        pass

    module = compile(Foo, '', mode='single')
    transformed = MetaclassTransformer().visit(module)
    six_import_ = next(m for m in module.body if isinstance(m, ast.ImportFrom))
    six_import = next(m for m in transformed.body if isinstance(m, ast.ImportFrom))
    assert six_import_.alias.name == six_import.alias.name
    assert six_import_.alias.asname == six_import.alias.asname
    assert six_import_.module == six_import.module
    foo_class = next(m for m in transformed.body if isinstance(m, ast.ClassDef))
    assert foo_class.name == 'Foo'
   

# Generated at 2022-06-21 17:36:40.719134
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    module = ast.parse("""
        class A(B, metaclass=C): pass
        class C(metaclass=B, object): pass
        """)
    transformer = MetaclassTransformer()
    module = transformer.visit(module)
    assert ast.dump(module) == dedent("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(C, *[B])):
            pass
        class C(_py_backwards_six_withmetaclass(B, *[object])):
            pass
        """).strip()

# Generated at 2022-06-21 17:36:41.582075
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:36:51.090092
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    Ensures that MetaclassTransformer works correctly.
    """
    # noinspection PyUnresolvedReferences
    data = """
        class B(metaclass=A):
            pass
    """

    result = """
    from six import with_metaclass as _py_backwards_six_with_metaclass

    class B(_py_backwards_six_with_metaclass(A)):
        pass
    """

    tree = ast.parse(data)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert ast.dump(tree) == result

# Generated at 2022-06-21 17:36:54.804181
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class A(metaclass=int):
        pass

    expected = six_import.get_body() + [
        ast.ClassDef(name='A', 
                     bases=[class_bases.get_body(metaclass=ast.Name(id='int', ctx=ast.Load()), 
                                                 bases=ast.List(elts=[], ctx=ast.Load()))], 
                     keywords=[], 
                     body=[], 
                     decorator_list=[])]
    node_transformer = MetaclassTransformer()
    node_transformer.visit(ast.parse(dedent(inspect.getsource(A))))
    assert node_transformer.tree_changed is True
    assert node_transformer.new_tree == ast.fix_missing_locations(ast.Module(body=expected))


# Generated at 2022-06-21 17:36:56.194151
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

# Generated at 2022-06-21 17:37:01.158752
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():  # noqa
    import six
    import sys

    class B(object):
        pass

    class A(metaclass=B):
        pass

    class C(metaclass=six.with_metaclass(B)):
        pass

    assert A.__bases__[0].__class__ == C.__bases__[0].__class__


# Generated at 2022-06-21 17:37:11.706639
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Assign, Name, Store, NameConstant, Load, Expr, ClassDef, Str, Pass, AnnAssign, \
        AugAssign, Add, BinOp, Subscript, List, Load, Slice, BinOp, Index, If, Return
    from .utils.helper import check_visit_result
    from .test_get_node_tree import get_node_tree

    node = six_import.get_tree()

# Generated at 2022-06-21 17:37:15.036823
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = 'class A(object, metaclass=type): pass'
    node = ast.parse(source)
    trans = MetaclassTransformer()
    res = trans.visit(node)
    import astunparse as uparse
    result = uparse.unparse(res)
    assert result == six_impo

# Generated at 2022-06-21 17:37:15.689332
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    MetaclassTransformer()

# Generated at 2022-06-21 17:37:24.006045
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from textwrap import dedent

    content = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    class MyClass(metaclass=MyMetaclass):
        pass
    """

    node: ast.Module = ast.parse(content)
    transformer = MetaclassTransformer()

    result = transformer.visit(node)

    assert transformer._tree_changed
    assert ast.dump(result) == dedent(content.replace('MyMetaclass', '_py_backwards_six_withmetaclass(MyMetaclass)'))



# Generated at 2022-06-21 17:37:34.737772
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    six_import()
    class_bases(metaclass=ast.Name('B', ast.Load()), 
                bases=[])
    code = """
    class A(metaclass=B):
        pass
    """
    tree = ast.parse(code)  # type: ignore
    result = MetaclassTransformer(tree).result
    assert result.body[0].body[0].body[0].bases[0].value.args[0].id == 'B'  # type: ignore
    assert result.body[0].body[0].body[0].bases[0].value.func.id == '_py_backwards_six_withmetaclass'
    assert result.body[0].body[0].body[0].keywords == []



# Generated at 2022-06-21 17:37:44.662256
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Check the MetaclassTransformer class visit_ClassDef method
        """

    six_import_code = six_import.get_body()
    import_six_code = six_import.get_import_stmt()


# Generated at 2022-06-21 17:37:53.195244
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from astunparse import unparse
    from .test_BaseNodeTransformer import BaseNodeTransformerTest

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='object', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='str', ctx=ast.Load()))])

    module = ast.Module(body=[class_def])

# Generated at 2022-06-21 17:37:54.135196
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:37:58.614620
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import BaseTestTransformer
    import astor
    from .test_future_annotations import class_with_metaclass
    code = class_with_metaclass
    tree = astor.parse_file(code)
    tree = MetaclassTransformer().visit(tree)
    code2 = astor.to_source(tree)
    assert code.strip() == code2.strip()

# Generated at 2022-06-21 17:37:59.176909
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    pass


# Generated at 2022-06-21 17:38:04.350774
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    mt = MetaclassTransformer()

    class_source = "class A(metaclass=B):\n    pass"
    class_ast = ast.parse(class_source)
    assert mt.visit_ClassDef(class_ast.body[0]) == ast.parse("class A(_py_backwards_six_withmetaclass(B))")

    class_source = "class A(object, metaclass=B):\n    pass"
    class_ast = ast.parse(class_source)
    assert mt.visit_ClassDef(class_ast.body[0]) == ast.parse("class A(_py_backwards_six_withmetaclass(B))")

# Generated at 2022-06-21 17:38:05.750612
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor


# Generated at 2022-06-21 17:38:15.771211
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.unparse import Unparser
    from ..utils.ast_helpers import parse_source
    import textwrap
    Unparser(parse_source(textwrap.dedent('''\
        class A(metaclass=B):
            pass
        ''')))

    Unparser(parse_source(six_import.dedent() +
                          textwrap.dedent('''\
        class A(metaclass=B):
            pass
        ''')))

    Unparser(parse_source(six_import.dedent() +
                          textwrap.dedent('''\
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        ''')))

# Generated at 2022-06-21 17:38:21.125793
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer().target == (2, 7)
    assert MetaclassTransformer().dependencies == ['six']

# Generated at 2022-06-21 17:38:23.209200
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..fake import FakeFile
    from ..utils import assert_equal

    t = MetaclassTransformer()


# Generated at 2022-06-21 17:38:25.505405
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ...testing import assert_transformation
    assert_transformation(MetaclassTransformer, 'def f():\n  class A(metaclass=B): pass')

# Generated at 2022-06-21 17:38:30.317187
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...testing import assert_code_equal

    code = """\
        class A(metaclass=object):
            pass
        """
    expected = """\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_with_metaclass(object)):
            pass
        """

    module = ast.parse(code)
    MetaclassTransformer().visit(module)
    assert_code_equal(module, expected)

# Generated at 2022-06-21 17:38:36.585395
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='C', ctx=ast.Load()))])
    transformer = MetaclassTransformer()
    class_def = transformer.visit(class_def)
    assert len(class_def.bases) == 1
    assert hasattr(class_def.bases[0], 'func')

# Generated at 2022-06-21 17:38:41.932387
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    """Unit test for method visit_ClassDef of class MetaclassTransformer"""
    # import typed_ast.ast3
    # import darglint.transforms.metaclass
    # import darglint.transforms

    class TestMetaclassTransformer(MetaclassTransformer):
        def __init__(self):
            # type: () -> None
            # ast.ClassDef.node_init(...) initializes .col_offset and .lineno
            # which we need for comparison here so we call it.
            super(TestMetaclassTransformer, self).__init__()
            self._tree_changed = False

        def generic_visit(self, node):
            # type: (ast.AST) -> ast.AST
            """Do not visit nodes."""
            return node

       

# Generated at 2022-06-21 17:38:45.941137
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .transformer import py_to_py
    from .sixsupport import six_ast_to_target
    from termcolor import cprint


# Generated at 2022-06-21 17:38:49.717187
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    from typed_ast.ast3 import parse, ClassDef

    class SomeClass:
        pass
    class SomeMetaClass(type):
        pass
    class SomeOtherClass(metaclass=SomeMetaClass):
        pass


# Generated at 2022-06-21 17:39:00.278138
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    in_ast = ast.Module(body=[
        ast.ClassDef(name='A', bases=[ast.Name(id='B', ctx=ast.Load())],
                     body=[],
                     decorator_list=[],
                     keywords=[ast.keyword(arg='metaclass',
                                           value=ast.Name(id='C', ctx=ast.Load()))])
    ])

    out_ast = ast.parse(
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n'
        'class A(_py_backwards_six_withmetaclass(C, B)):\n'
        '    pass')

    import time
    t0 = time.time()
    mt = MetaclassTransformer()

# Generated at 2022-06-21 17:39:10.638180
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ...tests.transformer_test import assert_transform

    assert_transform(MetaclassTransformer, """
        class A:
            __metaclass__ = B
        """, """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """)

    assert_transform(MetaclassTransformer, """
        class A(metaclass=B, another_kwarg=C):
            pass
        """, """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B), another_kwarg=C):
            pass
        """)


# Generated at 2022-06-21 17:39:31.088110
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    body = ast.parse('''
        class A(metaclass=B,b=c):
            pass
    ''').body

    t = MetaclassTransformer()
    t.visit_ClassDef(body[0])
    assert len(body) == 1
    assert "six" in t._imports
    assert body[0].bases == ast.parse('_py_backwards_six_withmetaclass(B,*bases)').body[0].value
    assert body[0].keywords == []

# Generated at 2022-06-21 17:39:38.369004
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    py_source = """
        class A(metaclass=B):
            pass
    """
    expected_result = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    metaclass_transformer = MetaclassTransformer()
    actual_result = metaclass_transformer.visit_and_transform(py_source)
    assert astunparse.unparse(actual_result).strip() == expected_result.strip()

# Generated at 2022-06-21 17:39:41.587893
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import sys

    if sys.version_info.major == 2:
        class A(object):
            pass

    else:
        from six import with_metaclass

        class A(with_metaclass(type)):
            pass

    assert type(A) == type



# Generated at 2022-06-21 17:39:47.182671
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    AST = lambda *args, **kwargs: ast.parse(*args, **kwargs).body[0]
    module = AST('class A(metaclass=B): pass')  # type: ignore
    result = MetaclassTransformer().visit(module)

# Generated at 2022-06-21 17:39:53.442947
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_environment import TestEnvironment
    from ..bases.TestBase import TestBase
    from typed_ast import ast3 as ast

    test_env = TestEnvironment(MetaclassTransformer)
    test_env.test_filename = 'py_backwards.metaclass.test_file'
    test_env.initialize()

    # Test with no keyword
    test_env.node = ast.Module(
        body=[
            ast.ClassDef(
                name='A',
                bases=[],
                keywords=[],
                starargs=None,
                kwargs=None,
                body=[],
                decorator_list=[],
            )
        ]
    )


# Generated at 2022-06-21 17:40:04.769962
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse("""
    class A(metaclass=B):
        def test(self):
            pass
    """)

    transformer = MetaclassTransformer()
    module = transformer.visit(module)

    assert_equal(module.body[0].args.elts[0], 'six')
    assert_equal(module.body[1].name, '_py_backwards_six_withmetaclass')
    assert_equal(module.body[1].args.args[0].id, 'metaclass')
    assert_equal(module.body[1].args.args[1].args[0].id, 'B')
    assert_equal(module.body[2].bases[0].value.id, '_py_backwards_six_withmetaclass')

# Generated at 2022-06-21 17:40:05.754026
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:40:14.693893
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    import_node = six_import.get_node()

    class_node = ast.ClassDef(name='Test',
                              bases=[],
                              keywords=[ast.arg(arg='metaclass')],
                              body=[])

    module_node = ast.Module(body=[class_node])

    module_node = MetaclassTransformer().visit(module_node)  # type: ignore

    assert module_node.body[0] == import_node
    assert module_node.body[1].name == 'Test'


# Generated at 2022-06-21 17:40:24.471077
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ast import parse
    from .six_import import test_six_import_transformer
    from .class_bases import test_class_bases_transformer

    source = """
    class A(metaclass=B):
        pass"""
    expected = """
    class A(_py_backwards_six_withmetaclass(B)):
        pass"""
    tree = parse(source)
    tree = MetaclassTransformer().visit(tree)
    code = compile(tree, "<test>", "exec")
    ns = {'B': type}
    exec(code, ns)
    assert isinstance(ns['A'], type)
    assert ns['A'].__name__ == 'A'
    assert ns['A'].__bases__ == (object,)

    # Test that the transformer added the correct imports

# Generated at 2022-06-21 17:40:34.064433
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_resources import get_test_ast

    source = """
        class A(object, metaclass=B):
            pass
    """

    tree = get_test_ast(source)
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    expected = expected.replace('\n        ', '\n')
    expected = expected.strip()
    expected = get_test_ast(expected)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert expected == tree

# Generated at 2022-06-21 17:41:00.330304
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    from six import with_metaclass as _py_backwards_six_withmetaclass
    from .base import BaseTestCase

    class MetaclassTransformerTestCase(BaseTestCase):
        target = (2, 7)
        dependencies = ['six']
        transformer = MetaclassTransformer

        def test_metaclass(self):
            src = """
            class A(metaclass=B):
                pass
            """

            expected = """
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(B)):
                pass
            """

            cxt = Context(src)
            self.check_ast(cxt.tree, expected, sys._getframe().f_code.co_name)

# Generated at 2022-06-21 17:41:09.991988
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import check_transformer

    source = """class A(metaclass=B):
        pass"""


# Generated at 2022-06-21 17:41:11.904181
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:41:12.749063
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:41:21.816553
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ast_compat import parse
    from astmonkey import visitors
    from ast_compat.tests.transforms.test_MetaclassTransformer import \
        MetaclassTransformer
    
    transform = MetaclassTransformer()
    transform.visit(parse('class A(metaclass=B): pass'))
    transformed = transform.visited
    
    assert bool(transform.visited)
    
    # The module must be a Module.
    assert isinstance(transformed, ast.Module)
    # The module must have 2 statements, the 'from six import with_metaclass'
    # and the 'class A(metaclass=B): pass'
    assert len(transformed.body) == 2
    # The first statement must be an 'ImportFrom'

# Generated at 2022-06-21 17:41:22.688809
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:41:29.759529
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import generate_source_code

    source_code = generate_source_code(
        """
        class Foo:
            pass
        """,
        target=(2, 7))

    transformer = MetaclassTransformer()
    root = ast.parse(source_code)
    transformer.visit(root)

    target_code = generate_source_code(
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class Foo:
            pass
        """,
        target=(2, 7))

    assert target_code == source_code



# Generated at 2022-06-21 17:41:34.695364
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    classdef = ast.parse("class A(metaclass=B):\n    pass").body[0]
    classdef = transformer.visit(classdef)
    assert codegen.to_source(classdef.bases) == "(_py_backwards_six_withmetaclass(B))"

# Generated at 2022-06-21 17:41:40.406614
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.builder import build

    node = build("", [("class A(metaclass=B):\n    pass")])
    res = build("", [("from six import with_metaclass as _py_backwards_six_withmetaclass"),
                     (""),
                     ("class A(_py_backwards_six_withmetaclass(B)):\n    pass")])
    node_ = MetaclassTransformer().visit(node)
    assert node_ == res

# Generated at 2022-06-21 17:41:46.065366
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import BaseTestTransformer
    from ..utils.source import source_to_module, source_to_code
    from io import StringIO
    import sys
    import tokenize

    class TestMetaclassTransformer(BaseTestTransformer):
        transformer = MetaclassTransformer
        filename = __file__


# Generated at 2022-06-21 17:42:21.398037
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = """
        class Stub(metaclass=type):
            pass
    """
    expected_output = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class Stub(_py_backwards_six_withmetaclass(type)):
            pass
    """
    assert_transformed_code_equals(MetaclassTransformer, source, expected_output)


# Generated at 2022-06-21 17:42:22.758927
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:42:29.592060
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse('''
        class A(metaclass=B): pass
    ''')
    new_node = MetaclassTransformer().visit(node)
    expected_node = ast.parse('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)): pass
    ''')
    assert new_node == expected_node

# Generated at 2022-06-21 17:42:41.117070
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    module = ast.parse('''
        class A(metaclass=B):
            pass
        ''')
    mod = MetaclassTransformer().visit(module)
    print(ast.dump(mod))
    assert ast.dump(mod) == "Module(body=[Assign(targets=[Name(id='_py_backwards_six_withmetaclass', ctx=Store())], value=Name(id='with_metaclass', ctx=Load())), ClassDef(name='A', bases=[Call(func=Attribute(value=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), attr='__call__', ctx=Load()), args=[Name(id='B', ctx=Load())], keywords=[])], body=[Pass()])])"

# Generated at 2022-06-21 17:42:43.678659
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    MetaclassTransformer.verify()


transformer = MetaclassTransformer

# Generated at 2022-06-21 17:42:52.890183
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.node_util import check_equal
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import ClassDef, Name, Load, Keyword, Str, Store, NameConstant
    from ..utils.fixtures import six_import, class_bases
    
    class Node:
        def __init__(self,
                     bases=[],
                     keywords=[],
                     body=[],
                     decorator_list=[],
                     name='test',
                     lineno=1, col_offset=1):
            self.bases = bases
            self.keywords = keywords
            self.body = body
            self.decorator_list = decorator_list
            self.name = name
            self.lineno = lineno
            self.col_offset = col_offset

# Generated at 2022-06-21 17:42:59.832995
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    t = MetaclassTransformer()
    assert str(t.visit(six_import.get_ast())) == str(six_import.get_ast())
    assert str(t.visit(class_bases.get_ast())) == str(class_bases.get_ast())

# Generated at 2022-06-21 17:43:11.869435
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import BaseNodeTransformerTestCase
    from ..utils.compiler import compile_snippet
    import typed_ast.ast3 as ast

    class Test(BaseNodeTransformerTestCase):
        transformer_class = MetaclassTransformer
        target_versions = (2, 7)
        dependencies = ['six']

        def test_simple(self):
            tree = ast.parse(compile_snippet(
                """
                class Meta(type):
                    pass
                class Foo(object, metaclass=Meta):
                    pass
                """
            ))

            new_tree = self.transform(tree)


# Generated at 2022-06-21 17:43:23.152553
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    import textwrap

    source = textwrap.dedent(r'''
        class Foo(metaclass=Bar):
            pass
    ''').strip()
    tree = ast.parse(source)

    for_2_7 = textwrap.dedent(r'''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class Foo(_py_backwards_six_withmetaclass(Bar)):
            pass
    ''').strip()

    tree = MetaclassTransformer().visit(tree)
    assert for_2_7 in astor.to_source(tree)

# Generated at 2022-06-21 17:43:33.700916
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.grammar import parse
    from ..utils.tree import print_tree, tree_to_str
    from ..environment import Environment
    from ..utils.source import source_to_str

    six_import_body = six_import.get_body()
    class_bases_body = class_bases.get_body()

    env = Environment()
    env.add_dependency('six')
    source = source_to_str(
        """
        class A(metaclass=B):
            pass
        """.strip()
    )
    tree = parse(source)
    tree = MetaclassTransformer(env).visit(tree)
    print_tree(tree)
    tree_str = tree_to_str(tree)


# Generated at 2022-06-21 17:44:47.092953
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import sys
    import os
    import ast
    import typing

# Generated at 2022-06-21 17:44:52.030849
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    node = ast.parse("class A(metaclass=B, bases=C): pass")
    x = MetaclassTransformer.run_on(node)
    assert str(x) == "from six import with_metaclass as _py_backwards_six_withmetaclass; class A(_py_backwards_six_withmetaclass(B, *C))"



# Generated at 2022-06-21 17:44:57.347439
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    import astunparse

    node = astor.parse_file("class C(metaclass=A):\n    pass")
    node = MetaclassTransformer().visit(node)
    expected = "from six import with_metaclass as _py_backwards_six_withmetaclass" + "\n" + \
               "class C(_py_backwards_six_withmetaclass(A))" + "\n" + \
               "    pass" 
    assert astunparse.unparse(node) == expected

# Generated at 2022-06-21 17:45:05.281280
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from unittest import TestCase
    from typed_ast import ast3 as ast
    from ..utils.syntaxtree import SyntaxTree
    from .base import TransformerTestCase

    class Test(TransformerTestCase, TestCase):
        tree = SyntaxTree()
        tree.parse("""
            class A(metaclass=B):
                pass
        """)
        transformer = MetaclassTransformer()

    results = Test().results()
    assert type(results[0]) is ast.ImportFrom
    assert type(results[1]) is ast.ClassDef
    assert type(results[1].bases[0]) is ast.Call

# Generated at 2022-06-21 17:45:16.409874
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer().visit(
        ast.parse('''
        class A:
            pass
    ''')) == ast.parse('''
        class A:
            pass
    ''')

    assert MetaclassTransformer().visit(
        ast.parse('''
        class A(metaclass=B):
            pass
    ''')) == ast.parse('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A():
            pass
    ''')
