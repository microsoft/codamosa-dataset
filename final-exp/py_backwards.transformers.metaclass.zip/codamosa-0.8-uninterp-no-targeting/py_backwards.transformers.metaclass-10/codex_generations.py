

# Generated at 2022-06-21 17:35:22.302874
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.ClassDef(name='A', bases=[ast.Name(id='object', ctx=ast.Load())], body=[], keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))])
    expected = ast.ClassDef(name='A', bases=[ast.Call(func=ast.Name(id='_py_backwards_six_with_metaclass', ctx=ast.Load()), args=[ast.Name(id='B', ctx=ast.Load())], keywords=[])], body=[], keywords=[])

    transformer = MetaclassTransformer(2, 7)
    actual = transformer.visit_ClassDef(node)

    assert_equal(expected, actual)

# Generated at 2022-06-21 17:35:29.690355
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import os
    import sys
    import astor
    import astunparse
    import tempfile
    import typing
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class Foo(_py_backwards_six_withmetaclass(list)):
        pass

    class Bar(_py_backwards_six_withmetaclass(tuple, object)):
        pass


# Generated at 2022-06-21 17:35:30.659163
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import typed_ast.ast3

# Generated at 2022-06-21 17:35:37.051434
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class A(object):
        pass

    node = ast.parse('class A(object, metaclass=type):\n    pass')
    assert hasattr(node.body[0].bases[1], 'value')

    transformer = MetaclassTransformer()
    transformer.visit(node)

    # assert not hasattr(node.body[0].bases[1], 'value')
    assert hasattr(node.body[0].bases[0].args[1], 'id')
    assert node.body[0].bases[0].args[1].id == 'object'

# Generated at 2022-06-21 17:35:43.295340
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.fake import fake_module
    from ..utils.tree import get_source
    from .six_transformer import SixTransformer

    module = fake_module(
        six_import(),
        ast.ClassDef(name='A', bases=ast.List(elts=[ast.Name(id='B', ctx=ast.Load())]), keywords=[]),
    )
    module = SixTransformer().visit(module)
    module = MetaclassTransformer().visit(module)

# Generated at 2022-06-21 17:35:48.344855
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    mod = ast.parse('class A(metaclass=B): x=1')
    MetaclassTransformer().visit(mod)
    exec(compile(mod, '', 'exec'))
    assert A.x == 1



# Generated at 2022-06-21 17:35:56.883421
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse("""class A(metaclass=object): pass""")
    node = MetaclassTransformer().visit(module)
    first = node.body[0]
    assert isinstance(first, ast.ImportFrom)
    assert first.module == 'six'
    assert [alias.name for alias in first.names] == ['with_metaclass']


# Generated at 2022-06-21 17:36:03.583080
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import textwrap
    code = textwrap.dedent("""
    class C(object):
        pass
    """)

    node = ast.parse(code)
    MetaclassTransformer().visit(node)
    node = ast.fix_missing_locations(node)
    exec(compile(node, '', 'exec'))

    assert C.__class__.__name__ == 'with_metaclass'



# Generated at 2022-06-21 17:36:12.205632
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source

    source_str = source('''
    class A(metaclass=B):
        pass
    ''')

    # The rest of the module
    import astor

    MetaclassTransformer().visit(ast.parse(source_str))
    exec(compile(ast.parse(source_str), '<test>', 'exec'))
    assert astor.to_source(ast.parse(source_str)) == source('''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''')

# Generated at 2022-06-21 17:36:22.515350
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ast import dump

    class DummyTransformer(BaseNodeTransformer):
        def __init__(self):
            self.visited_nodes = []

        def visit(self, node: ast.AST) -> ast.AST:
            self.visited_nodes.append(node)
            return super().visit(node)

        @staticmethod
        def is_useful(tree: ast.AST) -> bool:
            return False

    m = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    transformer = MetaclassTransformer()
    dummy = DummyTransformer()
    result = transformer.visit(m)
    dummy.visit(result)

# Generated at 2022-06-21 17:36:32.707714
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .test_utils import make_test, round_trip

    class MockSix(object):
        def with_metaclass(self):
            return 1
    mock_six = MockSix()

    MetaclassTransformer.dependencies = [mock_six]

    make_test(MetaclassTransformer, 'class A(): pass', 'class A(): pass')
    make_test(MetaclassTransformer,
              'class A(metaclass=B): pass',
              'class A(_py_backwards_six_with_metaclass(B)): pass')

# Generated at 2022-06-21 17:36:34.619858
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:36:37.525016
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast as pyast
    from typing import List


# Generated at 2022-06-21 17:36:44.571946
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_ast_is
    from .dedent import dedent
    from .base import transform

    node = dedent('''
        class A(metaclass=B):
            pass
        ''')
    assert_ast_is(transform(node, MetaclassTransformer), 
                  dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        '''))

# Generated at 2022-06-21 17:36:55.373925
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tree = ast.parse("""
                from six import with_metaclass as _py_backwards_six_withmetaclass
                class B:pass
                class A(object,metaclass=(B)):
                    pass
                """)
    transformer = MetaclassTransformer()
    transformer.visit(tree)

# Generated at 2022-06-21 17:37:02.195690
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = """
    class A:
        pass
    class B(metaclass=C):
        pass
    """
    tree = ast.parse(code)
    t = MetaclassTransformer()
    result = t.visit(tree)
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A:
        pass
    class B(_py_backwards_six_withmetaclass(C)):
        pass
    """
    assert code_gen.to_source(result).strip() == expected.strip()

# Generated at 2022-06-21 17:37:08.044491
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.fixtures import u_test
    from .examples import metaclass_example
    from .examples import metaclass_expected

    code = metaclass_example.get_source().strip()
    tree = metaclass_example.get_tree()
    node = tree.body[0].body[0]

    u_test(MetaclassTransformer, code, tree, node)

# Generated at 2022-06-21 17:37:15.609016
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from py_backwards.transformers.six_metaclass import MetaclassTransformer

    tree = ast.parse('class A(metaclass=B): pass')
    node = tree.body[0]
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)

    assert transformer._tree_changed
    assert isinstance(new_node, ast.ClassDef)
    assert new_node.bases[0].value.func.id == '_py_backwards_six_withmetaclass'
    assert new_node.bases[0].value.args[0].id == 'B'

# Generated at 2022-06-21 17:37:24.489868
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import sys
    from typed_ast.ast3 import Module, parse
    from py_backwards.transformers.metaclass import MetaclassTransformer

    PATH = "test.py"

    if sys.version_info >= (3, 7):
        return True

    tests = [
        ("""
        @six.add_metaclass(metaclass_A)
        class B(C, D):
            pass
        """, """
        class B(_py_backwards_six_withmetaclass(metaclass_A, *[C, D])):
            pass
        """)
    ]

    for code, expected in tests:
        tree = parse(code)
        transformer = MetaclassTransformer(path=PATH)
        new_tree = transformer.visit(tree)

# Generated at 2022-06-21 17:37:25.917032
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:37:32.013166
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astunparse
    import inspect
    # given

# Generated at 2022-06-21 17:37:35.175856
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    transformer = MetaclassTransformer()

# Generated at 2022-06-21 17:37:41.504163
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    m = ast.parse('class A(metaclass=B): pass')
    MetaclassTransformer().visit(m)
    six_import_code = six_import.get_code()
    class_bases_code = class_bases.get_code()
    assert six_import_code + class_bases_code in ast.dump(m)

# Generated at 2022-06-21 17:37:47.069650
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """Test the visit_Module function of the MetaclaassTransformer class"""
    mod = ast.parse("class A(metaclass=type): pass")
    mod = MetaclassTransformer().visit(mod)
    assert ast.dump(mod) == "from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(type)):\n    pass"



# Generated at 2022-06-21 17:37:53.552975
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse("class A(metaclass=B, **kwargs): pass")
    node = MetaclassTransformer().visit(node)
    assert ast.dump(node) == "Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='A', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='B', ctx=Load())], keywords=[], starargs=None, kwargs=None)], keywords=[], body=[Pass()], decorator_list=[])])"

# Generated at 2022-06-21 17:37:55.073804
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mt = MetaclassTransformer()

# Generated at 2022-06-21 17:37:59.257403
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse('class A():\n    pass')
    expected = ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A():\n    pass')
    actual = MetaclassTransformer(None).visit_Module(node)
    assert ast.dump(expected) == ast.dump(actual)


# Generated at 2022-06-21 17:38:02.631982
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class MyClass(object):
        pass

    class MyClass2(metaclass=MyClass):
        pass

    node = ast.parse("class A(metaclass=B):"
                     "    pass")
    transformed = MetaclassTransformer().visit(node)
    expected = ("from six import with_metaclass as _py_backwards_six_withmetaclass\n"
                "class A(_py_backwards_six_withmetaclass(B))\n"
                "    pass")
    assert astunparse.unparse(transformed) == expected

# Generated at 2022-06-21 17:38:14.602502
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:38:22.829403
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = dedent('''
        class A(metaclass=B):
            pass
    ''')
    expected = dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B, )):
            pass
    ''')
    compile_node = ast.parse(code)
    MetaclassTransformer().visit(compile_node)
    assert ast.dump(compile_node) == ast.dump(ast.parse(expected))

# Generated at 2022-06-21 17:38:37.417757
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import typed_ast.ast3 as ast
    from py_backwards.transformers.base import BaseNodeTransformer
    class Foo(BaseNodeTransformer):
        pass
    transformer = Foo(target=(0, 0))
    node = ast.ClassDef(name='ClassName', bases=[], keywords=[], body=[], decorator_list=[])
    node.keywords.append(ast.keyword('metaclass', ast.Name(id='MetaClass', ctx=ast.Load())))
    new_node = transformer.visit_ClassDef(node)  # type: ignore

    assert len(new_node.bases) == 1
    assert isinstance(new_node.bases[0], ast.Call)
    assert isinstance(new_node.bases[0].func, ast.Name)
    assert new_node.b

# Generated at 2022-06-21 17:38:49.959924
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():

    class Dummy(object):
        def __init__(self, tree):
            self.tree_changed = False
            self.tree = tree

    tree = ast.parse("""class A(metaclass=B): pass""")
    node = MetaclassTransformer(Dummy(tree))
    node.visit(tree)
    output = ast.dump(tree)


# Generated at 2022-06-21 17:38:52.012184
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from py_backwards.visitors import node_name


# Generated at 2022-06-21 17:38:59.492790
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .fixtures.methods import classes_method
    node = classes_method.ast

    ct = MetaclassTransformer(node, (2, 7))
    ct.visit(node)

    assert ct._tree_changed == True
    assert isinstance(ct.node, ast.Module)

    # Imports
    assert isinstance(ct.node.body[0], ast.ImportFrom)
    assert isinstance(ct.node.body[1], ast.Assign)
    assert isinstance(ct.node.body[2], ast.ClassDef)


# Generated at 2022-06-21 17:39:07.304008
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code_before = """\
        class A(M, metaclass=B, c=1):
            def __init__(self):
                pass
    """
    code_after = """\
        class A(_py_backwards_six_withmetaclass(B, *[M, ]), c=1):
            def __init__(self):
                pass
    """
    from .test_pipeline import assert_transformation
    assert_transformation(MetaclassTransformer, code_before, code_after)


# Generated at 2022-06-21 17:39:14.336794
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class Test():
        def setup_method(self):
            self.t = MetaclassTransformer()

        def test_visit_Module(self):
            assert astunparse.unparse(self.t.visit(ast.parse('class A(): pass'))) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A():\n    pass\n'

        def test_visit_ClassDef(self):
            assert astunparse.unparse(self.t.visit(ast.parse('class A(metaclass=B): pass'))) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_with_metaclass(B)):\n    pass\n'

    test

# Generated at 2022-06-21 17:39:15.958028
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    x = MetaclassTransformer.snippets
    print(x)

# Generated at 2022-06-21 17:39:17.600712
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3, parse
    from ._testutils import round_trip


# Generated at 2022-06-21 17:39:25.395711
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    with open("examples/MetaclassTransformer/input.py") as content_file:
        input_source = content_file.read()
    with open("examples/MetaclassTransformer/output.py") as content_file:
        output_source = content_file.read()
    
    module = ast.parse(input_source)
    module = MetaclassTransformer().visit(module)
    assert ast.dump(module) == output_source


# Generated at 2022-06-21 17:39:30.206788
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testing import assert_transformed

    cls = '''
            class T(metaclass=type):
                pass
            '''
    expected = six_import.get_source() + '\n' + cls.strip().replace('(metaclass=type)', class_bases.get_body()) + '\n'
    assert_transformed(expected, cls, MetaclassTransformer)

# Generated at 2022-06-21 17:39:48.998538
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    assert transformer._tree_changed is False

    source = """class A(metaclass=B):
    pass"""
    tree = ast.parse(source)

    transformer.visit(tree)
    assert transformer._tree_changed


# Generated at 2022-06-21 17:39:55.345717
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    src = '''
    class A(metaclass=B):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B, object)):
        pass
    '''
    modules, flags = compile_snippet(src, MetaclassTransformer)
    assert len(modules) == 1
    assert modules[0].source == expected



# Generated at 2022-06-21 17:39:56.376171
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    pass


# Generated at 2022-06-21 17:40:01.880271
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    assert transformer.visit_ClassDef(ast_parse("class A(object): pass").body[0]) == transformer.visit_ClassDef(ast_parse("class A(_py_backwards_six_withmetaclass(object)): pass").body[0])

# Generated at 2022-06-21 17:40:06.238130
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class_source = "class A(metaclass=B): pass"
    module_node = ast.parse(class_source)  # type: ast.Module
    tr = MetaclassTransformer()
    res = tr.visit(module_node)

# Generated at 2022-06-21 17:40:15.390819
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer((2, 7)).visit_Module(ast.parse('pass')) \
        == ast.parse(dedent("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        pass
        """))

    assert MetaclassTransformer((2, 7)).visit_ClassDef(ast.parse('class A(B, metaclass=C): pass').body[0]) \
        == ast.parse(dedent("""
        class A(_py_backwards_six_withmetaclass(C, *[B])):
            pass
        """))

# Generated at 2022-06-21 17:40:20.281355
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # given
    code = 'class A(metaclass=B):\n    pass\n'
    tree = ast.parse(code)
    transformer = MetaclassTransformer()

    # when
    transformed = transformer.visit(tree)

    # then

# Generated at 2022-06-21 17:40:27.395706
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = """
    class A(metaclass=B):
        pass
    """
    expected_code = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = ast.parse(code)
    MetaclassTransformer().visit(tree)
    assert ast.dump(tree) == expected_code

    code = """
    class A(B, metaclass=C):
        pass
    
    class D(E, metaclass=F):
        pass
    """

# Generated at 2022-06-21 17:40:39.420003
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Test method visit_ClassDef of class MetaclassTransformer"""
    # Arrange
    from ...converter import Py2PyConverter
    from ... import parse

    tree = parse('''
    class A(metaclass=B):
        pass
    ''')
    transformer = MetaclassTransformer()
    converter = Py2PyConverter(transformer=transformer)

    # Act
    result = converter.convert(tree)

    # Assert
    exp_tree = parse('''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B, )):
        pass
    ''')

# Generated at 2022-06-21 17:40:50.597653
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .transpile import transpile
    from typed_ast import ast3 as ast

    code = """class A(metaclass=B): pass"""
    expected = """class A(_py_backwards_six_withmetaclass(B)): pass\n"""

    module = transpile(code, target=3, flags=['six'])
    node = module.body[0]
    assert isinstance(node, ast.ClassDef)
    assert len(node.bases) == 1
    assert isinstance(node.bases[0], ast.Call)
    assert len(node.bases[0].args) == 2
    assert isinstance(node.bases[0].args[1], ast.List)
    assert len(node.bases[0].args[1].elts) == 0

# Generated at 2022-06-21 17:41:05.928793
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    node = ast.parse('class A(metaclass=B):\n  pass')
    transformer.visit(node)
    exec(compile(node, filename="<ast>", mode="exec"), globals())
    assert A.__class__ == _py_backwards_six_withmetaclass

# Generated at 2022-06-21 17:41:11.816287
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    # 1. Setup
    code = """
    class A(type):
        pass
    """
    expected_code = """
    _py_backwards_six_withmetaclass(type, A)
    """
    expected_tree = ast.parse(expected_code)

    # 2. Exercise
    tree = ast.parse(code)
    transformer = MetaclassTransformer()
    transformed_tree = transformer.visit(tree)

    # 3. Verify
    assert transformer._tree_changed
    assert ast.dump(transformed_tree) == ast.dump(expected_tree)

# Generated at 2022-06-21 17:41:19.040244
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = six_import.get_code().strip() + '\n' + "class Foo(bar):\n    pass"
    expected_code = code.replace('bar', '_py_backwards_six_withmetaclass(Foo, bar)')
    tree = ast.parse(code)
    assert MetaclassTransformer().visit(tree) is not None
    assert ast.dump(tree, include_attributes=True) == ast.dump(ast.parse(expected_code), include_attributes=True)


# Generated at 2022-06-21 17:41:26.288098
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    src = """\
        class A(metaclass=B):
            pass
    """
    expected = """\
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    assert MetaclassTransformer.test_single(src) == expected

# Generated at 2022-06-21 17:41:29.362391
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..test_utils import transform_test_case


# Generated at 2022-06-21 17:41:31.275694
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as pyast

# Generated at 2022-06-21 17:41:37.888163
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    node = ast.parse("class A(metaclass=B): pass")
    transformer.visit(node)

    expected = "from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)): pass"
    assert astor.to_source(node) == expected

# Generated at 2022-06-21 17:41:47.767021
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    snippet = snippet(
            '''
            class A(metaclass=B):
                pass
            '''
        )

    node = ast.parse(snippet.get_source())  # type: ast.Module
    MetaclassTransformer().visit(node)

    assert snippet.get_target_source() == compile(node, filename="<ast>", mode="exec").co_consts[1]



# Generated at 2022-06-21 17:41:56.870918
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..testing import coverage_testing
    from .test_six import test_six_import
    from .utils import assert_tree_equal
    from .test_class_bases import test_class_bases

    node_to_test = ast.parse(
        """class A(b): pass
        """)


# Generated at 2022-06-21 17:42:00.398707
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    prog = ast.parse("""
        class A(metaclass=B):
            pass
    """)
    trans = MetaclassTransformer()
    trans.visit(prog)
    assert str(prog) == """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B),):
            pass
    """[1:]

# Generated at 2022-06-21 17:42:27.022229
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class TestMetaclassTransformer(unittest.TestCase):
        def test_metaclass(self):
            code = """
            class A(metaclass=B):
                pass
            """

            expected = """
            from six import with_metaclass as _py_backwards_six_withmetaclass

            class A(_py_backwards_six_withmetaclass(B)):
                pass
            """

            tree = ast_parse(code)

            transformer = MetaclassTransformer()
            transformer.visit(tree)

            self.assertEqual(astunparse(tree), expected)

        def test_metaclasses(self):
            code = """
            class A(metaclass=B, C):
                pass
            """


# Generated at 2022-06-21 17:42:28.590439
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.localized_ast import parse


# Generated at 2022-06-21 17:42:39.823352
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .util import source_to_ast as sta
    from .util import ast_to_source as ats
    from .. import transform

    source = """class A(metaclass=B):
    pass"""
    target = """from six import with_metaclass as _py_backwards_six_withmetaclass
\nclass A(_py_backwards_six_withmetaclass(B)):
    pass"""
    tree = sta(source)
    new_tree = MetaclassTransformer().visit(tree)  # type: ignore
    result = ats(new_tree)
    transform(source, MetaclassTransformer) == target

# Generated at 2022-06-21 17:42:51.726610
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import Source
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        target_versions = (2, 7)
        transformer = MetaclassTransformer
        transform_source = Source("""
        class A(metaclass=B):
            pass
        class B(metaclass=C):
            pass
        class C(D):
            pass
        class D:
            pass
        """)

# Generated at 2022-06-21 17:43:01.478115
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..compat import typed_ast
    from ..upgrader import Upgrader
    from .. import fixer_log

    Upgrader.fixer_log = fixer_log

    code = """class A(metaclass=B): pass"""
    node = typed_ast.ast3.parse(code, mode='exec')
    new_node = MetaclassTransformer().visit(node)
    assert node is not new_node
    assert typed_ast.ast3.dump(node) == typed_ast.ast3.dump(new_node)

# Generated at 2022-06-21 17:43:05.508340
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    mt = MetaclassTransformer(target_context=DummyContext)
    

# Generated at 2022-06-21 17:43:11.947189
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class TestMetaclassTransformer(MetaclassTransformer):
        def visit_Import(self,n):
            raise ValueError(n)
        def visit_ImportFrom(self,n):
            raise ValueError(n)

    tree = ast.parse('import six\nclass A(metaclass=None): pass\n')
    TestMetaclassTransformer().visit(tree)
    assert 'six' not in tree._fields
    assert '_py_backwards_six_withmetaclass' in tree._fields



# Generated at 2022-06-21 17:43:21.402906
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astunparse

    code = "class A(metaclass=B):\n    pass"

    module = ast.parse(code)
    MetaclassTransformer().visit(module)

    exp = ("from six import with_metaclass as _py_backwards_six_withmetaclass\n"
           "class A(_py_backwards_six_withmetaclass(B))")

    assert astunparse.unparse(module) == exp

# Generated at 2022-06-21 17:43:22.567119
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:43:31.969920
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = """\
    class A(metaclass=B):
        pass
    """
    compiled_code = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B, *[])):
        pass
    """
    module = source_to_ast.parse(code)
    module = MetaclassTransformer().visit(module)  # type: ignore
    assert ast_to_source.dump_python_source(module) == compiled_code

# Generated at 2022-06-21 17:44:31.575017
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base_tester import BaseTester
    from .base_tester import SKIP

    def test_metaclass_visit_ClassDef(self, before, after):
        self.generic_test(before, after)

    BaseTester.test_metaclass_visit_ClassDef = test_metaclass_visit_ClassDef

    class_before = """
        class A(metaclass=B):
            pass
        """

    class_after = """
        class A(_py_backwards_six_withmetaclass(B, object)):
            pass
        """

    tests = [
        # (before, after),
        (class_before, class_after),
    ]

    BaseTester.run_tests(tests, MetaclassTransformer)
    # tester = BaseTester()


# Generated at 2022-06-21 17:44:40.437159
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    module = ast.parse(
        '\n'.join([
            six_import.src,
            class_bases.src,
            'class A(object, metaclass=B):',
            '    pass',
        ]), mode='exec')
    MetaclassTransformer.run(module)
    assert ast.dump(module) == '\n'.join([
        six_import.src,
        class_bases.src,
        'class A(_py_backwards_six_withmetaclass(B)):',
        '    pass',
    ])

# Generated at 2022-06-21 17:44:49.525323
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from literal_exec import ast_parse
    from ..utils.source import source_to_unicode

    source = class_bases.dedent("""
        class A(metaclass=B):
            pass
    """)
    expected = class_bases.dedent("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """).strip()

    tree = ast_parse(source)
    MetaclassTransformer().visit(tree)

    output = source_to_unicode(tree)
    assert output == expected



# Generated at 2022-06-21 17:44:52.528400
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import parse
    import astor

    class Foo(metaclass=type):
        pass
    

# Generated at 2022-06-21 17:44:55.266875
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import cst_to_ast
    cst = """
    class A(metaclass=B, foo=bar):
        pass
    """
    a = cst_to_ast(cst)
    MetaclassTran

# Generated at 2022-06-21 17:44:59.059319
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-21 17:45:04.469261
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast

    transformer = MetaclassTransformer()
    module = ast.parse('class A(metaclass=B): pass')
    transformer.visit(module)
    assert transformer._tree_changed is True
    # For whatever reason the formatting of the AST dump seems to be inconsistent
    assert module.body[-1].bases[0].func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-21 17:45:13.591716
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .test_utils import make_dummy_env, compare_ast
    from ..utils.source import source_to_unicode

    env = make_dummy_env()
    MetaclassTransformer(env).visit(env.tree)
    actual = source_to_unicode(env.tree)
    assert compare_ast(actual, """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        
        class Foo(_py_backwards_six_withmetaclass(Bar)):
            pass
        """).strip()