

# Generated at 2022-06-21 17:35:08.666206
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    tree = ast.parse("""
        class A(metaclass=int):
            pass
        """)
    transformer.visit(tree)

    assert transformer._tree_changed
    assert transformer.dependencies == ['six']
    assert transformer.target == (2, 7)
    assert transformer.get_result() == """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(int)):
            pass
        """

# Generated at 2022-06-21 17:35:09.567988
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:35:13.399973
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from six import PY3

# Generated at 2022-06-21 17:35:23.183619
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import textwrap
    from ..utils import roundtrip
    from ..sixutils import six_import

    six_def = six_import.get_definition()

    def do(src):
        src = textwrap.dedent(src)
        m = ast.parse(src)
        m = roundtrip(m)
        m = roundtrip(m)
        return m

    m = do('''
    class Test(metaclass=type):
        pass
    ''')
    assert str(m.body[0]) == 'class Test(): pass'
    assert str(m.body[1]) == six_import.get_definition()


# Generated at 2022-06-21 17:35:29.571939
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mt = MetaclassTransformer()
    node = ast.parse(
        'class A(metaclass=B, x=y):\n'
        '    pass\n'
        '.\n'
    )
    new_node = mt.visit(node)
    assert new_node != node
    assert new_node.body[0].body[0].bases[0].elts[0].value == '_py_backwards_six_withmetaclass(B)'
    assert new_node.body[1].value == '.'
    assert new_node.body[0].bases == [ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load())]

# Generated at 2022-06-21 17:35:35.160471
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    content = "class A(metaclass=B): pass"
    tree = MetaclassTransformer.run(ast.parse(content))
    result = astor.to_source(tree).rstrip()
    expected = "from six import with_metaclass as _py_backwards_six_withmetaclass\n" \
               "class A(_py_backwards_six_withmetaclass(B)): pass"
    print(result)
    assert result == expected

# Generated at 2022-06-21 17:35:35.955449
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:35:43.152505
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import transform, assert_equal_code, assert_equal_ast

    code = "class A(metaclass=B): pass"

    expected_ast = ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

    expected_code = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    transform(MetaclassTransformer, code, expected_ast=expected_ast, expected_code=expected_code)


# Generated at 2022-06-21 17:35:45.252455
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    transformer = MetaclassTransformer()

# Generated at 2022-06-21 17:35:51.614169
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', DeprecationWarning)
        module = ast.parse('class A(metaclass=B,): pass')
        MetaclassTransformer().visit(module)
        assert MetaclassTransformer().snippets_used == {'six.with_metaclass', '_py_backwards_six_withmetaclass'}
        exec(compile(module, filename="<ast>", mode="exec"), {})

# Generated at 2022-06-21 17:35:55.029495
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    pass

# Generated at 2022-06-21 17:35:59.735222
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Make sure that the code string evaluates to an AST object
    code = """
    class A(metaclass=B):
        pass
    """
    expected_ast = ast.parse(dedent(code))

    transformer = MetaclassTransformer()
    result_ast = transformer.visit(expected_ast)

    # assert that the snippet was inserted
    expected_import_ast = snippet_to_ast(six_import)
    assert expected_import_ast in result_ast.body



# Generated at 2022-06-21 17:36:01.801157
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    transformer = MetaclassTransformer()

# Generated at 2022-06-21 17:36:06.899053
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert len(MetaclassTransformer.__bases__) == 1
    assert MetaclassTransformer.__bases__[0] == BaseNodeTransformer
    assert MetaclassTransformer.__module__ == __name__
    return MetaclassTransformer

# Generated at 2022-06-21 17:36:13.991591
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import textwrap
    source_code = textwrap.dedent(
        """
        class A(metaclass=B):
            pass
        """
    )
    node = ast.parse(source_code)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    result_source_code = textwrap.dedent(
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    )
    result = ast.parse(result_source_code)
    assert ast.dump(node) == ast.dump(result)

# Generated at 2022-06-21 17:36:23.194932
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import six
    from pt.visitors.base import BaseNodeTransformer

    # Given
    class MetaclassTransformerTest(BaseNodeTransformer):
        def __init__(self):
            super(MetaclassTransformerTest, self).__init__()
            self._tree_changed = False

    node = ast.ClassDef(name='A', bases=[six.with_metaclass(object)],
                        keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='object', ctx=ast.Load()))])

    # When
    result = MetaclassTransformerTest().visit_ClassDef(node)

    # Then
    from pt.parsers.typed_ast_parser import parse
    assert parse(result) == parse

# Generated at 2022-06-21 17:36:26.333476
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import compile_source

    source = """
    class A(metaclass=B):
        def f(self):
            pass
    """
    node = compile_source(source, '<test>', 'exec')
    MetaclassTransformer().visit(node)
    assert compiler.ast_to_source(node).strip() == """
    class A(_py_backwards_six_withmetaclass(B)):
        def f(self):
            pass
    """.strip()

# Generated at 2022-06-21 17:36:28.946783
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse("""
        class A(metaclass=B):
            pass
    """)
    assert MetaclassTransformer(module).tree == ast.parse("""
        from six import with_metaclass as _py_backwards_six_with_metaclass


        class A(_py_backwards_six_with_metaclass(B)):
            pass
    """)

# Generated at 2022-06-21 17:36:31.622116
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()

# Generated at 2022-06-21 17:36:38.872525
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    metaclass_transformer = MetaclassTransformer(target_version=(2, 7))
    result = metaclass_transformer(
        """
        class A(metaclass=B):
            pass
        """
    )
    assert result == """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B, object)):
            pass

        """

# Generated at 2022-06-21 17:36:54.006157
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typing import List, Union
    from ..compile import parse
    from ..utils.tree import node_name

    source = "class A(metaclass=B):\n" \
             "    pass\n"
    tree = parse(source).body
    print(tree)
    node = tree[0]
    assert isinstance(node, ast.ClassDef)
    assert isinstance(node.bases[0], ast.Name)
    assert node.bases[0].id == "B"

    assert node.keywords[0].arg == "metaclass"

    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)
    assert transformer._tree_changed

    node = tree[0]
    assert isinstance(node, ast.ClassDef)

# Generated at 2022-06-21 17:36:54.510531
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:37:02.666114
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .helper import transform
    import ast

    @transform()
    class Test(metaclass=Aasdf):
        pass

    # We use ast.dump() rather than str() because ast.dump() will include
    # line numbers and column offsets which can help in debugging.

# Generated at 2022-06-21 17:37:08.655208
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_cases = ["", "import six", "from six import with_metaclass as _py_backwards_six_withmetaclass\n"]

    for test_case in test_cases:
        t = MetaclassTransformer()

        assert compile(t.visit(ast.parse(test_case)), "<ast>", "exec") == compile(test_case + six_import.get_body(), "<ast>", "exec")


# Generated at 2022-06-21 17:37:16.631690
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import codegen
    from .fake import FakeOptions, FakeFutureFeature
    from .future import FutureTransformer

    class FakeCompiler(BaseCompiler):
        def __init__(self):
            self.options = FakeOptions()
            self.future_features = [FakeFutureFeature(True, 'with_statement')]
            self.transformer = FutureTransformer(self)

    c = FakeCompiler()
    c.transformer.visit(MetaclassTransformer(c).visit(c.transformer.visit(ast.parse(
        '''
        import six

        class A(metaclass=int):
            pass
        '''
    ))))

# Generated at 2022-06-21 17:37:23.267713
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    transformer = MetaclassTransformer(target_version=(2, 7))
    tree = ast.parse("""
    import os
    class A:
        pass
    """)
    new_tree = transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(new_tree) == "\n".join([
        "import os",
        "from six import with_metaclass as _py_backwards_six_withmetaclass",
        "class A:",
        "    pass",
    ])


# Generated at 2022-06-21 17:37:28.392787
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import six
    six = six_import.snippet_to_ast()
    six.parent = None
    assert MetaclassTransformer().visit_Module(six) == six_import.get_body()


# Generated at 2022-06-21 17:37:36.528663
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    _test_MetaclassTransformer = MetaclassTransformer()

    class TMetaclassTransformer(unittest.TestCase):

        def check_metaclass_transformer(self, before, after):
            node = ast.parse(before)
            transformed = _test_MetaclassTransformer.visit(node)
            self.assertEqual(ast.dump(transformed), after)

        def test_metaclass_transformer(self):
            before = """
            class A(B):
                pass
            """
            after = """
            class A(_py_backwards_six_withmetaclass(B)):
                pass
            """
            self.check_metaclass_transformer(before, after)

# Generated at 2022-06-21 17:37:44.557749
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from textwrap import dedent
    import astor
    from .test_base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        def _test_code_before(self):
            return dedent("""
            class A(metaclass=abc.ABCMeta):
                pass
            """)

        def _test_code_after(self):
            return dedent("""
            from six import with_metaclass as _py_backwards_six_withmetaclass
            
            class A(_py_backwards_six_withmetaclass(abc.ABCMeta)):
                pass
            """)

    TestCase().run(MetaclassTransformer)

# Generated at 2022-06-21 17:37:51.391269
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    metaclass = ast.Name(id='Meta', ctx=ast.Load())
    bases = [ast.Name(id='Base1', ctx=ast.Load())]
    result = class_bases.get_body(metaclass=metaclass, bases=bases)
    assert len(result) == 1
    assert result[0].func.attr == 'with_metaclass'
    assert result[0].args[0].id == 'Meta'
    assert result[0].args[1].id == 'Base1'

# Generated at 2022-06-21 17:38:00.818967
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..unittest_tools import assert_code_equal, build_module_from_snippets

# Generated at 2022-06-21 17:38:01.522497
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import parse_snippet


# Generated at 2022-06-21 17:38:05.384255
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source

    code = source(MetaclassTransformer)

    assert 'six_import' in code
    assert 'class_bases' in code


transform = MetaclassTransformer.as_visitor()

# Generated at 2022-06-21 17:38:12.031897
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from . import compile

    assert compile(
        'class A(metaclass=B): pass', from_version=(2, 7), to_version=None) == \
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass\n'



# Generated at 2022-06-21 17:38:15.234015
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """Tests that the constructor of MetaclassTransformers works correctly."""
    m = MetaclassTransformer()
    assert m.target == (2, 7)
    assert m.dependencies == ['six']



# Generated at 2022-06-21 17:38:16.846000
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transform = MetaclassTransformer()

# Generated at 2022-06-21 17:38:22.792640
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("class A(metaclass=B):\n    pass")
    expected = ast.parse("from six import with_metaclass as _py_backwards_six_with_metaclass\n\nclass A(metaclass=B):\n    pass")
    result = MetaclassTransformer().visit(node)
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-21 17:38:30.694709
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    class A(metaclass=B):
        pass
    """
    import ast
    import textwrap
    from lib2to3.pgen2 import token
    from libfuturize.fixer_util import Name
    from libfuturize.fixes.six import MetaclassTransformer
    #
    tree = ast.parse(textwrap.dedent('''
        class A(metaclass=B):
            pass
    '''))
    transformer = MetaclassTransformer()
    result = transformer.visit(tree)
    #

# Generated at 2022-06-21 17:38:35.129236
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_with_metaclass(B))
    """
    assert MetaclassTransformer.run_ansi(code) == expected

# Generated at 2022-06-21 17:38:37.149979
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:39:00.583857
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    from .base import BaseNodeTransformer
    from .methoddef_decorator import MethodDefDecoratorTransformer
    from .metaclass import MetaclassTransformer
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at

    methoddef_snippet = snippet('''
    class A(metaclass=B):
        def foo(self):
            pass
    ''')
    methoddef_tree = methoddef_snippet.get_tree()
    node = MetaclassTransformer().visit(methoddef_tree)
    print(astor.to_source(node))

# Generated at 2022-06-21 17:39:06.393360
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    assert compile(MetaclassTransformer().visit(tree), '<string>', 'exec') == compile("""
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """, '<string>', 'exec')

# Generated at 2022-06-21 17:39:07.718722
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..testing import assert_transformed


# Generated at 2022-06-21 17:39:14.507479
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    m = ast.parse('class A(metaclass=B):\n    pass')
    trans = MetaclassTransformer()
    trans.visit(m)
    assert trans._tree_changed

# Generated at 2022-06-21 17:39:26.060217
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = "class A():\n    pass"
    expected = "class A():\n    pass"

    # noinspection PyTypeChecker
    visitor = MetaclassTransformer()
    actual = visitor.visit(ast.parse(source))
    assert ast.dump(actual) == expected

    source = "class A(metaclass=B):\n    pass"
    expected = "from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass"

    # noinspection PyTypeChecker
    visitor = MetaclassTransformer()
    actual = visitor.visit(ast.parse(source))
    assert ast.dump(actual) == expected


# Generated at 2022-06-21 17:39:37.666364
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    tree = ast.parse(six_import.get_source() + class_bases.get_source())
    m = MetaclassTransformer(2, '.')
    tree = ast.fix_missing_locations(m.visit(tree))
    assert m._tree_changed

# Generated at 2022-06-21 17:39:43.389502
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    from ..utils.unparse import Unparser
    import typed_astunparse

    text = textwrap.dedent("""
    class A(B, metaclass=C):
        pass
    """)
    tree = typed_astunparse.ast_parse(text)  # type: ignore
    m = MetaclassTransformer()
    tree = m.visit(tree)
    up = Unparser(tree)
    text2 = up.totext()
    text2 = text2.replace("(metaclass=C)", "").replace("_py_backwards_six_withmetaclass", "with_metaclass")

# Generated at 2022-06-21 17:39:50.483286
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    original = ast.parse('''
    class A(B, metaclass=C):
        pass
    ''')
    expected = ast.parse('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(C, B)):
        pass
    ''')
    transformer = MetaclassTransformer(original)
    result = transformer.visit(original)

    assert result == expected

# Generated at 2022-06-21 17:40:01.361271
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # test 2.7
    node = ast.parse("class C(B, metaclass=A): pass", version=2.7)
    transformer = MetaclassTransformer()
    transformed = transformer.visit(node)
    assert transformed.body == six_import.get_body() + [
        ast.ClassDef(name='C',
                     bases=[class_bases.get_body(metaclass=ast.Name(id='A'),
                                                 bases=ast.List(elts=[ast.Name(id='B')]))],
                     body=[],
                     decorator_list=[],
                     keywords=[])]

    # test 3.7
    node = ast.parse("class C(B, metaclass=A): pass", version=3.7)
    transformer = MetaclassTransformer()
    transformed = transformer

# Generated at 2022-06-21 17:40:03.599832
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..tests.test_utils import transform
    from ..ast_utils import dump


# Generated at 2022-06-21 17:40:41.260675
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()

    class_def = ast.ClassDef(name='Test',
                             bases=[],
                             keywords=[],
                             body=[],
                             decorator_list=[])
    class_def = transformer.visit(class_def)
    assert [] == class_def.bases
    assert [] == class_def.keywords

    class_def = ast.ClassDef(name='Test',
                             bases=[ast.Name(id='abc', ctx=ast.Load())],
                             keywords=[],
                             body=[],
                             decorator_list=[])
    class_def = transformer.visit(class_def)
    assert [ast.Name(id='abc', ctx=ast.Load())] == class_def.bases
    assert [] == class_def.keywords



# Generated at 2022-06-21 17:40:48.317353
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ...testing import assert_text_transformed
    assert_text_transformed(MetaclassTransformer, """
        class A(metaclass=B):
            pass

        """, """
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(_py_backwards_six_withmetaclass(B)):
            pass

        """)



# Generated at 2022-06-21 17:41:00.364269
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import textwrap
    from ..exceptions import BackportException
    from ..utils.ast_convenience import parse_ast, compare_ast

    module_with_meta = textwrap.dedent("""
        class A(metaclass=B):
            pass
    """)

    expected = textwrap.dedent("""
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    mt = MetaclassTransformer()
    ast_module = parse_ast(module_with_meta)
    mt.visit(ast_module)
    assert compare_ast(ast_module, expected)


# Generated at 2022-06-21 17:41:07.651198
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    ast_node = ast.ClassDef(bases=[], name="Foo", keywords=[ast.keyword(arg="metaclass", value=ast.Name(id="Bar", ctx=ast.Load()))], body=[])
    result = MetaclassTransformer().visit(ast_node)
    expected = ast.ClassDef(bases=[], name="Foo", keywords=[], body=[])
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-21 17:41:09.390304
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:41:11.298205
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 17:41:16.200884
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3
    from typed_ast.ast3 import parse
    
    import sys
    
    if sys.version_info < (3, 5):
        # skipping test because typed_ast is not available for python 2
        # this test can only run for python 3
        return


# Generated at 2022-06-21 17:41:28.549801
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    from ...utils.tree import find
    from ...utils.source import source

    import six
    six_import.set_globals(six=six)

    # def visit_ClassDef(self, node: ast3.ClassDef) -> ast3.ClassDef:
    #     if node.keywords:
    #         metaclass = node.keywords[0].value
    #         node.bases = class_bases.get_body(metaclass=metaclass,  # type: ignore
    #                                           bases=ast3.List(elts=node.bases))
    #         node.keywords = []
    #         self._tree_changed = True
    #
    #     return self.generic_visit(node)  # type: ignore

# Generated at 2022-06-21 17:41:36.228385
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = """
    class A(metaclass=C):
        pass
    """
    assert_equal(MetaclassTransformer(code).run(), """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(_py_backwards_six_withmetaclass(C)):
        pass""")


# Generated at 2022-06-21 17:41:49.359236
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class TestContent(object):
        def __init__(self, src, expected_src):
            self.src = src
            self.expected_src = expected_src
    

# Generated at 2022-06-21 17:43:04.923822
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import typed_astunparse
    from .stubs import MyMeta
    from .stubs import Builtin
    from .stubs import MyBase
    from .stubs import with_metaclass
    from .stubs import sys

    root_node = ast.parse('class MyClass(metaclass=MyMeta): pass')
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(root_node)

# Generated at 2022-06-21 17:43:06.515355
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:43:09.059732
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast as pyast
    from ..compiler import Compiler
    import six


# Generated at 2022-06-21 17:43:17.615724
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import ClassDef, Str, Load, Name, List, Pass, \
        Assign, arguments, NodeTransformer, Mark, alias, parse
    from py_backwards.utils.snippet import Snippet
    metaclass_class = parse('class test_metaclass(object):\n    pass')
    metaclass = metaclass_class.body[0]
    metaclass.name = 'test_metaclass'
    impo = parse('import six')
    statement1 = parse('from six import with_metaclass as _py_backwards_six_withmetaclass')
    statement2 = parse('_py_backwards_six_withmetaclass(test_metaclass, *bases)')

# Generated at 2022-06-21 17:43:23.102831
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.node import NodeTransformerTest
    class A(NodeTransformerTest):
        transformer = MetaclassTransformer
        target_version = (3, 7)
        before = """class A(metaclass=B, c=d): pass"""

# Generated at 2022-06-21 17:43:27.298573
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    assert transformer.generic_visit is ast.NodeTransformer.generic_visit



# Generated at 2022-06-21 17:43:29.294212
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    t = MetaclassTransformer()
    assert isinstance(t, BaseNodeTransformer)

# Generated at 2022-06-21 17:43:39.782661
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast
    import textwrap
    module = ast.parse(textwrap.dedent("""
    class A(metaclass=type):
        pass
    """))
    transformer = MetaclassTransformer()
    node = transformer.visit(module)
    assert isinstance(node, ast.Module)
    assert len(node.body) == 4
    assert isinstance(node.body[0], ast.ImportFrom)
    assert isinstance(node.body[1], ast.Assign)
    assert isinstance(node.body[2], ast.ClassDef)
    assert isinstance(node.body[3], ast.Expr)


# Generated at 2022-06-21 17:43:42.231904
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # Test if class MetaclassTransformer is defined
    metaclass_transformer = MetaclassTransformer()
    assert metaclass_transformer is not None


# Generated at 2022-06-21 17:43:46.806564
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    six_import = """
from six import with_metaclass as _py_backwards_six_with_metaclass"""

    class_bases = """
_py_backwards_six_with_metaclass(metaclass, *bases)"""
