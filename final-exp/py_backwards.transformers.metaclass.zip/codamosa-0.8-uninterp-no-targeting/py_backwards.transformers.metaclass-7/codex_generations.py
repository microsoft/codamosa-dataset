

# Generated at 2022-06-21 17:35:14.936941
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:35:16.645274
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from . import remove_imports


# Generated at 2022-06-21 17:35:26.622462
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    snippet_input = """
        class A(object, metaclass=B, name='A'):
            pass
    """
    snippet_output = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B, object)):
            pass
    """
    node = ast.parse(snippet_input)
    MetaclassTransformer().visit(node)
    assert ast.dump(node) == snippet_output

# Generated at 2022-06-21 17:35:30.020898
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:35:41.786679
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer({})
    result = transformer.visit(ast.parse("class X(y,metaclass=z):pass"))
    assert transformer.is_changed()
    assert ast.dump(result, include_attributes=False) == \
        "Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_with_metaclass')], level=0), ClassDef(name='X', bases=Call(func=Name(id='_py_backwards_six_with_metaclass', ctx=Load()), args=[Name(id='z', ctx=Load())], keywords=[], starargs=None, kwargs=None), body=[Pass()], decorator_list=[], keywords=[])])"



# Generated at 2022-06-21 17:35:52.984269
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    global _py_backwards_six_withmetaclass

    module = ast.parse("""
        class A(metaclass=B):
            pass
        """)
    assert isinstance(module, ast.Module)
    assert isinstance(module.body[0], ast.ClassDef)
    assert module.body[0].keywords[0].arg == "metaclass"
    _py_backwards_six_withmetaclass = lambda metaclass, *bases: bases

    MetaclassTransformer().visit(module)
    assert isinstance(module.body[0], ast.ClassDef)
    assert module.body[0].keywords == []
    assert module.body[0].bases[0].body[0].value.func.id == "_py_backwards_six_withmetaclass"

# Generated at 2022-06-21 17:35:57.229493
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.unit_tester import assert_equals_ast, run_local_tests
    run_local_tests()

# Code to run if called from the command line
if __name__ == '__main__':
    from ..utils.unit_tester import run_unittest, run_doctest
    run_unittest(test_MetaclassTransformer)
    run_doctest()

# Generated at 2022-06-21 17:36:06.470161
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """

    node = ast.parse(source)
    node = MetaclassTransformer().visit(node)
    result = ast.unparse(node)
    assert expected == result

    # This tree should be unchanged
    node = ast.parse(source)
    node = MetaclassTransformer().visit(node)
    result = ast.unparse(node)
    assert expected == result



# Generated at 2022-06-21 17:36:13.652593
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    class C:
        pass

    class ClassDef(ast.ClassDef):
        def __init__(self, name: ast.Name, bases: ast.List, body: ast.List, keywords: ast.List, starargs: ast.Name, kwargs: ast.Name,):
            self.name = name
            self.bases = bases
            self.body = body
            self.keywords = keywords
            self.starargs = starargs
            self.kwargs = kwargs

    class Name(ast.Name):
        def __init__(self, id: str, ctx: ast.ast3.Store,):
            self.id = id
            self.ctx = ctx


# Generated at 2022-06-21 17:36:21.126707
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..tests.utils import round_trip
    from ..utils.source import source

    example = source('''
        class A(metaclass=B):
            pass
    ''')
    transformed = source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')
    assert round_trip(example, MetaclassTransformer) == transformed


# Generated at 2022-06-21 17:36:33.210799
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as ast

    # Create a test AST for the following input:
    # class MyClass(metaclass=Meta):
    #     pass

    classdef_node = ast.ClassDef(name='MyClass', bases=[], keywords=[],
                                 body=[ast.Pass()], decorator_list=[])
    classdef_node.keywords.append(ast.keyword(arg='metaclass', value=ast.Name(id='Meta', ctx=ast.Load())))

    # Initialize MetaclassTransformer with test AST
    transformer = MetaclassTransformer()
    transformer.visit(classdef_node)

    # The resulting AST should be:
    # class MyClass(_py_backwards_six_with_metaclass(Meta))
    #     pass


# Generated at 2022-06-21 17:36:41.727916
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import parse
    class_def: ast.ClassDef = parse(
        textwrap.dedent(
            """
            class X(metaclass=type):
                pass
            """
        )
    ).body[0]
    assert type(class_def.keywords[0].value) is ast.Name
    assert class_def.keywords[0].arg == 'metaclass'

    class_def_transformed: ast.ClassDef = MetaclassTransformer().visit(class_def)
    assert type(class_def_transformed.bases[0]) is ast.Call
    assert type(class_def_transformed.bases[0].func) is ast.Attribute
    assert class_def_transformed.bases[0].func.attr == 'type'
    assert class_def

# Generated at 2022-06-21 17:36:53.006646
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Test if:
        class A(metaclass=B, C):
            pass
    Is compiled to:
        class A(_py_backwards_six_with_metaclass(B, C))
    """

    class_def = ast.ClassDef('A',
                             bases=[ast.Name('C', ast.Load()),
                                    ast.Name('D', ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name('B', ast.Load()))],
                             body=[],
                             decorator_list=[])

# Generated at 2022-06-21 17:37:01.613100
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    import io
    import unittest

    class TestMetaclassTransformer(unittest.TestCase):
        def setUp(self):
            self.transformer = MetaclassTransformer()

        def test_it_inserts_import_in_module(self):
            module = ast.parse("""
            class A(metaclass=B):
                pass
            """)
            self.transformer.visit(module)
            out = io.StringIO()
            ast.unparse(self.transformer.tree, out)
            self.assertEqual(out.getvalue(), """
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(B))
                pass
            """)

    un

# Generated at 2022-06-21 17:37:10.555030
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():  # noqa
    from ..utils.testing import assert_text_transformation
    from ..utils.testing import generate_ast

    code = "class A(metaclass=B): pass"
    expected = ("class A(_py_backwards_six_withmetaclass(B)):"
                " pass")
    metaclass_transformer = MetaclassTransformer()
    ast = generate_ast(code)
    metaclass_transformer.visit(ast)  # type: ignore
    assert_text_transformation(ast, code, expected, metaclass_transformer)


# Generated at 2022-06-21 17:37:13.039347
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:37:21.409718
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    original_source = "class A(metaclass=B):\n    pass\n"
    expected_source = "from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass\n"
    tree = ast.parse(original_source)
    tree = MetaclassTransformer().visit(tree)
    assert ast.dump(tree) == expected_source


# Generated at 2022-06-21 17:37:33.757081
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    Tests the method visit_ClassDef of the class MetaclassTransformer with a class
    with a metaclass.
    
    """
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet, snippet_execute
    from astor import to_source    
    
    with_metaclass = snippet_execute(six_import)
    _py_backwards_six_with_metaclass = snippet_execute(class_bases)


# Generated at 2022-06-21 17:37:38.381924
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class_ast = ast.parse("class A(metaclass=B):").body[0]
    class_ast = MetaclassTransformer().visit(class_ast)
    assert ast.dump(class_ast) == 'ClassDef(name=\'A\', bases=[Call(func=Name(id=\'_py_backwards_six_withmetaclass\', ctx=Load()), args=[Name(id=\'B\', ctx=Load())], keywords=[], starargs=None, kwargs=None)], keywords=[], body=[], decorator_list=[])'

# Generated at 2022-06-21 17:37:42.080796
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..python_to_python import compile_

    source = \
"""class A(metaclass=B):
    pass"""


# Generated at 2022-06-21 17:37:50.645346
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    class_def = ast.parse('class A(metaclass=B): pass').body[0]
    transformer = MetaclassTransformer()
    result = transformer.visit_ClassDef(class_def)
    expected = 'class A(_py_backwards_six_with_metaclass(B)): pass'
    assert astor.to_source(result).strip() == expected

# Generated at 2022-06-21 17:37:55.639933
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import textwrap
    source = textwrap.dedent('''
    class A(metaclass=B):
        pass
    ''')

    result = textwrap.dedent('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''')
    tree = ast.parse(source)
    new_tree = MetaclassTransformer().visit(tree)

    # Ensure that the code still runs
    code = compile(new_tree, filename="<ast>", mode="exec")
    exec(code)

    assert ast.dump(new_tree) == ast.dump(ast.parse(result))

# Generated at 2022-06-21 17:37:56.793813
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 17:38:00.806778
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import inspect
    import ast
    import six
    import _py_backwards
    module = _py_backwards.fixes.six.MetaclassTransformer()
    assert (inspect.getsource(module.visit_Module).splitlines()[0] ==
            "def visit_Module(self, node: ast3.Module) -> ast3.Module:"
            )

# Generated at 2022-06-21 17:38:05.415136
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Test snippet
    #     class A(metaclass=B):
    #         pass
    module = ast.parse("class A(metaclass=B):\n    pass")
    transformer = MetaclassTransformer()
    module = transformer.visit_Module(module)
    assert transformer._tree_changed

    # Assert that all imports are correctly inserted
    assert len(module.body) == 3
    assert isinstance(module.body[0], ast.Expr) and isinstance(module.body[0].value, ast.Str)
    assert isinstance(module.body[1], ast.ImportFrom) and module.body[1].module == 'six'
    assert isinstance(module.body[2], ast.ClassDef)


# Generated at 2022-06-21 17:38:16.414489
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import generate_visit_test
    from typed_ast import ast3 as ast

    class Py27Node(ast.AST):
        _fields = ('metaclass', 'bases')

        def __init__(self, metaclass=None, bases=None):
            self.metaclass, self.bases = metaclass, bases

    class Py27Class(Py27Node):
        _fields = ('name',)

        def __init__(self, name=None, metaclass=None, bases=None):
            super(Py27Class, self).__init__(metaclass=metaclass, bases=bases)
            self.name = name

    Py27Keyword = ast.keyword


# Generated at 2022-06-21 17:38:19.952464
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    metadata1 = {'metaclass': 'B'}
    metadata2 = {}
    test_node1 = ast.ClassDef(name='A',
                              bases=[],
                              keywords=[ast.arg(arg='metaclass', value=metadata1['metaclass'])])
    test_node2 = ast.ClassDef(name='A',
                              bases=[],
                              keywords=ast.List(elts=[], ctx=ast.Load()))
    assert MetaclassTransformer(metadata1).visit(test_node1) == test_node1
    assert MetaclassTransformer(metadata2).visit(test_node2) == None

# Generated at 2022-06-21 17:38:27.238407
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from py_backwards.transformers.six import MetaclassTransformer
    from py_backwards.transformers.six import six_import
    import ast
    import astor
    classdef_tree = ast.parse('class A(metaclass=B):\n    pass')

    transformer = MetaclassTransformer()
    transformer.visit(classdef_tree)
    result_tree = six_import.get_body() + astor.to_source(classdef_tree).splitlines()
    expected_tree = ['from six import with_metaclass as _py_backwards_six_withmetaclass',
                     '',
                     'class A(_py_backwards_six_withmetaclass(B)):',
                     '    pass']
    assert expected_tree == result_tree

# Generated at 2022-06-21 17:38:27.675270
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:38:31.151273
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    nodes = ast.parse('class A(metaclass=B): pass')
    MetaclassTransformer().generic_visit(nodes)
    assert ast.dump(nodes) == '''\
Module(body=[
    ClassDef(name='A', bases=[
        _py_backwards_six_withmetaclass(B)
    ], body=[], decorator_list=[])
])'''



# Generated at 2022-06-21 17:38:43.246484
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    global _py_backwards_six_withmetaclass
    tree = ast.parse('class A(metaclass=B): pass')

    _py_backwards_six_withmetaclass = object
    MetaclassTransformer().visit(tree)
    assert _py_backwards_six_withmetaclass is not object


# Generated at 2022-06-21 17:38:49.916174
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class_def = ast.ClassDef(name='FooClass',
                             bases=[],
                             keywords=[ast.keyword(arg='metaclass', value=ast.Name('Foo'))])

    module = ast.Module(body=[class_def])

# Generated at 2022-06-21 17:39:00.477912
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from lib2to3.pgen2 import token
    from ..utils.syntax import make_suite
    node = make_suite("class A(metaclass=B): pass")
    trans = MetaclassTransformer()
    trans.visit(node)
    base = node.body[0]
    assert base.body[0].func.elts[0].id == 'B'
    assert node.body[0].bases.elts[0].id == '_py_backwards_six_withmetaclass'
    assert node.body[0].keywords == []
    assert node.body[0].bases.elts[0].args[0].id == 'B'
    assert node.body[0].bases.elts[0].args[1].id == 'A'

# Generated at 2022-06-21 17:39:04.389050
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = """class A(metaclass=B): pass"""
    tree = ast.parse(code)

    MetaclassTransformer().visit(tree)


# Generated at 2022-06-21 17:39:06.500350
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert six_import() == six_import.get_body()



# Generated at 2022-06-21 17:39:12.109593
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse("""
        class A(metaclass=B):
            pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(tree)

    new_tree = ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)
    assert ast.dump(tree) == ast.dump(new_tree)



# Generated at 2022-06-21 17:39:12.890318
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:39:18.634095
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

  from typed_ast import ast3 as ast
  from ..utils.tree import dump_tree
  from collections import namedtuple

  class ClassDef(namedtuple('ClassDef', 'bases body lineno col_offset name keywords starargs keywords')):
    pass

  class Keyword(namedtuple('Keyword', 'arg value')):
    pass

  class Name(namedtuple('Name', 'id ctx')):
    pass


# Generated at 2022-06-21 17:39:23.413125
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    expected_tree = six_import.get_ast()
    expected_tree.body.extend([
        ast.ClassDef(name='A',
                     bases=class_bases.get_ast(metaclass=ast.Name(id='B'), bases=ast.List(elts=[])),
                     keywords=[], body=[],
                     decorator_list=[])
    ])

    input_tree = ast.parse(
        '''
        class A(metaclass=B):
            pass
        '''
    )

    metaclass_transformer = MetaclassTransformer(target_version=(2, 7))
    metaclass_transformer.visit(input_tree)
    assert metaclass_transformer.tree_changed == True

    # Ensure same AST

# Generated at 2022-06-21 17:39:32.527860
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    c_str = """class A(metaclass=B):
        pass"""
    c_obj = ast.parse(c_str)
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(c_obj)


# Generated at 2022-06-21 17:39:54.201682
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    transformer = MetaclassTransformer()
    module = ast.parse("class A(metaclass=B): pass")
    module = transformer.visit(module)
    assert ast.dump(module) == """Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='A', bases=[_py_backwards_six_withmetaclass(B)], keywords=[], body=[], decorator_list=[])])"""


# Generated at 2022-06-21 17:39:56.097834
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typing import Dict
    from typed_ast import ast3 as ast
    

# Generated at 2022-06-21 17:40:03.476243
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def = ast.ClassDef(name='a',
                             bases=[ast.Name(id='A', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C',
                                                                  ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    transformer = MetaclassTransformer(2, 7)
    new_class_def = transformer.visit(class_def)
    assert transformer._tree_changed
    assert new_class_def.bases[0].func.func.id == '_py_backwards_six_withmetaclass'
    assert new_class_def.decorator_list == []
    assert new_class_def.keywords == []


#

# Generated at 2022-06-21 17:40:04.485534
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:40:12.640409
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import Source
    from ..utils.compare_ast import compare_ast
    source = Source("""
        class A:
            pass
    """)
    expected = Source("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A:
            pass
    """)
    transformer = MetaclassTransformer()
    actual = source.to_ast(transformer)
    assert compare_ast(actual, expected) == True, compare_ast(actual, expected)



# Generated at 2022-06-21 17:40:18.699345
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """
    Test that MetaclassTransformer works as expected.
    """
    from ..utils.test_utils import get_code
    from ..utils.code_runner import run_src_with_module
    module = run_src_with_module(get_code(MetaclassTransformer,
                                          'class A(object):'
                                          '  pass'),
                                 filename='a.py')

    assert module.A.__new__.__module__ == '__main__'

# Generated at 2022-06-21 17:40:26.490335
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import transform
    from ..utils.snippet import normalize_indentation
    from ..utils.source import placeholder

    src = """\
        class A(metaclass=B):
            pass\
        """

    expected = """\
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass\
        """

    src = placeholder.replace_all(src)
    expected = placeholder.replace_all(expected)

    tree = ast.parse(src)
    transform(tree, MetaclassTransformer)

    text = normalize_indentation(ast.unparse(tree))
    assert text == expected



# Generated at 2022-06-21 17:40:29.541458
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    # Code input
    code = "class A(metaclass=B, prop=2): pass"
    # Expected output

# Generated at 2022-06-21 17:40:39.916248
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.python import python_to_python_code, python_code_to_python
    from ..utils.codegen import compare_ast

    code = python_code_to_python(python_to_python_code(MetaclassTransformer.visit_ClassDef) +
                                 '''
                                 if __name__ == '__main__':
                                     node = ast.ClassDef(name='Test', bases=[ast.Name(id='B', ctx=ast.Load())], keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='A', ctx=ast.Load()))], body=[ast.Pass()])
                                     transformer = MetaclassTransformer()
                                     transformer.visit(node)
                                     print(astunparse.unparse(node))
                                 ''')
   

# Generated at 2022-06-21 17:40:50.716645
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast27 as ast

    class DummySrc(object):
        pass

    dummysrc = DummySrc()
    dummysrc.src = six_import.get_src() + class_bases.get_src()

    m = MetaclassTransformer()
    # --- unit test for constructor
    assert isinstance(m, MetaclassTransformer)

    # --- unit test for visit_ClassDef
    metaclass = ast.Str(s='metaclass')
    bases = [ast.Name(id='bases', ctx=ast.Load())]
    cls = ast.ClassDef(name='Dummy', bases=bases, keywords=[ast.keyword(arg='metaclass', value=metaclass)],
                     body=[], decorator_list=[])
    node = ast

# Generated at 2022-06-21 17:41:26.788660
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse('class A(metaclass=B): pass')
    mt = MetaclassTransformer()
    mt.visit(node)
    assert len(node.body) == 2
    assert isinstance(node.body[0], ast.ImportFrom)
    assert isinstance(node.body[1], ast.ClassDef)
    assert node.body[1].bases[0].func.value.name == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-21 17:41:38.392227
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = '''
        class A():
            pass

        class B(metaclass=object):
            pass

        class C(metaclass=object, arg=1):
            pass
    '''

    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A():
            pass

        class B(_py_backwards_six_withmetaclass(object)):
            pass

        class C(_py_backwards_six_withmetaclass(object), arg=1):
            pass
    '''
    t = MetaclassTransformer()
    t.visit(ast.parse(code))
    assert expected == t.code

# Generated at 2022-06-21 17:41:42.279159
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # GIVEN
    transformer = MetaclassTransformer([])
    node = ast.parse("class A(metaclass=B):\n    pass")

    # WHEN
    result = transformer.visit_Module(node)

    # THEN
    assert result == ast.parse("from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(metaclass=B):\n    pass")



# Generated at 2022-06-21 17:41:47.918818
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse("""
    class BaseClass(object):
        pass
    class SubClass(BaseClass):
        def __init__(self):
            self.size = 'large'
            self.gender = 'male'
    """)
    transformer = MetaclassTransformer()
    transformer.visit(module)

    # Check that the transformer modified the code as expected

# Generated at 2022-06-21 17:41:55.923539
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTest
    node = ast.parse('class A(metaclass=B):\n    pass')
    transformer = MetaclassTransformer()
    transformer.visit(node)

# Generated at 2022-06-21 17:42:00.279126
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = """
    class A(object, metaclass=B):
        pass
    """
    result = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B, object)):
        pass
    """
    tree = parse(source)
    tree = MetaclassTransformer().visit(tree)
    expected = parse(result)
    assert astunparse(tree) == astunparse(expected)

# Generated at 2022-06-21 17:42:04.774309
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    node = ast.parse("class A(metaclass=B): pass")
    expected = "class A(metaclass=B): pass"
    transformer.visit(node)
    assert transforme

# Generated at 2022-06-21 17:42:11.450372
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import make_snippet
    from ..utils.snippet import parse_ast

    source = make_snippet('''
    class A(metaclass=B):
        pass
    ''')
    expected = make_snippet('''
    import six
    class A(_py_backwards_six_with_metaclass(B)):
        pass
    ''')

    transformer = MetaclassTransformer()
    actual = transformer.visit(parse_ast(source))

    assert transformer._tree_changed == True
    assert actual == parse_ast(expected)

# Generated at 2022-06-21 17:42:19.100711
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse(dedent('''
    class A(object):
        pass
    '''))

    t = MetaclassTransformer()
    t.visit(node)

    result = parse(dedent('''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(object)):
        pass
    '''))

    assert compare_ast(node, result) is True


# Generated at 2022-06-21 17:42:27.941913
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.Module(body=[ast.ClassDef(name='A', bases=[ast.Name(id='object', ctx=ast.Load())], keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))])])
    transformer = MetaclassTransformer()
    transformer.visit(node)
    print(ast3.dump(node))

# Generated at 2022-06-21 17:43:45.426333
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing_utils import assert_equal_ast
    from ..testing_utils import test_visitor_direct


# Generated at 2022-06-21 17:43:55.943225
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class TestMetaclassTransformer(MetaclassTransformer):
        def __init__(self):
            self._tree_changed = False

    # Simple test
    imports = (
        '#!/usr/bin/env python',
        '# -*- coding: utf-8 -*-',
        'class A(object):',
        '    pass',
    )

# Generated at 2022-06-21 17:43:56.569314
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:43:58.959785
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:44:04.372892
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = """
    class A(Metaclass=B): pass
    """
    target = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)): pass
    """
    mt = MetaclassTransformer()
    actual = mt.visit(ast.parse(source))
    desired = ast.parse(target)
    assert ast.dump(actual) == ast.dump(desired)

# Generated at 2022-06-21 17:44:05.395110
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-21 17:44:10.679582
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse('class A(metaclass=B): pass')
    exp = ast.parse('class A(_py_backwards_six_withmetaclass(B)): pass')
    node2 = MetaclassTransformer().visit(node)
    assert ast.dump(node2, annotate_fields=False) == ast.dump(exp, annotate_fields=False)

# Generated at 2022-06-21 17:44:17.785728
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_visitor import TestVisitor
    from ..utils.test_utils import assert_node_equal
    import ast
    ast_node = ast.parse("import six")
    ast_node = MetaclassTransformer().visit(ast_node)  # type: ignore
    TestVisitor().visit(ast_node)
    expected = ast_node = ast.parse(six_import.strip())
    assert_node_equal(ast_node, expected)



# Generated at 2022-06-21 17:44:21.177407
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    sample_content = \
'''class A(metaclass=B):
    pass'''

    # Everything should be removed

# Generated at 2022-06-21 17:44:31.079010
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    table = str.maketrans({'\n': None, ' ': None, '\t': None})
    source = '''
        class A(metaclass=type):
            pass
    '''

    result = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(type)):
            pass
    '''
    from typed_ast import ast3
    from ..testing import transform

    module, info = transform(MetaclassTransformer, ast3.parse(source))

    assert module.__str__().translate(table) == result.translate(table)
    assert info.transforms == [MetaclassTransformer]
