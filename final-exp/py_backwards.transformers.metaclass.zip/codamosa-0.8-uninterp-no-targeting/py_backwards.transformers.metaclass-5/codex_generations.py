

# Generated at 2022-06-21 17:35:23.678106
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # Arrange
    node = ast.parse("""class Test(metaclass=abc.ABCMeta):  
    pass""")
    # Act
    MetaclassTransformer().visit(node)
    # Assert

# Generated at 2022-06-21 17:35:30.367517
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import inspect
    from typed_ast import ast3 as ast

    class M(type):
        pass

    class A(metaclass=M):
        pass

    source = inspect.getsource(A).encode('utf8')
    mt = MetaclassTransformer()
    node = mt.visit(ast.parse(source))  # type: ast.Module
    assert mt._tree_changed
    assert mt._content_changed
    assert mt.dependencies == ['six']
    assert mt.packages == []
    assert ast.dump(node) == textwrap.dedent(
        '''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(M, object)):
            pass
        '''
    ).strip()

# Generated at 2022-06-21 17:35:37.693548
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = 'class A(metaclass=B):\n    pass'
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert tree.body == [
        six_import.get_body_as_ast(),
        ast.ClassDef(name='A',
                     body=[],
                     decorator_list=[],
                     keywords=[],
                     bases=[class_bases.get_body_as_ast(metaclass=ast.Name(id='B', ctx=ast.Load()),
                                                         bases=ast.List(elts=[]))])
    ]
    assert MetaclassTransformer.has_changed is True

# Generated at 2022-06-21 17:35:38.909690
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:35:44.044739
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    test_code = '''
        class A(metaclass=int):
            pass
    '''
    test_ast = ast.parse(test_code, mode='exec')
    expected_code = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(int)):
            pass
        '''
    trans = MetaclassTransformer(2, 7)
    trans.visit(test_ast)
    assert astor.to_source(test_ast) == expected_code

# Generated at 2022-06-21 17:35:48.067248
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing.transformer import check_transform
    code = 'class A(metaclass=B): pass'
    new_code = check_transform(code, MetaclassTransformer)

# Generated at 2022-06-21 17:35:57.654041
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = """
        class A(metaclass=B):
            pass
        """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B, )):
            pass
        """
    module, info = compile(source, MetaclassTransformer, '<test>', 'exec')
    assert info.tree_changed
    assert module == expected

# Generated at 2022-06-21 17:36:03.101723
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from py_backwards.transformers.ast.classes import MetaclassTransformer
    from ..utils.builder import build

    transformer = MetaclassTransformer()
    src = "class A(metaclass=B):\n    pass"

# Generated at 2022-06-21 17:36:08.568711
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    p = ast.parse('''
        class A(metaclass=B):
            pass
    ''')
    p = MetaclassTransformer().visit(p)

# Generated at 2022-06-21 17:36:20.884404
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from py2c.tests import TestCase
    from py2c.tree.visitor import print_tree
    import astor

    class TestMetaclassTransformer(TestCase):
        def test_with_metaclass(self):
            class_def = ast.ClassDef(
                name="A",
                bases=[ast.Name(id="B")],
                keywords=[ast.keyword(arg="metaclass", value=ast.Name(id="C"))],
                body=[ast.Pass()],
                decorator_list=[])
            module = ast.Module(body=[class_def])
            tree = MetaclassTransformer().visit(module)
            print_tree(tree)

# Generated at 2022-06-21 17:36:29.310410
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer.__init__.__code__.co_argcount == 2
    assert MetaclassTransformer.__init__.__defaults__ == (None, None)
    assert MetaclassTransformer().visit_Module
    assert MetaclassTransformer().visit_ClassDef

# Generated at 2022-06-21 17:36:37.153250
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.testing import assert_transformed

    assert_transformed(MetaclassTransformer, """\
        class A(metaclass=B):
            pass
    """, """\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

# Generated at 2022-06-21 17:36:37.679225
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:36:47.865670
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from astor import dump_tree, parse_tree
    for code in (
        "class A(metaclass=B): pass",
        "class A(metaclass=B, object): pass",
        "class A(object, metaclass=B): pass"
    ):
        # print(code)
        tree = parse_tree(code)
        MetaclassTransformer().visit(tree)
        assert dump_tree(tree) == "class A(_py_backwards_six_withmetaclass(B, object)): pass\n"

# Generated at 2022-06-21 17:36:50.953969
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:37:02.002444
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert 'class A(_py_backwards_six_withmetaclass(B, C)): pass' == \
           MetaclassTransformer.run_visitor_on_snippet(source='class A(metaclass=B, C): pass')
    assert 'class A(_py_backwards_six_withmetaclass(B, C)): pass' == \
           MetaclassTransformer.run_visitor_on_snippet(source='class A(B, C, metaclass=D): pass')
    assert 'class A(_py_backwards_six_withmetaclass(B, C)): pass' == \
           MetaclassTransformer.run_visitor_on_snippet(source='class A(B, C, metaclass=D, E): pass')

# Generated at 2022-06-21 17:37:07.451981
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    module = ast.parse('class A(metaclass=B, **k): pass')
    c = MetaclassTransformer().visit(module)
    assert c.body[0].value == six_import.get_body()[0].value
    assert c.body[1].bases[0].args[0].value == 'B'
    assert c.body[1].keywords == []



# Generated at 2022-06-21 17:37:14.541851
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    class_ast = ast.parse('class Foo(Bar): pass')
    class_ast.body[0].keywords = [ast.keyword(arg='metaclass',
                                              value=ast.Name(id='Bar'))]
    assert astor.to_source(MetaclassTransformer().visit(class_ast)) == '''from six import with_metaclass as _py_backwards_six_withmetaclass\nclass Foo(_py_backwards_six_withmetaclass(Bar)):\n    pass'''

# Generated at 2022-06-21 17:37:22.569412
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    METACLASS_RE = re.compile('class (.*)\\(\\):')
    class Test(metaclass=abc.ABCMeta):  # type: ignore
        pass
    code = ASTCodeGenerator().visit(ast.parse(inspect.getsource(Test)))
    assert re.match(METACLASS_RE, code)
    assert re.search('from six', code)
    assert re.search('with_metaclass as _py_backwards_six_withmetaclass', code)
    assert re.search('metaclass=abc.ABCMeta', code)

# Generated at 2022-06-21 17:37:33.116322
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
 
    # This is the test.
    compiler = MetaclassTransformer()

    # Expected result
    expected = six_import.get_ast()

    # Setup the tree to test
    tree = ast.Module(
        body=[]
    )

    # Convert the tree to AST then back to make sure it's valid.
    ast.fix_missing_locations(tree)
    tree = ast.parse(compiler._generic_ast_to_code(tree))

    # Visit the tree
    compiler.visit(tree)

    # Get the result
    result = tree

    # Make sure the result is what we expected
    assert expected.body == result.body



# Generated at 2022-06-21 17:37:42.209817
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class MyClass(object):
        __metaclass__ = MetaclassTransformer

    module = ast.parse("class Class(object): pass\n")
    MyClass().visit(module)
    assert MyClass().tree_changed
    assert six_import.get_body() == module.body[0]
    # List of bases will be changed to new statement
    assert module.body[1].bases == class_bases.get_body()

# Generated at 2022-06-21 17:37:47.262976
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """This test is here to ensure that the constructor of the class
    MetaclassTransformer works as expected.
    """
    # Check types
    try:
        MetaclassTransformer()
    except TypeError:
        raise AssertionError("MetaclassTransformer should not require any arguments")

# Generated at 2022-06-21 17:37:47.763887
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    ...


# Generated at 2022-06-21 17:37:49.267242
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .helpers import compile_visit

# Generated at 2022-06-21 17:37:59.189364
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import BaseTestTransformer
    # noinspection PyUnusedLocal
    class TestMetaclassTransformer(BaseTestTransformer):
        transformer = MetaclassTransformer
        target = (2, 7)
        dependencies = ['six']

        def test_metaclass(self):
            _expected = ast.parse('''
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class B(object):
                pass
            class A(_py_backwards_six_withmetaclass(B)):
                pass
            ''')
            _code = ast.parse('''
            class B(object):
                pass
            class A(metaclass=B):
                pass
            ''')
            self.check(_code, _expected)


# Generated at 2022-06-21 17:38:04.037262
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import six
    from .env import Env

    env = Env()
    transformer = MetaclassTransformer()
    from py_backwards.tests.visitors.test_classes_and_functions import module_with_metaclass
    old_module = module_with_metaclass(env.module)
    new_module = transformer.visit(old_module)
    from ..utils.source_convertor import SourceConvertor

    # Check that the new module is similar to the old one
    assert transformer._tree_changed

# Generated at 2022-06-21 17:38:11.061560
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    s = """
    class A(object, metaclass=B):
        pass
    """
    tree = ast.parse(s)
    tree = MetaclassTransformer().visit(tree)
    result = astor.to_source(tree)

# Generated at 2022-06-21 17:38:20.735754
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .fake_parser import fake_parse
    from .fake_parser import fake_parse_function
    from ..Transformer import Transformer

    transformer = Transformer()
    parser = transformer.get_parser()

    def parse(src):
        return fake_parse(parser, src)

    def parse_function(src):
        return fake_parse_function(parser, src)

    def transform(src):
        module = parse(src)
        return MetaclassTransformer().visit(module)

    def transform_function(src):
        func = parse_function(src)
        return MetaclassTransformer().visit(func)

    assert parse_function('def f():\n pass').body[0] == transform_function('def f():\n pass')
    assert parse('class A(object): pass').body[0] == transform

# Generated at 2022-06-21 17:38:28.901854
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    input = """
        class A(metaclass=B):
            pass
        """
    expected = """
        class A(metaclass=B):
            pass
        """
    output = MetaclassTransformer(input, target=(3, 0)).run()
    assert expected == output

    input = """
        class A(metaclass=B, abc=1):
            pass
        """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B, *[1])):
            pass
        """
    output = MetaclassTransformer(input, target=(2, 7)).run()
    assert expected == output

# Generated at 2022-06-21 17:38:33.064681
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    class_ast = ast.parse('class Foo(metaclass=Bar):\n  pass\n')
    MetaclassTransformer().visit(class_ast)
    assert astor.to_source(class_ast).count('_py_backwards_six_withmetaclass') == 1
    assert astor.to_source(class_ast).count(
        '_py_backwards_six_withmetaclass(Bar)') == 1
    assert astor.to_source(class_ast).count('Bar') == 0

# Generated at 2022-06-21 17:38:48.751623
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .classes import check_node
    from typed_ast import (
        ast27,
        ast3,
    )
    from six import with_metaclass as _py_backwards_six_withmetaclass

    check_node(ast27.parse("class A(metaclass=B):\n    pass"),
               ast3.parse("class A(_py_backwards_six_withmetaclass(B)):\n    pass"))
    check_node(ast27.parse("class A(a, metaclass=B):\n    pass"),
               ast3.parse("class A(_py_backwards_six_withmetaclass(B), a):\n    pass"))

# Generated at 2022-06-21 17:38:56.052144
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .utils import NodeTransformerTestCase

    class Test(NodeTransformerTestCase):
        target_versions = (2, 7)
        transformer = MetaclassTransformer

        def test_simple(self):
            source = """class A(B, C, metaclass=F):
    pass"""

# Generated at 2022-06-21 17:38:56.902588
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    MetaclassTransformer()

# Generated at 2022-06-21 17:39:06.143450
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    code = "class A(metaclass=B): pass"
    tree = ast.parse(code)
    transformer.visit(tree)
    assert len(tree.body) == 2
    assert isinstance(tree.body[1], ast.ClassDef)
    assert isinstance(tree.body[1].bases[0], ast.Call)
    assert isinstance(tree.body[1].bases[0].func, ast.Name)
    assert tree.body[1].bases[0].func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-21 17:39:13.752757
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import get_python_AST
    from .. import compile
    from .test_varargs import test_VarargsTransformer

    for target, input in (
            ((2, 3), 'class NoBase(metaclass=int): pass'),
            ((2, 3), 'class NoBase(object, metaclass=int): pass'),
            ((2, 3), 'class NoBase(metaclass=int, object=None): pass'),
            ((2, 3), 'class NoBase(object, metaclass=int, object=None): pass'),
            ((2, 4), 'class NoBase(object, metaclass=int, object=None): pass'),
    ):
        tree = compile(input, target,
                       tree_transformers=[test_VarargsTransformer, MetaclassTransformer])
        print(tree)
        #

# Generated at 2022-06-21 17:39:18.452317
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse('class A(B):\n    pass')
    new_node = MetaclassTransformer().visit(node)
    assert to_source(new_node) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(B):\n    pass'


# Generated at 2022-06-21 17:39:28.793018
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import parse
    from ..utils.converter import _convert
    from ..stubs.six import six_import
    from ..stubs.six import class_bases
    from .. import TransformerFinder

    trans = MetaclassTransformer.get_transformer(target=(2, 7))
    tree = parse("""
    class A(metaclass=type):
        pass
    """)
    tree = trans.visit(tree)
    assert _convert(tree, TransformerFinder()) == _convert(parse("""
    {0}\n
    class A({1}):
        pass
    """.format(six_import, class_bases)), TransformerFinder())

# Generated at 2022-06-21 17:39:29.786003
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:39:39.368386
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    import textwrap
    import astor

    class MyMetaClass(type): pass

    @six.add_metaclass(MyMetaClass)
    class MyClass(object): pass

    code = textwrap.dedent('''
        class MyClass:
            pass
        ''').strip()
    tree = ast.parse(code)
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(tree)
    assert astor.to_source(tree) == textwrap.dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class MyClass(_py_backwards_six_withmetaclass(None, object)):
            pass
        ''').strip()

# Generated at 2022-06-21 17:39:39.836423
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:39:56.896026
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(metaclass=B):
            pass
        """
    expected = """
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    module = ast.parse(source)
    transformer = MetaclassTransformer()
    new_module = transformer.visit(module)
    transformer.finalize()
    result = compile(new_module, 'test', 'exec')
    ns = {}
    exec(result, ns)
    assert ns['A'].__base__ == object
    assert ns['A'].__name__ == 'A'



# Generated at 2022-06-21 17:40:03.164463
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    assert transformer(
       """
       class A(metaclass=int):
           pass
       """
    ) == """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(int)):
        pass
    """

# Generated at 2022-06-21 17:40:09.247018
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...tests.lib import require_version
    require_version('2.7')  # For metaclasses
    from ...tests.lib import parse

    code = """
    class Test(object):
        class Meta:
            pass
    """

    class TestMetaclass(type):
        pass

    module = parse(code)
    klass = module.body[0]
    klass.keywords[0].value = TestMetaclass
    MetaclassTransformer(module).run()
    assert module.body[0].bases[0].value.args[1].id == 'TestMetaclass'

# Generated at 2022-06-21 17:40:14.933245
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    assert MetaclassTransformer().visit(ast.parse(_py_backwards_six_withmetaclass.get_body() + _py_backwards_six_withmetaclass.get_body())) == ast.parse(_py_backwards_six_withmetaclass.get_body() + _py_backwards_six_withmetaclass.get_body())

# Generated at 2022-06-21 17:40:24.352664
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    code = ast.parse('''
    class A(metaclass=B):
        pass
    ''')
    transformer = MetaclassTransformer()
    transformed = transformer.visit(code)
    assert transformer.tree_changed == True
    assert ast.dump(transformed) == '''\
Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='A', bases=[Attribute(value=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), attr='__call__', ctx=Load())], keywords=[], body=[], decorator_list=[])])
'''

# Generated at 2022-06-21 17:40:27.250486
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ...utils.ast_utils import get_fields


# Generated at 2022-06-21 17:40:37.937350
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..compile import _ast_to_source
    from .testing import expect_output

    test = """\
        class A(metaclass=B):
            pass
    """
    ast_ = expect_output(test)
    reparsed = MetaclassTransformer().visit(ast_)
    assert _ast_to_source(reparsed) == """\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        
        class A(_py_backwards_six_withmetaclass(B)):
            pass"""

# Generated at 2022-06-21 17:40:41.575393
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testing import TestTransformer
    from ..utils.source import source_to_node

    # INPUT

# Generated at 2022-06-21 17:40:51.170073
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from py_backwards.transformers import six
    try:
        del globals()['_py_backwards_six_withmetaclass']
        del globals()['_py_backwards_six_with_metaclass']
    except KeyError:
        pass

    code = '''
        import six
        class A(metaclass=B):
            pass
    '''
    tree = ast.parse(code)
    x = six.SixTransformer()
    x.visit(tree)
    metaclass = MetaclassTransformer()
    metaclass.visit(tree)
    assert '_py_backwards_six_withmetaclass' in globals()
    assert '_py_backwards_six_with_metaclass' in globals()



# Generated at 2022-06-21 17:40:59.275210
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.select import Selector
    from ..utils.snippet import Snippet
    from ..utils.tree import print_ast

    snippet_selector = Snippet(select=Selector.from_module(
        MetaclassTransformer).select)
    class_def = ast.parse(
        snippet_selector(snippet='class_def'))
    mt = MetaclassTransformer()
    assert mt.visit(class_def) is not None
    print_ast(class_def)



# Generated at 2022-06-21 17:41:23.494817
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
###
    class A(metaclass=B):
        pass
###

# Generated at 2022-06-21 17:41:32.093875
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    class_ = ast.ClassDef(name='A',
                          bases=[],
                          keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                          body=[ast.Pass()],
                          decorator_list=[])
    module = ast.Module(body=[class_])
    transformed = MetaclassTransformer().visit(module)
    assert MetaclassTransformer._tree_changed is True

# Generated at 2022-06-21 17:41:41.720555
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():

    class TestVisitor(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            return ast.Module(body=[node] + six_import.get_body())

    node = ast.parse(textwrap.dedent("""
    class A(metaclass=B): pass
    """), __file__)

    TestVisitor().visit(node)

    expected = ast.Module(body=[ast.ImportFrom(module='six', names=[ast.alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0),
                               string_to_ast(textwrap.dedent("""
    class A(metaclass=B): pass
    """))])

# Generated at 2022-06-21 17:41:45.001875
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source

    transformer = MetaclassTransformer()
    source = 'asd'
    source = source

    transformer = MetaclassTransformer()
    source = source

# Generated at 2022-06-21 17:41:48.626297
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # type: () -> None
    assert MetaclassTransformer.__name__ == 'MetaclassTransformer'
    assert MetaclassTransformer.__doc__ and isinstance(MetaclassTransformer.__doc__, str)


__all__ = ['MetaclassTransformer']

# Generated at 2022-06-21 17:41:54.477010
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def = ast.parse("""
    class A(metaclass=B, base=Foo):
        pass
    """).body[0]


# Generated at 2022-06-21 17:42:00.100699
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("""
        class A(metaclass=B):
            pass
        """)
    t = MetaclassTransformer()
    t.visit(node)

    expected = ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """).body[1]
    assert_equal(node.body[1], expected)


# Generated at 2022-06-21 17:42:06.696300
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    if sys.version_info < (3, 0):
        return
    import ast as pyast
    from ..utils import ast_dump
    from .base import transform
    from .with_transformer import WithTransformer
    from .str_transformer import StrTransformer
    from .inherit_transformer import InheritTransformer


# Generated at 2022-06-21 17:42:13.128712
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..testing import assert_nodes_equal
    from ..utils import parse
    assert_nodes_equal(
        MetaclassTransformer().visit(parse(
            'class A(metaclass=B):\n'
            '    pass'
        )),
        parse(
            'from six import with_metaclass as _py_backwards_six_withmetaclass\n'
            'class A(_py_backwards_six_withmetaclass(B)):\n'
            '    pass'
        ),
    )

# Generated at 2022-06-21 17:42:14.135188
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:42:53.189654
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse('class MyClass(metaclass=MyMetaClass):\n    pass')
    m = MetaclassTransformer()
    item = module.body[0]
    assert type(item) is ast.ClassDef
    assert type(item.keywords[0].value) is ast.Name

    m.visit(module)

    item = module.body[1]
    assert type(item) is ast.ClassDef
    assert item.bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert type(item.bases[0].args[0]) is ast.Name
    assert item.bases[0].args[0].id == 'MyMetaClass'

# Generated at 2022-06-21 17:43:00.265410
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse("""
    class Foo(object, metaclass=type):
        pass
    """)
    trans = MetaclassTransformer()
    tree = trans.visit(tree)

# Generated at 2022-06-21 17:43:08.800385
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse("""
    class A(metaclass=type):
        pass
    """)
    result = six.text_type(MetaclassTransformer().visit(node))
    assert result == """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(type)):
        pass
    """

# Generated at 2022-06-21 17:43:11.785082
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    tree = ast.parse("""
        class A(metaclass=B)
            pass
    """)
    MetaclassTransformer().visit(tree)
    print(ast.dump(tree))

# Generated at 2022-06-21 17:43:21.900484
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .base import compile_function, parse

    module = parse("""
    class A(object, metaclass=B):
        pass
    """)
    function = compile_function(module, 2, 7, MetaclassTransformer)
    assert check_source(function.source, '''
    from six import with_metaclass as _py_backwards_six_with_metaclass

    class A(_py_backwards_six_with_metaclass(B, object)):
        pass
    ''')

# Generated at 2022-06-21 17:43:33.195252
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # type: () -> None
    from ..utils import as_tuple
    from ..utils.node_util import pformat
    from ..utils.source_util import dedent
    from six import PY3

    for version in (2, 7):
        if version < 6:
            if PY3:
                # < 3.2 doesn't support keyword only arguments
                continue
            else:
                # < 2.7 doesn't support metaclasses
                continue
        code = dedent('''
            class A(metaclass=int):
                pass
            ''')
        tree = ast.parse(code)
        trans = MetaclassTransformer(version)
        trans.visit(tree)

# Generated at 2022-06-21 17:43:35.998282
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor


# Generated at 2022-06-21 17:43:47.011085
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # Test the visit_Module

    mt = MetaclassTransformer()
    tree = ast.parse('class B(): pass')

    result_ast = mt.visit(tree)

    assert result_ast.body[0].__class__ == ast.ImportFrom
    assert result_ast.body[0].lineno == 1
    assert result_ast.body[0].col_offset == 0

    assert result_ast.body[1].__class__ == ast.FunctionDef
    assert result_ast.body[1].lineno == 2
    assert result_ast.body[1].col_offset == 0

    assert result_ast.body[2].__class__ == ast.ClassDef
    assert result_ast.body[2].lineno == 3
    assert result_ast.body[2].col_offset == 0


    # Test visit

# Generated at 2022-06-21 17:43:48.018128
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:43:53.552885
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_base import get_node_tree
    src = """class A(metaclass=B):
        pass"""
    tree = get_node_tree(src, MetaclassTransformer)

# Generated at 2022-06-21 17:45:06.688513
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_string_1="""class A(metaclass=B):\n    pass"""
    tree_1 = ast.parse(test_string_1)


# Generated at 2022-06-21 17:45:11.313109
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ...tests.transpile_test_case import transpile_function, assert_parses_and_transpiles
    from .....tests.utils import assert_expression
    from ...general import withmetaclass

    assert_parses_and_transpiles(MetaclassTransformer,
        """
        class A(metaclass=B):
            pass
        """,
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    )
    
    def f():
        class A(metaclass=B):
            pass
    expr = assert_expression(transpile_function(f, MetaclassTransformer))