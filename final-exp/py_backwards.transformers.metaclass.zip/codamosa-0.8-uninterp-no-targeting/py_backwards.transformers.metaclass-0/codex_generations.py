

# Generated at 2022-06-21 17:35:13.103893
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    x = MetaclassTransformer()

# Generated at 2022-06-21 17:35:20.638097
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = "from six import with_metaclass as _py_backwards_six_with_metaclass\n" \
             "class A(metaclass=B):\n" \
             "    pass\n"
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    expected = "from six import with_metaclass as _py_backwards_six_with_metaclass\n" \
               "class A(_py_backwards_six_with_metaclass(B)):\n" \
               "    pass\n"
    assert astunparse.unparse(tree) == expected

# Generated at 2022-06-21 17:35:21.988079
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:35:30.255301
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..syntax import six_import, class_bases
    from ..utils.tree import print_node
    from ..utils.ast import parse, dump

    code = """
    class A(B):
        __metaclass__  = C
    
    class D(F, metaclass=G):
        pass
    """
    node = parse(code)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    result = dump(node)
    expected = (six_import.dump() + "\n\n" +
                class_bases.dump("C", "B") + "\n\n" +
                class_bases.dump("G", "F"))
    print("Expected:\n", expected)
    print("Result:\n", result)
    assert result == expected

# Generated at 2022-06-21 17:35:33.642635
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..transformers import TransformerSuite
    from typed_ast import ast3 as ast

    suite = TransformerSuite()
    transformer = MetaclassTransformer()
    suite.add_transformer(transformer)


# Generated at 2022-06-21 17:35:40.779409
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = "class A(metaclass=B):\n    pass"
    expected = "from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B))"

    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    gen = ast.PyCodeGen(tree)
    assert(expected == gen.text())


# Generated at 2022-06-21 17:35:50.046640
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """
    class A(object, metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B, object)):
        pass
    """
    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)
    result = str(new_tree)
    assert result == expected

# Generated at 2022-06-21 17:35:58.409822
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    snippet1 = snippet('''
        class A(metaclass=B):
            pass
    ''')
    expected = snippet('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')
    transformed = MetaclassTransformer()(snippet1.get_ast())
    assert expected.get_ast() == transformed

# Generated at 2022-06-21 17:36:08.608061
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from six import with_metaclass
    code = """
    class A(object):
        __metaclass__ = B
        pass
    """
    expected = """
    class A(with_metaclass(B)):
        pass
    """

    node = ast.parse(code)
    node = MetaclassTransformer().visit(node)
    assert(compile(node, '<test>', 'exec') == compile(expected, '<test>', 'exec'))



# Generated at 2022-06-21 17:36:17.028538
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast
    from py_backwards.transformers.metaclass import MetaclassTransformer # type: ignore
    trans = MetaclassTransformer()
    c = ast.parse("class A(metaclass=B, object=xa): pass")
    c = trans.visit(c)
    assert(c.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass')

# Generated at 2022-06-21 17:36:22.793254
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assertSourceEqual

# Generated at 2022-06-21 17:36:24.236786
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:36:32.627176
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source

    src = ("class A(metaclass=B):\n"
           "    pass\n")
    expected = ("from six import with_metaclass as _py_backwards_six_with_metaclass\n"
                "\n"
                "class A(_py_backwards_six_with_metaclass(B)):\n"
                "    pass\n")
    tree = ast.parse(src)
    mt = MetaclassTransformer(source=source.from_string(src))
    mt.visit(tree)
    assert mt.source.dumps() == expected

# Generated at 2022-06-21 17:36:40.825671
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.builder import ast_from, build
    from .base import BaseNodeTransformer

    tree = ast_from('''
        class A(object):
            pass
    ''')

    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.ClassDef)

    transformer = MetaclassTransformer(tree, build)
    transformer.visit_Module(tree)
    assert len(tree.body) == 2
    assert isinstance(tree.body[0], ast.ImportFrom)
    assert isinstance(tree.body[1], ast.ClassDef)


# Generated at 2022-06-21 17:36:49.196805
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse("""
    class A(metaclass=B):
    """)

    transformer = MetaclassTransformer()
    module = transformer.visit(module)
    assert transformer.dependencies == set(['six'])
    assert str(module) == """
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(_py_backwards_six_withmetaclass(metaclass = B))
    """.strip()

# Generated at 2022-06-21 17:36:58.078217
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astunparse
    module_ast = ast.parse('class A(metaclass=B):\n    pass')
    transformer = MetaclassTransformer()
    print(astunparse.unparse(transformer.visit(module_ast)))
    assert transformer.visit(module_ast) == (
        'import six\n'
        'class A(_py_backwards_six_withmetaclass(B)):\n    pass\n'
    )



# Generated at 2022-06-21 17:37:02.299236
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    class A(ast.NodeVisitor):
        def visit_ClassDef(self, node):
            return node.name

    node: ast.ClassDef = ast.parse("""
    class A(metaclass=B):
        pass
    """).body[0]
    assert A().visit(MetaclassTransformer().visit(node)) == 'A'



# Generated at 2022-06-21 17:37:07.401113
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # set up
    transformer = MetaclassTransformer()
    source = """class A(metaclass=B): pass"""
    expected = """class A(_py_backwards_six_withmetaclass(B)) pass"""
    # test
    result = transformer.run(source)
    assert result == expected
    assert transformer._tree_changed == True



# Generated at 2022-06-21 17:37:10.607453
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    input_code = '''class A(B,C,D):
    pass'''

# Generated at 2022-06-21 17:37:22.171922
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # Given
    from ..testing import assert_text_transformed
    from ..testing import assert_autoimport

    code = '''\
    class A(metaclass=B):
        pass
    '''

    expected = '''\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''

    # When
    actual = assert_text_transformed(code, MetaclassTransformer)

    # Then
    assert_autoimport(actual, 'six')
    assert actual == expected

# Generated at 2022-06-21 17:37:33.154929
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code =\
    '''class A(object, metaclass=B, *args, **kwargs):
           pass
    '''
    expected_code =\
    '''from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B, *args, **kwargs), object):
           pass
    '''
    result_code = compile_source(code, MetaclassTransformer)
    assert result_code == expected_code

# Generated at 2022-06-21 17:37:40.686027
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    from typed_ast import parse
    class_def = parse("class A(metaclass=B): pass").body[0]
    expected = parse("""
        _py_backwards_six_withmetaclass(B)(type(A))
    """)
    # When
    result = MetaclassTransformer.visit_ClassDef(class_def)
    # Then
    assert ast.dump(expected) == ast.dump(result)



# Generated at 2022-06-21 17:37:41.584263
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:37:45.123631
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse('class A(metaclass=B, d=c):\n    pass')
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed is True

# Generated at 2022-06-21 17:37:48.564927
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class A:
        def __init__(self, name):
            self.name = name

    a = A('test')
    assert a.name == 'test'

# Generated at 2022-06-21 17:37:58.940452
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """Test for the visit_Module method of the class MetaclassTransformer."""
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree, find_prefix
    from ..transformers.metaclass_transformer import MetaclassTransformer

    source_code = 'class A(metaclass=B):\n' \
                  '    pass'

    tree = ast.parse(source_code)

    transformer = MetaclassTransformer()
    print_tree(tree)
    print()
    transformed_tree = transformer.visit(tree)
    print_tree(transformed_tree)
    print()
    print_tree(transformer.get_tree())

    assert transformer.get_tree() == transformed_tree == tree

# Generated at 2022-06-21 17:37:59.931739
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    sut = MetaclassTransformer()
    assert sut.target == (2, 7)
    assert sut.dependencies == ['six']

# Generated at 2022-06-21 17:38:02.804749
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    node = ast.parse(source)
    MetaclassTransformer(None).visit(node)
    assert ast.dump(node) == expected

# Generated at 2022-06-21 17:38:14.766155
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class A(metaclass=int):
        pass
    node = ast.parse(textwrap.dedent(inspect.getsource(A)))
    node = MetaclassTransformer().visit(node)

# Generated at 2022-06-21 17:38:16.369990
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer(None).__class__

# Generated at 2022-06-21 17:38:30.833527
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import BaseTestTransformer

    class Test(BaseTestTransformer):
        target = (2, 7)
        transformer = MetaclassTransformer
        path = __file__
        name = 'MetaclassTransformer'

# Generated at 2022-06-21 17:38:41.375099
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    def test_transformer_metaclass(source):
        node = ast.parse(source)
        mct = MetaclassTransformer()
        mct.visit(node)
        return node, mct._tree_changed
        
    node, tree_changed = test_transformer_metaclass("class A(metaclass=B): pass")
    a = node.body[0]
    assert tree_changed == True
    assert type(a) is ast.ClassDef
    assert a.bases[0].func.id == "class_bases"
    assert a.bases[0].args[0].id == "B"
    
    node, tree_changed = test_transformer_metaclass("class A(B): pass")
    a = node.body[0]
    assert tree_changed == False

# Generated at 2022-06-21 17:38:43.502609
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source

    # Test with no metaclass specified

# Generated at 2022-06-21 17:38:50.159254
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from PyPyTest.compiler import test_compile_ast
    tree = ast.parse("""
        class A(metaclass=B):
            pass
    """)
    tx = MetaclassTransformer()
    tx.visit(tree)

    test_compile_ast(tree)


# Generated at 2022-06-21 17:38:51.483134
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:38:52.061751
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:38:57.648271
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given:
    from ..utils import source

    code = """
    class A(metaclass=B):
        pass
    """
    expected_code = """
    class A(_py_backwards_six_with_metaclass(B)):
        pass
    """

    # When:
    tree = ast.parse(code)
    MetaclassTransformer().visit(tree)

    # Then:
    assert source(tree) == expected_code



# Generated at 2022-06-21 17:38:59.807013
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    

# Generated at 2022-06-21 17:39:09.090125
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.transform_test import assert_transform
    from ..utils.transform_test import transform_assertions

    # Test for method visit_Module of class MetaclassTransformer
    @transform_assertions(six_import)
    def _test_MetaclassTransformer_visit_Module():
        return MetaclassTransformer()

    assert_transform(_test_MetaclassTransformer_visit_Module, """
        class A(metaclass=B):
            pass
    """, """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(metaclass=B):
            pass
    """)



# Generated at 2022-06-21 17:39:16.553107
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    input_code = """
        a = 1 
        class A(metaclass=B, object=C):
            pass
        class B(object=C):
            pass
    """
    expected_code = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        a = 1 
        class A(_py_backwards_six_withmetaclass(B, *[])):
            pass
        class B(object=C):
            pass
    """
    MetaclassTransformer.verify(input_code, expected_code)

# Generated at 2022-06-21 17:39:29.870960
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    from ..unit_tests.utils import source_to_mod


# Generated at 2022-06-21 17:39:38.375433
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .. import compile
    import ast

    code = '''
        class A(metaclass=B):
            pass
    '''

    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    '''

    result = compile(code, version=(2, 7))
    result = ast.fix_missing_locations(result)

    expected = compile(expected, version=(2, 7))
    expected = ast.fix_missing_locations(expected)

    assert ast.dump(expected) == ast.dump(result)

# Generated at 2022-06-21 17:39:49.047961
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3

    t = MetaclassTransformer
    assert t.visit_ClassDef(ast3.parse("class A(object): pass")) == ast3.parse("class A(object): pass")
    assert ast3.dump(t.visit_ClassDef(ast3.parse("class A(metaclass=B): pass"))) == \
           ast3.dump(ast3.parse("class A(_py_backwards_six_withmetaclass(B)): pass"))
    assert ast3.dump(t.visit_ClassDef(ast3.parse("class A(metaclass=B,b=1): pass"))) == \
           ast3.dump(ast3.parse("class A(_py_backwards_six_withmetaclass(B,b=1)): pass"))
    assert ast

# Generated at 2022-06-21 17:39:53.816632
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    src = """class A(metaclass=B): pass"""
    expected = """class A(_py_backwards_six_with_metaclass(B)): pass"""
    tree = ast.parse(src)
    transformer = MetaclassTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed is True
    assert astunparse.unparse(tree) == expected



# Generated at 2022-06-21 17:40:05.230068
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as ast

    module = ast.parse('''
        class A(object):
            pass
    ''')
    metaclass = ast.Name(id='Foo')
    module.body[0].keywords = [ast.keyword(arg='metaclass', value=metaclass)]
    transformer = MetaclassTransformer(target=(2, 7), dependencies=['six'])
    module = transformer.visit(module)  # type: ignore

    assert isinstance(module, ast.Module)
    assert len(module.body) == 3
    assert isinstance(module.body[0], ast.ImportFrom)
    assert isinstance(module.body[1], ast.ClassDef)
    assert isinstance(module.body[2], ast.Expr)

# Generated at 2022-06-21 17:40:14.144166
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = textwrap.dedent("""
        class A(metaclass=B):
            pass
    """)

    expected = textwrap.dedent("""
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    module = get_test_module(source)
    result = MetaclassTransformer().visit(module)
    assert result.body[1] == get_test_module(expected).body[1]  # type: ignore

# Generated at 2022-06-21 17:40:20.755636
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    
    t = MetaclassTransformer()
    class_def = ast.parse('class A(metaclass=B, bar=1):').body[0]
    t.visit(class_def)
    assert class_def.bases == ast.List(elts=[class_bases.get_body(metaclass=ast.Name(id="B"), bases=ast.List(elts=[]))], ctx=ast.Load())
    assert class_def.keywords == []
    

# Generated at 2022-06-21 17:40:29.254703
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .. import util
    from .. import converter
    convert = converter.convert_source
    transform = util.get_transformation_for(MetaclassTransformer)
    node = convert('''class WithMeta(metaclass=Foo, object=Bar):
                        pass''', '2.7')
    node = transform(node)

# Generated at 2022-06-21 17:40:38.538906
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    node = ast.parse(
        """
        class A(metaclass=B):
            pass
        """
    )

    r = MetaclassTransformer(2, 7).visit(node)

    assert len(r) == 1
    assert isinstance(r[0], ast.ClassDef)
    assert len(r[0].bases) == 1
    assert isinstance(r[0].bases[0], ast.Call)
    assert isinstance(r[0].bases[0].func, ast.Name)


__all__ = ['MetaclassTransformer']

# Generated at 2022-06-21 17:40:40.482028
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:41:11.443027
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as ast
    from .base import BaseNodeTransformer
    from .test_base import round_trip, transform, compare_ast

    code = """\
    class A(metaclass=B, **kwargs):
        pass
    """
    expected = """\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B, *[])):
        pass
    """
    tree = ast.parse(code, mode='exec')
    new_tree = round_trip(tree, MetaclassTransformer)
    compare_ast(new_tree, expected, code)



# Generated at 2022-06-21 17:41:17.554784
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse("class MetaclassTest(metaclass=type): pass")
    transformer = MetaclassTransformer(node)
    new_node = transformer.visit(node)
    assert str(new_node) == "from six import with_metaclass as _py_backwards_six_withmetaclass\nclass MetaclassTest(_py_backwards_six_withmetaclass(type)):\n    pass"

# Generated at 2022-06-21 17:41:28.836233
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse('class A(metaclass=B): pass')
    node = node.body[0] # remove module

    # Check before
    assert isinstance(node, ast.ClassDef)
    assert isinstance(node.bases[0], ast.Name)
    assert node.bases[0].id == 'B'
    assert isinstance(node.keywords[0], ast.keyword)
    assert node.keywords[0].arg == 'metaclass'
    assert node.keywords[0].value == 'B'

    # Transform
    xformer = MetaclassTransformer()
    new_node = xformer.visit(node)

    # Check after
    assert new_node is not node  # check new node
    assert isinstance(new_node, ast.ClassDef)
    assert isinstance

# Generated at 2022-06-21 17:41:40.376464
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_nodes_equal

    tree = ast.parse('class A(metaclass=B):\n    pass', mode='exec')
    MetaclassTransformer(tree).visit(tree)

# Generated at 2022-06-21 17:41:47.855082
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.utils import get_ast
    from six import with_metaclass as _py_backwards_six_withmetaclass

    node = get_ast('class A(): pass', parser='ast')
    tr = MetaclassTransformer()
    new_node = tr.visit_Module(node)

    assert (ast.dump(new_node) == "Module(body=[Import(names=[alias(name='six', asname=None)]),"
            " ClassDef(name='A', bases=[], keywords=[], body=[Pass()], decorator_list=[])])")



# Generated at 2022-06-21 17:41:57.477802
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    snippet(
        '''
        class A():
            pass
        ''')
    transpiled_output = MetaclassTransformer().visit(snippet.ast)
    assert snippet == transpiled_output


if __name__ == "__main__":
    import os
    import sys
    import unittest
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    unittest.main()

# Generated at 2022-06-21 17:42:09.057591
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast

    class DummyTransformer(BaseNodeTransformer):
        def visit(self, node: ast.AST) -> ast.AST:
            return node

    tree = ast.parse("""
        class F(metaclass=type):
            pass
        """)
    n_trans = DummyTransformer()
    n_trans.visit(tree)
    MetaclassTransformer().visit(tree)
    code = compile(tree, '<test>', mode='exec')
    loc = {}
    six_import.inject(loc=loc)
    eval(code, {'__builtins__': None}, loc)
    assert loc['F'] == type

# Generated at 2022-06-21 17:42:21.470088
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .test_utils import make_snippet
    from ..tools import ast_compare
    from six import PY2

    source = ('class A(metaclass=B):\n'
              '    pass\n')
    expected = ('from six import with_metaclass as _py_backwards_six_withmetaclass\n'
                '\n'
                '\n'
                'class A(_py_backwards_six_withmetaclass(B)):\n'
                '    pass\n')
    tree = make_snippet(source, MetaclassTransformer)
    assert ast_compare(expected, tree)

    if not PY2:
        source = ('class A(metaclass=B, object):\n'
                  '    pass\n')

# Generated at 2022-06-21 17:42:28.655536
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    src = """
    class A(metaclass=B):
        pass
    """
    res = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B, )):
        pass
    """
    MetaclassTransformer(target_version=(2, 7)).transform_source(src) == res

# Generated at 2022-06-21 17:42:40.897662
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.ClassDef(name='A',
                        bases=[ast.Name(id='B', ctx=ast.Load())],
                        keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='C', ctx=ast.Load()))],
                        body=[],
                        decorator_list=[])

# Generated at 2022-06-21 17:43:04.909397
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_utils import transform, compare
    from .test_utils import dedent_ftl

    @compare(dedent_ftl('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        
        class A:
            
            def __init__(self):
                self.x = 5
        
        class A(_py_backwards_six_withmetaclass(type)):
            
            def __init__(self):
                self.x = 5
    '''))
    def visit_Module():
        @transform(MetaclassTransformer)
        def visit_Module():
            class A:
        
                def __init__(self):
                    self.x = 5
        

# Generated at 2022-06-21 17:43:12.891143
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse("class A(metaclass=B): pass")
    transformer = MetaclassTransformer(module)
    module = transformer.visit(obj=module)

    result = ast.Module(['\n',
                         ast.Import(names=[ast.alias(name='six', asname=None)]),
                         '\n',
                         ast.ClassDef(name='A',
                                      bases=[ast.Name(id='_py_backwards_six_withmetaclass',
                                                      ctx=ast.Load())],
                                      keywords=[],
                                      body=[ast.Pass()],
                                      decorator_list=[])])

    assert ast.dump(node=module) == ast.dump(node=result)



# Generated at 2022-06-21 17:43:23.527287
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """
    The method 'visit_Module' of class 'MetaclassTransformer' should:
    - add the snippet 'six_import' in the module
    """
    module = ast.parse(textwrap.dedent("""\
        import os
        import six

        class A(metaclass=type):
            pass
    """))
    module = MetaclassTransformer().visit(module)

    assert len(module.body) == 3
    assert isinstance(module.body[0], ast.Import)
    assert isinstance(module.body[1], ast.Import)
    assert isinstance(module.body[2], ast.ClassDef)



# Generated at 2022-06-21 17:43:30.736433
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    input = """class A(metaclass=B): pass"""
    expected = """class A(_py_backwards_six_with_metaclass(B, )): pass"""
    node = ast.parse(input)  # type: ignore
    new_node = MetaclassTransformer().visit(node)
    assert ast.dump(new_node) == expected

# Generated at 2022-06-21 17:43:42.601946
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..ast_transformations import TransformError
    from ..utils import ast_util

    assert ast_util.pretty_source(MetaclassTransformer.visit_ClassDef(  # type: ignore
        MetaclassTransformer(),
        ast.parse(""" 
            class A(metaclass=B):
                pass
        """))) == ast_util.pretty_source("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """)

    assert ast_util.pretty_source(MetaclassTransformer.visit_ClassDef(  # type: ignore
        MetaclassTransformer(),
        ast.parse(""" 
            class A():
                pass
        """))) == ast_util.pretty_source("""
        class A():
            pass
        """)

# Generated at 2022-06-21 17:43:44.733664
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    tr = MetaclassTransformer()
    assert type(tr) == MetaclassTransformer

# Generated at 2022-06-21 17:43:55.460783
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3
    from .base import BaseNodeTransformer

    # Construct an instance of MetaclassTransformer
    transformer = MetaclassTransformer()

    # Construct calls to visit_ClassDef
    node = ast3.parse('class A(metaclass=B): pass').body[0]
    new_node = transformer.visit_ClassDef(node)

    # Check the result of the transformer
    assert new_node.keywords == []

# Generated at 2022-06-21 17:44:05.201079
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast, unittest

    # 3.2+ compatibility
    def _3_2_compat(tree):
        for node in ast.walk(tree):
            node.__class__.__module__ = ast.__name__

    # patch MetaClassTransformer
    class _MetaClassTransformer(MetaclassTransformer):
        @property
        def tree_changed(self):
            return self._tree_changed

    class TestCase(unittest.TestCase):
        def test_metaclass_class_def(self):
            code = "class A(metaclass=B): pass"
            tree = ast.parse(code)
            _3_2_compat(tree)
            transformer = _MetaClassTransformer()
            new_tree = transformer.visit(tree)

# Generated at 2022-06-21 17:44:13.218565
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = "class A(metaclass=typing.Type): pass"
    module = ast.parse(code)
    expected_module = "from six import with_metaclass as _py_backwards_six_withmetaclass" \
                      "\nclass A(_py_backwards_six_withmetaclass(typing.Type),):" \
                      "\n    pass"
    t = MetaclassTransformer(code)
    assert t.visit(module).body[0].body is not None
    assert t.visit(module).body[0].body[0].value.args == (ast.Name(id='typing.Type'),)


# Generated at 2022-06-21 17:44:23.156356
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..transpile import Transpiler
    from .base import SourceCode
    import os
    import astor

    test_dir = os.path.dirname(__file__)
    path = os.path.join(test_dir, 'test_sources/metaclass.py')
    source = open(path).read()
    source_code = SourceCode.from_string(source)
    transpiler = Transpiler()
    transpiler.register_transformer(MetaclassTransformer)
    with transpiler.setup(source_code):
        transpiler.transpile()
        source_code.to_string()
        source_code.append_output(six_import.get_body())
        transpiler.push(source_code)
        # result = astor.to_source(source_

# Generated at 2022-06-21 17:45:08.300685
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import parse
    from .base import BaseNodeTransformerTestCase
    from .six_transformer import SixTransformer
    from .bases_transformer import BasesTransformer

    class TestMetaclassTransformer(BaseNodeTransformerTestCase):
        transformer = MetaclassTransformer
        method = 'visit_Module'

        def test_backwards_six_with_metaclass(self):
            tree = parse('class A(metaclass=type): pass')
            tree = MetaclassTransformer.visit(tree)
            tree = SixTransformer.visit(tree)
            expected = parse('''
            class A(_py_backwards_six_withmetaclass(type, object)): pass
            '''.lstrip())
            self.assertEqual(tree, expected)

    TestMetac