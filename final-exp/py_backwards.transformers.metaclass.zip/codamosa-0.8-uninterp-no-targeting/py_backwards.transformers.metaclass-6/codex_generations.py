

# Generated at 2022-06-21 17:35:16.828700
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = """
    class X(metaclass=y): pass
    """
    nodes = parse(source)
    out = MetaclassTransformer()
    out.visit_Module(nodes)
    res = unparse(out.visit_Module(nodes))
    assert res == '''
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class X(_py_backwards_six_withmetaclass(y)):
        pass
    '''

# Generated at 2022-06-21 17:35:28.725162
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert six_import.get_body() == [
        ast.Import(names=[ast.alias(name='six',
                                    asname=None)])
    ]
    assert class_bases.get_body(metaclass=ast.Name(id='B', ctx=ast.Load()), bases=[
        ast.Name(id='A', ctx=ast.Load())
    ]) == [
        ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load()),
                 args=[ast.Name(id='metaclass', ctx=ast.Load()),
                       ast.Starred(value=ast.Name(id='bases', ctx=ast.Load()), ctx=ast.Load())],
                 keywords=[])
    ]

# Generated at 2022-06-21 17:35:29.706704
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class A:
        class B:
            pass
    assert A() is not None  # Ensure that our class is working

# Generated at 2022-06-21 17:35:31.263982
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import run_transformer


# Generated at 2022-06-21 17:35:35.236447
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    classdef = ast.parse("class A(metaclass=B): pass")
    result = MetaclassTransformer().visit(classdef)
    assert astor.to_source(result) == 'class A(_py_backwards_six_withmetaclass(B)):\n    pass'

# Generated at 2022-06-21 17:35:42.109836
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """class A(metaclass=B): pass"""
    expected = """class A(_py_backwards_six_with_metaclass(B)): pass"""
    with pytest.raises(NotImplementedError):
        six_import.insert(0, expected)
    six_import.insert(0, expected)
    class_bases.insert(expected)
    node = ast.parse(code)  # type: ignore
    node = MetaclassTransformer().visit(node)
    assert six_import.remove() == expected
    assert class_bases.remove() == expected
    check_source_code(node, code)



# Generated at 2022-06-21 17:35:49.444624
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    node = ast.parse('class A(metaclass=B):pass')
    MetaclassTransformer().visit(node)
    assert astor.to_source(node) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B))\n    pass\n'



# Generated at 2022-06-21 17:35:59.927607
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.const import TEST_CASE

    tree = test_tree_from(TEST_CASE, MetaclassTransformer)  # type: ast.Module

    assert(len(tree.body) == 2)
    assert(isinstance(tree.body[0], ast.ImportFrom))
    assert(tree.body[0].module == 'six')
    assert(len(tree.body[0].names) == 1)
    assert(tree.body[0].names[0].name == 'with_metaclass')
    assert(tree.body[0].names[0].asname == '_py_backwards_six_withmetaclass')
    assert(isinstance(tree.body[1], ast.ClassDef))


# Generated at 2022-06-21 17:36:08.008837
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = "class A(metaclass=B): pass"
    node = ast.parse(source, '<test>', 'exec')  # type: ignore

    transformer = MetaclassTransformer()
    node = transformer.visit(node)

    assert transformer._tree_changed


# Generated at 2022-06-21 17:36:13.926982
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor

    module_ast = ast.parse("""
    class A(metaclass=B):
        pass
    """)

    # Test 1
    original = astor.to_source(module_ast)
    transformer = MetaclassTransformer()
    transformed = astor.to_source(transformer.visit(module_ast))
    assert transformer._changed == 0

    # Test 2
    transformer = MetaclassTransformer()
    transformer.visit(module_ast)
    transformed = astor.to_source(module_ast)

# Generated at 2022-06-21 17:36:23.143899
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # Given
    code = six_import.snippet() + '\n' + class_bases.snippet() + '\n' + 'class A(metaclass=B, x=2): pass'
    module = ast.parse(code)

    # When
    MetaclassTransformer().visit(module)

    # Then
    expected = six_import.snippet() + '\n' + class_bases.snippet() + '\n' + 'class A(_py_backwards_six_withmetaclass(B, B)): pass'
    expected_module = ast.parse(expected)
    assert ast.dump(module) == ast.dump(expected_module)

# Generated at 2022-06-21 17:36:33.257878
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    def check(tree: ast.AST) -> None:
        """Check that the tree is transformed correctly"""
        node = tree.body[0]
        assert isinstance(node, ast.ClassDef)
        assert len(node.bases) == 1
        assert node.bases[0].func.id == '_py_backwards_six_withmetaclass'
        assert len(node.bases[0].args) == 1
        assert isinstance(node.bases[0].args[0], ast.Name)
        assert node.bases[0].args[0].id == 'B'
        assert node.keywords == []

    # Test with a normal module
    tree = parse('''\
        class A(metaclass=B):
            pass
        ''')
    check(tree)

    # Test with

# Generated at 2022-06-21 17:36:42.574133
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..pygram import python_symbols as syms
    import typed_ast.ast3 as ast3
    trans = MetaclassTransformer()

    # Test metaclass assignment
    example_tree = ast3.parse('class Test(metaclass=type): pass', mode='exec')
    new_tree = trans.visit(example_tree)
    assert new_tree.body[0].body == []
    assert new_tree.body[0].bases[0].args[0].id == 'type'
    assert new_tree.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'

    # Test metaclass inheritance
    example_tree = ast3.parse('class Test(object, metaclass=type): pass', mode='exec')
    new_tree

# Generated at 2022-06-21 17:36:47.908114
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import asttokens, ast
    atok = asttokens.ASTTokens(six_import.source(), parse=True)
    mt = MetaclassTransformer({}, 2, 7)
    assert mt.visit(atok.tree) == atok.tree


# Generated at 2022-06-21 17:36:55.317475
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Testing the visit_ClassDef method of the MetaclassTransformer with one
    ClassDef node and a visitor.
    
    """
    node = ast.parse(
        """class A(metaclass=B):
            pass""")
    tr = MetaclassTransformer()
    assert tr.visit(node) == node

# Generated at 2022-06-21 17:37:03.168035
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import ast_check, make_fixture_path
    from .base import BaseNodeTransformer
    from ast import ClassDef, parse

    text_before = '''
        class A(metaclass=B):
            pass
    '''
    text_after = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    '''
    class_def_before = parse(text_before).body[0]
    class_def_after = parse(text_after).body[1]
    assert(type(class_def_before) == ClassDef)
    assert(type(class_def_after) == ClassDef)

    # check if both nodes are equal

# Generated at 2022-06-21 17:37:12.331028
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = '''   
        class A(metaclass=B):
            pass
    '''
    expected_output = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(_py_backwards_six_withmetaclass(B)):
            pass
    '''
    # Use astor because the two trees are not comparable with the == operator.
    # It is due to the fact that the line numbers are in different places.
    # The astor library formats the trees in a standard way.
    tree = _get_tree(source)
    node_transformer = MetaclassTransformer()
    tree = node_transformer.visit(tree)
    expected_output = astor.to_source(ast.parse(expected_output)).strip()

# Generated at 2022-06-21 17:37:21.480880
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    if sys.version_info < (3, 5):
        pytest.skip()

    a = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    metaclass_transformer = MetaclassTransformer()
    assert metaclass_transformer.transform(a) == expected

# Generated at 2022-06-21 17:37:33.794087
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_utils import assert_py_src_eq

    class TestTransformer(MetaclassTransformer):
        def __init__(self):
            self.tree_changed = False

        def visit(self, node: ast.AST) -> ast.AST:
            node = self.generic_visit(node)  # type: ignore
            return node

    # Test all visit methods
    # This is done by checking that tree has not been changed
    # by the visit

    # Test visit_Module
    before_module = ast.parse("class A(metaclass=B): pass")
    after_module = ast.parse("from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)): pass")
    new_

# Generated at 2022-06-21 17:37:38.013285
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("""
        class A(metaclass=B):
            pass
    """)

    expected = ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    MetaclassTransformer.visit(node)
    assert ast.dump(node) == ast.dump(expected)



# Generated at 2022-06-21 17:37:49.513002
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import unittest
    from ..utils.testutils import make_test_case, find_line_numbers, print_test_code

    class TestMetaclassTransformer(unittest.TestCase):

        def test_metaclass(self):
            self.assertEqual(find_line_numbers(metaclass_test), (2, 5))

    test_case = make_test_case(TestMetaclassTransformer, metaclass_test)
    if __debug__:
        print_test_code(metaclass_test)
    unittest.TextTestRunner().run(test_case)


# Generated at 2022-06-21 17:37:52.148422
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer(None, None)
    assert transformer

# Generated at 2022-06-21 17:37:52.823479
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:37:59.249346
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from textwrap import dedent

    code = dedent("""\
    class A(metaclass=B):
        pass
    """)

    result = dedent("""\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

    node = ast.parse(code)
    MetaclassTransformer().visit(node)
    assert ast.dump(node) == ast.dump(ast.parse(result))

# Generated at 2022-06-21 17:38:03.674907
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # test:
    # class A(metaclass=B):
    #    pass
    # is complied to:
    # class A(_py_backwards_six_with_metaclass(B)):
    #    pass
    from ..utils.snippet import snippet_to_ast, snippet_equal
    from ..utils.compiler import compile_src
    metaclass_transformer = MetaclassTransformer()
    node = snippet_to_ast.get_ast('''
    class A(metaclass=B):
        pass
    ''')

# Generated at 2022-06-21 17:38:05.040161
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer()



# Generated at 2022-06-21 17:38:12.480981
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_parses, assert_source

    source = '''
        class A(metaclass=B):
            pass
    '''

    expected_source = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
    '''

    assert_parses(MetaclassTransformer, source, expected_source)

# Generated at 2022-06-21 17:38:14.261964
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..fixer_util import cst_to_ast, parse_compile_ast


# Generated at 2022-06-21 17:38:24.869353
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Arrange
    import textwrap
    input_code = textwrap.dedent('''\
        class A(metaclass=B):
            pass
        ''')
    expected_code = textwrap.dedent('''\
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
        ''')
    expected_tree = ast.parse(expected_code)

    # Act
    actual_tree = ast.parse(input_code)
    actual_tree = MetaclassTransformer().visit(actual_tree)

    # Assert
    assert ast.dump(expected_tree, annotate_fields=False) == ast.dump(actual_tree, annotate_fields=False)

# Generated at 2022-06-21 17:38:32.744215
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    import astor
    import ast
    # Test inputs
    class_def = ast.parse("""
    class A(object):
        def __init__(self, x):
            self.x = x
    """)
    class_def_1 = ast.parse("""
    class A(object, metaclass=object):
        def __init__(self, x):
            self.x = x
    """)
    # Unit test for constructor of class MetaclassTransformer
    def test_visit_ClassDef():
        mt = MetaclassTransformer()
        mt.visit(class_def)

# Generated at 2022-06-21 17:38:50.251565
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast

    # Original code
    code = ("class A(metaclass=B):\n"
            "    pass")
    module = ast.parse(code)
    expected = ("from six import with_metaclass as _py_backwards_six_withmetaclass\n"
                "\n"
                "class A(_py_backwards_six_withmetaclass(B))")

    # Test
    t = MetaclassTransformer()
    new_module = t.visit(module)
    assert t.tree_changed()
    assert ast.dump(new_module) == ast.dump(ast.parse(expected))

# Generated at 2022-06-21 17:38:51.575984
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:39:01.863224
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import uast
    source = """
        class A(object, metaclass=B):
            pass
    """
    trans = MetaclassTransformer()
    expected = ast.Module(body=[ast.ImportFrom(module='six', names=[ast.alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0),
                                ast.ClassDef(name='A',
                                             bases=[ast.Expr(value=ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass'),
                                                                            args=[ast.Name(id='object'), ast.Name(id='B')], keywords=[]))],
                                             keywords=[], body=[], decorator_list=[])])
    uast.compare

# Generated at 2022-06-21 17:39:08.045716
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tree = ast.parse("""class A(metaclass=B):

    def __init__(self):
        pass
    """)
    import astunparse
    tree = MetaclassTransformer().visit(tree)
    code = astunparse.unparse(tree)


# Generated at 2022-06-21 17:39:13.361191
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    t = MetaclassTransformer()
    node = ast.parse(dedent('''\
        class A(metaclass=B):
            pass'''))
    t.visit(node)
    assert 'from six import with_metaclass as _py_backwards_six_withmetaclass' in astor.to_source(node)
    assert astor.to_source(node).count('_py_backwards_six_withmetaclass') == 2
    assert astor.to_source(node).count('metaclass') == 0


# Generated at 2022-06-21 17:39:24.883254
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import sys
    import os
    sys.path.append(os.path.abspath(os.path.dirname(__file__) + '/..'))
    from transformers.utils.tree import compile

    from six import with_metaclass
    from .visitors.classdef import ClassDef
    from .visitors.expr import Expr
    from .visitors.name import Name
    from .visitors.module import Module

    class Ext(with_metaclass(int)):
        pass

    def m1():
        class Ext2(with_metaclass(int)):
            pass

    def m2():
        class Ext3(with_metaclass(int)):
            pass

    tree = ast.parse(compile(Ext))
    expected = ast.parse

# Generated at 2022-06-21 17:39:30.638641
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import get_ast

    a = get_ast("""
        class A(metaclass=B):
            pass
    """)
    t = MetaclassTransformer()
    t.visit(a)
    assert t._tree_changed is True
    assert len(t.ast_errors) == 0
    assert a.body[0].body[0].bases[0].args[0].func.id == "B"
    assert a.body[0].body[0].keywords == []



# Generated at 2022-06-21 17:39:31.625752
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:39:32.414484
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:39:37.824886
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..test_utils import assert_transformation
    assert_transformation(
        MetaclassTransformer,
        """
        class A(metaclass=B):
            pass
        """,
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    )

# Generated at 2022-06-21 17:39:54.916190
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class A:
        def __init__(self, a):
            self.a = a
        def make_list(self):
            return [1]

    test_input = ast.parse(inspect.getsource(A))

# Generated at 2022-06-21 17:40:06.278524
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source

    from .. import ast_transformer
    from ..ast_transformer import NAME_MAP
    from ..utils.source import source, source_for_module

    transformer_class = NAME_MAP['metaclass= to with_metaclass()']

    snippet_code = """
        class A(metaclass=B):
            pass
    """

    expected_code = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """

    actual_code = ast_transformer.transform_source(snippet_code, transformer_class)
    expected = source_for_module(expected_code)[0][0]

# Generated at 2022-06-21 17:40:17.722792
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from astunparse import unparse
    from ..utils.ast_helper import parse
    node = parse("class A(metaclass=B):\n    pass")
    MetaclassTransformer().visit(node)
    assert unparse(node) == "from six import with_metaclass as _py_backwards_six_withmetaclass\n" \
                             "\n" \
                             "class A(_py_backwards_six_withmetaclass(B))"
    node = parse("class A(B, metaclass=C):\n    pass")
    MetaclassTransformer().visit(node)

# Generated at 2022-06-21 17:40:24.907795
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .tester import AST_TESTS
    from ..utils.source import Source

    tests = [
        [("class Hello(metaclass=type): pass\n",
         """class Hello(_py_backwards_six_with_metaclass(type)): pass""")]
    ]

    AST_TESTS.register_test_set('metaclass', MetaclassTransformer, tests)
    AST_TESTS.run_tests(__file__, Source.from_test_dir)

if __name__ == '__main__':
    test_MetaclassTransformer()

# Generated at 2022-06-21 17:40:35.693888
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.ast import as_ast, parse
    from ..utils.comments import strip_comments
    from ..utils.source import dump_python
    from ..utils.tree import to_dict
    from .base import BaseNodeTransformer
    from .comments import CommentsTransformer
    from .doc_strings import DocStringsTransformer
    from .. import six
    import ast

    class_def = '''
        class A(metaclass=B):
            '''

    class_def_output = '''
        class A(_py_backwards_six_with_metaclass(B)):
            '''

    six_import_output = '''
        from six import with_metaclass as _py_backwards_six_with_metaclass'''

    class_def_code = class_def.strip()
    class_

# Generated at 2022-06-21 17:40:47.505077
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import os

    from typed_ast import ast3 as ast
    from ..utils.tree import ast_print

    with open(os.path.join(os.path.dirname(__file__), "data", "MetaclassTransformer.py")) as _file:
        input = _file.read()
        node = ast.parse(input)
    expected = ast.parse(six_import.resolve())
    expected.body.extend(ast.parse(input).body)
    print(ast_print(node))
    trans = MetaclassTransformer()
    node = trans.visit(node)
    print(ast_print(node))
    assert ast_print(node) == ast_print(expected)

# Generated at 2022-06-21 17:40:50.039607
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astunparse


# Generated at 2022-06-21 17:40:54.295916
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    class_def = ast.ClassDef(name='C')

    # When
    node = MetaclassTransformer().visit(class_def)

    # Then
    assert node is class_def



# Generated at 2022-06-21 17:40:58.077928
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class FakeNode(ast.AST):
        a = 1

    t = MetaclassTransformer()
    assert isinstance(t, BaseNodeTransformer)
    assert t.dependencies == ['six']
    assert t.target == (2, 7)

    node = FakeNode()
    assert t.visit(node) == node



# Generated at 2022-06-21 17:41:08.357612
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    def assert_transformation(target: str, result: str) -> None:
        module = parse(target)
        MetaclassTransformer().visit(module)
        assert unparse(module) == result
        scope = Scope.from_node(module)
        scope.analyze()
        assert scope.resolve('_py_backwards_six_withmetaclass') == 'six.with_metaclass'

    assert_transformation(
        '''
            class A:
                pass
        ''',
        '''
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A:
                pass
        ''',
    )



# Generated at 2022-06-21 17:41:44.912131
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("class A(metaclass=type): pass")
    tree = MetaclassTransformer().visit(node)
    assert ast.dump(tree) == "from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(type))"

# Generated at 2022-06-21 17:41:53.410523
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import textwrap
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_equal_ast
    from ..utils.tree import get_root_node

    module_node = ast.parse(textwrap.dedent('''
        class A:
            pass
        '''))
    class_node = get_root_node(ast.ClassDef(name='A', body=[]), module_node, ast.Module)
    metaclass_node = ast.keyword(arg='metaclass', value=ast.Name(id='B'))
    class_node.keywords = [metaclass_node]


# Generated at 2022-06-21 17:41:57.139275
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class Transformer(MetaclassTransformer):
        def __init__(self):
            self._tree_changed = False

    bnf_parser = BackportPythonBNF()

# Generated at 2022-06-21 17:42:03.163115
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class A(metaclass=B):
        pass

    def wrap_class_in_module(x):
        return ast.Module(body=ast.ClassDef(name='A', bases=[], keywords=[], body=[], decorator_list=[]))

# Generated at 2022-06-21 17:42:10.510526
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import parse
    from .six import insert_six_import

    m = parse('class A(metaclass=B, baz=1): pass')
    expect = 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B, object), baz=1): pass'

    insert_six_import.apply_to(m)
    MetaclassTransformer.apply_to(m)
    new = ast.fix_missing_locations(m)
    expect = ast.parse(expect)
    assert ast.dump(new) == ast.dump(expect)

# Generated at 2022-06-21 17:42:19.061326
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import astunparse
    node = ast.parse("""class A(metaclass=B):
    pass""", "", "exec")
    t = MetaclassTransformer()
    t.visit(node)
    res = astunparse.unparse(node)
    assert res == dedent("""\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(_py_backwards_six_withmetaclass(B)):
        pass""")

# Generated at 2022-06-21 17:42:26.320679
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.testutils import assert_node_equals
    from .. import parse
    import sys

    # if sys.version_info <= (3, 6):
    #     pytest.skip("Requires Python 3.7")


# Generated at 2022-06-21 17:42:35.040858
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.fakeast import AstSchema, Module, ClassDef, Name, arg, arg_no_value

    schema = AstSchema(
        Module(
            body=[
                ClassDef(
                    name='A',
                    bases=[
                        Name(id='object'),
                    ],
                    keywords=[
                        arg(
                            arg='metaclass',
                            value=Name(id='A'),
                        ),
                    ],
                ),
                ClassDef(
                    name='B',
                    bases=[
                        Name(id='object'),
                    ],
                    keywords=[
                        arg_no_value('metaclass'),
                    ],
                ),
            ],
        ),
    )

    assert schema == MetaclassTransformer.run_on_schema(schema)

# Generated at 2022-06-21 17:42:41.122024
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys

    node = ast.parse("""
        class A(metaclass=B):
            pass
    """)

    six_import.assert_matches(MetaclassTransformer().visit(node))

    sys.version_info = (2, 7)
    cls_bases = ast.parse("""
        class A(B):
            pass
    """)

    node.bases = cls_bases.body[0].bases
    node.keywords = []
    six_import.assert_matches(MetaclassTransformer().visit(node))


# Generated at 2022-06-21 17:42:44.386619
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3
    from ..compiler import Compiler


# Generated at 2022-06-21 17:44:00.970926
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    s = ast.parse(
        """
        class A(metaclass = B, C, D):
            pass
        """)
    node1 = s.body[0]
    t = MetaclassTransformer()
    s = t.visit(s)
    import astunparse
    astunparse.unparse(s)

    assert s.body[0].body[0].bases[0].func.value.id == '_py_backwards_six_withmetaclass'
    assert s.body[0].body[0].bases[0].args[0].id == 'B'
    assert s.body[0].body[0].bases[0].args[1].id == 'C'

# Generated at 2022-06-21 17:44:06.286824
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """
    class A(metaclass=B):
        pass
    """
    source = source_from_example(visit_Module)
    expected = source_from_example(visit_Module, suffix='expected')
    node = parse(source)
    tree = MetaclassTransformer().visit(node)
    assert compare_source(tree, expected)



# Generated at 2022-06-21 17:44:12.754823
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    (result, target) = six_import.get_ast()
    print(result)
    print(six_import)
    print(result.__class__)
    print(target.__class__)
    #print(six_import)
    #print(six_import.get_ast())
    #print(six_import.get_source())
    print(six_import.replace('{{missing}}', 'test1'))
    print(six_import.replace({'{{missing}}': 'test1', '@': ''}))

# Generated at 2022-06-21 17:44:15.113401
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_transformer import AstTransformer

# Generated at 2022-06-21 17:44:20.009272
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class Test(unittest.TestCase):
        def setUp(self):
            self.maxDiff=None
        def test_py27(self):
            in_str = '''class Foo(metaclass=Bar):
    pass'''

# Generated at 2022-06-21 17:44:25.417635
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast as std_ast
    import textwrap
    source = textwrap.dedent("""\
        class A(metaclass=B):
            pass
        """)
    compare = textwrap.dedent("""\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """)

    tree = std_ast.parse(source)
    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)
    assert std_ast.dump(tree) == compare
    assert transformer._tree_changed is True


# Generated at 2022-06-21 17:44:30.643000
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # set up
    # call the method under test
    transformer = MetaclassTransformer()  # type: ignore
    arg1 = ast.Module(body=[])
    result = transformer.visit_Module(arg1)

    # check the result
    assert isinstance(result, ast.Module)
    assert result.body == six_import.get_body() + arg1.body


# Generated at 2022-06-21 17:44:33.535225
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest

    import typed_astunparse
    from ...utils import test_node as test_node


# Generated at 2022-06-21 17:44:39.984020
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from . import Python2to3TreeTestCase
    class Transformer(MetaclassTransformer):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._tree_changed = False

        def changed(self):
            return self._tree_changed


# Generated at 2022-06-21 17:44:51.767237
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import unittest

    class TestMetaclassTransformer(unittest.TestCase):
        def test_transformer(self):
            transformer = MetaclassTransformer()

            result_bases = class_bases.get_body(metaclass=ast.Name(id='B', ctx=ast.Load()),
                                                bases=[ast.Name(id='A', ctx=ast.Load())])
            node_bases = ast.ClassDef(name='A',
                                      bases=result_bases)
            result_body = [ast.ImportFrom(module='six',
                                          names=[ast.alias(name='with_metaclass',
                                                           asname='_py_backwards_six_withmetaclass')],
                                          level=0)]